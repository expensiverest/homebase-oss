###### Class il.d (il.d)
.class public interface abstract Lil/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljl/d;


# virtual methods
.method public abstract get(I)Ljava/lang/Object;
.end method
