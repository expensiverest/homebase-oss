###### Class il.c (il.c)
.class public final Lil/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lil/b;
.implements Landroidx/customview/widget/c;
.implements Lc4/m;
.implements Lio/sentry/util/d;
.implements Lj5/d;
.implements Lj4/o;
.implements La20/b;
.implements Loq/b;
.implements Lww/h;


# static fields
.field public static d:Lil/c;


# direct methods
.method public static final i(Landroid/database/sqlite/SQLiteDatabase;I)V
    .registers 8

    .line 1
    const-string v0, "CREATE TABLE telemetry_ring_slots (slot_id INTEGER PRIMARY KEY, seq INTEGER NOT NULL, channel_mask INTEGER NOT NULL, payload_json TEXT, payload_size INTEGER NOT NULL)"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "CREATE TABLE telemetry_ring_meta (id INTEGER PRIMARY KEY CHECK (id=1), head INTEGER NOT NULL, tail INTEGER NOT NULL, count INTEGER NOT NULL, total_bytes INTEGER NOT NULL, next_seq INTEGER NOT NULL, capacity INTEGER NOT NULL)"

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "CREATE INDEX idx_ring_seq ON telemetry_ring_slots(seq)"

    .line 12
    .line 13
    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Landroid/content/ContentValues;

    .line 17
    .line 18
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 19
    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const-string v2, "id"

    .line 27
    .line 28
    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 29
    .line 30
    .line 31
    const/4 v2, -0x1

    .line 32
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    const-string v3, "head"

    .line 37
    .line 38
    invoke-virtual {v0, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 39
    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    const-string v4, "tail"

    .line 47
    .line 48
    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 49
    .line 50
    .line 51
    const-string v4, "count"

    .line 52
    .line 53
    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 54
    .line 55
    .line 56
    const-string v4, "total_bytes"

    .line 57
    .line 58
    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 59
    .line 60
    .line 61
    const-string v4, "next_seq"

    .line 62
    .line 63
    invoke-virtual {v0, v4, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 64
    .line 65
    .line 66
    const-string v1, "capacity"

    .line 67
    .line 68
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    invoke-virtual {v0, v1, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 73
    .line 74
    .line 75
    const-string v1, "telemetry_ring_meta"

    .line 76
    .line 77
    const/4 v4, 0x0

    .line 78
    invoke-virtual {p0, v1, v4, v0}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 79
    .line 80
    .line 81
    new-instance v0, Landroid/content/ContentValues;

    .line 82
    .line 83
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 84
    .line 85
    .line 86
    :goto_55
    if-ge v2, p1, :cond_7f

    .line 87
    .line 88
    invoke-virtual {v0}, Landroid/content/ContentValues;->clear()V

    .line 89
    .line 90
    .line 91
    const-string v1, "slot_id"

    .line 92
    .line 93
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object v5

    .line 97
    invoke-virtual {v0, v1, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 98
    .line 99
    .line 100
    const-string v1, "seq"

    .line 101
    .line 102
    invoke-virtual {v0, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 103
    .line 104
    .line 105
    const-string v1, "channel_mask"

    .line 106
    .line 107
    invoke-virtual {v0, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 108
    .line 109
    .line 110
    const-string v1, "payload_json"

    .line 111
    .line 112
    invoke-virtual {v0, v1}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    const-string v1, "payload_size"

    .line 116
    .line 117
    invoke-virtual {v0, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 118
    .line 119
    .line 120
    const-string v1, "telemetry_ring_slots"

    .line 121
    .line 122
    invoke-virtual {p0, v1, v4, v0}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 123
    .line 124
    .line 125
    add-int/lit8 v2, v2, 0x1

    .line 126
    .line 127
    goto :goto_55

    .line 128
    :cond_7f
    return-void
.end method

.method public static j(Ljl/b;)Ljl/b;
    .registers 3

    .line 1
    :try_start_0
    invoke-static {p0}, Ljl/b;->x(Ljl/b;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_2a

    .line 6
    .line 7
    invoke-static {p0}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Ljl/b;->n()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    instance-of v0, v0, Lgn/d;

    .line 15
    .line 16
    if-eqz v0, :cond_2a

    .line 17
    .line 18
    invoke-virtual {p0}, Ljl/b;->n()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lgn/d;

    .line 23
    .line 24
    check-cast v0, Lgn/g;

    .line 25
    .line 26
    monitor-enter v0
    :try_end_1a
    .catchall {:try_start_0 .. :try_end_1a} :catchall_28

    .line 27
    :try_start_1a
    iget-object v1, v0, Lgn/g;->v:Ljl/b;

    .line 28
    .line 29
    invoke-static {v1}, Ljl/b;->i(Ljl/b;)Ljl/b;

    .line 30
    .line 31
    .line 32
    move-result-object v1
    :try_end_20
    .catchall {:try_start_1a .. :try_end_20} :catchall_25

    .line 33
    :try_start_20
    monitor-exit v0
    :try_end_21
    .catchall {:try_start_20 .. :try_end_21} :catchall_28

    .line 34
    invoke-virtual {p0}, Ljl/b;->close()V

    .line 35
    .line 36
    .line 37
    return-object v1

    .line 38
    :catchall_25
    move-exception v1

    .line 39
    :try_start_26
    monitor-exit v0
    :try_end_27
    .catchall {:try_start_26 .. :try_end_27} :catchall_25

    .line 40
    :try_start_27
    throw v1
    :try_end_28
    .catchall {:try_start_27 .. :try_end_28} :catchall_28

    .line 41
    :catchall_28
    move-exception v0

    .line 42
    goto :goto_2f

    .line 43
    :cond_2a
    invoke-static {p0}, Ljl/b;->l(Ljl/b;)V

    .line 44
    .line 45
    .line 46
    const/4 p0, 0x0

    .line 47
    return-object p0

    .line 48
    :goto_2f
    invoke-static {p0}, Ljl/b;->l(Ljl/b;)V

    .line 49
    .line 50
    .line 51
    throw v0
.end method

.method public static k(Lb80/i0;)Landroid/media/MediaCodec;
    .registers 3

    .line 1
    iget-object p0, p0, Lb80/i0;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lc4/r;

    .line 4
    .line 5
    iget-object p0, p0, Lc4/r;->a:Ljava/lang/String;

    .line 6
    .line 7
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    const-string v1, "createCodec:"

    .line 10
    .line 11
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p0}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 29
    .line 30
    .line 31
    return-object p0
.end method

.method public static l(Ljava/lang/String;)La8/a;
    .registers 2

    .line 1
    new-instance v0, Ljava/net/URL;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Ljava/net/HttpURLConnection;

    .line 11
    .line 12
    const-string v0, "GET"

    .line 13
    .line 14
    invoke-virtual {p0, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/net/URLConnection;->connect()V

    .line 18
    .line 19
    .line 20
    new-instance v0, La8/a;

    .line 21
    .line 22
    invoke-direct {v0, p0}, La8/a;-><init>(Ljava/net/HttpURLConnection;)V

    .line 23
    .line 24
    .line 25
    return-object v0
.end method

.method public static m(Ljava/lang/String;)Lrp/i0;
    .registers 3

    .line 1
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const-string v0, "toLowerCase(...)"

    .line 8
    .line 9
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const v1, -0x48916256

    .line 17
    .line 18
    .line 19
    if-eq v0, v1, :cond_37

    .line 20
    .line 21
    const v1, -0x361a1933

    .line 22
    .line 23
    .line 24
    if-eq v0, v1, :cond_2b

    .line 25
    .line 26
    const v1, 0x1bd1f072

    .line 27
    .line 28
    .line 29
    if-eq v0, v1, :cond_1f

    .line 30
    .line 31
    goto :goto_3f

    .line 32
    :cond_1f
    const-string v0, "visible"

    .line 33
    .line 34
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result p0

    .line 38
    if-nez p0, :cond_28

    .line 39
    .line 40
    goto :goto_3f

    .line 41
    :cond_28
    sget-object p0, Lrp/i0;->e:Lrp/i0;

    .line 42
    .line 43
    return-object p0

    .line 44
    :cond_2b
    const-string v0, "scroll"

    .line 45
    .line 46
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    if-nez p0, :cond_34

    .line 51
    .line 52
    goto :goto_3f

    .line 53
    :cond_34
    sget-object p0, Lrp/i0;->v:Lrp/i0;

    .line 54
    .line 55
    return-object p0

    .line 56
    :cond_37
    const-string v0, "hidden"

    .line 57
    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result p0

    .line 62
    if-nez p0, :cond_41

    .line 63
    .line 64
    :goto_3f
    const/4 p0, 0x0

    .line 65
    return-object p0

    .line 66
    :cond_41
    sget-object p0, Lrp/i0;->i:Lrp/i0;

    .line 67
    .line 68
    return-object p0
.end method

.method public static declared-synchronized n()Lil/c;
    .registers 2

    .line 1
    const-class v0, Lil/c;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, Lil/c;->d:Lil/c;

    .line 5
    .line 6
    if-nez v1, :cond_11

    .line 7
    .line 8
    new-instance v1, Lil/c;

    .line 9
    .line 10
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lil/c;->d:Lil/c;

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :catchall_f
    move-exception v1

    .line 17
    goto :goto_15

    .line 18
    :cond_11
    :goto_11
    sget-object v1, Lil/c;->d:Lil/c;
    :try_end_13
    .catchall {:try_start_3 .. :try_end_13} :catchall_f

    .line 19
    .line 20
    monitor-exit v0

    .line 21
    return-object v1

    .line 22
    :goto_15
    :try_start_15
    monitor-exit v0
    :try_end_16
    .catchall {:try_start_15 .. :try_end_16} :catchall_f

    .line 23
    throw v1
.end method

.method public static o(Landroid/util/JsonReader;Lhx/j0;)V
    .registers 12

    .line 1
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginArray()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :goto_4
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_1b4

    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sget-object v2, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1af

    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 24
    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    move-object v1, v0

    .line 28
    move-object v2, v1

    .line 29
    move-object v3, v2

    .line 30
    :goto_1d
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_186

    .line 35
    .line 36
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    const-string v5, "BASE-ID"

    .line 41
    .line 42
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v5

    .line 46
    if-eqz v5, :cond_40

    .line 47
    .line 48
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    sget-object v6, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 53
    .line 54
    invoke-virtual {v5, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    if-eqz v5, :cond_40

    .line 59
    .line 60
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    goto :goto_1d

    .line 65
    :cond_40
    const-string v5, "ID"

    .line 66
    .line 67
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    if-eqz v5, :cond_59

    .line 72
    .line 73
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    sget-object v6, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 78
    .line 79
    invoke-virtual {v5, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    if-eqz v5, :cond_59

    .line 84
    .line 85
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    goto :goto_1d

    .line 90
    :cond_59
    const-string v5, "URI-REPLACEMENT"

    .line 91
    .line 92
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    if-eqz v4, :cond_181

    .line 97
    .line 98
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    sget-object v5, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 103
    .line 104
    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    if-eqz v4, :cond_181

    .line 109
    .line 110
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 111
    .line 112
    .line 113
    new-instance v3, Ljava/util/HashMap;

    .line 114
    .line 115
    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    .line 116
    .line 117
    .line 118
    new-instance v4, Ljava/util/HashMap;

    .line 119
    .line 120
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 121
    .line 122
    .line 123
    new-instance v5, Ljava/util/HashMap;

    .line 124
    .line 125
    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    .line 126
    .line 127
    .line 128
    move-object v6, v0

    .line 129
    :goto_80
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 130
    .line 131
    .line 132
    move-result v7

    .line 133
    if-eqz v7, :cond_176

    .line 134
    .line 135
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    const-string v8, "HOST"

    .line 140
    .line 141
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v8

    .line 145
    if-eqz v8, :cond_b0

    .line 146
    .line 147
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 148
    .line 149
    .line 150
    move-result-object v8

    .line 151
    sget-object v9, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 152
    .line 153
    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v8

    .line 157
    if-eqz v8, :cond_b0

    .line 158
    .line 159
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v6

    .line 163
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 164
    .line 165
    .line 166
    move-result v7

    .line 167
    if-nez v7, :cond_a9

    .line 168
    .line 169
    goto :goto_80

    .line 170
    :cond_a9
    const-string p0, "The HOST string is present but empty"

    .line 171
    .line 172
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 173
    .line 174
    .line 175
    move-result-object p0

    .line 176
    throw p0

    .line 177
    :cond_b0
    const-string v8, "PARAMS"

    .line 178
    .line 179
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result v8

    .line 183
    if-eqz v8, :cond_ed

    .line 184
    .line 185
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 186
    .line 187
    .line 188
    move-result-object v8

    .line 189
    sget-object v9, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 190
    .line 191
    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v8

    .line 195
    if-eqz v8, :cond_ed

    .line 196
    .line 197
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 198
    .line 199
    .line 200
    :goto_c7
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 201
    .line 202
    .line 203
    move-result v7

    .line 204
    if-eqz v7, :cond_e9

    .line 205
    .line 206
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v7

    .line 210
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 211
    .line 212
    .line 213
    move-result-object v8

    .line 214
    sget-object v9, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 215
    .line 216
    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result v8

    .line 220
    if-eqz v8, :cond_e5

    .line 221
    .line 222
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object v8

    .line 226
    invoke-virtual {v3, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    goto :goto_c7

    .line 230
    :cond_e5
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 231
    .line 232
    .line 233
    goto :goto_c7

    .line 234
    :cond_e9
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 235
    .line 236
    .line 237
    goto :goto_80

    .line 238
    :cond_ed
    const-string v8, "PER-VARIANT-URIS"

    .line 239
    .line 240
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 241
    .line 242
    .line 243
    move-result v8

    .line 244
    if-eqz v8, :cond_12f

    .line 245
    .line 246
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 247
    .line 248
    .line 249
    move-result-object v8

    .line 250
    sget-object v9, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 251
    .line 252
    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 253
    .line 254
    .line 255
    move-result v8

    .line 256
    if-eqz v8, :cond_12f

    .line 257
    .line 258
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 259
    .line 260
    .line 261
    :goto_104
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 262
    .line 263
    .line 264
    move-result v7

    .line 265
    if-eqz v7, :cond_12a

    .line 266
    .line 267
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object v7

    .line 271
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 272
    .line 273
    .line 274
    move-result-object v8

    .line 275
    sget-object v9, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 276
    .line 277
    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-result v8

    .line 281
    if-eqz v8, :cond_126

    .line 282
    .line 283
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v8

    .line 287
    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 288
    .line 289
    .line 290
    move-result-object v8

    .line 291
    invoke-virtual {v4, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    goto :goto_104

    .line 295
    :cond_126
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 296
    .line 297
    .line 298
    goto :goto_104

    .line 299
    :cond_12a
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 300
    .line 301
    .line 302
    goto/16 :goto_80

    .line 303
    .line 304
    :cond_12f
    const-string v8, "PER-RENDITION-URIS"

    .line 305
    .line 306
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v7

    .line 310
    if-eqz v7, :cond_171

    .line 311
    .line 312
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 313
    .line 314
    .line 315
    move-result-object v7

    .line 316
    sget-object v8, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 317
    .line 318
    invoke-virtual {v7, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v7

    .line 322
    if-eqz v7, :cond_171

    .line 323
    .line 324
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 325
    .line 326
    .line 327
    :goto_146
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 328
    .line 329
    .line 330
    move-result v7

    .line 331
    if-eqz v7, :cond_16c

    .line 332
    .line 333
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 334
    .line 335
    .line 336
    move-result-object v7

    .line 337
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 338
    .line 339
    .line 340
    move-result-object v8

    .line 341
    sget-object v9, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 342
    .line 343
    invoke-virtual {v8, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 344
    .line 345
    .line 346
    move-result v8

    .line 347
    if-eqz v8, :cond_168

    .line 348
    .line 349
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v8

    .line 353
    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 354
    .line 355
    .line 356
    move-result-object v8

    .line 357
    invoke-virtual {v5, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    goto :goto_146

    .line 361
    :cond_168
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 362
    .line 363
    .line 364
    goto :goto_146

    .line 365
    :cond_16c
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 366
    .line 367
    .line 368
    goto/16 :goto_80

    .line 369
    .line 370
    :cond_171
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 371
    .line 372
    .line 373
    goto/16 :goto_80

    .line 374
    .line 375
    :cond_176
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 376
    .line 377
    .line 378
    new-instance v7, Lk4/b;

    .line 379
    .line 380
    invoke-direct {v7, v6, v3, v4, v5}, Lk4/b;-><init>(Ljava/lang/String;Ljava/util/HashMap;Ljava/util/HashMap;Ljava/util/HashMap;)V

    .line 381
    .line 382
    .line 383
    move-object v3, v7

    .line 384
    goto/16 :goto_1d

    .line 385
    .line 386
    :cond_181
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 387
    .line 388
    .line 389
    goto/16 :goto_1d

    .line 390
    .line 391
    :cond_186
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 392
    .line 393
    .line 394
    if-eqz v1, :cond_1a8

    .line 395
    .line 396
    if-eqz v2, :cond_1a1

    .line 397
    .line 398
    if-eqz v3, :cond_19a

    .line 399
    .line 400
    new-instance v0, Lk4/a;

    .line 401
    .line 402
    invoke-direct {v0, v1, v2, v3}, Lk4/a;-><init>(Ljava/lang/String;Ljava/lang/String;Lk4/b;)V

    .line 403
    .line 404
    .line 405
    invoke-virtual {p1, v0}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 406
    .line 407
    .line 408
    const/4 v0, 0x1

    .line 409
    goto/16 :goto_4

    .line 410
    .line 411
    :cond_19a
    const-string p0, "URI-REPLACEMENT field is missing in a PATHWAY-CLONE object"

    .line 412
    .line 413
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 414
    .line 415
    .line 416
    move-result-object p0

    .line 417
    throw p0

    .line 418
    :cond_1a1
    const-string p0, "ID field is missing in a PATHWAY-CLONE object"

    .line 419
    .line 420
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 421
    .line 422
    .line 423
    move-result-object p0

    .line 424
    throw p0

    .line 425
    :cond_1a8
    const-string p0, "BASE-ID field is missing in a PATHWAY-CLONE object"

    .line 426
    .line 427
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 428
    .line 429
    .line 430
    move-result-object p0

    .line 431
    throw p0

    .line 432
    :cond_1af
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 433
    .line 434
    .line 435
    goto/16 :goto_4

    .line 436
    .line 437
    :cond_1b4
    invoke-virtual {p0}, Landroid/util/JsonReader;->endArray()V

    .line 438
    .line 439
    .line 440
    if-eqz v0, :cond_1ba

    .line 441
    .line 442
    return-void

    .line 443
    :cond_1ba
    const-string p0, "The PATHWAY-CLONES array is present but empty"

    .line 444
    .line 445
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 446
    .line 447
    .line 448
    move-result-object p0

    .line 449
    throw p0
.end method

.method public static p(Landroid/util/JsonReader;Lhx/j0;)V
    .registers 5

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginArray()V

    .line 7
    .line 8
    .line 9
    :goto_8
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_44

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sget-object v2, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 20
    .line 21
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_40

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_28

    .line 36
    .line 37
    invoke-virtual {p1, v1}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    goto :goto_8

    .line 41
    :cond_28
    new-instance p0, Ljava/lang/StringBuilder;

    .line 42
    .line 43
    const-string p1, "The pathway ID ("

    .line 44
    .line 45
    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    const-string p1, ") appears more than once in the PATHWAY-PRIORITY array"

    .line 52
    .line 53
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    throw p0

    .line 65
    :cond_40
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 66
    .line 67
    .line 68
    goto :goto_8

    .line 69
    :cond_44
    invoke-virtual {p0}, Landroid/util/JsonReader;->endArray()V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    .line 73
    .line 74
    .line 75
    move-result p0

    .line 76
    if-nez p0, :cond_4e

    .line 77
    .line 78
    return-void

    .line 79
    :cond_4e
    const-string p0, "The PATHWAY-PRIORITY array is present but empty"

    .line 80
    .line 81
    invoke-static {p0}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    throw p0
.end method

.method public static s(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;ZI)V
    .registers 9

    .line 1
    sget-object v0, Lfi/a;->b:Ljava/lang/Class;

    .line 2
    .line 3
    and-int/lit8 v0, p4, 0x4

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    const-wide/16 v0, 0x1388

    .line 8
    .line 9
    goto :goto_b

    .line 10
    :cond_9
    const-wide/16 v0, 0x7530

    .line 11
    .line 12
    :goto_b
    and-int/lit8 p4, p4, 0x10

    .line 13
    .line 14
    if-eqz p4, :cond_14

    .line 15
    .line 16
    new-instance p2, Landroid/os/Bundle;

    .line 17
    .line 18
    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    .line 19
    .line 20
    .line 21
    :cond_14
    const-string p4, "taskName"

    .line 22
    .line 23
    invoke-static {p1, p4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    new-instance p4, Landroid/content/Intent;

    .line 27
    .line 28
    sget-object v2, Lfi/a;->b:Ljava/lang/Class;

    .line 29
    .line 30
    invoke-direct {p4, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 31
    .line 32
    .line 33
    const-string v2, "intent.discord.headless_tasks_key"

    .line 34
    .line 35
    const/4 v3, 0x1

    .line 36
    invoke-virtual {p4, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 37
    .line 38
    .line 39
    const-string v2, "intent.discord.headless_tasks_name"

    .line 40
    .line 41
    invoke-virtual {p4, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 42
    .line 43
    .line 44
    const-string p1, "intent.discord.headless_tasks_timeout"

    .line 45
    .line 46
    invoke-virtual {p4, p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 47
    .line 48
    .line 49
    const-string p1, "intent.discord.headless_tasks_aif"

    .line 50
    .line 51
    invoke-virtual {p4, p1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 52
    .line 53
    .line 54
    const-string p1, "intent.discord.headless_tasks_params"

    .line 55
    .line 56
    invoke-virtual {p4, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0, p4}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 60
    .line 61
    .line 62
    if-eqz p3, :cond_44

    .line 63
    .line 64
    sget-object p1, Lsn/e;->e:Landroid/os/PowerManager$WakeLock;

    .line 65
    .line 66
    invoke-static {p0}, Lcom/facebook/react/uimanager/b0;->u(Landroid/content/Context;)V

    .line 67
    .line 68
    .line 69
    :cond_44
    return-void
.end method

.method public static t(Ljava/lang/Object;)Lkotlinx/serialization/json/b;
    .registers 7

    .line 1
    if-nez p0, :cond_5

    .line 2
    .line 3
    sget-object p0, Lkotlinx/serialization/json/JsonNull;->INSTANCE:Lkotlinx/serialization/json/JsonNull;

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    instance-of v0, p0, Ljava/lang/String;

    .line 7
    .line 8
    if-eqz v0, :cond_10

    .line 9
    .line 10
    check-cast p0, Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {p0}, Lo70/j;->c(Ljava/lang/String;)Lkotlinx/serialization/json/d;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0

    .line 17
    :cond_10
    instance-of v0, p0, Ljava/lang/Character;

    .line 18
    .line 19
    if-eqz v0, :cond_23

    .line 20
    .line 21
    check-cast p0, Ljava/lang/Character;

    .line 22
    .line 23
    invoke-virtual {p0}, Ljava/lang/Character;->charValue()C

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    invoke-static {p0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p0}, Lo70/j;->c(Ljava/lang/String;)Lkotlinx/serialization/json/d;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0

    .line 36
    :cond_23
    instance-of v0, p0, Ljava/lang/Boolean;

    .line 37
    .line 38
    if-eqz v0, :cond_2e

    .line 39
    .line 40
    check-cast p0, Ljava/lang/Boolean;

    .line 41
    .line 42
    invoke-static {p0}, Lo70/j;->a(Ljava/lang/Boolean;)Lkotlinx/serialization/json/d;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0

    .line 47
    :cond_2e
    instance-of v0, p0, Ljava/lang/Byte;

    .line 48
    .line 49
    if-nez v0, :cond_126

    .line 50
    .line 51
    instance-of v0, p0, Ljava/lang/Short;

    .line 52
    .line 53
    if-nez v0, :cond_126

    .line 54
    .line 55
    instance-of v0, p0, Ljava/lang/Integer;

    .line 56
    .line 57
    if-nez v0, :cond_126

    .line 58
    .line 59
    instance-of v0, p0, Ljava/lang/Long;

    .line 60
    .line 61
    if-nez v0, :cond_126

    .line 62
    .line 63
    instance-of v0, p0, Ljava/lang/Float;

    .line 64
    .line 65
    if-nez v0, :cond_126

    .line 66
    .line 67
    instance-of v0, p0, Ljava/lang/Double;

    .line 68
    .line 69
    if-eqz v0, :cond_48

    .line 70
    .line 71
    goto/16 :goto_126

    .line 72
    .line 73
    :cond_48
    instance-of v0, p0, Ljava/util/Map;

    .line 74
    .line 75
    const/16 v1, 0xa

    .line 76
    .line 77
    if-eqz v0, :cond_b5

    .line 78
    .line 79
    check-cast p0, Ljava/util/Map;

    .line 80
    .line 81
    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    if-eqz v0, :cond_5d

    .line 86
    .line 87
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    if-eqz v2, :cond_5d

    .line 92
    .line 93
    goto :goto_72

    .line 94
    :cond_5d
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    :cond_61
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 99
    .line 100
    .line 101
    move-result v2

    .line 102
    if-eqz v2, :cond_72

    .line 103
    .line 104
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    instance-of v2, v2, Ljava/lang/String;

    .line 109
    .line 110
    if-nez v2, :cond_61

    .line 111
    .line 112
    sget-object p0, Lkotlinx/serialization/json/JsonNull;->INSTANCE:Lkotlinx/serialization/json/JsonNull;

    .line 113
    .line 114
    return-object p0

    .line 115
    :cond_72
    :goto_72
    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    invoke-static {p0, v1}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    invoke-static {v0}, Lm30/x;->p0(I)I

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    const/16 v1, 0x10

    .line 128
    .line 129
    if-ge v0, v1, :cond_83

    .line 130
    .line 131
    move v0, v1

    .line 132
    :cond_83
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 133
    .line 134
    invoke-direct {v1, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 135
    .line 136
    .line 137
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    :goto_8c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-eqz v0, :cond_af

    .line 146
    .line 147
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    check-cast v0, Ljava/util/Map$Entry;

    .line 152
    .line 153
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    const-string v3, "null cannot be cast to non-null type kotlin.String"

    .line 162
    .line 163
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    check-cast v2, Ljava/lang/String;

    .line 167
    .line 168
    invoke-static {v0}, Lil/c;->t(Ljava/lang/Object;)Lkotlinx/serialization/json/b;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    goto :goto_8c

    .line 176
    :cond_af
    new-instance p0, Lkotlinx/serialization/json/c;

    .line 177
    .line 178
    invoke-direct {p0, v1}, Lkotlinx/serialization/json/c;-><init>(Ljava/util/Map;)V

    .line 179
    .line 180
    .line 181
    return-object p0

    .line 182
    :cond_b5
    instance-of v0, p0, Ljava/util/Collection;

    .line 183
    .line 184
    if-eqz v0, :cond_e0

    .line 185
    .line 186
    check-cast p0, Ljava/lang/Iterable;

    .line 187
    .line 188
    new-instance v0, Ljava/util/ArrayList;

    .line 189
    .line 190
    invoke-static {p0, v1}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 191
    .line 192
    .line 193
    move-result v1

    .line 194
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 195
    .line 196
    .line 197
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 198
    .line 199
    .line 200
    move-result-object p0

    .line 201
    :goto_c8
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 202
    .line 203
    .line 204
    move-result v1

    .line 205
    if-eqz v1, :cond_da

    .line 206
    .line 207
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    invoke-static {v1}, Lil/c;->t(Ljava/lang/Object;)Lkotlinx/serialization/json/b;

    .line 212
    .line 213
    .line 214
    move-result-object v1

    .line 215
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    goto :goto_c8

    .line 219
    :cond_da
    new-instance p0, Lkotlinx/serialization/json/a;

    .line 220
    .line 221
    invoke-direct {p0, v0}, Lkotlinx/serialization/json/a;-><init>(Ljava/util/List;)V

    .line 222
    .line 223
    .line 224
    return-object p0

    .line 225
    :cond_e0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    .line 230
    .line 231
    .line 232
    move-result v0

    .line 233
    const/4 v1, 0x0

    .line 234
    if-eqz v0, :cond_10a

    .line 235
    .line 236
    invoke-static {p0}, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I

    .line 237
    .line 238
    .line 239
    move-result v0

    .line 240
    new-instance v2, Ljava/util/ArrayList;

    .line 241
    .line 242
    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 243
    .line 244
    .line 245
    :goto_f4
    if-ge v1, v0, :cond_104

    .line 246
    .line 247
    invoke-static {p0, v1}, Ljava/lang/reflect/Array;->get(Ljava/lang/Object;I)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v3

    .line 251
    invoke-static {v3}, Lil/c;->t(Ljava/lang/Object;)Lkotlinx/serialization/json/b;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    add-int/lit8 v1, v1, 0x1

    .line 259
    .line 260
    goto :goto_f4

    .line 261
    :cond_104
    new-instance p0, Lkotlinx/serialization/json/a;

    .line 262
    .line 263
    invoke-direct {p0, v2}, Lkotlinx/serialization/json/a;-><init>(Ljava/util/List;)V

    .line 264
    .line 265
    .line 266
    return-object p0

    .line 267
    :cond_10a
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object v0

    .line 275
    const-string v2, "java."

    .line 276
    .line 277
    invoke-static {v0, v2, v1}, Lw60/v;->i0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 278
    .line 279
    .line 280
    move-result v0

    .line 281
    if-eqz v0, :cond_123

    .line 282
    .line 283
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object p0

    .line 287
    invoke-static {p0}, Lo70/j;->c(Ljava/lang/String;)Lkotlinx/serialization/json/d;

    .line 288
    .line 289
    .line 290
    move-result-object p0

    .line 291
    return-object p0

    .line 292
    :cond_123
    sget-object p0, Lkotlinx/serialization/json/JsonNull;->INSTANCE:Lkotlinx/serialization/json/JsonNull;

    .line 293
    .line 294
    return-object p0

    .line 295
    :cond_126
    :goto_126
    check-cast p0, Ljava/lang/Number;

    .line 296
    .line 297
    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    .line 298
    .line 299
    .line 300
    move-result-wide v0

    .line 301
    invoke-static {v0, v1}, Ljava/lang/Math;->abs(D)D

    .line 302
    .line 303
    .line 304
    move-result-wide v2

    .line 305
    const-wide v4, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    cmpg-double v2, v2, v4

    .line 311
    .line 312
    if-gtz v2, :cond_150

    .line 313
    .line 314
    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    .line 315
    .line 316
    .line 317
    move-result-wide v2

    .line 318
    long-to-double v4, v2

    .line 319
    cmpg-double v0, v0, v4

    .line 320
    .line 321
    if-nez v0, :cond_14b

    .line 322
    .line 323
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 324
    .line 325
    .line 326
    move-result-object p0

    .line 327
    invoke-static {p0}, Lo70/j;->b(Ljava/lang/Number;)Lkotlinx/serialization/json/d;

    .line 328
    .line 329
    .line 330
    move-result-object p0

    .line 331
    return-object p0

    .line 332
    :cond_14b
    invoke-static {p0}, Lo70/j;->b(Ljava/lang/Number;)Lkotlinx/serialization/json/d;

    .line 333
    .line 334
    .line 335
    move-result-object p0

    .line 336
    return-object p0

    .line 337
    :cond_150
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 338
    .line 339
    const-string v0, "JSON numbers must be finite"

    .line 340
    .line 341
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    throw p0
.end method

.method public static u(Lkotlinx/serialization/json/c;)Ljava/util/LinkedHashMap;
    .registers 4

    .line 1
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 2
    .line 3
    iget-object v1, p0, Lkotlinx/serialization/json/c;->d:Ljava/util/Map;

    .line 4
    .line 5
    invoke-interface {v1}, Ljava/util/Map;->size()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-static {v1}, Lm30/x;->p0(I)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 14
    .line 15
    .line 16
    iget-object p0, p0, Lkotlinx/serialization/json/c;->d:Ljava/util/Map;

    .line 17
    .line 18
    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    :goto_19
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_37

    .line 31
    .line 32
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    check-cast v1, Ljava/util/Map$Entry;

    .line 37
    .line 38
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    check-cast v1, Lkotlinx/serialization/json/b;

    .line 47
    .line 48
    invoke-static {v1}, Lil/c;->v(Lkotlinx/serialization/json/b;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    goto :goto_19

    .line 56
    :cond_37
    return-object v0
.end method

.method public static v(Lkotlinx/serialization/json/b;)Ljava/lang/Object;
    .registers 4

    .line 1
    sget-object v0, Lkotlinx/serialization/json/JsonNull;->INSTANCE:Lkotlinx/serialization/json/JsonNull;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_a

    .line 9
    .line 10
    return-object v1

    .line 11
    :cond_a
    instance-of v0, p0, Lkotlinx/serialization/json/c;

    .line 12
    .line 13
    if-eqz v0, :cond_15

    .line 14
    .line 15
    check-cast p0, Lkotlinx/serialization/json/c;

    .line 16
    .line 17
    invoke-static {p0}, Lil/c;->u(Lkotlinx/serialization/json/c;)Ljava/util/LinkedHashMap;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    :cond_15
    instance-of v0, p0, Lkotlinx/serialization/json/a;

    .line 23
    .line 24
    if-eqz v0, :cond_3f

    .line 25
    .line 26
    check-cast p0, Ljava/lang/Iterable;

    .line 27
    .line 28
    new-instance v0, Ljava/util/ArrayList;

    .line 29
    .line 30
    const/16 v1, 0xa

    .line 31
    .line 32
    invoke-static {p0, v1}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 37
    .line 38
    .line 39
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    :goto_2a
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_3e

    .line 48
    .line 49
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lkotlinx/serialization/json/b;

    .line 54
    .line 55
    invoke-static {v1}, Lil/c;->v(Lkotlinx/serialization/json/b;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    goto :goto_2a

    .line 63
    :cond_3e
    return-object v0

    .line 64
    :cond_3f
    instance-of v0, p0, Lkotlinx/serialization/json/d;

    .line 65
    .line 66
    if-eqz v0, :cond_93

    .line 67
    .line 68
    check-cast p0, Lkotlinx/serialization/json/d;

    .line 69
    .line 70
    invoke-virtual {p0}, Lkotlinx/serialization/json/d;->b()Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_50

    .line 75
    .line 76
    invoke-virtual {p0}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    return-object p0

    .line 81
    :cond_50
    sget-object v0, Lo70/j;->a:Ln70/a0;

    .line 82
    .line 83
    invoke-virtual {p0}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    sget-object v2, Lp70/f0;->a:[Ljava/lang/String;

    .line 88
    .line 89
    const-string v2, "<this>"

    .line 90
    .line 91
    invoke-static {v0, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    const-string v2, "true"

    .line 95
    .line 96
    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    if-eqz v2, :cond_68

    .line 101
    .line 102
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 103
    .line 104
    goto :goto_72

    .line 105
    :cond_68
    const-string v2, "false"

    .line 106
    .line 107
    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eqz v0, :cond_72

    .line 112
    .line 113
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 114
    .line 115
    :cond_72
    :goto_72
    if-nez v1, :cond_92

    .line 116
    .line 117
    invoke-virtual {p0}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    invoke-static {v0}, Lw60/v;->k0(Ljava/lang/String;)Ljava/lang/Integer;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    if-nez v0, :cond_91

    .line 126
    .line 127
    invoke-virtual {p0}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-static {v0}, Lw60/v;->l0(Ljava/lang/String;)Ljava/lang/Long;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    if-nez v0, :cond_91

    .line 136
    .line 137
    invoke-virtual {p0}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    invoke-static {p0}, Lw60/u;->X(Ljava/lang/String;)Ljava/lang/Double;

    .line 142
    .line 143
    .line 144
    move-result-object p0

    .line 145
    return-object p0

    .line 146
    :cond_91
    return-object v0

    .line 147
    :cond_92
    return-object v1

    .line 148
    :cond_93
    new-instance p0, Lan/g;

    .line 149
    .line 150
    const/4 v0, 0x0

    .line 151
    invoke-direct {p0, v0}, Lan/g;-><init>(Z)V

    .line 152
    .line 153
    .line 154
    throw p0
.end method


# virtual methods
.method public a()Lo4/b0;
    .registers 4

    .line 1
    new-instance v0, Lo4/s;

    .line 2
    .line 3
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1, v2}, Lo4/s;-><init>(J)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public b()Ljava/lang/Object;
    .registers 2

    .line 1
    new-instance v0, Lvw/c0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public c()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/k0;->i()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public d(J)V
    .registers 3

    .line 1
    return-void
.end method

.method public e(Ljava/lang/String;)Z
    .registers 2

    .line 1
    invoke-static {p1}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x1

    .line 5
    return p1
.end method

.method public f(Landroid/net/Uri;Lot/o;)Ljava/lang/Object;
    .registers 15

    .line 1
    new-instance p1, Landroid/util/JsonReader;

    .line 2
    .line 3
    new-instance v0, Ljava/io/InputStreamReader;

    .line 4
    .line 5
    invoke-direct {v0, p2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {p1, v0}, Landroid/util/JsonReader;-><init>(Ljava/io/Reader;)V

    .line 9
    .line 10
    .line 11
    :try_start_a
    invoke-virtual {p1}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 12
    .line 13
    .line 14
    move-result-object p2

    .line 15
    sget-object v0, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 16
    .line 17
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p2

    .line 21
    if-eqz p2, :cond_e9

    .line 22
    .line 23
    new-instance p2, Lhx/j0;

    .line 24
    .line 25
    const/4 v0, 0x4

    .line 26
    invoke-direct {p2, v0}, Lhx/f0;-><init>(I)V

    .line 27
    .line 28
    .line 29
    new-instance v1, Lhx/j0;

    .line 30
    .line 31
    invoke-direct {v1, v0}, Lhx/f0;-><init>(I)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginObject()V

    .line 35
    .line 36
    .line 37
    const/4 v0, 0x0

    .line 38
    const/4 v2, 0x1

    .line 39
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    move-object v9, v0

    .line 45
    move v6, v2

    .line 46
    move-wide v7, v3

    .line 47
    :goto_2e
    invoke-virtual {p1}, Landroid/util/JsonReader;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_c8

    .line 52
    .line 53
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    const-string v2, "VERSION"

    .line 58
    .line 59
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    if-eqz v2, :cond_56

    .line 64
    .line 65
    invoke-virtual {p1}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    sget-object v3, Landroid/util/JsonToken;->NUMBER:Landroid/util/JsonToken;

    .line 70
    .line 71
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-eqz v2, :cond_56

    .line 76
    .line 77
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextInt()I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    move v6, v0

    .line 82
    goto :goto_2e

    .line 83
    :catchall_52
    move-exception v0

    .line 84
    move-object p2, v0

    .line 85
    goto/16 :goto_f0

    .line 86
    .line 87
    :cond_56
    const-string v2, "TTL"

    .line 88
    .line 89
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v2

    .line 93
    if-eqz v2, :cond_74

    .line 94
    .line 95
    invoke-virtual {p1}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    sget-object v3, Landroid/util/JsonToken;->NUMBER:Landroid/util/JsonToken;

    .line 100
    .line 101
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v2

    .line 105
    if-eqz v2, :cond_74

    .line 106
    .line 107
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextInt()I

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    int-to-long v2, v0

    .line 112
    const-wide/16 v4, 0x3e8

    .line 113
    .line 114
    mul-long/2addr v2, v4

    .line 115
    move-wide v7, v2

    .line 116
    goto :goto_2e

    .line 117
    :cond_74
    const-string v2, "RELOAD-URI"

    .line 118
    .line 119
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    move-result v2

    .line 123
    if-eqz v2, :cond_92

    .line 124
    .line 125
    invoke-virtual {p1}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    sget-object v3, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 130
    .line 131
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    if-eqz v2, :cond_92

    .line 136
    .line 137
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    move-object v9, v0

    .line 146
    goto :goto_2e

    .line 147
    :cond_92
    const-string v2, "PATHWAY-PRIORITY"

    .line 148
    .line 149
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    if-eqz v2, :cond_aa

    .line 154
    .line 155
    invoke-virtual {p1}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    sget-object v3, Landroid/util/JsonToken;->BEGIN_ARRAY:Landroid/util/JsonToken;

    .line 160
    .line 161
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v2

    .line 165
    if-eqz v2, :cond_aa

    .line 166
    .line 167
    invoke-static {p1, p2}, Lil/c;->p(Landroid/util/JsonReader;Lhx/j0;)V

    .line 168
    .line 169
    .line 170
    goto :goto_2e

    .line 171
    :cond_aa
    const-string v2, "PATHWAY-CLONES"

    .line 172
    .line 173
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    if-eqz v0, :cond_c3

    .line 178
    .line 179
    invoke-virtual {p1}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    sget-object v2, Landroid/util/JsonToken;->BEGIN_ARRAY:Landroid/util/JsonToken;

    .line 184
    .line 185
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    if-eqz v0, :cond_c3

    .line 190
    .line 191
    invoke-static {p1, v1}, Lil/c;->o(Landroid/util/JsonReader;Lhx/j0;)V

    .line 192
    .line 193
    .line 194
    goto/16 :goto_2e

    .line 195
    .line 196
    :cond_c3
    invoke-virtual {p1}, Landroid/util/JsonReader;->skipValue()V

    .line 197
    .line 198
    .line 199
    goto/16 :goto_2e

    .line 200
    .line 201
    :cond_c8
    invoke-virtual {p1}, Landroid/util/JsonReader;->endObject()V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p2}, Lhx/j0;->g()Lhx/w1;

    .line 205
    .line 206
    .line 207
    move-result-object v10

    .line 208
    invoke-virtual {v10}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 209
    .line 210
    .line 211
    move-result p2

    .line 212
    if-nez p2, :cond_e2

    .line 213
    .line 214
    new-instance v5, Lk4/c;

    .line 215
    .line 216
    invoke-virtual {v1}, Lhx/j0;->g()Lhx/w1;

    .line 217
    .line 218
    .line 219
    move-result-object v11

    .line 220
    invoke-direct/range {v5 .. v11}, Lk4/c;-><init>(IJLandroid/net/Uri;Lhx/w1;Lhx/w1;)V
    :try_end_de
    .catchall {:try_start_a .. :try_end_de} :catchall_52

    .line 221
    .line 222
    .line 223
    invoke-virtual {p1}, Landroid/util/JsonReader;->close()V

    .line 224
    .line 225
    .line 226
    return-object v5

    .line 227
    :cond_e2
    :try_start_e2
    const-string p2, "PATHWAY-PRIORITY field is missing"

    .line 228
    .line 229
    invoke-static {p2}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 230
    .line 231
    .line 232
    move-result-object p2

    .line 233
    throw p2

    .line 234
    :cond_e9
    const-string p2, "Steering manifest JSON should be an object at root"

    .line 235
    .line 236
    invoke-static {p2}, Lk3/v0;->c(Ljava/lang/String;)Lk3/v0;

    .line 237
    .line 238
    .line 239
    move-result-object p2

    .line 240
    throw p2
    :try_end_f0
    .catchall {:try_start_e2 .. :try_end_f0} :catchall_52

    .line 241
    :goto_f0
    :try_start_f0
    invoke-virtual {p1}, Landroid/util/JsonReader;->close()V
    :try_end_f3
    .catchall {:try_start_f0 .. :try_end_f3} :catchall_f4

    .line 242
    .line 243
    .line 244
    goto :goto_f9

    .line 245
    :catchall_f4
    move-exception v0

    .line 246
    move-object p1, v0

    .line 247
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 248
    .line 249
    .line 250
    :goto_f9
    throw p2
.end method

.method public g(Lo4/o;)J
    .registers 4

    .line 1
    const-wide/16 v0, -0x1

    .line 2
    .line 3
    return-wide v0
.end method

.method public getEventName()Ljava/lang/String;
    .registers 2

    .line 1
    const-string v0, "topNativeDismissPrevented"

    .line 2
    .line 3
    return-object v0
.end method

.method public h(Lb80/i0;)Lc4/n;
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_1
    invoke-static {p1}, Lil/c;->k(Lb80/i0;)Landroid/media/MediaCodec;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    const-string v1, "configureCodec"

    .line 7
    .line 8
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p1, Lb80/i0;->w:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Landroid/view/Surface;

    .line 14
    .line 15
    if-nez v1, :cond_25

    .line 16
    .line 17
    iget-object v2, p1, Lb80/i0;->i:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Lc4/r;

    .line 20
    .line 21
    iget-boolean v2, v2, Lc4/r;->h:Z

    .line 22
    .line 23
    if-eqz v2, :cond_25

    .line 24
    .line 25
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 26
    .line 27
    const/16 v3, 0x23

    .line 28
    .line 29
    if-lt v2, v3, :cond_25

    .line 30
    .line 31
    const/16 v2, 0x8

    .line 32
    .line 33
    goto :goto_26

    .line 34
    :catch_21
    move-exception p1

    .line 35
    goto :goto_49

    .line 36
    :catch_23
    move-exception p1

    .line 37
    goto :goto_49

    .line 38
    :cond_25
    const/4 v2, 0x0

    .line 39
    :goto_26
    iget-object v3, p1, Lb80/i0;->e:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v3, Landroid/media/MediaFormat;

    .line 42
    .line 43
    iget-object v4, p1, Lb80/i0;->x:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v4, Landroid/media/MediaCrypto;

    .line 46
    .line 47
    invoke-virtual {v0, v3, v1, v4, v2}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    .line 48
    .line 49
    .line 50
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 51
    .line 52
    .line 53
    const-string v1, "startCodec"

    .line 54
    .line 55
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0}, Landroid/media/MediaCodec;->start()V

    .line 59
    .line 60
    .line 61
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 62
    .line 63
    .line 64
    new-instance v1, Lc4/c0;

    .line 65
    .line 66
    iget-object p1, p1, Lb80/i0;->y:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast p1, Lc4/l;

    .line 69
    .line 70
    invoke-direct {v1, v0, p1}, Lc4/c0;-><init>(Landroid/media/MediaCodec;Lc4/l;)V
    :try_end_48
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_48} :catch_23
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_48} :catch_21

    .line 71
    .line 72
    .line 73
    return-object v1

    .line 74
    :goto_49
    if-eqz v0, :cond_4e

    .line 75
    .line 76
    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    .line 77
    .line 78
    .line 79
    :cond_4e
    throw p1
.end method

.method public q(Lcom/google/firebase/components/ComponentRegistrar;)Ljava/util/List;
    .registers 12

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lcom/google/firebase/components/ComponentRegistrar;->getComponents()Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    :goto_d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_37

    .line 19
    .line 20
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Lrx/b;

    .line 25
    .line 26
    iget-object v3, v1, Lrx/b;->a:Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v3, :cond_33

    .line 29
    .line 30
    new-instance v8, Ll5/g;

    .line 31
    .line 32
    const/4 v2, 0x4

    .line 33
    invoke-direct {v8, v2, v3, v1}, Ll5/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    new-instance v2, Lrx/b;

    .line 37
    .line 38
    iget-object v4, v1, Lrx/b;->b:Ljava/util/Set;

    .line 39
    .line 40
    iget-object v5, v1, Lrx/b;->c:Ljava/util/Set;

    .line 41
    .line 42
    iget v6, v1, Lrx/b;->d:I

    .line 43
    .line 44
    iget v7, v1, Lrx/b;->e:I

    .line 45
    .line 46
    iget-object v9, v1, Lrx/b;->g:Ljava/util/Set;

    .line 47
    .line 48
    invoke-direct/range {v2 .. v9}, Lrx/b;-><init>(Ljava/lang/String;Ljava/util/Set;Ljava/util/Set;IILrx/d;Ljava/util/Set;)V

    .line 49
    .line 50
    .line 51
    move-object v1, v2

    .line 52
    :cond_33
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    goto :goto_d

    .line 56
    :cond_37
    return-object v0
.end method

.method public r(Lk7/l;F)V
    .registers 8

    .line 1
    iget-object v0, p1, Lk7/l;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/graphics/drawable/Drawable;

    .line 4
    .line 5
    check-cast v0, Lu/a;

    .line 6
    .line 7
    iget-object v1, p1, Lk7/l;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Landroidx/cardview/widget/CardView;

    .line 10
    .line 11
    invoke-virtual {v1}, Landroidx/cardview/widget/CardView;->getUseCompatPadding()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    invoke-virtual {v1}, Landroidx/cardview/widget/CardView;->getPreventCornerOverlap()Z

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    iget v4, v0, Lu/a;->e:F

    .line 20
    .line 21
    cmpl-float v4, p2, v4

    .line 22
    .line 23
    if-nez v4, :cond_21

    .line 24
    .line 25
    iget-boolean v4, v0, Lu/a;->f:Z

    .line 26
    .line 27
    if-ne v4, v2, :cond_21

    .line 28
    .line 29
    iget-boolean v4, v0, Lu/a;->g:Z

    .line 30
    .line 31
    if-ne v4, v3, :cond_21

    .line 32
    .line 33
    goto :goto_2e

    .line 34
    :cond_21
    iput p2, v0, Lu/a;->e:F

    .line 35
    .line 36
    iput-boolean v2, v0, Lu/a;->f:Z

    .line 37
    .line 38
    iput-boolean v3, v0, Lu/a;->g:Z

    .line 39
    .line 40
    const/4 p2, 0x0

    .line 41
    invoke-virtual {v0, p2}, Lu/a;->b(Landroid/graphics/Rect;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 45
    .line 46
    .line 47
    :goto_2e
    invoke-virtual {v1}, Landroidx/cardview/widget/CardView;->getUseCompatPadding()Z

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    if-nez p2, :cond_39

    .line 52
    .line 53
    const/4 p2, 0x0

    .line 54
    invoke-virtual {p1, p2, p2, p2, p2}, Lk7/l;->c0(IIII)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :cond_39
    iget-object p2, p1, Lk7/l;->d:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p2, Landroid/graphics/drawable/Drawable;

    .line 61
    .line 62
    check-cast p2, Lu/a;

    .line 63
    .line 64
    iget v0, p2, Lu/a;->e:F

    .line 65
    .line 66
    iget p2, p2, Lu/a;->a:F

    .line 67
    .line 68
    invoke-virtual {v1}, Landroidx/cardview/widget/CardView;->getPreventCornerOverlap()Z

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    invoke-static {v0, p2, v2}, Lu/b;->a(FFZ)F

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    float-to-double v2, v2

    .line 77
    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    .line 78
    .line 79
    .line 80
    move-result-wide v2

    .line 81
    double-to-int v2, v2

    .line 82
    invoke-virtual {v1}, Landroidx/cardview/widget/CardView;->getPreventCornerOverlap()Z

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    invoke-static {v0, p2, v1}, Lu/b;->b(FFZ)F

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    float-to-double v0, p2

    .line 91
    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    .line 92
    .line 93
    .line 94
    move-result-wide v0

    .line 95
    double-to-int p2, v0

    .line 96
    invoke-virtual {p1, v2, p2, v2, p2}, Lk7/l;->c0(IIII)V

    .line 97
    .line 98
    .line 99
    return-void
.end method

.method public x()Ljava/lang/String;
    .registers 2

    .line 1
    const-string v0, "onNativeDismissPrevented"

    .line 2
    .line 3
    return-object v0
.end method
