###### Class il.a (il.a)
.class public final Lil/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lu1/c;


# static fields
.field public static final a:Lcom/facebook/react/uimanager/p0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lcom/facebook/react/uimanager/p0;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lcom/facebook/react/uimanager/p0;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lil/a;->a:Lcom/facebook/react/uimanager/p0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    check-cast p1, Ljava/nio/ByteBuffer;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    return p1
.end method

.method public final acquire()Ljava/lang/Object;
    .registers 2

    .line 1
    sget-object v0, Lil/a;->a:Lcom/facebook/react/uimanager/p0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/nio/ByteBuffer;

    .line 8
    .line 9
    return-object v0
.end method
