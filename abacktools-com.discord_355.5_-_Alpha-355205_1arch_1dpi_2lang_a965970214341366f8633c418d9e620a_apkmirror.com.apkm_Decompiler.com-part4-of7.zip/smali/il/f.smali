###### Class il.f (il.f)
.class public final Lil/f;
.super Ljava/io/InputStream;
.source "SourceFile"


# instance fields
.field public final d:Lin/q;

.field public e:I

.field public i:I


# direct methods
.method public constructor <init>(Lin/q;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    .line 2
    .line 3
    .line 4
    monitor-enter p1

    .line 5
    :try_start_4
    iget-object v0, p1, Lin/q;->e:Ljl/b;

    .line 6
    .line 7
    invoke-static {v0}, Ljl/b;->x(Ljl/b;)Z

    .line 8
    .line 9
    .line 10
    move-result v0
    :try_end_a
    .catchall {:try_start_4 .. :try_end_a} :catchall_1b

    .line 11
    monitor-exit p1

    .line 12
    if-eqz v0, :cond_15

    .line 13
    .line 14
    iput-object p1, p0, Lil/f;->d:Lin/q;

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    iput p1, p0, Lil/f;->e:I

    .line 18
    .line 19
    iput p1, p0, Lil/f;->i:I

    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 23
    .line 24
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 25
    .line 26
    .line 27
    throw p1

    .line 28
    :catchall_1b
    move-exception v0

    .line 29
    :try_start_1c
    monitor-exit p1
    :try_end_1d
    .catchall {:try_start_1c .. :try_end_1d} :catchall_1b

    .line 30
    throw v0
.end method


# virtual methods
.method public final available()I
    .registers 3

    .line 1
    iget-object v0, p0, Lil/f;->d:Lin/q;

    .line 2
    .line 3
    invoke-virtual {v0}, Lin/q;->l()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lil/f;->e:I

    .line 8
    .line 9
    sub-int/2addr v0, v1

    .line 10
    return v0
.end method

.method public final mark(I)V
    .registers 2

    .line 1
    iget p1, p0, Lil/f;->e:I

    .line 2
    .line 3
    iput p1, p0, Lil/f;->i:I

    .line 4
    .line 5
    return-void
.end method

.method public final markSupported()Z
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final read()I
    .registers 3

    .line 1
    invoke-virtual {p0}, Lil/f;->available()I

    move-result v0

    if-gtz v0, :cond_8

    const/4 v0, -0x1

    return v0

    .line 2
    :cond_8
    iget v0, p0, Lil/f;->e:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lil/f;->e:I

    iget-object v1, p0, Lil/f;->d:Lin/q;

    invoke-virtual {v1, v0}, Lin/q;->i(I)B

    move-result v0

    and-int/lit16 v0, v0, 0xff

    return v0
.end method

.method public final read([B)I
    .registers 4

    const/4 v0, 0x0

    .line 3
    array-length v1, p1

    invoke-virtual {p0, p1, v0, v1}, Lil/f;->read([BII)I

    move-result p1

    return p1
.end method

.method public final read([BII)I
    .registers 8

    if-ltz p2, :cond_26

    if-ltz p3, :cond_26

    add-int v0, p2, p3

    .line 4
    array-length v1, p1

    if-gt v0, v1, :cond_26

    .line 5
    invoke-virtual {p0}, Lil/f;->available()I

    move-result v0

    if-gtz v0, :cond_11

    const/4 p1, -0x1

    return p1

    :cond_11
    if-gtz p3, :cond_15

    const/4 p1, 0x0

    return p1

    .line 6
    :cond_15
    invoke-static {v0, p3}, Ljava/lang/Math;->min(II)I

    move-result p3

    .line 7
    iget-object v0, p0, Lil/f;->d:Lin/q;

    iget v1, p0, Lil/f;->e:I

    invoke-virtual {v0, v1, p2, p3, p1}, Lin/q;->j(III[B)V

    .line 8
    iget p1, p0, Lil/f;->e:I

    add-int/2addr p1, p3

    iput p1, p0, Lil/f;->e:I

    return p3

    .line 9
    :cond_26
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "length="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    array-length p1, p1

    const-string v2, "; regionStart="

    const-string v3, "; regionLength="

    .line 10
    invoke-static {v1, p1, v2, p2, v3}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 11
    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final reset()V
    .registers 2

    .line 1
    iget v0, p0, Lil/f;->i:I

    .line 2
    .line 3
    iput v0, p0, Lil/f;->e:I

    .line 4
    .line 5
    return-void
.end method

.method public final skip(J)J
    .registers 5

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v0, p1, v0

    .line 4
    .line 5
    if-ltz v0, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, Lfl/j;->a(Ljava/lang/Boolean;)V

    .line 15
    .line 16
    .line 17
    long-to-int p1, p1

    .line 18
    invoke-virtual {p0}, Lil/f;->available()I

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    iget p2, p0, Lil/f;->e:I

    .line 27
    .line 28
    add-int/2addr p2, p1

    .line 29
    iput p2, p0, Lil/f;->e:I

    .line 30
    .line 31
    int-to-long p1, p1

    .line 32
    return-wide p1
.end method
