###### Class im.a (im.a)
.class public interface abstract Lim/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lim/c;Lgm/b;Lgm/a;I)V
.end method

.method public abstract b(III)Ljl/b;
.end method

.method public abstract d()V
.end method

.method public abstract h()V
.end method

.method public abstract i(II)V
.end method
