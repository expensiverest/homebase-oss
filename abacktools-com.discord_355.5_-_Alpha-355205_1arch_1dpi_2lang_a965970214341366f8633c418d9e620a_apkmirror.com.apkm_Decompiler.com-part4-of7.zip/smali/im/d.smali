###### Class im.d (im.d)
.class public final Lim/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lim/a;
.implements Lb8/d0;
.implements Lhs/g;
.implements Lqq/b;
.implements Lsu/c;


# instance fields
.field public final synthetic d:I

.field public e:I


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x3

    iput v0, p0, Lim/d;->d:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 4
    iput v0, p0, Lim/d;->e:I

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lim/d;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 2
    iput p2, p0, Lim/d;->d:I

    iput p1, p0, Lim/d;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static l(Lew/n;Lj4/h;)Lgs/f;
    .registers 5

    .line 1
    iget-object p1, p1, Lj4/h;->a:Ljava/io/IOException;

    .line 2
    .line 3
    instance-of v0, p1, Lot/d0;

    .line 4
    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    goto :goto_45

    .line 8
    :cond_7
    check-cast p1, Lot/d0;

    .line 9
    .line 10
    iget p1, p1, Lot/d0;->v:I

    .line 11
    .line 12
    const/16 v0, 0x193

    .line 13
    .line 14
    if-eq p1, v0, :cond_23

    .line 15
    .line 16
    const/16 v0, 0x194

    .line 17
    .line 18
    if-eq p1, v0, :cond_23

    .line 19
    .line 20
    const/16 v0, 0x19a

    .line 21
    .line 22
    if-eq p1, v0, :cond_23

    .line 23
    .line 24
    const/16 v0, 0x1a0

    .line 25
    .line 26
    if-eq p1, v0, :cond_23

    .line 27
    .line 28
    const/16 v0, 0x1f4

    .line 29
    .line 30
    if-eq p1, v0, :cond_23

    .line 31
    .line 32
    const/16 v0, 0x1f7

    .line 33
    .line 34
    if-ne p1, v0, :cond_45

    .line 35
    .line 36
    :cond_23
    const/4 p1, 0x1

    .line 37
    invoke-virtual {p0, p1}, Lew/n;->a(I)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_34

    .line 42
    .line 43
    new-instance p0, Lgs/f;

    .line 44
    .line 45
    const-wide/32 v0, 0x493e0

    .line 46
    .line 47
    .line 48
    const/4 v2, 0x3

    .line 49
    invoke-direct {p0, p1, v2, v0, v1}, Lgs/f;-><init>(IIJ)V

    .line 50
    .line 51
    .line 52
    return-object p0

    .line 53
    :cond_34
    const/4 p1, 0x2

    .line 54
    invoke-virtual {p0, p1}, Lew/n;->a(I)Z

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    if-eqz p0, :cond_45

    .line 59
    .line 60
    new-instance p0, Lgs/f;

    .line 61
    .line 62
    const-wide/32 v0, 0xea60

    .line 63
    .line 64
    .line 65
    const/4 v2, 0x3

    .line 66
    invoke-direct {p0, p1, v2, v0, v1}, Lgs/f;-><init>(IIJ)V

    .line 67
    .line 68
    .line 69
    return-object p0

    .line 70
    :cond_45
    :goto_45
    const/4 p0, 0x0

    .line 71
    return-object p0
.end method

.method public static o(Lj4/h;)J
    .registers 4

    .line 1
    iget-object v0, p0, Lj4/h;->a:Ljava/io/IOException;

    .line 2
    .line 3
    instance-of v1, v0, Lmr/k1;

    .line 4
    .line 5
    if-nez v1, :cond_37

    .line 6
    .line 7
    instance-of v1, v0, Ljava/io/FileNotFoundException;

    .line 8
    .line 9
    if-nez v1, :cond_37

    .line 10
    .line 11
    instance-of v1, v0, Lot/z;

    .line 12
    .line 13
    if-nez v1, :cond_37

    .line 14
    .line 15
    instance-of v1, v0, Lot/i0;

    .line 16
    .line 17
    if-nez v1, :cond_37

    .line 18
    .line 19
    sget v1, Lot/n;->e:I

    .line 20
    .line 21
    :goto_14
    if-eqz v0, :cond_29

    .line 22
    .line 23
    instance-of v1, v0, Lot/n;

    .line 24
    .line 25
    if-eqz v1, :cond_24

    .line 26
    .line 27
    move-object v1, v0

    .line 28
    check-cast v1, Lot/n;

    .line 29
    .line 30
    iget v1, v1, Lot/n;->d:I

    .line 31
    .line 32
    const/16 v2, 0x7d8

    .line 33
    .line 34
    if-ne v1, v2, :cond_24

    .line 35
    .line 36
    goto :goto_37

    .line 37
    :cond_24
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    goto :goto_14

    .line 42
    :cond_29
    iget p0, p0, Lj4/h;->b:I

    .line 43
    .line 44
    add-int/lit8 p0, p0, -0x1

    .line 45
    .line 46
    mul-int/lit16 p0, p0, 0x3e8

    .line 47
    .line 48
    const/16 v0, 0x1388

    .line 49
    .line 50
    invoke-static {p0, v0}, Ljava/lang/Math;->min(II)I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    int-to-long v0, p0

    .line 55
    return-wide v0

    .line 56
    :cond_37
    :goto_37
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    return-wide v0
.end method


# virtual methods
.method public a(Lim/c;Lgm/b;Lgm/a;I)V
    .registers 15

    .line 1
    const-string v0, "bitmapFramePreparer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lim/d;->e:I

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    if-gt v1, v0, :cond_8a

    .line 10
    .line 11
    :goto_a
    add-int v2, p4, v1

    .line 12
    .line 13
    iget-object v3, p3, Lgm/a;->c:Landroidx/core/view/g0;

    .line 14
    .line 15
    invoke-virtual {v3}, Landroidx/core/view/g0;->z()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    rem-int v8, v2, v3

    .line 20
    .line 21
    const/4 v2, 0x2

    .line 22
    sget-object v3, Lgl/a;->a:Lgl/c;

    .line 23
    .line 24
    invoke-interface {v3, v2}, Lgl/c;->L(I)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_2c

    .line 29
    .line 30
    const-class v2, Lim/d;

    .line 31
    .line 32
    const-string v3, "Preparing frame %d, last drawn: %d"

    .line 33
    .line 34
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 39
    .line 40
    .line 41
    move-result-object v5

    .line 42
    invoke-static {v2, v3, v4, v5}, Lgl/a;->k(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_2c
    invoke-virtual {p3}, Ljava/lang/Object;->hashCode()I

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    mul-int/lit8 v2, v2, 0x1f

    .line 50
    .line 51
    add-int v9, v2, v8

    .line 52
    .line 53
    iget-object v2, p1, Lim/c;->w:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v2, Landroid/util/SparseArray;

    .line 56
    .line 57
    monitor-enter v2

    .line 58
    :try_start_39
    iget-object v3, p1, Lim/c;->w:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v3, Landroid/util/SparseArray;

    .line 61
    .line 62
    invoke-virtual {v3, v9}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    if-eqz v3, :cond_56

    .line 67
    .line 68
    const-class v3, Lim/c;

    .line 69
    .line 70
    const-string v4, "Already scheduled decode job for frame %d"

    .line 71
    .line 72
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    invoke-static {v4, v5, v3}, Lgl/a;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V
    :try_end_4e
    .catchall {:try_start_39 .. :try_end_4e} :catchall_53

    .line 77
    .line 78
    .line 79
    monitor-exit v2

    .line 80
    :goto_4f
    move-object v5, p1

    .line 81
    move-object v7, p2

    .line 82
    move-object v6, p3

    .line 83
    goto :goto_80

    .line 84
    :catchall_53
    move-exception v0

    .line 85
    move-object p1, v0

    .line 86
    goto :goto_88

    .line 87
    :cond_56
    :try_start_56
    invoke-interface {p2, v8}, Lgm/b;->i(I)Z

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    if-eqz v3, :cond_69

    .line 92
    .line 93
    const-class v3, Lim/c;

    .line 94
    .line 95
    const-string v4, "Frame %d is cached already."

    .line 96
    .line 97
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 98
    .line 99
    .line 100
    move-result-object v5

    .line 101
    invoke-static {v4, v5, v3}, Lgl/a;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V
    :try_end_67
    .catchall {:try_start_56 .. :try_end_67} :catchall_53

    .line 102
    .line 103
    .line 104
    monitor-exit v2

    .line 105
    goto :goto_4f

    .line 106
    :cond_69
    :try_start_69
    new-instance v4, Lim/b;

    .line 107
    .line 108
    move-object v5, p1

    .line 109
    move-object v7, p2

    .line 110
    move-object v6, p3

    .line 111
    invoke-direct/range {v4 .. v9}, Lim/b;-><init>(Lim/c;Lgm/a;Lgm/b;II)V

    .line 112
    .line 113
    .line 114
    iget-object p1, v5, Lim/c;->w:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast p1, Landroid/util/SparseArray;

    .line 117
    .line 118
    invoke-virtual {p1, v9, v4}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    iget-object p1, v5, Lim/c;->v:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast p1, Ljava/util/concurrent/ExecutorService;

    .line 124
    .line 125
    invoke-interface {p1, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_7f
    .catchall {:try_start_69 .. :try_end_7f} :catchall_53

    .line 126
    .line 127
    .line 128
    monitor-exit v2

    .line 129
    :goto_80
    if-eq v1, v0, :cond_8a

    .line 130
    .line 131
    add-int/lit8 v1, v1, 0x1

    .line 132
    .line 133
    move-object p1, v5

    .line 134
    move-object p3, v6

    .line 135
    move-object p2, v7

    .line 136
    goto :goto_a

    .line 137
    :goto_88
    monitor-exit v2

    .line 138
    throw p1

    .line 139
    :cond_8a
    return-void
.end method

.method public b(III)Ljl/b;
    .registers 4

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public c(Landroid/content/Context;Z)I
    .registers 3

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public d()V
    .registers 1

    .line 1
    return-void
.end method

.method public e(Ljava/lang/UnsatisfiedLinkError;[Lcom/facebook/soloader/a0;)Z
    .registers 11

    .line 1
    instance-of v0, p1, Lcom/facebook/soloader/z;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_7

    .line 5
    .line 6
    goto/16 :goto_e9

    .line 7
    .line 8
    :cond_7
    check-cast p1, Lcom/facebook/soloader/z;

    .line 9
    .line 10
    iget-object v0, p1, Lcom/facebook/soloader/z;->d:Ljava/lang/String;

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const-string v3, "SoLoader"

    .line 17
    .line 18
    if-nez v0, :cond_19

    .line 19
    .line 20
    const-string p1, "No so name provided in ULE, cannot recover"

    .line 21
    .line 22
    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 23
    .line 24
    .line 25
    return v1

    .line 26
    :cond_19
    instance-of v4, p1, Lcom/facebook/soloader/y;

    .line 27
    .line 28
    const-string v5, ", retrying for specific library "

    .line 29
    .line 30
    const-string v6, "Reunpacking BackupSoSources due to "

    .line 31
    .line 32
    const/4 v7, 0x1

    .line 33
    if-eqz v4, :cond_67

    .line 34
    .line 35
    iget v2, p0, Lim/d;->e:I

    .line 36
    .line 37
    and-int/2addr v2, v7

    .line 38
    if-eqz v2, :cond_e9

    .line 39
    .line 40
    new-instance v2, Ljava/lang/StringBuilder;

    .line 41
    .line 42
    invoke-direct {v2, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 59
    .line 60
    .line 61
    :try_start_3c
    array-length p1, p2

    .line 62
    move v2, v1

    .line 63
    :goto_3e
    if-ge v2, p1, :cond_e9

    .line 64
    .line 65
    aget-object v4, p2, v2

    .line 66
    .line 67
    instance-of v5, v4, Lcom/facebook/soloader/b;

    .line 68
    .line 69
    if-nez v5, :cond_47

    .line 70
    .line 71
    goto :goto_51

    .line 72
    :cond_47
    check-cast v4, Lcom/facebook/soloader/b;

    .line 73
    .line 74
    invoke-virtual {v4, v0}, Lcom/facebook/soloader/b;->j(Ljava/lang/String;)Z

    .line 75
    .line 76
    .line 77
    move-result v4
    :try_end_4d
    .catch Ljava/io/IOException; {:try_start_3c .. :try_end_4d} :catch_54

    .line 78
    if-eqz v4, :cond_51

    .line 79
    .line 80
    goto/16 :goto_d1

    .line 81
    .line 82
    :cond_51
    :goto_51
    add-int/lit8 v2, v2, 0x1

    .line 83
    .line 84
    goto :goto_3e

    .line 85
    :catch_54
    move-exception p1

    .line 86
    new-instance p2, Ljava/lang/StringBuilder;

    .line 87
    .line 88
    const-string v0, "Failed to run recovery for backup so source due to: "

    .line 89
    .line 90
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    .line 102
    .line 103
    return v1

    .line 104
    :cond_67
    if-eqz v2, :cond_e9

    .line 105
    .line 106
    const-string v4, "/app/"

    .line 107
    .line 108
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 109
    .line 110
    .line 111
    move-result v4

    .line 112
    if-nez v4, :cond_7b

    .line 113
    .line 114
    const-string v4, "/mnt/"

    .line 115
    .line 116
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    if-nez v2, :cond_7b

    .line 121
    .line 122
    goto/16 :goto_e9

    .line 123
    .line 124
    :cond_7b
    new-instance v2, Ljava/lang/StringBuilder;

    .line 125
    .line 126
    invoke-direct {v2, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 143
    .line 144
    .line 145
    array-length p1, p2

    .line 146
    move v2, v1

    .line 147
    :goto_92
    if-ge v2, p1, :cond_e9

    .line 148
    .line 149
    aget-object v4, p2, v2

    .line 150
    .line 151
    instance-of v5, v4, Lcom/facebook/soloader/b;

    .line 152
    .line 153
    if-nez v5, :cond_9d

    .line 154
    .line 155
    add-int/lit8 v2, v2, 0x1

    .line 156
    .line 157
    goto :goto_92

    .line 158
    :cond_9d
    check-cast v4, Lcom/facebook/soloader/b;

    .line 159
    .line 160
    :try_start_9f
    new-instance p1, Ljava/lang/StringBuilder;

    .line 161
    .line 162
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 163
    .line 164
    .line 165
    const-string v2, "Preparing BackupSoSource for the first time "

    .line 166
    .line 167
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    const-string v2, "BackupSoSource"

    .line 171
    .line 172
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 180
    .line 181
    .line 182
    invoke-virtual {v4, v1}, Lcom/facebook/soloader/b;->d(I)V
    :try_end_b8
    .catch Ljava/lang/Exception; {:try_start_9f .. :try_end_b8} :catch_d2

    .line 183
    .line 184
    .line 185
    array-length p1, p2

    .line 186
    :goto_b9
    if-ge v1, p1, :cond_d1

    .line 187
    .line 188
    aget-object v0, p2, v1

    .line 189
    .line 190
    instance-of v2, v0, Lcom/facebook/soloader/e;

    .line 191
    .line 192
    if-nez v2, :cond_c2

    .line 193
    .line 194
    goto :goto_ce

    .line 195
    :cond_c2
    instance-of v2, v0, Lcom/facebook/soloader/b;

    .line 196
    .line 197
    if-eqz v2, :cond_c7

    .line 198
    .line 199
    goto :goto_ce

    .line 200
    :cond_c7
    check-cast v0, Lcom/facebook/soloader/e;

    .line 201
    .line 202
    iget v2, v0, Lcom/facebook/soloader/e;->b:I

    .line 203
    .line 204
    or-int/2addr v2, v7

    .line 205
    iput v2, v0, Lcom/facebook/soloader/e;->b:I

    .line 206
    .line 207
    :goto_ce
    add-int/lit8 v1, v1, 0x1

    .line 208
    .line 209
    goto :goto_b9

    .line 210
    :cond_d1
    :goto_d1
    return v7

    .line 211
    :catch_d2
    move-exception p1

    .line 212
    new-instance p2, Ljava/lang/StringBuilder;

    .line 213
    .line 214
    const-string v2, "Encountered an exception while reunpacking BackupSoSource BackupSoSource for library "

    .line 215
    .line 216
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 220
    .line 221
    .line 222
    const-string v0, ": "

    .line 223
    .line 224
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 225
    .line 226
    .line 227
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object p2

    .line 231
    invoke-static {v3, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 232
    .line 233
    .line 234
    :cond_e9
    :goto_e9
    return v1
.end method

.method public f(Lhs/f;)Lhs/h;
    .registers 5

    .line 1
    sget v0, Lqt/x;->a:I

    .line 2
    .line 3
    const/16 v1, 0x17

    .line 4
    .line 5
    if-lt v0, v1, :cond_3a

    .line 6
    .line 7
    iget v1, p0, Lim/d;->e:I

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    if-eq v1, v2, :cond_11

    .line 11
    .line 12
    if-nez v1, :cond_3a

    .line 13
    .line 14
    const/16 v1, 0x1f

    .line 15
    .line 16
    if-lt v0, v1, :cond_3a

    .line 17
    .line 18
    :cond_11
    iget-object v0, p1, Lhs/f;->c:Lmr/i0;

    .line 19
    .line 20
    iget-object v0, v0, Lmr/i0;->N:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v0}, Lqt/k;->g(Ljava/lang/String;)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    new-instance v1, Ljava/lang/StringBuilder;

    .line 27
    .line 28
    const-string v2, "Creating an asynchronous MediaCodec adapter for track type "

    .line 29
    .line 30
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-static {v0}, Lqt/x;->B(I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const-string v2, "DMCodecAdapterFactory"

    .line 45
    .line 46
    invoke-static {v2, v1}, Lqt/a;->y(Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    new-instance v1, Lk7/e;

    .line 50
    .line 51
    invoke-direct {v1, v0}, Lk7/e;-><init>(I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1, p1}, Lk7/e;->d(Lhs/f;)Ln3/v;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    return-object p1

    .line 59
    :cond_3a
    new-instance v0, Lzm/f;

    .line 60
    .line 61
    const/16 v1, 0x9

    .line 62
    .line 63
    invoke-direct {v0, v1}, Lzm/f;-><init>(I)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, p1}, Lzm/f;->f(Lhs/f;)Lhs/h;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    return-object p1
.end method

.method public g(Landroid/content/Context;)I
    .registers 2

    .line 1
    iget p1, p0, Lim/d;->e:I

    .line 2
    .line 3
    return p1
.end method

.method public h()V
    .registers 1

    .line 1
    return-void
.end method

.method public i(II)V
    .registers 3

    .line 1
    return-void
.end method

.method public j(Lc8/a;F)Ljava/lang/Object;
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-virtual/range {p1 .. p1}, Lc8/a;->A()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    const/4 v3, 0x1

    .line 13
    const/4 v4, 0x0

    .line 14
    if-ne v2, v3, :cond_11

    .line 15
    .line 16
    move v2, v3

    .line 17
    goto :goto_12

    .line 18
    :cond_11
    move v2, v4

    .line 19
    :goto_12
    if-eqz v2, :cond_17

    .line 20
    .line 21
    invoke-virtual/range {p1 .. p1}, Lc8/a;->c()V

    .line 22
    .line 23
    .line 24
    :cond_17
    :goto_17
    invoke-virtual/range {p1 .. p1}, Lc8/a;->l()Z

    .line 25
    .line 26
    .line 27
    move-result v5

    .line 28
    if-eqz v5, :cond_2a

    .line 29
    .line 30
    invoke-virtual/range {p1 .. p1}, Lc8/a;->u()D

    .line 31
    .line 32
    .line 33
    move-result-wide v5

    .line 34
    double-to-float v5, v5

    .line 35
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    goto :goto_17

    .line 43
    :cond_2a
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    const/4 v6, 0x3

    .line 48
    const/4 v7, 0x2

    .line 49
    const/4 v8, 0x4

    .line 50
    if-ne v5, v8, :cond_6f

    .line 51
    .line 52
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    check-cast v5, Ljava/lang/Float;

    .line 57
    .line 58
    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    .line 59
    .line 60
    .line 61
    move-result v5

    .line 62
    const/high16 v9, 0x3f800000    # 1.0f

    .line 63
    .line 64
    cmpl-float v5, v5, v9

    .line 65
    .line 66
    if-nez v5, :cond_6f

    .line 67
    .line 68
    const/4 v5, 0x0

    .line 69
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    invoke-virtual {v1, v4, v5}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    check-cast v5, Ljava/lang/Float;

    .line 88
    .line 89
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    check-cast v5, Ljava/lang/Float;

    .line 97
    .line 98
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v5

    .line 105
    check-cast v5, Ljava/lang/Float;

    .line 106
    .line 107
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    iput v7, v0, Lim/d;->e:I

    .line 111
    .line 112
    :cond_6f
    if-eqz v2, :cond_74

    .line 113
    .line 114
    invoke-virtual/range {p1 .. p1}, Lc8/a;->g()V

    .line 115
    .line 116
    .line 117
    :cond_74
    iget v2, v0, Lim/d;->e:I

    .line 118
    .line 119
    const/4 v5, -0x1

    .line 120
    if-ne v2, v5, :cond_80

    .line 121
    .line 122
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    div-int/2addr v2, v8

    .line 127
    iput v2, v0, Lim/d;->e:I

    .line 128
    .line 129
    :cond_80
    iget v2, v0, Lim/d;->e:I

    .line 130
    .line 131
    new-array v5, v2, [F

    .line 132
    .line 133
    new-array v9, v2, [I

    .line 134
    .line 135
    move v10, v4

    .line 136
    move v11, v10

    .line 137
    move v12, v11

    .line 138
    :goto_89
    iget v13, v0, Lim/d;->e:I

    .line 139
    .line 140
    mul-int/2addr v13, v8

    .line 141
    if-ge v10, v13, :cond_dc

    .line 142
    .line 143
    div-int/lit8 v13, v10, 0x4

    .line 144
    .line 145
    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v14

    .line 149
    check-cast v14, Ljava/lang/Float;

    .line 150
    .line 151
    invoke-virtual {v14}, Ljava/lang/Float;->floatValue()F

    .line 152
    .line 153
    .line 154
    move-result v14

    .line 155
    float-to-double v14, v14

    .line 156
    move/from16 p2, v4

    .line 157
    .line 158
    rem-int/lit8 v4, v10, 0x4

    .line 159
    .line 160
    if-eqz v4, :cond_c1

    .line 161
    .line 162
    const-wide v16, 0x406fe00000000000L    # 255.0

    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    if-eq v4, v3, :cond_bd

    .line 168
    .line 169
    if-eq v4, v7, :cond_b9

    .line 170
    .line 171
    if-eq v4, v6, :cond_ad

    .line 172
    .line 173
    goto :goto_d6

    .line 174
    :cond_ad
    mul-double v14, v14, v16

    .line 175
    .line 176
    double-to-int v4, v14

    .line 177
    const/16 v14, 0xff

    .line 178
    .line 179
    invoke-static {v14, v11, v12, v4}, Landroid/graphics/Color;->argb(IIII)I

    .line 180
    .line 181
    .line 182
    move-result v4

    .line 183
    aput v4, v9, v13

    .line 184
    .line 185
    goto :goto_d6

    .line 186
    :cond_b9
    mul-double v14, v14, v16

    .line 187
    .line 188
    double-to-int v12, v14

    .line 189
    goto :goto_d6

    .line 190
    :cond_bd
    mul-double v14, v14, v16

    .line 191
    .line 192
    double-to-int v11, v14

    .line 193
    goto :goto_d6

    .line 194
    :cond_c1
    if-lez v13, :cond_d3

    .line 195
    .line 196
    add-int/lit8 v4, v13, -0x1

    .line 197
    .line 198
    aget v4, v5, v4

    .line 199
    .line 200
    double-to-float v3, v14

    .line 201
    cmpl-float v4, v4, v3

    .line 202
    .line 203
    if-ltz v4, :cond_d3

    .line 204
    .line 205
    const v4, 0x3c23d70a    # 0.01f

    .line 206
    .line 207
    .line 208
    add-float/2addr v3, v4

    .line 209
    aput v3, v5, v13

    .line 210
    .line 211
    goto :goto_d6

    .line 212
    :cond_d3
    double-to-float v3, v14

    .line 213
    aput v3, v5, v13

    .line 214
    .line 215
    :goto_d6
    add-int/lit8 v10, v10, 0x1

    .line 216
    .line 217
    move/from16 v4, p2

    .line 218
    .line 219
    const/4 v3, 0x1

    .line 220
    goto :goto_89

    .line 221
    :cond_dc
    move/from16 p2, v4

    .line 222
    .line 223
    new-instance v3, Ly7/c;

    .line 224
    .line 225
    invoke-direct {v3, v5, v9}, Ly7/c;-><init>([F[I)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 229
    .line 230
    .line 231
    move-result v4

    .line 232
    if-gt v4, v13, :cond_ea

    .line 233
    .line 234
    return-object v3

    .line 235
    :cond_ea
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 236
    .line 237
    .line 238
    move-result v4

    .line 239
    sub-int/2addr v4, v13

    .line 240
    div-int/2addr v4, v7

    .line 241
    new-array v6, v4, [F

    .line 242
    .line 243
    new-array v8, v4, [F

    .line 244
    .line 245
    move/from16 v10, p2

    .line 246
    .line 247
    :goto_f6
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 248
    .line 249
    .line 250
    move-result v11

    .line 251
    if-ge v13, v11, :cond_11e

    .line 252
    .line 253
    rem-int/lit8 v11, v13, 0x2

    .line 254
    .line 255
    if-nez v11, :cond_10d

    .line 256
    .line 257
    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v11

    .line 261
    check-cast v11, Ljava/lang/Float;

    .line 262
    .line 263
    invoke-virtual {v11}, Ljava/lang/Float;->floatValue()F

    .line 264
    .line 265
    .line 266
    move-result v11

    .line 267
    aput v11, v6, v10

    .line 268
    .line 269
    goto :goto_11b

    .line 270
    :cond_10d
    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v11

    .line 274
    check-cast v11, Ljava/lang/Float;

    .line 275
    .line 276
    invoke-virtual {v11}, Ljava/lang/Float;->floatValue()F

    .line 277
    .line 278
    .line 279
    move-result v11

    .line 280
    aput v11, v8, v10

    .line 281
    .line 282
    add-int/lit8 v10, v10, 0x1

    .line 283
    .line 284
    :goto_11b
    add-int/lit8 v13, v13, 0x1

    .line 285
    .line 286
    goto :goto_f6

    .line 287
    :cond_11e
    iget-object v1, v3, Ly7/c;->a:[F

    .line 288
    .line 289
    array-length v3, v1

    .line 290
    if-nez v3, :cond_125

    .line 291
    .line 292
    move-object v1, v6

    .line 293
    goto :goto_175

    .line 294
    :cond_125
    if-nez v4, :cond_128

    .line 295
    .line 296
    goto :goto_175

    .line 297
    :cond_128
    array-length v3, v1

    .line 298
    add-int/2addr v3, v4

    .line 299
    new-array v10, v3, [F

    .line 300
    .line 301
    move/from16 v11, p2

    .line 302
    .line 303
    move v12, v11

    .line 304
    move v13, v12

    .line 305
    move v14, v13

    .line 306
    :goto_131
    if-ge v11, v3, :cond_16c

    .line 307
    .line 308
    array-length v15, v1

    .line 309
    const/high16 v17, 0x7fc00000    # Float.NaN

    .line 310
    .line 311
    if-ge v13, v15, :cond_13b

    .line 312
    .line 313
    aget v15, v1, v13

    .line 314
    .line 315
    goto :goto_13d

    .line 316
    :cond_13b
    move/from16 v15, v17

    .line 317
    .line 318
    :goto_13d
    if-ge v14, v4, :cond_141

    .line 319
    .line 320
    aget v17, v6, v14

    .line 321
    .line 322
    :cond_141
    invoke-static/range {v17 .. v17}, Ljava/lang/Float;->isNaN(F)Z

    .line 323
    .line 324
    .line 325
    move-result v18

    .line 326
    if-nez v18, :cond_165

    .line 327
    .line 328
    cmpg-float v18, v15, v17

    .line 329
    .line 330
    if-gez v18, :cond_14c

    .line 331
    .line 332
    goto :goto_165

    .line 333
    :cond_14c
    invoke-static {v15}, Ljava/lang/Float;->isNaN(F)Z

    .line 334
    .line 335
    .line 336
    move-result v18

    .line 337
    if-nez v18, :cond_160

    .line 338
    .line 339
    cmpg-float v18, v17, v15

    .line 340
    .line 341
    if-gez v18, :cond_157

    .line 342
    .line 343
    goto :goto_160

    .line 344
    :cond_157
    aput v15, v10, v11

    .line 345
    .line 346
    add-int/lit8 v13, v13, 0x1

    .line 347
    .line 348
    add-int/lit8 v14, v14, 0x1

    .line 349
    .line 350
    add-int/lit8 v12, v12, 0x1

    .line 351
    .line 352
    goto :goto_169

    .line 353
    :cond_160
    :goto_160
    aput v17, v10, v11

    .line 354
    .line 355
    add-int/lit8 v14, v14, 0x1

    .line 356
    .line 357
    goto :goto_169

    .line 358
    :cond_165
    :goto_165
    aput v15, v10, v11

    .line 359
    .line 360
    add-int/lit8 v13, v13, 0x1

    .line 361
    .line 362
    :goto_169
    add-int/lit8 v11, v11, 0x1

    .line 363
    .line 364
    goto :goto_131

    .line 365
    :cond_16c
    if-nez v12, :cond_170

    .line 366
    .line 367
    move-object v1, v10

    .line 368
    goto :goto_175

    .line 369
    :cond_170
    sub-int/2addr v3, v12

    .line 370
    invoke-static {v10, v3}, Ljava/util/Arrays;->copyOf([FI)[F

    .line 371
    .line 372
    .line 373
    move-result-object v1

    .line 374
    :goto_175
    array-length v3, v1

    .line 375
    new-array v10, v3, [I

    .line 376
    .line 377
    move/from16 v11, p2

    .line 378
    .line 379
    :goto_17a
    if-ge v11, v3, :cond_26d

    .line 380
    .line 381
    aget v12, v1, v11

    .line 382
    .line 383
    invoke-static {v5, v12}, Ljava/util/Arrays;->binarySearch([FF)I

    .line 384
    .line 385
    .line 386
    move-result v13

    .line 387
    invoke-static {v6, v12}, Ljava/util/Arrays;->binarySearch([FF)I

    .line 388
    .line 389
    .line 390
    move-result v14

    .line 391
    const-string v15, "Unreachable code."

    .line 392
    .line 393
    const/high16 v17, 0x437f0000    # 255.0f

    .line 394
    .line 395
    if-ltz v13, :cond_1f5

    .line 396
    .line 397
    if-lez v14, :cond_18f

    .line 398
    .line 399
    goto :goto_1f5

    .line 400
    :cond_18f
    aget v13, v9, v13

    .line 401
    .line 402
    if-lt v4, v7, :cond_1dc

    .line 403
    .line 404
    aget v14, v6, p2

    .line 405
    .line 406
    cmpg-float v14, v12, v14

    .line 407
    .line 408
    if-gtz v14, :cond_19a

    .line 409
    .line 410
    goto :goto_1dc

    .line 411
    :cond_19a
    const/4 v14, 0x1

    .line 412
    :goto_19b
    if-ge v14, v4, :cond_1d6

    .line 413
    .line 414
    aget v18, v6, v14

    .line 415
    .line 416
    cmpg-float v19, v18, v12

    .line 417
    .line 418
    if-gez v19, :cond_1ab

    .line 419
    .line 420
    add-int/lit8 v7, v4, -0x1

    .line 421
    .line 422
    if-eq v14, v7, :cond_1ab

    .line 423
    .line 424
    add-int/lit8 v14, v14, 0x1

    .line 425
    .line 426
    const/4 v7, 0x2

    .line 427
    goto :goto_19b

    .line 428
    :cond_1ab
    if-gtz v19, :cond_1b3

    .line 429
    .line 430
    aget v7, v8, v14

    .line 431
    .line 432
    :goto_1af
    mul-float v7, v7, v17

    .line 433
    .line 434
    float-to-int v7, v7

    .line 435
    goto :goto_1c5

    .line 436
    :cond_1b3
    add-int/lit8 v7, v14, -0x1

    .line 437
    .line 438
    aget v15, v6, v7

    .line 439
    .line 440
    sub-float v18, v18, v15

    .line 441
    .line 442
    sub-float/2addr v12, v15

    .line 443
    div-float v12, v12, v18

    .line 444
    .line 445
    aget v7, v8, v7

    .line 446
    .line 447
    aget v14, v8, v14

    .line 448
    .line 449
    invoke-static {v7, v14, v12}, Ld8/g;->e(FFF)F

    .line 450
    .line 451
    .line 452
    move-result v7

    .line 453
    goto :goto_1af

    .line 454
    :goto_1c5
    invoke-static {v13}, Landroid/graphics/Color;->red(I)I

    .line 455
    .line 456
    .line 457
    move-result v12

    .line 458
    invoke-static {v13}, Landroid/graphics/Color;->green(I)I

    .line 459
    .line 460
    .line 461
    move-result v14

    .line 462
    invoke-static {v13}, Landroid/graphics/Color;->blue(I)I

    .line 463
    .line 464
    .line 465
    move-result v13

    .line 466
    invoke-static {v7, v12, v14, v13}, Landroid/graphics/Color;->argb(IIII)I

    .line 467
    .line 468
    .line 469
    move-result v7

    .line 470
    goto :goto_1f1

    .line 471
    :cond_1d6
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 472
    .line 473
    invoke-direct {v1, v15}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 474
    .line 475
    .line 476
    throw v1

    .line 477
    :cond_1dc
    :goto_1dc
    aget v7, v8, p2

    .line 478
    .line 479
    mul-float v7, v7, v17

    .line 480
    .line 481
    float-to-int v7, v7

    .line 482
    invoke-static {v13}, Landroid/graphics/Color;->red(I)I

    .line 483
    .line 484
    .line 485
    move-result v12

    .line 486
    invoke-static {v13}, Landroid/graphics/Color;->green(I)I

    .line 487
    .line 488
    .line 489
    move-result v14

    .line 490
    invoke-static {v13}, Landroid/graphics/Color;->blue(I)I

    .line 491
    .line 492
    .line 493
    move-result v13

    .line 494
    invoke-static {v7, v12, v14, v13}, Landroid/graphics/Color;->argb(IIII)I

    .line 495
    .line 496
    .line 497
    move-result v7

    .line 498
    :goto_1f1
    aput v7, v10, v11

    .line 499
    .line 500
    goto/16 :goto_268

    .line 501
    .line 502
    :cond_1f5
    :goto_1f5
    if-gez v14, :cond_1fa

    .line 503
    .line 504
    add-int/lit8 v14, v14, 0x1

    .line 505
    .line 506
    neg-int v14, v14

    .line 507
    :cond_1fa
    aget v7, v8, v14

    .line 508
    .line 509
    const/4 v13, 0x2

    .line 510
    if-lt v2, v13, :cond_264

    .line 511
    .line 512
    aget v14, v5, p2

    .line 513
    .line 514
    cmpl-float v14, v12, v14

    .line 515
    .line 516
    if-nez v14, :cond_206

    .line 517
    .line 518
    goto :goto_264

    .line 519
    :cond_206
    const/4 v14, 0x1

    .line 520
    :goto_207
    if-ge v14, v2, :cond_25e

    .line 521
    .line 522
    aget v18, v5, v14

    .line 523
    .line 524
    cmpg-float v19, v18, v12

    .line 525
    .line 526
    if-gez v19, :cond_217

    .line 527
    .line 528
    add-int/lit8 v13, v2, -0x1

    .line 529
    .line 530
    if-eq v14, v13, :cond_217

    .line 531
    .line 532
    add-int/lit8 v14, v14, 0x1

    .line 533
    .line 534
    const/4 v13, 0x2

    .line 535
    goto :goto_207

    .line 536
    :cond_217
    add-int/lit8 v13, v2, -0x1

    .line 537
    .line 538
    if-ne v14, v13, :cond_239

    .line 539
    .line 540
    cmpl-float v13, v12, v18

    .line 541
    .line 542
    if-ltz v13, :cond_239

    .line 543
    .line 544
    mul-float v7, v7, v17

    .line 545
    .line 546
    float-to-int v7, v7

    .line 547
    aget v12, v9, v14

    .line 548
    .line 549
    invoke-static {v12}, Landroid/graphics/Color;->red(I)I

    .line 550
    .line 551
    .line 552
    move-result v12

    .line 553
    aget v13, v9, v14

    .line 554
    .line 555
    invoke-static {v13}, Landroid/graphics/Color;->green(I)I

    .line 556
    .line 557
    .line 558
    move-result v13

    .line 559
    aget v14, v9, v14

    .line 560
    .line 561
    invoke-static {v14}, Landroid/graphics/Color;->blue(I)I

    .line 562
    .line 563
    .line 564
    move-result v14

    .line 565
    invoke-static {v7, v12, v13, v14}, Landroid/graphics/Color;->argb(IIII)I

    .line 566
    .line 567
    .line 568
    move-result v7

    .line 569
    goto :goto_266

    .line 570
    :cond_239
    add-int/lit8 v13, v14, -0x1

    .line 571
    .line 572
    aget v15, v5, v13

    .line 573
    .line 574
    sub-float v18, v18, v15

    .line 575
    .line 576
    sub-float/2addr v12, v15

    .line 577
    div-float v12, v12, v18

    .line 578
    .line 579
    aget v14, v9, v14

    .line 580
    .line 581
    aget v13, v9, v13

    .line 582
    .line 583
    invoke-static {v12, v13, v14}, Lk80/l;->t(FII)I

    .line 584
    .line 585
    .line 586
    move-result v12

    .line 587
    mul-float v7, v7, v17

    .line 588
    .line 589
    float-to-int v7, v7

    .line 590
    invoke-static {v12}, Landroid/graphics/Color;->red(I)I

    .line 591
    .line 592
    .line 593
    move-result v13

    .line 594
    invoke-static {v12}, Landroid/graphics/Color;->green(I)I

    .line 595
    .line 596
    .line 597
    move-result v14

    .line 598
    invoke-static {v12}, Landroid/graphics/Color;->blue(I)I

    .line 599
    .line 600
    .line 601
    move-result v12

    .line 602
    invoke-static {v7, v13, v14, v12}, Landroid/graphics/Color;->argb(IIII)I

    .line 603
    .line 604
    .line 605
    move-result v7

    .line 606
    goto :goto_266

    .line 607
    :cond_25e
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 608
    .line 609
    invoke-direct {v1, v15}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 610
    .line 611
    .line 612
    throw v1

    .line 613
    :cond_264
    :goto_264
    aget v7, v9, p2

    .line 614
    .line 615
    :goto_266
    aput v7, v10, v11

    .line 616
    .line 617
    :goto_268
    add-int/lit8 v11, v11, 0x1

    .line 618
    .line 619
    const/4 v7, 0x2

    .line 620
    goto/16 :goto_17a

    .line 621
    .line 622
    :cond_26d
    new-instance v2, Ly7/c;

    .line 623
    .line 624
    invoke-direct {v2, v1, v10}, Ly7/c;-><init>([F[I)V

    .line 625
    .line 626
    .line 627
    return-object v2
.end method

.method public k(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    iget v0, p0, Lim/d;->e:I

    .line 2
    .line 3
    const-string v1, "method"

    .line 4
    .line 5
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v1, "BridgelessReact"

    .line 9
    .line 10
    if-nez p2, :cond_19

    .line 11
    .line 12
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    filled-new-array {p2, p1}, [Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    const-string p2, "ReactHost{%d}.%s"

    .line 21
    .line 22
    invoke-static {v1, p2, p1}, Lgl/a;->t(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_19
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    filled-new-array {v0, p1, p2}, [Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    const-string p2, "ReactHost{%d}.%s: %s"

    .line 35
    .line 36
    invoke-static {v1, p2, p1}, Lgl/a;->t(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public m(I)I
    .registers 4

    .line 1
    iget v0, p0, Lim/d;->e:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-ne v0, v1, :cond_c

    .line 5
    .line 6
    const/4 v0, 0x7

    .line 7
    if-ne p1, v0, :cond_a

    .line 8
    .line 9
    const/4 p1, 0x6

    .line 10
    return p1

    .line 11
    :cond_a
    const/4 p1, 0x3

    .line 12
    return p1

    .line 13
    :cond_c
    return v0
.end method

.method public n(I)I
    .registers 5

    .line 1
    iget v0, p0, Lim/d;->e:I

    .line 2
    .line 3
    rem-int/2addr p1, v0

    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    if-ltz v2, :cond_e

    .line 13
    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v1, 0x0

    .line 16
    :goto_f
    if-eqz v1, :cond_16

    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    return p1

    .line 23
    :cond_16
    add-int/2addr p1, v0

    .line 24
    return p1
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    .line 1
    iget v0, p0, Lim/d;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_22

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_a
    iget v0, p0, Lim/d;->e:I

    .line 12
    .line 13
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x1

    .line 22
    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    const/4 v1, 0x0

    .line 27
    const-string v2, "Status: %d"

    .line 28
    .line 29
    invoke-static {v1, v2, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    return-object v0

    .line 34
    nop

    .line 35
    :pswitch_data_22
    .packed-switch 0x9
        :pswitch_a
    .end packed-switch
.end method
