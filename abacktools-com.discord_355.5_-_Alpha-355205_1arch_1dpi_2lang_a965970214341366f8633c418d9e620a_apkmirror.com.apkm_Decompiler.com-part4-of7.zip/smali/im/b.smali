###### Class im.b (im.b)
.class public final Lim/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final d:Lgm/a;

.field public final e:Lgm/b;

.field public final i:I

.field public final v:I

.field public final synthetic w:Lim/c;


# direct methods
.method public constructor <init>(Lim/c;Lgm/a;Lgm/b;II)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lim/b;->w:Lim/c;

    .line 5
    .line 6
    iput-object p2, p0, Lim/b;->d:Lgm/a;

    .line 7
    .line 8
    iput-object p3, p0, Lim/b;->e:Lgm/b;

    .line 9
    .line 10
    iput p4, p0, Lim/b;->i:I

    .line 11
    .line 12
    iput p5, p0, Lim/b;->v:I

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final a(II)Z
    .registers 10

    .line 1
    iget-object v0, p0, Lim/b;->w:Lim/c;

    .line 2
    .line 3
    iget-object v1, p0, Lim/b;->d:Lgm/a;

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, -0x1

    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x0

    .line 9
    if-eq p2, v2, :cond_2f

    .line 10
    .line 11
    if-eq p2, v4, :cond_d

    .line 12
    .line 13
    goto :goto_2d

    .line 14
    :cond_d
    :try_start_d
    iget-object v2, v0, Lim/c;->d:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Lym/b;

    .line 17
    .line 18
    iget v4, v1, Lgm/a;->k:I

    .line 19
    .line 20
    iget v1, v1, Lgm/a;->l:I

    .line 21
    .line 22
    iget-object v6, v0, Lim/c;->i:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v6, Landroid/graphics/Bitmap$Config;

    .line 25
    .line 26
    invoke-virtual {v2, v4, v1, v6}, Lym/b;->a(IILandroid/graphics/Bitmap$Config;)Ljl/b;

    .line 27
    .line 28
    .line 29
    move-result-object v0
    :try_end_1d
    .catch Ljava/lang/RuntimeException; {:try_start_d .. :try_end_1d} :catch_22
    .catchall {:try_start_d .. :try_end_1d} :catchall_20

    .line 30
    move v4, v3

    .line 31
    :goto_1e
    move-object v5, v0

    .line 32
    goto :goto_36

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    goto :goto_48

    .line 35
    :catch_22
    move-exception p1

    .line 36
    :try_start_23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    const-class p2, Lim/c;

    .line 40
    .line 41
    const-string v0, "Failed to create frame bitmap"

    .line 42
    .line 43
    invoke-static {p2, v0, p1}, Lgl/a;->n(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Exception;)V

    .line 44
    .line 45
    .line 46
    :goto_2d
    const/4 p1, 0x0

    .line 47
    return p1

    .line 48
    :cond_2f
    iget-object v0, p0, Lim/b;->e:Lgm/b;

    .line 49
    .line 50
    invoke-interface {v0}, Lgm/b;->B()Ljl/b;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    goto :goto_1e

    .line 55
    :goto_36
    invoke-virtual {p0, p1, v5, p2}, Lim/b;->b(ILjl/b;I)Z

    .line 56
    .line 57
    .line 58
    move-result p2
    :try_end_3a
    .catchall {:try_start_23 .. :try_end_3a} :catchall_20

    .line 59
    invoke-static {v5}, Ljl/b;->l(Ljl/b;)V

    .line 60
    .line 61
    .line 62
    if-nez p2, :cond_47

    .line 63
    .line 64
    if-ne v4, v3, :cond_42

    .line 65
    .line 66
    goto :goto_47

    .line 67
    :cond_42
    invoke-virtual {p0, p1, v4}, Lim/b;->a(II)Z

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    return p1

    .line 72
    :cond_47
    :goto_47
    return p2

    .line 73
    :goto_48
    invoke-static {v5}, Ljl/b;->l(Ljl/b;)V

    .line 74
    .line 75
    .line 76
    throw p1
.end method

.method public final b(ILjl/b;I)Z
    .registers 6

    .line 1
    invoke-static {p2}, Ljl/b;->x(Ljl/b;)Z

    .line 2
    .line 3
    .line 4
    move-result p3

    .line 5
    if-nez p3, :cond_7

    .line 6
    .line 7
    goto :goto_3e

    .line 8
    :cond_7
    if-eqz p2, :cond_3e

    .line 9
    .line 10
    iget-object p3, p0, Lim/b;->w:Lim/c;

    .line 11
    .line 12
    iget-object p3, p3, Lim/c;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p3, Llm/a;

    .line 15
    .line 16
    invoke-virtual {p2}, Ljl/b;->n()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Landroid/graphics/Bitmap;

    .line 21
    .line 22
    invoke-virtual {p3, p1, v0}, Llm/a;->u(ILandroid/graphics/Bitmap;)Z

    .line 23
    .line 24
    .line 25
    move-result p3

    .line 26
    if-nez p3, :cond_1c

    .line 27
    .line 28
    goto :goto_3e

    .line 29
    :cond_1c
    iget-object p3, p0, Lim/b;->w:Lim/c;

    .line 30
    .line 31
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    const-class p3, Lim/c;

    .line 35
    .line 36
    const-string v0, "Frame %d ready."

    .line 37
    .line 38
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-static {v0, v1, p3}, Lgl/a;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V

    .line 43
    .line 44
    .line 45
    iget-object p3, p0, Lim/b;->w:Lim/c;

    .line 46
    .line 47
    iget-object p3, p3, Lim/c;->w:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p3, Landroid/util/SparseArray;

    .line 50
    .line 51
    monitor-enter p3

    .line 52
    :try_start_33
    iget-object v0, p0, Lim/b;->e:Lgm/b;

    .line 53
    .line 54
    invoke-interface {v0, p1, p2}, Lgm/b;->E(ILjl/b;)V
    :try_end_38
    .catchall {:try_start_33 .. :try_end_38} :catchall_3b

    .line 55
    .line 56
    .line 57
    monitor-exit p3

    .line 58
    const/4 p1, 0x1

    .line 59
    return p1

    .line 60
    :catchall_3b
    move-exception p1

    .line 61
    monitor-exit p3

    .line 62
    throw p1

    .line 63
    :cond_3e
    :goto_3e
    const/4 p1, 0x0

    .line 64
    return p1
.end method

.method public final run()V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lim/b;->e:Lgm/b;

    .line 2
    .line 3
    iget v1, p0, Lim/b;->i:I

    .line 4
    .line 5
    invoke-interface {v0, v1}, Lgm/b;->i(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_33

    .line 10
    .line 11
    iget-object v0, p0, Lim/b;->w:Lim/c;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const-class v0, Lim/c;

    .line 17
    .line 18
    const-string v1, "Frame %d is cached already."

    .line 19
    .line 20
    iget v2, p0, Lim/b;->i:I

    .line 21
    .line 22
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-static {v1, v2, v0}, Lgl/a;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V
    :try_end_1c
    .catchall {:try_start_0 .. :try_end_1c} :catchall_31

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lim/b;->w:Lim/c;

    .line 30
    .line 31
    iget-object v1, v0, Lim/c;->w:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v1, Landroid/util/SparseArray;

    .line 34
    .line 35
    monitor-enter v1

    .line 36
    :try_start_23
    iget-object v0, v0, Lim/c;->w:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Landroid/util/SparseArray;

    .line 39
    .line 40
    iget v2, p0, Lim/b;->v:I

    .line 41
    .line 42
    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->remove(I)V
    :try_end_2c
    .catchall {:try_start_23 .. :try_end_2c} :catchall_2e

    .line 43
    .line 44
    .line 45
    monitor-exit v1

    .line 46
    return-void

    .line 47
    :catchall_2e
    move-exception v0

    .line 48
    monitor-exit v1

    .line 49
    throw v0

    .line 50
    :catchall_31
    move-exception v0

    .line 51
    goto :goto_7a

    .line 52
    :cond_33
    :try_start_33
    iget v0, p0, Lim/b;->i:I

    .line 53
    .line 54
    const/4 v1, 0x1

    .line 55
    invoke-virtual {p0, v0, v1}, Lim/b;->a(II)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_4f

    .line 60
    .line 61
    iget-object v0, p0, Lim/b;->w:Lim/c;

    .line 62
    .line 63
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    const-class v0, Lim/c;

    .line 67
    .line 68
    const-string v1, "Prepared frame %d."

    .line 69
    .line 70
    iget v2, p0, Lim/b;->i:I

    .line 71
    .line 72
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    invoke-static {v1, v2, v0}, Lgl/a;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V

    .line 77
    .line 78
    .line 79
    goto :goto_65

    .line 80
    :cond_4f
    iget-object v0, p0, Lim/b;->w:Lim/c;

    .line 81
    .line 82
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    const-class v0, Lim/c;

    .line 86
    .line 87
    const-string v1, "Could not prepare frame %d."

    .line 88
    .line 89
    iget v2, p0, Lim/b;->i:I

    .line 90
    .line 91
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    invoke-static {v0, v1, v2}, Lgl/a;->e(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_65
    .catchall {:try_start_33 .. :try_end_65} :catchall_31

    .line 100
    .line 101
    .line 102
    :goto_65
    iget-object v0, p0, Lim/b;->w:Lim/c;

    .line 103
    .line 104
    iget-object v1, v0, Lim/c;->w:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v1, Landroid/util/SparseArray;

    .line 107
    .line 108
    monitor-enter v1

    .line 109
    :try_start_6c
    iget-object v0, v0, Lim/c;->w:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast v0, Landroid/util/SparseArray;

    .line 112
    .line 113
    iget v2, p0, Lim/b;->v:I

    .line 114
    .line 115
    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->remove(I)V
    :try_end_75
    .catchall {:try_start_6c .. :try_end_75} :catchall_77

    .line 116
    .line 117
    .line 118
    monitor-exit v1

    .line 119
    return-void

    .line 120
    :catchall_77
    move-exception v0

    .line 121
    monitor-exit v1

    .line 122
    throw v0

    .line 123
    :goto_7a
    iget-object v1, p0, Lim/b;->w:Lim/c;

    .line 124
    .line 125
    iget-object v2, v1, Lim/c;->w:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v2, Landroid/util/SparseArray;

    .line 128
    .line 129
    monitor-enter v2

    .line 130
    :try_start_81
    iget-object v1, v1, Lim/c;->w:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast v1, Landroid/util/SparseArray;

    .line 133
    .line 134
    iget v3, p0, Lim/b;->v:I

    .line 135
    .line 136
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->remove(I)V
    :try_end_8a
    .catchall {:try_start_81 .. :try_end_8a} :catchall_8c

    .line 137
    .line 138
    .line 139
    monitor-exit v2

    .line 140
    throw v0

    .line 141
    :catchall_8c
    move-exception v0

    .line 142
    monitor-exit v2

    .line 143
    throw v0
.end method
