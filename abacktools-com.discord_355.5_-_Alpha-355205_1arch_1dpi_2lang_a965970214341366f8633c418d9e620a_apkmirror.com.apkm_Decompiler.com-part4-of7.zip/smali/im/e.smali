###### Class im.e (im.e)
.class public final Lim/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final synthetic b:Lim/f;


# direct methods
.method public constructor <init>(Lim/f;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lim/e;->b:Lim/f;

    .line 5
    .line 6
    iget p1, p1, Lim/f;->K:I

    .line 7
    .line 8
    iput p1, p0, Lim/e;->a:I

    .line 9
    .line 10
    return-void
.end method
