###### Class im.f (im.f)
.class public final Lim/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lim/a;


# instance fields
.field public J:Lkm/d;

.field public final K:I

.field public L:I

.field public final M:Lim/e;

.field public final d:Landroidx/core/view/g0;

.field public final e:Llm/a;

.field public final i:Lkm/e;

.field public final v:Z

.field public final w:Ljava/lang/String;

.field public final x:I

.field public final y:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroidx/core/view/g0;Llm/a;Lkm/e;Z)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lim/f;->d:Landroidx/core/view/g0;

    .line 5
    .line 6
    iput-object p3, p0, Lim/f;->e:Llm/a;

    .line 7
    .line 8
    iput-object p4, p0, Lim/f;->i:Lkm/e;

    .line 9
    .line 10
    iput-boolean p5, p0, Lim/f;->v:Z

    .line 11
    .line 12
    if-nez p1, :cond_15

    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    :cond_15
    iput-object p1, p0, Lim/f;->w:Ljava/lang/String;

    .line 23
    .line 24
    iget-object p1, p2, Landroidx/core/view/g0;->e:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Lvm/a;

    .line 27
    .line 28
    iget-object p1, p1, Lvm/a;->c:Ltm/a;

    .line 29
    .line 30
    invoke-interface {p1}, Ltm/a;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    iput p1, p0, Lim/f;->x:I

    .line 35
    .line 36
    iget-object p1, p2, Landroidx/core/view/g0;->e:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Lvm/a;

    .line 39
    .line 40
    iget-object p1, p1, Lvm/a;->c:Ltm/a;

    .line 41
    .line 42
    invoke-interface {p1}, Ltm/a;->getHeight()I

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    iput p1, p0, Lim/f;->y:I

    .line 47
    .line 48
    sget-object p1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 49
    .line 50
    const-wide/16 p3, 0x1

    .line 51
    .line 52
    invoke-virtual {p1, p3, p4}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 53
    .line 54
    .line 55
    move-result-wide v0

    .line 56
    iget-object p1, p2, Landroidx/core/view/g0;->e:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast p1, Lvm/a;

    .line 59
    .line 60
    iget p1, p1, Lvm/a;->f:I

    .line 61
    .line 62
    invoke-virtual {p2}, Landroidx/core/view/g0;->z()I

    .line 63
    .line 64
    .line 65
    move-result p2

    .line 66
    div-int/2addr p1, p2

    .line 67
    int-to-long p1, p1

    .line 68
    div-long/2addr v0, p1

    .line 69
    cmp-long p1, v0, p3

    .line 70
    .line 71
    if-gez p1, :cond_49

    .line 72
    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    move-wide p3, v0

    .line 75
    :goto_4a
    long-to-int p1, p3

    .line 76
    iput p1, p0, Lim/f;->K:I

    .line 77
    .line 78
    iput p1, p0, Lim/f;->L:I

    .line 79
    .line 80
    new-instance p1, Lim/e;

    .line 81
    .line 82
    invoke-direct {p1, p0}, Lim/e;-><init>(Lim/f;)V

    .line 83
    .line 84
    .line 85
    iput-object p1, p0, Lim/f;->M:Lim/e;

    .line 86
    .line 87
    return-void
.end method


# virtual methods
.method public final a(Lim/c;Lgm/b;Lgm/a;I)V
    .registers 5

    .line 1
    const-string p2, "bitmapFramePreparer"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final b(III)Ljl/b;
    .registers 10

    .line 1
    invoke-virtual {p0, p2, p3}, Lim/f;->c(II)Landroidx/core/view/t;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    invoke-virtual {p0}, Lim/f;->e()Lkm/d;

    .line 6
    .line 7
    .line 8
    move-result-object p3

    .line 9
    const/4 v0, 0x0

    .line 10
    if-eqz p3, :cond_7a

    .line 11
    .line 12
    iget v1, p2, Landroidx/core/view/t;->b:I

    .line 13
    .line 14
    iget p2, p2, Landroidx/core/view/t;->c:I

    .line 15
    .line 16
    iget-object v2, p3, Lkm/d;->k:Ljava/lang/Object;

    .line 17
    .line 18
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Ljava/lang/Integer;

    .line 27
    .line 28
    if-eqz v2, :cond_75

    .line 29
    .line 30
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    iput p1, p3, Lkm/d;->j:I

    .line 35
    .line 36
    iget-object v3, p3, Lkm/d;->f:Ljava/util/concurrent/ConcurrentHashMap;

    .line 37
    .line 38
    invoke-virtual {v3, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    check-cast v2, Lkm/c;

    .line 43
    .line 44
    if-eqz v2, :cond_3a

    .line 45
    .line 46
    iget-boolean v3, v2, Lkm/c;->b:Z

    .line 47
    .line 48
    if-nez v3, :cond_3a

    .line 49
    .line 50
    iget-object v3, v2, Lkm/c;->a:Ljl/c;

    .line 51
    .line 52
    invoke-virtual {v3}, Ljl/b;->u()Z

    .line 53
    .line 54
    .line 55
    move-result v3

    .line 56
    if-eqz v3, :cond_3a

    .line 57
    .line 58
    goto :goto_3b

    .line 59
    :cond_3a
    move-object v2, v0

    .line 60
    :goto_3b
    if-eqz v2, :cond_6d

    .line 61
    .line 62
    iget-object v3, p3, Lkm/d;->i:Lim/d;

    .line 63
    .line 64
    iget v4, p3, Lkm/d;->g:I

    .line 65
    .line 66
    iget v5, p3, Lkm/d;->e:I

    .line 67
    .line 68
    add-int/2addr v5, v4

    .line 69
    invoke-virtual {v3, v5}, Lim/d;->n(I)I

    .line 70
    .line 71
    .line 72
    move-result v5

    .line 73
    if-ge v4, v5, :cond_4f

    .line 74
    .line 75
    if-gt v4, p1, :cond_5d

    .line 76
    .line 77
    if-gt p1, v5, :cond_5d

    .line 78
    .line 79
    goto :goto_5a

    .line 80
    :cond_4f
    if-gt v4, p1, :cond_56

    .line 81
    .line 82
    iget v3, v3, Lim/d;->e:I

    .line 83
    .line 84
    if-gt p1, v3, :cond_56

    .line 85
    .line 86
    goto :goto_5a

    .line 87
    :cond_56
    if-ltz p1, :cond_5d

    .line 88
    .line 89
    if-gt p1, v5, :cond_5d

    .line 90
    .line 91
    :goto_5a
    invoke-virtual {p3, v1, p2}, Lkm/d;->e(II)V

    .line 92
    .line 93
    .line 94
    :cond_5d
    new-instance p1, Lk7/c;

    .line 95
    .line 96
    iget-object p2, v2, Lkm/c;->a:Ljl/c;

    .line 97
    .line 98
    invoke-virtual {p2}, Ljl/c;->c()Ljl/b;

    .line 99
    .line 100
    .line 101
    move-result-object p2

    .line 102
    sget-object p3, Lkm/f;->d:Lkm/f;

    .line 103
    .line 104
    const/16 v1, 0x14

    .line 105
    .line 106
    invoke-direct {p1, v1, p2, p3}, Lk7/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    goto :goto_7b

    .line 110
    :cond_6d
    invoke-virtual {p3, v1, p2}, Lkm/d;->e(II)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p3, p1}, Lkm/d;->c(I)Lk7/c;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    goto :goto_7b

    .line 118
    :cond_75
    invoke-virtual {p3, p1}, Lkm/d;->c(I)Lk7/c;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    goto :goto_7b

    .line 123
    :cond_7a
    move-object p1, v0

    .line 124
    :goto_7b
    if-eqz p1, :cond_c5

    .line 125
    .line 126
    sget-object p2, Lkm/b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 127
    .line 128
    iget-object p2, p0, Lim/f;->M:Lim/e;

    .line 129
    .line 130
    const-string p3, "animation"

    .line 131
    .line 132
    invoke-static {p2, p3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    sget-object p3, Lkm/b;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 136
    .line 137
    invoke-virtual {p3, p2}, Ljava/util/concurrent/ConcurrentHashMap;->contains(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-nez v1, :cond_9d

    .line 142
    .line 143
    iget v1, p2, Lim/e;->a:I

    .line 144
    .line 145
    int-to-float v1, v1

    .line 146
    const v2, 0x3e4ccccd    # 0.2f

    .line 147
    .line 148
    .line 149
    mul-float/2addr v1, v2

    .line 150
    float-to-int v1, v1

    .line 151
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    invoke-virtual {p3, p2, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    :cond_9d
    iget-object p2, p1, Lk7/c;->i:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast p2, Lkm/f;

    .line 161
    .line 162
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 163
    .line 164
    .line 165
    move-result p2

    .line 166
    if-eqz p2, :cond_c0

    .line 167
    .line 168
    const/4 p3, 0x1

    .line 169
    if-eq p2, p3, :cond_ba

    .line 170
    .line 171
    const/4 p3, 0x2

    .line 172
    if-ne p2, p3, :cond_b3

    .line 173
    .line 174
    sget-object p2, Lkm/b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 175
    .line 176
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 177
    .line 178
    .line 179
    goto :goto_c5

    .line 180
    :cond_b3
    new-instance p1, Lan/g;

    .line 181
    .line 182
    const/4 p2, 0x0

    .line 183
    invoke-direct {p1, p2}, Lan/g;-><init>(Z)V

    .line 184
    .line 185
    .line 186
    throw p1

    .line 187
    :cond_ba
    sget-object p2, Lkm/b;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 188
    .line 189
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 190
    .line 191
    .line 192
    goto :goto_c5

    .line 193
    :cond_c0
    sget-object p2, Lkm/b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 194
    .line 195
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 196
    .line 197
    .line 198
    :cond_c5
    :goto_c5
    if-eqz p1, :cond_cc

    .line 199
    .line 200
    iget-object p1, p1, Lk7/c;->e:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast p1, Ljl/b;

    .line 203
    .line 204
    return-object p1

    .line 205
    :cond_cc
    return-object v0
.end method

.method public final c(II)Landroidx/core/view/t;
    .registers 10

    .line 1
    iget-boolean v0, p0, Lim/f;->v:Z

    .line 2
    .line 3
    iget v1, p0, Lim/f;->y:I

    .line 4
    .line 5
    iget v2, p0, Lim/f;->x:I

    .line 6
    .line 7
    if-nez v0, :cond_f

    .line 8
    .line 9
    new-instance p1, Landroidx/core/view/t;

    .line 10
    .line 11
    const/4 p2, 0x6

    .line 12
    invoke-direct {p1, v2, v1, p2}, Landroidx/core/view/t;-><init>(III)V

    .line 13
    .line 14
    .line 15
    return-object p1

    .line 16
    :cond_f
    if-lt p1, v2, :cond_13

    .line 17
    .line 18
    if-ge p2, v1, :cond_27

    .line 19
    .line 20
    :cond_13
    int-to-double v3, v2

    .line 21
    int-to-double v5, v1

    .line 22
    div-double/2addr v3, v5

    .line 23
    if-le p2, p1, :cond_20

    .line 24
    .line 25
    if-le p2, v1, :cond_1b

    .line 26
    .line 27
    move p2, v1

    .line 28
    :cond_1b
    int-to-double v0, p2

    .line 29
    mul-double/2addr v0, v3

    .line 30
    double-to-int v2, v0

    .line 31
    move v1, p2

    .line 32
    goto :goto_27

    .line 33
    :cond_20
    if-le p1, v2, :cond_23

    .line 34
    .line 35
    move p1, v2

    .line 36
    :cond_23
    int-to-double v0, p1

    .line 37
    div-double/2addr v0, v3

    .line 38
    double-to-int v1, v0

    .line 39
    move v2, p1

    .line 40
    :cond_27
    :goto_27
    new-instance p1, Landroidx/core/view/t;

    .line 41
    .line 42
    const/4 p2, 0x6

    .line 43
    invoke-direct {p1, v2, v1, p2}, Landroidx/core/view/t;-><init>(III)V

    .line 44
    .line 45
    .line 46
    return-object p1
.end method

.method public final d()V
    .registers 6

    .line 1
    invoke-virtual {p0}, Lim/f;->e()Lkm/d;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_1e

    .line 6
    .line 7
    sget-object v1, Lkm/e;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 8
    .line 9
    const-string v1, "cacheKey"

    .line 10
    .line 11
    iget-object v2, p0, Lim/f;->w:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v2, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget-object v1, Lkm/e;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 17
    .line 18
    new-instance v3, Lkm/g;

    .line 19
    .line 20
    new-instance v4, Ljava/util/Date;

    .line 21
    .line 22
    invoke-direct {v4}, Ljava/util/Date;-><init>()V

    .line 23
    .line 24
    .line 25
    invoke-direct {v3, v0, v4}, Lkm/g;-><init>(Lkm/d;Ljava/util/Date;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    :cond_1e
    const/4 v0, 0x0

    .line 32
    iput-object v0, p0, Lim/f;->J:Lkm/d;

    .line 33
    .line 34
    return-void
.end method

.method public final e()Lkm/d;
    .registers 9

    .line 1
    iget-object v0, p0, Lim/f;->J:Lkm/d;

    .line 2
    .line 3
    if-nez v0, :cond_3d

    .line 4
    .line 5
    iget-object v0, p0, Lim/f;->i:Lkm/e;

    .line 6
    .line 7
    iget-object v1, p0, Lim/f;->w:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, p0, Lim/f;->e:Llm/a;

    .line 10
    .line 11
    iget-object v6, p0, Lim/f;->d:Landroidx/core/view/g0;

    .line 12
    .line 13
    const-string v2, "cacheKey"

    .line 14
    .line 15
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    sget-object v2, Lkm/e;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 19
    .line 20
    monitor-enter v2

    .line 21
    :try_start_14
    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Lkm/g;

    .line 26
    .line 27
    if-eqz v3, :cond_25

    .line 28
    .line 29
    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    iget-object v0, v3, Lkm/g;->a:Lkm/d;
    :try_end_21
    .catchall {:try_start_14 .. :try_end_21} :catchall_23

    .line 33
    .line 34
    monitor-exit v2

    .line 35
    goto :goto_38

    .line 36
    :catchall_23
    move-exception v0

    .line 37
    goto :goto_3b

    .line 38
    :cond_25
    monitor-exit v2

    .line 39
    new-instance v2, Lkm/d;

    .line 40
    .line 41
    iget-object v3, v0, Lkm/e;->a:Lym/b;

    .line 42
    .line 43
    new-instance v5, Lim/d;

    .line 44
    .line 45
    iget v1, v0, Lkm/e;->b:I

    .line 46
    .line 47
    const/4 v7, 0x5

    .line 48
    invoke-direct {v5, v1, v7}, Lim/d;-><init>(II)V

    .line 49
    .line 50
    .line 51
    iget v7, v0, Lkm/e;->c:I

    .line 52
    .line 53
    invoke-direct/range {v2 .. v7}, Lkm/d;-><init>(Lym/b;Llm/a;Lim/d;Landroidx/core/view/g0;I)V

    .line 54
    .line 55
    .line 56
    move-object v0, v2

    .line 57
    :goto_38
    iput-object v0, p0, Lim/f;->J:Lkm/d;

    .line 58
    .line 59
    goto :goto_3d

    .line 60
    :goto_3b
    monitor-exit v2

    .line 61
    throw v0

    .line 62
    :cond_3d
    :goto_3d
    iget-object v0, p0, Lim/f;->J:Lkm/d;

    .line 63
    .line 64
    return-object v0
.end method

.method public final h()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lim/f;->e()Lkm/d;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lim/f;->d()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final i(II)V
    .registers 4

    .line 1
    if-lez p1, :cond_1c

    .line 2
    .line 3
    if-lez p2, :cond_1c

    .line 4
    .line 5
    iget v0, p0, Lim/f;->x:I

    .line 6
    .line 7
    if-lez v0, :cond_1c

    .line 8
    .line 9
    iget v0, p0, Lim/f;->y:I

    .line 10
    .line 11
    if-gtz v0, :cond_d

    .line 12
    .line 13
    goto :goto_1c

    .line 14
    :cond_d
    invoke-virtual {p0, p1, p2}, Lim/f;->c(II)Landroidx/core/view/t;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    invoke-virtual {p0}, Lim/f;->e()Lkm/d;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    if-eqz p2, :cond_1c

    .line 23
    .line 24
    iget p1, p1, Landroidx/core/view/t;->b:I

    .line 25
    .line 26
    invoke-virtual {p2, p1, p1}, Lkm/d;->e(II)V

    .line 27
    .line 28
    .line 29
    :cond_1c
    :goto_1c
    return-void
.end method
