###### Class i50.e (i50.e)
.class public final Li50/e;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lq40/q0;Li50/a;Lio/sentry/internal/debugmeta/c;Lk60/w;)Lk60/o0;
    .registers 10

    .line 1
    const-string v0, "typeAttr"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "typeParameterUpperBoundEraser"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-boolean p2, p1, Li50/a;->c:Z

    .line 12
    .line 13
    if-eqz p2, :cond_f

    .line 14
    .line 15
    goto :goto_1b

    .line 16
    :cond_f
    sget-object v1, Li50/b;->d:Li50/b;

    .line 17
    .line 18
    const/4 v4, 0x0

    .line 19
    const/16 v5, 0x3d

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    const/4 v3, 0x0

    .line 23
    move-object v0, p1

    .line 24
    invoke-static/range {v0 .. v5}, Li50/a;->a(Li50/a;Li50/b;ZLjava/util/Set;Lk60/a0;I)Li50/a;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    :goto_1b
    iget-object p2, p1, Li50/a;->b:Li50/b;

    .line 29
    .line 30
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 31
    .line 32
    .line 33
    move-result p2

    .line 34
    if-eqz p2, :cond_38

    .line 35
    .line 36
    const/4 v0, 0x1

    .line 37
    if-eq p2, v0, :cond_38

    .line 38
    .line 39
    const/4 p0, 0x2

    .line 40
    if-ne p2, p0, :cond_31

    .line 41
    .line 42
    new-instance p0, Lk60/f0;

    .line 43
    .line 44
    sget-object p1, Lk60/z0;->i:Lk60/z0;

    .line 45
    .line 46
    invoke-direct {p0, p3, p1}, Lk60/f0;-><init>(Lk60/w;Lk60/z0;)V

    .line 47
    .line 48
    .line 49
    return-object p0

    .line 50
    :cond_31
    new-instance p0, Lan/g;

    .line 51
    .line 52
    const/4 p1, 0x0

    .line 53
    invoke-direct {p0, p1}, Lan/g;-><init>(Z)V

    .line 54
    .line 55
    .line 56
    throw p0

    .line 57
    :cond_38
    invoke-interface {p0}, Lq40/q0;->M0()Lk60/z0;

    .line 58
    .line 59
    .line 60
    move-result-object p2

    .line 61
    iget-boolean p2, p2, Lk60/z0;->e:Z

    .line 62
    .line 63
    if-nez p2, :cond_50

    .line 64
    .line 65
    new-instance p1, Lk60/f0;

    .line 66
    .line 67
    sget-object p2, Lk60/z0;->i:Lk60/z0;

    .line 68
    .line 69
    invoke-static {p0}, La60/e;->e(Lq40/k;)Ln40/i;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    invoke-virtual {p0}, Ln40/i;->o()Lk60/a0;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    invoke-direct {p1, p0, p2}, Lk60/f0;-><init>(Lk60/w;Lk60/z0;)V

    .line 78
    .line 79
    .line 80
    return-object p1

    .line 81
    :cond_50
    invoke-virtual {p3}, Lk60/w;->n()Lk60/l0;

    .line 82
    .line 83
    .line 84
    move-result-object p2

    .line 85
    invoke-interface {p2}, Lk60/l0;->getParameters()Ljava/util/List;

    .line 86
    .line 87
    .line 88
    move-result-object p2

    .line 89
    const-string v0, "getParameters(...)"

    .line 90
    .line 91
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    .line 95
    .line 96
    .line 97
    move-result p2

    .line 98
    if-nez p2, :cond_6b

    .line 99
    .line 100
    new-instance p0, Lk60/f0;

    .line 101
    .line 102
    sget-object p1, Lk60/z0;->w:Lk60/z0;

    .line 103
    .line 104
    invoke-direct {p0, p3, p1}, Lk60/f0;-><init>(Lk60/w;Lk60/z0;)V

    .line 105
    .line 106
    .line 107
    return-object p0

    .line 108
    :cond_6b
    invoke-static {p0, p1}, Lk60/w0;->l(Lq40/q0;Li50/a;)Lk60/o0;

    .line 109
    .line 110
    .line 111
    move-result-object p0

    .line 112
    return-object p0
.end method
