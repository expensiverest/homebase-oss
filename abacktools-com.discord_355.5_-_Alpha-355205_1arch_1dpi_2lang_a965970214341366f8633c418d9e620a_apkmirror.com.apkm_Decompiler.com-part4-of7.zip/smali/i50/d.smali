###### Class i50.d (i50.d)
.class public abstract Li50/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lt50/c;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lt50/c;

    .line 2
    .line 3
    const-string v1, "java.lang.Class"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lt50/c;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Li50/d;->a:Lt50/c;

    .line 9
    .line 10
    return-void
.end method
