###### Class ih.a (ih.a)
.class public final synthetic Lih/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcom/discord/notifications/react/PushNotificationModule;


# direct methods
.method public synthetic constructor <init>(Lcom/discord/notifications/react/PushNotificationModule;I)V
    .registers 3

    .line 1
    iput p2, p0, Lih/a;->d:I

    iput-object p1, p0, Lih/a;->e:Lcom/discord/notifications/react/PushNotificationModule;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lih/a;->d:I

    packed-switch v0, :pswitch_data_20

    iget-object v0, p0, Lih/a;->e:Lcom/discord/notifications/react/PushNotificationModule;

    check-cast p1, Ljava/util/Map;

    invoke-static {v0, p1}, Lcom/discord/notifications/react/PushNotificationModule;->b(Lcom/discord/notifications/react/PushNotificationModule;Ljava/util/Map;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_e
    iget-object v0, p0, Lih/a;->e:Lcom/discord/notifications/react/PushNotificationModule;

    check-cast p1, Ljava/util/Map;

    invoke-static {v0, p1}, Lcom/discord/notifications/react/PushNotificationModule;->a(Lcom/discord/notifications/react/PushNotificationModule;Ljava/util/Map;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_17
    iget-object v0, p0, Lih/a;->e:Lcom/discord/notifications/react/PushNotificationModule;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/discord/notifications/react/PushNotificationModule;->d(Lcom/discord/notifications/react/PushNotificationModule;Ljava/lang/String;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_17
        :pswitch_e
    .end packed-switch
.end method
