###### Class ih.b (ih.b)
.class public final Lih/b;
.super Ljava/lang/Object;
.source "SourceFile"
