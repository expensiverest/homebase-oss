###### Class i20.a (i20.a)
.class public final Li20/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .registers 0

    .line 1
    return-void
.end method

.method public static a(Ljava/lang/Object;)Li20/d;
    .registers 2

    .line 1
    if-eqz p0, :cond_8

    .line 2
    .line 3
    new-instance v0, Li20/c;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Li20/c;-><init>(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-object v0

    .line 9
    :cond_8
    sget-object p0, Li20/b;->a:Li20/b;

    .line 10
    .line 11
    return-object p0
.end method
