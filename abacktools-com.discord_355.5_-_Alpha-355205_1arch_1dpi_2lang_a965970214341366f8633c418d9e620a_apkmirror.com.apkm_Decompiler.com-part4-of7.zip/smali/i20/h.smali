###### Class i20.h (i20.h)
.class public interface abstract Li20/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getItem()Li20/n;
.end method
