###### Class i20.b (i20.b)
.class public final Li20/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li20/d;


# static fields
.field public static final a:Li20/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Li20/b;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Li20/b;->a:Li20/b;

    .line 7
    .line 8
    return-void
.end method
