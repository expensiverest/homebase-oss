###### Class i20.n (i20.n)
.class public final Li20/n;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Z

.field public final g:Z

.field public final h:Li20/q;

.field public final i:Landroid/graphics/drawable/Drawable;

.field public final j:Ljava/lang/Integer;

.field public final k:Ljava/lang/Integer;

.field public final l:Ljava/lang/Integer;

.field public final m:Ljava/lang/Integer;

.field public final n:Ljava/lang/String;

.field public final o:Li20/r;

.field public final p:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLi20/q;Landroid/graphics/drawable/Drawable;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Li20/r;Z)V
    .registers 19

    .line 1
    move-object/from16 v0, p15

    .line 2
    .line 3
    const-string v1, "showAsAction"

    .line 4
    .line 5
    invoke-static {p8, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v1, "itemType"

    .line 9
    .line 10
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Li20/n;->a:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p2, p0, Li20/n;->b:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p3, p0, Li20/n;->c:Ljava/lang/String;

    .line 21
    .line 22
    iput-object p4, p0, Li20/n;->d:Ljava/lang/String;

    .line 23
    .line 24
    iput-object p5, p0, Li20/n;->e:Ljava/lang/String;

    .line 25
    .line 26
    iput-boolean p6, p0, Li20/n;->f:Z

    .line 27
    .line 28
    iput-boolean p7, p0, Li20/n;->g:Z

    .line 29
    .line 30
    iput-object p8, p0, Li20/n;->h:Li20/q;

    .line 31
    .line 32
    iput-object p9, p0, Li20/n;->i:Landroid/graphics/drawable/Drawable;

    .line 33
    .line 34
    iput-object p10, p0, Li20/n;->j:Ljava/lang/Integer;

    .line 35
    .line 36
    iput-object p11, p0, Li20/n;->k:Ljava/lang/Integer;

    .line 37
    .line 38
    iput-object p12, p0, Li20/n;->l:Ljava/lang/Integer;

    .line 39
    .line 40
    iput-object p13, p0, Li20/n;->m:Ljava/lang/Integer;

    .line 41
    .line 42
    move-object/from16 p1, p14

    .line 43
    .line 44
    iput-object p1, p0, Li20/n;->n:Ljava/lang/String;

    .line 45
    .line 46
    iput-object v0, p0, Li20/n;->o:Li20/r;

    .line 47
    .line 48
    move/from16 p1, p16

    .line 49
    .line 50
    iput-boolean p1, p0, Li20/n;->p:Z

    .line 51
    .line 52
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Li20/n;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Li20/n;

    .line 12
    .line 13
    iget-object v1, p0, Li20/n;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Li20/n;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    iget-object v1, p0, Li20/n;->b:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v3, p1, Li20/n;->b:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_22

    .line 33
    .line 34
    return v2

    .line 35
    :cond_22
    iget-object v1, p0, Li20/n;->c:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v3, p1, Li20/n;->c:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_2d

    .line 44
    .line 45
    return v2

    .line 46
    :cond_2d
    iget-object v1, p0, Li20/n;->d:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v3, p1, Li20/n;->d:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-nez v1, :cond_38

    .line 55
    .line 56
    return v2

    .line 57
    :cond_38
    iget-object v1, p0, Li20/n;->e:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v3, p1, Li20/n;->e:Ljava/lang/String;

    .line 60
    .line 61
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-nez v1, :cond_43

    .line 66
    .line 67
    return v2

    .line 68
    :cond_43
    iget-boolean v1, p0, Li20/n;->f:Z

    .line 69
    .line 70
    iget-boolean v3, p1, Li20/n;->f:Z

    .line 71
    .line 72
    if-eq v1, v3, :cond_4a

    .line 73
    .line 74
    return v2

    .line 75
    :cond_4a
    iget-boolean v1, p0, Li20/n;->g:Z

    .line 76
    .line 77
    iget-boolean v3, p1, Li20/n;->g:Z

    .line 78
    .line 79
    if-eq v1, v3, :cond_51

    .line 80
    .line 81
    return v2

    .line 82
    :cond_51
    iget-object v1, p0, Li20/n;->h:Li20/q;

    .line 83
    .line 84
    iget-object v3, p1, Li20/n;->h:Li20/q;

    .line 85
    .line 86
    if-eq v1, v3, :cond_58

    .line 87
    .line 88
    return v2

    .line 89
    :cond_58
    iget-object v1, p0, Li20/n;->i:Landroid/graphics/drawable/Drawable;

    .line 90
    .line 91
    iget-object v3, p1, Li20/n;->i:Landroid/graphics/drawable/Drawable;

    .line 92
    .line 93
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v1

    .line 97
    if-nez v1, :cond_63

    .line 98
    .line 99
    return v2

    .line 100
    :cond_63
    iget-object v1, p0, Li20/n;->j:Ljava/lang/Integer;

    .line 101
    .line 102
    iget-object v3, p1, Li20/n;->j:Ljava/lang/Integer;

    .line 103
    .line 104
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v1

    .line 108
    if-nez v1, :cond_6e

    .line 109
    .line 110
    return v2

    .line 111
    :cond_6e
    iget-object v1, p0, Li20/n;->k:Ljava/lang/Integer;

    .line 112
    .line 113
    iget-object v3, p1, Li20/n;->k:Ljava/lang/Integer;

    .line 114
    .line 115
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    if-nez v1, :cond_79

    .line 120
    .line 121
    return v2

    .line 122
    :cond_79
    iget-object v1, p0, Li20/n;->l:Ljava/lang/Integer;

    .line 123
    .line 124
    iget-object v3, p1, Li20/n;->l:Ljava/lang/Integer;

    .line 125
    .line 126
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v1

    .line 130
    if-nez v1, :cond_84

    .line 131
    .line 132
    return v2

    .line 133
    :cond_84
    iget-object v1, p0, Li20/n;->m:Ljava/lang/Integer;

    .line 134
    .line 135
    iget-object v3, p1, Li20/n;->m:Ljava/lang/Integer;

    .line 136
    .line 137
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-nez v1, :cond_8f

    .line 142
    .line 143
    return v2

    .line 144
    :cond_8f
    iget-object v1, p0, Li20/n;->n:Ljava/lang/String;

    .line 145
    .line 146
    iget-object v3, p1, Li20/n;->n:Ljava/lang/String;

    .line 147
    .line 148
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v1

    .line 152
    if-nez v1, :cond_9a

    .line 153
    .line 154
    return v2

    .line 155
    :cond_9a
    iget-object v1, p0, Li20/n;->o:Li20/r;

    .line 156
    .line 157
    iget-object v3, p1, Li20/n;->o:Li20/r;

    .line 158
    .line 159
    if-eq v1, v3, :cond_a1

    .line 160
    .line 161
    return v2

    .line 162
    :cond_a1
    iget-boolean v1, p0, Li20/n;->p:Z

    .line 163
    .line 164
    iget-boolean p1, p1, Li20/n;->p:Z

    .line 165
    .line 166
    if-eq v1, p1, :cond_a8

    .line 167
    .line 168
    return v2

    .line 169
    :cond_a8
    return v0
.end method

.method public final hashCode()I
    .registers 5

    .line 1
    iget-object v0, p0, Li20/n;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    const/4 v2, 0x0

    .line 11
    iget-object v3, p0, Li20/n;->b:Ljava/lang/String;

    .line 12
    .line 13
    if-nez v3, :cond_10

    .line 14
    .line 15
    move v3, v2

    .line 16
    goto :goto_14

    .line 17
    :cond_10
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    :goto_14
    add-int/2addr v0, v3

    .line 22
    mul-int/2addr v0, v1

    .line 23
    iget-object v3, p0, Li20/n;->c:Ljava/lang/String;

    .line 24
    .line 25
    if-nez v3, :cond_1c

    .line 26
    .line 27
    move v3, v2

    .line 28
    goto :goto_20

    .line 29
    :cond_1c
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    :goto_20
    add-int/2addr v0, v3

    .line 34
    mul-int/2addr v0, v1

    .line 35
    iget-object v3, p0, Li20/n;->d:Ljava/lang/String;

    .line 36
    .line 37
    if-nez v3, :cond_28

    .line 38
    .line 39
    move v3, v2

    .line 40
    goto :goto_2c

    .line 41
    :cond_28
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    :goto_2c
    add-int/2addr v0, v3

    .line 46
    mul-int/2addr v0, v1

    .line 47
    iget-object v3, p0, Li20/n;->e:Ljava/lang/String;

    .line 48
    .line 49
    if-nez v3, :cond_34

    .line 50
    .line 51
    move v3, v2

    .line 52
    goto :goto_38

    .line 53
    :cond_34
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    :goto_38
    add-int/2addr v0, v3

    .line 58
    mul-int/2addr v0, v1

    .line 59
    iget-boolean v3, p0, Li20/n;->f:Z

    .line 60
    .line 61
    invoke-static {v0, v1, v3}, Lhs/q;->d(IIZ)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    iget-boolean v3, p0, Li20/n;->g:Z

    .line 66
    .line 67
    invoke-static {v0, v1, v3}, Lhs/q;->d(IIZ)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    iget-object v3, p0, Li20/n;->h:Li20/q;

    .line 72
    .line 73
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 74
    .line 75
    .line 76
    move-result v3

    .line 77
    add-int/2addr v3, v0

    .line 78
    mul-int/2addr v3, v1

    .line 79
    iget-object v0, p0, Li20/n;->i:Landroid/graphics/drawable/Drawable;

    .line 80
    .line 81
    if-nez v0, :cond_54

    .line 82
    .line 83
    move v0, v2

    .line 84
    goto :goto_58

    .line 85
    :cond_54
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    :goto_58
    add-int/2addr v3, v0

    .line 90
    mul-int/2addr v3, v1

    .line 91
    iget-object v0, p0, Li20/n;->j:Ljava/lang/Integer;

    .line 92
    .line 93
    if-nez v0, :cond_60

    .line 94
    .line 95
    move v0, v2

    .line 96
    goto :goto_64

    .line 97
    :cond_60
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    :goto_64
    add-int/2addr v3, v0

    .line 102
    mul-int/2addr v3, v1

    .line 103
    iget-object v0, p0, Li20/n;->k:Ljava/lang/Integer;

    .line 104
    .line 105
    if-nez v0, :cond_6c

    .line 106
    .line 107
    move v0, v2

    .line 108
    goto :goto_70

    .line 109
    :cond_6c
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    :goto_70
    add-int/2addr v3, v0

    .line 114
    mul-int/2addr v3, v1

    .line 115
    iget-object v0, p0, Li20/n;->l:Ljava/lang/Integer;

    .line 116
    .line 117
    if-nez v0, :cond_78

    .line 118
    .line 119
    move v0, v2

    .line 120
    goto :goto_7c

    .line 121
    :cond_78
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    :goto_7c
    add-int/2addr v3, v0

    .line 126
    mul-int/2addr v3, v1

    .line 127
    iget-object v0, p0, Li20/n;->m:Ljava/lang/Integer;

    .line 128
    .line 129
    if-nez v0, :cond_84

    .line 130
    .line 131
    move v0, v2

    .line 132
    goto :goto_88

    .line 133
    :cond_84
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    :goto_88
    add-int/2addr v3, v0

    .line 138
    mul-int/2addr v3, v1

    .line 139
    iget-object v0, p0, Li20/n;->n:Ljava/lang/String;

    .line 140
    .line 141
    if-nez v0, :cond_8f

    .line 142
    .line 143
    goto :goto_93

    .line 144
    :cond_8f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    :goto_93
    add-int/2addr v3, v2

    .line 149
    mul-int/2addr v3, v1

    .line 150
    iget-object v0, p0, Li20/n;->o:Li20/r;

    .line 151
    .line 152
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    add-int/2addr v0, v3

    .line 157
    mul-int/2addr v0, v1

    .line 158
    iget-boolean v1, p0, Li20/n;->p:Z

    .line 159
    .line 160
    invoke-static {v1}, Ljava/lang/Boolean;->hashCode(Z)I

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    add-int/2addr v1, v0

    .line 165
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    const-string v0, ", title="

    .line 2
    .line 3
    const-string v1, ", titleCondensed="

    .line 4
    .line 5
    const-string v2, "StackHeaderToolbarMenuItemConfig(id="

    .line 6
    .line 7
    iget-object v3, p0, Li20/n;->a:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, p0, Li20/n;->b:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v2, v3, v0, v4, v1}, Lp/x2;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, ", tooltipText="

    .line 16
    .line 17
    const-string v2, ", accessibilityLabel="

    .line 18
    .line 19
    iget-object v3, p0, Li20/n;->c:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v4, p0, Li20/n;->d:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {v0, v3, v1, v4, v2}, Lp/x2;->t(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, Li20/n;->e:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, ", hidden="

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget-boolean v1, p0, Li20/n;->f:Z

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    const-string v1, ", disabled="

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    iget-boolean v1, p0, Li20/n;->g:Z

    .line 47
    .line 48
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    const-string v1, ", showAsAction="

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    iget-object v1, p0, Li20/n;->h:Li20/q;

    .line 57
    .line 58
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v1, ", icon="

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    iget-object v1, p0, Li20/n;->i:Landroid/graphics/drawable/Drawable;

    .line 67
    .line 68
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    const-string v1, ", iconTintColorNormal="

    .line 72
    .line 73
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    iget-object v1, p0, Li20/n;->j:Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    const-string v1, ", iconTintColorPressed="

    .line 82
    .line 83
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    const-string v1, ", iconTintColorFocused="

    .line 87
    .line 88
    const-string v2, ", iconTintColorDisabled="

    .line 89
    .line 90
    iget-object v3, p0, Li20/n;->k:Ljava/lang/Integer;

    .line 91
    .line 92
    iget-object v4, p0, Li20/n;->l:Ljava/lang/Integer;

    .line 93
    .line 94
    invoke-static {v0, v3, v1, v4, v2}, Lp/x2;->r(Ljava/lang/StringBuilder;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    const-string v1, ", groupId="

    .line 98
    .line 99
    const-string v2, ", itemType="

    .line 100
    .line 101
    iget-object v3, p0, Li20/n;->m:Ljava/lang/Integer;

    .line 102
    .line 103
    iget-object v4, p0, Li20/n;->n:Ljava/lang/String;

    .line 104
    .line 105
    invoke-static {v3, v1, v4, v2, v0}, Lp/x2;->p(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;)V

    .line 106
    .line 107
    .line 108
    iget-object v1, p0, Li20/n;->o:Li20/r;

    .line 109
    .line 110
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    const-string v1, ", initialToggleState="

    .line 114
    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    iget-boolean v1, p0, Li20/n;->p:Z

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    const-string v1, ")"

    .line 124
    .line 125
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    return-object v0
.end method
