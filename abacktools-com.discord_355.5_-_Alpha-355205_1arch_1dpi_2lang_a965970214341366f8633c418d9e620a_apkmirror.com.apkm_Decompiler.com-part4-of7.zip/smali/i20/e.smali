###### Class i20.e (i20.e)
.class public final Li20/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/List;

.field public final b:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/util/List;)V
    .registers 4

    .line 1
    const-string v0, "children"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Li20/e;->a:Ljava/util/List;

    .line 10
    .line 11
    iput-object p2, p0, Li20/e;->b:Ljava/util/List;

    .line 12
    .line 13
    return-void
.end method

.method public static a(Li20/e;Ljava/util/List;)Li20/e;
    .registers 3

    .line 1
    iget-object p0, p0, Li20/e;->a:Ljava/util/List;

    .line 2
    .line 3
    const-string v0, "children"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance v0, Li20/e;

    .line 9
    .line 10
    invoke-direct {v0, p0, p1}, Li20/e;-><init>(Ljava/util/List;Ljava/util/List;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public static b(Ljava/util/List;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Ljava/util/List;
    .registers 27

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v10, p2

    .line 4
    .line 5
    invoke-interface/range {p0 .. p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 6
    .line 7
    .line 8
    move-result-object v18

    .line 9
    const/4 v1, 0x0

    .line 10
    :goto_9
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    if-eqz v2, :cond_db

    .line 15
    .line 16
    add-int/lit8 v19, v1, 0x1

    .line 17
    .line 18
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    check-cast v2, Li20/h;

    .line 23
    .line 24
    invoke-interface {v2}, Li20/h;->getItem()Li20/n;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    iget-object v3, v3, Li20/n;->a:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    const/4 v4, 0x0

    .line 35
    if-eqz v3, :cond_a8

    .line 36
    .line 37
    invoke-interface {v2}, Li20/h;->getItem()Li20/n;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    iget-object v3, v3, Li20/n;->i:Landroid/graphics/drawable/Drawable;

    .line 42
    .line 43
    if-eq v10, v3, :cond_a2

    .line 44
    .line 45
    invoke-interface {v2}, Li20/h;->getItem()Li20/n;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    move-object v5, v2

    .line 50
    iget-object v2, v3, Li20/n;->a:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v6, v3, Li20/n;->b:Ljava/lang/String;

    .line 53
    .line 54
    move-object v7, v4

    .line 55
    iget-object v4, v3, Li20/n;->c:Ljava/lang/String;

    .line 56
    .line 57
    move-object v8, v5

    .line 58
    iget-object v5, v3, Li20/n;->d:Ljava/lang/String;

    .line 59
    .line 60
    move-object v9, v6

    .line 61
    iget-object v6, v3, Li20/n;->e:Ljava/lang/String;

    .line 62
    .line 63
    move-object v11, v7

    .line 64
    iget-boolean v7, v3, Li20/n;->f:Z

    .line 65
    .line 66
    move-object v12, v8

    .line 67
    iget-boolean v8, v3, Li20/n;->g:Z

    .line 68
    .line 69
    move-object v13, v9

    .line 70
    iget-object v9, v3, Li20/n;->h:Li20/q;

    .line 71
    .line 72
    move-object v14, v11

    .line 73
    iget-object v11, v3, Li20/n;->j:Ljava/lang/Integer;

    .line 74
    .line 75
    move-object v15, v12

    .line 76
    iget-object v12, v3, Li20/n;->k:Ljava/lang/Integer;

    .line 77
    .line 78
    move-object/from16 v16, v13

    .line 79
    .line 80
    iget-object v13, v3, Li20/n;->l:Ljava/lang/Integer;

    .line 81
    .line 82
    move-object/from16 v17, v14

    .line 83
    .line 84
    iget-object v14, v3, Li20/n;->m:Ljava/lang/Integer;

    .line 85
    .line 86
    move-object/from16 v20, v15

    .line 87
    .line 88
    iget-object v15, v3, Li20/n;->n:Ljava/lang/String;

    .line 89
    .line 90
    move/from16 v21, v1

    .line 91
    .line 92
    iget-object v1, v3, Li20/n;->o:Li20/r;

    .line 93
    .line 94
    iget-boolean v3, v3, Li20/n;->p:Z

    .line 95
    .line 96
    move-object/from16 v22, v2

    .line 97
    .line 98
    const-string v2, "showAsAction"

    .line 99
    .line 100
    invoke-static {v9, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    const-string v2, "itemType"

    .line 104
    .line 105
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    move-object/from16 v2, v17

    .line 109
    .line 110
    move/from16 v17, v3

    .line 111
    .line 112
    move-object/from16 v3, v16

    .line 113
    .line 114
    move-object/from16 v16, v1

    .line 115
    .line 116
    new-instance v1, Li20/n;

    .line 117
    .line 118
    move-object/from16 v0, v20

    .line 119
    .line 120
    move/from16 v23, v21

    .line 121
    .line 122
    move-object/from16 v2, v22

    .line 123
    .line 124
    invoke-direct/range {v1 .. v17}, Li20/n;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLi20/q;Landroid/graphics/drawable/Drawable;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Li20/r;Z)V

    .line 125
    .line 126
    .line 127
    instance-of v2, v0, Li20/f;

    .line 128
    .line 129
    if-eqz v2, :cond_8d

    .line 130
    .line 131
    move-object v2, v0

    .line 132
    check-cast v2, Li20/f;

    .line 133
    .line 134
    new-instance v2, Li20/f;

    .line 135
    .line 136
    invoke-direct {v2, v1}, Li20/f;-><init>(Li20/n;)V

    .line 137
    .line 138
    .line 139
    :goto_8a
    move-object/from16 v4, p1

    .line 140
    .line 141
    goto :goto_ca

    .line 142
    :cond_8d
    instance-of v2, v0, Li20/g;

    .line 143
    .line 144
    if-eqz v2, :cond_9b

    .line 145
    .line 146
    move-object v2, v0

    .line 147
    check-cast v2, Li20/g;

    .line 148
    .line 149
    const/4 v3, 0x6

    .line 150
    const/4 v14, 0x0

    .line 151
    invoke-static {v2, v1, v14, v3}, Li20/g;->a(Li20/g;Li20/n;Li20/e;I)Li20/g;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    goto :goto_8a

    .line 156
    :cond_9b
    new-instance v0, Lan/g;

    .line 157
    .line 158
    const/4 v1, 0x0

    .line 159
    invoke-direct {v0, v1}, Lan/g;-><init>(Z)V

    .line 160
    .line 161
    .line 162
    throw v0

    .line 163
    :cond_a2
    move/from16 v23, v1

    .line 164
    .line 165
    move-object v0, v2

    .line 166
    :cond_a5
    move-object/from16 v4, p1

    .line 167
    .line 168
    goto :goto_c9

    .line 169
    :cond_a8
    move/from16 v23, v1

    .line 170
    .line 171
    move-object v0, v2

    .line 172
    move-object v14, v4

    .line 173
    instance-of v1, v0, Li20/g;

    .line 174
    .line 175
    if-eqz v1, :cond_a5

    .line 176
    .line 177
    move-object v2, v0

    .line 178
    check-cast v2, Li20/g;

    .line 179
    .line 180
    iget-object v1, v2, Li20/g;->b:Li20/e;

    .line 181
    .line 182
    iget-object v3, v1, Li20/e;->b:Ljava/util/List;

    .line 183
    .line 184
    move-object/from16 v4, p1

    .line 185
    .line 186
    invoke-static {v3, v4, v10}, Li20/e;->b(Ljava/util/List;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Ljava/util/List;

    .line 187
    .line 188
    .line 189
    move-result-object v5

    .line 190
    if-eq v5, v3, :cond_c9

    .line 191
    .line 192
    invoke-static {v1, v5}, Li20/e;->a(Li20/e;Ljava/util/List;)Li20/e;

    .line 193
    .line 194
    .line 195
    move-result-object v1

    .line 196
    const/4 v3, 0x5

    .line 197
    invoke-static {v2, v14, v1, v3}, Li20/g;->a(Li20/g;Li20/n;Li20/e;I)Li20/g;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    goto :goto_ca

    .line 202
    :cond_c9
    :goto_c9
    move-object v2, v0

    .line 203
    :goto_ca
    if-eq v2, v0, :cond_d6

    .line 204
    .line 205
    invoke-static/range {p0 .. p0}, Lm30/q;->T0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    move/from16 v1, v23

    .line 210
    .line 211
    invoke-virtual {v0, v1, v2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    return-object v0

    .line 215
    :cond_d6
    move-object v0, v4

    .line 216
    move/from16 v1, v19

    .line 217
    .line 218
    goto/16 :goto_9

    .line 219
    .line 220
    :cond_db
    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Li20/e;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Li20/e;

    .line 12
    .line 13
    iget-object v1, p0, Li20/e;->a:Ljava/util/List;

    .line 14
    .line 15
    iget-object v3, p1, Li20/e;->a:Ljava/util/List;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    iget-object v1, p0, Li20/e;->b:Ljava/util/List;

    .line 25
    .line 26
    iget-object p1, p1, Li20/e;->b:Ljava/util/List;

    .line 27
    .line 28
    invoke-static {v1, p1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-nez p1, :cond_22

    .line 33
    .line 34
    return v2

    .line 35
    :cond_22
    return v0
.end method

.method public final hashCode()I
    .registers 3

    .line 1
    iget-object v0, p0, Li20/e;->a:Ljava/util/List;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Li20/e;->b:Ljava/util/List;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "StackHeaderToolbarMenuConfig(groups="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Li20/e;->a:Ljava/util/List;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", children="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Li20/e;->b:Ljava/util/List;

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ")"

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    return-object v0
.end method
