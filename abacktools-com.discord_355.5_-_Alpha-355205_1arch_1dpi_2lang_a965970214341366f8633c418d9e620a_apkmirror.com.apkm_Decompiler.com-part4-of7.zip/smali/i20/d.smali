###### Class i20.d (i20.d)
.class public interface abstract Li20/d;
.super Ljava/lang/Object;
.source "SourceFile"
