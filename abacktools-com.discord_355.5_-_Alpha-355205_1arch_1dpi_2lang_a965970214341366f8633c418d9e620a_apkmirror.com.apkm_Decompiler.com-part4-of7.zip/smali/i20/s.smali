###### Class i20.s (i20.s)
.class public final synthetic Li20/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Li20/j;

.field public final synthetic i:[Li20/k;

.field public final synthetic v:Lbn/j;

.field public final synthetic w:Ljava/util/List;

.field public final synthetic x:Lkotlin/jvm/internal/s;

.field public final synthetic y:Lkotlin/jvm/internal/q;


# direct methods
.method public synthetic constructor <init>(ILi20/j;[Li20/k;Lbn/j;Ljava/util/List;Lkotlin/jvm/internal/s;Lkotlin/jvm/internal/q;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Li20/s;->d:I

    iput-object p2, p0, Li20/s;->e:Li20/j;

    iput-object p3, p0, Li20/s;->i:[Li20/k;

    iput-object p4, p0, Li20/s;->v:Lbn/j;

    iput-object p5, p0, Li20/s;->w:Ljava/util/List;

    iput-object p6, p0, Li20/s;->x:Lkotlin/jvm/internal/s;

    iput-object p7, p0, Li20/s;->y:Lkotlin/jvm/internal/q;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v9, p1

    .line 4
    .line 5
    check-cast v9, Li20/d;

    .line 6
    .line 7
    const-string v1, "icon"

    .line 8
    .line 9
    invoke-static {v9, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object v1, v0, Li20/s;->e:Li20/j;

    .line 13
    .line 14
    iget-object v1, v1, Li20/j;->b:Li20/i;

    .line 15
    .line 16
    iget-object v2, v1, Li20/i;->a:Li20/d;

    .line 17
    .line 18
    iget-object v3, v1, Li20/i;->b:Li20/d;

    .line 19
    .line 20
    iget-object v4, v1, Li20/i;->c:Li20/d;

    .line 21
    .line 22
    iget-object v5, v1, Li20/i;->d:Li20/d;

    .line 23
    .line 24
    iget-object v6, v1, Li20/i;->e:Ljava/lang/Boolean;

    .line 25
    .line 26
    iget-object v7, v1, Li20/i;->f:Ljava/lang/Boolean;

    .line 27
    .line 28
    iget-object v8, v1, Li20/i;->g:Li20/q;

    .line 29
    .line 30
    iget-object v10, v1, Li20/i;->i:Li20/d;

    .line 31
    .line 32
    iget-object v11, v1, Li20/i;->j:Li20/d;

    .line 33
    .line 34
    iget-object v12, v1, Li20/i;->k:Li20/d;

    .line 35
    .line 36
    iget-object v13, v1, Li20/i;->l:Li20/d;

    .line 37
    .line 38
    iget-object v14, v1, Li20/i;->m:Ljava/lang/Boolean;

    .line 39
    .line 40
    iget-object v15, v1, Li20/i;->n:Li20/d;

    .line 41
    .line 42
    new-instance v1, Li20/i;

    .line 43
    .line 44
    invoke-direct/range {v1 .. v15}, Li20/i;-><init>(Li20/d;Li20/d;Li20/d;Li20/d;Ljava/lang/Boolean;Ljava/lang/Boolean;Li20/q;Li20/d;Li20/d;Li20/d;Li20/d;Li20/d;Ljava/lang/Boolean;Li20/d;)V

    .line 45
    .line 46
    .line 47
    iget-object v2, v0, Li20/s;->i:[Li20/k;

    .line 48
    .line 49
    iget-object v3, v0, Li20/s;->v:Lbn/j;

    .line 50
    .line 51
    iget-object v4, v0, Li20/s;->w:Ljava/util/List;

    .line 52
    .line 53
    iget-object v5, v0, Li20/s;->x:Lkotlin/jvm/internal/s;

    .line 54
    .line 55
    iget-object v6, v0, Li20/s;->y:Lkotlin/jvm/internal/q;

    .line 56
    .line 57
    iget v7, v0, Li20/s;->d:I

    .line 58
    .line 59
    move-object/from16 v22, v1

    .line 60
    .line 61
    move-object/from16 v16, v2

    .line 62
    .line 63
    move-object/from16 v17, v3

    .line 64
    .line 65
    move-object/from16 v18, v4

    .line 66
    .line 67
    move-object/from16 v19, v5

    .line 68
    .line 69
    move-object/from16 v20, v6

    .line 70
    .line 71
    move/from16 v21, v7

    .line 72
    .line 73
    invoke-static/range {v16 .. v22}, Lbn/j;->i([Li20/k;Lbn/j;Ljava/util/List;Lkotlin/jvm/internal/s;Lkotlin/jvm/internal/q;ILi20/i;)V

    .line 74
    .line 75
    .line 76
    sget-object v1, Ll30/a0;->a:Ll30/a0;

    .line 77
    .line 78
    return-object v1
.end method
