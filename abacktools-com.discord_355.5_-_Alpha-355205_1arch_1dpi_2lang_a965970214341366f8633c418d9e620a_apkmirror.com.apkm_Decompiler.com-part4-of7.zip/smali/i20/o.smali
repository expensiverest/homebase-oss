###### Class i20.o (i20.o)
.class public abstract Li20/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Li20/q;

.field public static final b:Li20/r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Li20/q;->w:Li20/q;

    .line 2
    .line 3
    sput-object v0, Li20/o;->a:Li20/q;

    .line 4
    .line 5
    sget-object v0, Li20/r;->i:Li20/r;

    .line 6
    .line 7
    sput-object v0, Li20/o;->b:Li20/r;

    .line 8
    .line 9
    return-void
.end method
