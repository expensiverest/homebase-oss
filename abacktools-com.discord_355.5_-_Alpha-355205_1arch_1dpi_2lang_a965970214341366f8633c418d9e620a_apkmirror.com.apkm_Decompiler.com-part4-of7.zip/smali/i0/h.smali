###### Class i0.h (i0.h)
.class public interface abstract Li0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getHeight()I
.end method

.method public abstract getWidth()I
.end method
