###### Class i0.f (i0.f)
.class public interface abstract Li0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()J
.end method
