###### Class i0.i (i0.i)
.class public interface abstract Li0/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li0/c;


# virtual methods
.method public f(IILkotlin/jvm/functions/Function1;)Li0/h;
    .registers 4

    .line 1
    invoke-interface {p0, p1, p2, p3}, Li0/i;->g(IILkotlin/jvm/functions/Function1;)Li0/h;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public abstract g(IILkotlin/jvm/functions/Function1;)Li0/h;
.end method
