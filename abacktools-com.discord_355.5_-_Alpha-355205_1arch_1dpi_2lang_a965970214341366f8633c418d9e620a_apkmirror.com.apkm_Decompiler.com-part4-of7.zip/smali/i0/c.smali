###### Class i0.c (i0.c)
.class public interface abstract Li0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getLayoutDirection()Ls0/c;
.end method
