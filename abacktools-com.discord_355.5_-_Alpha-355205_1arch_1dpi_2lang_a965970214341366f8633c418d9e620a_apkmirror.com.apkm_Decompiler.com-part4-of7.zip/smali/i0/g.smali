###### Class i0.g (i0.g)
.class public interface abstract Li0/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public maxIntrinsicHeight(Li0/c;Ljava/util/List;I)I
    .registers 12

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    move v3, v2

    .line 16
    :goto_f
    if-ge v3, v1, :cond_26

    .line 17
    .line 18
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Li0/a;

    .line 23
    .line 24
    new-instance v5, Li0/a;

    .line 25
    .line 26
    sget-object v6, Li0/d;->e:Li0/d;

    .line 27
    .line 28
    sget-object v7, Li0/e;->e:Li0/e;

    .line 29
    .line 30
    invoke-direct {v5, v4, v6, v7}, Li0/a;-><init>(Li0/a;Li0/d;Li0/e;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    add-int/lit8 v3, v3, 0x1

    .line 37
    .line 38
    goto :goto_f

    .line 39
    :cond_26
    const/16 p2, 0xd

    .line 40
    .line 41
    invoke-static {p3, v2, p2}, Ls0/a;->a(III)J

    .line 42
    .line 43
    .line 44
    move-result-wide p2

    .line 45
    new-instance v1, Landroidx/core/view/d0;

    .line 46
    .line 47
    invoke-interface {p1}, Li0/c;->getLayoutDirection()Ls0/c;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-direct {v1, p1, v2}, Landroidx/core/view/d0;-><init>(Li0/c;Ls0/c;)V

    .line 52
    .line 53
    .line 54
    invoke-interface {p0, v1, v0, p2, p3}, Li0/g;->measure-3p2s80s(Li0/i;Ljava/util/List;J)Li0/h;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-interface {p1}, Li0/h;->getHeight()I

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    return p1
.end method

.method public maxIntrinsicWidth(Li0/c;Ljava/util/List;I)I
    .registers 12

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    move v3, v2

    .line 16
    :goto_f
    if-ge v3, v1, :cond_26

    .line 17
    .line 18
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Li0/a;

    .line 23
    .line 24
    new-instance v5, Li0/a;

    .line 25
    .line 26
    sget-object v6, Li0/d;->e:Li0/d;

    .line 27
    .line 28
    sget-object v7, Li0/e;->d:Li0/e;

    .line 29
    .line 30
    invoke-direct {v5, v4, v6, v7}, Li0/a;-><init>(Li0/a;Li0/d;Li0/e;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    add-int/lit8 v3, v3, 0x1

    .line 37
    .line 38
    goto :goto_f

    .line 39
    :cond_26
    const/4 p2, 0x7

    .line 40
    invoke-static {v2, p3, p2}, Ls0/a;->a(III)J

    .line 41
    .line 42
    .line 43
    move-result-wide p2

    .line 44
    new-instance v1, Landroidx/core/view/d0;

    .line 45
    .line 46
    invoke-interface {p1}, Li0/c;->getLayoutDirection()Ls0/c;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-direct {v1, p1, v2}, Landroidx/core/view/d0;-><init>(Li0/c;Ls0/c;)V

    .line 51
    .line 52
    .line 53
    invoke-interface {p0, v1, v0, p2, p3}, Li0/g;->measure-3p2s80s(Li0/i;Ljava/util/List;J)Li0/h;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-interface {p1}, Li0/h;->getWidth()I

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    return p1
.end method

.method public abstract measure-3p2s80s(Li0/i;Ljava/util/List;J)Li0/h;
.end method

.method public minIntrinsicHeight(Li0/c;Ljava/util/List;I)I
    .registers 12

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    move v3, v2

    .line 16
    :goto_f
    if-ge v3, v1, :cond_26

    .line 17
    .line 18
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Li0/a;

    .line 23
    .line 24
    new-instance v5, Li0/a;

    .line 25
    .line 26
    sget-object v6, Li0/d;->d:Li0/d;

    .line 27
    .line 28
    sget-object v7, Li0/e;->e:Li0/e;

    .line 29
    .line 30
    invoke-direct {v5, v4, v6, v7}, Li0/a;-><init>(Li0/a;Li0/d;Li0/e;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    add-int/lit8 v3, v3, 0x1

    .line 37
    .line 38
    goto :goto_f

    .line 39
    :cond_26
    const/16 p2, 0xd

    .line 40
    .line 41
    invoke-static {p3, v2, p2}, Ls0/a;->a(III)J

    .line 42
    .line 43
    .line 44
    move-result-wide p2

    .line 45
    new-instance v1, Landroidx/core/view/d0;

    .line 46
    .line 47
    invoke-interface {p1}, Li0/c;->getLayoutDirection()Ls0/c;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-direct {v1, p1, v2}, Landroidx/core/view/d0;-><init>(Li0/c;Ls0/c;)V

    .line 52
    .line 53
    .line 54
    invoke-interface {p0, v1, v0, p2, p3}, Li0/g;->measure-3p2s80s(Li0/i;Ljava/util/List;J)Li0/h;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-interface {p1}, Li0/h;->getHeight()I

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    return p1
.end method

.method public minIntrinsicWidth(Li0/c;Ljava/util/List;I)I
    .registers 12

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    move v3, v2

    .line 16
    :goto_f
    if-ge v3, v1, :cond_26

    .line 17
    .line 18
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Li0/a;

    .line 23
    .line 24
    new-instance v5, Li0/a;

    .line 25
    .line 26
    sget-object v6, Li0/d;->d:Li0/d;

    .line 27
    .line 28
    sget-object v7, Li0/e;->d:Li0/e;

    .line 29
    .line 30
    invoke-direct {v5, v4, v6, v7}, Li0/a;-><init>(Li0/a;Li0/d;Li0/e;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    add-int/lit8 v3, v3, 0x1

    .line 37
    .line 38
    goto :goto_f

    .line 39
    :cond_26
    const/4 p2, 0x7

    .line 40
    invoke-static {v2, p3, p2}, Ls0/a;->a(III)J

    .line 41
    .line 42
    .line 43
    move-result-wide p2

    .line 44
    new-instance v1, Landroidx/core/view/d0;

    .line 45
    .line 46
    invoke-interface {p1}, Li0/c;->getLayoutDirection()Ls0/c;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-direct {v1, p1, v2}, Landroidx/core/view/d0;-><init>(Li0/c;Ls0/c;)V

    .line 51
    .line 52
    .line 53
    invoke-interface {p0, v1, v0, p2, p3}, Li0/g;->measure-3p2s80s(Li0/i;Ljava/util/List;J)Li0/h;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-interface {p1}, Li0/h;->getWidth()I

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    return p1
.end method
