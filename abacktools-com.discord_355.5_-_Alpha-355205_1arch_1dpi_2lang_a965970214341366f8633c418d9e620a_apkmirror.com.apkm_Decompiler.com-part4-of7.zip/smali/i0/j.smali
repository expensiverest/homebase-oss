###### Class i0.j (i0.j)
.class public abstract Li0/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Li0/k;II)V
.end method
