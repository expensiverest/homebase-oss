###### Class i0.a (i0.a)
.class public final Li0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Li0/a;

.field public final b:Li0/d;

.field public final c:Li0/e;


# direct methods
.method public constructor <init>(Li0/a;Li0/d;Li0/e;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li0/a;->a:Li0/a;

    .line 5
    .line 6
    iput-object p2, p0, Li0/a;->b:Li0/d;

    .line 7
    .line 8
    iput-object p3, p0, Li0/a;->c:Li0/e;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(I)I
    .registers 3

    .line 1
    iget-object v0, p0, Li0/a;->a:Li0/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Li0/a;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final b(I)I
    .registers 3

    .line 1
    iget-object v0, p0, Li0/a;->a:Li0/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Li0/a;->b(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final c(J)Li0/k;
    .registers 11

    .line 1
    iget-object v0, p0, Li0/a;->c:Li0/e;

    .line 2
    .line 3
    sget-object v1, Li0/e;->d:Li0/e;

    .line 4
    .line 5
    const/16 v2, 0x7fff

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    const-wide/16 v4, 0x3

    .line 9
    .line 10
    iget-object v6, p0, Li0/a;->b:Li0/d;

    .line 11
    .line 12
    iget-object v7, p0, Li0/a;->a:Li0/a;

    .line 13
    .line 14
    if-ne v0, v1, :cond_46

    .line 15
    .line 16
    sget-object v0, Li0/d;->e:Li0/d;

    .line 17
    .line 18
    if-ne v6, v0, :cond_1c

    .line 19
    .line 20
    invoke-static {p1, p2}, Lk80/l;->y(J)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-virtual {v7, v0}, Li0/a;->b(I)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    goto :goto_24

    .line 29
    :cond_1c
    invoke-static {p1, p2}, Lk80/l;->y(J)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-virtual {v7, v0}, Li0/a;->e(I)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    :goto_24
    and-long/2addr v4, p1

    .line 38
    long-to-int v1, v4

    .line 39
    and-int/lit8 v4, v1, 0x1

    .line 40
    .line 41
    shl-int/2addr v4, v3

    .line 42
    and-int/lit8 v1, v1, 0x2

    .line 43
    .line 44
    shr-int/2addr v1, v3

    .line 45
    mul-int/lit8 v1, v1, 0x3

    .line 46
    .line 47
    add-int/2addr v1, v4

    .line 48
    rsub-int/lit8 v4, v1, 0x12

    .line 49
    .line 50
    shl-int v4, v3, v4

    .line 51
    .line 52
    sub-int/2addr v4, v3

    .line 53
    add-int/lit8 v1, v1, 0x2e

    .line 54
    .line 55
    shr-long v5, p1, v1

    .line 56
    .line 57
    long-to-int v1, v5

    .line 58
    and-int/2addr v1, v4

    .line 59
    if-eqz v1, :cond_40

    .line 60
    .line 61
    invoke-static {p1, p2}, Lk80/l;->y(J)I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    :cond_40
    new-instance p1, Li0/b;

    .line 66
    .line 67
    invoke-direct {p1, v0, v2}, Li0/b;-><init>(II)V

    .line 68
    .line 69
    .line 70
    return-object p1

    .line 71
    :cond_46
    sget-object v0, Li0/d;->e:Li0/d;

    .line 72
    .line 73
    if-ne v6, v0, :cond_53

    .line 74
    .line 75
    invoke-static {p1, p2}, Lk80/l;->z(J)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    invoke-virtual {v7, v0}, Li0/a;->a(I)I

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    goto :goto_5b

    .line 84
    :cond_53
    invoke-static {p1, p2}, Lk80/l;->z(J)I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    invoke-virtual {v7, v0}, Li0/a;->d(I)I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    :goto_5b
    and-long/2addr v4, p1

    .line 93
    long-to-int v1, v4

    .line 94
    and-int/lit8 v4, v1, 0x1

    .line 95
    .line 96
    shl-int/2addr v4, v3

    .line 97
    and-int/lit8 v1, v1, 0x2

    .line 98
    .line 99
    shr-int/2addr v1, v3

    .line 100
    mul-int/lit8 v1, v1, 0x3

    .line 101
    .line 102
    add-int/2addr v1, v4

    .line 103
    add-int/lit8 v1, v1, 0xd

    .line 104
    .line 105
    shl-int v1, v3, v1

    .line 106
    .line 107
    sub-int/2addr v1, v3

    .line 108
    const/16 v3, 0x21

    .line 109
    .line 110
    shr-long v3, p1, v3

    .line 111
    .line 112
    long-to-int v3, v3

    .line 113
    and-int/2addr v1, v3

    .line 114
    if-eqz v1, :cond_77

    .line 115
    .line 116
    invoke-static {p1, p2}, Lk80/l;->z(J)I

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    :cond_77
    new-instance p1, Li0/b;

    .line 121
    .line 122
    invoke-direct {p1, v2, v0}, Li0/b;-><init>(II)V

    .line 123
    .line 124
    .line 125
    return-object p1
.end method

.method public final d(I)I
    .registers 3

    .line 1
    iget-object v0, p0, Li0/a;->a:Li0/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Li0/a;->d(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final e(I)I
    .registers 3

    .line 1
    iget-object v0, p0, Li0/a;->a:Li0/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Li0/a;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method
