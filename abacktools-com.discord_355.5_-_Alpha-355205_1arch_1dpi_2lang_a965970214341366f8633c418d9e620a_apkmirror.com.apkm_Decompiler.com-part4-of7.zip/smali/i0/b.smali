###### Class i0.b (i0.b)
.class public final Li0/b;
.super Li0/k;
.source "SourceFile"


# direct methods
.method public constructor <init>(II)V
    .registers 8

    .line 1
    invoke-direct {p0}, Li0/k;-><init>()V

    .line 2
    .line 3
    .line 4
    int-to-long v0, p1

    .line 5
    const/16 p1, 0x20

    .line 6
    .line 7
    shl-long/2addr v0, p1

    .line 8
    int-to-long p1, p2

    .line 9
    const-wide v2, 0xffffffffL

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    and-long/2addr p1, v2

    .line 15
    or-long/2addr p1, v0

    .line 16
    iget-wide v0, p0, Li0/k;->c:J

    .line 17
    .line 18
    cmp-long v0, v0, p1

    .line 19
    .line 20
    if-nez v0, :cond_16

    .line 21
    .line 22
    goto :goto_71

    .line 23
    :cond_16
    iput-wide p1, p0, Li0/k;->c:J

    .line 24
    .line 25
    iget-wide p1, p0, Li0/k;->c:J

    .line 26
    .line 27
    const/16 v0, 0x20

    .line 28
    .line 29
    shr-long/2addr p1, v0

    .line 30
    long-to-int p1, p1

    .line 31
    iget-wide v0, p0, Li0/k;->d:J

    .line 32
    .line 33
    const-wide/16 v2, 0x3

    .line 34
    .line 35
    and-long/2addr v2, v0

    .line 36
    long-to-int p2, v2

    .line 37
    and-int/lit8 v2, p2, 0x1

    .line 38
    .line 39
    const/4 v3, 0x1

    .line 40
    shl-int/2addr v2, v3

    .line 41
    const/4 v4, 0x2

    .line 42
    and-int/2addr p2, v4

    .line 43
    shr-int/2addr p2, v3

    .line 44
    mul-int/lit8 p2, p2, 0x3

    .line 45
    .line 46
    add-int/2addr p2, v2

    .line 47
    add-int/lit8 p2, p2, 0xd

    .line 48
    .line 49
    shl-int p2, v3, p2

    .line 50
    .line 51
    sub-int/2addr p2, v3

    .line 52
    shr-long/2addr v0, v4

    .line 53
    long-to-int v0, v0

    .line 54
    and-int/2addr p2, v0

    .line 55
    iget-wide v0, p0, Li0/k;->d:J

    .line 56
    .line 57
    invoke-static {v0, v1}, Lk80/l;->z(J)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    invoke-static {p1, p2, v0}, Lsg/a;->n(III)I

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    iput p1, p0, Li0/k;->a:I

    .line 66
    .line 67
    iget-wide p1, p0, Li0/k;->c:J

    .line 68
    .line 69
    const-wide v0, 0xffffffffL

    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    and-long/2addr p1, v0

    .line 75
    long-to-int p1, p1

    .line 76
    iget-wide v0, p0, Li0/k;->d:J

    .line 77
    .line 78
    const-wide/16 v2, 0x3

    .line 79
    .line 80
    and-long/2addr v2, v0

    .line 81
    long-to-int p2, v2

    .line 82
    and-int/lit8 v2, p2, 0x1

    .line 83
    .line 84
    const/4 v3, 0x1

    .line 85
    shl-int/2addr v2, v3

    .line 86
    and-int/lit8 p2, p2, 0x2

    .line 87
    .line 88
    shr-int/2addr p2, v3

    .line 89
    mul-int/lit8 p2, p2, 0x3

    .line 90
    .line 91
    add-int/2addr p2, v2

    .line 92
    rsub-int/lit8 v2, p2, 0x12

    .line 93
    .line 94
    shl-int v2, v3, v2

    .line 95
    .line 96
    sub-int/2addr v2, v3

    .line 97
    add-int/lit8 p2, p2, 0xf

    .line 98
    .line 99
    shr-long/2addr v0, p2

    .line 100
    long-to-int p2, v0

    .line 101
    and-int/2addr p2, v2

    .line 102
    iget-wide v0, p0, Li0/k;->d:J

    .line 103
    .line 104
    invoke-static {v0, v1}, Lk80/l;->y(J)I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    invoke-static {p1, p2, v0}, Lsg/a;->n(III)I

    .line 109
    .line 110
    .line 111
    move-result p1

    .line 112
    iput p1, p0, Li0/k;->b:I

    .line 113
    .line 114
    :goto_71
    return-void
.end method
