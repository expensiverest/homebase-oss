###### Class ia.b (ia.b)
.class public final synthetic Lia/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lia/b;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lia/b;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lia/b;->a:Lia/b;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.bridge.gift.GiftEmbed.Resolved.Invalid"

    .line 11
    .line 12
    const/16 v3, 0xa

    .line 13
    .line 14
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 15
    .line 16
    .line 17
    const-string v0, "headerText"

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 21
    .line 22
    .line 23
    const-string v0, "headerColor"

    .line 24
    .line 25
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 26
    .line 27
    .line 28
    const-string v0, "backgroundColor"

    .line 29
    .line 30
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    const-string v0, "thumbnailCornerRadius"

    .line 34
    .line 35
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    const-string v0, "thumbnailUrl"

    .line 39
    .line 40
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v0, "titleText"

    .line 44
    .line 45
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    const-string v0, "titleColor"

    .line 49
    .line 50
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 51
    .line 52
    .line 53
    const-string v0, "subtitle"

    .line 54
    .line 55
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 56
    .line 57
    .line 58
    const-string v0, "subtitleColor"

    .line 59
    .line 60
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 61
    .line 62
    .line 63
    const-string v0, "thumbnailBackgroundColor"

    .line 64
    .line 65
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 66
    .line 67
    .line 68
    sput-object v1, Lia/b;->descriptor:Ll70/g;

    .line 69
    .line 70
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 37

    .line 1
    sget-object v0, Lia/b;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/16 v3, 0x9

    .line 14
    .line 15
    const/4 v4, 0x7

    .line 16
    const/4 v5, 0x6

    .line 17
    const/4 v6, 0x5

    .line 18
    const/4 v7, 0x3

    .line 19
    const/16 v8, 0x8

    .line 20
    .line 21
    const/4 v9, 0x4

    .line 22
    const/4 v10, 0x2

    .line 23
    const/4 v11, 0x1

    .line 24
    const/4 v12, 0x0

    .line 25
    if-eqz v2, :cond_5c

    .line 26
    .line 27
    invoke-interface {v1, v0, v12}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-interface {v1, v0, v11}, Lm70/a;->p(Ll70/g;I)I

    .line 32
    .line 33
    .line 34
    move-result v11

    .line 35
    invoke-interface {v1, v0, v10}, Lm70/a;->p(Ll70/g;I)I

    .line 36
    .line 37
    .line 38
    move-result v10

    .line 39
    invoke-interface {v1, v0, v7}, Lm70/a;->p(Ll70/g;I)I

    .line 40
    .line 41
    .line 42
    move-result v7

    .line 43
    invoke-interface {v1, v0, v9}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v9

    .line 47
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 52
    .line 53
    .line 54
    move-result v5

    .line 55
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    invoke-interface {v1, v0, v8}, Lm70/a;->p(Ll70/g;I)I

    .line 60
    .line 61
    .line 62
    move-result v8

    .line 63
    invoke-interface {v1, v0, v3}, Lm70/a;->p(Ll70/g;I)I

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    const/16 v12, 0x3ff

    .line 68
    .line 69
    move/from16 v34, v3

    .line 70
    .line 71
    move-object/from16 v32, v4

    .line 72
    .line 73
    move/from16 v31, v5

    .line 74
    .line 75
    move-object/from16 v30, v6

    .line 76
    .line 77
    move/from16 v28, v7

    .line 78
    .line 79
    move/from16 v33, v8

    .line 80
    .line 81
    move-object/from16 v29, v9

    .line 82
    .line 83
    move/from16 v27, v10

    .line 84
    .line 85
    move/from16 v26, v11

    .line 86
    .line 87
    :goto_56
    move-object/from16 v25, v2

    .line 88
    .line 89
    move/from16 v24, v12

    .line 90
    .line 91
    goto/16 :goto_e0

    .line 92
    .line 93
    :cond_5c
    const/4 v2, 0x0

    .line 94
    move-object v14, v2

    .line 95
    move-object/from16 v16, v14

    .line 96
    .line 97
    move-object/from16 v19, v16

    .line 98
    .line 99
    move/from16 v22, v11

    .line 100
    .line 101
    move v13, v12

    .line 102
    move v15, v13

    .line 103
    move/from16 v17, v15

    .line 104
    .line 105
    move/from16 v18, v17

    .line 106
    .line 107
    move/from16 v20, v18

    .line 108
    .line 109
    move/from16 v21, v20

    .line 110
    .line 111
    :goto_6e
    if-eqz v22, :cond_cc

    .line 112
    .line 113
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 114
    .line 115
    .line 116
    move-result v11

    .line 117
    packed-switch v11, :pswitch_data_ea

    .line 118
    .line 119
    .line 120
    new-instance v0, Lj70/k;

    .line 121
    .line 122
    invoke-direct {v0, v11}, Lj70/k;-><init>(I)V

    .line 123
    .line 124
    .line 125
    throw v0

    .line 126
    :pswitch_7d
    invoke-interface {v1, v0, v3}, Lm70/a;->p(Ll70/g;I)I

    .line 127
    .line 128
    .line 129
    move-result v13

    .line 130
    or-int/lit16 v12, v12, 0x200

    .line 131
    .line 132
    :goto_83
    const/4 v11, 0x1

    .line 133
    goto :goto_6e

    .line 134
    :pswitch_85
    invoke-interface {v1, v0, v8}, Lm70/a;->p(Ll70/g;I)I

    .line 135
    .line 136
    .line 137
    move-result v18

    .line 138
    or-int/lit16 v12, v12, 0x100

    .line 139
    .line 140
    goto :goto_83

    .line 141
    :pswitch_8c
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v14

    .line 145
    or-int/lit16 v12, v12, 0x80

    .line 146
    .line 147
    goto :goto_83

    .line 148
    :pswitch_93
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 149
    .line 150
    .line 151
    move-result v15

    .line 152
    or-int/lit8 v12, v12, 0x40

    .line 153
    .line 154
    goto :goto_83

    .line 155
    :pswitch_9a
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v16

    .line 159
    or-int/lit8 v12, v12, 0x20

    .line 160
    .line 161
    goto :goto_83

    .line 162
    :pswitch_a1
    invoke-interface {v1, v0, v9}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v19

    .line 166
    or-int/lit8 v12, v12, 0x10

    .line 167
    .line 168
    goto :goto_83

    .line 169
    :pswitch_a8
    invoke-interface {v1, v0, v7}, Lm70/a;->p(Ll70/g;I)I

    .line 170
    .line 171
    .line 172
    move-result v17

    .line 173
    or-int/lit8 v12, v12, 0x8

    .line 174
    .line 175
    goto :goto_83

    .line 176
    :pswitch_af
    invoke-interface {v1, v0, v10}, Lm70/a;->p(Ll70/g;I)I

    .line 177
    .line 178
    .line 179
    move-result v20

    .line 180
    or-int/lit8 v12, v12, 0x4

    .line 181
    .line 182
    goto :goto_83

    .line 183
    :pswitch_b6
    const/4 v11, 0x1

    .line 184
    invoke-interface {v1, v0, v11}, Lm70/a;->p(Ll70/g;I)I

    .line 185
    .line 186
    .line 187
    move-result v21

    .line 188
    or-int/lit8 v12, v12, 0x2

    .line 189
    .line 190
    goto :goto_6e

    .line 191
    :pswitch_be
    const/4 v2, 0x0

    .line 192
    const/4 v11, 0x1

    .line 193
    invoke-interface {v1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v23

    .line 197
    or-int/lit8 v12, v12, 0x1

    .line 198
    .line 199
    move-object/from16 v2, v23

    .line 200
    .line 201
    goto :goto_6e

    .line 202
    :pswitch_c9
    const/16 v22, 0x0

    .line 203
    .line 204
    goto :goto_83

    .line 205
    :cond_cc
    move/from16 v34, v13

    .line 206
    .line 207
    move-object/from16 v32, v14

    .line 208
    .line 209
    move/from16 v31, v15

    .line 210
    .line 211
    move-object/from16 v30, v16

    .line 212
    .line 213
    move/from16 v28, v17

    .line 214
    .line 215
    move/from16 v33, v18

    .line 216
    .line 217
    move-object/from16 v29, v19

    .line 218
    .line 219
    move/from16 v27, v20

    .line 220
    .line 221
    move/from16 v26, v21

    .line 222
    .line 223
    goto/16 :goto_56

    .line 224
    .line 225
    :goto_e0
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 226
    .line 227
    .line 228
    new-instance v23, Lia/d;

    .line 229
    .line 230
    invoke-direct/range {v23 .. v34}, Lia/d;-><init>(ILjava/lang/String;IIILjava/lang/String;Ljava/lang/String;ILjava/lang/String;II)V

    .line 231
    .line 232
    .line 233
    return-object v23

    .line 234
    nop

    .line 235
    :pswitch_data_ea
    .packed-switch -0x1
        :pswitch_c9
        :pswitch_be
        :pswitch_b6
        :pswitch_af
        :pswitch_a8
        :pswitch_a1
        :pswitch_9a
        :pswitch_93
        :pswitch_8c
        :pswitch_85
        :pswitch_7d
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 5

    .line 1
    const/16 v0, 0xa

    .line 2
    .line 3
    new-array v0, v0, [Lj70/b;

    .line 4
    .line 5
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    aput-object v1, v0, v2

    .line 9
    .line 10
    sget-object v2, Ln70/e0;->a:Ln70/e0;

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    aput-object v2, v0, v3

    .line 14
    .line 15
    const/4 v3, 0x2

    .line 16
    aput-object v2, v0, v3

    .line 17
    .line 18
    const/4 v3, 0x3

    .line 19
    aput-object v2, v0, v3

    .line 20
    .line 21
    const/4 v3, 0x4

    .line 22
    aput-object v1, v0, v3

    .line 23
    .line 24
    const/4 v3, 0x5

    .line 25
    aput-object v1, v0, v3

    .line 26
    .line 27
    const/4 v3, 0x6

    .line 28
    aput-object v2, v0, v3

    .line 29
    .line 30
    const/4 v3, 0x7

    .line 31
    aput-object v1, v0, v3

    .line 32
    .line 33
    const/16 v1, 0x8

    .line 34
    .line 35
    aput-object v2, v0, v1

    .line 36
    .line 37
    const/16 v1, 0x9

    .line 38
    .line 39
    aput-object v2, v0, v1

    .line 40
    .line 41
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lia/d;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lia/b;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lia/d;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget v2, p2, Lia/d;->b:I

    .line 22
    .line 23
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget v2, p2, Lia/d;->c:I

    .line 28
    .line 29
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    iget v2, p2, Lia/d;->d:I

    .line 34
    .line 35
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 36
    .line 37
    .line 38
    const/4 v1, 0x4

    .line 39
    iget-object v2, p2, Lia/d;->e:Ljava/lang/String;

    .line 40
    .line 41
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 42
    .line 43
    .line 44
    const/4 v1, 0x5

    .line 45
    iget-object v2, p2, Lia/d;->f:Ljava/lang/String;

    .line 46
    .line 47
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const/4 v1, 0x6

    .line 51
    iget v2, p2, Lia/d;->g:I

    .line 52
    .line 53
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 54
    .line 55
    .line 56
    const/4 v1, 0x7

    .line 57
    iget-object v2, p2, Lia/d;->h:Ljava/lang/String;

    .line 58
    .line 59
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 60
    .line 61
    .line 62
    const/16 v1, 0x8

    .line 63
    .line 64
    iget v2, p2, Lia/d;->i:I

    .line 65
    .line 66
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 67
    .line 68
    .line 69
    const/16 v1, 0x9

    .line 70
    .line 71
    iget p2, p2, Lia/d;->j:I

    .line 72
    .line 73
    invoke-interface {p1, v1, p2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 74
    .line 75
    .line 76
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lia/b;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
