###### Class ia.l (ia.l)
.class public interface abstract Lia/l;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lj70/h;
    with = Lia/m;
.end annotation


# static fields
.field public static final Companion:Lia/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lia/a;->a:Lia/a;

    .line 2
    .line 3
    sput-object v0, Lia/l;->Companion:Lia/a;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()Ljava/lang/String;
.end method

.method public abstract c()I
.end method

.method public abstract e()I
.end method
