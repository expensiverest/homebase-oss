###### Class ia.k (ia.k)
.class public final Lia/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lia/l;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lia/j;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lia/j;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lia/k;->Companion:Lia/j;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;IIIII)V
    .registers 10

    .line 1
    and-int/lit8 v0, p1, 0x3f

    .line 2
    .line 3
    const/16 v1, 0x3f

    .line 4
    .line 5
    if-ne v1, v0, :cond_16

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p2, p0, Lia/k;->a:Ljava/lang/String;

    .line 11
    .line 12
    iput p3, p0, Lia/k;->b:I

    .line 13
    .line 14
    iput p4, p0, Lia/k;->c:I

    .line 15
    .line 16
    iput p5, p0, Lia/k;->d:I

    .line 17
    .line 18
    iput p6, p0, Lia/k;->e:I

    .line 19
    .line 20
    iput p7, p0, Lia/k;->f:I

    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    sget-object p2, Lia/i;->a:Lia/i;

    .line 24
    .line 25
    invoke-virtual {p2}, Lia/i;->d()Ll70/g;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    invoke-static {p1, v1, p2}, Ln70/t0;->j(IILl70/g;)V

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    throw p1
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, Lia/k;->c:I

    .line 2
    .line 3
    return v0
.end method

.method public final b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/k;->a:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c()I
    .registers 2

    .line 1
    iget v0, p0, Lia/k;->b:I

    .line 2
    .line 3
    return v0
.end method

.method public final e()I
    .registers 2

    .line 1
    iget v0, p0, Lia/k;->d:I

    .line 2
    .line 3
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lia/k;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lia/k;

    .line 12
    .line 13
    iget-object v1, p0, Lia/k;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lia/k;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    iget v1, p0, Lia/k;->b:I

    .line 25
    .line 26
    iget v3, p1, Lia/k;->b:I

    .line 27
    .line 28
    if-eq v1, v3, :cond_1e

    .line 29
    .line 30
    return v2

    .line 31
    :cond_1e
    iget v1, p0, Lia/k;->c:I

    .line 32
    .line 33
    iget v3, p1, Lia/k;->c:I

    .line 34
    .line 35
    if-eq v1, v3, :cond_25

    .line 36
    .line 37
    return v2

    .line 38
    :cond_25
    iget v1, p0, Lia/k;->d:I

    .line 39
    .line 40
    iget v3, p1, Lia/k;->d:I

    .line 41
    .line 42
    if-eq v1, v3, :cond_2c

    .line 43
    .line 44
    return v2

    .line 45
    :cond_2c
    iget v1, p0, Lia/k;->e:I

    .line 46
    .line 47
    iget v3, p1, Lia/k;->e:I

    .line 48
    .line 49
    if-eq v1, v3, :cond_33

    .line 50
    .line 51
    return v2

    .line 52
    :cond_33
    iget v1, p0, Lia/k;->f:I

    .line 53
    .line 54
    iget p1, p1, Lia/k;->f:I

    .line 55
    .line 56
    if-eq v1, p1, :cond_3a

    .line 57
    .line 58
    return v2

    .line 59
    :cond_3a
    return v0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lia/k;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lia/k;->b:I

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget v2, p0, Lia/k;->c:I

    .line 17
    .line 18
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget v2, p0, Lia/k;->d:I

    .line 23
    .line 24
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget v2, p0, Lia/k;->e:I

    .line 29
    .line 30
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget v1, p0, Lia/k;->f:I

    .line 35
    .line 36
    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    add-int/2addr v1, v0

    .line 41
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    const-string v0, ", headerColor="

    .line 2
    .line 3
    const-string v1, ", backgroundColor="

    .line 4
    .line 5
    iget v2, p0, Lia/k;->b:I

    .line 6
    .line 7
    const-string v3, "Resolving(headerText="

    .line 8
    .line 9
    iget-object v4, p0, Lia/k;->a:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v2, v3, v4, v0, v1}, La1/h;->n(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, ", thumbnailCornerRadius="

    .line 16
    .line 17
    const-string v2, ", resolvingGradientStart="

    .line 18
    .line 19
    iget v3, p0, Lia/k;->c:I

    .line 20
    .line 21
    iget v4, p0, Lia/k;->d:I

    .line 22
    .line 23
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget v1, p0, Lia/k;->e:I

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, ", resolvingGradientEnd="

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget v1, p0, Lia/k;->f:I

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    const-string v1, ")"

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    return-object v0
.end method
