###### Class ia.m (ia.m)
.class public final Lia/m;
.super Ln70/f0;
.source "SourceFile"


# static fields
.field public static final d:Lia/m;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lia/m;

    .line 2
    .line 3
    const-class v1, Lia/l;

    .line 4
    .line 5
    sget-object v2, Lkotlin/jvm/internal/v;->a:Lkotlin/jvm/internal/w;

    .line 6
    .line 7
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/w;->b(Ljava/lang/Class;)Lh40/d;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Ln70/f0;-><init>(Lh40/d;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lia/m;->d:Lia/m;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final g(Lkotlinx/serialization/json/b;)Lj70/b;
    .registers 6

    .line 1
    const-string v0, "element"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Lo70/j;->i(Lkotlinx/serialization/json/b;)Lkotlinx/serialization/json/c;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const-string v0, "resolvingGradientStart"

    .line 11
    .line 12
    const-string v1, "resolvingGradientEnd"

    .line 13
    .line 14
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const/4 v1, 0x0

    .line 19
    :goto_12
    const/4 v2, 0x2

    .line 20
    if-ge v1, v2, :cond_61

    .line 21
    .line 22
    aget-object v2, v0, v1

    .line 23
    .line 24
    invoke-virtual {p1, v2}, Lkotlinx/serialization/json/c;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Lkotlinx/serialization/json/b;

    .line 29
    .line 30
    const/4 v3, 0x1

    .line 31
    if-eqz v2, :cond_34

    .line 32
    .line 33
    invoke-static {v2}, Lo70/j;->j(Lkotlinx/serialization/json/b;)Lkotlinx/serialization/json/d;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    invoke-virtual {v2}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    if-eqz v2, :cond_34

    .line 42
    .line 43
    invoke-static {v2}, Lw60/o;->y0(Ljava/lang/CharSequence;)Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    xor-int/2addr v2, v3

    .line 48
    if-ne v2, v3, :cond_34

    .line 49
    .line 50
    add-int/lit8 v1, v1, 0x1

    .line 51
    .line 52
    goto :goto_12

    .line 53
    :cond_34
    const-string v0, "giftCode"

    .line 54
    .line 55
    invoke-virtual {p1, v0}, Lkotlinx/serialization/json/c;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    check-cast p1, Lkotlinx/serialization/json/b;

    .line 60
    .line 61
    if-eqz p1, :cond_58

    .line 62
    .line 63
    invoke-static {p1}, Lo70/j;->j(Lkotlinx/serialization/json/b;)Lkotlinx/serialization/json/d;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    invoke-virtual {p1}, Lkotlinx/serialization/json/d;->a()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-eqz p1, :cond_58

    .line 72
    .line 73
    invoke-static {p1}, Lw60/o;->y0(Ljava/lang/CharSequence;)Z

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    xor-int/2addr p1, v3

    .line 78
    if-ne p1, v3, :cond_58

    .line 79
    .line 80
    sget-object p1, Lia/g;->Companion:Lia/f;

    .line 81
    .line 82
    invoke-virtual {p1}, Lia/f;->serializer()Lj70/b;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    check-cast p1, Lj70/b;

    .line 87
    .line 88
    return-object p1

    .line 89
    :cond_58
    sget-object p1, Lia/d;->Companion:Lia/c;

    .line 90
    .line 91
    invoke-virtual {p1}, Lia/c;->serializer()Lj70/b;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, Lj70/b;

    .line 96
    .line 97
    return-object p1

    .line 98
    :cond_61
    sget-object p1, Lia/k;->Companion:Lia/j;

    .line 99
    .line 100
    invoke-virtual {p1}, Lia/j;->serializer()Lj70/b;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    check-cast p1, Lj70/b;

    .line 105
    .line 106
    return-object p1
.end method
