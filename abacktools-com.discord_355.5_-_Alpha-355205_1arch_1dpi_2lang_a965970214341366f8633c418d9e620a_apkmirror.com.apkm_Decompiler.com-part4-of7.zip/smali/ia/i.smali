###### Class ia.i (ia.i)
.class public final synthetic Lia/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lia/i;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lia/i;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lia/i;->a:Lia/i;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.bridge.gift.GiftEmbed.Resolving"

    .line 11
    .line 12
    const/4 v3, 0x6

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "headerText"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "headerColor"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "backgroundColor"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "thumbnailCornerRadius"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "resolvingGradientStart"

    .line 38
    .line 39
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "resolvingGradientEnd"

    .line 43
    .line 44
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    sput-object v1, Lia/i;->descriptor:Ll70/g;

    .line 48
    .line 49
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 26

    .line 1
    sget-object v0, Lia/i;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v5, 0x4

    .line 16
    const/4 v6, 0x2

    .line 17
    const/4 v7, 0x1

    .line 18
    const/4 v8, 0x0

    .line 19
    if-eqz v2, :cond_3d

    .line 20
    .line 21
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-interface {v1, v0, v7}, Lm70/a;->p(Ll70/g;I)I

    .line 26
    .line 27
    .line 28
    move-result v7

    .line 29
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 30
    .line 31
    .line 32
    move-result v6

    .line 33
    invoke-interface {v1, v0, v4}, Lm70/a;->p(Ll70/g;I)I

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 38
    .line 39
    .line 40
    move-result v5

    .line 41
    invoke-interface {v1, v0, v3}, Lm70/a;->p(Ll70/g;I)I

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    const/16 v8, 0x3f

    .line 46
    .line 47
    move/from16 v23, v3

    .line 48
    .line 49
    move/from16 v21, v4

    .line 50
    .line 51
    move/from16 v22, v5

    .line 52
    .line 53
    move/from16 v20, v6

    .line 54
    .line 55
    move/from16 v19, v7

    .line 56
    .line 57
    move/from16 v17, v8

    .line 58
    .line 59
    :goto_3a
    move-object/from16 v18, v2

    .line 60
    .line 61
    goto :goto_90

    .line 62
    :cond_3d
    const/4 v2, 0x0

    .line 63
    move v15, v7

    .line 64
    move v9, v8

    .line 65
    move v10, v9

    .line 66
    move v11, v10

    .line 67
    move v12, v11

    .line 68
    move v13, v12

    .line 69
    move v14, v13

    .line 70
    :goto_45
    if-eqz v15, :cond_83

    .line 71
    .line 72
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 73
    .line 74
    .line 75
    move-result v8

    .line 76
    packed-switch v8, :pswitch_data_9a

    .line 77
    .line 78
    .line 79
    new-instance v0, Lj70/k;

    .line 80
    .line 81
    invoke-direct {v0, v8}, Lj70/k;-><init>(I)V

    .line 82
    .line 83
    .line 84
    throw v0

    .line 85
    :pswitch_54
    invoke-interface {v1, v0, v3}, Lm70/a;->p(Ll70/g;I)I

    .line 86
    .line 87
    .line 88
    move-result v9

    .line 89
    or-int/lit8 v14, v14, 0x20

    .line 90
    .line 91
    :goto_5a
    const/4 v8, 0x0

    .line 92
    goto :goto_45

    .line 93
    :pswitch_5c
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 94
    .line 95
    .line 96
    move-result v11

    .line 97
    or-int/lit8 v14, v14, 0x10

    .line 98
    .line 99
    goto :goto_5a

    .line 100
    :pswitch_63
    invoke-interface {v1, v0, v4}, Lm70/a;->p(Ll70/g;I)I

    .line 101
    .line 102
    .line 103
    move-result v10

    .line 104
    or-int/lit8 v14, v14, 0x8

    .line 105
    .line 106
    goto :goto_5a

    .line 107
    :pswitch_6a
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 108
    .line 109
    .line 110
    move-result v12

    .line 111
    or-int/lit8 v14, v14, 0x4

    .line 112
    .line 113
    goto :goto_5a

    .line 114
    :pswitch_71
    invoke-interface {v1, v0, v7}, Lm70/a;->p(Ll70/g;I)I

    .line 115
    .line 116
    .line 117
    move-result v13

    .line 118
    or-int/lit8 v14, v14, 0x2

    .line 119
    .line 120
    goto :goto_5a

    .line 121
    :pswitch_78
    const/4 v8, 0x0

    .line 122
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    or-int/lit8 v14, v14, 0x1

    .line 127
    .line 128
    goto :goto_45

    .line 129
    :pswitch_80
    const/4 v8, 0x0

    .line 130
    move v15, v8

    .line 131
    goto :goto_45

    .line 132
    :cond_83
    move/from16 v23, v9

    .line 133
    .line 134
    move/from16 v21, v10

    .line 135
    .line 136
    move/from16 v22, v11

    .line 137
    .line 138
    move/from16 v20, v12

    .line 139
    .line 140
    move/from16 v19, v13

    .line 141
    .line 142
    move/from16 v17, v14

    .line 143
    .line 144
    goto :goto_3a

    .line 145
    :goto_90
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 146
    .line 147
    .line 148
    new-instance v16, Lia/k;

    .line 149
    .line 150
    invoke-direct/range {v16 .. v23}, Lia/k;-><init>(ILjava/lang/String;IIIII)V

    .line 151
    .line 152
    .line 153
    return-object v16

    .line 154
    nop

    .line 155
    :pswitch_data_9a
    .packed-switch -0x1
        :pswitch_80
        :pswitch_78
        :pswitch_71
        :pswitch_6a
        :pswitch_63
        :pswitch_5c
        :pswitch_54
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x6

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    aput-object v1, v0, v2

    .line 16
    .line 17
    const/4 v2, 0x3

    .line 18
    aput-object v1, v0, v2

    .line 19
    .line 20
    const/4 v2, 0x4

    .line 21
    aput-object v1, v0, v2

    .line 22
    .line 23
    const/4 v2, 0x5

    .line 24
    aput-object v1, v0, v2

    .line 25
    .line 26
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lia/k;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lia/i;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lia/k;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget v2, p2, Lia/k;->b:I

    .line 22
    .line 23
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget v2, p2, Lia/k;->c:I

    .line 28
    .line 29
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    iget v2, p2, Lia/k;->d:I

    .line 34
    .line 35
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 36
    .line 37
    .line 38
    const/4 v1, 0x4

    .line 39
    iget v2, p2, Lia/k;->e:I

    .line 40
    .line 41
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 42
    .line 43
    .line 44
    const/4 v1, 0x5

    .line 45
    iget p2, p2, Lia/k;->f:I

    .line 46
    .line 47
    invoke-interface {p1, v1, p2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lia/i;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
