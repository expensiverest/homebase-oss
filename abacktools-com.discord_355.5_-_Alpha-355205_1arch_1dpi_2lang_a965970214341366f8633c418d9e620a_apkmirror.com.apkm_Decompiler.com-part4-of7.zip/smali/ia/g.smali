###### Class ia.g (ia.g)
.class public final Lia/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lia/h;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lia/f;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;

.field public final g:I

.field public final h:Ljava/lang/String;

.field public final i:I

.field public final j:Ljava/lang/String;

.field public final k:I

.field public final l:Ljava/lang/String;

.field public final m:I

.field public final n:I

.field public final o:Ljava/lang/String;

.field public final p:F

.field public final q:Z

.field public final r:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lia/f;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lia/g;->Companion:Lia/f;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;IIILjava/lang/String;Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;ILjava/lang/String;IILjava/lang/String;FZLjava/lang/String;)V
    .registers 23

    .line 1
    const v0, 0x3b54f

    .line 2
    .line 3
    .line 4
    and-int v1, p1, v0

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    if-ne v0, v1, :cond_6a

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object p2, p0, Lia/g;->a:Ljava/lang/String;

    .line 13
    .line 14
    iput p3, p0, Lia/g;->b:I

    .line 15
    .line 16
    iput p4, p0, Lia/g;->c:I

    .line 17
    .line 18
    iput p5, p0, Lia/g;->d:I

    .line 19
    .line 20
    and-int/lit8 p2, p1, 0x10

    .line 21
    .line 22
    if-nez p2, :cond_1a

    .line 23
    .line 24
    iput-object v2, p0, Lia/g;->e:Ljava/lang/String;

    .line 25
    .line 26
    goto :goto_1c

    .line 27
    :cond_1a
    iput-object p6, p0, Lia/g;->e:Ljava/lang/String;

    .line 28
    .line 29
    :goto_1c
    and-int/lit8 p2, p1, 0x20

    .line 30
    .line 31
    if-nez p2, :cond_23

    .line 32
    .line 33
    iput-object v2, p0, Lia/g;->f:Ljava/lang/String;

    .line 34
    .line 35
    goto :goto_25

    .line 36
    :cond_23
    iput-object p7, p0, Lia/g;->f:Ljava/lang/String;

    .line 37
    .line 38
    :goto_25
    iput p8, p0, Lia/g;->g:I

    .line 39
    .line 40
    and-int/lit16 p2, p1, 0x80

    .line 41
    .line 42
    if-nez p2, :cond_2e

    .line 43
    .line 44
    iput-object v2, p0, Lia/g;->h:Ljava/lang/String;

    .line 45
    .line 46
    goto :goto_30

    .line 47
    :cond_2e
    iput-object p9, p0, Lia/g;->h:Ljava/lang/String;

    .line 48
    .line 49
    :goto_30
    iput p10, p0, Lia/g;->i:I

    .line 50
    .line 51
    and-int/lit16 p2, p1, 0x200

    .line 52
    .line 53
    if-nez p2, :cond_39

    .line 54
    .line 55
    iput-object v2, p0, Lia/g;->j:Ljava/lang/String;

    .line 56
    .line 57
    goto :goto_3b

    .line 58
    :cond_39
    iput-object p11, p0, Lia/g;->j:Ljava/lang/String;

    .line 59
    .line 60
    :goto_3b
    iput p12, p0, Lia/g;->k:I

    .line 61
    .line 62
    and-int/lit16 p2, p1, 0x800

    .line 63
    .line 64
    if-nez p2, :cond_46

    .line 65
    .line 66
    iput-object v2, p0, Lia/g;->l:Ljava/lang/String;

    .line 67
    .line 68
    :goto_43
    move/from16 p2, p14

    .line 69
    .line 70
    goto :goto_4b

    .line 71
    :cond_46
    move-object/from16 p2, p13

    .line 72
    .line 73
    iput-object p2, p0, Lia/g;->l:Ljava/lang/String;

    .line 74
    .line 75
    goto :goto_43

    .line 76
    :goto_4b
    iput p2, p0, Lia/g;->m:I

    .line 77
    .line 78
    move/from16 p2, p15

    .line 79
    .line 80
    iput p2, p0, Lia/g;->n:I

    .line 81
    .line 82
    and-int/lit16 p1, p1, 0x4000

    .line 83
    .line 84
    if-nez p1, :cond_5a

    .line 85
    .line 86
    iput-object v2, p0, Lia/g;->o:Ljava/lang/String;

    .line 87
    .line 88
    :goto_57
    move/from16 p1, p17

    .line 89
    .line 90
    goto :goto_5f

    .line 91
    :cond_5a
    move-object/from16 p1, p16

    .line 92
    .line 93
    iput-object p1, p0, Lia/g;->o:Ljava/lang/String;

    .line 94
    .line 95
    goto :goto_57

    .line 96
    :goto_5f
    iput p1, p0, Lia/g;->p:F

    .line 97
    .line 98
    move/from16 p1, p18

    .line 99
    .line 100
    iput-boolean p1, p0, Lia/g;->q:Z

    .line 101
    .line 102
    move-object/from16 p1, p19

    .line 103
    .line 104
    iput-object p1, p0, Lia/g;->r:Ljava/lang/String;

    .line 105
    .line 106
    return-void

    .line 107
    :cond_6a
    sget-object p2, Lia/e;->a:Lia/e;

    .line 108
    .line 109
    invoke-virtual {p2}, Lia/e;->d()Ll70/g;

    .line 110
    .line 111
    .line 112
    move-result-object p2

    .line 113
    invoke-static {p1, v0, p2}, Ln70/t0;->j(IILl70/g;)V

    .line 114
    .line 115
    .line 116
    throw v2
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, Lia/g;->c:I

    .line 2
    .line 3
    return v0
.end method

.method public final b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/g;->a:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c()I
    .registers 2

    .line 1
    iget v0, p0, Lia/g;->b:I

    .line 2
    .line 3
    return v0
.end method

.method public final d()I
    .registers 2

    .line 1
    iget v0, p0, Lia/g;->g:I

    .line 2
    .line 3
    return v0
.end method

.method public final e()I
    .registers 2

    .line 1
    iget v0, p0, Lia/g;->d:I

    .line 2
    .line 3
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lia/g;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lia/g;

    .line 12
    .line 13
    iget-object v1, p0, Lia/g;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lia/g;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    iget v1, p0, Lia/g;->b:I

    .line 25
    .line 26
    iget v3, p1, Lia/g;->b:I

    .line 27
    .line 28
    if-eq v1, v3, :cond_1e

    .line 29
    .line 30
    return v2

    .line 31
    :cond_1e
    iget v1, p0, Lia/g;->c:I

    .line 32
    .line 33
    iget v3, p1, Lia/g;->c:I

    .line 34
    .line 35
    if-eq v1, v3, :cond_25

    .line 36
    .line 37
    return v2

    .line 38
    :cond_25
    iget v1, p0, Lia/g;->d:I

    .line 39
    .line 40
    iget v3, p1, Lia/g;->d:I

    .line 41
    .line 42
    if-eq v1, v3, :cond_2c

    .line 43
    .line 44
    return v2

    .line 45
    :cond_2c
    iget-object v1, p0, Lia/g;->e:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v3, p1, Lia/g;->e:Ljava/lang/String;

    .line 48
    .line 49
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    if-nez v1, :cond_37

    .line 54
    .line 55
    return v2

    .line 56
    :cond_37
    iget-object v1, p0, Lia/g;->f:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v3, p1, Lia/g;->f:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-nez v1, :cond_42

    .line 65
    .line 66
    return v2

    .line 67
    :cond_42
    iget v1, p0, Lia/g;->g:I

    .line 68
    .line 69
    iget v3, p1, Lia/g;->g:I

    .line 70
    .line 71
    if-eq v1, v3, :cond_49

    .line 72
    .line 73
    return v2

    .line 74
    :cond_49
    iget-object v1, p0, Lia/g;->h:Ljava/lang/String;

    .line 75
    .line 76
    iget-object v3, p1, Lia/g;->h:Ljava/lang/String;

    .line 77
    .line 78
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-nez v1, :cond_54

    .line 83
    .line 84
    return v2

    .line 85
    :cond_54
    iget v1, p0, Lia/g;->i:I

    .line 86
    .line 87
    iget v3, p1, Lia/g;->i:I

    .line 88
    .line 89
    if-eq v1, v3, :cond_5b

    .line 90
    .line 91
    return v2

    .line 92
    :cond_5b
    iget-object v1, p0, Lia/g;->j:Ljava/lang/String;

    .line 93
    .line 94
    iget-object v3, p1, Lia/g;->j:Ljava/lang/String;

    .line 95
    .line 96
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v1

    .line 100
    if-nez v1, :cond_66

    .line 101
    .line 102
    return v2

    .line 103
    :cond_66
    iget v1, p0, Lia/g;->k:I

    .line 104
    .line 105
    iget v3, p1, Lia/g;->k:I

    .line 106
    .line 107
    if-eq v1, v3, :cond_6d

    .line 108
    .line 109
    return v2

    .line 110
    :cond_6d
    iget-object v1, p0, Lia/g;->l:Ljava/lang/String;

    .line 111
    .line 112
    iget-object v3, p1, Lia/g;->l:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-nez v1, :cond_78

    .line 119
    .line 120
    return v2

    .line 121
    :cond_78
    iget v1, p0, Lia/g;->m:I

    .line 122
    .line 123
    iget v3, p1, Lia/g;->m:I

    .line 124
    .line 125
    if-eq v1, v3, :cond_7f

    .line 126
    .line 127
    return v2

    .line 128
    :cond_7f
    iget v1, p0, Lia/g;->n:I

    .line 129
    .line 130
    iget v3, p1, Lia/g;->n:I

    .line 131
    .line 132
    if-eq v1, v3, :cond_86

    .line 133
    .line 134
    return v2

    .line 135
    :cond_86
    iget-object v1, p0, Lia/g;->o:Ljava/lang/String;

    .line 136
    .line 137
    iget-object v3, p1, Lia/g;->o:Ljava/lang/String;

    .line 138
    .line 139
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    if-nez v1, :cond_91

    .line 144
    .line 145
    return v2

    .line 146
    :cond_91
    iget v1, p0, Lia/g;->p:F

    .line 147
    .line 148
    iget v3, p1, Lia/g;->p:F

    .line 149
    .line 150
    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    .line 151
    .line 152
    .line 153
    move-result v1

    .line 154
    if-eqz v1, :cond_9c

    .line 155
    .line 156
    return v2

    .line 157
    :cond_9c
    iget-boolean v1, p0, Lia/g;->q:Z

    .line 158
    .line 159
    iget-boolean v3, p1, Lia/g;->q:Z

    .line 160
    .line 161
    if-eq v1, v3, :cond_a3

    .line 162
    .line 163
    return v2

    .line 164
    :cond_a3
    iget-object v1, p0, Lia/g;->r:Ljava/lang/String;

    .line 165
    .line 166
    iget-object p1, p1, Lia/g;->r:Ljava/lang/String;

    .line 167
    .line 168
    invoke-static {v1, p1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 169
    .line 170
    .line 171
    move-result p1

    .line 172
    if-nez p1, :cond_ae

    .line 173
    .line 174
    return v2

    .line 175
    :cond_ae
    return v0
.end method

.method public final f()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/g;->f:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final g()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/g;->e:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final h()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/g;->h:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final hashCode()I
    .registers 5

    .line 1
    iget-object v0, p0, Lia/g;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lia/g;->b:I

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget v2, p0, Lia/g;->c:I

    .line 17
    .line 18
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget v2, p0, Lia/g;->d:I

    .line 23
    .line 24
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    const/4 v2, 0x0

    .line 29
    iget-object v3, p0, Lia/g;->e:Ljava/lang/String;

    .line 30
    .line 31
    if-nez v3, :cond_22

    .line 32
    .line 33
    move v3, v2

    .line 34
    goto :goto_26

    .line 35
    :cond_22
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    :goto_26
    add-int/2addr v0, v3

    .line 40
    mul-int/2addr v0, v1

    .line 41
    iget-object v3, p0, Lia/g;->f:Ljava/lang/String;

    .line 42
    .line 43
    if-nez v3, :cond_2e

    .line 44
    .line 45
    move v3, v2

    .line 46
    goto :goto_32

    .line 47
    :cond_2e
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    :goto_32
    add-int/2addr v0, v3

    .line 52
    mul-int/2addr v0, v1

    .line 53
    iget v3, p0, Lia/g;->g:I

    .line 54
    .line 55
    invoke-static {v3, v0, v1}, Lhs/q;->a(III)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    iget-object v3, p0, Lia/g;->h:Ljava/lang/String;

    .line 60
    .line 61
    if-nez v3, :cond_40

    .line 62
    .line 63
    move v3, v2

    .line 64
    goto :goto_44

    .line 65
    :cond_40
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v3

    .line 69
    :goto_44
    add-int/2addr v0, v3

    .line 70
    mul-int/2addr v0, v1

    .line 71
    iget v3, p0, Lia/g;->i:I

    .line 72
    .line 73
    invoke-static {v3, v0, v1}, Lhs/q;->a(III)I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    iget-object v3, p0, Lia/g;->j:Ljava/lang/String;

    .line 78
    .line 79
    if-nez v3, :cond_52

    .line 80
    .line 81
    move v3, v2

    .line 82
    goto :goto_56

    .line 83
    :cond_52
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 84
    .line 85
    .line 86
    move-result v3

    .line 87
    :goto_56
    add-int/2addr v0, v3

    .line 88
    mul-int/2addr v0, v1

    .line 89
    iget v3, p0, Lia/g;->k:I

    .line 90
    .line 91
    invoke-static {v3, v0, v1}, Lhs/q;->a(III)I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    iget-object v3, p0, Lia/g;->l:Ljava/lang/String;

    .line 96
    .line 97
    if-nez v3, :cond_64

    .line 98
    .line 99
    move v3, v2

    .line 100
    goto :goto_68

    .line 101
    :cond_64
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 102
    .line 103
    .line 104
    move-result v3

    .line 105
    :goto_68
    add-int/2addr v0, v3

    .line 106
    mul-int/2addr v0, v1

    .line 107
    iget v3, p0, Lia/g;->m:I

    .line 108
    .line 109
    invoke-static {v3, v0, v1}, Lhs/q;->a(III)I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    iget v3, p0, Lia/g;->n:I

    .line 114
    .line 115
    invoke-static {v3, v0, v1}, Lhs/q;->a(III)I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    iget-object v3, p0, Lia/g;->o:Ljava/lang/String;

    .line 120
    .line 121
    if-nez v3, :cond_7b

    .line 122
    .line 123
    goto :goto_7f

    .line 124
    :cond_7b
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    :goto_7f
    add-int/2addr v0, v2

    .line 129
    mul-int/2addr v0, v1

    .line 130
    iget v2, p0, Lia/g;->p:F

    .line 131
    .line 132
    invoke-static {v2, v0, v1}, Lcom/google/android/gms/internal/fido/nb;->e(FII)I

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    iget-boolean v2, p0, Lia/g;->q:Z

    .line 137
    .line 138
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 139
    .line 140
    .line 141
    move-result v0

    .line 142
    iget-object v1, p0, Lia/g;->r:Ljava/lang/String;

    .line 143
    .line 144
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    add-int/2addr v1, v0

    .line 149
    return v1
.end method

.method public final i()I
    .registers 2

    .line 1
    iget v0, p0, Lia/g;->i:I

    .line 2
    .line 3
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    const-string v0, ", headerColor="

    .line 2
    .line 3
    const-string v1, ", backgroundColor="

    .line 4
    .line 5
    iget v2, p0, Lia/g;->b:I

    .line 6
    .line 7
    const-string v3, "Valid(headerText="

    .line 8
    .line 9
    iget-object v4, p0, Lia/g;->a:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v2, v3, v4, v0, v1}, La1/h;->n(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, ", thumbnailCornerRadius="

    .line 16
    .line 17
    const-string v2, ", thumbnailUrl="

    .line 18
    .line 19
    iget v3, p0, Lia/g;->c:I

    .line 20
    .line 21
    iget v4, p0, Lia/g;->d:I

    .line 22
    .line 23
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v1, ", titleText="

    .line 27
    .line 28
    const-string v2, ", titleColor="

    .line 29
    .line 30
    iget-object v3, p0, Lia/g;->e:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v4, p0, Lia/g;->f:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v0, v3, v1, v4, v2}, Lp/x2;->t(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v1, ", subtitle="

    .line 38
    .line 39
    const-string v2, ", subtitleColor="

    .line 40
    .line 41
    iget v3, p0, Lia/g;->g:I

    .line 42
    .line 43
    iget-object v4, p0, Lia/g;->h:Ljava/lang/String;

    .line 44
    .line 45
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->u(Ljava/lang/StringBuilder;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    const-string v1, ", bodyText="

    .line 49
    .line 50
    const-string v2, ", bodyTextColor="

    .line 51
    .line 52
    iget v3, p0, Lia/g;->i:I

    .line 53
    .line 54
    iget-object v4, p0, Lia/g;->j:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->u(Ljava/lang/StringBuilder;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    const-string v1, ", acceptLabelText="

    .line 60
    .line 61
    const-string v2, ", acceptLabelColor="

    .line 62
    .line 63
    iget v3, p0, Lia/g;->k:I

    .line 64
    .line 65
    iget-object v4, p0, Lia/g;->l:Ljava/lang/String;

    .line 66
    .line 67
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->u(Ljava/lang/StringBuilder;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    const-string v1, ", acceptLabelBackgroundColor="

    .line 71
    .line 72
    const-string v2, ", splashUrl="

    .line 73
    .line 74
    iget v3, p0, Lia/g;->m:I

    .line 75
    .line 76
    iget v4, p0, Lia/g;->n:I

    .line 77
    .line 78
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 79
    .line 80
    .line 81
    iget-object v1, p0, Lia/g;->o:Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    const-string v1, ", splashOpacity="

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    iget v1, p0, Lia/g;->p:F

    .line 92
    .line 93
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    const-string v1, ", canBeAccepted="

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    iget-boolean v1, p0, Lia/g;->q:Z

    .line 102
    .line 103
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    const-string v1, ", giftCode="

    .line 107
    .line 108
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    iget-object v1, p0, Lia/g;->r:Ljava/lang/String;

    .line 112
    .line 113
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    const-string v1, ")"

    .line 117
    .line 118
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    return-object v0
.end method
