###### Class ia.d (ia.d)
.class public final Lia/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lia/h;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lia/c;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;

.field public final g:I

.field public final h:Ljava/lang/String;

.field public final i:I

.field public final j:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lia/c;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lia/d;->Companion:Lia/c;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;IIILjava/lang/String;Ljava/lang/String;ILjava/lang/String;II)V
    .registers 14

    .line 1
    and-int/lit16 v0, p1, 0x3ff

    .line 2
    .line 3
    const/16 v1, 0x3ff

    .line 4
    .line 5
    if-ne v1, v0, :cond_1e

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p2, p0, Lia/d;->a:Ljava/lang/String;

    .line 11
    .line 12
    iput p3, p0, Lia/d;->b:I

    .line 13
    .line 14
    iput p4, p0, Lia/d;->c:I

    .line 15
    .line 16
    iput p5, p0, Lia/d;->d:I

    .line 17
    .line 18
    iput-object p6, p0, Lia/d;->e:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p7, p0, Lia/d;->f:Ljava/lang/String;

    .line 21
    .line 22
    iput p8, p0, Lia/d;->g:I

    .line 23
    .line 24
    iput-object p9, p0, Lia/d;->h:Ljava/lang/String;

    .line 25
    .line 26
    iput p10, p0, Lia/d;->i:I

    .line 27
    .line 28
    iput p11, p0, Lia/d;->j:I

    .line 29
    .line 30
    return-void

    .line 31
    :cond_1e
    sget-object p2, Lia/b;->a:Lia/b;

    .line 32
    .line 33
    invoke-virtual {p2}, Lia/b;->d()Ll70/g;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    invoke-static {p1, v1, p2}, Ln70/t0;->j(IILl70/g;)V

    .line 38
    .line 39
    .line 40
    const/4 p1, 0x0

    .line 41
    throw p1
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, Lia/d;->c:I

    .line 2
    .line 3
    return v0
.end method

.method public final b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/d;->a:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c()I
    .registers 2

    .line 1
    iget v0, p0, Lia/d;->b:I

    .line 2
    .line 3
    return v0
.end method

.method public final d()I
    .registers 2

    .line 1
    iget v0, p0, Lia/d;->g:I

    .line 2
    .line 3
    return v0
.end method

.method public final e()I
    .registers 2

    .line 1
    iget v0, p0, Lia/d;->d:I

    .line 2
    .line 3
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lia/d;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lia/d;

    .line 12
    .line 13
    iget-object v1, p0, Lia/d;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lia/d;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    iget v1, p0, Lia/d;->b:I

    .line 25
    .line 26
    iget v3, p1, Lia/d;->b:I

    .line 27
    .line 28
    if-eq v1, v3, :cond_1e

    .line 29
    .line 30
    return v2

    .line 31
    :cond_1e
    iget v1, p0, Lia/d;->c:I

    .line 32
    .line 33
    iget v3, p1, Lia/d;->c:I

    .line 34
    .line 35
    if-eq v1, v3, :cond_25

    .line 36
    .line 37
    return v2

    .line 38
    :cond_25
    iget v1, p0, Lia/d;->d:I

    .line 39
    .line 40
    iget v3, p1, Lia/d;->d:I

    .line 41
    .line 42
    if-eq v1, v3, :cond_2c

    .line 43
    .line 44
    return v2

    .line 45
    :cond_2c
    iget-object v1, p0, Lia/d;->e:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v3, p1, Lia/d;->e:Ljava/lang/String;

    .line 48
    .line 49
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    if-nez v1, :cond_37

    .line 54
    .line 55
    return v2

    .line 56
    :cond_37
    iget-object v1, p0, Lia/d;->f:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v3, p1, Lia/d;->f:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-nez v1, :cond_42

    .line 65
    .line 66
    return v2

    .line 67
    :cond_42
    iget v1, p0, Lia/d;->g:I

    .line 68
    .line 69
    iget v3, p1, Lia/d;->g:I

    .line 70
    .line 71
    if-eq v1, v3, :cond_49

    .line 72
    .line 73
    return v2

    .line 74
    :cond_49
    iget-object v1, p0, Lia/d;->h:Ljava/lang/String;

    .line 75
    .line 76
    iget-object v3, p1, Lia/d;->h:Ljava/lang/String;

    .line 77
    .line 78
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-nez v1, :cond_54

    .line 83
    .line 84
    return v2

    .line 85
    :cond_54
    iget v1, p0, Lia/d;->i:I

    .line 86
    .line 87
    iget v3, p1, Lia/d;->i:I

    .line 88
    .line 89
    if-eq v1, v3, :cond_5b

    .line 90
    .line 91
    return v2

    .line 92
    :cond_5b
    iget v1, p0, Lia/d;->j:I

    .line 93
    .line 94
    iget p1, p1, Lia/d;->j:I

    .line 95
    .line 96
    if-eq v1, p1, :cond_62

    .line 97
    .line 98
    return v2

    .line 99
    :cond_62
    return v0
.end method

.method public final f()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/d;->f:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final g()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/d;->e:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final h()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lia/d;->h:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lia/d;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lia/d;->b:I

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget v2, p0, Lia/d;->c:I

    .line 17
    .line 18
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget v2, p0, Lia/d;->d:I

    .line 23
    .line 24
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-object v2, p0, Lia/d;->e:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v0, v1, v2}, Lhs/q;->c(IILjava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget-object v2, p0, Lia/d;->f:Ljava/lang/String;

    .line 35
    .line 36
    invoke-static {v0, v1, v2}, Lhs/q;->c(IILjava/lang/String;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    iget v2, p0, Lia/d;->g:I

    .line 41
    .line 42
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    iget-object v2, p0, Lia/d;->h:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v0, v1, v2}, Lhs/q;->c(IILjava/lang/String;)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    iget v2, p0, Lia/d;->i:I

    .line 53
    .line 54
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    iget v1, p0, Lia/d;->j:I

    .line 59
    .line 60
    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    add-int/2addr v1, v0

    .line 65
    return v1
.end method

.method public final i()I
    .registers 2

    .line 1
    iget v0, p0, Lia/d;->i:I

    .line 2
    .line 3
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    const-string v0, ", headerColor="

    .line 2
    .line 3
    const-string v1, ", backgroundColor="

    .line 4
    .line 5
    iget v2, p0, Lia/d;->b:I

    .line 6
    .line 7
    const-string v3, "Invalid(headerText="

    .line 8
    .line 9
    iget-object v4, p0, Lia/d;->a:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v2, v3, v4, v0, v1}, La1/h;->n(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, ", thumbnailCornerRadius="

    .line 16
    .line 17
    const-string v2, ", thumbnailUrl="

    .line 18
    .line 19
    iget v3, p0, Lia/d;->c:I

    .line 20
    .line 21
    iget v4, p0, Lia/d;->d:I

    .line 22
    .line 23
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v1, ", titleText="

    .line 27
    .line 28
    const-string v2, ", titleColor="

    .line 29
    .line 30
    iget-object v3, p0, Lia/d;->e:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v4, p0, Lia/d;->f:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v0, v3, v1, v4, v2}, Lp/x2;->t(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v1, ", subtitle="

    .line 38
    .line 39
    const-string v2, ", subtitleColor="

    .line 40
    .line 41
    iget v3, p0, Lia/d;->g:I

    .line 42
    .line 43
    iget-object v4, p0, Lia/d;->h:Ljava/lang/String;

    .line 44
    .line 45
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->u(Ljava/lang/StringBuilder;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget v1, p0, Lia/d;->i:I

    .line 49
    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v1, ", thumbnailBackgroundColor="

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    iget v1, p0, Lia/d;->j:I

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v1, ")"

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    return-object v0
.end method
