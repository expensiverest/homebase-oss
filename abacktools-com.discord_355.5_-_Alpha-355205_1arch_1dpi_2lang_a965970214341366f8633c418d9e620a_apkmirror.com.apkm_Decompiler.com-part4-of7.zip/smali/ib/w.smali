###### Class ib.w (ib.w)
.class public final Lib/w;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lib/v;->a:Lib/v;

    .line 2
    .line 3
    return-object v0
.end method
