###### Class ib.n (ib.n)
.class public final Lib/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lib/m;->a:Lib/m;

    .line 2
    .line 3
    return-object v0
.end method
