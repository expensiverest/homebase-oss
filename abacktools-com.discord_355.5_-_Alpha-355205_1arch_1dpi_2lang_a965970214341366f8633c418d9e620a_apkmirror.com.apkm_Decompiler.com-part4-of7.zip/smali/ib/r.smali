###### Class ib.r (ib.r)
.class public final Lib/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lib/q;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lib/q;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lib/r;->Companion:Lib/q;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableMap;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Ll30/j;

    .line 3
    .line 4
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method
