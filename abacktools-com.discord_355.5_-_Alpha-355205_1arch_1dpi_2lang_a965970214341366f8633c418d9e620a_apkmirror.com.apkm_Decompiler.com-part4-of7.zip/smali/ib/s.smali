###### Class ib.s (ib.s)
.class public final synthetic Lib/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lib/s;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lib/s;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lib/s;->a:Lib/s;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.input.events.OnSelectionOrTextChangeEvent"

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "start"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "end"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "text"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "editId"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    sput-object v1, Lib/s;->descriptor:Ll70/g;

    .line 38
    .line 39
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 20

    .line 1
    sget-object v0, Lib/s;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    if-eqz v2, :cond_2c

    .line 18
    .line 19
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    const/16 v6, 0xf

    .line 36
    .line 37
    move-object/from16 v17, v3

    .line 38
    .line 39
    move-object/from16 v16, v4

    .line 40
    .line 41
    move v15, v5

    .line 42
    move v13, v6

    .line 43
    :goto_2a
    move v14, v2

    .line 44
    goto :goto_6f

    .line 45
    :cond_2c
    const/4 v2, 0x0

    .line 46
    move-object v7, v2

    .line 47
    move-object v8, v7

    .line 48
    move v11, v5

    .line 49
    move v2, v6

    .line 50
    move v9, v2

    .line 51
    move v10, v9

    .line 52
    :goto_33
    if-eqz v11, :cond_68

    .line 53
    .line 54
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 55
    .line 56
    .line 57
    move-result v12

    .line 58
    const/4 v13, -0x1

    .line 59
    if-eq v12, v13, :cond_66

    .line 60
    .line 61
    if-eqz v12, :cond_5f

    .line 62
    .line 63
    if-eq v12, v5, :cond_58

    .line 64
    .line 65
    if-eq v12, v4, :cond_51

    .line 66
    .line 67
    if-ne v12, v3, :cond_4b

    .line 68
    .line 69
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    or-int/lit8 v10, v10, 0x8

    .line 74
    .line 75
    goto :goto_33

    .line 76
    :cond_4b
    new-instance v0, Lj70/k;

    .line 77
    .line 78
    invoke-direct {v0, v12}, Lj70/k;-><init>(I)V

    .line 79
    .line 80
    .line 81
    throw v0

    .line 82
    :cond_51
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v8

    .line 86
    or-int/lit8 v10, v10, 0x4

    .line 87
    .line 88
    goto :goto_33

    .line 89
    :cond_58
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 90
    .line 91
    .line 92
    move-result v9

    .line 93
    or-int/lit8 v10, v10, 0x2

    .line 94
    .line 95
    goto :goto_33

    .line 96
    :cond_5f
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    or-int/lit8 v10, v10, 0x1

    .line 101
    .line 102
    goto :goto_33

    .line 103
    :cond_66
    move v11, v6

    .line 104
    goto :goto_33

    .line 105
    :cond_68
    move-object/from16 v17, v7

    .line 106
    .line 107
    move-object/from16 v16, v8

    .line 108
    .line 109
    move v15, v9

    .line 110
    move v13, v10

    .line 111
    goto :goto_2a

    .line 112
    :goto_6f
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 113
    .line 114
    .line 115
    new-instance v12, Lib/u;

    .line 116
    .line 117
    invoke-direct/range {v12 .. v17}, Lib/u;-><init>(IIILjava/lang/String;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    return-object v12
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x4

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    aput-object v1, v0, v2

    .line 11
    .line 12
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    aput-object v1, v0, v2

    .line 16
    .line 17
    const/4 v2, 0x3

    .line 18
    aput-object v1, v0, v2

    .line 19
    .line 20
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lib/u;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lib/s;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget v2, p2, Lib/u;->a:I

    .line 16
    .line 17
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget v2, p2, Lib/u;->b:I

    .line 22
    .line 23
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object v2, p2, Lib/u;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    iget-object p2, p2, Lib/u;->d:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lib/s;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
