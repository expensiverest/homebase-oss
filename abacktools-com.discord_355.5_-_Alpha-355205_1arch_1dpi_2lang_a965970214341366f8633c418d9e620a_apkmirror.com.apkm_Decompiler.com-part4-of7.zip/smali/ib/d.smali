###### Class ib.d (ib.d)
.class public final synthetic Lib/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lib/d;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lib/d;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lib/d;->a:Lib/d;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.input.events.OnEndBlurEvent"

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "text"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    sput-object v1, Lib/d;->descriptor:Ll70/g;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 10

    .line 1
    sget-object v0, Lib/d;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    if-eqz v1, :cond_13

    .line 14
    .line 15
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    goto :goto_30

    .line 20
    :cond_13
    const/4 v1, 0x0

    .line 21
    move v4, v2

    .line 22
    move v5, v3

    .line 23
    :goto_16
    if-eqz v4, :cond_2f

    .line 24
    .line 25
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    const/4 v7, -0x1

    .line 30
    if-eq v6, v7, :cond_2d

    .line 31
    .line 32
    if-nez v6, :cond_27

    .line 33
    .line 34
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    move v5, v2

    .line 39
    goto :goto_16

    .line 40
    :cond_27
    new-instance p1, Lj70/k;

    .line 41
    .line 42
    invoke-direct {p1, v6}, Lj70/k;-><init>(I)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2d
    move v4, v3

    .line 47
    goto :goto_16

    .line 48
    :cond_2f
    move v2, v5

    .line 49
    :goto_30
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 50
    .line 51
    .line 52
    new-instance p1, Lib/f;

    .line 53
    .line 54
    invoke-direct {p1, v2, v1}, Lib/f;-><init>(ILjava/lang/String;)V

    .line 55
    .line 56
    .line 57
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 5

    .line 1
    check-cast p2, Lib/f;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lib/d;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object p2, p2, Lib/f;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lib/d;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
