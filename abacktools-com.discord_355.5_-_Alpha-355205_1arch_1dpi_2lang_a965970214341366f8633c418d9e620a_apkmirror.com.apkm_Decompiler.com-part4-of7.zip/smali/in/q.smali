###### Class in.q (in.q)
.class public final Lin/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field public final d:I

.field public e:Ljl/b;


# direct methods
.method public constructor <init>(ILjl/c;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    if-ltz p1, :cond_16

    .line 8
    .line 9
    invoke-virtual {p2}, Ljl/b;->n()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lin/o;

    .line 14
    .line 15
    invoke-interface {v0}, Lin/o;->u()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-gt p1, v0, :cond_16

    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    const/4 v0, 0x0

    .line 24
    :goto_17
    if-eqz v0, :cond_22

    .line 25
    .line 26
    invoke-virtual {p2}, Ljl/c;->c()Ljl/b;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    iput-object p2, p0, Lin/q;->e:Ljl/b;

    .line 31
    .line 32
    iput p1, p0, Lin/q;->d:I

    .line 33
    .line 34
    return-void

    .line 35
    :cond_22
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 36
    .line 37
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 38
    .line 39
    .line 40
    throw p1
.end method


# virtual methods
.method public final declared-synchronized c()V
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    monitor-enter p0
    :try_end_2
    .catchall {:try_start_1 .. :try_end_2} :catchall_16

    .line 3
    :try_start_2
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 4
    .line 5
    invoke-static {v0}, Ljl/b;->x(Ljl/b;)Z

    .line 6
    .line 7
    .line 8
    move-result v0
    :try_end_8
    .catchall {:try_start_2 .. :try_end_8} :catchall_18

    .line 9
    :try_start_8
    monitor-exit p0
    :try_end_9
    .catchall {:try_start_8 .. :try_end_9} :catchall_16

    .line 10
    if-eqz v0, :cond_d

    .line 11
    .line 12
    monitor-exit p0

    .line 13
    return-void

    .line 14
    :cond_d
    :try_start_d
    new-instance v0, Lan/g;

    .line 15
    .line 16
    const-string v1, "Invalid bytebuf. Already closed"

    .line 17
    .line 18
    const/4 v2, 0x7

    .line 19
    invoke-direct {v0, v1, v2}, Lan/g;-><init>(Ljava/lang/String;I)V

    .line 20
    .line 21
    .line 22
    throw v0
    :try_end_16
    .catchall {:try_start_d .. :try_end_16} :catchall_16

    .line 23
    :catchall_16
    move-exception v0

    .line 24
    goto :goto_1b

    .line 25
    :catchall_18
    move-exception v0

    .line 26
    :try_start_19
    monitor-exit p0
    :try_end_1a
    .catchall {:try_start_19 .. :try_end_1a} :catchall_18

    .line 27
    :try_start_1a
    throw v0

    .line 28
    :goto_1b
    monitor-exit p0
    :try_end_1c
    .catchall {:try_start_1a .. :try_end_1c} :catchall_16

    .line 29
    throw v0
.end method

.method public final declared-synchronized close()V
    .registers 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 3
    .line 4
    invoke-static {v0}, Ljl/b;->l(Ljl/b;)V

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Lin/q;->e:Ljl/b;
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_b

    .line 9
    .line 10
    monitor-exit p0

    .line 11
    return-void

    .line 12
    :catchall_b
    move-exception v0

    .line 13
    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    .line 14
    throw v0
.end method

.method public final declared-synchronized d()Ljava/nio/ByteBuffer;
    .registers 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 3
    .line 4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljl/b;->n()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lin/o;

    .line 14
    .line 15
    invoke-interface {v0}, Lin/o;->g()Ljava/nio/ByteBuffer;

    .line 16
    .line 17
    .line 18
    move-result-object v0
    :try_end_12
    .catchall {:try_start_1 .. :try_end_12} :catchall_14

    .line 19
    monitor-exit p0

    .line 20
    return-object v0

    .line 21
    :catchall_14
    move-exception v0

    .line 22
    :try_start_15
    monitor-exit p0
    :try_end_16
    .catchall {:try_start_15 .. :try_end_16} :catchall_14

    .line 23
    throw v0
.end method

.method public final declared-synchronized g()J
    .registers 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0}, Lin/q;->c()V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljl/b;->n()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lin/o;

    .line 17
    .line 18
    invoke-interface {v0}, Lin/o;->n()J

    .line 19
    .line 20
    .line 21
    move-result-wide v0
    :try_end_15
    .catchall {:try_start_1 .. :try_end_15} :catchall_17

    .line 22
    monitor-exit p0

    .line 23
    return-wide v0

    .line 24
    :catchall_17
    move-exception v0

    .line 25
    :try_start_18
    monitor-exit p0
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_17

    .line 26
    throw v0
.end method

.method public final declared-synchronized i(I)B
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0}, Lin/q;->c()V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    const/4 v1, 0x1

    .line 7
    if-ltz p1, :cond_a

    .line 8
    .line 9
    move v2, v1

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    move v2, v0

    .line 12
    :goto_b
    if-eqz v2, :cond_2f

    .line 13
    .line 14
    iget v2, p0, Lin/q;->d:I

    .line 15
    .line 16
    if-ge p1, v2, :cond_12

    .line 17
    .line 18
    move v0, v1

    .line 19
    :cond_12
    if-eqz v0, :cond_29

    .line 20
    .line 21
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 27
    .line 28
    invoke-virtual {v0}, Ljl/b;->n()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lin/o;

    .line 33
    .line 34
    invoke-interface {v0, p1}, Lin/o;->d(I)B

    .line 35
    .line 36
    .line 37
    move-result p1
    :try_end_25
    .catchall {:try_start_1 .. :try_end_25} :catchall_27

    .line 38
    monitor-exit p0

    .line 39
    return p1

    .line 40
    :catchall_27
    move-exception p1

    .line 41
    goto :goto_35

    .line 42
    :cond_29
    :try_start_29
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 43
    .line 44
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 45
    .line 46
    .line 47
    throw p1

    .line 48
    :cond_2f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 49
    .line 50
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 51
    .line 52
    .line 53
    throw p1

    .line 54
    :goto_35
    monitor-exit p0
    :try_end_36
    .catchall {:try_start_29 .. :try_end_36} :catchall_27

    .line 55
    throw p1
.end method

.method public final declared-synchronized j(III[B)V
    .registers 7

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0}, Lin/q;->c()V

    .line 3
    .line 4
    .line 5
    add-int v0, p1, p3

    .line 6
    .line 7
    iget v1, p0, Lin/q;->d:I

    .line 8
    .line 9
    if-gt v0, v1, :cond_c

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 v0, 0x0

    .line 14
    :goto_d
    if-eqz v0, :cond_23

    .line 15
    .line 16
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lin/q;->e:Ljl/b;

    .line 22
    .line 23
    invoke-virtual {v0}, Ljl/b;->n()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Lin/o;

    .line 28
    .line 29
    invoke-interface {v0, p1, p2, p3, p4}, Lin/o;->i(III[B)I
    :try_end_1f
    .catchall {:try_start_1 .. :try_end_1f} :catchall_21

    .line 30
    .line 31
    .line 32
    monitor-exit p0

    .line 33
    return-void

    .line 34
    :catchall_21
    move-exception p1

    .line 35
    goto :goto_29

    .line 36
    :cond_23
    :try_start_23
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 37
    .line 38
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 39
    .line 40
    .line 41
    throw p1

    .line 42
    :goto_29
    monitor-exit p0
    :try_end_2a
    .catchall {:try_start_23 .. :try_end_2a} :catchall_21

    .line 43
    throw p1
.end method

.method public final declared-synchronized l()I
    .registers 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0}, Lin/q;->c()V

    .line 3
    .line 4
    .line 5
    iget v0, p0, Lin/q;->d:I
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    .line 6
    .line 7
    monitor-exit p0

    .line 8
    return v0

    .line 9
    :catchall_8
    move-exception v0

    .line 10
    :try_start_9
    monitor-exit p0
    :try_end_a
    .catchall {:try_start_9 .. :try_end_a} :catchall_8

    .line 11
    throw v0
.end method
