###### Class in.m (in.m)
.class public abstract Lin/m;
.super Ljava/lang/Object;
.source "SourceFile"
