###### Class in.t (in.t)
.class public final Lin/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lin/u;

.field public final b:Lin/s;

.field public final c:Lin/u;

.field public final d:Lil/c;

.field public final e:Lin/u;

.field public final f:Lin/s;

.field public final g:Lin/u;

.field public final h:Lin/s;

.field public final i:Ljava/lang/String;

.field public final j:I


# direct methods
.method public constructor <init>(La8/c;)V
    .registers 15

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lmn/a;->H()V

    .line 5
    .line 6
    .line 7
    invoke-static {}, Lin/j;->a()Lin/u;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lin/t;->a:Lin/u;

    .line 12
    .line 13
    invoke-static {}, Lin/s;->K()Lin/s;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Lin/t;->b:Lin/s;

    .line 18
    .line 19
    new-instance v0, Lin/u;

    .line 20
    .line 21
    sget v1, Lin/k;->a:I

    .line 22
    .line 23
    const/high16 v2, 0x400000

    .line 24
    .line 25
    mul-int v3, v1, v2

    .line 26
    .line 27
    new-instance v4, Landroid/util/SparseIntArray;

    .line 28
    .line 29
    invoke-direct {v4}, Landroid/util/SparseIntArray;-><init>()V

    .line 30
    .line 31
    .line 32
    const/high16 v5, 0x20000

    .line 33
    .line 34
    move v6, v5

    .line 35
    :goto_22
    if-gt v6, v2, :cond_2a

    .line 36
    .line 37
    invoke-virtual {v4, v6, v1}, Landroid/util/SparseIntArray;->put(II)V

    .line 38
    .line 39
    .line 40
    mul-int/lit8 v6, v6, 0x2

    .line 41
    .line 42
    goto :goto_22

    .line 43
    :cond_2a
    sget v1, Lin/k;->a:I

    .line 44
    .line 45
    invoke-direct {v0, v2, v3, v4, v1}, Lin/u;-><init>(IILandroid/util/SparseIntArray;I)V

    .line 46
    .line 47
    .line 48
    iput-object v0, p0, Lin/t;->c:Lin/u;

    .line 49
    .line 50
    invoke-static {}, Lil/c;->n()Lil/c;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iput-object v0, p0, Lin/t;->d:Lil/c;

    .line 55
    .line 56
    new-instance v0, Landroid/util/SparseIntArray;

    .line 57
    .line 58
    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    .line 59
    .line 60
    .line 61
    const/16 v1, 0x400

    .line 62
    .line 63
    const/4 v3, 0x5

    .line 64
    invoke-virtual {v0, v1, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 65
    .line 66
    .line 67
    const/16 v1, 0x800

    .line 68
    .line 69
    invoke-virtual {v0, v1, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 70
    .line 71
    .line 72
    const/16 v1, 0x1000

    .line 73
    .line 74
    invoke-virtual {v0, v1, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 75
    .line 76
    .line 77
    const/16 v1, 0x2000

    .line 78
    .line 79
    invoke-virtual {v0, v1, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 80
    .line 81
    .line 82
    const/16 v1, 0x4000

    .line 83
    .line 84
    invoke-virtual {v0, v1, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 85
    .line 86
    .line 87
    const v4, 0x8000

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0, v4, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 91
    .line 92
    .line 93
    const/high16 v4, 0x10000

    .line 94
    .line 95
    invoke-virtual {v0, v4, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v0, v5, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 99
    .line 100
    .line 101
    const/high16 v4, 0x40000

    .line 102
    .line 103
    const/4 v5, 0x2

    .line 104
    invoke-virtual {v0, v4, v5}, Landroid/util/SparseIntArray;->put(II)V

    .line 105
    .line 106
    .line 107
    const/high16 v4, 0x80000

    .line 108
    .line 109
    invoke-virtual {v0, v4, v5}, Landroid/util/SparseIntArray;->put(II)V

    .line 110
    .line 111
    .line 112
    const/high16 v4, 0x100000

    .line 113
    .line 114
    invoke-virtual {v0, v4, v5}, Landroid/util/SparseIntArray;->put(II)V

    .line 115
    .line 116
    .line 117
    new-instance v6, Lin/u;

    .line 118
    .line 119
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 120
    .line 121
    .line 122
    move-result-object v7

    .line 123
    invoke-virtual {v7}, Ljava/lang/Runtime;->maxMemory()J

    .line 124
    .line 125
    .line 126
    move-result-wide v7

    .line 127
    const-wide/32 v9, 0x7fffffff

    .line 128
    .line 129
    .line 130
    invoke-static {v7, v8, v9, v10}, Ljava/lang/Math;->min(JJ)J

    .line 131
    .line 132
    .line 133
    move-result-wide v7

    .line 134
    long-to-int v7, v7

    .line 135
    const/high16 v8, 0x1000000

    .line 136
    .line 137
    if-ge v7, v8, :cond_8d

    .line 138
    .line 139
    const/high16 v7, 0x300000

    .line 140
    .line 141
    goto :goto_96

    .line 142
    :cond_8d
    const/high16 v11, 0x2000000

    .line 143
    .line 144
    if-ge v7, v11, :cond_94

    .line 145
    .line 146
    const/high16 v7, 0x600000

    .line 147
    .line 148
    goto :goto_96

    .line 149
    :cond_94
    const/high16 v7, 0xc00000

    .line 150
    .line 151
    :goto_96
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 152
    .line 153
    .line 154
    move-result-object v11

    .line 155
    invoke-virtual {v11}, Ljava/lang/Runtime;->maxMemory()J

    .line 156
    .line 157
    .line 158
    move-result-wide v11

    .line 159
    invoke-static {v11, v12, v9, v10}, Ljava/lang/Math;->min(JJ)J

    .line 160
    .line 161
    .line 162
    move-result-wide v9

    .line 163
    long-to-int v9, v9

    .line 164
    if-ge v9, v8, :cond_a7

    .line 165
    .line 166
    div-int/2addr v9, v5

    .line 167
    goto :goto_ab

    .line 168
    :cond_a7
    div-int/lit8 v9, v9, 0x4

    .line 169
    .line 170
    mul-int/lit8 v9, v9, 0x3

    .line 171
    .line 172
    :goto_ab
    const/4 v5, -0x1

    .line 173
    invoke-direct {v6, v7, v9, v0, v5}, Lin/u;-><init>(IILandroid/util/SparseIntArray;I)V

    .line 174
    .line 175
    .line 176
    iput-object v6, p0, Lin/t;->e:Lin/u;

    .line 177
    .line 178
    invoke-static {}, Lin/s;->K()Lin/s;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    iput-object v0, p0, Lin/t;->f:Lin/s;

    .line 183
    .line 184
    iget-object p1, p1, La8/c;->d:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast p1, Lin/u;

    .line 187
    .line 188
    if-nez p1, :cond_ce

    .line 189
    .line 190
    new-instance p1, Landroid/util/SparseIntArray;

    .line 191
    .line 192
    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    .line 193
    .line 194
    .line 195
    invoke-virtual {p1, v1, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 196
    .line 197
    .line 198
    new-instance v0, Lin/u;

    .line 199
    .line 200
    const v1, 0x14000

    .line 201
    .line 202
    .line 203
    invoke-direct {v0, v1, v4, p1, v5}, Lin/u;-><init>(IILandroid/util/SparseIntArray;I)V

    .line 204
    .line 205
    .line 206
    move-object p1, v0

    .line 207
    :cond_ce
    iput-object p1, p0, Lin/t;->g:Lin/u;

    .line 208
    .line 209
    invoke-static {}, Lin/s;->K()Lin/s;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    iput-object p1, p0, Lin/t;->h:Lin/s;

    .line 214
    .line 215
    const-string p1, "legacy"

    .line 216
    .line 217
    iput-object p1, p0, Lin/t;->i:Ljava/lang/String;

    .line 218
    .line 219
    iput v2, p0, Lin/t;->j:I

    .line 220
    .line 221
    invoke-static {}, Lmn/a;->H()V

    .line 222
    .line 223
    .line 224
    return-void
.end method
