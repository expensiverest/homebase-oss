###### Class in.s (in.s)
.class public final Lin/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lin/v;
.implements Landroidx/customview/widget/d;
.implements Lc6/d;
.implements La20/b;
.implements Lg4/c;
.implements Lgm/b;
.implements Lio/sentry/clientreport/f;
.implements Lo/v;
.implements Lsr/x;
.implements Lww/h;
.implements Lzm/p;


# static fields
.field public static e:Lin/s;


# instance fields
.field public final synthetic d:I


# direct methods
.method public constructor <init>()V
    .registers 3

    const/16 v0, 0x18

    iput v0, p0, Lin/s;->d:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x23

    if-lt v0, v1, :cond_f

    .line 4
    new-instance v0, Lv3/h;

    :cond_f
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lin/s;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lb6/f;Lat/d;)V
    .registers 3

    const/4 p1, 0x3

    iput p1, p0, Lin/s;->d:I

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static I(Ljava/util/List;)Ljava/util/ArrayList;
    .registers 5

    .line 1
    const-string v0, "protocols"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    :cond_e
    :goto_e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_23

    .line 20
    .line 21
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    move-object v2, v1

    .line 26
    check-cast v2, Lb80/h0;

    .line 27
    .line 28
    sget-object v3, Lb80/h0;->e:Lb80/h0;

    .line 29
    .line 30
    if-eq v2, v3, :cond_e

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    goto :goto_e

    .line 36
    :cond_23
    new-instance p0, Ljava/util/ArrayList;

    .line 37
    .line 38
    const/16 v1, 0xa

    .line 39
    .line 40
    invoke-static {v0, v1}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    invoke-direct {p0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    :goto_32
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    if-eqz v1, :cond_44

    .line 56
    .line 57
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Lb80/h0;

    .line 62
    .line 63
    iget-object v1, v1, Lb80/h0;->d:Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    goto :goto_32

    .line 69
    :cond_44
    return-object p0
.end method

.method public static J(Ljava/util/List;)[B
    .registers 4

    .line 1
    const-string v0, "protocols"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Lq80/i;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-static {p0}, Lin/s;->I(Ljava/util/List;)Ljava/util/ArrayList;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    :goto_12
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-eqz v1, :cond_29

    .line 24
    .line 25
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    check-cast v1, Ljava/lang/String;

    .line 30
    .line 31
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    invoke-virtual {v0, v2}, Lq80/i;->Y(I)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lq80/i;->n0(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    goto :goto_12

    .line 42
    :cond_29
    iget-wide v1, v0, Lq80/i;->e:J

    .line 43
    .line 44
    invoke-virtual {v0, v1, v2}, Lq80/i;->u(J)[B

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0
.end method

.method public static declared-synchronized K()Lin/s;
    .registers 3

    .line 1
    const-class v0, Lin/s;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, Lin/s;->e:Lin/s;

    .line 5
    .line 6
    if-nez v1, :cond_12

    .line 7
    .line 8
    new-instance v1, Lin/s;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-direct {v1, v2}, Lin/s;-><init>(I)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Lin/s;->e:Lin/s;

    .line 15
    .line 16
    goto :goto_12

    .line 17
    :catchall_10
    move-exception v1

    .line 18
    goto :goto_16

    .line 19
    :cond_12
    :goto_12
    sget-object v1, Lin/s;->e:Lin/s;
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_10

    .line 20
    .line 21
    monitor-exit v0

    .line 22
    return-object v1

    .line 23
    :goto_16
    :try_start_16
    monitor-exit v0
    :try_end_17
    .catchall {:try_start_16 .. :try_end_17} :catchall_10

    .line 24
    throw v1
.end method

.method public static L()Z
    .registers 2

    .line 1
    const-string v0, "java.vm.name"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "Dalvik"

    .line 8
    .line 9
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    return v0
.end method

.method public static M(Ljava/util/List;)Lmx/y;
    .registers 3

    .line 1
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    :cond_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_1e

    .line 10
    .line 11
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lk3/o0;

    .line 16
    .line 17
    iget-object v1, v1, Lk3/o0;->b:Lk3/i0;

    .line 18
    .line 19
    if-nez v1, :cond_4

    .line 20
    .line 21
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 22
    .line 23
    invoke-direct {p0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 24
    .line 25
    .line 26
    invoke-static {p0}, Lk7/f;->y(Ljava/lang/RuntimeException;)Lmx/v;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0

    .line 31
    :cond_1e
    invoke-static {p0}, Lk7/f;->z(Ljava/lang/Object;)Lmx/w;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0
.end method

.method public static N(Landroid/content/Context;Ljava/lang/String;IIIIILjava/lang/String;)Ljava/io/File;
    .registers 13

    .line 1
    if-le p2, p4, :cond_a

    .line 2
    .line 3
    int-to-float v0, p4

    .line 4
    int-to-float v1, p2

    .line 5
    div-float/2addr v0, v1

    .line 6
    int-to-float v1, p3

    .line 7
    mul-float/2addr v1, v0

    .line 8
    float-to-int v0, v1

    .line 9
    move v1, p4

    .line 10
    goto :goto_c

    .line 11
    :cond_a
    move v1, p2

    .line 12
    move v0, p3

    .line 13
    :goto_c
    if-le v0, p5, :cond_15

    .line 14
    .line 15
    int-to-float v2, p5

    .line 16
    int-to-float v0, v0

    .line 17
    div-float/2addr v2, v0

    .line 18
    int-to-float v0, v1

    .line 19
    mul-float/2addr v0, v2

    .line 20
    float-to-int v1, v0

    .line 21
    move v0, p5

    .line 22
    :cond_15
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v1, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v1, Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v0, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    const/4 v2, 0x1

    .line 51
    if-gt p2, p4, :cond_3b

    .line 52
    .line 53
    if-gt p3, p5, :cond_3b

    .line 54
    .line 55
    invoke-static {p1}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    .line 56
    .line 57
    .line 58
    move-result-object p2

    .line 59
    goto :goto_5d

    .line 60
    :cond_3b
    new-instance p4, Landroid/graphics/BitmapFactory$Options;

    .line 61
    .line 62
    invoke-direct {p4}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 63
    .line 64
    .line 65
    if-gt p2, v1, :cond_47

    .line 66
    .line 67
    if-le p3, v0, :cond_45

    .line 68
    .line 69
    goto :goto_47

    .line 70
    :cond_45
    move p5, v2

    .line 71
    goto :goto_57

    .line 72
    :cond_47
    :goto_47
    div-int/lit8 p2, p2, 0x2

    .line 73
    .line 74
    div-int/lit8 p3, p3, 0x2

    .line 75
    .line 76
    move p5, v2

    .line 77
    :goto_4c
    div-int v3, p2, p5

    .line 78
    .line 79
    if-lt v3, v1, :cond_57

    .line 80
    .line 81
    div-int v3, p3, p5

    .line 82
    .line 83
    if-lt v3, v0, :cond_57

    .line 84
    .line 85
    mul-int/lit8 p5, p5, 0x2

    .line 86
    .line 87
    goto :goto_4c

    .line 88
    :cond_57
    :goto_57
    iput p5, p4, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 89
    .line 90
    invoke-static {p1, p4}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    :goto_5d
    new-instance p3, Landroid/media/ExifInterface;

    .line 95
    .line 96
    invoke-direct {p3, p1}, Landroid/media/ExifInterface;-><init>(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    const-string p1, "Orientation"

    .line 100
    .line 101
    invoke-virtual {p3, p1}, Landroid/media/ExifInterface;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p3

    .line 105
    invoke-static {p2, v1, v0, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    .line 106
    .line 107
    .line 108
    move-result-object p2

    .line 109
    sget-object p4, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    .line 110
    .line 111
    invoke-virtual {p0, p4}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    .line 116
    .line 117
    .line 118
    move-result p4

    .line 119
    if-nez p4, :cond_82

    .line 120
    .line 121
    const-string p4, "image-crop-picker"

    .line 122
    .line 123
    const-string p5, "Pictures Directory is not existing. Will create this directory."

    .line 124
    .line 125
    invoke-static {p4, p5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    .line 129
    .line 130
    .line 131
    :cond_82
    const-string p4, "image/png"

    .line 132
    .line 133
    invoke-virtual {p7, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    move-result p5

    .line 137
    if-eqz p5, :cond_8d

    .line 138
    .line 139
    sget-object p5, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    .line 140
    .line 141
    goto :goto_8f

    .line 142
    :cond_8d
    sget-object p5, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    .line 143
    .line 144
    :goto_8f
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    .line 145
    .line 146
    if-ne p5, v0, :cond_96

    .line 147
    .line 148
    const-string p5, ".png"

    .line 149
    .line 150
    goto :goto_98

    .line 151
    :cond_96
    const-string p5, ".jpg"

    .line 152
    .line 153
    :goto_98
    new-instance v1, Ljava/io/File;

    .line 154
    .line 155
    new-instance v3, Ljava/lang/StringBuilder;

    .line 156
    .line 157
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 158
    .line 159
    .line 160
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    invoke-virtual {v3, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object p5

    .line 174
    invoke-direct {v1, p0, p5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    new-instance p0, Ljava/io/BufferedOutputStream;

    .line 178
    .line 179
    new-instance p5, Ljava/io/FileOutputStream;

    .line 180
    .line 181
    invoke-direct {p5, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 182
    .line 183
    .line 184
    invoke-direct {p0, p5}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {p7, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result p4

    .line 191
    if-eqz p4, :cond_c1

    .line 192
    .line 193
    goto :goto_c3

    .line 194
    :cond_c1
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    .line 195
    .line 196
    :goto_c3
    invoke-virtual {p2, v0, p6, p0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 197
    .line 198
    .line 199
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object p4

    .line 203
    invoke-virtual {p3, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    move-result p4

    .line 207
    if-nez p4, :cond_ea

    .line 208
    .line 209
    const/4 p4, 0x0

    .line 210
    invoke-static {p4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object p4

    .line 214
    invoke-virtual {p3, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    move-result p4

    .line 218
    if-nez p4, :cond_ea

    .line 219
    .line 220
    new-instance p4, Landroid/media/ExifInterface;

    .line 221
    .line 222
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object p5

    .line 226
    invoke-direct {p4, p5}, Landroid/media/ExifInterface;-><init>(Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {p4, p1, p3}, Landroid/media/ExifInterface;->setAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {p4}, Landroid/media/ExifInterface;->saveAttributes()V

    .line 233
    .line 234
    .line 235
    :cond_ea
    invoke-virtual {p0}, Ljava/io/OutputStream;->close()V

    .line 236
    .line 237
    .line 238
    invoke-virtual {p2}, Landroid/graphics/Bitmap;->recycle()V

    .line 239
    .line 240
    .line 241
    return-object v1
.end method


# virtual methods
.method public A(Lio/sentry/clientreport/d;Lio/sentry/r4;)V
    .registers 3

    .line 1
    return-void
.end method

.method public B()Ljl/b;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public C(I)Ljl/b;
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public D(Lo/k;)Z
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public E(ILjl/b;)V
    .registers 3

    .line 1
    const-string p1, "bitmapReference"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public G(Lio/sentry/clientreport/d;Lk7/e;)V
    .registers 3

    .line 1
    return-void
.end method

.method public H(Landroid/os/Bundle;)Lfu/e;
    .registers 5

    .line 1
    const-string v0, "error"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    return-object v1

    .line 11
    :cond_a
    const-string v2, "is.error.remediable"

    .line 12
    .line 13
    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    new-instance p1, Lzw/a;

    .line 17
    .line 18
    invoke-direct {p1, v0, v1}, Lzw/a;-><init>(ILjava/lang/Exception;)V

    .line 19
    .line 20
    .line 21
    return-object p1
.end method

.method public a(Lio/sentry/clientreport/d;Lio/sentry/m;)V
    .registers 3

    .line 1
    return-void
.end method

.method public synthetic b()Ljava/lang/Object;
    .registers 2

    .line 1
    new-instance v0, Lvw/o0;

    .line 2
    .line 3
    invoke-direct {v0}, Lvw/o0;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public c([B)Ljava/util/Map;
    .registers 2

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public clear()V
    .registers 1

    .line 1
    return-void
.end method

.method public d()Lsr/w;
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public e()J
    .registers 2

    .line 1
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public f([B)Lrr/a;
    .registers 2

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public g()[B
    .registers 3

    .line 1
    new-instance v0, Landroid/media/MediaDrmException;

    .line 2
    .line 3
    const-string v1, "Attempting to open a session using a dummy ExoMediaDrm."

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroid/media/MediaDrmException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw v0
.end method

.method public getEventName()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Lin/s;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_c

    .line 4
    .line 5
    .line 6
    const-string v0, "topWillAppear"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_8
    const-string v0, "topDetentChanged"

    .line 10
    .line 11
    return-object v0

    .line 12
    nop

    .line 13
    :pswitch_data_c
    .packed-switch 0x6
        :pswitch_8
    .end packed-switch
.end method

.method public h(Lo/k;Z)V
    .registers 3

    .line 1
    return-void
.end method

.method public i(I)Z
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public j()J
    .registers 2

    .line 1
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public k([BLjava/lang/String;)Z
    .registers 3

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public l([B[B)V
    .registers 3

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public m([B)V
    .registers 2

    .line 1
    return-void
.end method

.method public n([B[B)[B
    .registers 3

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public next()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public o([B)V
    .registers 2

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public p([BLjava/util/List;ILjava/util/HashMap;)Lsr/v;
    .registers 5

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public q()V
    .registers 1

    .line 1
    return-void
.end method

.method public r()I
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public release()V
    .registers 1

    .line 1
    return-void
.end method

.method public s(Lp/g3;)V
    .registers 2

    .line 1
    return-void
.end method

.method public t(Ljava/lang/Object;)I
    .registers 2

    .line 1
    check-cast p1, Lin/q;

    .line 2
    .line 3
    invoke-virtual {p1}, Lin/q;->l()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public u(ILjava/lang/Object;)V
    .registers 3

    .line 1
    return-void
.end method

.method public v()Ljl/b;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public w(Lk7/e;)Lk7/e;
    .registers 2

    .line 1
    return-object p1
.end method

.method public x()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Lin/s;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_c

    .line 4
    .line 5
    .line 6
    const-string v0, "onWillAppear"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_8
    const-string v0, "onDetentChanged"

    .line 10
    .line 11
    return-object v0

    .line 12
    nop

    .line 13
    :pswitch_data_c
    .packed-switch 0x6
        :pswitch_8
    .end packed-switch
.end method

.method public y(ILjl/b;)V
    .registers 3

    .line 1
    const-string p1, "bitmapReference"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public z(Lio/sentry/clientreport/d;Lio/sentry/m;J)V
    .registers 5

    .line 1
    return-void
.end method
