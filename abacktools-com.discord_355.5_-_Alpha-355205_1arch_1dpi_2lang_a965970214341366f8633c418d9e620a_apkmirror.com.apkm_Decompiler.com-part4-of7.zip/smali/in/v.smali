###### Class in.v (in.v)
.class public interface abstract Lin/v;
.super Ljava/lang/Object;
.source "SourceFile"
