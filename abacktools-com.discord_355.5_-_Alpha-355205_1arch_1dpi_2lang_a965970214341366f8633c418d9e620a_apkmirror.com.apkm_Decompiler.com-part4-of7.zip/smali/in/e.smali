###### Class in.e (in.e)
.class public interface abstract Lin/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lil/d;
