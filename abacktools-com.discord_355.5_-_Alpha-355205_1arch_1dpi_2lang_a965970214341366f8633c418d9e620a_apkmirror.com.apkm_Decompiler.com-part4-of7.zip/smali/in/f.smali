###### Class in.f (in.f)
.class public Lin/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Ljava/util/LinkedList;

.field public d:I


# direct methods
.method public constructor <init>(III)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-lez p1, :cond_9

    .line 7
    .line 8
    move v2, v1

    .line 9
    goto :goto_a

    .line 10
    :cond_9
    move v2, v0

    .line 11
    :goto_a
    invoke-static {v2}, Lfl/j;->e(Z)V

    .line 12
    .line 13
    .line 14
    if-ltz p2, :cond_11

    .line 15
    .line 16
    move v2, v1

    .line 17
    goto :goto_12

    .line 18
    :cond_11
    move v2, v0

    .line 19
    :goto_12
    invoke-static {v2}, Lfl/j;->e(Z)V

    .line 20
    .line 21
    .line 22
    if-ltz p3, :cond_18

    .line 23
    .line 24
    move v0, v1

    .line 25
    :cond_18
    invoke-static {v0}, Lfl/j;->e(Z)V

    .line 26
    .line 27
    .line 28
    iput p1, p0, Lin/f;->a:I

    .line 29
    .line 30
    iput p2, p0, Lin/f;->b:I

    .line 31
    .line 32
    new-instance p1, Ljava/util/LinkedList;

    .line 33
    .line 34
    invoke-direct {p1}, Ljava/util/LinkedList;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, Lin/f;->c:Ljava/util/LinkedList;

    .line 38
    .line 39
    iput p3, p0, Lin/f;->d:I

    .line 40
    .line 41
    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lin/f;->c:Ljava/util/LinkedList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method
