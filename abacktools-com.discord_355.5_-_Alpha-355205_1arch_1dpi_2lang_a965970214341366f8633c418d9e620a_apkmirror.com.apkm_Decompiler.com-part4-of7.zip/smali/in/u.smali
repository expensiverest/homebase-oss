###### Class in.u (in.u)
.class public final Lin/u;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Landroid/util/SparseIntArray;

.field public final d:I


# direct methods
.method public constructor <init>(IILandroid/util/SparseIntArray;I)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    if-ltz p1, :cond_9

    .line 5
    .line 6
    if-lt p2, p1, :cond_9

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    goto :goto_a

    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    :goto_a
    invoke-static {v0}, Lfl/j;->e(Z)V

    .line 12
    .line 13
    .line 14
    iput p1, p0, Lin/u;->b:I

    .line 15
    .line 16
    iput p2, p0, Lin/u;->a:I

    .line 17
    .line 18
    iput-object p3, p0, Lin/u;->c:Landroid/util/SparseIntArray;

    .line 19
    .line 20
    iput p4, p0, Lin/u;->d:I

    .line 21
    .line 22
    return-void
.end method
