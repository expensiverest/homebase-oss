###### Class in.b (in.b)
.class public abstract Lin/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lil/d;


# instance fields
.field public final J:Landroidx/core/view/t;

.field public final K:Lin/v;

.field public final d:Ljava/lang/Class;

.field public final e:Lil/b;

.field public final i:Lin/u;

.field public final v:Landroid/util/SparseArray;

.field public final w:Ljava/util/Set;

.field public final x:Z

.field public final y:Landroidx/core/view/t;


# direct methods
.method public constructor <init>(Lil/b;Lin/u;Lin/v;)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, Lin/b;->d:Ljava/lang/Class;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lin/b;->e:Lil/b;

    .line 14
    .line 15
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    iput-object p2, p0, Lin/b;->i:Lin/u;

    .line 19
    .line 20
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    iput-object p3, p0, Lin/b;->K:Lin/v;

    .line 24
    .line 25
    new-instance p1, Landroid/util/SparseArray;

    .line 26
    .line 27
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 31
    .line 32
    new-instance p3, Landroid/util/SparseIntArray;

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    invoke-direct {p3, v0}, Landroid/util/SparseIntArray;-><init>(I)V

    .line 36
    .line 37
    .line 38
    monitor-enter p0

    .line 39
    :try_start_26
    monitor-enter p0
    :try_end_27
    .catchall {:try_start_26 .. :try_end_27} :catchall_7c

    .line 40
    :try_start_27
    invoke-virtual {p1}, Landroid/util/SparseArray;->clear()V

    .line 41
    .line 42
    .line 43
    iget-object p1, p2, Lin/u;->c:Landroid/util/SparseIntArray;

    .line 44
    .line 45
    if-eqz p1, :cond_5c

    .line 46
    .line 47
    move p2, v0

    .line 48
    :goto_2f
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->size()I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    if-ge p2, v1, :cond_59

    .line 53
    .line 54
    invoke-virtual {p1, p2}, Landroid/util/SparseIntArray;->keyAt(I)I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    invoke-virtual {p1, p2}, Landroid/util/SparseIntArray;->valueAt(I)I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    invoke-virtual {p3, v1, v0}, Landroid/util/SparseIntArray;->get(II)I

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    iget-object v4, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 67
    .line 68
    new-instance v5, Lin/f;

    .line 69
    .line 70
    invoke-virtual {p0, v1}, Lin/b;->h(I)I

    .line 71
    .line 72
    .line 73
    move-result v6

    .line 74
    iget-object v7, p0, Lin/b;->i:Lin/u;

    .line 75
    .line 76
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    invoke-direct {v5, v6, v2, v3}, Lin/f;-><init>(III)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v4, v1, v5}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    add-int/lit8 p2, p2, 0x1

    .line 86
    .line 87
    goto :goto_2f

    .line 88
    :catchall_57
    move-exception p1

    .line 89
    goto :goto_7e

    .line 90
    :cond_59
    iput-boolean v0, p0, Lin/b;->x:Z

    .line 91
    .line 92
    goto :goto_5f

    .line 93
    :cond_5c
    const/4 p1, 0x1

    .line 94
    iput-boolean p1, p0, Lin/b;->x:Z
    :try_end_5f
    .catchall {:try_start_27 .. :try_end_5f} :catchall_57

    .line 95
    .line 96
    :goto_5f
    :try_start_5f
    monitor-exit p0
    :try_end_60
    .catchall {:try_start_5f .. :try_end_60} :catchall_7c

    .line 97
    monitor-exit p0

    .line 98
    new-instance p1, Ljava/util/IdentityHashMap;

    .line 99
    .line 100
    invoke-direct {p1}, Ljava/util/IdentityHashMap;-><init>()V

    .line 101
    .line 102
    .line 103
    invoke-static {p1}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    iput-object p1, p0, Lin/b;->w:Ljava/util/Set;

    .line 108
    .line 109
    new-instance p1, Landroidx/core/view/t;

    .line 110
    .line 111
    const/4 p2, 0x7

    .line 112
    invoke-direct {p1, p2}, Landroidx/core/view/t;-><init>(I)V

    .line 113
    .line 114
    .line 115
    iput-object p1, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 116
    .line 117
    new-instance p1, Landroidx/core/view/t;

    .line 118
    .line 119
    invoke-direct {p1, p2}, Landroidx/core/view/t;-><init>(I)V

    .line 120
    .line 121
    .line 122
    iput-object p1, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 123
    .line 124
    return-void

    .line 125
    :catchall_7c
    move-exception p1

    .line 126
    goto :goto_80

    .line 127
    :goto_7e
    :try_start_7e
    monitor-exit p0
    :try_end_7f
    .catchall {:try_start_7e .. :try_end_7f} :catchall_57

    .line 128
    :try_start_7f
    throw p1

    .line 129
    :goto_80
    monitor-exit p0
    :try_end_81
    .catchall {:try_start_7f .. :try_end_81} :catchall_7c

    .line 130
    throw p1
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .registers 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Lin/b;->g(Ljava/lang/Object;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual {p0, v0}, Lin/b;->h(I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    monitor-enter p0

    .line 13
    :try_start_c
    monitor-enter p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_3f

    .line 14
    :try_start_d
    iget-object v2, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 15
    .line 16
    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    check-cast v2, Lin/f;
    :try_end_15
    .catchall {:try_start_d .. :try_end_15} :catchall_e9

    .line 21
    .line 22
    :try_start_15
    monitor-exit p0

    .line 23
    iget-object v3, p0, Lin/b;->w:Ljava/util/Set;

    .line 24
    .line 25
    invoke-interface {v3, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-nez v3, :cond_42

    .line 30
    .line 31
    iget-object v1, p0, Lin/b;->d:Ljava/lang/Class;

    .line 32
    .line 33
    const-string v2, "release (free, value unrecognized) (object, size) = (%x, %s)"

    .line 34
    .line 35
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    filled-new-array {v3, v0}, [Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-static {v1, v2, v0}, Lgl/a;->e(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0, p1}, Lin/b;->d(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, Lin/b;->K:Lin/v;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    goto/16 :goto_e4

    .line 63
    .line 64
    :catchall_3f
    move-exception p1

    .line 65
    goto/16 :goto_ec

    .line 66
    .line 67
    :cond_42
    const/4 v3, 0x2

    .line 68
    const/4 v4, 0x1

    .line 69
    if-eqz v2, :cond_ab

    .line 70
    .line 71
    iget v5, v2, Lin/f;->d:I

    .line 72
    .line 73
    iget-object v6, v2, Lin/f;->c:Ljava/util/LinkedList;

    .line 74
    .line 75
    invoke-virtual {v6}, Ljava/util/LinkedList;->size()I

    .line 76
    .line 77
    .line 78
    move-result v6

    .line 79
    add-int/2addr v6, v5

    .line 80
    iget v5, v2, Lin/f;->b:I

    .line 81
    .line 82
    if-le v6, v5, :cond_54

    .line 83
    .line 84
    goto :goto_ab

    .line 85
    :cond_54
    invoke-virtual {p0}, Lin/b;->j()Z

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    if-nez v5, :cond_ab

    .line 90
    .line 91
    invoke-virtual {p0, p1}, Lin/b;->k(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    if-nez v5, :cond_61

    .line 96
    .line 97
    goto :goto_ab

    .line 98
    :cond_61
    iget v5, v2, Lin/f;->d:I

    .line 99
    .line 100
    if-lez v5, :cond_6e

    .line 101
    .line 102
    sub-int/2addr v5, v4

    .line 103
    iput v5, v2, Lin/f;->d:I

    .line 104
    .line 105
    iget-object v2, v2, Lin/f;->c:Ljava/util/LinkedList;

    .line 106
    .line 107
    invoke-virtual {v2, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    goto :goto_79

    .line 111
    :cond_6e
    const-string v2, "BUCKET"

    .line 112
    .line 113
    const-string v5, "Tried to release value %s from an empty bucket!"

    .line 114
    .line 115
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    invoke-static {v2, v5, v6}, Lgl/a;->i(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :goto_79
    iget-object v2, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 123
    .line 124
    iget v5, v2, Landroidx/core/view/t;->b:I

    .line 125
    .line 126
    add-int/2addr v5, v4

    .line 127
    iput v5, v2, Landroidx/core/view/t;->b:I

    .line 128
    .line 129
    iget v4, v2, Landroidx/core/view/t;->c:I

    .line 130
    .line 131
    add-int/2addr v4, v1

    .line 132
    iput v4, v2, Landroidx/core/view/t;->c:I

    .line 133
    .line 134
    iget-object v2, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 135
    .line 136
    invoke-virtual {v2, v1}, Landroidx/core/view/t;->a(I)V

    .line 137
    .line 138
    .line 139
    iget-object v1, p0, Lin/b;->K:Lin/v;

    .line 140
    .line 141
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 142
    .line 143
    .line 144
    sget-object v1, Lgl/a;->a:Lgl/c;

    .line 145
    .line 146
    invoke-interface {v1, v3}, Lgl/c;->L(I)Z

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    if-eqz v1, :cond_e4

    .line 151
    .line 152
    iget-object v1, p0, Lin/b;->d:Ljava/lang/Class;

    .line 153
    .line 154
    const-string v2, "release (reuse) (object, size) = (%x, %s)"

    .line 155
    .line 156
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 157
    .line 158
    .line 159
    move-result p1

    .line 160
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    invoke-static {v1, v2, p1, v0}, Lgl/a;->k(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    goto :goto_e4

    .line 172
    :cond_ab
    :goto_ab
    if-eqz v2, :cond_bc

    .line 173
    .line 174
    iget v5, v2, Lin/f;->d:I

    .line 175
    .line 176
    if-lez v5, :cond_b3

    .line 177
    .line 178
    move v5, v4

    .line 179
    goto :goto_b4

    .line 180
    :cond_b3
    const/4 v5, 0x0

    .line 181
    :goto_b4
    invoke-static {v5}, Lfl/j;->e(Z)V

    .line 182
    .line 183
    .line 184
    iget v5, v2, Lin/f;->d:I

    .line 185
    .line 186
    sub-int/2addr v5, v4

    .line 187
    iput v5, v2, Lin/f;->d:I

    .line 188
    .line 189
    :cond_bc
    sget-object v2, Lgl/a;->a:Lgl/c;

    .line 190
    .line 191
    invoke-interface {v2, v3}, Lgl/c;->L(I)Z

    .line 192
    .line 193
    .line 194
    move-result v2

    .line 195
    if-eqz v2, :cond_d7

    .line 196
    .line 197
    iget-object v2, p0, Lin/b;->d:Ljava/lang/Class;

    .line 198
    .line 199
    const-string v3, "release (free) (object, size) = (%x, %s)"

    .line 200
    .line 201
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    invoke-static {v2, v3, v4, v0}, Lgl/a;->k(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_d7
    invoke-virtual {p0, p1}, Lin/b;->d(Ljava/lang/Object;)V

    .line 217
    .line 218
    .line 219
    iget-object p1, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 220
    .line 221
    invoke-virtual {p1, v1}, Landroidx/core/view/t;->a(I)V

    .line 222
    .line 223
    .line 224
    iget-object p1, p0, Lin/b;->K:Lin/v;

    .line 225
    .line 226
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 227
    .line 228
    .line 229
    :cond_e4
    :goto_e4
    invoke-virtual {p0}, Lin/b;->l()V

    .line 230
    .line 231
    .line 232
    monitor-exit p0
    :try_end_e8
    .catchall {:try_start_15 .. :try_end_e8} :catchall_3f

    .line 233
    return-void

    .line 234
    :catchall_e9
    move-exception p1

    .line 235
    :try_start_ea
    monitor-exit p0
    :try_end_eb
    .catchall {:try_start_ea .. :try_end_eb} :catchall_e9

    .line 236
    :try_start_eb
    throw p1

    .line 237
    :goto_ec
    monitor-exit p0
    :try_end_ed
    .catchall {:try_start_eb .. :try_end_ed} :catchall_3f

    .line 238
    throw p1
.end method

.method public abstract b(I)Ljava/lang/Object;
.end method

.method public final declared-synchronized c(I)Z
    .registers 7

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lin/b;->i:Lin/u;

    .line 3
    .line 4
    iget v1, v0, Lin/u;->a:I

    .line 5
    .line 6
    iget-object v2, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 7
    .line 8
    iget v2, v2, Landroidx/core/view/t;->c:I

    .line 9
    .line 10
    sub-int v3, v1, v2

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    if-le p1, v3, :cond_17

    .line 14
    .line 15
    iget-object p1, p0, Lin/b;->K:Lin/v;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_13
    .catchall {:try_start_1 .. :try_end_13} :catchall_15

    .line 18
    .line 19
    .line 20
    monitor-exit p0

    .line 21
    return v4

    .line 22
    :catchall_15
    move-exception p1

    .line 23
    goto :goto_3c

    .line 24
    :cond_17
    :try_start_17
    iget v0, v0, Lin/u;->b:I

    .line 25
    .line 26
    iget-object v3, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 27
    .line 28
    iget v3, v3, Landroidx/core/view/t;->c:I

    .line 29
    .line 30
    add-int/2addr v2, v3

    .line 31
    sub-int v2, v0, v2

    .line 32
    .line 33
    if-le p1, v2, :cond_26

    .line 34
    .line 35
    sub-int/2addr v0, p1

    .line 36
    invoke-virtual {p0, v0}, Lin/b;->m(I)V

    .line 37
    .line 38
    .line 39
    :cond_26
    iget-object v0, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 40
    .line 41
    iget v0, v0, Landroidx/core/view/t;->c:I

    .line 42
    .line 43
    iget-object v2, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 44
    .line 45
    iget v2, v2, Landroidx/core/view/t;->c:I

    .line 46
    .line 47
    add-int/2addr v0, v2

    .line 48
    sub-int/2addr v1, v0

    .line 49
    if-le p1, v1, :cond_39

    .line 50
    .line 51
    iget-object p1, p0, Lin/b;->K:Lin/v;

    .line 52
    .line 53
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_37
    .catchall {:try_start_17 .. :try_end_37} :catchall_15

    .line 54
    .line 55
    .line 56
    monitor-exit p0

    .line 57
    return v4

    .line 58
    :cond_39
    monitor-exit p0

    .line 59
    const/4 p1, 0x1

    .line 60
    return p1

    .line 61
    :goto_3c
    :try_start_3c
    monitor-exit p0
    :try_end_3d
    .catchall {:try_start_3c .. :try_end_3d} :catchall_15

    .line 62
    throw p1
.end method

.method public abstract d(Ljava/lang/Object;)V
.end method

.method public final declared-synchronized e(I)Lin/f;
    .registers 6

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 3
    .line 4
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lin/f;

    .line 9
    .line 10
    if-nez v0, :cond_40

    .line 11
    .line 12
    iget-boolean v1, p0, Lin/b;->x:Z

    .line 13
    .line 14
    if-nez v1, :cond_10

    .line 15
    .line 16
    goto :goto_40

    .line 17
    :cond_10
    sget-object v0, Lgl/a;->a:Lgl/c;

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    invoke-interface {v0, v1}, Lgl/c;->L(I)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_27

    .line 25
    .line 26
    iget-object v0, p0, Lin/b;->d:Ljava/lang/Class;

    .line 27
    .line 28
    const-string v1, "creating new bucket %s"

    .line 29
    .line 30
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-static {v1, v2, v0}, Lgl/a;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V

    .line 35
    .line 36
    .line 37
    goto :goto_27

    .line 38
    :catchall_25
    move-exception p1

    .line 39
    goto :goto_42

    .line 40
    :cond_27
    :goto_27
    new-instance v0, Lin/f;

    .line 41
    .line 42
    invoke-virtual {p0, p1}, Lin/b;->h(I)I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    iget-object v2, p0, Lin/b;->i:Lin/u;

    .line 47
    .line 48
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    const v2, 0x7fffffff

    .line 52
    .line 53
    .line 54
    const/4 v3, 0x0

    .line 55
    invoke-direct {v0, v1, v2, v3}, Lin/f;-><init>(III)V

    .line 56
    .line 57
    .line 58
    iget-object v1, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 59
    .line 60
    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    :try_end_3e
    .catchall {:try_start_1 .. :try_end_3e} :catchall_25

    .line 61
    .line 62
    .line 63
    monitor-exit p0

    .line 64
    return-object v0

    .line 65
    :cond_40
    :goto_40
    monitor-exit p0

    .line 66
    return-object v0

    .line 67
    :goto_42
    :try_start_42
    monitor-exit p0
    :try_end_43
    .catchall {:try_start_42 .. :try_end_43} :catchall_25

    .line 68
    throw p1
.end method

.method public abstract f(I)I
.end method

.method public abstract g(Ljava/lang/Object;)I
.end method

.method public final get(I)Ljava/lang/Object;
    .registers 9

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0}, Lin/b;->j()Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    const/4 v1, 0x0

    .line 7
    const/4 v2, 0x1

    .line 8
    if-eqz v0, :cond_15

    .line 9
    .line 10
    iget-object v0, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 11
    .line 12
    iget v0, v0, Landroidx/core/view/t;->c:I

    .line 13
    .line 14
    if-nez v0, :cond_10

    .line 15
    .line 16
    goto :goto_15

    .line 17
    :cond_10
    move v0, v1

    .line 18
    goto :goto_16

    .line 19
    :catchall_12
    move-exception p1

    .line 20
    goto/16 :goto_133

    .line 21
    .line 22
    :cond_15
    :goto_15
    move v0, v2

    .line 23
    :goto_16
    invoke-static {v0}, Lfl/j;->e(Z)V
    :try_end_19
    .catchall {:try_start_1 .. :try_end_19} :catchall_12

    .line 24
    .line 25
    .line 26
    monitor-exit p0

    .line 27
    invoke-virtual {p0, p1}, Lin/b;->f(I)I

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    monitor-enter p0

    .line 32
    :try_start_1f
    invoke-virtual {p0, p1}, Lin/b;->e(I)Lin/f;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const/4 v3, 0x2

    .line 37
    if-eqz v0, :cond_77

    .line 38
    .line 39
    invoke-virtual {p0, v0}, Lin/b;->i(Lin/f;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    if-eqz v4, :cond_77

    .line 44
    .line 45
    iget-object p1, p0, Lin/b;->w:Ljava/util/Set;

    .line 46
    .line 47
    invoke-interface {p1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    invoke-static {p1}, Lfl/j;->e(Z)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0, v4}, Lin/b;->g(Ljava/lang/Object;)I

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    invoke-virtual {p0, p1}, Lin/b;->h(I)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    iget-object v1, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 63
    .line 64
    iget v5, v1, Landroidx/core/view/t;->b:I

    .line 65
    .line 66
    add-int/2addr v5, v2

    .line 67
    iput v5, v1, Landroidx/core/view/t;->b:I

    .line 68
    .line 69
    iget v2, v1, Landroidx/core/view/t;->c:I

    .line 70
    .line 71
    add-int/2addr v2, v0

    .line 72
    iput v2, v1, Landroidx/core/view/t;->c:I

    .line 73
    .line 74
    iget-object v1, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 75
    .line 76
    invoke-virtual {v1, v0}, Landroidx/core/view/t;->a(I)V

    .line 77
    .line 78
    .line 79
    iget-object v0, p0, Lin/b;->K:Lin/v;

    .line 80
    .line 81
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    .line 83
    .line 84
    invoke-virtual {p0}, Lin/b;->l()V

    .line 85
    .line 86
    .line 87
    sget-object v0, Lgl/a;->a:Lgl/c;

    .line 88
    .line 89
    invoke-interface {v0, v3}, Lgl/c;->L(I)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_75

    .line 94
    .line 95
    iget-object v0, p0, Lin/b;->d:Ljava/lang/Class;

    .line 96
    .line 97
    const-string v1, "get (reuse) (object, size) = (%x, %s)"

    .line 98
    .line 99
    invoke-static {v4}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    invoke-static {v0, v1, v2, p1}, Lgl/a;->k(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    goto :goto_75

    .line 115
    :catchall_72
    move-exception p1

    .line 116
    goto/16 :goto_131

    .line 117
    .line 118
    :cond_75
    :goto_75
    monitor-exit p0

    .line 119
    return-object v4

    .line 120
    :cond_77
    invoke-virtual {p0, p1}, Lin/b;->h(I)I

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    invoke-virtual {p0, v4}, Lin/b;->c(I)Z

    .line 125
    .line 126
    .line 127
    move-result v5

    .line 128
    if-eqz v5, :cond_11f

    .line 129
    .line 130
    iget-object v5, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 131
    .line 132
    iget v6, v5, Landroidx/core/view/t;->b:I

    .line 133
    .line 134
    add-int/2addr v6, v2

    .line 135
    iput v6, v5, Landroidx/core/view/t;->b:I

    .line 136
    .line 137
    iget v6, v5, Landroidx/core/view/t;->c:I

    .line 138
    .line 139
    add-int/2addr v6, v4

    .line 140
    iput v6, v5, Landroidx/core/view/t;->c:I

    .line 141
    .line 142
    if-eqz v0, :cond_94

    .line 143
    .line 144
    iget v5, v0, Lin/f;->d:I

    .line 145
    .line 146
    add-int/2addr v5, v2

    .line 147
    iput v5, v0, Lin/f;->d:I

    .line 148
    .line 149
    :cond_94
    monitor-exit p0
    :try_end_95
    .catchall {:try_start_1f .. :try_end_95} :catchall_72

    .line 150
    :try_start_95
    invoke-virtual {p0, p1}, Lin/b;->b(I)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v0
    :try_end_99
    .catchall {:try_start_95 .. :try_end_99} :catchall_9a

    .line 154
    goto :goto_c6

    .line 155
    :catchall_9a
    move-exception v0

    .line 156
    monitor-enter p0

    .line 157
    :try_start_9c
    iget-object v5, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 158
    .line 159
    invoke-virtual {v5, v4}, Landroidx/core/view/t;->a(I)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {p0, p1}, Lin/b;->e(I)Lin/f;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    if-eqz v4, :cond_b4

    .line 167
    .line 168
    iget v5, v4, Lin/f;->d:I

    .line 169
    .line 170
    if-lez v5, :cond_ac

    .line 171
    .line 172
    move v1, v2

    .line 173
    :cond_ac
    invoke-static {v1}, Lfl/j;->e(Z)V

    .line 174
    .line 175
    .line 176
    iget v1, v4, Lin/f;->d:I

    .line 177
    .line 178
    sub-int/2addr v1, v2

    .line 179
    iput v1, v4, Lin/f;->d:I

    .line 180
    .line 181
    :cond_b4
    monitor-exit p0
    :try_end_b5
    .catchall {:try_start_9c .. :try_end_b5} :catchall_11c

    .line 182
    const-class v1, Ljava/lang/Error;

    .line 183
    .line 184
    invoke-virtual {v1, v0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    if-nez v2, :cond_115

    .line 189
    .line 190
    const-class v1, Ljava/lang/RuntimeException;

    .line 191
    .line 192
    invoke-virtual {v1, v0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result v2

    .line 196
    if-nez v2, :cond_10e

    .line 197
    .line 198
    const/4 v0, 0x0

    .line 199
    :goto_c6
    monitor-enter p0

    .line 200
    :try_start_c7
    iget-object v1, p0, Lin/b;->w:Ljava/util/Set;

    .line 201
    .line 202
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v1

    .line 206
    invoke-static {v1}, Lfl/j;->e(Z)V

    .line 207
    .line 208
    .line 209
    monitor-enter p0
    :try_end_d1
    .catchall {:try_start_c7 .. :try_end_d1} :catchall_106

    .line 210
    :try_start_d1
    invoke-virtual {p0}, Lin/b;->j()Z

    .line 211
    .line 212
    .line 213
    move-result v1

    .line 214
    if-eqz v1, :cond_e1

    .line 215
    .line 216
    iget-object v1, p0, Lin/b;->i:Lin/u;

    .line 217
    .line 218
    iget v1, v1, Lin/u;->b:I

    .line 219
    .line 220
    invoke-virtual {p0, v1}, Lin/b;->m(I)V
    :try_end_de
    .catchall {:try_start_d1 .. :try_end_de} :catchall_df

    .line 221
    .line 222
    .line 223
    goto :goto_e1

    .line 224
    :catchall_df
    move-exception p1

    .line 225
    goto :goto_10a

    .line 226
    :cond_e1
    :goto_e1
    :try_start_e1
    monitor-exit p0

    .line 227
    iget-object v1, p0, Lin/b;->K:Lin/v;

    .line 228
    .line 229
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 230
    .line 231
    .line 232
    invoke-virtual {p0}, Lin/b;->l()V

    .line 233
    .line 234
    .line 235
    sget-object v1, Lgl/a;->a:Lgl/c;

    .line 236
    .line 237
    invoke-interface {v1, v3}, Lgl/c;->L(I)Z

    .line 238
    .line 239
    .line 240
    move-result v1

    .line 241
    if-eqz v1, :cond_108

    .line 242
    .line 243
    iget-object v1, p0, Lin/b;->d:Ljava/lang/Class;

    .line 244
    .line 245
    const-string v2, "get (alloc) (object, size) = (%x, %s)"

    .line 246
    .line 247
    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 248
    .line 249
    .line 250
    move-result v3

    .line 251
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    invoke-static {v1, v2, v3, p1}, Lgl/a;->k(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 260
    .line 261
    .line 262
    goto :goto_108

    .line 263
    :catchall_106
    move-exception p1

    .line 264
    goto :goto_10c

    .line 265
    :cond_108
    :goto_108
    monitor-exit p0
    :try_end_109
    .catchall {:try_start_e1 .. :try_end_109} :catchall_106

    .line 266
    return-object v0

    .line 267
    :goto_10a
    :try_start_10a
    monitor-exit p0
    :try_end_10b
    .catchall {:try_start_10a .. :try_end_10b} :catchall_df

    .line 268
    :try_start_10b
    throw p1

    .line 269
    :goto_10c
    monitor-exit p0
    :try_end_10d
    .catchall {:try_start_10b .. :try_end_10d} :catchall_106

    .line 270
    throw p1

    .line 271
    :cond_10e
    invoke-virtual {v1, v0}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    move-result-object p1

    .line 275
    check-cast p1, Ljava/lang/Throwable;

    .line 276
    .line 277
    throw p1

    .line 278
    :cond_115
    invoke-virtual {v1, v0}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object p1

    .line 282
    check-cast p1, Ljava/lang/Throwable;

    .line 283
    .line 284
    throw p1

    .line 285
    :catchall_11c
    move-exception p1

    .line 286
    :try_start_11d
    monitor-exit p0
    :try_end_11e
    .catchall {:try_start_11d .. :try_end_11e} :catchall_11c

    .line 287
    throw p1

    .line 288
    :cond_11f
    :try_start_11f
    new-instance p1, Lan/g;

    .line 289
    .line 290
    iget-object v0, p0, Lin/b;->i:Lin/u;

    .line 291
    .line 292
    iget v0, v0, Lin/u;->a:I

    .line 293
    .line 294
    iget-object v1, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 295
    .line 296
    iget v1, v1, Landroidx/core/view/t;->c:I

    .line 297
    .line 298
    iget-object v2, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 299
    .line 300
    iget v2, v2, Landroidx/core/view/t;->c:I

    .line 301
    .line 302
    invoke-direct {p1, v0, v1, v2, v4}, Lan/g;-><init>(IIII)V

    .line 303
    .line 304
    .line 305
    throw p1

    .line 306
    :goto_131
    monitor-exit p0
    :try_end_132
    .catchall {:try_start_11f .. :try_end_132} :catchall_72

    .line 307
    throw p1

    .line 308
    :goto_133
    :try_start_133
    monitor-exit p0
    :try_end_134
    .catchall {:try_start_133 .. :try_end_134} :catchall_12

    .line 309
    throw p1
.end method

.method public abstract h(I)I
.end method

.method public declared-synchronized i(Lin/f;)Ljava/lang/Object;
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p1}, Lin/f;->a()Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_d

    .line 7
    .line 8
    iget v1, p1, Lin/f;->d:I

    .line 9
    .line 10
    add-int/lit8 v1, v1, 0x1

    .line 11
    .line 12
    iput v1, p1, Lin/f;->d:I
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_11

    .line 13
    .line 14
    :cond_d
    monitor-exit p0

    .line 15
    return-object v0

    .line 16
    :goto_f
    :try_start_f
    monitor-exit p0
    :try_end_10
    .catchall {:try_start_f .. :try_end_10} :catchall_11

    .line 17
    throw p1

    .line 18
    :catchall_11
    move-exception p1

    .line 19
    goto :goto_f
.end method

.method public final declared-synchronized j()Z
    .registers 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 3
    .line 4
    iget v0, v0, Landroidx/core/view/t;->c:I

    .line 5
    .line 6
    iget-object v1, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 7
    .line 8
    iget v1, v1, Landroidx/core/view/t;->c:I

    .line 9
    .line 10
    add-int/2addr v0, v1

    .line 11
    iget-object v1, p0, Lin/b;->i:Lin/u;

    .line 12
    .line 13
    iget v1, v1, Lin/u;->b:I

    .line 14
    .line 15
    if-le v0, v1, :cond_12

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x0

    .line 20
    :goto_13
    if-eqz v0, :cond_1d

    .line 21
    .line 22
    iget-object v1, p0, Lin/b;->K:Lin/v;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1a
    .catchall {:try_start_1 .. :try_end_1a} :catchall_1b

    .line 25
    .line 26
    .line 27
    goto :goto_1d

    .line 28
    :catchall_1b
    move-exception v0

    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    :goto_1d
    monitor-exit p0

    .line 31
    return v0

    .line 32
    :goto_1f
    :try_start_1f
    monitor-exit p0
    :try_end_20
    .catchall {:try_start_1f .. :try_end_20} :catchall_1b

    .line 33
    throw v0
.end method

.method public k(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x1

    .line 5
    return p1
.end method

.method public final l()V
    .registers 7

    .line 1
    sget-object v0, Lgl/a;->a:Lgl/c;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-interface {v0, v1}, Lgl/c;->L(I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_43

    .line 9
    .line 10
    iget-object v0, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 11
    .line 12
    iget v2, v0, Landroidx/core/view/t;->b:I

    .line 13
    .line 14
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iget v0, v0, Landroidx/core/view/t;->c:I

    .line 19
    .line 20
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iget-object v3, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 25
    .line 26
    iget v4, v3, Landroidx/core/view/t;->b:I

    .line 27
    .line 28
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    iget v3, v3, Landroidx/core/view/t;->c:I

    .line 33
    .line 34
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    sget-object v5, Lgl/a;->a:Lgl/c;

    .line 39
    .line 40
    invoke-interface {v5, v1}, Lgl/c;->L(I)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-eqz v1, :cond_43

    .line 45
    .line 46
    sget-object v1, Lgl/a;->a:Lgl/c;

    .line 47
    .line 48
    iget-object v5, p0, Lin/b;->d:Ljava/lang/Class;

    .line 49
    .line 50
    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    filled-new-array {v2, v0, v4, v3}, [Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    const/4 v2, 0x0

    .line 59
    const-string v3, "Used = (%d, %d); Free = (%d, %d)"

    .line 60
    .line 61
    invoke-static {v2, v3, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-interface {v1, v5, v0}, Lgl/c;->A(Ljava/lang/String;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    :cond_43
    return-void
.end method

.method public final declared-synchronized m(I)V
    .registers 9

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 3
    .line 4
    iget v0, v0, Landroidx/core/view/t;->c:I

    .line 5
    .line 6
    iget-object v1, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 7
    .line 8
    iget v1, v1, Landroidx/core/view/t;->c:I

    .line 9
    .line 10
    add-int/2addr v0, v1

    .line 11
    sub-int/2addr v0, p1

    .line 12
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 13
    .line 14
    .line 15
    move-result v0
    :try_end_f
    .catchall {:try_start_1 .. :try_end_f} :catchall_39

    .line 16
    if-gtz v0, :cond_13

    .line 17
    .line 18
    monitor-exit p0

    .line 19
    return-void

    .line 20
    :cond_13
    :try_start_13
    sget-object v1, Lgl/a;->a:Lgl/c;

    .line 21
    .line 22
    const/4 v2, 0x2

    .line 23
    invoke-interface {v1, v2}, Lgl/c;->L(I)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_3b

    .line 28
    .line 29
    iget-object v1, p0, Lin/b;->d:Ljava/lang/Class;

    .line 30
    .line 31
    const-string v3, "trimToSize: TargetSize = %d; Initial Size = %d; Bytes to free = %d"

    .line 32
    .line 33
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    iget-object v5, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 38
    .line 39
    iget v5, v5, Landroidx/core/view/t;->c:I

    .line 40
    .line 41
    iget-object v6, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 42
    .line 43
    iget v6, v6, Landroidx/core/view/t;->c:I

    .line 44
    .line 45
    add-int/2addr v5, v6

    .line 46
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 51
    .line 52
    .line 53
    move-result-object v6

    .line 54
    invoke-static {v1, v3, v4, v5, v6}, Lgl/a;->l(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    goto :goto_3b

    .line 58
    :catchall_39
    move-exception p1

    .line 59
    goto :goto_92

    .line 60
    :cond_3b
    :goto_3b
    invoke-virtual {p0}, Lin/b;->l()V

    .line 61
    .line 62
    .line 63
    const/4 v1, 0x0

    .line 64
    :goto_3f
    iget-object v3, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 65
    .line 66
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-ge v1, v3, :cond_6d

    .line 71
    .line 72
    if-gtz v0, :cond_4a

    .line 73
    .line 74
    goto :goto_6d

    .line 75
    :cond_4a
    iget-object v3, p0, Lin/b;->v:Landroid/util/SparseArray;

    .line 76
    .line 77
    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    check-cast v3, Lin/f;

    .line 82
    .line 83
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    :goto_55
    if-lez v0, :cond_6a

    .line 87
    .line 88
    invoke-virtual {v3}, Lin/f;->a()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    if-nez v4, :cond_5e

    .line 93
    .line 94
    goto :goto_6a

    .line 95
    :cond_5e
    invoke-virtual {p0, v4}, Lin/b;->d(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    iget v4, v3, Lin/f;->a:I

    .line 99
    .line 100
    sub-int/2addr v0, v4

    .line 101
    iget-object v5, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 102
    .line 103
    invoke-virtual {v5, v4}, Landroidx/core/view/t;->a(I)V

    .line 104
    .line 105
    .line 106
    goto :goto_55

    .line 107
    :cond_6a
    :goto_6a
    add-int/lit8 v1, v1, 0x1

    .line 108
    .line 109
    goto :goto_3f

    .line 110
    :cond_6d
    :goto_6d
    invoke-virtual {p0}, Lin/b;->l()V

    .line 111
    .line 112
    .line 113
    sget-object v0, Lgl/a;->a:Lgl/c;

    .line 114
    .line 115
    invoke-interface {v0, v2}, Lgl/c;->L(I)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_90

    .line 120
    .line 121
    iget-object v0, p0, Lin/b;->d:Ljava/lang/Class;

    .line 122
    .line 123
    const-string v1, "trimToSize: TargetSize = %d; Final Size = %d"

    .line 124
    .line 125
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    iget-object v2, p0, Lin/b;->y:Landroidx/core/view/t;

    .line 130
    .line 131
    iget v2, v2, Landroidx/core/view/t;->c:I

    .line 132
    .line 133
    iget-object v3, p0, Lin/b;->J:Landroidx/core/view/t;

    .line 134
    .line 135
    iget v3, v3, Landroidx/core/view/t;->c:I

    .line 136
    .line 137
    add-int/2addr v2, v3

    .line 138
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    invoke-static {v0, v1, p1, v2}, Lgl/a;->k(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_90
    .catchall {:try_start_13 .. :try_end_90} :catchall_39

    .line 143
    .line 144
    .line 145
    :cond_90
    monitor-exit p0

    .line 146
    return-void

    .line 147
    :goto_92
    :try_start_92
    monitor-exit p0
    :try_end_93
    .catchall {:try_start_92 .. :try_end_93} :catchall_39

    .line 148
    throw p1
.end method
