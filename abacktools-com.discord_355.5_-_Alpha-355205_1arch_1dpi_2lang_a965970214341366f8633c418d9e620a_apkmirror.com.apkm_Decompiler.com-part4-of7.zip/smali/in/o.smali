###### Class in.o (in.o)
.class public interface abstract Lin/o;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c()J
.end method

.method public abstract close()V
.end method

.method public abstract d(I)B
.end method

.method public abstract g()Ljava/nio/ByteBuffer;
.end method

.method public abstract i(III[B)I
.end method

.method public abstract isClosed()Z
.end method

.method public abstract j(III[B)I
.end method

.method public abstract l(Lin/o;I)V
.end method

.method public abstract n()J
.end method

.method public abstract u()I
.end method
