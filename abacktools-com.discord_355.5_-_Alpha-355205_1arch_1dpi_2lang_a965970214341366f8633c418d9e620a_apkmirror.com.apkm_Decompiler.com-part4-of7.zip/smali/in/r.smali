###### Class in.r (in.r)
.class public final Lin/r;
.super Ljava/io/OutputStream;
.source "SourceFile"


# instance fields
.field public final d:Lin/p;

.field public e:Ljl/c;

.field public i:I


# direct methods
.method public constructor <init>(Lin/p;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/io/OutputStream;-><init>()V

    .line 2
    .line 3
    .line 4
    if-lez p2, :cond_17

    .line 5
    .line 6
    iput-object p1, p0, Lin/r;->d:Lin/p;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput v0, p0, Lin/r;->i:I

    .line 10
    .line 11
    invoke-virtual {p1, p2}, Lin/b;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p2

    .line 15
    sget-object v0, Ljl/b;->x:Lal/c;

    .line 16
    .line 17
    invoke-static {p2, p1, v0}, Ljl/b;->A(Ljava/lang/Object;Ljl/d;Ljl/a;)Ljl/c;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p0, Lin/r;->e:Ljl/c;

    .line 22
    .line 23
    return-void

    .line 24
    :cond_17
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    const-string p2, "Check failed."

    .line 27
    .line 28
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1
.end method


# virtual methods
.method public final c()V
    .registers 2

    .line 1
    :try_start_0
    invoke-super {p0}, Ljava/io/OutputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_3} :catch_4

    .line 2
    .line 3
    .line 4
    return-void

    .line 5
    :catch_4
    move-exception v0

    .line 6
    invoke-static {v0}, Lfl/j;->h(Ljava/lang/Throwable;)V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    throw v0
.end method

.method public final close()V
    .registers 2

    .line 1
    iget-object v0, p0, Lin/r;->e:Ljl/c;

    .line 2
    .line 3
    invoke-static {v0}, Ljl/b;->l(Ljl/b;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput-object v0, p0, Lin/r;->e:Ljl/c;

    .line 8
    .line 9
    const/4 v0, -0x1

    .line 10
    iput v0, p0, Lin/r;->i:I

    .line 11
    .line 12
    invoke-virtual {p0}, Lin/r;->c()V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final d()Lin/q;
    .registers 4

    .line 1
    iget-object v0, p0, Lin/r;->e:Ljl/c;

    .line 2
    .line 3
    invoke-static {v0}, Ljl/b;->x(Ljl/b;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1c

    .line 8
    .line 9
    new-instance v0, Lin/q;

    .line 10
    .line 11
    iget-object v1, p0, Lin/r;->e:Ljl/c;

    .line 12
    .line 13
    if-eqz v1, :cond_14

    .line 14
    .line 15
    iget v2, p0, Lin/r;->i:I

    .line 16
    .line 17
    invoke-direct {v0, v2, v1}, Lin/q;-><init>(ILjl/c;)V

    .line 18
    .line 19
    .line 20
    return-object v0

    .line 21
    :cond_14
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 22
    .line 23
    const-string v1, "Required value was null."

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v0

    .line 29
    :cond_1c
    new-instance v0, Lan/g;

    .line 30
    .line 31
    const-string v1, "OutputStream no longer valid"

    .line 32
    .line 33
    const/16 v2, 0xa

    .line 34
    .line 35
    invoke-direct {v0, v1, v2}, Lan/g;-><init>(Ljava/lang/String;I)V

    .line 36
    .line 37
    .line 38
    throw v0
.end method

.method public final write(I)V
    .registers 4

    int-to-byte p1, p1

    const/4 v0, 0x1

    .line 1
    new-array v0, v0, [B

    const/4 v1, 0x0

    aput-byte p1, v0, v1

    .line 2
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write([B)V

    return-void
.end method

.method public final write([BII)V
    .registers 9

    const-string v0, "buffer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    if-ltz p2, :cond_99

    if-ltz p3, :cond_99

    add-int v0, p2, p3

    .line 3
    array-length v1, p1

    if-gt v0, v1, :cond_99

    .line 4
    iget-object v0, p0, Lin/r;->e:Ljl/c;

    invoke-static {v0}, Ljl/b;->x(Ljl/b;)Z

    move-result v0

    const-string v1, "OutputStream no longer valid"

    if-eqz v0, :cond_91

    .line 5
    iget v0, p0, Lin/r;->i:I

    add-int/2addr v0, p3

    .line 6
    iget-object v2, p0, Lin/r;->e:Ljl/c;

    invoke-static {v2}, Ljl/b;->x(Ljl/b;)Z

    move-result v2

    if-eqz v2, :cond_89

    .line 7
    iget-object v1, p0, Lin/r;->e:Ljl/c;

    const-string v2, "Required value was null."

    if-eqz v1, :cond_83

    .line 8
    invoke-virtual {v1}, Ljl/b;->n()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lin/o;

    invoke-interface {v1}, Lin/o;->u()I

    move-result v1

    if-gt v0, v1, :cond_36

    goto :goto_62

    .line 9
    :cond_36
    iget-object v1, p0, Lin/r;->d:Lin/p;

    invoke-virtual {v1, v0}, Lin/b;->get(I)Ljava/lang/Object;

    move-result-object v0

    const-string v3, "get(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lin/o;

    .line 10
    iget-object v3, p0, Lin/r;->e:Ljl/c;

    if-eqz v3, :cond_7d

    .line 11
    invoke-virtual {v3}, Ljl/b;->n()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lin/o;

    iget v4, p0, Lin/r;->i:I

    invoke-interface {v3, v0, v4}, Lin/o;->l(Lin/o;I)V

    .line 12
    iget-object v3, p0, Lin/r;->e:Ljl/c;

    invoke-static {v3}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    invoke-virtual {v3}, Ljl/b;->close()V

    .line 13
    sget-object v3, Ljl/b;->x:Lal/c;

    invoke-static {v0, v1, v3}, Ljl/b;->A(Ljava/lang/Object;Ljl/d;Ljl/a;)Ljl/c;

    move-result-object v0

    .line 14
    iput-object v0, p0, Lin/r;->e:Ljl/c;

    .line 15
    :goto_62
    iget-object v0, p0, Lin/r;->e:Ljl/c;

    if-eqz v0, :cond_77

    invoke-virtual {v0}, Ljl/b;->n()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lin/o;

    iget v1, p0, Lin/r;->i:I

    invoke-interface {v0, v1, p2, p3, p1}, Lin/o;->j(III[B)I

    .line 16
    iget p1, p0, Lin/r;->i:I

    add-int/2addr p1, p3

    iput p1, p0, Lin/r;->i:I

    return-void

    .line 17
    :cond_77
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 18
    :cond_7d
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 19
    :cond_83
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 20
    :cond_89
    new-instance p1, Lan/g;

    const/16 p2, 0xa

    .line 21
    invoke-direct {p1, v1, p2}, Lan/g;-><init>(Ljava/lang/String;I)V

    .line 22
    throw p1

    .line 23
    :cond_91
    new-instance p1, Lan/g;

    const/16 p2, 0xa

    .line 24
    invoke-direct {p1, v1, p2}, Lan/g;-><init>(Ljava/lang/String;I)V

    .line 25
    throw p1

    .line 26
    :cond_99
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 27
    array-length p1, p1

    const-string v1, "; regionStart="

    const-string v2, "; regionLength="

    .line 28
    const-string v3, "length="

    invoke-static {p1, v3, p2, v1, v2}, La1/h;->m(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 29
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 30
    invoke-direct {v0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
