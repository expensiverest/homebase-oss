###### Class in.p (in.p)
.class public abstract Lin/p;
.super Lin/b;
.source "SourceFile"


# instance fields
.field public final L:[I


# direct methods
.method public constructor <init>(Lil/b;Lin/u;Lin/v;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lin/b;-><init>(Lil/b;Lin/u;Lin/v;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p2, Lin/u;->c:Landroid/util/SparseIntArray;

    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->size()I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    new-array p2, p2, [I

    .line 14
    .line 15
    iput-object p2, p0, Lin/p;->L:[I

    .line 16
    .line 17
    const/4 p2, 0x0

    .line 18
    :goto_11
    iget-object p3, p0, Lin/p;->L:[I

    .line 19
    .line 20
    array-length v0, p3

    .line 21
    if-ge p2, v0, :cond_1f

    .line 22
    .line 23
    invoke-virtual {p1, p2}, Landroid/util/SparseIntArray;->keyAt(I)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    aput v0, p3, p2

    .line 28
    .line 29
    add-int/lit8 p2, p2, 0x1

    .line 30
    .line 31
    goto :goto_11

    .line 32
    :cond_1f
    iget-object p1, p0, Lin/b;->e:Lil/b;

    .line 33
    .line 34
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    iget-object p1, p0, Lin/b;->K:Lin/v;

    .line 38
    .line 39
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Lin/o;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lin/o;->close()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final f(I)I
    .registers 6

    .line 1
    if-lez p1, :cond_11

    .line 2
    .line 3
    iget-object v0, p0, Lin/p;->L:[I

    .line 4
    .line 5
    array-length v1, v0

    .line 6
    const/4 v2, 0x0

    .line 7
    :goto_6
    if-ge v2, v1, :cond_10

    .line 8
    .line 9
    aget v3, v0, v2

    .line 10
    .line 11
    if-lt v3, p1, :cond_d

    .line 12
    .line 13
    return v3

    .line 14
    :cond_d
    add-int/lit8 v2, v2, 0x1

    .line 15
    .line 16
    goto :goto_6

    .line 17
    :cond_10
    return p1

    .line 18
    :cond_11
    new-instance v0, Lan/g;

    .line 19
    .line 20
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-direct {v0, p1}, Lan/g;-><init>(Ljava/lang/Integer;)V

    .line 25
    .line 26
    .line 27
    throw v0
.end method

.method public final g(Ljava/lang/Object;)I
    .registers 2

    .line 1
    check-cast p1, Lin/o;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lin/o;->u()I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    return p1
.end method

.method public final h(I)I
    .registers 2

    .line 1
    return p1
.end method

.method public final k(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    check-cast p1, Lin/o;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lin/o;->isClosed()Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    xor-int/lit8 p1, p1, 0x1

    .line 11
    .line 12
    return p1
.end method
