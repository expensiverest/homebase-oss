###### Class i6.b (i6.b)
.class public final Li6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/t;


# instance fields
.field public final synthetic d:I

.field public final e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Li6/b;->d:I

    iput-object p2, p0, Li6/b;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroidx/lifecycle/o;Ll20/h;)V
    .registers 4

    const/4 v0, 0x5

    iput v0, p0, Li6/b;->d:I

    const-string v0, "screenLifecycle"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "appearanceEventEmitter"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p2, p0, Li6/b;->e:Ljava/lang/Object;

    .line 4
    invoke-virtual {p1, p0}, Landroidx/lifecycle/o;->a(Landroidx/lifecycle/u;)V

    return-void
.end method


# virtual methods
.method public final c(Landroidx/lifecycle/v;Landroidx/lifecycle/m;)V
    .registers 8

    .line 1
    iget v0, p0, Li6/b;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1be

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li6/b;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, La20/c;

    .line 9
    .line 10
    sget-object v1, Ll20/g;->a:[I

    .line 11
    .line 12
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 13
    .line 14
    .line 15
    move-result p2

    .line 16
    aget p2, v1, p2

    .line 17
    .line 18
    packed-switch p2, :pswitch_data_1cc

    .line 19
    .line 20
    .line 21
    new-instance p1, Lan/g;

    .line 22
    .line 23
    const/4 p2, 0x0

    .line 24
    invoke-direct {p1, p2}, Lan/g;-><init>(Z)V

    .line 25
    .line 26
    .line 27
    throw p1

    .line 28
    :pswitch_1b
    invoke-interface {p1}, Landroidx/lifecycle/v;->i()Landroidx/lifecycle/x;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1, p0}, Landroidx/lifecycle/x;->b(Landroidx/lifecycle/u;)V

    .line 33
    .line 34
    .line 35
    goto :goto_32

    .line 36
    :pswitch_23
    invoke-interface {v0}, La20/c;->a()V

    .line 37
    .line 38
    .line 39
    goto :goto_32

    .line 40
    :pswitch_27
    invoke-interface {v0}, La20/c;->d()V

    .line 41
    .line 42
    .line 43
    goto :goto_32

    .line 44
    :pswitch_2b
    invoke-interface {v0}, La20/c;->b()V

    .line 45
    .line 46
    .line 47
    goto :goto_32

    .line 48
    :pswitch_2f
    invoke-interface {v0}, La20/c;->c()V

    .line 49
    .line 50
    .line 51
    :goto_32
    :pswitch_32
    return-void

    .line 52
    :pswitch_33
    iget-object p1, p0, Li6/b;->e:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p1, Le/j;

    .line 55
    .line 56
    iget-object p2, p1, Le/j;->w:Landroidx/lifecycle/c1;

    .line 57
    .line 58
    if-nez p2, :cond_52

    .line 59
    .line 60
    invoke-virtual {p1}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    check-cast p2, Le/f;

    .line 65
    .line 66
    if-eqz p2, :cond_47

    .line 67
    .line 68
    iget-object p2, p2, Le/f;->a:Landroidx/lifecycle/c1;

    .line 69
    .line 70
    iput-object p2, p1, Le/j;->w:Landroidx/lifecycle/c1;

    .line 71
    .line 72
    :cond_47
    iget-object p2, p1, Le/j;->w:Landroidx/lifecycle/c1;

    .line 73
    .line 74
    if-nez p2, :cond_52

    .line 75
    .line 76
    new-instance p2, Landroidx/lifecycle/c1;

    .line 77
    .line 78
    invoke-direct {p2}, Landroidx/lifecycle/c1;-><init>()V

    .line 79
    .line 80
    .line 81
    iput-object p2, p1, Le/j;->w:Landroidx/lifecycle/c1;

    .line 82
    .line 83
    :cond_52
    iget-object p1, p1, Le1/h;->d:Landroidx/lifecycle/x;

    .line 84
    .line 85
    invoke-virtual {p1, p0}, Landroidx/lifecycle/x;->b(Landroidx/lifecycle/u;)V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :pswitch_58
    sget-object p1, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;

    .line 90
    .line 91
    if-ne p2, p1, :cond_67

    .line 92
    .line 93
    iget-object p1, p0, Li6/b;->e:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast p1, Lb3/a0;

    .line 96
    .line 97
    iget-object p1, p1, Lb3/a0;->j0:Landroid/view/View;

    .line 98
    .line 99
    if-eqz p1, :cond_67

    .line 100
    .line 101
    invoke-virtual {p1}, Landroid/view/View;->cancelPendingInputEvents()V

    .line 102
    .line 103
    .line 104
    :cond_67
    return-void

    .line 105
    :pswitch_68
    sget-object v0, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;

    .line 106
    .line 107
    if-ne p2, v0, :cond_7b

    .line 108
    .line 109
    invoke-interface {p1}, Landroidx/lifecycle/v;->i()Landroidx/lifecycle/x;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-virtual {p1, p0}, Landroidx/lifecycle/x;->b(Landroidx/lifecycle/u;)V

    .line 114
    .line 115
    .line 116
    iget-object p1, p0, Li6/b;->e:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast p1, Landroidx/lifecycle/u0;

    .line 119
    .line 120
    invoke-virtual {p1}, Landroidx/lifecycle/u0;->b()V

    .line 121
    .line 122
    .line 123
    return-void

    .line 124
    :cond_7b
    new-instance p1, Ljava/lang/StringBuilder;

    .line 125
    .line 126
    const-string v0, "Next event must be ON_CREATE, it was "

    .line 127
    .line 128
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 139
    .line 140
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    throw p2

    .line 148
    :pswitch_93
    new-instance p1, Ljava/util/HashMap;

    .line 149
    .line 150
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 151
    .line 152
    .line 153
    iget-object p1, p0, Li6/b;->e:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast p1, [Landroidx/lifecycle/h;

    .line 156
    .line 157
    array-length p2, p1

    .line 158
    const/4 v0, 0x0

    .line 159
    const/4 v1, 0x0

    .line 160
    if-gtz p2, :cond_a8

    .line 161
    .line 162
    array-length p2, p1

    .line 163
    if-gtz p2, :cond_a5

    .line 164
    .line 165
    return-void

    .line 166
    :cond_a5
    aget-object p1, p1, v1

    .line 167
    .line 168
    throw v0

    .line 169
    :cond_a8
    aget-object p1, p1, v1

    .line 170
    .line 171
    throw v0

    .line 172
    :pswitch_ab
    iget-object v0, p0, Li6/b;->e:Ljava/lang/Object;

    .line 173
    .line 174
    check-cast v0, Li6/e;

    .line 175
    .line 176
    sget-object v1, Landroidx/lifecycle/m;->ON_CREATE:Landroidx/lifecycle/m;

    .line 177
    .line 178
    if-ne p2, v1, :cond_1b6

    .line 179
    .line 180
    invoke-interface {p1}, Landroidx/lifecycle/v;->i()Landroidx/lifecycle/x;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    invoke-virtual {p1, p0}, Landroidx/lifecycle/x;->b(Landroidx/lifecycle/u;)V

    .line 185
    .line 186
    .line 187
    invoke-interface {v0}, Li6/e;->g()Lz5/u;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    const-string p2, "androidx.savedstate.Restarter"

    .line 192
    .line 193
    invoke-virtual {p1, p2}, Lz5/u;->u(Ljava/lang/String;)Landroid/os/Bundle;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    if-nez p1, :cond_c8

    .line 198
    .line 199
    goto/16 :goto_1ad

    .line 200
    .line 201
    :cond_c8
    const-string p2, "classes_to_restore"

    .line 202
    .line 203
    invoke-virtual {p1, p2}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    if-eqz p1, :cond_1ae

    .line 208
    .line 209
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    :cond_d4
    :goto_d4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 214
    .line 215
    .line 216
    move-result p2

    .line 217
    if-eqz p2, :cond_1ad

    .line 218
    .line 219
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object p2

    .line 223
    check-cast p2, Ljava/lang/String;

    .line 224
    .line 225
    const-string v1, "Class "

    .line 226
    .line 227
    :try_start_e2
    const-class v2, Li6/b;

    .line 228
    .line 229
    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 230
    .line 231
    .line 232
    move-result-object v2

    .line 233
    const/4 v3, 0x0

    .line 234
    invoke-static {p2, v3, v2}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 235
    .line 236
    .line 237
    move-result-object v2

    .line 238
    const-class v3, Li6/c;

    .line 239
    .line 240
    invoke-virtual {v2, v3}, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;

    .line 241
    .line 242
    .line 243
    move-result-object v2

    .line 244
    invoke-static {v2}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V
    :try_end_f6
    .catch Ljava/lang/ClassNotFoundException; {:try_start_e2 .. :try_end_f6} :catch_1a0

    .line 245
    .line 246
    .line 247
    const/4 v3, 0x0

    .line 248
    :try_start_f7
    invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 249
    .line 250
    .line 251
    move-result-object v1
    :try_end_fb
    .catch Ljava/lang/NoSuchMethodException; {:try_start_f7 .. :try_end_fb} :catch_184

    .line 252
    const/4 v2, 0x1

    .line 253
    invoke-virtual {v1, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 254
    .line 255
    .line 256
    :try_start_ff
    invoke-virtual {v1, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object v1

    .line 260
    invoke-static {v1}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 261
    .line 262
    .line 263
    check-cast v1, Li6/c;
    :try_end_108
    .catch Ljava/lang/Exception; {:try_start_ff .. :try_end_108} :catch_177

    .line 264
    .line 265
    instance-of p2, v0, Landroidx/lifecycle/d1;

    .line 266
    .line 267
    if-eqz p2, :cond_15f

    .line 268
    .line 269
    move-object p2, v0

    .line 270
    check-cast p2, Landroidx/lifecycle/d1;

    .line 271
    .line 272
    invoke-interface {p2}, Landroidx/lifecycle/d1;->e()Landroidx/lifecycle/c1;

    .line 273
    .line 274
    .line 275
    move-result-object p2

    .line 276
    invoke-interface {v0}, Li6/e;->g()Lz5/u;

    .line 277
    .line 278
    .line 279
    move-result-object v1

    .line 280
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 281
    .line 282
    .line 283
    iget-object p2, p2, Landroidx/lifecycle/c1;->a:Ljava/util/LinkedHashMap;

    .line 284
    .line 285
    new-instance v2, Ljava/util/HashSet;

    .line 286
    .line 287
    invoke-virtual {p2}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 288
    .line 289
    .line 290
    move-result-object v3

    .line 291
    invoke-direct {v2, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 295
    .line 296
    .line 297
    move-result-object v2

    .line 298
    :goto_129
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 299
    .line 300
    .line 301
    move-result v3

    .line 302
    if-eqz v3, :cond_14b

    .line 303
    .line 304
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    move-result-object v3

    .line 308
    check-cast v3, Ljava/lang/String;

    .line 309
    .line 310
    const-string v4, "key"

    .line 311
    .line 312
    invoke-static {v3, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {p2, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    check-cast v3, Landroidx/lifecycle/z0;

    .line 320
    .line 321
    if-nez v3, :cond_143

    .line 322
    .line 323
    goto :goto_129

    .line 324
    :cond_143
    invoke-interface {v0}, Landroidx/lifecycle/v;->i()Landroidx/lifecycle/x;

    .line 325
    .line 326
    .line 327
    move-result-object v4

    .line 328
    invoke-static {v3, v1, v4}, Landroidx/lifecycle/s0;->a(Landroidx/lifecycle/z0;Lz5/u;Landroidx/lifecycle/o;)V

    .line 329
    .line 330
    .line 331
    goto :goto_129

    .line 332
    :cond_14b
    new-instance v2, Ljava/util/HashSet;

    .line 333
    .line 334
    invoke-virtual {p2}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 335
    .line 336
    .line 337
    move-result-object p2

    .line 338
    invoke-direct {v2, p2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 339
    .line 340
    .line 341
    invoke-virtual {v2}, Ljava/util/HashSet;->isEmpty()Z

    .line 342
    .line 343
    .line 344
    move-result p2

    .line 345
    if-nez p2, :cond_d4

    .line 346
    .line 347
    invoke-virtual {v1}, Lz5/u;->S()V

    .line 348
    .line 349
    .line 350
    goto/16 :goto_d4

    .line 351
    .line 352
    :cond_15f
    new-instance p1, Ljava/lang/StringBuilder;

    .line 353
    .line 354
    const-string p2, "Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner. Received owner: "

    .line 355
    .line 356
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 357
    .line 358
    .line 359
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 360
    .line 361
    .line 362
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 363
    .line 364
    .line 365
    move-result-object p1

    .line 366
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 367
    .line 368
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 369
    .line 370
    .line 371
    move-result-object p1

    .line 372
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    throw p2

    .line 376
    :catch_177
    move-exception p1

    .line 377
    new-instance v0, Ljava/lang/RuntimeException;

    .line 378
    .line 379
    const-string v1, "Failed to instantiate "

    .line 380
    .line 381
    invoke-static {v1, p2}, La1/h;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object p2

    .line 385
    invoke-direct {v0, p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 386
    .line 387
    .line 388
    throw v0

    .line 389
    :catch_184
    move-exception p1

    .line 390
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 391
    .line 392
    new-instance v0, Ljava/lang/StringBuilder;

    .line 393
    .line 394
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 395
    .line 396
    .line 397
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 398
    .line 399
    .line 400
    move-result-object v1

    .line 401
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 402
    .line 403
    .line 404
    const-string v1, " must have default constructor in order to be automatically recreated"

    .line 405
    .line 406
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 407
    .line 408
    .line 409
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    invoke-direct {p2, v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 414
    .line 415
    .line 416
    throw p2

    .line 417
    :catch_1a0
    move-exception p1

    .line 418
    new-instance v0, Ljava/lang/RuntimeException;

    .line 419
    .line 420
    const-string v2, " wasn\'t found"

    .line 421
    .line 422
    invoke-static {v1, p2, v2}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object p2

    .line 426
    invoke-direct {v0, p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 427
    .line 428
    .line 429
    throw v0

    .line 430
    :cond_1ad
    :goto_1ad
    return-void

    .line 431
    :cond_1ae
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 432
    .line 433
    const-string p2, "SavedState with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\""

    .line 434
    .line 435
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    throw p1

    .line 439
    :cond_1b6
    new-instance p1, Ljava/lang/AssertionError;

    .line 440
    .line 441
    const-string p2, "Next event must be ON_CREATE"

    .line 442
    .line 443
    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 444
    .line 445
    .line 446
    throw p1

    .line 447
    :pswitch_data_1be
    .packed-switch 0x0
        :pswitch_ab
        :pswitch_93
        :pswitch_68
        :pswitch_58
        :pswitch_33
    .end packed-switch

    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    :pswitch_data_1cc
    .packed-switch 0x1
        :pswitch_2f
        :pswitch_2b
        :pswitch_27
        :pswitch_23
        :pswitch_1b
        :pswitch_32
        :pswitch_32
    .end packed-switch
.end method
