###### Class i6.d (i6.d)
.class public interface abstract Li6/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Landroid/os/Bundle;
.end method
