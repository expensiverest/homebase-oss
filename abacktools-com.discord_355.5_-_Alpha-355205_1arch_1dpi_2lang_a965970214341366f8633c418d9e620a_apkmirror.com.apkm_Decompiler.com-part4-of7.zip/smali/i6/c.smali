###### Class i6.c (i6.c)
.class public interface abstract Li6/c;
.super Ljava/lang/Object;
.source "SourceFile"
