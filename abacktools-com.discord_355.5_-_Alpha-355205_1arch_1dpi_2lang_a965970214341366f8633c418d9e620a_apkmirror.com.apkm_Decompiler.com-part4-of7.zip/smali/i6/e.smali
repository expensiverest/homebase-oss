###### Class i6.e (i6.e)
.class public interface abstract Li6/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/v;


# virtual methods
.method public abstract g()Lz5/u;
.end method
