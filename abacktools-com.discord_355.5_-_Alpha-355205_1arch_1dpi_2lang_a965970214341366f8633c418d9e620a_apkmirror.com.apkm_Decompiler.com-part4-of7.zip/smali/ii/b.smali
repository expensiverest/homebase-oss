###### Class ii.b (ii.b)
.class public final Lii/b;
.super Lb3/l;
.source "SourceFile"


# static fields
.field public static final i:Lii/b;

.field public static final v:Loj/a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lii/b;

    .line 2
    .line 3
    const/4 v1, 0x7

    .line 4
    invoke-direct {v0, v1}, Lb3/l;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lii/b;->i:Lii/b;

    .line 8
    .line 9
    sget-object v0, Loj/a;->U:Loj/a;

    .line 10
    .line 11
    sput-object v0, Lii/b;->v:Loj/a;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final v2()Loj/a;
    .registers 2

    .line 1
    sget-object v0, Lii/b;->v:Loj/a;

    .line 2
    .line 3
    return-object v0
.end method
