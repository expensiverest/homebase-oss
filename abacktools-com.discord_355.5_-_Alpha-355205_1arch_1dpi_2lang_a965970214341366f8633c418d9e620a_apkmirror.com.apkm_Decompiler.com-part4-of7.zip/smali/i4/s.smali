###### Class i4.s (i4.s)
.class public final Li4/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:[I

.field public final c:[Lf4/q1;

.field public final d:[I

.field public final e:[[[I

.field public final f:Lf4/q1;


# direct methods
.method public constructor <init>([I[Lf4/q1;[I[[[ILf4/q1;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li4/s;->b:[I

    .line 5
    .line 6
    iput-object p2, p0, Li4/s;->c:[Lf4/q1;

    .line 7
    .line 8
    iput-object p4, p0, Li4/s;->e:[[[I

    .line 9
    .line 10
    iput-object p3, p0, Li4/s;->d:[I

    .line 11
    .line 12
    iput-object p5, p0, Li4/s;->f:Lf4/q1;

    .line 13
    .line 14
    array-length p1, p1

    .line 15
    iput p1, p0, Li4/s;->a:I

    .line 16
    .line 17
    return-void
.end method
