###### Class i4.r (i4.r)
.class public final Li4/r;
.super Li4/c;
.source "SourceFile"


# virtual methods
.method public final c()I
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final j()I
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final m()Ljava/lang/Object;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final q(JJJLjava/util/List;[Lg4/c;)V
    .registers 9

    .line 1
    return-void
.end method
