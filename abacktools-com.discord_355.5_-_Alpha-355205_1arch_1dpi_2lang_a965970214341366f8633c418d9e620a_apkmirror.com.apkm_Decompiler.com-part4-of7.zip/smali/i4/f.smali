###### Class i4.f (i4.f)
.class public final Li4/f;
.super Li4/m;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public final J:Li4/j;

.field public final K:Z

.field public final L:I

.field public final M:I

.field public final N:I

.field public final O:I

.field public final P:Z

.field public final Q:Z

.field public final R:I

.field public final S:I

.field public final T:Z

.field public final U:I

.field public final V:I

.field public final W:I

.field public final X:I

.field public final Y:Z

.field public final Z:Z

.field public final a0:Z

.field public final w:I

.field public final x:Z

.field public final y:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILk3/o1;ILi4/j;IZLi4/d;I)V
    .registers 16

    .line 1
    invoke-direct {p0, p1, p2, p3}, Li4/m;-><init>(ILk3/o1;I)V

    .line 2
    .line 3
    .line 4
    iput-object p4, p0, Li4/f;->J:Li4/j;

    .line 5
    .line 6
    iget-boolean p1, p4, Li4/j;->z0:Z

    .line 7
    .line 8
    iget-object p2, p4, Lk3/t1;->v:Lhx/m0;

    .line 9
    .line 10
    iget-object p3, p4, Lk3/t1;->q:Lhx/m0;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    const/16 p1, 0x18

    .line 15
    .line 16
    goto :goto_12

    .line 17
    :cond_10
    const/16 p1, 0x10

    .line 18
    .line 19
    :goto_12
    const/4 p8, 0x0

    .line 20
    iput-boolean p8, p0, Li4/f;->P:Z

    .line 21
    .line 22
    iget-object v0, p0, Li4/m;->v:Lk3/w;

    .line 23
    .line 24
    iget-object v0, v0, Lk3/w;->d:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0}, Li4/o;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iput-object v0, p0, Li4/f;->y:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {p5, p8}, Lv3/a;->m(IZ)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    iput-boolean v0, p0, Li4/f;->K:Z

    .line 37
    .line 38
    move v0, p8

    .line 39
    :goto_26
    invoke-virtual {p3}, Ljava/util/AbstractCollection;->size()I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    const v2, 0x7fffffff

    .line 44
    .line 45
    .line 46
    if-ge v0, v1, :cond_41

    .line 47
    .line 48
    iget-object v1, p0, Li4/m;->v:Lk3/w;

    .line 49
    .line 50
    invoke-interface {p3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    check-cast v3, Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v1, v3, p8}, Li4/o;->C(Lk3/w;Ljava/lang/String;Z)I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-lez v1, :cond_3e

    .line 61
    .line 62
    goto :goto_43

    .line 63
    :cond_3e
    add-int/lit8 v0, v0, 0x1

    .line 64
    .line 65
    goto :goto_26

    .line 66
    :cond_41
    move v1, p8

    .line 67
    move v0, v2

    .line 68
    :goto_43
    iput v0, p0, Li4/f;->M:I

    .line 69
    .line 70
    iput v1, p0, Li4/f;->L:I

    .line 71
    .line 72
    iget-object p3, p0, Li4/m;->v:Lk3/w;

    .line 73
    .line 74
    iget p3, p3, Lk3/w;->f:I

    .line 75
    .line 76
    iget v0, p4, Lk3/t1;->s:I

    .line 77
    .line 78
    if-eqz p3, :cond_53

    .line 79
    .line 80
    if-ne p3, v0, :cond_53

    .line 81
    .line 82
    move p3, v2

    .line 83
    goto :goto_58

    .line 84
    :cond_53
    and-int/2addr p3, v0

    .line 85
    invoke-static {p3}, Ljava/lang/Integer;->bitCount(I)I

    .line 86
    .line 87
    .line 88
    move-result p3

    .line 89
    :goto_58
    iput p3, p0, Li4/f;->N:I

    .line 90
    .line 91
    iget-object p3, p0, Li4/m;->v:Lk3/w;

    .line 92
    .line 93
    iget-object v0, p4, Lk3/t1;->r:Lhx/m0;

    .line 94
    .line 95
    invoke-static {p3, v0}, Li4/o;->w(Lk3/w;Lhx/m0;)I

    .line 96
    .line 97
    .line 98
    move-result p3

    .line 99
    iput p3, p0, Li4/f;->O:I

    .line 100
    .line 101
    iget-object p3, p0, Li4/m;->v:Lk3/w;

    .line 102
    .line 103
    iget v0, p3, Lk3/w;->f:I

    .line 104
    .line 105
    const/4 v1, 0x1

    .line 106
    if-eqz v0, :cond_71

    .line 107
    .line 108
    and-int/2addr v0, v1

    .line 109
    if-eqz v0, :cond_6f

    .line 110
    .line 111
    goto :goto_71

    .line 112
    :cond_6f
    move v0, p8

    .line 113
    goto :goto_72

    .line 114
    :cond_71
    :goto_71
    move v0, v1

    .line 115
    :goto_72
    iput-boolean v0, p0, Li4/f;->Q:Z

    .line 116
    .line 117
    iget v0, p3, Lk3/w;->e:I

    .line 118
    .line 119
    and-int/2addr v0, v1

    .line 120
    if-eqz v0, :cond_7b

    .line 121
    .line 122
    move v0, v1

    .line 123
    goto :goto_7c

    .line 124
    :cond_7b
    move v0, p8

    .line 125
    :goto_7c
    iput-boolean v0, p0, Li4/f;->T:Z

    .line 126
    .line 127
    iget-object v0, p3, Lk3/w;->p:Ljava/lang/String;

    .line 128
    .line 129
    const/4 v3, 0x2

    .line 130
    const/4 v4, -0x1

    .line 131
    if-nez v0, :cond_85

    .line 132
    .line 133
    goto :goto_b1

    .line 134
    :cond_85
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 135
    .line 136
    .line 137
    move-result v5

    .line 138
    sparse-switch v5, :sswitch_data_194

    .line 139
    .line 140
    .line 141
    :goto_8c
    move v0, v4

    .line 142
    goto :goto_ae

    .line 143
    :sswitch_8e
    const-string v5, "audio/iamf"

    .line 144
    .line 145
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    if-nez v0, :cond_97

    .line 150
    .line 151
    goto :goto_8c

    .line 152
    :cond_97
    move v0, v3

    .line 153
    goto :goto_ae

    .line 154
    :sswitch_99
    const-string v5, "audio/ac4"

    .line 155
    .line 156
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    if-nez v0, :cond_a2

    .line 161
    .line 162
    goto :goto_8c

    .line 163
    :cond_a2
    move v0, v1

    .line 164
    goto :goto_ae

    .line 165
    :sswitch_a4
    const-string v5, "audio/eac3-joc"

    .line 166
    .line 167
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    if-nez v0, :cond_ad

    .line 172
    .line 173
    goto :goto_8c

    .line 174
    :cond_ad
    move v0, p8

    .line 175
    :goto_ae
    packed-switch v0, :pswitch_data_1a2

    .line 176
    .line 177
    .line 178
    :goto_b1
    move v0, p8

    .line 179
    goto :goto_b4

    .line 180
    :pswitch_b3
    move v0, v1

    .line 181
    :goto_b4
    iput-boolean v0, p0, Li4/f;->a0:Z

    .line 182
    .line 183
    iget v0, p3, Lk3/w;->J:I

    .line 184
    .line 185
    iput v0, p0, Li4/f;->U:I

    .line 186
    .line 187
    iget v5, p3, Lk3/w;->L:I

    .line 188
    .line 189
    iput v5, p0, Li4/f;->V:I

    .line 190
    .line 191
    iget v5, p3, Lk3/w;->k:I

    .line 192
    .line 193
    iput v5, p0, Li4/f;->W:I

    .line 194
    .line 195
    if-eq v5, v4, :cond_c8

    .line 196
    .line 197
    iget v6, p4, Lk3/t1;->u:I

    .line 198
    .line 199
    if-gt v5, v6, :cond_d6

    .line 200
    .line 201
    :cond_c8
    if-eq v0, v4, :cond_ce

    .line 202
    .line 203
    iget p4, p4, Lk3/t1;->t:I

    .line 204
    .line 205
    if-gt v0, p4, :cond_d6

    .line 206
    .line 207
    :cond_ce
    invoke-virtual {p7, p3}, Li4/d;->apply(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result p3

    .line 211
    if-eqz p3, :cond_d6

    .line 212
    .line 213
    move p3, v1

    .line 214
    goto :goto_d7

    .line 215
    :cond_d6
    move p3, p8

    .line 216
    :goto_d7
    iput-boolean p3, p0, Li4/f;->x:Z

    .line 217
    .line 218
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 219
    .line 220
    .line 221
    move-result-object p3

    .line 222
    invoke-virtual {p3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 223
    .line 224
    .line 225
    move-result-object p3

    .line 226
    invoke-virtual {p3}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    .line 227
    .line 228
    .line 229
    move-result-object p3

    .line 230
    invoke-virtual {p3}, Landroid/os/LocaleList;->toLanguageTags()Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object p3

    .line 234
    const-string p4, ","

    .line 235
    .line 236
    invoke-virtual {p3, p4, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object p3

    .line 240
    move p4, p8

    .line 241
    :goto_f0
    array-length p7, p3

    .line 242
    if-ge p4, p7, :cond_fe

    .line 243
    .line 244
    aget-object p7, p3, p4

    .line 245
    .line 246
    invoke-static {p7}, Ln3/l0;->T(Ljava/lang/String;)Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object p7

    .line 250
    aput-object p7, p3, p4

    .line 251
    .line 252
    add-int/lit8 p4, p4, 0x1

    .line 253
    .line 254
    goto :goto_f0

    .line 255
    :cond_fe
    move p4, p8

    .line 256
    :goto_ff
    array-length p7, p3

    .line 257
    if-ge p4, p7, :cond_110

    .line 258
    .line 259
    iget-object p7, p0, Li4/m;->v:Lk3/w;

    .line 260
    .line 261
    aget-object v0, p3, p4

    .line 262
    .line 263
    invoke-static {p7, v0, p8}, Li4/o;->C(Lk3/w;Ljava/lang/String;Z)I

    .line 264
    .line 265
    .line 266
    move-result p7

    .line 267
    if-lez p7, :cond_10d

    .line 268
    .line 269
    goto :goto_112

    .line 270
    :cond_10d
    add-int/lit8 p4, p4, 0x1

    .line 271
    .line 272
    goto :goto_ff

    .line 273
    :cond_110
    move p7, p8

    .line 274
    move p4, v2

    .line 275
    :goto_112
    iput p4, p0, Li4/f;->R:I

    .line 276
    .line 277
    iput p7, p0, Li4/f;->S:I

    .line 278
    .line 279
    move p3, p8

    .line 280
    :goto_117
    invoke-virtual {p2}, Ljava/util/AbstractCollection;->size()I

    .line 281
    .line 282
    .line 283
    move-result p4

    .line 284
    if-ge p3, p4, :cond_132

    .line 285
    .line 286
    iget-object p4, p0, Li4/m;->v:Lk3/w;

    .line 287
    .line 288
    iget-object p4, p4, Lk3/w;->p:Ljava/lang/String;

    .line 289
    .line 290
    if-eqz p4, :cond_12f

    .line 291
    .line 292
    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 293
    .line 294
    .line 295
    move-result-object p7

    .line 296
    invoke-virtual {p4, p7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 297
    .line 298
    .line 299
    move-result p4

    .line 300
    if-eqz p4, :cond_12f

    .line 301
    .line 302
    move v2, p3

    .line 303
    goto :goto_132

    .line 304
    :cond_12f
    add-int/lit8 p3, p3, 0x1

    .line 305
    .line 306
    goto :goto_117

    .line 307
    :cond_132
    :goto_132
    iput v2, p0, Li4/f;->X:I

    .line 308
    .line 309
    and-int/lit16 p2, p5, 0x180

    .line 310
    .line 311
    const/16 p3, 0x80

    .line 312
    .line 313
    if-ne p2, p3, :cond_13c

    .line 314
    .line 315
    move p2, v1

    .line 316
    goto :goto_13d

    .line 317
    :cond_13c
    move p2, p8

    .line 318
    :goto_13d
    iput-boolean p2, p0, Li4/f;->Y:Z

    .line 319
    .line 320
    and-int/lit8 p2, p5, 0x40

    .line 321
    .line 322
    const/16 p3, 0x40

    .line 323
    .line 324
    if-ne p2, p3, :cond_147

    .line 325
    .line 326
    move p2, v1

    .line 327
    goto :goto_148

    .line 328
    :cond_147
    move p2, p8

    .line 329
    :goto_148
    iput-boolean p2, p0, Li4/f;->Z:Z

    .line 330
    .line 331
    iget-object p2, p0, Li4/m;->v:Lk3/w;

    .line 332
    .line 333
    iget-boolean p3, p0, Li4/f;->x:Z

    .line 334
    .line 335
    iget-object p4, p0, Li4/f;->J:Li4/j;

    .line 336
    .line 337
    iget-boolean p7, p4, Li4/j;->B0:Z

    .line 338
    .line 339
    iget-object v0, p4, Lk3/t1;->w:Lk3/r1;

    .line 340
    .line 341
    invoke-static {p5, p7}, Lv3/a;->m(IZ)Z

    .line 342
    .line 343
    .line 344
    move-result p7

    .line 345
    if-nez p7, :cond_15b

    .line 346
    .line 347
    goto :goto_191

    .line 348
    :cond_15b
    if-nez p3, :cond_162

    .line 349
    .line 350
    iget-boolean p7, p4, Li4/j;->y0:Z

    .line 351
    .line 352
    if-nez p7, :cond_162

    .line 353
    .line 354
    goto :goto_191

    .line 355
    :cond_162
    iget p7, v0, Lk3/r1;->a:I

    .line 356
    .line 357
    if-ne p7, v3, :cond_16d

    .line 358
    .line 359
    invoke-static {p4, p5, p2}, Li4/o;->E(Li4/j;ILk3/w;)Z

    .line 360
    .line 361
    .line 362
    move-result p7

    .line 363
    if-nez p7, :cond_16d

    .line 364
    .line 365
    goto :goto_191

    .line 366
    :cond_16d
    invoke-static {p5, p8}, Lv3/a;->m(IZ)Z

    .line 367
    .line 368
    .line 369
    move-result p7

    .line 370
    if-eqz p7, :cond_190

    .line 371
    .line 372
    if-eqz p3, :cond_190

    .line 373
    .line 374
    iget p2, p2, Lk3/w;->k:I

    .line 375
    .line 376
    if-eq p2, v4, :cond_190

    .line 377
    .line 378
    iget-boolean p2, p4, Lk3/t1;->G:Z

    .line 379
    .line 380
    if-nez p2, :cond_190

    .line 381
    .line 382
    iget-boolean p2, p4, Lk3/t1;->F:Z

    .line 383
    .line 384
    if-nez p2, :cond_190

    .line 385
    .line 386
    iget-boolean p2, p4, Li4/j;->C0:Z

    .line 387
    .line 388
    if-nez p2, :cond_187

    .line 389
    .line 390
    if-nez p6, :cond_190

    .line 391
    .line 392
    :cond_187
    iget p2, v0, Lk3/r1;->a:I

    .line 393
    .line 394
    if-eq p2, v3, :cond_190

    .line 395
    .line 396
    and-int/2addr p1, p5

    .line 397
    if-eqz p1, :cond_190

    .line 398
    .line 399
    move p8, v3

    .line 400
    goto :goto_191

    .line 401
    :cond_190
    move p8, v1

    .line 402
    :goto_191
    iput p8, p0, Li4/f;->w:I

    .line 403
    .line 404
    return-void

    .line 405
    :sswitch_data_194
    .sparse-switch
        -0x7e929daa -> :sswitch_a4
        0xb269699 -> :sswitch_99
        0x59afdf4a -> :sswitch_8e
    .end sparse-switch

    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    :pswitch_data_1a2
    .packed-switch 0x0
        :pswitch_b3
        :pswitch_b3
        :pswitch_b3
    .end packed-switch
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, Li4/f;->w:I

    .line 2
    .line 3
    return v0
.end method

.method public final b(Li4/m;)Z
    .registers 7

    .line 1
    check-cast p1, Li4/f;

    .line 2
    .line 3
    iget-object v0, p1, Li4/m;->v:Lk3/w;

    .line 4
    .line 5
    iget-object v1, p0, Li4/f;->J:Li4/j;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Li4/m;->v:Lk3/w;

    .line 11
    .line 12
    iget v2, v1, Lk3/w;->J:I

    .line 13
    .line 14
    const/4 v3, -0x1

    .line 15
    if-eq v2, v3, :cond_3a

    .line 16
    .line 17
    iget v4, v0, Lk3/w;->J:I

    .line 18
    .line 19
    if-ne v2, v4, :cond_3a

    .line 20
    .line 21
    iget-boolean v2, p0, Li4/f;->P:Z

    .line 22
    .line 23
    if-nez v2, :cond_24

    .line 24
    .line 25
    iget-object v2, v1, Lk3/w;->p:Ljava/lang/String;

    .line 26
    .line 27
    if-eqz v2, :cond_3a

    .line 28
    .line 29
    iget-object v4, v0, Lk3/w;->p:Ljava/lang/String;

    .line 30
    .line 31
    invoke-static {v2, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_3a

    .line 36
    .line 37
    :cond_24
    iget v1, v1, Lk3/w;->L:I

    .line 38
    .line 39
    if-eq v1, v3, :cond_3a

    .line 40
    .line 41
    iget v0, v0, Lk3/w;->L:I

    .line 42
    .line 43
    if-ne v1, v0, :cond_3a

    .line 44
    .line 45
    iget-boolean v0, p0, Li4/f;->Y:Z

    .line 46
    .line 47
    iget-boolean v1, p1, Li4/f;->Y:Z

    .line 48
    .line 49
    if-ne v0, v1, :cond_3a

    .line 50
    .line 51
    iget-boolean v0, p0, Li4/f;->Z:Z

    .line 52
    .line 53
    iget-boolean p1, p1, Li4/f;->Z:Z

    .line 54
    .line 55
    if-ne v0, p1, :cond_3a

    .line 56
    .line 57
    const/4 p1, 0x1

    .line 58
    return p1

    .line 59
    :cond_3a
    const/4 p1, 0x0

    .line 60
    return p1
.end method

.method public final c(Li4/f;)I
    .registers 9

    .line 1
    iget-boolean v0, p0, Li4/f;->K:Z

    .line 2
    .line 3
    iget-boolean v1, p0, Li4/f;->x:Z

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    if-eqz v0, :cond_b

    .line 8
    .line 9
    sget-object v2, Li4/o;->k:Lhx/u1;

    .line 10
    .line 11
    goto :goto_11

    .line 12
    :cond_b
    sget-object v2, Li4/o;->k:Lhx/u1;

    .line 13
    .line 14
    invoke-virtual {v2}, Lhx/u1;->c()Lhx/u1;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    :goto_11
    iget-boolean v3, p1, Li4/f;->K:Z

    .line 19
    .line 20
    iget v4, p1, Li4/f;->W:I

    .line 21
    .line 22
    sget-object v5, Lhx/a0;->a:Lhx/y;

    .line 23
    .line 24
    invoke-virtual {v5, v0, v3}, Lhx/y;->c(ZZ)Lhx/a0;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget v3, p0, Li4/f;->M:I

    .line 29
    .line 30
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    iget v5, p1, Li4/f;->M:I

    .line 35
    .line 36
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    sget-object v6, Lhx/r1;->i:Lhx/r1;

    .line 41
    .line 42
    invoke-virtual {v0, v3, v5, v6}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    iget v3, p0, Li4/f;->L:I

    .line 47
    .line 48
    iget v5, p1, Li4/f;->L:I

    .line 49
    .line 50
    invoke-virtual {v0, v3, v5}, Lhx/a0;->a(II)Lhx/a0;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iget v3, p0, Li4/f;->N:I

    .line 55
    .line 56
    iget v5, p1, Li4/f;->N:I

    .line 57
    .line 58
    invoke-virtual {v0, v3, v5}, Lhx/a0;->a(II)Lhx/a0;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iget v3, p0, Li4/f;->O:I

    .line 63
    .line 64
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    iget v5, p1, Li4/f;->O:I

    .line 69
    .line 70
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    invoke-virtual {v0, v3, v5, v6}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iget-boolean v3, p0, Li4/f;->T:Z

    .line 79
    .line 80
    iget-boolean v5, p1, Li4/f;->T:Z

    .line 81
    .line 82
    invoke-virtual {v0, v3, v5}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    iget-boolean v3, p0, Li4/f;->Q:Z

    .line 87
    .line 88
    iget-boolean v5, p1, Li4/f;->Q:Z

    .line 89
    .line 90
    invoke-virtual {v0, v3, v5}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    iget v3, p0, Li4/f;->R:I

    .line 95
    .line 96
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    iget v5, p1, Li4/f;->R:I

    .line 101
    .line 102
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    invoke-virtual {v0, v3, v5, v6}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    iget v3, p0, Li4/f;->S:I

    .line 111
    .line 112
    iget v5, p1, Li4/f;->S:I

    .line 113
    .line 114
    invoke-virtual {v0, v3, v5}, Lhx/a0;->a(II)Lhx/a0;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    iget-boolean v3, p1, Li4/f;->x:Z

    .line 119
    .line 120
    invoke-virtual {v0, v1, v3}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    iget v1, p0, Li4/f;->X:I

    .line 125
    .line 126
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    iget v3, p1, Li4/f;->X:I

    .line 131
    .line 132
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 133
    .line 134
    .line 135
    move-result-object v3

    .line 136
    invoke-virtual {v0, v1, v3, v6}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    iget-object v1, p0, Li4/f;->J:Li4/j;

    .line 141
    .line 142
    iget-boolean v1, v1, Lk3/t1;->F:Z

    .line 143
    .line 144
    iget v3, p0, Li4/f;->W:I

    .line 145
    .line 146
    if-eqz v1, :cond_a5

    .line 147
    .line 148
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    sget-object v6, Li4/o;->k:Lhx/u1;

    .line 157
    .line 158
    invoke-virtual {v6}, Lhx/u1;->c()Lhx/u1;

    .line 159
    .line 160
    .line 161
    move-result-object v6

    .line 162
    invoke-virtual {v0, v1, v5, v6}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    :cond_a5
    iget-boolean v1, p0, Li4/f;->Y:Z

    .line 167
    .line 168
    iget-boolean v5, p1, Li4/f;->Y:Z

    .line 169
    .line 170
    invoke-virtual {v0, v1, v5}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    iget-boolean v1, p0, Li4/f;->Z:Z

    .line 175
    .line 176
    iget-boolean v5, p1, Li4/f;->Z:Z

    .line 177
    .line 178
    invoke-virtual {v0, v1, v5}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    iget-boolean v1, p0, Li4/f;->a0:Z

    .line 183
    .line 184
    iget-boolean v5, p1, Li4/f;->a0:Z

    .line 185
    .line 186
    invoke-virtual {v0, v1, v5}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    iget v1, p0, Li4/f;->U:I

    .line 191
    .line 192
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 193
    .line 194
    .line 195
    move-result-object v1

    .line 196
    iget v5, p1, Li4/f;->U:I

    .line 197
    .line 198
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 199
    .line 200
    .line 201
    move-result-object v5

    .line 202
    invoke-virtual {v0, v1, v5, v2}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    iget v1, p0, Li4/f;->V:I

    .line 207
    .line 208
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 209
    .line 210
    .line 211
    move-result-object v1

    .line 212
    iget v5, p1, Li4/f;->V:I

    .line 213
    .line 214
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 215
    .line 216
    .line 217
    move-result-object v5

    .line 218
    invoke-virtual {v0, v1, v5, v2}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    iget-object v1, p0, Li4/f;->y:Ljava/lang/String;

    .line 223
    .line 224
    iget-object p1, p1, Li4/f;->y:Ljava/lang/String;

    .line 225
    .line 226
    invoke-static {v1, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result p1

    .line 230
    if-eqz p1, :cond_f3

    .line 231
    .line 232
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 233
    .line 234
    .line 235
    move-result-object p1

    .line 236
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    invoke-virtual {v0, p1, v1, v2}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    :cond_f3
    invoke-virtual {v0}, Lhx/a0;->e()I

    .line 245
    .line 246
    .line 247
    move-result p1

    .line 248
    return p1
.end method

.method public final bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    .line 1
    check-cast p1, Li4/f;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Li4/f;->c(Li4/f;)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method
