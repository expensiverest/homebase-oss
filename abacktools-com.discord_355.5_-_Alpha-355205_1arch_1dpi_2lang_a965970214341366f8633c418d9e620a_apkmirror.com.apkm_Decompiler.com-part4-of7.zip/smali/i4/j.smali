###### Class i4.j (i4.j)
.class public final Li4/j;
.super Lk3/t1;
.source "SourceFile"


# static fields
.field public static final F0:Li4/j;

.field public static final G0:Ljava/lang/String;

.field public static final H0:Ljava/lang/String;

.field public static final I0:Ljava/lang/String;

.field public static final J0:Ljava/lang/String;

.field public static final K0:Ljava/lang/String;

.field public static final L0:Ljava/lang/String;

.field public static final M0:Ljava/lang/String;

.field public static final N0:Ljava/lang/String;

.field public static final O0:Ljava/lang/String;

.field public static final P0:Ljava/lang/String;

.field public static final Q0:Ljava/lang/String;

.field public static final R0:Ljava/lang/String;

.field public static final S0:Ljava/lang/String;

.field public static final T0:Ljava/lang/String;

.field public static final U0:Ljava/lang/String;

.field public static final V0:Ljava/lang/String;

.field public static final W0:Ljava/lang/String;

.field public static final X0:Ljava/lang/String;

.field public static final Y0:Ljava/lang/String;


# instance fields
.field public final A0:Z

.field public final B0:Z

.field public final C0:Z

.field public final D0:Landroid/util/SparseArray;

.field public final E0:Landroid/util/SparseBooleanArray;

.field public final w0:Z

.field public final x0:Z

.field public final y0:Z

.field public final z0:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Li4/i;

    .line 2
    .line 3
    invoke-direct {v0}, Li4/i;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Li4/j;

    .line 7
    .line 8
    invoke-direct {v1, v0}, Li4/j;-><init>(Li4/i;)V

    .line 9
    .line 10
    .line 11
    sput-object v1, Li4/j;->F0:Li4/j;

    .line 12
    .line 13
    sget-object v0, Ln3/l0;->a:Ljava/lang/String;

    .line 14
    .line 15
    const/16 v0, 0x3e8

    .line 16
    .line 17
    const/16 v1, 0x24

    .line 18
    .line 19
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sput-object v0, Li4/j;->G0:Ljava/lang/String;

    .line 24
    .line 25
    const/16 v0, 0x3e9

    .line 26
    .line 27
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, Li4/j;->H0:Ljava/lang/String;

    .line 32
    .line 33
    const/16 v0, 0x3ea

    .line 34
    .line 35
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sput-object v0, Li4/j;->I0:Ljava/lang/String;

    .line 40
    .line 41
    const/16 v0, 0x3eb

    .line 42
    .line 43
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sput-object v0, Li4/j;->J0:Ljava/lang/String;

    .line 48
    .line 49
    const/16 v0, 0x3ec

    .line 50
    .line 51
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sput-object v0, Li4/j;->K0:Ljava/lang/String;

    .line 56
    .line 57
    const/16 v0, 0x3ed

    .line 58
    .line 59
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    sput-object v0, Li4/j;->L0:Ljava/lang/String;

    .line 64
    .line 65
    const/16 v0, 0x3ee

    .line 66
    .line 67
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, Li4/j;->M0:Ljava/lang/String;

    .line 72
    .line 73
    const/16 v0, 0x3ef

    .line 74
    .line 75
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    sput-object v0, Li4/j;->N0:Ljava/lang/String;

    .line 80
    .line 81
    const/16 v0, 0x3f0

    .line 82
    .line 83
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    sput-object v0, Li4/j;->O0:Ljava/lang/String;

    .line 88
    .line 89
    const/16 v0, 0x3f1

    .line 90
    .line 91
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    sput-object v0, Li4/j;->P0:Ljava/lang/String;

    .line 96
    .line 97
    const/16 v0, 0x3f2

    .line 98
    .line 99
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    sput-object v0, Li4/j;->Q0:Ljava/lang/String;

    .line 104
    .line 105
    const/16 v0, 0x3f3

    .line 106
    .line 107
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    sput-object v0, Li4/j;->R0:Ljava/lang/String;

    .line 112
    .line 113
    const/16 v0, 0x3f4

    .line 114
    .line 115
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    sput-object v0, Li4/j;->S0:Ljava/lang/String;

    .line 120
    .line 121
    const/16 v0, 0x3f5

    .line 122
    .line 123
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    sput-object v0, Li4/j;->T0:Ljava/lang/String;

    .line 128
    .line 129
    const/16 v0, 0x3f6

    .line 130
    .line 131
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    sput-object v0, Li4/j;->U0:Ljava/lang/String;

    .line 136
    .line 137
    const/16 v0, 0x3f7

    .line 138
    .line 139
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    sput-object v0, Li4/j;->V0:Ljava/lang/String;

    .line 144
    .line 145
    const/16 v0, 0x3f8

    .line 146
    .line 147
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    sput-object v0, Li4/j;->W0:Ljava/lang/String;

    .line 152
    .line 153
    const/16 v0, 0x3f9

    .line 154
    .line 155
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    sput-object v0, Li4/j;->X0:Ljava/lang/String;

    .line 160
    .line 161
    const/16 v0, 0x3fa

    .line 162
    .line 163
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    sput-object v0, Li4/j;->Y0:Ljava/lang/String;

    .line 168
    .line 169
    return-void
.end method

.method public constructor <init>(Li4/i;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Lk3/t1;-><init>(Lk3/s1;)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p1, Li4/i;->J:Z

    .line 5
    .line 6
    iput-boolean v0, p0, Li4/j;->w0:Z

    .line 7
    .line 8
    iget-boolean v0, p1, Li4/i;->K:Z

    .line 9
    .line 10
    iput-boolean v0, p0, Li4/j;->x0:Z

    .line 11
    .line 12
    iget-boolean v0, p1, Li4/i;->L:Z

    .line 13
    .line 14
    iput-boolean v0, p0, Li4/j;->y0:Z

    .line 15
    .line 16
    iget-boolean v0, p1, Li4/i;->M:Z

    .line 17
    .line 18
    iput-boolean v0, p0, Li4/j;->z0:Z

    .line 19
    .line 20
    iget-boolean v0, p1, Li4/i;->N:Z

    .line 21
    .line 22
    iput-boolean v0, p0, Li4/j;->A0:Z

    .line 23
    .line 24
    iget-boolean v0, p1, Li4/i;->O:Z

    .line 25
    .line 26
    iput-boolean v0, p0, Li4/j;->B0:Z

    .line 27
    .line 28
    iget-boolean v0, p1, Li4/i;->P:Z

    .line 29
    .line 30
    iput-boolean v0, p0, Li4/j;->C0:Z

    .line 31
    .line 32
    iget-object v0, p1, Li4/i;->Q:Landroid/util/SparseArray;

    .line 33
    .line 34
    iput-object v0, p0, Li4/j;->D0:Landroid/util/SparseArray;

    .line 35
    .line 36
    iget-object p1, p1, Li4/i;->R:Landroid/util/SparseBooleanArray;

    .line 37
    .line 38
    iput-object p1, p0, Li4/j;->E0:Landroid/util/SparseBooleanArray;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final a()Lk3/s1;
    .registers 2

    .line 1
    new-instance v0, Li4/i;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Li4/i;-><init>(Li4/j;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final c()Landroid/os/Bundle;
    .registers 11

    .line 1
    invoke-super {p0}, Lk3/t1;->c()Landroid/os/Bundle;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Li4/j;->G0:Ljava/lang/String;

    .line 6
    .line 7
    iget-boolean v2, p0, Li4/j;->w0:Z

    .line 8
    .line 9
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 10
    .line 11
    .line 12
    sget-object v1, Li4/j;->H0:Ljava/lang/String;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 16
    .line 17
    .line 18
    sget-object v1, Li4/j;->I0:Ljava/lang/String;

    .line 19
    .line 20
    iget-boolean v3, p0, Li4/j;->x0:Z

    .line 21
    .line 22
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 23
    .line 24
    .line 25
    sget-object v1, Li4/j;->U0:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 28
    .line 29
    .line 30
    sget-object v1, Li4/j;->J0:Ljava/lang/String;

    .line 31
    .line 32
    iget-boolean v3, p0, Li4/j;->y0:Z

    .line 33
    .line 34
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    sget-object v1, Li4/j;->K0:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    sget-object v1, Li4/j;->L0:Ljava/lang/String;

    .line 43
    .line 44
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    sget-object v1, Li4/j;->M0:Ljava/lang/String;

    .line 48
    .line 49
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 50
    .line 51
    .line 52
    sget-object v1, Li4/j;->V0:Ljava/lang/String;

    .line 53
    .line 54
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    sget-object v1, Li4/j;->Y0:Ljava/lang/String;

    .line 58
    .line 59
    iget-boolean v3, p0, Li4/j;->z0:Z

    .line 60
    .line 61
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 62
    .line 63
    .line 64
    sget-object v1, Li4/j;->W0:Ljava/lang/String;

    .line 65
    .line 66
    iget-boolean v3, p0, Li4/j;->A0:Z

    .line 67
    .line 68
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 69
    .line 70
    .line 71
    sget-object v1, Li4/j;->N0:Ljava/lang/String;

    .line 72
    .line 73
    iget-boolean v3, p0, Li4/j;->B0:Z

    .line 74
    .line 75
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 76
    .line 77
    .line 78
    sget-object v1, Li4/j;->O0:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 81
    .line 82
    .line 83
    sget-object v1, Li4/j;->P0:Ljava/lang/String;

    .line 84
    .line 85
    iget-boolean v3, p0, Li4/j;->C0:Z

    .line 86
    .line 87
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 88
    .line 89
    .line 90
    sget-object v1, Li4/j;->X0:Ljava/lang/String;

    .line 91
    .line 92
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 93
    .line 94
    .line 95
    new-instance v1, Ljava/util/ArrayList;

    .line 96
    .line 97
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 98
    .line 99
    .line 100
    new-instance v3, Ljava/util/ArrayList;

    .line 101
    .line 102
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 103
    .line 104
    .line 105
    new-instance v4, Landroid/util/SparseArray;

    .line 106
    .line 107
    invoke-direct {v4}, Landroid/util/SparseArray;-><init>()V

    .line 108
    .line 109
    .line 110
    move v5, v2

    .line 111
    :goto_6e
    iget-object v6, p0, Li4/j;->D0:Landroid/util/SparseArray;

    .line 112
    .line 113
    invoke-virtual {v6}, Landroid/util/SparseArray;->size()I

    .line 114
    .line 115
    .line 116
    move-result v7

    .line 117
    if-ge v5, v7, :cond_ed

    .line 118
    .line 119
    invoke-virtual {v6, v5}, Landroid/util/SparseArray;->keyAt(I)I

    .line 120
    .line 121
    .line 122
    move-result v7

    .line 123
    invoke-virtual {v6, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v6

    .line 127
    check-cast v6, Ljava/util/Map;

    .line 128
    .line 129
    invoke-interface {v6}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 130
    .line 131
    .line 132
    move-result-object v6

    .line 133
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 134
    .line 135
    .line 136
    move-result-object v6

    .line 137
    :goto_88
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 138
    .line 139
    .line 140
    move-result v8

    .line 141
    if-eqz v8, :cond_b1

    .line 142
    .line 143
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v8

    .line 147
    check-cast v8, Ljava/util/Map$Entry;

    .line 148
    .line 149
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v9

    .line 153
    if-nez v9, :cond_ab

    .line 154
    .line 155
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v8

    .line 159
    check-cast v8, Lf4/q1;

    .line 160
    .line 161
    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 165
    .line 166
    .line 167
    move-result-object v8

    .line 168
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 169
    .line 170
    .line 171
    goto :goto_88

    .line 172
    :cond_ab
    new-instance v0, Ljava/lang/ClassCastException;

    .line 173
    .line 174
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 175
    .line 176
    .line 177
    throw v0

    .line 178
    :cond_b1
    sget-object v6, Li4/j;->Q0:Ljava/lang/String;

    .line 179
    .line 180
    invoke-static {v1}, Lc7/t;->O(Ljava/util/Collection;)[I

    .line 181
    .line 182
    .line 183
    move-result-object v7

    .line 184
    invoke-virtual {v0, v6, v7}, Landroid/os/BaseBundle;->putIntArray(Ljava/lang/String;[I)V

    .line 185
    .line 186
    .line 187
    new-instance v6, Ldh/a;

    .line 188
    .line 189
    const/16 v7, 0x1b

    .line 190
    .line 191
    invoke-direct {v6, v7}, Ldh/a;-><init>(I)V

    .line 192
    .line 193
    .line 194
    invoke-static {v3, v6}, Ln3/e;->k(Ljava/util/Collection;Lgx/k;)Ljava/util/ArrayList;

    .line 195
    .line 196
    .line 197
    move-result-object v6

    .line 198
    sget-object v7, Li4/j;->R0:Ljava/lang/String;

    .line 199
    .line 200
    invoke-virtual {v0, v7, v6}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 201
    .line 202
    .line 203
    new-instance v6, Landroid/util/SparseArray;

    .line 204
    .line 205
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    .line 206
    .line 207
    .line 208
    move-result v7

    .line 209
    invoke-direct {v6, v7}, Landroid/util/SparseArray;-><init>(I)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    .line 213
    .line 214
    .line 215
    move-result v7

    .line 216
    if-gtz v7, :cond_e1

    .line 217
    .line 218
    sget-object v7, Li4/j;->S0:Ljava/lang/String;

    .line 219
    .line 220
    invoke-virtual {v0, v7, v6}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V

    .line 221
    .line 222
    .line 223
    add-int/lit8 v5, v5, 0x1

    .line 224
    .line 225
    goto :goto_6e

    .line 226
    :cond_e1
    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->keyAt(I)I

    .line 227
    .line 228
    .line 229
    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    invoke-static {v0}, La1/h;->s(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    const/4 v0, 0x0

    .line 237
    throw v0

    .line 238
    :cond_ed
    iget-object v1, p0, Li4/j;->E0:Landroid/util/SparseBooleanArray;

    .line 239
    .line 240
    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->size()I

    .line 241
    .line 242
    .line 243
    move-result v3

    .line 244
    new-array v3, v3, [I

    .line 245
    .line 246
    :goto_f5
    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->size()I

    .line 247
    .line 248
    .line 249
    move-result v4

    .line 250
    if-ge v2, v4, :cond_104

    .line 251
    .line 252
    invoke-virtual {v1, v2}, Landroid/util/SparseBooleanArray;->keyAt(I)I

    .line 253
    .line 254
    .line 255
    move-result v4

    .line 256
    aput v4, v3, v2

    .line 257
    .line 258
    add-int/lit8 v2, v2, 0x1

    .line 259
    .line 260
    goto :goto_f5

    .line 261
    :cond_104
    sget-object v1, Li4/j;->T0:Ljava/lang/String;

    .line 262
    .line 263
    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putIntArray(Ljava/lang/String;[I)V

    .line 264
    .line 265
    .line 266
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 11

    .line 1
    if-ne p0, p1, :cond_4

    .line 2
    .line 3
    goto/16 :goto_ca

    .line 4
    .line 5
    :cond_4
    const/4 v0, 0x0

    .line 6
    if-eqz p1, :cond_cc

    .line 7
    .line 8
    const-class v1, Li4/j;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    if-eq v1, v2, :cond_11

    .line 15
    .line 16
    goto/16 :goto_cc

    .line 17
    .line 18
    :cond_11
    check-cast p1, Li4/j;

    .line 19
    .line 20
    invoke-super {p0, p1}, Lk3/t1;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_cc

    .line 25
    .line 26
    iget-boolean v1, p0, Li4/j;->w0:Z

    .line 27
    .line 28
    iget-boolean v2, p1, Li4/j;->w0:Z

    .line 29
    .line 30
    if-ne v1, v2, :cond_cc

    .line 31
    .line 32
    iget-boolean v1, p0, Li4/j;->x0:Z

    .line 33
    .line 34
    iget-boolean v2, p1, Li4/j;->x0:Z

    .line 35
    .line 36
    if-ne v1, v2, :cond_cc

    .line 37
    .line 38
    iget-boolean v1, p0, Li4/j;->y0:Z

    .line 39
    .line 40
    iget-boolean v2, p1, Li4/j;->y0:Z

    .line 41
    .line 42
    if-ne v1, v2, :cond_cc

    .line 43
    .line 44
    iget-boolean v1, p0, Li4/j;->z0:Z

    .line 45
    .line 46
    iget-boolean v2, p1, Li4/j;->z0:Z

    .line 47
    .line 48
    if-ne v1, v2, :cond_cc

    .line 49
    .line 50
    iget-boolean v1, p0, Li4/j;->A0:Z

    .line 51
    .line 52
    iget-boolean v2, p1, Li4/j;->A0:Z

    .line 53
    .line 54
    if-ne v1, v2, :cond_cc

    .line 55
    .line 56
    iget-boolean v1, p0, Li4/j;->B0:Z

    .line 57
    .line 58
    iget-boolean v2, p1, Li4/j;->B0:Z

    .line 59
    .line 60
    if-ne v1, v2, :cond_cc

    .line 61
    .line 62
    iget-boolean v1, p0, Li4/j;->C0:Z

    .line 63
    .line 64
    iget-boolean v2, p1, Li4/j;->C0:Z

    .line 65
    .line 66
    if-ne v1, v2, :cond_cc

    .line 67
    .line 68
    iget-object v1, p1, Li4/j;->E0:Landroid/util/SparseBooleanArray;

    .line 69
    .line 70
    iget-object v2, p0, Li4/j;->E0:Landroid/util/SparseBooleanArray;

    .line 71
    .line 72
    invoke-virtual {v2}, Landroid/util/SparseBooleanArray;->size()I

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->size()I

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    if-eq v4, v3, :cond_53

    .line 81
    .line 82
    goto/16 :goto_cc

    .line 83
    .line 84
    :cond_53
    move v4, v0

    .line 85
    :goto_54
    if-ge v4, v3, :cond_65

    .line 86
    .line 87
    invoke-virtual {v2, v4}, Landroid/util/SparseBooleanArray;->keyAt(I)I

    .line 88
    .line 89
    .line 90
    move-result v5

    .line 91
    invoke-virtual {v1, v5}, Landroid/util/SparseBooleanArray;->indexOfKey(I)I

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    if-gez v5, :cond_62

    .line 96
    .line 97
    goto/16 :goto_cc

    .line 98
    .line 99
    :cond_62
    add-int/lit8 v4, v4, 0x1

    .line 100
    .line 101
    goto :goto_54

    .line 102
    :cond_65
    iget-object p1, p1, Li4/j;->D0:Landroid/util/SparseArray;

    .line 103
    .line 104
    iget-object v1, p0, Li4/j;->D0:Landroid/util/SparseArray;

    .line 105
    .line 106
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 111
    .line 112
    .line 113
    move-result v3

    .line 114
    if-eq v3, v2, :cond_74

    .line 115
    .line 116
    goto :goto_cc

    .line 117
    :cond_74
    move v3, v0

    .line 118
    :goto_75
    if-ge v3, v2, :cond_ca

    .line 119
    .line 120
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->keyAt(I)I

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    invoke-virtual {p1, v4}, Landroid/util/SparseArray;->indexOfKey(I)I

    .line 125
    .line 126
    .line 127
    move-result v4

    .line 128
    if-ltz v4, :cond_cc

    .line 129
    .line 130
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v5

    .line 134
    check-cast v5, Ljava/util/Map;

    .line 135
    .line 136
    invoke-virtual {p1, v4}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v4

    .line 140
    check-cast v4, Ljava/util/Map;

    .line 141
    .line 142
    invoke-interface {v5}, Ljava/util/Map;->size()I

    .line 143
    .line 144
    .line 145
    move-result v6

    .line 146
    invoke-interface {v4}, Ljava/util/Map;->size()I

    .line 147
    .line 148
    .line 149
    move-result v7

    .line 150
    if-eq v7, v6, :cond_98

    .line 151
    .line 152
    goto :goto_cc

    .line 153
    :cond_98
    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 154
    .line 155
    .line 156
    move-result-object v5

    .line 157
    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 158
    .line 159
    .line 160
    move-result-object v5

    .line 161
    :cond_a0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 162
    .line 163
    .line 164
    move-result v6

    .line 165
    if-eqz v6, :cond_c7

    .line 166
    .line 167
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v6

    .line 171
    check-cast v6, Ljava/util/Map$Entry;

    .line 172
    .line 173
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v7

    .line 177
    check-cast v7, Lf4/q1;

    .line 178
    .line 179
    invoke-interface {v4, v7}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result v8

    .line 183
    if-eqz v8, :cond_cc

    .line 184
    .line 185
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v6

    .line 189
    invoke-interface {v4, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v7

    .line 193
    invoke-static {v6, v7}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    move-result v6

    .line 197
    if-nez v6, :cond_a0

    .line 198
    .line 199
    goto :goto_cc

    .line 200
    :cond_c7
    add-int/lit8 v3, v3, 0x1

    .line 201
    .line 202
    goto :goto_75

    .line 203
    :cond_ca
    :goto_ca
    const/4 p1, 0x1

    .line 204
    return p1

    .line 205
    :cond_cc
    :goto_cc
    return v0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    invoke-super {p0}, Lk3/t1;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x1f

    .line 6
    .line 7
    add-int/2addr v0, v1

    .line 8
    mul-int/2addr v0, v1

    .line 9
    iget-boolean v2, p0, Li4/j;->w0:Z

    .line 10
    .line 11
    add-int/2addr v0, v2

    .line 12
    mul-int/lit16 v0, v0, 0x3c1

    .line 13
    .line 14
    iget-boolean v2, p0, Li4/j;->x0:Z

    .line 15
    .line 16
    add-int/2addr v0, v2

    .line 17
    mul-int/lit16 v0, v0, 0x3c1

    .line 18
    .line 19
    iget-boolean v2, p0, Li4/j;->y0:Z

    .line 20
    .line 21
    add-int/2addr v0, v2

    .line 22
    const v2, 0x1b4d89f

    .line 23
    .line 24
    .line 25
    mul-int/2addr v0, v2

    .line 26
    iget-boolean v2, p0, Li4/j;->z0:Z

    .line 27
    .line 28
    add-int/2addr v0, v2

    .line 29
    mul-int/2addr v0, v1

    .line 30
    iget-boolean v2, p0, Li4/j;->A0:Z

    .line 31
    .line 32
    add-int/2addr v0, v2

    .line 33
    mul-int/2addr v0, v1

    .line 34
    iget-boolean v2, p0, Li4/j;->B0:Z

    .line 35
    .line 36
    add-int/2addr v0, v2

    .line 37
    mul-int/lit16 v0, v0, 0x3c1

    .line 38
    .line 39
    iget-boolean v2, p0, Li4/j;->C0:Z

    .line 40
    .line 41
    add-int/2addr v0, v2

    .line 42
    mul-int/2addr v0, v1

    .line 43
    return v0
.end method
