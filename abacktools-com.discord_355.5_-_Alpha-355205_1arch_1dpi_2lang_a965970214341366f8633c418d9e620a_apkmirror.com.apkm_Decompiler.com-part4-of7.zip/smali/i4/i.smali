###### Class i4.i (i4.i)
.class public final Li4/i;
.super Lk3/s1;
.source "SourceFile"


# instance fields
.field public final J:Z

.field public final K:Z

.field public final L:Z

.field public final M:Z

.field public final N:Z

.field public final O:Z

.field public final P:Z

.field public final Q:Landroid/util/SparseArray;

.field public final R:Landroid/util/SparseBooleanArray;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 17
    invoke-direct {p0}, Lk3/s1;-><init>()V

    .line 18
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Li4/i;->Q:Landroid/util/SparseArray;

    .line 19
    new-instance v0, Landroid/util/SparseBooleanArray;

    invoke-direct {v0}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object v0, p0, Li4/i;->R:Landroid/util/SparseBooleanArray;

    const/4 v0, 0x1

    .line 20
    iput-boolean v0, p0, Li4/i;->J:Z

    .line 21
    iput-boolean v0, p0, Li4/i;->K:Z

    .line 22
    iput-boolean v0, p0, Li4/i;->L:Z

    .line 23
    iput-boolean v0, p0, Li4/i;->M:Z

    .line 24
    iput-boolean v0, p0, Li4/i;->N:Z

    .line 25
    iput-boolean v0, p0, Li4/i;->O:Z

    .line 26
    iput-boolean v0, p0, Li4/i;->P:Z

    return-void
.end method

.method public constructor <init>(Li4/j;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-virtual {p0, p1}, Lk3/s1;->e(Lk3/t1;)V

    .line 3
    iget-boolean v0, p1, Li4/j;->w0:Z

    iput-boolean v0, p0, Li4/i;->J:Z

    .line 4
    iget-boolean v0, p1, Li4/j;->x0:Z

    iput-boolean v0, p0, Li4/i;->K:Z

    .line 5
    iget-boolean v0, p1, Li4/j;->y0:Z

    iput-boolean v0, p0, Li4/i;->L:Z

    .line 6
    iget-boolean v0, p1, Li4/j;->z0:Z

    iput-boolean v0, p0, Li4/i;->M:Z

    .line 7
    iget-boolean v0, p1, Li4/j;->A0:Z

    iput-boolean v0, p0, Li4/i;->N:Z

    .line 8
    iget-boolean v0, p1, Li4/j;->B0:Z

    iput-boolean v0, p0, Li4/i;->O:Z

    .line 9
    iget-boolean v0, p1, Li4/j;->C0:Z

    iput-boolean v0, p0, Li4/i;->P:Z

    .line 10
    iget-object v0, p1, Li4/j;->D0:Landroid/util/SparseArray;

    .line 11
    new-instance v1, Landroid/util/SparseArray;

    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    const/4 v2, 0x0

    .line 12
    :goto_2a
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_45

    .line 13
    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    new-instance v4, Ljava/util/HashMap;

    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map;

    invoke-direct {v4, v5}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    invoke-virtual {v1, v3, v4}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2a

    .line 14
    :cond_45
    iput-object v1, p0, Li4/i;->Q:Landroid/util/SparseArray;

    .line 15
    iget-object p1, p1, Li4/j;->E0:Landroid/util/SparseBooleanArray;

    .line 16
    invoke-virtual {p1}, Landroid/util/SparseBooleanArray;->clone()Landroid/util/SparseBooleanArray;

    move-result-object p1

    iput-object p1, p0, Li4/i;->R:Landroid/util/SparseBooleanArray;

    return-void
.end method


# virtual methods
.method public final a(Lk3/p1;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lk3/s1;->H:Ljava/util/HashMap;

    .line 2
    .line 3
    iget-object v1, p1, Lk3/p1;->a:Lk3/o1;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final b()Lk3/t1;
    .registers 2

    .line 1
    new-instance v0, Li4/j;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Li4/j;-><init>(Li4/i;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final c()Lk3/s1;
    .registers 1

    .line 1
    invoke-super {p0}, Lk3/s1;->c()Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final d(I)Lk3/s1;
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lk3/s1;->d(I)Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final g()Lk3/s1;
    .registers 2

    .line 1
    const/4 v0, -0x3

    .line 2
    iput v0, p0, Lk3/s1;->C:I

    .line 3
    .line 4
    return-object p0
.end method

.method public final h(Lk3/p1;)Lk3/s1;
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lk3/s1;->h(Lk3/p1;)Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final i()Lk3/s1;
    .registers 1

    .line 1
    invoke-super {p0}, Lk3/s1;->i()Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final j([Ljava/lang/String;)Lk3/s1;
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lk3/s1;->j([Ljava/lang/String;)Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final k()Lk3/s1;
    .registers 1

    .line 1
    invoke-super {p0}, Lk3/s1;->k()Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final l(IZ)Lk3/s1;
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Lk3/s1;->l(IZ)Lk3/s1;

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final m(Ljava/util/Set;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lk3/s1;->I:Ljava/util/HashSet;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lk3/s1;->I:Ljava/util/HashSet;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 9
    .line 10
    .line 11
    return-void
.end method
