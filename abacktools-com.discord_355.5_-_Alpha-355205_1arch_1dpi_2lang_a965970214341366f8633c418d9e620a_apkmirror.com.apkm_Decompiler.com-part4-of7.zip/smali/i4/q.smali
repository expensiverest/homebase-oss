###### Class i4.q (i4.q)
.class public interface abstract Li4/q;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(IJ)Z
.end method

.method public abstract b()Lk3/o1;
.end method

.method public abstract c()I
.end method

.method public abstract d(Z)V
.end method

.method public abstract disable()V
.end method

.method public abstract e(I)Lk3/w;
.end method

.method public abstract enable()V
.end method

.method public abstract f(I)I
.end method

.method public abstract g(JLjava/util/List;)I
.end method

.method public abstract h()I
.end method

.method public abstract i()Lk3/w;
.end method

.method public abstract j()I
.end method

.method public abstract k(IJ)Z
.end method

.method public abstract l(F)V
.end method

.method public abstract length()I
.end method

.method public abstract m()Ljava/lang/Object;
.end method

.method public n()V
    .registers 1

    .line 1
    return-void
.end method

.method public o()V
    .registers 1

    .line 1
    return-void
.end method

.method public abstract p(I)I
.end method

.method public abstract q(JJJLjava/util/List;[Lg4/c;)V
.end method

.method public abstract r()V
.end method

.method public s(JLg4/a;Ljava/util/List;)Z
    .registers 5

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method
