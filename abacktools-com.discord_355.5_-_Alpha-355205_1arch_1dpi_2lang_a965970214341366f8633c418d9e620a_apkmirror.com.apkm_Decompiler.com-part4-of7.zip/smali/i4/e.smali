###### Class i4.e (i4.e)
.class public final synthetic Li4/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li4/l;
.implements Lio/sentry/v3;


# instance fields
.field public final synthetic d:Z

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Li4/o;Li4/j;Z[I)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li4/e;->e:Ljava/lang/Object;

    iput-object p2, p0, Li4/e;->i:Ljava/lang/Object;

    iput-boolean p3, p0, Li4/e;->d:Z

    iput-object p4, p0, Li4/e;->v:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lio/sentry/j6;ZLjava/util/concurrent/atomic/AtomicReference;Lio/sentry/a6;)V
    .registers 5

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li4/e;->e:Ljava/lang/Object;

    iput-boolean p2, p0, Li4/e;->d:Z

    iput-object p3, p0, Li4/e;->i:Ljava/lang/Object;

    iput-object p4, p0, Li4/e;->v:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public f(ILk3/o1;[I)Lhx/w1;
    .registers 15

    .line 1
    iget-object v0, p0, Li4/e;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Li4/o;

    .line 4
    .line 5
    iget-object v1, p0, Li4/e;->i:Ljava/lang/Object;

    .line 6
    .line 7
    move-object v6, v1

    .line 8
    check-cast v6, Li4/j;

    .line 9
    .line 10
    iget-object v1, p0, Li4/e;->v:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, [I

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v9, Li4/d;

    .line 18
    .line 19
    invoke-direct {v9, v0, v6}, Li4/d;-><init>(Li4/o;Li4/j;)V

    .line 20
    .line 21
    .line 22
    aget v10, v1, p1

    .line 23
    .line 24
    invoke-static {}, Lhx/m0;->p()Lhx/j0;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const/4 v1, 0x0

    .line 29
    move v5, v1

    .line 30
    :goto_1d
    iget v1, p2, Lk3/o1;->a:I

    .line 31
    .line 32
    if-ge v5, v1, :cond_32

    .line 33
    .line 34
    new-instance v2, Li4/f;

    .line 35
    .line 36
    aget v7, p3, v5

    .line 37
    .line 38
    iget-boolean v8, p0, Li4/e;->d:Z

    .line 39
    .line 40
    move v3, p1

    .line 41
    move-object v4, p2

    .line 42
    invoke-direct/range {v2 .. v10}, Li4/f;-><init>(ILk3/o1;ILi4/j;IZLi4/d;I)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0, v2}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    add-int/lit8 v5, v5, 0x1

    .line 49
    .line 50
    goto :goto_1d

    .line 51
    :cond_32
    invoke-virtual {v0}, Lhx/j0;->g()Lhx/w1;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    return-object p1
.end method

.method public l(Lio/sentry/y0;)V
    .registers 7

    .line 1
    iget-object v0, p0, Li4/e;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/sentry/j6;

    .line 4
    .line 5
    iget-object v1, p0, Li4/e;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 8
    .line 9
    iget-object v2, p0, Li4/e;->v:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lio/sentry/a6;

    .line 12
    .line 13
    invoke-interface {p1}, Lio/sentry/y0;->u()Lio/sentry/k6;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    if-eqz v3, :cond_2f

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    iget-boolean v4, p0, Li4/e;->d:Z

    .line 21
    .line 22
    invoke-virtual {v3, v0, v2, v4, v2}, Lio/sentry/k6;->d(Lio/sentry/j6;Ljava/lang/String;ZLjava/lang/String;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_2e

    .line 27
    .line 28
    iget-object v0, v3, Lio/sentry/k6;->y:Lio/sentry/j6;

    .line 29
    .line 30
    sget-object v2, Lio/sentry/j6;->Crashed:Lio/sentry/j6;

    .line 31
    .line 32
    if-ne v0, v2, :cond_2b

    .line 33
    .line 34
    invoke-static {}, Lz20/g;->t()Ljava/util/Date;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v3, v0}, Lio/sentry/k6;->b(Ljava/util/Date;)V

    .line 39
    .line 40
    .line 41
    invoke-interface {p1}, Lio/sentry/y0;->J()V

    .line 42
    .line 43
    .line 44
    :cond_2b
    invoke-virtual {v1, v3}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    return-void

    .line 48
    :cond_2f
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    sget-object v0, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 53
    .line 54
    const/4 v1, 0x0

    .line 55
    new-array v1, v1, [Ljava/lang/Object;

    .line 56
    .line 57
    const-string v2, "Session is null on updateSession"

    .line 58
    .line 59
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    return-void
.end method
