###### Class i4.b (i4.b)
.class public final Li4/b;
.super Li4/c;
.source "SourceFile"


# instance fields
.field public final h:Lj4/d;

.field public final i:J

.field public final j:J

.field public final k:J

.field public final l:I

.field public final m:I

.field public final n:F

.field public final o:F

.field public final p:Lhx/m0;

.field public final q:Ln3/e0;

.field public r:F

.field public s:I

.field public t:I

.field public u:J

.field public v:Lg4/b;


# direct methods
.method public constructor <init>(Lk3/o1;[ILj4/d;JJJLhx/m0;)V
    .registers 12

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0, p1, p2}, Li4/c;-><init>(ILk3/o1;[I)V

    .line 3
    .line 4
    .line 5
    cmp-long p1, p8, p4

    .line 6
    .line 7
    if-gez p1, :cond_10

    .line 8
    .line 9
    const-string p1, "AdaptiveTrackSelection"

    .line 10
    .line 11
    const-string p2, "Adjusting minDurationToRetainAfterDiscardMs to be at least minDurationForQualityIncreaseMs"

    .line 12
    .line 13
    invoke-static {p1, p2}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    move-wide p8, p4

    .line 17
    :cond_10
    iput-object p3, p0, Li4/b;->h:Lj4/d;

    .line 18
    .line 19
    const-wide/16 p1, 0x3e8

    .line 20
    .line 21
    mul-long/2addr p4, p1

    .line 22
    iput-wide p4, p0, Li4/b;->i:J

    .line 23
    .line 24
    mul-long/2addr p6, p1

    .line 25
    iput-wide p6, p0, Li4/b;->j:J

    .line 26
    .line 27
    mul-long/2addr p8, p1

    .line 28
    iput-wide p8, p0, Li4/b;->k:J

    .line 29
    .line 30
    const/16 p1, 0x4ff

    .line 31
    .line 32
    iput p1, p0, Li4/b;->l:I

    .line 33
    .line 34
    const/16 p1, 0x2cf

    .line 35
    .line 36
    iput p1, p0, Li4/b;->m:I

    .line 37
    .line 38
    const p1, 0x3f333333    # 0.7f

    .line 39
    .line 40
    .line 41
    iput p1, p0, Li4/b;->n:F

    .line 42
    .line 43
    const/high16 p1, 0x3f400000    # 0.75f

    .line 44
    .line 45
    iput p1, p0, Li4/b;->o:F

    .line 46
    .line 47
    invoke-static {p10}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    iput-object p1, p0, Li4/b;->p:Lhx/m0;

    .line 52
    .line 53
    sget-object p1, Ln3/e0;->a:Ln3/e0;

    .line 54
    .line 55
    iput-object p1, p0, Li4/b;->q:Ln3/e0;

    .line 56
    .line 57
    const/high16 p1, 0x3f800000    # 1.0f

    .line 58
    .line 59
    iput p1, p0, Li4/b;->r:F

    .line 60
    .line 61
    iput v0, p0, Li4/b;->t:I

    .line 62
    .line 63
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    iput-wide p1, p0, Li4/b;->u:J

    .line 69
    .line 70
    return-void
.end method

.method public static t(Ljava/util/ArrayList;[J)V
    .registers 9

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    move v3, v2

    .line 5
    :goto_4
    array-length v4, p1

    .line 6
    if-ge v3, v4, :cond_d

    .line 7
    .line 8
    aget-wide v4, p1, v3

    .line 9
    .line 10
    add-long/2addr v0, v4

    .line 11
    add-int/lit8 v3, v3, 0x1

    .line 12
    .line 13
    goto :goto_4

    .line 14
    :cond_d
    :goto_d
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    if-ge v2, v3, :cond_29

    .line 19
    .line 20
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    check-cast v3, Lhx/j0;

    .line 25
    .line 26
    if-nez v3, :cond_1c

    .line 27
    .line 28
    goto :goto_26

    .line 29
    :cond_1c
    new-instance v4, Li4/a;

    .line 30
    .line 31
    aget-wide v5, p1, v2

    .line 32
    .line 33
    invoke-direct {v4, v0, v1, v5, v6}, Li4/a;-><init>(JJ)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v3, v4}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :goto_26
    add-int/lit8 v2, v2, 0x1

    .line 40
    .line 41
    goto :goto_d

    .line 42
    :cond_29
    return-void
.end method

.method public static w(Ljava/util/List;)J
    .registers 8

    .line 1
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    if-eqz v0, :cond_c

    .line 11
    .line 12
    goto :goto_20

    .line 13
    :cond_c
    invoke-static {p0}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    check-cast p0, Lg4/b;

    .line 18
    .line 19
    iget-wide v3, p0, Lg4/a;->g:J

    .line 20
    .line 21
    cmp-long v0, v3, v1

    .line 22
    .line 23
    if-eqz v0, :cond_20

    .line 24
    .line 25
    iget-wide v5, p0, Lg4/a;->h:J

    .line 26
    .line 27
    cmp-long p0, v5, v1

    .line 28
    .line 29
    if-eqz p0, :cond_20

    .line 30
    .line 31
    sub-long/2addr v5, v3

    .line 32
    return-wide v5

    .line 33
    :cond_20
    :goto_20
    return-wide v1
.end method


# virtual methods
.method public final c()I
    .registers 2

    .line 1
    iget v0, p0, Li4/b;->s:I

    .line 2
    .line 3
    return v0
.end method

.method public final disable()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Li4/b;->v:Lg4/b;

    .line 3
    .line 4
    return-void
.end method

.method public final enable()V
    .registers 3

    .line 1
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    iput-wide v0, p0, Li4/b;->u:J

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Li4/b;->v:Lg4/b;

    .line 10
    .line 11
    return-void
.end method

.method public final g(JLjava/util/List;)I
    .registers 14

    .line 1
    iget-object v0, p0, Li4/b;->q:Ln3/e0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    iget-wide v2, p0, Li4/b;->u:J

    .line 11
    .line 12
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    cmp-long v4, v2, v4

    .line 18
    .line 19
    if-eqz v4, :cond_36

    .line 20
    .line 21
    sub-long v2, v0, v2

    .line 22
    .line 23
    const-wide/16 v4, 0x3e8

    .line 24
    .line 25
    cmp-long v2, v2, v4

    .line 26
    .line 27
    if-gez v2, :cond_36

    .line 28
    .line 29
    invoke-interface {p3}, Ljava/util/List;->isEmpty()Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-nez v2, :cond_31

    .line 34
    .line 35
    invoke-static {p3}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, Lg4/b;

    .line 40
    .line 41
    iget-object v3, p0, Li4/b;->v:Lg4/b;

    .line 42
    .line 43
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-nez v2, :cond_31

    .line 48
    .line 49
    goto :goto_36

    .line 50
    :cond_31
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    return p1

    .line 55
    :cond_36
    :goto_36
    iput-wide v0, p0, Li4/b;->u:J

    .line 56
    .line 57
    invoke-interface {p3}, Ljava/util/List;->isEmpty()Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_40

    .line 62
    .line 63
    const/4 v2, 0x0

    .line 64
    goto :goto_46

    .line 65
    :cond_40
    invoke-static {p3}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    check-cast v2, Lg4/b;

    .line 70
    .line 71
    :goto_46
    iput-object v2, p0, Li4/b;->v:Lg4/b;

    .line 72
    .line 73
    invoke-interface {p3}, Ljava/util/List;->isEmpty()Z

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    const/4 v3, 0x0

    .line 78
    if-eqz v2, :cond_50

    .line 79
    .line 80
    return v3

    .line 81
    :cond_50
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    add-int/lit8 v4, v2, -0x1

    .line 86
    .line 87
    invoke-interface {p3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v4

    .line 91
    check-cast v4, Lg4/b;

    .line 92
    .line 93
    iget-wide v4, v4, Lg4/a;->g:J

    .line 94
    .line 95
    sub-long/2addr v4, p1

    .line 96
    iget v6, p0, Li4/b;->r:F

    .line 97
    .line 98
    invoke-static {v4, v5, v6}, Ln3/l0;->F(JF)J

    .line 99
    .line 100
    .line 101
    move-result-wide v4

    .line 102
    iget-wide v6, p0, Li4/b;->k:J

    .line 103
    .line 104
    cmp-long v4, v4, v6

    .line 105
    .line 106
    if-gez v4, :cond_6c

    .line 107
    .line 108
    goto :goto_b1

    .line 109
    :cond_6c
    invoke-static {p3}, Li4/b;->w(Ljava/util/List;)J

    .line 110
    .line 111
    .line 112
    invoke-virtual {p0}, Li4/b;->v()J

    .line 113
    .line 114
    .line 115
    move-result-wide v4

    .line 116
    invoke-virtual {p0, v0, v1, v4, v5}, Li4/b;->u(JJ)I

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    iget-object v1, p0, Li4/c;->d:[Lk3/w;

    .line 121
    .line 122
    aget-object v0, v1, v0

    .line 123
    .line 124
    :goto_7b
    if-ge v3, v2, :cond_b1

    .line 125
    .line 126
    invoke-interface {p3, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    check-cast v1, Lg4/b;

    .line 131
    .line 132
    iget-object v4, v1, Lg4/a;->d:Lk3/w;

    .line 133
    .line 134
    iget-wide v8, v1, Lg4/a;->g:J

    .line 135
    .line 136
    sub-long/2addr v8, p1

    .line 137
    iget v1, p0, Li4/b;->r:F

    .line 138
    .line 139
    invoke-static {v8, v9, v1}, Ln3/l0;->F(JF)J

    .line 140
    .line 141
    .line 142
    move-result-wide v8

    .line 143
    cmp-long v1, v8, v6

    .line 144
    .line 145
    if-ltz v1, :cond_ae

    .line 146
    .line 147
    iget v1, v4, Lk3/w;->k:I

    .line 148
    .line 149
    iget v5, v0, Lk3/w;->k:I

    .line 150
    .line 151
    if-ge v1, v5, :cond_ae

    .line 152
    .line 153
    iget v1, v4, Lk3/w;->x:I

    .line 154
    .line 155
    const/4 v5, -0x1

    .line 156
    if-eq v1, v5, :cond_ae

    .line 157
    .line 158
    iget v8, p0, Li4/b;->m:I

    .line 159
    .line 160
    if-gt v1, v8, :cond_ae

    .line 161
    .line 162
    iget v4, v4, Lk3/w;->w:I

    .line 163
    .line 164
    if-eq v4, v5, :cond_ae

    .line 165
    .line 166
    iget v5, p0, Li4/b;->l:I

    .line 167
    .line 168
    if-gt v4, v5, :cond_ae

    .line 169
    .line 170
    iget v4, v0, Lk3/w;->x:I

    .line 171
    .line 172
    if-ge v1, v4, :cond_ae

    .line 173
    .line 174
    return v3

    .line 175
    :cond_ae
    add-int/lit8 v3, v3, 0x1

    .line 176
    .line 177
    goto :goto_7b

    .line 178
    :cond_b1
    :goto_b1
    return v2
.end method

.method public final j()I
    .registers 2

    .line 1
    iget v0, p0, Li4/b;->t:I

    .line 2
    .line 3
    return v0
.end method

.method public final l(F)V
    .registers 2

    .line 1
    iput p1, p0, Li4/b;->r:F

    .line 2
    .line 3
    return-void
.end method

.method public final m()Ljava/lang/Object;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final q(JJJLjava/util/List;[Lg4/c;)V
    .registers 19

    .line 1
    move-object/from16 p1, p8

    .line 2
    .line 3
    iget-object p2, p0, Li4/b;->q:Ln3/e0;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    iget p2, p0, Li4/b;->s:I

    .line 13
    .line 14
    array-length v2, p1

    .line 15
    const/4 v3, 0x0

    .line 16
    if-ge p2, v2, :cond_27

    .line 17
    .line 18
    aget-object p2, p1, p2

    .line 19
    .line 20
    invoke-interface {p2}, Lg4/c;->next()Z

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    if-eqz p2, :cond_27

    .line 25
    .line 26
    iget p2, p0, Li4/b;->s:I

    .line 27
    .line 28
    aget-object p1, p1, p2

    .line 29
    .line 30
    invoke-interface {p1}, Lg4/c;->j()J

    .line 31
    .line 32
    .line 33
    move-result-wide v4

    .line 34
    invoke-interface {p1}, Lg4/c;->e()J

    .line 35
    .line 36
    .line 37
    move-result-wide p1

    .line 38
    sub-long/2addr v4, p1

    .line 39
    goto :goto_45

    .line 40
    :cond_27
    array-length p2, p1

    .line 41
    move v2, v3

    .line 42
    :goto_29
    if-ge v2, p2, :cond_41

    .line 43
    .line 44
    aget-object v4, p1, v2

    .line 45
    .line 46
    invoke-interface {v4}, Lg4/c;->next()Z

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    if-eqz v5, :cond_3e

    .line 51
    .line 52
    invoke-interface {v4}, Lg4/c;->j()J

    .line 53
    .line 54
    .line 55
    move-result-wide p1

    .line 56
    invoke-interface {v4}, Lg4/c;->e()J

    .line 57
    .line 58
    .line 59
    move-result-wide v4

    .line 60
    sub-long v4, p1, v4

    .line 61
    .line 62
    goto :goto_45

    .line 63
    :cond_3e
    add-int/lit8 v2, v2, 0x1

    .line 64
    .line 65
    goto :goto_29

    .line 66
    :cond_41
    invoke-static/range {p7 .. p7}, Li4/b;->w(Ljava/util/List;)J

    .line 67
    .line 68
    .line 69
    move-result-wide v4

    .line 70
    :goto_45
    invoke-virtual {p0}, Li4/b;->v()J

    .line 71
    .line 72
    .line 73
    move-result-wide p1

    .line 74
    iget v2, p0, Li4/b;->t:I

    .line 75
    .line 76
    if-nez v2, :cond_57

    .line 77
    .line 78
    const/4 v2, 0x1

    .line 79
    iput v2, p0, Li4/b;->t:I

    .line 80
    .line 81
    invoke-virtual {p0, v0, v1, p1, p2}, Li4/b;->u(JJ)I

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    iput p1, p0, Li4/b;->s:I

    .line 86
    .line 87
    return-void

    .line 88
    :cond_57
    iget v6, p0, Li4/b;->s:I

    .line 89
    .line 90
    invoke-interface/range {p7 .. p7}, Ljava/util/List;->isEmpty()Z

    .line 91
    .line 92
    .line 93
    move-result v7

    .line 94
    const/4 v8, -0x1

    .line 95
    if-eqz v7, :cond_62

    .line 96
    .line 97
    :cond_60
    move v3, v8

    .line 98
    goto :goto_78

    .line 99
    :cond_62
    invoke-static/range {p7 .. p7}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v7

    .line 103
    check-cast v7, Lg4/b;

    .line 104
    .line 105
    iget-object v7, v7, Lg4/a;->d:Lk3/w;

    .line 106
    .line 107
    :goto_6a
    iget v9, p0, Li4/c;->b:I

    .line 108
    .line 109
    if-ge v3, v9, :cond_60

    .line 110
    .line 111
    iget-object v9, p0, Li4/c;->d:[Lk3/w;

    .line 112
    .line 113
    aget-object v9, v9, v3

    .line 114
    .line 115
    if-ne v9, v7, :cond_75

    .line 116
    .line 117
    goto :goto_78

    .line 118
    :cond_75
    add-int/lit8 v3, v3, 0x1

    .line 119
    .line 120
    goto :goto_6a

    .line 121
    :goto_78
    if-eq v3, v8, :cond_83

    .line 122
    .line 123
    invoke-static/range {p7 .. p7}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    check-cast v2, Lg4/b;

    .line 128
    .line 129
    iget v2, v2, Lg4/a;->e:I

    .line 130
    .line 131
    move v6, v3

    .line 132
    :cond_83
    invoke-virtual {p0, v0, v1, p1, p2}, Li4/b;->u(JJ)I

    .line 133
    .line 134
    .line 135
    move-result p1

    .line 136
    if-eq p1, v6, :cond_bc

    .line 137
    .line 138
    invoke-virtual {p0, v6, v0, v1}, Li4/c;->a(IJ)Z

    .line 139
    .line 140
    .line 141
    move-result p2

    .line 142
    if-nez p2, :cond_bc

    .line 143
    .line 144
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    cmp-long p2, p5, v0

    .line 150
    .line 151
    iget-wide v7, p0, Li4/b;->i:J

    .line 152
    .line 153
    if-nez p2, :cond_9b

    .line 154
    .line 155
    goto :goto_ac

    .line 156
    :cond_9b
    cmp-long p2, v4, v0

    .line 157
    .line 158
    if-eqz p2, :cond_a2

    .line 159
    .line 160
    sub-long v0, p5, v4

    .line 161
    .line 162
    goto :goto_a3

    .line 163
    :cond_a2
    move-wide v0, p5

    .line 164
    :goto_a3
    long-to-float p2, v0

    .line 165
    iget v0, p0, Li4/b;->o:F

    .line 166
    .line 167
    mul-float/2addr p2, v0

    .line 168
    float-to-long v0, p2

    .line 169
    invoke-static {v0, v1, v7, v8}, Ljava/lang/Math;->min(JJ)J

    .line 170
    .line 171
    .line 172
    move-result-wide v7

    .line 173
    :goto_ac
    if-ge p1, v6, :cond_b3

    .line 174
    .line 175
    cmp-long p2, p3, v7

    .line 176
    .line 177
    if-gez p2, :cond_b3

    .line 178
    .line 179
    goto :goto_bb

    .line 180
    :cond_b3
    if-le p1, v6, :cond_bc

    .line 181
    .line 182
    iget-wide v0, p0, Li4/b;->j:J

    .line 183
    .line 184
    cmp-long p2, p3, v0

    .line 185
    .line 186
    if-ltz p2, :cond_bc

    .line 187
    .line 188
    :goto_bb
    move p1, v6

    .line 189
    :cond_bc
    if-ne p1, v6, :cond_bf

    .line 190
    .line 191
    goto :goto_c0

    .line 192
    :cond_bf
    const/4 v2, 0x3

    .line 193
    :goto_c0
    iput v2, p0, Li4/b;->t:I

    .line 194
    .line 195
    iput p1, p0, Li4/b;->s:I

    .line 196
    .line 197
    return-void
.end method

.method public final u(JJ)I
    .registers 9

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :goto_2
    iget v2, p0, Li4/c;->b:I

    .line 4
    .line 5
    if-ge v0, v2, :cond_22

    .line 6
    .line 7
    const-wide/high16 v2, -0x8000000000000000L

    .line 8
    .line 9
    cmp-long v2, p1, v2

    .line 10
    .line 11
    if-eqz v2, :cond_12

    .line 12
    .line 13
    invoke-virtual {p0, v0, p1, p2}, Li4/c;->a(IJ)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-nez v2, :cond_1f

    .line 18
    .line 19
    :cond_12
    iget-object v1, p0, Li4/c;->d:[Lk3/w;

    .line 20
    .line 21
    aget-object v1, v1, v0

    .line 22
    .line 23
    iget v1, v1, Lk3/w;->k:I

    .line 24
    .line 25
    int-to-long v1, v1

    .line 26
    cmp-long v1, v1, p3

    .line 27
    .line 28
    if-gtz v1, :cond_1e

    .line 29
    .line 30
    return v0

    .line 31
    :cond_1e
    move v1, v0

    .line 32
    :cond_1f
    add-int/lit8 v0, v0, 0x1

    .line 33
    .line 34
    goto :goto_2

    .line 35
    :cond_22
    return v1
.end method

.method public final v()J
    .registers 9

    .line 1
    iget-object v0, p0, Li4/b;->h:Lj4/d;

    .line 2
    .line 3
    invoke-interface {v0}, Lj4/d;->d()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    long-to-float v0, v0

    .line 8
    iget v1, p0, Li4/b;->n:F

    .line 9
    .line 10
    mul-float/2addr v0, v1

    .line 11
    float-to-long v0, v0

    .line 12
    long-to-float v0, v0

    .line 13
    iget v1, p0, Li4/b;->r:F

    .line 14
    .line 15
    div-float/2addr v0, v1

    .line 16
    float-to-long v0, v0

    .line 17
    iget-object v2, p0, Li4/b;->p:Lhx/m0;

    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_19

    .line 24
    .line 25
    return-wide v0

    .line 26
    :cond_19
    const/4 v3, 0x1

    .line 27
    move v4, v3

    .line 28
    :goto_1b
    invoke-virtual {v2}, Ljava/util/AbstractCollection;->size()I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    sub-int/2addr v5, v3

    .line 33
    if-ge v4, v5, :cond_31

    .line 34
    .line 35
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    check-cast v5, Li4/a;

    .line 40
    .line 41
    iget-wide v5, v5, Li4/a;->a:J

    .line 42
    .line 43
    cmp-long v5, v5, v0

    .line 44
    .line 45
    if-gez v5, :cond_31

    .line 46
    .line 47
    add-int/lit8 v4, v4, 0x1

    .line 48
    .line 49
    goto :goto_1b

    .line 50
    :cond_31
    add-int/lit8 v3, v4, -0x1

    .line 51
    .line 52
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Li4/a;

    .line 57
    .line 58
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    check-cast v2, Li4/a;

    .line 63
    .line 64
    iget-wide v4, v3, Li4/a;->a:J

    .line 65
    .line 66
    sub-long/2addr v0, v4

    .line 67
    long-to-float v0, v0

    .line 68
    iget-wide v6, v2, Li4/a;->a:J

    .line 69
    .line 70
    sub-long/2addr v6, v4

    .line 71
    long-to-float v1, v6

    .line 72
    div-float/2addr v0, v1

    .line 73
    iget-wide v3, v3, Li4/a;->b:J

    .line 74
    .line 75
    iget-wide v1, v2, Li4/a;->b:J

    .line 76
    .line 77
    sub-long/2addr v1, v3

    .line 78
    long-to-float v1, v1

    .line 79
    mul-float/2addr v0, v1

    .line 80
    float-to-long v0, v0

    .line 81
    add-long/2addr v3, v0

    .line 82
    return-wide v3
.end method
