###### Class i4.l (i4.l)
.class public interface abstract Li4/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(ILk3/o1;[I)Lhx/w1;
.end method
