###### Class i4.m (i4.m)
.class public abstract Li4/m;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final d:I

.field public final e:Lk3/o1;

.field public final i:I

.field public final v:Lk3/w;


# direct methods
.method public constructor <init>(ILk3/o1;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Li4/m;->d:I

    .line 5
    .line 6
    iput-object p2, p0, Li4/m;->e:Lk3/o1;

    .line 7
    .line 8
    iput p3, p0, Li4/m;->i:I

    .line 9
    .line 10
    iget-object p1, p2, Lk3/o1;->d:[Lk3/w;

    .line 11
    .line 12
    aget-object p1, p1, p3

    .line 13
    .line 14
    iput-object p1, p0, Li4/m;->v:Lk3/w;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public abstract a()I
.end method

.method public abstract b(Li4/m;)Z
.end method
