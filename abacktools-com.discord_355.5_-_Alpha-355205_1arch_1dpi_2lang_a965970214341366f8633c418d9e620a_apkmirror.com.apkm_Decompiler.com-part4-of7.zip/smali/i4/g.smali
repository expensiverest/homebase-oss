###### Class i4.g (i4.g)
.class public final Li4/g;
.super Li4/m;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public final w:I

.field public final x:I


# direct methods
.method public constructor <init>(ILk3/o1;ILi4/j;I)V
    .registers 6

    .line 1
    invoke-direct {p0, p1, p2, p3}, Li4/m;-><init>(ILk3/o1;I)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p4, Li4/j;->B0:Z

    .line 5
    .line 6
    invoke-static {p5, p1}, Lv3/a;->m(IZ)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    iput p1, p0, Li4/g;->w:I

    .line 11
    .line 12
    iget-object p1, p0, Li4/m;->v:Lk3/w;

    .line 13
    .line 14
    iget p2, p1, Lk3/w;->w:I

    .line 15
    .line 16
    const/4 p3, -0x1

    .line 17
    if-eq p2, p3, :cond_19

    .line 18
    .line 19
    iget p1, p1, Lk3/w;->x:I

    .line 20
    .line 21
    if-ne p1, p3, :cond_17

    .line 22
    .line 23
    goto :goto_19

    .line 24
    :cond_17
    mul-int p3, p2, p1

    .line 25
    .line 26
    :cond_19
    :goto_19
    iput p3, p0, Li4/g;->x:I

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, Li4/g;->w:I

    .line 2
    .line 3
    return v0
.end method

.method public final bridge synthetic b(Li4/m;)Z
    .registers 2

    .line 1
    check-cast p1, Li4/g;

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    return p1
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 3

    .line 1
    check-cast p1, Li4/g;

    .line 2
    .line 3
    iget v0, p0, Li4/g;->x:I

    .line 4
    .line 5
    iget p1, p1, Li4/g;->x:I

    .line 6
    .line 7
    invoke-static {v0, p1}, Ljava/lang/Integer;->compare(II)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1
.end method
