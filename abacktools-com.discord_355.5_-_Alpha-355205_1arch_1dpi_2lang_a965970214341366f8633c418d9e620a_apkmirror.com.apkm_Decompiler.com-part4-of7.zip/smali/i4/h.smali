###### Class i4.h (i4.h)
.class public final Li4/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public final d:Z

.field public final e:Z


# direct methods
.method public constructor <init>(Lk3/w;I)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget p1, p1, Lk3/w;->e:I

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    and-int/2addr p1, v0

    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz p1, :cond_b

    .line 10
    .line 11
    goto :goto_c

    .line 12
    :cond_b
    move v0, v1

    .line 13
    :goto_c
    iput-boolean v0, p0, Li4/h;->d:Z

    .line 14
    .line 15
    invoke-static {p2, v1}, Lv3/a;->m(IZ)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    iput-boolean p1, p0, Li4/h;->e:Z

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 5

    .line 1
    check-cast p1, Li4/h;

    .line 2
    .line 3
    iget-boolean v0, p0, Li4/h;->e:Z

    .line 4
    .line 5
    iget-boolean v1, p1, Li4/h;->e:Z

    .line 6
    .line 7
    sget-object v2, Lhx/a0;->a:Lhx/y;

    .line 8
    .line 9
    invoke-virtual {v2, v0, v1}, Lhx/y;->c(ZZ)Lhx/a0;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iget-boolean v1, p0, Li4/h;->d:Z

    .line 14
    .line 15
    iget-boolean p1, p1, Li4/h;->d:Z

    .line 16
    .line 17
    invoke-virtual {v0, v1, p1}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {p1}, Lhx/a0;->e()I

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    return p1
.end method
