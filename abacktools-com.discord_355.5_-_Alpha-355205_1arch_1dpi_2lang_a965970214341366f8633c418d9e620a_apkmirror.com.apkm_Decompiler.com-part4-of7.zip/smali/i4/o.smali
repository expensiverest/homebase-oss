###### Class i4.o (i4.o)
.class public final Li4/o;
.super Lcom/facebook/react/devsupport/g;
.source "SourceFile"


# static fields
.field public static final k:Lhx/u1;


# instance fields
.field public final c:Landroid/content/Context;

.field public final d:Lay/f;

.field public e:Li4/j;

.field public f:Li4/j;

.field public volatile g:Ljava/lang/Thread;

.field public h:Ll4/b;

.field public i:Lk3/e;

.field public j:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, La4/h;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1}, La4/h;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0}, Lhx/u1;->a(Ljava/util/Comparator;)Lhx/u1;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Li4/o;->k:Lhx/u1;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 5

    .line 1
    new-instance v0, Lay/f;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lay/f;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sget-object v1, Li4/j;->F0:Li4/j;

    .line 9
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    if-eqz p1, :cond_13

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v2, 0x0

    .line 21
    :goto_14
    iput-object v2, p0, Li4/o;->c:Landroid/content/Context;

    .line 22
    .line 23
    iput-object v0, p0, Li4/o;->d:Lay/f;

    .line 24
    .line 25
    if-eqz v1, :cond_1b

    .line 26
    .line 27
    goto :goto_2b

    .line 28
    :cond_1b
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    new-instance v0, Li4/i;

    .line 32
    .line 33
    invoke-direct {v0, v1}, Li4/i;-><init>(Li4/j;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0, v1}, Lk3/s1;->e(Lk3/t1;)V

    .line 37
    .line 38
    .line 39
    new-instance v1, Li4/j;

    .line 40
    .line 41
    invoke-direct {v1, v0}, Li4/j;-><init>(Li4/i;)V

    .line 42
    .line 43
    .line 44
    :goto_2b
    iput-object v1, p0, Li4/o;->e:Li4/j;

    .line 45
    .line 46
    iput-object v1, p0, Li4/o;->f:Li4/j;

    .line 47
    .line 48
    sget-object v0, Lk3/e;->i:Lk3/e;

    .line 49
    .line 50
    iput-object v0, p0, Li4/o;->i:Lk3/e;

    .line 51
    .line 52
    iget-boolean v0, v1, Li4/j;->A0:Z

    .line 53
    .line 54
    if-eqz v0, :cond_40

    .line 55
    .line 56
    if-nez p1, :cond_40

    .line 57
    .line 58
    const-string p1, "DefaultTrackSelector"

    .line 59
    .line 60
    const-string v0, "Audio channel count constraints cannot be applied without reference to Context. Build the track selector instance with one of the non-deprecated constructors that take a Context argument."

    .line 61
    .line 62
    invoke-static {p1, v0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    :cond_40
    return-void
.end method

.method public static A(Lf4/q1;Lk3/t1;Ljava/util/HashMap;)V
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    iget v1, p0, Lf4/q1;->a:I

    .line 3
    .line 4
    if-ge v0, v1, :cond_40

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lf4/q1;->a(I)Lk3/o1;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iget-object v2, p1, Lk3/t1;->H:Lhx/p0;

    .line 11
    .line 12
    invoke-virtual {v2, v1}, Lhx/p0;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    check-cast v1, Lk3/p1;

    .line 17
    .line 18
    if-nez v1, :cond_14

    .line 19
    .line 20
    goto :goto_3d

    .line 21
    :cond_14
    iget-object v2, v1, Lk3/p1;->a:Lk3/o1;

    .line 22
    .line 23
    iget v3, v2, Lk3/o1;->c:I

    .line 24
    .line 25
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    invoke-virtual {p2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    check-cast v3, Lk3/p1;

    .line 34
    .line 35
    if-eqz v3, :cond_34

    .line 36
    .line 37
    iget-object v3, v3, Lk3/p1;->b:Lhx/m0;

    .line 38
    .line 39
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-eqz v3, :cond_3d

    .line 44
    .line 45
    iget-object v3, v1, Lk3/p1;->b:Lhx/m0;

    .line 46
    .line 47
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    if-nez v3, :cond_3d

    .line 52
    .line 53
    :cond_34
    iget v2, v2, Lk3/o1;->c:I

    .line 54
    .line 55
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-virtual {p2, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    :cond_3d
    :goto_3d
    add-int/lit8 v0, v0, 0x1

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_40
    return-void
.end method

.method public static B([Li4/p;I)Landroid/util/Pair;
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    array-length v1, p0

    .line 3
    if-ge v0, v1, :cond_1a

    .line 4
    .line 5
    aget-object v1, p0, v0

    .line 6
    .line 7
    if-eqz v1, :cond_17

    .line 8
    .line 9
    iget-object v2, v1, Li4/p;->a:Lk3/o1;

    .line 10
    .line 11
    iget v2, v2, Lk3/o1;->c:I

    .line 12
    .line 13
    if-ne v2, p1, :cond_17

    .line 14
    .line 15
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-static {v1, p0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0

    .line 24
    :cond_17
    add-int/lit8 v0, v0, 0x1

    .line 25
    .line 26
    goto :goto_1

    .line 27
    :cond_1a
    const/4 p0, 0x0

    .line 28
    return-object p0
.end method

.method public static C(Lk3/w;Ljava/lang/String;Z)I
    .registers 5

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_10

    .line 6
    .line 7
    iget-object v0, p0, Lk3/w;->d:Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_10

    .line 14
    .line 15
    const/4 p0, 0x4

    .line 16
    return p0

    .line 17
    :cond_10
    invoke-static {p1}, Li4/o;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iget-object p0, p0, Lk3/w;->d:Ljava/lang/String;

    .line 22
    .line 23
    invoke-static {p0}, Li4/o;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    const/4 v0, 0x0

    .line 28
    if-eqz p0, :cond_48

    .line 29
    .line 30
    if-nez p1, :cond_20

    .line 31
    .line 32
    goto :goto_48

    .line 33
    :cond_20
    invoke-virtual {p0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    if-nez p2, :cond_46

    .line 38
    .line 39
    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 40
    .line 41
    .line 42
    move-result p2

    .line 43
    if-eqz p2, :cond_2d

    .line 44
    .line 45
    goto :goto_46

    .line 46
    :cond_2d
    sget-object p2, Ln3/l0;->a:Ljava/lang/String;

    .line 47
    .line 48
    const-string p2, "-"

    .line 49
    .line 50
    const/4 v1, 0x2

    .line 51
    invoke-virtual {p0, p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    aget-object p0, p0, v0

    .line 56
    .line 57
    invoke-virtual {p1, p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    aget-object p1, p1, v0

    .line 62
    .line 63
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-eqz p0, :cond_45

    .line 68
    .line 69
    return v1

    .line 70
    :cond_45
    return v0

    .line 71
    :cond_46
    :goto_46
    const/4 p0, 0x3

    .line 72
    return p0

    .line 73
    :cond_48
    :goto_48
    if-eqz p2, :cond_4e

    .line 74
    .line 75
    if-nez p0, :cond_4e

    .line 76
    .line 77
    const/4 p0, 0x1

    .line 78
    return p0

    .line 79
    :cond_4e
    return v0
.end method

.method public static D(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_10

    .line 6
    .line 7
    const-string v0, "und"

    .line 8
    .line 9
    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    goto :goto_10

    .line 16
    :cond_f
    return-object p0

    .line 17
    :cond_10
    :goto_10
    const/4 p0, 0x0

    .line 18
    return-object p0
.end method

.method public static E(Li4/j;ILk3/w;)Z
    .registers 5

    .line 1
    and-int/lit16 v0, p1, 0xe00

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_6

    .line 5
    .line 6
    return v1

    .line 7
    :cond_6
    iget-object p0, p0, Lk3/t1;->w:Lk3/r1;

    .line 8
    .line 9
    iget-boolean v0, p0, Lk3/r1;->c:Z

    .line 10
    .line 11
    if-eqz v0, :cond_11

    .line 12
    .line 13
    and-int/lit16 v0, p1, 0x800

    .line 14
    .line 15
    if-nez v0, :cond_11

    .line 16
    .line 17
    return v1

    .line 18
    :cond_11
    iget-boolean p0, p0, Lk3/r1;->b:Z

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    if-eqz p0, :cond_2f

    .line 22
    .line 23
    iget p0, p2, Lk3/w;->N:I

    .line 24
    .line 25
    if-nez p0, :cond_21

    .line 26
    .line 27
    iget p0, p2, Lk3/w;->O:I

    .line 28
    .line 29
    if-eqz p0, :cond_1f

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    move p0, v1

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    :goto_21
    move p0, v0

    .line 35
    :goto_22
    and-int/lit16 p1, p1, 0x400

    .line 36
    .line 37
    if-eqz p1, :cond_28

    .line 38
    .line 39
    move p1, v0

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move p1, v1

    .line 42
    :goto_29
    if-eqz p0, :cond_2f

    .line 43
    .line 44
    if-eqz p1, :cond_2e

    .line 45
    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    return v1

    .line 48
    :cond_2f
    :goto_2f
    return v0
.end method

.method public static F(Lf4/q1;[[ILi4/j;)Li4/p;
    .registers 16

    .line 1
    iget-object v0, p2, Lk3/t1;->w:Lk3/r1;

    .line 2
    .line 3
    iget v0, v0, Lk3/r1;->a:I

    .line 4
    .line 5
    const/4 v1, 0x2

    .line 6
    const/4 v2, 0x0

    .line 7
    if-ne v0, v1, :cond_9

    .line 8
    .line 9
    goto :goto_57

    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    move v1, v0

    .line 12
    move v4, v1

    .line 13
    move-object v3, v2

    .line 14
    move-object v5, v3

    .line 15
    :goto_e
    iget v6, p0, Lf4/q1;->a:I

    .line 16
    .line 17
    if-ge v1, v6, :cond_55

    .line 18
    .line 19
    invoke-virtual {p0, v1}, Lf4/q1;->a(I)Lk3/o1;

    .line 20
    .line 21
    .line 22
    move-result-object v6

    .line 23
    aget-object v7, p1, v1

    .line 24
    .line 25
    move v8, v0

    .line 26
    :goto_19
    iget v9, v6, Lk3/o1;->a:I

    .line 27
    .line 28
    if-ge v8, v9, :cond_52

    .line 29
    .line 30
    aget v9, v7, v8

    .line 31
    .line 32
    iget-boolean v10, p2, Li4/j;->B0:Z

    .line 33
    .line 34
    invoke-static {v9, v10}, Lv3/a;->m(IZ)Z

    .line 35
    .line 36
    .line 37
    move-result v9

    .line 38
    if-eqz v9, :cond_4f

    .line 39
    .line 40
    iget-object v9, v6, Lk3/o1;->d:[Lk3/w;

    .line 41
    .line 42
    aget-object v9, v9, v8

    .line 43
    .line 44
    new-instance v10, Li4/h;

    .line 45
    .line 46
    aget v11, v7, v8

    .line 47
    .line 48
    invoke-direct {v10, v9, v11}, Li4/h;-><init>(Lk3/w;I)V

    .line 49
    .line 50
    .line 51
    if-eqz v5, :cond_4c

    .line 52
    .line 53
    iget-boolean v9, v10, Li4/h;->e:Z

    .line 54
    .line 55
    iget-boolean v11, v5, Li4/h;->e:Z

    .line 56
    .line 57
    sget-object v12, Lhx/a0;->a:Lhx/y;

    .line 58
    .line 59
    invoke-virtual {v12, v9, v11}, Lhx/y;->c(ZZ)Lhx/a0;

    .line 60
    .line 61
    .line 62
    move-result-object v9

    .line 63
    iget-boolean v11, v10, Li4/h;->d:Z

    .line 64
    .line 65
    iget-boolean v12, v5, Li4/h;->d:Z

    .line 66
    .line 67
    invoke-virtual {v9, v11, v12}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    invoke-virtual {v9}, Lhx/a0;->e()I

    .line 72
    .line 73
    .line 74
    move-result v9

    .line 75
    if-lez v9, :cond_4f

    .line 76
    .line 77
    :cond_4c
    move-object v3, v6

    .line 78
    move v4, v8

    .line 79
    move-object v5, v10

    .line 80
    :cond_4f
    add-int/lit8 v8, v8, 0x1

    .line 81
    .line 82
    goto :goto_19

    .line 83
    :cond_52
    add-int/lit8 v1, v1, 0x1

    .line 84
    .line 85
    goto :goto_e

    .line 86
    :cond_55
    if-nez v3, :cond_58

    .line 87
    .line 88
    :goto_57
    return-object v2

    .line 89
    :cond_58
    new-instance p0, Li4/p;

    .line 90
    .line 91
    filled-new-array {v4}, [I

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-direct {p0, v3, p1}, Li4/p;-><init>(Lk3/o1;[I)V

    .line 96
    .line 97
    .line 98
    return-object p0
.end method

.method public static G(ILi4/s;[[[ILi4/l;Ljava/util/Comparator;)Landroid/util/Pair;
    .registers 23

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    new-instance v1, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 6
    .line 7
    .line 8
    iget v2, v0, Li4/s;->a:I

    .line 9
    .line 10
    const/4 v4, 0x0

    .line 11
    :goto_a
    if-ge v4, v2, :cond_a1

    .line 12
    .line 13
    iget-object v5, v0, Li4/s;->b:[I

    .line 14
    .line 15
    aget v5, v5, v4

    .line 16
    .line 17
    move/from16 v6, p0

    .line 18
    .line 19
    if-ne v6, v5, :cond_95

    .line 20
    .line 21
    iget-object v5, v0, Li4/s;->c:[Lf4/q1;

    .line 22
    .line 23
    aget-object v5, v5, v4

    .line 24
    .line 25
    const/4 v7, 0x0

    .line 26
    :goto_19
    iget v8, v5, Lf4/q1;->a:I

    .line 27
    .line 28
    if-ge v7, v8, :cond_95

    .line 29
    .line 30
    invoke-virtual {v5, v7}, Lf4/q1;->a(I)Lk3/o1;

    .line 31
    .line 32
    .line 33
    move-result-object v8

    .line 34
    aget-object v9, p2, v4

    .line 35
    .line 36
    aget-object v9, v9, v7

    .line 37
    .line 38
    move-object/from16 v10, p3

    .line 39
    .line 40
    invoke-interface {v10, v4, v8, v9}, Li4/l;->f(ILk3/o1;[I)Lhx/w1;

    .line 41
    .line 42
    .line 43
    move-result-object v9

    .line 44
    iget v8, v8, Lk3/o1;->a:I

    .line 45
    .line 46
    new-array v11, v8, [Z

    .line 47
    .line 48
    const/4 v12, 0x0

    .line 49
    :goto_30
    if-ge v12, v8, :cond_8e

    .line 50
    .line 51
    invoke-virtual {v9, v12}, Lhx/w1;->get(I)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v13

    .line 55
    check-cast v13, Li4/m;

    .line 56
    .line 57
    invoke-virtual {v13}, Li4/m;->a()I

    .line 58
    .line 59
    .line 60
    move-result v14

    .line 61
    aget-boolean v15, v11, v12

    .line 62
    .line 63
    if-nez v15, :cond_42

    .line 64
    .line 65
    if-nez v14, :cond_45

    .line 66
    .line 67
    :cond_42
    move/from16 v16, v2

    .line 68
    .line 69
    goto :goto_87

    .line 70
    :cond_45
    const/4 v15, 0x1

    .line 71
    if-ne v14, v15, :cond_4f

    .line 72
    .line 73
    invoke-static {v13}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 74
    .line 75
    .line 76
    move-result-object v13

    .line 77
    :goto_4c
    move/from16 v16, v2

    .line 78
    .line 79
    goto :goto_84

    .line 80
    :cond_4f
    new-instance v14, Ljava/util/ArrayList;

    .line 81
    .line 82
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v14, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    add-int/lit8 v16, v12, 0x1

    .line 89
    .line 90
    move/from16 v17, v15

    .line 91
    .line 92
    move/from16 v15, v16

    .line 93
    .line 94
    :goto_5d
    if-ge v15, v8, :cond_82

    .line 95
    .line 96
    invoke-virtual {v9, v15}, Lhx/w1;->get(I)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v16

    .line 100
    move-object/from16 v3, v16

    .line 101
    .line 102
    check-cast v3, Li4/m;

    .line 103
    .line 104
    invoke-virtual {v3}, Li4/m;->a()I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    move/from16 v16, v2

    .line 109
    .line 110
    const/4 v2, 0x2

    .line 111
    if-ne v0, v2, :cond_7b

    .line 112
    .line 113
    invoke-virtual {v13, v3}, Li4/m;->b(Li4/m;)Z

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    if-eqz v0, :cond_7b

    .line 118
    .line 119
    invoke-virtual {v14, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    aput-boolean v17, v11, v15

    .line 123
    .line 124
    :cond_7b
    add-int/lit8 v15, v15, 0x1

    .line 125
    .line 126
    move-object/from16 v0, p1

    .line 127
    .line 128
    move/from16 v2, v16

    .line 129
    .line 130
    goto :goto_5d

    .line 131
    :cond_82
    move-object v13, v14

    .line 132
    goto :goto_4c

    .line 133
    :goto_84
    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    :goto_87
    add-int/lit8 v12, v12, 0x1

    .line 137
    .line 138
    move-object/from16 v0, p1

    .line 139
    .line 140
    move/from16 v2, v16

    .line 141
    .line 142
    goto :goto_30

    .line 143
    :cond_8e
    move/from16 v16, v2

    .line 144
    .line 145
    add-int/lit8 v7, v7, 0x1

    .line 146
    .line 147
    move-object/from16 v0, p1

    .line 148
    .line 149
    goto :goto_19

    .line 150
    :cond_95
    move-object/from16 v10, p3

    .line 151
    .line 152
    move/from16 v16, v2

    .line 153
    .line 154
    add-int/lit8 v4, v4, 0x1

    .line 155
    .line 156
    move-object/from16 v0, p1

    .line 157
    .line 158
    move/from16 v2, v16

    .line 159
    .line 160
    goto/16 :goto_a

    .line 161
    .line 162
    :cond_a1
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-eqz v0, :cond_a9

    .line 167
    .line 168
    const/4 v0, 0x0

    .line 169
    return-object v0

    .line 170
    :cond_a9
    move-object/from16 v0, p4

    .line 171
    .line 172
    invoke-static {v1, v0}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    check-cast v0, Ljava/util/List;

    .line 177
    .line 178
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    new-array v1, v1, [I

    .line 183
    .line 184
    const/4 v2, 0x0

    .line 185
    :goto_b8
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    if-ge v2, v3, :cond_cb

    .line 190
    .line 191
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v3

    .line 195
    check-cast v3, Li4/m;

    .line 196
    .line 197
    iget v3, v3, Li4/m;->i:I

    .line 198
    .line 199
    aput v3, v1, v2

    .line 200
    .line 201
    add-int/lit8 v2, v2, 0x1

    .line 202
    .line 203
    goto :goto_b8

    .line 204
    :cond_cb
    const/4 v2, 0x0

    .line 205
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    check-cast v0, Li4/m;

    .line 210
    .line 211
    new-instance v2, Li4/p;

    .line 212
    .line 213
    iget-object v3, v0, Li4/m;->e:Lk3/o1;

    .line 214
    .line 215
    invoke-direct {v2, v3, v1}, Li4/p;-><init>(Lk3/o1;[I)V

    .line 216
    .line 217
    .line 218
    iget v0, v0, Li4/m;->d:I

    .line 219
    .line 220
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-static {v2, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    return-object v0
.end method

.method public static w(Lk3/w;Lhx/m0;)I
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :goto_2
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    .line 4
    .line 5
    .line 6
    move-result v2

    .line 7
    if-ge v1, v2, :cond_2c

    .line 8
    .line 9
    move v2, v0

    .line 10
    :goto_9
    iget-object v3, p0, Lk3/w;->c:Lhx/m0;

    .line 11
    .line 12
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-ge v2, v3, :cond_29

    .line 17
    .line 18
    iget-object v3, p0, Lk3/w;->c:Lhx/m0;

    .line 19
    .line 20
    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    check-cast v3, Lk3/z;

    .line 25
    .line 26
    iget-object v3, v3, Lk3/z;->b:Ljava/lang/String;

    .line 27
    .line 28
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-eqz v3, :cond_26

    .line 37
    .line 38
    return v1

    .line 39
    :cond_26
    add-int/lit8 v2, v2, 0x1

    .line 40
    .line 41
    goto :goto_9

    .line 42
    :cond_29
    add-int/lit8 v1, v1, 0x1

    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_2c
    const p0, 0x7fffffff

    .line 46
    .line 47
    .line 48
    return p0
.end method

.method public static x(Li4/s;Li4/j;[Li4/p;)V
    .registers 7

    .line 1
    iget v0, p0, Li4/s;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    :goto_3
    if-ge v1, v0, :cond_36

    .line 5
    .line 6
    iget-object v2, p0, Li4/s;->c:[Lf4/q1;

    .line 7
    .line 8
    aget-object v2, v2, v1

    .line 9
    .line 10
    iget-object v3, p1, Li4/j;->D0:Landroid/util/SparseArray;

    .line 11
    .line 12
    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    check-cast v3, Ljava/util/Map;

    .line 17
    .line 18
    if-eqz v3, :cond_33

    .line 19
    .line 20
    invoke-interface {v3, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-eqz v3, :cond_33

    .line 25
    .line 26
    iget-object v3, p1, Li4/j;->D0:Landroid/util/SparseArray;

    .line 27
    .line 28
    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    check-cast v3, Ljava/util/Map;

    .line 33
    .line 34
    if-eqz v3, :cond_30

    .line 35
    .line 36
    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    if-nez v2, :cond_2a

    .line 41
    .line 42
    goto :goto_30

    .line 43
    :cond_2a
    new-instance p0, Ljava/lang/ClassCastException;

    .line 44
    .line 45
    invoke-direct {p0}, Ljava/lang/ClassCastException;-><init>()V

    .line 46
    .line 47
    .line 48
    throw p0

    .line 49
    :cond_30
    :goto_30
    const/4 v2, 0x0

    .line 50
    aput-object v2, p2, v1

    .line 51
    .line 52
    :cond_33
    add-int/lit8 v1, v1, 0x1

    .line 53
    .line 54
    goto :goto_3

    .line 55
    :cond_36
    return-void
.end method

.method public static y(Li4/s;Li4/j;[Li4/p;)V
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    iget v1, p0, Li4/s;->a:I

    .line 3
    .line 4
    if-ge v0, v1, :cond_23

    .line 5
    .line 6
    iget-object v1, p0, Li4/s;->b:[I

    .line 7
    .line 8
    aget v1, v1, v0

    .line 9
    .line 10
    iget-object v2, p1, Li4/j;->E0:Landroid/util/SparseBooleanArray;

    .line 11
    .line 12
    invoke-virtual {v2, v0}, Landroid/util/SparseBooleanArray;->get(I)Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-nez v2, :cond_1d

    .line 17
    .line 18
    iget-object v2, p1, Lk3/t1;->I:Lhx/x0;

    .line 19
    .line 20
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v2, v1}, Lhx/h0;->contains(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-eqz v1, :cond_20

    .line 29
    .line 30
    :cond_1d
    const/4 v1, 0x0

    .line 31
    aput-object v1, p2, v0

    .line 32
    .line 33
    :cond_20
    add-int/lit8 v0, v0, 0x1

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_23
    return-void
.end method

.method public static z(Li4/s;Li4/j;[Li4/p;)V
    .registers 10

    .line 1
    iget v0, p0, Li4/s;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Li4/s;->c:[Lf4/q1;

    .line 4
    .line 5
    new-instance v2, Ljava/util/HashMap;

    .line 6
    .line 7
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 8
    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    move v4, v3

    .line 12
    :goto_b
    if-ge v4, v0, :cond_15

    .line 13
    .line 14
    aget-object v5, v1, v4

    .line 15
    .line 16
    invoke-static {v5, p1, v2}, Li4/o;->A(Lf4/q1;Lk3/t1;Ljava/util/HashMap;)V

    .line 17
    .line 18
    .line 19
    add-int/lit8 v4, v4, 0x1

    .line 20
    .line 21
    goto :goto_b

    .line 22
    :cond_15
    iget-object v4, p0, Li4/s;->f:Lf4/q1;

    .line 23
    .line 24
    invoke-static {v4, p1, v2}, Li4/o;->A(Lf4/q1;Lk3/t1;Ljava/util/HashMap;)V

    .line 25
    .line 26
    .line 27
    :goto_1a
    if-ge v3, v0, :cond_50

    .line 28
    .line 29
    iget-object p1, p0, Li4/s;->b:[I

    .line 30
    .line 31
    aget p1, p1, v3

    .line 32
    .line 33
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    check-cast p1, Lk3/p1;

    .line 42
    .line 43
    if-nez p1, :cond_2d

    .line 44
    .line 45
    goto :goto_4d

    .line 46
    :cond_2d
    iget-object v4, p1, Lk3/p1;->a:Lk3/o1;

    .line 47
    .line 48
    iget-object p1, p1, Lk3/p1;->b:Lhx/m0;

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v5

    .line 54
    if-nez v5, :cond_4a

    .line 55
    .line 56
    aget-object v5, v1, v3

    .line 57
    .line 58
    invoke-virtual {v5, v4}, Lf4/q1;->b(Lk3/o1;)I

    .line 59
    .line 60
    .line 61
    move-result v5

    .line 62
    const/4 v6, -0x1

    .line 63
    if-eq v5, v6, :cond_4a

    .line 64
    .line 65
    new-instance v5, Li4/p;

    .line 66
    .line 67
    invoke-static {p1}, Lc7/t;->O(Ljava/util/Collection;)[I

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    invoke-direct {v5, v4, p1}, Li4/p;-><init>(Lk3/o1;[I)V

    .line 72
    .line 73
    .line 74
    goto :goto_4b

    .line 75
    :cond_4a
    const/4 v5, 0x0

    .line 76
    :goto_4b
    aput-object v5, p2, v3

    .line 77
    .line 78
    :goto_4d
    add-int/lit8 v3, v3, 0x1

    .line 79
    .line 80
    goto :goto_1a

    .line 81
    :cond_50
    return-void
.end method


# virtual methods
.method public final H(Li4/j;)V
    .registers 4

    .line 1
    iget-object v0, p0, Li4/o;->e:Li4/j;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Li4/j;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iput-object p1, p0, Li4/o;->e:Li4/j;

    .line 8
    .line 9
    if-nez v0, :cond_2a

    .line 10
    .line 11
    iget-boolean v0, p1, Li4/j;->A0:Z

    .line 12
    .line 13
    if-eqz v0, :cond_19

    .line 14
    .line 15
    iget-object v0, p0, Li4/o;->c:Landroid/content/Context;

    .line 16
    .line 17
    if-nez v0, :cond_19

    .line 18
    .line 19
    const-string v0, "DefaultTrackSelector"

    .line 20
    .line 21
    const-string v1, "Audio channel count constraints cannot be applied without reference to Context. Build the track selector instance with one of the non-deprecated constructors that take a Context argument."

    .line 22
    .line 23
    invoke-static {v0, v1}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :cond_19
    iget-object v0, p0, Lcom/facebook/react/devsupport/g;->a:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v0, Lv3/e0;

    .line 29
    .line 30
    if-eqz v0, :cond_2a

    .line 31
    .line 32
    iget-object v0, v0, Lv3/e0;->y:Ln3/g0;

    .line 33
    .line 34
    const/16 v1, 0xa

    .line 35
    .line 36
    invoke-virtual {v0, v1, p1}, Ln3/g0;->c(ILjava/lang/Object;)Ln3/f0;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    invoke-virtual {p1}, Ln3/f0;->b()V

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void
.end method

.method public final p(Lk3/t1;)V
    .registers 4

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    instance-of v0, p1, Li4/j;

    .line 5
    .line 6
    if-eqz v0, :cond_c

    .line 7
    .line 8
    check-cast p1, Li4/j;

    .line 9
    .line 10
    iput-object p1, p0, Li4/o;->f:Li4/j;

    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    new-instance v0, Li4/i;

    .line 14
    .line 15
    iget-object v1, p0, Li4/o;->f:Li4/j;

    .line 16
    .line 17
    invoke-direct {v0, v1}, Li4/i;-><init>(Li4/j;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, p1}, Lk3/s1;->e(Lk3/t1;)V

    .line 21
    .line 22
    .line 23
    new-instance p1, Li4/j;

    .line 24
    .line 25
    invoke-direct {p1, v0}, Li4/j;-><init>(Li4/i;)V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, Li4/o;->f:Li4/j;

    .line 29
    .line 30
    return-void
.end method
