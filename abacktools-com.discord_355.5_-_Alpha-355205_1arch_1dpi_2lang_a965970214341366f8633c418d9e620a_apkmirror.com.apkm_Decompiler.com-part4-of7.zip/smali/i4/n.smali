###### Class i4.n (i4.n)
.class public final Li4/n;
.super Li4/m;
.source "SourceFile"


# instance fields
.field public final J:Z

.field public final K:Z

.field public final L:I

.field public final M:I

.field public final N:I

.field public final O:I

.field public final P:I

.field public final Q:I

.field public final R:I

.field public final S:Z

.field public final T:I

.field public final U:Z

.field public final V:I

.field public final W:Z

.field public final X:Z

.field public final Y:Z

.field public final Z:I

.field public final a0:Z

.field public final b0:Ljava/lang/String;

.field public final w:Z

.field public final x:Li4/j;

.field public final y:Z


# direct methods
.method public constructor <init>(ILk3/o1;ILi4/j;ILjava/lang/String;IZ)V
    .registers 15

    .line 1
    invoke-direct {p0, p1, p2, p3}, Li4/m;-><init>(ILk3/o1;I)V

    .line 2
    .line 3
    .line 4
    iput-object p4, p0, Li4/n;->x:Li4/j;

    .line 5
    .line 6
    iget-boolean p1, p4, Li4/j;->x0:Z

    .line 7
    .line 8
    iget-object p2, p4, Lk3/t1;->m:Lhx/m0;

    .line 9
    .line 10
    iget-object p3, p4, Lk3/t1;->o:Lhx/m0;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    const/16 p1, 0x18

    .line 15
    .line 16
    goto :goto_12

    .line 17
    :cond_10
    const/16 p1, 0x10

    .line 18
    .line 19
    :goto_12
    const/4 p7, 0x0

    .line 20
    iput-boolean p7, p0, Li4/n;->U:Z

    .line 21
    .line 22
    const/high16 v0, -0x40800000    # -1.0f

    .line 23
    .line 24
    const/4 v1, -0x1

    .line 25
    const/4 v2, 0x1

    .line 26
    if-eqz p8, :cond_44

    .line 27
    .line 28
    iget-object v3, p0, Li4/m;->v:Lk3/w;

    .line 29
    .line 30
    iget v4, v3, Lk3/w;->w:I

    .line 31
    .line 32
    if-eq v4, v1, :cond_25

    .line 33
    .line 34
    iget v5, p4, Lk3/t1;->a:I

    .line 35
    .line 36
    if-gt v4, v5, :cond_44

    .line 37
    .line 38
    :cond_25
    iget v4, v3, Lk3/w;->x:I

    .line 39
    .line 40
    if-eq v4, v1, :cond_2d

    .line 41
    .line 42
    iget v5, p4, Lk3/t1;->b:I

    .line 43
    .line 44
    if-gt v4, v5, :cond_44

    .line 45
    .line 46
    :cond_2d
    iget v4, v3, Lk3/w;->B:F

    .line 47
    .line 48
    cmpl-float v5, v4, v0

    .line 49
    .line 50
    if-eqz v5, :cond_3a

    .line 51
    .line 52
    iget v5, p4, Lk3/t1;->c:I

    .line 53
    .line 54
    int-to-float v5, v5

    .line 55
    cmpg-float v4, v4, v5

    .line 56
    .line 57
    if-gtz v4, :cond_44

    .line 58
    .line 59
    :cond_3a
    iget v3, v3, Lk3/w;->k:I

    .line 60
    .line 61
    if-eq v3, v1, :cond_42

    .line 62
    .line 63
    iget v4, p4, Lk3/t1;->d:I

    .line 64
    .line 65
    if-gt v3, v4, :cond_44

    .line 66
    .line 67
    :cond_42
    move v3, v2

    .line 68
    goto :goto_45

    .line 69
    :cond_44
    move v3, p7

    .line 70
    :goto_45
    iput-boolean v3, p0, Li4/n;->w:Z

    .line 71
    .line 72
    if-eqz p8, :cond_72

    .line 73
    .line 74
    iget-object p8, p0, Li4/m;->v:Lk3/w;

    .line 75
    .line 76
    iget v3, p8, Lk3/w;->w:I

    .line 77
    .line 78
    if-eq v3, v1, :cond_53

    .line 79
    .line 80
    iget v4, p4, Lk3/t1;->e:I

    .line 81
    .line 82
    if-lt v3, v4, :cond_72

    .line 83
    .line 84
    :cond_53
    iget v3, p8, Lk3/w;->x:I

    .line 85
    .line 86
    if-eq v3, v1, :cond_5b

    .line 87
    .line 88
    iget v4, p4, Lk3/t1;->f:I

    .line 89
    .line 90
    if-lt v3, v4, :cond_72

    .line 91
    .line 92
    :cond_5b
    iget v3, p8, Lk3/w;->B:F

    .line 93
    .line 94
    cmpl-float v4, v3, v0

    .line 95
    .line 96
    if-eqz v4, :cond_68

    .line 97
    .line 98
    iget v4, p4, Lk3/t1;->g:I

    .line 99
    .line 100
    int-to-float v4, v4

    .line 101
    cmpl-float v3, v3, v4

    .line 102
    .line 103
    if-ltz v3, :cond_72

    .line 104
    .line 105
    :cond_68
    iget p8, p8, Lk3/w;->k:I

    .line 106
    .line 107
    if-eq p8, v1, :cond_70

    .line 108
    .line 109
    iget v3, p4, Lk3/t1;->h:I

    .line 110
    .line 111
    if-lt p8, v3, :cond_72

    .line 112
    .line 113
    :cond_70
    move p8, v2

    .line 114
    goto :goto_73

    .line 115
    :cond_72
    move p8, p7

    .line 116
    :goto_73
    iput-boolean p8, p0, Li4/n;->y:Z

    .line 117
    .line 118
    invoke-static {p5, p7}, Lv3/a;->m(IZ)Z

    .line 119
    .line 120
    .line 121
    move-result p8

    .line 122
    iput-boolean p8, p0, Li4/n;->J:Z

    .line 123
    .line 124
    iget-object p8, p0, Li4/m;->v:Lk3/w;

    .line 125
    .line 126
    iget v3, p8, Lk3/w;->B:F

    .line 127
    .line 128
    cmpl-float v0, v3, v0

    .line 129
    .line 130
    if-eqz v0, :cond_8b

    .line 131
    .line 132
    const/high16 v0, 0x41200000    # 10.0f

    .line 133
    .line 134
    cmpl-float v0, v3, v0

    .line 135
    .line 136
    if-ltz v0, :cond_8b

    .line 137
    .line 138
    move v0, v2

    .line 139
    goto :goto_8c

    .line 140
    :cond_8b
    move v0, p7

    .line 141
    :goto_8c
    iput-boolean v0, p0, Li4/n;->K:Z

    .line 142
    .line 143
    iget v0, p8, Lk3/w;->k:I

    .line 144
    .line 145
    iput v0, p0, Li4/n;->L:I

    .line 146
    .line 147
    iget v0, p8, Lk3/w;->w:I

    .line 148
    .line 149
    if-eq v0, v1, :cond_9d

    .line 150
    .line 151
    iget p8, p8, Lk3/w;->x:I

    .line 152
    .line 153
    if-ne p8, v1, :cond_9b

    .line 154
    .line 155
    goto :goto_9d

    .line 156
    :cond_9b
    mul-int/2addr v0, p8

    .line 157
    goto :goto_9e

    .line 158
    :cond_9d
    :goto_9d
    move v0, v1

    .line 159
    :goto_9e
    iput v0, p0, Li4/n;->M:I

    .line 160
    .line 161
    move p8, p7

    .line 162
    :goto_a1
    invoke-virtual {p3}, Ljava/util/AbstractCollection;->size()I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    const v3, 0x7fffffff

    .line 167
    .line 168
    .line 169
    if-ge p8, v0, :cond_bc

    .line 170
    .line 171
    iget-object v0, p0, Li4/m;->v:Lk3/w;

    .line 172
    .line 173
    invoke-interface {p3, p8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v4

    .line 177
    check-cast v4, Ljava/lang/String;

    .line 178
    .line 179
    invoke-static {v0, v4, p7}, Li4/o;->C(Lk3/w;Ljava/lang/String;Z)I

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    if-lez v0, :cond_b9

    .line 184
    .line 185
    goto :goto_be

    .line 186
    :cond_b9
    add-int/lit8 p8, p8, 0x1

    .line 187
    .line 188
    goto :goto_a1

    .line 189
    :cond_bc
    move v0, p7

    .line 190
    move p8, v3

    .line 191
    :goto_be
    iput p8, p0, Li4/n;->O:I

    .line 192
    .line 193
    iput v0, p0, Li4/n;->P:I

    .line 194
    .line 195
    iget-object p3, p0, Li4/m;->v:Lk3/w;

    .line 196
    .line 197
    iget p3, p3, Lk3/w;->f:I

    .line 198
    .line 199
    iget p8, p4, Lk3/t1;->p:I

    .line 200
    .line 201
    sget-object v0, Li4/o;->k:Lhx/u1;

    .line 202
    .line 203
    if-eqz p3, :cond_d0

    .line 204
    .line 205
    if-ne p3, p8, :cond_d0

    .line 206
    .line 207
    move p3, v3

    .line 208
    goto :goto_d5

    .line 209
    :cond_d0
    and-int/2addr p3, p8

    .line 210
    invoke-static {p3}, Ljava/lang/Integer;->bitCount(I)I

    .line 211
    .line 212
    .line 213
    move-result p3

    .line 214
    :goto_d5
    iput p3, p0, Li4/n;->Q:I

    .line 215
    .line 216
    iget-object p3, p0, Li4/m;->v:Lk3/w;

    .line 217
    .line 218
    iget p3, p3, Lk3/w;->f:I

    .line 219
    .line 220
    if-eqz p3, :cond_e3

    .line 221
    .line 222
    and-int/2addr p3, v2

    .line 223
    if-eqz p3, :cond_e1

    .line 224
    .line 225
    goto :goto_e3

    .line 226
    :cond_e1
    move p3, p7

    .line 227
    goto :goto_e4

    .line 228
    :cond_e3
    :goto_e3
    move p3, v2

    .line 229
    :goto_e4
    iput-boolean p3, p0, Li4/n;->S:Z

    .line 230
    .line 231
    invoke-static {p6}, Li4/o;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object p3

    .line 235
    if-nez p3, :cond_ee

    .line 236
    .line 237
    move p3, v2

    .line 238
    goto :goto_ef

    .line 239
    :cond_ee
    move p3, p7

    .line 240
    :goto_ef
    iget-object p8, p0, Li4/m;->v:Lk3/w;

    .line 241
    .line 242
    invoke-static {p8, p6, p3}, Li4/o;->C(Lk3/w;Ljava/lang/String;Z)I

    .line 243
    .line 244
    .line 245
    move-result p3

    .line 246
    iput p3, p0, Li4/n;->T:I

    .line 247
    .line 248
    iget-object p3, p0, Li4/m;->v:Lk3/w;

    .line 249
    .line 250
    iget-object p6, p3, Lk3/w;->p:Ljava/lang/String;

    .line 251
    .line 252
    and-int/lit16 p8, p5, 0x180

    .line 253
    .line 254
    const/16 v0, 0x100

    .line 255
    .line 256
    if-ne p8, v0, :cond_108

    .line 257
    .line 258
    invoke-static {p3}, Lc4/b0;->c(Lk3/w;)Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object p3

    .line 262
    if-eqz p3, :cond_108

    .line 263
    .line 264
    move-object p6, p3

    .line 265
    :cond_108
    move p3, p7

    .line 266
    :goto_109
    invoke-virtual {p2}, Ljava/util/AbstractCollection;->size()I

    .line 267
    .line 268
    .line 269
    move-result v4

    .line 270
    if-ge p3, v4, :cond_120

    .line 271
    .line 272
    if-eqz p6, :cond_11d

    .line 273
    .line 274
    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object v4

    .line 278
    invoke-virtual {p6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 279
    .line 280
    .line 281
    move-result v4

    .line 282
    if-eqz v4, :cond_11d

    .line 283
    .line 284
    move v3, p3

    .line 285
    goto :goto_120

    .line 286
    :cond_11d
    add-int/lit8 p3, p3, 0x1

    .line 287
    .line 288
    goto :goto_109

    .line 289
    :cond_120
    :goto_120
    iput v3, p0, Li4/n;->N:I

    .line 290
    .line 291
    iget-object p2, p0, Li4/m;->v:Lk3/w;

    .line 292
    .line 293
    iget-object p3, p4, Lk3/t1;->n:Lhx/m0;

    .line 294
    .line 295
    invoke-static {p2, p3}, Li4/o;->w(Lk3/w;Lhx/m0;)I

    .line 296
    .line 297
    .line 298
    move-result p2

    .line 299
    iput p2, p0, Li4/n;->R:I

    .line 300
    .line 301
    const/16 p2, 0x80

    .line 302
    .line 303
    if-eq p8, p2, :cond_135

    .line 304
    .line 305
    if-ne p8, v0, :cond_133

    .line 306
    .line 307
    goto :goto_135

    .line 308
    :cond_133
    move p3, p7

    .line 309
    goto :goto_136

    .line 310
    :cond_135
    :goto_135
    move p3, v2

    .line 311
    :goto_136
    iput-boolean p3, p0, Li4/n;->W:Z

    .line 312
    .line 313
    if-ne p8, p2, :cond_13c

    .line 314
    .line 315
    move p2, v2

    .line 316
    goto :goto_13d

    .line 317
    :cond_13c
    move p2, p7

    .line 318
    :goto_13d
    iput-boolean p2, p0, Li4/n;->X:Z

    .line 319
    .line 320
    and-int/lit8 p3, p5, 0x40

    .line 321
    .line 322
    const/16 p4, 0x40

    .line 323
    .line 324
    if-ne p3, p4, :cond_147

    .line 325
    .line 326
    move p3, v2

    .line 327
    goto :goto_148

    .line 328
    :cond_147
    move p3, p7

    .line 329
    :goto_148
    iput-boolean p3, p0, Li4/n;->Y:Z

    .line 330
    .line 331
    iput-object p6, p0, Li4/n;->b0:Ljava/lang/String;

    .line 332
    .line 333
    const/4 p3, 0x2

    .line 334
    if-nez p6, :cond_150

    .line 335
    .line 336
    goto :goto_194

    .line 337
    :cond_150
    invoke-virtual {p6}, Ljava/lang/String;->hashCode()I

    .line 338
    .line 339
    .line 340
    move-result p4

    .line 341
    const/4 p8, 0x4

    .line 342
    const/4 v0, 0x3

    .line 343
    sparse-switch p4, :sswitch_data_1f4

    .line 344
    .line 345
    .line 346
    :goto_159
    move p4, v1

    .line 347
    goto :goto_191

    .line 348
    :sswitch_15b
    const-string p4, "video/x-vnd.on2.vp9"

    .line 349
    .line 350
    invoke-virtual {p6, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    move-result p4

    .line 354
    if-nez p4, :cond_164

    .line 355
    .line 356
    goto :goto_159

    .line 357
    :cond_164
    move p4, p8

    .line 358
    goto :goto_191

    .line 359
    :sswitch_166
    const-string p4, "video/avc"

    .line 360
    .line 361
    invoke-virtual {p6, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 362
    .line 363
    .line 364
    move-result p4

    .line 365
    if-nez p4, :cond_16f

    .line 366
    .line 367
    goto :goto_159

    .line 368
    :cond_16f
    move p4, v0

    .line 369
    goto :goto_191

    .line 370
    :sswitch_171
    const-string p4, "video/hevc"

    .line 371
    .line 372
    invoke-virtual {p6, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 373
    .line 374
    .line 375
    move-result p4

    .line 376
    if-nez p4, :cond_17a

    .line 377
    .line 378
    goto :goto_159

    .line 379
    :cond_17a
    move p4, p3

    .line 380
    goto :goto_191

    .line 381
    :sswitch_17c
    const-string p4, "video/av01"

    .line 382
    .line 383
    invoke-virtual {p6, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 384
    .line 385
    .line 386
    move-result p4

    .line 387
    if-nez p4, :cond_185

    .line 388
    .line 389
    goto :goto_159

    .line 390
    :cond_185
    move p4, v2

    .line 391
    goto :goto_191

    .line 392
    :sswitch_187
    const-string p4, "video/dolby-vision"

    .line 393
    .line 394
    invoke-virtual {p6, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 395
    .line 396
    .line 397
    move-result p4

    .line 398
    if-nez p4, :cond_190

    .line 399
    .line 400
    goto :goto_159

    .line 401
    :cond_190
    move p4, p7

    .line 402
    :goto_191
    packed-switch p4, :pswitch_data_20a

    .line 403
    .line 404
    .line 405
    :goto_194
    move p8, p7

    .line 406
    goto :goto_19d

    .line 407
    :pswitch_196
    move p8, p3

    .line 408
    goto :goto_19d

    .line 409
    :pswitch_198
    move p8, v2

    .line 410
    goto :goto_19d

    .line 411
    :pswitch_19a
    move p8, v0

    .line 412
    goto :goto_19d

    .line 413
    :pswitch_19c
    const/4 p8, 0x5

    .line 414
    :goto_19d
    :pswitch_19d
    iput p8, p0, Li4/n;->Z:I

    .line 415
    .line 416
    if-eqz p2, :cond_1b3

    .line 417
    .line 418
    iget-object p2, p0, Li4/m;->v:Lk3/w;

    .line 419
    .line 420
    iget-object p2, p2, Lk3/w;->H:Lk3/m;

    .line 421
    .line 422
    if-eqz p2, :cond_1b1

    .line 423
    .line 424
    iget p2, p2, Lk3/m;->c:I

    .line 425
    .line 426
    const/4 p4, 0x7

    .line 427
    if-eq p2, p4, :cond_1af

    .line 428
    .line 429
    const/4 p4, 0x6

    .line 430
    if-ne p2, p4, :cond_1b3

    .line 431
    .line 432
    :cond_1af
    move p2, v2

    .line 433
    goto :goto_1b4

    .line 434
    :cond_1b1
    sget-object p2, Lk3/m;->h:Lk3/m;

    .line 435
    .line 436
    :cond_1b3
    move p2, p7

    .line 437
    :goto_1b4
    iput-boolean p2, p0, Li4/n;->a0:Z

    .line 438
    .line 439
    iget-boolean p2, p0, Li4/n;->w:Z

    .line 440
    .line 441
    iget-object p4, p0, Li4/n;->x:Li4/j;

    .line 442
    .line 443
    iget-object p6, p0, Li4/m;->v:Lk3/w;

    .line 444
    .line 445
    iget p8, p6, Lk3/w;->f:I

    .line 446
    .line 447
    and-int/lit16 p8, p8, 0x4000

    .line 448
    .line 449
    if-eqz p8, :cond_1c3

    .line 450
    .line 451
    goto :goto_1f1

    .line 452
    :cond_1c3
    iget-boolean p8, p4, Li4/j;->B0:Z

    .line 453
    .line 454
    invoke-static {p5, p8}, Lv3/a;->m(IZ)Z

    .line 455
    .line 456
    .line 457
    move-result p8

    .line 458
    if-nez p8, :cond_1cc

    .line 459
    .line 460
    goto :goto_1f1

    .line 461
    :cond_1cc
    if-nez p2, :cond_1d3

    .line 462
    .line 463
    iget-boolean p8, p4, Li4/j;->w0:Z

    .line 464
    .line 465
    if-nez p8, :cond_1d3

    .line 466
    .line 467
    goto :goto_1f1

    .line 468
    :cond_1d3
    invoke-static {p5, p7}, Lv3/a;->m(IZ)Z

    .line 469
    .line 470
    .line 471
    move-result p7

    .line 472
    if-eqz p7, :cond_1f0

    .line 473
    .line 474
    iget-boolean p7, p0, Li4/n;->y:Z

    .line 475
    .line 476
    if-eqz p7, :cond_1f0

    .line 477
    .line 478
    if-eqz p2, :cond_1f0

    .line 479
    .line 480
    iget p2, p6, Lk3/w;->k:I

    .line 481
    .line 482
    if-eq p2, v1, :cond_1f0

    .line 483
    .line 484
    iget-boolean p2, p4, Lk3/t1;->G:Z

    .line 485
    .line 486
    if-nez p2, :cond_1f0

    .line 487
    .line 488
    iget-boolean p2, p4, Lk3/t1;->F:Z

    .line 489
    .line 490
    if-nez p2, :cond_1f0

    .line 491
    .line 492
    and-int/2addr p1, p5

    .line 493
    if-eqz p1, :cond_1f0

    .line 494
    .line 495
    move p7, p3

    .line 496
    goto :goto_1f1

    .line 497
    :cond_1f0
    move p7, v2

    .line 498
    :goto_1f1
    iput p7, p0, Li4/n;->V:I

    .line 499
    .line 500
    return-void

    :sswitch_data_1f4
    .sparse-switch
        -0x6e5534ef -> :sswitch_187
        -0x631b55f6 -> :sswitch_17c
        -0x63185e82 -> :sswitch_171
        0x4f62373a -> :sswitch_166
        0x5f50bed9 -> :sswitch_15b
    .end sparse-switch

    :pswitch_data_20a
    .packed-switch 0x0
        :pswitch_19c
        :pswitch_19d
        :pswitch_19a
        :pswitch_198
        :pswitch_196
    .end packed-switch
.end method

.method public static c(Li4/n;Li4/n;)I
    .registers 6

    .line 1
    iget-boolean v0, p0, Li4/n;->J:Z

    .line 2
    .line 3
    iget-boolean v1, p1, Li4/n;->J:Z

    .line 4
    .line 5
    sget-object v2, Lhx/a0;->a:Lhx/y;

    .line 6
    .line 7
    invoke-virtual {v2, v0, v1}, Lhx/y;->c(ZZ)Lhx/a0;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget v1, p0, Li4/n;->O:I

    .line 12
    .line 13
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    iget v2, p1, Li4/n;->O:I

    .line 18
    .line 19
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    sget-object v3, Lhx/r1;->i:Lhx/r1;

    .line 24
    .line 25
    invoke-virtual {v0, v1, v2, v3}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iget v1, p0, Li4/n;->P:I

    .line 30
    .line 31
    iget v2, p1, Li4/n;->P:I

    .line 32
    .line 33
    invoke-virtual {v0, v1, v2}, Lhx/a0;->a(II)Lhx/a0;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iget v1, p0, Li4/n;->Q:I

    .line 38
    .line 39
    iget v2, p1, Li4/n;->Q:I

    .line 40
    .line 41
    invoke-virtual {v0, v1, v2}, Lhx/a0;->a(II)Lhx/a0;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iget v1, p0, Li4/n;->R:I

    .line 46
    .line 47
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    iget v2, p1, Li4/n;->R:I

    .line 52
    .line 53
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v0, v1, v2, v3}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    iget-boolean v1, p0, Li4/n;->S:Z

    .line 62
    .line 63
    iget-boolean v2, p1, Li4/n;->S:Z

    .line 64
    .line 65
    invoke-virtual {v0, v1, v2}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    iget v1, p0, Li4/n;->T:I

    .line 70
    .line 71
    iget v2, p1, Li4/n;->T:I

    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Lhx/a0;->a(II)Lhx/a0;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    iget-boolean v1, p0, Li4/n;->K:Z

    .line 78
    .line 79
    iget-boolean v2, p1, Li4/n;->K:Z

    .line 80
    .line 81
    invoke-virtual {v0, v1, v2}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    iget-boolean v1, p0, Li4/n;->w:Z

    .line 86
    .line 87
    iget-boolean v2, p1, Li4/n;->w:Z

    .line 88
    .line 89
    invoke-virtual {v0, v1, v2}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    iget-boolean v1, p0, Li4/n;->y:Z

    .line 94
    .line 95
    iget-boolean v2, p1, Li4/n;->y:Z

    .line 96
    .line 97
    invoke-virtual {v0, v1, v2}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    iget v1, p0, Li4/n;->N:I

    .line 102
    .line 103
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    iget v2, p1, Li4/n;->N:I

    .line 108
    .line 109
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    invoke-virtual {v0, v1, v2, v3}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    iget-boolean v1, p0, Li4/n;->W:Z

    .line 118
    .line 119
    iget-boolean v2, p1, Li4/n;->W:Z

    .line 120
    .line 121
    invoke-virtual {v0, v1, v2}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    iget-boolean p0, p0, Li4/n;->Y:Z

    .line 126
    .line 127
    iget-boolean p1, p1, Li4/n;->Y:Z

    .line 128
    .line 129
    invoke-virtual {v0, p0, p1}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    invoke-virtual {p0}, Lhx/a0;->e()I

    .line 134
    .line 135
    .line 136
    move-result p0

    .line 137
    return p0
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, Li4/n;->V:I

    .line 2
    .line 3
    return v0
.end method

.method public final b(Li4/m;)Z
    .registers 4

    .line 1
    check-cast p1, Li4/n;

    .line 2
    .line 3
    iget-boolean v0, p0, Li4/n;->U:Z

    .line 4
    .line 5
    if-nez v0, :cond_10

    .line 6
    .line 7
    iget-object v0, p0, Li4/n;->b0:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v1, p1, Li4/n;->b0:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_23

    .line 16
    .line 17
    :cond_10
    iget-object v0, p0, Li4/n;->x:Li4/j;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    iget-boolean v0, p0, Li4/n;->W:Z

    .line 23
    .line 24
    iget-boolean v1, p1, Li4/n;->W:Z

    .line 25
    .line 26
    if-ne v0, v1, :cond_23

    .line 27
    .line 28
    iget-boolean v0, p0, Li4/n;->Y:Z

    .line 29
    .line 30
    iget-boolean p1, p1, Li4/n;->Y:Z

    .line 31
    .line 32
    if-ne v0, p1, :cond_23

    .line 33
    .line 34
    const/4 p1, 0x1

    .line 35
    return p1

    .line 36
    :cond_23
    const/4 p1, 0x0

    .line 37
    return p1
.end method
