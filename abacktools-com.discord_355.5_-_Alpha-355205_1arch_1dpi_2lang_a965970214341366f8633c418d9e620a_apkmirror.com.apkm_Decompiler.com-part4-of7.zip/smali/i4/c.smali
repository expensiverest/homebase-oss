###### Class i4.c (i4.c)
.class public abstract Li4/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li4/q;


# static fields
.field public static final g:La4/h;


# instance fields
.field public final a:Lk3/o1;

.field public final b:I

.field public final c:[I

.field public final d:[Lk3/w;

.field public final e:[J

.field public f:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, La4/h;

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    invoke-direct {v0, v1}, La4/h;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Li4/c;->g:La4/h;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(ILk3/o1;[I)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    array-length p1, p3

    .line 5
    const/4 v0, 0x0

    .line 6
    if-lez p1, :cond_9

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    goto :goto_a

    .line 10
    :cond_9
    move p1, v0

    .line 11
    :goto_a
    invoke-static {p1}, Loq/a;->z(Z)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iput-object p2, p0, Li4/c;->a:Lk3/o1;

    .line 18
    .line 19
    array-length p1, p3

    .line 20
    iput p1, p0, Li4/c;->b:I

    .line 21
    .line 22
    new-array p1, p1, [Lk3/w;

    .line 23
    .line 24
    iput-object p1, p0, Li4/c;->d:[Lk3/w;

    .line 25
    .line 26
    move p1, v0

    .line 27
    :goto_1a
    array-length v1, p3

    .line 28
    if-ge p1, v1, :cond_2a

    .line 29
    .line 30
    iget-object v1, p0, Li4/c;->d:[Lk3/w;

    .line 31
    .line 32
    aget v2, p3, p1

    .line 33
    .line 34
    iget-object v3, p2, Lk3/o1;->d:[Lk3/w;

    .line 35
    .line 36
    aget-object v2, v3, v2

    .line 37
    .line 38
    aput-object v2, v1, p1

    .line 39
    .line 40
    add-int/lit8 p1, p1, 0x1

    .line 41
    .line 42
    goto :goto_1a

    .line 43
    :cond_2a
    iget-object p1, p0, Li4/c;->d:[Lk3/w;

    .line 44
    .line 45
    sget-object p3, Li4/c;->g:La4/h;

    .line 46
    .line 47
    invoke-static {p1, p3}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    .line 48
    .line 49
    .line 50
    iget p1, p0, Li4/c;->b:I

    .line 51
    .line 52
    new-array p1, p1, [I

    .line 53
    .line 54
    iput-object p1, p0, Li4/c;->c:[I

    .line 55
    .line 56
    :goto_37
    iget p1, p0, Li4/c;->b:I

    .line 57
    .line 58
    if-ge v0, p1, :cond_4a

    .line 59
    .line 60
    iget-object p1, p0, Li4/c;->c:[I

    .line 61
    .line 62
    iget-object p3, p0, Li4/c;->d:[Lk3/w;

    .line 63
    .line 64
    aget-object p3, p3, v0

    .line 65
    .line 66
    invoke-virtual {p2, p3}, Lk3/o1;->a(Lk3/w;)I

    .line 67
    .line 68
    .line 69
    move-result p3

    .line 70
    aput p3, p1, v0

    .line 71
    .line 72
    add-int/lit8 v0, v0, 0x1

    .line 73
    .line 74
    goto :goto_37

    .line 75
    :cond_4a
    new-array p1, p1, [J

    .line 76
    .line 77
    iput-object p1, p0, Li4/c;->e:[J

    .line 78
    .line 79
    return-void
.end method


# virtual methods
.method public final a(IJ)Z
    .registers 7

    .line 1
    iget-object v0, p0, Li4/c;->e:[J

    .line 2
    .line 3
    aget-wide v1, v0, p1

    .line 4
    .line 5
    cmp-long p1, v1, p2

    .line 6
    .line 7
    if-lez p1, :cond_a

    .line 8
    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_a
    const/4 p1, 0x0

    .line 12
    return p1
.end method

.method public final b()Lk3/o1;
    .registers 2

    .line 1
    iget-object v0, p0, Li4/c;->a:Lk3/o1;

    .line 2
    .line 3
    return-object v0
.end method

.method public final d(Z)V
    .registers 2

    .line 1
    return-void
.end method

.method public disable()V
    .registers 1

    .line 1
    return-void
.end method

.method public final e(I)Lk3/w;
    .registers 3

    .line 1
    iget-object v0, p0, Li4/c;->d:[Lk3/w;

    .line 2
    .line 3
    aget-object p1, v0, p1

    .line 4
    .line 5
    return-object p1
.end method

.method public enable()V
    .registers 1

    .line 1
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_29

    .line 7
    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    if-eq v2, v3, :cond_12

    .line 17
    .line 18
    goto :goto_29

    .line 19
    :cond_12
    check-cast p1, Li4/c;

    .line 20
    .line 21
    iget-object v2, p0, Li4/c;->a:Lk3/o1;

    .line 22
    .line 23
    iget-object v3, p1, Li4/c;->a:Lk3/o1;

    .line 24
    .line 25
    invoke-virtual {v2, v3}, Lk3/o1;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_29

    .line 30
    .line 31
    iget-object v2, p0, Li4/c;->c:[I

    .line 32
    .line 33
    iget-object p1, p1, Li4/c;->c:[I

    .line 34
    .line 35
    invoke-static {v2, p1}, Ljava/util/Arrays;->equals([I[I)Z

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    if-eqz p1, :cond_29

    .line 40
    .line 41
    return v0

    .line 42
    :cond_29
    :goto_29
    return v1
.end method

.method public final f(I)I
    .registers 3

    .line 1
    iget-object v0, p0, Li4/c;->c:[I

    .line 2
    .line 3
    aget p1, v0, p1

    .line 4
    .line 5
    return p1
.end method

.method public g(JLjava/util/List;)I
    .registers 4

    .line 1
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public final h()I
    .registers 3

    .line 1
    iget-object v0, p0, Li4/c;->c:[I

    .line 2
    .line 3
    invoke-interface {p0}, Li4/q;->c()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    aget v0, v0, v1

    .line 8
    .line 9
    return v0
.end method

.method public final hashCode()I
    .registers 3

    .line 1
    iget v0, p0, Li4/c;->f:I

    .line 2
    .line 3
    if-nez v0, :cond_15

    .line 4
    .line 5
    iget-object v0, p0, Li4/c;->a:Lk3/o1;

    .line 6
    .line 7
    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    mul-int/lit8 v0, v0, 0x1f

    .line 12
    .line 13
    iget-object v1, p0, Li4/c;->c:[I

    .line 14
    .line 15
    invoke-static {v1}, Ljava/util/Arrays;->hashCode([I)I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    add-int/2addr v1, v0

    .line 20
    iput v1, p0, Li4/c;->f:I

    .line 21
    .line 22
    :cond_15
    iget v0, p0, Li4/c;->f:I

    .line 23
    .line 24
    return v0
.end method

.method public final i()Lk3/w;
    .registers 3

    .line 1
    iget-object v0, p0, Li4/c;->d:[Lk3/w;

    .line 2
    .line 3
    invoke-interface {p0}, Li4/q;->c()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    aget-object v0, v0, v1

    .line 8
    .line 9
    return-object v0
.end method

.method public final k(IJ)Z
    .registers 11

    .line 1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    invoke-virtual {p0, p1, v0, v1}, Li4/c;->a(IJ)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x0

    .line 10
    move v4, v3

    .line 11
    :goto_a
    iget v5, p0, Li4/c;->b:I

    .line 12
    .line 13
    const/4 v6, 0x1

    .line 14
    if-ge v4, v5, :cond_1f

    .line 15
    .line 16
    if-nez v2, :cond_1f

    .line 17
    .line 18
    if-eq v4, p1, :cond_1b

    .line 19
    .line 20
    invoke-virtual {p0, v4, v0, v1}, Li4/c;->a(IJ)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-nez v2, :cond_1b

    .line 25
    .line 26
    move v2, v6

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    move v2, v3

    .line 29
    :goto_1c
    add-int/lit8 v4, v4, 0x1

    .line 30
    .line 31
    goto :goto_a

    .line 32
    :cond_1f
    if-nez v2, :cond_22

    .line 33
    .line 34
    return v3

    .line 35
    :cond_22
    iget-object v2, p0, Li4/c;->e:[J

    .line 36
    .line 37
    aget-wide v3, v2, p1

    .line 38
    .line 39
    invoke-static {v0, v1, p2, p3}, Ln3/l0;->a(JJ)J

    .line 40
    .line 41
    .line 42
    move-result-wide p2

    .line 43
    invoke-static {v3, v4, p2, p3}, Ljava/lang/Math;->max(JJ)J

    .line 44
    .line 45
    .line 46
    move-result-wide p2

    .line 47
    aput-wide p2, v2, p1

    .line 48
    .line 49
    return v6
.end method

.method public l(F)V
    .registers 2

    .line 1
    return-void
.end method

.method public final length()I
    .registers 2

    .line 1
    iget-object v0, p0, Li4/c;->c:[I

    .line 2
    .line 3
    array-length v0, v0

    .line 4
    return v0
.end method

.method public final p(I)I
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    iget v1, p0, Li4/c;->b:I

    .line 3
    .line 4
    if-ge v0, v1, :cond_f

    .line 5
    .line 6
    iget-object v1, p0, Li4/c;->c:[I

    .line 7
    .line 8
    aget v1, v1, v0

    .line 9
    .line 10
    if-ne v1, p1, :cond_c

    .line 11
    .line 12
    return v0

    .line 13
    :cond_c
    add-int/lit8 v0, v0, 0x1

    .line 14
    .line 15
    goto :goto_1

    .line 16
    :cond_f
    const/4 p1, -0x1

    .line 17
    return p1
.end method

.method public final r()V
    .registers 4

    .line 1
    iget-object v0, p0, Li4/c;->e:[J

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    invoke-static {v0, v1, v2}, Ljava/util/Arrays;->fill([JJ)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
