###### Class ie.a (ie.a)
.class public final synthetic Lie/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lie/a;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lie/a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lie/a;->a:Lie/a;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.file_manager.react.DiskUsageResult"

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "size"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "timeToMeasure"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "report"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lie/a;->descriptor:Ll70/g;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 21

    .line 1
    sget-object v0, Lie/a;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x2

    .line 14
    const/4 v4, 0x1

    .line 15
    const/4 v5, 0x0

    .line 16
    if-eqz v2, :cond_25

    .line 17
    .line 18
    invoke-interface {v1, v0, v5}, Lm70/a;->I(Ll70/g;I)J

    .line 19
    .line 20
    .line 21
    move-result-wide v5

    .line 22
    invoke-interface {v1, v0, v4}, Lm70/a;->I(Ll70/g;I)J

    .line 23
    .line 24
    .line 25
    move-result-wide v7

    .line 26
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    const/4 v3, 0x7

    .line 31
    move/from16 v18, v3

    .line 32
    .line 33
    move-wide v13, v5

    .line 34
    move-wide v15, v7

    .line 35
    :goto_22
    move-object/from16 v17, v2

    .line 36
    .line 37
    goto :goto_5d

    .line 38
    :cond_25
    const-wide/16 v6, 0x0

    .line 39
    .line 40
    const/4 v2, 0x0

    .line 41
    move v11, v4

    .line 42
    move-wide v9, v6

    .line 43
    move v6, v5

    .line 44
    move-wide v7, v9

    .line 45
    :goto_2c
    if-eqz v11, :cond_58

    .line 46
    .line 47
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 48
    .line 49
    .line 50
    move-result v12

    .line 51
    const/4 v13, -0x1

    .line 52
    if-eq v12, v13, :cond_56

    .line 53
    .line 54
    if-eqz v12, :cond_4f

    .line 55
    .line 56
    if-eq v12, v4, :cond_48

    .line 57
    .line 58
    if-ne v12, v3, :cond_42

    .line 59
    .line 60
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    or-int/lit8 v6, v6, 0x4

    .line 65
    .line 66
    goto :goto_2c

    .line 67
    :cond_42
    new-instance v0, Lj70/k;

    .line 68
    .line 69
    invoke-direct {v0, v12}, Lj70/k;-><init>(I)V

    .line 70
    .line 71
    .line 72
    throw v0

    .line 73
    :cond_48
    invoke-interface {v1, v0, v4}, Lm70/a;->I(Ll70/g;I)J

    .line 74
    .line 75
    .line 76
    move-result-wide v9

    .line 77
    or-int/lit8 v6, v6, 0x2

    .line 78
    .line 79
    goto :goto_2c

    .line 80
    :cond_4f
    invoke-interface {v1, v0, v5}, Lm70/a;->I(Ll70/g;I)J

    .line 81
    .line 82
    .line 83
    move-result-wide v7

    .line 84
    or-int/lit8 v6, v6, 0x1

    .line 85
    .line 86
    goto :goto_2c

    .line 87
    :cond_56
    move v11, v5

    .line 88
    goto :goto_2c

    .line 89
    :cond_58
    move/from16 v18, v6

    .line 90
    .line 91
    move-wide v13, v7

    .line 92
    move-wide v15, v9

    .line 93
    goto :goto_22

    .line 94
    :goto_5d
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 95
    .line 96
    .line 97
    new-instance v12, Lie/c;

    .line 98
    .line 99
    invoke-direct/range {v12 .. v18}, Lie/c;-><init>(JJLjava/lang/String;I)V

    .line 100
    .line 101
    .line 102
    return-object v12
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/l0;->a:Ln70/l0;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    aput-object v1, v0, v2

    .line 11
    .line 12
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    aput-object v1, v0, v2

    .line 16
    .line 17
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lie/c;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lie/a;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-wide v2, p2, Lie/c;->a:J

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2, v3}, Lm70/b;->v(Ll70/g;IJ)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-wide v2, p2, Lie/c;->b:J

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2, v3}, Lm70/b;->v(Ll70/g;IJ)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object p2, p2, Lie/c;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lie/a;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
