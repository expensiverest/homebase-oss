###### Class ig.a (ig.a)
.class public final synthetic Lig/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;

.field public final synthetic w:Ljava/lang/Object;

.field public final synthetic x:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 7

    .line 1
    iput p2, p0, Lig/a;->d:I

    iput-object p3, p0, Lig/a;->i:Ljava/lang/Object;

    iput-object p4, p0, Lig/a;->v:Ljava/lang/Object;

    iput-object p5, p0, Lig/a;->w:Ljava/lang/Object;

    iput p1, p0, Lig/a;->e:I

    iput-object p6, p0, Lig/a;->x:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lv3/u0;Landroid/util/Pair;Lf4/u;Lf4/z;I)V
    .registers 7

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lig/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lig/a;->i:Ljava/lang/Object;

    iput-object p2, p0, Lig/a;->v:Ljava/lang/Object;

    iput-object p3, p0, Lig/a;->w:Ljava/lang/Object;

    iput-object p4, p0, Lig/a;->x:Ljava/lang/Object;

    iput p5, p0, Lig/a;->e:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    .line 1
    iget v0, p0, Lig/a;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_80

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lig/a;->i:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ly5/v0;

    .line 9
    .line 10
    iget-object v1, p0, Lig/a;->v:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lz5/v;

    .line 13
    .line 14
    iget-object v2, p0, Lig/a;->w:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Ly5/y1;

    .line 17
    .line 18
    iget-object v3, p0, Lig/a;->x:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v3, Ly5/u0;

    .line 21
    .line 22
    new-instance v4, Ly5/p0;

    .line 23
    .line 24
    iget v5, p0, Lig/a;->e:I

    .line 25
    .line 26
    invoke-direct {v4, v0, v2, v5, v3}, Ly5/p0;-><init>(Ly5/v0;Ly5/y1;ILy5/u0;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, v1, v4}, Ly5/v0;->J(Lz5/v;Ly5/u0;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_20
    iget-object v0, p0, Lig/a;->i:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, Lv3/u0;

    .line 36
    .line 37
    iget-object v1, p0, Lig/a;->v:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v1, Landroid/util/Pair;

    .line 40
    .line 41
    iget-object v2, p0, Lig/a;->w:Ljava/lang/Object;

    .line 42
    .line 43
    move-object v6, v2

    .line 44
    check-cast v6, Lf4/u;

    .line 45
    .line 46
    iget-object v2, p0, Lig/a;->x:Ljava/lang/Object;

    .line 47
    .line 48
    move-object v7, v2

    .line 49
    check-cast v7, Lf4/z;

    .line 50
    .line 51
    iget-object v0, v0, Lv3/u0;->e:Lmr/j1;

    .line 52
    .line 53
    iget-object v0, v0, Lmr/j1;->k:Ljava/lang/Object;

    .line 54
    .line 55
    move-object v3, v0

    .line 56
    check-cast v3, Lw3/e;

    .line 57
    .line 58
    iget-object v0, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v0, Ljava/lang/Integer;

    .line 61
    .line 62
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 63
    .line 64
    .line 65
    move-result v4

    .line 66
    iget-object v0, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 67
    .line 68
    move-object v5, v0

    .line 69
    check-cast v5, Lf4/d0;

    .line 70
    .line 71
    iget v8, p0, Lig/a;->e:I

    .line 72
    .line 73
    invoke-virtual/range {v3 .. v8}, Lw3/e;->O(ILf4/d0;Lf4/u;Lf4/z;I)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_4c
    iget-object v0, p0, Lig/a;->i:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 80
    .line 81
    iget-object v1, p0, Lig/a;->v:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v1, Ljava/util/concurrent/CompletableFuture;

    .line 84
    .line 85
    iget-object v2, p0, Lig/a;->w:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v2, Landroid/content/Intent;

    .line 88
    .line 89
    iget v3, p0, Lig/a;->e:I

    .line 90
    .line 91
    iget-object v4, p0, Lig/a;->x:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v4, Landroid/os/Bundle;

    .line 94
    .line 95
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    check-cast v0, Landroid/app/Activity;

    .line 100
    .line 101
    if-nez v0, :cond_71

    .line 102
    .line 103
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 104
    .line 105
    const-string v2, "Activity was null"

    .line 106
    .line 107
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v1, v0}, Ljava/util/concurrent/CompletableFuture;->completeExceptionally(Ljava/lang/Throwable;)Z

    .line 111
    .line 112
    .line 113
    goto :goto_7e

    .line 114
    :cond_71
    :try_start_71
    invoke-virtual {v0, v2, v3, v4}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    .line 115
    .line 116
    .line 117
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 118
    .line 119
    invoke-virtual {v1, v0}, Ljava/util/concurrent/CompletableFuture;->complete(Ljava/lang/Object;)Z
    :try_end_79
    .catch Ljava/lang/Exception; {:try_start_71 .. :try_end_79} :catch_7a

    .line 120
    .line 121
    .line 122
    goto :goto_7e

    .line 123
    :catch_7a
    move-exception v0

    .line 124
    invoke-virtual {v1, v0}, Ljava/util/concurrent/CompletableFuture;->completeExceptionally(Ljava/lang/Throwable;)Z

    .line 125
    .line 126
    .line 127
    :goto_7e
    return-void

    .line 128
    nop

    .line 129
    :pswitch_data_80
    .packed-switch 0x0
        :pswitch_4c
        :pswitch_20
    .end packed-switch
.end method

###### Class y5.p0 (y5.p0)
.class public final synthetic Ly5/p0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly5/u0;


# instance fields
.field public final synthetic a:Ly5/v0;

.field public final synthetic b:Ly5/y1;

.field public final synthetic c:I

.field public final synthetic d:Ly5/u0;


# direct methods
.method public synthetic constructor <init>(Ly5/v0;Ly5/y1;ILy5/u0;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ly5/p0;->a:Ly5/v0;

    iput-object p2, p0, Ly5/p0;->b:Ly5/y1;

    iput p3, p0, Ly5/p0;->c:I

    iput-object p4, p0, Ly5/p0;->d:Ly5/u0;

    return-void
.end method


# virtual methods
.method public final a(Ly5/u;)V
    .registers 5

    .line 1
    iget-object v0, p0, Ly5/p0;->d:Ly5/u0;

    .line 2
    .line 3
    iget-object v1, p0, Ly5/p0;->a:Ly5/v0;

    .line 4
    .line 5
    iget-object v1, v1, Ly5/v0;->f:Ly0/c;

    .line 6
    .line 7
    iget-object v2, p0, Ly5/p0;->b:Ly5/y1;

    .line 8
    .line 9
    if-eqz v2, :cond_11

    .line 10
    .line 11
    invoke-virtual {v1, p1, v2}, Ly0/c;->o(Ly5/u;Ly5/y1;)Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_1a

    .line 16
    .line 17
    goto :goto_19

    .line 18
    :cond_11
    iget v2, p0, Ly5/p0;->c:I

    .line 19
    .line 20
    invoke-virtual {v1, p1, v2}, Ly0/c;->n(Ly5/u;I)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-nez v1, :cond_1a

    .line 25
    .line 26
    :goto_19
    return-void

    .line 27
    :cond_1a
    :try_start_1a
    invoke-interface {v0, p1}, Ly5/u0;->a(Ly5/u;)V
    :try_end_1d
    .catch Landroid/os/RemoteException; {:try_start_1a .. :try_end_1d} :catch_1e

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :catch_1e
    move-exception v0

    .line 32
    new-instance v1, Ljava/lang/StringBuilder;

    .line 33
    .line 34
    const-string v2, "Exception in "

    .line 35
    .line 36
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const-string v1, "MediaSessionLegacyStub"

    .line 47
    .line 48
    invoke-static {v1, p1, v0}, Ln3/b;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method
