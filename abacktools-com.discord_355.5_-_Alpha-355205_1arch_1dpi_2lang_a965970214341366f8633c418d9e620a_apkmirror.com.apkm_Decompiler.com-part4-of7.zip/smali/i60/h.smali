###### Class i60.h (i60.h)
.class public final Li60/h;
.super Li60/p;
.source "SourceFile"


# instance fields
.field public final g:Ll60/f;

.field public final h:Lj60/i;

.field public final i:Lj60/i;

.field public final synthetic j:Li60/i;


# direct methods
.method public constructor <init>(Li60/i;Ll60/f;)V
    .registers 10

    .line 1
    const-string v0, "kotlinTypeRefiner"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Li60/h;->j:Li60/i;

    .line 7
    .line 8
    iget-object v2, p1, Li60/i;->N:Lbg/c;

    .line 9
    .line 10
    iget-object v0, p1, Li60/i;->w:Lo50/k;

    .line 11
    .line 12
    iget-object v3, v0, Lo50/k;->S:Ljava/util/List;

    .line 13
    .line 14
    const-string v1, "getFunctionList(...)"

    .line 15
    .line 16
    invoke-static {v3, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v4, v0, Lo50/k;->T:Ljava/util/List;

    .line 20
    .line 21
    const-string v1, "getPropertyList(...)"

    .line 22
    .line 23
    invoke-static {v4, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v5, v0, Lo50/k;->U:Ljava/util/List;

    .line 27
    .line 28
    const-string v1, "getTypeAliasList(...)"

    .line 29
    .line 30
    invoke-static {v5, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, v0, Lo50/k;->M:Ljava/util/List;

    .line 34
    .line 35
    const-string v1, "getNestedClassNameList(...)"

    .line 36
    .line 37
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    iget-object p1, p1, Li60/i;->N:Lbg/c;

    .line 41
    .line 42
    iget-object p1, p1, Lbg/c;->i:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p1, Lq50/f;

    .line 45
    .line 46
    new-instance v1, Ljava/util/ArrayList;

    .line 47
    .line 48
    const/16 v6, 0xa

    .line 49
    .line 50
    invoke-static {v0, v6}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 51
    .line 52
    .line 53
    move-result v6

    .line 54
    invoke-direct {v1, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 55
    .line 56
    .line 57
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    :goto_3c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 62
    .line 63
    .line 64
    move-result v6

    .line 65
    if-eqz v6, :cond_54

    .line 66
    .line 67
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    check-cast v6, Ljava/lang/Number;

    .line 72
    .line 73
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 74
    .line 75
    .line 76
    move-result v6

    .line 77
    invoke-static {p1, v6}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    goto :goto_3c

    .line 85
    :cond_54
    new-instance v6, Li60/e;

    .line 86
    .line 87
    const/4 p1, 0x0

    .line 88
    invoke-direct {v6, p1, v1}, Li60/e;-><init>(ILjava/util/ArrayList;)V

    .line 89
    .line 90
    .line 91
    move-object v1, p0

    .line 92
    invoke-direct/range {v1 .. v6}, Li60/p;-><init>(Lbg/c;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkotlin/jvm/functions/Function0;)V

    .line 93
    .line 94
    .line 95
    iget-object p1, v2, Lbg/c;->e:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast p1, Lg60/i;

    .line 98
    .line 99
    iput-object p2, v1, Li60/h;->g:Ll60/f;

    .line 100
    .line 101
    iget-object p2, p1, Lg60/i;->a:Lj60/l;

    .line 102
    .line 103
    new-instance v0, Li60/f;

    .line 104
    .line 105
    const/4 v2, 0x0

    .line 106
    invoke-direct {v0, p0, v2}, Li60/f;-><init>(Li60/h;I)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    new-instance v2, Lj60/i;

    .line 113
    .line 114
    invoke-direct {v2, p2, v0}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 115
    .line 116
    .line 117
    iput-object v2, v1, Li60/h;->h:Lj60/i;

    .line 118
    .line 119
    iget-object p1, p1, Lg60/i;->a:Lj60/l;

    .line 120
    .line 121
    new-instance p2, Li60/f;

    .line 122
    .line 123
    const/4 v0, 0x1

    .line 124
    invoke-direct {p2, p0, v0}, Li60/f;-><init>(Li60/h;I)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    new-instance v0, Lj60/i;

    .line 131
    .line 132
    invoke-direct {v0, p1, p2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 133
    .line 134
    .line 135
    iput-object v0, v1, Li60/h;->i:Lj60/i;

    .line 136
    .line 137
    return-void
.end method


# virtual methods
.method public final a(Lt50/e;Ly40/c;)Ljava/util/Collection;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, Li60/h;->s(Lt50/e;Ly40/a;)V

    .line 7
    .line 8
    .line 9
    invoke-super {p0, p1, p2}, Li60/p;->a(Lt50/e;Ly40/c;)Ljava/util/Collection;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method

.method public final d(Ld60/f;Lkotlin/jvm/functions/Function1;)Ljava/util/Collection;
    .registers 3

    .line 1
    const-string p2, "kindFilter"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Li60/h;->h:Lj60/i;

    .line 7
    .line 8
    invoke-virtual {p1}, Lj60/i;->invoke()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Ljava/util/Collection;

    .line 13
    .line 14
    return-object p1
.end method

.method public final e(Lt50/e;Ly40/a;)Ljava/util/Collection;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1, p2}, Li60/h;->s(Lt50/e;Ly40/a;)V

    .line 7
    .line 8
    .line 9
    invoke-super {p0, p1, p2}, Li60/p;->e(Lt50/e;Ly40/a;)Ljava/util/Collection;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method

.method public final g(Lt50/e;Ly40/a;)Lq40/h;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "location"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1, p2}, Li60/h;->s(Lt50/e;Ly40/a;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Li60/h;->j:Li60/i;

    .line 15
    .line 16
    iget-object v0, v0, Li60/i;->R:Lcom/google/firebase/messaging/t;

    .line 17
    .line 18
    if-eqz v0, :cond_20

    .line 19
    .line 20
    iget-object v0, v0, Lcom/google/firebase/messaging/t;->i:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Lj60/j;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lj60/j;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Lq40/e;

    .line 29
    .line 30
    if-eqz v0, :cond_20

    .line 31
    .line 32
    return-object v0

    .line 33
    :cond_20
    invoke-super {p0, p1, p2}, Li60/p;->g(Lt50/e;Ly40/a;)Lq40/h;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    return-object p1
.end method

.method public final h(Ljava/util/ArrayList;Lkotlin/jvm/functions/Function1;)V
    .registers 7

    .line 1
    iget-object p2, p0, Li60/h;->j:Li60/i;

    .line 2
    .line 3
    iget-object p2, p2, Li60/i;->R:Lcom/google/firebase/messaging/t;

    .line 4
    .line 5
    if-eqz p2, :cond_38

    .line 6
    .line 7
    iget-object v0, p2, Lcom/google/firebase/messaging/t;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    new-instance v1, Ljava/util/ArrayList;

    .line 16
    .line 17
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 18
    .line 19
    .line 20
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :cond_17
    :goto_17
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_39

    .line 29
    .line 30
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    check-cast v2, Lt50/e;

    .line 35
    .line 36
    const-string v3, "name"

    .line 37
    .line 38
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget-object v3, p2, Lcom/google/firebase/messaging/t;->i:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v3, Lj60/j;

    .line 44
    .line 45
    invoke-virtual {v3, v2}, Lj60/j;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    check-cast v2, Lq40/e;

    .line 50
    .line 51
    if-eqz v2, :cond_17

    .line 52
    .line 53
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    goto :goto_17

    .line 57
    :cond_38
    const/4 v1, 0x0

    .line 58
    :cond_39
    if-nez v1, :cond_3d

    .line 59
    .line 60
    sget-object v1, Lm30/s;->d:Lm30/s;

    .line 61
    .line 62
    :cond_3d
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final j(Ljava/util/ArrayList;Lt50/e;)V
    .registers 10

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v3, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Li60/h;->i:Lj60/i;

    .line 12
    .line 13
    invoke-virtual {v0}, Lj60/i;->invoke()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Ljava/util/Collection;

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_30

    .line 28
    .line 29
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Lk60/w;

    .line 34
    .line 35
    invoke-virtual {v1}, Lk60/w;->Y0()Ld60/o;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    sget-object v2, Ly40/c;->i:Ly40/c;

    .line 40
    .line 41
    invoke-interface {v1, p2, v2}, Ld60/o;->e(Lt50/e;Ly40/a;)Ljava/util/Collection;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 46
    .line 47
    .line 48
    goto :goto_16

    .line 49
    :cond_30
    iget-object v0, p0, Li60/p;->b:Lbg/c;

    .line 50
    .line 51
    iget-object v1, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Lg60/i;

    .line 54
    .line 55
    iget-object v1, v1, Lg60/i;->n:Ls40/b;

    .line 56
    .line 57
    iget-object v2, p0, Li60/h;->j:Li60/i;

    .line 58
    .line 59
    invoke-interface {v1, p2, v2}, Ls40/b;->c(Lt50/e;Lq40/e;)Ljava/util/Collection;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 64
    .line 65
    .line 66
    new-instance v4, Ljava/util/ArrayList;

    .line 67
    .line 68
    invoke-direct {v4, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 69
    .line 70
    .line 71
    iget-object v0, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, Lg60/i;

    .line 74
    .line 75
    iget-object v0, v0, Lg60/i;->q:Ll60/k;

    .line 76
    .line 77
    check-cast v0, Ll60/l;

    .line 78
    .line 79
    iget-object v1, v0, Ll60/l;->d:Lw50/k;

    .line 80
    .line 81
    new-instance v6, Li60/g;

    .line 82
    .line 83
    const/4 v0, 0x0

    .line 84
    invoke-direct {v6, p1, v0}, Li60/g;-><init>(Ljava/util/AbstractCollection;I)V

    .line 85
    .line 86
    .line 87
    iget-object v5, p0, Li60/h;->j:Li60/i;

    .line 88
    .line 89
    move-object v2, p2

    .line 90
    invoke-virtual/range {v1 .. v6}, Lw50/k;->h(Lt50/e;Ljava/util/Collection;Ljava/util/Collection;Lq40/e;Lw50/l;)V

    .line 91
    .line 92
    .line 93
    return-void
.end method

.method public final k(Ljava/util/ArrayList;Lt50/e;)V
    .registers 10

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v3, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Li60/h;->i:Lj60/i;

    .line 12
    .line 13
    invoke-virtual {v0}, Lj60/i;->invoke()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Ljava/util/Collection;

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_30

    .line 28
    .line 29
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Lk60/w;

    .line 34
    .line 35
    invoke-virtual {v1}, Lk60/w;->Y0()Ld60/o;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    sget-object v2, Ly40/c;->i:Ly40/c;

    .line 40
    .line 41
    invoke-interface {v1, p2, v2}, Ld60/o;->a(Lt50/e;Ly40/c;)Ljava/util/Collection;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 46
    .line 47
    .line 48
    goto :goto_16

    .line 49
    :cond_30
    new-instance v4, Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-direct {v4, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 52
    .line 53
    .line 54
    iget-object v0, p0, Li60/p;->b:Lbg/c;

    .line 55
    .line 56
    iget-object v0, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v0, Lg60/i;

    .line 59
    .line 60
    iget-object v0, v0, Lg60/i;->q:Ll60/k;

    .line 61
    .line 62
    check-cast v0, Ll60/l;

    .line 63
    .line 64
    iget-object v1, v0, Ll60/l;->d:Lw50/k;

    .line 65
    .line 66
    new-instance v6, Li60/g;

    .line 67
    .line 68
    const/4 v0, 0x0

    .line 69
    invoke-direct {v6, p1, v0}, Li60/g;-><init>(Ljava/util/AbstractCollection;I)V

    .line 70
    .line 71
    .line 72
    iget-object v5, p0, Li60/h;->j:Li60/i;

    .line 73
    .line 74
    move-object v2, p2

    .line 75
    invoke-virtual/range {v1 .. v6}, Lw50/k;->h(Lt50/e;Ljava/util/Collection;Ljava/util/Collection;Lq40/e;Lw50/l;)V

    .line 76
    .line 77
    .line 78
    return-void
.end method

.method public final l(Lt50/e;)Lt50/b;
    .registers 3

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li60/h;->j:Li60/i;

    .line 7
    .line 8
    iget-object v0, v0, Li60/i;->J:Lt50/b;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Lt50/b;->d(Lt50/e;)Lt50/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method

.method public final n()Ljava/util/Set;
    .registers 4

    .line 1
    iget-object v0, p0, Li60/h;->j:Li60/i;

    .line 2
    .line 3
    iget-object v0, v0, Li60/i;->P:Lh50/h;

    .line 4
    .line 5
    invoke-virtual {v0}, Lk60/f;->e()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 10
    .line 11
    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 12
    .line 13
    .line 14
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-eqz v2, :cond_2d

    .line 23
    .line 24
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Lk60/w;

    .line 29
    .line 30
    invoke-virtual {v2}, Lk60/w;->Y0()Ld60/o;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-interface {v2}, Ld60/o;->c()Ljava/util/Set;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    if-nez v2, :cond_29

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    return-object v0

    .line 42
    :cond_29
    invoke-static {v2, v1}, Lm30/q;->b0(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 43
    .line 44
    .line 45
    goto :goto_11

    .line 46
    :cond_2d
    return-object v1
.end method

.method public final o()Ljava/util/Set;
    .registers 5

    .line 1
    iget-object v0, p0, Li60/h;->j:Li60/i;

    .line 2
    .line 3
    iget-object v1, v0, Li60/i;->P:Lh50/h;

    .line 4
    .line 5
    invoke-virtual {v1}, Lk60/f;->e()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 10
    .line 11
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 12
    .line 13
    .line 14
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    :goto_11
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    if-eqz v3, :cond_29

    .line 23
    .line 24
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    check-cast v3, Lk60/w;

    .line 29
    .line 30
    invoke-virtual {v3}, Lk60/w;->Y0()Ld60/o;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    invoke-interface {v3}, Ld60/o;->b()Ljava/util/Set;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-static {v3, v2}, Lm30/q;->b0(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 39
    .line 40
    .line 41
    goto :goto_11

    .line 42
    :cond_29
    iget-object v1, p0, Li60/p;->b:Lbg/c;

    .line 43
    .line 44
    iget-object v1, v1, Lbg/c;->e:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v1, Lg60/i;

    .line 47
    .line 48
    iget-object v1, v1, Lg60/i;->n:Ls40/b;

    .line 49
    .line 50
    invoke-interface {v1, v0}, Ls40/b;->b(Lq40/e;)Ljava/util/Collection;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-virtual {v2, v0}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 55
    .line 56
    .line 57
    return-object v2
.end method

.method public final p()Ljava/util/Set;
    .registers 4

    .line 1
    iget-object v0, p0, Li60/h;->j:Li60/i;

    .line 2
    .line 3
    iget-object v0, v0, Li60/i;->P:Lh50/h;

    .line 4
    .line 5
    invoke-virtual {v0}, Lk60/f;->e()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 10
    .line 11
    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 12
    .line 13
    .line 14
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-eqz v2, :cond_29

    .line 23
    .line 24
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Lk60/w;

    .line 29
    .line 30
    invoke-virtual {v2}, Lk60/w;->Y0()Ld60/o;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-interface {v2}, Ld60/o;->f()Ljava/util/Set;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {v2, v1}, Lm30/q;->b0(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 39
    .line 40
    .line 41
    goto :goto_11

    .line 42
    :cond_29
    return-object v1
.end method

.method public final r(Li60/s;)Z
    .registers 4

    .line 1
    iget-object v0, p0, Li60/p;->b:Lbg/c;

    .line 2
    .line 3
    iget-object v0, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lg60/i;

    .line 6
    .line 7
    iget-object v0, v0, Lg60/i;->o:Ls40/d;

    .line 8
    .line 9
    iget-object v1, p0, Li60/h;->j:Li60/i;

    .line 10
    .line 11
    invoke-interface {v0, v1, p1}, Ls40/d;->e(Lq40/e;Li60/s;)Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    return p1
.end method

.method public final s(Lt50/e;Ly40/a;)V
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "location"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Li60/p;->b:Lbg/c;

    .line 12
    .line 13
    iget-object p1, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, Lg60/i;

    .line 16
    .line 17
    iget-object p1, p1, Lg60/i;->i:Ly40/b;

    .line 18
    .line 19
    const-string p2, "<this>"

    .line 20
    .line 21
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const-string p1, "scopeOwner"

    .line 25
    .line 26
    iget-object p2, p0, Li60/h;->j:Li60/i;

    .line 27
    .line 28
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
