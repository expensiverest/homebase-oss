###### Class i60.a (i60.a)
.class public Li60/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr40/h;


# static fields
.field public static final synthetic e:[Lh40/t;


# instance fields
.field public final d:Lj60/i;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 1
    new-instance v0, Lkotlin/jvm/internal/o;

    .line 2
    .line 3
    const-class v1, Li60/a;

    .line 4
    .line 5
    const-string v2, "annotations"

    .line 6
    .line 7
    const-string v3, "getAnnotations()Ljava/util/List;"

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    invoke-direct {v0, v1, v2, v3, v4}, Lkotlin/jvm/internal/o;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    sget-object v1, Lkotlin/jvm/internal/v;->a:Lkotlin/jvm/internal/w;

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Lkotlin/jvm/internal/w;->f(Lkotlin/jvm/internal/o;)Lh40/s;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const/4 v1, 0x1

    .line 20
    new-array v1, v1, [Lh40/t;

    .line 21
    .line 22
    aput-object v0, v1, v4

    .line 23
    .line 24
    sput-object v1, Li60/a;->e:[Lh40/t;

    .line 25
    .line 26
    return-void
.end method

.method public constructor <init>(Lj60/o;Lkotlin/jvm/functions/Function0;)V
    .registers 4

    .line 1
    const-string v0, "storageManager"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    check-cast p1, Lj60/l;

    .line 10
    .line 11
    new-instance v0, Lj60/i;

    .line 12
    .line 13
    invoke-direct {v0, p1, p2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Li60/a;->d:Lj60/i;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final bridge A(Lt50/c;)Lr40/b;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lw70/m;->n(Lr40/h;Lt50/c;)Lr40/b;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final bridge L(Lt50/c;)Z
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lw70/m;->K(Lr40/h;Lt50/c;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public isEmpty()Z
    .registers 3

    .line 1
    sget-object v0, Li60/a;->e:[Lh40/t;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    iget-object v1, p0, Li60/a;->d:Lj60/i;

    .line 7
    .line 8
    invoke-static {v1, v0}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/List;

    .line 13
    .line 14
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3

    .line 1
    sget-object v0, Li60/a;->e:[Lh40/t;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    iget-object v1, p0, Li60/a;->d:Lj60/i;

    .line 7
    .line 8
    invoke-static {v1, v0}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/List;

    .line 13
    .line 14
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0
.end method
