###### Class i60.k (i60.k)
.class public interface abstract Li60/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq40/m0;


# virtual methods
.method public abstract f()Ljava/lang/String;
.end method
