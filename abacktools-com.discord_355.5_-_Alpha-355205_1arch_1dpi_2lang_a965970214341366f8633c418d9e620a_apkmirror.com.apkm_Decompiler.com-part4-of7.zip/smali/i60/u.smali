###### Class i60.u (i60.u)
.class public final Li60/u;
.super Lt40/c;
.source "SourceFile"


# instance fields
.field public final N:Lbg/c;

.field public final O:Lo50/y0;

.field public final P:Li60/a;


# direct methods
.method public constructor <init>(Lbg/c;Lo50/y0;I)V
    .registers 14

    .line 1
    iget-object v0, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lg60/i;

    .line 4
    .line 5
    iget-object v2, v0, Lg60/i;->a:Lj60/l;

    .line 6
    .line 7
    iget-object v0, p1, Lbg/c;->v:Ljava/lang/Object;

    .line 8
    .line 9
    move-object v3, v0

    .line 10
    check-cast v3, Lq40/k;

    .line 11
    .line 12
    iget-object v0, p1, Lbg/c;->i:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Lq50/f;

    .line 15
    .line 16
    iget v1, p2, Lo50/y0;->w:I

    .line 17
    .line 18
    invoke-static {v0, v1}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    iget-object v0, p2, Lo50/y0;->y:Lo50/x0;

    .line 23
    .line 24
    const-string v1, "getVariance(...)"

    .line 25
    .line 26
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_36

    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    if-eq v0, v1, :cond_33

    .line 37
    .line 38
    const/4 v1, 0x2

    .line 39
    if-ne v0, v1, :cond_2c

    .line 40
    .line 41
    sget-object v0, Lk60/z0;->i:Lk60/z0;

    .line 42
    .line 43
    :goto_2a
    move-object v6, v0

    .line 44
    goto :goto_39

    .line 45
    :cond_2c
    new-instance p1, Lan/g;

    .line 46
    .line 47
    const/4 p2, 0x0

    .line 48
    invoke-direct {p1, p2}, Lan/g;-><init>(Z)V

    .line 49
    .line 50
    .line 51
    throw p1

    .line 52
    :cond_33
    sget-object v0, Lk60/z0;->w:Lk60/z0;

    .line 53
    .line 54
    goto :goto_2a

    .line 55
    :cond_36
    sget-object v0, Lk60/z0;->v:Lk60/z0;

    .line 56
    .line 57
    goto :goto_2a

    .line 58
    :goto_39
    iget-boolean v7, p2, Lo50/y0;->x:Z

    .line 59
    .line 60
    sget-object v9, Lq40/n0;->i:Lq40/n0;

    .line 61
    .line 62
    sget-object v4, Lr40/g;->a:Lr40/f;

    .line 63
    .line 64
    move-object v1, p0

    .line 65
    move v8, p3

    .line 66
    invoke-direct/range {v1 .. v9}, Lt40/c;-><init>(Lj60/o;Lq40/k;Lr40/h;Lt50/e;Lk60/z0;ZILq40/n0;)V

    .line 67
    .line 68
    .line 69
    iput-object p1, v1, Li60/u;->N:Lbg/c;

    .line 70
    .line 71
    iput-object p2, v1, Li60/u;->O:Lo50/y0;

    .line 72
    .line 73
    new-instance p1, Li60/a;

    .line 74
    .line 75
    new-instance p2, Lbg/w;

    .line 76
    .line 77
    const/16 p3, 0xb

    .line 78
    .line 79
    invoke-direct {p2, p3, p0}, Lbg/w;-><init>(ILjava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    invoke-direct {p1, v2, p2}, Li60/a;-><init>(Lj60/o;Lkotlin/jvm/functions/Function0;)V

    .line 83
    .line 84
    .line 85
    iput-object p1, v1, Li60/u;->P:Li60/a;

    .line 86
    .line 87
    return-void
.end method


# virtual methods
.method public final K2()Ljava/util/List;
    .registers 5

    .line 1
    iget-object v0, p0, Li60/u;->N:Lbg/c;

    .line 2
    .line 3
    iget-object v1, v0, Lbg/c;->w:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ld20/n;

    .line 6
    .line 7
    iget-object v2, p0, Li60/u;->O:Lo50/y0;

    .line 8
    .line 9
    invoke-static {v2, v1}, Landroid/support/v4/media/session/b;->o0(Lo50/y0;Ld20/n;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_1f

    .line 18
    .line 19
    invoke-static {p0}, La60/e;->e(Lq40/k;)Ln40/i;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Ln40/i;->n()Lk60/a0;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0

    .line 32
    :cond_1f
    iget-object v0, v0, Lbg/c;->K:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, Lp/r3;

    .line 35
    .line 36
    new-instance v2, Ljava/util/ArrayList;

    .line 37
    .line 38
    const/16 v3, 0xa

    .line 39
    .line 40
    invoke-static {v1, v3}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 45
    .line 46
    .line 47
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    :goto_32
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    if-eqz v3, :cond_46

    .line 56
    .line 57
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    check-cast v3, Lo50/t0;

    .line 62
    .line 63
    invoke-virtual {v0, v3}, Lp/r3;->s(Lo50/t0;)Lk60/w;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    goto :goto_32

    .line 71
    :cond_46
    return-object v2
.end method

.method public final getAnnotations()Lr40/h;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/u;->P:Li60/a;

    .line 2
    .line 3
    return-object v0
.end method
