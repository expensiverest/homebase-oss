###### Class i60.q (i60.q)
.class public final Li60/q;
.super Li60/p;
.source "SourceFile"


# instance fields
.field public final g:Lq40/d0;

.field public final h:Ljava/lang/String;

.field public final i:Lt50/c;


# direct methods
.method public constructor <init>(Lq40/d0;Lo50/f0;Lq50/f;Lq50/a;Lm50/g;Lg60/i;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .registers 17

    .line 1
    move-object v7, p7

    .line 2
    const-string v0, "proto"

    .line 3
    .line 4
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    const-string v0, "nameResolver"

    .line 8
    .line 9
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v0, "metadataVersion"

    .line 13
    .line 14
    invoke-static {p4, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const-string v0, "components"

    .line 18
    .line 19
    invoke-static {p6, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-string v0, "debugName"

    .line 23
    .line 24
    invoke-static {p7, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    new-instance v3, Ld20/n;

    .line 28
    .line 29
    iget-object v0, p2, Lo50/f0;->y:Lo50/z0;

    .line 30
    .line 31
    const-string v4, "getTypeTable(...)"

    .line 32
    .line 33
    invoke-static {v0, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-direct {v3, v0}, Ld20/n;-><init>(Lo50/z0;)V

    .line 37
    .line 38
    .line 39
    sget-object v0, Lq50/i;->b:Lq50/i;

    .line 40
    .line 41
    iget-object v0, p2, Lo50/f0;->J:Lo50/g1;

    .line 42
    .line 43
    const-string v4, "getVersionRequirementTable(...)"

    .line 44
    .line 45
    invoke-static {v0, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-static {v0}, Lc7/t;->k(Lo50/g1;)Lq50/i;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    move-object v1, p1

    .line 53
    move-object v2, p3

    .line 54
    move-object v5, p4

    .line 55
    move-object v6, p5

    .line 56
    move-object v0, p6

    .line 57
    invoke-virtual/range {v0 .. v6}, Lg60/i;->a(Lq40/d0;Lq50/f;Ld20/n;Lq50/i;Lq50/a;Li60/k;)Lbg/c;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    iget-object v2, p2, Lo50/f0;->v:Ljava/util/List;

    .line 62
    .line 63
    const-string v1, "getFunctionList(...)"

    .line 64
    .line 65
    invoke-static {v2, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    iget-object v3, p2, Lo50/f0;->w:Ljava/util/List;

    .line 69
    .line 70
    const-string v1, "getPropertyList(...)"

    .line 71
    .line 72
    invoke-static {v3, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    iget-object v4, p2, Lo50/f0;->x:Ljava/util/List;

    .line 76
    .line 77
    const-string v1, "getTypeAliasList(...)"

    .line 78
    .line 79
    invoke-static {v4, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    move-object/from16 v5, p8

    .line 83
    .line 84
    move-object v1, v0

    .line 85
    move-object v0, p0

    .line 86
    invoke-direct/range {v0 .. v5}, Li60/p;-><init>(Lbg/c;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkotlin/jvm/functions/Function0;)V

    .line 87
    .line 88
    .line 89
    iput-object p1, p0, Li60/q;->g:Lq40/d0;

    .line 90
    .line 91
    iput-object v7, p0, Li60/q;->h:Ljava/lang/String;

    .line 92
    .line 93
    move-object v1, p1

    .line 94
    check-cast v1, Lt40/b0;

    .line 95
    .line 96
    iget-object v1, v1, Lt40/b0;->x:Lt50/c;

    .line 97
    .line 98
    iput-object v1, p0, Li60/q;->i:Lt50/c;

    .line 99
    .line 100
    return-void
.end method


# virtual methods
.method public final d(Ld60/f;Lkotlin/jvm/functions/Function1;)Ljava/util/Collection;
    .registers 6

    .line 1
    const-string v0, "kindFilter"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Ly40/c;->d:Ly40/c;

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, Li60/p;->i(Ld60/f;Lkotlin/jvm/functions/Function1;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iget-object p2, p0, Li60/p;->b:Lbg/c;

    .line 13
    .line 14
    iget-object p2, p2, Lbg/c;->e:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p2, Lg60/i;

    .line 17
    .line 18
    iget-object p2, p2, Lg60/i;->k:Ljava/lang/Iterable;

    .line 19
    .line 20
    new-instance v0, Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 23
    .line 24
    .line 25
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    :goto_1c
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_32

    .line 34
    .line 35
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Ls40/c;

    .line 40
    .line 41
    iget-object v2, p0, Li60/q;->i:Lt50/c;

    .line 42
    .line 43
    invoke-interface {v1, v2}, Ls40/c;->a(Lt50/c;)Ljava/util/Collection;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-static {v1, v0}, Lm30/q;->b0(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 48
    .line 49
    .line 50
    goto :goto_1c

    .line 51
    :cond_32
    invoke-static {v0, p1}, Lm30/q;->B0(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    return-object p1
.end method

.method public final g(Lt50/e;Ly40/a;)Lq40/h;
    .registers 5

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "location"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Li60/p;->b:Lbg/c;

    .line 12
    .line 13
    iget-object v0, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lg60/i;

    .line 16
    .line 17
    iget-object v0, v0, Lg60/i;->i:Ly40/b;

    .line 18
    .line 19
    iget-object v1, p0, Li60/q;->g:Lq40/d0;

    .line 20
    .line 21
    invoke-static {v0, p2, v1, p1}, Lcom/facebook/react/uimanager/b0;->o0(Ly40/b;Ly40/a;Lq40/d0;Lt50/e;)V

    .line 22
    .line 23
    .line 24
    invoke-super {p0, p1, p2}, Li60/p;->g(Lt50/e;Ly40/a;)Lq40/h;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1
.end method

.method public final h(Ljava/util/ArrayList;Lkotlin/jvm/functions/Function1;)V
    .registers 3

    .line 1
    return-void
.end method

.method public final l(Lt50/e;)Lt50/b;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Lt50/b;

    .line 7
    .line 8
    iget-object v1, p0, Li60/q;->i:Lt50/c;

    .line 9
    .line 10
    invoke-direct {v0, v1, p1}, Lt50/b;-><init>(Lt50/c;Lt50/e;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final n()Ljava/util/Set;
    .registers 2

    .line 1
    sget-object v0, Lm30/u;->d:Lm30/u;

    .line 2
    .line 3
    return-object v0
.end method

.method public final o()Ljava/util/Set;
    .registers 2

    .line 1
    sget-object v0, Lm30/u;->d:Lm30/u;

    .line 2
    .line 3
    return-object v0
.end method

.method public final p()Ljava/util/Set;
    .registers 2

    .line 1
    sget-object v0, Lm30/u;->d:Lm30/u;

    .line 2
    .line 3
    return-object v0
.end method

.method public final q(Lt50/e;)Z
    .registers 5

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1}, Li60/p;->q(Lt50/e;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_3c

    .line 11
    .line 12
    iget-object v0, p0, Li60/p;->b:Lbg/c;

    .line 13
    .line 14
    iget-object v0, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lg60/i;

    .line 17
    .line 18
    iget-object v0, v0, Lg60/i;->k:Ljava/lang/Iterable;

    .line 19
    .line 20
    instance-of v1, v0, Ljava/util/Collection;

    .line 21
    .line 22
    if-eqz v1, :cond_21

    .line 23
    .line 24
    move-object v1, v0

    .line 25
    check-cast v1, Ljava/util/Collection;

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_21

    .line 32
    .line 33
    goto :goto_3a

    .line 34
    :cond_21
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    :cond_25
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_3a

    .line 43
    .line 44
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    check-cast v1, Ls40/c;

    .line 49
    .line 50
    iget-object v2, p0, Li60/q;->i:Lt50/c;

    .line 51
    .line 52
    invoke-interface {v1, v2, p1}, Ls40/c;->c(Lt50/c;Lt50/e;)Z

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_25

    .line 57
    .line 58
    goto :goto_3c

    .line 59
    :cond_3a
    :goto_3a
    const/4 p1, 0x0

    .line 60
    return p1

    .line 61
    :cond_3c
    :goto_3c
    const/4 p1, 0x1

    .line 62
    return p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/q;->h:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method
