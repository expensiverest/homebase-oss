###### Class i60.d (i60.d)
.class public final Li60/d;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I

.field public final e:Li60/i;


# direct methods
.method public synthetic constructor <init>(Li60/i;I)V
    .registers 3

    .line 1
    iput p2, p0, Li60/d;->d:I

    iput-object p1, p0, Li60/d;->e:Li60/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Li60/d;->d:I

    .line 4
    .line 5
    const-string v3, "getConstructorList(...)"

    .line 6
    .line 7
    const/4 v6, 0x1

    .line 8
    iget-object v7, v0, Li60/d;->e:Li60/i;

    .line 9
    .line 10
    packed-switch v1, :pswitch_data_372

    .line 11
    .line 12
    .line 13
    invoke-static {v7}, Lq40/v;->c(Lq40/i;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    return-object v1

    .line 18
    :pswitch_11
    iget-object v1, v7, Li60/i;->N:Lbg/c;

    .line 19
    .line 20
    iget-object v1, v1, Lbg/c;->e:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Lg60/i;

    .line 23
    .line 24
    iget-object v1, v1, Lg60/i;->e:Lg60/a;

    .line 25
    .line 26
    iget-object v2, v7, Li60/i;->W:Lg60/t;

    .line 27
    .line 28
    invoke-interface {v1, v2}, Lg60/c;->l(Lg60/t;)Ljava/util/ArrayList;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-static {v1}, Lm30/q;->S0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    return-object v1

    .line 37
    :pswitch_24
    iget-object v9, v0, Li60/d;->e:Li60/i;

    .line 38
    .line 39
    invoke-virtual {v9}, Li60/i;->isInline()Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_36

    .line 44
    .line 45
    invoke-virtual {v9}, Li60/i;->w()Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-nez v1, :cond_36

    .line 50
    .line 51
    const/16 v19, 0x0

    .line 52
    .line 53
    goto/16 :goto_1b4

    .line 54
    .line 55
    :cond_36
    iget-object v1, v9, Li60/i;->x:Lq50/a;

    .line 56
    .line 57
    const/4 v7, 0x5

    .line 58
    invoke-virtual {v1, v6, v7, v6}, Lq50/a;->a(III)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    iget-object v15, v9, Li60/i;->w:Lo50/k;

    .line 63
    .line 64
    iget-object v7, v9, Li60/i;->N:Lbg/c;

    .line 65
    .line 66
    iget-object v8, v7, Lbg/c;->i:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v8, Lq50/f;

    .line 69
    .line 70
    iget-object v10, v7, Lbg/c;->w:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v10, Ld20/n;

    .line 73
    .line 74
    iget-object v7, v7, Lbg/c;->K:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v7, Lp/r3;

    .line 77
    .line 78
    move-object v11, v7

    .line 79
    new-instance v7, Lcg/a;

    .line 80
    .line 81
    const/4 v13, 0x0

    .line 82
    const/4 v14, 0x6

    .line 83
    move-object v12, v8

    .line 84
    const/4 v8, 0x1

    .line 85
    move-object/from16 v16, v10

    .line 86
    .line 87
    const-class v10, Li60/i;

    .line 88
    .line 89
    move-object/from16 v17, v11

    .line 90
    .line 91
    const-string v11, "getValueClassPropertyType"

    .line 92
    .line 93
    move-object/from16 v18, v12

    .line 94
    .line 95
    const-string v12, "getValueClassPropertyType(Lorg/jetbrains/kotlin/name/Name;)Lorg/jetbrains/kotlin/types/SimpleType;"

    .line 96
    .line 97
    move-object/from16 v5, v16

    .line 98
    .line 99
    move-object/from16 v2, v17

    .line 100
    .line 101
    move-object/from16 v4, v18

    .line 102
    .line 103
    const/16 v19, 0x0

    .line 104
    .line 105
    invoke-direct/range {v7 .. v14}, Lcg/a;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    .line 106
    .line 107
    .line 108
    const-string v8, "<this>"

    .line 109
    .line 110
    invoke-static {v15, v8}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    const-string v8, "nameResolver"

    .line 114
    .line 115
    invoke-static {v4, v8}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    iget v8, v15, Lo50/k;->i:I

    .line 119
    .line 120
    const/16 v10, 0x8

    .line 121
    .line 122
    and-int/2addr v8, v10

    .line 123
    if-ne v8, v10, :cond_c3

    .line 124
    .line 125
    iget v3, v15, Lo50/k;->Y:I

    .line 126
    .line 127
    invoke-static {v4, v3}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-static {v15, v5}, Landroid/support/v4/media/session/b;->F(Lo50/k;Ld20/n;)Lo50/t0;

    .line 132
    .line 133
    .line 134
    move-result-object v5

    .line 135
    if-eqz v5, :cond_8e

    .line 136
    .line 137
    invoke-virtual {v2, v5, v6}, Lp/r3;->o(Lo50/t0;Z)Lk60/a0;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    if-nez v2, :cond_96

    .line 142
    .line 143
    :cond_8e
    invoke-virtual {v7, v3}, Lcg/a;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    check-cast v2, Ln60/e;

    .line 148
    .line 149
    if-eqz v2, :cond_9d

    .line 150
    .line 151
    :cond_96
    new-instance v4, Lq40/u;

    .line 152
    .line 153
    invoke-direct {v4, v3, v2}, Lq40/u;-><init>(Lt50/e;Ln60/e;)V

    .line 154
    .line 155
    .line 156
    goto/16 :goto_151

    .line 157
    .line 158
    :cond_9d
    new-instance v1, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    const-string v2, "cannot determine underlying type for value class "

    .line 161
    .line 162
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    iget v2, v15, Lo50/k;->w:I

    .line 166
    .line 167
    invoke-static {v4, v2}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    const-string v2, " with property "

    .line 175
    .line 176
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 177
    .line 178
    .line 179
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v1

    .line 186
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 187
    .line 188
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    throw v2

    .line 196
    :cond_c3
    if-eqz v1, :cond_10b

    .line 197
    .line 198
    sget-object v7, Lq50/d;->k:Lq50/b;

    .line 199
    .line 200
    iget v8, v15, Lo50/k;->v:I

    .line 201
    .line 202
    invoke-virtual {v7, v8}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 203
    .line 204
    .line 205
    move-result-object v7

    .line 206
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 207
    .line 208
    .line 209
    move-result v7

    .line 210
    if-eqz v7, :cond_10b

    .line 211
    .line 212
    iget-object v7, v15, Lo50/k;->R:Ljava/util/List;

    .line 213
    .line 214
    invoke-static {v7, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 218
    .line 219
    .line 220
    move-result-object v3

    .line 221
    move-object/from16 v7, v19

    .line 222
    .line 223
    const/16 v16, 0x0

    .line 224
    .line 225
    :cond_e0
    :goto_e0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 226
    .line 227
    .line 228
    move-result v8

    .line 229
    if-eqz v8, :cond_104

    .line 230
    .line 231
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v8

    .line 235
    move-object v10, v8

    .line 236
    check-cast v10, Lo50/n;

    .line 237
    .line 238
    sget-object v11, Lq50/d;->n:Lq50/b;

    .line 239
    .line 240
    iget v10, v10, Lo50/n;->v:I

    .line 241
    .line 242
    invoke-virtual {v11, v10}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 243
    .line 244
    .line 245
    move-result-object v10

    .line 246
    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    .line 247
    .line 248
    .line 249
    move-result v10

    .line 250
    if-nez v10, :cond_e0

    .line 251
    .line 252
    if-eqz v16, :cond_100

    .line 253
    .line 254
    :goto_fd
    move-object/from16 v7, v19

    .line 255
    .line 256
    goto :goto_107

    .line 257
    :cond_100
    move/from16 v16, v6

    .line 258
    .line 259
    move-object v7, v8

    .line 260
    goto :goto_e0

    .line 261
    :cond_104
    if-nez v16, :cond_107

    .line 262
    .line 263
    goto :goto_fd

    .line 264
    :cond_107
    :goto_107
    check-cast v7, Lo50/n;

    .line 265
    .line 266
    if-nez v7, :cond_10e

    .line 267
    .line 268
    :cond_10b
    move-object/from16 v4, v19

    .line 269
    .line 270
    goto :goto_151

    .line 271
    :cond_10e
    iget-object v3, v7, Lo50/n;->w:Ljava/util/List;

    .line 272
    .line 273
    const-string v7, "getValueParameterList(...)"

    .line 274
    .line 275
    invoke-static {v3, v7}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 276
    .line 277
    .line 278
    new-instance v7, Ljava/util/ArrayList;

    .line 279
    .line 280
    const/16 v8, 0xa

    .line 281
    .line 282
    invoke-static {v3, v8}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 283
    .line 284
    .line 285
    move-result v8

    .line 286
    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    .line 287
    .line 288
    .line 289
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 290
    .line 291
    .line 292
    move-result-object v3

    .line 293
    :goto_124
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 294
    .line 295
    .line 296
    move-result v8

    .line 297
    if-eqz v8, :cond_14c

    .line 298
    .line 299
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v8

    .line 303
    check-cast v8, Lo50/b1;

    .line 304
    .line 305
    iget v10, v8, Lo50/b1;->w:I

    .line 306
    .line 307
    invoke-static {v4, v10}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 308
    .line 309
    .line 310
    move-result-object v10

    .line 311
    invoke-static {v8, v5}, Landroid/support/v4/media/session/b;->l0(Lo50/b1;Ld20/n;)Lo50/t0;

    .line 312
    .line 313
    .line 314
    move-result-object v8

    .line 315
    const-string v11, "p0"

    .line 316
    .line 317
    invoke-static {v8, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {v2, v8, v6}, Lp/r3;->o(Lo50/t0;Z)Lk60/a0;

    .line 321
    .line 322
    .line 323
    move-result-object v8

    .line 324
    new-instance v11, Ll30/j;

    .line 325
    .line 326
    invoke-direct {v11, v10, v8}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 327
    .line 328
    .line 329
    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 330
    .line 331
    .line 332
    goto :goto_124

    .line 333
    :cond_14c
    new-instance v4, Lq40/z;

    .line 334
    .line 335
    invoke-direct {v4, v7}, Lq40/z;-><init>(Ljava/util/ArrayList;)V

    .line 336
    .line 337
    .line 338
    :goto_151
    if-eqz v4, :cond_154

    .line 339
    .line 340
    goto :goto_1b6

    .line 341
    :cond_154
    if-nez v1, :cond_1b4

    .line 342
    .line 343
    invoke-virtual {v9}, Li60/i;->S0()Lt40/i;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    if-eqz v1, :cond_19c

    .line 348
    .line 349
    check-cast v1, Lt40/t;

    .line 350
    .line 351
    invoke-virtual {v1}, Lt40/t;->b1()Ljava/util/List;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    const-string v2, "getValueParameters(...)"

    .line 356
    .line 357
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 358
    .line 359
    .line 360
    invoke-static {v1}, Lm30/q;->n0(Ljava/util/List;)Ljava/lang/Object;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    check-cast v1, Lt40/r0;

    .line 365
    .line 366
    check-cast v1, Lt40/m;

    .line 367
    .line 368
    invoke-virtual {v1}, Lt40/m;->getName()Lt50/e;

    .line 369
    .line 370
    .line 371
    move-result-object v1

    .line 372
    const-string v2, "getName(...)"

    .line 373
    .line 374
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    invoke-virtual {v9, v1}, Li60/i;->m(Lt50/e;)Lk60/a0;

    .line 378
    .line 379
    .line 380
    move-result-object v2

    .line 381
    if-eqz v2, :cond_184

    .line 382
    .line 383
    new-instance v4, Lq40/u;

    .line 384
    .line 385
    invoke-direct {v4, v1, v2}, Lq40/u;-><init>(Lt50/e;Ln60/e;)V

    .line 386
    .line 387
    .line 388
    goto :goto_1b6

    .line 389
    :cond_184
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 390
    .line 391
    new-instance v2, Ljava/lang/StringBuilder;

    .line 392
    .line 393
    const-string v3, "Value class has no underlying property: "

    .line 394
    .line 395
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 396
    .line 397
    .line 398
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v2

    .line 405
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v2

    .line 409
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 410
    .line 411
    .line 412
    throw v1

    .line 413
    :cond_19c
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 414
    .line 415
    new-instance v2, Ljava/lang/StringBuilder;

    .line 416
    .line 417
    const-string v3, "Inline class has no primary constructor: "

    .line 418
    .line 419
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 420
    .line 421
    .line 422
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 423
    .line 424
    .line 425
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object v2

    .line 429
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 430
    .line 431
    .line 432
    move-result-object v2

    .line 433
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    throw v1

    .line 437
    :cond_1b4
    :goto_1b4
    move-object/from16 v4, v19

    .line 438
    .line 439
    :goto_1b6
    return-object v4

    .line 440
    :pswitch_1b7
    iget-object v1, v7, Li60/i;->K:Lq40/x;

    .line 441
    .line 442
    sget-object v2, Lq40/x;->i:Lq40/x;

    .line 443
    .line 444
    if-eq v1, v2, :cond_1be

    .line 445
    .line 446
    goto :goto_201

    .line 447
    :cond_1be
    iget-object v3, v7, Li60/i;->w:Lo50/k;

    .line 448
    .line 449
    iget-object v3, v3, Lo50/k;->W:Ljava/util/List;

    .line 450
    .line 451
    invoke-static {v3}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 452
    .line 453
    .line 454
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 455
    .line 456
    .line 457
    move-result v4

    .line 458
    if-nez v4, :cond_1ff

    .line 459
    .line 460
    new-instance v1, Ljava/util/ArrayList;

    .line 461
    .line 462
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 463
    .line 464
    .line 465
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 466
    .line 467
    .line 468
    move-result-object v2

    .line 469
    :cond_1d4
    :goto_1d4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 470
    .line 471
    .line 472
    move-result v3

    .line 473
    if-eqz v3, :cond_229

    .line 474
    .line 475
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v3

    .line 479
    check-cast v3, Ljava/lang/Integer;

    .line 480
    .line 481
    iget-object v4, v7, Li60/i;->N:Lbg/c;

    .line 482
    .line 483
    iget-object v5, v4, Lbg/c;->e:Ljava/lang/Object;

    .line 484
    .line 485
    check-cast v5, Lg60/i;

    .line 486
    .line 487
    iget-object v4, v4, Lbg/c;->i:Ljava/lang/Object;

    .line 488
    .line 489
    check-cast v4, Lq50/f;

    .line 490
    .line 491
    invoke-static {v3}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 492
    .line 493
    .line 494
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 495
    .line 496
    .line 497
    move-result v3

    .line 498
    invoke-static {v4, v3}, Lul/b;->s(Lq50/f;I)Lt50/b;

    .line 499
    .line 500
    .line 501
    move-result-object v3

    .line 502
    invoke-virtual {v5, v3}, Lg60/i;->b(Lt50/b;)Lq40/e;

    .line 503
    .line 504
    .line 505
    move-result-object v3

    .line 506
    if-eqz v3, :cond_1d4

    .line 507
    .line 508
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 509
    .line 510
    .line 511
    goto :goto_1d4

    .line 512
    :cond_1ff
    if-eq v1, v2, :cond_204

    .line 513
    .line 514
    :goto_201
    sget-object v1, Lm30/s;->d:Lm30/s;

    .line 515
    .line 516
    goto :goto_229

    .line 517
    :cond_204
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 518
    .line 519
    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 520
    .line 521
    .line 522
    iget-object v2, v7, Li60/i;->S:Lq40/k;

    .line 523
    .line 524
    instance-of v3, v2, Lq40/d0;

    .line 525
    .line 526
    if-eqz v3, :cond_219

    .line 527
    .line 528
    check-cast v2, Lq40/d0;

    .line 529
    .line 530
    invoke-interface {v2}, Lq40/d0;->Y0()Ld60/o;

    .line 531
    .line 532
    .line 533
    move-result-object v2

    .line 534
    const/4 v3, 0x0

    .line 535
    invoke-static {v7, v1, v2, v3}, Lw50/l;->c(Lq40/e;Ljava/util/LinkedHashSet;Ld60/o;Z)V

    .line 536
    .line 537
    .line 538
    :cond_219
    invoke-virtual {v7}, Lt40/b;->T1()Ld60/o;

    .line 539
    .line 540
    .line 541
    move-result-object v2

    .line 542
    invoke-static {v7, v1, v2, v6}, Lw50/l;->c(Lq40/e;Ljava/util/LinkedHashSet;Ld60/o;Z)V

    .line 543
    .line 544
    .line 545
    new-instance v2, Lw50/h;

    .line 546
    .line 547
    invoke-direct {v2, v6}, Lw50/h;-><init>(I)V

    .line 548
    .line 549
    .line 550
    invoke-static {v1, v2}, Lm30/q;->N0(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/util/List;

    .line 551
    .line 552
    .line 553
    move-result-object v1

    .line 554
    :cond_229
    :goto_229
    return-object v1

    .line 555
    :pswitch_22a
    const/16 v19, 0x0

    .line 556
    .line 557
    iget-object v1, v7, Li60/i;->w:Lo50/k;

    .line 558
    .line 559
    iget v2, v1, Lo50/k;->i:I

    .line 560
    .line 561
    const/4 v3, 0x4

    .line 562
    and-int/2addr v2, v3

    .line 563
    if-ne v2, v3, :cond_252

    .line 564
    .line 565
    iget-object v2, v7, Li60/i;->N:Lbg/c;

    .line 566
    .line 567
    iget-object v2, v2, Lbg/c;->i:Ljava/lang/Object;

    .line 568
    .line 569
    check-cast v2, Lq50/f;

    .line 570
    .line 571
    iget v1, v1, Lo50/k;->x:I

    .line 572
    .line 573
    invoke-static {v2, v1}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 574
    .line 575
    .line 576
    move-result-object v1

    .line 577
    invoke-virtual {v7}, Li60/i;->l()Li60/h;

    .line 578
    .line 579
    .line 580
    move-result-object v2

    .line 581
    sget-object v3, Ly40/c;->y:Ly40/c;

    .line 582
    .line 583
    invoke-virtual {v2, v1, v3}, Li60/h;->g(Lt50/e;Ly40/a;)Lq40/h;

    .line 584
    .line 585
    .line 586
    move-result-object v1

    .line 587
    instance-of v2, v1, Lq40/e;

    .line 588
    .line 589
    if-eqz v2, :cond_252

    .line 590
    .line 591
    move-object v4, v1

    .line 592
    check-cast v4, Lq40/e;

    .line 593
    .line 594
    goto :goto_254

    .line 595
    :cond_252
    move-object/from16 v4, v19

    .line 596
    .line 597
    :goto_254
    return-object v4

    .line 598
    :pswitch_255
    iget-object v1, v7, Li60/i;->N:Lbg/c;

    .line 599
    .line 600
    iget-object v2, v7, Li60/i;->w:Lo50/k;

    .line 601
    .line 602
    iget-object v2, v2, Lo50/k;->R:Ljava/util/List;

    .line 603
    .line 604
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 605
    .line 606
    .line 607
    new-instance v3, Ljava/util/ArrayList;

    .line 608
    .line 609
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 610
    .line 611
    .line 612
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 613
    .line 614
    .line 615
    move-result-object v2

    .line 616
    :cond_267
    :goto_267
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 617
    .line 618
    .line 619
    move-result v4

    .line 620
    if-eqz v4, :cond_286

    .line 621
    .line 622
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 623
    .line 624
    .line 625
    move-result-object v4

    .line 626
    move-object v5, v4

    .line 627
    check-cast v5, Lo50/n;

    .line 628
    .line 629
    sget-object v6, Lq50/d;->n:Lq50/b;

    .line 630
    .line 631
    iget v5, v5, Lo50/n;->v:I

    .line 632
    .line 633
    invoke-virtual {v6, v5}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 634
    .line 635
    .line 636
    move-result-object v5

    .line 637
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 638
    .line 639
    .line 640
    move-result v5

    .line 641
    if-eqz v5, :cond_267

    .line 642
    .line 643
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 644
    .line 645
    .line 646
    goto :goto_267

    .line 647
    :cond_286
    new-instance v2, Ljava/util/ArrayList;

    .line 648
    .line 649
    const/16 v8, 0xa

    .line 650
    .line 651
    invoke-static {v3, v8}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 652
    .line 653
    .line 654
    move-result v4

    .line 655
    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 656
    .line 657
    .line 658
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 659
    .line 660
    .line 661
    move-result-object v3

    .line 662
    :goto_295
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 663
    .line 664
    .line 665
    move-result v4

    .line 666
    if-eqz v4, :cond_2b1

    .line 667
    .line 668
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 669
    .line 670
    .line 671
    move-result-object v4

    .line 672
    check-cast v4, Lo50/n;

    .line 673
    .line 674
    iget-object v5, v1, Lbg/c;->L:Ljava/lang/Object;

    .line 675
    .line 676
    check-cast v5, Lg60/s;

    .line 677
    .line 678
    invoke-static {v4}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    const/4 v6, 0x0

    .line 682
    invoke-virtual {v5, v4, v6}, Lg60/s;->e(Lo50/n;Z)Li60/c;

    .line 683
    .line 684
    .line 685
    move-result-object v4

    .line 686
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 687
    .line 688
    .line 689
    goto :goto_295

    .line 690
    :cond_2b1
    invoke-virtual {v7}, Li60/i;->S0()Lt40/i;

    .line 691
    .line 692
    .line 693
    move-result-object v3

    .line 694
    invoke-static {v3}, Ls1/e;->v(Ljava/lang/Object;)Ljava/util/List;

    .line 695
    .line 696
    .line 697
    move-result-object v3

    .line 698
    invoke-static {v3, v2}, Lm30/q;->B0(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 699
    .line 700
    .line 701
    move-result-object v2

    .line 702
    iget-object v1, v1, Lbg/c;->e:Ljava/lang/Object;

    .line 703
    .line 704
    check-cast v1, Lg60/i;

    .line 705
    .line 706
    iget-object v1, v1, Lg60/i;->n:Ls40/b;

    .line 707
    .line 708
    invoke-interface {v1, v7}, Ls40/b;->a(Lq40/e;)Ljava/util/Collection;

    .line 709
    .line 710
    .line 711
    move-result-object v1

    .line 712
    invoke-static {v1, v2}, Lm30/q;->B0(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 713
    .line 714
    .line 715
    move-result-object v1

    .line 716
    return-object v1

    .line 717
    :pswitch_2cc
    move-object v1, v3

    .line 718
    const/16 v19, 0x0

    .line 719
    .line 720
    iget-object v3, v0, Li60/d;->e:Li60/i;

    .line 721
    .line 722
    iget-object v9, v3, Li60/i;->M:Lq40/f;

    .line 723
    .line 724
    invoke-virtual {v9}, Lq40/f;->a()Z

    .line 725
    .line 726
    .line 727
    move-result v2

    .line 728
    if-eqz v2, :cond_336

    .line 729
    .line 730
    new-instance v2, Lw50/d;

    .line 731
    .line 732
    const/4 v6, 0x1

    .line 733
    const/4 v7, 0x1

    .line 734
    const/4 v4, 0x0

    .line 735
    sget-object v5, Lr40/g;->a:Lr40/f;

    .line 736
    .line 737
    sget-object v8, Lq40/m0;->u:Lq40/n0;

    .line 738
    .line 739
    invoke-direct/range {v2 .. v8}, Lt40/i;-><init>(Lq40/e;Lq40/j;Lr40/h;ZILq40/m0;)V

    .line 740
    .line 741
    .line 742
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 743
    .line 744
    sget v4, Lw50/e;->a:I

    .line 745
    .line 746
    sget-object v4, Lq40/f;->i:Lq40/f;

    .line 747
    .line 748
    if-eq v9, v4, :cond_321

    .line 749
    .line 750
    invoke-virtual {v9}, Lq40/f;->a()Z

    .line 751
    .line 752
    .line 753
    move-result v4

    .line 754
    if-eqz v4, :cond_2f4

    .line 755
    .line 756
    goto :goto_321

    .line 757
    :cond_2f4
    invoke-static {v3}, Lw50/e;->p(Lq40/k;)Z

    .line 758
    .line 759
    .line 760
    move-result v4

    .line 761
    if-eqz v4, :cond_305

    .line 762
    .line 763
    sget-object v4, Lq40/o;->a:Ld50/o;

    .line 764
    .line 765
    if-eqz v4, :cond_2ff

    .line 766
    .line 767
    goto :goto_325

    .line 768
    :cond_2ff
    const/16 v1, 0x33

    .line 769
    .line 770
    invoke-static {v1}, Lw50/e;->a(I)V

    .line 771
    .line 772
    .line 773
    throw v19

    .line 774
    :cond_305
    invoke-static {v3}, Lw50/e;->k(Lq40/k;)Z

    .line 775
    .line 776
    .line 777
    move-result v4

    .line 778
    if-eqz v4, :cond_316

    .line 779
    .line 780
    sget-object v4, Lq40/o;->j:Ld50/o;

    .line 781
    .line 782
    if-eqz v4, :cond_310

    .line 783
    .line 784
    goto :goto_325

    .line 785
    :cond_310
    const/16 v1, 0x34

    .line 786
    .line 787
    invoke-static {v1}, Lw50/e;->a(I)V

    .line 788
    .line 789
    .line 790
    throw v19

    .line 791
    :cond_316
    sget-object v4, Lq40/o;->e:Ld50/o;

    .line 792
    .line 793
    if-eqz v4, :cond_31b

    .line 794
    .line 795
    goto :goto_325

    .line 796
    :cond_31b
    const/16 v1, 0x35

    .line 797
    .line 798
    invoke-static {v1}, Lw50/e;->a(I)V

    .line 799
    .line 800
    .line 801
    throw v19

    .line 802
    :cond_321
    :goto_321
    sget-object v4, Lq40/o;->a:Ld50/o;

    .line 803
    .line 804
    if-eqz v4, :cond_330

    .line 805
    .line 806
    :goto_325
    invoke-virtual {v2, v1, v4}, Lt40/i;->X2(Ljava/util/List;Ld50/o;)V

    .line 807
    .line 808
    .line 809
    invoke-virtual {v3}, Lt40/b;->M()Lk60/a0;

    .line 810
    .line 811
    .line 812
    move-result-object v1

    .line 813
    iput-object v1, v2, Lt40/t;->J:Lk60/w;

    .line 814
    .line 815
    move-object v4, v2

    .line 816
    goto :goto_370

    .line 817
    :cond_330
    const/16 v1, 0x31

    .line 818
    .line 819
    invoke-static {v1}, Lw50/e;->a(I)V

    .line 820
    .line 821
    .line 822
    throw v19

    .line 823
    :cond_336
    iget-object v2, v3, Li60/i;->w:Lo50/k;

    .line 824
    .line 825
    iget-object v2, v2, Lo50/k;->R:Ljava/util/List;

    .line 826
    .line 827
    invoke-static {v2, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 828
    .line 829
    .line 830
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 831
    .line 832
    .line 833
    move-result-object v1

    .line 834
    :cond_341
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 835
    .line 836
    .line 837
    move-result v2

    .line 838
    if-eqz v2, :cond_35d

    .line 839
    .line 840
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 841
    .line 842
    .line 843
    move-result-object v2

    .line 844
    move-object v4, v2

    .line 845
    check-cast v4, Lo50/n;

    .line 846
    .line 847
    sget-object v5, Lq50/d;->n:Lq50/b;

    .line 848
    .line 849
    iget v4, v4, Lo50/n;->v:I

    .line 850
    .line 851
    invoke-virtual {v5, v4}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 852
    .line 853
    .line 854
    move-result-object v4

    .line 855
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 856
    .line 857
    .line 858
    move-result v4

    .line 859
    if-nez v4, :cond_341

    .line 860
    .line 861
    goto :goto_35f

    .line 862
    :cond_35d
    move-object/from16 v2, v19

    .line 863
    .line 864
    :goto_35f
    check-cast v2, Lo50/n;

    .line 865
    .line 866
    if-eqz v2, :cond_36e

    .line 867
    .line 868
    iget-object v1, v3, Li60/i;->N:Lbg/c;

    .line 869
    .line 870
    iget-object v1, v1, Lbg/c;->L:Ljava/lang/Object;

    .line 871
    .line 872
    check-cast v1, Lg60/s;

    .line 873
    .line 874
    invoke-virtual {v1, v2, v6}, Lg60/s;->e(Lo50/n;Z)Li60/c;

    .line 875
    .line 876
    .line 877
    move-result-object v4

    .line 878
    goto :goto_370

    .line 879
    :cond_36e
    move-object/from16 v4, v19

    .line 880
    .line 881
    :goto_370
    return-object v4

    .line 882
    nop

    .line 883
    :pswitch_data_372
    .packed-switch 0x0
        :pswitch_2cc
        :pswitch_255
        :pswitch_22a
        :pswitch_1b7
        :pswitch_24
        :pswitch_11
    .end packed-switch
.end method
