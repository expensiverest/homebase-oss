###### Class i60.f (i60.f)
.class public final Li60/f;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I

.field public final e:Li60/h;


# direct methods
.method public synthetic constructor <init>(Li60/h;I)V
    .registers 3

    .line 1
    iput p2, p0, Li60/f;->d:I

    iput-object p1, p0, Li60/f;->e:Li60/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Li60/f;->d:I

    .line 2
    .line 3
    iget-object v1, p0, Li60/f;->e:Li60/h;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_34

    .line 6
    .line 7
    .line 8
    iget-object v0, v1, Li60/h;->g:Ll60/f;

    .line 9
    .line 10
    iget-object v1, v1, Li60/h;->j:Li60/i;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const-string v0, "classDescriptor"

    .line 16
    .line 17
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1}, Li60/i;->i0()Lk60/l0;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lk60/f;

    .line 25
    .line 26
    invoke-virtual {v0}, Lk60/f;->i()Ljava/util/Collection;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const-string v1, "getSupertypes(...)"

    .line 31
    .line 32
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    return-object v0

    .line 36
    :pswitch_23
    sget-object v0, Ld60/f;->m:Ld60/f;

    .line 37
    .line 38
    sget-object v2, Ld60/o;->a:Ld60/m;

    .line 39
    .line 40
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    sget-object v2, Ld60/l;->e:Ld60/l;

    .line 44
    .line 45
    sget-object v3, Ly40/c;->d:Ly40/c;

    .line 46
    .line 47
    invoke-virtual {v1, v0, v2}, Li60/p;->i(Ld60/f;Lkotlin/jvm/functions/Function1;)Ljava/util/List;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    return-object v0

    .line 52
    nop

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_23
    .end packed-switch
.end method
