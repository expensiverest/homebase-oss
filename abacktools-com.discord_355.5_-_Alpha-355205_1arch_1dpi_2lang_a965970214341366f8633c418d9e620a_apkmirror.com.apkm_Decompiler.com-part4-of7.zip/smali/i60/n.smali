###### Class i60.n (i60.n)
.class public final Li60/n;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I

.field public final e:Li60/o;

.field public final i:Li60/p;


# direct methods
.method public synthetic constructor <init>(Li60/o;Li60/p;I)V
    .registers 4

    .line 1
    iput p3, p0, Li60/n;->d:I

    iput-object p1, p0, Li60/n;->e:Li60/o;

    iput-object p2, p0, Li60/n;->i:Li60/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Li60/n;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_2c

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li60/n;->e:Li60/o;

    .line 7
    .line 8
    iget-object v0, v0, Li60/o;->b:Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v1, p0, Li60/n;->i:Li60/p;

    .line 15
    .line 16
    invoke-virtual {v1}, Li60/p;->p()Ljava/util/Set;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-static {v1, v0}, Lm30/d0;->U(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0

    .line 25
    :pswitch_18
    iget-object v0, p0, Li60/n;->e:Li60/o;

    .line 26
    .line 27
    iget-object v0, v0, Li60/o;->a:Ljava/util/LinkedHashMap;

    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object v1, p0, Li60/n;->i:Li60/p;

    .line 34
    .line 35
    invoke-virtual {v1}, Li60/p;->o()Ljava/util/Set;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-static {v1, v0}, Lm30/d0;->U(Ljava/lang/Iterable;Ljava/util/Set;)Ljava/util/LinkedHashSet;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    return-object v0

    .line 44
    nop

    .line 45
    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_18
    .end packed-switch
.end method
