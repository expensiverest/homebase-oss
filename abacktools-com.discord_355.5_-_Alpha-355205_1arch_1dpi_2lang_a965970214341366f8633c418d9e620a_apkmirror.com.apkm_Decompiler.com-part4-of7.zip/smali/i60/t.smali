###### Class i60.t (i60.t)
.class public final Li60/t;
.super Lt40/f;
.source "SourceFile"

# interfaces
.implements Li60/l;


# instance fields
.field public final L:Lo50/v0;

.field public final M:Lq50/f;

.field public final N:Ld20/n;

.field public final O:Lq50/i;

.field public final P:Li60/k;

.field public Q:Lk60/a0;

.field public R:Lk60/a0;

.field public S:Ljava/util/List;

.field public T:Lk60/a0;


# direct methods
.method public constructor <init>(Lj60/o;Lq40/k;Lr40/h;Lt50/e;Ld50/o;Lo50/v0;Lq50/f;Ld20/n;Lq50/i;Li60/k;)V
    .registers 12

    .line 1
    const-string v0, "storageManager"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "containingDeclaration"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "visibility"

    .line 12
    .line 13
    invoke-static {p5, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "proto"

    .line 17
    .line 18
    invoke-static {p6, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "nameResolver"

    .line 22
    .line 23
    invoke-static {p7, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v0, "typeTable"

    .line 27
    .line 28
    invoke-static {p8, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const-string v0, "versionRequirementTable"

    .line 32
    .line 33
    invoke-static {p9, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-direct/range {p0 .. p5}, Lt40/f;-><init>(Lj60/o;Lq40/k;Lr40/h;Lt50/e;Ld50/o;)V

    .line 37
    .line 38
    .line 39
    move-object p1, p0

    .line 40
    iput-object p6, p1, Li60/t;->L:Lo50/v0;

    .line 41
    .line 42
    iput-object p7, p1, Li60/t;->M:Lq50/f;

    .line 43
    .line 44
    iput-object p8, p1, Li60/t;->N:Ld20/n;

    .line 45
    .line 46
    iput-object p9, p1, Li60/t;->O:Lq50/i;

    .line 47
    .line 48
    iput-object p10, p1, Li60/t;->P:Li60/k;

    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final J2()Lq40/e;
    .registers 3

    .line 1
    invoke-virtual {p0}, Li60/t;->K2()Lk60/a0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lk60/c;->k(Lk60/w;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_1e

    .line 12
    :cond_b
    invoke-virtual {p0}, Li60/t;->K2()Lk60/a0;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Lk60/w;->n()Lk60/l0;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-interface {v0}, Lk60/l0;->h()Lq40/h;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    instance-of v1, v0, Lq40/e;

    .line 25
    .line 26
    if-eqz v1, :cond_1e

    .line 27
    .line 28
    check-cast v0, Lq40/e;

    .line 29
    .line 30
    return-object v0

    .line 31
    :cond_1e
    :goto_1e
    const/4 v0, 0x0

    .line 32
    return-object v0
.end method

.method public final K2()Lk60/a0;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->R:Lk60/a0;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    const-string v0, "expandedType"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    throw v0
.end method

.method public final L2()Lk60/a0;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->Q:Lk60/a0;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    const-string v0, "underlyingType"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    throw v0
.end method

.method public final M()Lk60/a0;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->T:Lk60/a0;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    const-string v0, "defaultTypeImpl"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    throw v0
.end method

.method public final M2(Ljava/util/List;Lk60/a0;Lk60/a0;)V
    .registers 10

    .line 1
    const-string v0, "underlyingType"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "expandedType"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lt40/f;->J:Ljava/util/List;

    .line 12
    .line 13
    iput-object p2, p0, Li60/t;->Q:Lk60/a0;

    .line 14
    .line 15
    iput-object p3, p0, Li60/t;->R:Lk60/a0;

    .line 16
    .line 17
    invoke-static {p0}, Lq40/v;->c(Lq40/i;)Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p0, Li60/t;->S:Ljava/util/List;

    .line 22
    .line 23
    invoke-virtual {p0}, Li60/t;->J2()Lq40/e;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    if-eqz p1, :cond_25

    .line 28
    .line 29
    invoke-interface {p1}, Lq40/e;->c2()Ld60/o;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    if-nez p1, :cond_23

    .line 34
    .line 35
    goto :goto_25

    .line 36
    :cond_23
    :goto_23
    move-object v4, p1

    .line 37
    goto :goto_28

    .line 38
    :cond_25
    :goto_25
    sget-object p1, Ld60/n;->b:Ld60/n;

    .line 39
    .line 40
    goto :goto_23

    .line 41
    :goto_28
    new-instance v5, Lt40/d;

    .line 42
    .line 43
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 44
    .line 45
    .line 46
    sget-object p1, Lk60/w0;->a:Lm60/j;

    .line 47
    .line 48
    invoke-static {p0}, Lm60/m;->f(Lq40/k;)Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    if-eqz p1, :cond_44

    .line 53
    .line 54
    sget-object p1, Lm60/l;->M:Lm60/l;

    .line 55
    .line 56
    invoke-virtual {p0}, Lt40/f;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    filled-new-array {p2}, [Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    invoke-static {p1, p2}, Lm60/m;->c(Lm60/l;[Ljava/lang/String;)Lm60/j;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    goto :goto_61

    .line 69
    :cond_44
    invoke-virtual {p0}, Lt40/f;->i0()Lk60/l0;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    if-eqz v1, :cond_64

    .line 74
    .line 75
    move-object p1, v1

    .line 76
    check-cast p1, Lt40/e;

    .line 77
    .line 78
    invoke-virtual {p1}, Lt40/e;->getParameters()Ljava/util/List;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    invoke-static {p1}, Lk60/w0;->d(Ljava/util/List;)Ljava/util/List;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    sget-object p1, Lk60/h0;->e:Lz5/u;

    .line 87
    .line 88
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    sget-object v0, Lk60/h0;->i:Lk60/h0;

    .line 92
    .line 93
    const/4 v3, 0x0

    .line 94
    invoke-static/range {v0 .. v5}, Lk60/c;->w(Lk60/h0;Lk60/l0;Ljava/util/List;ZLd60/o;Lkotlin/jvm/functions/Function1;)Lk60/a0;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    :goto_61
    iput-object p1, p0, Li60/t;->T:Lk60/a0;

    .line 99
    .line 100
    return-void

    .line 101
    :cond_64
    const/16 p1, 0xc

    .line 102
    .line 103
    invoke-static {p1}, Lk60/w0;->a(I)V

    .line 104
    .line 105
    .line 106
    const/4 p1, 0x0

    .line 107
    throw p1
.end method

.method public final U0()Ld20/n;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->N:Ld20/n;

    .line 2
    .line 3
    return-object v0
.end method

.method public final d1()Lq50/f;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->M:Lq50/f;

    .line 2
    .line 3
    return-object v0
.end method

.method public final f(Lk60/t0;)Lq40/l;
    .registers 14

    .line 1
    const-string v0, "substitutor"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p1, Lk60/t0;->a:Lk60/r0;

    .line 7
    .line 8
    invoke-virtual {v0}, Lk60/r0;->e()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_e

    .line 13
    .line 14
    return-object p0

    .line 15
    :cond_e
    new-instance v1, Li60/t;

    .line 16
    .line 17
    invoke-virtual {p0}, Lt40/n;->A()Lq40/k;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    const-string v0, "getContainingDeclaration(...)"

    .line 22
    .line 23
    invoke-static {v3, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0}, Lb3/l;->getAnnotations()Lr40/h;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    const-string v0, "<get-annotations>(...)"

    .line 31
    .line 32
    invoke-static {v4, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Lt40/m;->getName()Lt50/e;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    const-string v0, "getName(...)"

    .line 40
    .line 41
    invoke-static {v5, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v10, p0, Li60/t;->O:Lq50/i;

    .line 45
    .line 46
    iget-object v11, p0, Li60/t;->P:Li60/k;

    .line 47
    .line 48
    iget-object v2, p0, Lt40/f;->x:Lj60/o;

    .line 49
    .line 50
    iget-object v6, p0, Lt40/f;->y:Ld50/o;

    .line 51
    .line 52
    iget-object v7, p0, Li60/t;->L:Lo50/v0;

    .line 53
    .line 54
    iget-object v8, p0, Li60/t;->M:Lq50/f;

    .line 55
    .line 56
    iget-object v9, p0, Li60/t;->N:Ld20/n;

    .line 57
    .line 58
    invoke-direct/range {v1 .. v11}, Li60/t;-><init>(Lj60/o;Lq40/k;Lr40/h;Lt50/e;Ld50/o;Lo50/v0;Lq50/f;Ld20/n;Lq50/i;Li60/k;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p0}, Lt40/f;->a0()Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {p0}, Li60/t;->L2()Lk60/a0;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    sget-object v3, Lk60/z0;->i:Lk60/z0;

    .line 70
    .line 71
    invoke-virtual {p1, v2, v3}, Lk60/t0;->g(Lk60/w;Lk60/z0;)Lk60/w;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    invoke-static {v2}, Lk60/c;->b(Lk60/w;)Lk60/a0;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    invoke-virtual {p0}, Li60/t;->K2()Lk60/a0;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    invoke-virtual {p1, v4, v3}, Lk60/t0;->g(Lk60/w;Lk60/z0;)Lk60/w;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    invoke-static {p1}, Lk60/c;->b(Lk60/w;)Lk60/a0;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    invoke-virtual {v1, v0, v2, p1}, Li60/t;->M2(Ljava/util/List;Lk60/a0;Lk60/a0;)V

    .line 92
    .line 93
    .line 94
    return-object v1
.end method

.method public final h1()Li60/k;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->P:Li60/k;

    .line 2
    .line 3
    return-object v0
.end method

.method public final v0()Lu50/a;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/t;->L:Lo50/v0;

    .line 2
    .line 3
    return-object v0
.end method
