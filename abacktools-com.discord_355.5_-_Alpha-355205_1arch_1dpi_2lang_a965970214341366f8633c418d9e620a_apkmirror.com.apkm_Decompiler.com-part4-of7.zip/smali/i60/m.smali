###### Class i60.m (i60.m)
.class public final Li60/m;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final e:Li60/o;


# direct methods
.method public synthetic constructor <init>(Li60/o;I)V
    .registers 3

    .line 1
    iput p2, p0, Li60/m;->d:I

    iput-object p1, p0, Li60/m;->e:Li60/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget v0, p0, Li60/m;->d:I

    .line 2
    .line 3
    check-cast p1, Lt50/e;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_1b6

    .line 6
    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Li60/m;->e:Li60/o;

    .line 14
    .line 15
    iget-object v1, v0, Li60/o;->i:Li60/p;

    .line 16
    .line 17
    iget-object v1, v1, Li60/p;->b:Lbg/c;

    .line 18
    .line 19
    iget-object v0, v0, Li60/o;->c:Ljava/util/LinkedHashMap;

    .line 20
    .line 21
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, [B

    .line 26
    .line 27
    if-nez p1, :cond_1d

    .line 28
    .line 29
    goto :goto_33

    .line 30
    :cond_1d
    new-instance v0, Ljava/io/ByteArrayInputStream;

    .line 31
    .line 32
    invoke-direct {v0, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 33
    .line 34
    .line 35
    iget-object p1, v1, Lbg/c;->e:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Lg60/i;

    .line 38
    .line 39
    iget-object p1, p1, Lg60/i;->p:Lu50/g;

    .line 40
    .line 41
    sget-object v2, Lo50/v0;->S:Lo50/a;

    .line 42
    .line 43
    invoke-virtual {v2, v0, p1}, Lu50/b;->b(Ljava/io/ByteArrayInputStream;Lu50/g;)Lu50/a;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    move-object v8, p1

    .line 48
    check-cast v8, Lo50/v0;

    .line 49
    .line 50
    if-nez v8, :cond_36

    .line 51
    .line 52
    :goto_33
    const/4 p1, 0x0

    .line 53
    goto/16 :goto_e6

    .line 54
    .line 55
    :cond_36
    iget-object p1, v1, Lbg/c;->L:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p1, Lg60/s;

    .line 58
    .line 59
    iget-object v0, p1, Lg60/s;->a:Lbg/c;

    .line 60
    .line 61
    iget-object v1, v0, Lbg/c;->i:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v1, Lq50/f;

    .line 64
    .line 65
    iget-object v2, v0, Lbg/c;->w:Ljava/lang/Object;

    .line 66
    .line 67
    move-object v10, v2

    .line 68
    check-cast v10, Ld20/n;

    .line 69
    .line 70
    iget-object v2, v8, Lo50/v0;->M:Ljava/util/List;

    .line 71
    .line 72
    const-string v3, "getAnnotationList(...)"

    .line 73
    .line 74
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    new-instance v3, Ljava/util/ArrayList;

    .line 78
    .line 79
    const/16 v4, 0xa

    .line 80
    .line 81
    invoke-static {v2, v4}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 82
    .line 83
    .line 84
    move-result v4

    .line 85
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 86
    .line 87
    .line 88
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    :goto_5b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    if-eqz v4, :cond_74

    .line 97
    .line 98
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    check-cast v4, Lo50/h;

    .line 103
    .line 104
    iget-object v5, p1, Lg60/s;->b:Lio/sentry/internal/debugmeta/c;

    .line 105
    .line 106
    invoke-static {v4}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v5, v4, v1}, Lio/sentry/internal/debugmeta/c;->o(Lo50/h;Lq50/f;)Lr40/c;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    goto :goto_5b

    .line 117
    :cond_74
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 118
    .line 119
    .line 120
    move-result p1

    .line 121
    if-eqz p1, :cond_7e

    .line 122
    .line 123
    sget-object p1, Lr40/g;->a:Lr40/f;

    .line 124
    .line 125
    :goto_7c
    move-object v5, p1

    .line 126
    goto :goto_85

    .line 127
    :cond_7e
    new-instance p1, Lr40/i;

    .line 128
    .line 129
    const/4 v2, 0x0

    .line 130
    invoke-direct {p1, v2, v3}, Lr40/i;-><init>(ILjava/util/List;)V

    .line 131
    .line 132
    .line 133
    goto :goto_7c

    .line 134
    :goto_85
    sget-object p1, Lq50/d;->d:Lq50/c;

    .line 135
    .line 136
    iget v2, v8, Lo50/v0;->v:I

    .line 137
    .line 138
    invoke-virtual {p1, v2}, Lq50/c;->c(I)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    check-cast p1, Lo50/h1;

    .line 143
    .line 144
    invoke-static {p1}, Lw70/m;->k(Lo50/h1;)Ld50/o;

    .line 145
    .line 146
    .line 147
    move-result-object v7

    .line 148
    new-instance v2, Li60/t;

    .line 149
    .line 150
    iget-object p1, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast p1, Lg60/i;

    .line 153
    .line 154
    iget-object v3, p1, Lg60/i;->a:Lj60/l;

    .line 155
    .line 156
    iget-object p1, v0, Lbg/c;->v:Ljava/lang/Object;

    .line 157
    .line 158
    move-object v4, p1

    .line 159
    check-cast v4, Lq40/k;

    .line 160
    .line 161
    iget p1, v8, Lo50/v0;->w:I

    .line 162
    .line 163
    invoke-static {v1, p1}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 164
    .line 165
    .line 166
    move-result-object v6

    .line 167
    iget-object p1, v0, Lbg/c;->i:Ljava/lang/Object;

    .line 168
    .line 169
    move-object v9, p1

    .line 170
    check-cast v9, Lq50/f;

    .line 171
    .line 172
    iget-object p1, v0, Lbg/c;->x:Ljava/lang/Object;

    .line 173
    .line 174
    move-object v11, p1

    .line 175
    check-cast v11, Lq50/i;

    .line 176
    .line 177
    iget-object p1, v0, Lbg/c;->J:Ljava/lang/Object;

    .line 178
    .line 179
    move-object v12, p1

    .line 180
    check-cast v12, Li60/k;

    .line 181
    .line 182
    invoke-direct/range {v2 .. v12}, Li60/t;-><init>(Lj60/o;Lq40/k;Lr40/h;Lt50/e;Ld50/o;Lo50/v0;Lq50/f;Ld20/n;Lq50/i;Li60/k;)V

    .line 183
    .line 184
    .line 185
    iget-object p1, v8, Lo50/v0;->x:Ljava/util/List;

    .line 186
    .line 187
    const-string v1, "getTypeParameterList(...)"

    .line 188
    .line 189
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    invoke-static {v0, v2, p1}, Lbg/c;->c(Lbg/c;Lt40/n;Ljava/util/List;)Lbg/c;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    iget-object p1, p1, Lbg/c;->K:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast p1, Lp/r3;

    .line 199
    .line 200
    iget-object v0, p1, Lp/r3;->J:Ljava/lang/Object;

    .line 201
    .line 202
    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    invoke-static {v0}, Lm30/q;->S0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-static {v8, v10}, Landroid/support/v4/media/session/b;->m0(Lo50/v0;Ld20/n;)Lo50/t0;

    .line 211
    .line 212
    .line 213
    move-result-object v1

    .line 214
    const/4 v3, 0x0

    .line 215
    invoke-virtual {p1, v1, v3}, Lp/r3;->o(Lo50/t0;Z)Lk60/a0;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    invoke-static {v8, v10}, Landroid/support/v4/media/session/b;->t(Lo50/v0;Ld20/n;)Lo50/t0;

    .line 220
    .line 221
    .line 222
    move-result-object v4

    .line 223
    invoke-virtual {p1, v4, v3}, Lp/r3;->o(Lo50/t0;Z)Lk60/a0;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    invoke-virtual {v2, v0, v1, p1}, Li60/t;->M2(Ljava/util/List;Lk60/a0;Lk60/a0;)V

    .line 228
    .line 229
    .line 230
    move-object p1, v2

    .line 231
    :goto_e6
    return-object p1

    .line 232
    :pswitch_e7
    const-string v0, "it"

    .line 233
    .line 234
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    .line 236
    .line 237
    iget-object v0, p0, Li60/m;->e:Li60/o;

    .line 238
    .line 239
    iget-object v1, v0, Li60/o;->b:Ljava/util/LinkedHashMap;

    .line 240
    .line 241
    sget-object v2, Lo50/j0;->f0:Lo50/a;

    .line 242
    .line 243
    const-string v3, "PARSER"

    .line 244
    .line 245
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    iget-object v0, v0, Li60/o;->i:Li60/p;

    .line 249
    .line 250
    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v1

    .line 254
    check-cast v1, [B

    .line 255
    .line 256
    if-eqz v1, :cond_115

    .line 257
    .line 258
    new-instance v3, Ljava/io/ByteArrayInputStream;

    .line 259
    .line 260
    invoke-direct {v3, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 261
    .line 262
    .line 263
    new-instance v1, Lbg/y;

    .line 264
    .line 265
    const/4 v4, 0x1

    .line 266
    invoke-direct {v1, v4, v2, v3, v0}, Lbg/y;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    invoke-static {v1}, Lv60/m;->F0(Lkotlin/jvm/functions/Function0;)Lv60/k;

    .line 270
    .line 271
    .line 272
    move-result-object v1

    .line 273
    invoke-static {v1}, Lv60/m;->K0(Lv60/k;)Ljava/util/List;

    .line 274
    .line 275
    .line 276
    move-result-object v1

    .line 277
    goto :goto_117

    .line 278
    :cond_115
    sget-object v1, Lm30/s;->d:Lm30/s;

    .line 279
    .line 280
    :goto_117
    new-instance v2, Ljava/util/ArrayList;

    .line 281
    .line 282
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 283
    .line 284
    .line 285
    move-result v3

    .line 286
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 287
    .line 288
    .line 289
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 290
    .line 291
    .line 292
    move-result-object v1

    .line 293
    :goto_124
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 294
    .line 295
    .line 296
    move-result v3

    .line 297
    if-eqz v3, :cond_142

    .line 298
    .line 299
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v3

    .line 303
    check-cast v3, Lo50/j0;

    .line 304
    .line 305
    iget-object v4, v0, Li60/p;->b:Lbg/c;

    .line 306
    .line 307
    iget-object v4, v4, Lbg/c;->L:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast v4, Lg60/s;

    .line 310
    .line 311
    invoke-static {v3}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    const/4 v5, 0x0

    .line 315
    invoke-virtual {v4, v3, v5}, Lg60/s;->g(Lo50/j0;Z)Li60/r;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 320
    .line 321
    .line 322
    goto :goto_124

    .line 323
    :cond_142
    invoke-virtual {v0, v2, p1}, Li60/p;->k(Ljava/util/ArrayList;Lt50/e;)V

    .line 324
    .line 325
    .line 326
    invoke-static {v2}, Lt60/l;->d(Ljava/util/ArrayList;)Ljava/util/List;

    .line 327
    .line 328
    .line 329
    move-result-object p1

    .line 330
    return-object p1

    .line 331
    :pswitch_14a
    const-string v0, "it"

    .line 332
    .line 333
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    iget-object v0, p0, Li60/m;->e:Li60/o;

    .line 337
    .line 338
    iget-object v1, v0, Li60/o;->a:Ljava/util/LinkedHashMap;

    .line 339
    .line 340
    sget-object v2, Lo50/b0;->b0:Lo50/a;

    .line 341
    .line 342
    const-string v3, "PARSER"

    .line 343
    .line 344
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 345
    .line 346
    .line 347
    iget-object v0, v0, Li60/o;->i:Li60/p;

    .line 348
    .line 349
    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v1

    .line 353
    check-cast v1, [B

    .line 354
    .line 355
    if-eqz v1, :cond_178

    .line 356
    .line 357
    new-instance v3, Ljava/io/ByteArrayInputStream;

    .line 358
    .line 359
    invoke-direct {v3, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 360
    .line 361
    .line 362
    new-instance v1, Lbg/y;

    .line 363
    .line 364
    const/4 v4, 0x1

    .line 365
    invoke-direct {v1, v4, v2, v3, v0}, Lbg/y;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 366
    .line 367
    .line 368
    invoke-static {v1}, Lv60/m;->F0(Lkotlin/jvm/functions/Function0;)Lv60/k;

    .line 369
    .line 370
    .line 371
    move-result-object v1

    .line 372
    invoke-static {v1}, Lv60/m;->K0(Lv60/k;)Ljava/util/List;

    .line 373
    .line 374
    .line 375
    move-result-object v1

    .line 376
    goto :goto_17a

    .line 377
    :cond_178
    sget-object v1, Lm30/s;->d:Lm30/s;

    .line 378
    .line 379
    :goto_17a
    new-instance v2, Ljava/util/ArrayList;

    .line 380
    .line 381
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 382
    .line 383
    .line 384
    move-result v3

    .line 385
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 386
    .line 387
    .line 388
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 389
    .line 390
    .line 391
    move-result-object v1

    .line 392
    :cond_187
    :goto_187
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 393
    .line 394
    .line 395
    move-result v3

    .line 396
    if-eqz v3, :cond_1ae

    .line 397
    .line 398
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 399
    .line 400
    .line 401
    move-result-object v3

    .line 402
    check-cast v3, Lo50/b0;

    .line 403
    .line 404
    iget-object v4, v0, Li60/p;->b:Lbg/c;

    .line 405
    .line 406
    iget-object v4, v4, Lbg/c;->L:Ljava/lang/Object;

    .line 407
    .line 408
    check-cast v4, Lg60/s;

    .line 409
    .line 410
    invoke-static {v3}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 411
    .line 412
    .line 413
    invoke-virtual {v4, v3}, Lg60/s;->f(Lo50/b0;)Li60/s;

    .line 414
    .line 415
    .line 416
    move-result-object v3

    .line 417
    invoke-virtual {v0, v3}, Li60/p;->r(Li60/s;)Z

    .line 418
    .line 419
    .line 420
    move-result v4

    .line 421
    if-eqz v4, :cond_1a7

    .line 422
    .line 423
    goto :goto_1a8

    .line 424
    :cond_1a7
    const/4 v3, 0x0

    .line 425
    :goto_1a8
    if-eqz v3, :cond_187

    .line 426
    .line 427
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 428
    .line 429
    .line 430
    goto :goto_187

    .line 431
    :cond_1ae
    invoke-virtual {v0, v2, p1}, Li60/p;->j(Ljava/util/ArrayList;Lt50/e;)V

    .line 432
    .line 433
    .line 434
    invoke-static {v2}, Lt60/l;->d(Ljava/util/ArrayList;)Ljava/util/List;

    .line 435
    .line 436
    .line 437
    move-result-object p1

    .line 438
    return-object p1

    .line 439
    :pswitch_data_1b6
    .packed-switch 0x0
        :pswitch_14a
        :pswitch_e7
    .end packed-switch
.end method
