###### Class i60.c (i60.c)
.class public final Li60/c;
.super Lt40/i;
.source "SourceFile"

# interfaces
.implements Li60/b;


# instance fields
.field public final h0:Lo50/n;

.field public final i0:Lq50/f;

.field public final j0:Ld20/n;

.field public final k0:Lq50/i;

.field public final l0:Li60/k;


# direct methods
.method public constructor <init>(Lq40/e;Lq40/j;Lr40/h;ZILo50/n;Lq50/f;Ld20/n;Lq50/i;Li60/k;Lq40/m0;)V
    .registers 23

    .line 1
    move-object/from16 v7, p6

    .line 2
    .line 3
    move-object/from16 v8, p7

    .line 4
    .line 5
    move-object/from16 v9, p8

    .line 6
    .line 7
    move-object/from16 v10, p9

    .line 8
    .line 9
    const-string v0, "containingDeclaration"

    .line 10
    .line 11
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v0, "annotations"

    .line 15
    .line 16
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const-string v0, "kind"

    .line 20
    .line 21
    move/from16 v5, p5

    .line 22
    .line 23
    invoke-static {v5, v0}, Lhs/q;->q(ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v0, "proto"

    .line 27
    .line 28
    invoke-static {v7, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const-string v0, "nameResolver"

    .line 32
    .line 33
    invoke-static {v8, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const-string v0, "typeTable"

    .line 37
    .line 38
    invoke-static {v9, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    const-string v0, "versionRequirementTable"

    .line 42
    .line 43
    invoke-static {v10, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    if-nez p11, :cond_38

    .line 47
    .line 48
    sget-object v0, Lq40/m0;->u:Lq40/n0;

    .line 49
    .line 50
    move-object v6, v0

    .line 51
    move-object v1, p1

    .line 52
    move-object v2, p2

    .line 53
    move-object v3, p3

    .line 54
    move v4, p4

    .line 55
    move-object v0, p0

    .line 56
    goto :goto_3f

    .line 57
    :cond_38
    move-object/from16 v6, p11

    .line 58
    .line 59
    move-object v0, p0

    .line 60
    move-object v1, p1

    .line 61
    move-object v2, p2

    .line 62
    move-object v3, p3

    .line 63
    move v4, p4

    .line 64
    :goto_3f
    invoke-direct/range {v0 .. v6}, Lt40/i;-><init>(Lq40/e;Lq40/j;Lr40/h;ZILq40/m0;)V

    .line 65
    .line 66
    .line 67
    iput-object v7, p0, Li60/c;->h0:Lo50/n;

    .line 68
    .line 69
    iput-object v8, p0, Li60/c;->i0:Lq50/f;

    .line 70
    .line 71
    iput-object v9, p0, Li60/c;->j0:Ld20/n;

    .line 72
    .line 73
    iput-object v10, p0, Li60/c;->k0:Lq50/i;

    .line 74
    .line 75
    move-object/from16 v1, p10

    .line 76
    .line 77
    iput-object v1, p0, Li60/c;->l0:Li60/k;

    .line 78
    .line 79
    return-void
.end method


# virtual methods
.method public final bridge synthetic L2(ILq40/k;Lq40/t;Lq40/m0;Lr40/h;Lt50/e;)Lt40/t;
    .registers 7

    .line 1
    move-object p6, p4

    .line 2
    move p4, p1

    .line 3
    move-object p1, p0

    .line 4
    invoke-virtual/range {p1 .. p6}, Li60/c;->a3(Lq40/k;Lq40/t;ILr40/h;Lq40/m0;)Li60/c;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    return-object p2
.end method

.method public final P0()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final U0()Ld20/n;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/c;->j0:Ld20/n;

    .line 2
    .line 3
    return-object v0
.end method

.method public final bridge synthetic U2(ILq40/k;Lq40/t;Lq40/m0;Lr40/h;Lt50/e;)Lt40/i;
    .registers 7

    .line 1
    move-object p6, p4

    .line 2
    move p4, p1

    .line 3
    move-object p1, p0

    .line 4
    invoke-virtual/range {p1 .. p6}, Li60/c;->a3(Lq40/k;Lq40/t;ILr40/h;Lq40/m0;)Li60/c;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    return-object p2
.end method

.method public final a3(Lq40/k;Lq40/t;ILr40/h;Lq40/m0;)Li60/c;
    .registers 19

    .line 1
    const-string v0, "newOwner"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "kind"

    .line 7
    .line 8
    move/from16 v6, p3

    .line 9
    .line 10
    invoke-static {v6, v0}, Lhs/q;->q(ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v0, "annotations"

    .line 14
    .line 15
    move-object/from16 v4, p4

    .line 16
    .line 17
    invoke-static {v4, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    new-instance v1, Li60/c;

    .line 21
    .line 22
    move-object v2, p1

    .line 23
    check-cast v2, Lq40/e;

    .line 24
    .line 25
    move-object v3, p2

    .line 26
    check-cast v3, Lq40/j;

    .line 27
    .line 28
    iget-object v10, p0, Li60/c;->k0:Lq50/i;

    .line 29
    .line 30
    iget-object v11, p0, Li60/c;->l0:Li60/k;

    .line 31
    .line 32
    iget-boolean v5, p0, Lt40/i;->g0:Z

    .line 33
    .line 34
    iget-object v7, p0, Li60/c;->h0:Lo50/n;

    .line 35
    .line 36
    iget-object v8, p0, Li60/c;->i0:Lq50/f;

    .line 37
    .line 38
    iget-object v9, p0, Li60/c;->j0:Ld20/n;

    .line 39
    .line 40
    move-object/from16 v12, p5

    .line 41
    .line 42
    invoke-direct/range {v1 .. v12}, Li60/c;-><init>(Lq40/e;Lq40/j;Lr40/h;ZILo50/n;Lq50/f;Ld20/n;Lq50/i;Li60/k;Lq40/m0;)V

    .line 43
    .line 44
    .line 45
    iget-boolean p1, p0, Lt40/t;->Y:Z

    .line 46
    .line 47
    iput-boolean p1, v1, Lt40/t;->Y:Z

    .line 48
    .line 49
    return-object v1
.end method

.method public final d1()Lq50/f;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/c;->i0:Lq50/f;

    .line 2
    .line 3
    return-object v0
.end method

.method public final h1()Li60/k;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/c;->l0:Li60/k;

    .line 2
    .line 3
    return-object v0
.end method

.method public final isExternal()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final isInline()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final isSuspend()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final v0()Lu50/a;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/c;->h0:Lo50/n;

    .line 2
    .line 3
    return-object v0
.end method
