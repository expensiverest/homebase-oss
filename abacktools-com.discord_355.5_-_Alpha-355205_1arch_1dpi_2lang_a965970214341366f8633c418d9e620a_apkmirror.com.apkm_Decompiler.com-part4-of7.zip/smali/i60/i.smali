###### Class i60.i (i60.i)
.class public final Li60/i;
.super Lt40/b;
.source "SourceFile"

# interfaces
.implements Lq40/k;


# instance fields
.field public final J:Lt50/b;

.field public final K:Lq40/x;

.field public final L:Ld50/o;

.field public final M:Lq40/f;

.field public final N:Lbg/c;

.field public final O:Ld60/p;

.field public final P:Lh50/h;

.field public final Q:Lq40/l0;

.field public final R:Lcom/google/firebase/messaging/t;

.field public final S:Lq40/k;

.field public final T:Lj60/h;

.field public final U:Lj60/i;

.field public final V:Lj60/h;

.field public final W:Lg60/t;

.field public final X:Lr40/h;

.field public final w:Lo50/k;

.field public final x:Lq50/a;

.field public final y:Lq40/m0;


# direct methods
.method public constructor <init>(Lbg/c;Lo50/k;Lq50/f;Lq50/a;Lq40/m0;)V
    .registers 23

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v8, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    move-object/from16 v9, p5

    .line 10
    .line 11
    const-string v2, "outerContext"

    .line 12
    .line 13
    invoke-static {v0, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v2, "classProto"

    .line 17
    .line 18
    invoke-static {v8, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v2, "nameResolver"

    .line 22
    .line 23
    invoke-static {v3, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v2, "sourceElement"

    .line 27
    .line 28
    invoke-static {v9, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v2, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v2, Lg60/i;

    .line 34
    .line 35
    iget-object v2, v2, Lg60/i;->a:Lj60/l;

    .line 36
    .line 37
    iget v4, v8, Lo50/k;->w:I

    .line 38
    .line 39
    invoke-static {v3, v4}, Lul/b;->s(Lq50/f;I)Lt50/b;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    invoke-virtual {v4}, Lt50/b;->f()Lt50/e;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-direct {v1, v2, v4}, Lt40/b;-><init>(Lj60/o;Lt50/e;)V

    .line 48
    .line 49
    .line 50
    iput-object v8, v1, Li60/i;->w:Lo50/k;

    .line 51
    .line 52
    move-object/from16 v6, p4

    .line 53
    .line 54
    iput-object v6, v1, Li60/i;->x:Lq50/a;

    .line 55
    .line 56
    iput-object v9, v1, Li60/i;->y:Lq40/m0;

    .line 57
    .line 58
    iget v2, v8, Lo50/k;->w:I

    .line 59
    .line 60
    invoke-static {v3, v2}, Lul/b;->s(Lq50/f;I)Lt50/b;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    iput-object v2, v1, Li60/i;->J:Lt50/b;

    .line 65
    .line 66
    sget-object v2, Lq50/d;->e:Lq50/c;

    .line 67
    .line 68
    iget v4, v8, Lo50/k;->v:I

    .line 69
    .line 70
    invoke-virtual {v2, v4}, Lq50/c;->c(I)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    check-cast v2, Lo50/d0;

    .line 75
    .line 76
    invoke-static {v2}, Lg60/j;->e(Lo50/d0;)Lq40/x;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    iput-object v2, v1, Li60/i;->K:Lq40/x;

    .line 81
    .line 82
    sget-object v2, Lq50/d;->d:Lq50/c;

    .line 83
    .line 84
    iget v4, v8, Lo50/k;->v:I

    .line 85
    .line 86
    invoke-virtual {v2, v4}, Lq50/c;->c(I)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    check-cast v2, Lo50/h1;

    .line 91
    .line 92
    invoke-static {v2}, Lw70/m;->k(Lo50/h1;)Ld50/o;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    iput-object v2, v1, Li60/i;->L:Ld50/o;

    .line 97
    .line 98
    sget-object v2, Lq50/d;->f:Lq50/c;

    .line 99
    .line 100
    iget v4, v8, Lo50/k;->v:I

    .line 101
    .line 102
    invoke-virtual {v2, v4}, Lq50/c;->c(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    check-cast v2, Lo50/j;

    .line 107
    .line 108
    if-nez v2, :cond_6f

    .line 109
    .line 110
    const/4 v2, -0x1

    .line 111
    goto :goto_77

    .line 112
    :cond_6f
    sget-object v4, Lg60/v;->b:[I

    .line 113
    .line 114
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 115
    .line 116
    .line 117
    move-result v2

    .line 118
    aget v2, v4, v2

    .line 119
    .line 120
    :goto_77
    packed-switch v2, :pswitch_data_1b2

    .line 121
    .line 122
    .line 123
    sget-object v2, Lq40/f;->d:Lq40/f;

    .line 124
    .line 125
    :goto_7c
    move-object v10, v2

    .line 126
    goto :goto_90

    .line 127
    :pswitch_7e
    sget-object v2, Lq40/f;->x:Lq40/f;

    .line 128
    .line 129
    goto :goto_7c

    .line 130
    :pswitch_81
    sget-object v2, Lq40/f;->w:Lq40/f;

    .line 131
    .line 132
    goto :goto_7c

    .line 133
    :pswitch_84
    sget-object v2, Lq40/f;->v:Lq40/f;

    .line 134
    .line 135
    goto :goto_7c

    .line 136
    :pswitch_87
    sget-object v2, Lq40/f;->i:Lq40/f;

    .line 137
    .line 138
    goto :goto_7c

    .line 139
    :pswitch_8a
    sget-object v2, Lq40/f;->e:Lq40/f;

    .line 140
    .line 141
    goto :goto_7c

    .line 142
    :pswitch_8d
    sget-object v2, Lq40/f;->d:Lq40/f;

    .line 143
    .line 144
    goto :goto_7c

    .line 145
    :goto_90
    iput-object v10, v1, Li60/i;->M:Lq40/f;

    .line 146
    .line 147
    iget-object v2, v8, Lo50/k;->y:Ljava/util/List;

    .line 148
    .line 149
    const-string v4, "getTypeParameterList(...)"

    .line 150
    .line 151
    invoke-static {v2, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    new-instance v4, Ld20/n;

    .line 155
    .line 156
    iget-object v5, v8, Lo50/k;->c0:Lo50/z0;

    .line 157
    .line 158
    const-string v7, "getTypeTable(...)"

    .line 159
    .line 160
    invoke-static {v5, v7}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    invoke-direct {v4, v5}, Ld20/n;-><init>(Lo50/z0;)V

    .line 164
    .line 165
    .line 166
    sget-object v5, Lq50/i;->b:Lq50/i;

    .line 167
    .line 168
    iget-object v5, v8, Lo50/k;->e0:Lo50/g1;

    .line 169
    .line 170
    const-string v7, "getVersionRequirementTable(...)"

    .line 171
    .line 172
    invoke-static {v5, v7}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v5}, Lc7/t;->k(Lo50/g1;)Lq50/i;

    .line 176
    .line 177
    .line 178
    move-result-object v5

    .line 179
    invoke-virtual/range {v0 .. v6}, Lbg/c;->a(Lq40/k;Ljava/util/List;Lq50/f;Ld20/n;Lq50/i;Lq50/a;)Lbg/c;

    .line 180
    .line 181
    .line 182
    move-result-object v11

    .line 183
    move-object v12, v0

    .line 184
    iget-object v0, v11, Lbg/c;->e:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v0, Lg60/i;

    .line 187
    .line 188
    iget-object v13, v0, Lg60/i;->a:Lj60/l;

    .line 189
    .line 190
    iput-object v11, v1, Li60/i;->N:Lbg/c;

    .line 191
    .line 192
    sget-object v2, Lq50/d;->m:Lq50/b;

    .line 193
    .line 194
    iget v3, v8, Lo50/k;->v:I

    .line 195
    .line 196
    invoke-virtual {v2, v3}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 197
    .line 198
    .line 199
    move-result-object v2

    .line 200
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 201
    .line 202
    .line 203
    move-result v2

    .line 204
    sget-object v14, Lq40/f;->i:Lq40/f;

    .line 205
    .line 206
    const/4 v3, 0x0

    .line 207
    if-ne v10, v14, :cond_ea

    .line 208
    .line 209
    if-nez v2, :cond_e3

    .line 210
    .line 211
    iget-object v2, v0, Lg60/i;->s:Lg60/k;

    .line 212
    .line 213
    invoke-interface {v2}, Lg60/k;->d()Ljava/lang/Boolean;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 218
    .line 219
    invoke-static {v2, v4}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v2

    .line 223
    if-eqz v2, :cond_e1

    .line 224
    .line 225
    goto :goto_e3

    .line 226
    :cond_e1
    move v2, v3

    .line 227
    goto :goto_e4

    .line 228
    :cond_e3
    :goto_e3
    const/4 v2, 0x1

    .line 229
    :goto_e4
    new-instance v4, Ld60/s;

    .line 230
    .line 231
    invoke-direct {v4, v13, v1, v2}, Ld60/s;-><init>(Lj60/l;Li60/i;Z)V

    .line 232
    .line 233
    .line 234
    goto :goto_ec

    .line 235
    :cond_ea
    sget-object v4, Ld60/n;->b:Ld60/n;

    .line 236
    .line 237
    :goto_ec
    iput-object v4, v1, Li60/i;->O:Ld60/p;

    .line 238
    .line 239
    new-instance v2, Lh50/h;

    .line 240
    .line 241
    invoke-direct {v2, v1}, Lh50/h;-><init>(Li60/i;)V

    .line 242
    .line 243
    .line 244
    iput-object v2, v1, Li60/i;->P:Lh50/h;

    .line 245
    .line 246
    sget-object v16, Lq40/l0;->d:Lq40/n0;

    .line 247
    .line 248
    iget-object v0, v0, Lg60/i;->q:Ll60/k;

    .line 249
    .line 250
    check-cast v0, Ll60/l;

    .line 251
    .line 252
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 253
    .line 254
    .line 255
    new-instance v0, Lcg/a;

    .line 256
    .line 257
    const/4 v6, 0x0

    .line 258
    const/4 v7, 0x7

    .line 259
    const/4 v1, 0x1

    .line 260
    move v2, v3

    .line 261
    const-class v3, Li60/h;

    .line 262
    .line 263
    const-string v4, "<init>"

    .line 264
    .line 265
    const-string v5, "<init>(Lorg/jetbrains/kotlin/serialization/deserialization/descriptors/DeserializedClassDescriptor;Lorg/jetbrains/kotlin/types/checker/KotlinTypeRefiner;)V"

    .line 266
    .line 267
    move v15, v2

    .line 268
    move-object/from16 v2, p0

    .line 269
    .line 270
    invoke-direct/range {v0 .. v7}, Lcg/a;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    .line 271
    .line 272
    .line 273
    move-object v6, v2

    .line 274
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 275
    .line 276
    .line 277
    const-string v1, "storageManager"

    .line 278
    .line 279
    invoke-static {v13, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    new-instance v1, Lq40/l0;

    .line 283
    .line 284
    invoke-direct {v1, v6, v13, v0}, Lq40/l0;-><init>(Lt40/b;Lj60/o;Lkotlin/jvm/functions/Function1;)V

    .line 285
    .line 286
    .line 287
    iput-object v1, v6, Li60/i;->Q:Lq40/l0;

    .line 288
    .line 289
    const/4 v0, 0x0

    .line 290
    if-ne v10, v14, :cond_129

    .line 291
    .line 292
    new-instance v1, Lcom/google/firebase/messaging/t;

    .line 293
    .line 294
    invoke-direct {v1, v6}, Lcom/google/firebase/messaging/t;-><init>(Li60/i;)V

    .line 295
    .line 296
    .line 297
    goto :goto_12a

    .line 298
    :cond_129
    move-object v1, v0

    .line 299
    :goto_12a
    iput-object v1, v6, Li60/i;->R:Lcom/google/firebase/messaging/t;

    .line 300
    .line 301
    iget-object v1, v12, Lbg/c;->v:Ljava/lang/Object;

    .line 302
    .line 303
    check-cast v1, Lq40/k;

    .line 304
    .line 305
    iput-object v1, v6, Li60/i;->S:Lq40/k;

    .line 306
    .line 307
    new-instance v2, Li60/d;

    .line 308
    .line 309
    invoke-direct {v2, v6, v15}, Li60/d;-><init>(Li60/i;I)V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 313
    .line 314
    .line 315
    new-instance v3, Lj60/h;

    .line 316
    .line 317
    invoke-direct {v3, v13, v2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 318
    .line 319
    .line 320
    iput-object v3, v6, Li60/i;->T:Lj60/h;

    .line 321
    .line 322
    new-instance v2, Li60/d;

    .line 323
    .line 324
    const/4 v3, 0x1

    .line 325
    invoke-direct {v2, v6, v3}, Li60/d;-><init>(Li60/i;I)V

    .line 326
    .line 327
    .line 328
    new-instance v3, Lj60/i;

    .line 329
    .line 330
    invoke-direct {v3, v13, v2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 331
    .line 332
    .line 333
    iput-object v3, v6, Li60/i;->U:Lj60/i;

    .line 334
    .line 335
    new-instance v2, Li60/d;

    .line 336
    .line 337
    const/4 v3, 0x2

    .line 338
    invoke-direct {v2, v6, v3}, Li60/d;-><init>(Li60/i;I)V

    .line 339
    .line 340
    .line 341
    new-instance v3, Lj60/h;

    .line 342
    .line 343
    invoke-direct {v3, v13, v2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 344
    .line 345
    .line 346
    new-instance v2, Li60/d;

    .line 347
    .line 348
    const/4 v3, 0x3

    .line 349
    invoke-direct {v2, v6, v3}, Li60/d;-><init>(Li60/i;I)V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v13, v2}, Lj60/l;->a(Lkotlin/jvm/functions/Function0;)Lj60/i;

    .line 353
    .line 354
    .line 355
    new-instance v2, Li60/d;

    .line 356
    .line 357
    const/4 v3, 0x4

    .line 358
    invoke-direct {v2, v6, v3}, Li60/d;-><init>(Li60/i;I)V

    .line 359
    .line 360
    .line 361
    new-instance v3, Lj60/h;

    .line 362
    .line 363
    invoke-direct {v3, v13, v2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 364
    .line 365
    .line 366
    iput-object v3, v6, Li60/i;->V:Lj60/h;

    .line 367
    .line 368
    move-object v2, v0

    .line 369
    new-instance v0, Lg60/t;

    .line 370
    .line 371
    iget-object v3, v11, Lbg/c;->i:Ljava/lang/Object;

    .line 372
    .line 373
    check-cast v3, Lq50/f;

    .line 374
    .line 375
    iget-object v4, v11, Lbg/c;->w:Ljava/lang/Object;

    .line 376
    .line 377
    check-cast v4, Ld20/n;

    .line 378
    .line 379
    instance-of v5, v1, Li60/i;

    .line 380
    .line 381
    if-eqz v5, :cond_181

    .line 382
    .line 383
    check-cast v1, Li60/i;

    .line 384
    .line 385
    goto :goto_182

    .line 386
    :cond_181
    move-object v1, v2

    .line 387
    :goto_182
    if-eqz v1, :cond_18c

    .line 388
    .line 389
    iget-object v1, v1, Li60/i;->W:Lg60/t;

    .line 390
    .line 391
    move-object v5, v1

    .line 392
    :goto_187
    move-object v2, v3

    .line 393
    move-object v3, v4

    .line 394
    move-object v1, v8

    .line 395
    move-object v4, v9

    .line 396
    goto :goto_18e

    .line 397
    :cond_18c
    move-object v5, v2

    .line 398
    goto :goto_187

    .line 399
    :goto_18e
    invoke-direct/range {v0 .. v5}, Lg60/t;-><init>(Lo50/k;Lq50/f;Ld20/n;Lq40/m0;Lg60/t;)V

    .line 400
    .line 401
    .line 402
    iput-object v0, v6, Li60/i;->W:Lg60/t;

    .line 403
    .line 404
    sget-object v0, Lq50/d;->c:Lq50/b;

    .line 405
    .line 406
    iget v1, v1, Lo50/k;->v:I

    .line 407
    .line 408
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 409
    .line 410
    .line 411
    move-result-object v0

    .line 412
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 413
    .line 414
    .line 415
    move-result v0

    .line 416
    if-nez v0, :cond_1a4

    .line 417
    .line 418
    sget-object v0, Lr40/g;->a:Lr40/f;

    .line 419
    .line 420
    goto :goto_1af

    .line 421
    :cond_1a4
    new-instance v0, Li60/v;

    .line 422
    .line 423
    new-instance v1, Li60/d;

    .line 424
    .line 425
    const/4 v2, 0x5

    .line 426
    invoke-direct {v1, v6, v2}, Li60/d;-><init>(Li60/i;I)V

    .line 427
    .line 428
    .line 429
    invoke-direct {v0, v13, v1}, Li60/v;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 430
    .line 431
    .line 432
    :goto_1af
    iput-object v0, v6, Li60/i;->X:Lr40/h;

    .line 433
    .line 434
    return-void

    .line 435
    :pswitch_data_1b2
    .packed-switch 0x1
        :pswitch_8d
        :pswitch_8a
        :pswitch_87
        :pswitch_84
        :pswitch_81
        :pswitch_7e
        :pswitch_7e
    .end packed-switch
.end method


# virtual methods
.method public final A()Lq40/k;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->S:Lq40/k;

    .line 2
    .line 3
    return-object v0
.end method

.method public final K0()Z
    .registers 3

    .line 1
    sget-object v0, Lq50/d;->j:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final L0()Z
    .registers 3

    .line 1
    sget-object v0, Lq50/d;->g:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final S0()Lt40/i;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->T:Lj60/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lt40/i;

    .line 8
    .line 9
    return-object v0
.end method

.method public final T0()Ld60/o;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->O:Ld60/p;

    .line 2
    .line 3
    return-object v0
.end method

.method public final U1()Lq40/r0;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->V:Lj60/h;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lq40/r0;

    .line 8
    .line 9
    return-object v0
.end method

.method public final a0()Ljava/util/List;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->N:Lbg/c;

    .line 2
    .line 3
    iget-object v0, v0, Lbg/c;->K:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lp/r3;

    .line 6
    .line 7
    iget-object v0, v0, Lp/r3;->J:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, Lm30/q;->S0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0
.end method

.method public final d(Ll60/f;)Ld60/o;
    .registers 4

    .line 1
    iget-object p1, p0, Li60/i;->Q:Lq40/l0;

    .line 2
    .line 3
    iget-object v0, p1, Lq40/l0;->a:Lt40/b;

    .line 4
    .line 5
    invoke-static {v0}, La60/e;->j(Lq40/k;)Lq40/y;

    .line 6
    .line 7
    .line 8
    iget-object p1, p1, Lq40/l0;->c:Lj60/i;

    .line 9
    .line 10
    sget-object v0, Lq40/l0;->e:[Lh40/t;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    aget-object v0, v0, v1

    .line 14
    .line 15
    invoke-static {p1, v0}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, Ld60/o;

    .line 20
    .line 21
    return-object p1
.end method

.method public final e2()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final getAnnotations()Lr40/h;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->X:Lr40/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getVisibility()Ld50/o;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->L:Ld50/o;

    .line 2
    .line 3
    return-object v0
.end method

.method public final i0()Lk60/l0;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->P:Lh50/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public final i2()Ljava/util/List;
    .registers 9

    .line 1
    iget-object v0, p0, Li60/i;->N:Lbg/c;

    .line 2
    .line 3
    iget-object v1, v0, Lbg/c;->w:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ld20/n;

    .line 6
    .line 7
    iget-object v2, p0, Li60/i;->w:Lo50/k;

    .line 8
    .line 9
    invoke-static {v2, v1}, Landroid/support/v4/media/session/b;->m(Lo50/k;Ld20/n;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    new-instance v2, Ljava/util/ArrayList;

    .line 14
    .line 15
    const/16 v3, 0xa

    .line 16
    .line 17
    invoke-static {v1, v3}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 22
    .line 23
    .line 24
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    :goto_1b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-eqz v3, :cond_44

    .line 33
    .line 34
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, Lo50/t0;

    .line 39
    .line 40
    iget-object v4, v0, Lbg/c;->K:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v4, Lp/r3;

    .line 43
    .line 44
    invoke-virtual {v4, v3}, Lp/r3;->s(Lo50/t0;)Lk60/w;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    new-instance v4, Lt40/u;

    .line 49
    .line 50
    invoke-virtual {p0}, Lt40/b;->r2()Lt40/u;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    new-instance v6, Le60/a;

    .line 55
    .line 56
    const/4 v7, 0x0

    .line 57
    invoke-direct {v6, p0, v3, v7}, Le60/a;-><init>(Lq40/e;Lk60/w;Lt50/e;)V

    .line 58
    .line 59
    .line 60
    sget-object v3, Lr40/g;->a:Lr40/f;

    .line 61
    .line 62
    invoke-direct {v4, v5, v6, v3}, Lt40/u;-><init>(Lq40/k;Lb3/l;Lr40/h;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    goto :goto_1b

    .line 69
    :cond_44
    return-object v2
.end method

.method public final isExternal()Z
    .registers 3

    .line 1
    sget-object v0, Lq50/d;->i:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final isInline()Z
    .registers 5

    .line 1
    sget-object v0, Lq50/d;->k:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_29

    .line 16
    .line 17
    iget-object v0, p0, Li60/i;->x:Lq50/a;

    .line 18
    .line 19
    iget v1, v0, Lq50/a;->b:I

    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    if-ge v1, v2, :cond_18

    .line 23
    .line 24
    goto :goto_28

    .line 25
    :cond_18
    if-le v1, v2, :cond_1b

    .line 26
    .line 27
    goto :goto_29

    .line 28
    :cond_1b
    iget v1, v0, Lq50/a;->c:I

    .line 29
    .line 30
    const/4 v3, 0x4

    .line 31
    if-ge v1, v3, :cond_21

    .line 32
    .line 33
    goto :goto_28

    .line 34
    :cond_21
    if-le v1, v3, :cond_24

    .line 35
    .line 36
    goto :goto_29

    .line 37
    :cond_24
    iget v0, v0, Lq50/a;->d:I

    .line 38
    .line 39
    if-gt v0, v2, :cond_29

    .line 40
    .line 41
    :goto_28
    return v2

    .line 42
    :cond_29
    :goto_29
    const/4 v0, 0x0

    .line 43
    return v0
.end method

.method public final j()Lq40/f;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->M:Lq40/f;

    .line 2
    .line 3
    return-object v0
.end method

.method public final k()Lq40/m0;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->y:Lq40/m0;

    .line 2
    .line 3
    return-object v0
.end method

.method public final l()Li60/h;
    .registers 4

    .line 1
    iget-object v0, p0, Li60/i;->N:Lbg/c;

    .line 2
    .line 3
    iget-object v0, v0, Lbg/c;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lg60/i;

    .line 6
    .line 7
    iget-object v0, v0, Lg60/i;->q:Ll60/k;

    .line 8
    .line 9
    check-cast v0, Ll60/l;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Li60/i;->Q:Lq40/l0;

    .line 15
    .line 16
    iget-object v1, v0, Lq40/l0;->a:Lt40/b;

    .line 17
    .line 18
    invoke-static {v1}, La60/e;->j(Lq40/k;)Lq40/y;

    .line 19
    .line 20
    .line 21
    iget-object v0, v0, Lq40/l0;->c:Lj60/i;

    .line 22
    .line 23
    sget-object v1, Lq40/l0;->e:[Lh40/t;

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    aget-object v1, v1, v2

    .line 27
    .line 28
    invoke-static {v0, v1}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Ld60/o;

    .line 33
    .line 34
    check-cast v0, Li60/h;

    .line 35
    .line 36
    return-object v0
.end method

.method public final l0()Z
    .registers 3

    .line 1
    sget-object v0, Lq50/d;->f:Lq50/c;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/c;->c(I)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Lo50/j;->x:Lo50/j;

    .line 12
    .line 13
    if-ne v0, v1, :cond_10

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    return v0

    .line 17
    :cond_10
    const/4 v0, 0x0

    .line 18
    return v0
.end method

.method public final m(Lt50/e;)Lk60/a0;
    .registers 7

    .line 1
    invoke-virtual {p0}, Li60/i;->l()Li60/h;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Ly40/c;->y:Ly40/c;

    .line 6
    .line 7
    invoke-virtual {v0, p1, v1}, Li60/h;->a(Lt50/e;Ly40/c;)Ljava/util/Collection;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const/4 v0, 0x0

    .line 16
    const/4 v1, 0x0

    .line 17
    move-object v2, v0

    .line 18
    :cond_11
    :goto_11
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    if-eqz v3, :cond_2b

    .line 23
    .line 24
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    move-object v4, v3

    .line 29
    check-cast v4, Lq40/k0;

    .line 30
    .line 31
    invoke-interface {v4}, Lq40/b;->v1()Lt40/u;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    if-nez v4, :cond_11

    .line 36
    .line 37
    if-eqz v1, :cond_28

    .line 38
    .line 39
    :goto_26
    move-object v2, v0

    .line 40
    goto :goto_2e

    .line 41
    :cond_28
    const/4 v1, 0x1

    .line 42
    move-object v2, v3

    .line 43
    goto :goto_11

    .line 44
    :cond_2b
    if-nez v1, :cond_2e

    .line 45
    .line 46
    goto :goto_26

    .line 47
    :cond_2e
    :goto_2e
    check-cast v2, Lq40/k0;

    .line 48
    .line 49
    if-eqz v2, :cond_36

    .line 50
    .line 51
    invoke-interface {v2}, Lq40/s0;->getType()Lk60/w;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    :cond_36
    check-cast v0, Lk60/a0;

    .line 56
    .line 57
    return-object v0
.end method

.method public final n0()Ljava/util/Collection;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->U:Lj60/i;

    .line 2
    .line 3
    invoke-virtual {v0}, Lj60/i;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/util/Collection;

    .line 8
    .line 9
    return-object v0
.end method

.method public final o2()Z
    .registers 3

    .line 1
    sget-object v0, Lq50/d;->h:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final p()Lq40/x;
    .registers 2

    .line 1
    iget-object v0, p0, Li60/i;->K:Lq40/x;

    .line 2
    .line 3
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "deserialized "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Li60/i;->K0()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_10

    .line 13
    .line 14
    const-string v1, "expect "

    .line 15
    .line 16
    goto :goto_12

    .line 17
    :cond_10
    const-string v1, ""

    .line 18
    .line 19
    :goto_12
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    const-string v1, "class "

    .line 23
    .line 24
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, Lt40/b;->getName()Lt50/e;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0
.end method

.method public final u0()Z
    .registers 3

    .line 1
    sget-object v0, Lq50/d;->l:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final w()Z
    .registers 5

    .line 1
    sget-object v0, Lq50/d;->k:Lq50/b;

    .line 2
    .line 3
    iget-object v1, p0, Li60/i;->w:Lo50/k;

    .line 4
    .line 5
    iget v1, v1, Lo50/k;->v:I

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lq50/b;->h(I)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1c

    .line 16
    .line 17
    const/4 v0, 0x4

    .line 18
    const/4 v1, 0x2

    .line 19
    iget-object v2, p0, Li60/i;->x:Lq50/a;

    .line 20
    .line 21
    const/4 v3, 0x1

    .line 22
    invoke-virtual {v2, v3, v0, v1}, Lq50/a;->a(III)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1c

    .line 27
    .line 28
    return v3

    .line 29
    :cond_1c
    const/4 v0, 0x0

    .line 30
    return v0
.end method
