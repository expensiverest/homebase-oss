###### Class i60.l (i60.l)
.class public interface abstract Li60/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq40/k;
.implements Lq40/w;


# virtual methods
.method public abstract U0()Ld20/n;
.end method

.method public abstract d1()Lq50/f;
.end method

.method public abstract h1()Li60/k;
.end method

.method public abstract v0()Lu50/a;
.end method
