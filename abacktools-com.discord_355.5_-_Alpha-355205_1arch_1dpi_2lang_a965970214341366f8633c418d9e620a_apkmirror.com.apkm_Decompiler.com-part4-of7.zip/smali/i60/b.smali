###### Class i60.b (i60.b)
.class public interface abstract Li60/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq40/c;
.implements Li60/l;
