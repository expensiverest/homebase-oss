###### Class i60.v (i60.v)
.class public final Li60/v;
.super Li60/a;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V
    .registers 4

    .line 1
    const-string v0, "storageManager"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p1, p2}, Li60/a;-><init>(Lj60/o;Lkotlin/jvm/functions/Function0;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final isEmpty()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method
