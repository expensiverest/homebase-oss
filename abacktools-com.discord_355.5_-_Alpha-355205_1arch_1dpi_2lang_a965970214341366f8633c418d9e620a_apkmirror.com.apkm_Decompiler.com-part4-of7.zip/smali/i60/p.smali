###### Class i60.p (i60.p)
.class public abstract Li60/p;
.super Ld60/p;
.source "SourceFile"


# static fields
.field public static final synthetic f:[Lh40/t;


# instance fields
.field public final b:Lbg/c;

.field public final c:Li60/o;

.field public final d:Lj60/i;

.field public final e:Lj60/h;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Lkotlin/jvm/internal/o;

    .line 2
    .line 3
    const-class v1, Li60/p;

    .line 4
    .line 5
    const-string v2, "classNames"

    .line 6
    .line 7
    const-string v3, "getClassNames$deserialization()Ljava/util/Set;"

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    invoke-direct {v0, v1, v2, v3, v4}, Lkotlin/jvm/internal/o;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    sget-object v2, Lkotlin/jvm/internal/v;->a:Lkotlin/jvm/internal/w;

    .line 14
    .line 15
    invoke-virtual {v2, v0}, Lkotlin/jvm/internal/w;->f(Lkotlin/jvm/internal/o;)Lh40/s;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const-string v3, "classifierNamesLazy"

    .line 20
    .line 21
    const-string v5, "getClassifierNamesLazy()Ljava/util/Set;"

    .line 22
    .line 23
    invoke-static {v1, v3, v5, v4, v2}, Lhs/q;->f(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/w;)Lh40/s;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const/4 v2, 0x2

    .line 28
    new-array v2, v2, [Lh40/t;

    .line 29
    .line 30
    aput-object v0, v2, v4

    .line 31
    .line 32
    const/4 v0, 0x1

    .line 33
    aput-object v1, v2, v0

    .line 34
    .line 35
    sput-object v2, Li60/p;->f:[Lh40/t;

    .line 36
    .line 37
    return-void
.end method

.method public constructor <init>(Lbg/c;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lkotlin/jvm/functions/Function0;)V
    .registers 7

    .line 1
    const-string v0, "c"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "functionList"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "propertyList"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "typeAliasList"

    .line 17
    .line 18
    invoke-static {p4, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Li60/p;->b:Lbg/c;

    .line 25
    .line 26
    iget-object p1, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Lg60/i;

    .line 29
    .line 30
    iget-object v0, p1, Lg60/i;->c:Lg60/j;

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    new-instance v0, Li60/o;

    .line 36
    .line 37
    invoke-direct {v0, p0, p2, p3, p4}, Li60/o;-><init>(Li60/p;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, Li60/p;->c:Li60/o;

    .line 41
    .line 42
    iget-object p1, p1, Lg60/i;->a:Lj60/l;

    .line 43
    .line 44
    new-instance p2, Ld60/j;

    .line 45
    .line 46
    const/4 p3, 0x2

    .line 47
    invoke-direct {p2, p5, p3}, Ld60/j;-><init>(Lkotlin/jvm/functions/Function0;I)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    new-instance p3, Lj60/i;

    .line 54
    .line 55
    invoke-direct {p3, p1, p2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 56
    .line 57
    .line 58
    iput-object p3, p0, Li60/p;->d:Lj60/i;

    .line 59
    .line 60
    new-instance p2, Lbg/w;

    .line 61
    .line 62
    const/16 p3, 0xa

    .line 63
    .line 64
    invoke-direct {p2, p3, p0}, Lbg/w;-><init>(ILjava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    new-instance p3, Lj60/h;

    .line 71
    .line 72
    invoke-direct {p3, p1, p2}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 73
    .line 74
    .line 75
    iput-object p3, p0, Li60/p;->e:Lj60/h;

    .line 76
    .line 77
    return-void
.end method


# virtual methods
.method public a(Lt50/e;Ly40/c;)Ljava/util/Collection;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li60/p;->c:Li60/o;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, Li60/o;->b(Lt50/e;Ly40/a;)Ljava/util/Collection;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public final b()Ljava/util/Set;
    .registers 4

    .line 1
    iget-object v0, p0, Li60/p;->c:Li60/o;

    .line 2
    .line 3
    iget-object v0, v0, Li60/o;->g:Lj60/i;

    .line 4
    .line 5
    sget-object v1, Li60/o;->j:[Lh40/t;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    aget-object v1, v1, v2

    .line 9
    .line 10
    invoke-static {v0, v1}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Ljava/util/Set;

    .line 15
    .line 16
    return-object v0
.end method

.method public final c()Ljava/util/Set;
    .registers 4

    .line 1
    sget-object v0, Li60/p;->f:[Lh40/t;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    const-string v1, "<this>"

    .line 7
    .line 8
    iget-object v2, p0, Li60/p;->e:Lj60/h;

    .line 9
    .line 10
    invoke-static {v2, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "p"

    .line 14
    .line 15
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v2}, Lj60/h;->invoke()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Ljava/util/Set;

    .line 23
    .line 24
    return-object v0
.end method

.method public e(Lt50/e;Ly40/a;)Ljava/util/Collection;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li60/p;->c:Li60/o;

    .line 7
    .line 8
    invoke-virtual {v0, p1, p2}, Li60/o;->a(Lt50/e;Ly40/a;)Ljava/util/Collection;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public final f()Ljava/util/Set;
    .registers 4

    .line 1
    iget-object v0, p0, Li60/p;->c:Li60/o;

    .line 2
    .line 3
    iget-object v0, v0, Li60/o;->h:Lj60/i;

    .line 4
    .line 5
    sget-object v1, Li60/o;->j:[Lh40/t;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    aget-object v1, v1, v2

    .line 9
    .line 10
    invoke-static {v0, v1}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Ljava/util/Set;

    .line 15
    .line 16
    return-object v0
.end method

.method public g(Lt50/e;Ly40/a;)Lq40/h;
    .registers 4

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "location"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1}, Li60/p;->q(Lt50/e;)Z

    .line 12
    .line 13
    .line 14
    move-result p2

    .line 15
    if-eqz p2, :cond_1f

    .line 16
    .line 17
    iget-object p2, p0, Li60/p;->b:Lbg/c;

    .line 18
    .line 19
    iget-object p2, p2, Lbg/c;->e:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p2, Lg60/i;

    .line 22
    .line 23
    invoke-virtual {p0, p1}, Li60/p;->l(Lt50/e;)Lt50/b;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-virtual {p2, p1}, Lg60/i;->b(Lt50/b;)Lq40/e;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    return-object p1

    .line 32
    :cond_1f
    iget-object p2, p0, Li60/p;->c:Li60/o;

    .line 33
    .line 34
    iget-object v0, p2, Li60/o;->c:Ljava/util/LinkedHashMap;

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_39

    .line 45
    .line 46
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    iget-object p2, p2, Li60/o;->f:Lj60/j;

    .line 50
    .line 51
    invoke-virtual {p2, p1}, Lj60/j;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Lq40/p0;

    .line 56
    .line 57
    return-object p1

    .line 58
    :cond_39
    const/4 p1, 0x0

    .line 59
    return-object p1
.end method

.method public abstract h(Ljava/util/ArrayList;Lkotlin/jvm/functions/Function1;)V
.end method

.method public final i(Ld60/f;Lkotlin/jvm/functions/Function1;)Ljava/util/List;
    .registers 12

    .line 1
    sget-object v0, Ly40/c;->v:Ly40/c;

    .line 2
    .line 3
    const-string v1, "kindFilter"

    .line 4
    .line 5
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Ljava/util/ArrayList;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 12
    .line 13
    .line 14
    sget v3, Ld60/f;->f:I

    .line 15
    .line 16
    invoke-virtual {p1, v3}, Ld60/f;->a(I)Z

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-eqz v3, :cond_18

    .line 21
    .line 22
    invoke-virtual {p0, v1, p2}, Li60/p;->h(Ljava/util/ArrayList;Lkotlin/jvm/functions/Function1;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    iget-object v3, p0, Li60/p;->c:Li60/o;

    .line 26
    .line 27
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    sget v4, Ld60/f;->j:I

    .line 31
    .line 32
    invoke-virtual {p1, v4}, Ld60/f;->a(I)Z

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    sget-object v5, Lw50/h;->e:Lw50/h;

    .line 37
    .line 38
    if-eqz v4, :cond_63

    .line 39
    .line 40
    iget-object v4, v3, Li60/o;->h:Lj60/i;

    .line 41
    .line 42
    sget-object v6, Li60/o;->j:[Lh40/t;

    .line 43
    .line 44
    const/4 v7, 0x1

    .line 45
    aget-object v6, v6, v7

    .line 46
    .line 47
    invoke-static {v4, v6}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Ljava/util/Set;

    .line 52
    .line 53
    new-instance v6, Ljava/util/ArrayList;

    .line 54
    .line 55
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 56
    .line 57
    .line 58
    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    :cond_3d
    :goto_3d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 63
    .line 64
    .line 65
    move-result v7

    .line 66
    if-eqz v7, :cond_5d

    .line 67
    .line 68
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    check-cast v7, Lt50/e;

    .line 73
    .line 74
    invoke-interface {p2, v7}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v8

    .line 78
    check-cast v8, Ljava/lang/Boolean;

    .line 79
    .line 80
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 81
    .line 82
    .line 83
    move-result v8

    .line 84
    if-eqz v8, :cond_3d

    .line 85
    .line 86
    invoke-virtual {v3, v7, v0}, Li60/o;->b(Lt50/e;Ly40/a;)Ljava/util/Collection;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 91
    .line 92
    .line 93
    goto :goto_3d

    .line 94
    :cond_5d
    invoke-static {v5, v6}, Lm30/o;->Y(Ljava/util/Comparator;Ljava/util/List;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 98
    .line 99
    .line 100
    :cond_63
    sget v4, Ld60/f;->i:I

    .line 101
    .line 102
    invoke-virtual {p1, v4}, Ld60/f;->a(I)Z

    .line 103
    .line 104
    .line 105
    move-result v4

    .line 106
    if-eqz v4, :cond_a6

    .line 107
    .line 108
    iget-object v4, v3, Li60/o;->g:Lj60/i;

    .line 109
    .line 110
    sget-object v6, Li60/o;->j:[Lh40/t;

    .line 111
    .line 112
    aget-object v2, v6, v2

    .line 113
    .line 114
    invoke-static {v4, v2}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    check-cast v2, Ljava/util/Set;

    .line 119
    .line 120
    new-instance v4, Ljava/util/ArrayList;

    .line 121
    .line 122
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 123
    .line 124
    .line 125
    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    :cond_80
    :goto_80
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 130
    .line 131
    .line 132
    move-result v6

    .line 133
    if-eqz v6, :cond_a0

    .line 134
    .line 135
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v6

    .line 139
    check-cast v6, Lt50/e;

    .line 140
    .line 141
    invoke-interface {p2, v6}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v7

    .line 145
    check-cast v7, Ljava/lang/Boolean;

    .line 146
    .line 147
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 148
    .line 149
    .line 150
    move-result v7

    .line 151
    if-eqz v7, :cond_80

    .line 152
    .line 153
    invoke-virtual {v3, v6, v0}, Li60/o;->a(Lt50/e;Ly40/a;)Ljava/util/Collection;

    .line 154
    .line 155
    .line 156
    move-result-object v6

    .line 157
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 158
    .line 159
    .line 160
    goto :goto_80

    .line 161
    :cond_a0
    invoke-static {v5, v4}, Lm30/o;->Y(Ljava/util/Comparator;Ljava/util/List;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 165
    .line 166
    .line 167
    :cond_a6
    sget v0, Ld60/f;->l:I

    .line 168
    .line 169
    invoke-virtual {p1, v0}, Ld60/f;->a(I)Z

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    if-eqz v0, :cond_e0

    .line 174
    .line 175
    invoke-virtual {p0}, Li60/p;->m()Ljava/util/Set;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    :cond_b6
    :goto_b6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 184
    .line 185
    .line 186
    move-result v2

    .line 187
    if-eqz v2, :cond_e0

    .line 188
    .line 189
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v2

    .line 193
    check-cast v2, Lt50/e;

    .line 194
    .line 195
    invoke-interface {p2, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v4

    .line 199
    check-cast v4, Ljava/lang/Boolean;

    .line 200
    .line 201
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    if-eqz v4, :cond_b6

    .line 206
    .line 207
    iget-object v4, p0, Li60/p;->b:Lbg/c;

    .line 208
    .line 209
    iget-object v4, v4, Lbg/c;->e:Ljava/lang/Object;

    .line 210
    .line 211
    check-cast v4, Lg60/i;

    .line 212
    .line 213
    invoke-virtual {p0, v2}, Li60/p;->l(Lt50/e;)Lt50/b;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    invoke-virtual {v4, v2}, Lg60/i;->b(Lt50/b;)Lq40/e;

    .line 218
    .line 219
    .line 220
    move-result-object v2

    .line 221
    invoke-static {v1, v2}, Lt60/l;->a(Ljava/util/AbstractCollection;Ljava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    goto :goto_b6

    .line 225
    :cond_e0
    sget v0, Ld60/f;->g:I

    .line 226
    .line 227
    invoke-virtual {p1, v0}, Ld60/f;->a(I)Z

    .line 228
    .line 229
    .line 230
    move-result p1

    .line 231
    if-eqz p1, :cond_11e

    .line 232
    .line 233
    iget-object p1, v3, Li60/o;->c:Ljava/util/LinkedHashMap;

    .line 234
    .line 235
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 236
    .line 237
    .line 238
    move-result-object p1

    .line 239
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 240
    .line 241
    .line 242
    move-result-object p1

    .line 243
    :cond_f2
    :goto_f2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 244
    .line 245
    .line 246
    move-result v0

    .line 247
    if-eqz v0, :cond_11e

    .line 248
    .line 249
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    check-cast v0, Lt50/e;

    .line 254
    .line 255
    invoke-interface {p2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    move-result-object v2

    .line 259
    check-cast v2, Ljava/lang/Boolean;

    .line 260
    .line 261
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 262
    .line 263
    .line 264
    move-result v2

    .line 265
    if-eqz v2, :cond_f2

    .line 266
    .line 267
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 268
    .line 269
    .line 270
    const-string v2, "name"

    .line 271
    .line 272
    invoke-static {v0, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    iget-object v2, v3, Li60/o;->f:Lj60/j;

    .line 276
    .line 277
    invoke-virtual {v2, v0}, Lj60/j;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    check-cast v0, Lq40/p0;

    .line 282
    .line 283
    invoke-static {v1, v0}, Lt60/l;->a(Ljava/util/AbstractCollection;Ljava/lang/Object;)V

    .line 284
    .line 285
    .line 286
    goto :goto_f2

    .line 287
    :cond_11e
    invoke-static {v1}, Lt60/l;->d(Ljava/util/ArrayList;)Ljava/util/List;

    .line 288
    .line 289
    .line 290
    move-result-object p1

    .line 291
    return-object p1
.end method

.method public j(Ljava/util/ArrayList;Lt50/e;)V
    .registers 3

    .line 1
    const-string p1, "name"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public k(Ljava/util/ArrayList;Lt50/e;)V
    .registers 3

    .line 1
    const-string p1, "name"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public abstract l(Lt50/e;)Lt50/b;
.end method

.method public final m()Ljava/util/Set;
    .registers 3

    .line 1
    sget-object v0, Li60/p;->f:[Lh40/t;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    iget-object v1, p0, Li60/p;->d:Lj60/i;

    .line 7
    .line 8
    invoke-static {v1, v0}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/util/Set;

    .line 13
    .line 14
    return-object v0
.end method

.method public abstract n()Ljava/util/Set;
.end method

.method public abstract o()Ljava/util/Set;
.end method

.method public abstract p()Ljava/util/Set;
.end method

.method public q(Lt50/e;)Z
    .registers 3

    .line 1
    const-string v0, "name"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Li60/p;->m()Ljava/util/Set;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    return p1
.end method

.method public r(Li60/s;)Z
    .registers 2

    .line 1
    const/4 p1, 0x1

    .line 2
    return p1
.end method
