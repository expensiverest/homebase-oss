###### Class i60.o (i60.o)
.class public final Li60/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic j:[Lh40/t;


# instance fields
.field public final a:Ljava/util/LinkedHashMap;

.field public final b:Ljava/util/LinkedHashMap;

.field public final c:Ljava/util/LinkedHashMap;

.field public final d:Lj60/e;

.field public final e:Lj60/e;

.field public final f:Lj60/j;

.field public final g:Lj60/i;

.field public final h:Lj60/i;

.field public final synthetic i:Li60/p;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Lkotlin/jvm/internal/o;

    .line 2
    .line 3
    const-class v1, Li60/o;

    .line 4
    .line 5
    const-string v2, "functionNames"

    .line 6
    .line 7
    const-string v3, "getFunctionNames()Ljava/util/Set;"

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    invoke-direct {v0, v1, v2, v3, v4}, Lkotlin/jvm/internal/o;-><init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 11
    .line 12
    .line 13
    sget-object v2, Lkotlin/jvm/internal/v;->a:Lkotlin/jvm/internal/w;

    .line 14
    .line 15
    invoke-virtual {v2, v0}, Lkotlin/jvm/internal/w;->f(Lkotlin/jvm/internal/o;)Lh40/s;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const-string v3, "variableNames"

    .line 20
    .line 21
    const-string v5, "getVariableNames()Ljava/util/Set;"

    .line 22
    .line 23
    invoke-static {v1, v3, v5, v4, v2}, Lhs/q;->f(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/w;)Lh40/s;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const/4 v2, 0x2

    .line 28
    new-array v2, v2, [Lh40/t;

    .line 29
    .line 30
    aput-object v0, v2, v4

    .line 31
    .line 32
    const/4 v0, 0x1

    .line 33
    aput-object v1, v2, v0

    .line 34
    .line 35
    sput-object v2, Li60/o;->j:[Lh40/t;

    .line 36
    .line 37
    return-void
.end method

.method public constructor <init>(Li60/p;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "functionList"

    .line 5
    .line 6
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    const-string v0, "propertyList"

    .line 10
    .line 11
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v0, "typeAliasList"

    .line 15
    .line 16
    invoke-static {p4, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Li60/o;->i:Li60/p;

    .line 20
    .line 21
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 22
    .line 23
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 24
    .line 25
    .line 26
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    :goto_1d
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-eqz v1, :cond_4c

    .line 35
    .line 36
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    move-object v2, v1

    .line 41
    check-cast v2, Lu50/a;

    .line 42
    .line 43
    iget-object v3, p1, Li60/p;->b:Lbg/c;

    .line 44
    .line 45
    iget-object v3, v3, Lbg/c;->i:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v3, Lq50/f;

    .line 48
    .line 49
    check-cast v2, Lo50/b0;

    .line 50
    .line 51
    iget v2, v2, Lo50/b0;->x:I

    .line 52
    .line 53
    invoke-static {v3, v2}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    if-nez v3, :cond_46

    .line 62
    .line 63
    new-instance v3, Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 66
    .line 67
    .line 68
    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    :cond_46
    check-cast v3, Ljava/util/List;

    .line 72
    .line 73
    invoke-interface {v3, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    goto :goto_1d

    .line 77
    :cond_4c
    invoke-static {v0}, Li60/o;->c(Ljava/util/LinkedHashMap;)Ljava/util/LinkedHashMap;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    iput-object p1, p0, Li60/o;->a:Ljava/util/LinkedHashMap;

    .line 82
    .line 83
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 84
    .line 85
    new-instance p2, Ljava/util/LinkedHashMap;

    .line 86
    .line 87
    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 88
    .line 89
    .line 90
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 91
    .line 92
    .line 93
    move-result-object p3

    .line 94
    :goto_5d
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    if-eqz v0, :cond_8c

    .line 99
    .line 100
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    move-object v1, v0

    .line 105
    check-cast v1, Lu50/a;

    .line 106
    .line 107
    iget-object v2, p1, Li60/p;->b:Lbg/c;

    .line 108
    .line 109
    iget-object v2, v2, Lbg/c;->i:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast v2, Lq50/f;

    .line 112
    .line 113
    check-cast v1, Lo50/j0;

    .line 114
    .line 115
    iget v1, v1, Lo50/j0;->x:I

    .line 116
    .line 117
    invoke-static {v2, v1}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    invoke-virtual {p2, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    if-nez v2, :cond_86

    .line 126
    .line 127
    new-instance v2, Ljava/util/ArrayList;

    .line 128
    .line 129
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 130
    .line 131
    .line 132
    invoke-interface {p2, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    :cond_86
    check-cast v2, Ljava/util/List;

    .line 136
    .line 137
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    goto :goto_5d

    .line 141
    :cond_8c
    invoke-static {p2}, Li60/o;->c(Ljava/util/LinkedHashMap;)Ljava/util/LinkedHashMap;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    iput-object p1, p0, Li60/o;->b:Ljava/util/LinkedHashMap;

    .line 146
    .line 147
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 148
    .line 149
    iget-object p1, p1, Li60/p;->b:Lbg/c;

    .line 150
    .line 151
    iget-object p1, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast p1, Lg60/i;

    .line 154
    .line 155
    iget-object p1, p1, Lg60/i;->c:Lg60/j;

    .line 156
    .line 157
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 158
    .line 159
    .line 160
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 161
    .line 162
    new-instance p2, Ljava/util/LinkedHashMap;

    .line 163
    .line 164
    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 165
    .line 166
    .line 167
    invoke-interface {p4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 168
    .line 169
    .line 170
    move-result-object p3

    .line 171
    :goto_aa
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 172
    .line 173
    .line 174
    move-result p4

    .line 175
    if-eqz p4, :cond_d9

    .line 176
    .line 177
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object p4

    .line 181
    move-object v0, p4

    .line 182
    check-cast v0, Lu50/a;

    .line 183
    .line 184
    iget-object v1, p1, Li60/p;->b:Lbg/c;

    .line 185
    .line 186
    iget-object v1, v1, Lbg/c;->i:Ljava/lang/Object;

    .line 187
    .line 188
    check-cast v1, Lq50/f;

    .line 189
    .line 190
    check-cast v0, Lo50/v0;

    .line 191
    .line 192
    iget v0, v0, Lo50/v0;->w:I

    .line 193
    .line 194
    invoke-static {v1, v0}, Lul/b;->w(Lq50/f;I)Lt50/e;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    invoke-virtual {p2, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    if-nez v1, :cond_d3

    .line 203
    .line 204
    new-instance v1, Ljava/util/ArrayList;

    .line 205
    .line 206
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 207
    .line 208
    .line 209
    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    :cond_d3
    check-cast v1, Ljava/util/List;

    .line 213
    .line 214
    invoke-interface {v1, p4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    goto :goto_aa

    .line 218
    :cond_d9
    invoke-static {p2}, Li60/o;->c(Ljava/util/LinkedHashMap;)Ljava/util/LinkedHashMap;

    .line 219
    .line 220
    .line 221
    move-result-object p1

    .line 222
    iput-object p1, p0, Li60/o;->c:Ljava/util/LinkedHashMap;

    .line 223
    .line 224
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 225
    .line 226
    iget-object p1, p1, Li60/p;->b:Lbg/c;

    .line 227
    .line 228
    iget-object p1, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast p1, Lg60/i;

    .line 231
    .line 232
    iget-object p1, p1, Lg60/i;->a:Lj60/l;

    .line 233
    .line 234
    new-instance p2, Li60/m;

    .line 235
    .line 236
    const/4 p3, 0x0

    .line 237
    invoke-direct {p2, p0, p3}, Li60/m;-><init>(Li60/o;I)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {p1, p2}, Lj60/l;->b(Lkotlin/jvm/functions/Function1;)Lj60/e;

    .line 241
    .line 242
    .line 243
    move-result-object p1

    .line 244
    iput-object p1, p0, Li60/o;->d:Lj60/e;

    .line 245
    .line 246
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 247
    .line 248
    iget-object p1, p1, Li60/p;->b:Lbg/c;

    .line 249
    .line 250
    iget-object p1, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast p1, Lg60/i;

    .line 253
    .line 254
    iget-object p1, p1, Lg60/i;->a:Lj60/l;

    .line 255
    .line 256
    new-instance p2, Li60/m;

    .line 257
    .line 258
    const/4 p3, 0x1

    .line 259
    invoke-direct {p2, p0, p3}, Li60/m;-><init>(Li60/o;I)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {p1, p2}, Lj60/l;->b(Lkotlin/jvm/functions/Function1;)Lj60/e;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    iput-object p1, p0, Li60/o;->e:Lj60/e;

    .line 267
    .line 268
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 269
    .line 270
    iget-object p1, p1, Li60/p;->b:Lbg/c;

    .line 271
    .line 272
    iget-object p1, p1, Lbg/c;->e:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast p1, Lg60/i;

    .line 275
    .line 276
    iget-object p1, p1, Lg60/i;->a:Lj60/l;

    .line 277
    .line 278
    new-instance p2, Li60/m;

    .line 279
    .line 280
    const/4 p3, 0x2

    .line 281
    invoke-direct {p2, p0, p3}, Li60/m;-><init>(Li60/o;I)V

    .line 282
    .line 283
    .line 284
    invoke-virtual {p1, p2}, Lj60/l;->c(Lkotlin/jvm/functions/Function1;)Lj60/j;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    iput-object p1, p0, Li60/o;->f:Lj60/j;

    .line 289
    .line 290
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 291
    .line 292
    iget-object p2, p1, Li60/p;->b:Lbg/c;

    .line 293
    .line 294
    iget-object p2, p2, Lbg/c;->e:Ljava/lang/Object;

    .line 295
    .line 296
    check-cast p2, Lg60/i;

    .line 297
    .line 298
    iget-object p2, p2, Lg60/i;->a:Lj60/l;

    .line 299
    .line 300
    new-instance p3, Li60/n;

    .line 301
    .line 302
    const/4 p4, 0x0

    .line 303
    invoke-direct {p3, p0, p1, p4}, Li60/n;-><init>(Li60/o;Li60/p;I)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 307
    .line 308
    .line 309
    new-instance p1, Lj60/i;

    .line 310
    .line 311
    invoke-direct {p1, p2, p3}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 312
    .line 313
    .line 314
    iput-object p1, p0, Li60/o;->g:Lj60/i;

    .line 315
    .line 316
    iget-object p1, p0, Li60/o;->i:Li60/p;

    .line 317
    .line 318
    iget-object p2, p1, Li60/p;->b:Lbg/c;

    .line 319
    .line 320
    iget-object p2, p2, Lbg/c;->e:Ljava/lang/Object;

    .line 321
    .line 322
    check-cast p2, Lg60/i;

    .line 323
    .line 324
    iget-object p2, p2, Lg60/i;->a:Lj60/l;

    .line 325
    .line 326
    new-instance p3, Li60/n;

    .line 327
    .line 328
    const/4 p4, 0x1

    .line 329
    invoke-direct {p3, p0, p1, p4}, Li60/n;-><init>(Li60/o;Li60/p;I)V

    .line 330
    .line 331
    .line 332
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 333
    .line 334
    .line 335
    new-instance p1, Lj60/i;

    .line 336
    .line 337
    invoke-direct {p1, p2, p3}, Lj60/h;-><init>(Lj60/l;Lkotlin/jvm/functions/Function0;)V

    .line 338
    .line 339
    .line 340
    iput-object p1, p0, Li60/o;->h:Lj60/i;

    .line 341
    .line 342
    return-void
.end method

.method public static c(Ljava/util/LinkedHashMap;)Ljava/util/LinkedHashMap;
    .registers 10

    .line 1
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 2
    .line 3
    invoke-interface {p0}, Ljava/util/Map;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-static {v1}, Lm30/x;->p0(I)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    :goto_15
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_74

    .line 27
    .line 28
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Ljava/util/Map$Entry;

    .line 33
    .line 34
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    .line 39
    .line 40
    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 41
    .line 42
    .line 43
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    check-cast v1, Ljava/lang/Iterable;

    .line 48
    .line 49
    new-instance v4, Ljava/util/ArrayList;

    .line 50
    .line 51
    const/16 v5, 0xa

    .line 52
    .line 53
    invoke-static {v1, v5}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 54
    .line 55
    .line 56
    move-result v5

    .line 57
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 58
    .line 59
    .line 60
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    :goto_3f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    if-eqz v5, :cond_6c

    .line 69
    .line 70
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    check-cast v5, Lu50/a;

    .line 75
    .line 76
    invoke-virtual {v5}, Lu50/a;->a()I

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    invoke-static {v6}, Lcom/google/android/gms/internal/play_billing/s1;->g(I)I

    .line 81
    .line 82
    .line 83
    move-result v7

    .line 84
    add-int/2addr v7, v6

    .line 85
    const/16 v8, 0x1000

    .line 86
    .line 87
    if-le v7, v8, :cond_59

    .line 88
    .line 89
    move v7, v8

    .line 90
    :cond_59
    invoke-static {v3, v7}, Lcom/google/android/gms/internal/play_billing/s1;->l(Ljava/io/OutputStream;I)Lcom/google/android/gms/internal/play_billing/s1;

    .line 91
    .line 92
    .line 93
    move-result-object v7

    .line 94
    invoke-virtual {v7, v6}, Lcom/google/android/gms/internal/play_billing/s1;->y(I)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v5, v7}, Lu50/a;->d(Lcom/google/android/gms/internal/play_billing/s1;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v7}, Lcom/google/android/gms/internal/play_billing/s1;->j()V

    .line 101
    .line 102
    .line 103
    sget-object v5, Ll30/a0;->a:Ll30/a0;

    .line 104
    .line 105
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    goto :goto_3f

    .line 109
    :cond_6c
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    goto :goto_15

    .line 117
    :cond_74
    return-object v0
.end method


# virtual methods
.method public final a(Lt50/e;Ly40/a;)Ljava/util/Collection;
    .registers 4

    .line 1
    const-string p2, "name"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object p2, Li60/o;->j:[Lh40/t;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    aget-object p2, p2, v0

    .line 10
    .line 11
    iget-object v0, p0, Li60/o;->g:Lj60/i;

    .line 12
    .line 13
    invoke-static {v0, p2}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    check-cast p2, Ljava/util/Set;

    .line 18
    .line 19
    invoke-interface {p2, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    if-nez p2, :cond_1b

    .line 24
    .line 25
    sget-object p1, Lm30/s;->d:Lm30/s;

    .line 26
    .line 27
    return-object p1

    .line 28
    :cond_1b
    iget-object p2, p0, Li60/o;->d:Lj60/e;

    .line 29
    .line 30
    invoke-virtual {p2, p1}, Lj60/e;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    check-cast p1, Ljava/util/Collection;

    .line 35
    .line 36
    return-object p1
.end method

.method public final b(Lt50/e;Ly40/a;)Ljava/util/Collection;
    .registers 4

    .line 1
    const-string p2, "name"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object p2, Li60/o;->j:[Lh40/t;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    aget-object p2, p2, v0

    .line 10
    .line 11
    iget-object v0, p0, Li60/o;->h:Lj60/i;

    .line 12
    .line 13
    invoke-static {v0, p2}, Lh40/f0;->u(Lj60/m;Lh40/t;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    check-cast p2, Ljava/util/Set;

    .line 18
    .line 19
    invoke-interface {p2, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    if-nez p2, :cond_1b

    .line 24
    .line 25
    sget-object p1, Lm30/s;->d:Lm30/s;

    .line 26
    .line 27
    return-object p1

    .line 28
    :cond_1b
    iget-object p2, p0, Li60/o;->e:Lj60/e;

    .line 29
    .line 30
    invoke-virtual {p2, p1}, Lj60/e;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    check-cast p1, Ljava/util/Collection;

    .line 35
    .line 36
    return-object p1
.end method
