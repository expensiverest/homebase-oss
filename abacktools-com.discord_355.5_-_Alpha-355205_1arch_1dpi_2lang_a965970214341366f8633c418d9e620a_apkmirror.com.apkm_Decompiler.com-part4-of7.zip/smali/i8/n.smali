###### Class i8.n (i8.n)
.class public interface abstract Li8/n;
.super Ljava/lang/Object;
.source "SourceFile"
