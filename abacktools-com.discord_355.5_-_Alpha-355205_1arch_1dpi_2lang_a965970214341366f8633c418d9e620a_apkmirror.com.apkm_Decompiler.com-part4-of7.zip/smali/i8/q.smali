###### Class i8.q (i8.q)
.class public Li8/q;
.super Ljava/lang/Exception;
.source "SourceFile"
