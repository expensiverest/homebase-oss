###### Class i8.a (i8.a)
.class public Li8/a;
.super Li8/q;
.source "SourceFile"
