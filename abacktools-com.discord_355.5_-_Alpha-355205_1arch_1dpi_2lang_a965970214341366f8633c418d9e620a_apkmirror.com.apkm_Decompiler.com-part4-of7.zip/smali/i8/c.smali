###### Class i8.c (i8.c)
.class public final Li8/c;
.super Ljava/lang/Thread;
.source "SourceFile"


# static fields
.field public static final y:Z


# instance fields
.field public final d:Ljava/util/concurrent/BlockingQueue;

.field public final e:Ljava/util/concurrent/BlockingQueue;

.field public final i:Lap/j;

.field public final v:Lbu/i;

.field public volatile w:Z

.field public final x:Lk7/i;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-boolean v0, Li8/t;->a:Z

    .line 2
    .line 3
    sput-boolean v0, Li8/c;->y:Z

    .line 4
    .line 5
    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/PriorityBlockingQueue;Ljava/util/concurrent/PriorityBlockingQueue;Lap/j;Lbu/i;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Li8/c;->w:Z

    .line 6
    .line 7
    iput-object p1, p0, Li8/c;->d:Ljava/util/concurrent/BlockingQueue;

    .line 8
    .line 9
    iput-object p2, p0, Li8/c;->e:Ljava/util/concurrent/BlockingQueue;

    .line 10
    .line 11
    iput-object p3, p0, Li8/c;->i:Lap/j;

    .line 12
    .line 13
    iput-object p4, p0, Li8/c;->v:Lbu/i;

    .line 14
    .line 15
    new-instance p1, Lk7/i;

    .line 16
    .line 17
    invoke-direct {p1, p0, p2, p4}, Lk7/i;-><init>(Li8/c;Ljava/util/concurrent/BlockingQueue;Lbu/i;)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Li8/c;->x:Lk7/i;

    .line 21
    .line 22
    return-void
.end method

.method private a()V
    .registers 12

    .line 1
    iget-object v0, p0, Li8/c;->d:Ljava/util/concurrent/BlockingQueue;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Li8/k;

    .line 8
    .line 9
    const-string v1, "cache-queue-take"

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    invoke-virtual {v0, v1}, Li8/k;->sendEvent(I)V

    .line 16
    .line 17
    .line 18
    const/4 v2, 0x2

    .line 19
    :try_start_12
    invoke-virtual {v0}, Li8/k;->isCanceled()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_24

    .line 24
    .line 25
    const-string v1, "cache-discard-canceled"

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Li8/k;->finish(Ljava/lang/String;)V
    :try_end_1d
    .catchall {:try_start_12 .. :try_end_1d} :catchall_21

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v2}, Li8/k;->sendEvent(I)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :catchall_21
    move-exception v1

    .line 35
    goto/16 :goto_f8

    .line 36
    .line 37
    :cond_24
    :try_start_24
    iget-object v3, p0, Li8/c;->i:Lap/j;

    .line 38
    .line 39
    invoke-virtual {v0}, Li8/k;->getCacheKey()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    invoke-virtual {v3, v4}, Lap/j;->a(Ljava/lang/String;)Li8/b;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    if-nez v3, :cond_46

    .line 48
    .line 49
    const-string v1, "cache-miss"

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    iget-object v1, p0, Li8/c;->x:Lk7/i;

    .line 55
    .line 56
    invoke-virtual {v1, v0}, Lk7/i;->F(Li8/k;)Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-nez v1, :cond_42

    .line 61
    .line 62
    iget-object v1, p0, Li8/c;->e:Ljava/util/concurrent/BlockingQueue;

    .line 63
    .line 64
    invoke-interface {v1, v0}, Ljava/util/concurrent/BlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_42
    .catchall {:try_start_24 .. :try_end_42} :catchall_21

    .line 65
    .line 66
    .line 67
    :cond_42
    invoke-virtual {v0, v2}, Li8/k;->sendEvent(I)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_46
    :try_start_46
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 72
    .line 73
    .line 74
    move-result-wide v4

    .line 75
    iget-wide v6, v3, Li8/b;->e:J

    .line 76
    .line 77
    cmp-long v6, v6, v4

    .line 78
    .line 79
    const/4 v7, 0x0

    .line 80
    if-gez v6, :cond_53

    .line 81
    .line 82
    move v6, v1

    .line 83
    goto :goto_54

    .line 84
    :cond_53
    move v6, v7

    .line 85
    :goto_54
    if-eqz v6, :cond_6f

    .line 86
    .line 87
    const-string v1, "cache-hit-expired"

    .line 88
    .line 89
    invoke-virtual {v0, v1}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0, v3}, Li8/k;->setCacheEntry(Li8/b;)Li8/k;

    .line 93
    .line 94
    .line 95
    iget-object v1, p0, Li8/c;->x:Lk7/i;

    .line 96
    .line 97
    invoke-virtual {v1, v0}, Lk7/i;->F(Li8/k;)Z

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    if-nez v1, :cond_6b

    .line 102
    .line 103
    iget-object v1, p0, Li8/c;->e:Ljava/util/concurrent/BlockingQueue;

    .line 104
    .line 105
    invoke-interface {v1, v0}, Ljava/util/concurrent/BlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_6b
    .catchall {:try_start_46 .. :try_end_6b} :catchall_21

    .line 106
    .line 107
    .line 108
    :cond_6b
    invoke-virtual {v0, v2}, Li8/k;->sendEvent(I)V

    .line 109
    .line 110
    .line 111
    return-void

    .line 112
    :cond_6f
    :try_start_6f
    const-string v6, "cache-hit"

    .line 113
    .line 114
    invoke-virtual {v0, v6}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    new-instance v6, Li8/g;

    .line 118
    .line 119
    iget-object v8, v3, Li8/b;->a:[B

    .line 120
    .line 121
    iget-object v9, v3, Li8/b;->g:Ljava/util/Map;

    .line 122
    .line 123
    invoke-direct {v6, v8, v9}, Li8/g;-><init>([BLjava/util/Map;)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v0, v6}, Li8/k;->parseNetworkResponse(Li8/g;)Li8/o;

    .line 127
    .line 128
    .line 129
    move-result-object v6

    .line 130
    const-string v8, "cache-hit-parsed"

    .line 131
    .line 132
    invoke-virtual {v0, v8}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    iget-object v8, v6, Li8/o;->c:Li8/q;

    .line 136
    .line 137
    if-nez v8, :cond_8b

    .line 138
    .line 139
    move v7, v1

    .line 140
    :cond_8b
    const/4 v8, 0x0

    .line 141
    if-nez v7, :cond_c3

    .line 142
    .line 143
    const-string v1, "cache-parsing-failed"

    .line 144
    .line 145
    invoke-virtual {v0, v1}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    iget-object v1, p0, Li8/c;->i:Lap/j;

    .line 149
    .line 150
    invoke-virtual {v0}, Li8/k;->getCacheKey()Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v3

    .line 154
    monitor-enter v1
    :try_end_9a
    .catchall {:try_start_6f .. :try_end_9a} :catchall_21

    .line 155
    :try_start_9a
    invoke-virtual {v1, v3}, Lap/j;->a(Ljava/lang/String;)Li8/b;

    .line 156
    .line 157
    .line 158
    move-result-object v4

    .line 159
    if-eqz v4, :cond_ac

    .line 160
    .line 161
    const-wide/16 v5, 0x0

    .line 162
    .line 163
    iput-wide v5, v4, Li8/b;->f:J

    .line 164
    .line 165
    iput-wide v5, v4, Li8/b;->e:J

    .line 166
    .line 167
    invoke-virtual {v1, v3, v4}, Lap/j;->g(Ljava/lang/String;Li8/b;)V
    :try_end_a9
    .catchall {:try_start_9a .. :try_end_a9} :catchall_aa

    .line 168
    .line 169
    .line 170
    goto :goto_ac

    .line 171
    :catchall_aa
    move-exception v3

    .line 172
    goto :goto_c1

    .line 173
    :cond_ac
    :goto_ac
    :try_start_ac
    monitor-exit v1

    .line 174
    invoke-virtual {v0, v8}, Li8/k;->setCacheEntry(Li8/b;)Li8/k;

    .line 175
    .line 176
    .line 177
    iget-object v1, p0, Li8/c;->x:Lk7/i;

    .line 178
    .line 179
    invoke-virtual {v1, v0}, Lk7/i;->F(Li8/k;)Z

    .line 180
    .line 181
    .line 182
    move-result v1

    .line 183
    if-nez v1, :cond_bd

    .line 184
    .line 185
    iget-object v1, p0, Li8/c;->e:Ljava/util/concurrent/BlockingQueue;

    .line 186
    .line 187
    invoke-interface {v1, v0}, Ljava/util/concurrent/BlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_bd
    .catchall {:try_start_ac .. :try_end_bd} :catchall_21

    .line 188
    .line 189
    .line 190
    :cond_bd
    invoke-virtual {v0, v2}, Li8/k;->sendEvent(I)V

    .line 191
    .line 192
    .line 193
    return-void

    .line 194
    :goto_c1
    :try_start_c1
    monitor-exit v1
    :try_end_c2
    .catchall {:try_start_c1 .. :try_end_c2} :catchall_aa

    .line 195
    :try_start_c2
    throw v3

    .line 196
    :cond_c3
    iget-wide v9, v3, Li8/b;->f:J

    .line 197
    .line 198
    cmp-long v4, v9, v4

    .line 199
    .line 200
    if-gez v4, :cond_ef

    .line 201
    .line 202
    const-string v4, "cache-hit-refresh-needed"

    .line 203
    .line 204
    invoke-virtual {v0, v4}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v0, v3}, Li8/k;->setCacheEntry(Li8/b;)Li8/k;

    .line 208
    .line 209
    .line 210
    iput-boolean v1, v6, Li8/o;->d:Z

    .line 211
    .line 212
    iget-object v1, p0, Li8/c;->x:Lk7/i;

    .line 213
    .line 214
    invoke-virtual {v1, v0}, Lk7/i;->F(Li8/k;)Z

    .line 215
    .line 216
    .line 217
    move-result v1

    .line 218
    if-nez v1, :cond_e9

    .line 219
    .line 220
    iget-object v1, p0, Li8/c;->v:Lbu/i;

    .line 221
    .line 222
    new-instance v3, Lmx/u;

    .line 223
    .line 224
    const/16 v4, 0x11

    .line 225
    .line 226
    const/4 v5, 0x0

    .line 227
    invoke-direct {v3, p0, v0, v4, v5}, Lmx/u;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {v1, v0, v6, v3}, Lbu/i;->P(Li8/k;Li8/o;Lmx/u;)V

    .line 231
    .line 232
    .line 233
    goto :goto_f4

    .line 234
    :cond_e9
    iget-object v1, p0, Li8/c;->v:Lbu/i;

    .line 235
    .line 236
    invoke-virtual {v1, v0, v6, v8}, Lbu/i;->P(Li8/k;Li8/o;Lmx/u;)V

    .line 237
    .line 238
    .line 239
    goto :goto_f4

    .line 240
    :cond_ef
    iget-object v1, p0, Li8/c;->v:Lbu/i;

    .line 241
    .line 242
    invoke-virtual {v1, v0, v6, v8}, Lbu/i;->P(Li8/k;Li8/o;Lmx/u;)V
    :try_end_f4
    .catchall {:try_start_c2 .. :try_end_f4} :catchall_21

    .line 243
    .line 244
    .line 245
    :goto_f4
    invoke-virtual {v0, v2}, Li8/k;->sendEvent(I)V

    .line 246
    .line 247
    .line 248
    return-void

    .line 249
    :goto_f8
    invoke-virtual {v0, v2}, Li8/k;->sendEvent(I)V

    .line 250
    .line 251
    .line 252
    throw v1
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    sget-boolean v0, Li8/c;->y:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_c

    .line 5
    .line 6
    const-string v0, "start new dispatcher"

    .line 7
    .line 8
    new-array v2, v1, [Ljava/lang/Object;

    .line 9
    .line 10
    invoke-static {v0, v2}, Li8/t;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :cond_c
    const/16 v0, 0xa

    .line 14
    .line 15
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Li8/c;->i:Lap/j;

    .line 19
    .line 20
    invoke-virtual {v0}, Lap/j;->e()V

    .line 21
    .line 22
    .line 23
    :goto_16
    :try_start_16
    invoke-direct {p0}, Li8/c;->a()V
    :try_end_19
    .catch Ljava/lang/InterruptedException; {:try_start_16 .. :try_end_19} :catch_1a

    .line 24
    .line 25
    .line 26
    goto :goto_16

    .line 27
    :catch_1a
    iget-boolean v0, p0, Li8/c;->w:Z

    .line 28
    .line 29
    if-eqz v0, :cond_26

    .line 30
    .line 31
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_26
    const-string v0, "Ignoring spurious interrupt of CacheDispatcher thread; use quit() to terminate it"

    .line 40
    .line 41
    new-array v2, v1, [Ljava/lang/Object;

    .line 42
    .line 43
    invoke-static {v0, v2}, Li8/t;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    goto :goto_16
.end method
