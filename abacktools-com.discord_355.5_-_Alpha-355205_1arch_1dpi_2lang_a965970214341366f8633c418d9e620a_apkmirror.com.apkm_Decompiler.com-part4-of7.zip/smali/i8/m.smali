###### Class i8.m (i8.m)
.class public interface abstract Li8/m;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e(Li8/q;)V
.end method
