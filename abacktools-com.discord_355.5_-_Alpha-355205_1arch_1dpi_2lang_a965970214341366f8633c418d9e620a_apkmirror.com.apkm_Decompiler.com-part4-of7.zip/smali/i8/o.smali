###### Class i8.o (i8.o)
.class public final Li8/o;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Li8/b;

.field public final c:Li8/q;

.field public d:Z


# direct methods
.method public constructor <init>(Li8/q;)V
    .registers 3

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 7
    iput-boolean v0, p0, Li8/o;->d:Z

    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Li8/o;->a:Ljava/lang/Object;

    .line 9
    iput-object v0, p0, Li8/o;->b:Li8/b;

    .line 10
    iput-object p1, p0, Li8/o;->c:Li8/q;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;Li8/b;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Li8/o;->d:Z

    .line 3
    iput-object p1, p0, Li8/o;->a:Ljava/lang/Object;

    .line 4
    iput-object p2, p0, Li8/o;->b:Li8/b;

    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, Li8/o;->c:Li8/q;

    return-void
.end method
