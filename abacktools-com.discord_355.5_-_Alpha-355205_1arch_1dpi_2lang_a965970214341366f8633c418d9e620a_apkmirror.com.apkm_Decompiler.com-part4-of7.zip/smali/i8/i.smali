###### Class i8.i (i8.i)
.class public interface abstract Li8/i;
.super Ljava/lang/Object;
.source "SourceFile"
