###### Class i8.j (i8.j)
.class public final enum Li8/j;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum d:Li8/j;

.field public static final synthetic e:[Li8/j;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Li8/j;

    .line 2
    .line 3
    const-string v1, "LOW"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    new-instance v1, Li8/j;

    .line 10
    .line 11
    const-string v2, "NORMAL"

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 15
    .line 16
    .line 17
    sput-object v1, Li8/j;->d:Li8/j;

    .line 18
    .line 19
    new-instance v2, Li8/j;

    .line 20
    .line 21
    const-string v3, "HIGH"

    .line 22
    .line 23
    const/4 v4, 0x2

    .line 24
    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 25
    .line 26
    .line 27
    new-instance v3, Li8/j;

    .line 28
    .line 29
    const-string v4, "IMMEDIATE"

    .line 30
    .line 31
    const/4 v5, 0x3

    .line 32
    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 33
    .line 34
    .line 35
    filled-new-array {v0, v1, v2, v3}, [Li8/j;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sput-object v0, Li8/j;->e:[Li8/j;

    .line 40
    .line 41
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Li8/j;
    .registers 2

    .line 1
    const-class v0, Li8/j;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Li8/j;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Li8/j;
    .registers 1

    .line 1
    sget-object v0, Li8/j;->e:[Li8/j;

    .line 2
    .line 3
    invoke-virtual {v0}, [Li8/j;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Li8/j;

    .line 8
    .line 9
    return-object v0
.end method
