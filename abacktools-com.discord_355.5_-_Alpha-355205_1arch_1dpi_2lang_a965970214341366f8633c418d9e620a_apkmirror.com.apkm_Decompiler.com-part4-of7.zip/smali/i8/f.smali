###### Class i8.f (i8.f)
.class public final Li8/f;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field public final d:Ljava/util/concurrent/BlockingQueue;

.field public final e:Lk7/r;

.field public final i:Lap/j;

.field public final v:Lbu/i;

.field public volatile w:Z


# direct methods
.method public constructor <init>(Ljava/util/concurrent/PriorityBlockingQueue;Lk7/r;Lap/j;Lbu/i;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Li8/f;->w:Z

    .line 6
    .line 7
    iput-object p1, p0, Li8/f;->d:Ljava/util/concurrent/BlockingQueue;

    .line 8
    .line 9
    iput-object p2, p0, Li8/f;->e:Lk7/r;

    .line 10
    .line 11
    iput-object p3, p0, Li8/f;->i:Lap/j;

    .line 12
    .line 13
    iput-object p4, p0, Li8/f;->v:Lbu/i;

    .line 14
    .line 15
    return-void
.end method

.method private a()V
    .registers 10

    .line 1
    const-string v1, "post-error"

    .line 2
    .line 3
    iget-object v0, p0, Li8/f;->d:Ljava/util/concurrent/BlockingQueue;

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    move-object v3, v0

    .line 10
    check-cast v3, Li8/k;

    .line 11
    .line 12
    iget-object v2, p0, Li8/f;->v:Lbu/i;

    .line 13
    .line 14
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x3

    .line 18
    invoke-virtual {v3, v0}, Li8/k;->sendEvent(I)V

    .line 19
    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    const/4 v8, 0x4

    .line 23
    :try_start_16
    const-string v0, "network-queue-take"

    .line 24
    .line 25
    invoke-virtual {v3, v0}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v3}, Li8/k;->isCanceled()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_35

    .line 33
    .line 34
    const-string v0, "network-discard-cancelled"

    .line 35
    .line 36
    invoke-virtual {v3, v0}, Li8/k;->finish(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v3}, Li8/k;->notifyListenerResponseNotUsable()V
    :try_end_29
    .catch Li8/q; {:try_start_16 .. :try_end_29} :catch_32
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_29} :catch_30
    .catchall {:try_start_16 .. :try_end_29} :catchall_2d

    .line 40
    .line 41
    .line 42
    invoke-virtual {v3, v8}, Li8/k;->sendEvent(I)V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :catchall_2d
    move-exception v0

    .line 47
    goto/16 :goto_f0

    .line 48
    .line 49
    :catch_30
    move-exception v0

    .line 50
    goto :goto_8d

    .line 51
    :catch_32
    move-exception v0

    .line 52
    goto/16 :goto_ca

    .line 53
    .line 54
    :cond_35
    :try_start_35
    invoke-virtual {v3}, Li8/k;->getTrafficStatsTag()I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    invoke-static {v0}, Landroid/net/TrafficStats;->setThreadStatsTag(I)V

    .line 59
    .line 60
    .line 61
    iget-object v0, p0, Li8/f;->e:Lk7/r;

    .line 62
    .line 63
    invoke-virtual {v0, v3}, Lk7/r;->L(Li8/k;)Li8/g;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    const-string v4, "network-http-complete"

    .line 68
    .line 69
    invoke-virtual {v3, v4}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-boolean v4, v0, Li8/g;->d:Z

    .line 73
    .line 74
    if-eqz v4, :cond_5d

    .line 75
    .line 76
    invoke-virtual {v3}, Li8/k;->hasHadResponseDelivered()Z

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    if-eqz v4, :cond_5d

    .line 81
    .line 82
    const-string v0, "not-modified"

    .line 83
    .line 84
    invoke-virtual {v3, v0}, Li8/k;->finish(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v3}, Li8/k;->notifyListenerResponseNotUsable()V
    :try_end_59
    .catch Li8/q; {:try_start_35 .. :try_end_59} :catch_32
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_59} :catch_30
    .catchall {:try_start_35 .. :try_end_59} :catchall_2d

    .line 88
    .line 89
    .line 90
    invoke-virtual {v3, v8}, Li8/k;->sendEvent(I)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    :cond_5d
    :try_start_5d
    invoke-virtual {v3, v0}, Li8/k;->parseNetworkResponse(Li8/g;)Li8/o;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    const-string v4, "network-parse-complete"

    .line 99
    .line 100
    invoke-virtual {v3, v4}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v3}, Li8/k;->shouldCache()Z

    .line 104
    .line 105
    .line 106
    move-result v4

    .line 107
    if-eqz v4, :cond_80

    .line 108
    .line 109
    iget-object v4, v0, Li8/o;->b:Li8/b;

    .line 110
    .line 111
    if-eqz v4, :cond_80

    .line 112
    .line 113
    iget-object v4, p0, Li8/f;->i:Lap/j;

    .line 114
    .line 115
    invoke-virtual {v3}, Li8/k;->getCacheKey()Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    iget-object v7, v0, Li8/o;->b:Li8/b;

    .line 120
    .line 121
    invoke-virtual {v4, v6, v7}, Lap/j;->g(Ljava/lang/String;Li8/b;)V

    .line 122
    .line 123
    .line 124
    const-string v4, "network-cache-written"

    .line 125
    .line 126
    invoke-virtual {v3, v4}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    :cond_80
    invoke-virtual {v3}, Li8/k;->markDelivered()V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2, v3, v0, v5}, Lbu/i;->P(Li8/k;Li8/o;Lmx/u;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v3, v0}, Li8/k;->notifyListenerResponseReceived(Li8/o;)V
    :try_end_89
    .catch Li8/q; {:try_start_5d .. :try_end_89} :catch_32
    .catch Ljava/lang/Exception; {:try_start_5d .. :try_end_89} :catch_30
    .catchall {:try_start_5d .. :try_end_89} :catchall_2d

    .line 136
    .line 137
    .line 138
    invoke-virtual {v3, v8}, Li8/k;->sendEvent(I)V

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :goto_8d
    :try_start_8d
    const-string v4, "Unhandled exception %s"

    .line 143
    .line 144
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v6

    .line 148
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v6

    .line 152
    const-string v7, "Volley"

    .line 153
    .line 154
    invoke-static {v4, v6}, Li8/t;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v4

    .line 158
    invoke-static {v7, v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 159
    .line 160
    .line 161
    new-instance v4, Li8/q;

    .line 162
    .line 163
    invoke-direct {v4, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 164
    .line 165
    .line 166
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 167
    .line 168
    .line 169
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v3, v1}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    move-object v0, v4

    .line 176
    new-instance v4, Li8/o;

    .line 177
    .line 178
    invoke-direct {v4, v0}, Li8/o;-><init>(Li8/q;)V

    .line 179
    .line 180
    .line 181
    iget-object v0, v2, Lbu/i;->e:Ljava/lang/Object;

    .line 182
    .line 183
    check-cast v0, Le6/e;

    .line 184
    .line 185
    new-instance v2, Lcom/facebook/imagepipeline/producers/y;

    .line 186
    .line 187
    const/16 v6, 0x8

    .line 188
    .line 189
    const/4 v7, 0x0

    .line 190
    invoke-direct/range {v2 .. v7}, Lcom/facebook/imagepipeline/producers/y;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v0, v2}, Le6/e;->execute(Ljava/lang/Runnable;)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v3}, Li8/k;->notifyListenerResponseNotUsable()V
    :try_end_c6
    .catchall {:try_start_8d .. :try_end_c6} :catchall_2d

    .line 197
    .line 198
    .line 199
    :goto_c6
    invoke-virtual {v3, v8}, Li8/k;->sendEvent(I)V

    .line 200
    .line 201
    .line 202
    goto :goto_ef

    .line 203
    :goto_ca
    :try_start_ca
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 204
    .line 205
    .line 206
    invoke-virtual {v3, v0}, Li8/k;->parseNetworkError(Li8/q;)Li8/q;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 211
    .line 212
    .line 213
    invoke-virtual {v3, v1}, Li8/k;->addMarker(Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    new-instance v4, Li8/o;

    .line 217
    .line 218
    invoke-direct {v4, v0}, Li8/o;-><init>(Li8/q;)V

    .line 219
    .line 220
    .line 221
    iget-object v0, v2, Lbu/i;->e:Ljava/lang/Object;

    .line 222
    .line 223
    check-cast v0, Le6/e;

    .line 224
    .line 225
    new-instance v2, Lcom/facebook/imagepipeline/producers/y;

    .line 226
    .line 227
    const/16 v6, 0x8

    .line 228
    .line 229
    const/4 v7, 0x0

    .line 230
    invoke-direct/range {v2 .. v7}, Lcom/facebook/imagepipeline/producers/y;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v0, v2}, Le6/e;->execute(Ljava/lang/Runnable;)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {v3}, Li8/k;->notifyListenerResponseNotUsable()V
    :try_end_ee
    .catchall {:try_start_ca .. :try_end_ee} :catchall_2d

    .line 237
    .line 238
    .line 239
    goto :goto_c6

    .line 240
    :goto_ef
    return-void

    .line 241
    :goto_f0
    invoke-virtual {v3, v8}, Li8/k;->sendEvent(I)V

    .line 242
    .line 243
    .line 244
    throw v0
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 1
    const/16 v0, 0xa

    .line 2
    .line 3
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    .line 4
    .line 5
    .line 6
    :goto_5
    :try_start_5
    invoke-direct {p0}, Li8/f;->a()V
    :try_end_8
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_8} :catch_9

    .line 7
    .line 8
    .line 9
    goto :goto_5

    .line 10
    :catch_9
    iget-boolean v0, p0, Li8/f;->w:Z

    .line 11
    .line 12
    if-eqz v0, :cond_15

    .line 13
    .line 14
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    const/4 v0, 0x0

    .line 23
    new-array v0, v0, [Ljava/lang/Object;

    .line 24
    .line 25
    const-string v1, "Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it"

    .line 26
    .line 27
    invoke-static {v1, v0}, Li8/t;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    goto :goto_5
.end method
