###### Class i80.r (i80.r)
.class public final Li80/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field public static final v:Ljava/util/logging/Logger;


# instance fields
.field public final d:Lq80/k;

.field public final e:Li80/q;

.field public final i:Li80/c;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const-class v0, Li80/f;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "getLogger(Http2::class.java.name)"

    .line 12
    .line 13
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Li80/r;->v:Ljava/util/logging/Logger;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>(Lq80/w;)V
    .registers 3

    .line 1
    const-string v0, "source"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Li80/r;->d:Lq80/k;

    .line 10
    .line 11
    new-instance v0, Li80/q;

    .line 12
    .line 13
    invoke-direct {v0, p1}, Li80/q;-><init>(Lq80/k;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Li80/r;->e:Li80/q;

    .line 17
    .line 18
    new-instance p1, Li80/c;

    .line 19
    .line 20
    invoke-direct {p1, v0}, Li80/c;-><init>(Li80/q;)V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, Li80/r;->i:Li80/c;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final c(ZLbg/v;)Z
    .registers 26

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    :try_start_5
    iget-object v3, v1, Li80/r;->d:Lq80/k;

    .line 7
    .line 8
    const-wide/16 v4, 0x9

    .line 9
    .line 10
    invoke-interface {v3, v4, v5}, Lq80/k;->e0(J)V
    :try_end_c
    .catch Ljava/io/EOFException; {:try_start_5 .. :try_end_c} :catch_365

    .line 11
    .line 12
    .line 13
    iget-object v3, v1, Li80/r;->d:Lq80/k;

    .line 14
    .line 15
    invoke-static {v3}, Lc80/b;->s(Lq80/k;)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    const/16 v4, 0x4000

    .line 20
    .line 21
    if-gt v3, v4, :cond_359

    .line 22
    .line 23
    iget-object v5, v1, Li80/r;->d:Lq80/k;

    .line 24
    .line 25
    invoke-interface {v5}, Lq80/k;->readByte()B

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    and-int/lit16 v5, v5, 0xff

    .line 30
    .line 31
    iget-object v6, v1, Li80/r;->d:Lq80/k;

    .line 32
    .line 33
    invoke-interface {v6}, Lq80/k;->readByte()B

    .line 34
    .line 35
    .line 36
    move-result v6

    .line 37
    and-int/lit16 v7, v6, 0xff

    .line 38
    .line 39
    iget-object v8, v1, Li80/r;->d:Lq80/k;

    .line 40
    .line 41
    invoke-interface {v8}, Lq80/k;->readInt()I

    .line 42
    .line 43
    .line 44
    move-result v8

    .line 45
    const v9, 0x7fffffff

    .line 46
    .line 47
    .line 48
    and-int v13, v8, v9

    .line 49
    .line 50
    sget-object v9, Li80/r;->v:Ljava/util/logging/Logger;

    .line 51
    .line 52
    sget-object v10, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 53
    .line 54
    invoke-virtual {v9, v10}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    .line 55
    .line 56
    .line 57
    move-result v10

    .line 58
    const/4 v11, 0x1

    .line 59
    if-eqz v10, :cond_43

    .line 60
    .line 61
    invoke-static {v11, v13, v3, v5, v7}, Li80/f;->a(ZIIII)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v10

    .line 65
    invoke-virtual {v9, v10}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    :cond_43
    const/4 v9, 0x4

    .line 69
    if-eqz p1, :cond_73

    .line 70
    .line 71
    if-ne v5, v9, :cond_49

    .line 72
    .line 73
    goto :goto_73

    .line 74
    :cond_49
    new-instance v0, Ljava/io/IOException;

    .line 75
    .line 76
    new-instance v2, Ljava/lang/StringBuilder;

    .line 77
    .line 78
    const-string v3, "Expected a SETTINGS frame but was "

    .line 79
    .line 80
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    sget-object v3, Li80/f;->b:[Ljava/lang/String;

    .line 84
    .line 85
    array-length v4, v3

    .line 86
    if-ge v5, v4, :cond_5a

    .line 87
    .line 88
    aget-object v3, v3, v5

    .line 89
    .line 90
    goto :goto_68

    .line 91
    :cond_5a
    const-string v3, "0x%02x"

    .line 92
    .line 93
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object v4

    .line 97
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    invoke-static {v3, v4}, Lc80/b;->h(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v3

    .line 105
    :goto_68
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    throw v0

    .line 116
    :cond_73
    :goto_73
    const/4 v12, 0x5

    .line 117
    const/4 v14, 0x3

    .line 118
    const/4 v15, 0x2

    .line 119
    const/16 p1, 0xe

    .line 120
    .line 121
    const/16 v10, 0x8

    .line 122
    .line 123
    move/from16 v17, v5

    .line 124
    .line 125
    const-wide/16 v4, 0x0

    .line 126
    .line 127
    packed-switch v17, :pswitch_data_366

    .line 128
    .line 129
    .line 130
    iget-object v0, v1, Li80/r;->d:Lq80/k;

    .line 131
    .line 132
    int-to-long v2, v3

    .line 133
    invoke-interface {v0, v2, v3}, Lq80/k;->skip(J)V

    .line 134
    .line 135
    .line 136
    return v11

    .line 137
    :pswitch_88
    if-ne v3, v9, :cond_d3

    .line 138
    .line 139
    iget-object v2, v1, Li80/r;->d:Lq80/k;

    .line 140
    .line 141
    invoke-interface {v2}, Lq80/k;->readInt()I

    .line 142
    .line 143
    .line 144
    move-result v2

    .line 145
    const-wide/32 v6, 0x7fffffff

    .line 146
    .line 147
    .line 148
    int-to-long v2, v2

    .line 149
    and-long/2addr v2, v6

    .line 150
    cmp-long v4, v2, v4

    .line 151
    .line 152
    if-eqz v4, :cond_cb

    .line 153
    .line 154
    if-nez v13, :cond_ae

    .line 155
    .line 156
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 157
    .line 158
    move-object v4, v0

    .line 159
    check-cast v4, Li80/n;

    .line 160
    .line 161
    monitor-enter v4

    .line 162
    :try_start_a1
    iget-wide v5, v4, Li80/n;->W:J

    .line 163
    .line 164
    add-long/2addr v5, v2

    .line 165
    iput-wide v5, v4, Li80/n;->W:J

    .line 166
    .line 167
    invoke-virtual {v4}, Ljava/lang/Object;->notifyAll()V
    :try_end_a9
    .catchall {:try_start_a1 .. :try_end_a9} :catchall_ab

    .line 168
    .line 169
    .line 170
    monitor-exit v4

    .line 171
    return v11

    .line 172
    :catchall_ab
    move-exception v0

    .line 173
    monitor-exit v4

    .line 174
    throw v0

    .line 175
    :cond_ae
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 176
    .line 177
    check-cast v0, Li80/n;

    .line 178
    .line 179
    invoke-virtual {v0, v13}, Li80/n;->d(I)Li80/v;

    .line 180
    .line 181
    .line 182
    move-result-object v5

    .line 183
    if-eqz v5, :cond_c8

    .line 184
    .line 185
    monitor-enter v5

    .line 186
    :try_start_b9
    iget-wide v6, v5, Li80/v;->f:J

    .line 187
    .line 188
    add-long/2addr v6, v2

    .line 189
    iput-wide v6, v5, Li80/v;->f:J

    .line 190
    .line 191
    if-lez v4, :cond_c3

    .line 192
    .line 193
    invoke-virtual {v5}, Ljava/lang/Object;->notifyAll()V
    :try_end_c3
    .catchall {:try_start_b9 .. :try_end_c3} :catchall_c5

    .line 194
    .line 195
    .line 196
    :cond_c3
    monitor-exit v5

    .line 197
    return v11

    .line 198
    :catchall_c5
    move-exception v0

    .line 199
    monitor-exit v5

    .line 200
    throw v0

    .line 201
    :cond_c8
    :goto_c8
    move v2, v11

    .line 202
    goto/16 :goto_308

    .line 203
    .line 204
    :cond_cb
    new-instance v0, Ljava/io/IOException;

    .line 205
    .line 206
    const-string v2, "windowSizeIncrement was 0"

    .line 207
    .line 208
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    throw v0

    .line 212
    :cond_d3
    new-instance v0, Ljava/io/IOException;

    .line 213
    .line 214
    const-string v2, "TYPE_WINDOW_UPDATE length !=4: "

    .line 215
    .line 216
    invoke-static {v3, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v2

    .line 220
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    throw v0

    .line 224
    :pswitch_df
    if-lt v3, v10, :cond_165

    .line 225
    .line 226
    if-nez v13, :cond_15d

    .line 227
    .line 228
    iget-object v4, v1, Li80/r;->d:Lq80/k;

    .line 229
    .line 230
    invoke-interface {v4}, Lq80/k;->readInt()I

    .line 231
    .line 232
    .line 233
    move-result v4

    .line 234
    iget-object v5, v1, Li80/r;->d:Lq80/k;

    .line 235
    .line 236
    invoke-interface {v5}, Lq80/k;->readInt()I

    .line 237
    .line 238
    .line 239
    move-result v5

    .line 240
    sub-int/2addr v3, v10

    .line 241
    invoke-static/range {p1 .. p1}, Lv0/d;->e(I)[I

    .line 242
    .line 243
    .line 244
    move-result-object v6

    .line 245
    array-length v7, v6

    .line 246
    move v8, v2

    .line 247
    :goto_f6
    if-ge v8, v7, :cond_104

    .line 248
    .line 249
    aget v9, v6, v8

    .line 250
    .line 251
    invoke-static {v9}, Lv0/d;->d(I)I

    .line 252
    .line 253
    .line 254
    move-result v12

    .line 255
    if-ne v12, v5, :cond_101

    .line 256
    .line 257
    goto :goto_105

    .line 258
    :cond_101
    add-int/lit8 v8, v8, 0x1

    .line 259
    .line 260
    goto :goto_f6

    .line 261
    :cond_104
    move v9, v2

    .line 262
    :goto_105
    if-eqz v9, :cond_151

    .line 263
    .line 264
    sget-object v5, Lq80/l;->v:Lq80/l;

    .line 265
    .line 266
    if-lez v3, :cond_112

    .line 267
    .line 268
    iget-object v5, v1, Li80/r;->d:Lq80/k;

    .line 269
    .line 270
    int-to-long v6, v3

    .line 271
    invoke-interface {v5, v6, v7}, Lq80/k;->p(J)Lq80/l;

    .line 272
    .line 273
    .line 274
    move-result-object v5

    .line 275
    :cond_112
    const-string v3, "debugData"

    .line 276
    .line 277
    invoke-static {v5, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v5}, Lq80/l;->c()I

    .line 281
    .line 282
    .line 283
    iget-object v3, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 284
    .line 285
    check-cast v3, Li80/n;

    .line 286
    .line 287
    monitor-enter v3

    .line 288
    :try_start_11f
    iget-object v5, v3, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 289
    .line 290
    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 291
    .line 292
    .line 293
    move-result-object v5

    .line 294
    new-array v6, v2, [Li80/v;

    .line 295
    .line 296
    invoke-interface {v5, v6}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v5

    .line 300
    iput-boolean v11, v3, Li80/n;->x:Z
    :try_end_12d
    .catchall {:try_start_11f .. :try_end_12d} :catchall_14e

    .line 301
    .line 302
    monitor-exit v3

    .line 303
    check-cast v5, [Li80/v;

    .line 304
    .line 305
    array-length v3, v5

    .line 306
    :goto_131
    if-ge v2, v3, :cond_c8

    .line 307
    .line 308
    aget-object v6, v5, v2

    .line 309
    .line 310
    iget v7, v6, Li80/v;->a:I

    .line 311
    .line 312
    if-le v7, v4, :cond_14b

    .line 313
    .line 314
    invoke-virtual {v6}, Li80/v;->g()Z

    .line 315
    .line 316
    .line 317
    move-result v7

    .line 318
    if-eqz v7, :cond_14b

    .line 319
    .line 320
    invoke-virtual {v6, v10}, Li80/v;->j(I)V

    .line 321
    .line 322
    .line 323
    iget-object v7, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 324
    .line 325
    check-cast v7, Li80/n;

    .line 326
    .line 327
    iget v6, v6, Li80/v;->a:I

    .line 328
    .line 329
    invoke-virtual {v7, v6}, Li80/n;->g(I)Li80/v;

    .line 330
    .line 331
    .line 332
    :cond_14b
    add-int/lit8 v2, v2, 0x1

    .line 333
    .line 334
    goto :goto_131

    .line 335
    :catchall_14e
    move-exception v0

    .line 336
    monitor-exit v3

    .line 337
    throw v0

    .line 338
    :cond_151
    new-instance v0, Ljava/io/IOException;

    .line 339
    .line 340
    const-string v2, "TYPE_GOAWAY unexpected error code: "

    .line 341
    .line 342
    invoke-static {v5, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 343
    .line 344
    .line 345
    move-result-object v2

    .line 346
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 347
    .line 348
    .line 349
    throw v0

    .line 350
    :cond_15d
    new-instance v0, Ljava/io/IOException;

    .line 351
    .line 352
    const-string v2, "TYPE_GOAWAY streamId != 0"

    .line 353
    .line 354
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    throw v0

    .line 358
    :cond_165
    new-instance v0, Ljava/io/IOException;

    .line 359
    .line 360
    const-string v2, "TYPE_GOAWAY length < 8: "

    .line 361
    .line 362
    invoke-static {v3, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 363
    .line 364
    .line 365
    move-result-object v2

    .line 366
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    throw v0

    .line 370
    :pswitch_171
    if-ne v3, v10, :cond_1df

    .line 371
    .line 372
    if-nez v13, :cond_1d7

    .line 373
    .line 374
    iget-object v3, v1, Li80/r;->d:Lq80/k;

    .line 375
    .line 376
    invoke-interface {v3}, Lq80/k;->readInt()I

    .line 377
    .line 378
    .line 379
    move-result v3

    .line 380
    iget-object v7, v1, Li80/r;->d:Lq80/k;

    .line 381
    .line 382
    invoke-interface {v7}, Lq80/k;->readInt()I

    .line 383
    .line 384
    .line 385
    move-result v20

    .line 386
    and-int/2addr v6, v11

    .line 387
    if-eqz v6, :cond_185

    .line 388
    .line 389
    move v2, v11

    .line 390
    :cond_185
    if-eqz v2, :cond_1ab

    .line 391
    .line 392
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 393
    .line 394
    move-object v2, v0

    .line 395
    check-cast v2, Li80/n;

    .line 396
    .line 397
    monitor-enter v2

    .line 398
    const-wide/16 v4, 0x1

    .line 399
    .line 400
    if-eq v3, v11, :cond_1a2

    .line 401
    .line 402
    if-eq v3, v15, :cond_19c

    .line 403
    .line 404
    if-eq v3, v14, :cond_196

    .line 405
    .line 406
    goto :goto_1a7

    .line 407
    :cond_196
    :try_start_196
    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V

    .line 408
    .line 409
    .line 410
    goto :goto_1a7

    .line 411
    :catchall_19a
    move-exception v0

    .line 412
    goto :goto_1a9

    .line 413
    :cond_19c
    iget-wide v6, v2, Li80/n;->P:J

    .line 414
    .line 415
    add-long/2addr v6, v4

    .line 416
    iput-wide v6, v2, Li80/n;->P:J

    .line 417
    .line 418
    goto :goto_1a7

    .line 419
    :cond_1a2
    iget-wide v6, v2, Li80/n;->N:J

    .line 420
    .line 421
    add-long/2addr v6, v4

    .line 422
    iput-wide v6, v2, Li80/n;->N:J
    :try_end_1a7
    .catchall {:try_start_196 .. :try_end_1a7} :catchall_19a

    .line 423
    .line 424
    :goto_1a7
    monitor-exit v2

    .line 425
    return v11

    .line 426
    :goto_1a9
    monitor-exit v2

    .line 427
    throw v0

    .line 428
    :cond_1ab
    iget-object v2, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 429
    .line 430
    check-cast v2, Li80/n;

    .line 431
    .line 432
    iget-object v2, v2, Li80/n;->J:Le80/b;

    .line 433
    .line 434
    new-instance v6, Ljava/lang/StringBuilder;

    .line 435
    .line 436
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 437
    .line 438
    .line 439
    iget-object v7, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 440
    .line 441
    check-cast v7, Li80/n;

    .line 442
    .line 443
    iget-object v7, v7, Li80/n;->i:Ljava/lang/String;

    .line 444
    .line 445
    const-string v8, " ping"

    .line 446
    .line 447
    invoke-static {v6, v7, v8}, Lcom/google/android/gms/internal/fido/nb;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v17

    .line 451
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 452
    .line 453
    move-object/from16 v18, v0

    .line 454
    .line 455
    check-cast v18, Li80/n;

    .line 456
    .line 457
    new-instance v16, Li80/j;

    .line 458
    .line 459
    const/16 v21, 0x0

    .line 460
    .line 461
    move/from16 v19, v3

    .line 462
    .line 463
    invoke-direct/range {v16 .. v21}, Li80/j;-><init>(Ljava/lang/String;Li80/n;III)V

    .line 464
    .line 465
    .line 466
    move-object/from16 v0, v16

    .line 467
    .line 468
    invoke-virtual {v2, v0, v4, v5}, Le80/b;->c(Le80/a;J)V

    .line 469
    .line 470
    .line 471
    return v11

    .line 472
    :cond_1d7
    new-instance v0, Ljava/io/IOException;

    .line 473
    .line 474
    const-string v2, "TYPE_PING streamId != 0"

    .line 475
    .line 476
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 477
    .line 478
    .line 479
    throw v0

    .line 480
    :cond_1df
    new-instance v0, Ljava/io/IOException;

    .line 481
    .line 482
    const-string v2, "TYPE_PING length != 8: "

    .line 483
    .line 484
    invoke-static {v3, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 485
    .line 486
    .line 487
    move-result-object v2

    .line 488
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 489
    .line 490
    .line 491
    throw v0

    .line 492
    :pswitch_1eb
    invoke-virtual {v1, v0, v3, v7, v13}, Li80/r;->j(Lbg/v;III)V

    .line 493
    .line 494
    .line 495
    return v11

    .line 496
    :pswitch_1ef
    iget-object v7, v1, Li80/r;->d:Lq80/k;

    .line 497
    .line 498
    if-nez v13, :cond_29a

    .line 499
    .line 500
    and-int/2addr v6, v11

    .line 501
    if-eqz v6, :cond_202

    .line 502
    .line 503
    if-nez v3, :cond_1fa

    .line 504
    .line 505
    goto/16 :goto_c8

    .line 506
    .line 507
    :cond_1fa
    new-instance v0, Ljava/io/IOException;

    .line 508
    .line 509
    const-string v2, "FRAME_SIZE_ERROR ack frame should be empty!"

    .line 510
    .line 511
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 512
    .line 513
    .line 514
    throw v0

    .line 515
    :cond_202
    rem-int/lit8 v6, v3, 0x6

    .line 516
    .line 517
    if-nez v6, :cond_28e

    .line 518
    .line 519
    new-instance v6, Li80/z;

    .line 520
    .line 521
    invoke-direct {v6}, Li80/z;-><init>()V

    .line 522
    .line 523
    .line 524
    invoke-static {v2, v3}, Lsg/a;->g0(II)Lg40/c;

    .line 525
    .line 526
    .line 527
    move-result-object v2

    .line 528
    const/4 v3, 0x6

    .line 529
    invoke-static {v3, v2}, Lsg/a;->d0(ILg40/c;)Lg40/a;

    .line 530
    .line 531
    .line 532
    move-result-object v2

    .line 533
    iget v3, v2, Lg40/a;->d:I

    .line 534
    .line 535
    iget v8, v2, Lg40/a;->e:I

    .line 536
    .line 537
    iget v2, v2, Lg40/a;->i:I

    .line 538
    .line 539
    if-lez v2, :cond_21e

    .line 540
    .line 541
    if-le v3, v8, :cond_222

    .line 542
    .line 543
    :cond_21e
    if-gez v2, :cond_272

    .line 544
    .line 545
    if-gt v8, v3, :cond_272

    .line 546
    .line 547
    :cond_222
    :goto_222
    invoke-interface {v7}, Lq80/k;->readShort()S

    .line 548
    .line 549
    .line 550
    move-result v10

    .line 551
    sget-object v13, Lc80/b;->a:[B

    .line 552
    .line 553
    const v13, 0xffff

    .line 554
    .line 555
    .line 556
    and-int/2addr v10, v13

    .line 557
    invoke-interface {v7}, Lq80/k;->readInt()I

    .line 558
    .line 559
    .line 560
    move-result v13

    .line 561
    if-eq v10, v15, :cond_25d

    .line 562
    .line 563
    if-eq v10, v14, :cond_25b

    .line 564
    .line 565
    if-eq v10, v9, :cond_24f

    .line 566
    .line 567
    if-eq v10, v12, :cond_239

    .line 568
    .line 569
    goto :goto_26a

    .line 570
    :cond_239
    const/16 v14, 0x4000

    .line 571
    .line 572
    if-lt v13, v14, :cond_243

    .line 573
    .line 574
    const v14, 0xffffff

    .line 575
    .line 576
    .line 577
    if-gt v13, v14, :cond_243

    .line 578
    .line 579
    goto :goto_26a

    .line 580
    :cond_243
    new-instance v0, Ljava/io/IOException;

    .line 581
    .line 582
    const-string v2, "PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: "

    .line 583
    .line 584
    invoke-static {v13, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object v2

    .line 588
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 589
    .line 590
    .line 591
    throw v0

    .line 592
    :cond_24f
    if-ltz v13, :cond_253

    .line 593
    .line 594
    const/4 v10, 0x7

    .line 595
    goto :goto_26a

    .line 596
    :cond_253
    new-instance v0, Ljava/io/IOException;

    .line 597
    .line 598
    const-string v2, "PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1"

    .line 599
    .line 600
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 601
    .line 602
    .line 603
    throw v0

    .line 604
    :cond_25b
    move v10, v9

    .line 605
    goto :goto_26a

    .line 606
    :cond_25d
    if-eqz v13, :cond_26a

    .line 607
    .line 608
    if-ne v13, v11, :cond_262

    .line 609
    .line 610
    goto :goto_26a

    .line 611
    :cond_262
    new-instance v0, Ljava/io/IOException;

    .line 612
    .line 613
    const-string v2, "PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1"

    .line 614
    .line 615
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 616
    .line 617
    .line 618
    throw v0

    .line 619
    :cond_26a
    :goto_26a
    invoke-virtual {v6, v10, v13}, Li80/z;->c(II)V

    .line 620
    .line 621
    .line 622
    if-eq v3, v8, :cond_272

    .line 623
    .line 624
    add-int/2addr v3, v2

    .line 625
    const/4 v14, 0x3

    .line 626
    goto :goto_222

    .line 627
    :cond_272
    iget-object v2, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 628
    .line 629
    check-cast v2, Li80/n;

    .line 630
    .line 631
    iget-object v3, v2, Li80/n;->J:Le80/b;

    .line 632
    .line 633
    new-instance v7, Ljava/lang/StringBuilder;

    .line 634
    .line 635
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 636
    .line 637
    .line 638
    iget-object v2, v2, Li80/n;->i:Ljava/lang/String;

    .line 639
    .line 640
    const-string v8, " applyAndAckSettings"

    .line 641
    .line 642
    invoke-static {v7, v2, v8}, Lcom/google/android/gms/internal/fido/nb;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object v2

    .line 646
    new-instance v7, Li80/i;

    .line 647
    .line 648
    invoke-direct {v7, v2, v0, v6, v15}, Li80/i;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 649
    .line 650
    .line 651
    invoke-virtual {v3, v7, v4, v5}, Le80/b;->c(Le80/a;J)V

    .line 652
    .line 653
    .line 654
    return v11

    .line 655
    :cond_28e
    new-instance v0, Ljava/io/IOException;

    .line 656
    .line 657
    const-string v2, "TYPE_SETTINGS length % 6 != 0: "

    .line 658
    .line 659
    invoke-static {v3, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 660
    .line 661
    .line 662
    move-result-object v2

    .line 663
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 664
    .line 665
    .line 666
    throw v0

    .line 667
    :cond_29a
    new-instance v0, Ljava/io/IOException;

    .line 668
    .line 669
    const-string v2, "TYPE_SETTINGS streamId != 0"

    .line 670
    .line 671
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 672
    .line 673
    .line 674
    throw v0

    .line 675
    :pswitch_2a2
    if-ne v3, v9, :cond_31d

    .line 676
    .line 677
    if-eqz v13, :cond_315

    .line 678
    .line 679
    iget-object v3, v1, Li80/r;->d:Lq80/k;

    .line 680
    .line 681
    invoke-interface {v3}, Lq80/k;->readInt()I

    .line 682
    .line 683
    .line 684
    move-result v3

    .line 685
    invoke-static/range {p1 .. p1}, Lv0/d;->e(I)[I

    .line 686
    .line 687
    .line 688
    move-result-object v6

    .line 689
    array-length v7, v6

    .line 690
    move v9, v2

    .line 691
    :goto_2b2
    if-ge v9, v7, :cond_2c1

    .line 692
    .line 693
    aget v10, v6, v9

    .line 694
    .line 695
    invoke-static {v10}, Lv0/d;->d(I)I

    .line 696
    .line 697
    .line 698
    move-result v12

    .line 699
    if-ne v12, v3, :cond_2be

    .line 700
    .line 701
    move v14, v10

    .line 702
    goto :goto_2c2

    .line 703
    :cond_2be
    add-int/lit8 v9, v9, 0x1

    .line 704
    .line 705
    goto :goto_2b2

    .line 706
    :cond_2c1
    move v14, v2

    .line 707
    :goto_2c2
    if-eqz v14, :cond_309

    .line 708
    .line 709
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 710
    .line 711
    move-object v12, v0

    .line 712
    check-cast v12, Li80/n;

    .line 713
    .line 714
    if-eqz v13, :cond_2d0

    .line 715
    .line 716
    and-int/lit8 v0, v8, 0x1

    .line 717
    .line 718
    if-nez v0, :cond_2d0

    .line 719
    .line 720
    move v2, v11

    .line 721
    :cond_2d0
    if-eqz v2, :cond_2fe

    .line 722
    .line 723
    iget-object v0, v12, Li80/n;->K:Le80/b;

    .line 724
    .line 725
    new-instance v2, Ljava/lang/StringBuilder;

    .line 726
    .line 727
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 728
    .line 729
    .line 730
    iget-object v3, v12, Li80/n;->i:Ljava/lang/String;

    .line 731
    .line 732
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 733
    .line 734
    .line 735
    const/16 v3, 0x5b

    .line 736
    .line 737
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 738
    .line 739
    .line 740
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 741
    .line 742
    .line 743
    const-string v3, "] onReset"

    .line 744
    .line 745
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 746
    .line 747
    .line 748
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 749
    .line 750
    .line 751
    move-result-object v2

    .line 752
    new-instance v10, Li80/j;

    .line 753
    .line 754
    const/4 v15, 0x1

    .line 755
    move/from16 v22, v11

    .line 756
    .line 757
    move-object v11, v2

    .line 758
    move/from16 v2, v22

    .line 759
    .line 760
    invoke-direct/range {v10 .. v15}, Li80/j;-><init>(Ljava/lang/String;Li80/n;III)V

    .line 761
    .line 762
    .line 763
    invoke-virtual {v0, v10, v4, v5}, Le80/b;->c(Le80/a;J)V

    .line 764
    .line 765
    .line 766
    return v2

    .line 767
    :cond_2fe
    move v2, v11

    .line 768
    invoke-virtual {v12, v13}, Li80/n;->g(I)Li80/v;

    .line 769
    .line 770
    .line 771
    move-result-object v0

    .line 772
    if-eqz v0, :cond_308

    .line 773
    .line 774
    invoke-virtual {v0, v14}, Li80/v;->j(I)V

    .line 775
    .line 776
    .line 777
    :cond_308
    :goto_308
    return v2

    .line 778
    :cond_309
    new-instance v0, Ljava/io/IOException;

    .line 779
    .line 780
    const-string v2, "TYPE_RST_STREAM unexpected error code: "

    .line 781
    .line 782
    invoke-static {v3, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 783
    .line 784
    .line 785
    move-result-object v2

    .line 786
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 787
    .line 788
    .line 789
    throw v0

    .line 790
    :cond_315
    new-instance v0, Ljava/io/IOException;

    .line 791
    .line 792
    const-string v2, "TYPE_RST_STREAM streamId == 0"

    .line 793
    .line 794
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 795
    .line 796
    .line 797
    throw v0

    .line 798
    :cond_31d
    new-instance v0, Ljava/io/IOException;

    .line 799
    .line 800
    const-string v2, "TYPE_RST_STREAM length: "

    .line 801
    .line 802
    const-string v4, " != 4"

    .line 803
    .line 804
    invoke-static {v3, v2, v4}, Lp/x2;->e(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 805
    .line 806
    .line 807
    move-result-object v2

    .line 808
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 809
    .line 810
    .line 811
    throw v0

    .line 812
    :pswitch_32b
    move v2, v11

    .line 813
    if-ne v3, v12, :cond_341

    .line 814
    .line 815
    if-eqz v13, :cond_339

    .line 816
    .line 817
    iget-object v0, v1, Li80/r;->d:Lq80/k;

    .line 818
    .line 819
    invoke-interface {v0}, Lq80/k;->readInt()I

    .line 820
    .line 821
    .line 822
    invoke-interface {v0}, Lq80/k;->readByte()B

    .line 823
    .line 824
    .line 825
    return v2

    .line 826
    :cond_339
    new-instance v0, Ljava/io/IOException;

    .line 827
    .line 828
    const-string v2, "TYPE_PRIORITY streamId == 0"

    .line 829
    .line 830
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 831
    .line 832
    .line 833
    throw v0

    .line 834
    :cond_341
    new-instance v0, Ljava/io/IOException;

    .line 835
    .line 836
    const-string v2, "TYPE_PRIORITY length: "

    .line 837
    .line 838
    const-string v4, " != 5"

    .line 839
    .line 840
    invoke-static {v3, v2, v4}, Lp/x2;->e(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 841
    .line 842
    .line 843
    move-result-object v2

    .line 844
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 845
    .line 846
    .line 847
    throw v0

    .line 848
    :pswitch_34f
    move v2, v11

    .line 849
    invoke-virtual {v1, v0, v3, v7, v13}, Li80/r;->i(Lbg/v;III)V

    .line 850
    .line 851
    .line 852
    return v2

    .line 853
    :pswitch_354
    move v2, v11

    .line 854
    invoke-virtual {v1, v0, v3, v7, v13}, Li80/r;->d(Lbg/v;III)V

    .line 855
    .line 856
    .line 857
    return v2

    .line 858
    :cond_359
    new-instance v0, Ljava/io/IOException;

    .line 859
    .line 860
    const-string v2, "FRAME_SIZE_ERROR: "

    .line 861
    .line 862
    invoke-static {v3, v2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 863
    .line 864
    .line 865
    move-result-object v2

    .line 866
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 867
    .line 868
    .line 869
    throw v0

    .line 870
    :catch_365
    return v2

    .line 871
    :pswitch_data_366
    .packed-switch 0x0
        :pswitch_354
        :pswitch_34f
        :pswitch_32b
        :pswitch_2a2
        :pswitch_1ef
        :pswitch_1eb
        :pswitch_171
        :pswitch_df
        :pswitch_88
    .end packed-switch
.end method

.method public final close()V
    .registers 2

    .line 1
    iget-object v0, p0, Li80/r;->d:Lq80/k;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/io/Closeable;->close()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final d(Lbg/v;III)V
    .registers 21

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move/from16 v2, p3

    .line 6
    .line 7
    move/from16 v5, p4

    .line 8
    .line 9
    if-eqz v5, :cond_127

    .line 10
    .line 11
    and-int/lit8 v3, v2, 0x1

    .line 12
    .line 13
    if-eqz v3, :cond_10

    .line 14
    .line 15
    const/4 v8, 0x1

    .line 16
    goto :goto_11

    .line 17
    :cond_10
    const/4 v8, 0x0

    .line 18
    :goto_11
    and-int/lit8 v3, v2, 0x20

    .line 19
    .line 20
    if-nez v3, :cond_11f

    .line 21
    .line 22
    and-int/lit8 v3, v2, 0x8

    .line 23
    .line 24
    if-eqz v3, :cond_27

    .line 25
    .line 26
    iget-object v3, v1, Li80/r;->d:Lq80/k;

    .line 27
    .line 28
    invoke-interface {v3}, Lq80/k;->readByte()B

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    sget-object v7, Lc80/b;->a:[B

    .line 33
    .line 34
    and-int/lit16 v3, v3, 0xff

    .line 35
    .line 36
    move v9, v3

    .line 37
    :goto_24
    move/from16 v3, p2

    .line 38
    .line 39
    goto :goto_29

    .line 40
    :cond_27
    const/4 v9, 0x0

    .line 41
    goto :goto_24

    .line 42
    :goto_29
    invoke-static {v3, v2, v9}, Li80/p;->a(III)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    iget-object v2, v1, Li80/r;->d:Lq80/k;

    .line 47
    .line 48
    const-string v3, "source"

    .line 49
    .line 50
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    iget-object v3, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v3, Li80/n;

    .line 56
    .line 57
    const-wide/16 v10, 0x0

    .line 58
    .line 59
    if-eqz v5, :cond_75

    .line 60
    .line 61
    and-int/lit8 v12, v5, 0x1

    .line 62
    .line 63
    if-nez v12, :cond_75

    .line 64
    .line 65
    new-instance v6, Lq80/i;

    .line 66
    .line 67
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 68
    .line 69
    .line 70
    int-to-long v12, v7

    .line 71
    invoke-interface {v2, v12, v13}, Lq80/k;->e0(J)V

    .line 72
    .line 73
    .line 74
    invoke-interface {v2, v6, v12, v13}, Lq80/c0;->b0(Lq80/i;J)J

    .line 75
    .line 76
    .line 77
    iget-object v0, v3, Li80/n;->K:Le80/b;

    .line 78
    .line 79
    new-instance v2, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 82
    .line 83
    .line 84
    iget-object v4, v3, Li80/n;->i:Ljava/lang/String;

    .line 85
    .line 86
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    const/16 v4, 0x5b

    .line 90
    .line 91
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    const-string v4, "] onData"

    .line 98
    .line 99
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    move-object v4, v3

    .line 107
    move-object v3, v2

    .line 108
    new-instance v2, Li80/k;

    .line 109
    .line 110
    invoke-direct/range {v2 .. v8}, Li80/k;-><init>(Ljava/lang/String;Li80/n;ILq80/i;IZ)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v0, v2, v10, v11}, Le80/b;->c(Le80/a;J)V

    .line 114
    .line 115
    .line 116
    goto/16 :goto_118

    .line 117
    .line 118
    :cond_75
    invoke-virtual {v3, v5}, Li80/n;->d(I)Li80/v;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    if-nez v3, :cond_90

    .line 123
    .line 124
    iget-object v3, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 125
    .line 126
    check-cast v3, Li80/n;

    .line 127
    .line 128
    const/4 v4, 0x2

    .line 129
    invoke-virtual {v3, v5, v4}, Li80/n;->n(II)V

    .line 130
    .line 131
    .line 132
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v0, Li80/n;

    .line 135
    .line 136
    int-to-long v3, v7

    .line 137
    invoke-virtual {v0, v3, v4}, Li80/n;->j(J)V

    .line 138
    .line 139
    .line 140
    invoke-interface {v2, v3, v4}, Lq80/k;->skip(J)V

    .line 141
    .line 142
    .line 143
    goto/16 :goto_118

    .line 144
    .line 145
    :cond_90
    sget-object v0, Lc80/b;->a:[B

    .line 146
    .line 147
    iget-object v0, v3, Li80/v;->i:Li80/t;

    .line 148
    .line 149
    int-to-long v12, v7

    .line 150
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 151
    .line 152
    .line 153
    move-wide v14, v12

    .line 154
    :goto_99
    cmp-long v5, v14, v10

    .line 155
    .line 156
    if-lez v5, :cond_107

    .line 157
    .line 158
    iget-object v5, v0, Li80/t;->x:Li80/v;

    .line 159
    .line 160
    monitor-enter v5

    .line 161
    :try_start_a0
    iget-boolean v7, v0, Li80/t;->e:Z

    .line 162
    .line 163
    iget-object v4, v0, Li80/t;->v:Lq80/i;

    .line 164
    .line 165
    move-wide/from16 p2, v10

    .line 166
    .line 167
    iget-wide v10, v4, Lq80/i;->e:J

    .line 168
    .line 169
    add-long/2addr v10, v14

    .line 170
    move/from16 p1, v7

    .line 171
    .line 172
    iget-wide v6, v0, Li80/t;->d:J
    :try_end_ad
    .catchall {:try_start_a0 .. :try_end_ad} :catchall_104

    .line 173
    .line 174
    cmp-long v6, v10, v6

    .line 175
    .line 176
    if-lez v6, :cond_b3

    .line 177
    .line 178
    const/4 v6, 0x1

    .line 179
    goto :goto_b4

    .line 180
    :cond_b3
    const/4 v6, 0x0

    .line 181
    :goto_b4
    monitor-exit v5

    .line 182
    if-eqz v6, :cond_c1

    .line 183
    .line 184
    invoke-interface {v2, v14, v15}, Lq80/k;->skip(J)V

    .line 185
    .line 186
    .line 187
    iget-object v0, v0, Li80/t;->x:Li80/v;

    .line 188
    .line 189
    const/4 v2, 0x4

    .line 190
    invoke-virtual {v0, v2}, Li80/v;->e(I)V

    .line 191
    .line 192
    .line 193
    goto :goto_110

    .line 194
    :cond_c1
    if-eqz p1, :cond_c7

    .line 195
    .line 196
    invoke-interface {v2, v14, v15}, Lq80/k;->skip(J)V

    .line 197
    .line 198
    .line 199
    goto :goto_110

    .line 200
    :cond_c7
    iget-object v5, v0, Li80/t;->i:Lq80/i;

    .line 201
    .line 202
    invoke-interface {v2, v5, v14, v15}, Lq80/c0;->b0(Lq80/i;J)J

    .line 203
    .line 204
    .line 205
    move-result-wide v5

    .line 206
    const-wide/16 v10, -0x1

    .line 207
    .line 208
    cmp-long v7, v5, v10

    .line 209
    .line 210
    if-eqz v7, :cond_fe

    .line 211
    .line 212
    sub-long/2addr v14, v5

    .line 213
    iget-object v5, v0, Li80/t;->x:Li80/v;

    .line 214
    .line 215
    monitor-enter v5

    .line 216
    :try_start_d7
    iget-boolean v6, v0, Li80/t;->w:Z

    .line 217
    .line 218
    if-eqz v6, :cond_e3

    .line 219
    .line 220
    iget-object v6, v0, Li80/t;->i:Lq80/i;

    .line 221
    .line 222
    invoke-virtual {v6}, Lq80/i;->c()V

    .line 223
    .line 224
    .line 225
    goto :goto_f8

    .line 226
    :catchall_e1
    move-exception v0

    .line 227
    goto :goto_fc

    .line 228
    :cond_e3
    iget-object v6, v0, Li80/t;->v:Lq80/i;

    .line 229
    .line 230
    iget-wide v10, v6, Lq80/i;->e:J

    .line 231
    .line 232
    cmp-long v7, v10, p2

    .line 233
    .line 234
    if-nez v7, :cond_ed

    .line 235
    .line 236
    const/4 v7, 0x1

    .line 237
    goto :goto_ee

    .line 238
    :cond_ed
    const/4 v7, 0x0

    .line 239
    :goto_ee
    iget-object v10, v0, Li80/t;->i:Lq80/i;

    .line 240
    .line 241
    invoke-virtual {v6, v10}, Lq80/i;->d0(Lq80/c0;)J

    .line 242
    .line 243
    .line 244
    if-eqz v7, :cond_f8

    .line 245
    .line 246
    invoke-virtual {v5}, Ljava/lang/Object;->notifyAll()V
    :try_end_f8
    .catchall {:try_start_d7 .. :try_end_f8} :catchall_e1

    .line 247
    .line 248
    .line 249
    :cond_f8
    :goto_f8
    monitor-exit v5

    .line 250
    move-wide/from16 v10, p2

    .line 251
    .line 252
    goto :goto_99

    .line 253
    :goto_fc
    monitor-exit v5

    .line 254
    throw v0

    .line 255
    :cond_fe
    new-instance v0, Ljava/io/EOFException;

    .line 256
    .line 257
    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    .line 258
    .line 259
    .line 260
    throw v0

    .line 261
    :catchall_104
    move-exception v0

    .line 262
    monitor-exit v5

    .line 263
    throw v0

    .line 264
    :cond_107
    iget-object v0, v0, Li80/t;->x:Li80/v;

    .line 265
    .line 266
    sget-object v2, Lc80/b;->a:[B

    .line 267
    .line 268
    iget-object v0, v0, Li80/v;->b:Li80/n;

    .line 269
    .line 270
    invoke-virtual {v0, v12, v13}, Li80/n;->j(J)V

    .line 271
    .line 272
    .line 273
    :goto_110
    if-eqz v8, :cond_118

    .line 274
    .line 275
    sget-object v0, Lc80/b;->b:Lb80/y;

    .line 276
    .line 277
    const/4 v4, 0x1

    .line 278
    invoke-virtual {v3, v0, v4}, Li80/v;->i(Lb80/y;Z)V

    .line 279
    .line 280
    .line 281
    :cond_118
    :goto_118
    iget-object v0, v1, Li80/r;->d:Lq80/k;

    .line 282
    .line 283
    int-to-long v2, v9

    .line 284
    invoke-interface {v0, v2, v3}, Lq80/k;->skip(J)V

    .line 285
    .line 286
    .line 287
    return-void

    .line 288
    :cond_11f
    new-instance v0, Ljava/io/IOException;

    .line 289
    .line 290
    const-string v2, "PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA"

    .line 291
    .line 292
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    throw v0

    .line 296
    :cond_127
    new-instance v0, Ljava/io/IOException;

    .line 297
    .line 298
    const-string v2, "PROTOCOL_ERROR: TYPE_DATA streamId == 0"

    .line 299
    .line 300
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    throw v0
.end method

.method public final g(IIII)Ljava/util/List;
    .registers 8

    .line 1
    iget-object v0, p0, Li80/r;->e:Li80/q;

    .line 2
    .line 3
    iput p1, v0, Li80/q;->w:I

    .line 4
    .line 5
    iput p1, v0, Li80/q;->e:I

    .line 6
    .line 7
    iput p2, v0, Li80/q;->x:I

    .line 8
    .line 9
    iput p3, v0, Li80/q;->i:I

    .line 10
    .line 11
    iput p4, v0, Li80/q;->v:I

    .line 12
    .line 13
    iget-object p1, p0, Li80/r;->i:Li80/c;

    .line 14
    .line 15
    iget-object p2, p1, Li80/c;->c:Lq80/w;

    .line 16
    .line 17
    iget-object p3, p1, Li80/c;->b:Ljava/util/ArrayList;

    .line 18
    .line 19
    :cond_12
    :goto_12
    invoke-virtual {p2}, Lq80/w;->c()Z

    .line 20
    .line 21
    .line 22
    move-result p4

    .line 23
    if-nez p4, :cond_126

    .line 24
    .line 25
    invoke-virtual {p2}, Lq80/w;->readByte()B

    .line 26
    .line 27
    .line 28
    move-result p4

    .line 29
    sget-object v0, Lc80/b;->a:[B

    .line 30
    .line 31
    and-int/lit16 v0, p4, 0xff

    .line 32
    .line 33
    const/16 v1, 0x80

    .line 34
    .line 35
    if-eq v0, v1, :cond_11e

    .line 36
    .line 37
    and-int/lit16 v2, p4, 0x80

    .line 38
    .line 39
    if-ne v2, v1, :cond_64

    .line 40
    .line 41
    const/16 p4, 0x7f

    .line 42
    .line 43
    invoke-virtual {p1, v0, p4}, Li80/c;->e(II)I

    .line 44
    .line 45
    .line 46
    move-result p4

    .line 47
    add-int/lit8 v0, p4, -0x1

    .line 48
    .line 49
    if-ltz v0, :cond_3f

    .line 50
    .line 51
    sget-object v1, Li80/e;->a:[Li80/b;

    .line 52
    .line 53
    array-length v2, v1

    .line 54
    add-int/lit8 v2, v2, -0x1

    .line 55
    .line 56
    if-gt v0, v2, :cond_3f

    .line 57
    .line 58
    aget-object p4, v1, v0

    .line 59
    .line 60
    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    goto :goto_12

    .line 64
    :cond_3f
    sget-object v1, Li80/e;->a:[Li80/b;

    .line 65
    .line 66
    array-length v1, v1

    .line 67
    sub-int/2addr v0, v1

    .line 68
    iget v1, p1, Li80/c;->e:I

    .line 69
    .line 70
    add-int/lit8 v1, v1, 0x1

    .line 71
    .line 72
    add-int/2addr v1, v0

    .line 73
    if-ltz v1, :cond_58

    .line 74
    .line 75
    iget-object v0, p1, Li80/c;->d:[Li80/b;

    .line 76
    .line 77
    array-length v2, v0

    .line 78
    if-ge v1, v2, :cond_58

    .line 79
    .line 80
    aget-object p4, v0, v1

    .line 81
    .line 82
    invoke-static {p4}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p3, p4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    goto :goto_12

    .line 89
    :cond_58
    new-instance p1, Ljava/io/IOException;

    .line 90
    .line 91
    const-string p2, "Header index too large "

    .line 92
    .line 93
    invoke-static {p4, p2}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object p2

    .line 97
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    throw p1

    .line 101
    :cond_64
    const/16 v1, 0x40

    .line 102
    .line 103
    if-ne v0, v1, :cond_7e

    .line 104
    .line 105
    sget-object p4, Li80/e;->a:[Li80/b;

    .line 106
    .line 107
    invoke-virtual {p1}, Li80/c;->d()Lq80/l;

    .line 108
    .line 109
    .line 110
    move-result-object p4

    .line 111
    invoke-static {p4}, Li80/e;->a(Lq80/l;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {p1}, Li80/c;->d()Lq80/l;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    new-instance v1, Li80/b;

    .line 119
    .line 120
    invoke-direct {v1, p4, v0}, Li80/b;-><init>(Lq80/l;Lq80/l;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {p1, v1}, Li80/c;->c(Li80/b;)V

    .line 124
    .line 125
    .line 126
    goto :goto_12

    .line 127
    :cond_7e
    and-int/lit8 v2, p4, 0x40

    .line 128
    .line 129
    if-ne v2, v1, :cond_9c

    .line 130
    .line 131
    const/16 p4, 0x3f

    .line 132
    .line 133
    invoke-virtual {p1, v0, p4}, Li80/c;->e(II)I

    .line 134
    .line 135
    .line 136
    move-result p4

    .line 137
    add-int/lit8 p4, p4, -0x1

    .line 138
    .line 139
    invoke-virtual {p1, p4}, Li80/c;->b(I)Lq80/l;

    .line 140
    .line 141
    .line 142
    move-result-object p4

    .line 143
    invoke-virtual {p1}, Li80/c;->d()Lq80/l;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    new-instance v1, Li80/b;

    .line 148
    .line 149
    invoke-direct {v1, p4, v0}, Li80/b;-><init>(Lq80/l;Lq80/l;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {p1, v1}, Li80/c;->c(Li80/b;)V

    .line 153
    .line 154
    .line 155
    goto/16 :goto_12

    .line 156
    .line 157
    :cond_9c
    and-int/lit8 p4, p4, 0x20

    .line 158
    .line 159
    const/16 v1, 0x20

    .line 160
    .line 161
    if-ne p4, v1, :cond_e6

    .line 162
    .line 163
    const/16 p4, 0x1f

    .line 164
    .line 165
    invoke-virtual {p1, v0, p4}, Li80/c;->e(II)I

    .line 166
    .line 167
    .line 168
    move-result p4

    .line 169
    iput p4, p1, Li80/c;->a:I

    .line 170
    .line 171
    if-ltz p4, :cond_d0

    .line 172
    .line 173
    const/16 v0, 0x1000

    .line 174
    .line 175
    if-gt p4, v0, :cond_d0

    .line 176
    .line 177
    iget v0, p1, Li80/c;->g:I

    .line 178
    .line 179
    if-ge p4, v0, :cond_12

    .line 180
    .line 181
    if-nez p4, :cond_ca

    .line 182
    .line 183
    iget-object p4, p1, Li80/c;->d:[Li80/b;

    .line 184
    .line 185
    const/4 v0, 0x0

    .line 186
    invoke-static {p4, v0}, Lm30/k;->d0([Ljava/lang/Object;La6/q0;)V

    .line 187
    .line 188
    .line 189
    iget-object p4, p1, Li80/c;->d:[Li80/b;

    .line 190
    .line 191
    array-length p4, p4

    .line 192
    add-int/lit8 p4, p4, -0x1

    .line 193
    .line 194
    iput p4, p1, Li80/c;->e:I

    .line 195
    .line 196
    const/4 p4, 0x0

    .line 197
    iput p4, p1, Li80/c;->f:I

    .line 198
    .line 199
    iput p4, p1, Li80/c;->g:I

    .line 200
    .line 201
    goto/16 :goto_12

    .line 202
    .line 203
    :cond_ca
    sub-int/2addr v0, p4

    .line 204
    invoke-virtual {p1, v0}, Li80/c;->a(I)I

    .line 205
    .line 206
    .line 207
    goto/16 :goto_12

    .line 208
    .line 209
    :cond_d0
    new-instance p2, Ljava/io/IOException;

    .line 210
    .line 211
    new-instance p3, Ljava/lang/StringBuilder;

    .line 212
    .line 213
    const-string p4, "Invalid dynamic table size update "

    .line 214
    .line 215
    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 216
    .line 217
    .line 218
    iget p1, p1, Li80/c;->a:I

    .line 219
    .line 220
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 221
    .line 222
    .line 223
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    throw p2

    .line 231
    :cond_e6
    const/16 p4, 0x10

    .line 232
    .line 233
    if-eq v0, p4, :cond_107

    .line 234
    .line 235
    if-nez v0, :cond_ed

    .line 236
    .line 237
    goto :goto_107

    .line 238
    :cond_ed
    const/16 p4, 0xf

    .line 239
    .line 240
    invoke-virtual {p1, v0, p4}, Li80/c;->e(II)I

    .line 241
    .line 242
    .line 243
    move-result p4

    .line 244
    add-int/lit8 p4, p4, -0x1

    .line 245
    .line 246
    invoke-virtual {p1, p4}, Li80/c;->b(I)Lq80/l;

    .line 247
    .line 248
    .line 249
    move-result-object p4

    .line 250
    invoke-virtual {p1}, Li80/c;->d()Lq80/l;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    new-instance v1, Li80/b;

    .line 255
    .line 256
    invoke-direct {v1, p4, v0}, Li80/b;-><init>(Lq80/l;Lq80/l;)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    goto/16 :goto_12

    .line 263
    .line 264
    :cond_107
    :goto_107
    sget-object p4, Li80/e;->a:[Li80/b;

    .line 265
    .line 266
    invoke-virtual {p1}, Li80/c;->d()Lq80/l;

    .line 267
    .line 268
    .line 269
    move-result-object p4

    .line 270
    invoke-static {p4}, Li80/e;->a(Lq80/l;)V

    .line 271
    .line 272
    .line 273
    invoke-virtual {p1}, Li80/c;->d()Lq80/l;

    .line 274
    .line 275
    .line 276
    move-result-object v0

    .line 277
    new-instance v1, Li80/b;

    .line 278
    .line 279
    invoke-direct {v1, p4, v0}, Li80/b;-><init>(Lq80/l;Lq80/l;)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    goto/16 :goto_12

    .line 286
    .line 287
    :cond_11e
    new-instance p1, Ljava/io/IOException;

    .line 288
    .line 289
    const-string p2, "index == 0"

    .line 290
    .line 291
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    throw p1

    .line 295
    :cond_126
    invoke-static {p3}, Lm30/q;->S0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 296
    .line 297
    .line 298
    move-result-object p1

    .line 299
    invoke-virtual {p3}, Ljava/util/ArrayList;->clear()V

    .line 300
    .line 301
    .line 302
    return-object p1
.end method

.method public final i(Lbg/v;III)V
    .registers 14

    .line 1
    if-eqz p4, :cond_d1

    .line 2
    .line 3
    and-int/lit8 v0, p3, 0x1

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    if-eqz v0, :cond_a

    .line 8
    .line 9
    move v7, v2

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    move v7, v1

    .line 12
    :goto_b
    and-int/lit8 v0, p3, 0x8

    .line 13
    .line 14
    if-eqz v0, :cond_19

    .line 15
    .line 16
    iget-object v0, p0, Li80/r;->d:Lq80/k;

    .line 17
    .line 18
    invoke-interface {v0}, Lq80/k;->readByte()B

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    sget-object v1, Lc80/b;->a:[B

    .line 23
    .line 24
    and-int/lit16 v1, v0, 0xff

    .line 25
    .line 26
    :cond_19
    and-int/lit8 v0, p3, 0x20

    .line 27
    .line 28
    if-eqz v0, :cond_29

    .line 29
    .line 30
    iget-object v0, p0, Li80/r;->d:Lq80/k;

    .line 31
    .line 32
    invoke-interface {v0}, Lq80/k;->readInt()I

    .line 33
    .line 34
    .line 35
    invoke-interface {v0}, Lq80/k;->readByte()B

    .line 36
    .line 37
    .line 38
    sget-object v0, Lc80/b;->a:[B

    .line 39
    .line 40
    add-int/lit8 p2, p2, -0x5

    .line 41
    .line 42
    :cond_29
    invoke-static {p2, p3, v1}, Li80/p;->a(III)I

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    invoke-virtual {p0, p2, v1, p3, p4}, Li80/r;->g(IIII)Ljava/util/List;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    iget-object p1, p1, Lbg/v;->i:Ljava/lang/Object;

    .line 51
    .line 52
    move-object v5, p1

    .line 53
    check-cast v5, Li80/n;

    .line 54
    .line 55
    const-wide/16 v0, 0x0

    .line 56
    .line 57
    const/16 p1, 0x5b

    .line 58
    .line 59
    if-eqz p4, :cond_67

    .line 60
    .line 61
    and-int/lit8 p3, p4, 0x1

    .line 62
    .line 63
    if-nez p3, :cond_67

    .line 64
    .line 65
    iget-object p3, v5, Li80/n;->K:Le80/b;

    .line 66
    .line 67
    new-instance v2, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 70
    .line 71
    .line 72
    iget-object v3, v5, Li80/n;->i:Ljava/lang/String;

    .line 73
    .line 74
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    const-string p1, "] onHeaders"

    .line 84
    .line 85
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    new-instance v3, Li80/l;

    .line 93
    .line 94
    move v6, p4

    .line 95
    move v8, v7

    .line 96
    move-object v7, p2

    .line 97
    invoke-direct/range {v3 .. v8}, Li80/l;-><init>(Ljava/lang/String;Li80/n;ILjava/util/List;Z)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p3, v3, v0, v1}, Le80/b;->c(Le80/a;J)V

    .line 101
    .line 102
    .line 103
    return-void

    .line 104
    :cond_67
    move v4, p4

    .line 105
    monitor-enter v5

    .line 106
    :try_start_69
    invoke-virtual {v5, v4}, Li80/n;->d(I)Li80/v;

    .line 107
    .line 108
    .line 109
    move-result-object p3

    .line 110
    if-nez p3, :cond_c6

    .line 111
    .line 112
    iget-boolean p3, v5, Li80/n;->x:Z
    :try_end_71
    .catchall {:try_start_69 .. :try_end_71} :catchall_c3

    .line 113
    .line 114
    if-eqz p3, :cond_75

    .line 115
    .line 116
    monitor-exit v5

    .line 117
    return-void

    .line 118
    :cond_75
    :try_start_75
    iget p3, v5, Li80/n;->v:I
    :try_end_77
    .catchall {:try_start_75 .. :try_end_77} :catchall_c3

    .line 119
    .line 120
    if-gt v4, p3, :cond_7b

    .line 121
    .line 122
    monitor-exit v5

    .line 123
    return-void

    .line 124
    :cond_7b
    :try_start_7b
    rem-int/lit8 p4, v4, 0x2

    .line 125
    .line 126
    iget p3, v5, Li80/n;->w:I

    .line 127
    .line 128
    rem-int/lit8 p3, p3, 0x2
    :try_end_81
    .catchall {:try_start_7b .. :try_end_81} :catchall_c3

    .line 129
    .line 130
    if-ne p4, p3, :cond_85

    .line 131
    .line 132
    monitor-exit v5

    .line 133
    return-void

    .line 134
    :cond_85
    :try_start_85
    invoke-static {p2}, Lc80/b;->u(Ljava/util/List;)Lb80/y;

    .line 135
    .line 136
    .line 137
    move-result-object v8

    .line 138
    new-instance v3, Li80/v;

    .line 139
    .line 140
    const/4 v6, 0x0

    .line 141
    invoke-direct/range {v3 .. v8}, Li80/v;-><init>(ILi80/n;ZZLb80/y;)V

    .line 142
    .line 143
    .line 144
    iput v4, v5, Li80/n;->v:I

    .line 145
    .line 146
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    .line 148
    .line 149
    move-result-object p2

    .line 150
    iget-object p3, v5, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 151
    .line 152
    invoke-interface {p3, p2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    iget-object p2, v5, Li80/n;->y:Le80/c;

    .line 156
    .line 157
    invoke-virtual {p2}, Le80/c;->e()Le80/b;

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    new-instance p3, Ljava/lang/StringBuilder;

    .line 162
    .line 163
    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    .line 164
    .line 165
    .line 166
    iget-object p4, v5, Li80/n;->i:Ljava/lang/String;

    .line 167
    .line 168
    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {p3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    const-string p1, "] onStream"

    .line 178
    .line 179
    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object p1

    .line 186
    new-instance p3, Li80/i;

    .line 187
    .line 188
    invoke-direct {p3, p1, v5, v3, v2}, Li80/i;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p2, p3, v0, v1}, Le80/b;->c(Le80/a;J)V
    :try_end_c1
    .catchall {:try_start_85 .. :try_end_c1} :catchall_c3

    .line 192
    .line 193
    .line 194
    monitor-exit v5

    .line 195
    return-void

    .line 196
    :catchall_c3
    move-exception v0

    .line 197
    move-object p1, v0

    .line 198
    goto :goto_cf

    .line 199
    :cond_c6
    monitor-exit v5

    .line 200
    invoke-static {p2}, Lc80/b;->u(Ljava/util/List;)Lb80/y;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    invoke-virtual {p3, p1, v7}, Li80/v;->i(Lb80/y;Z)V

    .line 205
    .line 206
    .line 207
    return-void

    .line 208
    :goto_cf
    monitor-exit v5

    .line 209
    throw p1

    .line 210
    :cond_d1
    new-instance p1, Ljava/io/IOException;

    .line 211
    .line 212
    const-string p2, "PROTOCOL_ERROR: TYPE_HEADERS streamId == 0"

    .line 213
    .line 214
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    throw p1
.end method

.method public final j(Lbg/v;III)V
    .registers 8

    .line 1
    if-eqz p4, :cond_73

    .line 2
    .line 3
    and-int/lit8 v0, p3, 0x8

    .line 4
    .line 5
    if-eqz v0, :cond_11

    .line 6
    .line 7
    iget-object v0, p0, Li80/r;->d:Lq80/k;

    .line 8
    .line 9
    invoke-interface {v0}, Lq80/k;->readByte()B

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    sget-object v1, Lc80/b;->a:[B

    .line 14
    .line 15
    and-int/lit16 v0, v0, 0xff

    .line 16
    .line 17
    goto :goto_12

    .line 18
    :cond_11
    const/4 v0, 0x0

    .line 19
    :goto_12
    iget-object v1, p0, Li80/r;->d:Lq80/k;

    .line 20
    .line 21
    invoke-interface {v1}, Lq80/k;->readInt()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const v2, 0x7fffffff

    .line 26
    .line 27
    .line 28
    and-int/2addr v1, v2

    .line 29
    add-int/lit8 p2, p2, -0x4

    .line 30
    .line 31
    invoke-static {p2, p3, v0}, Li80/p;->a(III)I

    .line 32
    .line 33
    .line 34
    move-result p2

    .line 35
    invoke-virtual {p0, p2, v0, p3, p4}, Li80/r;->g(IIII)Ljava/util/List;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    iget-object p1, p1, Lbg/v;->i:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p1, Li80/n;

    .line 42
    .line 43
    monitor-enter p1

    .line 44
    :try_start_2b
    iget-object p3, p1, Li80/n;->a0:Ljava/util/LinkedHashSet;

    .line 45
    .line 46
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object p4

    .line 50
    invoke-interface {p3, p4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result p3

    .line 54
    if-eqz p3, :cond_3f

    .line 55
    .line 56
    const/4 p2, 0x2

    .line 57
    invoke-virtual {p1, v1, p2}, Li80/n;->n(II)V
    :try_end_3b
    .catchall {:try_start_2b .. :try_end_3b} :catchall_3d

    .line 58
    .line 59
    .line 60
    monitor-exit p1

    .line 61
    return-void

    .line 62
    :catchall_3d
    move-exception p2

    .line 63
    goto :goto_71

    .line 64
    :cond_3f
    :try_start_3f
    iget-object p3, p1, Li80/n;->a0:Ljava/util/LinkedHashSet;

    .line 65
    .line 66
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 67
    .line 68
    .line 69
    move-result-object p4

    .line 70
    invoke-interface {p3, p4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_48
    .catchall {:try_start_3f .. :try_end_48} :catchall_3d

    .line 71
    .line 72
    .line 73
    monitor-exit p1

    .line 74
    iget-object p3, p1, Li80/n;->K:Le80/b;

    .line 75
    .line 76
    new-instance p4, Ljava/lang/StringBuilder;

    .line 77
    .line 78
    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    .line 79
    .line 80
    .line 81
    iget-object v0, p1, Li80/n;->i:Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    const/16 v0, 0x5b

    .line 87
    .line 88
    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-virtual {p4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    const-string v0, "] onRequest"

    .line 95
    .line 96
    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p4

    .line 103
    new-instance v0, Li80/l;

    .line 104
    .line 105
    invoke-direct {v0, p4, p1, v1, p2}, Li80/l;-><init>(Ljava/lang/String;Li80/n;ILjava/util/List;)V

    .line 106
    .line 107
    .line 108
    const-wide/16 p1, 0x0

    .line 109
    .line 110
    invoke-virtual {p3, v0, p1, p2}, Le80/b;->c(Le80/a;J)V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :goto_71
    monitor-exit p1

    .line 115
    throw p2

    .line 116
    :cond_73
    new-instance p1, Ljava/io/IOException;

    .line 117
    .line 118
    const-string p2, "PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0"

    .line 119
    .line 120
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw p1
.end method
