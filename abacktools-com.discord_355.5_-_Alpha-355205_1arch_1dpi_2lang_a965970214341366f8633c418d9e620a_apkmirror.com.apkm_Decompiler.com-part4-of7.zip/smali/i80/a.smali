###### Class i80.a (i80.a)
.class public final Li80/a;
.super Ljava/io/IOException;
.source "SourceFile"
