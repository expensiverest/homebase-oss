###### Class i80.i (i80.i)
.class public final Li80/i;
.super Le80/a;
.source "SourceFile"


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    .line 1
    iput p4, p0, Li80/i;->e:I

    iput-object p2, p0, Li80/i;->f:Ljava/lang/Object;

    iput-object p3, p0, Li80/i;->g:Ljava/lang/Object;

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Le80/a;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public final a()J
    .registers 19

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Li80/i;->e:I

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    packed-switch v0, :pswitch_data_102

    .line 7
    .line 8
    .line 9
    iget-object v0, v1, Li80/i;->f:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lbg/v;

    .line 12
    .line 13
    iget-object v5, v1, Li80/i;->g:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v5, Li80/z;

    .line 16
    .line 17
    new-instance v6, Lkotlin/jvm/internal/u;

    .line 18
    .line 19
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    iget-object v0, v0, Lbg/v;->i:Ljava/lang/Object;

    .line 23
    .line 24
    move-object v7, v0

    .line 25
    check-cast v7, Li80/n;

    .line 26
    .line 27
    iget-object v8, v7, Li80/n;->Y:Li80/w;

    .line 28
    .line 29
    monitor-enter v8

    .line 30
    :try_start_1d
    monitor-enter v7
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_91

    .line 31
    :try_start_1e
    iget-object v0, v7, Li80/n;->S:Li80/z;

    .line 32
    .line 33
    new-instance v9, Li80/z;

    .line 34
    .line 35
    invoke-direct {v9}, Li80/z;-><init>()V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v9, v0}, Li80/z;->b(Li80/z;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v9, v5}, Li80/z;->b(Li80/z;)V

    .line 42
    .line 43
    .line 44
    iput-object v9, v6, Lkotlin/jvm/internal/u;->d:Ljava/lang/Object;

    .line 45
    .line 46
    invoke-virtual {v9}, Li80/z;->a()I

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    int-to-long v9, v5

    .line 51
    invoke-virtual {v0}, Li80/z;->a()I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    int-to-long v11, v0

    .line 56
    sub-long/2addr v9, v11

    .line 57
    const-wide/16 v11, 0x0

    .line 58
    .line 59
    cmp-long v5, v9, v11

    .line 60
    .line 61
    const/4 v13, 0x0

    .line 62
    if-eqz v5, :cond_5a

    .line 63
    .line 64
    iget-object v0, v7, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 65
    .line 66
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_48

    .line 71
    .line 72
    goto :goto_5a

    .line 73
    :cond_48
    iget-object v0, v7, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 74
    .line 75
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    new-array v14, v13, [Li80/v;

    .line 80
    .line 81
    invoke-interface {v0, v14}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    check-cast v0, [Li80/v;

    .line 86
    .line 87
    :goto_56
    move-object v14, v0

    .line 88
    goto :goto_5c

    .line 89
    :catchall_58
    move-exception v0

    .line 90
    goto :goto_b2

    .line 91
    :cond_5a
    :goto_5a
    const/4 v0, 0x0

    .line 92
    goto :goto_56

    .line 93
    :goto_5c
    iget-object v0, v6, Lkotlin/jvm/internal/u;->d:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v0, Li80/z;

    .line 96
    .line 97
    const-string v15, "<set-?>"

    .line 98
    .line 99
    invoke-static {v0, v15}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    iput-object v0, v7, Li80/n;->S:Li80/z;

    .line 103
    .line 104
    iget-object v0, v7, Li80/n;->L:Le80/b;

    .line 105
    .line 106
    new-instance v15, Ljava/lang/StringBuilder;

    .line 107
    .line 108
    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    .line 109
    .line 110
    .line 111
    const-wide/16 v16, -0x1

    .line 112
    .line 113
    iget-object v3, v7, Li80/n;->i:Ljava/lang/String;

    .line 114
    .line 115
    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    const-string v3, " onSettings"

    .line 119
    .line 120
    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v3

    .line 127
    new-instance v4, Li80/i;

    .line 128
    .line 129
    invoke-direct {v4, v3, v7, v6, v13}, Li80/i;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v0, v4, v11, v12}, Le80/b;->c(Le80/a;J)V
    :try_end_86
    .catchall {:try_start_1e .. :try_end_86} :catchall_58

    .line 133
    .line 134
    .line 135
    :try_start_86
    monitor-exit v7
    :try_end_87
    .catchall {:try_start_86 .. :try_end_87} :catchall_91

    .line 136
    :try_start_87
    iget-object v0, v7, Li80/n;->Y:Li80/w;

    .line 137
    .line 138
    iget-object v3, v6, Lkotlin/jvm/internal/u;->d:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v3, Li80/z;

    .line 141
    .line 142
    invoke-virtual {v0, v3}, Li80/w;->c(Li80/z;)V
    :try_end_90
    .catch Ljava/io/IOException; {:try_start_87 .. :try_end_90} :catch_93
    .catchall {:try_start_87 .. :try_end_90} :catchall_91

    .line 143
    .line 144
    .line 145
    goto :goto_97

    .line 146
    :catchall_91
    move-exception v0

    .line 147
    goto :goto_b4

    .line 148
    :catch_93
    move-exception v0

    .line 149
    :try_start_94
    invoke-virtual {v7, v2, v2, v0}, Li80/n;->c(IILjava/io/IOException;)V
    :try_end_97
    .catchall {:try_start_94 .. :try_end_97} :catchall_91

    .line 150
    .line 151
    .line 152
    :goto_97
    monitor-exit v8

    .line 153
    if-eqz v14, :cond_b1

    .line 154
    .line 155
    array-length v0, v14

    .line 156
    :goto_9b
    if-ge v13, v0, :cond_b1

    .line 157
    .line 158
    aget-object v2, v14, v13

    .line 159
    .line 160
    monitor-enter v2

    .line 161
    :try_start_a0
    iget-wide v3, v2, Li80/v;->f:J

    .line 162
    .line 163
    add-long/2addr v3, v9

    .line 164
    iput-wide v3, v2, Li80/v;->f:J

    .line 165
    .line 166
    if-lez v5, :cond_aa

    .line 167
    .line 168
    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V
    :try_end_aa
    .catchall {:try_start_a0 .. :try_end_aa} :catchall_ae

    .line 169
    .line 170
    .line 171
    :cond_aa
    monitor-exit v2

    .line 172
    add-int/lit8 v13, v13, 0x1

    .line 173
    .line 174
    goto :goto_9b

    .line 175
    :catchall_ae
    move-exception v0

    .line 176
    monitor-exit v2

    .line 177
    throw v0

    .line 178
    :cond_b1
    return-wide v16

    .line 179
    :goto_b2
    :try_start_b2
    monitor-exit v7

    .line 180
    throw v0
    :try_end_b4
    .catchall {:try_start_b2 .. :try_end_b4} :catchall_91

    .line 181
    :goto_b4
    monitor-exit v8

    .line 182
    throw v0

    .line 183
    :pswitch_b6
    const-wide/16 v16, -0x1

    .line 184
    .line 185
    :try_start_b8
    iget-object v0, v1, Li80/i;->f:Ljava/lang/Object;

    .line 186
    .line 187
    check-cast v0, Li80/n;

    .line 188
    .line 189
    iget-object v0, v0, Li80/n;->d:Li80/h;

    .line 190
    .line 191
    iget-object v3, v1, Li80/i;->g:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v3, Li80/v;

    .line 194
    .line 195
    invoke-virtual {v0, v3}, Li80/h;->b(Li80/v;)V
    :try_end_c5
    .catch Ljava/io/IOException; {:try_start_b8 .. :try_end_c5} :catch_c6

    .line 196
    .line 197
    .line 198
    goto :goto_ed

    .line 199
    :catch_c6
    move-exception v0

    .line 200
    sget-object v3, Lk80/n;->a:Lk80/n;

    .line 201
    .line 202
    sget-object v3, Lk80/n;->a:Lk80/n;

    .line 203
    .line 204
    new-instance v4, Ljava/lang/StringBuilder;

    .line 205
    .line 206
    const-string v5, "Http2Connection.Listener failure for "

    .line 207
    .line 208
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    iget-object v5, v1, Li80/i;->f:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast v5, Li80/n;

    .line 214
    .line 215
    iget-object v5, v5, Li80/n;->i:Ljava/lang/String;

    .line 216
    .line 217
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 218
    .line 219
    .line 220
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v4

    .line 224
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 225
    .line 226
    .line 227
    const/4 v3, 0x4

    .line 228
    invoke-static {v3, v4, v0}, Lk80/n;->i(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 229
    .line 230
    .line 231
    :try_start_e6
    iget-object v3, v1, Li80/i;->g:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast v3, Li80/v;

    .line 234
    .line 235
    invoke-virtual {v3, v2, v0}, Li80/v;->c(ILjava/io/IOException;)V
    :try_end_ed
    .catch Ljava/io/IOException; {:try_start_e6 .. :try_end_ed} :catch_ed

    .line 236
    .line 237
    .line 238
    :catch_ed
    :goto_ed
    return-wide v16

    .line 239
    :pswitch_ee
    const-wide/16 v16, -0x1

    .line 240
    .line 241
    iget-object v0, v1, Li80/i;->f:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast v0, Li80/n;

    .line 244
    .line 245
    iget-object v2, v0, Li80/n;->d:Li80/h;

    .line 246
    .line 247
    iget-object v3, v1, Li80/i;->g:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v3, Lkotlin/jvm/internal/u;

    .line 250
    .line 251
    iget-object v3, v3, Lkotlin/jvm/internal/u;->d:Ljava/lang/Object;

    .line 252
    .line 253
    check-cast v3, Li80/z;

    .line 254
    .line 255
    invoke-virtual {v2, v0, v3}, Li80/h;->a(Li80/n;Li80/z;)V

    .line 256
    .line 257
    .line 258
    return-wide v16

    .line 259
    :pswitch_data_102
    .packed-switch 0x0
        :pswitch_ee
        :pswitch_b6
    .end packed-switch
.end method
