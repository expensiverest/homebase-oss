###### Class i80.t (i80.t)
.class public final Li80/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq80/c0;


# instance fields
.field public final d:J

.field public e:Z

.field public final i:Lq80/i;

.field public final v:Lq80/i;

.field public w:Z

.field public final synthetic x:Li80/v;


# direct methods
.method public constructor <init>(Li80/v;JZ)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li80/t;->x:Li80/v;

    .line 5
    .line 6
    iput-wide p2, p0, Li80/t;->d:J

    .line 7
    .line 8
    iput-boolean p4, p0, Li80/t;->e:Z

    .line 9
    .line 10
    new-instance p1, Lq80/i;

    .line 11
    .line 12
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Li80/t;->i:Lq80/i;

    .line 16
    .line 17
    new-instance p1, Lq80/i;

    .line 18
    .line 19
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, Li80/t;->v:Lq80/i;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final b0(Lq80/i;J)J
    .registers 13

    .line 1
    const-string p2, "sink"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    :goto_5
    iget-object p2, p0, Li80/t;->x:Li80/v;

    .line 7
    .line 8
    monitor-enter p2

    .line 9
    :try_start_8
    iget-object p3, p2, Li80/v;->k:Li80/u;

    .line 10
    .line 11
    invoke-virtual {p3}, Lq80/f;->i()V
    :try_end_d
    .catchall {:try_start_8 .. :try_end_d} :catchall_9b

    .line 12
    .line 13
    .line 14
    :try_start_d
    monitor-enter p2
    :try_end_e
    .catchall {:try_start_d .. :try_end_e} :catchall_28

    .line 15
    :try_start_e
    iget p3, p2, Li80/v;->m:I
    :try_end_10
    .catchall {:try_start_e .. :try_end_10} :catchall_a5

    .line 16
    .line 17
    :try_start_10
    monitor-exit p2

    .line 18
    if-eqz p3, :cond_2e

    .line 19
    .line 20
    iget-boolean p3, p0, Li80/t;->e:Z

    .line 21
    .line 22
    if-nez p3, :cond_2e

    .line 23
    .line 24
    iget-object p3, p2, Li80/v;->n:Ljava/io/IOException;

    .line 25
    .line 26
    if-nez p3, :cond_2f

    .line 27
    .line 28
    new-instance p3, Li80/a0;

    .line 29
    .line 30
    monitor-enter p2
    :try_end_1e
    .catchall {:try_start_10 .. :try_end_1e} :catchall_28

    .line 31
    :try_start_1e
    iget v0, p2, Li80/v;->m:I
    :try_end_20
    .catchall {:try_start_1e .. :try_end_20} :catchall_2b

    .line 32
    .line 33
    :try_start_20
    monitor-exit p2

    .line 34
    invoke-static {v0}, Lhs/q;->o(I)V

    .line 35
    .line 36
    .line 37
    invoke-direct {p3, v0}, Li80/a0;-><init>(I)V
    :try_end_27
    .catchall {:try_start_20 .. :try_end_27} :catchall_28

    .line 38
    .line 39
    .line 40
    goto :goto_2f

    .line 41
    :catchall_28
    move-exception p1

    .line 42
    goto/16 :goto_a8

    .line 43
    .line 44
    :catchall_2b
    move-exception p1

    .line 45
    :try_start_2c
    monitor-exit p2
    :try_end_2d
    .catchall {:try_start_2c .. :try_end_2d} :catchall_2b

    .line 46
    :try_start_2d
    throw p1

    .line 47
    :cond_2e
    const/4 p3, 0x0

    .line 48
    :cond_2f
    :goto_2f
    iget-boolean v0, p0, Li80/t;->w:Z

    .line 49
    .line 50
    if-nez v0, :cond_9d

    .line 51
    .line 52
    iget-object v0, p0, Li80/t;->v:Lq80/i;

    .line 53
    .line 54
    iget-wide v1, v0, Lq80/i;->e:J

    .line 55
    .line 56
    const-wide/16 v3, 0x0

    .line 57
    .line 58
    cmp-long v3, v1, v3

    .line 59
    .line 60
    const-wide/16 v4, -0x1

    .line 61
    .line 62
    const/4 v6, 0x0

    .line 63
    if-lez v3, :cond_6f

    .line 64
    .line 65
    const-wide/16 v7, 0x2000

    .line 66
    .line 67
    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->min(JJ)J

    .line 68
    .line 69
    .line 70
    move-result-wide v1

    .line 71
    invoke-virtual {v0, p1, v1, v2}, Lq80/i;->b0(Lq80/i;J)J

    .line 72
    .line 73
    .line 74
    move-result-wide v0

    .line 75
    iget-wide v2, p2, Li80/v;->c:J

    .line 76
    .line 77
    add-long/2addr v2, v0

    .line 78
    iput-wide v2, p2, Li80/v;->c:J

    .line 79
    .line 80
    iget-wide v7, p2, Li80/v;->d:J

    .line 81
    .line 82
    sub-long/2addr v2, v7

    .line 83
    if-nez p3, :cond_88

    .line 84
    .line 85
    iget-object v7, p2, Li80/v;->b:Li80/n;

    .line 86
    .line 87
    iget-object v7, v7, Li80/n;->R:Li80/z;

    .line 88
    .line 89
    invoke-virtual {v7}, Li80/z;->a()I

    .line 90
    .line 91
    .line 92
    move-result v7

    .line 93
    div-int/lit8 v7, v7, 0x2

    .line 94
    .line 95
    int-to-long v7, v7

    .line 96
    cmp-long v7, v2, v7

    .line 97
    .line 98
    if-ltz v7, :cond_88

    .line 99
    .line 100
    iget-object v7, p2, Li80/v;->b:Li80/n;

    .line 101
    .line 102
    iget v8, p2, Li80/v;->a:I

    .line 103
    .line 104
    invoke-virtual {v7, v8, v2, v3}, Li80/n;->u(IJ)V

    .line 105
    .line 106
    .line 107
    iget-wide v2, p2, Li80/v;->c:J

    .line 108
    .line 109
    iput-wide v2, p2, Li80/v;->d:J

    .line 110
    .line 111
    goto :goto_88

    .line 112
    :cond_6f
    iget-boolean v0, p0, Li80/t;->e:Z
    :try_end_71
    .catchall {:try_start_2d .. :try_end_71} :catchall_28

    .line 113
    .line 114
    if-nez v0, :cond_79

    .line 115
    .line 116
    if-nez p3, :cond_79

    .line 117
    .line 118
    :try_start_75
    invoke-virtual {p2}, Ljava/lang/Object;->wait()V
    :try_end_78
    .catch Ljava/lang/InterruptedException; {:try_start_75 .. :try_end_78} :catch_7b
    .catchall {:try_start_75 .. :try_end_78} :catchall_28

    .line 119
    .line 120
    .line 121
    const/4 v6, 0x1

    .line 122
    :cond_79
    move-wide v0, v4

    .line 123
    goto :goto_88

    .line 124
    :catch_7b
    :try_start_7b
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 129
    .line 130
    .line 131
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 132
    .line 133
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 134
    .line 135
    .line 136
    throw p1
    :try_end_88
    .catchall {:try_start_7b .. :try_end_88} :catchall_28

    .line 137
    :cond_88
    :goto_88
    :try_start_88
    iget-object v2, p2, Li80/v;->k:Li80/u;

    .line 138
    .line 139
    invoke-virtual {v2}, Li80/u;->l()V
    :try_end_8d
    .catchall {:try_start_88 .. :try_end_8d} :catchall_9b

    .line 140
    .line 141
    .line 142
    monitor-exit p2

    .line 143
    if-eqz v6, :cond_92

    .line 144
    .line 145
    goto/16 :goto_5

    .line 146
    .line 147
    :cond_92
    cmp-long p1, v0, v4

    .line 148
    .line 149
    if-eqz p1, :cond_97

    .line 150
    .line 151
    return-wide v0

    .line 152
    :cond_97
    if-nez p3, :cond_9a

    .line 153
    .line 154
    return-wide v4

    .line 155
    :cond_9a
    throw p3

    .line 156
    :catchall_9b
    move-exception p1

    .line 157
    goto :goto_ae

    .line 158
    :cond_9d
    :try_start_9d
    new-instance p1, Ljava/io/IOException;

    .line 159
    .line 160
    const-string p3, "stream closed"

    .line 161
    .line 162
    invoke-direct {p1, p3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    throw p1
    :try_end_a5
    .catchall {:try_start_9d .. :try_end_a5} :catchall_28

    .line 166
    :catchall_a5
    move-exception p1

    .line 167
    :try_start_a6
    monitor-exit p2
    :try_end_a7
    .catchall {:try_start_a6 .. :try_end_a7} :catchall_a5

    .line 168
    :try_start_a7
    throw p1
    :try_end_a8
    .catchall {:try_start_a7 .. :try_end_a8} :catchall_28

    .line 169
    :goto_a8
    :try_start_a8
    iget-object p3, p2, Li80/v;->k:Li80/u;

    .line 170
    .line 171
    invoke-virtual {p3}, Li80/u;->l()V

    .line 172
    .line 173
    .line 174
    throw p1
    :try_end_ae
    .catchall {:try_start_a8 .. :try_end_ae} :catchall_9b

    .line 175
    :goto_ae
    monitor-exit p2

    .line 176
    throw p1
.end method

.method public final close()V
    .registers 5

    .line 1
    iget-object v0, p0, Li80/t;->x:Li80/v;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    const/4 v1, 0x1

    .line 5
    :try_start_4
    iput-boolean v1, p0, Li80/t;->w:Z

    .line 6
    .line 7
    iget-object v1, p0, Li80/t;->v:Lq80/i;

    .line 8
    .line 9
    iget-wide v2, v1, Lq80/i;->e:J

    .line 10
    .line 11
    invoke-virtual {v1}, Lq80/i;->c()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V
    :try_end_10
    .catchall {:try_start_4 .. :try_end_10} :catchall_26

    .line 15
    .line 16
    .line 17
    monitor-exit v0

    .line 18
    const-wide/16 v0, 0x0

    .line 19
    .line 20
    cmp-long v0, v2, v0

    .line 21
    .line 22
    if-lez v0, :cond_20

    .line 23
    .line 24
    iget-object v0, p0, Li80/t;->x:Li80/v;

    .line 25
    .line 26
    sget-object v1, Lc80/b;->a:[B

    .line 27
    .line 28
    iget-object v0, v0, Li80/v;->b:Li80/n;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v3}, Li80/n;->j(J)V

    .line 31
    .line 32
    .line 33
    :cond_20
    iget-object v0, p0, Li80/t;->x:Li80/v;

    .line 34
    .line 35
    invoke-virtual {v0}, Li80/v;->a()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :catchall_26
    move-exception v1

    .line 40
    monitor-exit v0

    .line 41
    throw v1
.end method

.method public final timeout()Lq80/e0;
    .registers 2

    .line 1
    iget-object v0, p0, Li80/t;->x:Li80/v;

    .line 2
    .line 3
    iget-object v0, v0, Li80/v;->k:Li80/u;

    .line 4
    .line 5
    return-object v0
.end method
