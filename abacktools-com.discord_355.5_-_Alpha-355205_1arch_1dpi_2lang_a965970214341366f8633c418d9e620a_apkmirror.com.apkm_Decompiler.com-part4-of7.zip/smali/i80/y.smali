###### Class i80.y (i80.y)
.class public final Li80/y;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Li80/y;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Li80/y;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Li80/y;->a:Li80/y;

    .line 7
    .line 8
    return-void
.end method
