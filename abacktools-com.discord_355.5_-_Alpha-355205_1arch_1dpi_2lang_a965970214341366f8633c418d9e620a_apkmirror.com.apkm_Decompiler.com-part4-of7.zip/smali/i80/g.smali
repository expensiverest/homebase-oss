###### Class i80.g (i80.g)
.class public final Li80/g;
.super Li80/h;
.source "SourceFile"


# virtual methods
.method public final b(Li80/v;)V
    .registers 4

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p1, v0, v1}, Li80/v;->c(ILjava/io/IOException;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
