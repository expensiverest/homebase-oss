###### Class i80.n (i80.n)
.class public final Li80/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field public static final b0:Li80/z;


# instance fields
.field public final J:Le80/b;

.field public final K:Le80/b;

.field public final L:Le80/b;

.field public final M:Li80/y;

.field public N:J

.field public O:J

.field public P:J

.field public Q:J

.field public final R:Li80/z;

.field public S:Li80/z;

.field public T:J

.field public U:J

.field public V:J

.field public W:J

.field public final X:Ljava/net/Socket;

.field public final Y:Li80/w;

.field public final Z:Lbg/v;

.field public final a0:Ljava/util/LinkedHashSet;

.field public final d:Li80/h;

.field public final e:Ljava/util/LinkedHashMap;

.field public final i:Ljava/lang/String;

.field public v:I

.field public w:I

.field public x:Z

.field public final y:Le80/c;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Li80/z;

    .line 2
    .line 3
    invoke-direct {v0}, Li80/z;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x7

    .line 7
    const v2, 0xffff

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, v1, v2}, Li80/z;->c(II)V

    .line 11
    .line 12
    .line 13
    const/4 v1, 0x5

    .line 14
    const/16 v2, 0x4000

    .line 15
    .line 16
    invoke-virtual {v0, v1, v2}, Li80/z;->c(II)V

    .line 17
    .line 18
    .line 19
    sput-object v0, Li80/n;->b0:Li80/z;

    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>(Lb80/i0;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lb80/i0;->y:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v0, Li80/h;

    .line 7
    .line 8
    iput-object v0, p0, Li80/n;->d:Li80/h;

    .line 9
    .line 10
    new-instance v0, Ljava/util/LinkedHashMap;

    .line 11
    .line 12
    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 16
    .line 17
    iget-object v0, p1, Lb80/i0;->e:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/lang/String;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    if-eqz v0, :cond_94

    .line 23
    .line 24
    iput-object v0, p0, Li80/n;->i:Ljava/lang/String;

    .line 25
    .line 26
    const/4 v0, 0x3

    .line 27
    iput v0, p0, Li80/n;->w:I

    .line 28
    .line 29
    iget-object v0, p1, Lb80/i0;->i:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Le80/c;

    .line 32
    .line 33
    iput-object v0, p0, Li80/n;->y:Le80/c;

    .line 34
    .line 35
    invoke-virtual {v0}, Le80/c;->e()Le80/b;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    iput-object v2, p0, Li80/n;->J:Le80/b;

    .line 40
    .line 41
    invoke-virtual {v0}, Le80/c;->e()Le80/b;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    iput-object v2, p0, Li80/n;->K:Le80/b;

    .line 46
    .line 47
    invoke-virtual {v0}, Le80/c;->e()Le80/b;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    iput-object v0, p0, Li80/n;->L:Le80/b;

    .line 52
    .line 53
    sget-object v0, Li80/y;->a:Li80/y;

    .line 54
    .line 55
    iput-object v0, p0, Li80/n;->M:Li80/y;

    .line 56
    .line 57
    new-instance v0, Li80/z;

    .line 58
    .line 59
    invoke-direct {v0}, Li80/z;-><init>()V

    .line 60
    .line 61
    .line 62
    const/4 v2, 0x7

    .line 63
    const/high16 v3, 0x1000000

    .line 64
    .line 65
    invoke-virtual {v0, v2, v3}, Li80/z;->c(II)V

    .line 66
    .line 67
    .line 68
    iput-object v0, p0, Li80/n;->R:Li80/z;

    .line 69
    .line 70
    sget-object v0, Li80/n;->b0:Li80/z;

    .line 71
    .line 72
    iput-object v0, p0, Li80/n;->S:Li80/z;

    .line 73
    .line 74
    invoke-virtual {v0}, Li80/z;->a()I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    int-to-long v2, v0

    .line 79
    iput-wide v2, p0, Li80/n;->W:J

    .line 80
    .line 81
    iget-object v0, p1, Lb80/i0;->v:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v0, Ljava/net/Socket;

    .line 84
    .line 85
    if-eqz v0, :cond_8e

    .line 86
    .line 87
    iput-object v0, p0, Li80/n;->X:Ljava/net/Socket;

    .line 88
    .line 89
    new-instance v0, Li80/w;

    .line 90
    .line 91
    iget-object v2, p1, Lb80/i0;->x:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v2, Lq80/v;

    .line 94
    .line 95
    if-eqz v2, :cond_88

    .line 96
    .line 97
    invoke-direct {v0, v2}, Li80/w;-><init>(Lq80/v;)V

    .line 98
    .line 99
    .line 100
    iput-object v0, p0, Li80/n;->Y:Li80/w;

    .line 101
    .line 102
    new-instance v0, Lbg/v;

    .line 103
    .line 104
    new-instance v2, Li80/r;

    .line 105
    .line 106
    iget-object p1, p1, Lb80/i0;->w:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast p1, Lq80/w;

    .line 109
    .line 110
    if-eqz p1, :cond_82

    .line 111
    .line 112
    invoke-direct {v2, p1}, Li80/r;-><init>(Lq80/w;)V

    .line 113
    .line 114
    .line 115
    const/16 p1, 0xa

    .line 116
    .line 117
    const/4 v1, 0x0

    .line 118
    invoke-direct {v0, p0, v2, p1, v1}, Lbg/v;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 119
    .line 120
    .line 121
    iput-object v0, p0, Li80/n;->Z:Lbg/v;

    .line 122
    .line 123
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 124
    .line 125
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 126
    .line 127
    .line 128
    iput-object p1, p0, Li80/n;->a0:Ljava/util/LinkedHashSet;

    .line 129
    .line 130
    return-void

    .line 131
    :cond_82
    const-string p1, "source"

    .line 132
    .line 133
    invoke-static {p1}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    throw v1

    .line 137
    :cond_88
    const-string p1, "sink"

    .line 138
    .line 139
    invoke-static {p1}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    throw v1

    .line 143
    :cond_8e
    const-string p1, "socket"

    .line 144
    .line 145
    invoke-static {p1}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    throw v1

    .line 149
    :cond_94
    const-string p1, "connectionName"

    .line 150
    .line 151
    invoke-static {p1}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    throw v1
.end method


# virtual methods
.method public final c(IILjava/io/IOException;)V
    .registers 7

    .line 1
    const-string v0, "connectionCode"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lhs/q;->q(ILjava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "streamCode"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lhs/q;->q(ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, Lc80/b;->a:[B

    .line 12
    .line 13
    :try_start_c
    invoke-virtual {p0, p1}, Li80/n;->i(I)V
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_f} :catch_f

    .line 14
    .line 15
    .line 16
    :catch_f
    monitor-enter p0

    .line 17
    :try_start_10
    iget-object p1, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 18
    .line 19
    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v0, 0x0

    .line 24
    if-nez p1, :cond_2d

    .line 25
    .line 26
    iget-object p1, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 27
    .line 28
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    new-array v1, v0, [Li80/v;

    .line 33
    .line 34
    invoke-interface {p1, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iget-object v1, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->clear()V
    :try_end_2a
    .catchall {:try_start_10 .. :try_end_2a} :catchall_2b

    .line 41
    .line 42
    .line 43
    goto :goto_2e

    .line 44
    :catchall_2b
    move-exception p1

    .line 45
    goto :goto_58

    .line 46
    :cond_2d
    const/4 p1, 0x0

    .line 47
    :goto_2e
    monitor-exit p0

    .line 48
    check-cast p1, [Li80/v;

    .line 49
    .line 50
    if-eqz p1, :cond_3e

    .line 51
    .line 52
    array-length v1, p1

    .line 53
    :goto_34
    if-ge v0, v1, :cond_3e

    .line 54
    .line 55
    aget-object v2, p1, v0

    .line 56
    .line 57
    :try_start_38
    invoke-virtual {v2, p2, p3}, Li80/v;->c(ILjava/io/IOException;)V
    :try_end_3b
    .catch Ljava/io/IOException; {:try_start_38 .. :try_end_3b} :catch_3b

    .line 58
    .line 59
    .line 60
    :catch_3b
    add-int/lit8 v0, v0, 0x1

    .line 61
    .line 62
    goto :goto_34

    .line 63
    :cond_3e
    :try_start_3e
    iget-object p1, p0, Li80/n;->Y:Li80/w;

    .line 64
    .line 65
    invoke-virtual {p1}, Li80/w;->close()V
    :try_end_43
    .catch Ljava/io/IOException; {:try_start_3e .. :try_end_43} :catch_43

    .line 66
    .line 67
    .line 68
    :catch_43
    :try_start_43
    iget-object p1, p0, Li80/n;->X:Ljava/net/Socket;

    .line 69
    .line 70
    invoke-virtual {p1}, Ljava/net/Socket;->close()V
    :try_end_48
    .catch Ljava/io/IOException; {:try_start_43 .. :try_end_48} :catch_48

    .line 71
    .line 72
    .line 73
    :catch_48
    iget-object p1, p0, Li80/n;->J:Le80/b;

    .line 74
    .line 75
    invoke-virtual {p1}, Le80/b;->f()V

    .line 76
    .line 77
    .line 78
    iget-object p1, p0, Li80/n;->K:Le80/b;

    .line 79
    .line 80
    invoke-virtual {p1}, Le80/b;->f()V

    .line 81
    .line 82
    .line 83
    iget-object p1, p0, Li80/n;->L:Le80/b;

    .line 84
    .line 85
    invoke-virtual {p1}, Le80/b;->f()V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :goto_58
    monitor-exit p0

    .line 90
    throw p1
.end method

.method public final close()V
    .registers 4

    .line 1
    const/16 v0, 0x9

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-virtual {p0, v2, v0, v1}, Li80/n;->c(IILjava/io/IOException;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final declared-synchronized d(I)Li80/v;
    .registers 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Li80/v;
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_f

    .line 13
    .line 14
    monitor-exit p0

    .line 15
    return-object p1

    .line 16
    :catchall_f
    move-exception p1

    .line 17
    :try_start_10
    monitor-exit p0
    :try_end_11
    .catchall {:try_start_10 .. :try_end_11} :catchall_f

    .line 18
    throw p1
.end method

.method public final flush()V
    .registers 2

    .line 1
    iget-object v0, p0, Li80/n;->Y:Li80/w;

    .line 2
    .line 3
    invoke-virtual {v0}, Li80/w;->flush()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final declared-synchronized g(I)Li80/v;
    .registers 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Li80/v;

    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_10
    .catchall {:try_start_1 .. :try_end_10} :catchall_12

    .line 15
    .line 16
    .line 17
    monitor-exit p0

    .line 18
    return-object p1

    .line 19
    :catchall_12
    move-exception p1

    .line 20
    :try_start_13
    monitor-exit p0
    :try_end_14
    .catchall {:try_start_13 .. :try_end_14} :catchall_12

    .line 21
    throw p1
.end method

.method public final i(I)V
    .registers 6

    .line 1
    const-string v0, "statusCode"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lhs/q;->q(ILjava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li80/n;->Y:Li80/w;

    .line 7
    .line 8
    monitor-enter v0

    .line 9
    :try_start_8
    monitor-enter p0
    :try_end_9
    .catchall {:try_start_8 .. :try_end_9} :catchall_10

    .line 10
    :try_start_9
    iget-boolean v1, p0, Li80/n;->x:Z
    :try_end_b
    .catchall {:try_start_9 .. :try_end_b} :catchall_21

    .line 11
    .line 12
    if-eqz v1, :cond_12

    .line 13
    .line 14
    :try_start_d
    monitor-exit p0
    :try_end_e
    .catchall {:try_start_d .. :try_end_e} :catchall_10

    .line 15
    monitor-exit v0

    .line 16
    return-void

    .line 17
    :catchall_10
    move-exception p1

    .line 18
    goto :goto_24

    .line 19
    :cond_12
    const/4 v1, 0x1

    .line 20
    :try_start_13
    iput-boolean v1, p0, Li80/n;->x:Z

    .line 21
    .line 22
    iget v1, p0, Li80/n;->v:I
    :try_end_17
    .catchall {:try_start_13 .. :try_end_17} :catchall_21

    .line 23
    .line 24
    :try_start_17
    monitor-exit p0

    .line 25
    iget-object v2, p0, Li80/n;->Y:Li80/w;

    .line 26
    .line 27
    sget-object v3, Lc80/b;->a:[B

    .line 28
    .line 29
    invoke-virtual {v2, v3, v1, p1}, Li80/w;->i([BII)V
    :try_end_1f
    .catchall {:try_start_17 .. :try_end_1f} :catchall_10

    .line 30
    .line 31
    .line 32
    monitor-exit v0

    .line 33
    return-void

    .line 34
    :catchall_21
    move-exception p1

    .line 35
    :try_start_22
    monitor-exit p0

    .line 36
    throw p1
    :try_end_24
    .catchall {:try_start_22 .. :try_end_24} :catchall_10

    .line 37
    :goto_24
    monitor-exit v0

    .line 38
    throw p1
.end method

.method public final declared-synchronized j(J)V
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-wide v0, p0, Li80/n;->T:J

    .line 3
    .line 4
    add-long/2addr v0, p1

    .line 5
    iput-wide v0, p0, Li80/n;->T:J

    .line 6
    .line 7
    iget-wide p1, p0, Li80/n;->U:J

    .line 8
    .line 9
    sub-long/2addr v0, p1

    .line 10
    iget-object p1, p0, Li80/n;->R:Li80/z;

    .line 11
    .line 12
    invoke-virtual {p1}, Li80/z;->a()I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    div-int/lit8 p1, p1, 0x2

    .line 17
    .line 18
    int-to-long p1, p1

    .line 19
    cmp-long p1, v0, p1

    .line 20
    .line 21
    if-ltz p1, :cond_22

    .line 22
    .line 23
    const/4 p1, 0x0

    .line 24
    invoke-virtual {p0, p1, v0, v1}, Li80/n;->u(IJ)V

    .line 25
    .line 26
    .line 27
    iget-wide p1, p0, Li80/n;->U:J

    .line 28
    .line 29
    add-long/2addr p1, v0

    .line 30
    iput-wide p1, p0, Li80/n;->U:J
    :try_end_1f
    .catchall {:try_start_1 .. :try_end_1f} :catchall_20

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    goto :goto_24

    .line 35
    :cond_22
    :goto_22
    monitor-exit p0

    .line 36
    return-void

    .line 37
    :goto_24
    :try_start_24
    monitor-exit p0
    :try_end_25
    .catchall {:try_start_24 .. :try_end_25} :catchall_20

    .line 38
    throw p1
.end method

.method public final l(IZLq80/i;J)V
    .registers 14

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v2, p4, v0

    .line 4
    .line 5
    const/4 v3, 0x0

    .line 6
    if-nez v2, :cond_d

    .line 7
    .line 8
    iget-object p4, p0, Li80/n;->Y:Li80/w;

    .line 9
    .line 10
    invoke-virtual {p4, p2, p1, p3, v3}, Li80/w;->d(ZILq80/i;I)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    :goto_d
    cmp-long v2, p4, v0

    .line 15
    .line 16
    if-lez v2, :cond_68

    .line 17
    .line 18
    monitor-enter p0

    .line 19
    :goto_12
    :try_start_12
    iget-wide v4, p0, Li80/n;->V:J

    .line 20
    .line 21
    iget-wide v6, p0, Li80/n;->W:J

    .line 22
    .line 23
    cmp-long v2, v4, v6

    .line 24
    .line 25
    if-ltz v2, :cond_34

    .line 26
    .line 27
    iget-object v2, p0, Li80/n;->e:Ljava/util/LinkedHashMap;

    .line 28
    .line 29
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    invoke-interface {v2, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_2c

    .line 38
    .line 39
    invoke-virtual {p0}, Ljava/lang/Object;->wait()V

    .line 40
    .line 41
    .line 42
    goto :goto_12

    .line 43
    :catchall_2a
    move-exception p1

    .line 44
    goto :goto_66

    .line 45
    :cond_2c
    new-instance p1, Ljava/io/IOException;

    .line 46
    .line 47
    const-string p2, "stream closed"

    .line 48
    .line 49
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw p1
    :try_end_34
    .catch Ljava/lang/InterruptedException; {:try_start_12 .. :try_end_34} :catch_59
    .catchall {:try_start_12 .. :try_end_34} :catchall_2a

    .line 53
    :cond_34
    sub-long/2addr v6, v4

    .line 54
    :try_start_35
    invoke-static {p4, p5, v6, v7}, Ljava/lang/Math;->min(JJ)J

    .line 55
    .line 56
    .line 57
    move-result-wide v4

    .line 58
    long-to-int v2, v4

    .line 59
    iget-object v4, p0, Li80/n;->Y:Li80/w;

    .line 60
    .line 61
    iget v4, v4, Li80/w;->i:I

    .line 62
    .line 63
    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    iget-wide v4, p0, Li80/n;->V:J

    .line 68
    .line 69
    int-to-long v6, v2

    .line 70
    add-long/2addr v4, v6

    .line 71
    iput-wide v4, p0, Li80/n;->V:J
    :try_end_48
    .catchall {:try_start_35 .. :try_end_48} :catchall_2a

    .line 72
    .line 73
    monitor-exit p0

    .line 74
    sub-long/2addr p4, v6

    .line 75
    iget-object v4, p0, Li80/n;->Y:Li80/w;

    .line 76
    .line 77
    if-eqz p2, :cond_54

    .line 78
    .line 79
    cmp-long v5, p4, v0

    .line 80
    .line 81
    if-nez v5, :cond_54

    .line 82
    .line 83
    const/4 v5, 0x1

    .line 84
    goto :goto_55

    .line 85
    :cond_54
    move v5, v3

    .line 86
    :goto_55
    invoke-virtual {v4, v5, p1, p3, v2}, Li80/w;->d(ZILq80/i;I)V

    .line 87
    .line 88
    .line 89
    goto :goto_d

    .line 90
    :catch_59
    :try_start_59
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 95
    .line 96
    .line 97
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 98
    .line 99
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 100
    .line 101
    .line 102
    throw p1
    :try_end_66
    .catchall {:try_start_59 .. :try_end_66} :catchall_2a

    .line 103
    :goto_66
    monitor-exit p0

    .line 104
    throw p1

    .line 105
    :cond_68
    return-void
.end method

.method public final n(II)V
    .registers 11

    .line 1
    const-string v0, "errorCode"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lhs/q;->q(ILjava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Li80/n;->i:Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    const/16 v1, 0x5b

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const-string v1, "] writeSynReset"

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    new-instance v2, Li80/j;

    .line 34
    .line 35
    const/4 v7, 0x2

    .line 36
    move-object v4, p0

    .line 37
    move v5, p1

    .line 38
    move v6, p2

    .line 39
    invoke-direct/range {v2 .. v7}, Li80/j;-><init>(Ljava/lang/String;Li80/n;III)V

    .line 40
    .line 41
    .line 42
    iget-object p1, v4, Li80/n;->J:Le80/b;

    .line 43
    .line 44
    const-wide/16 v0, 0x0

    .line 45
    .line 46
    invoke-virtual {p1, v2, v0, v1}, Le80/b;->c(Le80/a;J)V

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public final u(IJ)V
    .registers 12

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Li80/n;->i:Ljava/lang/String;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const/16 v1, 0x5b

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string v1, "] windowUpdate"

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    new-instance v2, Li80/m;

    .line 29
    .line 30
    move-object v4, p0

    .line 31
    move v5, p1

    .line 32
    move-wide v6, p2

    .line 33
    invoke-direct/range {v2 .. v7}, Li80/m;-><init>(Ljava/lang/String;Li80/n;IJ)V

    .line 34
    .line 35
    .line 36
    iget-object p1, v4, Li80/n;->J:Le80/b;

    .line 37
    .line 38
    const-wide/16 p2, 0x0

    .line 39
    .line 40
    invoke-virtual {p1, v2, p2, p3}, Le80/b;->c(Le80/a;J)V

    .line 41
    .line 42
    .line 43
    return-void
.end method
