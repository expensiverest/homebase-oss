###### Class i7.g (i7.g)
.class public final Li7/g;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Li7/g;->a:I

    iput-object p2, p0, Li7/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAvailable(Landroid/net/Network;)V
    .registers 3

    .line 1
    iget v0, p0, Li7/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1}, Landroid/net/ConnectivityManager$NetworkCallback;->onAvailable(Landroid/net/Network;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_9
    iget-object v0, p0, Li7/g;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lq00/d;

    .line 13
    .line 14
    iput-object p1, v0, Lq00/d;->k:Landroid/net/Network;

    .line 15
    .line 16
    const/16 p1, 0xfa

    .line 17
    .line 18
    invoke-virtual {v0, p1}, Lq00/d;->d(I)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_16
    .packed-switch 0x1
        :pswitch_9
    .end packed-switch
.end method

.method public final onCapabilitiesChanged(Landroid/net/Network;Landroid/net/NetworkCapabilities;)V
    .registers 6

    .line 1
    iget v0, p0, Li7/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_40

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li7/g;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lq00/d;

    .line 9
    .line 10
    iput-object p1, v0, Lq00/d;->k:Landroid/net/Network;

    .line 11
    .line 12
    iput-object p2, v0, Lq00/d;->l:Landroid/net/NetworkCapabilities;

    .line 13
    .line 14
    invoke-virtual {v0}, Lq00/d;->e()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_11
    const-string v0, "network"

    .line 19
    .line 20
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const-string p1, "capabilities"

    .line 24
    .line 25
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    sget-object v0, Li7/i;->a:Ljava/lang/String;

    .line 33
    .line 34
    new-instance v1, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    const-string v2, "Network capabilities changed: "

    .line 37
    .line 38
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    invoke-virtual {p1, v0, p2}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, Li7/g;->b:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast p1, Li7/h;

    .line 54
    .line 55
    iget-object p2, p1, Li7/h;->f:Landroid/net/ConnectivityManager;

    .line 56
    .line 57
    invoke-static {p2}, Li7/i;->a(Landroid/net/ConnectivityManager;)Lg7/d;

    .line 58
    .line 59
    .line 60
    move-result-object p2

    .line 61
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method

.method public onLinkPropertiesChanged(Landroid/net/Network;Landroid/net/LinkProperties;)V
    .registers 4

    .line 1
    iget v0, p0, Li7/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1a

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2}, Landroid/net/ConnectivityManager$NetworkCallback;->onLinkPropertiesChanged(Landroid/net/Network;Landroid/net/LinkProperties;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_9
    iget-object p2, p0, Li7/g;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p2, Lq00/d;

    .line 13
    .line 14
    iget-object v0, p2, Lq00/d;->k:Landroid/net/Network;

    .line 15
    .line 16
    if-eqz v0, :cond_13

    .line 17
    .line 18
    iput-object p1, p2, Lq00/d;->k:Landroid/net/Network;

    .line 19
    .line 20
    :cond_13
    const/16 p1, 0xfa

    .line 21
    .line 22
    invoke-virtual {p2, p1}, Lq00/d;->d(I)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x1
        :pswitch_9
    .end packed-switch
.end method

.method public onLosing(Landroid/net/Network;I)V
    .registers 4

    .line 1
    iget v0, p0, Li7/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_14

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2}, Landroid/net/ConnectivityManager$NetworkCallback;->onLosing(Landroid/net/Network;I)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_9
    iget-object p2, p0, Li7/g;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p2, Lq00/d;

    .line 13
    .line 14
    iput-object p1, p2, Lq00/d;->k:Landroid/net/Network;

    .line 15
    .line 16
    invoke-virtual {p2}, Lq00/d;->e()V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0x1
        :pswitch_9
    .end packed-switch
.end method

.method public final onLost(Landroid/net/Network;)V
    .registers 4

    .line 1
    iget v0, p0, Li7/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_30

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Li7/g;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Lq00/d;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p1, Lq00/d;->k:Landroid/net/Network;

    .line 12
    .line 13
    iput-object v0, p1, Lq00/d;->l:Landroid/net/NetworkCapabilities;

    .line 14
    .line 15
    invoke-virtual {p1}, Lq00/d;->e()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_12
    const-string v0, "network"

    .line 20
    .line 21
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    sget-object v0, Li7/i;->a:Ljava/lang/String;

    .line 29
    .line 30
    const-string v1, "Network connection lost"

    .line 31
    .line 32
    invoke-virtual {p1, v0, v1}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, Li7/g;->b:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Li7/h;

    .line 38
    .line 39
    iget-object v0, p1, Li7/h;->f:Landroid/net/ConnectivityManager;

    .line 40
    .line 41
    invoke-static {v0}, Li7/i;->a(Landroid/net/ConnectivityManager;)Lg7/d;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {p1, v0}, Li7/e;->b(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_12
    .end packed-switch
.end method

.method public onUnavailable()V
    .registers 3

    .line 1
    iget v0, p0, Li7/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Landroid/net/ConnectivityManager$NetworkCallback;->onUnavailable()V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_9
    iget-object v0, p0, Li7/g;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lq00/d;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    iput-object v1, v0, Lq00/d;->k:Landroid/net/Network;

    .line 16
    .line 17
    iput-object v1, v0, Lq00/d;->l:Landroid/net/NetworkCapabilities;

    .line 18
    .line 19
    invoke-virtual {v0}, Lq00/d;->e()V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :pswitch_data_16
    .packed-switch 0x1
        :pswitch_9
    .end packed-switch
.end method
