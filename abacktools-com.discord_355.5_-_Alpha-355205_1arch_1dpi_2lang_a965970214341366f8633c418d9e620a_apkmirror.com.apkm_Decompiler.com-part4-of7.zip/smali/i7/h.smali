###### Class i7.h (i7.h)
.class public final Li7/h;
.super Li7/e;
.source "SourceFile"


# instance fields
.field public final f:Landroid/net/ConnectivityManager;

.field public final g:Li7/g;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ln7/b;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Li7/e;-><init>(Landroid/content/Context;Ln7/b;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Li7/e;->b:Landroid/content/Context;

    .line 5
    .line 6
    const-string p2, "connectivity"

    .line 7
    .line 8
    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string p2, "null cannot be cast to non-null type android.net.ConnectivityManager"

    .line 13
    .line 14
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    check-cast p1, Landroid/net/ConnectivityManager;

    .line 18
    .line 19
    iput-object p1, p0, Li7/h;->f:Landroid/net/ConnectivityManager;

    .line 20
    .line 21
    new-instance p1, Li7/g;

    .line 22
    .line 23
    const/4 p2, 0x0

    .line 24
    invoke-direct {p1, p2, p0}, Li7/g;-><init>(ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Li7/h;->g:Li7/g;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Li7/h;->f:Landroid/net/ConnectivityManager;

    .line 2
    .line 3
    invoke-static {v0}, Li7/i;->a(Landroid/net/ConnectivityManager;)Lg7/d;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final c()V
    .registers 5

    .line 1
    const-string v0, "Received exception while registering network callback"

    .line 2
    .line 3
    :try_start_2
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, Li7/i;->a:Ljava/lang/String;

    .line 8
    .line 9
    const-string v3, "Registering network callback"

    .line 10
    .line 11
    invoke-virtual {v1, v2, v3}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Li7/h;->f:Landroid/net/ConnectivityManager;

    .line 15
    .line 16
    iget-object v2, p0, Li7/h;->g:Li7/g;

    .line 17
    .line 18
    invoke-static {v1, v2}, Ll7/h;->a(Landroid/net/ConnectivityManager;Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_14
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_14} :catch_17
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_14} :catch_15

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :catch_15
    move-exception v1

    .line 23
    goto :goto_19

    .line 24
    :catch_17
    move-exception v1

    .line 25
    goto :goto_23

    .line 26
    :goto_19
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    sget-object v3, Li7/i;->a:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v2, v3, v0, v1}, Lb7/s;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 33
    .line 34
    .line 35
    goto :goto_2c

    .line 36
    :goto_23
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    sget-object v3, Li7/i;->a:Ljava/lang/String;

    .line 41
    .line 42
    invoke-virtual {v2, v3, v0, v1}, Lb7/s;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 43
    .line 44
    .line 45
    :goto_2c
    return-void
.end method

.method public final d()V
    .registers 5

    .line 1
    const-string v0, "Received exception while unregistering network callback"

    .line 2
    .line 3
    :try_start_2
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, Li7/i;->a:Ljava/lang/String;

    .line 8
    .line 9
    const-string v3, "Unregistering network callback"

    .line 10
    .line 11
    invoke-virtual {v1, v2, v3}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Li7/h;->f:Landroid/net/ConnectivityManager;

    .line 15
    .line 16
    iget-object v2, p0, Li7/h;->g:Li7/g;

    .line 17
    .line 18
    invoke-static {v1, v2}, Ll7/f;->c(Landroid/net/ConnectivityManager;Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_14
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_14} :catch_17
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_14} :catch_15

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :catch_15
    move-exception v1

    .line 23
    goto :goto_19

    .line 24
    :catch_17
    move-exception v1

    .line 25
    goto :goto_23

    .line 26
    :goto_19
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    sget-object v3, Li7/i;->a:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v2, v3, v0, v1}, Lb7/s;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 33
    .line 34
    .line 35
    goto :goto_2c

    .line 36
    :goto_23
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    sget-object v3, Li7/i;->a:Ljava/lang/String;

    .line 41
    .line 42
    invoke-virtual {v2, v3, v0, v1}, Lb7/s;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 43
    .line 44
    .line 45
    :goto_2c
    return-void
.end method
