###### Class hx.v (hx.v)
.class public final Lhx/v;
.super Lhx/n;
.source "SourceFile"


# instance fields
.field public final d:Ljava/lang/Object;

.field public e:I

.field public final synthetic i:Lhx/w;


# direct methods
.method public constructor <init>(Lhx/w;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lhx/v;->i:Lhx/w;

    .line 5
    .line 6
    sget-object v0, Lhx/w;->L:Ljava/lang/Object;

    .line 7
    .line 8
    invoke-virtual {p1}, Lhx/w;->j()[Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    aget-object p1, p1, p2

    .line 13
    .line 14
    iput-object p1, p0, Lhx/v;->d:Ljava/lang/Object;

    .line 15
    .line 16
    iput p2, p0, Lhx/v;->e:I

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 5

    .line 1
    iget v0, p0, Lhx/v;->e:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    iget-object v2, p0, Lhx/v;->d:Ljava/lang/Object;

    .line 5
    .line 6
    iget-object v3, p0, Lhx/v;->i:Lhx/w;

    .line 7
    .line 8
    if-eq v0, v1, :cond_1f

    .line 9
    .line 10
    invoke-virtual {v3}, Lhx/w;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-ge v0, v1, :cond_1f

    .line 15
    .line 16
    iget v0, p0, Lhx/v;->e:I

    .line 17
    .line 18
    invoke-virtual {v3}, Lhx/w;->j()[Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    aget-object v0, v1, v0

    .line 23
    .line 24
    invoke-static {v2, v0}, Lmn/a;->u(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1e

    .line 29
    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    return-void

    .line 32
    :cond_1f
    :goto_1f
    sget-object v0, Lhx/w;->L:Ljava/lang/Object;

    .line 33
    .line 34
    invoke-virtual {v3, v2}, Lhx/w;->e(Ljava/lang/Object;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    iput v0, p0, Lhx/v;->e:I

    .line 39
    .line 40
    return-void
.end method

.method public final getKey()Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/v;->d:Ljava/lang/Object;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getValue()Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object v0, p0, Lhx/v;->i:Lhx/w;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/w;->c()Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_f

    .line 8
    .line 9
    iget-object v0, p0, Lhx/v;->d:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0

    .line 16
    :cond_f
    invoke-virtual {p0}, Lhx/v;->a()V

    .line 17
    .line 18
    .line 19
    iget v1, p0, Lhx/v;->e:I

    .line 20
    .line 21
    const/4 v2, -0x1

    .line 22
    if-ne v1, v2, :cond_19

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    return-object v0

    .line 26
    :cond_19
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    aget-object v0, v0, v1

    .line 31
    .line 32
    return-object v0
.end method

.method public final setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget-object v0, p0, Lhx/v;->i:Lhx/w;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/w;->c()Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    iget-object v2, p0, Lhx/v;->d:Ljava/lang/Object;

    .line 8
    .line 9
    if-eqz v1, :cond_f

    .line 10
    .line 11
    invoke-interface {v1, v2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1

    .line 16
    :cond_f
    invoke-virtual {p0}, Lhx/v;->a()V

    .line 17
    .line 18
    .line 19
    iget v1, p0, Lhx/v;->e:I

    .line 20
    .line 21
    const/4 v3, -0x1

    .line 22
    if-ne v1, v3, :cond_1c

    .line 23
    .line 24
    invoke-virtual {v0, v2, p1}, Lhx/w;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    const/4 p1, 0x0

    .line 28
    return-object p1

    .line 29
    :cond_1c
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    aget-object v1, v2, v1

    .line 34
    .line 35
    iget v2, p0, Lhx/v;->e:I

    .line 36
    .line 37
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    aput-object p1, v0, v2

    .line 42
    .line 43
    return-object v1
.end method
