###### Class hx.t0 (hx.t0)
.class public final Lhx/t0;
.super Lhx/g0;
.source "SourceFile"


# instance fields
.field public a:Lhx/t1;

.field public b:Z


# virtual methods
.method public final a(Ljava/lang/Object;)Lhx/g0;
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, v0, p1}, Lhx/t0;->c(ILjava/lang/Object;)V

    .line 3
    .line 4
    .line 5
    return-object p0
.end method

.method public final c(ILjava/lang/Object;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lhx/t0;->a:Lhx/t1;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    if-nez p1, :cond_8

    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-boolean v0, p0, Lhx/t0;->b:Z

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz v0, :cond_41

    .line 13
    .line 14
    new-instance v0, Lhx/t1;

    .line 15
    .line 16
    iget-object v2, p0, Lhx/t0;->a:Lhx/t1;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 19
    .line 20
    .line 21
    iget v3, v2, Lhx/t1;->c:I

    .line 22
    .line 23
    invoke-virtual {v0, v3}, Lhx/t1;->d(I)V

    .line 24
    .line 25
    .line 26
    iget v3, v2, Lhx/t1;->c:I

    .line 27
    .line 28
    const/4 v4, -0x1

    .line 29
    if-nez v3, :cond_20

    .line 30
    .line 31
    :cond_1e
    move v3, v4

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move v3, v1

    .line 34
    :goto_21
    if-eq v3, v4, :cond_3f

    .line 35
    .line 36
    iget v5, v2, Lhx/t1;->c:I

    .line 37
    .line 38
    invoke-static {v3, v5}, Loq/a;->s(II)V

    .line 39
    .line 40
    .line 41
    iget-object v5, v2, Lhx/t1;->a:[Ljava/lang/Object;

    .line 42
    .line 43
    aget-object v5, v5, v3

    .line 44
    .line 45
    iget v6, v2, Lhx/t1;->c:I

    .line 46
    .line 47
    invoke-static {v3, v6}, Loq/a;->s(II)V

    .line 48
    .line 49
    .line 50
    iget-object v6, v2, Lhx/t1;->b:[I

    .line 51
    .line 52
    aget v6, v6, v3

    .line 53
    .line 54
    invoke-virtual {v0, v6, v5}, Lhx/t1;->e(ILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    add-int/lit8 v3, v3, 0x1

    .line 58
    .line 59
    iget v5, v2, Lhx/t1;->c:I

    .line 60
    .line 61
    if-ge v3, v5, :cond_1e

    .line 62
    .line 63
    goto :goto_21

    .line 64
    :cond_3f
    iput-object v0, p0, Lhx/t0;->a:Lhx/t1;

    .line 65
    .line 66
    :cond_41
    iput-boolean v1, p0, Lhx/t0;->b:Z

    .line 67
    .line 68
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    iget-object v0, p0, Lhx/t0;->a:Lhx/t1;

    .line 72
    .line 73
    invoke-virtual {v0, p2}, Lhx/t1;->b(Ljava/lang/Object;)I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    add-int/2addr v1, p1

    .line 78
    invoke-virtual {v0, v1, p2}, Lhx/t1;->e(ILjava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    return-void
.end method
