###### Class hx.n0 (hx.n0)
.class public Lhx/n0;
.super Lhx/q;
.source "SourceFile"

# interfaces
.implements Lhx/e1;
.implements Ljava/io/Serializable;


# instance fields
.field public final transient w:Lhx/b2;

.field public final transient x:I


# direct methods
.method public constructor <init>(Lhx/b2;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lhx/n0;->w:Lhx/b2;

    .line 5
    .line 6
    iput p2, p0, Lhx/n0;->x:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Collection;
    .registers 2

    .line 1
    invoke-super {p0}, Lhx/p;->a()Ljava/util/Collection;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lhx/h0;

    .line 6
    .line 7
    return-object v0
.end method

.method public bridge synthetic asMap()Ljava/util/Map;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lhx/n0;->g()Lhx/p0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final b(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    if-eqz p1, :cond_a

    .line 2
    .line 3
    invoke-super {p0, p1}, Lhx/p;->b(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eqz p1, :cond_a

    .line 8
    .line 9
    const/4 p1, 0x1

    .line 10
    return p1

    .line 11
    :cond_a
    const/4 p1, 0x0

    .line 12
    return p1
.end method

.method public final c()Ljava/util/Map;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/AssertionError;

    .line 2
    .line 3
    const-string v1, "should never be called"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    throw v0
.end method

.method public final clear()V
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public final d()Ljava/util/Collection;
    .registers 2

    .line 1
    new-instance v0, Lhx/r0;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lhx/r0;-><init>(Lhx/n0;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final e()Ljava/util/Set;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/AssertionError;

    .line 2
    .line 3
    const-string v1, "unreachable"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    throw v0
.end method

.method public final f()Ljava/util/Iterator;
    .registers 2

    .line 1
    new-instance v0, Lhx/q0;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lhx/q0;-><init>(Lhx/n0;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public g()Lhx/p0;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/n0;->w:Lhx/b2;

    .line 2
    .line 3
    return-object v0
.end method

.method public final get(Ljava/lang/Object;)Ljava/util/Collection;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/n0;->w:Lhx/b2;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lhx/b2;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lhx/m0;

    .line 8
    .line 9
    if-nez p1, :cond_e

    .line 10
    .line 11
    sget-object p1, Lhx/m0;->e:Lhx/k0;

    .line 12
    .line 13
    sget-object p1, Lhx/w1;->w:Lhx/w1;

    .line 14
    .line 15
    :cond_e
    return-object p1
.end method

.method public final keySet()Ljava/util/Set;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/n0;->w:Lhx/b2;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/p0;->e()Lhx/x0;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final remove(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 3

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public final size()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/n0;->x:I

    .line 2
    .line 3
    return v0
.end method
