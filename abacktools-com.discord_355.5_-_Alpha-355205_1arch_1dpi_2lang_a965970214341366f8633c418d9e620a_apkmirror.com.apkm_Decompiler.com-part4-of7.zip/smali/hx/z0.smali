###### Class hx.z0 (hx.z0)
.class public final Lhx/z0;
.super Lhx/l2;
.source "SourceFile"


# instance fields
.field public d:I

.field public e:Ljava/lang/Object;

.field public final synthetic i:I

.field public final v:Ljava/util/Iterator;

.field public final synthetic w:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    .line 2
    iput v0, p0, Lhx/z0;->d:I

    return-void
.end method

.method public constructor <init>(Lhx/f2;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lhx/z0;->i:I

    .line 4
    iput-object p1, p0, Lhx/z0;->w:Ljava/lang/Object;

    invoke-direct {p0}, Lhx/z0;-><init>()V

    .line 5
    iget-object p1, p1, Lhx/f2;->d:Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    iput-object p1, p0, Lhx/z0;->v:Ljava/util/Iterator;

    return-void
.end method

.method public constructor <init>(Ljava/util/Iterator;Lgx/m;)V
    .registers 4

    const/4 v0, 0x0

    iput v0, p0, Lhx/z0;->i:I

    .line 3
    iput-object p1, p0, Lhx/z0;->v:Ljava/util/Iterator;

    iput-object p2, p0, Lhx/z0;->w:Ljava/lang/Object;

    invoke-direct {p0}, Lhx/z0;-><init>()V

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 6

    .line 1
    iget v0, p0, Lhx/z0;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x4

    .line 6
    if-eq v0, v3, :cond_9

    .line 7
    .line 8
    move v0, v2

    .line 9
    goto :goto_a

    .line 10
    :cond_9
    move v0, v1

    .line 11
    :goto_a
    invoke-static {v0}, Loq/a;->z(Z)V

    .line 12
    .line 13
    .line 14
    iget v0, p0, Lhx/z0;->d:I

    .line 15
    .line 16
    invoke-static {v0}, Lv0/d;->d(I)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_63

    .line 21
    .line 22
    const/4 v4, 0x2

    .line 23
    if-eq v0, v4, :cond_62

    .line 24
    .line 25
    iput v3, p0, Lhx/z0;->d:I

    .line 26
    .line 27
    iget v0, p0, Lhx/z0;->i:I

    .line 28
    .line 29
    packed-switch v0, :pswitch_data_64

    .line 30
    .line 31
    .line 32
    :cond_1f
    iget-object v0, p0, Lhx/z0;->v:Ljava/util/Iterator;

    .line 33
    .line 34
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    if-eqz v3, :cond_38

    .line 39
    .line 40
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iget-object v3, p0, Lhx/z0;->w:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v3, Lhx/f2;

    .line 47
    .line 48
    iget-object v3, v3, Lhx/f2;->e:Ljava/util/Set;

    .line 49
    .line 50
    invoke-interface {v3, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eqz v3, :cond_1f

    .line 55
    .line 56
    goto :goto_58

    .line 57
    :cond_38
    const/4 v0, 0x3

    .line 58
    iput v0, p0, Lhx/z0;->d:I

    .line 59
    .line 60
    :goto_3b
    const/4 v0, 0x0

    .line 61
    goto :goto_58

    .line 62
    :cond_3d
    :pswitch_3d
    iget-object v0, p0, Lhx/z0;->v:Ljava/util/Iterator;

    .line 63
    .line 64
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-eqz v3, :cond_54

    .line 69
    .line 70
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    iget-object v3, p0, Lhx/z0;->w:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v3, Lgx/m;

    .line 77
    .line 78
    invoke-interface {v3, v0}, Lgx/m;->apply(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v3

    .line 82
    if-eqz v3, :cond_3d

    .line 83
    .line 84
    goto :goto_58

    .line 85
    :cond_54
    const/4 v0, 0x3

    .line 86
    iput v0, p0, Lhx/z0;->d:I

    .line 87
    .line 88
    goto :goto_3b

    .line 89
    :goto_58
    iput-object v0, p0, Lhx/z0;->e:Ljava/lang/Object;

    .line 90
    .line 91
    iget v0, p0, Lhx/z0;->d:I

    .line 92
    .line 93
    const/4 v3, 0x3

    .line 94
    if-eq v0, v3, :cond_62

    .line 95
    .line 96
    iput v2, p0, Lhx/z0;->d:I

    .line 97
    .line 98
    return v2

    .line 99
    :cond_62
    return v1

    .line 100
    :cond_63
    return v2

    .line 101
    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_3d
    .end packed-switch
.end method

.method public final next()Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/z0;->hasNext()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_f

    .line 6
    .line 7
    const/4 v0, 0x2

    .line 8
    iput v0, p0, Lhx/z0;->d:I

    .line 9
    .line 10
    iget-object v0, p0, Lhx/z0;->e:Ljava/lang/Object;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    iput-object v1, p0, Lhx/z0;->e:Ljava/lang/Object;

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_f
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    .line 19
    .line 20
    .line 21
    throw v0
.end method
