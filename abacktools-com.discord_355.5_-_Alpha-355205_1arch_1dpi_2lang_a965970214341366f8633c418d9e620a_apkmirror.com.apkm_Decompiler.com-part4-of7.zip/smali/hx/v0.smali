###### Class hx.v0 (hx.v0)
.class public abstract Lhx/v0;
.super Lhx/h0;
.source "SourceFile"

# interfaces
.implements Lhx/q1;


# static fields
.field public static final synthetic v:I


# instance fields
.field public transient e:Lhx/w1;

.field public transient i:Lhx/x0;


# virtual methods
.method public final a()Lhx/m0;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/v0;->e:Lhx/w1;

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    invoke-super {p0}, Lhx/h0;->a()Lhx/m0;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    move-object v1, v0

    .line 10
    check-cast v1, Lhx/w1;

    .line 11
    .line 12
    iput-object v1, p0, Lhx/v0;->e:Lhx/w1;

    .line 13
    .line 14
    :cond_d
    return-object v0
.end method

.method public final b(I[Ljava/lang/Object;)I
    .registers 7

    .line 1
    invoke-virtual {p0}, Lhx/v0;->p()Lhx/x0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lhx/h0;->m()Lhx/l2;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_24

    .line 14
    .line 15
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Lhx/s1;

    .line 20
    .line 21
    invoke-virtual {v1}, Lhx/s1;->a()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    add-int/2addr v2, p1

    .line 26
    iget-object v3, v1, Lhx/s1;->a:Ljava/lang/Object;

    .line 27
    .line 28
    invoke-static {p2, p1, v2, v3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1}, Lhx/s1;->a()I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    add-int/2addr p1, v1

    .line 36
    goto :goto_8

    .line 37
    :cond_24
    return p1
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    move-object v0, p0

    .line 2
    check-cast v0, Lhx/c2;

    .line 3
    .line 4
    iget-object v0, v0, Lhx/c2;->w:Lhx/t1;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Lhx/t1;->b(Ljava/lang/Object;)I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-lez p1, :cond_d

    .line 11
    .line 12
    const/4 p1, 0x1

    .line 13
    return p1

    .line 14
    :cond_d
    const/4 p1, 0x0

    .line 15
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    if-ne p1, p0, :cond_3

    .line 2
    .line 3
    goto :goto_4d

    .line 4
    :cond_3
    instance-of v0, p1, Lhx/q1;

    .line 5
    .line 6
    if-eqz v0, :cond_4f

    .line 7
    .line 8
    check-cast p1, Lhx/q1;

    .line 9
    .line 10
    move-object v0, p0

    .line 11
    check-cast v0, Lhx/c2;

    .line 12
    .line 13
    move-object v1, p1

    .line 14
    check-cast v1, Lhx/c2;

    .line 15
    .line 16
    iget v1, v1, Lhx/c2;->x:I

    .line 17
    .line 18
    iget v2, v0, Lhx/c2;->x:I

    .line 19
    .line 20
    if-ne v2, v1, :cond_4f

    .line 21
    .line 22
    invoke-virtual {p0}, Lhx/v0;->p()Lhx/x0;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-interface {v1}, Ljava/util/Set;->size()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    check-cast p1, Lhx/v0;

    .line 31
    .line 32
    invoke-virtual {p1}, Lhx/v0;->p()Lhx/x0;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-interface {v2}, Ljava/util/Set;->size()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eq v1, v2, :cond_2a

    .line 41
    .line 42
    goto :goto_4f

    .line 43
    :cond_2a
    invoke-virtual {p1}, Lhx/v0;->p()Lhx/x0;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    :cond_32
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    if-eqz v1, :cond_4d

    .line 56
    .line 57
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Lhx/s1;

    .line 62
    .line 63
    iget-object v2, v1, Lhx/s1;->a:Ljava/lang/Object;

    .line 64
    .line 65
    iget-object v3, v0, Lhx/c2;->w:Lhx/t1;

    .line 66
    .line 67
    invoke-virtual {v3, v2}, Lhx/t1;->b(Ljava/lang/Object;)I

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    invoke-virtual {v1}, Lhx/s1;->a()I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    if-eq v2, v1, :cond_32

    .line 76
    .line 77
    goto :goto_4f

    .line 78
    :cond_4d
    :goto_4d
    const/4 p1, 0x1

    .line 79
    return p1

    .line 80
    :cond_4f
    :goto_4f
    const/4 p1, 0x0

    .line 81
    return p1
.end method

.method public final hashCode()I
    .registers 2

    .line 1
    invoke-virtual {p0}, Lhx/v0;->p()Lhx/x0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Lhx/s;->p(Ljava/util/Set;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public final m()Lhx/l2;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/v0;->p()Lhx/x0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lhx/h0;->m()Lhx/l2;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance v1, Lhx/s0;

    .line 10
    .line 11
    invoke-direct {v1, v0}, Lhx/s0;-><init>(Lhx/l2;)V

    .line 12
    .line 13
    .line 14
    return-object v1
.end method

.method public abstract o()Lhx/x0;
.end method

.method public final p()Lhx/x0;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/v0;->i:Lhx/x0;

    .line 2
    .line 3
    if-nez v0, :cond_15

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_d

    .line 10
    .line 11
    sget-object v0, Lhx/d2;->L:Lhx/d2;

    .line 12
    .line 13
    goto :goto_13

    .line 14
    :cond_d
    new-instance v0, Lhx/u0;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-direct {v0, p0, v1}, Lhx/u0;-><init>(Lhx/v0;I)V

    .line 18
    .line 19
    .line 20
    :goto_13
    iput-object v0, p0, Lhx/v0;->i:Lhx/x0;

    .line 21
    .line 22
    :cond_15
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lhx/v0;->p()Lhx/x0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method
