###### Class hx.m1 (hx.m1)
.class public interface abstract Lhx/m1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Ljava/util/Collection;
.end method

.method public abstract asMap()Ljava/util/Map;
.end method

.method public abstract clear()V
.end method

.method public abstract get(Ljava/lang/Object;)Ljava/util/Collection;
.end method

.method public abstract keySet()Ljava/util/Set;
.end method

.method public abstract remove(Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public abstract size()I
.end method
