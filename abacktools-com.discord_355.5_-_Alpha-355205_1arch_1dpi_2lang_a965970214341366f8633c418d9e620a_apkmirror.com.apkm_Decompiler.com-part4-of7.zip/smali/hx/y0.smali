###### Class hx.y0 (hx.y0)
.class public final Lhx/y0;
.super Lhx/m0;
.source "SourceFile"


# instance fields
.field public final synthetic i:Lhx/u0;


# direct methods
.method public constructor <init>(Lhx/u0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lhx/y0;->i:Lhx/u0;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/util/AbstractCollection;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final get(I)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object v0, p0, Lhx/y0;->i:Lhx/u0;

    .line 2
    .line 3
    iget v1, v0, Lhx/u0;->v:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_2a

    .line 6
    .line 7
    .line 8
    iget-object v0, v0, Lhx/u0;->w:Lhx/v0;

    .line 9
    .line 10
    check-cast v0, Lhx/c2;

    .line 11
    .line 12
    iget-object v0, v0, Lhx/c2;->w:Lhx/t1;

    .line 13
    .line 14
    iget v1, v0, Lhx/t1;->c:I

    .line 15
    .line 16
    invoke-static {p1, v1}, Loq/a;->s(II)V

    .line 17
    .line 18
    .line 19
    iget-object v0, v0, Lhx/t1;->a:[Ljava/lang/Object;

    .line 20
    .line 21
    aget-object p1, v0, p1

    .line 22
    .line 23
    goto :goto_28

    .line 24
    :pswitch_17
    iget-object v0, v0, Lhx/u0;->w:Lhx/v0;

    .line 25
    .line 26
    check-cast v0, Lhx/c2;

    .line 27
    .line 28
    iget-object v0, v0, Lhx/c2;->w:Lhx/t1;

    .line 29
    .line 30
    iget v1, v0, Lhx/t1;->c:I

    .line 31
    .line 32
    invoke-static {p1, v1}, Loq/a;->s(II)V

    .line 33
    .line 34
    .line 35
    new-instance v1, Lhx/s1;

    .line 36
    .line 37
    invoke-direct {v1, v0, p1}, Lhx/s1;-><init>(Lhx/t1;I)V

    .line 38
    .line 39
    .line 40
    move-object p1, v1

    .line 41
    :goto_28
    return-object p1

    .line 42
    nop

    .line 43
    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_17
    .end packed-switch
.end method

.method public final k()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/y0;->i:Lhx/u0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/h0;->k()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final size()I
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/y0;->i:Lhx/u0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method
