###### Class hx.l0 (hx.l0)
.class public final Lhx/l0;
.super Lhx/m0;
.source "SourceFile"


# instance fields
.field public final transient i:I

.field public final transient v:I

.field public final synthetic w:Lhx/m0;


# direct methods
.method public constructor <init>(Lhx/m0;II)V
    .registers 4

    .line 1
    iput-object p1, p0, Lhx/l0;->w:Lhx/m0;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/util/AbstractCollection;-><init>()V

    .line 4
    .line 5
    .line 6
    iput p2, p0, Lhx/l0;->i:I

    .line 7
    .line 8
    iput p3, p0, Lhx/l0;->v:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final B(II)Lhx/m0;
    .registers 4

    .line 1
    iget v0, p0, Lhx/l0;->v:I

    .line 2
    .line 3
    invoke-static {p1, p2, v0}, Loq/a;->w(III)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lhx/l0;->i:I

    .line 7
    .line 8
    add-int/2addr p1, v0

    .line 9
    add-int/2addr p2, v0

    .line 10
    iget-object v0, p0, Lhx/l0;->w:Lhx/m0;

    .line 11
    .line 12
    invoke-virtual {v0, p1, p2}, Lhx/m0;->B(II)Lhx/m0;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1
.end method

.method public final e()[Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/l0;->w:Lhx/m0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/h0;->e()[Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final f()I
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/l0;->w:Lhx/m0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/h0;->h()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lhx/l0;->i:I

    .line 8
    .line 9
    add-int/2addr v0, v1

    .line 10
    iget v1, p0, Lhx/l0;->v:I

    .line 11
    .line 12
    add-int/2addr v0, v1

    .line 13
    return v0
.end method

.method public final get(I)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lhx/l0;->v:I

    .line 2
    .line 3
    invoke-static {p1, v0}, Loq/a;->s(II)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lhx/l0;->i:I

    .line 7
    .line 8
    add-int/2addr p1, v0

    .line 9
    iget-object v0, p0, Lhx/l0;->w:Lhx/m0;

    .line 10
    .line 11
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method

.method public final h()I
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/l0;->w:Lhx/m0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lhx/h0;->h()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lhx/l0;->i:I

    .line 8
    .line 9
    add-int/2addr v0, v1

    .line 10
    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Lhx/m0;->s(I)Lhx/k0;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    return-object v0
.end method

.method public final k()Z
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final listIterator()Ljava/util/ListIterator;
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-virtual {p0, v0}, Lhx/m0;->s(I)Lhx/k0;

    move-result-object v0

    return-object v0
.end method

.method public final bridge synthetic listIterator(I)Ljava/util/ListIterator;
    .registers 2

    .line 2
    invoke-virtual {p0, p1}, Lhx/m0;->s(I)Lhx/k0;

    move-result-object p1

    return-object p1
.end method

.method public final size()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/l0;->v:I

    .line 2
    .line 3
    return v0
.end method

.method public final bridge synthetic subList(II)Ljava/util/List;
    .registers 3

    .line 1
    invoke-virtual {p0, p1, p2}, Lhx/l0;->B(II)Lhx/m0;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method
