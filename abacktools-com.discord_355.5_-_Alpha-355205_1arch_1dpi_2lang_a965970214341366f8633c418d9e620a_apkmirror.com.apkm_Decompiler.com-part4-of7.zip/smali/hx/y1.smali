###### Class hx.y1 (hx.y1)
.class public final Lhx/y1;
.super Lhx/x0;
.source "SourceFile"


# instance fields
.field public final transient v:Lhx/p0;

.field public final transient w:[Ljava/lang/Object;

.field public final transient x:I

.field public final transient y:I


# direct methods
.method public constructor <init>(Lhx/p0;[Ljava/lang/Object;II)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/util/AbstractCollection;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lhx/y1;->v:Lhx/p0;

    .line 5
    .line 6
    iput-object p2, p0, Lhx/y1;->w:[Ljava/lang/Object;

    .line 7
    .line 8
    iput p3, p0, Lhx/y1;->x:I

    .line 9
    .line 10
    iput p4, p0, Lhx/y1;->y:I

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final b(I[Ljava/lang/Object;)I
    .registers 4

    .line 1
    invoke-virtual {p0}, Lhx/x0;->a()Lhx/m0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p1, p2}, Lhx/m0;->b(I[Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    return p1
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    instance-of v0, p1, Ljava/util/Map$Entry;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1f

    .line 5
    .line 6
    check-cast p1, Ljava/util/Map$Entry;

    .line 7
    .line 8
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    if-eqz p1, :cond_1f

    .line 17
    .line 18
    iget-object v2, p0, Lhx/y1;->v:Lhx/p0;

    .line 19
    .line 20
    invoke-virtual {v2, v0}, Lhx/p0;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    if-eqz p1, :cond_1f

    .line 29
    .line 30
    const/4 p1, 0x1

    .line 31
    return p1

    .line 32
    :cond_1f
    return v1
.end method

.method public final k()Z
    .registers 2

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final m()Lhx/l2;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/x0;->a()Lhx/m0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Lhx/m0;->s(I)Lhx/k0;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final r()Lhx/m0;
    .registers 2

    .line 1
    new-instance v0, Lhx/x1;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lhx/x1;-><init>(Lhx/y1;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final size()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/y1;->y:I

    .line 2
    .line 3
    return v0
.end method
