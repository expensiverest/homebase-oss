###### Class hx.j0 (hx.j0)
.class public final Lhx/j0;
.super Lhx/f0;
.source "SourceFile"


# virtual methods
.method public final a(Ljava/lang/Object;)Lhx/g0;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final g()Lhx/w1;
    .registers 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lhx/f0;->c:Z

    .line 3
    .line 4
    iget-object v0, p0, Lhx/f0;->a:[Ljava/lang/Object;

    .line 5
    .line 6
    iget v1, p0, Lhx/f0;->b:I

    .line 7
    .line 8
    invoke-static {v1, v0}, Lhx/m0;->o(I[Ljava/lang/Object;)Lhx/w1;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method
