###### Class hx.q1 (hx.q1)
.class public interface abstract Lhx/q1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Collection;
