###### Class hx.s0 (hx.s0)
.class public final Lhx/s0;
.super Lhx/l2;
.source "SourceFile"


# instance fields
.field public d:I

.field public e:Ljava/lang/Object;

.field public final synthetic i:Ljava/util/Iterator;


# direct methods
.method public constructor <init>(Lhx/l2;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lhx/s0;->i:Ljava/util/Iterator;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .line 1
    iget v0, p0, Lhx/s0;->d:I

    .line 2
    .line 3
    if-gtz v0, :cond_f

    .line 4
    .line 5
    iget-object v0, p0, Lhx/s0;->i:Ljava/util/Iterator;

    .line 6
    .line 7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_d

    .line 12
    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const/4 v0, 0x0

    .line 15
    return v0

    .line 16
    :cond_f
    :goto_f
    const/4 v0, 0x1

    .line 17
    return v0
.end method

.method public final next()Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lhx/s0;->d:I

    .line 2
    .line 3
    if-gtz v0, :cond_16

    .line 4
    .line 5
    iget-object v0, p0, Lhx/s0;->i:Ljava/util/Iterator;

    .line 6
    .line 7
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lhx/s1;

    .line 12
    .line 13
    iget-object v1, v0, Lhx/s1;->a:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object v1, p0, Lhx/s0;->e:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-virtual {v0}, Lhx/s1;->a()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    iput v0, p0, Lhx/s0;->d:I

    .line 22
    .line 23
    :cond_16
    iget v0, p0, Lhx/s0;->d:I

    .line 24
    .line 25
    add-int/lit8 v0, v0, -0x1

    .line 26
    .line 27
    iput v0, p0, Lhx/s0;->d:I

    .line 28
    .line 29
    iget-object v0, p0, Lhx/s0;->e:Ljava/lang/Object;

    .line 30
    .line 31
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    return-object v0
.end method
