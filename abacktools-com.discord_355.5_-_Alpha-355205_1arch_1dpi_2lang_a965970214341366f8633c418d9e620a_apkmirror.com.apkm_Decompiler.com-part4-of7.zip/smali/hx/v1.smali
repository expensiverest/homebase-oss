###### Class hx.v1 (hx.v1)
.class public final Lhx/v1;
.super Lhx/e0;
.source "SourceFile"


# static fields
.field public static final K:Lhx/v1;


# instance fields
.field public final transient J:Lhx/v1;

.field public final transient v:Ljava/lang/Object;

.field public final transient w:[Ljava/lang/Object;

.field public final transient x:I

.field public final transient y:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lhx/v1;

    .line 2
    .line 3
    invoke-direct {v0}, Lhx/v1;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lhx/v1;->K:Lhx/v1;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lhx/v1;->v:Ljava/lang/Object;

    const/4 v0, 0x0

    .line 3
    new-array v1, v0, [Ljava/lang/Object;

    iput-object v1, p0, Lhx/v1;->w:[Ljava/lang/Object;

    .line 4
    iput v0, p0, Lhx/v1;->x:I

    .line 5
    iput v0, p0, Lhx/v1;->y:I

    .line 6
    iput-object p0, p0, Lhx/v1;->J:Lhx/v1;

    return-void
.end method

.method public constructor <init>(I[Ljava/lang/Object;)V
    .registers 7

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-object p2, p0, Lhx/v1;->w:[Ljava/lang/Object;

    .line 9
    iput p1, p0, Lhx/v1;->y:I

    const/4 v0, 0x0

    .line 10
    iput v0, p0, Lhx/v1;->x:I

    const/4 v1, 0x2

    if-lt p1, v1, :cond_12

    .line 11
    invoke-static {p1}, Lhx/x0;->o(I)I

    move-result v2

    goto :goto_13

    :cond_12
    move v2, v0

    .line 12
    :goto_13
    invoke-static {p2, p1, v2, v0}, Lhx/b2;->h([Ljava/lang/Object;III)Ljava/lang/Object;

    move-result-object v0

    .line 13
    instance-of v3, v0, [Ljava/lang/Object;

    if-nez v3, :cond_39

    .line 14
    iput-object v0, p0, Lhx/v1;->v:Ljava/lang/Object;

    const/4 v0, 0x1

    .line 15
    invoke-static {p2, p1, v2, v0}, Lhx/b2;->h([Ljava/lang/Object;III)Ljava/lang/Object;

    move-result-object v0

    .line 16
    instance-of v2, v0, [Ljava/lang/Object;

    if-nez v2, :cond_2e

    .line 17
    new-instance v1, Lhx/v1;

    invoke-direct {v1, v0, p2, p1, p0}, Lhx/v1;-><init>(Ljava/lang/Object;[Ljava/lang/Object;ILhx/v1;)V

    iput-object v1, p0, Lhx/v1;->J:Lhx/v1;

    return-void

    .line 18
    :cond_2e
    check-cast v0, [Ljava/lang/Object;

    .line 19
    aget-object p1, v0, v1

    check-cast p1, Lhx/o0;

    .line 20
    invoke-virtual {p1}, Lhx/o0;->a()Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1

    .line 21
    :cond_39
    check-cast v0, [Ljava/lang/Object;

    .line 22
    aget-object p1, v0, v1

    check-cast p1, Lhx/o0;

    .line 23
    invoke-virtual {p1}, Lhx/o0;->a()Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1
.end method

.method public constructor <init>(Ljava/lang/Object;[Ljava/lang/Object;ILhx/v1;)V
    .registers 5

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, Lhx/v1;->v:Ljava/lang/Object;

    .line 26
    iput-object p2, p0, Lhx/v1;->w:[Ljava/lang/Object;

    const/4 p1, 0x1

    .line 27
    iput p1, p0, Lhx/v1;->x:I

    .line 28
    iput p3, p0, Lhx/v1;->y:I

    .line 29
    iput-object p4, p0, Lhx/v1;->J:Lhx/v1;

    return-void
.end method


# virtual methods
.method public final b()Lhx/y1;
    .registers 5

    .line 1
    new-instance v0, Lhx/y1;

    .line 2
    .line 3
    iget v1, p0, Lhx/v1;->x:I

    .line 4
    .line 5
    iget v2, p0, Lhx/v1;->y:I

    .line 6
    .line 7
    iget-object v3, p0, Lhx/v1;->w:[Ljava/lang/Object;

    .line 8
    .line 9
    invoke-direct {v0, p0, v3, v1, v2}, Lhx/y1;-><init>(Lhx/p0;[Ljava/lang/Object;II)V

    .line 10
    .line 11
    .line 12
    return-object v0
.end method

.method public final c()Lhx/z1;
    .registers 5

    .line 1
    new-instance v0, Lhx/a2;

    .line 2
    .line 3
    iget v1, p0, Lhx/v1;->x:I

    .line 4
    .line 5
    iget v2, p0, Lhx/v1;->y:I

    .line 6
    .line 7
    iget-object v3, p0, Lhx/v1;->w:[Ljava/lang/Object;

    .line 8
    .line 9
    invoke-direct {v0, v3, v1, v2}, Lhx/a2;-><init>([Ljava/lang/Object;II)V

    .line 10
    .line 11
    .line 12
    new-instance v1, Lhx/z1;

    .line 13
    .line 14
    invoke-direct {v1, p0, v0}, Lhx/z1;-><init>(Lhx/p0;Lhx/a2;)V

    .line 15
    .line 16
    .line 17
    return-object v1
.end method

.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lhx/v1;->y:I

    .line 2
    .line 3
    iget v1, p0, Lhx/v1;->x:I

    .line 4
    .line 5
    iget-object v2, p0, Lhx/v1;->v:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, Lhx/v1;->w:[Ljava/lang/Object;

    .line 8
    .line 9
    invoke-static {v2, v3, v0, v1, p1}, Lhx/b2;->i(Ljava/lang/Object;[Ljava/lang/Object;IILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    if-nez p1, :cond_f

    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    :cond_f
    return-object p1
.end method

.method public final size()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/v1;->y:I

    .line 2
    .line 3
    return v0
.end method
