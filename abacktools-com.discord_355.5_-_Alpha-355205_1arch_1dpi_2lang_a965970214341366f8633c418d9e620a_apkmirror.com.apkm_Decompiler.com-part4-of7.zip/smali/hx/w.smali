###### Class hx.w (hx.w)
.class public final Lhx/w;
.super Ljava/util/AbstractMap;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final L:Ljava/lang/Object;


# instance fields
.field public transient J:Lhx/u;

.field public transient K:Lhx/o;

.field public transient d:Ljava/lang/Object;

.field public transient e:[I

.field public transient i:[Ljava/lang/Object;

.field public transient v:[Ljava/lang/Object;

.field public transient w:I

.field public transient x:I

.field public transient y:Lhx/u;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lhx/w;->L:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method

.method public static a()Lhx/w;
    .registers 4

    .line 1
    new-instance v0, Lhx/w;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/AbstractMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const v1, 0x3fffffff    # 1.9999999f

    .line 7
    .line 8
    .line 9
    const/4 v2, 0x3

    .line 10
    const/4 v3, 0x1

    .line 11
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    iput v1, v0, Lhx/w;->w:I

    .line 20
    .line 21
    return-object v0
.end method

.method public static b(I)Lhx/w;
    .registers 5

    .line 1
    new-instance v0, Lhx/w;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/AbstractMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    if-ltz p0, :cond_a

    .line 8
    .line 9
    move v2, v1

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    const/4 v2, 0x0

    .line 12
    :goto_b
    const-string v3, "Expected size must be >= 0"

    .line 13
    .line 14
    invoke-static {v3, v2}, Loq/a;->m(Ljava/lang/String;Z)V

    .line 15
    .line 16
    .line 17
    const v2, 0x3fffffff    # 1.9999999f

    .line 18
    .line 19
    .line 20
    invoke-static {p0, v1}, Ljava/lang/Math;->max(II)I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    invoke-static {p0, v2}, Ljava/lang/Math;->min(II)I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    iput p0, v0, Lhx/w;->w:I

    .line 29
    .line 30
    return-object v0
.end method


# virtual methods
.method public final c()Ljava/util/Map;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 2
    .line 3
    instance-of v1, v0, Ljava/util/Map;

    .line 4
    .line 5
    if-eqz v1, :cond_9

    .line 6
    .line 7
    check-cast v0, Ljava/util/Map;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    return-object v0
.end method

.method public final clear()V
    .registers 7

    .line 1
    invoke-virtual {p0}, Lhx/w;->g()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    iget v0, p0, Lhx/w;->w:I

    .line 9
    .line 10
    add-int/lit8 v0, v0, 0x20

    .line 11
    .line 12
    iput v0, p0, Lhx/w;->w:I

    .line 13
    .line 14
    invoke-virtual {p0}, Lhx/w;->c()Ljava/util/Map;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const/4 v1, 0x0

    .line 19
    const/4 v2, 0x0

    .line 20
    if-eqz v0, :cond_2f

    .line 21
    .line 22
    invoke-virtual {p0}, Lhx/w;->size()I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    const v4, 0x3fffffff    # 1.9999999f

    .line 27
    .line 28
    .line 29
    const/4 v5, 0x3

    .line 30
    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    iput v3, p0, Lhx/w;->w:I

    .line 39
    .line 40
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 41
    .line 42
    .line 43
    iput-object v1, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 44
    .line 45
    iput v2, p0, Lhx/w;->x:I

    .line 46
    .line 47
    return-void

    .line 48
    :cond_2f
    invoke-virtual {p0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iget v3, p0, Lhx/w;->x:I

    .line 53
    .line 54
    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    iget v3, p0, Lhx/w;->x:I

    .line 62
    .line 63
    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iget-object v0, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 67
    .line 68
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    instance-of v1, v0, [B

    .line 72
    .line 73
    if-eqz v1, :cond_50

    .line 74
    .line 75
    check-cast v0, [B

    .line 76
    .line 77
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([BB)V

    .line 78
    .line 79
    .line 80
    goto :goto_5f

    .line 81
    :cond_50
    instance-of v1, v0, [S

    .line 82
    .line 83
    if-eqz v1, :cond_5a

    .line 84
    .line 85
    check-cast v0, [S

    .line 86
    .line 87
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([SS)V

    .line 88
    .line 89
    .line 90
    goto :goto_5f

    .line 91
    :cond_5a
    check-cast v0, [I

    .line 92
    .line 93
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    .line 94
    .line 95
    .line 96
    :goto_5f
    invoke-virtual {p0}, Lhx/w;->i()[I

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    iget v1, p0, Lhx/w;->x:I

    .line 101
    .line 102
    invoke-static {v0, v2, v1, v2}, Ljava/util/Arrays;->fill([IIII)V

    .line 103
    .line 104
    .line 105
    iput v2, p0, Lhx/w;->x:I

    .line 106
    .line 107
    return-void
.end method

.method public final containsKey(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/w;->c()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1

    .line 12
    :cond_b
    invoke-virtual {p0, p1}, Lhx/w;->e(Ljava/lang/Object;)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    const/4 v0, -0x1

    .line 17
    if-eq p1, v0, :cond_14

    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    return p1

    .line 21
    :cond_14
    const/4 p1, 0x0

    .line 22
    return p1
.end method

.method public final containsValue(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    invoke-virtual {p0}, Lhx/w;->c()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-interface {v0, p1}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    move v1, v0

    .line 14
    :goto_d
    iget v2, p0, Lhx/w;->x:I

    .line 15
    .line 16
    if-ge v1, v2, :cond_22

    .line 17
    .line 18
    invoke-virtual {p0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    aget-object v2, v2, v1

    .line 23
    .line 24
    invoke-static {p1, v2}, Lmn/a;->u(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_1f

    .line 29
    .line 30
    const/4 p1, 0x1

    .line 31
    return p1

    .line 32
    :cond_1f
    add-int/lit8 v1, v1, 0x1

    .line 33
    .line 34
    goto :goto_d

    .line 35
    :cond_22
    return v0
.end method

.method public final d()I
    .registers 3

    .line 1
    iget v0, p0, Lhx/w;->w:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x1f

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    shl-int v0, v1, v0

    .line 7
    .line 8
    sub-int/2addr v0, v1

    .line 9
    return v0
.end method

.method public final e(Ljava/lang/Object;)I
    .registers 9

    .line 1
    invoke-virtual {p0}, Lhx/w;->g()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-eqz v0, :cond_8

    .line 7
    .line 8
    return v1

    .line 9
    :cond_8
    invoke-static {p1}, Lhx/s;->w(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p0}, Lhx/w;->d()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    iget-object v3, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 18
    .line 19
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    and-int v4, v0, v2

    .line 23
    .line 24
    invoke-static {v4, v3}, Lhx/s;->x(ILjava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    if-nez v3, :cond_1e

    .line 29
    .line 30
    return v1

    .line 31
    :cond_1e
    not-int v4, v2

    .line 32
    and-int/2addr v0, v4

    .line 33
    :cond_20
    add-int/lit8 v3, v3, -0x1

    .line 34
    .line 35
    invoke-virtual {p0}, Lhx/w;->i()[I

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    aget v5, v5, v3

    .line 40
    .line 41
    and-int v6, v5, v4

    .line 42
    .line 43
    if-ne v6, v0, :cond_39

    .line 44
    .line 45
    invoke-virtual {p0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    aget-object v6, v6, v3

    .line 50
    .line 51
    invoke-static {p1, v6}, Lmn/a;->u(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_39

    .line 56
    .line 57
    return v3

    .line 58
    :cond_39
    and-int v3, v5, v2

    .line 59
    .line 60
    if-nez v3, :cond_20

    .line 61
    .line 62
    return v1
.end method

.method public final entrySet()Ljava/util/Set;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/w;->J:Lhx/u;

    .line 2
    .line 3
    if-nez v0, :cond_c

    .line 4
    .line 5
    new-instance v0, Lhx/u;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, p0, v1}, Lhx/u;-><init>(Lhx/w;I)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lhx/w;->J:Lhx/u;

    .line 12
    .line 13
    :cond_c
    return-object v0
.end method

.method public final f(II)V
    .registers 13

    .line 1
    iget-object v0, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lhx/w;->i()[I

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {p0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {p0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {p0}, Lhx/w;->size()I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    add-int/lit8 v5, v4, -0x1

    .line 23
    .line 24
    const/4 v6, 0x0

    .line 25
    const/4 v7, 0x0

    .line 26
    if-ge p1, v5, :cond_51

    .line 27
    .line 28
    aget-object v8, v2, v5

    .line 29
    .line 30
    aput-object v8, v2, p1

    .line 31
    .line 32
    aget-object v9, v3, v5

    .line 33
    .line 34
    aput-object v9, v3, p1

    .line 35
    .line 36
    aput-object v7, v2, v5

    .line 37
    .line 38
    aput-object v7, v3, v5

    .line 39
    .line 40
    aget v2, v1, v5

    .line 41
    .line 42
    aput v2, v1, p1

    .line 43
    .line 44
    aput v6, v1, v5

    .line 45
    .line 46
    invoke-static {v8}, Lhx/s;->w(Ljava/lang/Object;)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    and-int/2addr v2, p2

    .line 51
    invoke-static {v2, v0}, Lhx/s;->x(ILjava/lang/Object;)I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    if-ne v3, v4, :cond_3e

    .line 56
    .line 57
    add-int/lit8 p1, p1, 0x1

    .line 58
    .line 59
    invoke-static {v2, p1, v0}, Lhx/s;->y(IILjava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_3e
    :goto_3e
    add-int/lit8 v3, v3, -0x1

    .line 64
    .line 65
    aget v0, v1, v3

    .line 66
    .line 67
    and-int v2, v0, p2

    .line 68
    .line 69
    if-ne v2, v4, :cond_4f

    .line 70
    .line 71
    add-int/lit8 p1, p1, 0x1

    .line 72
    .line 73
    invoke-static {v0, p1, p2}, Lhx/s;->r(III)I

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    aput p1, v1, v3

    .line 78
    .line 79
    return-void

    .line 80
    :cond_4f
    move v3, v2

    .line 81
    goto :goto_3e

    .line 82
    :cond_51
    aput-object v7, v2, p1

    .line 83
    .line 84
    aput-object v7, v3, p1

    .line 85
    .line 86
    aput v6, v1, p1

    .line 87
    .line 88
    return-void
.end method

.method public final g()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    return v0

    .line 7
    :cond_6
    const/4 v0, 0x0

    .line 8
    return v0
.end method

.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/w;->c()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    return-object p1

    .line 12
    :cond_b
    invoke-virtual {p0, p1}, Lhx/w;->e(Ljava/lang/Object;)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    const/4 v0, -0x1

    .line 17
    if-ne p1, v0, :cond_14

    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    return-object p1

    .line 21
    :cond_14
    invoke-virtual {p0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    aget-object p1, v0, p1

    .line 26
    .line 27
    return-object p1
.end method

.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    invoke-virtual {p0}, Lhx/w;->g()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    goto :goto_22

    .line 8
    :cond_7
    invoke-virtual {p0}, Lhx/w;->d()I

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    iget-object v4, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Lhx/w;->i()[I

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    invoke-virtual {p0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    const/4 v7, 0x0

    .line 26
    const/4 v2, 0x0

    .line 27
    move-object v1, p1

    .line 28
    invoke-static/range {v1 .. v7}, Lhx/s;->t(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;[I[Ljava/lang/Object;[Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    const/4 v0, -0x1

    .line 33
    if-ne p1, v0, :cond_25

    .line 34
    .line 35
    :goto_22
    sget-object p1, Lhx/w;->L:Ljava/lang/Object;

    .line 36
    .line 37
    return-object p1

    .line 38
    :cond_25
    invoke-virtual {p0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    aget-object v0, v0, p1

    .line 43
    .line 44
    invoke-virtual {p0, p1, v3}, Lhx/w;->f(II)V

    .line 45
    .line 46
    .line 47
    iget p1, p0, Lhx/w;->x:I

    .line 48
    .line 49
    add-int/lit8 p1, p1, -0x1

    .line 50
    .line 51
    iput p1, p0, Lhx/w;->x:I

    .line 52
    .line 53
    iget p1, p0, Lhx/w;->w:I

    .line 54
    .line 55
    add-int/lit8 p1, p1, 0x20

    .line 56
    .line 57
    iput p1, p0, Lhx/w;->w:I

    .line 58
    .line 59
    return-object v0
.end method

.method public final i()[I
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/w;->e:[I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [I

    .line 7
    .line 8
    return-object v0
.end method

.method public final isEmpty()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lhx/w;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    return v0

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    return v0
.end method

.method public final j()[Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/w;->i:[Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public final k()[Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/w;->v:[Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public final keySet()Ljava/util/Set;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/w;->y:Lhx/u;

    .line 2
    .line 3
    if-nez v0, :cond_c

    .line 4
    .line 5
    new-instance v0, Lhx/u;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {v0, p0, v1}, Lhx/u;-><init>(Lhx/w;I)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lhx/w;->y:Lhx/u;

    .line 12
    .line 13
    :cond_c
    return-object v0
.end method

.method public final l(IIII)I
    .registers 13

    .line 1
    invoke-static {p2}, Lhx/s;->h(I)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    add-int/lit8 p2, p2, -0x1

    .line 6
    .line 7
    if-eqz p4, :cond_e

    .line 8
    .line 9
    and-int/2addr p3, p2

    .line 10
    add-int/lit8 p4, p4, 0x1

    .line 11
    .line 12
    invoke-static {p3, p4, v0}, Lhx/s;->y(IILjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object p3, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-static {p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lhx/w;->i()[I

    .line 21
    .line 22
    .line 23
    move-result-object p4

    .line 24
    const/4 v1, 0x0

    .line 25
    :goto_18
    if-gt v1, p1, :cond_3c

    .line 26
    .line 27
    invoke-static {v1, p3}, Lhx/s;->x(ILjava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    :goto_1e
    if-eqz v2, :cond_39

    .line 32
    .line 33
    add-int/lit8 v3, v2, -0x1

    .line 34
    .line 35
    aget v4, p4, v3

    .line 36
    .line 37
    not-int v5, p1

    .line 38
    and-int/2addr v5, v4

    .line 39
    or-int/2addr v5, v1

    .line 40
    and-int v6, v5, p2

    .line 41
    .line 42
    invoke-static {v6, v0}, Lhx/s;->x(ILjava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    invoke-static {v6, v2, v0}, Lhx/s;->y(IILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-static {v5, v7, p2}, Lhx/s;->r(III)I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    aput v2, p4, v3

    .line 54
    .line 55
    and-int v2, v4, p1

    .line 56
    .line 57
    goto :goto_1e

    .line 58
    :cond_39
    add-int/lit8 v1, v1, 0x1

    .line 59
    .line 60
    goto :goto_18

    .line 61
    :cond_3c
    iput-object v0, p0, Lhx/w;->d:Ljava/lang/Object;

    .line 62
    .line 63
    invoke-static {p2}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    rsub-int/lit8 p1, p1, 0x20

    .line 68
    .line 69
    iget p3, p0, Lhx/w;->w:I

    .line 70
    .line 71
    const/16 p4, 0x1f

    .line 72
    .line 73
    invoke-static {p3, p1, p4}, Lhx/s;->r(III)I

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    iput p1, p0, Lhx/w;->w:I

    .line 78
    .line 79
    return p2
.end method

.method public final put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-virtual {v0}, Lhx/w;->g()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    const/4 v4, 0x2

    .line 12
    const/4 v5, 0x4

    .line 13
    const/16 v6, 0x20

    .line 14
    .line 15
    const/4 v7, 0x1

    .line 16
    if-eqz v3, :cond_5b

    .line 17
    .line 18
    invoke-virtual {v0}, Lhx/w;->g()Z

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    const-string v8, "Arrays already allocated"

    .line 23
    .line 24
    invoke-static {v8, v3}, Loq/a;->y(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    iget v3, v0, Lhx/w;->w:I

    .line 28
    .line 29
    add-int/lit8 v8, v3, 0x1

    .line 30
    .line 31
    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    .line 32
    .line 33
    .line 34
    move-result v8

    .line 35
    invoke-static {v8}, Ljava/lang/Integer;->highestOneBit(I)I

    .line 36
    .line 37
    .line 38
    move-result v9

    .line 39
    int-to-double v10, v9

    .line 40
    const-wide/high16 v12, 0x3ff0000000000000L    # 1.0

    .line 41
    .line 42
    mul-double/2addr v12, v10

    .line 43
    double-to-int v10, v12

    .line 44
    if-le v8, v10, :cond_34

    .line 45
    .line 46
    shl-int/lit8 v9, v9, 0x1

    .line 47
    .line 48
    if-lez v9, :cond_32

    .line 49
    .line 50
    goto :goto_34

    .line 51
    :cond_32
    const/high16 v9, 0x40000000    # 2.0f

    .line 52
    .line 53
    :cond_34
    :goto_34
    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    .line 54
    .line 55
    .line 56
    move-result v8

    .line 57
    invoke-static {v8}, Lhx/s;->h(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    iput-object v9, v0, Lhx/w;->d:Ljava/lang/Object;

    .line 62
    .line 63
    sub-int/2addr v8, v7

    .line 64
    invoke-static {v8}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    .line 65
    .line 66
    .line 67
    move-result v8

    .line 68
    rsub-int/lit8 v8, v8, 0x20

    .line 69
    .line 70
    iget v9, v0, Lhx/w;->w:I

    .line 71
    .line 72
    const/16 v10, 0x1f

    .line 73
    .line 74
    invoke-static {v9, v8, v10}, Lhx/s;->r(III)I

    .line 75
    .line 76
    .line 77
    move-result v8

    .line 78
    iput v8, v0, Lhx/w;->w:I

    .line 79
    .line 80
    new-array v8, v3, [I

    .line 81
    .line 82
    iput-object v8, v0, Lhx/w;->e:[I

    .line 83
    .line 84
    new-array v8, v3, [Ljava/lang/Object;

    .line 85
    .line 86
    iput-object v8, v0, Lhx/w;->i:[Ljava/lang/Object;

    .line 87
    .line 88
    new-array v3, v3, [Ljava/lang/Object;

    .line 89
    .line 90
    iput-object v3, v0, Lhx/w;->v:[Ljava/lang/Object;

    .line 91
    .line 92
    :cond_5b
    invoke-virtual {v0}, Lhx/w;->c()Ljava/util/Map;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    if-eqz v3, :cond_66

    .line 97
    .line 98
    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    return-object v1

    .line 103
    :cond_66
    invoke-virtual {v0}, Lhx/w;->i()[I

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    invoke-virtual {v0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    iget v10, v0, Lhx/w;->x:I

    .line 116
    .line 117
    add-int/lit8 v11, v10, 0x1

    .line 118
    .line 119
    invoke-static {v1}, Lhx/s;->w(Ljava/lang/Object;)I

    .line 120
    .line 121
    .line 122
    move-result v12

    .line 123
    invoke-virtual {v0}, Lhx/w;->d()I

    .line 124
    .line 125
    .line 126
    move-result v13

    .line 127
    and-int v14, v12, v13

    .line 128
    .line 129
    iget-object v15, v0, Lhx/w;->d:Ljava/lang/Object;

    .line 130
    .line 131
    invoke-static {v15}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    invoke-static {v14, v15}, Lhx/s;->x(ILjava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v15

    .line 138
    if-nez v15, :cond_a9

    .line 139
    .line 140
    if-le v11, v13, :cond_a0

    .line 141
    .line 142
    if-ge v13, v6, :cond_92

    .line 143
    .line 144
    const/16 v16, 0x4

    .line 145
    .line 146
    goto :goto_94

    .line 147
    :cond_92
    const/16 v16, 0x2

    .line 148
    .line 149
    :goto_94
    add-int/lit8 v3, v13, 0x1

    .line 150
    .line 151
    mul-int v3, v3, v16

    .line 152
    .line 153
    invoke-virtual {v0, v13, v3, v12, v10}, Lhx/w;->l(IIII)I

    .line 154
    .line 155
    .line 156
    move-result v13

    .line 157
    :goto_9c
    move/from16 v19, v7

    .line 158
    .line 159
    goto/16 :goto_12e

    .line 160
    .line 161
    :cond_a0
    iget-object v3, v0, Lhx/w;->d:Ljava/lang/Object;

    .line 162
    .line 163
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    invoke-static {v14, v11, v3}, Lhx/s;->y(IILjava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    goto :goto_9c

    .line 170
    :cond_a9
    not-int v14, v13

    .line 171
    and-int v5, v12, v14

    .line 172
    .line 173
    const/16 v18, 0x0

    .line 174
    .line 175
    :goto_ae
    sub-int/2addr v15, v7

    .line 176
    move/from16 v19, v7

    .line 177
    .line 178
    aget v7, v3, v15

    .line 179
    .line 180
    move/from16 v20, v6

    .line 181
    .line 182
    and-int v6, v7, v14

    .line 183
    .line 184
    if-ne v6, v5, :cond_c6

    .line 185
    .line 186
    aget-object v6, v8, v15

    .line 187
    .line 188
    invoke-static {v1, v6}, Lmn/a;->u(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    move-result v6

    .line 192
    if-eqz v6, :cond_c6

    .line 193
    .line 194
    aget-object v1, v9, v15

    .line 195
    .line 196
    aput-object v2, v9, v15

    .line 197
    .line 198
    return-object v1

    .line 199
    :cond_c6
    and-int v6, v7, v13

    .line 200
    .line 201
    add-int/lit8 v4, v18, 0x1

    .line 202
    .line 203
    if-nez v6, :cond_18a

    .line 204
    .line 205
    const/16 v5, 0x9

    .line 206
    .line 207
    if-lt v4, v5, :cond_117

    .line 208
    .line 209
    invoke-virtual {v0}, Lhx/w;->d()I

    .line 210
    .line 211
    .line 212
    move-result v3

    .line 213
    add-int/lit8 v3, v3, 0x1

    .line 214
    .line 215
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 216
    .line 217
    const/high16 v5, 0x3f800000    # 1.0f

    .line 218
    .line 219
    invoke-direct {v4, v3, v5}, Ljava/util/LinkedHashMap;-><init>(IF)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v0}, Lhx/w;->isEmpty()Z

    .line 223
    .line 224
    .line 225
    move-result v3

    .line 226
    const/4 v5, -0x1

    .line 227
    if-eqz v3, :cond_e7

    .line 228
    .line 229
    :cond_e4
    move/from16 v17, v5

    .line 230
    .line 231
    goto :goto_e9

    .line 232
    :cond_e7
    const/16 v17, 0x0

    .line 233
    .line 234
    :goto_e9
    if-ltz v17, :cond_103

    .line 235
    .line 236
    invoke-virtual {v0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v3

    .line 240
    aget-object v3, v3, v17

    .line 241
    .line 242
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v6

    .line 246
    aget-object v6, v6, v17

    .line 247
    .line 248
    invoke-interface {v4, v3, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    add-int/lit8 v3, v17, 0x1

    .line 252
    .line 253
    iget v6, v0, Lhx/w;->x:I

    .line 254
    .line 255
    if-ge v3, v6, :cond_e4

    .line 256
    .line 257
    move/from16 v17, v3

    .line 258
    .line 259
    goto :goto_e9

    .line 260
    :cond_103
    iput-object v4, v0, Lhx/w;->d:Ljava/lang/Object;

    .line 261
    .line 262
    const/4 v3, 0x0

    .line 263
    iput-object v3, v0, Lhx/w;->e:[I

    .line 264
    .line 265
    iput-object v3, v0, Lhx/w;->i:[Ljava/lang/Object;

    .line 266
    .line 267
    iput-object v3, v0, Lhx/w;->v:[Ljava/lang/Object;

    .line 268
    .line 269
    iget v3, v0, Lhx/w;->w:I

    .line 270
    .line 271
    add-int/lit8 v3, v3, 0x20

    .line 272
    .line 273
    iput v3, v0, Lhx/w;->w:I

    .line 274
    .line 275
    invoke-interface {v4, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object v1

    .line 279
    return-object v1

    .line 280
    :cond_117
    if-le v11, v13, :cond_128

    .line 281
    .line 282
    move/from16 v4, v20

    .line 283
    .line 284
    if-ge v13, v4, :cond_11f

    .line 285
    .line 286
    const/4 v4, 0x4

    .line 287
    goto :goto_120

    .line 288
    :cond_11f
    const/4 v4, 0x2

    .line 289
    :goto_120
    add-int/lit8 v3, v13, 0x1

    .line 290
    .line 291
    mul-int/2addr v3, v4

    .line 292
    invoke-virtual {v0, v13, v3, v12, v10}, Lhx/w;->l(IIII)I

    .line 293
    .line 294
    .line 295
    move-result v13

    .line 296
    goto :goto_12e

    .line 297
    :cond_128
    invoke-static {v7, v11, v13}, Lhx/s;->r(III)I

    .line 298
    .line 299
    .line 300
    move-result v4

    .line 301
    aput v4, v3, v15

    .line 302
    .line 303
    :goto_12e
    invoke-virtual {v0}, Lhx/w;->i()[I

    .line 304
    .line 305
    .line 306
    move-result-object v3

    .line 307
    array-length v3, v3

    .line 308
    if-le v11, v3, :cond_166

    .line 309
    .line 310
    ushr-int/lit8 v4, v3, 0x1

    .line 311
    .line 312
    move/from16 v7, v19

    .line 313
    .line 314
    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    .line 315
    .line 316
    .line 317
    move-result v4

    .line 318
    add-int/2addr v4, v3

    .line 319
    or-int/2addr v4, v7

    .line 320
    const v5, 0x3fffffff    # 1.9999999f

    .line 321
    .line 322
    .line 323
    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    .line 324
    .line 325
    .line 326
    move-result v4

    .line 327
    if-eq v4, v3, :cond_166

    .line 328
    .line 329
    invoke-virtual {v0}, Lhx/w;->i()[I

    .line 330
    .line 331
    .line 332
    move-result-object v3

    .line 333
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([II)[I

    .line 334
    .line 335
    .line 336
    move-result-object v3

    .line 337
    iput-object v3, v0, Lhx/w;->e:[I

    .line 338
    .line 339
    invoke-virtual {v0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 340
    .line 341
    .line 342
    move-result-object v3

    .line 343
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v3

    .line 347
    iput-object v3, v0, Lhx/w;->i:[Ljava/lang/Object;

    .line 348
    .line 349
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v3

    .line 353
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 354
    .line 355
    .line 356
    move-result-object v3

    .line 357
    iput-object v3, v0, Lhx/w;->v:[Ljava/lang/Object;

    .line 358
    .line 359
    :cond_166
    const/4 v15, 0x0

    .line 360
    invoke-static {v12, v15, v13}, Lhx/s;->r(III)I

    .line 361
    .line 362
    .line 363
    move-result v3

    .line 364
    invoke-virtual {v0}, Lhx/w;->i()[I

    .line 365
    .line 366
    .line 367
    move-result-object v4

    .line 368
    aput v3, v4, v10

    .line 369
    .line 370
    invoke-virtual {v0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    move-result-object v3

    .line 374
    aput-object v1, v3, v10

    .line 375
    .line 376
    invoke-virtual {v0}, Lhx/w;->k()[Ljava/lang/Object;

    .line 377
    .line 378
    .line 379
    move-result-object v1

    .line 380
    aput-object v2, v1, v10

    .line 381
    .line 382
    iput v11, v0, Lhx/w;->x:I

    .line 383
    .line 384
    iget v1, v0, Lhx/w;->w:I

    .line 385
    .line 386
    const/16 v20, 0x20

    .line 387
    .line 388
    add-int/lit8 v1, v1, 0x20

    .line 389
    .line 390
    iput v1, v0, Lhx/w;->w:I

    .line 391
    .line 392
    const/16 v21, 0x0

    .line 393
    .line 394
    return-object v21

    .line 395
    :cond_18a
    const/16 v21, 0x0

    .line 396
    .line 397
    move/from16 v18, v4

    .line 398
    .line 399
    move v15, v6

    .line 400
    move/from16 v7, v19

    .line 401
    .line 402
    move/from16 v6, v20

    .line 403
    .line 404
    goto/16 :goto_ae
.end method

.method public final remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/w;->c()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    return-object p1

    .line 12
    :cond_b
    invoke-virtual {p0, p1}, Lhx/w;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    sget-object v0, Lhx/w;->L:Ljava/lang/Object;

    .line 17
    .line 18
    if-ne p1, v0, :cond_14

    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    :cond_14
    return-object p1
.end method

.method public final size()I
    .registers 2

    .line 1
    invoke-virtual {p0}, Lhx/w;->c()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0

    .line 12
    :cond_b
    iget v0, p0, Lhx/w;->x:I

    .line 13
    .line 14
    return v0
.end method

.method public final values()Ljava/util/Collection;
    .registers 3

    .line 1
    iget-object v0, p0, Lhx/w;->K:Lhx/o;

    .line 2
    .line 3
    if-nez v0, :cond_c

    .line 4
    .line 5
    new-instance v0, Lhx/o;

    .line 6
    .line 7
    const/4 v1, 0x2

    .line 8
    invoke-direct {v0, v1, p0}, Lhx/o;-><init>(ILjava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lhx/w;->K:Lhx/o;

    .line 12
    .line 13
    :cond_c
    return-object v0
.end method
