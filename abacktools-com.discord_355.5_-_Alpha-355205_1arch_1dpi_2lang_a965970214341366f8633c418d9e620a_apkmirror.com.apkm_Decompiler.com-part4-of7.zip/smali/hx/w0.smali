###### Class hx.w0 (hx.w0)
.class public final Lhx/w0;
.super Lhx/f0;
.source "SourceFile"


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;)Lhx/g0;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lhx/w0;->g(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    return-object p0
.end method

.method public final g(Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final h(Ljava/util/List;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Lhx/f0;->e(Ljava/lang/Iterable;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final i()Lhx/x0;
    .registers 4

    .line 1
    iget v0, p0, Lhx/f0;->b:I

    .line 2
    .line 3
    if-eqz v0, :cond_26

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-eq v0, v1, :cond_16

    .line 7
    .line 8
    iget-object v2, p0, Lhx/f0;->a:[Ljava/lang/Object;

    .line 9
    .line 10
    invoke-static {v0, v2}, Lhx/x0;->p(I[Ljava/lang/Object;)Lhx/x0;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    iput v2, p0, Lhx/f0;->b:I

    .line 19
    .line 20
    iput-boolean v1, p0, Lhx/f0;->c:Z

    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_16
    iget-object v0, p0, Lhx/f0;->a:[Ljava/lang/Object;

    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    aget-object v0, v0, v1

    .line 27
    .line 28
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    sget v1, Lhx/x0;->i:I

    .line 32
    .line 33
    new-instance v1, Lhx/j2;

    .line 34
    .line 35
    invoke-direct {v1, v0}, Lhx/j2;-><init>(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    return-object v1

    .line 39
    :cond_26
    sget v0, Lhx/x0;->i:I

    .line 40
    .line 41
    sget-object v0, Lhx/d2;->L:Lhx/d2;

    .line 42
    .line 43
    return-object v0
.end method
