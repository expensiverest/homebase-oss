###### Class hx.k1 (hx.k1)
.class public interface abstract Lhx/k1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
