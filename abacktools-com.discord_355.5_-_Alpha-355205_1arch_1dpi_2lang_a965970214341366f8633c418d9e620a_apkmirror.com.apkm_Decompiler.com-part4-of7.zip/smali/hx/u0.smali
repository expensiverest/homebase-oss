###### Class hx.u0 (hx.u0)
.class public final Lhx/u0;
.super Lhx/x0;
.source "SourceFile"


# instance fields
.field public final synthetic v:I

.field public final synthetic w:Lhx/v0;


# direct methods
.method public synthetic constructor <init>(Lhx/v0;I)V
    .registers 3

    .line 1
    iput p2, p0, Lhx/u0;->v:I

    iput-object p1, p0, Lhx/u0;->w:Lhx/v0;

    invoke-direct {p0}, Ljava/util/AbstractCollection;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(I[Ljava/lang/Object;)I
    .registers 4

    .line 1
    invoke-virtual {p0}, Lhx/x0;->a()Lhx/m0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p1, p2}, Lhx/m0;->b(I[Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    return p1
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    iget v0, p0, Lhx/u0;->v:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_30

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lhx/u0;->w:Lhx/v0;

    .line 7
    .line 8
    check-cast v0, Lhx/c2;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Lhx/v0;->contains(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    return p1

    .line 15
    :pswitch_e
    instance-of v0, p1, Lhx/s1;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    if-eqz v0, :cond_2f

    .line 19
    .line 20
    check-cast p1, Lhx/s1;

    .line 21
    .line 22
    invoke-virtual {p1}, Lhx/s1;->a()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-gtz v0, :cond_1c

    .line 27
    .line 28
    goto :goto_2f

    .line 29
    :cond_1c
    iget-object v0, p1, Lhx/s1;->a:Ljava/lang/Object;

    .line 30
    .line 31
    iget-object v2, p0, Lhx/u0;->w:Lhx/v0;

    .line 32
    .line 33
    check-cast v2, Lhx/c2;

    .line 34
    .line 35
    iget-object v2, v2, Lhx/c2;->w:Lhx/t1;

    .line 36
    .line 37
    invoke-virtual {v2, v0}, Lhx/t1;->b(Ljava/lang/Object;)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {p1}, Lhx/s1;->a()I

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    if-ne v0, p1, :cond_2f

    .line 46
    .line 47
    const/4 v1, 0x1

    .line 48
    :cond_2f
    :goto_2f
    return v1

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/u0;->v:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_12

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Lhx/x0;->hashCode()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    return v0

    .line 11
    :pswitch_a
    iget-object v0, p0, Lhx/u0;->w:Lhx/v0;

    .line 12
    .line 13
    invoke-virtual {v0}, Lhx/v0;->hashCode()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    return v0

    .line 18
    nop

    .line 19
    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method

.method public final k()Z
    .registers 2

    .line 1
    iget v0, p0, Lhx/u0;->v:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    return v0

    .line 8
    :pswitch_7
    iget-object v0, p0, Lhx/u0;->w:Lhx/v0;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    return v0

    .line 15
    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_7
    .end packed-switch
.end method

.method public final m()Lhx/l2;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lhx/x0;->a()Lhx/m0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Lhx/m0;->s(I)Lhx/k0;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0
.end method

.method public final r()Lhx/m0;
    .registers 2

    .line 1
    new-instance v0, Lhx/y0;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lhx/y0;-><init>(Lhx/u0;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final size()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/u0;->v:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1a

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lhx/u0;->w:Lhx/v0;

    .line 7
    .line 8
    check-cast v0, Lhx/c2;

    .line 9
    .line 10
    iget-object v0, v0, Lhx/c2;->w:Lhx/t1;

    .line 11
    .line 12
    iget v0, v0, Lhx/t1;->c:I

    .line 13
    .line 14
    return v0

    .line 15
    :pswitch_e
    iget-object v0, p0, Lhx/u0;->w:Lhx/v0;

    .line 16
    .line 17
    invoke-virtual {v0}, Lhx/v0;->o()Lhx/x0;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    return v0

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
