###### Class hx.t (hx.t)
.class public final Lhx/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field public d:I

.field public e:I

.field public i:I

.field public final synthetic v:Lhx/w;

.field public final synthetic w:I

.field public final synthetic x:Lhx/w;


# direct methods
.method public constructor <init>(Lhx/w;I)V
    .registers 3

    .line 1
    iput p2, p0, Lhx/t;->w:I

    .line 2
    .line 3
    iput-object p1, p0, Lhx/t;->x:Lhx/w;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lhx/t;->v:Lhx/w;

    .line 9
    .line 10
    iget p2, p1, Lhx/w;->w:I

    .line 11
    .line 12
    iput p2, p0, Lhx/t;->d:I

    .line 13
    .line 14
    invoke-virtual {p1}, Lhx/w;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    const/4 p2, -0x1

    .line 19
    if-eqz p1, :cond_16

    .line 20
    .line 21
    move p1, p2

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    const/4 p1, 0x0

    .line 24
    :goto_17
    iput p1, p0, Lhx/t;->e:I

    .line 25
    .line 26
    iput p2, p0, Lhx/t;->i:I

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .line 1
    iget v0, p0, Lhx/t;->e:I

    .line 2
    .line 3
    if-ltz v0, :cond_6

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    return v0

    .line 7
    :cond_6
    const/4 v0, 0x0

    .line 8
    return v0
.end method

.method public final next()Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, Lhx/t;->v:Lhx/w;

    .line 2
    .line 3
    iget v1, v0, Lhx/w;->w:I

    .line 4
    .line 5
    iget v2, p0, Lhx/t;->d:I

    .line 6
    .line 7
    if-ne v1, v2, :cond_44

    .line 8
    .line 9
    invoke-virtual {p0}, Lhx/t;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_3e

    .line 14
    .line 15
    iget v1, p0, Lhx/t;->e:I

    .line 16
    .line 17
    iput v1, p0, Lhx/t;->i:I

    .line 18
    .line 19
    iget v2, p0, Lhx/t;->w:I

    .line 20
    .line 21
    packed-switch v2, :pswitch_data_4a

    .line 22
    .line 23
    .line 24
    iget-object v2, p0, Lhx/t;->x:Lhx/w;

    .line 25
    .line 26
    invoke-virtual {v2}, Lhx/w;->k()[Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    aget-object v1, v2, v1

    .line 31
    .line 32
    goto :goto_31

    .line 33
    :pswitch_20
    new-instance v2, Lhx/v;

    .line 34
    .line 35
    iget-object v3, p0, Lhx/t;->x:Lhx/w;

    .line 36
    .line 37
    invoke-direct {v2, v3, v1}, Lhx/v;-><init>(Lhx/w;I)V

    .line 38
    .line 39
    .line 40
    move-object v1, v2

    .line 41
    goto :goto_31

    .line 42
    :pswitch_29
    iget-object v2, p0, Lhx/t;->x:Lhx/w;

    .line 43
    .line 44
    invoke-virtual {v2}, Lhx/w;->j()[Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    aget-object v1, v2, v1

    .line 49
    .line 50
    :goto_31
    iget v2, p0, Lhx/t;->e:I

    .line 51
    .line 52
    add-int/lit8 v2, v2, 0x1

    .line 53
    .line 54
    iget v0, v0, Lhx/w;->x:I

    .line 55
    .line 56
    if-ge v2, v0, :cond_3a

    .line 57
    .line 58
    goto :goto_3b

    .line 59
    :cond_3a
    const/4 v2, -0x1

    .line 60
    :goto_3b
    iput v2, p0, Lhx/t;->e:I

    .line 61
    .line 62
    return-object v1

    .line 63
    :cond_3e
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 64
    .line 65
    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    .line 66
    .line 67
    .line 68
    throw v0

    .line 69
    :cond_44
    new-instance v0, Ljava/util/ConcurrentModificationException;

    .line 70
    .line 71
    invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V

    .line 72
    .line 73
    .line 74
    throw v0

    .line 75
    :pswitch_data_4a
    .packed-switch 0x0
        :pswitch_29
        :pswitch_20
    .end packed-switch
.end method

.method public final remove()V
    .registers 5

    .line 1
    iget-object v0, p0, Lhx/t;->v:Lhx/w;

    .line 2
    .line 3
    iget v1, v0, Lhx/w;->w:I

    .line 4
    .line 5
    iget v2, p0, Lhx/t;->d:I

    .line 6
    .line 7
    if-ne v1, v2, :cond_2f

    .line 8
    .line 9
    iget v1, p0, Lhx/t;->i:I

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    if-ltz v1, :cond_f

    .line 13
    .line 14
    move v1, v2

    .line 15
    goto :goto_10

    .line 16
    :cond_f
    const/4 v1, 0x0

    .line 17
    :goto_10
    const-string v3, "no calls to next() since the last call to remove()"

    .line 18
    .line 19
    invoke-static {v3, v1}, Loq/a;->y(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    iget v1, p0, Lhx/t;->d:I

    .line 23
    .line 24
    add-int/lit8 v1, v1, 0x20

    .line 25
    .line 26
    iput v1, p0, Lhx/t;->d:I

    .line 27
    .line 28
    iget v1, p0, Lhx/t;->i:I

    .line 29
    .line 30
    invoke-virtual {v0}, Lhx/w;->j()[Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    aget-object v1, v3, v1

    .line 35
    .line 36
    invoke-virtual {v0, v1}, Lhx/w;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    iget v0, p0, Lhx/t;->e:I

    .line 40
    .line 41
    sub-int/2addr v0, v2

    .line 42
    iput v0, p0, Lhx/t;->e:I

    .line 43
    .line 44
    const/4 v0, -0x1

    .line 45
    iput v0, p0, Lhx/t;->i:I

    .line 46
    .line 47
    return-void

    .line 48
    :cond_2f
    new-instance v0, Ljava/util/ConcurrentModificationException;

    .line 49
    .line 50
    invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V

    .line 51
    .line 52
    .line 53
    throw v0
.end method
