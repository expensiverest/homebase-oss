###### Class hx.z (hx.z)
.class public final Lhx/z;
.super Lhx/a0;
.source "SourceFile"


# instance fields
.field public final d:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lhx/z;->d:I

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(II)Lhx/a0;
    .registers 3

    .line 1
    return-object p0
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;
    .registers 4

    .line 1
    return-object p0
.end method

.method public final c(ZZ)Lhx/a0;
    .registers 3

    .line 1
    return-object p0
.end method

.method public final d(ZZ)Lhx/a0;
    .registers 3

    .line 1
    return-object p0
.end method

.method public final e()I
    .registers 2

    .line 1
    iget v0, p0, Lhx/z;->d:I

    .line 2
    .line 3
    return v0
.end method
