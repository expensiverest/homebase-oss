###### Class hx.u1 (hx.u1)
.class public abstract Lhx/u1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static a(Ljava/util/Comparator;)Lhx/u1;
    .registers 2

    .line 1
    instance-of v0, p0, Lhx/u1;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    check-cast p0, Lhx/u1;

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_7
    new-instance v0, Lhx/x;

    .line 9
    .line 10
    invoke-direct {v0, p0}, Lhx/x;-><init>(Ljava/util/Comparator;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method


# virtual methods
.method public c()Lhx/u1;
    .registers 2

    .line 1
    new-instance v0, Lhx/e2;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lhx/e2;-><init>(Lhx/u1;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
