###### Class hx.i (hx.i)
.class public final Lhx/i;
.super Lhx/m;
.source "SourceFile"

# interfaces
.implements Ljava/util/RandomAccess;
