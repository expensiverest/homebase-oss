###### Class hx.p1 (hx.p1)
.class public final Lhx/p1;
.super Lhx/p;
.source "SourceFile"

# interfaces
.implements Lhx/e1;


# instance fields
.field public final w:Lhx/e1;

.field public final x:Lbu/i;


# direct methods
.method public constructor <init>(Lhx/e1;Lbu/i;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lhx/p1;->w:Lhx/e1;

    .line 8
    .line 9
    iput-object p2, p0, Lhx/p1;->x:Lbu/i;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final c()Ljava/util/Map;
    .registers 4

    .line 1
    iget-object v0, p0, Lhx/p1;->w:Lhx/e1;

    .line 2
    .line 3
    invoke-interface {v0}, Lhx/m1;->asMap()Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Lapp/rive/runtime/kotlin/a;

    .line 8
    .line 9
    const/16 v2, 0x16

    .line 10
    .line 11
    invoke-direct {v1, v2, p0}, Lapp/rive/runtime/kotlin/a;-><init>(ILjava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    new-instance v2, Lhx/l1;

    .line 15
    .line 16
    invoke-direct {v2, v0, v1}, Lhx/l1;-><init>(Ljava/util/Map;Lhx/k1;)V

    .line 17
    .line 18
    .line 19
    return-object v2
.end method

.method public final clear()V
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/p1;->w:Lhx/e1;

    .line 2
    .line 3
    invoke-interface {v0}, Lhx/m1;->clear()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final d()Ljava/util/Collection;
    .registers 3

    .line 1
    new-instance v0, Lhx/o;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1, p0}, Lhx/o;-><init>(ILjava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final e()Ljava/util/Set;
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/p1;->w:Lhx/e1;

    .line 2
    .line 3
    invoke-interface {v0}, Lhx/m1;->keySet()Ljava/util/Set;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final f()Ljava/util/Iterator;
    .registers 5

    .line 1
    iget-object v0, p0, Lhx/p1;->w:Lhx/e1;

    .line 2
    .line 3
    invoke-interface {v0}, Lhx/m1;->a()Ljava/util/Collection;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    new-instance v1, La8/d;

    .line 12
    .line 13
    const/16 v2, 0x14

    .line 14
    .line 15
    iget-object v3, p0, Lhx/p1;->x:Lbu/i;

    .line 16
    .line 17
    invoke-direct {v1, v2, v3}, La8/d;-><init>(ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    new-instance v2, Lhx/a1;

    .line 21
    .line 22
    invoke-direct {v2, v0, v1}, Lhx/a1;-><init>(Ljava/util/Iterator;Lgx/k;)V

    .line 23
    .line 24
    .line 25
    return-object v2
.end method

.method public final get(Ljava/lang/Object;)Ljava/util/Collection;
    .registers 6

    .line 1
    iget-object v0, p0, Lhx/p1;->w:Lhx/e1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Lhx/m1;->get(Ljava/lang/Object;)Ljava/util/Collection;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/util/List;

    .line 8
    .line 9
    new-instance v1, Lk7/e;

    .line 10
    .line 11
    const/16 v2, 0xf

    .line 12
    .line 13
    iget-object v3, p0, Lhx/p1;->x:Lbu/i;

    .line 14
    .line 15
    invoke-direct {v1, v2, v3, p1}, Lk7/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-static {v0, v1}, Lhx/s;->z(Ljava/util/List;Lgx/k;)Ljava/util/AbstractList;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1
.end method

.method public final remove(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 3

    .line 1
    invoke-virtual {p0, p1}, Lhx/p1;->get(Ljava/lang/Object;)Ljava/util/Collection;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-interface {p1, p2}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    return p1
.end method

.method public final size()I
    .registers 2

    .line 1
    iget-object v0, p0, Lhx/p1;->w:Lhx/e1;

    .line 2
    .line 3
    invoke-interface {v0}, Lhx/m1;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method
