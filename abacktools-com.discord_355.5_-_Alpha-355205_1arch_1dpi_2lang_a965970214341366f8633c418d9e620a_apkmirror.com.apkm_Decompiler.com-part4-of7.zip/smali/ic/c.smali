###### Class ic.c (ic.c)
.class public final Lic/c;
.super Ls30/i;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic J:Ljava/util/List;

.field public final synthetic K:Landroid/content/Context;

.field public d:Landroid/graphics/Bitmap;

.field public e:Landroid/graphics/Canvas;

.field public i:Landroid/graphics/Rect;

.field public v:Landroid/graphics/Paint;

.field public w:Ljava/util/Iterator;

.field public x:I

.field public final synthetic y:I


# direct methods
.method public constructor <init>(ILjava/util/List;Landroid/content/Context;Lq30/c;)V
    .registers 5

    .line 1
    iput p1, p0, Lic/c;->y:I

    .line 2
    .line 3
    iput-object p2, p0, Lic/c;->J:Ljava/util/List;

    .line 4
    .line 5
    iput-object p3, p0, Lic/c;->K:Landroid/content/Context;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Ls30/i;-><init>(ILq30/c;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lq30/c;)Lq30/c;
    .registers 6

    .line 1
    new-instance p1, Lic/c;

    .line 2
    .line 3
    iget-object v0, p0, Lic/c;->J:Ljava/util/List;

    .line 4
    .line 5
    iget-object v1, p0, Lic/c;->K:Landroid/content/Context;

    .line 6
    .line 7
    iget v2, p0, Lic/c;->y:I

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, Lic/c;-><init>(ILjava/util/List;Landroid/content/Context;Lq30/c;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Lz60/x;

    .line 2
    .line 3
    check-cast p2, Lq30/c;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lic/c;->create(Ljava/lang/Object;Lq30/c;)Lq30/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lic/c;

    .line 10
    .line 11
    sget-object p2, Ll30/a0;->a:Ll30/a0;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lic/c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 1
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 2
    .line 3
    iget v1, p0, Lic/c;->x:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_20

    .line 8
    .line 9
    if-ne v1, v3, :cond_18

    .line 10
    .line 11
    iget-object v1, p0, Lic/c;->w:Ljava/util/Iterator;

    .line 12
    .line 13
    iget-object v4, p0, Lic/c;->v:Landroid/graphics/Paint;

    .line 14
    .line 15
    iget-object v5, p0, Lic/c;->i:Landroid/graphics/Rect;

    .line 16
    .line 17
    iget-object v6, p0, Lic/c;->e:Landroid/graphics/Canvas;

    .line 18
    .line 19
    iget-object v7, p0, Lic/c;->d:Landroid/graphics/Bitmap;

    .line 20
    .line 21
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    goto :goto_7e

    .line 25
    :cond_18
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 26
    .line 27
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 28
    .line 29
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    throw p1

    .line 33
    :cond_20
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    sget-object p1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 37
    .line 38
    iget v1, p0, Lic/c;->y:I

    .line 39
    .line 40
    invoke-static {v1, v1, p1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    new-instance v4, Landroid/graphics/Canvas;

    .line 45
    .line 46
    invoke-direct {v4, p1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 47
    .line 48
    .line 49
    new-instance v5, Landroid/graphics/Rect;

    .line 50
    .line 51
    const/4 v6, 0x0

    .line 52
    invoke-direct {v5, v6, v6, v1, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 53
    .line 54
    .line 55
    new-instance v1, Landroid/graphics/Paint;

    .line 56
    .line 57
    const/4 v6, 0x2

    .line 58
    invoke-direct {v1, v6}, Landroid/graphics/Paint;-><init>(I)V

    .line 59
    .line 60
    .line 61
    iget-object v6, p0, Lic/c;->J:Ljava/util/List;

    .line 62
    .line 63
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    move-object v7, v4

    .line 68
    move-object v4, v1

    .line 69
    move-object v1, v6

    .line 70
    move-object v6, v7

    .line 71
    move-object v7, p1

    .line 72
    :cond_47
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    if-eqz p1, :cond_87

    .line 77
    .line 78
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    check-cast p1, Ljava/lang/String;

    .line 83
    .line 84
    iput-object v7, p0, Lic/c;->d:Landroid/graphics/Bitmap;

    .line 85
    .line 86
    iput-object v6, p0, Lic/c;->e:Landroid/graphics/Canvas;

    .line 87
    .line 88
    iput-object v5, p0, Lic/c;->i:Landroid/graphics/Rect;

    .line 89
    .line 90
    iput-object v4, p0, Lic/c;->v:Landroid/graphics/Paint;

    .line 91
    .line 92
    iput-object v1, p0, Lic/c;->w:Ljava/util/Iterator;

    .line 93
    .line 94
    iput v3, p0, Lic/c;->x:I

    .line 95
    .line 96
    new-instance v8, Lz60/k;

    .line 97
    .line 98
    invoke-static {p0}, Lul/b;->F(Lq30/c;)Lq30/c;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    invoke-direct {v8, v3, v9}, Lz60/k;-><init>(ILq30/c;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v8}, Lz60/k;->s()V

    .line 106
    .line 107
    .line 108
    new-instance v9, Lic/b;

    .line 109
    .line 110
    invoke-direct {v9, v8, v6, v5, v4}, Lic/b;-><init>(Lz60/k;Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 111
    .line 112
    .line 113
    iget-object v10, p0, Lic/c;->K:Landroid/content/Context;

    .line 114
    .line 115
    invoke-static {v10, p1, v2, v9}, Lxe/k;->b(Landroid/content/Context;Ljava/lang/String;Lbf/a;Lkotlin/jvm/functions/Function1;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v8}, Lz60/k;->r()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    sget-object v8, Lr30/a;->d:Lr30/a;

    .line 123
    .line 124
    if-ne p1, v0, :cond_7e

    .line 125
    .line 126
    return-object v0

    .line 127
    :cond_7e
    :goto_7e
    check-cast p1, Ljava/lang/Boolean;

    .line 128
    .line 129
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 130
    .line 131
    .line 132
    move-result p1

    .line 133
    if-nez p1, :cond_47

    .line 134
    .line 135
    return-object v2

    .line 136
    :cond_87
    return-object v7
.end method
