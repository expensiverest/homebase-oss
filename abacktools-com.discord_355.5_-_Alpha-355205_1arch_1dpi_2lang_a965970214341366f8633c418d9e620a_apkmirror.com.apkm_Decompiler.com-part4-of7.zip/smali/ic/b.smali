###### Class ic.b (ic.b)
.class public final Lic/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:Lz60/k;

.field public final synthetic e:Landroid/graphics/Canvas;

.field public final synthetic i:Landroid/graphics/Rect;

.field public final synthetic v:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Lz60/k;Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lic/b;->d:Lz60/k;

    .line 5
    .line 6
    iput-object p2, p0, Lic/b;->e:Landroid/graphics/Canvas;

    .line 7
    .line 8
    iput-object p3, p0, Lic/b;->i:Landroid/graphics/Rect;

    .line 9
    .line 10
    iput-object p4, p0, Lic/b;->v:Landroid/graphics/Paint;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    check-cast p1, Landroid/graphics/Bitmap;

    .line 2
    .line 3
    iget-object v0, p0, Lic/b;->d:Lz60/k;

    .line 4
    .line 5
    if-eqz p1, :cond_16

    .line 6
    .line 7
    invoke-virtual {v0}, Lz60/k;->w()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_16

    .line 12
    .line 13
    iget-object v1, p0, Lic/b;->i:Landroid/graphics/Rect;

    .line 14
    .line 15
    iget-object v2, p0, Lic/b;->v:Landroid/graphics/Paint;

    .line 16
    .line 17
    iget-object v3, p0, Lic/b;->e:Landroid/graphics/Canvas;

    .line 18
    .line 19
    const/4 v4, 0x0

    .line 20
    invoke-virtual {v3, p1, v4, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 21
    .line 22
    .line 23
    :cond_16
    if-eqz p1, :cond_1a

    .line 24
    .line 25
    const/4 p1, 0x1

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 p1, 0x0

    .line 28
    :goto_1b
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {v0, p1}, Lz60/k;->resumeWith(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 36
    .line 37
    return-object p1
.end method
