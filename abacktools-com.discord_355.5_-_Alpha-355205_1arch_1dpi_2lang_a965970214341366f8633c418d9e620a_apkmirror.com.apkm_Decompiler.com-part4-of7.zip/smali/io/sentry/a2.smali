###### Class io.sentry.a2 (io.sentry.a2)
.class public final Lio/sentry/a2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field public final synthetic d:I

.field public final e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/io/Reader;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lio/sentry/a2;->d:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lio/sentry/vendor/gson/stream/a;

    invoke-direct {v0, p1}, Lio/sentry/vendor/gson/stream/a;-><init>(Ljava/io/Reader;)V

    iput-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/util/Map;)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lio/sentry/a2;->d:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 5
    new-instance v1, Ljava/util/AbstractMap$SimpleEntry;

    const/4 v2, 0x0

    invoke-direct {v1, v2, p1}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    return-void
.end method

.method private final u0(Z)V
    .registers 2

    .line 1
    return-void
.end method

.method private final w0()V
    .registers 1

    .line 1
    return-void
.end method


# virtual methods
.method public final A()Ljava/lang/Float;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_34

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_18

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    const/4 v0, 0x0

    .line 26
    :goto_19
    return-object v0

    .line 27
    :pswitch_1a
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 30
    .line 31
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 36
    .line 37
    if-ne v1, v2, :cond_2b

    .line 38
    .line 39
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 40
    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    goto :goto_33

    .line 44
    :cond_2b
    invoke-virtual {p0}, Lio/sentry/a2;->z()F

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    :goto_33
    return-object v0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method

.method public final L()I
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_26

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_14

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0

    .line 21
    :cond_14
    new-instance v0, Ljava/io/IOException;

    .line 22
    .line 23
    const-string v1, "Expected int"

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v0

    .line 29
    :pswitch_1c
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 32
    .line 33
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->X()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    return v0

    .line 38
    nop

    .line 39
    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method

.method public final X()Ljava/lang/Integer;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_34

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_18

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    const/4 v0, 0x0

    .line 26
    :goto_19
    return-object v0

    .line 27
    :pswitch_1a
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 30
    .line 31
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 36
    .line 37
    if-ne v1, v2, :cond_2b

    .line 38
    .line 39
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 40
    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    goto :goto_33

    .line 44
    :cond_2b
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->X()I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    :goto_33
    return-object v0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method

.method public final Y(Lio/sentry/ILogger;Lio/sentry/r1;)Ljava/util/ArrayList;
    .registers 8

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_9e

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sget-object v1, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 11
    .line 12
    if-ne v0, v1, :cond_2d

    .line 13
    .line 14
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    if-nez p1, :cond_15

    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    goto :goto_5a

    .line 22
    :cond_15
    new-instance p1, Ljava/io/IOException;

    .line 23
    .line 24
    new-instance p2, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string v0, "Expected null but was "

    .line 27
    .line 28
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2d
    :try_start_2d
    invoke-virtual {p0}, Lio/sentry/a2;->c()V

    .line 47
    .line 48
    .line 49
    new-instance v0, Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, Lio/sentry/a2;->j()Z

    .line 55
    .line 56
    .line 57
    move-result v1
    :try_end_39
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_39} :catch_54

    .line 58
    if-eqz v1, :cond_56

    .line 59
    .line 60
    :cond_3b
    :try_start_3b
    invoke-interface {p2, p0, p1}, Lio/sentry/r1;->a(Lio/sentry/a2;Lio/sentry/ILogger;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_42} :catch_43

    .line 65
    .line 66
    .line 67
    goto :goto_4b

    .line 68
    :catch_43
    move-exception v1

    .line 69
    :try_start_44
    sget-object v2, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 70
    .line 71
    const-string v3, "Failed to deserialize object in list."

    .line 72
    .line 73
    invoke-interface {p1, v2, v3, v1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 74
    .line 75
    .line 76
    :goto_4b
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->BEGIN_OBJECT:Lio/sentry/vendor/gson/stream/b;

    .line 81
    .line 82
    if-eq v1, v2, :cond_3b

    .line 83
    .line 84
    goto :goto_56

    .line 85
    :catch_54
    move-exception p1

    .line 86
    goto :goto_5b

    .line 87
    :cond_56
    :goto_56
    invoke-virtual {p0}, Lio/sentry/a2;->g()V
    :try_end_59
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_59} :catch_54

    .line 88
    .line 89
    .line 90
    move-object p1, v0

    .line 91
    :goto_5a
    return-object p1

    .line 92
    :goto_5b
    new-instance p2, Ljava/io/IOException;

    .line 93
    .line 94
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 95
    .line 96
    .line 97
    throw p2

    .line 98
    :pswitch_61
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 101
    .line 102
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 107
    .line 108
    if-ne v1, v2, :cond_72

    .line 109
    .line 110
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 111
    .line 112
    .line 113
    const/4 p1, 0x0

    .line 114
    goto :goto_9c

    .line 115
    :cond_72
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->c()V

    .line 116
    .line 117
    .line 118
    new-instance v1, Ljava/util/ArrayList;

    .line 119
    .line 120
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->u()Z

    .line 124
    .line 125
    .line 126
    move-result v2

    .line 127
    if-eqz v2, :cond_98

    .line 128
    .line 129
    :cond_80
    :try_start_80
    invoke-interface {p2, p0, p1}, Lio/sentry/r1;->a(Lio/sentry/a2;Lio/sentry/ILogger;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_80 .. :try_end_87} :catch_88

    .line 134
    .line 135
    .line 136
    goto :goto_90

    .line 137
    :catch_88
    move-exception v2

    .line 138
    sget-object v3, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 139
    .line 140
    const-string v4, "Failed to deserialize object in list."

    .line 141
    .line 142
    invoke-interface {p1, v3, v4, v2}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 143
    .line 144
    .line 145
    :goto_90
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    sget-object v3, Lio/sentry/vendor/gson/stream/b;->BEGIN_OBJECT:Lio/sentry/vendor/gson/stream/b;

    .line 150
    .line 151
    if-eq v2, v3, :cond_80

    .line 152
    .line 153
    :cond_98
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->j()V

    .line 154
    .line 155
    .line 156
    move-object p1, v1

    .line 157
    :goto_9c
    return-object p1

    .line 158
    nop

    .line 159
    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_61
    .end packed-switch
.end method

.method public final Z()J
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_26

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_14

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    return-wide v0

    .line 21
    :cond_14
    new-instance v0, Ljava/io/IOException;

    .line 22
    .line 23
    const-string v1, "Expected long"

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v0

    .line 29
    :pswitch_1c
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 32
    .line 33
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->Y()J

    .line 34
    .line 35
    .line 36
    move-result-wide v0

    .line 37
    return-wide v0

    .line 38
    nop

    .line 39
    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method

.method public final c()V
    .registers 7

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_56

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Ljava/util/Map$Entry;

    .line 15
    .line 16
    if-eqz v1, :cond_46

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    instance-of v2, v1, Ljava/util/List;

    .line 23
    .line 24
    if-eqz v2, :cond_3e

    .line 25
    .line 26
    new-instance v2, Ljava/util/AbstractMap$SimpleEntry;

    .line 27
    .line 28
    sget-object v3, Lio/sentry/vendor/gson/stream/b;->END_ARRAY:Lio/sentry/vendor/gson/stream/b;

    .line 29
    .line 30
    const/4 v4, 0x0

    .line 31
    invoke-direct {v2, v4, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0, v2}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    check-cast v1, Ljava/util/List;

    .line 38
    .line 39
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    add-int/lit8 v2, v2, -0x1

    .line 44
    .line 45
    :goto_2c
    if-ltz v2, :cond_3d

    .line 46
    .line 47
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    new-instance v5, Ljava/util/AbstractMap$SimpleEntry;

    .line 52
    .line 53
    invoke-direct {v5, v4, v3}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0, v5}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    add-int/lit8 v2, v2, -0x1

    .line 60
    .line 61
    goto :goto_2c

    .line 62
    :cond_3d
    return-void

    .line 63
    :cond_3e
    new-instance v0, Ljava/io/IOException;

    .line 64
    .line 65
    const-string v1, "Current token is not an object"

    .line 66
    .line 67
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    throw v0

    .line 71
    :cond_46
    new-instance v0, Ljava/io/IOException;

    .line 72
    .line 73
    const-string v1, "No more entries"

    .line 74
    .line 75
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    throw v0

    .line 79
    :pswitch_4e
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 82
    .line 83
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->c()V

    .line 84
    .line 85
    .line 86
    return-void

    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_4e
    .end packed-switch
.end method

.method public final c0()Ljava/lang/Long;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_34

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_18

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    const/4 v0, 0x0

    .line 26
    :goto_19
    return-object v0

    .line 27
    :pswitch_1a
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 30
    .line 31
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 36
    .line 37
    if-ne v1, v2, :cond_2b

    .line 38
    .line 39
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 40
    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    goto :goto_33

    .line 44
    :cond_2b
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->Y()J

    .line 45
    .line 46
    .line 47
    move-result-wide v0

    .line 48
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    :goto_33
    return-object v0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method

.method public final close()V
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_d
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 17
    .line 18
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->close()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method

.method public final d()V
    .registers 6

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_58

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Ljava/util/Map$Entry;

    .line 15
    .line 16
    if-eqz v1, :cond_47

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    instance-of v2, v1, Ljava/util/Map;

    .line 23
    .line 24
    if-eqz v2, :cond_3f

    .line 25
    .line 26
    new-instance v2, Ljava/util/AbstractMap$SimpleEntry;

    .line 27
    .line 28
    const/4 v3, 0x0

    .line 29
    sget-object v4, Lio/sentry/vendor/gson/stream/b;->END_OBJECT:Lio/sentry/vendor/gson/stream/b;

    .line 30
    .line 31
    invoke-direct {v2, v3, v4}, Ljava/util/AbstractMap$SimpleEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0, v2}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    check-cast v1, Ljava/util/Map;

    .line 38
    .line 39
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    :goto_2e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_3e

    .line 52
    .line 53
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    check-cast v2, Ljava/util/Map$Entry;

    .line 58
    .line 59
    invoke-virtual {v0, v2}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    goto :goto_2e

    .line 63
    :cond_3e
    return-void

    .line 64
    :cond_3f
    new-instance v0, Ljava/io/IOException;

    .line 65
    .line 66
    const-string v1, "Current token is not an object"

    .line 67
    .line 68
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw v0

    .line 72
    :cond_47
    new-instance v0, Ljava/io/IOException;

    .line 73
    .line 74
    const-string v1, "No more entries"

    .line 75
    .line 76
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    throw v0

    .line 80
    :pswitch_4f
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 83
    .line 84
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->d()V

    .line 85
    .line 86
    .line 87
    return-void

    .line 88
    nop

    .line 89
    :pswitch_data_58
    .packed-switch 0x0
        :pswitch_4f
    .end packed-switch
.end method

.method public final g()V
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1c

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x1

    .line 15
    if-le v1, v2, :cond_13

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    :cond_13
    return-void

    .line 21
    :pswitch_14
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 24
    .line 25
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->j()V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_14
    .end packed-switch
.end method

.method public final i()V
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1c

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x1

    .line 15
    if-le v1, v2, :cond_13

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    :cond_13
    return-void

    .line 21
    :pswitch_14
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 24
    .line 25
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->l()V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_14
    .end packed-switch
.end method

.method public final j()Z
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1a

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    xor-int/lit8 v0, v0, 0x1

    .line 15
    .line 16
    return v0

    .line 17
    :pswitch_10
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 20
    .line 21
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->u()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    return v0

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_10
    .end packed-switch
.end method

.method public final k0(Lio/sentry/ILogger;Lio/sentry/r1;)Ljava/util/HashMap;
    .registers 8

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_b6

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sget-object v1, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 11
    .line 12
    if-ne v0, v1, :cond_2d

    .line 13
    .line 14
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    if-nez p1, :cond_15

    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    goto :goto_66

    .line 22
    :cond_15
    new-instance p1, Ljava/io/IOException;

    .line 23
    .line 24
    new-instance p2, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string v0, "Expected null but was "

    .line 27
    .line 28
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2d
    :try_start_2d
    invoke-virtual {p0}, Lio/sentry/a2;->d()V

    .line 47
    .line 48
    .line 49
    new-instance v0, Ljava/util/HashMap;

    .line 50
    .line 51
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, Lio/sentry/a2;->j()Z

    .line 55
    .line 56
    .line 57
    move-result v1
    :try_end_39
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_39} :catch_60

    .line 58
    if-eqz v1, :cond_62

    .line 59
    .line 60
    :cond_3b
    :try_start_3b
    invoke-virtual {p0}, Lio/sentry/a2;->l0()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-interface {p2, p0, p1}, Lio/sentry/r1;->a(Lio/sentry/a2;Lio/sentry/ILogger;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_46
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_46} :catch_47

    .line 69
    .line 70
    .line 71
    goto :goto_4f

    .line 72
    :catch_47
    move-exception v1

    .line 73
    :try_start_48
    sget-object v2, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 74
    .line 75
    const-string v3, "Failed to deserialize object in map."

    .line 76
    .line 77
    invoke-interface {p1, v2, v3, v1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 78
    .line 79
    .line 80
    :goto_4f
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->BEGIN_OBJECT:Lio/sentry/vendor/gson/stream/b;

    .line 85
    .line 86
    if-eq v1, v2, :cond_3b

    .line 87
    .line 88
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NAME:Lio/sentry/vendor/gson/stream/b;

    .line 93
    .line 94
    if-eq v1, v2, :cond_3b

    .line 95
    .line 96
    goto :goto_62

    .line 97
    :catch_60
    move-exception p1

    .line 98
    goto :goto_67

    .line 99
    :cond_62
    :goto_62
    invoke-virtual {p0}, Lio/sentry/a2;->i()V
    :try_end_65
    .catch Ljava/lang/Exception; {:try_start_48 .. :try_end_65} :catch_60

    .line 100
    .line 101
    .line 102
    move-object p1, v0

    .line 103
    :goto_66
    return-object p1

    .line 104
    :goto_67
    new-instance p2, Ljava/io/IOException;

    .line 105
    .line 106
    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 107
    .line 108
    .line 109
    throw p2

    .line 110
    :pswitch_6d
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 113
    .line 114
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 119
    .line 120
    if-ne v1, v2, :cond_7e

    .line 121
    .line 122
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 123
    .line 124
    .line 125
    const/4 p1, 0x0

    .line 126
    goto :goto_b4

    .line 127
    :cond_7e
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->d()V

    .line 128
    .line 129
    .line 130
    new-instance v1, Ljava/util/HashMap;

    .line 131
    .line 132
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->u()Z

    .line 136
    .line 137
    .line 138
    move-result v2

    .line 139
    if-eqz v2, :cond_b0

    .line 140
    .line 141
    :cond_8c
    :try_start_8c
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->Z()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    invoke-interface {p2, p0, p1}, Lio/sentry/r1;->a(Lio/sentry/a2;Lio/sentry/ILogger;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_97
    .catch Ljava/lang/Exception; {:try_start_8c .. :try_end_97} :catch_98

    .line 150
    .line 151
    .line 152
    goto :goto_a0

    .line 153
    :catch_98
    move-exception v2

    .line 154
    sget-object v3, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 155
    .line 156
    const-string v4, "Failed to deserialize object in map."

    .line 157
    .line 158
    invoke-interface {p1, v3, v4, v2}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 159
    .line 160
    .line 161
    :goto_a0
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    sget-object v3, Lio/sentry/vendor/gson/stream/b;->BEGIN_OBJECT:Lio/sentry/vendor/gson/stream/b;

    .line 166
    .line 167
    if-eq v2, v3, :cond_8c

    .line 168
    .line 169
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 170
    .line 171
    .line 172
    move-result-object v2

    .line 173
    sget-object v3, Lio/sentry/vendor/gson/stream/b;->NAME:Lio/sentry/vendor/gson/stream/b;

    .line 174
    .line 175
    if-eq v2, v3, :cond_8c

    .line 176
    .line 177
    :cond_b0
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->l()V

    .line 178
    .line 179
    .line 180
    move-object p1, v1

    .line 181
    :goto_b4
    return-object p1

    .line 182
    nop

    .line 183
    :pswitch_data_b6
    .packed-switch 0x0
        :pswitch_6d
    .end packed-switch
.end method

.method public final l()Ljava/lang/Boolean;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_26

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ljava/lang/Boolean;

    .line 11
    .line 12
    return-object v0

    .line 13
    :pswitch_c
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 22
    .line 23
    if-ne v1, v2, :cond_1d

    .line 24
    .line 25
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    goto :goto_25

    .line 30
    :cond_1d
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->A()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    :goto_25
    return-object v0

    .line 39
    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_c
    .end packed-switch
.end method

.method public final l0()Ljava/lang/String;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_40

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->peekLast()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Ljava/util/Map$Entry;

    .line 15
    .line 16
    if-eqz v0, :cond_1e

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-eqz v1, :cond_1e

    .line 23
    .line 24
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Ljava/lang/String;

    .line 29
    .line 30
    return-object v0

    .line 31
    :cond_1e
    new-instance v0, Ljava/io/IOException;

    .line 32
    .line 33
    new-instance v1, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    const-string v2, "Expected a name but was "

    .line 36
    .line 37
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0}, Lio/sentry/a2;->s0()Lio/sentry/vendor/gson/stream/b;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    throw v0

    .line 55
    :pswitch_36
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 58
    .line 59
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->Z()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    return-object v0

    .line 64
    nop

    .line 65
    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_36
    .end packed-switch
.end method

.method public final m0()Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_20

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_a
    new-instance v0, Lb80/x;

    .line 12
    .line 13
    const/4 v1, 0x2

    .line 14
    invoke-direct {v0, v1}, Lb80/x;-><init>(I)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, p0}, Lb80/x;->j(Lio/sentry/a2;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Lb80/x;->g()Lio/sentry/v1;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_1e

    .line 25
    .line 26
    invoke-interface {v0}, Lio/sentry/v1;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    const/4 v0, 0x0

    .line 32
    :goto_1f
    return-object v0

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method

.method public final n(Lio/sentry/ILogger;)Ljava/util/Date;
    .registers 6

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_4e

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ljava/lang/String;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    if-nez v0, :cond_f

    .line 14
    .line 15
    goto :goto_21

    .line 16
    :cond_f
    :try_start_f
    invoke-static {v0}, Lz20/g;->v(Ljava/lang/String;)Ljava/util/Date;

    .line 17
    .line 18
    .line 19
    move-result-object v1
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_13} :catch_14

    .line 20
    goto :goto_21

    .line 21
    :catch_14
    :try_start_14
    invoke-static {v0}, Lz20/g;->w(Ljava/lang/String;)Ljava/util/Date;

    .line 22
    .line 23
    .line 24
    move-result-object v1
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_18} :catch_19

    .line 25
    goto :goto_21

    .line 26
    :catch_19
    move-exception v0

    .line 27
    sget-object v2, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 28
    .line 29
    const-string v3, "Error when deserializing millis timestamp format."

    .line 30
    .line 31
    invoke-interface {p1, v2, v3, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 32
    .line 33
    .line 34
    :goto_21
    return-object v1

    .line 35
    :pswitch_22
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 38
    .line 39
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    if-ne v1, v2, :cond_33

    .line 47
    .line 48
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 49
    .line 50
    .line 51
    goto :goto_4c

    .line 52
    :cond_33
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->m0()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    if-nez v0, :cond_3a

    .line 57
    .line 58
    goto :goto_4c

    .line 59
    :cond_3a
    :try_start_3a
    invoke-static {v0}, Lz20/g;->v(Ljava/lang/String;)Ljava/util/Date;

    .line 60
    .line 61
    .line 62
    move-result-object v3
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_3e} :catch_3f

    .line 63
    goto :goto_4c

    .line 64
    :catch_3f
    :try_start_3f
    invoke-static {v0}, Lz20/g;->w(Ljava/lang/String;)Ljava/util/Date;

    .line 65
    .line 66
    .line 67
    move-result-object v3
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_3f .. :try_end_43} :catch_44

    .line 68
    goto :goto_4c

    .line 69
    :catch_44
    move-exception v0

    .line 70
    sget-object v1, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 71
    .line 72
    const-string v2, "Error when deserializing millis timestamp format."

    .line 73
    .line 74
    invoke-interface {p1, v1, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 75
    .line 76
    .line 77
    :goto_4c
    return-object v3

    .line 78
    nop

    .line 79
    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_22
    .end packed-switch
.end method

.method public final n0(Lio/sentry/ILogger;Lio/sentry/r1;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_3a

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->peekLast()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Ljava/util/Map$Entry;

    .line 15
    .line 16
    if-nez v1, :cond_13

    .line 17
    .line 18
    const/4 p1, 0x0

    .line 19
    goto :goto_22

    .line 20
    :cond_13
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    if-eqz p1, :cond_1e

    .line 25
    .line 26
    invoke-interface {p2, p0, p1}, Lio/sentry/r1;->a(Lio/sentry/a2;Lio/sentry/ILogger;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    goto :goto_22

    .line 31
    :cond_1e
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-object p1, v1

    .line 35
    :goto_22
    return-object p1

    .line 36
    :pswitch_23
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 39
    .line 40
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 45
    .line 46
    if-ne v1, v2, :cond_34

    .line 47
    .line 48
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 49
    .line 50
    .line 51
    const/4 p1, 0x0

    .line 52
    goto :goto_38

    .line 53
    :cond_34
    invoke-interface {p2, p0, p1}, Lio/sentry/r1;->a(Lio/sentry/a2;Lio/sentry/ILogger;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    :goto_38
    return-object p1

    .line 58
    nop

    .line 59
    :pswitch_data_3a
    .packed-switch 0x0
        :pswitch_23
    .end packed-switch
.end method

.method public final o0()Ljava/lang/String;
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_20

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ljava/lang/String;

    .line 11
    .line 12
    if-eqz v0, :cond_e

    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_e
    new-instance v0, Ljava/io/IOException;

    .line 16
    .line 17
    const-string v1, "Expected string"

    .line 18
    .line 19
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw v0

    .line 23
    :pswitch_16
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 26
    .line 27
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->m0()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0

    .line 32
    nop

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_16
    .end packed-switch
.end method

.method public final p0()Ljava/lang/String;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_22

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ljava/lang/String;

    .line 11
    .line 12
    return-object v0

    .line 13
    :pswitch_c
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 22
    .line 23
    if-ne v1, v2, :cond_1d

    .line 24
    .line 25
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    goto :goto_21

    .line 30
    :cond_1d
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->m0()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    :goto_21
    return-object v0

    .line 35
    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_c
    .end packed-switch
.end method

.method public final q0(Lio/sentry/ILogger;Ljava/util/AbstractMap;Ljava/lang/String;)V
    .registers 6

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_30

    .line 4
    .line 5
    .line 6
    :try_start_5
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {p2, p3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_c} :catch_d

    .line 11
    .line 12
    .line 13
    goto :goto_19

    .line 14
    :catch_d
    move-exception p2

    .line 15
    sget-object v0, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 16
    .line 17
    const-string v1, "Error deserializing unknown key: %s"

    .line 18
    .line 19
    filled-new-array {p3}, [Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p3

    .line 23
    invoke-interface {p1, v0, p2, v1, p3}, Lio/sentry/ILogger;->b(Lio/sentry/a5;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :goto_19
    return-void

    .line 27
    :pswitch_1a
    :try_start_1a
    invoke-virtual {p0}, Lio/sentry/a2;->m0()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-interface {p2, p3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_21} :catch_22

    .line 32
    .line 33
    .line 34
    goto :goto_2e

    .line 35
    :catch_22
    move-exception p2

    .line 36
    sget-object v0, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 37
    .line 38
    const-string v1, "Error deserializing unknown key: %s"

    .line 39
    .line 40
    filled-new-array {p3}, [Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p3

    .line 44
    invoke-interface {p1, v0, p2, v1, p3}, Lio/sentry/ILogger;->b(Lio/sentry/a5;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :goto_2e
    return-void

    .line 48
    nop

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method

.method public r0()Ljava/lang/Object;
    .registers 3

    .line 1
    :try_start_0
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayDeque;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->peekLast()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Ljava/util/Map$Entry;

    .line 10
    .line 11
    if-nez v1, :cond_e

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    return-object v0

    .line 15
    :cond_e
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeLast()Ljava/lang/Object;
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_15} :catch_16

    .line 20
    .line 21
    .line 22
    return-object v1

    .line 23
    :catch_16
    move-exception v0

    .line 24
    new-instance v1, Ljava/io/IOException;

    .line 25
    .line 26
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 27
    .line 28
    .line 29
    throw v1
.end method

.method public final s0()Lio/sentry/vendor/gson/stream/b;
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_60

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_12

    .line 15
    .line 16
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->END_DOCUMENT:Lio/sentry/vendor/gson/stream/b;

    .line 17
    .line 18
    goto :goto_56

    .line 19
    :cond_12
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->peekLast()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Ljava/util/Map$Entry;

    .line 24
    .line 25
    if-nez v0, :cond_1d

    .line 26
    .line 27
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->END_DOCUMENT:Lio/sentry/vendor/gson/stream/b;

    .line 28
    .line 29
    goto :goto_56

    .line 30
    :cond_1d
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    if-eqz v1, :cond_26

    .line 35
    .line 36
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->NAME:Lio/sentry/vendor/gson/stream/b;

    .line 37
    .line 38
    goto :goto_56

    .line 39
    :cond_26
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    instance-of v1, v0, Ljava/util/Map;

    .line 44
    .line 45
    if-eqz v1, :cond_31

    .line 46
    .line 47
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->BEGIN_OBJECT:Lio/sentry/vendor/gson/stream/b;

    .line 48
    .line 49
    goto :goto_56

    .line 50
    :cond_31
    instance-of v1, v0, Ljava/util/List;

    .line 51
    .line 52
    if-eqz v1, :cond_38

    .line 53
    .line 54
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->BEGIN_ARRAY:Lio/sentry/vendor/gson/stream/b;

    .line 55
    .line 56
    goto :goto_56

    .line 57
    :cond_38
    instance-of v1, v0, Ljava/lang/String;

    .line 58
    .line 59
    if-eqz v1, :cond_3f

    .line 60
    .line 61
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->STRING:Lio/sentry/vendor/gson/stream/b;

    .line 62
    .line 63
    goto :goto_56

    .line 64
    :cond_3f
    instance-of v1, v0, Ljava/lang/Number;

    .line 65
    .line 66
    if-eqz v1, :cond_46

    .line 67
    .line 68
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->NUMBER:Lio/sentry/vendor/gson/stream/b;

    .line 69
    .line 70
    goto :goto_56

    .line 71
    :cond_46
    instance-of v1, v0, Ljava/lang/Boolean;

    .line 72
    .line 73
    if-eqz v1, :cond_4d

    .line 74
    .line 75
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->BOOLEAN:Lio/sentry/vendor/gson/stream/b;

    .line 76
    .line 77
    goto :goto_56

    .line 78
    :cond_4d
    instance-of v1, v0, Lio/sentry/vendor/gson/stream/b;

    .line 79
    .line 80
    if-eqz v1, :cond_54

    .line 81
    .line 82
    check-cast v0, Lio/sentry/vendor/gson/stream/b;

    .line 83
    .line 84
    goto :goto_56

    .line 85
    :cond_54
    sget-object v0, Lio/sentry/vendor/gson/stream/b;->END_DOCUMENT:Lio/sentry/vendor/gson/stream/b;

    .line 86
    .line 87
    :goto_56
    return-object v0

    .line 88
    :pswitch_57
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 91
    .line 92
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    return-object v0

    .line 97
    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_57
    .end packed-switch
.end method

.method public final t0(Z)V
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 10
    .line 11
    iput-boolean p1, v0, Lio/sentry/vendor/gson/stream/a;->e:Z

    .line 12
    .line 13
    return-void

    .line 14
    nop

    .line 15
    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_6
    .end packed-switch
.end method

.method public final u()D
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_26

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_14

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    return-wide v0

    .line 21
    :cond_14
    new-instance v0, Ljava/io/IOException;

    .line 22
    .line 23
    const-string v1, "Expected double"

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v0

    .line 29
    :pswitch_1c
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 32
    .line 33
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->L()D

    .line 34
    .line 35
    .line 36
    move-result-wide v0

    .line 37
    return-wide v0

    .line 38
    nop

    .line 39
    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method

.method public final v0()V
    .registers 12

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_d2

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_6
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    move v2, v1

    .line 13
    :cond_c
    iget v3, v0, Lio/sentry/vendor/gson/stream/a;->J:I

    .line 14
    .line 15
    if-nez v3, :cond_14

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->i()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    :cond_14
    const/4 v4, 0x3

    .line 22
    const/4 v5, 0x1

    .line 23
    if-ne v3, v4, :cond_1f

    .line 24
    .line 25
    invoke-virtual {v0, v5}, Lio/sentry/vendor/gson/stream/a;->p0(I)V

    .line 26
    .line 27
    .line 28
    :goto_1b
    add-int/lit8 v2, v2, 0x1

    .line 29
    .line 30
    goto/16 :goto_bc

    .line 31
    .line 32
    :cond_1f
    if-ne v3, v5, :cond_25

    .line 33
    .line 34
    invoke-virtual {v0, v4}, Lio/sentry/vendor/gson/stream/a;->p0(I)V

    .line 35
    .line 36
    .line 37
    goto :goto_1b

    .line 38
    :cond_25
    const/4 v4, 0x4

    .line 39
    if-ne v3, v4, :cond_31

    .line 40
    .line 41
    iget v3, v0, Lio/sentry/vendor/gson/stream/a;->O:I

    .line 42
    .line 43
    sub-int/2addr v3, v5

    .line 44
    iput v3, v0, Lio/sentry/vendor/gson/stream/a;->O:I

    .line 45
    .line 46
    :goto_2d
    add-int/lit8 v2, v2, -0x1

    .line 47
    .line 48
    goto/16 :goto_bc

    .line 49
    .line 50
    :cond_31
    const/4 v4, 0x2

    .line 51
    if-ne v3, v4, :cond_3a

    .line 52
    .line 53
    iget v3, v0, Lio/sentry/vendor/gson/stream/a;->O:I

    .line 54
    .line 55
    sub-int/2addr v3, v5

    .line 56
    iput v3, v0, Lio/sentry/vendor/gson/stream/a;->O:I

    .line 57
    .line 58
    goto :goto_2d

    .line 59
    :cond_3a
    const/16 v4, 0xe

    .line 60
    .line 61
    const/16 v6, 0xd

    .line 62
    .line 63
    const/16 v7, 0x9

    .line 64
    .line 65
    const/16 v8, 0xc

    .line 66
    .line 67
    const/16 v9, 0xa

    .line 68
    .line 69
    if-eq v3, v4, :cond_6d

    .line 70
    .line 71
    if-ne v3, v9, :cond_49

    .line 72
    .line 73
    goto :goto_6d

    .line 74
    :cond_49
    const/16 v4, 0x8

    .line 75
    .line 76
    if-eq v3, v4, :cond_67

    .line 77
    .line 78
    if-ne v3, v8, :cond_50

    .line 79
    .line 80
    goto :goto_67

    .line 81
    :cond_50
    if-eq v3, v7, :cond_61

    .line 82
    .line 83
    if-ne v3, v6, :cond_55

    .line 84
    .line 85
    goto :goto_61

    .line 86
    :cond_55
    const/16 v4, 0x10

    .line 87
    .line 88
    if-ne v3, v4, :cond_bc

    .line 89
    .line 90
    iget v3, v0, Lio/sentry/vendor/gson/stream/a;->v:I

    .line 91
    .line 92
    iget v4, v0, Lio/sentry/vendor/gson/stream/a;->L:I

    .line 93
    .line 94
    add-int/2addr v3, v4

    .line 95
    iput v3, v0, Lio/sentry/vendor/gson/stream/a;->v:I

    .line 96
    .line 97
    goto :goto_bc

    .line 98
    :cond_61
    :goto_61
    const/16 v3, 0x22

    .line 99
    .line 100
    invoke-virtual {v0, v3}, Lio/sentry/vendor/gson/stream/a;->r0(C)V

    .line 101
    .line 102
    .line 103
    goto :goto_bc

    .line 104
    :cond_67
    :goto_67
    const/16 v3, 0x27

    .line 105
    .line 106
    invoke-virtual {v0, v3}, Lio/sentry/vendor/gson/stream/a;->r0(C)V

    .line 107
    .line 108
    .line 109
    goto :goto_bc

    .line 110
    :cond_6d
    :goto_6d
    move v3, v1

    .line 111
    :goto_6e
    iget v4, v0, Lio/sentry/vendor/gson/stream/a;->v:I

    .line 112
    .line 113
    add-int/2addr v4, v3

    .line 114
    iget v10, v0, Lio/sentry/vendor/gson/stream/a;->w:I

    .line 115
    .line 116
    if-ge v4, v10, :cond_b4

    .line 117
    .line 118
    iget-object v10, v0, Lio/sentry/vendor/gson/stream/a;->i:[C

    .line 119
    .line 120
    aget-char v4, v10, v4

    .line 121
    .line 122
    if-eq v4, v7, :cond_ae

    .line 123
    .line 124
    if-eq v4, v9, :cond_ae

    .line 125
    .line 126
    if-eq v4, v8, :cond_ae

    .line 127
    .line 128
    if-eq v4, v6, :cond_ae

    .line 129
    .line 130
    const/16 v10, 0x20

    .line 131
    .line 132
    if-eq v4, v10, :cond_ae

    .line 133
    .line 134
    const/16 v10, 0x23

    .line 135
    .line 136
    if-eq v4, v10, :cond_ab

    .line 137
    .line 138
    const/16 v10, 0x2c

    .line 139
    .line 140
    if-eq v4, v10, :cond_ae

    .line 141
    .line 142
    const/16 v10, 0x2f

    .line 143
    .line 144
    if-eq v4, v10, :cond_ab

    .line 145
    .line 146
    const/16 v10, 0x3d

    .line 147
    .line 148
    if-eq v4, v10, :cond_ab

    .line 149
    .line 150
    const/16 v10, 0x7b

    .line 151
    .line 152
    if-eq v4, v10, :cond_ae

    .line 153
    .line 154
    const/16 v10, 0x7d

    .line 155
    .line 156
    if-eq v4, v10, :cond_ae

    .line 157
    .line 158
    const/16 v10, 0x3a

    .line 159
    .line 160
    if-eq v4, v10, :cond_ae

    .line 161
    .line 162
    const/16 v10, 0x3b

    .line 163
    .line 164
    if-eq v4, v10, :cond_ab

    .line 165
    .line 166
    packed-switch v4, :pswitch_data_d8

    .line 167
    .line 168
    .line 169
    add-int/lit8 v3, v3, 0x1

    .line 170
    .line 171
    goto :goto_6e

    .line 172
    :cond_ab
    :pswitch_ab
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->g()V

    .line 173
    .line 174
    .line 175
    :cond_ae
    :pswitch_ae
    iget v4, v0, Lio/sentry/vendor/gson/stream/a;->v:I

    .line 176
    .line 177
    add-int/2addr v4, v3

    .line 178
    iput v4, v0, Lio/sentry/vendor/gson/stream/a;->v:I

    .line 179
    .line 180
    goto :goto_bc

    .line 181
    :cond_b4
    iput v4, v0, Lio/sentry/vendor/gson/stream/a;->v:I

    .line 182
    .line 183
    invoke-virtual {v0, v5}, Lio/sentry/vendor/gson/stream/a;->n(I)Z

    .line 184
    .line 185
    .line 186
    move-result v3

    .line 187
    if-nez v3, :cond_6d

    .line 188
    .line 189
    :cond_bc
    :goto_bc
    iput v1, v0, Lio/sentry/vendor/gson/stream/a;->J:I

    .line 190
    .line 191
    if-nez v2, :cond_c

    .line 192
    .line 193
    iget-object v1, v0, Lio/sentry/vendor/gson/stream/a;->Q:[I

    .line 194
    .line 195
    iget v2, v0, Lio/sentry/vendor/gson/stream/a;->O:I

    .line 196
    .line 197
    sub-int/2addr v2, v5

    .line 198
    aget v3, v1, v2

    .line 199
    .line 200
    add-int/2addr v3, v5

    .line 201
    aput v3, v1, v2

    .line 202
    .line 203
    iget-object v0, v0, Lio/sentry/vendor/gson/stream/a;->P:[Ljava/lang/String;

    .line 204
    .line 205
    const-string v1, "null"

    .line 206
    .line 207
    aput-object v1, v0, v2

    .line 208
    .line 209
    return-void

    .line 210
    nop

    .line 211
    :pswitch_data_d2
    .packed-switch 0x0
        :pswitch_6
    .end packed-switch

    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    :pswitch_data_d8
    .packed-switch 0x5b
        :pswitch_ae
        :pswitch_ab
        :pswitch_ae
    .end packed-switch
.end method

.method public final x()Ljava/lang/Double;
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_34

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_18

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    const/4 v0, 0x0

    .line 26
    :goto_19
    return-object v0

    .line 27
    :pswitch_1a
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 30
    .line 31
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    sget-object v2, Lio/sentry/vendor/gson/stream/b;->NULL:Lio/sentry/vendor/gson/stream/b;

    .line 36
    .line 37
    if-ne v1, v2, :cond_2b

    .line 38
    .line 39
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->k0()V

    .line 40
    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    goto :goto_33

    .line 44
    :cond_2b
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->L()D

    .line 45
    .line 46
    .line 47
    move-result-wide v0

    .line 48
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    :goto_33
    return-object v0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method

.method public final z()F
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/a2;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_26

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lio/sentry/a2;->r0()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    instance-of v1, v0, Ljava/lang/Number;

    .line 11
    .line 12
    if-eqz v1, :cond_14

    .line 13
    .line 14
    check-cast v0, Ljava/lang/Number;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0

    .line 21
    :cond_14
    new-instance v0, Ljava/io/IOException;

    .line 22
    .line 23
    const-string v1, "Expected float"

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v0

    .line 29
    :pswitch_1c
    iget-object v0, p0, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lio/sentry/vendor/gson/stream/a;

    .line 32
    .line 33
    invoke-virtual {v0}, Lio/sentry/vendor/gson/stream/a;->L()D

    .line 34
    .line 35
    .line 36
    move-result-wide v0

    .line 37
    double-to-float v0, v0

    .line 38
    return v0

    .line 39
    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method
