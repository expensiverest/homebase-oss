###### Class io.sentry.a1 (io.sentry.a1)
.class public interface abstract Lio/sentry/a1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Z)V
.end method

.method public abstract b(J)V
.end method

.method public abstract c(Lio/sentry/e;)V
.end method

.method public abstract clone()Lio/sentry/s0;
.end method

.method public abstract d(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract e()Lio/sentry/transport/p;
.end method

.method public abstract f()Z
.end method

.method public abstract g(Lio/sentry/e;Lio/sentry/h0;)V
.end method

.method public abstract h(Lk7/e;Lio/sentry/h0;)Lio/sentry/protocol/v;
.end method

.method public abstract i(Lio/sentry/h3;)Lio/sentry/protocol/v;
.end method

.method public abstract isEnabled()Z
.end method

.method public abstract j(Lio/sentry/t6;Lio/sentry/u6;)Lio/sentry/j1;
.end method

.method public abstract k()Ljava/lang/Boolean;
.end method

.method public abstract l()Lio/sentry/a6;
.end method

.method public m()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public abstract n()Lio/sentry/j1;
.end method

.method public abstract o()V
.end method

.method public abstract p()V
.end method

.method public abstract q(Lio/sentry/x3;Lio/sentry/v3;)V
.end method

.method public abstract r(Lio/sentry/c6;Lio/sentry/h0;)Lio/sentry/protocol/v;
.end method

.method public abstract s(Lbq/a;)V
.end method

.method public abstract t(Ljava/lang/Throwable;Lio/sentry/h0;)Lio/sentry/protocol/v;
.end method

.method public abstract u(Ljava/lang/String;Lio/sentry/a5;)Lio/sentry/protocol/v;
.end method

.method public abstract v(Lio/sentry/protocol/e0;Lio/sentry/r6;Lio/sentry/h0;Lio/sentry/k3;)Lio/sentry/protocol/v;
.end method

.method public abstract w(Ljava/lang/String;)Lio/sentry/a1;
.end method

.method public abstract x(Lio/sentry/t4;Lio/sentry/h0;)Lio/sentry/protocol/v;
.end method
