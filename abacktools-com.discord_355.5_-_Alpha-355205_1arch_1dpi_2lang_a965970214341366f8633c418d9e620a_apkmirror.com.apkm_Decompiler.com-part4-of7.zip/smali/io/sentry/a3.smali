###### Class io.sentry.a3 (io.sentry.a3)
.class public final Lio/sentry/a3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/l1;


# static fields
.field public static final d:Lio/sentry/a3;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lio/sentry/a3;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/a3;->d:Lio/sentry/a3;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final e(Lio/sentry/a6;Lz5/u;)Lio/sentry/transport/g;
    .registers 3

    .line 1
    sget-object p1, Lio/sentry/transport/j;->d:Lio/sentry/transport/j;

    .line 2
    .line 3
    return-object p1
.end method
