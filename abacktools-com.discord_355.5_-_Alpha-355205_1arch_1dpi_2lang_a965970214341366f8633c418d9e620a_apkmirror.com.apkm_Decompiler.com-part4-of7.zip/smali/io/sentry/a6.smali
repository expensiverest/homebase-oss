###### Class io.sentry.a6 (io.sentry.a6)
.class public Lio/sentry/a6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static final DEFAULT_DIAGNOSTIC_LEVEL:Lio/sentry/a5;

.field private static final DEFAULT_ENVIRONMENT:Ljava/lang/String; = "production"

.field public static final DEFAULT_PROPAGATION_TARGETS:Ljava/lang/String; = ".*"

.field public static final MAX_EVENT_SIZE_BYTES:J = 0x100000L


# instance fields
.field private attachServerName:Z

.field private attachStacktrace:Z

.field private attachThreads:Z

.field private backpressureMonitor:Lio/sentry/backpressure/b;

.field private beforeBreadcrumb:Lio/sentry/l5;

.field private beforeEnvelopeCallback:Lio/sentry/m5;

.field private beforeSend:Lio/sentry/n5;

.field private beforeSendFeedback:Lio/sentry/n5;

.field private beforeSendReplay:Lio/sentry/o5;

.field private beforeSendTransaction:Lio/sentry/p5;

.field private final bundleIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private cacheDirPath:Ljava/lang/String;

.field private captureOpenTelemetryEvents:Z

.field clientReportRecorder:Lio/sentry/clientreport/f;

.field private compositePerformanceCollector:Lio/sentry/l;

.field private connectionStatusProvider:Lio/sentry/o0;

.field private connectionTimeoutMillis:I

.field private final contextTags:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private continuousProfiler:Lio/sentry/p0;

.field private cron:Lio/sentry/q5;

.field private final dateProvider:Lio/sentry/util/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/sentry/util/e;"
        }
    .end annotation
.end field

.field private deadlineTimeout:J

.field private debug:Z

.field private debugMetaLoader:Lio/sentry/internal/debugmeta/a;

.field private defaultScopeType:Lio/sentry/x3;

.field private final defaultTracePropagationTargets:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private diagnosticLevel:Lio/sentry/a5;

.field private dist:Ljava/lang/String;

.field private distinctId:Ljava/lang/String;

.field private distribution:Lio/sentry/r5;

.field private distributionController:Lio/sentry/q0;

.field private dsn:Ljava/lang/String;

.field private dsnHash:Ljava/lang/String;

.field private enableAppStartProfiling:Z

.field private enableAutoSessionTracking:Z

.field private enableBackpressureHandling:Z

.field private enableDatabaseTransactionTracing:Z

.field private enableDeduplication:Z

.field private enableEventSizeLimiting:Z

.field private enableExternalConfiguration:Z

.field private enablePrettySerializationOutput:Z

.field private enableScopePersistence:Z

.field private enableScreenTracking:Z

.field private enableShutdownHook:Z

.field private enableSpotlight:Z

.field private enableTimeToFullDisplayTracing:Z

.field private enableUncaughtExceptionHandler:Z

.field private enableUserInteractionBreadcrumbs:Z

.field private enableUserInteractionTracing:Z

.field private enabled:Z

.field private envelopeDiskCache:Lio/sentry/cache/d;

.field private final envelopeReader:Lio/sentry/util/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/sentry/util/e;"
        }
    .end annotation
.end field

.field private environment:Ljava/lang/String;

.field private final eventProcessors:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/c0;",
            ">;"
        }
    .end annotation
.end field

.field private executorService:Lio/sentry/d1;

.field private final experimental:Lio/sentry/d0;

.field private fatalLogger:Lio/sentry/ILogger;

.field private feedbackOptions:Lio/sentry/v4;

.field private flushTimeoutMillis:J

.field private forceInit:Z

.field private fullyDisplayedReporter:Lio/sentry/g0;

.field private final gestureTargetLocators:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/gestures/a;",
            ">;"
        }
    .end annotation
.end field

.field private globalHubMode:Ljava/lang/Boolean;

.field private idleTimeout:Ljava/lang/Long;

.field private ignoredCheckIns:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation
.end field

.field private ignoredErrors:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation
.end field

.field private final ignoredExceptionsForType:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Throwable;",
            ">;>;"
        }
    .end annotation
.end field

.field private ignoredSpanOrigins:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation
.end field

.field private ignoredTransactions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation
.end field

.field private final inAppExcludes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final inAppIncludes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private initPriority:Lio/sentry/n1;

.field private instrumenter:Lio/sentry/o1;

.field private final integrations:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/p1;",
            ">;"
        }
    .end annotation
.end field

.field private volatile internalTracesSampler:Lio/sentry/s6;

.field protected final lock:Lio/sentry/util/a;

.field private logger:Lio/sentry/ILogger;

.field private logs:Lio/sentry/s5;

.field private maxAttachmentSize:J

.field private maxBreadcrumbs:I

.field private maxCacheItems:I

.field private maxDepth:I

.field private maxFeatureFlags:I

.field private maxQueueSize:I

.field private maxRequestBodySize:Lio/sentry/y5;

.field private maxSpans:I

.field private maxTraceFileSize:J

.field private metrics:Lio/sentry/t5;

.field private modulesLoader:Lio/sentry/internal/modules/a;

.field private final observers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/z0;",
            ">;"
        }
    .end annotation
.end field

.field private onDiscard:Lio/sentry/u5;

.field private onOversizedEvent:Lio/sentry/v5;

.field private openTelemetryMode:Lio/sentry/j5;

.field private final optionsObservers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/t0;",
            ">;"
        }
    .end annotation
.end field

.field private final parsedDsn:Lio/sentry/util/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/sentry/util/e;"
        }
    .end annotation
.end field

.field private final performanceCollectors:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/sentry/u0;",
            ">;"
        }
    .end annotation
.end field

.field private printUncaughtStackTrace:Z

.field private profileLifecycle:Lio/sentry/j3;

.field private profileSessionSampleRate:Ljava/lang/Double;

.field private profilerConverter:Lio/sentry/x0;

.field private profilesSampleRate:Ljava/lang/Double;

.field private profilesSampler:Lio/sentry/w5;

.field private profilingTracesDirPath:Ljava/lang/String;

.field private profilingTracesHz:I

.field private proguardUuid:Ljava/lang/String;

.field private propagateTraceparent:Z

.field private proxy:Lio/sentry/x5;

.field private readTimeoutMillis:I

.field private release:Ljava/lang/String;

.field private replayController:Lio/sentry/n3;

.field private runtimeManager:Lio/sentry/util/runtime/b;

.field private sampleRate:Ljava/lang/Double;

.field private sdkVersion:Lio/sentry/protocol/t;

.field private sendClientReports:Z

.field private sendDefaultPii:Z

.field private sendModules:Z

.field private sentryClientName:Ljava/lang/String;

.field private final serializer:Lio/sentry/util/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/sentry/util/e;"
        }
    .end annotation
.end field

.field private serverName:Ljava/lang/String;

.field private sessionFlushTimeoutMillis:J

.field private sessionReplay:Lio/sentry/e6;

.field private sessionTrackingIntervalMillis:J

.field private shutdownTimeoutMillis:J

.field private socketTagger:Lio/sentry/g1;

.field private spanFactory:Lio/sentry/i1;

.field private spotlightConnectionUrl:Ljava/lang/String;

.field private sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

.field private startProfilerOnAppStart:Z

.field private final tags:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private threadChecker:Lio/sentry/util/thread/a;

.field private traceOptionsRequests:Z

.field private tracePropagationTargets:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private traceSampling:Z

.field private tracesSampleRate:Ljava/lang/Double;

.field private tracesSampler:Lio/sentry/z5;

.field private transactionProfiler:Lio/sentry/k1;

.field private transportFactory:Lio/sentry/l1;

.field private transportGate:Lio/sentry/transport/h;

.field private versionDetector:Lio/sentry/m1;

.field private final viewHierarchyExporters:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 2
    .line 3
    sput-object v0, Lio/sentry/a6;->DEFAULT_DIAGNOSTIC_LEVEL:Lio/sentry/a5;

    .line 4
    .line 5
    return-void
.end method

.method public constructor <init>(Z)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lio/sentry/a6;->eventProcessors:Ljava/util/List;

    .line 10
    .line 11
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lio/sentry/a6;->ignoredExceptionsForType:Ljava/util/Set;

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    iput-object v0, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 20
    .line 21
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 22
    .line 23
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object v1, p0, Lio/sentry/a6;->integrations:Ljava/util/List;

    .line 27
    .line 28
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 29
    .line 30
    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, Lio/sentry/a6;->bundleIds:Ljava/util/Set;

    .line 34
    .line 35
    new-instance v1, Lio/sentry/util/e;

    .line 36
    .line 37
    new-instance v2, Lio/sentry/k5;

    .line 38
    .line 39
    const/4 v3, 0x0

    .line 40
    invoke-direct {v2, p0, v3}, Lio/sentry/k5;-><init>(Lio/sentry/a6;I)V

    .line 41
    .line 42
    .line 43
    invoke-direct {v1, v2}, Lio/sentry/util/e;-><init>(Lio/sentry/util/d;)V

    .line 44
    .line 45
    .line 46
    iput-object v1, p0, Lio/sentry/a6;->parsedDsn:Lio/sentry/util/e;

    .line 47
    .line 48
    const-wide/16 v1, 0x7d0

    .line 49
    .line 50
    iput-wide v1, p0, Lio/sentry/a6;->shutdownTimeoutMillis:J

    .line 51
    .line 52
    const-wide/16 v1, 0x3a98

    .line 53
    .line 54
    iput-wide v1, p0, Lio/sentry/a6;->flushTimeoutMillis:J

    .line 55
    .line 56
    iput-wide v1, p0, Lio/sentry/a6;->sessionFlushTimeoutMillis:J

    .line 57
    .line 58
    sget-object v1, Lio/sentry/m2;->d:Lio/sentry/m2;

    .line 59
    .line 60
    iput-object v1, p0, Lio/sentry/a6;->logger:Lio/sentry/ILogger;

    .line 61
    .line 62
    iput-object v1, p0, Lio/sentry/a6;->fatalLogger:Lio/sentry/ILogger;

    .line 63
    .line 64
    sget-object v2, Lio/sentry/a6;->DEFAULT_DIAGNOSTIC_LEVEL:Lio/sentry/a5;

    .line 65
    .line 66
    iput-object v2, p0, Lio/sentry/a6;->diagnosticLevel:Lio/sentry/a5;

    .line 67
    .line 68
    new-instance v2, Lio/sentry/util/e;

    .line 69
    .line 70
    new-instance v4, Lio/sentry/k5;

    .line 71
    .line 72
    const/4 v5, 0x1

    .line 73
    invoke-direct {v4, p0, v5}, Lio/sentry/k5;-><init>(Lio/sentry/a6;I)V

    .line 74
    .line 75
    .line 76
    invoke-direct {v2, v4}, Lio/sentry/util/e;-><init>(Lio/sentry/util/d;)V

    .line 77
    .line 78
    .line 79
    iput-object v2, p0, Lio/sentry/a6;->serializer:Lio/sentry/util/e;

    .line 80
    .line 81
    new-instance v2, Lio/sentry/util/e;

    .line 82
    .line 83
    new-instance v4, Lio/sentry/k5;

    .line 84
    .line 85
    const/4 v6, 0x2

    .line 86
    invoke-direct {v4, p0, v6}, Lio/sentry/k5;-><init>(Lio/sentry/a6;I)V

    .line 87
    .line 88
    .line 89
    invoke-direct {v2, v4}, Lio/sentry/util/e;-><init>(Lio/sentry/util/d;)V

    .line 90
    .line 91
    .line 92
    iput-object v2, p0, Lio/sentry/a6;->envelopeReader:Lio/sentry/util/e;

    .line 93
    .line 94
    const/16 v2, 0x64

    .line 95
    .line 96
    iput v2, p0, Lio/sentry/a6;->maxDepth:I

    .line 97
    .line 98
    const/16 v4, 0x1e

    .line 99
    .line 100
    iput v4, p0, Lio/sentry/a6;->maxCacheItems:I

    .line 101
    .line 102
    iput v4, p0, Lio/sentry/a6;->maxQueueSize:I

    .line 103
    .line 104
    iput v2, p0, Lio/sentry/a6;->maxBreadcrumbs:I

    .line 105
    .line 106
    iput v2, p0, Lio/sentry/a6;->maxFeatureFlags:I

    .line 107
    .line 108
    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 109
    .line 110
    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 111
    .line 112
    .line 113
    iput-object v2, p0, Lio/sentry/a6;->inAppExcludes:Ljava/util/List;

    .line 114
    .line 115
    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 116
    .line 117
    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 118
    .line 119
    .line 120
    iput-object v2, p0, Lio/sentry/a6;->inAppIncludes:Ljava/util/List;

    .line 121
    .line 122
    sget-object v2, Lio/sentry/a3;->d:Lio/sentry/a3;

    .line 123
    .line 124
    iput-object v2, p0, Lio/sentry/a6;->transportFactory:Lio/sentry/l1;

    .line 125
    .line 126
    sget-object v2, Lio/sentry/transport/k;->d:Lio/sentry/transport/k;

    .line 127
    .line 128
    iput-object v2, p0, Lio/sentry/a6;->transportGate:Lio/sentry/transport/h;

    .line 129
    .line 130
    iput-boolean v5, p0, Lio/sentry/a6;->attachStacktrace:Z

    .line 131
    .line 132
    iput-boolean v5, p0, Lio/sentry/a6;->enableAutoSessionTracking:Z

    .line 133
    .line 134
    const-wide/16 v6, 0x7530

    .line 135
    .line 136
    iput-wide v6, p0, Lio/sentry/a6;->sessionTrackingIntervalMillis:J

    .line 137
    .line 138
    iput-boolean v5, p0, Lio/sentry/a6;->attachServerName:Z

    .line 139
    .line 140
    iput-boolean v5, p0, Lio/sentry/a6;->enableUncaughtExceptionHandler:Z

    .line 141
    .line 142
    iput-boolean v3, p0, Lio/sentry/a6;->printUncaughtStackTrace:Z

    .line 143
    .line 144
    sget-object v2, Lio/sentry/j2;->i:Lio/sentry/j2;

    .line 145
    .line 146
    iput-object v2, p0, Lio/sentry/a6;->executorService:Lio/sentry/d1;

    .line 147
    .line 148
    const/16 v2, 0x7530

    .line 149
    .line 150
    iput v2, p0, Lio/sentry/a6;->connectionTimeoutMillis:I

    .line 151
    .line 152
    iput v2, p0, Lio/sentry/a6;->readTimeoutMillis:I

    .line 153
    .line 154
    sget-object v2, Lio/sentry/transport/i;->d:Lio/sentry/transport/i;

    .line 155
    .line 156
    iput-object v2, p0, Lio/sentry/a6;->envelopeDiskCache:Lio/sentry/cache/d;

    .line 157
    .line 158
    iput-boolean v3, p0, Lio/sentry/a6;->sendDefaultPii:Z

    .line 159
    .line 160
    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 161
    .line 162
    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 163
    .line 164
    .line 165
    iput-object v2, p0, Lio/sentry/a6;->observers:Ljava/util/List;

    .line 166
    .line 167
    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 168
    .line 169
    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 170
    .line 171
    .line 172
    iput-object v2, p0, Lio/sentry/a6;->optionsObservers:Ljava/util/List;

    .line 173
    .line 174
    new-instance v2, Ljava/util/concurrent/ConcurrentHashMap;

    .line 175
    .line 176
    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 177
    .line 178
    .line 179
    iput-object v2, p0, Lio/sentry/a6;->tags:Ljava/util/Map;

    .line 180
    .line 181
    const-wide/32 v8, 0x1400000

    .line 182
    .line 183
    .line 184
    iput-wide v8, p0, Lio/sentry/a6;->maxAttachmentSize:J

    .line 185
    .line 186
    iput-boolean v5, p0, Lio/sentry/a6;->enableDeduplication:Z

    .line 187
    .line 188
    iput-boolean v3, p0, Lio/sentry/a6;->enableEventSizeLimiting:Z

    .line 189
    .line 190
    const/16 v2, 0x3e8

    .line 191
    .line 192
    iput v2, p0, Lio/sentry/a6;->maxSpans:I

    .line 193
    .line 194
    iput-boolean v5, p0, Lio/sentry/a6;->enableShutdownHook:Z

    .line 195
    .line 196
    sget-object v2, Lio/sentry/y5;->NONE:Lio/sentry/y5;

    .line 197
    .line 198
    iput-object v2, p0, Lio/sentry/a6;->maxRequestBodySize:Lio/sentry/y5;

    .line 199
    .line 200
    iput-boolean v5, p0, Lio/sentry/a6;->traceSampling:Z

    .line 201
    .line 202
    const-wide/32 v8, 0x500000

    .line 203
    .line 204
    .line 205
    iput-wide v8, p0, Lio/sentry/a6;->maxTraceFileSize:J

    .line 206
    .line 207
    sget-object v2, Lio/sentry/j2;->v:Lio/sentry/j2;

    .line 208
    .line 209
    iput-object v2, p0, Lio/sentry/a6;->transactionProfiler:Lio/sentry/k1;

    .line 210
    .line 211
    sget-object v2, Lio/sentry/i2;->d:Lio/sentry/i2;

    .line 212
    .line 213
    iput-object v2, p0, Lio/sentry/a6;->continuousProfiler:Lio/sentry/p0;

    .line 214
    .line 215
    sget-object v2, Lio/sentry/n2;->a:Lio/sentry/n2;

    .line 216
    .line 217
    iput-object v2, p0, Lio/sentry/a6;->profilerConverter:Lio/sentry/x0;

    .line 218
    .line 219
    iput-object v0, p0, Lio/sentry/a6;->tracePropagationTargets:Ljava/util/List;

    .line 220
    .line 221
    const-string v2, ".*"

    .line 222
    .line 223
    invoke-static {v2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    iput-object v2, p0, Lio/sentry/a6;->defaultTracePropagationTargets:Ljava/util/List;

    .line 228
    .line 229
    iput-boolean v3, p0, Lio/sentry/a6;->propagateTraceparent:Z

    .line 230
    .line 231
    const-wide/16 v8, 0xbb8

    .line 232
    .line 233
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    iput-object v2, p0, Lio/sentry/a6;->idleTimeout:Ljava/lang/Long;

    .line 238
    .line 239
    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 240
    .line 241
    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 242
    .line 243
    .line 244
    iput-object v2, p0, Lio/sentry/a6;->contextTags:Ljava/util/List;

    .line 245
    .line 246
    iput-boolean v5, p0, Lio/sentry/a6;->sendClientReports:Z

    .line 247
    .line 248
    new-instance v2, Lz5/u;

    .line 249
    .line 250
    invoke-direct {v2, p0}, Lz5/u;-><init>(Lio/sentry/a6;)V

    .line 251
    .line 252
    .line 253
    iput-object v2, p0, Lio/sentry/a6;->clientReportRecorder:Lio/sentry/clientreport/f;

    .line 254
    .line 255
    sget-object v2, Lio/sentry/internal/modules/e;->a:Lio/sentry/internal/modules/e;

    .line 256
    .line 257
    iput-object v2, p0, Lio/sentry/a6;->modulesLoader:Lio/sentry/internal/modules/a;

    .line 258
    .line 259
    sget-object v2, Lio/sentry/internal/debugmeta/b;->d:Lio/sentry/internal/debugmeta/b;

    .line 260
    .line 261
    iput-object v2, p0, Lio/sentry/a6;->debugMetaLoader:Lio/sentry/internal/debugmeta/a;

    .line 262
    .line 263
    iput-boolean v3, p0, Lio/sentry/a6;->enableUserInteractionTracing:Z

    .line 264
    .line 265
    iput-boolean v5, p0, Lio/sentry/a6;->enableUserInteractionBreadcrumbs:Z

    .line 266
    .line 267
    sget-object v2, Lio/sentry/o1;->SENTRY:Lio/sentry/o1;

    .line 268
    .line 269
    iput-object v2, p0, Lio/sentry/a6;->instrumenter:Lio/sentry/o1;

    .line 270
    .line 271
    new-instance v2, Ljava/util/ArrayList;

    .line 272
    .line 273
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 274
    .line 275
    .line 276
    iput-object v2, p0, Lio/sentry/a6;->gestureTargetLocators:Ljava/util/List;

    .line 277
    .line 278
    new-instance v2, Ljava/util/ArrayList;

    .line 279
    .line 280
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 281
    .line 282
    .line 283
    iput-object v2, p0, Lio/sentry/a6;->viewHierarchyExporters:Ljava/util/List;

    .line 284
    .line 285
    sget-object v2, Lio/sentry/util/thread/b;->a:Lio/sentry/util/thread/b;

    .line 286
    .line 287
    iput-object v2, p0, Lio/sentry/a6;->threadChecker:Lio/sentry/util/thread/a;

    .line 288
    .line 289
    iput-boolean v5, p0, Lio/sentry/a6;->traceOptionsRequests:Z

    .line 290
    .line 291
    iput-boolean v3, p0, Lio/sentry/a6;->enableDatabaseTransactionTracing:Z

    .line 292
    .line 293
    new-instance v2, Lio/sentry/util/e;

    .line 294
    .line 295
    new-instance v4, Lio/sentry/p2;

    .line 296
    .line 297
    const/4 v8, 0x3

    .line 298
    invoke-direct {v4, v8}, Lio/sentry/p2;-><init>(I)V

    .line 299
    .line 300
    .line 301
    invoke-direct {v2, v4}, Lio/sentry/util/e;-><init>(Lio/sentry/util/d;)V

    .line 302
    .line 303
    .line 304
    iput-object v2, p0, Lio/sentry/a6;->dateProvider:Lio/sentry/util/e;

    .line 305
    .line 306
    new-instance v2, Ljava/util/ArrayList;

    .line 307
    .line 308
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 309
    .line 310
    .line 311
    iput-object v2, p0, Lio/sentry/a6;->performanceCollectors:Ljava/util/List;

    .line 312
    .line 313
    sget-object v2, Lio/sentry/g2;->a:Lio/sentry/g2;

    .line 314
    .line 315
    iput-object v2, p0, Lio/sentry/a6;->compositePerformanceCollector:Lio/sentry/l;

    .line 316
    .line 317
    iput-boolean v3, p0, Lio/sentry/a6;->enableTimeToFullDisplayTracing:Z

    .line 318
    .line 319
    sget-object v2, Lio/sentry/g0;->b:Lio/sentry/g0;

    .line 320
    .line 321
    iput-object v2, p0, Lio/sentry/a6;->fullyDisplayedReporter:Lio/sentry/g0;

    .line 322
    .line 323
    new-instance v2, Lio/sentry/h2;

    .line 324
    .line 325
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 326
    .line 327
    .line 328
    iput-object v2, p0, Lio/sentry/a6;->connectionStatusProvider:Lio/sentry/o0;

    .line 329
    .line 330
    iput-boolean v5, p0, Lio/sentry/a6;->enabled:Z

    .line 331
    .line 332
    iput-boolean v5, p0, Lio/sentry/a6;->enablePrettySerializationOutput:Z

    .line 333
    .line 334
    iput-boolean v5, p0, Lio/sentry/a6;->sendModules:Z

    .line 335
    .line 336
    iput-boolean v3, p0, Lio/sentry/a6;->enableSpotlight:Z

    .line 337
    .line 338
    iput-boolean v5, p0, Lio/sentry/a6;->enableScopePersistence:Z

    .line 339
    .line 340
    iput-object v0, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 341
    .line 342
    iput-object v0, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 343
    .line 344
    iput-object v0, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 345
    .line 346
    sget-object v2, Lio/sentry/backpressure/c;->d:Lio/sentry/backpressure/c;

    .line 347
    .line 348
    iput-object v2, p0, Lio/sentry/a6;->backpressureMonitor:Lio/sentry/backpressure/b;

    .line 349
    .line 350
    iput-boolean v5, p0, Lio/sentry/a6;->enableBackpressureHandling:Z

    .line 351
    .line 352
    iput-boolean v3, p0, Lio/sentry/a6;->enableAppStartProfiling:Z

    .line 353
    .line 354
    sget-object v2, Lio/sentry/y2;->b:Lio/sentry/y2;

    .line 355
    .line 356
    iput-object v2, p0, Lio/sentry/a6;->spanFactory:Lio/sentry/i1;

    .line 357
    .line 358
    const/16 v2, 0x65

    .line 359
    .line 360
    iput v2, p0, Lio/sentry/a6;->profilingTracesHz:I

    .line 361
    .line 362
    iput-object v0, p0, Lio/sentry/a6;->cron:Lio/sentry/q5;

    .line 363
    .line 364
    sget-object v2, Lio/sentry/j2;->e:Lio/sentry/j2;

    .line 365
    .line 366
    iput-object v2, p0, Lio/sentry/a6;->replayController:Lio/sentry/n3;

    .line 367
    .line 368
    sget-object v2, Lio/sentry/j2;->d:Lio/sentry/j2;

    .line 369
    .line 370
    iput-object v2, p0, Lio/sentry/a6;->distributionController:Lio/sentry/q0;

    .line 371
    .line 372
    iput-boolean v5, p0, Lio/sentry/a6;->enableScreenTracking:Z

    .line 373
    .line 374
    sget-object v2, Lio/sentry/x3;->ISOLATION:Lio/sentry/x3;

    .line 375
    .line 376
    iput-object v2, p0, Lio/sentry/a6;->defaultScopeType:Lio/sentry/x3;

    .line 377
    .line 378
    sget-object v2, Lio/sentry/n1;->MEDIUM:Lio/sentry/n1;

    .line 379
    .line 380
    iput-object v2, p0, Lio/sentry/a6;->initPriority:Lio/sentry/n1;

    .line 381
    .line 382
    iput-boolean v3, p0, Lio/sentry/a6;->forceInit:Z

    .line 383
    .line 384
    iput-object v0, p0, Lio/sentry/a6;->globalHubMode:Ljava/lang/Boolean;

    .line 385
    .line 386
    new-instance v2, Lio/sentry/util/a;

    .line 387
    .line 388
    invoke-direct {v2}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 389
    .line 390
    .line 391
    iput-object v2, p0, Lio/sentry/a6;->lock:Lio/sentry/util/a;

    .line 392
    .line 393
    sget-object v2, Lio/sentry/j5;->AUTO:Lio/sentry/j5;

    .line 394
    .line 395
    iput-object v2, p0, Lio/sentry/a6;->openTelemetryMode:Lio/sentry/j5;

    .line 396
    .line 397
    iput-boolean v3, p0, Lio/sentry/a6;->captureOpenTelemetryEvents:Z

    .line 398
    .line 399
    sget-object v2, Lio/sentry/b3;->d:Lio/sentry/b3;

    .line 400
    .line 401
    iput-object v2, p0, Lio/sentry/a6;->versionDetector:Lio/sentry/m1;

    .line 402
    .line 403
    sget-object v2, Lio/sentry/j3;->MANUAL:Lio/sentry/j3;

    .line 404
    .line 405
    iput-object v2, p0, Lio/sentry/a6;->profileLifecycle:Lio/sentry/j3;

    .line 406
    .line 407
    iput-boolean v3, p0, Lio/sentry/a6;->startProfilerOnAppStart:Z

    .line 408
    .line 409
    iput-wide v6, p0, Lio/sentry/a6;->deadlineTimeout:J

    .line 410
    .line 411
    new-instance v2, Lio/sentry/s5;

    .line 412
    .line 413
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 414
    .line 415
    .line 416
    iput-boolean v3, v2, Lio/sentry/s5;->a:Z

    .line 417
    .line 418
    new-instance v4, Lio/sentry/logger/d;

    .line 419
    .line 420
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 421
    .line 422
    .line 423
    iput-object v4, v2, Lio/sentry/s5;->b:Lio/sentry/logger/b;

    .line 424
    .line 425
    iput-object v2, p0, Lio/sentry/a6;->logs:Lio/sentry/s5;

    .line 426
    .line 427
    new-instance v2, Lio/sentry/t5;

    .line 428
    .line 429
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 430
    .line 431
    .line 432
    iput-boolean v5, v2, Lio/sentry/t5;->a:Z

    .line 433
    .line 434
    new-instance v4, Lio/sentry/metrics/c;

    .line 435
    .line 436
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 437
    .line 438
    .line 439
    iput-object v4, v2, Lio/sentry/t5;->b:Lio/sentry/metrics/b;

    .line 440
    .line 441
    iput-object v2, p0, Lio/sentry/a6;->metrics:Lio/sentry/t5;

    .line 442
    .line 443
    sget-object v2, Lio/sentry/w2;->d:Lio/sentry/w2;

    .line 444
    .line 445
    iput-object v2, p0, Lio/sentry/a6;->socketTagger:Lio/sentry/g1;

    .line 446
    .line 447
    new-instance v2, Lzm/f;

    .line 448
    .line 449
    const/16 v4, 0xa

    .line 450
    .line 451
    invoke-direct {v2, v4}, Lzm/f;-><init>(I)V

    .line 452
    .line 453
    .line 454
    iput-object v2, p0, Lio/sentry/a6;->runtimeManager:Lio/sentry/util/runtime/b;

    .line 455
    .line 456
    new-instance v2, Lio/sentry/r5;

    .line 457
    .line 458
    invoke-direct {v2}, Lio/sentry/r5;-><init>()V

    .line 459
    .line 460
    .line 461
    iput-object v2, p0, Lio/sentry/a6;->distribution:Lio/sentry/r5;

    .line 462
    .line 463
    new-instance v2, Lio/sentry/protocol/t;

    .line 464
    .line 465
    const-string v4, "sentry.java"

    .line 466
    .line 467
    const-string v6, "8.32.0"

    .line 468
    .line 469
    invoke-direct {v2, v4, v6}, Lio/sentry/protocol/t;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 470
    .line 471
    .line 472
    iput-object v6, v2, Lio/sentry/protocol/t;->e:Ljava/lang/String;

    .line 473
    .line 474
    new-instance v4, Lio/sentry/d0;

    .line 475
    .line 476
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 477
    .line 478
    .line 479
    iput-object v4, p0, Lio/sentry/a6;->experimental:Lio/sentry/d0;

    .line 480
    .line 481
    new-instance v4, Lio/sentry/e6;

    .line 482
    .line 483
    invoke-direct {v4, p1, v2}, Lio/sentry/e6;-><init>(ZLio/sentry/protocol/t;)V

    .line 484
    .line 485
    .line 486
    iput-object v4, p0, Lio/sentry/a6;->sessionReplay:Lio/sentry/e6;

    .line 487
    .line 488
    new-instance v4, Lio/sentry/v4;

    .line 489
    .line 490
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 491
    .line 492
    .line 493
    iput-boolean v3, v4, Lio/sentry/v4;->a:Z

    .line 494
    .line 495
    iput-boolean v5, v4, Lio/sentry/v4;->b:Z

    .line 496
    .line 497
    iput-boolean v3, v4, Lio/sentry/v4;->c:Z

    .line 498
    .line 499
    iput-boolean v5, v4, Lio/sentry/v4;->d:Z

    .line 500
    .line 501
    iput-boolean v5, v4, Lio/sentry/v4;->e:Z

    .line 502
    .line 503
    iput-boolean v5, v4, Lio/sentry/v4;->f:Z

    .line 504
    .line 505
    iput-object v4, p0, Lio/sentry/a6;->feedbackOptions:Lio/sentry/v4;

    .line 506
    .line 507
    if-nez p1, :cond_28d

    .line 508
    .line 509
    sget-boolean p1, Lio/sentry/util/h;->a:Z

    .line 510
    .line 511
    if-nez p1, :cond_21f

    .line 512
    .line 513
    const-string p1, "io.sentry.opentelemetry.OtelSpanFactory"

    .line 514
    .line 515
    invoke-static {p1, v1}, Lio/sentry/util/f;->b(Ljava/lang/String;Lio/sentry/ILogger;)Z

    .line 516
    .line 517
    .line 518
    move-result v3

    .line 519
    if-eqz v3, :cond_21f

    .line 520
    .line 521
    invoke-static {p1, v1}, Lio/sentry/util/f;->c(Ljava/lang/String;Lio/sentry/ILogger;)Ljava/lang/Class;

    .line 522
    .line 523
    .line 524
    move-result-object p1

    .line 525
    if-eqz p1, :cond_21f

    .line 526
    .line 527
    :try_start_20e
    invoke-virtual {p1, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 528
    .line 529
    .line 530
    move-result-object p1

    .line 531
    invoke-virtual {p1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 532
    .line 533
    .line 534
    move-result-object p1

    .line 535
    if-eqz p1, :cond_21f

    .line 536
    .line 537
    instance-of v1, p1, Lio/sentry/i1;

    .line 538
    .line 539
    if-eqz v1, :cond_21f

    .line 540
    .line 541
    check-cast p1, Lio/sentry/i1;
    :try_end_21e
    .catch Ljava/lang/InstantiationException; {:try_start_20e .. :try_end_21e} :catch_21f
    .catch Ljava/lang/IllegalAccessException; {:try_start_20e .. :try_end_21e} :catch_21f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_20e .. :try_end_21e} :catch_21f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_20e .. :try_end_21e} :catch_21f

    .line 542
    .line 543
    goto :goto_224

    .line 544
    :catch_21f
    :cond_21f
    new-instance p1, Lio/sentry/y2;

    .line 545
    .line 546
    invoke-direct {p1, v5}, Lio/sentry/y2;-><init>(I)V

    .line 547
    .line 548
    .line 549
    :goto_224
    invoke-virtual {p0, p1}, Lio/sentry/a6;->setSpanFactory(Lio/sentry/i1;)V

    .line 550
    .line 551
    .line 552
    new-instance p1, Lld/d;

    .line 553
    .line 554
    invoke-direct {p1, p0}, Lld/d;-><init>(Lio/sentry/a6;)V

    .line 555
    .line 556
    .line 557
    iput-object p1, p0, Lio/sentry/a6;->executorService:Lio/sentry/d1;

    .line 558
    .line 559
    invoke-virtual {p1}, Lld/d;->f()V

    .line 560
    .line 561
    .line 562
    iget-object p1, p0, Lio/sentry/a6;->integrations:Ljava/util/List;

    .line 563
    .line 564
    new-instance v1, Lio/sentry/UncaughtExceptionHandlerIntegration;

    .line 565
    .line 566
    invoke-direct {v1}, Lio/sentry/UncaughtExceptionHandlerIntegration;-><init>()V

    .line 567
    .line 568
    .line 569
    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 570
    .line 571
    .line 572
    iget-object p1, p0, Lio/sentry/a6;->integrations:Ljava/util/List;

    .line 573
    .line 574
    new-instance v1, Lio/sentry/ShutdownHookIntegration;

    .line 575
    .line 576
    invoke-direct {v1}, Lio/sentry/ShutdownHookIntegration;-><init>()V

    .line 577
    .line 578
    .line 579
    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 580
    .line 581
    .line 582
    :try_start_245
    const-string p1, "io.sentry.spotlight.SpotlightIntegration"

    .line 583
    .line 584
    invoke-static {p1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 585
    .line 586
    .line 587
    move-result-object p1

    .line 588
    invoke-virtual {p1, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 589
    .line 590
    .line 591
    move-result-object p1

    .line 592
    invoke-virtual {p1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 593
    .line 594
    .line 595
    move-result-object p1

    .line 596
    check-cast p1, Lio/sentry/p1;

    .line 597
    .line 598
    iget-object v0, p0, Lio/sentry/a6;->integrations:Ljava/util/List;

    .line 599
    .line 600
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_25a
    .catchall {:try_start_245 .. :try_end_25a} :catchall_25a

    .line 601
    .line 602
    .line 603
    :catchall_25a
    iget-object p1, p0, Lio/sentry/a6;->eventProcessors:Ljava/util/List;

    .line 604
    .line 605
    new-instance v0, Lio/sentry/d2;

    .line 606
    .line 607
    invoke-direct {v0, p0}, Lio/sentry/d2;-><init>(Lio/sentry/a6;)V

    .line 608
    .line 609
    .line 610
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 611
    .line 612
    .line 613
    iget-object p1, p0, Lio/sentry/a6;->eventProcessors:Ljava/util/List;

    .line 614
    .line 615
    new-instance v0, Lio/sentry/n;

    .line 616
    .line 617
    invoke-direct {v0, p0}, Lio/sentry/n;-><init>(Lio/sentry/a6;)V

    .line 618
    .line 619
    .line 620
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 621
    .line 622
    .line 623
    sget-boolean p1, Lio/sentry/util/h;->a:Z

    .line 624
    .line 625
    if-nez p1, :cond_27c

    .line 626
    .line 627
    iget-object p1, p0, Lio/sentry/a6;->eventProcessors:Ljava/util/List;

    .line 628
    .line 629
    new-instance v0, Lio/sentry/f6;

    .line 630
    .line 631
    invoke-direct {v0}, Lio/sentry/f6;-><init>()V

    .line 632
    .line 633
    .line 634
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 635
    .line 636
    .line 637
    :cond_27c
    const-string p1, "sentry.java/8.32.0"

    .line 638
    .line 639
    invoke-virtual {p0, p1}, Lio/sentry/a6;->setSentryClientName(Ljava/lang/String;)V

    .line 640
    .line 641
    .line 642
    invoke-virtual {p0, v2}, Lio/sentry/a6;->setSdkVersion(Lio/sentry/protocol/t;)V

    .line 643
    .line 644
    .line 645
    invoke-static {}, Lio/sentry/y4;->d()Lio/sentry/y4;

    .line 646
    .line 647
    .line 648
    move-result-object p1

    .line 649
    const-string v0, "maven:io.sentry:sentry"

    .line 650
    .line 651
    invoke-virtual {p1, v0, v6}, Lio/sentry/y4;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 652
    .line 653
    .line 654
    :cond_28d
    return-void
.end method

.method public static synthetic a(Lio/sentry/a6;)Lio/sentry/z;
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/z;

    .line 2
    .line 3
    iget-object p0, p0, Lio/sentry/a6;->dsn:Ljava/lang/String;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Lio/sentry/z;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public static synthetic b(Lio/sentry/a6;)Lio/sentry/a0;
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/a0;

    .line 2
    .line 3
    iget-object p0, p0, Lio/sentry/a6;->serializer:Lio/sentry/util/e;

    .line 4
    .line 5
    invoke-virtual {p0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lio/sentry/f1;

    .line 10
    .line 11
    invoke-direct {v0, p0}, Lio/sentry/a0;-><init>(Lio/sentry/f1;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public static empty()Lio/sentry/a6;
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/a6;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Lio/sentry/a6;-><init>(Z)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method


# virtual methods
.method public addBundleId(Ljava/lang/String;)V
    .registers 3

    .line 1
    if-eqz p1, :cond_11

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_11

    .line 12
    .line 13
    iget-object v0, p0, Lio/sentry/a6;->bundleIds:Ljava/util/Set;

    .line 14
    .line 15
    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public addContextTag(Ljava/lang/String;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->contextTags:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addEventProcessor(Lio/sentry/c0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->eventProcessors:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addIgnoredCheckIn(Ljava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 11
    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 13
    .line 14
    new-instance v1, Lio/sentry/f0;

    .line 15
    .line 16
    invoke-direct {v1, p1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public addIgnoredError(Ljava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 11
    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 13
    .line 14
    new-instance v1, Lio/sentry/f0;

    .line 15
    .line 16
    invoke-direct {v1, p1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public addIgnoredExceptionForType(Ljava/lang/Class;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredExceptionsForType:Ljava/util/Set;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addIgnoredSpanOrigin(Ljava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 11
    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 13
    .line 14
    new-instance v1, Lio/sentry/f0;

    .line 15
    .line 16
    invoke-direct {v1, p1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public addIgnoredTransaction(Ljava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 11
    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 13
    .line 14
    new-instance v1, Lio/sentry/f0;

    .line 15
    .line 16
    invoke-direct {v1, p1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public addInAppExclude(Ljava/lang/String;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->inAppExcludes:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addInAppInclude(Ljava/lang/String;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->inAppIncludes:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addIntegration(Lio/sentry/p1;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->integrations:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addOptionsObserver(Lio/sentry/t0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->optionsObservers:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addPerformanceCollector(Lio/sentry/u0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->performanceCollectors:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public addScopeObserver(Lio/sentry/z0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->observers:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public containsIgnoredExceptionForType(Ljava/lang/Throwable;)Z
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredExceptionsForType:Ljava/util/Set;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1
.end method

.method public findPersistingScopeObserver()Lio/sentry/cache/g;
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->observers:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :cond_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_19

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Lio/sentry/z0;

    .line 18
    .line 19
    instance-of v2, v1, Lio/sentry/cache/g;

    .line 20
    .line 21
    if-eqz v2, :cond_6

    .line 22
    .line 23
    check-cast v1, Lio/sentry/cache/g;

    .line 24
    .line 25
    return-object v1

    .line 26
    :cond_19
    const/4 v0, 0x0

    .line 27
    return-object v0
.end method

.method public getBackpressureMonitor()Lio/sentry/backpressure/b;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->backpressureMonitor:Lio/sentry/backpressure/b;

    .line 2
    .line 3
    return-object v0
.end method

.method public getBeforeBreadcrumb()Lio/sentry/l5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->beforeBreadcrumb:Lio/sentry/l5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getBeforeEnvelopeCallback()Lio/sentry/m5;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getBeforeSend()Lio/sentry/n5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->beforeSend:Lio/sentry/n5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getBeforeSendFeedback()Lio/sentry/n5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->beforeSendFeedback:Lio/sentry/n5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getBeforeSendReplay()Lio/sentry/o5;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getBeforeSendTransaction()Lio/sentry/p5;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getBundleIds()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->bundleIds:Ljava/util/Set;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCacheDirPath()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->cacheDirPath:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz v0, :cond_20

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_20

    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->dsnHash:Ljava/lang/String;

    .line 13
    .line 14
    if-eqz v0, :cond_1d

    .line 15
    .line 16
    new-instance v0, Ljava/io/File;

    .line 17
    .line 18
    iget-object v1, p0, Lio/sentry/a6;->cacheDirPath:Ljava/lang/String;

    .line 19
    .line 20
    iget-object v2, p0, Lio/sentry/a6;->dsnHash:Ljava/lang/String;

    .line 21
    .line 22
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    return-object v0

    .line 30
    :cond_1d
    iget-object v0, p0, Lio/sentry/a6;->cacheDirPath:Ljava/lang/String;

    .line 31
    .line 32
    return-object v0

    .line 33
    :cond_20
    :goto_20
    const/4 v0, 0x0

    .line 34
    return-object v0
.end method

.method public getCacheDirPathWithoutDsn()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->cacheDirPath:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz v0, :cond_e

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_e

    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->cacheDirPath:Ljava/lang/String;

    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_e
    :goto_e
    const/4 v0, 0x0

    .line 16
    return-object v0
.end method

.method public getClientReportRecorder()Lio/sentry/clientreport/f;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->clientReportRecorder:Lio/sentry/clientreport/f;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCompositePerformanceCollector()Lio/sentry/l;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->compositePerformanceCollector:Lio/sentry/l;

    .line 2
    .line 3
    return-object v0
.end method

.method public getConnectionStatusProvider()Lio/sentry/o0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->connectionStatusProvider:Lio/sentry/o0;

    .line 2
    .line 3
    return-object v0
.end method

.method public getConnectionTimeoutMillis()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->connectionTimeoutMillis:I

    .line 2
    .line 3
    return v0
.end method

.method public getContextTags()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->contextTags:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getContinuousProfiler()Lio/sentry/p0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->continuousProfiler:Lio/sentry/p0;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCron()Lio/sentry/q5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->cron:Lio/sentry/q5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDateProvider()Lio/sentry/m4;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->dateProvider:Lio/sentry/util/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lio/sentry/m4;

    .line 8
    .line 9
    return-object v0
.end method

.method public getDeadlineTimeout()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->deadlineTimeout:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getDebugMetaLoader()Lio/sentry/internal/debugmeta/a;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->debugMetaLoader:Lio/sentry/internal/debugmeta/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDefaultScopeType()Lio/sentry/x3;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->defaultScopeType:Lio/sentry/x3;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDiagnosticLevel()Lio/sentry/a5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->diagnosticLevel:Lio/sentry/a5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDist()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->dist:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDistinctId()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->distinctId:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDistribution()Lio/sentry/r5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->distribution:Lio/sentry/r5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDistributionController()Lio/sentry/q0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->distributionController:Lio/sentry/q0;

    .line 2
    .line 3
    return-object v0
.end method

.method public getDsn()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->dsn:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getEnvelopeDiskCache()Lio/sentry/cache/d;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->envelopeDiskCache:Lio/sentry/cache/d;

    .line 2
    .line 3
    return-object v0
.end method

.method public getEnvelopeReader()Lio/sentry/r0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->envelopeReader:Lio/sentry/util/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lio/sentry/r0;

    .line 8
    .line 9
    return-object v0
.end method

.method public getEnvironment()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->environment:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    const-string v0, "production"

    .line 7
    .line 8
    return-object v0
.end method

.method public getEventProcessors()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/c0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->eventProcessors:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getExecutorService()Lio/sentry/d1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->executorService:Lio/sentry/d1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getExperimental()Lio/sentry/d0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->experimental:Lio/sentry/d0;

    .line 2
    .line 3
    return-object v0
.end method

.method public getFatalLogger()Lio/sentry/ILogger;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->fatalLogger:Lio/sentry/ILogger;

    .line 2
    .line 3
    return-object v0
.end method

.method public getFeedbackOptions()Lio/sentry/v4;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->feedbackOptions:Lio/sentry/v4;

    .line 2
    .line 3
    return-object v0
.end method

.method public getFlushTimeoutMillis()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->flushTimeoutMillis:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getFullyDisplayedReporter()Lio/sentry/g0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->fullyDisplayedReporter:Lio/sentry/g0;

    .line 2
    .line 3
    return-object v0
.end method

.method public getGestureTargetLocators()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/gestures/a;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->gestureTargetLocators:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIdleTimeout()Ljava/lang/Long;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->idleTimeout:Ljava/lang/Long;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIgnoredCheckIns()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIgnoredErrors()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIgnoredExceptionsForType()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Throwable;",
            ">;>;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredExceptionsForType:Ljava/util/Set;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIgnoredSpanOrigins()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIgnoredTransactions()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/f0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getInAppExcludes()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->inAppExcludes:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getInAppIncludes()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->inAppIncludes:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getInitPriority()Lio/sentry/n1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->initPriority:Lio/sentry/n1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getInstrumenter()Lio/sentry/o1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->instrumenter:Lio/sentry/o1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIntegrations()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/p1;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->integrations:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getInternalTracesSampler()Lio/sentry/s6;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->internalTracesSampler:Lio/sentry/s6;

    .line 2
    .line 3
    if-nez v0, :cond_25

    .line 4
    .line 5
    iget-object v0, p0, Lio/sentry/a6;->lock:Lio/sentry/util/a;

    .line 6
    .line 7
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    :try_start_a
    iget-object v1, p0, Lio/sentry/a6;->internalTracesSampler:Lio/sentry/s6;

    .line 12
    .line 13
    if-nez v1, :cond_18

    .line 14
    .line 15
    new-instance v1, Lio/sentry/s6;

    .line 16
    .line 17
    invoke-direct {v1, p0}, Lio/sentry/s6;-><init>(Lio/sentry/a6;)V

    .line 18
    .line 19
    .line 20
    iput-object v1, p0, Lio/sentry/a6;->internalTracesSampler:Lio/sentry/s6;
    :try_end_15
    .catchall {:try_start_a .. :try_end_15} :catchall_16

    .line 21
    .line 22
    goto :goto_18

    .line 23
    :catchall_16
    move-exception v1

    .line 24
    goto :goto_1c

    .line 25
    :cond_18
    :goto_18
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 26
    .line 27
    .line 28
    goto :goto_25

    .line 29
    :goto_1c
    :try_start_1c
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_1f
    .catchall {:try_start_1c .. :try_end_1f} :catchall_20

    .line 30
    .line 31
    .line 32
    goto :goto_24

    .line 33
    :catchall_20
    move-exception v0

    .line 34
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 35
    .line 36
    .line 37
    :goto_24
    throw v1

    .line 38
    :cond_25
    :goto_25
    iget-object v0, p0, Lio/sentry/a6;->internalTracesSampler:Lio/sentry/s6;

    .line 39
    .line 40
    return-object v0
.end method

.method public getLogger()Lio/sentry/ILogger;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->logger:Lio/sentry/ILogger;

    .line 2
    .line 3
    return-object v0
.end method

.method public getLogs()Lio/sentry/s5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->logs:Lio/sentry/s5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMaxAttachmentSize()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->maxAttachmentSize:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getMaxBreadcrumbs()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->maxBreadcrumbs:I

    .line 2
    .line 3
    return v0
.end method

.method public getMaxCacheItems()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->maxCacheItems:I

    .line 2
    .line 3
    return v0
.end method

.method public getMaxDepth()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->maxDepth:I

    .line 2
    .line 3
    return v0
.end method

.method public getMaxFeatureFlags()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->maxFeatureFlags:I

    .line 2
    .line 3
    return v0
.end method

.method public getMaxQueueSize()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->maxQueueSize:I

    .line 2
    .line 3
    return v0
.end method

.method public getMaxRequestBodySize()Lio/sentry/y5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->maxRequestBodySize:Lio/sentry/y5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMaxSpans()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->maxSpans:I

    .line 2
    .line 3
    return v0
.end method

.method public getMaxTraceFileSize()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->maxTraceFileSize:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getMetrics()Lio/sentry/t5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->metrics:Lio/sentry/t5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getModulesLoader()Lio/sentry/internal/modules/a;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->modulesLoader:Lio/sentry/internal/modules/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOnDiscard()Lio/sentry/u5;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getOnOversizedEvent()Lio/sentry/v5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->onOversizedEvent:Lio/sentry/v5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOpenTelemetryMode()Lio/sentry/j5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->openTelemetryMode:Lio/sentry/j5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOptionsObservers()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/t0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->optionsObservers:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOutboxPath()Ljava/lang/String;
    .registers 4

    .line 1
    invoke-virtual {p0}, Lio/sentry/a6;->getCacheDirPath()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    return-object v0

    .line 9
    :cond_8
    new-instance v1, Ljava/io/File;

    .line 10
    .line 11
    const-string v2, "outbox"

    .line 12
    .line 13
    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method

.method public getPerformanceCollectors()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/u0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->performanceCollectors:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getProfileLifecycle()Lio/sentry/j3;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profileLifecycle:Lio/sentry/j3;

    .line 2
    .line 3
    return-object v0
.end method

.method public getProfileSessionSampleRate()Ljava/lang/Double;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profileSessionSampleRate:Ljava/lang/Double;

    .line 2
    .line 3
    return-object v0
.end method

.method public getProfilerConverter()Lio/sentry/x0;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profilerConverter:Lio/sentry/x0;

    .line 2
    .line 3
    return-object v0
.end method

.method public getProfilesSampleRate()Ljava/lang/Double;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profilesSampleRate:Ljava/lang/Double;

    .line 2
    .line 3
    return-object v0
.end method

.method public getProfilesSampler()Lio/sentry/w5;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getProfilingTracesDirPath()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profilingTracesDirPath:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz v0, :cond_1f

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_1f

    .line 10
    .line 11
    iget-object v0, p0, Lio/sentry/a6;->dsnHash:Ljava/lang/String;

    .line 12
    .line 13
    if-eqz v0, :cond_1c

    .line 14
    .line 15
    new-instance v0, Ljava/io/File;

    .line 16
    .line 17
    iget-object v1, p0, Lio/sentry/a6;->profilingTracesDirPath:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v2, p0, Lio/sentry/a6;->dsnHash:Ljava/lang/String;

    .line 20
    .line 21
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    return-object v0

    .line 29
    :cond_1c
    iget-object v0, p0, Lio/sentry/a6;->profilingTracesDirPath:Ljava/lang/String;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_1f
    invoke-virtual {p0}, Lio/sentry/a6;->getCacheDirPath()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-nez v0, :cond_27

    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    return-object v0

    .line 40
    :cond_27
    new-instance v1, Ljava/io/File;

    .line 41
    .line 42
    const-string v2, "profiling_traces"

    .line 43
    .line 44
    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    return-object v0
.end method

.method public getProfilingTracesHz()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->profilingTracesHz:I

    .line 2
    .line 3
    return v0
.end method

.method public getProguardUuid()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->proguardUuid:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getProxy()Lio/sentry/x5;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->proxy:Lio/sentry/x5;

    .line 2
    .line 3
    return-object v0
.end method

.method public getReadTimeoutMillis()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/a6;->readTimeoutMillis:I

    .line 2
    .line 3
    return v0
.end method

.method public getRelease()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->release:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getReplayController()Lio/sentry/n3;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->replayController:Lio/sentry/n3;

    .line 2
    .line 3
    return-object v0
.end method

.method public getRuntimeManager()Lio/sentry/util/runtime/b;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->runtimeManager:Lio/sentry/util/runtime/b;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSampleRate()Ljava/lang/Double;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->sampleRate:Ljava/lang/Double;

    .line 2
    .line 3
    return-object v0
.end method

.method public getScopeObservers()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/z0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->observers:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSdkVersion()Lio/sentry/protocol/t;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->sdkVersion:Lio/sentry/protocol/t;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSentryClientName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->sentryClientName:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSerializer()Lio/sentry/f1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->serializer:Lio/sentry/util/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lio/sentry/f1;

    .line 8
    .line 9
    return-object v0
.end method

.method public getServerName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->serverName:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSessionFlushTimeoutMillis()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->sessionFlushTimeoutMillis:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getSessionReplay()Lio/sentry/e6;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->sessionReplay:Lio/sentry/e6;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSessionTrackingIntervalMillis()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->sessionTrackingIntervalMillis:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getShutdownTimeoutMillis()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/a6;->shutdownTimeoutMillis:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getSocketTagger()Lio/sentry/g1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->socketTagger:Lio/sentry/g1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSpanFactory()Lio/sentry/i1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->spanFactory:Lio/sentry/i1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSpotlightConnectionUrl()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->spotlightConnectionUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSslSocketFactory()Ljavax/net/ssl/SSLSocketFactory;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTags()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->tags:Ljava/util/Map;

    .line 2
    .line 3
    return-object v0
.end method

.method public getThreadChecker()Lio/sentry/util/thread/a;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->threadChecker:Lio/sentry/util/thread/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTracePropagationTargets()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->tracePropagationTargets:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    iget-object v0, p0, Lio/sentry/a6;->defaultTracePropagationTargets:Ljava/util/List;

    .line 6
    .line 7
    :cond_6
    return-object v0
.end method

.method public getTracesSampleRate()Ljava/lang/Double;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->tracesSampleRate:Ljava/lang/Double;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTracesSampler()Lio/sentry/z5;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getTransactionProfiler()Lio/sentry/k1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->transactionProfiler:Lio/sentry/k1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTransportFactory()Lio/sentry/l1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->transportFactory:Lio/sentry/l1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTransportGate()Lio/sentry/transport/h;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->transportGate:Lio/sentry/transport/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public getVersionDetector()Lio/sentry/m1;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->versionDetector:Lio/sentry/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getViewHierarchyExporters()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->viewHierarchyExporters:Ljava/util/List;

    .line 2
    .line 3
    return-object v0
.end method

.method public isAttachServerName()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->attachServerName:Z

    .line 2
    .line 3
    return v0
.end method

.method public isAttachStacktrace()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->attachStacktrace:Z

    .line 2
    .line 3
    return v0
.end method

.method public isAttachThreads()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->attachThreads:Z

    .line 2
    .line 3
    return v0
.end method

.method public isCaptureOpenTelemetryEvents()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->captureOpenTelemetryEvents:Z

    .line 2
    .line 3
    return v0
.end method

.method public isContinuousProfilingEnabled()Z
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profilesSampleRate:Ljava/lang/Double;

    .line 2
    .line 3
    if-nez v0, :cond_14

    .line 4
    .line 5
    iget-object v0, p0, Lio/sentry/a6;->profileSessionSampleRate:Ljava/lang/Double;

    .line 6
    .line 7
    if-eqz v0, :cond_14

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    const-wide/16 v2, 0x0

    .line 14
    .line 15
    cmpl-double v0, v0, v2

    .line 16
    .line 17
    if-lez v0, :cond_14

    .line 18
    .line 19
    const/4 v0, 0x1

    .line 20
    return v0

    .line 21
    :cond_14
    const/4 v0, 0x0

    .line 22
    return v0
.end method

.method public isDebug()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->debug:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableAppStartProfiling()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lio/sentry/a6;->isProfilingEnabled()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_c

    .line 6
    .line 7
    invoke-virtual {p0}, Lio/sentry/a6;->isContinuousProfilingEnabled()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_12

    .line 12
    .line 13
    :cond_c
    iget-boolean v0, p0, Lio/sentry/a6;->enableAppStartProfiling:Z

    .line 14
    .line 15
    if-eqz v0, :cond_12

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    return v0

    .line 19
    :cond_12
    const/4 v0, 0x0

    .line 20
    return v0
.end method

.method public isEnableAutoSessionTracking()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableAutoSessionTracking:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableBackpressureHandling()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableBackpressureHandling:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableDatabaseTransactionTracing()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableDatabaseTransactionTracing:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableDeduplication()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableDeduplication:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableEventSizeLimiting()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableEventSizeLimiting:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableExternalConfiguration()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableExternalConfiguration:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnablePrettySerializationOutput()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enablePrettySerializationOutput:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableScopePersistence()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableScopePersistence:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableScreenTracking()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableScreenTracking:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableShutdownHook()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableShutdownHook:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableSpotlight()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableSpotlight:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableTimeToFullDisplayTracing()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableTimeToFullDisplayTracing:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableUncaughtExceptionHandler()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableUncaughtExceptionHandler:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableUserInteractionBreadcrumbs()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableUserInteractionBreadcrumbs:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnableUserInteractionTracing()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enableUserInteractionTracing:Z

    .line 2
    .line 3
    return v0
.end method

.method public isEnabled()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->enabled:Z

    .line 2
    .line 3
    return v0
.end method

.method public isForceInit()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->forceInit:Z

    .line 2
    .line 3
    return v0
.end method

.method public isGlobalHubMode()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->globalHubMode:Ljava/lang/Boolean;

    .line 2
    .line 3
    return-object v0
.end method

.method public isPrintUncaughtStackTrace()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->printUncaughtStackTrace:Z

    .line 2
    .line 3
    return v0
.end method

.method public isProfilingEnabled()Z
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->profilesSampleRate:Ljava/lang/Double;

    .line 2
    .line 3
    if-eqz v0, :cond_11

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    const-wide/16 v2, 0x0

    .line 10
    .line 11
    cmpl-double v0, v0, v2

    .line 12
    .line 13
    if-gtz v0, :cond_f

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :cond_f
    const/4 v0, 0x1

    .line 17
    return v0

    .line 18
    :cond_11
    :goto_11
    const/4 v0, 0x0

    .line 19
    return v0
.end method

.method public isPropagateTraceparent()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->propagateTraceparent:Z

    .line 2
    .line 3
    return v0
.end method

.method public isSendClientReports()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->sendClientReports:Z

    .line 2
    .line 3
    return v0
.end method

.method public isSendDefaultPii()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->sendDefaultPii:Z

    .line 2
    .line 3
    return v0
.end method

.method public isSendModules()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->sendModules:Z

    .line 2
    .line 3
    return v0
.end method

.method public isStartProfilerOnAppStart()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->startProfilerOnAppStart:Z

    .line 2
    .line 3
    return v0
.end method

.method public isTraceOptionsRequests()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->traceOptionsRequests:Z

    .line 2
    .line 3
    return v0
.end method

.method public isTraceSampling()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/a6;->traceSampling:Z

    .line 2
    .line 3
    return v0
.end method

.method public isTracingEnabled()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lio/sentry/a6;->getTracesSampleRate()Ljava/lang/Double;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-virtual {p0}, Lio/sentry/a6;->getTracesSampler()Lio/sentry/z5;

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    return v0

    .line 12
    :cond_b
    const/4 v0, 0x1

    .line 13
    return v0
.end method

.method public loadLazyFields()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lio/sentry/a6;->getSerializer()Lio/sentry/f1;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lio/sentry/a6;->retrieveParsedDsn()Lio/sentry/z;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lio/sentry/a6;->getEnvelopeReader()Lio/sentry/r0;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Lio/sentry/a6;->getDateProvider()Lio/sentry/m4;

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public merge(Lio/sentry/e0;)V
    .registers 6

    .line 1
    iget-object v0, p1, Lio/sentry/e0;->a:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setDsn(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    iget-object v0, p1, Lio/sentry/e0;->b:Ljava/lang/String;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnvironment(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object v0, p1, Lio/sentry/e0;->c:Ljava/lang/String;

    .line 16
    .line 17
    if-eqz v0, :cond_15

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setRelease(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_15
    iget-object v0, p1, Lio/sentry/e0;->d:Ljava/lang/String;

    .line 23
    .line 24
    if-eqz v0, :cond_1c

    .line 25
    .line 26
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setDist(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    :cond_1c
    iget-object v0, p1, Lio/sentry/e0;->e:Ljava/lang/String;

    .line 30
    .line 31
    if-eqz v0, :cond_23

    .line 32
    .line 33
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setServerName(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    iget-object v0, p1, Lio/sentry/e0;->m:Lio/sentry/x5;

    .line 37
    .line 38
    if-eqz v0, :cond_2a

    .line 39
    .line 40
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setProxy(Lio/sentry/x5;)V

    .line 41
    .line 42
    .line 43
    :cond_2a
    iget-object v0, p1, Lio/sentry/e0;->f:Ljava/lang/Boolean;

    .line 44
    .line 45
    if-eqz v0, :cond_35

    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnableUncaughtExceptionHandler(Z)V

    .line 52
    .line 53
    .line 54
    :cond_35
    iget-object v0, p1, Lio/sentry/e0;->v:Ljava/lang/Boolean;

    .line 55
    .line 56
    if-eqz v0, :cond_40

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setPrintUncaughtStackTrace(Z)V

    .line 63
    .line 64
    .line 65
    :cond_40
    iget-object v0, p1, Lio/sentry/e0;->i:Ljava/lang/Double;

    .line 66
    .line 67
    if-eqz v0, :cond_47

    .line 68
    .line 69
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setTracesSampleRate(Ljava/lang/Double;)V

    .line 70
    .line 71
    .line 72
    :cond_47
    iget-object v0, p1, Lio/sentry/e0;->j:Ljava/lang/Double;

    .line 73
    .line 74
    if-eqz v0, :cond_4e

    .line 75
    .line 76
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setProfilesSampleRate(Ljava/lang/Double;)V

    .line 77
    .line 78
    .line 79
    :cond_4e
    iget-object v0, p1, Lio/sentry/e0;->g:Ljava/lang/Boolean;

    .line 80
    .line 81
    if-eqz v0, :cond_59

    .line 82
    .line 83
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setDebug(Z)V

    .line 88
    .line 89
    .line 90
    :cond_59
    iget-object v0, p1, Lio/sentry/e0;->h:Ljava/lang/Boolean;

    .line 91
    .line 92
    if-eqz v0, :cond_64

    .line 93
    .line 94
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnableDeduplication(Z)V

    .line 99
    .line 100
    .line 101
    :cond_64
    iget-object v0, p1, Lio/sentry/e0;->w:Ljava/lang/Boolean;

    .line 102
    .line 103
    if-eqz v0, :cond_6f

    .line 104
    .line 105
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setSendClientReports(Z)V

    .line 110
    .line 111
    .line 112
    :cond_6f
    iget-object v0, p1, Lio/sentry/e0;->L:Ljava/lang/Boolean;

    .line 113
    .line 114
    if-eqz v0, :cond_7a

    .line 115
    .line 116
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setForceInit(Z)V

    .line 121
    .line 122
    .line 123
    :cond_7a
    new-instance v0, Ljava/util/HashMap;

    .line 124
    .line 125
    iget-object v1, p1, Lio/sentry/e0;->l:Ljava/util/concurrent/ConcurrentHashMap;

    .line 126
    .line 127
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    :goto_89
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    if-eqz v1, :cond_a7

    .line 143
    .line 144
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    check-cast v1, Ljava/util/Map$Entry;

    .line 149
    .line 150
    iget-object v2, p0, Lio/sentry/a6;->tags:Ljava/util/Map;

    .line 151
    .line 152
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v3

    .line 156
    check-cast v3, Ljava/lang/String;

    .line 157
    .line 158
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    check-cast v1, Ljava/lang/String;

    .line 163
    .line 164
    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    goto :goto_89

    .line 168
    :cond_a7
    new-instance v0, Ljava/util/ArrayList;

    .line 169
    .line 170
    iget-object v1, p1, Lio/sentry/e0;->o:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 171
    .line 172
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    :goto_b2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 180
    .line 181
    .line 182
    move-result v1

    .line 183
    if-eqz v1, :cond_c2

    .line 184
    .line 185
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    check-cast v1, Ljava/lang/String;

    .line 190
    .line 191
    invoke-virtual {p0, v1}, Lio/sentry/a6;->addInAppInclude(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    goto :goto_b2

    .line 195
    :cond_c2
    new-instance v0, Ljava/util/ArrayList;

    .line 196
    .line 197
    iget-object v1, p1, Lio/sentry/e0;->n:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 198
    .line 199
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    :goto_cd
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    if-eqz v1, :cond_dd

    .line 211
    .line 212
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    check-cast v1, Ljava/lang/String;

    .line 217
    .line 218
    invoke-virtual {p0, v1}, Lio/sentry/a6;->addInAppExclude(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    goto :goto_cd

    .line 222
    :cond_dd
    new-instance v0, Ljava/util/HashSet;

    .line 223
    .line 224
    iget-object v1, p1, Lio/sentry/e0;->t:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 225
    .line 226
    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    :goto_e8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 234
    .line 235
    .line 236
    move-result v1

    .line 237
    if-eqz v1, :cond_f8

    .line 238
    .line 239
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object v1

    .line 243
    check-cast v1, Ljava/lang/Class;

    .line 244
    .line 245
    invoke-virtual {p0, v1}, Lio/sentry/a6;->addIgnoredExceptionForType(Ljava/lang/Class;)V

    .line 246
    .line 247
    .line 248
    goto :goto_e8

    .line 249
    :cond_f8
    iget-object v0, p1, Lio/sentry/e0;->p:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 250
    .line 251
    if-eqz v0, :cond_106

    .line 252
    .line 253
    new-instance v0, Ljava/util/ArrayList;

    .line 254
    .line 255
    iget-object v1, p1, Lio/sentry/e0;->p:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 256
    .line 257
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 258
    .line 259
    .line 260
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setTracePropagationTargets(Ljava/util/List;)V

    .line 261
    .line 262
    .line 263
    :cond_106
    new-instance v0, Ljava/util/ArrayList;

    .line 264
    .line 265
    iget-object v1, p1, Lio/sentry/e0;->q:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 266
    .line 267
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    :goto_111
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 275
    .line 276
    .line 277
    move-result v1

    .line 278
    if-eqz v1, :cond_121

    .line 279
    .line 280
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v1

    .line 284
    check-cast v1, Ljava/lang/String;

    .line 285
    .line 286
    invoke-virtual {p0, v1}, Lio/sentry/a6;->addContextTag(Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    goto :goto_111

    .line 290
    :cond_121
    iget-object v0, p1, Lio/sentry/e0;->r:Ljava/lang/String;

    .line 291
    .line 292
    if-eqz v0, :cond_128

    .line 293
    .line 294
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setProguardUuid(Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    :cond_128
    iget-object v0, p1, Lio/sentry/e0;->s:Ljava/lang/Long;

    .line 298
    .line 299
    if-eqz v0, :cond_12f

    .line 300
    .line 301
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setIdleTimeout(Ljava/lang/Long;)V

    .line 302
    .line 303
    .line 304
    :cond_12f
    iget-object v0, p1, Lio/sentry/e0;->x:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 305
    .line 306
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    :goto_135
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 311
    .line 312
    .line 313
    move-result v1

    .line 314
    if-eqz v1, :cond_145

    .line 315
    .line 316
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object v1

    .line 320
    check-cast v1, Ljava/lang/String;

    .line 321
    .line 322
    invoke-virtual {p0, v1}, Lio/sentry/a6;->addBundleId(Ljava/lang/String;)V

    .line 323
    .line 324
    .line 325
    goto :goto_135

    .line 326
    :cond_145
    iget-object v0, p1, Lio/sentry/e0;->y:Ljava/lang/Boolean;

    .line 327
    .line 328
    if-eqz v0, :cond_150

    .line 329
    .line 330
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnabled(Z)V

    .line 335
    .line 336
    .line 337
    :cond_150
    iget-object v0, p1, Lio/sentry/e0;->z:Ljava/lang/Boolean;

    .line 338
    .line 339
    if-eqz v0, :cond_15b

    .line 340
    .line 341
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 342
    .line 343
    .line 344
    move-result v0

    .line 345
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnablePrettySerializationOutput(Z)V

    .line 346
    .line 347
    .line 348
    :cond_15b
    iget-object v0, p1, Lio/sentry/e0;->G:Ljava/lang/Boolean;

    .line 349
    .line 350
    if-eqz v0, :cond_166

    .line 351
    .line 352
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 353
    .line 354
    .line 355
    move-result v0

    .line 356
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setSendModules(Z)V

    .line 357
    .line 358
    .line 359
    :cond_166
    iget-object v0, p1, Lio/sentry/e0;->E:Ljava/util/List;

    .line 360
    .line 361
    if-eqz v0, :cond_174

    .line 362
    .line 363
    new-instance v0, Ljava/util/ArrayList;

    .line 364
    .line 365
    iget-object v1, p1, Lio/sentry/e0;->E:Ljava/util/List;

    .line 366
    .line 367
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 368
    .line 369
    .line 370
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setIgnoredCheckIns(Ljava/util/List;)V

    .line 371
    .line 372
    .line 373
    :cond_174
    iget-object v0, p1, Lio/sentry/e0;->F:Ljava/util/List;

    .line 374
    .line 375
    if-eqz v0, :cond_182

    .line 376
    .line 377
    new-instance v0, Ljava/util/ArrayList;

    .line 378
    .line 379
    iget-object v1, p1, Lio/sentry/e0;->F:Ljava/util/List;

    .line 380
    .line 381
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 382
    .line 383
    .line 384
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setIgnoredTransactions(Ljava/util/List;)V

    .line 385
    .line 386
    .line 387
    :cond_182
    iget-object v0, p1, Lio/sentry/e0;->u:Ljava/util/List;

    .line 388
    .line 389
    if-eqz v0, :cond_190

    .line 390
    .line 391
    new-instance v0, Ljava/util/ArrayList;

    .line 392
    .line 393
    iget-object v1, p1, Lio/sentry/e0;->u:Ljava/util/List;

    .line 394
    .line 395
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 396
    .line 397
    .line 398
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setIgnoredErrors(Ljava/util/List;)V

    .line 399
    .line 400
    .line 401
    :cond_190
    iget-object v0, p1, Lio/sentry/e0;->I:Ljava/lang/Boolean;

    .line 402
    .line 403
    if-eqz v0, :cond_19b

    .line 404
    .line 405
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 406
    .line 407
    .line 408
    move-result v0

    .line 409
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnableBackpressureHandling(Z)V

    .line 410
    .line 411
    .line 412
    :cond_19b
    iget-object v0, p1, Lio/sentry/e0;->J:Ljava/lang/Boolean;

    .line 413
    .line 414
    if-eqz v0, :cond_1a6

    .line 415
    .line 416
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 417
    .line 418
    .line 419
    move-result v0

    .line 420
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnableDatabaseTransactionTracing(Z)V

    .line 421
    .line 422
    .line 423
    :cond_1a6
    iget-object v0, p1, Lio/sentry/e0;->k:Lio/sentry/y5;

    .line 424
    .line 425
    if-eqz v0, :cond_1ad

    .line 426
    .line 427
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setMaxRequestBodySize(Lio/sentry/y5;)V

    .line 428
    .line 429
    .line 430
    :cond_1ad
    iget-object v0, p1, Lio/sentry/e0;->H:Ljava/lang/Boolean;

    .line 431
    .line 432
    if-eqz v0, :cond_1b8

    .line 433
    .line 434
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 435
    .line 436
    .line 437
    move-result v0

    .line 438
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setSendDefaultPii(Z)V

    .line 439
    .line 440
    .line 441
    :cond_1b8
    iget-object v0, p1, Lio/sentry/e0;->M:Ljava/lang/Boolean;

    .line 442
    .line 443
    if-eqz v0, :cond_1c3

    .line 444
    .line 445
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 446
    .line 447
    .line 448
    move-result v0

    .line 449
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setCaptureOpenTelemetryEvents(Z)V

    .line 450
    .line 451
    .line 452
    :cond_1c3
    iget-object v0, p1, Lio/sentry/e0;->A:Ljava/lang/Boolean;

    .line 453
    .line 454
    if-eqz v0, :cond_1ce

    .line 455
    .line 456
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 457
    .line 458
    .line 459
    move-result v0

    .line 460
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setEnableSpotlight(Z)V

    .line 461
    .line 462
    .line 463
    :cond_1ce
    iget-object v0, p1, Lio/sentry/e0;->D:Ljava/lang/String;

    .line 464
    .line 465
    if-eqz v0, :cond_1d5

    .line 466
    .line 467
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setSpotlightConnectionUrl(Ljava/lang/String;)V

    .line 468
    .line 469
    .line 470
    :cond_1d5
    iget-object v0, p1, Lio/sentry/e0;->K:Ljava/lang/Boolean;

    .line 471
    .line 472
    if-eqz v0, :cond_1dc

    .line 473
    .line 474
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setGlobalHubMode(Ljava/lang/Boolean;)V

    .line 475
    .line 476
    .line 477
    :cond_1dc
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 478
    .line 479
    if-eqz v0, :cond_23c

    .line 480
    .line 481
    invoke-virtual {p0}, Lio/sentry/a6;->getCron()Lio/sentry/q5;

    .line 482
    .line 483
    .line 484
    move-result-object v0

    .line 485
    if-nez v0, :cond_1ec

    .line 486
    .line 487
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 488
    .line 489
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setCron(Lio/sentry/q5;)V

    .line 490
    .line 491
    .line 492
    goto :goto_23c

    .line 493
    :cond_1ec
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 494
    .line 495
    iget-object v0, v0, Lio/sentry/q5;->a:Ljava/lang/Long;

    .line 496
    .line 497
    if-eqz v0, :cond_1fc

    .line 498
    .line 499
    invoke-virtual {p0}, Lio/sentry/a6;->getCron()Lio/sentry/q5;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    iget-object v1, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 504
    .line 505
    iget-object v1, v1, Lio/sentry/q5;->a:Ljava/lang/Long;

    .line 506
    .line 507
    iput-object v1, v0, Lio/sentry/q5;->a:Ljava/lang/Long;

    .line 508
    .line 509
    :cond_1fc
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 510
    .line 511
    iget-object v0, v0, Lio/sentry/q5;->b:Ljava/lang/Long;

    .line 512
    .line 513
    if-eqz v0, :cond_20c

    .line 514
    .line 515
    invoke-virtual {p0}, Lio/sentry/a6;->getCron()Lio/sentry/q5;

    .line 516
    .line 517
    .line 518
    move-result-object v0

    .line 519
    iget-object v1, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 520
    .line 521
    iget-object v1, v1, Lio/sentry/q5;->b:Ljava/lang/Long;

    .line 522
    .line 523
    iput-object v1, v0, Lio/sentry/q5;->b:Ljava/lang/Long;

    .line 524
    .line 525
    :cond_20c
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 526
    .line 527
    iget-object v0, v0, Lio/sentry/q5;->c:Ljava/lang/String;

    .line 528
    .line 529
    if-eqz v0, :cond_21c

    .line 530
    .line 531
    invoke-virtual {p0}, Lio/sentry/a6;->getCron()Lio/sentry/q5;

    .line 532
    .line 533
    .line 534
    move-result-object v0

    .line 535
    iget-object v1, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 536
    .line 537
    iget-object v1, v1, Lio/sentry/q5;->c:Ljava/lang/String;

    .line 538
    .line 539
    iput-object v1, v0, Lio/sentry/q5;->c:Ljava/lang/String;

    .line 540
    .line 541
    :cond_21c
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 542
    .line 543
    iget-object v0, v0, Lio/sentry/q5;->d:Ljava/lang/Long;

    .line 544
    .line 545
    if-eqz v0, :cond_22c

    .line 546
    .line 547
    invoke-virtual {p0}, Lio/sentry/a6;->getCron()Lio/sentry/q5;

    .line 548
    .line 549
    .line 550
    move-result-object v0

    .line 551
    iget-object v1, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 552
    .line 553
    iget-object v1, v1, Lio/sentry/q5;->d:Ljava/lang/Long;

    .line 554
    .line 555
    iput-object v1, v0, Lio/sentry/q5;->d:Ljava/lang/Long;

    .line 556
    .line 557
    :cond_22c
    iget-object v0, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 558
    .line 559
    iget-object v0, v0, Lio/sentry/q5;->e:Ljava/lang/Long;

    .line 560
    .line 561
    if-eqz v0, :cond_23c

    .line 562
    .line 563
    invoke-virtual {p0}, Lio/sentry/a6;->getCron()Lio/sentry/q5;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    iget-object v1, p1, Lio/sentry/e0;->Q:Lio/sentry/q5;

    .line 568
    .line 569
    iget-object v1, v1, Lio/sentry/q5;->e:Ljava/lang/Long;

    .line 570
    .line 571
    iput-object v1, v0, Lio/sentry/q5;->e:Ljava/lang/Long;

    .line 572
    .line 573
    :cond_23c
    :goto_23c
    iget-object v0, p1, Lio/sentry/e0;->B:Ljava/lang/Boolean;

    .line 574
    .line 575
    if-eqz v0, :cond_24c

    .line 576
    .line 577
    invoke-virtual {p0}, Lio/sentry/a6;->getLogs()Lio/sentry/s5;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    iget-object v1, p1, Lio/sentry/e0;->B:Ljava/lang/Boolean;

    .line 582
    .line 583
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 584
    .line 585
    .line 586
    move-result v1

    .line 587
    iput-boolean v1, v0, Lio/sentry/s5;->a:Z

    .line 588
    .line 589
    :cond_24c
    iget-object v0, p1, Lio/sentry/e0;->C:Ljava/lang/Boolean;

    .line 590
    .line 591
    if-eqz v0, :cond_25c

    .line 592
    .line 593
    invoke-virtual {p0}, Lio/sentry/a6;->getMetrics()Lio/sentry/t5;

    .line 594
    .line 595
    .line 596
    move-result-object v0

    .line 597
    iget-object v1, p1, Lio/sentry/e0;->C:Ljava/lang/Boolean;

    .line 598
    .line 599
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 600
    .line 601
    .line 602
    move-result v1

    .line 603
    iput-boolean v1, v0, Lio/sentry/t5;->a:Z

    .line 604
    .line 605
    :cond_25c
    iget-object v0, p1, Lio/sentry/e0;->N:Ljava/lang/Double;

    .line 606
    .line 607
    if-eqz v0, :cond_263

    .line 608
    .line 609
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setProfileSessionSampleRate(Ljava/lang/Double;)V

    .line 610
    .line 611
    .line 612
    :cond_263
    iget-object v0, p1, Lio/sentry/e0;->O:Ljava/lang/String;

    .line 613
    .line 614
    if-eqz v0, :cond_26a

    .line 615
    .line 616
    invoke-virtual {p0, v0}, Lio/sentry/a6;->setProfilingTracesDirPath(Ljava/lang/String;)V

    .line 617
    .line 618
    .line 619
    :cond_26a
    iget-object p1, p1, Lio/sentry/e0;->P:Lio/sentry/j3;

    .line 620
    .line 621
    if-eqz p1, :cond_271

    .line 622
    .line 623
    invoke-virtual {p0, p1}, Lio/sentry/a6;->setProfileLifecycle(Lio/sentry/j3;)V

    .line 624
    .line 625
    .line 626
    :cond_271
    return-void
.end method

.method public retrieveParsedDsn()Lio/sentry/z;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->parsedDsn:Lio/sentry/util/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lio/sentry/z;

    .line 8
    .line 9
    return-object v0
.end method

.method public setAttachServerName(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->attachServerName:Z

    .line 2
    .line 3
    return-void
.end method

.method public setAttachStacktrace(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->attachStacktrace:Z

    .line 2
    .line 3
    return-void
.end method

.method public setAttachThreads(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->attachThreads:Z

    .line 2
    .line 3
    return-void
.end method

.method public setBackpressureMonitor(Lio/sentry/backpressure/b;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->backpressureMonitor:Lio/sentry/backpressure/b;

    .line 2
    .line 3
    return-void
.end method

.method public setBeforeBreadcrumb(Lio/sentry/l5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->beforeBreadcrumb:Lio/sentry/l5;

    .line 2
    .line 3
    return-void
.end method

.method public setBeforeEnvelopeCallback(Lio/sentry/m5;)V
    .registers 2

    return-void
.end method

.method public setBeforeSend(Lio/sentry/n5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->beforeSend:Lio/sentry/n5;

    .line 2
    .line 3
    return-void
.end method

.method public setBeforeSendFeedback(Lio/sentry/n5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->beforeSendFeedback:Lio/sentry/n5;

    .line 2
    .line 3
    return-void
.end method

.method public setBeforeSendReplay(Lio/sentry/o5;)V
    .registers 2

    return-void
.end method

.method public setBeforeSendTransaction(Lio/sentry/p5;)V
    .registers 2

    return-void
.end method

.method public setCacheDirPath(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->cacheDirPath:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setCaptureOpenTelemetryEvents(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->captureOpenTelemetryEvents:Z

    .line 2
    .line 3
    return-void
.end method

.method public setCompositePerformanceCollector(Lio/sentry/l;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->compositePerformanceCollector:Lio/sentry/l;

    .line 2
    .line 3
    return-void
.end method

.method public setConnectionStatusProvider(Lio/sentry/o0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->connectionStatusProvider:Lio/sentry/o0;

    .line 2
    .line 3
    return-void
.end method

.method public setConnectionTimeoutMillis(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->connectionTimeoutMillis:I

    .line 2
    .line 3
    return-void
.end method

.method public setContinuousProfiler(Lio/sentry/p0;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->continuousProfiler:Lio/sentry/p0;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/i2;->d:Lio/sentry/i2;

    .line 4
    .line 5
    if-ne v0, v1, :cond_a

    .line 6
    .line 7
    if-eqz p1, :cond_a

    .line 8
    .line 9
    iput-object p1, p0, Lio/sentry/a6;->continuousProfiler:Lio/sentry/p0;

    .line 10
    .line 11
    :cond_a
    return-void
.end method

.method public setCron(Lio/sentry/q5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->cron:Lio/sentry/q5;

    .line 2
    .line 3
    return-void
.end method

.method public setDateProvider(Lio/sentry/m4;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->dateProvider:Lio/sentry/util/e;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lio/sentry/util/e;->c(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setDeadlineTimeout(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->deadlineTimeout:J

    .line 2
    .line 3
    return-void
.end method

.method public setDebug(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->debug:Z

    .line 2
    .line 3
    return-void
.end method

.method public setDebugMetaLoader(Lio/sentry/internal/debugmeta/a;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/internal/debugmeta/b;->d:Lio/sentry/internal/debugmeta/b;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->debugMetaLoader:Lio/sentry/internal/debugmeta/a;

    .line 7
    .line 8
    return-void
.end method

.method public setDefaultScopeType(Lio/sentry/x3;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->defaultScopeType:Lio/sentry/x3;

    .line 2
    .line 3
    return-void
.end method

.method public setDiagnosticLevel(Lio/sentry/a5;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/a6;->DEFAULT_DIAGNOSTIC_LEVEL:Lio/sentry/a5;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->diagnosticLevel:Lio/sentry/a5;

    .line 7
    .line 8
    return-void
.end method

.method public setDist(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->dist:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setDistinctId(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->distinctId:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setDistribution(Lio/sentry/r5;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_8

    .line 4
    :cond_3
    new-instance p1, Lio/sentry/r5;

    .line 5
    .line 6
    invoke-direct {p1}, Lio/sentry/r5;-><init>()V

    .line 7
    .line 8
    .line 9
    :goto_8
    iput-object p1, p0, Lio/sentry/a6;->distribution:Lio/sentry/r5;

    .line 10
    .line 11
    return-void
.end method

.method public setDistributionController(Lio/sentry/q0;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/j2;->d:Lio/sentry/j2;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->distributionController:Lio/sentry/q0;

    .line 7
    .line 8
    return-void
.end method

.method public setDsn(Ljava/lang/String;)V
    .registers 7

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->dsn:Ljava/lang/String;

    .line 2
    .line 3
    iget-object p1, p0, Lio/sentry/a6;->parsedDsn:Lio/sentry/util/e;

    .line 4
    .line 5
    invoke-virtual {p1}, Lio/sentry/util/e;->b()V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, Lio/sentry/a6;->dsn:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v0, p0, Lio/sentry/a6;->logger:Lio/sentry/ILogger;

    .line 11
    .line 12
    sget-object v1, Lio/sentry/util/l;->a:Ljava/nio/charset/Charset;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz p1, :cond_54

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_17

    .line 22
    .line 23
    goto :goto_54

    .line 24
    :cond_17
    :try_start_17
    const-string v2, "SHA-1"

    .line 25
    .line 26
    invoke-static {v2}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    sget-object v3, Lio/sentry/util/l;->a:Ljava/nio/charset/Charset;

    .line 31
    .line 32
    invoke-virtual {p1, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v2, v3}, Ljava/security/MessageDigest;->digest([B)[B

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    new-instance v3, Ljava/math/BigInteger;

    .line 41
    .line 42
    const/4 v4, 0x1

    .line 43
    invoke-direct {v3, v4, v2}, Ljava/math/BigInteger;-><init>(I[B)V

    .line 44
    .line 45
    .line 46
    new-instance v2, Ljava/lang/StringBuilder;

    .line 47
    .line 48
    const/16 v4, 0x10

    .line 49
    .line 50
    invoke-virtual {v3, v4}, Ljava/math/BigInteger;->toString(I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v1
    :try_end_3c
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_17 .. :try_end_3c} :catch_3f
    .catchall {:try_start_17 .. :try_end_3c} :catchall_3d

    .line 61
    goto :goto_54

    .line 62
    :catchall_3d
    move-exception v2

    .line 63
    goto :goto_41

    .line 64
    :catch_3f
    move-exception p1

    .line 65
    goto :goto_4d

    .line 66
    :goto_41
    sget-object v3, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 67
    .line 68
    const-string v4, "string: %s could not calculate its hash"

    .line 69
    .line 70
    filled-new-array {v2, p1}, [Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-interface {v0, v3, v4, p1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    goto :goto_54

    .line 78
    :goto_4d
    sget-object v2, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 79
    .line 80
    const-string v3, "SHA-1 isn\'t available to calculate the hash."

    .line 81
    .line 82
    invoke-interface {v0, v2, v3, p1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 83
    .line 84
    .line 85
    :cond_54
    :goto_54
    iput-object v1, p0, Lio/sentry/a6;->dsnHash:Ljava/lang/String;

    .line 86
    .line 87
    return-void
.end method

.method public setEnableAppStartProfiling(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableAppStartProfiling:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableAutoSessionTracking(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableAutoSessionTracking:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableBackpressureHandling(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableBackpressureHandling:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableDatabaseTransactionTracing(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableDatabaseTransactionTracing:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableDeduplication(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableDeduplication:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableEventSizeLimiting(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableEventSizeLimiting:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableExternalConfiguration(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableExternalConfiguration:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnablePrettySerializationOutput(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enablePrettySerializationOutput:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableScopePersistence(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableScopePersistence:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableScreenTracking(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableScreenTracking:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableShutdownHook(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableShutdownHook:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableSpotlight(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableSpotlight:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableTimeToFullDisplayTracing(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableTimeToFullDisplayTracing:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableUncaughtExceptionHandler(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableUncaughtExceptionHandler:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableUserInteractionBreadcrumbs(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableUserInteractionBreadcrumbs:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnableUserInteractionTracing(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enableUserInteractionTracing:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnabled(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->enabled:Z

    .line 2
    .line 3
    return-void
.end method

.method public setEnvelopeDiskCache(Lio/sentry/cache/d;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/transport/i;->d:Lio/sentry/transport/i;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->envelopeDiskCache:Lio/sentry/cache/d;

    .line 7
    .line 8
    return-void
.end method

.method public setEnvelopeReader(Lio/sentry/r0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->envelopeReader:Lio/sentry/util/e;

    .line 2
    .line 3
    if-eqz p1, :cond_5

    .line 4
    .line 5
    goto :goto_7

    .line 6
    :cond_5
    sget-object p1, Lio/sentry/k2;->a:Lio/sentry/k2;

    .line 7
    .line 8
    :goto_7
    invoke-virtual {v0, p1}, Lio/sentry/util/e;->c(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setEnvironment(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->environment:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setExecutorService(Lio/sentry/d1;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_4

    .line 2
    .line 3
    iput-object p1, p0, Lio/sentry/a6;->executorService:Lio/sentry/d1;

    .line 4
    .line 5
    :cond_4
    return-void
.end method

.method public setFatalLogger(Lio/sentry/ILogger;)V
    .registers 2

    .line 1
    if-nez p1, :cond_4

    .line 2
    .line 3
    sget-object p1, Lio/sentry/m2;->d:Lio/sentry/m2;

    .line 4
    .line 5
    :cond_4
    iput-object p1, p0, Lio/sentry/a6;->fatalLogger:Lio/sentry/ILogger;

    .line 6
    .line 7
    return-void
.end method

.method public setFeedbackOptions(Lio/sentry/v4;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->feedbackOptions:Lio/sentry/v4;

    .line 2
    .line 3
    return-void
.end method

.method public setFlushTimeoutMillis(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->flushTimeoutMillis:J

    .line 2
    .line 3
    return-void
.end method

.method public setForceInit(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->forceInit:Z

    .line 2
    .line 3
    return-void
.end method

.method public setFullyDisplayedReporter(Lio/sentry/g0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->fullyDisplayedReporter:Lio/sentry/g0;

    .line 2
    .line 3
    return-void
.end method

.method public setGestureTargetLocators(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/gestures/a;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->gestureTargetLocators:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a6;->gestureTargetLocators:Ljava/util/List;

    .line 7
    .line 8
    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setGlobalHubMode(Ljava/lang/Boolean;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->globalHubMode:Ljava/lang/Boolean;

    .line 2
    .line 3
    return-void
.end method

.method public setIdleTimeout(Ljava/lang/Long;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->idleTimeout:Ljava/lang/Long;

    .line 2
    .line 3
    return-void
.end method

.method public setIgnoredCheckIns(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    if-nez p1, :cond_6

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    :cond_f
    :goto_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_2a

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-nez v2, :cond_f

    .line 33
    .line 34
    new-instance v2, Lio/sentry/f0;

    .line 35
    .line 36
    invoke-direct {v2, v1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    goto :goto_f

    .line 43
    :cond_2a
    iput-object v0, p0, Lio/sentry/a6;->ignoredCheckIns:Ljava/util/List;

    .line 44
    .line 45
    return-void
.end method

.method public setIgnoredErrors(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    if-nez p1, :cond_6

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    :cond_f
    :goto_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_2c

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v1, :cond_f

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-nez v2, :cond_f

    .line 35
    .line 36
    new-instance v2, Lio/sentry/f0;

    .line 37
    .line 38
    invoke-direct {v2, v1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    goto :goto_f

    .line 45
    :cond_2c
    iput-object v0, p0, Lio/sentry/a6;->ignoredErrors:Ljava/util/List;

    .line 46
    .line 47
    return-void
.end method

.method public setIgnoredSpanOrigins(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    if-nez p1, :cond_6

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    :cond_f
    :goto_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_2c

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v1, :cond_f

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-nez v2, :cond_f

    .line 35
    .line 36
    new-instance v2, Lio/sentry/f0;

    .line 37
    .line 38
    invoke-direct {v2, v1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    goto :goto_f

    .line 45
    :cond_2c
    iput-object v0, p0, Lio/sentry/a6;->ignoredSpanOrigins:Ljava/util/List;

    .line 46
    .line 47
    return-void
.end method

.method public setIgnoredTransactions(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    if-nez p1, :cond_6

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    :cond_f
    :goto_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_2c

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v1, :cond_f

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-nez v2, :cond_f

    .line 35
    .line 36
    new-instance v2, Lio/sentry/f0;

    .line 37
    .line 38
    invoke-direct {v2, v1}, Lio/sentry/f0;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    goto :goto_f

    .line 45
    :cond_2c
    iput-object v0, p0, Lio/sentry/a6;->ignoredTransactions:Ljava/util/List;

    .line 46
    .line 47
    return-void
.end method

.method public setInitPriority(Lio/sentry/n1;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->initPriority:Lio/sentry/n1;

    .line 2
    .line 3
    return-void
.end method

.method public setInstrumenter(Lio/sentry/o1;)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->instrumenter:Lio/sentry/o1;

    .line 2
    .line 3
    return-void
.end method

.method public setLogger(Lio/sentry/ILogger;)V
    .registers 3

    .line 1
    if-nez p1, :cond_5

    .line 2
    .line 3
    sget-object p1, Lio/sentry/m2;->d:Lio/sentry/m2;

    .line 4
    .line 5
    goto :goto_b

    .line 6
    :cond_5
    new-instance v0, Lk7/l;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, Lk7/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    move-object p1, v0

    .line 12
    :goto_b
    iput-object p1, p0, Lio/sentry/a6;->logger:Lio/sentry/ILogger;

    .line 13
    .line 14
    return-void
.end method

.method public setLogs(Lio/sentry/s5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->logs:Lio/sentry/s5;

    .line 2
    .line 3
    return-void
.end method

.method public setMaxAttachmentSize(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->maxAttachmentSize:J

    .line 2
    .line 3
    return-void
.end method

.method public setMaxBreadcrumbs(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->maxBreadcrumbs:I

    .line 2
    .line 3
    return-void
.end method

.method public setMaxCacheItems(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->maxCacheItems:I

    .line 2
    .line 3
    return-void
.end method

.method public setMaxDepth(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->maxDepth:I

    .line 2
    .line 3
    return-void
.end method

.method public setMaxFeatureFlags(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->maxFeatureFlags:I

    .line 2
    .line 3
    return-void
.end method

.method public setMaxQueueSize(I)V
    .registers 2

    .line 1
    if-lez p1, :cond_4

    .line 2
    .line 3
    iput p1, p0, Lio/sentry/a6;->maxQueueSize:I

    .line 4
    .line 5
    :cond_4
    return-void
.end method

.method public setMaxRequestBodySize(Lio/sentry/y5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->maxRequestBodySize:Lio/sentry/y5;

    .line 2
    .line 3
    return-void
.end method

.method public setMaxSpans(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->maxSpans:I

    .line 2
    .line 3
    return-void
.end method

.method public setMaxTraceFileSize(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->maxTraceFileSize:J

    .line 2
    .line 3
    return-void
.end method

.method public setMetrics(Lio/sentry/t5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->metrics:Lio/sentry/t5;

    .line 2
    .line 3
    return-void
.end method

.method public setModulesLoader(Lio/sentry/internal/modules/a;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/internal/modules/e;->a:Lio/sentry/internal/modules/e;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->modulesLoader:Lio/sentry/internal/modules/a;

    .line 7
    .line 8
    return-void
.end method

.method public setOnDiscard(Lio/sentry/u5;)V
    .registers 2

    return-void
.end method

.method public setOnOversizedEvent(Lio/sentry/v5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->onOversizedEvent:Lio/sentry/v5;

    .line 2
    .line 3
    return-void
.end method

.method public setOpenTelemetryMode(Lio/sentry/j5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->openTelemetryMode:Lio/sentry/j5;

    .line 2
    .line 3
    return-void
.end method

.method public setPrintUncaughtStackTrace(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->printUncaughtStackTrace:Z

    .line 2
    .line 3
    return-void
.end method

.method public setProfileLifecycle(Lio/sentry/j3;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->profileLifecycle:Lio/sentry/j3;

    .line 2
    .line 3
    sget-object v0, Lio/sentry/j3;->TRACE:Lio/sentry/j3;

    .line 4
    .line 5
    if-ne p1, v0, :cond_18

    .line 6
    .line 7
    invoke-virtual {p0}, Lio/sentry/a6;->isTracingEnabled()Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    if-nez p1, :cond_18

    .line 12
    .line 13
    iget-object p1, p0, Lio/sentry/a6;->logger:Lio/sentry/ILogger;

    .line 14
    .line 15
    sget-object v0, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    new-array v1, v1, [Ljava/lang/Object;

    .line 19
    .line 20
    const-string v2, "Profiling lifecycle is set to TRACE but tracing is disabled. Profiling will not be started automatically."

    .line 21
    .line 22
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    return-void
.end method

.method public setProfileSessionSampleRate(Ljava/lang/Double;)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v0}, Lsg/a;->L(Ljava/lang/Double;Z)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    iput-object p1, p0, Lio/sentry/a6;->profileSessionSampleRate:Ljava/lang/Double;

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v2, "The value "

    .line 16
    .line 17
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " is not valid. Use values between 0.0 and 1.0."

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v0
.end method

.method public setProfilerConverter(Lio/sentry/x0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->profilerConverter:Lio/sentry/x0;

    .line 2
    .line 3
    return-void
.end method

.method public setProfilesSampleRate(Ljava/lang/Double;)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v0}, Lsg/a;->L(Ljava/lang/Double;Z)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    iput-object p1, p0, Lio/sentry/a6;->profilesSampleRate:Ljava/lang/Double;

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v2, "The value "

    .line 16
    .line 17
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " is not valid. Use null to disable or values between 0.0 and 1.0."

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v0
.end method

.method public setProfilesSampler(Lio/sentry/w5;)V
    .registers 2

    return-void
.end method

.method public setProfilingTracesDirPath(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->profilingTracesDirPath:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setProfilingTracesHz(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->profilingTracesHz:I

    .line 2
    .line 3
    return-void
.end method

.method public setProguardUuid(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->proguardUuid:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setPropagateTraceparent(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->propagateTraceparent:Z

    .line 2
    .line 3
    return-void
.end method

.method public setProxy(Lio/sentry/x5;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->proxy:Lio/sentry/x5;

    .line 2
    .line 3
    return-void
.end method

.method public setReadTimeoutMillis(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/a6;->readTimeoutMillis:I

    .line 2
    .line 3
    return-void
.end method

.method public setRelease(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->release:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setReplayController(Lio/sentry/n3;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/j2;->e:Lio/sentry/j2;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->replayController:Lio/sentry/n3;

    .line 7
    .line 8
    return-void
.end method

.method public setRuntimeManager(Lio/sentry/util/runtime/b;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->runtimeManager:Lio/sentry/util/runtime/b;

    .line 2
    .line 3
    return-void
.end method

.method public setSampleRate(Ljava/lang/Double;)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v0}, Lsg/a;->L(Ljava/lang/Double;Z)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    iput-object p1, p0, Lio/sentry/a6;->sampleRate:Ljava/lang/Double;

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v2, "The value "

    .line 16
    .line 17
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " is not valid. Use null to disable or values >= 0.0 and <= 1.0."

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v0
.end method

.method public setSdkVersion(Lio/sentry/protocol/t;)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lio/sentry/a6;->getSessionReplay()Lio/sentry/e6;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lio/sentry/e6;->m:Lio/sentry/protocol/t;

    .line 6
    .line 7
    iget-object v1, p0, Lio/sentry/a6;->sdkVersion:Lio/sentry/protocol/t;

    .line 8
    .line 9
    if-eqz v1, :cond_18

    .line 10
    .line 11
    if-eqz v0, :cond_18

    .line 12
    .line 13
    invoke-virtual {v1, v0}, Lio/sentry/protocol/t;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_18

    .line 18
    .line 19
    invoke-virtual {p0}, Lio/sentry/a6;->getSessionReplay()Lio/sentry/e6;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object p1, v0, Lio/sentry/e6;->m:Lio/sentry/protocol/t;

    .line 24
    .line 25
    :cond_18
    iput-object p1, p0, Lio/sentry/a6;->sdkVersion:Lio/sentry/protocol/t;

    .line 26
    .line 27
    return-void
.end method

.method public setSendClientReports(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->sendClientReports:Z

    .line 2
    .line 3
    if-eqz p1, :cond_c

    .line 4
    .line 5
    new-instance p1, Lz5/u;

    .line 6
    .line 7
    invoke-direct {p1, p0}, Lz5/u;-><init>(Lio/sentry/a6;)V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, Lio/sentry/a6;->clientReportRecorder:Lio/sentry/clientreport/f;

    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    new-instance p1, Lin/s;

    .line 14
    .line 15
    const/16 v0, 0xa

    .line 16
    .line 17
    invoke-direct {p1, v0}, Lin/s;-><init>(I)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lio/sentry/a6;->clientReportRecorder:Lio/sentry/clientreport/f;

    .line 21
    .line 22
    return-void
.end method

.method public setSendDefaultPii(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->sendDefaultPii:Z

    .line 2
    .line 3
    return-void
.end method

.method public setSendModules(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->sendModules:Z

    .line 2
    .line 3
    return-void
.end method

.method public setSentryClientName(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->sentryClientName:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setSerializer(Lio/sentry/f1;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->serializer:Lio/sentry/util/e;

    .line 2
    .line 3
    if-eqz p1, :cond_5

    .line 4
    .line 5
    goto :goto_7

    .line 6
    :cond_5
    sget-object p1, Lio/sentry/v2;->a:Lio/sentry/v2;

    .line 7
    .line 8
    :goto_7
    invoke-virtual {v0, p1}, Lio/sentry/util/e;->c(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setServerName(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->serverName:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setSessionFlushTimeoutMillis(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->sessionFlushTimeoutMillis:J

    .line 2
    .line 3
    return-void
.end method

.method public setSessionReplay(Lio/sentry/e6;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->sessionReplay:Lio/sentry/e6;

    .line 2
    .line 3
    return-void
.end method

.method public setSessionTrackingIntervalMillis(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->sessionTrackingIntervalMillis:J

    .line 2
    .line 3
    return-void
.end method

.method public setShutdownTimeoutMillis(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/a6;->shutdownTimeoutMillis:J

    .line 2
    .line 3
    return-void
.end method

.method public setSocketTagger(Lio/sentry/g1;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/w2;->d:Lio/sentry/w2;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->socketTagger:Lio/sentry/g1;

    .line 7
    .line 8
    return-void
.end method

.method public setSpanFactory(Lio/sentry/i1;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->spanFactory:Lio/sentry/i1;

    .line 2
    .line 3
    return-void
.end method

.method public setSpotlightConnectionUrl(Ljava/lang/String;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->spotlightConnectionUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setSslSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    .line 2
    .line 3
    return-void
.end method

.method public setStartProfilerOnAppStart(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->startProfilerOnAppStart:Z

    .line 2
    .line 3
    return-void
.end method

.method public setTag(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    if-nez p2, :cond_b

    .line 5
    .line 6
    iget-object p2, p0, Lio/sentry/a6;->tags:Ljava/util/Map;

    .line 7
    .line 8
    invoke-interface {p2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    iget-object v0, p0, Lio/sentry/a6;->tags:Ljava/util/Map;

    .line 13
    .line 14
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public setThreadChecker(Lio/sentry/util/thread/a;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->threadChecker:Lio/sentry/util/thread/a;

    .line 2
    .line 3
    return-void
.end method

.method public setTraceOptionsRequests(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->traceOptionsRequests:Z

    .line 2
    .line 3
    return-void
.end method

.method public setTracePropagationTargets(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    if-nez p1, :cond_6

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lio/sentry/a6;->tracePropagationTargets:Ljava/util/List;

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    :cond_f
    :goto_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_25

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-nez v2, :cond_f

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    goto :goto_f

    .line 38
    :cond_25
    iput-object v0, p0, Lio/sentry/a6;->tracePropagationTargets:Ljava/util/List;

    .line 39
    .line 40
    return-void
.end method

.method public setTraceSampling(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iput-boolean p1, p0, Lio/sentry/a6;->traceSampling:Z

    .line 2
    .line 3
    return-void
.end method

.method public setTracesSampleRate(Ljava/lang/Double;)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v0}, Lsg/a;->L(Ljava/lang/Double;Z)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    iput-object p1, p0, Lio/sentry/a6;->tracesSampleRate:Ljava/lang/Double;

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 12
    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v2, "The value "

    .line 16
    .line 17
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " is not valid. Use null to disable or values between 0.0 and 1.0."

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v0
.end method

.method public setTracesSampler(Lio/sentry/z5;)V
    .registers 2

    return-void
.end method

.method public setTransactionProfiler(Lio/sentry/k1;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->transactionProfiler:Lio/sentry/k1;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/j2;->v:Lio/sentry/j2;

    .line 4
    .line 5
    if-ne v0, v1, :cond_a

    .line 6
    .line 7
    if-eqz p1, :cond_a

    .line 8
    .line 9
    iput-object p1, p0, Lio/sentry/a6;->transactionProfiler:Lio/sentry/k1;

    .line 10
    .line 11
    :cond_a
    return-void
.end method

.method public setTransportFactory(Lio/sentry/l1;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/a3;->d:Lio/sentry/a3;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->transportFactory:Lio/sentry/l1;

    .line 7
    .line 8
    return-void
.end method

.method public setTransportGate(Lio/sentry/transport/h;)V
    .registers 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    goto :goto_5

    .line 4
    :cond_3
    sget-object p1, Lio/sentry/transport/k;->d:Lio/sentry/transport/k;

    .line 5
    .line 6
    :goto_5
    iput-object p1, p0, Lio/sentry/a6;->transportGate:Lio/sentry/transport/h;

    .line 7
    .line 8
    return-void
.end method

.method public setVersionDetector(Lio/sentry/m1;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lio/sentry/a6;->versionDetector:Lio/sentry/m1;

    .line 2
    .line 3
    return-void
.end method

.method public setViewHierarchyExporters(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/a6;->viewHierarchyExporters:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/a6;->viewHierarchyExporters:Ljava/util/List;

    .line 7
    .line 8
    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 9
    .line 10
    .line 11
    return-void
.end method
