###### Class io.sentry.android.core.ScreenshotEventProcessor (io.sentry.android.core.ScreenshotEventProcessor)
.class public final Lio/sentry/android/core/ScreenshotEventProcessor;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/c0;


# instance fields
.field public final d:Lio/sentry/android/core/SentryAndroidOptions;

.field public final e:Lio/sentry/android/core/j0;

.field public final i:Lio/sentry/android/core/internal/util/g;


# direct methods
.method public constructor <init>(Lio/sentry/android/core/SentryAndroidOptions;Lio/sentry/android/core/j0;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "SentryAndroidOptions is required"

    .line 5
    .line 6
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lio/sentry/android/core/ScreenshotEventProcessor;->d:Lio/sentry/android/core/SentryAndroidOptions;

    .line 10
    .line 11
    iput-object p2, p0, Lio/sentry/android/core/ScreenshotEventProcessor;->e:Lio/sentry/android/core/j0;

    .line 12
    .line 13
    new-instance p2, Lio/sentry/android/core/internal/util/g;

    .line 14
    .line 15
    const-wide/16 v0, 0x7d0

    .line 16
    .line 17
    const/4 v2, 0x3

    .line 18
    invoke-direct {p2, v0, v1, v2}, Lio/sentry/android/core/internal/util/g;-><init>(JI)V

    .line 19
    .line 20
    .line 21
    iput-object p2, p0, Lio/sentry/android/core/ScreenshotEventProcessor;->i:Lio/sentry/android/core/internal/util/g;

    .line 22
    .line 23
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isAttachScreenshot()Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    if-eqz p1, :cond_21

    .line 28
    .line 29
    const-string p1, "Screenshot"

    .line 30
    .line 31
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    :cond_21
    return-void
.end method


# virtual methods
.method public final d(Lio/sentry/t4;Lio/sentry/h0;)Lio/sentry/t4;
    .registers 7

    .line 1
    invoke-virtual {p1}, Lio/sentry/t4;->g()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    goto :goto_66

    .line 8
    :cond_7
    iget-object v0, p0, Lio/sentry/android/core/ScreenshotEventProcessor;->d:Lio/sentry/android/core/SentryAndroidOptions;

    .line 9
    .line 10
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isAttachScreenshot()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-nez v1, :cond_1e

    .line 15
    .line 16
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    new-array v1, v1, [Ljava/lang/Object;

    .line 24
    .line 25
    const-string v2, "attachScreenshot is disabled."

    .line 26
    .line 27
    invoke-interface {p2, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object p1

    .line 31
    :cond_1e
    sget-object v1, Lio/sentry/android/core/l0;->e:Lio/sentry/android/core/l0;

    .line 32
    .line 33
    iget-object v1, v1, Lio/sentry/android/core/l0;->d:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Ljava/lang/ref/WeakReference;

    .line 36
    .line 37
    if-eqz v1, :cond_2d

    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    check-cast v1, Landroid/app/Activity;

    .line 44
    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    const/4 v1, 0x0

    .line 47
    :goto_2e
    if-eqz v1, :cond_66

    .line 48
    .line 49
    invoke-static {p2}, Lk80/l;->L(Lio/sentry/h0;)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_37

    .line 54
    .line 55
    goto :goto_66

    .line 56
    :cond_37
    iget-object v2, p0, Lio/sentry/android/core/ScreenshotEventProcessor;->i:Lio/sentry/android/core/internal/util/g;

    .line 57
    .line 58
    invoke-virtual {v2}, Lio/sentry/android/core/internal/util/g;->a()Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->getBeforeScreenshotCaptureCallback()Lio/sentry/android/core/g1;

    .line 63
    .line 64
    .line 65
    if-eqz v2, :cond_43

    .line 66
    .line 67
    goto :goto_66

    .line 68
    :cond_43
    invoke-virtual {v0}, Lio/sentry/a6;->getThreadChecker()Lio/sentry/util/thread/a;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    iget-object v3, p0, Lio/sentry/android/core/ScreenshotEventProcessor;->e:Lio/sentry/android/core/j0;

    .line 77
    .line 78
    invoke-static {v1, v2, v0, v3}, Lou/a;->a(Landroid/app/Activity;Lio/sentry/util/thread/a;Lio/sentry/ILogger;Lio/sentry/android/core/j0;)Landroid/graphics/Bitmap;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-nez v0, :cond_54

    .line 83
    .line 84
    goto :goto_66

    .line 85
    :cond_54
    new-instance v2, Lcom/google/firebase/messaging/h;

    .line 86
    .line 87
    const/4 v3, 0x7

    .line 88
    invoke-direct {v2, v3, p0, v0}, Lcom/google/firebase/messaging/h;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    new-instance v0, Lio/sentry/a;

    .line 92
    .line 93
    invoke-direct {v0, v2}, Lio/sentry/a;-><init>(Lcom/google/firebase/messaging/h;)V

    .line 94
    .line 95
    .line 96
    iput-object v0, p2, Lio/sentry/h0;->d:Lio/sentry/a;

    .line 97
    .line 98
    const-string v0, "android:activity"

    .line 99
    .line 100
    invoke-virtual {p2, v1, v0}, Lio/sentry/h0;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    :cond_66
    :goto_66
    return-object p1
.end method

.method public final g(Lio/sentry/protocol/e0;Lio/sentry/h0;)Lio/sentry/protocol/e0;
    .registers 3

    .line 1
    return-object p1
.end method
