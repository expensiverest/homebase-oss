###### Class io.sentry.android.core.SentryPerformanceProvider (io.sentry.android.core.SentryPerformanceProvider)
.class public final Lio/sentry/android/core/SentryPerformanceProvider;
.super Lio/sentry/android/core/q0;
.source "SourceFile"


# static fields
.field public static final w:J


# instance fields
.field public e:Landroid/app/Application;

.field public final i:Lio/sentry/ILogger;

.field public final v:Lio/sentry/android/core/j0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    sput-wide v0, Lio/sentry/android/core/SentryPerformanceProvider;->w:J

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 6
    invoke-direct {p0}, Lio/sentry/android/core/q0;-><init>()V

    .line 7
    new-instance v0, Lio/sentry/util/a;

    .line 8
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 9
    new-instance v0, Lio/sentry/android/core/l0;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lio/sentry/android/core/l0;-><init>(I)V

    iput-object v0, p0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 10
    new-instance v1, Lio/sentry/android/core/j0;

    invoke-direct {v1, v0}, Lio/sentry/android/core/j0;-><init>(Lio/sentry/ILogger;)V

    iput-object v1, p0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    return-void
.end method

.method public constructor <init>(Lio/sentry/ILogger;Lio/sentry/android/core/j0;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/q0;-><init>()V

    .line 2
    new-instance v0, Lio/sentry/util/a;

    .line 3
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 4
    iput-object p1, p0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 5
    iput-object p2, p0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Lio/sentry/g4;Lio/sentry/android/core/performance/g;)V
    .registers 14

    .line 1
    iget-boolean v0, p2, Lio/sentry/g4;->K:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 5
    .line 6
    if-nez v0, :cond_11

    .line 7
    .line 8
    sget-object p1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 9
    .line 10
    const-string p2, "App start profiling was not sampled. It will not start."

    .line 11
    .line 12
    new-array p3, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-interface {v2, p1, p2, p3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_11
    new-instance v3, Lio/sentry/android/core/g;

    .line 19
    .line 20
    new-instance v5, Lio/sentry/android/core/internal/util/n;

    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    iget-object v0, p0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    .line 27
    .line 28
    invoke-direct {v5, p1, v2, v0}, Lio/sentry/android/core/internal/util/n;-><init>(Landroid/content/Context;Lio/sentry/ILogger;Lio/sentry/android/core/j0;)V

    .line 29
    .line 30
    .line 31
    iget-object v7, p2, Lio/sentry/g4;->w:Ljava/lang/String;

    .line 32
    .line 33
    iget v8, p2, Lio/sentry/g4;->J:I

    .line 34
    .line 35
    new-instance v9, Lld/d;

    .line 36
    .line 37
    const/16 p1, 0xa

    .line 38
    .line 39
    const/4 v0, 0x0

    .line 40
    invoke-direct {v9, p1, v0}, Lld/d;-><init>(IB)V

    .line 41
    .line 42
    .line 43
    iget-object v4, p0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    .line 44
    .line 45
    iget-object v6, p0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 46
    .line 47
    invoke-direct/range {v3 .. v9}, Lio/sentry/android/core/g;-><init>(Lio/sentry/android/core/j0;Lio/sentry/android/core/internal/util/n;Lio/sentry/ILogger;Ljava/lang/String;ILio/sentry/d1;)V

    .line 48
    .line 49
    .line 50
    const/4 p1, 0x0

    .line 51
    iput-object p1, p3, Lio/sentry/android/core/performance/g;->K:Lio/sentry/android/core/u;

    .line 52
    .line 53
    iput-object v3, p3, Lio/sentry/android/core/performance/g;->L:Lio/sentry/android/core/g;

    .line 54
    .line 55
    sget-object p1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 56
    .line 57
    const-string p3, "App start continuous profiling started."

    .line 58
    .line 59
    new-array v0, v1, [Ljava/lang/Object;

    .line 60
    .line 61
    invoke-interface {v2, p1, p3, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    invoke-static {}, Lio/sentry/a6;->empty()Lio/sentry/a6;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    iget-boolean p3, p2, Lio/sentry/g4;->K:Z

    .line 69
    .line 70
    if-eqz p3, :cond_4a

    .line 71
    .line 72
    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    .line 73
    .line 74
    goto :goto_4c

    .line 75
    :cond_4a
    const-wide/16 v0, 0x0

    .line 76
    .line 77
    :goto_4c
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 78
    .line 79
    .line 80
    move-result-object p3

    .line 81
    invoke-virtual {p1, p3}, Lio/sentry/a6;->setProfileSessionSampleRate(Ljava/lang/Double;)V

    .line 82
    .line 83
    .line 84
    iget-object p2, p2, Lio/sentry/g4;->N:Lio/sentry/j3;

    .line 85
    .line 86
    new-instance p3, Lio/sentry/s6;

    .line 87
    .line 88
    invoke-direct {p3, p1}, Lio/sentry/s6;-><init>(Lio/sentry/a6;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v3, p2, p3}, Lio/sentry/android/core/g;->c(Lio/sentry/j3;Lio/sentry/s6;)V

    .line 92
    .line 93
    .line 94
    return-void
.end method

.method public final attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    .registers 5

    .line 1
    const-class v0, Lio/sentry/android/core/SentryPerformanceProvider;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_12

    .line 14
    .line 15
    invoke-super {p0, p1, p2}, Landroid/content/ContentProvider;->attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    const-string p2, "An applicationId is required to fulfill the manifest placeholder."

    .line 22
    .line 23
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1
.end method

.method public final b(Landroid/content/Context;Lio/sentry/g4;Lio/sentry/android/core/performance/g;)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    new-instance v3, Lf10/e;

    .line 8
    .line 9
    iget-boolean v9, v1, Lio/sentry/g4;->i:Z

    .line 10
    .line 11
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    iget-object v5, v1, Lio/sentry/g4;->v:Ljava/lang/Double;

    .line 16
    .line 17
    iget-boolean v6, v1, Lio/sentry/g4;->d:Z

    .line 18
    .line 19
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 20
    .line 21
    .line 22
    move-result-object v7

    .line 23
    iget-object v8, v1, Lio/sentry/g4;->e:Ljava/lang/Double;

    .line 24
    .line 25
    const/4 v6, 0x0

    .line 26
    invoke-direct/range {v3 .. v8}, Lf10/e;-><init>(Ljava/lang/Boolean;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/Boolean;Ljava/lang/Double;)V

    .line 27
    .line 28
    .line 29
    iput-object v3, v2, Lio/sentry/android/core/performance/g;->M:Lf10/e;

    .line 30
    .line 31
    iget-object v3, v3, Lf10/e;->w:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v3, Ljava/lang/Boolean;

    .line 34
    .line 35
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    const/4 v4, 0x0

    .line 40
    iget-object v5, v0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 41
    .line 42
    if-eqz v3, :cond_66

    .line 43
    .line 44
    if-nez v9, :cond_2e

    .line 45
    .line 46
    goto :goto_66

    .line 47
    :cond_2e
    new-instance v10, Lio/sentry/android/core/u;

    .line 48
    .line 49
    new-instance v13, Lio/sentry/android/core/internal/util/n;

    .line 50
    .line 51
    iget-object v3, v0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    .line 52
    .line 53
    move-object/from16 v11, p1

    .line 54
    .line 55
    invoke-direct {v13, v11, v5, v3}, Lio/sentry/android/core/internal/util/n;-><init>(Landroid/content/Context;Lio/sentry/ILogger;Lio/sentry/android/core/j0;)V

    .line 56
    .line 57
    .line 58
    iget-object v15, v1, Lio/sentry/g4;->w:Ljava/lang/String;

    .line 59
    .line 60
    iget-boolean v3, v1, Lio/sentry/g4;->x:Z

    .line 61
    .line 62
    iget v1, v1, Lio/sentry/g4;->J:I

    .line 63
    .line 64
    new-instance v6, Lld/d;

    .line 65
    .line 66
    const/16 v7, 0xa

    .line 67
    .line 68
    const/4 v8, 0x0

    .line 69
    invoke-direct {v6, v7, v8}, Lld/d;-><init>(IB)V

    .line 70
    .line 71
    .line 72
    iget-object v12, v0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    .line 73
    .line 74
    iget-object v14, v0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 75
    .line 76
    move/from16 v17, v1

    .line 77
    .line 78
    move/from16 v16, v3

    .line 79
    .line 80
    move-object/from16 v18, v6

    .line 81
    .line 82
    invoke-direct/range {v10 .. v18}, Lio/sentry/android/core/u;-><init>(Landroid/content/Context;Lio/sentry/android/core/j0;Lio/sentry/android/core/internal/util/n;Lio/sentry/ILogger;Ljava/lang/String;ZILio/sentry/d1;)V

    .line 83
    .line 84
    .line 85
    const/4 v1, 0x0

    .line 86
    iput-object v1, v2, Lio/sentry/android/core/performance/g;->L:Lio/sentry/android/core/g;

    .line 87
    .line 88
    iput-object v10, v2, Lio/sentry/android/core/performance/g;->K:Lio/sentry/android/core/u;

    .line 89
    .line 90
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 91
    .line 92
    const-string v2, "App start profiling started."

    .line 93
    .line 94
    new-array v3, v4, [Ljava/lang/Object;

    .line 95
    .line 96
    invoke-interface {v5, v1, v2, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v10}, Lio/sentry/android/core/u;->start()V

    .line 100
    .line 101
    .line 102
    return-void

    .line 103
    :cond_66
    :goto_66
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 104
    .line 105
    const-string v2, "App start profiling was not sampled. It will not start."

    .line 106
    .line 107
    new-array v3, v4, [Ljava/lang/Object;

    .line 108
    .line 109
    invoke-interface {v5, v1, v2, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    return-void
.end method

.method public final getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 2

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onCreate()Z
    .registers 10

    .line 1
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    iget-object v2, v0, Lio/sentry/android/core/performance/g;->w:Lio/sentry/android/core/performance/h;

    .line 10
    .line 11
    sget-wide v3, Lio/sentry/android/core/SentryPerformanceProvider;->w:J

    .line 12
    .line 13
    invoke-virtual {v2, v3, v4}, Lio/sentry/android/core/performance/h;->d(J)V

    .line 14
    .line 15
    .line 16
    iget-object v2, p0, Lio/sentry/android/core/SentryPerformanceProvider;->v:Lio/sentry/android/core/j0;

    .line 17
    .line 18
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget-object v2, v0, Lio/sentry/android/core/performance/g;->v:Lio/sentry/android/core/performance/h;

    .line 22
    .line 23
    invoke-static {}, Landroid/os/Process;->getStartUptimeMillis()J

    .line 24
    .line 25
    .line 26
    move-result-wide v3

    .line 27
    invoke-virtual {v2, v3, v4}, Lio/sentry/android/core/performance/h;->d(J)V

    .line 28
    .line 29
    .line 30
    instance-of v2, v1, Landroid/app/Application;

    .line 31
    .line 32
    if-eqz v2, :cond_25

    .line 33
    .line 34
    check-cast v1, Landroid/app/Application;

    .line 35
    .line 36
    iput-object v1, p0, Lio/sentry/android/core/SentryPerformanceProvider;->e:Landroid/app/Application;

    .line 37
    .line 38
    :cond_25
    iget-object v1, p0, Lio/sentry/android/core/SentryPerformanceProvider;->e:Landroid/app/Application;

    .line 39
    .line 40
    if-nez v1, :cond_2a

    .line 41
    .line 42
    goto :goto_2d

    .line 43
    :cond_2a
    invoke-virtual {v0, v1}, Lio/sentry/android/core/performance/g;->e(Landroid/app/Application;)V

    .line 44
    .line 45
    .line 46
    :goto_2d
    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    const/4 v2, 0x0

    .line 51
    iget-object v3, p0, Lio/sentry/android/core/SentryPerformanceProvider;->i:Lio/sentry/ILogger;

    .line 52
    .line 53
    if-nez v1, :cond_41

    .line 54
    .line 55
    sget-object v0, Lio/sentry/a5;->FATAL:Lio/sentry/a5;

    .line 56
    .line 57
    const-string v1, "App. Context from ContentProvider is null"

    .line 58
    .line 59
    new-array v2, v2, [Ljava/lang/Object;

    .line 60
    .line 61
    invoke-interface {v3, v0, v1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    goto/16 :goto_e8

    .line 65
    .line 66
    :cond_41
    invoke-static {}, Landroid/os/StrictMode;->getThreadPolicy()Landroid/os/StrictMode$ThreadPolicy;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    invoke-static {}, Landroid/os/StrictMode;->getVmPolicy()Landroid/os/StrictMode$VmPolicy;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    sget-object v6, Landroid/os/StrictMode$ThreadPolicy;->LAX:Landroid/os/StrictMode$ThreadPolicy;

    .line 75
    .line 76
    invoke-static {v6}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 77
    .line 78
    .line 79
    sget-object v6, Landroid/os/StrictMode$VmPolicy;->LAX:Landroid/os/StrictMode$VmPolicy;

    .line 80
    .line 81
    invoke-static {v6}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    .line 82
    .line 83
    .line 84
    :try_start_53
    new-instance v6, Ljava/io/File;

    .line 85
    .line 86
    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    const-string v8, "sentry"

    .line 91
    .line 92
    invoke-direct {v6, v7, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_5e
    .catchall {:try_start_53 .. :try_end_5e} :catchall_ea

    .line 93
    .line 94
    .line 95
    invoke-static {v4}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 96
    .line 97
    .line 98
    invoke-static {v5}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    .line 99
    .line 100
    .line 101
    new-instance v4, Ljava/io/File;

    .line 102
    .line 103
    const-string v5, "app_start_profiling_config"

    .line 104
    .line 105
    invoke-direct {v4, v6, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    .line 109
    .line 110
    .line 111
    move-result v5

    .line 112
    if-eqz v5, :cond_e8

    .line 113
    .line 114
    invoke-virtual {v4}, Ljava/io/File;->canRead()Z

    .line 115
    .line 116
    .line 117
    move-result v5

    .line 118
    if-nez v5, :cond_79

    .line 119
    .line 120
    goto/16 :goto_e8

    .line 121
    .line 122
    :cond_79
    :try_start_79
    new-instance v5, Ljava/io/BufferedReader;

    .line 123
    .line 124
    new-instance v6, Ljava/io/InputStreamReader;

    .line 125
    .line 126
    new-instance v7, Ljava/io/FileInputStream;

    .line 127
    .line 128
    invoke-direct {v7, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 129
    .line 130
    .line 131
    invoke-direct {v6, v7}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 132
    .line 133
    .line 134
    invoke-direct {v5, v6}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_88
    .catch Ljava/io/FileNotFoundException; {:try_start_79 .. :try_end_88} :catch_aa
    .catchall {:try_start_79 .. :try_end_88} :catchall_a8

    .line 135
    .line 136
    .line 137
    :try_start_88
    new-instance v4, Lio/sentry/c2;

    .line 138
    .line 139
    invoke-static {}, Lio/sentry/a6;->empty()Lio/sentry/a6;

    .line 140
    .line 141
    .line 142
    move-result-object v6

    .line 143
    invoke-direct {v4, v6}, Lio/sentry/c2;-><init>(Lio/sentry/a6;)V

    .line 144
    .line 145
    .line 146
    const-class v6, Lio/sentry/g4;

    .line 147
    .line 148
    invoke-virtual {v4, v5, v6}, Lio/sentry/c2;->c(Ljava/io/Reader;Ljava/lang/Class;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v4

    .line 152
    check-cast v4, Lio/sentry/g4;

    .line 153
    .line 154
    if-nez v4, :cond_ae

    .line 155
    .line 156
    sget-object v0, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 157
    .line 158
    const-string v1, "Unable to deserialize the SentryAppStartProfilingOptions. App start profiling will not start."

    .line 159
    .line 160
    new-array v2, v2, [Ljava/lang/Object;

    .line 161
    .line 162
    invoke-interface {v3, v0, v1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_a4
    .catchall {:try_start_88 .. :try_end_a4} :catchall_ac

    .line 163
    .line 164
    .line 165
    :cond_a4
    :goto_a4
    :try_start_a4
    invoke-virtual {v5}, Ljava/io/Reader;->close()V
    :try_end_a7
    .catch Ljava/io/FileNotFoundException; {:try_start_a4 .. :try_end_a7} :catch_aa
    .catchall {:try_start_a4 .. :try_end_a7} :catchall_a8

    .line 166
    .line 167
    .line 168
    goto :goto_e8

    .line 169
    :catchall_a8
    move-exception v0

    .line 170
    goto :goto_d9

    .line 171
    :catch_aa
    move-exception v0

    .line 172
    goto :goto_e1

    .line 173
    :catchall_ac
    move-exception v0

    .line 174
    goto :goto_d0

    .line 175
    :cond_ae
    :try_start_ae
    iget-boolean v6, v4, Lio/sentry/g4;->y:Z

    .line 176
    .line 177
    if-eqz v6, :cond_ba

    .line 178
    .line 179
    iget-boolean v6, v4, Lio/sentry/g4;->M:Z

    .line 180
    .line 181
    if-eqz v6, :cond_ba

    .line 182
    .line 183
    invoke-virtual {p0, v1, v4, v0}, Lio/sentry/android/core/SentryPerformanceProvider;->a(Landroid/content/Context;Lio/sentry/g4;Lio/sentry/android/core/performance/g;)V

    .line 184
    .line 185
    .line 186
    goto :goto_a4

    .line 187
    :cond_ba
    iget-boolean v6, v4, Lio/sentry/g4;->x:Z

    .line 188
    .line 189
    if-nez v6, :cond_c8

    .line 190
    .line 191
    sget-object v0, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 192
    .line 193
    const-string v1, "Profiling is not enabled. App start profiling will not start."

    .line 194
    .line 195
    new-array v2, v2, [Ljava/lang/Object;

    .line 196
    .line 197
    invoke-interface {v3, v0, v1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    goto :goto_a4

    .line 201
    :cond_c8
    iget-boolean v2, v4, Lio/sentry/g4;->L:Z

    .line 202
    .line 203
    if-eqz v2, :cond_a4

    .line 204
    .line 205
    invoke-virtual {p0, v1, v4, v0}, Lio/sentry/android/core/SentryPerformanceProvider;->b(Landroid/content/Context;Lio/sentry/g4;Lio/sentry/android/core/performance/g;)V
    :try_end_cf
    .catchall {:try_start_ae .. :try_end_cf} :catchall_ac

    .line 206
    .line 207
    .line 208
    goto :goto_a4

    .line 209
    :goto_d0
    :try_start_d0
    invoke-virtual {v5}, Ljava/io/Reader;->close()V
    :try_end_d3
    .catchall {:try_start_d0 .. :try_end_d3} :catchall_d4

    .line 210
    .line 211
    .line 212
    goto :goto_d8

    .line 213
    :catchall_d4
    move-exception v1

    .line 214
    :try_start_d5
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 215
    .line 216
    .line 217
    :goto_d8
    throw v0
    :try_end_d9
    .catch Ljava/io/FileNotFoundException; {:try_start_d5 .. :try_end_d9} :catch_aa
    .catchall {:try_start_d5 .. :try_end_d9} :catchall_a8

    .line 218
    :goto_d9
    sget-object v1, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 219
    .line 220
    const-string v2, "Error reading app start profiling config file. "

    .line 221
    .line 222
    invoke-interface {v3, v1, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 223
    .line 224
    .line 225
    goto :goto_e8

    .line 226
    :goto_e1
    sget-object v1, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 227
    .line 228
    const-string v2, "App start profiling config file not found. "

    .line 229
    .line 230
    invoke-interface {v3, v1, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 231
    .line 232
    .line 233
    :cond_e8
    :goto_e8
    const/4 v0, 0x1

    .line 234
    return v0

    .line 235
    :catchall_ea
    move-exception v0

    .line 236
    invoke-static {v4}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 237
    .line 238
    .line 239
    invoke-static {v5}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    .line 240
    .line 241
    .line 242
    throw v0
.end method

.method public final shutdown()V
    .registers 4

    .line 1
    sget-object v0, Lio/sentry/android/core/performance/g;->T:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iget-object v1, v1, Lio/sentry/android/core/performance/g;->K:Lio/sentry/android/core/u;

    .line 12
    .line 13
    if-eqz v1, :cond_14

    .line 14
    .line 15
    invoke-virtual {v1}, Lio/sentry/android/core/u;->close()V

    .line 16
    .line 17
    .line 18
    goto :goto_14

    .line 19
    :catchall_12
    move-exception v1

    .line 20
    goto :goto_24

    .line 21
    :cond_14
    :goto_14
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iget-object v1, v1, Lio/sentry/android/core/performance/g;->L:Lio/sentry/android/core/g;

    .line 26
    .line 27
    if-eqz v1, :cond_20

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    invoke-virtual {v1, v2}, Lio/sentry/android/core/g;->a(Z)V
    :try_end_20
    .catchall {:try_start_6 .. :try_end_20} :catchall_12

    .line 31
    .line 32
    .line 33
    :cond_20
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :goto_24
    :try_start_24
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_27
    .catchall {:try_start_24 .. :try_end_27} :catchall_28

    .line 38
    .line 39
    .line 40
    goto :goto_2c

    .line 41
    :catchall_28
    move-exception v0

    .line 42
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 43
    .line 44
    .line 45
    :goto_2c
    throw v1
.end method
