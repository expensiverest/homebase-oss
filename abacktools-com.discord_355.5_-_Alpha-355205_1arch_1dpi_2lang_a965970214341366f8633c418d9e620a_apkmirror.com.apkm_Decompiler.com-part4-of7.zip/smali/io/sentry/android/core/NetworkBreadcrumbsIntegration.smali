###### Class io.sentry.android.core.NetworkBreadcrumbsIntegration (io.sentry.android.core.NetworkBreadcrumbsIntegration)
.class public final Lio/sentry/android/core/NetworkBreadcrumbsIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Ljava/io/Closeable;


# instance fields
.field public final d:Landroid/content/Context;

.field public final e:Lio/sentry/android/core/j0;

.field public final i:Lio/sentry/util/a;

.field public volatile v:Lio/sentry/android/core/b1;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lio/sentry/android/core/j0;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lio/sentry/util/a;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->i:Lio/sentry/util/a;

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_11

    .line 16
    .line 17
    move-object p1, v0

    .line 18
    :cond_11
    iput-object p1, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->d:Landroid/content/Context;

    .line 19
    .line 20
    iput-object p2, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->e:Lio/sentry/android/core/j0;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final close()V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->i:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    iget-object v1, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->v:Lio/sentry/android/core/b1;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    iput-object v2, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->v:Lio/sentry/android/core/b1;
    :try_end_b
    .catchall {:try_start_6 .. :try_end_b} :catchall_2a

    .line 11
    .line 12
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 13
    .line 14
    .line 15
    if-eqz v1, :cond_29

    .line 16
    .line 17
    sget-object v0, Lio/sentry/android/core/internal/util/c;->P:Lio/sentry/util/a;

    .line 18
    .line 19
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    :try_start_16
    sget-object v2, Lio/sentry/android/core/internal/util/c;->Q:Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_1b
    .catchall {:try_start_16 .. :try_end_1b} :catchall_1f

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :catchall_1f
    move-exception v1

    .line 33
    :try_start_20
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_23
    .catchall {:try_start_20 .. :try_end_23} :catchall_24

    .line 34
    .line 35
    .line 36
    goto :goto_28

    .line 37
    :catchall_24
    move-exception v0

    .line 38
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 39
    .line 40
    .line 41
    :goto_28
    throw v1

    .line 42
    :cond_29
    return-void

    .line 43
    :catchall_2a
    move-exception v1

    .line 44
    :try_start_2b
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_2f

    .line 45
    .line 46
    .line 47
    goto :goto_33

    .line 48
    :catchall_2f
    move-exception v0

    .line 49
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    :goto_33
    throw v1
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 8

    .line 1
    instance-of v0, p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lio/sentry/android/core/SentryAndroidOptions;

    .line 7
    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    const-string v1, "SentryAndroidOptions is required"

    .line 11
    .line 12
    invoke-static {v0, v1}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sget-object v2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 20
    .line 21
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableNetworkEventBreadcrumbs()Z

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    const-string v4, "NetworkBreadcrumbsIntegration enabled: %s"

    .line 34
    .line 35
    invoke-interface {v1, v2, v4, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableNetworkEventBreadcrumbs()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_7f

    .line 43
    .line 44
    iget-object v0, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->e:Lio/sentry/android/core/j0;

    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    iget-object v0, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->i:Lio/sentry/util/a;

    .line 50
    .line 51
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    :try_start_36
    new-instance v1, Lio/sentry/android/core/b1;

    .line 56
    .line 57
    iget-object v3, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->e:Lio/sentry/android/core/j0;

    .line 58
    .line 59
    invoke-virtual {p1}, Lio/sentry/a6;->getDateProvider()Lio/sentry/m4;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    invoke-direct {v1, v3, v4}, Lio/sentry/android/core/b1;-><init>(Lio/sentry/android/core/j0;Lio/sentry/m4;)V

    .line 64
    .line 65
    .line 66
    iput-object v1, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->v:Lio/sentry/android/core/b1;

    .line 67
    .line 68
    iget-object v1, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->d:Landroid/content/Context;

    .line 69
    .line 70
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    iget-object v4, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->e:Lio/sentry/android/core/j0;

    .line 75
    .line 76
    iget-object v5, p0, Lio/sentry/android/core/NetworkBreadcrumbsIntegration;->v:Lio/sentry/android/core/b1;

    .line 77
    .line 78
    invoke-static {v1, v3, v4, v5}, Lio/sentry/android/core/internal/util/c;->g(Landroid/content/Context;Lio/sentry/ILogger;Lio/sentry/android/core/j0;Landroid/net/ConnectivityManager$NetworkCallback;)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    const/4 v3, 0x0

    .line 83
    if-eqz v1, :cond_67

    .line 84
    .line 85
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    const-string v1, "NetworkBreadcrumbsIntegration installed."

    .line 90
    .line 91
    new-array v3, v3, [Ljava/lang/Object;

    .line 92
    .line 93
    invoke-interface {p1, v2, v1, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    const-string p1, "NetworkBreadcrumbs"

    .line 97
    .line 98
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    goto :goto_72

    .line 102
    :catchall_65
    move-exception p1

    .line 103
    goto :goto_76

    .line 104
    :cond_67
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    const-string v1, "NetworkBreadcrumbsIntegration not installed."

    .line 109
    .line 110
    new-array v3, v3, [Ljava/lang/Object;

    .line 111
    .line 112
    invoke-interface {p1, v2, v1, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_72
    .catchall {:try_start_36 .. :try_end_72} :catchall_65

    .line 113
    .line 114
    .line 115
    :goto_72
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :goto_76
    :try_start_76
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_79
    .catchall {:try_start_76 .. :try_end_79} :catchall_7a

    .line 120
    .line 121
    .line 122
    goto :goto_7e

    .line 123
    :catchall_7a
    move-exception v0

    .line 124
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 125
    .line 126
    .line 127
    :goto_7e
    throw p1

    .line 128
    :cond_7f
    return-void
.end method
