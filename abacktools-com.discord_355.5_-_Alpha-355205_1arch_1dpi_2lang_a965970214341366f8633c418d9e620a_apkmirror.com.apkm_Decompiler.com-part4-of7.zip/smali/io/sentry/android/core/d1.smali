###### Class io.sentry.android.core.d1 (io.sentry.android.core.d1)
.class public final synthetic Lio/sentry/android/core/d1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 1
    iput p1, p0, Lio/sentry/android/core/d1;->d:I

    iput-object p2, p0, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    iput-object p3, p0, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    iput-object p4, p0, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;Lio/sentry/a1;Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 5

    .line 2
    const/4 v0, 0x4

    iput v0, p0, Lio/sentry/android/core/d1;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    iput-object p2, p0, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    iput-object p3, p0, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Lio/sentry/android/core/d1;->d:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_226

    .line 6
    .line 7
    .line 8
    iget-object v0, v1, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;

    .line 11
    .line 12
    iget-object v2, v1, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Lio/sentry/a1;

    .line 15
    .line 16
    iget-object v3, v1, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v3, Lio/sentry/android/core/SentryAndroidOptions;

    .line 19
    .line 20
    iget-object v4, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->M:Lio/sentry/util/a;

    .line 21
    .line 22
    invoke-virtual {v4}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    :try_start_19
    iget-boolean v5, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->x:Z

    .line 27
    .line 28
    if-nez v5, :cond_a9

    .line 29
    .line 30
    iget-boolean v5, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->y:Z

    .line 31
    .line 32
    if-nez v5, :cond_a9

    .line 33
    .line 34
    iget-object v5, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->e:Lcom/google/android/gms/internal/fido/c2;

    .line 35
    .line 36
    if-eqz v5, :cond_27

    .line 37
    .line 38
    goto/16 :goto_a9

    .line 39
    .line 40
    :cond_27
    new-instance v5, Lcom/google/android/gms/internal/fido/c2;

    .line 41
    .line 42
    invoke-direct {v5, v0, v2, v3}, Lcom/google/android/gms/internal/fido/c2;-><init>(Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;Lio/sentry/a1;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 43
    .line 44
    .line 45
    iput-object v5, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->e:Lcom/google/android/gms/internal/fido/c2;

    .line 46
    .line 47
    iget-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->J:Landroid/content/IntentFilter;

    .line 48
    .line 49
    const/4 v5, 0x0

    .line 50
    if-nez v2, :cond_4d

    .line 51
    .line 52
    new-instance v2, Landroid/content/IntentFilter;

    .line 53
    .line 54
    invoke-direct {v2}, Landroid/content/IntentFilter;-><init>()V

    .line 55
    .line 56
    .line 57
    iput-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->J:Landroid/content/IntentFilter;

    .line 58
    .line 59
    iget-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->w:[Ljava/lang/String;

    .line 60
    .line 61
    array-length v6, v2

    .line 62
    move v7, v5

    .line 63
    :goto_3e
    if-ge v7, v6, :cond_4d

    .line 64
    .line 65
    aget-object v8, v2, v7

    .line 66
    .line 67
    iget-object v9, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->J:Landroid/content/IntentFilter;

    .line 68
    .line 69
    invoke-virtual {v9, v8}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    add-int/lit8 v7, v7, 0x1

    .line 73
    .line 74
    goto :goto_3e

    .line 75
    :catchall_4a
    move-exception v0

    .line 76
    move-object v2, v0

    .line 77
    goto :goto_ad

    .line 78
    :cond_4d
    iget-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 79
    .line 80
    if-nez v2, :cond_61

    .line 81
    .line 82
    new-instance v2, Landroid/os/HandlerThread;

    .line 83
    .line 84
    const-string v6, "SystemEventsReceiver"

    .line 85
    .line 86
    const/16 v7, 0xa

    .line 87
    .line 88
    invoke-direct {v2, v6, v7}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    .line 89
    .line 90
    .line 91
    iput-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 92
    .line 93
    iget-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 94
    .line 95
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V
    :try_end_61
    .catchall {:try_start_19 .. :try_end_61} :catchall_4a

    .line 96
    .line 97
    .line 98
    :cond_61
    :try_start_61
    new-instance v2, Landroid/os/Handler;

    .line 99
    .line 100
    iget-object v6, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 101
    .line 102
    invoke-virtual {v6}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    invoke-direct {v2, v6}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 107
    .line 108
    .line 109
    iget-object v6, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->d:Landroid/content/Context;

    .line 110
    .line 111
    iget-object v7, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->e:Lcom/google/android/gms/internal/fido/c2;

    .line 112
    .line 113
    iget-object v8, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->J:Landroid/content/IntentFilter;

    .line 114
    .line 115
    new-instance v9, Lio/sentry/android/core/j0;

    .line 116
    .line 117
    invoke-virtual {v3}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 118
    .line 119
    .line 120
    move-result-object v10

    .line 121
    invoke-direct {v9, v10}, Lio/sentry/android/core/j0;-><init>(Lio/sentry/ILogger;)V

    .line 122
    .line 123
    .line 124
    invoke-static {v6, v9, v7, v8, v2}, Lio/sentry/android/core/k0;->j(Landroid/content/Context;Lio/sentry/android/core/j0;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;)Landroid/content/Intent;

    .line 125
    .line 126
    .line 127
    iget-object v0, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->L:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 128
    .line 129
    const/4 v2, 0x1

    .line 130
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    if-nez v0, :cond_a9

    .line 135
    .line 136
    invoke-virtual {v3}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    sget-object v2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 141
    .line 142
    const-string v6, "SystemEventsBreadcrumbsIntegration installed."

    .line 143
    .line 144
    new-array v7, v5, [Ljava/lang/Object;

    .line 145
    .line 146
    invoke-interface {v0, v2, v6, v7}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    const-string v0, "SystemEventsBreadcrumbs"

    .line 150
    .line 151
    invoke-static {v0}, Loq/a;->d(Ljava/lang/String;)V
    :try_end_99
    .catchall {:try_start_61 .. :try_end_99} :catchall_9a

    .line 152
    .line 153
    .line 154
    goto :goto_a9

    .line 155
    :catchall_9a
    move-exception v0

    .line 156
    :try_start_9b
    invoke-virtual {v3, v5}, Lio/sentry/android/core/SentryAndroidOptions;->setEnableSystemEventBreadcrumbs(Z)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v3}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 164
    .line 165
    const-string v5, "Failed to initialize SystemEventsBreadcrumbsIntegration."

    .line 166
    .line 167
    invoke-interface {v2, v3, v5, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_a9
    .catchall {:try_start_9b .. :try_end_a9} :catchall_4a

    .line 168
    .line 169
    .line 170
    :cond_a9
    :goto_a9
    invoke-virtual {v4}, Lio/sentry/s;->close()V

    .line 171
    .line 172
    .line 173
    return-void

    .line 174
    :goto_ad
    :try_start_ad
    invoke-virtual {v4}, Lio/sentry/s;->close()V
    :try_end_b0
    .catchall {:try_start_ad .. :try_end_b0} :catchall_b1

    .line 175
    .line 176
    .line 177
    goto :goto_b5

    .line 178
    :catchall_b1
    move-exception v0

    .line 179
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 180
    .line 181
    .line 182
    :goto_b5
    throw v2

    .line 183
    :pswitch_b6
    iget-object v0, v1, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast v0, Lio/sentry/android/core/EnvelopeFileObserverIntegration;

    .line 186
    .line 187
    iget-object v2, v1, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    .line 188
    .line 189
    check-cast v2, Lio/sentry/a6;

    .line 190
    .line 191
    iget-object v3, v1, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v3, Ljava/lang/String;

    .line 194
    .line 195
    iget-object v4, v0, Lio/sentry/android/core/EnvelopeFileObserverIntegration;->v:Lio/sentry/util/a;

    .line 196
    .line 197
    invoke-virtual {v4}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 198
    .line 199
    .line 200
    move-result-object v4

    .line 201
    :try_start_c8
    iget-boolean v5, v0, Lio/sentry/android/core/EnvelopeFileObserverIntegration;->i:Z

    .line 202
    .line 203
    if-nez v5, :cond_d3

    .line 204
    .line 205
    invoke-virtual {v0, v2, v3}, Lio/sentry/android/core/EnvelopeFileObserverIntegration;->c(Lio/sentry/a6;Ljava/lang/String;)V
    :try_end_cf
    .catchall {:try_start_c8 .. :try_end_cf} :catchall_d0

    .line 206
    .line 207
    .line 208
    goto :goto_d3

    .line 209
    :catchall_d0
    move-exception v0

    .line 210
    move-object v2, v0

    .line 211
    goto :goto_d7

    .line 212
    :cond_d3
    :goto_d3
    invoke-virtual {v4}, Lio/sentry/s;->close()V

    .line 213
    .line 214
    .line 215
    return-void

    .line 216
    :goto_d7
    :try_start_d7
    invoke-virtual {v4}, Lio/sentry/s;->close()V
    :try_end_da
    .catchall {:try_start_d7 .. :try_end_da} :catchall_db

    .line 217
    .line 218
    .line 219
    goto :goto_df

    .line 220
    :catchall_db
    move-exception v0

    .line 221
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 222
    .line 223
    .line 224
    :goto_df
    throw v2

    .line 225
    :pswitch_e0
    iget-object v0, v1, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v0, Lio/sentry/android/core/g;

    .line 228
    .line 229
    iget-object v2, v1, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    .line 230
    .line 231
    move-object v10, v2

    .line 232
    check-cast v10, Lio/sentry/a6;

    .line 233
    .line 234
    iget-object v2, v1, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast v2, Lio/sentry/a1;

    .line 237
    .line 238
    iget-object v11, v0, Lio/sentry/android/core/g;->O:Ljava/util/ArrayList;

    .line 239
    .line 240
    iget-object v3, v0, Lio/sentry/android/core/g;->R:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 241
    .line 242
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 243
    .line 244
    .line 245
    move-result v3

    .line 246
    if-eqz v3, :cond_f8

    .line 247
    .line 248
    goto :goto_157

    .line 249
    :cond_f8
    new-instance v12, Ljava/util/ArrayList;

    .line 250
    .line 251
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 252
    .line 253
    .line 254
    move-result v3

    .line 255
    invoke-direct {v12, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 256
    .line 257
    .line 258
    iget-object v0, v0, Lio/sentry/android/core/g;->Y:Lio/sentry/util/a;

    .line 259
    .line 260
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 261
    .line 262
    .line 263
    move-result-object v13

    .line 264
    :try_start_107
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    :goto_10b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    if-eqz v3, :cond_13d

    .line 273
    .line 274
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object v3

    .line 278
    check-cast v3, Lio/sentry/g3;

    .line 279
    .line 280
    new-instance v4, Lio/sentry/h3;

    .line 281
    .line 282
    move-object v5, v4

    .line 283
    iget-object v4, v3, Lio/sentry/g3;->a:Lio/sentry/protocol/v;

    .line 284
    .line 285
    move-object v6, v5

    .line 286
    iget-object v5, v3, Lio/sentry/g3;->b:Lio/sentry/protocol/v;

    .line 287
    .line 288
    move-object v7, v6

    .line 289
    iget-object v6, v3, Lio/sentry/g3;->d:Ljava/io/File;

    .line 290
    .line 291
    move-object v8, v7

    .line 292
    iget-object v7, v3, Lio/sentry/g3;->c:Ljava/util/concurrent/ConcurrentHashMap;

    .line 293
    .line 294
    iget-wide v14, v3, Lio/sentry/g3;->e:D

    .line 295
    .line 296
    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 297
    .line 298
    .line 299
    move-result-object v9

    .line 300
    iget-object v3, v3, Lio/sentry/g3;->f:Ljava/lang/String;

    .line 301
    .line 302
    move-object/from16 v16, v9

    .line 303
    .line 304
    move-object v9, v3

    .line 305
    move-object v3, v8

    .line 306
    move-object/from16 v8, v16

    .line 307
    .line 308
    invoke-direct/range {v3 .. v10}, Lio/sentry/h3;-><init>(Lio/sentry/protocol/v;Lio/sentry/protocol/v;Ljava/io/File;Ljava/util/Map;Ljava/lang/Double;Ljava/lang/String;Lio/sentry/a6;)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {v12, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    goto :goto_10b

    .line 315
    :catchall_13a
    move-exception v0

    .line 316
    move-object v2, v0

    .line 317
    goto :goto_158

    .line 318
    :cond_13d
    invoke-virtual {v11}, Ljava/util/ArrayList;->clear()V
    :try_end_140
    .catchall {:try_start_107 .. :try_end_140} :catchall_13a

    .line 319
    .line 320
    .line 321
    invoke-virtual {v13}, Lio/sentry/s;->close()V

    .line 322
    .line 323
    .line 324
    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    :goto_147
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 329
    .line 330
    .line 331
    move-result v3

    .line 332
    if-eqz v3, :cond_157

    .line 333
    .line 334
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v3

    .line 338
    check-cast v3, Lio/sentry/h3;

    .line 339
    .line 340
    invoke-interface {v2, v3}, Lio/sentry/a1;->i(Lio/sentry/h3;)Lio/sentry/protocol/v;

    .line 341
    .line 342
    .line 343
    goto :goto_147

    .line 344
    :cond_157
    :goto_157
    return-void

    .line 345
    :goto_158
    :try_start_158
    invoke-virtual {v13}, Lio/sentry/s;->close()V
    :try_end_15b
    .catchall {:try_start_158 .. :try_end_15b} :catchall_15c

    .line 346
    .line 347
    .line 348
    goto :goto_160

    .line 349
    :catchall_15c
    move-exception v0

    .line 350
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 351
    .line 352
    .line 353
    :goto_160
    throw v2

    .line 354
    :pswitch_161
    iget-object v0, v1, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v0, Lp/r3;

    .line 357
    .line 358
    iget-object v2, v1, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    .line 359
    .line 360
    check-cast v2, Ljava/lang/Runnable;

    .line 361
    .line 362
    iget-object v3, v1, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v3, Ljava/lang/String;

    .line 365
    .line 366
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 367
    .line 368
    .line 369
    :try_start_170
    invoke-interface {v2}, Ljava/lang/Runnable;->run()V
    :try_end_173
    .catchall {:try_start_170 .. :try_end_173} :catchall_174

    .line 370
    .line 371
    .line 372
    goto :goto_18c

    .line 373
    :catchall_174
    if-eqz v3, :cond_18c

    .line 374
    .line 375
    iget-object v0, v0, Lp/r3;->i:Ljava/lang/Object;

    .line 376
    .line 377
    check-cast v0, Lio/sentry/android/core/SentryAndroidOptions;

    .line 378
    .line 379
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 380
    .line 381
    .line 382
    move-result-object v0

    .line 383
    sget-object v2, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 384
    .line 385
    const-string v4, "Failed to execute "

    .line 386
    .line 387
    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 388
    .line 389
    .line 390
    move-result-object v3

    .line 391
    const/4 v4, 0x0

    .line 392
    new-array v4, v4, [Ljava/lang/Object;

    .line 393
    .line 394
    invoke-interface {v0, v2, v3, v4}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 395
    .line 396
    .line 397
    :cond_18c
    :goto_18c
    return-void

    .line 398
    :pswitch_18d
    iget-object v0, v1, Lio/sentry/android/core/d1;->e:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;

    .line 401
    .line 402
    iget-object v2, v1, Lio/sentry/android/core/d1;->i:Ljava/lang/Object;

    .line 403
    .line 404
    check-cast v2, Lio/sentry/android/core/SentryAndroidOptions;

    .line 405
    .line 406
    iget-object v3, v1, Lio/sentry/android/core/d1;->v:Ljava/lang/Object;

    .line 407
    .line 408
    check-cast v3, Lio/sentry/a1;

    .line 409
    .line 410
    :try_start_199
    iget-object v4, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->K:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 411
    .line 412
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 413
    .line 414
    .line 415
    move-result v4

    .line 416
    const/4 v5, 0x0

    .line 417
    if-eqz v4, :cond_1b3

    .line 418
    .line 419
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 420
    .line 421
    .line 422
    move-result-object v0

    .line 423
    sget-object v3, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 424
    .line 425
    const-string v4, "SendCachedEnvelopeIntegration, not trying to send after closing."

    .line 426
    .line 427
    new-array v5, v5, [Ljava/lang/Object;

    .line 428
    .line 429
    invoke-interface {v0, v3, v4, v5}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 430
    .line 431
    .line 432
    goto/16 :goto_224

    .line 433
    .line 434
    :catchall_1b1
    move-exception v0

    .line 435
    goto :goto_219

    .line 436
    :cond_1b3
    iget-object v4, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->J:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 437
    .line 438
    const/4 v6, 0x1

    .line 439
    invoke-virtual {v4, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 440
    .line 441
    .line 442
    move-result v4

    .line 443
    if-nez v4, :cond_1cd

    .line 444
    .line 445
    invoke-virtual {v2}, Lio/sentry/a6;->getConnectionStatusProvider()Lio/sentry/o0;

    .line 446
    .line 447
    .line 448
    move-result-object v4

    .line 449
    iput-object v4, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->v:Lio/sentry/o0;

    .line 450
    .line 451
    invoke-interface {v4, v0}, Lio/sentry/o0;->S(Lio/sentry/n0;)Z

    .line 452
    .line 453
    .line 454
    iget-object v4, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->d:Lio/sentry/b4;

    .line 455
    .line 456
    invoke-interface {v4, v3, v2}, Lio/sentry/b4;->j(Lio/sentry/a1;Lio/sentry/a6;)Lcg/q;

    .line 457
    .line 458
    .line 459
    move-result-object v4

    .line 460
    iput-object v4, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->y:Lcg/q;

    .line 461
    .line 462
    :cond_1cd
    iget-object v4, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->v:Lio/sentry/o0;

    .line 463
    .line 464
    if-eqz v4, :cond_1e7

    .line 465
    .line 466
    invoke-interface {v4}, Lio/sentry/o0;->O()Lio/sentry/m0;

    .line 467
    .line 468
    .line 469
    move-result-object v4

    .line 470
    sget-object v6, Lio/sentry/m0;->DISCONNECTED:Lio/sentry/m0;

    .line 471
    .line 472
    if-ne v4, v6, :cond_1e7

    .line 473
    .line 474
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    sget-object v3, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 479
    .line 480
    const-string v4, "SendCachedEnvelopeIntegration, no connection."

    .line 481
    .line 482
    new-array v5, v5, [Ljava/lang/Object;

    .line 483
    .line 484
    invoke-interface {v0, v3, v4, v5}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 485
    .line 486
    .line 487
    goto :goto_224

    .line 488
    :cond_1e7
    invoke-interface {v3}, Lio/sentry/a1;->e()Lio/sentry/transport/p;

    .line 489
    .line 490
    .line 491
    move-result-object v3

    .line 492
    if-eqz v3, :cond_203

    .line 493
    .line 494
    sget-object v4, Lio/sentry/m;->All:Lio/sentry/m;

    .line 495
    .line 496
    invoke-virtual {v3, v4}, Lio/sentry/transport/p;->d(Lio/sentry/m;)Z

    .line 497
    .line 498
    .line 499
    move-result v3

    .line 500
    if-eqz v3, :cond_203

    .line 501
    .line 502
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 503
    .line 504
    .line 505
    move-result-object v0

    .line 506
    sget-object v3, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 507
    .line 508
    const-string v4, "SendCachedEnvelopeIntegration, rate limiting active."

    .line 509
    .line 510
    new-array v5, v5, [Ljava/lang/Object;

    .line 511
    .line 512
    invoke-interface {v0, v3, v4, v5}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 513
    .line 514
    .line 515
    goto :goto_224

    .line 516
    :cond_203
    iget-object v0, v0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->y:Lcg/q;

    .line 517
    .line 518
    if-nez v0, :cond_215

    .line 519
    .line 520
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 521
    .line 522
    .line 523
    move-result-object v0

    .line 524
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 525
    .line 526
    const-string v4, "SendCachedEnvelopeIntegration factory is null."

    .line 527
    .line 528
    new-array v5, v5, [Ljava/lang/Object;

    .line 529
    .line 530
    invoke-interface {v0, v3, v4, v5}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 531
    .line 532
    .line 533
    goto :goto_224

    .line 534
    :cond_215
    invoke-virtual {v0}, Lcg/q;->a()V
    :try_end_218
    .catchall {:try_start_199 .. :try_end_218} :catchall_1b1

    .line 535
    .line 536
    .line 537
    goto :goto_224

    .line 538
    :goto_219
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 539
    .line 540
    .line 541
    move-result-object v2

    .line 542
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 543
    .line 544
    const-string v4, "Failed trying to send cached events."

    .line 545
    .line 546
    invoke-interface {v2, v3, v4, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 547
    .line 548
    .line 549
    :goto_224
    return-void

    .line 550
    nop

    .line 551
    :pswitch_data_226
    .packed-switch 0x0
        :pswitch_18d
        :pswitch_161
        :pswitch_e0
        :pswitch_b6
    .end packed-switch
.end method
