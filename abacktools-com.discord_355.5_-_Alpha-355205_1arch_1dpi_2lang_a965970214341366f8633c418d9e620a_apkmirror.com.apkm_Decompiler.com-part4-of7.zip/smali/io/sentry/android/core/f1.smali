###### Class io.sentry.android.core.f1 (io.sentry.android.core.f1)
.class public final Lio/sentry/android/core/f1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/m4;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final now()Lio/sentry/l4;
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/i5;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/i5;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
