###### Class io.sentry.android.core.SendCachedEnvelopeIntegration (io.sentry.android.core.SendCachedEnvelopeIntegration)
.class final Lio/sentry/android/core/SendCachedEnvelopeIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Lio/sentry/n0;
.implements Ljava/io/Closeable;


# instance fields
.field public final J:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final K:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final L:Lio/sentry/util/a;

.field public final d:Lio/sentry/b4;

.field public final e:Lio/sentry/util/e;

.field public final i:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public v:Lio/sentry/o0;

.field public w:Lio/sentry/z3;

.field public x:Lio/sentry/android/core/SentryAndroidOptions;

.field public y:Lcg/q;


# direct methods
.method public constructor <init>(Lio/sentry/b4;Lio/sentry/util/e;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 11
    .line 12
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 13
    .line 14
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->J:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 18
    .line 19
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->K:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 25
    .line 26
    new-instance v0, Lio/sentry/util/a;

    .line 27
    .line 28
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->L:Lio/sentry/util/a;

    .line 32
    .line 33
    iput-object p1, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->d:Lio/sentry/b4;

    .line 34
    .line 35
    iput-object p2, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->e:Lio/sentry/util/e;

    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final c(Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 9

    .line 1
    :try_start_0
    iget-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->L:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0
    :try_end_6
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_6} :catch_65
    .catchall {:try_start_0 .. :try_end_6} :catchall_63

    .line 7
    :try_start_6
    invoke-virtual {p2}, Lio/sentry/a6;->getExecutorService()Lio/sentry/d1;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    new-instance v2, Lio/sentry/android/core/d1;

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    invoke-direct {v2, v3, p0, p2, p1}, Lio/sentry/android/core/d1;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-interface {v1, v2}, Lio/sentry/d1;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iget-object v1, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->e:Lio/sentry/util/e;

    .line 22
    .line 23
    invoke-virtual {v1}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    const/4 v2, 0x0

    .line 34
    if-eqz v1, :cond_52

    .line 35
    .line 36
    iget-object v1, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 37
    .line 38
    const/4 v3, 0x1

    .line 39
    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_52

    .line 44
    .line 45
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    sget-object v3, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 50
    .line 51
    const-string v4, "Startup Crash marker exists, blocking flush."

    .line 52
    .line 53
    new-array v5, v2, [Ljava/lang/Object;

    .line 54
    .line 55
    invoke-interface {v1, v3, v4, v5}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_39
    .catchall {:try_start_6 .. :try_end_39} :catchall_43

    .line 56
    .line 57
    .line 58
    :try_start_39
    invoke-virtual {p2}, Lio/sentry/android/core/SentryAndroidOptions;->getStartupCrashFlushTimeoutMillis()J

    .line 59
    .line 60
    .line 61
    move-result-wide v3

    .line 62
    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 63
    .line 64
    invoke-interface {p1, v3, v4, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    :try_end_42
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_39 .. :try_end_42} :catch_45
    .catchall {:try_start_39 .. :try_end_42} :catchall_43

    .line 65
    .line 66
    .line 67
    goto :goto_52

    .line 68
    :catchall_43
    move-exception p1

    .line 69
    goto :goto_67

    .line 70
    :catch_45
    :try_start_45
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 75
    .line 76
    const-string v3, "Synchronous send timed out, continuing in the background."

    .line 77
    .line 78
    new-array v4, v2, [Ljava/lang/Object;

    .line 79
    .line 80
    invoke-interface {p1, v1, v3, v4}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    :cond_52
    :goto_52
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 88
    .line 89
    const-string v3, "SendCachedEnvelopeIntegration installed."

    .line 90
    .line 91
    new-array v2, v2, [Ljava/lang/Object;

    .line 92
    .line 93
    invoke-interface {p1, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_5f
    .catchall {:try_start_45 .. :try_end_5f} :catchall_43

    .line 94
    .line 95
    .line 96
    :try_start_5f
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_62
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_5f .. :try_end_62} :catch_65
    .catchall {:try_start_5f .. :try_end_62} :catchall_63

    .line 97
    .line 98
    .line 99
    goto :goto_87

    .line 100
    :catchall_63
    move-exception p1

    .line 101
    goto :goto_70

    .line 102
    :catch_65
    move-exception p1

    .line 103
    goto :goto_7c

    .line 104
    :goto_67
    :try_start_67
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_6a
    .catchall {:try_start_67 .. :try_end_6a} :catchall_6b

    .line 105
    .line 106
    .line 107
    goto :goto_6f

    .line 108
    :catchall_6b
    move-exception v0

    .line 109
    :try_start_6c
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 110
    .line 111
    .line 112
    :goto_6f
    throw p1
    :try_end_70
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_6c .. :try_end_70} :catch_65
    .catchall {:try_start_6c .. :try_end_70} :catchall_63

    .line 113
    :goto_70
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 114
    .line 115
    .line 116
    move-result-object p2

    .line 117
    sget-object v0, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 118
    .line 119
    const-string v1, "Failed to call the executor. Cached events will not be sent"

    .line 120
    .line 121
    invoke-interface {p2, v0, v1, p1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 122
    .line 123
    .line 124
    goto :goto_87

    .line 125
    :goto_7c
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 126
    .line 127
    .line 128
    move-result-object p2

    .line 129
    sget-object v0, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 130
    .line 131
    const-string v1, "Failed to call the executor. Cached events will not be sent. Did you call Sentry.close()?"

    .line 132
    .line 133
    invoke-interface {p2, v0, v1, p1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 134
    .line 135
    .line 136
    :goto_87
    return-void
.end method

.method public final close()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->K:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->v:Lio/sentry/o0;

    .line 8
    .line 9
    if-eqz v0, :cond_d

    .line 10
    .line 11
    invoke-interface {v0, p0}, Lio/sentry/o0;->a0(Lio/sentry/n0;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

.method public final g(Lio/sentry/m0;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->w:Lio/sentry/z3;

    .line 2
    .line 3
    if-eqz v0, :cond_f

    .line 4
    .line 5
    iget-object v1, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->x:Lio/sentry/android/core/SentryAndroidOptions;

    .line 6
    .line 7
    if-eqz v1, :cond_f

    .line 8
    .line 9
    sget-object v2, Lio/sentry/m0;->DISCONNECTED:Lio/sentry/m0;

    .line 10
    .line 11
    if-eq p1, v2, :cond_f

    .line 12
    .line 13
    invoke-virtual {p0, v0, v1}, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->c(Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 14
    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 6

    .line 1
    sget-object v0, Lio/sentry/z3;->a:Lio/sentry/z3;

    .line 2
    .line 3
    iput-object v0, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->w:Lio/sentry/z3;

    .line 4
    .line 5
    instance-of v1, p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 6
    .line 7
    if-eqz v1, :cond_c

    .line 8
    .line 9
    move-object v1, p1

    .line 10
    check-cast v1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 11
    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 v1, 0x0

    .line 14
    :goto_d
    const-string v2, "SentryAndroidOptions is required"

    .line 15
    .line 16
    invoke-static {v1, v2}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iput-object v1, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->x:Lio/sentry/android/core/SentryAndroidOptions;

    .line 20
    .line 21
    invoke-virtual {p1}, Lio/sentry/a6;->getCacheDirPath()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    iget-object v3, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->d:Lio/sentry/b4;

    .line 30
    .line 31
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    invoke-static {v1, v2}, Lio/sentry/b4;->o(Ljava/lang/String;Lio/sentry/ILogger;)Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-nez v1, :cond_36

    .line 39
    .line 40
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    sget-object v0, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 45
    .line 46
    const/4 v1, 0x0

    .line 47
    new-array v1, v1, [Ljava/lang/Object;

    .line 48
    .line 49
    const-string v2, "No cache dir path is defined in options."

    .line 50
    .line 51
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_36
    const-string p1, "SendCachedEnvelope"

    .line 56
    .line 57
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    iget-object p1, p0, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->x:Lio/sentry/android/core/SentryAndroidOptions;

    .line 61
    .line 62
    invoke-virtual {p0, v0, p1}, Lio/sentry/android/core/SendCachedEnvelopeIntegration;->c(Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 63
    .line 64
    .line 65
    return-void
.end method
