###### Class io.sentry.android.core.g0 (io.sentry.android.core.g0)
.class public final Lio/sentry/android/core/g0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/c0;


# instance fields
.field public final d:Landroid/content/Context;

.field public final e:Lio/sentry/android/core/SentryAndroidOptions;

.field public final i:Lio/sentry/android/core/j0;

.field public final v:Lbu/i;

.field public final w:Lio/sentry/cache/g;

.field public final x:Ljava/util/List;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lio/sentry/android/core/j0;Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lio/sentry/android/core/f0;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Lio/sentry/android/core/f0;-><init>(Lio/sentry/android/core/g0;)V

    .line 7
    .line 8
    .line 9
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iput-object v0, p0, Lio/sentry/android/core/g0;->x:Ljava/util/List;

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-eqz v0, :cond_15

    .line 20
    .line 21
    move-object p1, v0

    .line 22
    :cond_15
    iput-object p1, p0, Lio/sentry/android/core/g0;->d:Landroid/content/Context;

    .line 23
    .line 24
    iput-object p3, p0, Lio/sentry/android/core/g0;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 25
    .line 26
    iput-object p2, p0, Lio/sentry/android/core/g0;->i:Lio/sentry/android/core/j0;

    .line 27
    .line 28
    invoke-virtual {p3}, Lio/sentry/a6;->findPersistingScopeObserver()Lio/sentry/cache/g;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Lio/sentry/android/core/g0;->w:Lio/sentry/cache/g;

    .line 33
    .line 34
    new-instance p1, Landroidx/core/view/d0;

    .line 35
    .line 36
    invoke-direct {p1, p3}, Landroidx/core/view/d0;-><init>(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    new-instance p2, Lbu/i;

    .line 40
    .line 41
    const/16 p3, 0x12

    .line 42
    .line 43
    invoke-direct {p2, p3, p1}, Lbu/i;-><init>(ILjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iput-object p2, p0, Lio/sentry/android/core/g0;->v:Lbu/i;

    .line 47
    .line 48
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/g0;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    :try_start_2
    invoke-virtual {v0}, Lio/sentry/a6;->getRuntimeManager()Lio/sentry/util/runtime/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    new-instance v2, Lapp/rive/runtime/kotlin/a;

    .line 8
    .line 9
    const/16 v3, 0x1c

    .line 10
    .line 11
    invoke-direct {v2, v3, p0}, Lapp/rive/runtime/kotlin/a;-><init>(ILjava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    invoke-interface {v1, v2}, Lio/sentry/util/runtime/b;->i(Lio/sentry/util/runtime/a;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    check-cast v1, Ljava/lang/String;
    :try_end_13
    .catchall {:try_start_2 .. :try_end_13} :catchall_14

    .line 19
    .line 20
    return-object v1

    .line 21
    :catchall_14
    move-exception v1

    .line 22
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sget-object v2, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 27
    .line 28
    const-string v3, "Error getting installationId."

    .line 29
    .line 30
    invoke-interface {v0, v2, v3, v1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 31
    .line 32
    .line 33
    const/4 v0, 0x0

    .line 34
    return-object v0
.end method

.method public final b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/g0;->w:Lio/sentry/cache/g;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    return-object p1

    .line 7
    :cond_6
    invoke-virtual {v0, p1, p2, p3}, Lio/sentry/cache/g;->p(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    return-object p1
.end method

.method public final d(Lio/sentry/t4;Lio/sentry/h0;)Lio/sentry/t4;
    .registers 30

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    const-string v0, "sentry:typeCheckHint"

    .line 6
    .line 7
    move-object/from16 v3, p2

    .line 8
    .line 9
    invoke-virtual {v3, v0}, Lio/sentry/h0;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    instance-of v3, v0, Lio/sentry/hints/b;

    .line 14
    .line 15
    const/4 v4, 0x0

    .line 16
    iget-object v5, v1, Lio/sentry/android/core/g0;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 17
    .line 18
    if-nez v3, :cond_21

    .line 19
    .line 20
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    sget-object v3, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 25
    .line 26
    const-string v5, "The event is not Backfillable, but has been passed to BackfillingEventProcessor, skipping."

    .line 27
    .line 28
    new-array v4, v4, [Ljava/lang/Object;

    .line 29
    .line 30
    invoke-interface {v0, v3, v5, v4}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    return-object v2

    .line 34
    :cond_21
    move-object v3, v0

    .line 35
    check-cast v3, Lio/sentry/hints/b;

    .line 36
    .line 37
    iget-object v6, v1, Lio/sentry/android/core/g0;->x:Ljava/util/List;

    .line 38
    .line 39
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 40
    .line 41
    .line 42
    move-result-object v6

    .line 43
    :cond_2a
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 44
    .line 45
    .line 46
    move-result v7

    .line 47
    if-eqz v7, :cond_3e

    .line 48
    .line 49
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v7

    .line 53
    check-cast v7, Lio/sentry/android/core/f0;

    .line 54
    .line 55
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    instance-of v9, v0, Lio/sentry/hints/a;

    .line 59
    .line 60
    if-eqz v9, :cond_2a

    .line 61
    .line 62
    goto :goto_3f

    .line 63
    :cond_3e
    const/4 v7, 0x0

    .line 64
    :goto_3f
    const-string v6, "anr_background"

    .line 65
    .line 66
    const/4 v9, 0x1

    .line 67
    if-eqz v7, :cond_e4

    .line 68
    .line 69
    instance-of v0, v3, Lio/sentry/hints/a;

    .line 70
    .line 71
    if-eqz v0, :cond_54

    .line 72
    .line 73
    move-object v0, v3

    .line 74
    check-cast v0, Lio/sentry/hints/a;

    .line 75
    .line 76
    invoke-interface {v0}, Lio/sentry/hints/a;->e()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    goto :goto_55

    .line 85
    :cond_54
    move v0, v4

    .line 86
    :goto_55
    iget-object v10, v7, Lio/sentry/android/core/f0;->a:Lio/sentry/android/core/g0;

    .line 87
    .line 88
    iget-object v11, v2, Lio/sentry/i4;->J:Ljava/lang/String;

    .line 89
    .line 90
    if-nez v11, :cond_5f

    .line 91
    .line 92
    const-string v11, "java"

    .line 93
    .line 94
    iput-object v11, v2, Lio/sentry/i4;->J:Ljava/lang/String;

    .line 95
    .line 96
    :cond_5f
    invoke-virtual {v2}, Lio/sentry/t4;->d()Ljava/util/ArrayList;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    if-eqz v11, :cond_67

    .line 101
    .line 102
    goto/16 :goto_e4

    .line 103
    .line 104
    :cond_67
    new-instance v11, Lio/sentry/protocol/m;

    .line 105
    .line 106
    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    .line 107
    .line 108
    .line 109
    invoke-interface {v3}, Lio/sentry/hints/b;->a()Z

    .line 110
    .line 111
    .line 112
    move-result v12

    .line 113
    if-nez v12, :cond_77

    .line 114
    .line 115
    const-string v12, "HistoricalAppExitInfo"

    .line 116
    .line 117
    iput-object v12, v11, Lio/sentry/protocol/m;->d:Ljava/lang/String;

    .line 118
    .line 119
    goto :goto_7b

    .line 120
    :cond_77
    const-string v12, "AppExitInfo"

    .line 121
    .line 122
    iput-object v12, v11, Lio/sentry/protocol/m;->d:Ljava/lang/String;

    .line 123
    .line 124
    :goto_7b
    if-eqz v0, :cond_80

    .line 125
    .line 126
    const-string v0, "Background ANR"

    .line 127
    .line 128
    goto :goto_82

    .line 129
    :cond_80
    const-string v0, "ANR"

    .line 130
    .line 131
    :goto_82
    new-instance v12, Lio/sentry/android/core/ApplicationNotResponding;

    .line 132
    .line 133
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 134
    .line 135
    .line 136
    move-result-object v13

    .line 137
    invoke-direct {v12, v0, v13}, Lio/sentry/android/core/ApplicationNotResponding;-><init>(Ljava/lang/String;Ljava/lang/Thread;)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v2}, Lio/sentry/t4;->e()Ljava/util/ArrayList;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    if-eqz v0, :cond_ae

    .line 145
    .line 146
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    :cond_95
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 151
    .line 152
    .line 153
    move-result v13

    .line 154
    if-eqz v13, :cond_ae

    .line 155
    .line 156
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v13

    .line 160
    check-cast v13, Lio/sentry/protocol/d0;

    .line 161
    .line 162
    iget-object v14, v13, Lio/sentry/protocol/d0;->i:Ljava/lang/String;

    .line 163
    .line 164
    if-eqz v14, :cond_95

    .line 165
    .line 166
    const-string v15, "main"

    .line 167
    .line 168
    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 169
    .line 170
    .line 171
    move-result v14

    .line 172
    if-eqz v14, :cond_95

    .line 173
    .line 174
    goto :goto_af

    .line 175
    :cond_ae
    const/4 v13, 0x0

    .line 176
    :goto_af
    if-nez v13, :cond_bd

    .line 177
    .line 178
    new-instance v13, Lio/sentry/protocol/d0;

    .line 179
    .line 180
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 181
    .line 182
    .line 183
    new-instance v0, Lio/sentry/protocol/b0;

    .line 184
    .line 185
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 186
    .line 187
    .line 188
    iput-object v0, v13, Lio/sentry/protocol/d0;->K:Lio/sentry/protocol/b0;

    .line 189
    .line 190
    :cond_bd
    iget-object v0, v10, Lio/sentry/android/core/g0;->v:Lbu/i;

    .line 191
    .line 192
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 193
    .line 194
    .line 195
    iget-object v0, v13, Lio/sentry/protocol/d0;->K:Lio/sentry/protocol/b0;

    .line 196
    .line 197
    if-nez v0, :cond_cc

    .line 198
    .line 199
    new-instance v0, Ljava/util/ArrayList;

    .line 200
    .line 201
    invoke-direct {v0, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 202
    .line 203
    .line 204
    goto :goto_dd

    .line 205
    :cond_cc
    new-instance v10, Ljava/util/ArrayList;

    .line 206
    .line 207
    invoke-direct {v10, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 208
    .line 209
    .line 210
    iget-object v13, v13, Lio/sentry/protocol/d0;->d:Ljava/lang/Long;

    .line 211
    .line 212
    iget-object v0, v0, Lio/sentry/protocol/b0;->d:Ljava/util/List;

    .line 213
    .line 214
    invoke-static {v12, v11, v13, v0, v9}, Lbu/i;->J(Ljava/lang/Throwable;Lio/sentry/protocol/m;Ljava/lang/Long;Ljava/util/List;Z)Lio/sentry/protocol/u;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    move-object v0, v10

    .line 222
    :goto_dd
    new-instance v10, Lg8/k;

    .line 223
    .line 224
    invoke-direct {v10, v0}, Lg8/k;-><init>(Ljava/util/List;)V

    .line 225
    .line 226
    .line 227
    iput-object v10, v2, Lio/sentry/t4;->V:Lg8/k;

    .line 228
    .line 229
    :cond_e4
    :goto_e4
    iget-object v10, v2, Lio/sentry/i4;->e:Lio/sentry/protocol/c;

    .line 230
    .line 231
    invoke-virtual {v10}, Lio/sentry/protocol/c;->g()Lio/sentry/protocol/o;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    iget-object v11, v1, Lio/sentry/android/core/g0;->d:Landroid/content/Context;

    .line 236
    .line 237
    invoke-static {v11, v5}, Lio/sentry/android/core/p0;->c(Landroid/content/Context;Lio/sentry/android/core/SentryAndroidOptions;)Lio/sentry/android/core/p0;

    .line 238
    .line 239
    .line 240
    move-result-object v12

    .line 241
    iget-object v12, v12, Lio/sentry/android/core/p0;->g:Lio/sentry/protocol/o;

    .line 242
    .line 243
    invoke-virtual {v10, v12}, Lio/sentry/protocol/c;->s(Lio/sentry/protocol/o;)V

    .line 244
    .line 245
    .line 246
    if-eqz v0, :cond_11f

    .line 247
    .line 248
    iget-object v12, v0, Lio/sentry/protocol/o;->d:Ljava/lang/String;

    .line 249
    .line 250
    if-eqz v12, :cond_11a

    .line 251
    .line 252
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    .line 253
    .line 254
    .line 255
    move-result v13

    .line 256
    if-nez v13, :cond_11a

    .line 257
    .line 258
    new-instance v13, Ljava/lang/StringBuilder;

    .line 259
    .line 260
    const-string v14, "os_"

    .line 261
    .line 262
    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object v12

    .line 269
    sget-object v14, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 270
    .line 271
    invoke-virtual {v12, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object v12

    .line 275
    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v12

    .line 282
    goto :goto_11c

    .line 283
    :cond_11a
    const-string v12, "os_1"

    .line 284
    .line 285
    :goto_11c
    invoke-virtual {v10, v0, v12}, Lio/sentry/protocol/c;->k(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    :cond_11f
    invoke-virtual {v10}, Lio/sentry/protocol/c;->e()Lio/sentry/protocol/f;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    iget-object v12, v1, Lio/sentry/android/core/g0;->i:Lio/sentry/android/core/j0;

    .line 293
    .line 294
    if-nez v0, :cond_1cd

    .line 295
    .line 296
    new-instance v13, Lio/sentry/protocol/f;

    .line 297
    .line 298
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 299
    .line 300
    .line 301
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 302
    .line 303
    iput-object v0, v13, Lio/sentry/protocol/f;->e:Ljava/lang/String;

    .line 304
    .line 305
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 306
    .line 307
    iput-object v0, v13, Lio/sentry/protocol/f;->i:Ljava/lang/String;

    .line 308
    .line 309
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    invoke-static {v0}, Lio/sentry/android/core/k0;->d(Lio/sentry/ILogger;)Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    iput-object v0, v13, Lio/sentry/protocol/f;->v:Ljava/lang/String;

    .line 318
    .line 319
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 320
    .line 321
    iput-object v0, v13, Lio/sentry/protocol/f;->w:Ljava/lang/String;

    .line 322
    .line 323
    sget-object v0, Landroid/os/Build;->ID:Ljava/lang/String;

    .line 324
    .line 325
    iput-object v0, v13, Lio/sentry/protocol/f;->x:Ljava/lang/String;

    .line 326
    .line 327
    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    .line 328
    .line 329
    iput-object v0, v13, Lio/sentry/protocol/f;->y:[Ljava/lang/String;

    .line 330
    .line 331
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    invoke-static {v11, v0}, Lio/sentry/android/core/k0;->e(Landroid/content/Context;Lio/sentry/ILogger;)Landroid/app/ActivityManager$MemoryInfo;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    if-eqz v0, :cond_15c

    .line 340
    .line 341
    iget-wide v14, v0, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    .line 342
    .line 343
    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 344
    .line 345
    .line 346
    move-result-object v0

    .line 347
    iput-object v0, v13, Lio/sentry/protocol/f;->O:Ljava/lang/Long;

    .line 348
    .line 349
    :cond_15c
    invoke-virtual {v12}, Lio/sentry/android/core/j0;->a()Ljava/lang/Boolean;

    .line 350
    .line 351
    .line 352
    move-result-object v0

    .line 353
    iput-object v0, v13, Lio/sentry/protocol/f;->N:Ljava/lang/Boolean;

    .line 354
    .line 355
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 356
    .line 357
    .line 358
    move-result-object v14

    .line 359
    :try_start_166
    invoke-virtual {v11}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 364
    .line 365
    .line 366
    move-result-object v0
    :try_end_16e
    .catchall {:try_start_166 .. :try_end_16e} :catchall_16f

    .line 367
    goto :goto_178

    .line 368
    :catchall_16f
    move-exception v0

    .line 369
    sget-object v15, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 370
    .line 371
    const-string v8, "Error getting DisplayMetrics."

    .line 372
    .line 373
    invoke-interface {v14, v15, v8, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 374
    .line 375
    .line 376
    const/4 v0, 0x0

    .line 377
    :goto_178
    if-eqz v0, :cond_19a

    .line 378
    .line 379
    iget v8, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 380
    .line 381
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 382
    .line 383
    .line 384
    move-result-object v8

    .line 385
    iput-object v8, v13, Lio/sentry/protocol/f;->W:Ljava/lang/Integer;

    .line 386
    .line 387
    iget v8, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 388
    .line 389
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 390
    .line 391
    .line 392
    move-result-object v8

    .line 393
    iput-object v8, v13, Lio/sentry/protocol/f;->X:Ljava/lang/Integer;

    .line 394
    .line 395
    iget v8, v0, Landroid/util/DisplayMetrics;->density:F

    .line 396
    .line 397
    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 398
    .line 399
    .line 400
    move-result-object v8

    .line 401
    iput-object v8, v13, Lio/sentry/protocol/f;->Y:Ljava/lang/Float;

    .line 402
    .line 403
    iget v0, v0, Landroid/util/DisplayMetrics;->densityDpi:I

    .line 404
    .line 405
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    iput-object v0, v13, Lio/sentry/protocol/f;->Z:Ljava/lang/Integer;

    .line 410
    .line 411
    :cond_19a
    iget-object v0, v13, Lio/sentry/protocol/f;->c0:Ljava/lang/String;

    .line 412
    .line 413
    if-nez v0, :cond_1a4

    .line 414
    .line 415
    invoke-virtual {v1}, Lio/sentry/android/core/g0;->a()Ljava/lang/String;

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    iput-object v0, v13, Lio/sentry/protocol/f;->c0:Ljava/lang/String;

    .line 420
    .line 421
    :cond_1a4
    sget-object v0, Lio/sentry/android/core/internal/util/f;->c:Lio/sentry/android/core/internal/util/f;

    .line 422
    .line 423
    invoke-virtual {v0}, Lio/sentry/android/core/internal/util/f;->a()Ljava/util/ArrayList;

    .line 424
    .line 425
    .line 426
    move-result-object v0

    .line 427
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 428
    .line 429
    .line 430
    move-result v8

    .line 431
    if-nez v8, :cond_1ca

    .line 432
    .line 433
    invoke-static {v0}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 434
    .line 435
    .line 436
    move-result-object v8

    .line 437
    check-cast v8, Ljava/lang/Integer;

    .line 438
    .line 439
    invoke-virtual {v8}, Ljava/lang/Integer;->doubleValue()D

    .line 440
    .line 441
    .line 442
    move-result-wide v14

    .line 443
    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 444
    .line 445
    .line 446
    move-result-object v8

    .line 447
    iput-object v8, v13, Lio/sentry/protocol/f;->h0:Ljava/lang/Double;

    .line 448
    .line 449
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 450
    .line 451
    .line 452
    move-result v0

    .line 453
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 454
    .line 455
    .line 456
    move-result-object v0

    .line 457
    iput-object v0, v13, Lio/sentry/protocol/f;->g0:Ljava/lang/Integer;

    .line 458
    .line 459
    :cond_1ca
    invoke-virtual {v10, v13}, Lio/sentry/protocol/c;->p(Lio/sentry/protocol/f;)V

    .line 460
    .line 461
    .line 462
    :cond_1cd
    invoke-interface {v3}, Lio/sentry/hints/b;->a()Z

    .line 463
    .line 464
    .line 465
    move-result v0

    .line 466
    if-nez v0, :cond_1e1

    .line 467
    .line 468
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 469
    .line 470
    .line 471
    move-result-object v0

    .line 472
    sget-object v3, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 473
    .line 474
    const-string v5, "The event is Backfillable, but should not be enriched, skipping."

    .line 475
    .line 476
    new-array v4, v4, [Ljava/lang/Object;

    .line 477
    .line 478
    invoke-interface {v0, v3, v5, v4}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 479
    .line 480
    .line 481
    return-object v2

    .line 482
    :cond_1e1
    iget-object v0, v2, Lio/sentry/i4;->v:Lio/sentry/protocol/p;

    .line 483
    .line 484
    if-nez v0, :cond_1f1

    .line 485
    .line 486
    const-string v0, "request.json"

    .line 487
    .line 488
    const-class v8, Lio/sentry/protocol/p;

    .line 489
    .line 490
    invoke-virtual {v1, v5, v0, v8}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object v0

    .line 494
    check-cast v0, Lio/sentry/protocol/p;

    .line 495
    .line 496
    iput-object v0, v2, Lio/sentry/i4;->v:Lio/sentry/protocol/p;

    .line 497
    .line 498
    :cond_1f1
    iget-object v0, v2, Lio/sentry/i4;->K:Lio/sentry/protocol/i0;

    .line 499
    .line 500
    if-nez v0, :cond_201

    .line 501
    .line 502
    const-string v0, "user.json"

    .line 503
    .line 504
    const-class v8, Lio/sentry/protocol/i0;

    .line 505
    .line 506
    invoke-virtual {v1, v5, v0, v8}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 507
    .line 508
    .line 509
    move-result-object v0

    .line 510
    check-cast v0, Lio/sentry/protocol/i0;

    .line 511
    .line 512
    iput-object v0, v2, Lio/sentry/i4;->K:Lio/sentry/protocol/i0;

    .line 513
    .line 514
    :cond_201
    const-string v8, "tags.json"

    .line 515
    .line 516
    const-class v13, Ljava/util/Map;

    .line 517
    .line 518
    invoke-virtual {v1, v5, v8, v13}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 519
    .line 520
    .line 521
    move-result-object v0

    .line 522
    check-cast v0, Ljava/util/Map;

    .line 523
    .line 524
    if-nez v0, :cond_20e

    .line 525
    .line 526
    goto :goto_250

    .line 527
    :cond_20e
    iget-object v14, v2, Lio/sentry/i4;->w:Ljava/util/AbstractMap;

    .line 528
    .line 529
    if-nez v14, :cond_21f

    .line 530
    .line 531
    new-instance v14, Ljava/util/HashMap;

    .line 532
    .line 533
    invoke-direct {v14, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 534
    .line 535
    .line 536
    new-instance v0, Ljava/util/HashMap;

    .line 537
    .line 538
    invoke-direct {v0, v14}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 539
    .line 540
    .line 541
    iput-object v0, v2, Lio/sentry/i4;->w:Ljava/util/AbstractMap;

    .line 542
    .line 543
    goto :goto_250

    .line 544
    :cond_21f
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 545
    .line 546
    .line 547
    move-result-object v0

    .line 548
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 549
    .line 550
    .line 551
    move-result-object v0

    .line 552
    :goto_227
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 553
    .line 554
    .line 555
    move-result v14

    .line 556
    if-eqz v14, :cond_250

    .line 557
    .line 558
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 559
    .line 560
    .line 561
    move-result-object v14

    .line 562
    check-cast v14, Ljava/util/Map$Entry;

    .line 563
    .line 564
    iget-object v15, v2, Lio/sentry/i4;->w:Ljava/util/AbstractMap;

    .line 565
    .line 566
    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 567
    .line 568
    .line 569
    move-result-object v4

    .line 570
    invoke-interface {v15, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 571
    .line 572
    .line 573
    move-result v4

    .line 574
    if-nez v4, :cond_24e

    .line 575
    .line 576
    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 577
    .line 578
    .line 579
    move-result-object v4

    .line 580
    check-cast v4, Ljava/lang/String;

    .line 581
    .line 582
    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 583
    .line 584
    .line 585
    move-result-object v14

    .line 586
    check-cast v14, Ljava/lang/String;

    .line 587
    .line 588
    invoke-virtual {v2, v4, v14}, Lio/sentry/i4;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 589
    .line 590
    .line 591
    :cond_24e
    const/4 v4, 0x0

    .line 592
    goto :goto_227

    .line 593
    :cond_250
    :goto_250
    const-string v0, "breadcrumbs.json"

    .line 594
    .line 595
    const-class v4, Ljava/util/List;

    .line 596
    .line 597
    invoke-virtual {v1, v5, v0, v4}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 598
    .line 599
    .line 600
    move-result-object v0

    .line 601
    check-cast v0, Ljava/util/List;

    .line 602
    .line 603
    if-nez v0, :cond_25d

    .line 604
    .line 605
    goto :goto_26c

    .line 606
    :cond_25d
    iget-object v14, v2, Lio/sentry/i4;->O:Ljava/util/List;

    .line 607
    .line 608
    if-nez v14, :cond_269

    .line 609
    .line 610
    new-instance v14, Ljava/util/ArrayList;

    .line 611
    .line 612
    invoke-direct {v14, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 613
    .line 614
    .line 615
    iput-object v14, v2, Lio/sentry/i4;->O:Ljava/util/List;

    .line 616
    .line 617
    goto :goto_26c

    .line 618
    :cond_269
    invoke-interface {v14, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 619
    .line 620
    .line 621
    :goto_26c
    const-string v0, "extras.json"

    .line 622
    .line 623
    invoke-virtual {v1, v5, v0, v13}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 624
    .line 625
    .line 626
    move-result-object v0

    .line 627
    check-cast v0, Ljava/util/Map;

    .line 628
    .line 629
    if-nez v0, :cond_277

    .line 630
    .line 631
    goto :goto_287

    .line 632
    :cond_277
    iget-object v14, v2, Lio/sentry/i4;->Q:Ljava/util/AbstractMap;

    .line 633
    .line 634
    if-nez v14, :cond_28a

    .line 635
    .line 636
    new-instance v14, Ljava/util/HashMap;

    .line 637
    .line 638
    invoke-direct {v14, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 639
    .line 640
    .line 641
    new-instance v0, Ljava/util/HashMap;

    .line 642
    .line 643
    invoke-direct {v0, v14}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 644
    .line 645
    .line 646
    iput-object v0, v2, Lio/sentry/i4;->Q:Ljava/util/AbstractMap;

    .line 647
    .line 648
    :cond_287
    :goto_287
    move/from16 v16, v9

    .line 649
    .line 650
    goto :goto_2be

    .line 651
    :cond_28a
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 652
    .line 653
    .line 654
    move-result-object v0

    .line 655
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 656
    .line 657
    .line 658
    move-result-object v0

    .line 659
    :goto_292
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 660
    .line 661
    .line 662
    move-result v14

    .line 663
    if-eqz v14, :cond_287

    .line 664
    .line 665
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 666
    .line 667
    .line 668
    move-result-object v14

    .line 669
    check-cast v14, Ljava/util/Map$Entry;

    .line 670
    .line 671
    iget-object v15, v2, Lio/sentry/i4;->Q:Ljava/util/AbstractMap;

    .line 672
    .line 673
    move/from16 v16, v9

    .line 674
    .line 675
    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 676
    .line 677
    .line 678
    move-result-object v9

    .line 679
    invoke-interface {v15, v9}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 680
    .line 681
    .line 682
    move-result v9

    .line 683
    if-nez v9, :cond_2bb

    .line 684
    .line 685
    iget-object v9, v2, Lio/sentry/i4;->Q:Ljava/util/AbstractMap;

    .line 686
    .line 687
    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 688
    .line 689
    .line 690
    move-result-object v15

    .line 691
    check-cast v15, Ljava/lang/String;

    .line 692
    .line 693
    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 694
    .line 695
    .line 696
    move-result-object v14

    .line 697
    invoke-interface {v9, v15, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 698
    .line 699
    .line 700
    :cond_2bb
    move/from16 v9, v16

    .line 701
    .line 702
    goto :goto_292

    .line 703
    :goto_2be
    const-string v0, "contexts.json"

    .line 704
    .line 705
    const-class v9, Lio/sentry/protocol/c;

    .line 706
    .line 707
    invoke-virtual {v1, v5, v0, v9}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 708
    .line 709
    .line 710
    move-result-object v0

    .line 711
    check-cast v0, Lio/sentry/protocol/c;

    .line 712
    .line 713
    if-nez v0, :cond_2cb

    .line 714
    .line 715
    goto :goto_313

    .line 716
    :cond_2cb
    new-instance v9, Lio/sentry/protocol/c;

    .line 717
    .line 718
    invoke-direct {v9, v0}, Lio/sentry/protocol/c;-><init>(Lio/sentry/protocol/c;)V

    .line 719
    .line 720
    .line 721
    iget-object v0, v9, Lio/sentry/protocol/c;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 722
    .line 723
    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    .line 724
    .line 725
    .line 726
    move-result-object v0

    .line 727
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 728
    .line 729
    .line 730
    move-result-object v0

    .line 731
    :goto_2da
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 732
    .line 733
    .line 734
    move-result v9

    .line 735
    if-eqz v9, :cond_313

    .line 736
    .line 737
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 738
    .line 739
    .line 740
    move-result-object v9

    .line 741
    check-cast v9, Ljava/util/Map$Entry;

    .line 742
    .line 743
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 744
    .line 745
    .line 746
    move-result-object v14

    .line 747
    const-string v15, "trace"

    .line 748
    .line 749
    move-object/from16 v17, v0

    .line 750
    .line 751
    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 752
    .line 753
    .line 754
    move-result-object v0

    .line 755
    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 756
    .line 757
    .line 758
    move-result v0

    .line 759
    if-eqz v0, :cond_2ff

    .line 760
    .line 761
    instance-of v0, v14, Lio/sentry/m6;

    .line 762
    .line 763
    if-eqz v0, :cond_2ff

    .line 764
    .line 765
    :cond_2fc
    :goto_2fc
    move-object/from16 v0, v17

    .line 766
    .line 767
    goto :goto_2da

    .line 768
    :cond_2ff
    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 769
    .line 770
    .line 771
    move-result-object v0

    .line 772
    invoke-virtual {v10, v0}, Lio/sentry/protocol/c;->a(Ljava/lang/Object;)Z

    .line 773
    .line 774
    .line 775
    move-result v0

    .line 776
    if-nez v0, :cond_2fc

    .line 777
    .line 778
    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 779
    .line 780
    .line 781
    move-result-object v0

    .line 782
    check-cast v0, Ljava/lang/String;

    .line 783
    .line 784
    invoke-virtual {v10, v14, v0}, Lio/sentry/protocol/c;->k(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 785
    .line 786
    .line 787
    goto :goto_2fc

    .line 788
    :cond_313
    :goto_313
    const-string v0, "transaction.json"

    .line 789
    .line 790
    const-class v9, Ljava/lang/String;

    .line 791
    .line 792
    invoke-virtual {v1, v5, v0, v9}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 793
    .line 794
    .line 795
    move-result-object v0

    .line 796
    check-cast v0, Ljava/lang/String;

    .line 797
    .line 798
    iget-object v14, v2, Lio/sentry/t4;->X:Ljava/lang/String;

    .line 799
    .line 800
    if-nez v14, :cond_323

    .line 801
    .line 802
    iput-object v0, v2, Lio/sentry/t4;->X:Ljava/lang/String;

    .line 803
    .line 804
    :cond_323
    const-string v0, "fingerprint.json"

    .line 805
    .line 806
    invoke-virtual {v1, v5, v0, v4}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 807
    .line 808
    .line 809
    move-result-object v0

    .line 810
    check-cast v0, Ljava/util/List;

    .line 811
    .line 812
    iget-object v4, v2, Lio/sentry/t4;->Y:Ljava/util/List;

    .line 813
    .line 814
    if-nez v4, :cond_33a

    .line 815
    .line 816
    if-eqz v0, :cond_337

    .line 817
    .line 818
    new-instance v4, Ljava/util/ArrayList;

    .line 819
    .line 820
    invoke-direct {v4, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 821
    .line 822
    .line 823
    goto :goto_338

    .line 824
    :cond_337
    const/4 v4, 0x0

    .line 825
    :goto_338
    iput-object v4, v2, Lio/sentry/t4;->Y:Ljava/util/List;

    .line 826
    .line 827
    :cond_33a
    const-string v0, "level.json"

    .line 828
    .line 829
    const-class v4, Lio/sentry/a5;

    .line 830
    .line 831
    invoke-virtual {v1, v5, v0, v4}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 832
    .line 833
    .line 834
    move-result-object v0

    .line 835
    check-cast v0, Lio/sentry/a5;

    .line 836
    .line 837
    iget-object v4, v2, Lio/sentry/t4;->W:Lio/sentry/a5;

    .line 838
    .line 839
    if-nez v4, :cond_34a

    .line 840
    .line 841
    iput-object v0, v2, Lio/sentry/t4;->W:Lio/sentry/a5;

    .line 842
    .line 843
    :cond_34a
    const-string v0, "trace.json"

    .line 844
    .line 845
    const-class v4, Lio/sentry/m6;

    .line 846
    .line 847
    invoke-virtual {v1, v5, v0, v4}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 848
    .line 849
    .line 850
    move-result-object v0

    .line 851
    check-cast v0, Lio/sentry/m6;

    .line 852
    .line 853
    invoke-virtual {v10}, Lio/sentry/protocol/c;->i()Lio/sentry/m6;

    .line 854
    .line 855
    .line 856
    move-result-object v4

    .line 857
    if-nez v4, :cond_35f

    .line 858
    .line 859
    if-eqz v0, :cond_35f

    .line 860
    .line 861
    invoke-virtual {v10, v0}, Lio/sentry/protocol/c;->w(Lio/sentry/m6;)V

    .line 862
    .line 863
    .line 864
    :cond_35f
    const-string v0, "replay.json"

    .line 865
    .line 866
    invoke-virtual {v1, v5, v0, v9}, Lio/sentry/android/core/g0;->b(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 867
    .line 868
    .line 869
    move-result-object v4

    .line 870
    check-cast v4, Ljava/lang/String;

    .line 871
    .line 872
    invoke-virtual {v5}, Lio/sentry/a6;->getCacheDirPath()Ljava/lang/String;

    .line 873
    .line 874
    .line 875
    move-result-object v14

    .line 876
    const-string v15, ".options-cache"

    .line 877
    .line 878
    if-nez v14, :cond_375

    .line 879
    .line 880
    move-object/from16 v18, v6

    .line 881
    .line 882
    move-object/from16 v17, v7

    .line 883
    .line 884
    goto/16 :goto_431

    .line 885
    .line 886
    :cond_375
    new-instance v1, Ljava/io/File;

    .line 887
    .line 888
    move-object/from16 v17, v7

    .line 889
    .line 890
    const-string v7, "replay_"

    .line 891
    .line 892
    move-object/from16 v18, v6

    .line 893
    .line 894
    invoke-static {v7, v4}, La1/h;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 895
    .line 896
    .line 897
    move-result-object v6

    .line 898
    invoke-direct {v1, v14, v6}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 899
    .line 900
    .line 901
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    .line 902
    .line 903
    .line 904
    move-result v1

    .line 905
    if-nez v1, :cond_422

    .line 906
    .line 907
    const-string v1, "replay-error-sample-rate.json"

    .line 908
    .line 909
    invoke-static {v5, v15, v1, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 910
    .line 911
    .line 912
    move-result-object v1

    .line 913
    check-cast v1, Ljava/lang/String;

    .line 914
    .line 915
    if-nez v1, :cond_396

    .line 916
    .line 917
    goto/16 :goto_431

    .line 918
    .line 919
    :cond_396
    :try_start_396
    invoke-static {v1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 920
    .line 921
    .line 922
    move-result-wide v19

    .line 923
    invoke-static {}, Lio/sentry/util/j;->a()Lio/sentry/util/i;

    .line 924
    .line 925
    .line 926
    move-result-object v1

    .line 927
    invoke-virtual {v1}, Lio/sentry/util/i;->c()D

    .line 928
    .line 929
    .line 930
    move-result-wide v21

    .line 931
    cmpg-double v1, v19, v21

    .line 932
    .line 933
    if-gez v1, :cond_3bb

    .line 934
    .line 935
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 936
    .line 937
    .line 938
    move-result-object v0

    .line 939
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 940
    .line 941
    const-string v4, "Not capturing replay for ANR %s due to not being sampled."

    .line 942
    .line 943
    iget-object v6, v2, Lio/sentry/i4;->d:Lio/sentry/protocol/v;

    .line 944
    .line 945
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 946
    .line 947
    .line 948
    move-result-object v6

    .line 949
    invoke-interface {v0, v1, v4, v6}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_3b7
    .catchall {:try_start_396 .. :try_end_3b7} :catchall_3b9

    .line 950
    .line 951
    .line 952
    goto/16 :goto_431

    .line 953
    .line 954
    :catchall_3b9
    move-exception v0

    .line 955
    goto :goto_416

    .line 956
    :cond_3bb
    new-instance v1, Ljava/io/File;

    .line 957
    .line 958
    invoke-direct {v1, v14}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 959
    .line 960
    .line 961
    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 962
    .line 963
    .line 964
    move-result-object v1

    .line 965
    if-eqz v1, :cond_414

    .line 966
    .line 967
    array-length v4, v1

    .line 968
    const-wide/high16 v19, -0x8000000000000000L

    .line 969
    .line 970
    const/4 v6, 0x0

    .line 971
    const/4 v14, 0x0

    .line 972
    :goto_3cb
    if-ge v14, v4, :cond_412

    .line 973
    .line 974
    aget-object v21, v1, v14

    .line 975
    .line 976
    invoke-virtual/range {v21 .. v21}, Ljava/io/File;->isDirectory()Z

    .line 977
    .line 978
    .line 979
    move-result v22

    .line 980
    if-eqz v22, :cond_40b

    .line 981
    .line 982
    move-object/from16 v22, v1

    .line 983
    .line 984
    invoke-virtual/range {v21 .. v21}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 985
    .line 986
    .line 987
    move-result-object v1

    .line 988
    invoke-virtual {v1, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 989
    .line 990
    .line 991
    move-result v1

    .line 992
    if-eqz v1, :cond_40d

    .line 993
    .line 994
    invoke-virtual/range {v21 .. v21}, Ljava/io/File;->lastModified()J

    .line 995
    .line 996
    .line 997
    move-result-wide v23

    .line 998
    cmp-long v1, v23, v19

    .line 999
    .line 1000
    if-lez v1, :cond_40d

    .line 1001
    .line 1002
    invoke-virtual/range {v21 .. v21}, Ljava/io/File;->lastModified()J

    .line 1003
    .line 1004
    .line 1005
    move-result-wide v23

    .line 1006
    iget-object v1, v2, Lio/sentry/t4;->R:Ljava/util/Date;

    .line 1007
    .line 1008
    invoke-virtual {v1}, Ljava/util/Date;->clone()Ljava/lang/Object;

    .line 1009
    .line 1010
    .line 1011
    move-result-object v1

    .line 1012
    check-cast v1, Ljava/util/Date;

    .line 1013
    .line 1014
    invoke-virtual {v1}, Ljava/util/Date;->getTime()J

    .line 1015
    .line 1016
    .line 1017
    move-result-wide v25

    .line 1018
    cmp-long v1, v23, v25

    .line 1019
    .line 1020
    if-gtz v1, :cond_40d

    .line 1021
    .line 1022
    invoke-virtual/range {v21 .. v21}, Ljava/io/File;->lastModified()J

    .line 1023
    .line 1024
    .line 1025
    move-result-wide v19

    .line 1026
    invoke-virtual/range {v21 .. v21}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 1027
    .line 1028
    .line 1029
    move-result-object v1

    .line 1030
    const/4 v6, 0x7

    .line 1031
    invoke-virtual {v1, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1032
    .line 1033
    .line 1034
    move-result-object v6

    .line 1035
    goto :goto_40d

    .line 1036
    :cond_40b
    move-object/from16 v22, v1

    .line 1037
    .line 1038
    :cond_40d
    :goto_40d
    add-int/lit8 v14, v14, 0x1

    .line 1039
    .line 1040
    move-object/from16 v1, v22

    .line 1041
    .line 1042
    goto :goto_3cb

    .line 1043
    :cond_412
    move-object v4, v6

    .line 1044
    goto :goto_422

    .line 1045
    :cond_414
    const/4 v4, 0x0

    .line 1046
    goto :goto_422

    .line 1047
    :goto_416
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 1048
    .line 1049
    .line 1050
    move-result-object v1

    .line 1051
    sget-object v4, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 1052
    .line 1053
    const-string v6, "Error parsing replay sample rate."

    .line 1054
    .line 1055
    invoke-interface {v1, v4, v6, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1056
    .line 1057
    .line 1058
    goto :goto_431

    .line 1059
    :cond_422
    :goto_422
    if-nez v4, :cond_425

    .line 1060
    .line 1061
    goto :goto_431

    .line 1062
    :cond_425
    sget-object v1, Lio/sentry/cache/g;->c:Ljava/nio/charset/Charset;

    .line 1063
    .line 1064
    const-string v1, ".scope-cache"

    .line 1065
    .line 1066
    invoke-static {v5, v4, v1, v0}, Lio/sentry/cache/a;->d(Lio/sentry/a6;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 1067
    .line 1068
    .line 1069
    const-string v0, "replay_id"

    .line 1070
    .line 1071
    invoke-virtual {v10, v4, v0}, Lio/sentry/protocol/c;->k(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 1072
    .line 1073
    .line 1074
    :goto_431
    iget-object v0, v2, Lio/sentry/i4;->x:Ljava/lang/String;

    .line 1075
    .line 1076
    const-string v1, "release.json"

    .line 1077
    .line 1078
    if-nez v0, :cond_43f

    .line 1079
    .line 1080
    invoke-static {v5, v15, v1, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1081
    .line 1082
    .line 1083
    move-result-object v0

    .line 1084
    check-cast v0, Ljava/lang/String;

    .line 1085
    .line 1086
    iput-object v0, v2, Lio/sentry/i4;->x:Ljava/lang/String;

    .line 1087
    .line 1088
    :cond_43f
    iget-object v0, v2, Lio/sentry/i4;->y:Ljava/lang/String;

    .line 1089
    .line 1090
    if-nez v0, :cond_454

    .line 1091
    .line 1092
    const-string v0, "environment.json"

    .line 1093
    .line 1094
    invoke-static {v5, v15, v0, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1095
    .line 1096
    .line 1097
    move-result-object v0

    .line 1098
    check-cast v0, Ljava/lang/String;

    .line 1099
    .line 1100
    if-eqz v0, :cond_44e

    .line 1101
    .line 1102
    goto :goto_452

    .line 1103
    :cond_44e
    invoke-virtual {v5}, Lio/sentry/a6;->getEnvironment()Ljava/lang/String;

    .line 1104
    .line 1105
    .line 1106
    move-result-object v0

    .line 1107
    :goto_452
    iput-object v0, v2, Lio/sentry/i4;->y:Ljava/lang/String;

    .line 1108
    .line 1109
    :cond_454
    iget-object v0, v2, Lio/sentry/i4;->N:Ljava/lang/String;

    .line 1110
    .line 1111
    if-nez v0, :cond_462

    .line 1112
    .line 1113
    const-string v0, "dist.json"

    .line 1114
    .line 1115
    invoke-static {v5, v15, v0, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1116
    .line 1117
    .line 1118
    move-result-object v0

    .line 1119
    check-cast v0, Ljava/lang/String;

    .line 1120
    .line 1121
    iput-object v0, v2, Lio/sentry/i4;->N:Ljava/lang/String;

    .line 1122
    .line 1123
    :cond_462
    iget-object v0, v2, Lio/sentry/i4;->N:Ljava/lang/String;

    .line 1124
    .line 1125
    const-string v4, "Failed to parse release from scope cache: %s"

    .line 1126
    .line 1127
    const/16 v6, 0x2b

    .line 1128
    .line 1129
    if-nez v0, :cond_48c

    .line 1130
    .line 1131
    invoke-static {v5, v15, v1, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1132
    .line 1133
    .line 1134
    move-result-object v0

    .line 1135
    check-cast v0, Ljava/lang/String;

    .line 1136
    .line 1137
    if-eqz v0, :cond_48c

    .line 1138
    .line 1139
    :try_start_472
    invoke-virtual {v0, v6}, Ljava/lang/String;->indexOf(I)I

    .line 1140
    .line 1141
    .line 1142
    move-result v7

    .line 1143
    add-int/lit8 v7, v7, 0x1

    .line 1144
    .line 1145
    invoke-virtual {v0, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v7

    .line 1149
    iput-object v7, v2, Lio/sentry/i4;->N:Ljava/lang/String;
    :try_end_47e
    .catchall {:try_start_472 .. :try_end_47e} :catchall_47f

    .line 1150
    .line 1151
    goto :goto_48c

    .line 1152
    :catchall_47f
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 1153
    .line 1154
    .line 1155
    move-result-object v7

    .line 1156
    sget-object v14, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 1157
    .line 1158
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 1159
    .line 1160
    .line 1161
    move-result-object v0

    .line 1162
    invoke-interface {v7, v14, v4, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1163
    .line 1164
    .line 1165
    :cond_48c
    :goto_48c
    iget-object v0, v2, Lio/sentry/i4;->P:Lio/sentry/protocol/d;

    .line 1166
    .line 1167
    if-nez v0, :cond_495

    .line 1168
    .line 1169
    new-instance v0, Lio/sentry/protocol/d;

    .line 1170
    .line 1171
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 1172
    .line 1173
    .line 1174
    :cond_495
    iget-object v7, v0, Lio/sentry/protocol/d;->e:Ljava/util/List;

    .line 1175
    .line 1176
    if-nez v7, :cond_4a5

    .line 1177
    .line 1178
    new-instance v7, Ljava/util/ArrayList;

    .line 1179
    .line 1180
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 1181
    .line 1182
    .line 1183
    new-instance v14, Ljava/util/ArrayList;

    .line 1184
    .line 1185
    invoke-direct {v14, v7}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 1186
    .line 1187
    .line 1188
    iput-object v14, v0, Lio/sentry/protocol/d;->e:Ljava/util/List;

    .line 1189
    .line 1190
    :cond_4a5
    iget-object v7, v0, Lio/sentry/protocol/d;->e:Ljava/util/List;

    .line 1191
    .line 1192
    if-eqz v7, :cond_4cb

    .line 1193
    .line 1194
    const-string v14, "proguard-uuid.json"

    .line 1195
    .line 1196
    invoke-static {v5, v15, v14, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1197
    .line 1198
    .line 1199
    move-result-object v14

    .line 1200
    check-cast v14, Ljava/lang/String;

    .line 1201
    .line 1202
    if-eqz v14, :cond_4c6

    .line 1203
    .line 1204
    new-instance v6, Lio/sentry/protocol/DebugImage;

    .line 1205
    .line 1206
    invoke-direct {v6}, Lio/sentry/protocol/DebugImage;-><init>()V

    .line 1207
    .line 1208
    .line 1209
    move-object/from16 v20, v3

    .line 1210
    .line 1211
    const-string v3, "proguard"

    .line 1212
    .line 1213
    invoke-virtual {v6, v3}, Lio/sentry/protocol/DebugImage;->setType(Ljava/lang/String;)V

    .line 1214
    .line 1215
    .line 1216
    invoke-virtual {v6, v14}, Lio/sentry/protocol/DebugImage;->setUuid(Ljava/lang/String;)V

    .line 1217
    .line 1218
    .line 1219
    invoke-interface {v7, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1220
    .line 1221
    .line 1222
    goto :goto_4c8

    .line 1223
    :cond_4c6
    move-object/from16 v20, v3

    .line 1224
    .line 1225
    :goto_4c8
    iput-object v0, v2, Lio/sentry/i4;->P:Lio/sentry/protocol/d;

    .line 1226
    .line 1227
    goto :goto_4cd

    .line 1228
    :cond_4cb
    move-object/from16 v20, v3

    .line 1229
    .line 1230
    :goto_4cd
    iget-object v0, v2, Lio/sentry/i4;->i:Lio/sentry/protocol/t;

    .line 1231
    .line 1232
    if-nez v0, :cond_4dd

    .line 1233
    .line 1234
    const-string v0, "sdk-version.json"

    .line 1235
    .line 1236
    const-class v3, Lio/sentry/protocol/t;

    .line 1237
    .line 1238
    invoke-static {v5, v15, v0, v3}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1239
    .line 1240
    .line 1241
    move-result-object v0

    .line 1242
    check-cast v0, Lio/sentry/protocol/t;

    .line 1243
    .line 1244
    iput-object v0, v2, Lio/sentry/i4;->i:Lio/sentry/protocol/t;

    .line 1245
    .line 1246
    :cond_4dd
    invoke-virtual {v10}, Lio/sentry/protocol/c;->d()Lio/sentry/protocol/a;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v0

    .line 1250
    if-nez v0, :cond_4e8

    .line 1251
    .line 1252
    new-instance v0, Lio/sentry/protocol/a;

    .line 1253
    .line 1254
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 1255
    .line 1256
    .line 1257
    :cond_4e8
    move-object v3, v0

    .line 1258
    sget-object v0, Lio/sentry/android/core/k0;->c:Lcom/google/android/gms/internal/fido/g4;

    .line 1259
    .line 1260
    invoke-virtual {v0, v11}, Lcom/google/android/gms/internal/fido/g4;->a(Landroid/content/Context;)Ljava/lang/Object;

    .line 1261
    .line 1262
    .line 1263
    move-result-object v0

    .line 1264
    check-cast v0, Ljava/lang/String;

    .line 1265
    .line 1266
    iput-object v0, v3, Lio/sentry/protocol/a;->w:Ljava/lang/String;

    .line 1267
    .line 1268
    invoke-static {v11, v12}, Lio/sentry/android/core/k0;->g(Landroid/content/Context;Lio/sentry/android/core/j0;)Landroid/content/pm/PackageInfo;

    .line 1269
    .line 1270
    .line 1271
    move-result-object v0

    .line 1272
    if-eqz v0, :cond_4fd

    .line 1273
    .line 1274
    iget-object v0, v0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    .line 1275
    .line 1276
    iput-object v0, v3, Lio/sentry/protocol/a;->d:Ljava/lang/String;

    .line 1277
    .line 1278
    :cond_4fd
    iget-object v0, v2, Lio/sentry/i4;->x:Ljava/lang/String;

    .line 1279
    .line 1280
    if-eqz v0, :cond_502

    .line 1281
    .line 1282
    goto :goto_508

    .line 1283
    :cond_502
    invoke-static {v5, v15, v1, v9}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1284
    .line 1285
    .line 1286
    move-result-object v0

    .line 1287
    check-cast v0, Ljava/lang/String;

    .line 1288
    .line 1289
    :goto_508
    if-eqz v0, :cond_538

    .line 1290
    .line 1291
    const/16 v1, 0x40

    .line 1292
    .line 1293
    :try_start_50c
    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(I)I

    .line 1294
    .line 1295
    .line 1296
    move-result v1

    .line 1297
    add-int/lit8 v1, v1, 0x1

    .line 1298
    .line 1299
    const/16 v6, 0x2b

    .line 1300
    .line 1301
    invoke-virtual {v0, v6}, Ljava/lang/String;->indexOf(I)I

    .line 1302
    .line 1303
    .line 1304
    move-result v7

    .line 1305
    invoke-virtual {v0, v1, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1306
    .line 1307
    .line 1308
    move-result-object v1

    .line 1309
    invoke-virtual {v0, v6}, Ljava/lang/String;->indexOf(I)I

    .line 1310
    .line 1311
    .line 1312
    move-result v6

    .line 1313
    add-int/lit8 v6, v6, 0x1

    .line 1314
    .line 1315
    invoke-virtual {v0, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1316
    .line 1317
    .line 1318
    move-result-object v6

    .line 1319
    iput-object v1, v3, Lio/sentry/protocol/a;->x:Ljava/lang/String;

    .line 1320
    .line 1321
    iput-object v6, v3, Lio/sentry/protocol/a;->y:Ljava/lang/String;
    :try_end_52a
    .catchall {:try_start_50c .. :try_end_52a} :catchall_52b

    .line 1322
    .line 1323
    goto :goto_538

    .line 1324
    :catchall_52b
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 1325
    .line 1326
    .line 1327
    move-result-object v1

    .line 1328
    sget-object v6, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 1329
    .line 1330
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 1331
    .line 1332
    .line 1333
    move-result-object v0

    .line 1334
    invoke-interface {v1, v6, v4, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1335
    .line 1336
    .line 1337
    :cond_538
    :goto_538
    :try_start_538
    invoke-static {v11, v5}, Lio/sentry/android/core/p0;->c(Landroid/content/Context;Lio/sentry/android/core/SentryAndroidOptions;)Lio/sentry/android/core/p0;

    .line 1338
    .line 1339
    .line 1340
    move-result-object v0

    .line 1341
    iget-object v0, v0, Lio/sentry/android/core/p0;->f:Lbj/d;

    .line 1342
    .line 1343
    if-eqz v0, :cond_561

    .line 1344
    .line 1345
    iget-boolean v1, v0, Lbj/d;->e:Z

    .line 1346
    .line 1347
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1348
    .line 1349
    .line 1350
    move-result-object v1

    .line 1351
    iput-object v1, v3, Lio/sentry/protocol/a;->N:Ljava/lang/Boolean;

    .line 1352
    .line 1353
    iget-object v0, v0, Lbj/d;->i:Ljava/lang/Object;

    .line 1354
    .line 1355
    check-cast v0, [Ljava/lang/String;

    .line 1356
    .line 1357
    if-eqz v0, :cond_561

    .line 1358
    .line 1359
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1360
    .line 1361
    .line 1362
    move-result-object v0

    .line 1363
    iput-object v0, v3, Lio/sentry/protocol/a;->O:Ljava/util/List;
    :try_end_554
    .catchall {:try_start_538 .. :try_end_554} :catchall_555

    .line 1364
    .line 1365
    goto :goto_561

    .line 1366
    :catchall_555
    move-exception v0

    .line 1367
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 1368
    .line 1369
    .line 1370
    move-result-object v1

    .line 1371
    sget-object v4, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 1372
    .line 1373
    const-string v6, "Error getting split apks info."

    .line 1374
    .line 1375
    invoke-interface {v1, v4, v6, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1376
    .line 1377
    .line 1378
    :cond_561
    :goto_561
    invoke-virtual {v10, v3}, Lio/sentry/protocol/c;->n(Lio/sentry/protocol/a;)V

    .line 1379
    .line 1380
    .line 1381
    invoke-static {v5, v15, v8, v13}, Lio/sentry/cache/a;->c(Lio/sentry/a6;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1382
    .line 1383
    .line 1384
    move-result-object v0

    .line 1385
    check-cast v0, Ljava/util/Map;

    .line 1386
    .line 1387
    if-nez v0, :cond_56d

    .line 1388
    .line 1389
    goto :goto_5ae

    .line 1390
    :cond_56d
    iget-object v1, v2, Lio/sentry/i4;->w:Ljava/util/AbstractMap;

    .line 1391
    .line 1392
    if-nez v1, :cond_57e

    .line 1393
    .line 1394
    new-instance v1, Ljava/util/HashMap;

    .line 1395
    .line 1396
    invoke-direct {v1, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 1397
    .line 1398
    .line 1399
    new-instance v0, Ljava/util/HashMap;

    .line 1400
    .line 1401
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 1402
    .line 1403
    .line 1404
    iput-object v0, v2, Lio/sentry/i4;->w:Ljava/util/AbstractMap;

    .line 1405
    .line 1406
    goto :goto_5ae

    .line 1407
    :cond_57e
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 1408
    .line 1409
    .line 1410
    move-result-object v0

    .line 1411
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 1412
    .line 1413
    .line 1414
    move-result-object v0

    .line 1415
    :cond_586
    :goto_586
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1416
    .line 1417
    .line 1418
    move-result v1

    .line 1419
    if-eqz v1, :cond_5ae

    .line 1420
    .line 1421
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1422
    .line 1423
    .line 1424
    move-result-object v1

    .line 1425
    check-cast v1, Ljava/util/Map$Entry;

    .line 1426
    .line 1427
    iget-object v3, v2, Lio/sentry/i4;->w:Ljava/util/AbstractMap;

    .line 1428
    .line 1429
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1430
    .line 1431
    .line 1432
    move-result-object v4

    .line 1433
    invoke-interface {v3, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 1434
    .line 1435
    .line 1436
    move-result v3

    .line 1437
    if-nez v3, :cond_586

    .line 1438
    .line 1439
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1440
    .line 1441
    .line 1442
    move-result-object v3

    .line 1443
    check-cast v3, Ljava/lang/String;

    .line 1444
    .line 1445
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1446
    .line 1447
    .line 1448
    move-result-object v1

    .line 1449
    check-cast v1, Ljava/lang/String;

    .line 1450
    .line 1451
    invoke-virtual {v2, v3, v1}, Lio/sentry/i4;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 1452
    .line 1453
    .line 1454
    goto :goto_586

    .line 1455
    :cond_5ae
    :goto_5ae
    iget-object v0, v2, Lio/sentry/i4;->K:Lio/sentry/protocol/i0;

    .line 1456
    .line 1457
    if-nez v0, :cond_5b9

    .line 1458
    .line 1459
    new-instance v0, Lio/sentry/protocol/i0;

    .line 1460
    .line 1461
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 1462
    .line 1463
    .line 1464
    iput-object v0, v2, Lio/sentry/i4;->K:Lio/sentry/protocol/i0;

    .line 1465
    .line 1466
    :cond_5b9
    iget-object v1, v0, Lio/sentry/protocol/i0;->e:Ljava/lang/String;

    .line 1467
    .line 1468
    if-nez v1, :cond_5c3

    .line 1469
    .line 1470
    invoke-virtual/range {p0 .. p0}, Lio/sentry/android/core/g0;->a()Ljava/lang/String;

    .line 1471
    .line 1472
    .line 1473
    move-result-object v1

    .line 1474
    iput-object v1, v0, Lio/sentry/protocol/i0;->e:Ljava/lang/String;

    .line 1475
    .line 1476
    :cond_5c3
    iget-object v1, v0, Lio/sentry/protocol/i0;->v:Ljava/lang/String;

    .line 1477
    .line 1478
    if-nez v1, :cond_5d1

    .line 1479
    .line 1480
    invoke-virtual {v5}, Lio/sentry/a6;->isSendDefaultPii()Z

    .line 1481
    .line 1482
    .line 1483
    move-result v1

    .line 1484
    if-eqz v1, :cond_5d1

    .line 1485
    .line 1486
    const-string v1, "{{auto}}"

    .line 1487
    .line 1488
    iput-object v1, v0, Lio/sentry/protocol/i0;->v:Ljava/lang/String;

    .line 1489
    .line 1490
    :cond_5d1
    :try_start_5d1
    invoke-static {v11, v5}, Lio/sentry/android/core/p0;->c(Landroid/content/Context;Lio/sentry/android/core/SentryAndroidOptions;)Lio/sentry/android/core/p0;

    .line 1491
    .line 1492
    .line 1493
    move-result-object v0

    .line 1494
    iget-object v0, v0, Lio/sentry/android/core/p0;->e:Lf6/j;

    .line 1495
    .line 1496
    if-eqz v0, :cond_622

    .line 1497
    .line 1498
    new-instance v1, Ljava/util/HashMap;

    .line 1499
    .line 1500
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 1501
    .line 1502
    .line 1503
    const-string v3, "isSideLoaded"

    .line 1504
    .line 1505
    iget-boolean v4, v0, Lf6/j;->b:Z

    .line 1506
    .line 1507
    invoke-static {v4}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 1508
    .line 1509
    .line 1510
    move-result-object v4

    .line 1511
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1512
    .line 1513
    .line 1514
    iget-object v0, v0, Lf6/j;->a:Ljava/lang/String;

    .line 1515
    .line 1516
    if-eqz v0, :cond_5f2

    .line 1517
    .line 1518
    const-string v3, "installerStore"

    .line 1519
    .line 1520
    invoke-virtual {v1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1521
    .line 1522
    .line 1523
    :cond_5f2
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 1524
    .line 1525
    .line 1526
    move-result-object v0

    .line 1527
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 1528
    .line 1529
    .line 1530
    move-result-object v0

    .line 1531
    :goto_5fa
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1532
    .line 1533
    .line 1534
    move-result v1

    .line 1535
    if-eqz v1, :cond_622

    .line 1536
    .line 1537
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1538
    .line 1539
    .line 1540
    move-result-object v1

    .line 1541
    check-cast v1, Ljava/util/Map$Entry;

    .line 1542
    .line 1543
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1544
    .line 1545
    .line 1546
    move-result-object v3

    .line 1547
    check-cast v3, Ljava/lang/String;

    .line 1548
    .line 1549
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1550
    .line 1551
    .line 1552
    move-result-object v1

    .line 1553
    check-cast v1, Ljava/lang/String;

    .line 1554
    .line 1555
    invoke-virtual {v2, v3, v1}, Lio/sentry/i4;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_615
    .catchall {:try_start_5d1 .. :try_end_615} :catchall_616

    .line 1556
    .line 1557
    .line 1558
    goto :goto_5fa

    .line 1559
    :catchall_616
    move-exception v0

    .line 1560
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 1561
    .line 1562
    .line 1563
    move-result-object v1

    .line 1564
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 1565
    .line 1566
    const-string v4, "Error getting side loaded info."

    .line 1567
    .line 1568
    invoke-interface {v1, v3, v4, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1569
    .line 1570
    .line 1571
    :cond_622
    if-eqz v17, :cond_673

    .line 1572
    .line 1573
    move-object/from16 v1, v20

    .line 1574
    .line 1575
    instance-of v0, v1, Lio/sentry/hints/a;

    .line 1576
    .line 1577
    if-eqz v0, :cond_638

    .line 1578
    .line 1579
    move-object v3, v1

    .line 1580
    check-cast v3, Lio/sentry/hints/a;

    .line 1581
    .line 1582
    invoke-interface {v3}, Lio/sentry/hints/a;->e()Ljava/lang/String;

    .line 1583
    .line 1584
    .line 1585
    move-result-object v0

    .line 1586
    move-object/from16 v1, v18

    .line 1587
    .line 1588
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1589
    .line 1590
    .line 1591
    move-result v4

    .line 1592
    goto :goto_639

    .line 1593
    :cond_638
    const/4 v4, 0x0

    .line 1594
    :goto_639
    xor-int/lit8 v0, v4, 0x1

    .line 1595
    .line 1596
    invoke-virtual {v10}, Lio/sentry/protocol/c;->d()Lio/sentry/protocol/a;

    .line 1597
    .line 1598
    .line 1599
    move-result-object v1

    .line 1600
    if-nez v1, :cond_649

    .line 1601
    .line 1602
    new-instance v1, Lio/sentry/protocol/a;

    .line 1603
    .line 1604
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 1605
    .line 1606
    .line 1607
    invoke-virtual {v10, v1}, Lio/sentry/protocol/c;->n(Lio/sentry/protocol/a;)V

    .line 1608
    .line 1609
    .line 1610
    :cond_649
    iget-object v3, v1, Lio/sentry/protocol/a;->M:Ljava/lang/Boolean;

    .line 1611
    .line 1612
    if-nez v3, :cond_653

    .line 1613
    .line 1614
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1615
    .line 1616
    .line 1617
    move-result-object v0

    .line 1618
    iput-object v0, v1, Lio/sentry/protocol/a;->M:Ljava/lang/Boolean;

    .line 1619
    .line 1620
    :cond_653
    iget-object v0, v2, Lio/sentry/t4;->Y:Ljava/util/List;

    .line 1621
    .line 1622
    if-nez v0, :cond_673

    .line 1623
    .line 1624
    if-eqz v4, :cond_65c

    .line 1625
    .line 1626
    const-string v0, "background-anr"

    .line 1627
    .line 1628
    goto :goto_65e

    .line 1629
    :cond_65c
    const-string v0, "foreground-anr"

    .line 1630
    .line 1631
    :goto_65e
    const-string v1, "{{ default }}"

    .line 1632
    .line 1633
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 1634
    .line 1635
    .line 1636
    move-result-object v0

    .line 1637
    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1638
    .line 1639
    .line 1640
    move-result-object v0

    .line 1641
    if-eqz v0, :cond_670

    .line 1642
    .line 1643
    new-instance v8, Ljava/util/ArrayList;

    .line 1644
    .line 1645
    invoke-direct {v8, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 1646
    .line 1647
    .line 1648
    goto :goto_671

    .line 1649
    :cond_670
    const/4 v8, 0x0

    .line 1650
    :goto_671
    iput-object v8, v2, Lio/sentry/t4;->Y:Ljava/util/List;

    .line 1651
    .line 1652
    :cond_673
    return-object v2
.end method

.method public final g(Lio/sentry/protocol/e0;Lio/sentry/h0;)Lio/sentry/protocol/e0;
    .registers 3

    .line 1
    return-object p1
.end method
