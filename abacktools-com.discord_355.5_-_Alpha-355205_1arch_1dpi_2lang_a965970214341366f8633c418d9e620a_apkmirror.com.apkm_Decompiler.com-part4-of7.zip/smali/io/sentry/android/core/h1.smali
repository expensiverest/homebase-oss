###### Class io.sentry.android.core.h1 (io.sentry.android.core.h1)
.class public final Lio/sentry/android/core/h1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public final d:J

.field public final e:J

.field public final i:J

.field public final v:J

.field public final w:Z

.field public final x:Z

.field public final y:J


# direct methods
.method public constructor <init>(J)V
    .registers 16

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    const/4 v9, 0x0

    move-wide v3, p1

    move-object v0, p0

    move-wide v1, p1

    .line 1
    invoke-direct/range {v0 .. v12}, Lio/sentry/android/core/h1;-><init>(JJJJZZJ)V

    return-void
.end method

.method public constructor <init>(JJJJZZJ)V
    .registers 13

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-wide p1, p0, Lio/sentry/android/core/h1;->d:J

    .line 4
    iput-wide p3, p0, Lio/sentry/android/core/h1;->e:J

    .line 5
    iput-wide p5, p0, Lio/sentry/android/core/h1;->i:J

    .line 6
    iput-wide p7, p0, Lio/sentry/android/core/h1;->v:J

    .line 7
    iput-boolean p9, p0, Lio/sentry/android/core/h1;->w:Z

    .line 8
    iput-boolean p10, p0, Lio/sentry/android/core/h1;->x:Z

    .line 9
    iput-wide p11, p0, Lio/sentry/android/core/h1;->y:J

    return-void
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 6

    .line 1
    check-cast p1, Lio/sentry/android/core/h1;

    .line 2
    .line 3
    iget-wide v0, p0, Lio/sentry/android/core/h1;->e:J

    .line 4
    .line 5
    iget-wide v2, p1, Lio/sentry/android/core/h1;->e:J

    .line 6
    .line 7
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1
.end method
