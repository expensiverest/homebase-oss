###### Class io.sentry.android.core.AnrIntegration (io.sentry.android.core.AnrIntegration)
.class public final Lio/sentry/android/core/AnrIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Ljava/io/Closeable;


# static fields
.field public static w:Lio/sentry/android/core/a;

.field public static final x:Lio/sentry/util/a;


# instance fields
.field public final d:Landroid/content/Context;

.field public e:Z

.field public final i:Lio/sentry/util/a;

.field public v:Lio/sentry/a6;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/AnrIntegration;->x:Lio/sentry/util/a;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lio/sentry/android/core/AnrIntegration;->e:Z

    .line 6
    .line 7
    new-instance v0, Lio/sentry/util/a;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lio/sentry/android/core/AnrIntegration;->i:Lio/sentry/util/a;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-eqz v0, :cond_14

    .line 19
    .line 20
    move-object p1, v0

    .line 21
    :cond_14
    iput-object p1, p0, Lio/sentry/android/core/AnrIntegration;->d:Landroid/content/Context;

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final c(Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 14

    .line 1
    sget-object v0, Lio/sentry/android/core/AnrIntegration;->x:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    :try_start_6
    sget-object v0, Lio/sentry/android/core/AnrIntegration;->w:Lio/sentry/android/core/a;

    .line 8
    .line 9
    if-nez v0, :cond_50

    .line 10
    .line 11
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sget-object v2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 16
    .line 17
    const-string v3, "ANR timeout in milliseconds: %d"

    .line 18
    .line 19
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->getAnrTimeoutIntervalMillis()J

    .line 20
    .line 21
    .line 22
    move-result-wide v4

    .line 23
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    invoke-interface {v0, v2, v3, v4}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    new-instance v5, Lio/sentry/android/core/a;

    .line 35
    .line 36
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->getAnrTimeoutIntervalMillis()J

    .line 37
    .line 38
    .line 39
    move-result-wide v6

    .line 40
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isAnrReportInDebug()Z

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    new-instance v9, Lc4/s;

    .line 45
    .line 46
    const/16 v0, 0x13

    .line 47
    .line 48
    invoke-direct {v9, v0, p0, p1}, Lc4/s;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 52
    .line 53
    .line 54
    move-result-object v10

    .line 55
    iget-object v11, p0, Lio/sentry/android/core/AnrIntegration;->d:Landroid/content/Context;

    .line 56
    .line 57
    invoke-direct/range {v5 .. v11}, Lio/sentry/android/core/a;-><init>(JZLc4/s;Lio/sentry/ILogger;Landroid/content/Context;)V

    .line 58
    .line 59
    .line 60
    sput-object v5, Lio/sentry/android/core/AnrIntegration;->w:Lio/sentry/android/core/a;

    .line 61
    .line 62
    invoke-virtual {v5}, Ljava/lang/Thread;->start()V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    const-string v0, "AnrIntegration installed."

    .line 70
    .line 71
    const/4 v3, 0x0

    .line 72
    new-array v3, v3, [Ljava/lang/Object;

    .line 73
    .line 74
    invoke-interface {p1, v2, v0, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_4c
    .catchall {:try_start_6 .. :try_end_4c} :catchall_4d

    .line 75
    .line 76
    .line 77
    goto :goto_50

    .line 78
    :catchall_4d
    move-exception v0

    .line 79
    move-object p1, v0

    .line 80
    goto :goto_54

    .line 81
    :cond_50
    :goto_50
    invoke-virtual {v1}, Lio/sentry/s;->close()V

    .line 82
    .line 83
    .line 84
    return-void

    .line 85
    :goto_54
    :try_start_54
    invoke-virtual {v1}, Lio/sentry/s;->close()V
    :try_end_57
    .catchall {:try_start_54 .. :try_end_57} :catchall_58

    .line 86
    .line 87
    .line 88
    goto :goto_5c

    .line 89
    :catchall_58
    move-exception v0

    .line 90
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 91
    .line 92
    .line 93
    :goto_5c
    throw p1
.end method

.method public final close()V
    .registers 6

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/AnrIntegration;->i:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x1

    .line 8
    :try_start_7
    iput-boolean v1, p0, Lio/sentry/android/core/AnrIntegration;->e:Z
    :try_end_9
    .catchall {:try_start_7 .. :try_end_9} :catchall_3e

    .line 9
    .line 10
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lio/sentry/android/core/AnrIntegration;->x:Lio/sentry/util/a;

    .line 14
    .line 15
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    :try_start_12
    sget-object v1, Lio/sentry/android/core/AnrIntegration;->w:Lio/sentry/android/core/a;

    .line 20
    .line 21
    if-eqz v1, :cond_31

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    sput-object v1, Lio/sentry/android/core/AnrIntegration;->w:Lio/sentry/android/core/a;

    .line 28
    .line 29
    iget-object v1, p0, Lio/sentry/android/core/AnrIntegration;->v:Lio/sentry/a6;

    .line 30
    .line 31
    if-eqz v1, :cond_31

    .line 32
    .line 33
    invoke-virtual {v1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    sget-object v2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 38
    .line 39
    const-string v3, "AnrIntegration removed."

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    new-array v4, v4, [Ljava/lang/Object;

    .line 43
    .line 44
    invoke-interface {v1, v2, v3, v4}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2e
    .catchall {:try_start_12 .. :try_end_2e} :catchall_2f

    .line 45
    .line 46
    .line 47
    goto :goto_31

    .line 48
    :catchall_2f
    move-exception v1

    .line 49
    goto :goto_35

    .line 50
    :cond_31
    :goto_31
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :goto_35
    :try_start_35
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_38
    .catchall {:try_start_35 .. :try_end_38} :catchall_39

    .line 55
    .line 56
    .line 57
    goto :goto_3d

    .line 58
    :catchall_39
    move-exception v0

    .line 59
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 60
    .line 61
    .line 62
    :goto_3d
    throw v1

    .line 63
    :catchall_3e
    move-exception v1

    .line 64
    :try_start_3f
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_42
    .catchall {:try_start_3f .. :try_end_42} :catchall_43

    .line 65
    .line 66
    .line 67
    goto :goto_47

    .line 68
    :catchall_43
    move-exception v0

    .line 69
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 70
    .line 71
    .line 72
    :goto_47
    throw v1
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 6

    .line 1
    iput-object p1, p0, Lio/sentry/android/core/AnrIntegration;->v:Lio/sentry/a6;

    .line 2
    .line 3
    check-cast p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 4
    .line 5
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 10
    .line 11
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isAnrEnabled()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const-string v3, "AnrIntegration enabled: %s"

    .line 24
    .line 25
    invoke-interface {v0, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isAnrEnabled()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_41

    .line 33
    .line 34
    const-string v0, "Anr"

    .line 35
    .line 36
    invoke-static {v0}, Loq/a;->d(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    :try_start_26
    invoke-virtual {p1}, Lio/sentry/a6;->getExecutorService()Lio/sentry/d1;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    new-instance v1, Lf4/q0;

    .line 44
    .line 45
    const/16 v2, 0xe

    .line 46
    .line 47
    invoke-direct {v1, v2, p0, p1}, Lf4/q0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    invoke-interface {v0, v1}, Lio/sentry/d1;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    :try_end_34
    .catchall {:try_start_26 .. :try_end_34} :catchall_35

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :catchall_35
    move-exception v0

    .line 55
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 60
    .line 61
    const-string v2, "Failed to start AnrIntegration on executor thread."

    .line 62
    .line 63
    invoke-interface {p1, v1, v2, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 64
    .line 65
    .line 66
    :cond_41
    return-void
.end method
