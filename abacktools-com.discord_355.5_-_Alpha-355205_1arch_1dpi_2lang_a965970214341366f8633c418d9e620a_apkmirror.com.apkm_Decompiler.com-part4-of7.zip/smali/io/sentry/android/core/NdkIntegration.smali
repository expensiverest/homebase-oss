###### Class io.sentry.android.core.NdkIntegration (io.sentry.android.core.NdkIntegration)
.class public final Lio/sentry/android/core/NdkIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Ljava/io/Closeable;


# instance fields
.field public final d:Ljava/lang/Class;

.field public e:Lio/sentry/android/core/SentryAndroidOptions;


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/NdkIntegration;->d:Ljava/lang/Class;

    .line 5
    .line 6
    return-void
.end method

.method public static c(Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Lio/sentry/android/core/SentryAndroidOptions;->setEnableNdk(Z)V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, v0}, Lio/sentry/android/core/SentryAndroidOptions;->setEnableScopeSync(Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final close()V
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    if-eqz v0, :cond_5b

    .line 4
    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableNdk()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_5b

    .line 10
    .line 11
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->d:Ljava/lang/Class;

    .line 12
    .line 13
    if-eqz v0, :cond_5b

    .line 14
    .line 15
    :try_start_e
    const-string v1, "close"

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0, v2, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 26
    .line 27
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 32
    .line 33
    const-string v2, "NdkIntegration removed."

    .line 34
    .line 35
    const/4 v3, 0x0

    .line 36
    new-array v3, v3, [Ljava/lang/Object;

    .line 37
    .line 38
    invoke-interface {v0, v1, v2, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_28
    .catch Ljava/lang/NoSuchMethodException; {:try_start_e .. :try_end_28} :catch_30
    .catchall {:try_start_e .. :try_end_28} :catchall_2e

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 42
    .line 43
    invoke-static {v0}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :catchall_2e
    move-exception v0

    .line 48
    goto :goto_32

    .line 49
    :catch_30
    move-exception v0

    .line 50
    goto :goto_47

    .line 51
    :goto_32
    :try_start_32
    iget-object v1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 52
    .line 53
    invoke-virtual {v1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    sget-object v2, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 58
    .line 59
    const-string v3, "Failed to close SentryNdk."

    .line 60
    .line 61
    invoke-interface {v1, v2, v3, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_3f
    .catchall {:try_start_32 .. :try_end_3f} :catchall_45

    .line 62
    .line 63
    .line 64
    :goto_3f
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 65
    .line 66
    invoke-static {v0}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 67
    .line 68
    .line 69
    goto :goto_5b

    .line 70
    :catchall_45
    move-exception v0

    .line 71
    goto :goto_55

    .line 72
    :goto_47
    :try_start_47
    iget-object v1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 73
    .line 74
    invoke-virtual {v1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    sget-object v2, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 79
    .line 80
    const-string v3, "Failed to invoke the SentryNdk.close method."

    .line 81
    .line 82
    invoke-interface {v1, v2, v3, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_54
    .catchall {:try_start_47 .. :try_end_54} :catchall_45

    .line 83
    .line 84
    .line 85
    goto :goto_3f

    .line 86
    :goto_55
    iget-object v1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 87
    .line 88
    invoke-static {v1}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 89
    .line 90
    .line 91
    throw v0

    .line 92
    :cond_5b
    :goto_5b
    return-void
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 7

    .line 1
    instance-of v0, p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_8

    .line 5
    .line 6
    check-cast p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 7
    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move-object p1, v1

    .line 10
    :goto_9
    const-string v0, "SentryAndroidOptions is required"

    .line 11
    .line 12
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 16
    .line 17
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableNdk()Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 22
    .line 23
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sget-object v2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 28
    .line 29
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    const-string v4, "NdkIntegration enabled: %s"

    .line 38
    .line 39
    invoke-interface {v0, v2, v4, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    if-eqz p1, :cond_9f

    .line 43
    .line 44
    iget-object p1, p0, Lio/sentry/android/core/NdkIntegration;->d:Ljava/lang/Class;

    .line 45
    .line 46
    if-eqz p1, :cond_9f

    .line 47
    .line 48
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 49
    .line 50
    invoke-virtual {v0}, Lio/sentry/a6;->getCacheDirPath()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    const/4 v3, 0x0

    .line 55
    if-nez v0, :cond_4d

    .line 56
    .line 57
    iget-object p1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 58
    .line 59
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    sget-object v0, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 64
    .line 65
    const-string v1, "No cache dir path is defined in options."

    .line 66
    .line 67
    new-array v2, v3, [Ljava/lang/Object;

    .line 68
    .line 69
    invoke-interface {p1, v0, v1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    iget-object p1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 73
    .line 74
    invoke-static {p1}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_4d
    :try_start_4d
    const-string v0, "init"

    .line 79
    .line 80
    const-class v4, Lio/sentry/android/core/SentryAndroidOptions;

    .line 81
    .line 82
    filled-new-array {v4}, [Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-virtual {p1, v0, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 91
    .line 92
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {p1, v1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    iget-object p1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 100
    .line 101
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    const-string v0, "NdkIntegration installed."

    .line 106
    .line 107
    new-array v1, v3, [Ljava/lang/Object;

    .line 108
    .line 109
    invoke-interface {p1, v2, v0, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    const-string p1, "Ndk"

    .line 113
    .line 114
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V
    :try_end_74
    .catch Ljava/lang/NoSuchMethodException; {:try_start_4d .. :try_end_74} :catch_77
    .catchall {:try_start_4d .. :try_end_74} :catchall_75

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    :catchall_75
    move-exception p1

    .line 119
    goto :goto_79

    .line 120
    :catch_77
    move-exception p1

    .line 121
    goto :goto_8c

    .line 122
    :goto_79
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 123
    .line 124
    invoke-static {v0}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 125
    .line 126
    .line 127
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 128
    .line 129
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    sget-object v1, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 134
    .line 135
    const-string v2, "Failed to initialize SentryNdk."

    .line 136
    .line 137
    invoke-interface {v0, v1, v2, p1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 138
    .line 139
    .line 140
    goto :goto_9e

    .line 141
    :goto_8c
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 142
    .line 143
    invoke-static {v0}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 144
    .line 145
    .line 146
    iget-object v0, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 147
    .line 148
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    sget-object v1, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 153
    .line 154
    const-string v2, "Failed to invoke the SentryNdk.init method."

    .line 155
    .line 156
    invoke-interface {v0, v1, v2, p1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 157
    .line 158
    .line 159
    :goto_9e
    return-void

    .line 160
    :cond_9f
    iget-object p1, p0, Lio/sentry/android/core/NdkIntegration;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 161
    .line 162
    invoke-static {p1}, Lio/sentry/android/core/NdkIntegration;->c(Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 163
    .line 164
    .line 165
    return-void
.end method
