###### Class io.sentry.android.core.b0 (io.sentry.android.core.b0)
.class public interface abstract Lio/sentry/android/core/b0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c()V
.end method

.method public abstract d()V
.end method
