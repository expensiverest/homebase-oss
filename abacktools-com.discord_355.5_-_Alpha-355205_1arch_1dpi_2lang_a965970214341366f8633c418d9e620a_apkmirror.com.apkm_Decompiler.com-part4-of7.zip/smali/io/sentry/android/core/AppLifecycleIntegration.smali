###### Class io.sentry.android.core.AppLifecycleIntegration (io.sentry.android.core.AppLifecycleIntegration)
.class public final Lio/sentry/android/core/AppLifecycleIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Ljava/io/Closeable;


# instance fields
.field public final d:Lio/sentry/util/a;

.field public volatile e:Lio/sentry/android/core/w0;

.field public i:Lio/sentry/android/core/SentryAndroidOptions;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lio/sentry/util/a;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->d:Lio/sentry/util/a;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final close()V
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->d:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    iget-object v1, p0, Lio/sentry/android/core/AppLifecycleIntegration;->e:Lio/sentry/android/core/w0;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    iput-object v2, p0, Lio/sentry/android/core/AppLifecycleIntegration;->e:Lio/sentry/android/core/w0;
    :try_end_b
    .catchall {:try_start_6 .. :try_end_b} :catchall_2d

    .line 11
    .line 12
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 13
    .line 14
    .line 15
    if-eqz v1, :cond_27

    .line 16
    .line 17
    sget-object v0, Lio/sentry/android/core/e0;->w:Lio/sentry/android/core/e0;

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Lio/sentry/android/core/e0;->i(Lio/sentry/android/core/b0;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 23
    .line 24
    if-eqz v0, :cond_27

    .line 25
    .line 26
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    new-array v2, v2, [Ljava/lang/Object;

    .line 34
    .line 35
    const-string v3, "AppLifecycleIntegration removed."

    .line 36
    .line 37
    invoke-interface {v0, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_27
    sget-object v0, Lio/sentry/android/core/e0;->w:Lio/sentry/android/core/e0;

    .line 41
    .line 42
    invoke-virtual {v0}, Lio/sentry/android/core/e0;->j()V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :catchall_2d
    move-exception v1

    .line 47
    :try_start_2e
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_31
    .catchall {:try_start_2e .. :try_end_31} :catchall_32

    .line 48
    .line 49
    .line 50
    goto :goto_36

    .line 51
    :catchall_32
    move-exception v0

    .line 52
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 53
    .line 54
    .line 55
    :goto_36
    throw v1
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 9

    .line 1
    instance-of v0, p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lio/sentry/android/core/SentryAndroidOptions;

    .line 7
    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    const-string v1, "SentryAndroidOptions is required"

    .line 11
    .line 12
    invoke-static {v0, v1}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 22
    .line 23
    iget-object v2, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 24
    .line 25
    invoke-virtual {v2}, Lio/sentry/a6;->isEnableAutoSessionTracking()Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    const-string v3, "enableSessionTracking enabled: %s"

    .line 38
    .line 39
    invoke-interface {v0, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 43
    .line 44
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iget-object v2, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 49
    .line 50
    invoke-virtual {v2}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableAppLifecycleBreadcrumbs()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    const-string v3, "enableAppLifecycleBreadcrumbs enabled: %s"

    .line 63
    .line 64
    invoke-interface {v0, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    iget-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 68
    .line 69
    invoke-virtual {v0}, Lio/sentry/a6;->isEnableAutoSessionTracking()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-nez v0, :cond_54

    .line 74
    .line 75
    iget-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 76
    .line 77
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableAppLifecycleBreadcrumbs()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_53

    .line 82
    .line 83
    goto :goto_54

    .line 84
    :cond_53
    return-void

    .line 85
    :cond_54
    :goto_54
    iget-object v0, p0, Lio/sentry/android/core/AppLifecycleIntegration;->d:Lio/sentry/util/a;

    .line 86
    .line 87
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    :try_start_5a
    iget-object v2, p0, Lio/sentry/android/core/AppLifecycleIntegration;->e:Lio/sentry/android/core/w0;
    :try_end_5c
    .catchall {:try_start_5a .. :try_end_5c} :catchall_97

    .line 92
    .line 93
    if-eqz v2, :cond_62

    .line 94
    .line 95
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :cond_62
    :try_start_62
    new-instance v2, Lio/sentry/android/core/w0;

    .line 100
    .line 101
    iget-object v3, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 102
    .line 103
    invoke-virtual {v3}, Lio/sentry/a6;->getSessionTrackingIntervalMillis()J

    .line 104
    .line 105
    .line 106
    move-result-wide v3

    .line 107
    iget-object v5, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 108
    .line 109
    invoke-virtual {v5}, Lio/sentry/a6;->isEnableAutoSessionTracking()Z

    .line 110
    .line 111
    .line 112
    move-result v5

    .line 113
    iget-object v6, p0, Lio/sentry/android/core/AppLifecycleIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 114
    .line 115
    invoke-virtual {v6}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableAppLifecycleBreadcrumbs()Z

    .line 116
    .line 117
    .line 118
    move-result v6

    .line 119
    invoke-direct {v2, v3, v4, v5, v6}, Lio/sentry/android/core/w0;-><init>(JZZ)V

    .line 120
    .line 121
    .line 122
    iput-object v2, p0, Lio/sentry/android/core/AppLifecycleIntegration;->e:Lio/sentry/android/core/w0;

    .line 123
    .line 124
    sget-object v2, Lio/sentry/android/core/e0;->w:Lio/sentry/android/core/e0;

    .line 125
    .line 126
    iget-object v3, p0, Lio/sentry/android/core/AppLifecycleIntegration;->e:Lio/sentry/android/core/w0;

    .line 127
    .line 128
    invoke-virtual {v2, v3}, Lio/sentry/android/core/e0;->c(Lio/sentry/android/core/b0;)V
    :try_end_82
    .catchall {:try_start_62 .. :try_end_82} :catchall_97

    .line 129
    .line 130
    .line 131
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 132
    .line 133
    .line 134
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    const/4 v0, 0x0

    .line 139
    new-array v0, v0, [Ljava/lang/Object;

    .line 140
    .line 141
    const-string v2, "AppLifecycleIntegration installed."

    .line 142
    .line 143
    invoke-interface {p1, v1, v2, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    const-string p1, "AppLifecycle"

    .line 147
    .line 148
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    return-void

    .line 152
    :catchall_97
    move-exception p1

    .line 153
    :try_start_98
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_9b
    .catchall {:try_start_98 .. :try_end_9b} :catchall_9c

    .line 154
    .line 155
    .line 156
    goto :goto_a0

    .line 157
    :catchall_9c
    move-exception v0

    .line 158
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 159
    .line 160
    .line 161
    :goto_a0
    throw p1
.end method
