###### Class io.sentry.android.core.d0 (io.sentry.android.core.d0)
.class public final Lio/sentry/android/core/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/DefaultLifecycleObserver;


# instance fields
.field public final d:Lio/sentry/android/core/c0;

.field public final synthetic e:Lio/sentry/android/core/e0;


# direct methods
.method public constructor <init>(Lio/sentry/android/core/e0;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/d0;->e:Lio/sentry/android/core/e0;

    .line 5
    .line 6
    new-instance p1, Lio/sentry/android/core/c0;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p1, v0, p0}, Lio/sentry/android/core/c0;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lio/sentry/android/core/d0;->d:Lio/sentry/android/core/c0;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final onStart(Landroidx/lifecycle/v;)V
    .registers 3

    .line 1
    iget-object p1, p0, Lio/sentry/android/core/d0;->e:Lio/sentry/android/core/e0;

    .line 2
    .line 3
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 4
    .line 5
    iput-object v0, p1, Lio/sentry/android/core/e0;->v:Ljava/lang/Boolean;

    .line 6
    .line 7
    iget-object p1, p0, Lio/sentry/android/core/d0;->d:Lio/sentry/android/core/c0;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    :goto_c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1c

    .line 18
    .line 19
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lio/sentry/android/core/b0;

    .line 24
    .line 25
    invoke-interface {v0}, Lio/sentry/android/core/b0;->c()V

    .line 26
    .line 27
    .line 28
    goto :goto_c

    .line 29
    :cond_1c
    return-void
.end method

.method public final onStop(Landroidx/lifecycle/v;)V
    .registers 3

    .line 1
    iget-object p1, p0, Lio/sentry/android/core/d0;->e:Lio/sentry/android/core/e0;

    .line 2
    .line 3
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 4
    .line 5
    iput-object v0, p1, Lio/sentry/android/core/e0;->v:Ljava/lang/Boolean;

    .line 6
    .line 7
    iget-object p1, p0, Lio/sentry/android/core/d0;->d:Lio/sentry/android/core/c0;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    :goto_c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1c

    .line 18
    .line 19
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lio/sentry/android/core/b0;

    .line 24
    .line 25
    invoke-interface {v0}, Lio/sentry/android/core/b0;->d()V

    .line 26
    .line 27
    .line 28
    goto :goto_c

    .line 29
    :cond_1c
    return-void
.end method
