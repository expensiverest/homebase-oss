###### Class io.sentry.android.core.f0 (io.sentry.android.core.f0)
.class public final Lio/sentry/android/core/f0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lio/sentry/android/core/g0;


# direct methods
.method public constructor <init>(Lio/sentry/android/core/g0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/f0;->a:Lio/sentry/android/core/g0;

    .line 5
    .line 6
    return-void
.end method
