###### Class io.sentry.android.core.cache.a (io.sentry.android.core.cache.a)
.class public final Lio/sentry/android/core/cache/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Class;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Lio/sentry/p2;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;Lio/sentry/p2;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/cache/a;->a:Ljava/lang/Class;

    .line 5
    .line 6
    iput-object p2, p0, Lio/sentry/android/core/cache/a;->b:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Lio/sentry/android/core/cache/a;->c:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lio/sentry/android/core/cache/a;->d:Lio/sentry/p2;

    .line 11
    .line 12
    return-void
.end method
