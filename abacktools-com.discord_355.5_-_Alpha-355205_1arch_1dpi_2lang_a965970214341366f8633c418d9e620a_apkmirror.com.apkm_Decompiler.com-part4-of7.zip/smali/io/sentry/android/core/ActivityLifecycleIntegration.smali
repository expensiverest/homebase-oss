###### Class io.sentry.android.core.ActivityLifecycleIntegration (io.sentry.android.core.ActivityLifecycleIntegration)
.class public final Lio/sentry/android/core/ActivityLifecycleIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Ljava/io/Closeable;
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# instance fields
.field public J:Z

.field public K:Lio/sentry/g0;

.field public L:Lio/sentry/h1;

.field public final M:Ljava/util/WeakHashMap;

.field public final N:Ljava/util/WeakHashMap;

.field public final O:Ljava/util/WeakHashMap;

.field public P:Lio/sentry/l4;

.field public Q:Ljava/util/concurrent/Future;

.field public final R:Ljava/util/WeakHashMap;

.field public final S:Lp/r3;

.field public final T:Lio/sentry/util/a;

.field public final U:Lio/sentry/util/a;

.field public final d:Landroid/app/Application;

.field public final e:Lio/sentry/android/core/j0;

.field public i:Lio/sentry/z3;

.field public v:Lio/sentry/android/core/SentryAndroidOptions;

.field public w:Z

.field public x:Z

.field public final y:Z


# direct methods
.method public constructor <init>(Landroid/app/Application;Lio/sentry/android/core/j0;Lp/r3;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 6
    .line 7
    iput-boolean v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->x:Z

    .line 8
    .line 9
    iput-boolean v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->K:Lio/sentry/g0;

    .line 13
    .line 14
    new-instance v1, Ljava/util/WeakHashMap;

    .line 15
    .line 16
    invoke-direct {v1}, Ljava/util/WeakHashMap;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->M:Ljava/util/WeakHashMap;

    .line 20
    .line 21
    new-instance v1, Ljava/util/WeakHashMap;

    .line 22
    .line 23
    invoke-direct {v1}, Ljava/util/WeakHashMap;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->N:Ljava/util/WeakHashMap;

    .line 27
    .line 28
    new-instance v1, Ljava/util/WeakHashMap;

    .line 29
    .line 30
    invoke-direct {v1}, Ljava/util/WeakHashMap;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->O:Ljava/util/WeakHashMap;

    .line 34
    .line 35
    new-instance v1, Lio/sentry/i5;

    .line 36
    .line 37
    new-instance v2, Ljava/util/Date;

    .line 38
    .line 39
    const-wide/16 v3, 0x0

    .line 40
    .line 41
    invoke-direct {v2, v3, v4}, Ljava/util/Date;-><init>(J)V

    .line 42
    .line 43
    .line 44
    invoke-direct {v1, v2, v3, v4}, Lio/sentry/i5;-><init>(Ljava/util/Date;J)V

    .line 45
    .line 46
    .line 47
    iput-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->P:Lio/sentry/l4;

    .line 48
    .line 49
    iput-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->Q:Ljava/util/concurrent/Future;

    .line 50
    .line 51
    new-instance v0, Ljava/util/WeakHashMap;

    .line 52
    .line 53
    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    .line 54
    .line 55
    .line 56
    iput-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->R:Ljava/util/WeakHashMap;

    .line 57
    .line 58
    new-instance v0, Lio/sentry/util/a;

    .line 59
    .line 60
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 61
    .line 62
    .line 63
    iput-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->T:Lio/sentry/util/a;

    .line 64
    .line 65
    new-instance v0, Lio/sentry/util/a;

    .line 66
    .line 67
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 68
    .line 69
    .line 70
    iput-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->U:Lio/sentry/util/a;

    .line 71
    .line 72
    const-string v0, "Application is required"

    .line 73
    .line 74
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    iput-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->d:Landroid/app/Application;

    .line 78
    .line 79
    iput-object p2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->e:Lio/sentry/android/core/j0;

    .line 80
    .line 81
    iput-object p3, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->S:Lp/r3;

    .line 82
    .line 83
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 84
    .line 85
    const/16 p2, 0x1d

    .line 86
    .line 87
    if-lt p1, p2, :cond_5b

    .line 88
    .line 89
    const/4 p1, 0x1

    .line 90
    iput-boolean p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->y:Z

    .line 91
    .line 92
    :cond_5b
    return-void
.end method

.method public static d(Lio/sentry/h1;Lio/sentry/h1;)V
    .registers 5

    .line 1
    if-eqz p0, :cond_42

    .line 2
    .line 3
    invoke-interface {p0}, Lio/sentry/h1;->isFinished()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 8
    .line 9
    goto :goto_42

    .line 10
    :cond_9
    invoke-interface {p0}, Lio/sentry/h1;->getDescription()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, " - Deadline Exceeded"

    .line 15
    .line 16
    if-eqz v0, :cond_18

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-eqz v2, :cond_18

    .line 23
    .line 24
    goto :goto_2b

    .line 25
    :cond_18
    new-instance v0, Ljava/lang/StringBuilder;

    .line 26
    .line 27
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 28
    .line 29
    .line 30
    invoke-interface {p0}, Lio/sentry/h1;->getDescription()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    :goto_2b
    invoke-interface {p0, v0}, Lio/sentry/h1;->j(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    if-eqz p1, :cond_35

    .line 48
    .line 49
    invoke-interface {p1}, Lio/sentry/h1;->p()Lio/sentry/l4;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    goto :goto_36

    .line 54
    :cond_35
    const/4 p1, 0x0

    .line 55
    :goto_36
    if-eqz p1, :cond_39

    .line 56
    .line 57
    goto :goto_3d

    .line 58
    :cond_39
    invoke-interface {p0}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    :goto_3d
    sget-object v0, Lio/sentry/p6;->DEADLINE_EXCEEDED:Lio/sentry/p6;

    .line 63
    .line 64
    invoke-static {p0, p1, v0}, Lio/sentry/android/core/ActivityLifecycleIntegration;->g(Lio/sentry/h1;Lio/sentry/l4;Lio/sentry/p6;)V

    .line 65
    .line 66
    .line 67
    :cond_42
    :goto_42
    return-void
.end method

.method public static g(Lio/sentry/h1;Lio/sentry/l4;Lio/sentry/p6;)V
    .registers 4

    .line 1
    if-eqz p0, :cond_1b

    .line 2
    .line 3
    invoke-interface {p0}, Lio/sentry/h1;->isFinished()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_1b

    .line 8
    .line 9
    if-eqz p2, :cond_b

    .line 10
    .line 11
    goto :goto_18

    .line 12
    :cond_b
    invoke-interface {p0}, Lio/sentry/h1;->b()Lio/sentry/p6;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    if-eqz p2, :cond_16

    .line 17
    .line 18
    invoke-interface {p0}, Lio/sentry/h1;->b()Lio/sentry/p6;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    goto :goto_18

    .line 23
    :cond_16
    sget-object p2, Lio/sentry/p6;->OK:Lio/sentry/p6;

    .line 24
    .line 25
    :goto_18
    invoke-interface {p0, p2, p1}, Lio/sentry/h1;->q(Lio/sentry/p6;Lio/sentry/l4;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void
.end method


# virtual methods
.method public final c()V
    .registers 8

    .line 1
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lio/sentry/android/core/performance/g;->b(Lio/sentry/android/core/SentryAndroidOptions;)Lio/sentry/android/core/performance/h;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-wide v1, v0, Lio/sentry/android/core/performance/h;->v:J

    .line 12
    .line 13
    const-wide/16 v3, 0x0

    .line 14
    .line 15
    cmp-long v1, v1, v3

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    if-eqz v1, :cond_2a

    .line 19
    .line 20
    new-instance v1, Lio/sentry/f5;

    .line 21
    .line 22
    invoke-virtual {v0}, Lio/sentry/android/core/performance/h;->c()Z

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    if-eqz v5, :cond_22

    .line 27
    .line 28
    iget-wide v3, v0, Lio/sentry/android/core/performance/h;->e:J

    .line 29
    .line 30
    invoke-virtual {v0}, Lio/sentry/android/core/performance/h;->a()J

    .line 31
    .line 32
    .line 33
    move-result-wide v5

    .line 34
    add-long/2addr v3, v5

    .line 35
    :cond_22
    const-wide/32 v5, 0xf4240

    .line 36
    .line 37
    .line 38
    mul-long/2addr v3, v5

    .line 39
    invoke-direct {v1, v3, v4}, Lio/sentry/f5;-><init>(J)V

    .line 40
    .line 41
    .line 42
    goto :goto_2b

    .line 43
    :cond_2a
    move-object v1, v2

    .line 44
    :goto_2b
    iget-boolean v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 45
    .line 46
    if-eqz v0, :cond_36

    .line 47
    .line 48
    if-eqz v1, :cond_36

    .line 49
    .line 50
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->L:Lio/sentry/h1;

    .line 51
    .line 52
    invoke-static {v0, v1, v2}, Lio/sentry/android/core/ActivityLifecycleIntegration;->g(Lio/sentry/h1;Lio/sentry/l4;Lio/sentry/p6;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    return-void
.end method

.method public final close()V
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->d:Landroid/app/Application;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 7
    .line 8
    if-eqz v0, :cond_17

    .line 9
    .line 10
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    new-array v2, v2, [Ljava/lang/Object;

    .line 18
    .line 19
    const-string v3, "ActivityLifecycleIntegration removed."

    .line 20
    .line 21
    invoke-interface {v0, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->S:Lp/r3;

    .line 25
    .line 26
    iget-object v1, v0, Lp/r3;->y:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, Lio/sentry/util/a;

    .line 29
    .line 30
    invoke-virtual {v1}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    :try_start_21
    invoke-virtual {v0}, Lp/r3;->h()Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_4a

    .line 39
    .line 40
    new-instance v2, Le/k;

    .line 41
    .line 42
    const/16 v3, 0xf

    .line 43
    .line 44
    invoke-direct {v2, v3, v0}, Le/k;-><init>(ILjava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    const-string v3, "FrameMetricsAggregator.stop"

    .line 48
    .line 49
    invoke-virtual {v0, v2, v3}, Lp/r3;->n(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    iget-object v2, v0, Lp/r3;->e:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v2, Lio/sentry/util/e;

    .line 55
    .line 56
    invoke-virtual {v2}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    check-cast v2, Landroidx/core/app/FrameMetricsAggregator;

    .line 61
    .line 62
    iget-object v2, v2, Landroidx/core/app/FrameMetricsAggregator;->a:Lqt/p;

    .line 63
    .line 64
    iget-object v3, v2, Lqt/p;->b:Ljava/lang/Object;

    .line 65
    .line 66
    const/16 v3, 0x9

    .line 67
    .line 68
    new-array v3, v3, [Landroid/util/SparseIntArray;

    .line 69
    .line 70
    iput-object v3, v2, Lqt/p;->b:Ljava/lang/Object;

    .line 71
    .line 72
    goto :goto_4a

    .line 73
    :catchall_48
    move-exception v0

    .line 74
    goto :goto_55

    .line 75
    :cond_4a
    :goto_4a
    iget-object v0, v0, Lp/r3;->v:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 78
    .line 79
    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V
    :try_end_51
    .catchall {:try_start_21 .. :try_end_51} :catchall_48

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1}, Lio/sentry/s;->close()V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :goto_55
    :try_start_55
    invoke-virtual {v1}, Lio/sentry/s;->close()V
    :try_end_58
    .catchall {:try_start_55 .. :try_end_58} :catchall_59

    .line 87
    .line 88
    .line 89
    goto :goto_5d

    .line 90
    :catchall_59
    move-exception v1

    .line 91
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 92
    .line 93
    .line 94
    :goto_5d
    throw v0
.end method

.method public final i(Lio/sentry/j1;Lio/sentry/h1;Lio/sentry/h1;)V
    .registers 6

    .line 1
    if-eqz p1, :cond_3b

    .line 2
    .line 3
    invoke-interface {p1}, Lio/sentry/h1;->isFinished()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 8
    .line 9
    goto :goto_3b

    .line 10
    :cond_9
    sget-object v0, Lio/sentry/p6;->DEADLINE_EXCEEDED:Lio/sentry/p6;

    .line 11
    .line 12
    if-eqz p2, :cond_16

    .line 13
    .line 14
    invoke-interface {p2}, Lio/sentry/h1;->isFinished()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-nez v1, :cond_16

    .line 19
    .line 20
    invoke-interface {p2, v0}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 21
    .line 22
    .line 23
    :cond_16
    invoke-static {p3, p2}, Lio/sentry/android/core/ActivityLifecycleIntegration;->d(Lio/sentry/h1;Lio/sentry/h1;)V

    .line 24
    .line 25
    .line 26
    iget-object p2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->Q:Ljava/util/concurrent/Future;

    .line 27
    .line 28
    const/4 p3, 0x0

    .line 29
    if-eqz p2, :cond_24

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    invoke-interface {p2, v0}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 33
    .line 34
    .line 35
    iput-object p3, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->Q:Ljava/util/concurrent/Future;

    .line 36
    .line 37
    :cond_24
    invoke-interface {p1}, Lio/sentry/h1;->b()Lio/sentry/p6;

    .line 38
    .line 39
    .line 40
    move-result-object p2

    .line 41
    if-nez p2, :cond_2c

    .line 42
    .line 43
    sget-object p2, Lio/sentry/p6;->OK:Lio/sentry/p6;

    .line 44
    .line 45
    :cond_2c
    invoke-interface {p1, p2}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 46
    .line 47
    .line 48
    iget-object p2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 49
    .line 50
    if-eqz p2, :cond_3b

    .line 51
    .line 52
    new-instance p2, Lapp/rive/runtime/kotlin/a;

    .line 53
    .line 54
    invoke-direct {p2, p0, p1}, Lapp/rive/runtime/kotlin/a;-><init>(Lio/sentry/android/core/ActivityLifecycleIntegration;Lio/sentry/j1;)V

    .line 55
    .line 56
    .line 57
    invoke-static {p3, p2}, Lio/sentry/f4;->d(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 58
    .line 59
    .line 60
    :cond_3b
    :goto_3b
    return-void
.end method

.method public final j(Lio/sentry/h1;Lio/sentry/h1;)V
    .registers 9

    .line 1
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p1, Lio/sentry/android/core/performance/g;->v:Lio/sentry/android/core/performance/h;

    .line 6
    .line 7
    iget-object p1, p1, Lio/sentry/android/core/performance/g;->w:Lio/sentry/android/core/performance/h;

    .line 8
    .line 9
    invoke-virtual {v0}, Lio/sentry/android/core/performance/h;->c()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const-wide/16 v2, 0x0

    .line 14
    .line 15
    if-eqz v1, :cond_1c

    .line 16
    .line 17
    iget-wide v4, v0, Lio/sentry/android/core/performance/h;->v:J

    .line 18
    .line 19
    cmp-long v1, v4, v2

    .line 20
    .line 21
    if-nez v1, :cond_1c

    .line 22
    .line 23
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 24
    .line 25
    .line 26
    move-result-wide v4

    .line 27
    iput-wide v4, v0, Lio/sentry/android/core/performance/h;->v:J

    .line 28
    .line 29
    :cond_1c
    invoke-virtual {p1}, Lio/sentry/android/core/performance/h;->c()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_2e

    .line 34
    .line 35
    iget-wide v0, p1, Lio/sentry/android/core/performance/h;->v:J

    .line 36
    .line 37
    cmp-long v0, v0, v2

    .line 38
    .line 39
    if-nez v0, :cond_2e

    .line 40
    .line 41
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 42
    .line 43
    .line 44
    move-result-wide v0

    .line 45
    iput-wide v0, p1, Lio/sentry/android/core/performance/h;->v:J

    .line 46
    .line 47
    :cond_2e
    invoke-virtual {p0}, Lio/sentry/android/core/ActivityLifecycleIntegration;->c()V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->U:Lio/sentry/util/a;

    .line 51
    .line 52
    invoke-virtual {p1}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    :try_start_37
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 57
    .line 58
    if-eqz v0, :cond_65

    .line 59
    .line 60
    if-eqz p2, :cond_65

    .line 61
    .line 62
    invoke-virtual {v0}, Lio/sentry/a6;->getDateProvider()Lio/sentry/m4;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-interface {v0}, Lio/sentry/m4;->now()Lio/sentry/l4;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-interface {p2}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    invoke-virtual {v0, v1}, Lio/sentry/l4;->b(Lio/sentry/l4;)J

    .line 75
    .line 76
    .line 77
    move-result-wide v1

    .line 78
    sget-object v3, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    .line 79
    .line 80
    invoke-virtual {v3, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 81
    .line 82
    .line 83
    move-result-wide v1

    .line 84
    const-string v3, "time_to_initial_display"

    .line 85
    .line 86
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    sget-object v2, Lio/sentry/e2;->MILLISECOND:Lio/sentry/e2;

    .line 91
    .line 92
    invoke-interface {p2, v3, v1, v2}, Lio/sentry/h1;->n(Ljava/lang/String;Ljava/lang/Long;Lio/sentry/f2;)V

    .line 93
    .line 94
    .line 95
    const/4 v1, 0x0

    .line 96
    invoke-static {p2, v0, v1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->g(Lio/sentry/h1;Lio/sentry/l4;Lio/sentry/p6;)V

    .line 97
    .line 98
    .line 99
    goto :goto_70

    .line 100
    :catchall_63
    move-exception p2

    .line 101
    goto :goto_74

    .line 102
    :cond_65
    if-eqz p2, :cond_70

    .line 103
    .line 104
    invoke-interface {p2}, Lio/sentry/h1;->isFinished()Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-nez v0, :cond_70

    .line 109
    .line 110
    invoke-interface {p2}, Lio/sentry/h1;->g()V
    :try_end_70
    .catchall {:try_start_37 .. :try_end_70} :catchall_63

    .line 111
    .line 112
    .line 113
    :cond_70
    :goto_70
    invoke-virtual {p1}, Lio/sentry/s;->close()V

    .line 114
    .line 115
    .line 116
    return-void

    .line 117
    :goto_74
    :try_start_74
    invoke-virtual {p1}, Lio/sentry/s;->close()V
    :try_end_77
    .catchall {:try_start_74 .. :try_end_77} :catchall_78

    .line 118
    .line 119
    .line 120
    goto :goto_7c

    .line 121
    :catchall_78
    move-exception p1

    .line 122
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 123
    .line 124
    .line 125
    :goto_7c
    throw p2
.end method

.method public final l(Landroid/app/Activity;)V
    .registers 24

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 6
    .line 7
    invoke-direct {v0, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    iget-object v3, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 11
    .line 12
    if-eqz v3, :cond_1b4

    .line 13
    .line 14
    iget-object v3, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->R:Ljava/util/WeakHashMap;

    .line 15
    .line 16
    invoke-virtual {v3, v2}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v4

    .line 20
    if-nez v4, :cond_1b4

    .line 21
    .line 22
    iget-boolean v4, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 23
    .line 24
    const/4 v5, 0x0

    .line 25
    if-nez v4, :cond_34

    .line 26
    .line 27
    sget-object v0, Lio/sentry/z2;->a:Lio/sentry/z2;

    .line 28
    .line 29
    invoke-virtual {v3, v2, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    iget-object v0, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 33
    .line 34
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableAutoTraceIdGeneration()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_1b4

    .line 39
    .line 40
    iget-object v0, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 41
    .line 42
    new-instance v2, Lio/sentry/p2;

    .line 43
    .line 44
    const/16 v3, 0x17

    .line 45
    .line 46
    invoke-direct {v2, v3}, Lio/sentry/p2;-><init>(I)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0, v5, v2}, Lio/sentry/z3;->q(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_34
    invoke-virtual {v3}, Ljava/util/WeakHashMap;->entrySet()Ljava/util/Set;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    :goto_3c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 62
    .line 63
    .line 64
    move-result v6

    .line 65
    iget-object v7, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->N:Ljava/util/WeakHashMap;

    .line 66
    .line 67
    iget-object v8, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->M:Ljava/util/WeakHashMap;

    .line 68
    .line 69
    if-eqz v6, :cond_6a

    .line 70
    .line 71
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    check-cast v6, Ljava/util/Map$Entry;

    .line 76
    .line 77
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v9

    .line 81
    check-cast v9, Lio/sentry/j1;

    .line 82
    .line 83
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v10

    .line 87
    invoke-virtual {v8, v10}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v8

    .line 91
    check-cast v8, Lio/sentry/h1;

    .line 92
    .line 93
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v6

    .line 97
    invoke-virtual {v7, v6}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v6

    .line 101
    check-cast v6, Lio/sentry/h1;

    .line 102
    .line 103
    invoke-virtual {v1, v9, v8, v6}, Lio/sentry/android/core/ActivityLifecycleIntegration;->i(Lio/sentry/j1;Lio/sentry/h1;Lio/sentry/h1;)V

    .line 104
    .line 105
    .line 106
    goto :goto_3c

    .line 107
    :cond_6a
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    move-result-object v4

    .line 111
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    iget-object v9, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 120
    .line 121
    invoke-virtual {v6, v9}, Lio/sentry/android/core/performance/g;->b(Lio/sentry/android/core/SentryAndroidOptions;)Lio/sentry/android/core/performance/h;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    invoke-static {}, Lio/sentry/android/core/k0;->i()Z

    .line 126
    .line 127
    .line 128
    move-result v9

    .line 129
    const/4 v10, 0x0

    .line 130
    const/4 v11, 0x1

    .line 131
    if-eqz v9, :cond_a1

    .line 132
    .line 133
    invoke-virtual {v6}, Lio/sentry/android/core/performance/h;->c()Z

    .line 134
    .line 135
    .line 136
    move-result v9

    .line 137
    if-eqz v9, :cond_a1

    .line 138
    .line 139
    invoke-virtual {v6}, Lio/sentry/android/core/performance/h;->b()Lio/sentry/f5;

    .line 140
    .line 141
    .line 142
    move-result-object v6

    .line 143
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 144
    .line 145
    .line 146
    move-result-object v9

    .line 147
    iget-object v9, v9, Lio/sentry/android/core/performance/g;->d:Lio/sentry/android/core/performance/f;

    .line 148
    .line 149
    sget-object v12, Lio/sentry/android/core/performance/f;->COLD:Lio/sentry/android/core/performance/f;

    .line 150
    .line 151
    if-ne v9, v12, :cond_9a

    .line 152
    .line 153
    move v9, v11

    .line 154
    goto :goto_9b

    .line 155
    :cond_9a
    move v9, v10

    .line 156
    :goto_9b
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 157
    .line 158
    .line 159
    move-result-object v9

    .line 160
    move-object v15, v6

    .line 161
    goto :goto_a3

    .line 162
    :cond_a1
    move-object v9, v5

    .line 163
    move-object v15, v9

    .line 164
    :goto_a3
    new-instance v6, Lio/sentry/u6;

    .line 165
    .line 166
    invoke-direct {v6}, Lio/sentry/u6;-><init>()V

    .line 167
    .line 168
    .line 169
    iget-object v12, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 170
    .line 171
    invoke-virtual {v12}, Lio/sentry/a6;->getDeadlineTimeout()J

    .line 172
    .line 173
    .line 174
    move-result-wide v12

    .line 175
    const-wide/16 v16, 0x0

    .line 176
    .line 177
    cmp-long v14, v12, v16

    .line 178
    .line 179
    if-gtz v14, :cond_b6

    .line 180
    .line 181
    move-object v12, v5

    .line 182
    goto :goto_ba

    .line 183
    :cond_b6
    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 184
    .line 185
    .line 186
    move-result-object v12

    .line 187
    :goto_ba
    iput-object v12, v6, Lio/sentry/u6;->J:Ljava/lang/Long;

    .line 188
    .line 189
    iget-object v12, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 190
    .line 191
    invoke-virtual {v12}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableActivityLifecycleTracingAutoFinish()Z

    .line 192
    .line 193
    .line 194
    move-result v12

    .line 195
    if-eqz v12, :cond_ce

    .line 196
    .line 197
    iget-object v12, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 198
    .line 199
    invoke-virtual {v12}, Lio/sentry/a6;->getIdleTimeout()Ljava/lang/Long;

    .line 200
    .line 201
    .line 202
    move-result-object v12

    .line 203
    iput-object v12, v6, Lio/sentry/u6;->y:Ljava/lang/Long;

    .line 204
    .line 205
    iput-boolean v11, v6, Lcom/google/firebase/messaging/o;->d:Z

    .line 206
    .line 207
    :cond_ce
    iput-boolean v11, v6, Lio/sentry/u6;->x:Z

    .line 208
    .line 209
    new-instance v12, Lio/sentry/android/core/e;

    .line 210
    .line 211
    invoke-direct {v12, v1, v0, v4}, Lio/sentry/android/core/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    iput-object v12, v6, Lio/sentry/u6;->K:Lio/sentry/android/core/e;

    .line 215
    .line 216
    iget-boolean v0, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 217
    .line 218
    if-nez v0, :cond_ee

    .line 219
    .line 220
    if-eqz v15, :cond_ee

    .line 221
    .line 222
    if-eqz v9, :cond_ee

    .line 223
    .line 224
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    iget-object v0, v0, Lio/sentry/android/core/performance/g;->M:Lf10/e;

    .line 229
    .line 230
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 231
    .line 232
    .line 233
    move-result-object v12

    .line 234
    iput-object v5, v12, Lio/sentry/android/core/performance/g;->M:Lf10/e;

    .line 235
    .line 236
    move-object v12, v0

    .line 237
    move-object v0, v15

    .line 238
    goto :goto_f1

    .line 239
    :cond_ee
    iget-object v0, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->P:Lio/sentry/l4;

    .line 240
    .line 241
    move-object v12, v5

    .line 242
    :goto_f1
    iput-object v0, v6, Lcom/google/firebase/messaging/o;->e:Ljava/lang/Object;

    .line 243
    .line 244
    if-eqz v12, :cond_f6

    .line 245
    .line 246
    move v10, v11

    .line 247
    :cond_f6
    iput-boolean v10, v6, Lio/sentry/u6;->w:Z

    .line 248
    .line 249
    const-string v10, "auto.ui.activity"

    .line 250
    .line 251
    iput-object v10, v6, Lcom/google/firebase/messaging/o;->v:Ljava/lang/Object;

    .line 252
    .line 253
    iget-object v11, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 254
    .line 255
    new-instance v13, Lio/sentry/t6;

    .line 256
    .line 257
    sget-object v14, Lio/sentry/protocol/h0;->COMPONENT:Lio/sentry/protocol/h0;

    .line 258
    .line 259
    const-string v5, "ui.load"

    .line 260
    .line 261
    invoke-direct {v13, v4, v14, v5, v12}, Lio/sentry/t6;-><init>(Ljava/lang/String;Lio/sentry/protocol/h0;Ljava/lang/String;Lf10/e;)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v11, v13, v6}, Lio/sentry/z3;->j(Lio/sentry/t6;Lio/sentry/u6;)Lio/sentry/j1;

    .line 265
    .line 266
    .line 267
    move-result-object v16

    .line 268
    new-instance v5, Lcom/google/firebase/messaging/o;

    .line 269
    .line 270
    const/4 v6, 0x4

    .line 271
    const/4 v11, 0x0

    .line 272
    invoke-direct {v5, v6, v11}, Lcom/google/firebase/messaging/o;-><init>(IZ)V

    .line 273
    .line 274
    .line 275
    iput-object v10, v5, Lcom/google/firebase/messaging/o;->v:Ljava/lang/Object;

    .line 276
    .line 277
    iget-boolean v6, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 278
    .line 279
    if-nez v6, :cond_14a

    .line 280
    .line 281
    if-eqz v15, :cond_14a

    .line 282
    .line 283
    if-eqz v9, :cond_14a

    .line 284
    .line 285
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 286
    .line 287
    .line 288
    move-result v6

    .line 289
    if-eqz v6, :cond_126

    .line 290
    .line 291
    const-string v6, "app.start.cold"

    .line 292
    .line 293
    :goto_124
    move-object v13, v6

    .line 294
    goto :goto_129

    .line 295
    :cond_126
    const-string v6, "app.start.warm"

    .line 296
    .line 297
    goto :goto_124

    .line 298
    :goto_129
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 299
    .line 300
    .line 301
    move-result v6

    .line 302
    if-eqz v6, :cond_135

    .line 303
    .line 304
    const-string v6, "Cold Start"

    .line 305
    .line 306
    :goto_131
    move-object v14, v6

    .line 307
    move-object/from16 v12, v16

    .line 308
    .line 309
    goto :goto_138

    .line 310
    :cond_135
    const-string v6, "Warm Start"

    .line 311
    .line 312
    goto :goto_131

    .line 313
    :goto_138
    sget-object v16, Lio/sentry/o1;->SENTRY:Lio/sentry/o1;

    .line 314
    .line 315
    move-object/from16 v17, v5

    .line 316
    .line 317
    invoke-interface/range {v12 .. v17}, Lio/sentry/h1;->r(Ljava/lang/String;Ljava/lang/String;Lio/sentry/l4;Lio/sentry/o1;Lcom/google/firebase/messaging/o;)Lio/sentry/h1;

    .line 318
    .line 319
    .line 320
    move-result-object v5

    .line 321
    move-object/from16 v16, v12

    .line 322
    .line 323
    move-object/from16 v21, v17

    .line 324
    .line 325
    iput-object v5, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->L:Lio/sentry/h1;

    .line 326
    .line 327
    invoke-virtual {v1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->c()V

    .line 328
    .line 329
    .line 330
    goto :goto_14c

    .line 331
    :cond_14a
    move-object/from16 v21, v5

    .line 332
    .line 333
    :goto_14c
    const-string v5, " initial display"

    .line 334
    .line 335
    invoke-virtual {v4, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 336
    .line 337
    .line 338
    move-result-object v18

    .line 339
    sget-object v20, Lio/sentry/o1;->SENTRY:Lio/sentry/o1;

    .line 340
    .line 341
    const-string v17, "ui.load.initial_display"

    .line 342
    .line 343
    move-object/from16 v19, v0

    .line 344
    .line 345
    invoke-interface/range {v16 .. v21}, Lio/sentry/h1;->r(Ljava/lang/String;Ljava/lang/String;Lio/sentry/l4;Lio/sentry/o1;Lcom/google/firebase/messaging/o;)Lio/sentry/h1;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    invoke-virtual {v8, v2, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    iget-boolean v5, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->x:Z

    .line 353
    .line 354
    if-eqz v5, :cond_19f

    .line 355
    .line 356
    iget-object v5, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->K:Lio/sentry/g0;

    .line 357
    .line 358
    if-eqz v5, :cond_19f

    .line 359
    .line 360
    iget-object v5, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 361
    .line 362
    if-eqz v5, :cond_19f

    .line 363
    .line 364
    const-string v5, " full display"

    .line 365
    .line 366
    invoke-virtual {v4, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v18

    .line 370
    const-string v17, "ui.load.full_display"

    .line 371
    .line 372
    invoke-interface/range {v16 .. v21}, Lio/sentry/h1;->r(Ljava/lang/String;Ljava/lang/String;Lio/sentry/l4;Lio/sentry/o1;Lcom/google/firebase/messaging/o;)Lio/sentry/h1;

    .line 373
    .line 374
    .line 375
    move-result-object v4

    .line 376
    move-object/from16 v12, v16

    .line 377
    .line 378
    :try_start_179
    invoke-virtual {v7, v2, v4}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    iget-object v5, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 382
    .line 383
    invoke-virtual {v5}, Lio/sentry/a6;->getExecutorService()Lio/sentry/d1;

    .line 384
    .line 385
    .line 386
    move-result-object v5

    .line 387
    new-instance v6, Lf4/q0;

    .line 388
    .line 389
    invoke-direct {v6, v1, v4, v0}, Lf4/q0;-><init>(Lio/sentry/android/core/ActivityLifecycleIntegration;Lio/sentry/h1;Lio/sentry/h1;)V

    .line 390
    .line 391
    .line 392
    const-wide/16 v7, 0x61a8

    .line 393
    .line 394
    invoke-interface {v5, v6, v7, v8}, Lio/sentry/d1;->l(Ljava/lang/Runnable;J)Ljava/util/concurrent/Future;

    .line 395
    .line 396
    .line 397
    move-result-object v0

    .line 398
    iput-object v0, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->Q:Ljava/util/concurrent/Future;
    :try_end_18f
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_179 .. :try_end_18f} :catch_190

    .line 399
    .line 400
    goto :goto_1a1

    .line 401
    :catch_190
    move-exception v0

    .line 402
    iget-object v4, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 403
    .line 404
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 405
    .line 406
    .line 407
    move-result-object v4

    .line 408
    sget-object v5, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 409
    .line 410
    const-string v6, "Failed to call the executor. Time to full display span will not be finished automatically. Did you call Sentry.close()?"

    .line 411
    .line 412
    invoke-interface {v4, v5, v6, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 413
    .line 414
    .line 415
    goto :goto_1a1

    .line 416
    :cond_19f
    move-object/from16 v12, v16

    .line 417
    .line 418
    :goto_1a1
    iget-object v0, v1, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 419
    .line 420
    new-instance v4, Lc4/s;

    .line 421
    .line 422
    const/16 v5, 0x12

    .line 423
    .line 424
    invoke-direct {v4, v5, v1, v12}, Lc4/s;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 428
    .line 429
    .line 430
    const/4 v5, 0x0

    .line 431
    invoke-static {v5, v4}, Lio/sentry/f4;->d(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 432
    .line 433
    .line 434
    invoke-virtual {v3, v2, v12}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 435
    .line 436
    .line 437
    :cond_1b4
    return-void
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 5

    .line 1
    instance-of v0, p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    check-cast p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 6
    .line 7
    goto :goto_8

    .line 8
    :cond_7
    const/4 p1, 0x0

    .line 9
    :goto_8
    const-string v0, "SentryAndroidOptions is required"

    .line 10
    .line 11
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 15
    .line 16
    sget-object v0, Lio/sentry/z3;->a:Lio/sentry/z3;

    .line 17
    .line 18
    iput-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 19
    .line 20
    invoke-virtual {p1}, Lio/sentry/a6;->isTracingEnabled()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/4 v1, 0x0

    .line 25
    if-eqz v0, :cond_22

    .line 26
    .line 27
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableAutoActivityLifecycleTracing()Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_22

    .line 32
    .line 33
    const/4 p1, 0x1

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move p1, v1

    .line 36
    :goto_23
    iput-boolean p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 37
    .line 38
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 39
    .line 40
    invoke-virtual {p1}, Lio/sentry/a6;->getFullyDisplayedReporter()Lio/sentry/g0;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    iput-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->K:Lio/sentry/g0;

    .line 45
    .line 46
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 47
    .line 48
    invoke-virtual {p1}, Lio/sentry/a6;->isEnableTimeToFullDisplayTracing()Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    iput-boolean p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->x:Z

    .line 53
    .line 54
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->d:Landroid/app/Application;

    .line 55
    .line 56
    invoke-virtual {p1, p0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 57
    .line 58
    .line 59
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 60
    .line 61
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 66
    .line 67
    const-string v2, "ActivityLifecycleIntegration installed."

    .line 68
    .line 69
    new-array v1, v1, [Ljava/lang/Object;

    .line 70
    .line 71
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    const-string p1, "ActivityLifecycle"

    .line 75
    .line 76
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public final onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 7

    .line 1
    iget-boolean v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->y:Z

    .line 2
    .line 3
    if-nez v0, :cond_7

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lio/sentry/android/core/ActivityLifecycleIntegration;->onActivityPreCreated(Landroid/app/Activity;Landroid/os/Bundle;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    iget-object p2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->T:Lio/sentry/util/a;

    .line 9
    .line 10
    invoke-virtual {p2}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    :try_start_d
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 15
    .line 16
    if-eqz v0, :cond_31

    .line 17
    .line 18
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 19
    .line 20
    if-eqz v0, :cond_31

    .line 21
    .line 22
    invoke-virtual {v0}, Lio/sentry/a6;->isEnableScreenTracking()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_31

    .line 27
    .line 28
    invoke-static {p1}, Landroid/support/v4/media/session/b;->x(Landroid/view/KeyEvent$Callback;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 33
    .line 34
    new-instance v2, Lapp/rive/runtime/kotlin/b;

    .line 35
    .line 36
    const/4 v3, 0x2

    .line 37
    invoke-direct {v2, v0, v3}, Lapp/rive/runtime/kotlin/b;-><init>(Ljava/lang/String;I)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    const/4 v0, 0x0

    .line 44
    invoke-static {v0, v2}, Lio/sentry/f4;->d(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 45
    .line 46
    .line 47
    goto :goto_31

    .line 48
    :catchall_2f
    move-exception p1

    .line 49
    goto :goto_62

    .line 50
    :cond_31
    :goto_31
    invoke-virtual {p0, p1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->l(Landroid/app/Activity;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->M:Ljava/util/WeakHashMap;

    .line 54
    .line 55
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Lio/sentry/h1;

    .line 60
    .line 61
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->N:Ljava/util/WeakHashMap;

    .line 62
    .line 63
    invoke-virtual {v1, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    check-cast p1, Lio/sentry/h1;

    .line 68
    .line 69
    const/4 v1, 0x1

    .line 70
    iput-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 71
    .line 72
    iget-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 73
    .line 74
    if-eqz v1, :cond_5e

    .line 75
    .line 76
    if-eqz v0, :cond_5e

    .line 77
    .line 78
    if-eqz p1, :cond_5e

    .line 79
    .line 80
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->K:Lio/sentry/g0;

    .line 81
    .line 82
    if-eqz p1, :cond_5e

    .line 83
    .line 84
    new-instance v0, Lio/sentry/p2;

    .line 85
    .line 86
    const/4 v1, 0x7

    .line 87
    invoke-direct {v0, v1}, Lio/sentry/p2;-><init>(I)V

    .line 88
    .line 89
    .line 90
    iget-object p1, p1, Lio/sentry/g0;->a:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 91
    .line 92
    invoke-virtual {p1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z
    :try_end_5e
    .catchall {:try_start_d .. :try_end_5e} :catchall_2f

    .line 93
    .line 94
    .line 95
    :cond_5e
    invoke-virtual {p2}, Lio/sentry/s;->close()V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :goto_62
    :try_start_62
    invoke-virtual {p2}, Lio/sentry/s;->close()V
    :try_end_65
    .catchall {:try_start_62 .. :try_end_65} :catchall_66

    .line 100
    .line 101
    .line 102
    goto :goto_6a

    .line 103
    :catchall_66
    move-exception p2

    .line 104
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 105
    .line 106
    .line 107
    :goto_6a
    throw p1
.end method

.method public final onActivityDestroyed(Landroid/app/Activity;)V
    .registers 13

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->N:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->M:Ljava/util/WeakHashMap;

    .line 4
    .line 5
    iget-object v2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->O:Ljava/util/WeakHashMap;

    .line 6
    .line 7
    iget-object v3, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->T:Lio/sentry/util/a;

    .line 8
    .line 9
    invoke-virtual {v3}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    :try_start_c
    invoke-virtual {v2, p1}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    check-cast v4, Lio/sentry/android/core/performance/b;

    .line 18
    .line 19
    const/4 v5, 0x0

    .line 20
    if-eqz v4, :cond_3b

    .line 21
    .line 22
    iget-object v6, v4, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 23
    .line 24
    if-eqz v6, :cond_26

    .line 25
    .line 26
    invoke-interface {v6}, Lio/sentry/h1;->isFinished()Z

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    if-nez v6, :cond_26

    .line 31
    .line 32
    iget-object v6, v4, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 33
    .line 34
    sget-object v7, Lio/sentry/p6;->CANCELLED:Lio/sentry/p6;

    .line 35
    .line 36
    invoke-interface {v6, v7}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 37
    .line 38
    .line 39
    :cond_26
    iput-object v5, v4, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 40
    .line 41
    iget-object v6, v4, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 42
    .line 43
    if-eqz v6, :cond_39

    .line 44
    .line 45
    invoke-interface {v6}, Lio/sentry/h1;->isFinished()Z

    .line 46
    .line 47
    .line 48
    move-result v6

    .line 49
    if-nez v6, :cond_39

    .line 50
    .line 51
    iget-object v6, v4, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 52
    .line 53
    sget-object v7, Lio/sentry/p6;->CANCELLED:Lio/sentry/p6;

    .line 54
    .line 55
    invoke-interface {v6, v7}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 56
    .line 57
    .line 58
    :cond_39
    iput-object v5, v4, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 59
    .line 60
    :cond_3b
    iget-boolean v4, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z
    :try_end_3d
    .catchall {:try_start_c .. :try_end_3d} :catchall_8c

    .line 61
    .line 62
    const/4 v6, 0x0

    .line 63
    iget-object v7, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->R:Ljava/util/WeakHashMap;

    .line 64
    .line 65
    if-eqz v4, :cond_8e

    .line 66
    .line 67
    :try_start_42
    iget-object v4, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->L:Lio/sentry/h1;

    .line 68
    .line 69
    sget-object v8, Lio/sentry/p6;->CANCELLED:Lio/sentry/p6;

    .line 70
    .line 71
    if-eqz v4, :cond_51

    .line 72
    .line 73
    invoke-interface {v4}, Lio/sentry/h1;->isFinished()Z

    .line 74
    .line 75
    .line 76
    move-result v9

    .line 77
    if-nez v9, :cond_51

    .line 78
    .line 79
    invoke-interface {v4, v8}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    invoke-virtual {v1, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    check-cast v4, Lio/sentry/h1;

    .line 87
    .line 88
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v8

    .line 92
    check-cast v8, Lio/sentry/h1;

    .line 93
    .line 94
    sget-object v9, Lio/sentry/p6;->DEADLINE_EXCEEDED:Lio/sentry/p6;

    .line 95
    .line 96
    if-eqz v4, :cond_6a

    .line 97
    .line 98
    invoke-interface {v4}, Lio/sentry/h1;->isFinished()Z

    .line 99
    .line 100
    .line 101
    move-result v10

    .line 102
    if-nez v10, :cond_6a

    .line 103
    .line 104
    invoke-interface {v4, v9}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 105
    .line 106
    .line 107
    :cond_6a
    invoke-static {v8, v4}, Lio/sentry/android/core/ActivityLifecycleIntegration;->d(Lio/sentry/h1;Lio/sentry/h1;)V

    .line 108
    .line 109
    .line 110
    iget-object v4, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->Q:Ljava/util/concurrent/Future;

    .line 111
    .line 112
    if-eqz v4, :cond_76

    .line 113
    .line 114
    invoke-interface {v4, v6}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 115
    .line 116
    .line 117
    iput-object v5, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->Q:Ljava/util/concurrent/Future;

    .line 118
    .line 119
    :cond_76
    iget-boolean v4, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 120
    .line 121
    if-eqz v4, :cond_83

    .line 122
    .line 123
    invoke-virtual {v7, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v4

    .line 127
    check-cast v4, Lio/sentry/j1;

    .line 128
    .line 129
    invoke-virtual {p0, v4, v5, v5}, Lio/sentry/android/core/ActivityLifecycleIntegration;->i(Lio/sentry/j1;Lio/sentry/h1;Lio/sentry/h1;)V

    .line 130
    .line 131
    .line 132
    :cond_83
    iput-object v5, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->L:Lio/sentry/h1;

    .line 133
    .line 134
    invoke-virtual {v1, p1}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    goto :goto_8e

    .line 141
    :catchall_8c
    move-exception p1

    .line 142
    goto :goto_b4

    .line 143
    :cond_8e
    :goto_8e
    invoke-virtual {v7, p1}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v7}, Ljava/util/WeakHashMap;->isEmpty()Z

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    if-eqz v0, :cond_b0

    .line 151
    .line 152
    invoke-virtual {p1}, Landroid/app/Activity;->isChangingConfigurations()Z

    .line 153
    .line 154
    .line 155
    move-result p1

    .line 156
    if-nez p1, :cond_b0

    .line 157
    .line 158
    iput-boolean v6, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 159
    .line 160
    new-instance p1, Lio/sentry/i5;

    .line 161
    .line 162
    new-instance v0, Ljava/util/Date;

    .line 163
    .line 164
    const-wide/16 v4, 0x0

    .line 165
    .line 166
    invoke-direct {v0, v4, v5}, Ljava/util/Date;-><init>(J)V

    .line 167
    .line 168
    .line 169
    invoke-direct {p1, v0, v4, v5}, Lio/sentry/i5;-><init>(Ljava/util/Date;J)V

    .line 170
    .line 171
    .line 172
    iput-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->P:Lio/sentry/l4;

    .line 173
    .line 174
    invoke-virtual {v2}, Ljava/util/WeakHashMap;->clear()V
    :try_end_b0
    .catchall {:try_start_42 .. :try_end_b0} :catchall_8c

    .line 175
    .line 176
    .line 177
    :cond_b0
    invoke-virtual {v3}, Lio/sentry/s;->close()V

    .line 178
    .line 179
    .line 180
    return-void

    .line 181
    :goto_b4
    :try_start_b4
    invoke-virtual {v3}, Lio/sentry/s;->close()V
    :try_end_b7
    .catchall {:try_start_b4 .. :try_end_b7} :catchall_b8

    .line 182
    .line 183
    .line 184
    goto :goto_bc

    .line 185
    :catchall_b8
    move-exception v0

    .line 186
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 187
    .line 188
    .line 189
    :goto_bc
    throw p1
.end method

.method public final onActivityPaused(Landroid/app/Activity;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->T:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    iget-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->y:Z

    .line 8
    .line 9
    if-nez v1, :cond_10

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->onActivityPrePaused(Landroid/app/Activity;)V
    :try_end_d
    .catchall {:try_start_6 .. :try_end_d} :catchall_e

    .line 12
    .line 13
    .line 14
    goto :goto_10

    .line 15
    :catchall_e
    move-exception p1

    .line 16
    goto :goto_14

    .line 17
    :cond_10
    :goto_10
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :goto_14
    :try_start_14
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_17
    .catchall {:try_start_14 .. :try_end_17} :catchall_18

    .line 22
    .line 23
    .line 24
    goto :goto_1c

    .line 25
    :catchall_18
    move-exception v0

    .line 26
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 27
    .line 28
    .line 29
    :goto_1c
    throw p1
.end method

.method public final onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 5

    .line 1
    iget-object p2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->O:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    invoke-virtual {p2, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    check-cast p2, Lio/sentry/android/core/performance/b;

    .line 8
    .line 9
    if-eqz p2, :cond_31

    .line 10
    .line 11
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->L:Lio/sentry/h1;

    .line 12
    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    goto :goto_18

    .line 16
    :cond_f
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->R:Ljava/util/WeakHashMap;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    move-object v0, p1

    .line 23
    check-cast v0, Lio/sentry/h1;

    .line 24
    .line 25
    :goto_18
    iget-object p1, p2, Lio/sentry/android/core/performance/b;->b:Lio/sentry/l4;

    .line 26
    .line 27
    if-eqz p1, :cond_31

    .line 28
    .line 29
    if-eqz v0, :cond_31

    .line 30
    .line 31
    iget-object p1, p2, Lio/sentry/android/core/performance/b;->a:Ljava/lang/String;

    .line 32
    .line 33
    const-string v1, ".onCreate"

    .line 34
    .line 35
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    iget-object v1, p2, Lio/sentry/android/core/performance/b;->b:Lio/sentry/l4;

    .line 40
    .line 41
    invoke-static {v0, p1, v1}, Lio/sentry/android/core/performance/b;->a(Lio/sentry/h1;Ljava/lang/String;Lio/sentry/l4;)Lio/sentry/h1;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    iput-object p1, p2, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 46
    .line 47
    invoke-interface {p1}, Lio/sentry/h1;->g()V

    .line 48
    .line 49
    .line 50
    :cond_31
    return-void
.end method

.method public final onActivityPostResumed(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method

.method public final onActivityPostStarted(Landroid/app/Activity;)V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lio/sentry/android/core/ActivityLifecycleIntegration;->O:Ljava/util/WeakHashMap;

    .line 6
    .line 7
    invoke-virtual {v2, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    check-cast v2, Lio/sentry/android/core/performance/b;

    .line 12
    .line 13
    if-eqz v2, :cond_df

    .line 14
    .line 15
    iget-object v3, v0, Lio/sentry/android/core/ActivityLifecycleIntegration;->L:Lio/sentry/h1;

    .line 16
    .line 17
    if-eqz v3, :cond_13

    .line 18
    .line 19
    goto :goto_1c

    .line 20
    :cond_13
    iget-object v3, v0, Lio/sentry/android/core/ActivityLifecycleIntegration;->R:Ljava/util/WeakHashMap;

    .line 21
    .line 22
    invoke-virtual {v3, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    move-object v3, v1

    .line 27
    check-cast v3, Lio/sentry/h1;

    .line 28
    .line 29
    :goto_1c
    iget-object v1, v2, Lio/sentry/android/core/performance/b;->c:Lio/sentry/l4;

    .line 30
    .line 31
    if-eqz v1, :cond_35

    .line 32
    .line 33
    if-eqz v3, :cond_35

    .line 34
    .line 35
    iget-object v1, v2, Lio/sentry/android/core/performance/b;->a:Ljava/lang/String;

    .line 36
    .line 37
    const-string v4, ".onStart"

    .line 38
    .line 39
    invoke-virtual {v1, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    iget-object v4, v2, Lio/sentry/android/core/performance/b;->c:Lio/sentry/l4;

    .line 44
    .line 45
    invoke-static {v3, v1, v4}, Lio/sentry/android/core/performance/b;->a(Lio/sentry/h1;Ljava/lang/String;Lio/sentry/l4;)Lio/sentry/h1;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    iput-object v1, v2, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 50
    .line 51
    invoke-interface {v1}, Lio/sentry/h1;->g()V

    .line 52
    .line 53
    .line 54
    :cond_35
    iget-object v1, v2, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 55
    .line 56
    if-eqz v1, :cond_df

    .line 57
    .line 58
    iget-object v3, v2, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 59
    .line 60
    if-nez v3, :cond_3f

    .line 61
    .line 62
    goto/16 :goto_df

    .line 63
    .line 64
    :cond_3f
    invoke-interface {v1}, Lio/sentry/h1;->p()Lio/sentry/l4;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    iget-object v3, v2, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 69
    .line 70
    invoke-interface {v3}, Lio/sentry/h1;->p()Lio/sentry/l4;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    if-eqz v1, :cond_df

    .line 75
    .line 76
    if-nez v3, :cond_4f

    .line 77
    .line 78
    goto/16 :goto_df

    .line 79
    .line 80
    :cond_4f
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 81
    .line 82
    .line 83
    move-result-wide v4

    .line 84
    sget-object v6, Lio/sentry/android/core/i;->a:Lio/sentry/android/core/f1;

    .line 85
    .line 86
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    new-instance v6, Lio/sentry/i5;

    .line 90
    .line 91
    invoke-direct {v6}, Lio/sentry/i5;-><init>()V

    .line 92
    .line 93
    .line 94
    sget-object v7, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    .line 95
    .line 96
    iget-object v8, v2, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 97
    .line 98
    invoke-interface {v8}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 99
    .line 100
    .line 101
    move-result-object v8

    .line 102
    invoke-virtual {v6, v8}, Lio/sentry/i5;->b(Lio/sentry/l4;)J

    .line 103
    .line 104
    .line 105
    move-result-wide v8

    .line 106
    invoke-virtual {v7, v8, v9}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 107
    .line 108
    .line 109
    move-result-wide v8

    .line 110
    invoke-virtual {v6, v1}, Lio/sentry/i5;->b(Lio/sentry/l4;)J

    .line 111
    .line 112
    .line 113
    move-result-wide v10

    .line 114
    invoke-virtual {v7, v10, v11}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 115
    .line 116
    .line 117
    move-result-wide v10

    .line 118
    iget-object v1, v2, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 119
    .line 120
    invoke-interface {v1}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    invoke-virtual {v6, v1}, Lio/sentry/i5;->b(Lio/sentry/l4;)J

    .line 125
    .line 126
    .line 127
    move-result-wide v12

    .line 128
    invoke-virtual {v7, v12, v13}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 129
    .line 130
    .line 131
    move-result-wide v12

    .line 132
    invoke-virtual {v6, v3}, Lio/sentry/i5;->b(Lio/sentry/l4;)J

    .line 133
    .line 134
    .line 135
    move-result-wide v14

    .line 136
    invoke-virtual {v7, v14, v15}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 137
    .line 138
    .line 139
    move-result-wide v14

    .line 140
    new-instance v1, Lio/sentry/android/core/performance/c;

    .line 141
    .line 142
    invoke-direct {v1}, Lio/sentry/android/core/performance/c;-><init>()V

    .line 143
    .line 144
    .line 145
    iget-object v3, v2, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 146
    .line 147
    invoke-interface {v3}, Lio/sentry/h1;->getDescription()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v3

    .line 151
    iget-object v6, v2, Lio/sentry/android/core/performance/b;->d:Lio/sentry/h1;

    .line 152
    .line 153
    invoke-interface {v6}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 154
    .line 155
    .line 156
    move-result-object v6

    .line 157
    move-wide/from16 v16, v4

    .line 158
    .line 159
    invoke-virtual {v6}, Lio/sentry/l4;->d()J

    .line 160
    .line 161
    .line 162
    move-result-wide v4

    .line 163
    invoke-virtual {v7, v4, v5}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 164
    .line 165
    .line 166
    move-result-wide v4

    .line 167
    sub-long v8, v16, v8

    .line 168
    .line 169
    sub-long v10, v16, v10

    .line 170
    .line 171
    iget-object v6, v1, Lio/sentry/android/core/performance/c;->d:Lio/sentry/android/core/performance/h;

    .line 172
    .line 173
    iput-object v3, v6, Lio/sentry/android/core/performance/h;->d:Ljava/lang/String;

    .line 174
    .line 175
    iput-wide v4, v6, Lio/sentry/android/core/performance/h;->e:J

    .line 176
    .line 177
    iput-wide v8, v6, Lio/sentry/android/core/performance/h;->i:J

    .line 178
    .line 179
    iput-wide v10, v6, Lio/sentry/android/core/performance/h;->v:J

    .line 180
    .line 181
    iget-object v3, v2, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 182
    .line 183
    invoke-interface {v3}, Lio/sentry/h1;->getDescription()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v3

    .line 187
    iget-object v2, v2, Lio/sentry/android/core/performance/b;->e:Lio/sentry/h1;

    .line 188
    .line 189
    invoke-interface {v2}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 190
    .line 191
    .line 192
    move-result-object v2

    .line 193
    invoke-virtual {v2}, Lio/sentry/l4;->d()J

    .line 194
    .line 195
    .line 196
    move-result-wide v4

    .line 197
    invoke-virtual {v7, v4, v5}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 198
    .line 199
    .line 200
    move-result-wide v4

    .line 201
    sub-long v6, v16, v12

    .line 202
    .line 203
    sub-long v8, v16, v14

    .line 204
    .line 205
    iget-object v2, v1, Lio/sentry/android/core/performance/c;->e:Lio/sentry/android/core/performance/h;

    .line 206
    .line 207
    iput-object v3, v2, Lio/sentry/android/core/performance/h;->d:Ljava/lang/String;

    .line 208
    .line 209
    iput-wide v4, v2, Lio/sentry/android/core/performance/h;->e:J

    .line 210
    .line 211
    iput-wide v6, v2, Lio/sentry/android/core/performance/h;->i:J

    .line 212
    .line 213
    iput-wide v8, v2, Lio/sentry/android/core/performance/h;->v:J

    .line 214
    .line 215
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 216
    .line 217
    .line 218
    move-result-object v2

    .line 219
    iget-object v2, v2, Lio/sentry/android/core/performance/g;->J:Ljava/util/ArrayList;

    .line 220
    .line 221
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    :cond_df
    :goto_df
    return-void
.end method

.method public final onActivityPreCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p2, Lio/sentry/android/core/performance/b;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-direct {p2, v0}, Lio/sentry/android/core/performance/b;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->O:Ljava/util/WeakHashMap;

    .line 15
    .line 16
    invoke-virtual {v0, p1, p2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    iget-boolean p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 20
    .line 21
    if-eqz p1, :cond_17

    .line 22
    .line 23
    return-void

    .line 24
    :cond_17
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 25
    .line 26
    if-eqz p1, :cond_28

    .line 27
    .line 28
    invoke-virtual {p1}, Lio/sentry/z3;->l()Lio/sentry/a6;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1}, Lio/sentry/a6;->getDateProvider()Lio/sentry/m4;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-interface {p1}, Lio/sentry/m4;->now()Lio/sentry/l4;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    goto :goto_32

    .line 41
    :cond_28
    sget-object p1, Lio/sentry/android/core/i;->a:Lio/sentry/android/core/f1;

    .line 42
    .line 43
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    new-instance p1, Lio/sentry/i5;

    .line 47
    .line 48
    invoke-direct {p1}, Lio/sentry/i5;-><init>()V

    .line 49
    .line 50
    .line 51
    :goto_32
    iput-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->P:Lio/sentry/l4;

    .line 52
    .line 53
    iput-object p1, p2, Lio/sentry/android/core/performance/b;->b:Lio/sentry/l4;

    .line 54
    .line 55
    return-void
.end method

.method public final onActivityPrePaused(Landroid/app/Activity;)V
    .registers 2

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->J:Z

    .line 3
    .line 4
    iget-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->i:Lio/sentry/z3;

    .line 5
    .line 6
    if-eqz p1, :cond_14

    .line 7
    .line 8
    invoke-virtual {p1}, Lio/sentry/z3;->l()Lio/sentry/a6;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-virtual {p1}, Lio/sentry/a6;->getDateProvider()Lio/sentry/m4;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-interface {p1}, Lio/sentry/m4;->now()Lio/sentry/l4;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    goto :goto_1e

    .line 21
    :cond_14
    sget-object p1, Lio/sentry/android/core/i;->a:Lio/sentry/android/core/f1;

    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    new-instance p1, Lio/sentry/i5;

    .line 27
    .line 28
    invoke-direct {p1}, Lio/sentry/i5;-><init>()V

    .line 29
    .line 30
    .line 31
    :goto_1e
    iput-object p1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->P:Lio/sentry/l4;

    .line 32
    .line 33
    return-void
.end method

.method public final onActivityPreStarted(Landroid/app/Activity;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->O:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/performance/b;

    .line 8
    .line 9
    if-eqz p1, :cond_23

    .line 10
    .line 11
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 12
    .line 13
    if-eqz v0, :cond_17

    .line 14
    .line 15
    invoke-virtual {v0}, Lio/sentry/a6;->getDateProvider()Lio/sentry/m4;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-interface {v0}, Lio/sentry/m4;->now()Lio/sentry/l4;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    goto :goto_21

    .line 24
    :cond_17
    sget-object v0, Lio/sentry/android/core/i;->a:Lio/sentry/android/core/f1;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    new-instance v0, Lio/sentry/i5;

    .line 30
    .line 31
    invoke-direct {v0}, Lio/sentry/i5;-><init>()V

    .line 32
    .line 33
    .line 34
    :goto_21
    iput-object v0, p1, Lio/sentry/android/core/performance/b;->c:Lio/sentry/l4;

    .line 35
    .line 36
    :cond_23
    return-void
.end method

.method public final onActivityResumed(Landroid/app/Activity;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->T:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    iget-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->y:Z

    .line 8
    .line 9
    if-nez v1, :cond_10

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->onActivityPostStarted(Landroid/app/Activity;)V

    .line 12
    .line 13
    .line 14
    goto :goto_10

    .line 15
    :catchall_e
    move-exception p1

    .line 16
    goto :goto_4c

    .line 17
    :cond_10
    :goto_10
    iget-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 18
    .line 19
    if-eqz v1, :cond_48

    .line 20
    .line 21
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->M:Ljava/util/WeakHashMap;

    .line 22
    .line 23
    invoke-virtual {v1, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, Lio/sentry/h1;

    .line 28
    .line 29
    iget-object v2, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->N:Ljava/util/WeakHashMap;

    .line 30
    .line 31
    invoke-virtual {v2, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    check-cast v2, Lio/sentry/h1;

    .line 36
    .line 37
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    if-eqz v3, :cond_36

    .line 42
    .line 43
    new-instance v3, Lio/sentry/android/core/d;

    .line 44
    .line 45
    const/4 v4, 0x0

    .line 46
    invoke-direct {v3, p0, v2, v1, v4}, Lio/sentry/android/core/d;-><init>(Lio/sentry/android/core/ActivityLifecycleIntegration;Lio/sentry/h1;Lio/sentry/h1;I)V

    .line 47
    .line 48
    .line 49
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->e:Lio/sentry/android/core/j0;

    .line 50
    .line 51
    invoke-static {p1, v3, v1}, Lio/sentry/android/core/internal/util/h;->a(Landroid/app/Activity;Ljava/lang/Runnable;Lio/sentry/android/core/j0;)V

    .line 52
    .line 53
    .line 54
    goto :goto_48

    .line 55
    :cond_36
    new-instance p1, Landroid/os/Handler;

    .line 56
    .line 57
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    invoke-direct {p1, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 62
    .line 63
    .line 64
    new-instance v3, Lio/sentry/android/core/d;

    .line 65
    .line 66
    const/4 v4, 0x1

    .line 67
    invoke-direct {v3, p0, v2, v1, v4}, Lio/sentry/android/core/d;-><init>(Lio/sentry/android/core/ActivityLifecycleIntegration;Lio/sentry/h1;Lio/sentry/h1;I)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_48
    .catchall {:try_start_6 .. :try_end_48} :catchall_e

    .line 71
    .line 72
    .line 73
    :cond_48
    :goto_48
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :goto_4c
    :try_start_4c
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_4f
    .catchall {:try_start_4c .. :try_end_4f} :catchall_50

    .line 78
    .line 79
    .line 80
    goto :goto_54

    .line 81
    :catchall_50
    move-exception v0

    .line 82
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 83
    .line 84
    .line 85
    :goto_54
    throw p1
.end method

.method public final onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    return-void
.end method

.method public final onActivityStarted(Landroid/app/Activity;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->T:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :try_start_6
    iget-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->y:Z

    .line 8
    .line 9
    if-nez v1, :cond_14

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {p0, p1, v1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->onActivityPreStarted(Landroid/app/Activity;)V

    .line 16
    .line 17
    .line 18
    goto :goto_14

    .line 19
    :catchall_12
    move-exception p1

    .line 20
    goto :goto_21

    .line 21
    :cond_14
    :goto_14
    iget-boolean v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->w:Z

    .line 22
    .line 23
    if-eqz v1, :cond_1d

    .line 24
    .line 25
    iget-object v1, p0, Lio/sentry/android/core/ActivityLifecycleIntegration;->S:Lp/r3;

    .line 26
    .line 27
    invoke-virtual {v1, p1}, Lp/r3;->a(Landroid/app/Activity;)V
    :try_end_1d
    .catchall {:try_start_6 .. :try_end_1d} :catchall_12

    .line 28
    .line 29
    .line 30
    :cond_1d
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :goto_21
    :try_start_21
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_24
    .catchall {:try_start_21 .. :try_end_24} :catchall_25

    .line 35
    .line 36
    .line 37
    goto :goto_29

    .line 38
    :catchall_25
    move-exception v0

    .line 39
    invoke-virtual {p1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 40
    .line 41
    .line 42
    :goto_29
    throw p1
.end method

.method public final onActivityStopped(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method

###### Class io.sentry.android.core.d (io.sentry.android.core.d)
.class public final synthetic Lio/sentry/android/core/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lio/sentry/android/core/ActivityLifecycleIntegration;

.field public final synthetic i:Lio/sentry/h1;

.field public final synthetic v:Lio/sentry/h1;


# direct methods
.method public synthetic constructor <init>(Lio/sentry/android/core/ActivityLifecycleIntegration;Lio/sentry/h1;Lio/sentry/h1;I)V
    .registers 5

    .line 1
    iput p4, p0, Lio/sentry/android/core/d;->d:I

    iput-object p1, p0, Lio/sentry/android/core/d;->e:Lio/sentry/android/core/ActivityLifecycleIntegration;

    iput-object p2, p0, Lio/sentry/android/core/d;->i:Lio/sentry/h1;

    iput-object p3, p0, Lio/sentry/android/core/d;->v:Lio/sentry/h1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    iget v0, p0, Lio/sentry/android/core/d;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1a

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/android/core/d;->i:Lio/sentry/h1;

    .line 7
    .line 8
    iget-object v1, p0, Lio/sentry/android/core/d;->v:Lio/sentry/h1;

    .line 9
    .line 10
    iget-object v2, p0, Lio/sentry/android/core/d;->e:Lio/sentry/android/core/ActivityLifecycleIntegration;

    .line 11
    .line 12
    invoke-virtual {v2, v0, v1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->j(Lio/sentry/h1;Lio/sentry/h1;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_f
    iget-object v0, p0, Lio/sentry/android/core/d;->i:Lio/sentry/h1;

    .line 17
    .line 18
    iget-object v1, p0, Lio/sentry/android/core/d;->v:Lio/sentry/h1;

    .line 19
    .line 20
    iget-object v2, p0, Lio/sentry/android/core/d;->e:Lio/sentry/android/core/ActivityLifecycleIntegration;

    .line 21
    .line 22
    invoke-virtual {v2, v0, v1}, Lio/sentry/android/core/ActivityLifecycleIntegration;->j(Lio/sentry/h1;Lio/sentry/h1;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_f
    .end packed-switch
.end method
