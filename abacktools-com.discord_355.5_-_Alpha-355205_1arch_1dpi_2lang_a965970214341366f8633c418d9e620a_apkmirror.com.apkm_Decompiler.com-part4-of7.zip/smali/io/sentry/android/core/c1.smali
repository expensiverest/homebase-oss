###### Class io.sentry.android.core.c1 (io.sentry.android.core.c1)
.class public final Lio/sentry/android/core/c1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/c0;


# instance fields
.field public final d:Lp/r3;

.field public final e:Lio/sentry/android/core/SentryAndroidOptions;

.field public final i:Lio/sentry/util/a;


# direct methods
.method public constructor <init>(Lio/sentry/android/core/SentryAndroidOptions;Lp/r3;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lio/sentry/util/a;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lio/sentry/android/core/c1;->i:Lio/sentry/util/a;

    .line 10
    .line 11
    const-string v0, "SentryAndroidOptions is required"

    .line 12
    .line 13
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lio/sentry/android/core/c1;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 17
    .line 18
    iput-object p2, p0, Lio/sentry/android/core/c1;->d:Lp/r3;

    .line 19
    .line 20
    return-void
.end method

.method public static a(Lio/sentry/android/core/performance/g;Lio/sentry/protocol/e0;)V
    .registers 12

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/performance/g;->d:Lio/sentry/android/core/performance/f;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/android/core/performance/f;->COLD:Lio/sentry/android/core/performance/f;

    .line 4
    .line 5
    if-eq v0, v1, :cond_7

    .line 6
    .line 7
    goto :goto_11

    .line 8
    :cond_7
    iget-object v0, p1, Lio/sentry/i4;->e:Lio/sentry/protocol/c;

    .line 9
    .line 10
    iget-object p1, p1, Lio/sentry/protocol/e0;->U:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v0}, Lio/sentry/protocol/c;->i()Lio/sentry/m6;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_12

    .line 17
    .line 18
    :goto_11
    return-void

    .line 19
    :cond_12
    iget-object v0, v0, Lio/sentry/m6;->d:Lio/sentry/protocol/v;

    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    :cond_18
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_31

    .line 30
    .line 31
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    check-cast v2, Lio/sentry/protocol/y;

    .line 36
    .line 37
    iget-object v3, v2, Lio/sentry/protocol/y;->x:Ljava/lang/String;

    .line 38
    .line 39
    const-string v4, "app.start.cold"

    .line 40
    .line 41
    invoke-virtual {v3, v4}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-eqz v3, :cond_18

    .line 46
    .line 47
    iget-object v1, v2, Lio/sentry/protocol/y;->v:Lio/sentry/o6;

    .line 48
    .line 49
    goto :goto_32

    .line 50
    :cond_31
    const/4 v1, 0x0

    .line 51
    :goto_32
    new-instance v2, Lio/sentry/android/core/performance/h;

    .line 52
    .line 53
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 54
    .line 55
    .line 56
    iget-object v3, p0, Lio/sentry/android/core/performance/g;->v:Lio/sentry/android/core/performance/h;

    .line 57
    .line 58
    iget-wide v4, v3, Lio/sentry/android/core/performance/h;->e:J

    .line 59
    .line 60
    iget-wide v6, v3, Lio/sentry/android/core/performance/h;->i:J

    .line 61
    .line 62
    sget-wide v8, Lio/sentry/android/core/performance/g;->R:J

    .line 63
    .line 64
    const-string v3, "Process Initialization"

    .line 65
    .line 66
    iput-object v3, v2, Lio/sentry/android/core/performance/h;->d:Ljava/lang/String;

    .line 67
    .line 68
    iput-wide v4, v2, Lio/sentry/android/core/performance/h;->e:J

    .line 69
    .line 70
    iput-wide v6, v2, Lio/sentry/android/core/performance/h;->i:J

    .line 71
    .line 72
    iput-wide v8, v2, Lio/sentry/android/core/performance/h;->v:J

    .line 73
    .line 74
    invoke-virtual {v2}, Lio/sentry/android/core/performance/h;->c()Z

    .line 75
    .line 76
    .line 77
    move-result v3

    .line 78
    if-eqz v3, :cond_66

    .line 79
    .line 80
    invoke-virtual {v2}, Lio/sentry/android/core/performance/h;->a()J

    .line 81
    .line 82
    .line 83
    move-result-wide v3

    .line 84
    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    .line 85
    .line 86
    .line 87
    move-result-wide v3

    .line 88
    const-wide/16 v5, 0x2710

    .line 89
    .line 90
    cmp-long v3, v3, v5

    .line 91
    .line 92
    if-gtz v3, :cond_66

    .line 93
    .line 94
    const-string v3, "process.load"

    .line 95
    .line 96
    invoke-static {v2, v1, v0, v3}, Lio/sentry/android/core/c1;->f(Lio/sentry/android/core/performance/h;Lio/sentry/o6;Lio/sentry/protocol/v;Ljava/lang/String;)Lio/sentry/protocol/y;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    :cond_66
    new-instance v2, Ljava/util/ArrayList;

    .line 104
    .line 105
    iget-object v3, p0, Lio/sentry/android/core/performance/g;->y:Ljava/util/HashMap;

    .line 106
    .line 107
    invoke-virtual {v3}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v2}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 118
    .line 119
    .line 120
    move-result v3

    .line 121
    if-nez v3, :cond_94

    .line 122
    .line 123
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    :goto_7e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    if-eqz v3, :cond_94

    .line 132
    .line 133
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v3

    .line 137
    check-cast v3, Lio/sentry/android/core/performance/h;

    .line 138
    .line 139
    const-string v4, "contentprovider.load"

    .line 140
    .line 141
    invoke-static {v3, v1, v0, v4}, Lio/sentry/android/core/c1;->f(Lio/sentry/android/core/performance/h;Lio/sentry/o6;Lio/sentry/protocol/v;Ljava/lang/String;)Lio/sentry/protocol/y;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    goto :goto_7e

    .line 149
    :cond_94
    iget-object p0, p0, Lio/sentry/android/core/performance/g;->x:Lio/sentry/android/core/performance/h;

    .line 150
    .line 151
    iget-wide v2, p0, Lio/sentry/android/core/performance/h;->v:J

    .line 152
    .line 153
    const-wide/16 v4, 0x0

    .line 154
    .line 155
    cmp-long v2, v2, v4

    .line 156
    .line 157
    if-eqz v2, :cond_a7

    .line 158
    .line 159
    const-string v2, "application.load"

    .line 160
    .line 161
    invoke-static {p0, v1, v0, v2}, Lio/sentry/android/core/c1;->f(Lio/sentry/android/core/performance/h;Lio/sentry/o6;Lio/sentry/protocol/v;Ljava/lang/String;)Lio/sentry/protocol/y;

    .line 162
    .line 163
    .line 164
    move-result-object p0

    .line 165
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 166
    .line 167
    .line 168
    :cond_a7
    return-void
.end method

.method public static b(Lio/sentry/protocol/e0;)Z
    .registers 6

    .line 1
    iget-object v0, p0, Lio/sentry/protocol/e0;->U:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :cond_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const-string v2, "app.start.warm"

    .line 12
    .line 13
    const-string v3, "app.start.cold"

    .line 14
    .line 15
    if-eqz v1, :cond_27

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lio/sentry/protocol/y;

    .line 22
    .line 23
    iget-object v4, v1, Lio/sentry/protocol/y;->x:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v4, v3}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-nez v3, :cond_3d

    .line 30
    .line 31
    iget-object v1, v1, Lio/sentry/protocol/y;->x:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v1, v2}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_6

    .line 38
    .line 39
    goto :goto_3d

    .line 40
    :cond_27
    iget-object p0, p0, Lio/sentry/i4;->e:Lio/sentry/protocol/c;

    .line 41
    .line 42
    invoke-virtual {p0}, Lio/sentry/protocol/c;->i()Lio/sentry/m6;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    if-eqz p0, :cond_3f

    .line 47
    .line 48
    iget-object p0, p0, Lio/sentry/m6;->w:Ljava/lang/String;

    .line 49
    .line 50
    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-nez v0, :cond_3d

    .line 55
    .line 56
    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result p0

    .line 60
    if-eqz p0, :cond_3f

    .line 61
    .line 62
    :cond_3d
    :goto_3d
    const/4 p0, 0x1

    .line 63
    return p0

    .line 64
    :cond_3f
    const/4 p0, 0x0

    .line 65
    return p0
.end method

.method public static e(Lio/sentry/protocol/e0;)V
    .registers 12

    .line 1
    iget-object p0, p0, Lio/sentry/protocol/e0;->U:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    move-object v2, v1

    .line 9
    :cond_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    if-eqz v3, :cond_2f

    .line 14
    .line 15
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    check-cast v3, Lio/sentry/protocol/y;

    .line 20
    .line 21
    const-string v4, "ui.load.initial_display"

    .line 22
    .line 23
    iget-object v5, v3, Lio/sentry/protocol/y;->x:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    if-eqz v4, :cond_20

    .line 30
    .line 31
    move-object v1, v3

    .line 32
    goto :goto_2b

    .line 33
    :cond_20
    const-string v4, "ui.load.full_display"

    .line 34
    .line 35
    iget-object v5, v3, Lio/sentry/protocol/y;->x:Ljava/lang/String;

    .line 36
    .line 37
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_2b

    .line 42
    .line 43
    move-object v2, v3

    .line 44
    :cond_2b
    :goto_2b
    if-eqz v1, :cond_8

    .line 45
    .line 46
    if-eqz v2, :cond_8

    .line 47
    .line 48
    :cond_2f
    if-nez v1, :cond_35

    .line 49
    .line 50
    if-nez v2, :cond_35

    .line 51
    .line 52
    goto/16 :goto_c7

    .line 53
    .line 54
    :cond_35
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    :cond_39
    :goto_39
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_c7

    .line 63
    .line 64
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    check-cast v0, Lio/sentry/protocol/y;

    .line 69
    .line 70
    if-eq v0, v1, :cond_39

    .line 71
    .line 72
    if-ne v0, v2, :cond_4a

    .line 73
    .line 74
    goto :goto_39

    .line 75
    :cond_4a
    iget-object v3, v0, Lio/sentry/protocol/y;->M:Ljava/util/Map;

    .line 76
    .line 77
    iget-object v4, v0, Lio/sentry/protocol/y;->d:Ljava/lang/Double;

    .line 78
    .line 79
    const/4 v5, 0x0

    .line 80
    const/4 v6, 0x1

    .line 81
    if-eqz v3, :cond_65

    .line 82
    .line 83
    const-string v7, "thread.name"

    .line 84
    .line 85
    invoke-interface {v3, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v3

    .line 89
    if-eqz v3, :cond_65

    .line 90
    .line 91
    const-string v7, "main"

    .line 92
    .line 93
    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    if-eqz v3, :cond_63

    .line 98
    .line 99
    goto :goto_65

    .line 100
    :cond_63
    move v3, v5

    .line 101
    goto :goto_66

    .line 102
    :cond_65
    :goto_65
    move v3, v6

    .line 103
    :goto_66
    if-eqz v1, :cond_86

    .line 104
    .line 105
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 106
    .line 107
    .line 108
    move-result-wide v7

    .line 109
    iget-object v9, v1, Lio/sentry/protocol/y;->d:Ljava/lang/Double;

    .line 110
    .line 111
    invoke-virtual {v9}, Ljava/lang/Double;->doubleValue()D

    .line 112
    .line 113
    .line 114
    move-result-wide v9

    .line 115
    cmpl-double v9, v7, v9

    .line 116
    .line 117
    if-ltz v9, :cond_86

    .line 118
    .line 119
    iget-object v9, v1, Lio/sentry/protocol/y;->e:Ljava/lang/Double;

    .line 120
    .line 121
    if-eqz v9, :cond_82

    .line 122
    .line 123
    invoke-virtual {v9}, Ljava/lang/Double;->doubleValue()D

    .line 124
    .line 125
    .line 126
    move-result-wide v9

    .line 127
    cmpg-double v7, v7, v9

    .line 128
    .line 129
    if-gtz v7, :cond_86

    .line 130
    .line 131
    :cond_82
    if-eqz v3, :cond_86

    .line 132
    .line 133
    move v3, v6

    .line 134
    goto :goto_87

    .line 135
    :cond_86
    move v3, v5

    .line 136
    :goto_87
    if-eqz v2, :cond_a4

    .line 137
    .line 138
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 139
    .line 140
    .line 141
    move-result-wide v7

    .line 142
    iget-object v4, v2, Lio/sentry/protocol/y;->d:Ljava/lang/Double;

    .line 143
    .line 144
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 145
    .line 146
    .line 147
    move-result-wide v9

    .line 148
    cmpl-double v4, v7, v9

    .line 149
    .line 150
    if-ltz v4, :cond_a4

    .line 151
    .line 152
    iget-object v4, v2, Lio/sentry/protocol/y;->e:Ljava/lang/Double;

    .line 153
    .line 154
    if-eqz v4, :cond_a3

    .line 155
    .line 156
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 157
    .line 158
    .line 159
    move-result-wide v9

    .line 160
    cmpg-double v4, v7, v9

    .line 161
    .line 162
    if-gtz v4, :cond_a4

    .line 163
    .line 164
    :cond_a3
    move v5, v6

    .line 165
    :cond_a4
    if-nez v3, :cond_a8

    .line 166
    .line 167
    if-eqz v5, :cond_39

    .line 168
    .line 169
    :cond_a8
    iget-object v4, v0, Lio/sentry/protocol/y;->M:Ljava/util/Map;

    .line 170
    .line 171
    if-nez v4, :cond_b3

    .line 172
    .line 173
    new-instance v4, Ljava/util/concurrent/ConcurrentHashMap;

    .line 174
    .line 175
    invoke-direct {v4}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 176
    .line 177
    .line 178
    iput-object v4, v0, Lio/sentry/protocol/y;->M:Ljava/util/Map;

    .line 179
    .line 180
    :cond_b3
    if-eqz v3, :cond_bc

    .line 181
    .line 182
    const-string v0, "ui.contributes_to_ttid"

    .line 183
    .line 184
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 185
    .line 186
    invoke-interface {v4, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    :cond_bc
    if-eqz v5, :cond_39

    .line 190
    .line 191
    const-string v0, "ui.contributes_to_ttfd"

    .line 192
    .line 193
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 194
    .line 195
    invoke-interface {v4, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    goto/16 :goto_39

    .line 199
    .line 200
    :cond_c7
    :goto_c7
    return-void
.end method

.method public static f(Lio/sentry/android/core/performance/h;Lio/sentry/o6;Lio/sentry/protocol/v;Ljava/lang/String;)Lio/sentry/protocol/y;
    .registers 17

    .line 1
    new-instance v12, Ljava/util/HashMap;

    .line 2
    .line 3
    const/4 v0, 0x2

    .line 4
    invoke-direct {v12, v0}, Ljava/util/HashMap;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sget-wide v0, Lio/sentry/android/core/internal/util/e;->b:J

    .line 8
    .line 9
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const-string v1, "thread.id"

    .line 14
    .line 15
    invoke-virtual {v12, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    const-string v0, "thread.name"

    .line 19
    .line 20
    const-string v1, "main"

    .line 21
    .line 22
    invoke-virtual {v12, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 26
    .line 27
    const-string v1, "ui.contributes_to_ttid"

    .line 28
    .line 29
    invoke-virtual {v12, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    const-string v1, "ui.contributes_to_ttfd"

    .line 33
    .line 34
    invoke-virtual {v12, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    new-instance v0, Lio/sentry/protocol/y;

    .line 38
    .line 39
    iget-wide v1, p0, Lio/sentry/android/core/performance/h;->e:J

    .line 40
    .line 41
    long-to-double v1, v1

    .line 42
    const-wide v3, 0x408f400000000000L    # 1000.0

    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    div-double/2addr v1, v3

    .line 48
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {p0}, Lio/sentry/android/core/performance/h;->c()Z

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    if-eqz v2, :cond_41

    .line 57
    .line 58
    iget-wide v5, p0, Lio/sentry/android/core/performance/h;->e:J

    .line 59
    .line 60
    invoke-virtual {p0}, Lio/sentry/android/core/performance/h;->a()J

    .line 61
    .line 62
    .line 63
    move-result-wide v7

    .line 64
    add-long/2addr v7, v5

    .line 65
    goto :goto_43

    .line 66
    :cond_41
    const-wide/16 v7, 0x0

    .line 67
    .line 68
    :goto_43
    long-to-double v5, v7

    .line 69
    div-double/2addr v5, v3

    .line 70
    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    new-instance v4, Lio/sentry/o6;

    .line 75
    .line 76
    invoke-direct {v4}, Lio/sentry/o6;-><init>()V

    .line 77
    .line 78
    .line 79
    iget-object v7, p0, Lio/sentry/android/core/performance/h;->d:Ljava/lang/String;

    .line 80
    .line 81
    sget-object v8, Lio/sentry/p6;->OK:Lio/sentry/p6;

    .line 82
    .line 83
    new-instance v10, Ljava/util/concurrent/ConcurrentHashMap;

    .line 84
    .line 85
    invoke-direct {v10}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 86
    .line 87
    .line 88
    new-instance v11, Ljava/util/concurrent/ConcurrentHashMap;

    .line 89
    .line 90
    invoke-direct {v11}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 91
    .line 92
    .line 93
    const-string v9, "auto.ui"

    .line 94
    .line 95
    move-object v5, p1

    .line 96
    move-object v3, p2

    .line 97
    move-object/from16 v6, p3

    .line 98
    .line 99
    invoke-direct/range {v0 .. v12}, Lio/sentry/protocol/y;-><init>(Ljava/lang/Double;Ljava/lang/Double;Lio/sentry/protocol/v;Lio/sentry/o6;Lio/sentry/o6;Ljava/lang/String;Ljava/lang/String;Lio/sentry/p6;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V

    .line 100
    .line 101
    .line 102
    return-object v0
.end method


# virtual methods
.method public final d(Lio/sentry/t4;Lio/sentry/h0;)Lio/sentry/t4;
    .registers 3

    .line 1
    return-object p1
.end method

.method public final g(Lio/sentry/protocol/e0;Lio/sentry/h0;)Lio/sentry/protocol/e0;
    .registers 12

    .line 1
    iget-object p2, p0, Lio/sentry/android/core/c1;->e:Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    iget-object v0, p0, Lio/sentry/android/core/c1;->i:Lio/sentry/util/a;

    .line 4
    .line 5
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    :try_start_8
    invoke-virtual {p2}, Lio/sentry/a6;->isTracingEnabled()Z

    .line 10
    .line 11
    .line 12
    move-result v1
    :try_end_c
    .catchall {:try_start_8 .. :try_end_c} :catchall_59

    .line 13
    if-nez v1, :cond_12

    .line 14
    .line 15
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 16
    .line 17
    .line 18
    return-object p1

    .line 19
    :cond_12
    :try_start_12
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-static {p1}, Lio/sentry/android/core/c1;->b(Lio/sentry/protocol/e0;)Z

    .line 24
    .line 25
    .line 26
    move-result v2
    :try_end_1a
    .catchall {:try_start_12 .. :try_end_1a} :catchall_59

    .line 27
    iget-object v3, p1, Lio/sentry/protocol/e0;->V:Ljava/util/HashMap;

    .line 28
    .line 29
    iget-object v4, p1, Lio/sentry/i4;->e:Lio/sentry/protocol/c;

    .line 30
    .line 31
    if-eqz v2, :cond_8c

    .line 32
    .line 33
    :try_start_20
    iget-boolean v2, v1, Lio/sentry/android/core/performance/g;->O:Z

    .line 34
    .line 35
    if-eqz v2, :cond_71

    .line 36
    .line 37
    iget-object v2, v1, Lio/sentry/android/core/performance/g;->e:Lio/sentry/util/e;

    .line 38
    .line 39
    invoke-virtual {v2}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    check-cast v2, Ljava/lang/Boolean;

    .line 44
    .line 45
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_71

    .line 50
    .line 51
    invoke-virtual {v1, p2}, Lio/sentry/android/core/performance/g;->b(Lio/sentry/android/core/SentryAndroidOptions;)Lio/sentry/android/core/performance/h;

    .line 52
    .line 53
    .line 54
    move-result-object p2

    .line 55
    invoke-virtual {p2}, Lio/sentry/android/core/performance/h;->a()J

    .line 56
    .line 57
    .line 58
    move-result-wide v5

    .line 59
    const-wide/16 v7, 0x0

    .line 60
    .line 61
    cmp-long p2, v5, v7

    .line 62
    .line 63
    if-eqz p2, :cond_71

    .line 64
    .line 65
    new-instance p2, Lio/sentry/protocol/l;

    .line 66
    .line 67
    long-to-float v2, v5

    .line 68
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    sget-object v5, Lio/sentry/e2;->MILLISECOND:Lio/sentry/e2;

    .line 73
    .line 74
    invoke-virtual {v5}, Lio/sentry/e2;->apiName()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    invoke-direct {p2, v2, v5}, Lio/sentry/protocol/l;-><init>(Ljava/lang/Number;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    iget-object v2, v1, Lio/sentry/android/core/performance/g;->d:Lio/sentry/android/core/performance/f;

    .line 82
    .line 83
    sget-object v5, Lio/sentry/android/core/performance/f;->COLD:Lio/sentry/android/core/performance/f;

    .line 84
    .line 85
    if-ne v2, v5, :cond_5c

    .line 86
    .line 87
    const-string v2, "app_start_cold"

    .line 88
    .line 89
    goto :goto_5e

    .line 90
    :catchall_59
    move-exception p1

    .line 91
    goto/16 :goto_dd

    .line 92
    .line 93
    :cond_5c
    const-string v2, "app_start_warm"

    .line 94
    .line 95
    :goto_5e
    invoke-virtual {v3, v2, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    invoke-static {v1, p1}, Lio/sentry/android/core/c1;->a(Lio/sentry/android/core/performance/g;Lio/sentry/protocol/e0;)V

    .line 99
    .line 100
    .line 101
    const/4 p2, 0x0

    .line 102
    iput-boolean p2, v1, Lio/sentry/android/core/performance/g;->O:Z

    .line 103
    .line 104
    iget-object p2, v1, Lio/sentry/android/core/performance/g;->y:Ljava/util/HashMap;

    .line 105
    .line 106
    invoke-virtual {p2}, Ljava/util/HashMap;->clear()V

    .line 107
    .line 108
    .line 109
    iget-object p2, v1, Lio/sentry/android/core/performance/g;->J:Ljava/util/ArrayList;

    .line 110
    .line 111
    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    .line 112
    .line 113
    .line 114
    :cond_71
    invoke-virtual {v4}, Lio/sentry/protocol/c;->d()Lio/sentry/protocol/a;

    .line 115
    .line 116
    .line 117
    move-result-object p2

    .line 118
    if-nez p2, :cond_7f

    .line 119
    .line 120
    new-instance p2, Lio/sentry/protocol/a;

    .line 121
    .line 122
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v4, p2}, Lio/sentry/protocol/c;->n(Lio/sentry/protocol/a;)V

    .line 126
    .line 127
    .line 128
    :cond_7f
    iget-object v1, v1, Lio/sentry/android/core/performance/g;->d:Lio/sentry/android/core/performance/f;

    .line 129
    .line 130
    sget-object v2, Lio/sentry/android/core/performance/f;->COLD:Lio/sentry/android/core/performance/f;

    .line 131
    .line 132
    if-ne v1, v2, :cond_88

    .line 133
    .line 134
    const-string v1, "cold"

    .line 135
    .line 136
    goto :goto_8a

    .line 137
    :cond_88
    const-string v1, "warm"

    .line 138
    .line 139
    :goto_8a
    iput-object v1, p2, Lio/sentry/protocol/a;->L:Ljava/lang/String;

    .line 140
    .line 141
    :cond_8c
    invoke-static {p1}, Lio/sentry/android/core/c1;->e(Lio/sentry/protocol/e0;)V

    .line 142
    .line 143
    .line 144
    iget-object p2, p1, Lio/sentry/i4;->d:Lio/sentry/protocol/v;

    .line 145
    .line 146
    invoke-virtual {v4}, Lio/sentry/protocol/c;->i()Lio/sentry/m6;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    if-eqz p2, :cond_d9

    .line 151
    .line 152
    if-eqz v1, :cond_d9

    .line 153
    .line 154
    iget-object v1, v1, Lio/sentry/m6;->w:Ljava/lang/String;

    .line 155
    .line 156
    const-string v2, "ui.load"

    .line 157
    .line 158
    invoke-virtual {v1, v2}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    .line 159
    .line 160
    .line 161
    move-result v1

    .line 162
    if-eqz v1, :cond_d9

    .line 163
    .line 164
    iget-object v1, p0, Lio/sentry/android/core/c1;->d:Lp/r3;

    .line 165
    .line 166
    iget-object v2, v1, Lp/r3;->v:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v2, Ljava/util/concurrent/ConcurrentHashMap;

    .line 169
    .line 170
    iget-object v4, v1, Lp/r3;->y:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast v4, Lio/sentry/util/a;

    .line 173
    .line 174
    invoke-virtual {v4}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 175
    .line 176
    .line 177
    move-result-object v4
    :try_end_b1
    .catchall {:try_start_20 .. :try_end_b1} :catchall_59

    .line 178
    :try_start_b1
    invoke-virtual {v1}, Lp/r3;->h()Z

    .line 179
    .line 180
    .line 181
    move-result v1
    :try_end_b5
    .catchall {:try_start_b1 .. :try_end_b5} :catchall_cf

    .line 182
    if-nez v1, :cond_bc

    .line 183
    .line 184
    :try_start_b7
    invoke-virtual {v4}, Lio/sentry/s;->close()V
    :try_end_ba
    .catchall {:try_start_b7 .. :try_end_ba} :catchall_59

    .line 185
    .line 186
    .line 187
    const/4 p2, 0x0

    .line 188
    goto :goto_c9

    .line 189
    :cond_bc
    :try_start_bc
    invoke-virtual {v2, p2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    check-cast v1, Ljava/util/Map;

    .line 194
    .line 195
    invoke-virtual {v2, p2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_c5
    .catchall {:try_start_bc .. :try_end_c5} :catchall_cf

    .line 196
    .line 197
    .line 198
    :try_start_c5
    invoke-virtual {v4}, Lio/sentry/s;->close()V

    .line 199
    .line 200
    .line 201
    move-object p2, v1

    .line 202
    :goto_c9
    if-eqz p2, :cond_d9

    .line 203
    .line 204
    invoke-virtual {v3, p2}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V
    :try_end_ce
    .catchall {:try_start_c5 .. :try_end_ce} :catchall_59

    .line 205
    .line 206
    .line 207
    goto :goto_d9

    .line 208
    :catchall_cf
    move-exception p1

    .line 209
    :try_start_d0
    invoke-virtual {v4}, Lio/sentry/s;->close()V
    :try_end_d3
    .catchall {:try_start_d0 .. :try_end_d3} :catchall_d4

    .line 210
    .line 211
    .line 212
    goto :goto_d8

    .line 213
    :catchall_d4
    move-exception p2

    .line 214
    :try_start_d5
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 215
    .line 216
    .line 217
    :goto_d8
    throw p1
    :try_end_d9
    .catchall {:try_start_d5 .. :try_end_d9} :catchall_59

    .line 218
    :cond_d9
    :goto_d9
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 219
    .line 220
    .line 221
    return-object p1

    .line 222
    :goto_dd
    :try_start_dd
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_e0
    .catchall {:try_start_dd .. :try_end_e0} :catchall_e1

    .line 223
    .line 224
    .line 225
    goto :goto_e5

    .line 226
    :catchall_e1
    move-exception p2

    .line 227
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 228
    .line 229
    .line 230
    :goto_e5
    throw p1
.end method
