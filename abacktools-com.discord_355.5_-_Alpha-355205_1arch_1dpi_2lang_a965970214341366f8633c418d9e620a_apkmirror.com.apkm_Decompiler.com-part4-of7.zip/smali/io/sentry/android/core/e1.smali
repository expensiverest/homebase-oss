###### Class io.sentry.android.core.e1 (io.sentry.android.core.e1)
.class public abstract Lio/sentry/android/core/e1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:J

.field public static final b:Lio/sentry/util/a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    sput-wide v0, Lio/sentry/android/core/e1;->a:J

    .line 6
    .line 7
    new-instance v0, Lio/sentry/util/a;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 10
    .line 11
    .line 12
    sput-object v0, Lio/sentry/android/core/e1;->b:Lio/sentry/util/a;

    .line 13
    .line 14
    return-void
.end method

.method public static a(Lio/sentry/a6;ZZ)V
    .registers 9

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    new-instance v2, Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Lio/sentry/a6;->getIntegrations()Ljava/util/List;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    :cond_17
    :goto_17
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    if-eqz v4, :cond_3d

    .line 29
    .line 30
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Lio/sentry/p1;

    .line 35
    .line 36
    if-eqz p1, :cond_2c

    .line 37
    .line 38
    instance-of v5, v4, Lio/sentry/android/fragment/FragmentLifecycleIntegration;

    .line 39
    .line 40
    if-eqz v5, :cond_2c

    .line 41
    .line 42
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    :cond_2c
    if-eqz p2, :cond_35

    .line 46
    .line 47
    instance-of v5, v4, Lio/sentry/android/timber/SentryTimberIntegration;

    .line 48
    .line 49
    if-eqz v5, :cond_35

    .line 50
    .line 51
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    :cond_35
    instance-of v5, v4, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;

    .line 55
    .line 56
    if-eqz v5, :cond_17

    .line 57
    .line 58
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    goto :goto_17

    .line 62
    :cond_3d
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 63
    .line 64
    .line 65
    move-result p1

    .line 66
    const/4 p2, 0x0

    .line 67
    const/4 v3, 0x1

    .line 68
    if-le p1, v3, :cond_5d

    .line 69
    .line 70
    move p1, p2

    .line 71
    :goto_46
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    sub-int/2addr v4, v3

    .line 76
    if-ge p1, v4, :cond_5d

    .line 77
    .line 78
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    check-cast v4, Lio/sentry/p1;

    .line 83
    .line 84
    invoke-virtual {p0}, Lio/sentry/a6;->getIntegrations()Ljava/util/List;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    invoke-interface {v5, v4}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    add-int/lit8 p1, p1, 0x1

    .line 92
    .line 93
    goto :goto_46

    .line 94
    :cond_5d
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    if-le p1, v3, :cond_7b

    .line 99
    .line 100
    move p1, p2

    .line 101
    :goto_64
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    sub-int/2addr v1, v3

    .line 106
    if-ge p1, v1, :cond_7b

    .line 107
    .line 108
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    check-cast v1, Lio/sentry/p1;

    .line 113
    .line 114
    invoke-virtual {p0}, Lio/sentry/a6;->getIntegrations()Ljava/util/List;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    invoke-interface {v4, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    add-int/lit8 p1, p1, 0x1

    .line 122
    .line 123
    goto :goto_64

    .line 124
    :cond_7b
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 125
    .line 126
    .line 127
    move-result p1

    .line 128
    if-le p1, v3, :cond_98

    .line 129
    .line 130
    :goto_81
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 131
    .line 132
    .line 133
    move-result p1

    .line 134
    sub-int/2addr p1, v3

    .line 135
    if-ge p2, p1, :cond_98

    .line 136
    .line 137
    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    check-cast p1, Lio/sentry/p1;

    .line 142
    .line 143
    invoke-virtual {p0}, Lio/sentry/a6;->getIntegrations()Ljava/util/List;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    add-int/lit8 p2, p2, 0x1

    .line 151
    .line 152
    goto :goto_81

    .line 153
    :cond_98
    return-void
.end method

.method public static b(Landroid/content/Context;Lio/sentry/android/core/l0;Lio/sentry/e4;)V
    .registers 8

    .line 1
    const-string v0, "Failed to initialize Sentry\'s SDK"

    .line 2
    .line 3
    const-string v1, "Fatal error during SentryAndroid.init(...)"

    .line 4
    .line 5
    :try_start_4
    sget-object v2, Lio/sentry/android/core/e1;->b:Lio/sentry/util/a;

    .line 6
    .line 7
    invoke-virtual {v2}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 8
    .line 9
    .line 10
    move-result-object v2
    :try_end_a
    .catch Ljava/lang/IllegalAccessException; {:try_start_4 .. :try_end_a} :catch_5c
    .catch Ljava/lang/InstantiationException; {:try_start_4 .. :try_end_a} :catch_5a
    .catch Ljava/lang/NoSuchMethodException; {:try_start_4 .. :try_end_a} :catch_58
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_4 .. :try_end_a} :catch_56

    .line 11
    :try_start_a
    new-instance v3, Lio/sentry/j2;

    .line 12
    .line 13
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    new-instance v4, Lio/sentry/android/core/e;

    .line 17
    .line 18
    invoke-direct {v4, p1, p0, p2}, Lio/sentry/android/core/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-static {v3, v4}, Lio/sentry/f4;->g(Lio/sentry/j2;Lio/sentry/android/core/e;)V

    .line 22
    .line 23
    .line 24
    invoke-static {}, Lio/sentry/f4;->f()Lio/sentry/a1;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-static {}, Lio/sentry/android/core/k0;->i()Z

    .line 29
    .line 30
    .line 31
    move-result p2

    .line 32
    if-eqz p2, :cond_52

    .line 33
    .line 34
    invoke-interface {p0}, Lio/sentry/a1;->l()Lio/sentry/a6;

    .line 35
    .line 36
    .line 37
    move-result-object p2

    .line 38
    invoke-virtual {p2}, Lio/sentry/a6;->isEnableAutoSessionTracking()Z

    .line 39
    .line 40
    .line 41
    move-result p2

    .line 42
    if-eqz p2, :cond_47

    .line 43
    .line 44
    new-instance p2, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 45
    .line 46
    const/4 v3, 0x0

    .line 47
    invoke-direct {p2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 48
    .line 49
    .line 50
    new-instance v3, Lio/sentry/android/core/n0;

    .line 51
    .line 52
    const/4 v4, 0x3

    .line 53
    invoke-direct {v3, v4, p2}, Lio/sentry/android/core/n0;-><init>(ILjava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    const/4 v4, 0x0

    .line 57
    invoke-interface {p0, v4, v3}, Lio/sentry/a1;->q(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 61
    .line 62
    .line 63
    move-result p2

    .line 64
    if-nez p2, :cond_47

    .line 65
    .line 66
    invoke-interface {p0}, Lio/sentry/a1;->p()V

    .line 67
    .line 68
    .line 69
    goto :goto_47

    .line 70
    :catchall_45
    move-exception p0

    .line 71
    goto :goto_5e

    .line 72
    :cond_47
    :goto_47
    invoke-interface {p0}, Lio/sentry/a1;->l()Lio/sentry/a6;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    invoke-virtual {p0}, Lio/sentry/a6;->getReplayController()Lio/sentry/n3;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    invoke-interface {p0}, Lio/sentry/n3;->u()V
    :try_end_52
    .catchall {:try_start_a .. :try_end_52} :catchall_45

    .line 81
    .line 82
    .line 83
    :cond_52
    :try_start_52
    invoke-virtual {v2}, Lio/sentry/s;->close()V
    :try_end_55
    .catch Ljava/lang/IllegalAccessException; {:try_start_52 .. :try_end_55} :catch_5c
    .catch Ljava/lang/InstantiationException; {:try_start_52 .. :try_end_55} :catch_5a
    .catch Ljava/lang/NoSuchMethodException; {:try_start_52 .. :try_end_55} :catch_58
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_52 .. :try_end_55} :catch_56

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :catch_56
    move-exception p0

    .line 88
    goto :goto_67

    .line 89
    :catch_58
    move-exception p0

    .line 90
    goto :goto_72

    .line 91
    :catch_5a
    move-exception p0

    .line 92
    goto :goto_7d

    .line 93
    :catch_5c
    move-exception p0

    .line 94
    goto :goto_88

    .line 95
    :goto_5e
    :try_start_5e
    invoke-virtual {v2}, Lio/sentry/s;->close()V
    :try_end_61
    .catchall {:try_start_5e .. :try_end_61} :catchall_62

    .line 96
    .line 97
    .line 98
    goto :goto_66

    .line 99
    :catchall_62
    move-exception p2

    .line 100
    :try_start_63
    invoke-virtual {p0, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 101
    .line 102
    .line 103
    :goto_66
    throw p0
    :try_end_67
    .catch Ljava/lang/IllegalAccessException; {:try_start_63 .. :try_end_67} :catch_5c
    .catch Ljava/lang/InstantiationException; {:try_start_63 .. :try_end_67} :catch_5a
    .catch Ljava/lang/NoSuchMethodException; {:try_start_63 .. :try_end_67} :catch_58
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_63 .. :try_end_67} :catch_56

    .line 104
    :goto_67
    sget-object p2, Lio/sentry/a5;->FATAL:Lio/sentry/a5;

    .line 105
    .line 106
    invoke-virtual {p1, p2, v1, p0}, Lio/sentry/android/core/l0;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 107
    .line 108
    .line 109
    new-instance p1, Ljava/lang/RuntimeException;

    .line 110
    .line 111
    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 112
    .line 113
    .line 114
    throw p1

    .line 115
    :goto_72
    sget-object p2, Lio/sentry/a5;->FATAL:Lio/sentry/a5;

    .line 116
    .line 117
    invoke-virtual {p1, p2, v1, p0}, Lio/sentry/android/core/l0;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 118
    .line 119
    .line 120
    new-instance p1, Ljava/lang/RuntimeException;

    .line 121
    .line 122
    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 123
    .line 124
    .line 125
    throw p1

    .line 126
    :goto_7d
    sget-object p2, Lio/sentry/a5;->FATAL:Lio/sentry/a5;

    .line 127
    .line 128
    invoke-virtual {p1, p2, v1, p0}, Lio/sentry/android/core/l0;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 129
    .line 130
    .line 131
    new-instance p1, Ljava/lang/RuntimeException;

    .line 132
    .line 133
    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 134
    .line 135
    .line 136
    throw p1

    .line 137
    :goto_88
    sget-object p2, Lio/sentry/a5;->FATAL:Lio/sentry/a5;

    .line 138
    .line 139
    invoke-virtual {p1, p2, v1, p0}, Lio/sentry/android/core/l0;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 140
    .line 141
    .line 142
    new-instance p1, Ljava/lang/RuntimeException;

    .line 143
    .line 144
    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 145
    .line 146
    .line 147
    throw p1
.end method
