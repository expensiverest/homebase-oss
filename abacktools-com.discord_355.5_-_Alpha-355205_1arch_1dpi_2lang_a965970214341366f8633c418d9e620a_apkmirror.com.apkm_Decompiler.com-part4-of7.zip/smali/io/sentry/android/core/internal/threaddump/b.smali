###### Class io.sentry.android.core.internal.threaddump.b (io.sentry.android.core.internal.threaddump.b)
.class public final Lio/sentry/android/core/internal/threaddump/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:Ljava/util/regex/Pattern;

.field public static final g:Ljava/util/regex/Pattern;

.field public static final h:Ljava/util/regex/Pattern;

.field public static final i:Ljava/util/regex/Pattern;

.field public static final j:Ljava/util/regex/Pattern;

.field public static final k:Ljava/util/regex/Pattern;

.field public static final l:Ljava/util/regex/Pattern;

.field public static final m:Ljava/util/regex/Pattern;

.field public static final n:Ljava/util/regex/Pattern;

.field public static final o:Ljava/util/regex/Pattern;

.field public static final p:Ljava/util/regex/Pattern;

.field public static final q:Ljava/util/regex/Pattern;


# instance fields
.field public final a:Lio/sentry/a6;

.field public final b:Z

.field public final c:Landroidx/core/view/d0;

.field public final d:Ljava/util/HashMap;

.field public final e:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const-string v0, "\"(.*)\" (.*) ?prio=(\\d+)\\s+tid=(\\d+)\\s*(.*)"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->f:Ljava/util/regex/Pattern;

    .line 8
    .line 9
    const-string v0, "\"(.*)\" (.*) ?sysTid=(\\d+)"

    .line 10
    .line 11
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->g:Ljava/util/regex/Pattern;

    .line 16
    .line 17
    const-string v0, " *(?:native: )?#(\\d+) \\S+ ([0-9a-fA-F]+)\\s+((.*?)(?:\\s+\\(deleted\\))?(?:\\s+\\(offset (.*?)\\))?)(?:\\s+\\((?:\\?\\?\\?|(.*?)(?:\\+(\\d+))?)\\))?(?:\\s+\\(BuildId: (.*?)\\))?"

    .line 18
    .line 19
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->h:Ljava/util/regex/Pattern;

    .line 24
    .line 25
    const-string v0, " *at (?:(.+)\\.)?([^.]+)\\.([^.]+)\\((.*):([\\d-]+)\\)"

    .line 26
    .line 27
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->i:Ljava/util/regex/Pattern;

    .line 32
    .line 33
    const-string v0, " *at (?:(.+)\\.)?([^.]+)\\.([^.]+)\\(Native method\\)"

    .line 34
    .line 35
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->j:Ljava/util/regex/Pattern;

    .line 40
    .line 41
    const-string v0, " *- locked \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)"

    .line 42
    .line 43
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->k:Ljava/util/regex/Pattern;

    .line 48
    .line 49
    const-string v0, " *- sleeping on \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)"

    .line 50
    .line 51
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->l:Ljava/util/regex/Pattern;

    .line 56
    .line 57
    const-string v0, " *- waiting on \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)"

    .line 58
    .line 59
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->m:Ljava/util/regex/Pattern;

    .line 64
    .line 65
    const-string v0, " *- waiting to lock \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)"

    .line 66
    .line 67
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->n:Ljava/util/regex/Pattern;

    .line 72
    .line 73
    const-string v0, " *- waiting to lock \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)(?: held by thread (\\d+))"

    .line 74
    .line 75
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->o:Ljava/util/regex/Pattern;

    .line 80
    .line 81
    const-string v0, " *- waiting to lock an unknown object"

    .line 82
    .line 83
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->p:Ljava/util/regex/Pattern;

    .line 88
    .line 89
    const-string v0, "\\s+"

    .line 90
    .line 91
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    sput-object v0, Lio/sentry/android/core/internal/threaddump/b;->q:Ljava/util/regex/Pattern;

    .line 96
    .line 97
    return-void
.end method

.method public constructor <init>(Lio/sentry/a6;Z)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/threaddump/b;->a:Lio/sentry/a6;

    .line 5
    .line 6
    iput-boolean p2, p0, Lio/sentry/android/core/internal/threaddump/b;->b:Z

    .line 7
    .line 8
    new-instance p2, Landroidx/core/view/d0;

    .line 9
    .line 10
    invoke-direct {p2, p1}, Landroidx/core/view/d0;-><init>(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    iput-object p2, p0, Lio/sentry/android/core/internal/threaddump/b;->c:Landroidx/core/view/d0;

    .line 14
    .line 15
    new-instance p1, Ljava/util/HashMap;

    .line 16
    .line 17
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lio/sentry/android/core/internal/threaddump/b;->d:Ljava/util/HashMap;

    .line 21
    .line 22
    new-instance p1, Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lio/sentry/android/core/internal/threaddump/b;->e:Ljava/util/ArrayList;

    .line 28
    .line 29
    return-void
.end method

.method public static a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lio/sentry/protocol/d0;->L:Ljava/util/Map;

    .line 2
    .line 3
    if-nez v0, :cond_9

    .line 4
    .line 5
    new-instance v0, Ljava/util/HashMap;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object v1, p1, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 11
    .line 12
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    check-cast v1, Lio/sentry/b5;

    .line 17
    .line 18
    if-eqz v1, :cond_1e

    .line 19
    .line 20
    iget v2, v1, Lio/sentry/b5;->d:I

    .line 21
    .line 22
    iget p1, p1, Lio/sentry/b5;->d:I

    .line 23
    .line 24
    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    iput p1, v1, Lio/sentry/b5;->d:I

    .line 29
    .line 30
    goto :goto_42

    .line 31
    :cond_1e
    iget-object v1, p1, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 32
    .line 33
    new-instance v2, Lio/sentry/b5;

    .line 34
    .line 35
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 36
    .line 37
    .line 38
    iget v3, p1, Lio/sentry/b5;->d:I

    .line 39
    .line 40
    iput v3, v2, Lio/sentry/b5;->d:I

    .line 41
    .line 42
    iput-object v1, v2, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v3, p1, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 45
    .line 46
    iput-object v3, v2, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v3, p1, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 49
    .line 50
    iput-object v3, v2, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v3, p1, Lio/sentry/b5;->w:Ljava/lang/Long;

    .line 53
    .line 54
    iput-object v3, v2, Lio/sentry/b5;->w:Ljava/lang/Long;

    .line 55
    .line 56
    iget-object p1, p1, Lio/sentry/b5;->x:Ljava/util/concurrent/ConcurrentHashMap;

    .line 57
    .line 58
    invoke-static {p1}, Lh40/f0;->y(Ljava/util/Map;)Ljava/util/concurrent/ConcurrentHashMap;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    iput-object p1, v2, Lio/sentry/b5;->x:Ljava/util/concurrent/ConcurrentHashMap;

    .line 63
    .line 64
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    :goto_42
    iput-object v0, p0, Lio/sentry/protocol/d0;->L:Ljava/util/Map;

    .line 68
    .line 69
    return-void
.end method

.method public static b(Ljava/util/regex/Matcher;I)Ljava/lang/Long;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    if-eqz p0, :cond_16

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    if-nez p1, :cond_d

    .line 12
    .line 13
    goto :goto_16

    .line 14
    :cond_d
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 15
    .line 16
    .line 17
    move-result-wide p0

    .line 18
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :cond_16
    :goto_16
    const/4 p0, 0x0

    .line 24
    return-object p0
.end method

.method public static c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->reset(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->matches()Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method


# virtual methods
.method public final d(La1/f;)V
    .registers 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget v2, v1, La1/f;->b:I

    .line 6
    .line 7
    sget-object v3, Lio/sentry/android/core/internal/threaddump/b;->f:Ljava/util/regex/Pattern;

    .line 8
    .line 9
    const-string v4, ""

    .line 10
    .line 11
    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    sget-object v6, Lio/sentry/android/core/internal/threaddump/b;->g:Ljava/util/regex/Pattern;

    .line 16
    .line 17
    invoke-virtual {v6, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 18
    .line 19
    .line 20
    move-result-object v7

    .line 21
    :goto_14
    iget v8, v1, La1/f;->c:I

    .line 22
    .line 23
    if-ge v8, v2, :cond_411

    .line 24
    .line 25
    invoke-virtual {v1}, La1/f;->a()Lio/sentry/android/core/internal/threaddump/a;

    .line 26
    .line 27
    .line 28
    move-result-object v8

    .line 29
    const/4 v9, 0x0

    .line 30
    const-string v10, "Internal error while parsing thread dump."

    .line 31
    .line 32
    iget-object v11, v0, Lio/sentry/android/core/internal/threaddump/b;->a:Lio/sentry/a6;

    .line 33
    .line 34
    if-nez v8, :cond_2f

    .line 35
    .line 36
    invoke-virtual {v11}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    sget-object v2, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 41
    .line 42
    new-array v3, v9, [Ljava/lang/Object;

    .line 43
    .line 44
    invoke-interface {v1, v2, v10, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :cond_2f
    iget-object v8, v8, Lio/sentry/android/core/internal/threaddump/a;->a:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v5, v8}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 51
    .line 52
    .line 53
    move-result v12

    .line 54
    if-nez v12, :cond_4c

    .line 55
    .line 56
    invoke-static {v7, v8}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    if-eqz v8, :cond_3e

    .line 61
    .line 62
    goto :goto_4c

    .line 63
    :cond_3e
    move/from16 v30, v2

    .line 64
    .line 65
    move-object/from16 v20, v3

    .line 66
    .line 67
    move-object/from16 v27, v4

    .line 68
    .line 69
    move-object/from16 v21, v5

    .line 70
    .line 71
    move-object/from16 v22, v6

    .line 72
    .line 73
    move-object/from16 v23, v7

    .line 74
    .line 75
    goto/16 :goto_401

    .line 76
    .line 77
    :cond_4c
    :goto_4c
    iget v8, v1, La1/f;->c:I

    .line 78
    .line 79
    const/4 v12, 0x1

    .line 80
    sub-int/2addr v8, v12

    .line 81
    iput v8, v1, La1/f;->c:I

    .line 82
    .line 83
    new-instance v8, Lio/sentry/protocol/d0;

    .line 84
    .line 85
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 89
    .line 90
    .line 91
    move-result-object v13

    .line 92
    invoke-virtual {v6, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 93
    .line 94
    .line 95
    move-result-object v14

    .line 96
    iget v15, v1, La1/f;->c:I

    .line 97
    .line 98
    const/16 v16, 0x0

    .line 99
    .line 100
    if-ge v15, v2, :cond_76

    .line 101
    .line 102
    invoke-virtual {v1}, La1/f;->a()Lio/sentry/android/core/internal/threaddump/a;

    .line 103
    .line 104
    .line 105
    move-result-object v15

    .line 106
    if-nez v15, :cond_86

    .line 107
    .line 108
    invoke-virtual {v11}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 109
    .line 110
    .line 111
    move-result-object v8

    .line 112
    sget-object v11, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 113
    .line 114
    new-array v9, v9, [Ljava/lang/Object;

    .line 115
    .line 116
    invoke-interface {v8, v11, v10, v9}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    :cond_76
    :goto_76
    move/from16 v30, v2

    .line 120
    .line 121
    move-object/from16 v20, v3

    .line 122
    .line 123
    move-object/from16 v27, v4

    .line 124
    .line 125
    move-object/from16 v21, v5

    .line 126
    .line 127
    move-object/from16 v22, v6

    .line 128
    .line 129
    move-object/from16 v23, v7

    .line 130
    .line 131
    move-object/from16 v8, v16

    .line 132
    .line 133
    goto/16 :goto_3f8

    .line 134
    .line 135
    :cond_86
    iget-object v15, v15, Lio/sentry/android/core/internal/threaddump/a;->a:Ljava/lang/String;

    .line 136
    .line 137
    invoke-static {v13, v15}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 138
    .line 139
    .line 140
    move-result v17

    .line 141
    const-string v12, "No thread id in the dump, skipping thread."

    .line 142
    .line 143
    const/4 v9, 0x4

    .line 144
    if-eqz v17, :cond_cd

    .line 145
    .line 146
    invoke-static {v13, v9}, Lio/sentry/android/core/internal/threaddump/b;->b(Ljava/util/regex/Matcher;I)Ljava/lang/Long;

    .line 147
    .line 148
    .line 149
    move-result-object v14

    .line 150
    if-nez v14, :cond_a4

    .line 151
    .line 152
    invoke-virtual {v11}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 153
    .line 154
    .line 155
    move-result-object v8

    .line 156
    sget-object v9, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 157
    .line 158
    const/4 v10, 0x0

    .line 159
    new-array v10, v10, [Ljava/lang/Object;

    .line 160
    .line 161
    invoke-interface {v8, v9, v12, v10}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    goto :goto_76

    .line 165
    :cond_a4
    iput-object v14, v8, Lio/sentry/protocol/d0;->d:Ljava/lang/Long;

    .line 166
    .line 167
    const/4 v12, 0x1

    .line 168
    invoke-virtual {v13, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v14

    .line 172
    iput-object v14, v8, Lio/sentry/protocol/d0;->i:Ljava/lang/String;

    .line 173
    .line 174
    const/4 v12, 0x5

    .line 175
    invoke-virtual {v13, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v13

    .line 179
    if-eqz v13, :cond_f0

    .line 180
    .line 181
    const-string v12, " "

    .line 182
    .line 183
    invoke-virtual {v13, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 184
    .line 185
    .line 186
    move-result v12

    .line 187
    if-eqz v12, :cond_ca

    .line 188
    .line 189
    const/16 v12, 0x20

    .line 190
    .line 191
    invoke-virtual {v13, v12}, Ljava/lang/String;->indexOf(I)I

    .line 192
    .line 193
    .line 194
    move-result v12

    .line 195
    const/4 v14, 0x0

    .line 196
    invoke-virtual {v13, v14, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v12

    .line 200
    iput-object v12, v8, Lio/sentry/protocol/d0;->v:Ljava/lang/String;

    .line 201
    .line 202
    goto :goto_f0

    .line 203
    :cond_ca
    iput-object v13, v8, Lio/sentry/protocol/d0;->v:Ljava/lang/String;

    .line 204
    .line 205
    goto :goto_f0

    .line 206
    :cond_cd
    invoke-static {v14, v15}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 207
    .line 208
    .line 209
    move-result v13

    .line 210
    if-eqz v13, :cond_f0

    .line 211
    .line 212
    const/4 v13, 0x3

    .line 213
    invoke-static {v14, v13}, Lio/sentry/android/core/internal/threaddump/b;->b(Ljava/util/regex/Matcher;I)Ljava/lang/Long;

    .line 214
    .line 215
    .line 216
    move-result-object v15

    .line 217
    if-nez v15, :cond_e7

    .line 218
    .line 219
    invoke-virtual {v11}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 220
    .line 221
    .line 222
    move-result-object v8

    .line 223
    sget-object v9, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 224
    .line 225
    const/4 v14, 0x0

    .line 226
    new-array v10, v14, [Ljava/lang/Object;

    .line 227
    .line 228
    invoke-interface {v8, v9, v12, v10}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    goto :goto_76

    .line 232
    :cond_e7
    iput-object v15, v8, Lio/sentry/protocol/d0;->d:Ljava/lang/Long;

    .line 233
    .line 234
    const/4 v12, 0x1

    .line 235
    invoke-virtual {v14, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v13

    .line 239
    iput-object v13, v8, Lio/sentry/protocol/d0;->i:Ljava/lang/String;

    .line 240
    .line 241
    :cond_f0
    :goto_f0
    iget-object v12, v8, Lio/sentry/protocol/d0;->i:Ljava/lang/String;

    .line 242
    .line 243
    if-eqz v12, :cond_115

    .line 244
    .line 245
    const-string v13, "main"

    .line 246
    .line 247
    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v12

    .line 251
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 252
    .line 253
    .line 254
    move-result-object v13

    .line 255
    iput-object v13, v8, Lio/sentry/protocol/d0;->J:Ljava/lang/Boolean;

    .line 256
    .line 257
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 258
    .line 259
    .line 260
    move-result-object v13

    .line 261
    iput-object v13, v8, Lio/sentry/protocol/d0;->w:Ljava/lang/Boolean;

    .line 262
    .line 263
    if-eqz v12, :cond_10e

    .line 264
    .line 265
    iget-boolean v12, v0, Lio/sentry/android/core/internal/threaddump/b;->b:Z

    .line 266
    .line 267
    if-nez v12, :cond_10e

    .line 268
    .line 269
    const/4 v12, 0x1

    .line 270
    goto :goto_10f

    .line 271
    :cond_10e
    const/4 v12, 0x0

    .line 272
    :goto_10f
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 273
    .line 274
    .line 275
    move-result-object v12

    .line 276
    iput-object v12, v8, Lio/sentry/protocol/d0;->x:Ljava/lang/Boolean;

    .line 277
    .line 278
    :cond_115
    iget-object v12, v0, Lio/sentry/android/core/internal/threaddump/b;->c:Landroidx/core/view/d0;

    .line 279
    .line 280
    iget-object v12, v12, Landroidx/core/view/d0;->d:Ljava/lang/Object;

    .line 281
    .line 282
    check-cast v12, Lio/sentry/a6;

    .line 283
    .line 284
    new-instance v13, Ljava/util/ArrayList;

    .line 285
    .line 286
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 287
    .line 288
    .line 289
    sget-object v14, Lio/sentry/android/core/internal/threaddump/b;->h:Ljava/util/regex/Pattern;

    .line 290
    .line 291
    invoke-virtual {v14, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 292
    .line 293
    .line 294
    move-result-object v14

    .line 295
    sget-object v15, Lio/sentry/android/core/internal/threaddump/b;->i:Ljava/util/regex/Pattern;

    .line 296
    .line 297
    invoke-virtual {v15, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 298
    .line 299
    .line 300
    move-result-object v15

    .line 301
    sget-object v9, Lio/sentry/android/core/internal/threaddump/b;->j:Ljava/util/regex/Pattern;

    .line 302
    .line 303
    invoke-virtual {v9, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 304
    .line 305
    .line 306
    move-result-object v9

    .line 307
    move-object/from16 v20, v3

    .line 308
    .line 309
    sget-object v3, Lio/sentry/android/core/internal/threaddump/b;->k:Ljava/util/regex/Pattern;

    .line 310
    .line 311
    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 312
    .line 313
    .line 314
    move-result-object v3

    .line 315
    move-object/from16 v21, v5

    .line 316
    .line 317
    sget-object v5, Lio/sentry/android/core/internal/threaddump/b;->m:Ljava/util/regex/Pattern;

    .line 318
    .line 319
    invoke-virtual {v5, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 320
    .line 321
    .line 322
    move-result-object v5

    .line 323
    move-object/from16 v22, v6

    .line 324
    .line 325
    sget-object v6, Lio/sentry/android/core/internal/threaddump/b;->l:Ljava/util/regex/Pattern;

    .line 326
    .line 327
    invoke-virtual {v6, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 328
    .line 329
    .line 330
    move-result-object v6

    .line 331
    move-object/from16 v23, v7

    .line 332
    .line 333
    sget-object v7, Lio/sentry/android/core/internal/threaddump/b;->o:Ljava/util/regex/Pattern;

    .line 334
    .line 335
    invoke-virtual {v7, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 336
    .line 337
    .line 338
    move-result-object v7

    .line 339
    move-object/from16 v24, v11

    .line 340
    .line 341
    sget-object v11, Lio/sentry/android/core/internal/threaddump/b;->n:Ljava/util/regex/Pattern;

    .line 342
    .line 343
    invoke-virtual {v11, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 344
    .line 345
    .line 346
    move-result-object v11

    .line 347
    move-object/from16 v25, v12

    .line 348
    .line 349
    sget-object v12, Lio/sentry/android/core/internal/threaddump/b;->p:Ljava/util/regex/Pattern;

    .line 350
    .line 351
    invoke-virtual {v12, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 352
    .line 353
    .line 354
    move-result-object v12

    .line 355
    move-object/from16 v26, v12

    .line 356
    .line 357
    sget-object v12, Lio/sentry/android/core/internal/threaddump/b;->q:Ljava/util/regex/Pattern;

    .line 358
    .line 359
    invoke-virtual {v12, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 360
    .line 361
    .line 362
    move-result-object v12

    .line 363
    move-object/from16 v27, v4

    .line 364
    .line 365
    move-object/from16 v28, v12

    .line 366
    .line 367
    move-object/from16 v4, v16

    .line 368
    .line 369
    :goto_170
    iget v12, v1, La1/f;->c:I

    .line 370
    .line 371
    if-ge v12, v2, :cond_186

    .line 372
    .line 373
    invoke-virtual {v1}, La1/f;->a()Lio/sentry/android/core/internal/threaddump/a;

    .line 374
    .line 375
    .line 376
    move-result-object v12

    .line 377
    if-nez v12, :cond_18a

    .line 378
    .line 379
    invoke-virtual/range {v24 .. v24}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 380
    .line 381
    .line 382
    move-result-object v3

    .line 383
    sget-object v4, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 384
    .line 385
    const/4 v5, 0x0

    .line 386
    new-array v5, v5, [Ljava/lang/Object;

    .line 387
    .line 388
    invoke-interface {v3, v4, v10, v5}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 389
    .line 390
    .line 391
    :cond_186
    move/from16 v30, v2

    .line 392
    .line 393
    goto/16 :goto_3ea

    .line 394
    .line 395
    :cond_18a
    const/16 v19, 0x0

    .line 396
    .line 397
    iget-object v12, v12, Lio/sentry/android/core/internal/threaddump/a;->a:Ljava/lang/String;

    .line 398
    .line 399
    invoke-static {v15, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 400
    .line 401
    .line 402
    move-result v29

    .line 403
    const-string v1, "."

    .line 404
    .line 405
    move/from16 v30, v2

    .line 406
    .line 407
    const/4 v2, 0x2

    .line 408
    if-eqz v29, :cond_1f6

    .line 409
    .line 410
    new-instance v4, Lio/sentry/protocol/z;

    .line 411
    .line 412
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 413
    .line 414
    .line 415
    move-object/from16 v29, v10

    .line 416
    .line 417
    const/4 v12, 0x1

    .line 418
    invoke-virtual {v15, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v10

    .line 422
    invoke-virtual {v15, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object v2

    .line 426
    invoke-static {v10, v1, v2}, Lp/x2;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 427
    .line 428
    .line 429
    move-result-object v1

    .line 430
    iput-object v1, v4, Lio/sentry/protocol/z;->x:Ljava/lang/String;

    .line 431
    .line 432
    const/4 v2, 0x3

    .line 433
    invoke-virtual {v15, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 434
    .line 435
    .line 436
    move-result-object v10

    .line 437
    iput-object v10, v4, Lio/sentry/protocol/z;->w:Ljava/lang/String;

    .line 438
    .line 439
    const/4 v2, 0x4

    .line 440
    invoke-virtual {v15, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 441
    .line 442
    .line 443
    move-result-object v10

    .line 444
    iput-object v10, v4, Lio/sentry/protocol/z;->v:Ljava/lang/String;

    .line 445
    .line 446
    const/4 v10, 0x5

    .line 447
    invoke-virtual {v15, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v2

    .line 451
    if-eqz v2, :cond_1d6

    .line 452
    .line 453
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 454
    .line 455
    .line 456
    move-result v12

    .line 457
    if-nez v12, :cond_1cb

    .line 458
    .line 459
    goto :goto_1d6

    .line 460
    :cond_1cb
    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 461
    .line 462
    .line 463
    move-result v2

    .line 464
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 465
    .line 466
    .line 467
    move-result-object v12

    .line 468
    if-ltz v2, :cond_1d6

    .line 469
    .line 470
    goto :goto_1d8

    .line 471
    :cond_1d6
    :goto_1d6
    move-object/from16 v12, v16

    .line 472
    .line 473
    :goto_1d8
    iput-object v12, v4, Lio/sentry/protocol/z;->y:Ljava/lang/Integer;

    .line 474
    .line 475
    invoke-virtual/range {v25 .. v25}, Lio/sentry/a6;->getInAppIncludes()Ljava/util/List;

    .line 476
    .line 477
    .line 478
    move-result-object v2

    .line 479
    invoke-virtual/range {v25 .. v25}, Lio/sentry/a6;->getInAppExcludes()Ljava/util/List;

    .line 480
    .line 481
    .line 482
    move-result-object v12

    .line 483
    invoke-static {v1, v2, v12}, Landroidx/core/view/d0;->p(Ljava/lang/String;Ljava/util/List;Ljava/util/List;)Ljava/lang/Boolean;

    .line 484
    .line 485
    .line 486
    move-result-object v1

    .line 487
    iput-object v1, v4, Lio/sentry/protocol/z;->M:Ljava/lang/Boolean;

    .line 488
    .line 489
    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 490
    .line 491
    .line 492
    move-object/from16 v18, v15

    .line 493
    .line 494
    :cond_1ed
    :goto_1ed
    move-object/from16 v0, v26

    .line 495
    .line 496
    move-object/from16 v10, v28

    .line 497
    .line 498
    const/4 v1, 0x1

    .line 499
    const/4 v2, 0x3

    .line 500
    const/4 v15, 0x4

    .line 501
    goto/16 :goto_3da

    .line 502
    .line 503
    :cond_1f6
    move-object/from16 v29, v10

    .line 504
    .line 505
    const/4 v10, 0x5

    .line 506
    invoke-static {v14, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 507
    .line 508
    .line 509
    move-result v18

    .line 510
    const/16 v10, 0x8

    .line 511
    .line 512
    if-eqz v18, :cond_290

    .line 513
    .line 514
    new-instance v1, Lio/sentry/protocol/z;

    .line 515
    .line 516
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 517
    .line 518
    .line 519
    const/4 v4, 0x3

    .line 520
    invoke-virtual {v14, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 521
    .line 522
    .line 523
    move-result-object v12

    .line 524
    iput-object v12, v1, Lio/sentry/protocol/z;->N:Ljava/lang/String;

    .line 525
    .line 526
    const/4 v4, 0x6

    .line 527
    invoke-virtual {v14, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 528
    .line 529
    .line 530
    move-result-object v4

    .line 531
    iput-object v4, v1, Lio/sentry/protocol/z;->w:Ljava/lang/String;

    .line 532
    .line 533
    const/4 v4, 0x7

    .line 534
    invoke-virtual {v14, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 535
    .line 536
    .line 537
    move-result-object v4

    .line 538
    if-eqz v4, :cond_22b

    .line 539
    .line 540
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 541
    .line 542
    .line 543
    move-result v12

    .line 544
    if-nez v12, :cond_222

    .line 545
    .line 546
    goto :goto_22b

    .line 547
    :cond_222
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 548
    .line 549
    .line 550
    move-result v4

    .line 551
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 552
    .line 553
    .line 554
    move-result-object v4

    .line 555
    goto :goto_22d

    .line 556
    :cond_22b
    :goto_22b
    move-object/from16 v4, v16

    .line 557
    .line 558
    :goto_22d
    iput-object v4, v1, Lio/sentry/protocol/z;->y:Ljava/lang/Integer;

    .line 559
    .line 560
    new-instance v4, Ljava/lang/StringBuilder;

    .line 561
    .line 562
    const-string v12, "0x"

    .line 563
    .line 564
    invoke-direct {v4, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 565
    .line 566
    .line 567
    invoke-virtual {v14, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 568
    .line 569
    .line 570
    move-result-object v2

    .line 571
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 572
    .line 573
    .line 574
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 575
    .line 576
    .line 577
    move-result-object v2

    .line 578
    iput-object v2, v1, Lio/sentry/protocol/z;->S:Ljava/lang/String;

    .line 579
    .line 580
    const-string v2, "native"

    .line 581
    .line 582
    iput-object v2, v1, Lio/sentry/protocol/z;->P:Ljava/lang/String;

    .line 583
    .line 584
    invoke-virtual {v14, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object v2

    .line 588
    if-nez v2, :cond_250

    .line 589
    .line 590
    move-object/from16 v4, v16

    .line 591
    .line 592
    goto :goto_254

    .line 593
    :cond_250
    invoke-static {v2}, Lc7/t;->h(Ljava/lang/String;)Ljava/lang/String;

    .line 594
    .line 595
    .line 596
    move-result-object v4

    .line 597
    :goto_254
    if-eqz v4, :cond_287

    .line 598
    .line 599
    iget-object v10, v0, Lio/sentry/android/core/internal/threaddump/b;->d:Ljava/util/HashMap;

    .line 600
    .line 601
    invoke-virtual {v10, v4}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 602
    .line 603
    .line 604
    move-result v12

    .line 605
    if-nez v12, :cond_27c

    .line 606
    .line 607
    new-instance v12, Lio/sentry/protocol/DebugImage;

    .line 608
    .line 609
    invoke-direct {v12}, Lio/sentry/protocol/DebugImage;-><init>()V

    .line 610
    .line 611
    .line 612
    invoke-virtual {v12, v4}, Lio/sentry/protocol/DebugImage;->setDebugId(Ljava/lang/String;)V

    .line 613
    .line 614
    .line 615
    move-object/from16 v18, v15

    .line 616
    .line 617
    const-string v15, "elf"

    .line 618
    .line 619
    invoke-virtual {v12, v15}, Lio/sentry/protocol/DebugImage;->setType(Ljava/lang/String;)V

    .line 620
    .line 621
    .line 622
    const/4 v15, 0x4

    .line 623
    invoke-virtual {v14, v15}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 624
    .line 625
    .line 626
    move-result-object v0

    .line 627
    invoke-virtual {v12, v0}, Lio/sentry/protocol/DebugImage;->setCodeFile(Ljava/lang/String;)V

    .line 628
    .line 629
    .line 630
    invoke-virtual {v12, v2}, Lio/sentry/protocol/DebugImage;->setCodeId(Ljava/lang/String;)V

    .line 631
    .line 632
    .line 633
    invoke-virtual {v10, v4, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 634
    .line 635
    .line 636
    goto :goto_27e

    .line 637
    :cond_27c
    move-object/from16 v18, v15

    .line 638
    .line 639
    :goto_27e
    const-string v0, "rel:"

    .line 640
    .line 641
    invoke-virtual {v0, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 642
    .line 643
    .line 644
    move-result-object v0

    .line 645
    iput-object v0, v1, Lio/sentry/protocol/z;->T:Ljava/lang/String;

    .line 646
    .line 647
    goto :goto_289

    .line 648
    :cond_287
    move-object/from16 v18, v15

    .line 649
    .line 650
    :goto_289
    invoke-virtual {v13, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 651
    .line 652
    .line 653
    move-object/from16 v4, v16

    .line 654
    .line 655
    goto/16 :goto_1ed

    .line 656
    .line 657
    :cond_290
    move-object/from16 v18, v15

    .line 658
    .line 659
    invoke-static {v9, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 660
    .line 661
    .line 662
    move-result v0

    .line 663
    if-eqz v0, :cond_2ca

    .line 664
    .line 665
    new-instance v4, Lio/sentry/protocol/z;

    .line 666
    .line 667
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 668
    .line 669
    .line 670
    const/4 v12, 0x1

    .line 671
    invoke-virtual {v9, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 672
    .line 673
    .line 674
    move-result-object v0

    .line 675
    invoke-virtual {v9, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 676
    .line 677
    .line 678
    move-result-object v2

    .line 679
    invoke-static {v0, v1, v2}, Lp/x2;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    iput-object v0, v4, Lio/sentry/protocol/z;->x:Ljava/lang/String;

    .line 684
    .line 685
    const/4 v2, 0x3

    .line 686
    invoke-virtual {v9, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 687
    .line 688
    .line 689
    move-result-object v1

    .line 690
    iput-object v1, v4, Lio/sentry/protocol/z;->w:Ljava/lang/String;

    .line 691
    .line 692
    invoke-virtual/range {v25 .. v25}, Lio/sentry/a6;->getInAppIncludes()Ljava/util/List;

    .line 693
    .line 694
    .line 695
    move-result-object v1

    .line 696
    invoke-virtual/range {v25 .. v25}, Lio/sentry/a6;->getInAppExcludes()Ljava/util/List;

    .line 697
    .line 698
    .line 699
    move-result-object v2

    .line 700
    invoke-static {v0, v1, v2}, Landroidx/core/view/d0;->p(Ljava/lang/String;Ljava/util/List;Ljava/util/List;)Ljava/lang/Boolean;

    .line 701
    .line 702
    .line 703
    move-result-object v0

    .line 704
    iput-object v0, v4, Lio/sentry/protocol/z;->M:Ljava/lang/Boolean;

    .line 705
    .line 706
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 707
    .line 708
    iput-object v0, v4, Lio/sentry/protocol/z;->O:Ljava/lang/Boolean;

    .line 709
    .line 710
    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 711
    .line 712
    .line 713
    goto/16 :goto_1ed

    .line 714
    .line 715
    :cond_2ca
    invoke-static {v3, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 716
    .line 717
    .line 718
    move-result v0

    .line 719
    if-eqz v0, :cond_2f4

    .line 720
    .line 721
    if-eqz v4, :cond_1ed

    .line 722
    .line 723
    new-instance v0, Lio/sentry/b5;

    .line 724
    .line 725
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 726
    .line 727
    .line 728
    const/4 v12, 0x1

    .line 729
    iput v12, v0, Lio/sentry/b5;->d:I

    .line 730
    .line 731
    invoke-virtual {v3, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 732
    .line 733
    .line 734
    move-result-object v1

    .line 735
    iput-object v1, v0, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 736
    .line 737
    invoke-virtual {v3, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 738
    .line 739
    .line 740
    move-result-object v1

    .line 741
    iput-object v1, v0, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 742
    .line 743
    const/4 v2, 0x3

    .line 744
    invoke-virtual {v3, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 745
    .line 746
    .line 747
    move-result-object v1

    .line 748
    iput-object v1, v0, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 749
    .line 750
    iput-object v0, v4, Lio/sentry/protocol/z;->X:Lio/sentry/b5;

    .line 751
    .line 752
    invoke-static {v8, v0}, Lio/sentry/android/core/internal/threaddump/b;->a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V

    .line 753
    .line 754
    .line 755
    goto/16 :goto_1ed

    .line 756
    .line 757
    :cond_2f4
    invoke-static {v5, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 758
    .line 759
    .line 760
    move-result v0

    .line 761
    if-eqz v0, :cond_31e

    .line 762
    .line 763
    if-eqz v4, :cond_1ed

    .line 764
    .line 765
    new-instance v0, Lio/sentry/b5;

    .line 766
    .line 767
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 768
    .line 769
    .line 770
    iput v2, v0, Lio/sentry/b5;->d:I

    .line 771
    .line 772
    const/4 v12, 0x1

    .line 773
    invoke-virtual {v5, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 774
    .line 775
    .line 776
    move-result-object v1

    .line 777
    iput-object v1, v0, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 778
    .line 779
    invoke-virtual {v5, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 780
    .line 781
    .line 782
    move-result-object v1

    .line 783
    iput-object v1, v0, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 784
    .line 785
    const/4 v2, 0x3

    .line 786
    invoke-virtual {v5, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 787
    .line 788
    .line 789
    move-result-object v1

    .line 790
    iput-object v1, v0, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 791
    .line 792
    iput-object v0, v4, Lio/sentry/protocol/z;->X:Lio/sentry/b5;

    .line 793
    .line 794
    invoke-static {v8, v0}, Lio/sentry/android/core/internal/threaddump/b;->a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V

    .line 795
    .line 796
    .line 797
    goto/16 :goto_1ed

    .line 798
    .line 799
    :cond_31e
    invoke-static {v6, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 800
    .line 801
    .line 802
    move-result v0

    .line 803
    if-eqz v0, :cond_349

    .line 804
    .line 805
    if-eqz v4, :cond_1ed

    .line 806
    .line 807
    new-instance v0, Lio/sentry/b5;

    .line 808
    .line 809
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 810
    .line 811
    .line 812
    const/4 v15, 0x4

    .line 813
    iput v15, v0, Lio/sentry/b5;->d:I

    .line 814
    .line 815
    const/4 v12, 0x1

    .line 816
    invoke-virtual {v6, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 817
    .line 818
    .line 819
    move-result-object v1

    .line 820
    iput-object v1, v0, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 821
    .line 822
    invoke-virtual {v6, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 823
    .line 824
    .line 825
    move-result-object v1

    .line 826
    iput-object v1, v0, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 827
    .line 828
    const/4 v2, 0x3

    .line 829
    invoke-virtual {v6, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 830
    .line 831
    .line 832
    move-result-object v1

    .line 833
    iput-object v1, v0, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 834
    .line 835
    iput-object v0, v4, Lio/sentry/protocol/z;->X:Lio/sentry/b5;

    .line 836
    .line 837
    invoke-static {v8, v0}, Lio/sentry/android/core/internal/threaddump/b;->a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V

    .line 838
    .line 839
    .line 840
    goto/16 :goto_1ed

    .line 841
    .line 842
    :cond_349
    invoke-static {v7, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 843
    .line 844
    .line 845
    move-result v0

    .line 846
    if-eqz v0, :cond_381

    .line 847
    .line 848
    if-eqz v4, :cond_37f

    .line 849
    .line 850
    new-instance v0, Lio/sentry/b5;

    .line 851
    .line 852
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 853
    .line 854
    .line 855
    iput v10, v0, Lio/sentry/b5;->d:I

    .line 856
    .line 857
    const/4 v12, 0x1

    .line 858
    invoke-virtual {v7, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 859
    .line 860
    .line 861
    move-result-object v1

    .line 862
    iput-object v1, v0, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 863
    .line 864
    invoke-virtual {v7, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 865
    .line 866
    .line 867
    move-result-object v1

    .line 868
    iput-object v1, v0, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 869
    .line 870
    const/4 v2, 0x3

    .line 871
    invoke-virtual {v7, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 872
    .line 873
    .line 874
    move-result-object v1

    .line 875
    iput-object v1, v0, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 876
    .line 877
    const/4 v15, 0x4

    .line 878
    invoke-static {v7, v15}, Lio/sentry/android/core/internal/threaddump/b;->b(Ljava/util/regex/Matcher;I)Ljava/lang/Long;

    .line 879
    .line 880
    .line 881
    move-result-object v1

    .line 882
    iput-object v1, v0, Lio/sentry/b5;->w:Ljava/lang/Long;

    .line 883
    .line 884
    iput-object v0, v4, Lio/sentry/protocol/z;->X:Lio/sentry/b5;

    .line 885
    .line 886
    invoke-static {v8, v0}, Lio/sentry/android/core/internal/threaddump/b;->a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V

    .line 887
    .line 888
    .line 889
    :goto_378
    move-object/from16 v0, v26

    .line 890
    .line 891
    move-object/from16 v10, v28

    .line 892
    .line 893
    const/4 v1, 0x1

    .line 894
    const/4 v2, 0x3

    .line 895
    goto :goto_3da

    .line 896
    :cond_37f
    const/4 v15, 0x4

    .line 897
    goto :goto_378

    .line 898
    :cond_381
    const/4 v15, 0x4

    .line 899
    invoke-static {v11, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 900
    .line 901
    .line 902
    move-result v0

    .line 903
    if-eqz v0, :cond_3b2

    .line 904
    .line 905
    if-eqz v4, :cond_3af

    .line 906
    .line 907
    new-instance v0, Lio/sentry/b5;

    .line 908
    .line 909
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 910
    .line 911
    .line 912
    iput v10, v0, Lio/sentry/b5;->d:I

    .line 913
    .line 914
    const/4 v1, 0x1

    .line 915
    invoke-virtual {v11, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 916
    .line 917
    .line 918
    move-result-object v10

    .line 919
    iput-object v10, v0, Lio/sentry/b5;->e:Ljava/lang/String;

    .line 920
    .line 921
    invoke-virtual {v11, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 922
    .line 923
    .line 924
    move-result-object v2

    .line 925
    iput-object v2, v0, Lio/sentry/b5;->i:Ljava/lang/String;

    .line 926
    .line 927
    const/4 v2, 0x3

    .line 928
    invoke-virtual {v11, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 929
    .line 930
    .line 931
    move-result-object v10

    .line 932
    iput-object v10, v0, Lio/sentry/b5;->v:Ljava/lang/String;

    .line 933
    .line 934
    iput-object v0, v4, Lio/sentry/protocol/z;->X:Lio/sentry/b5;

    .line 935
    .line 936
    invoke-static {v8, v0}, Lio/sentry/android/core/internal/threaddump/b;->a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V

    .line 937
    .line 938
    .line 939
    :goto_3aa
    move-object/from16 v0, v26

    .line 940
    .line 941
    :cond_3ac
    :goto_3ac
    move-object/from16 v10, v28

    .line 942
    .line 943
    goto :goto_3da

    .line 944
    :cond_3af
    const/4 v1, 0x1

    .line 945
    const/4 v2, 0x3

    .line 946
    goto :goto_3aa

    .line 947
    :cond_3b2
    move-object/from16 v0, v26

    .line 948
    .line 949
    const/4 v1, 0x1

    .line 950
    const/4 v2, 0x3

    .line 951
    invoke-static {v0, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 952
    .line 953
    .line 954
    move-result v17

    .line 955
    if-eqz v17, :cond_3cb

    .line 956
    .line 957
    if-eqz v4, :cond_3ac

    .line 958
    .line 959
    new-instance v12, Lio/sentry/b5;

    .line 960
    .line 961
    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    .line 962
    .line 963
    .line 964
    iput v10, v12, Lio/sentry/b5;->d:I

    .line 965
    .line 966
    iput-object v12, v4, Lio/sentry/protocol/z;->X:Lio/sentry/b5;

    .line 967
    .line 968
    invoke-static {v8, v12}, Lio/sentry/android/core/internal/threaddump/b;->a(Lio/sentry/protocol/d0;Lio/sentry/b5;)V

    .line 969
    .line 970
    .line 971
    goto :goto_3ac

    .line 972
    :cond_3cb
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 973
    .line 974
    .line 975
    move-result v10

    .line 976
    if-eqz v10, :cond_3ea

    .line 977
    .line 978
    move-object/from16 v10, v28

    .line 979
    .line 980
    invoke-static {v10, v12}, Lio/sentry/android/core/internal/threaddump/b;->c(Ljava/util/regex/Matcher;Ljava/lang/String;)Z

    .line 981
    .line 982
    .line 983
    move-result v12

    .line 984
    if-eqz v12, :cond_3da

    .line 985
    .line 986
    goto :goto_3ea

    .line 987
    :cond_3da
    :goto_3da
    move-object/from16 v1, p1

    .line 988
    .line 989
    move-object/from16 v26, v0

    .line 990
    .line 991
    move-object/from16 v28, v10

    .line 992
    .line 993
    move-object/from16 v15, v18

    .line 994
    .line 995
    move-object/from16 v10, v29

    .line 996
    .line 997
    move/from16 v2, v30

    .line 998
    .line 999
    move-object/from16 v0, p0

    .line 1000
    .line 1001
    goto/16 :goto_170

    .line 1002
    .line 1003
    :cond_3ea
    :goto_3ea
    invoke-static {v13}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    .line 1004
    .line 1005
    .line 1006
    new-instance v0, Lio/sentry/protocol/b0;

    .line 1007
    .line 1008
    invoke-direct {v0, v13}, Lio/sentry/protocol/b0;-><init>(Ljava/util/List;)V

    .line 1009
    .line 1010
    .line 1011
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1012
    .line 1013
    iput-object v1, v0, Lio/sentry/protocol/b0;->i:Ljava/lang/Boolean;

    .line 1014
    .line 1015
    iput-object v0, v8, Lio/sentry/protocol/d0;->K:Lio/sentry/protocol/b0;

    .line 1016
    .line 1017
    :goto_3f8
    move-object/from16 v0, p0

    .line 1018
    .line 1019
    if-eqz v8, :cond_401

    .line 1020
    .line 1021
    iget-object v1, v0, Lio/sentry/android/core/internal/threaddump/b;->e:Ljava/util/ArrayList;

    .line 1022
    .line 1023
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1024
    .line 1025
    .line 1026
    :cond_401
    :goto_401
    move-object/from16 v1, p1

    .line 1027
    .line 1028
    move-object/from16 v3, v20

    .line 1029
    .line 1030
    move-object/from16 v5, v21

    .line 1031
    .line 1032
    move-object/from16 v6, v22

    .line 1033
    .line 1034
    move-object/from16 v7, v23

    .line 1035
    .line 1036
    move-object/from16 v4, v27

    .line 1037
    .line 1038
    move/from16 v2, v30

    .line 1039
    .line 1040
    goto/16 :goto_14

    .line 1041
    .line 1042
    :cond_411
    return-void
.end method
