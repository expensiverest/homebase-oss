###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$FD (io.sentry.android.core.internal.tombstone.TombstoneProtos$FD)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/n;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lio/sentry/android/core/internal/tombstone/n;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

.field public static final FD_FIELD_NUMBER:I = 0x1

.field public static final OWNER_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/u2; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field

.field public static final PATH_FIELD_NUMBER:I = 0x2

.field public static final TAG_FIELD_NUMBER:I = 0x4


# instance fields
.field private fd_:I

.field private owner_:Ljava/lang/String;

.field private path_:Ljava/lang/String;

.field private tag_:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, ""

    .line 5
    .line 6
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->path_:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->owner_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method public static synthetic access$28000()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$28100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->setFd(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->clearFd()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->setPath(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->clearPath()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->setPathBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->setOwner(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->clearOwner()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->setOwnerBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$28900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;J)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->setTag(J)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->clearTag()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private clearFd()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->fd_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearOwner()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->getOwner()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->owner_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearPath()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->getPath()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->path_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearTag()V
    .registers 3

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->tag_:J

    .line 4
    .line 5
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 2
    .line 3
    return-object v0
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/m;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/m;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)Lio/sentry/android/core/internal/tombstone/m;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/m;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private setFd(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->fd_:I

    .line 2
    .line 3
    return-void
.end method

.method private setOwner(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->owner_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setOwnerBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->owner_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setPath(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->path_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setPathBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->path_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setTag(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->tag_:J

    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    packed-switch p1, :pswitch_data_58

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_d
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez p1, :cond_26

    .line 17
    .line 18
    const-class p2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 19
    .line 20
    monitor-enter p2

    .line 21
    :try_start_14
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez p1, :cond_22

    .line 24
    .line 25
    new-instance p1, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    goto :goto_24

    .line 35
    :cond_22
    :goto_22
    monitor-exit p2

    .line 36
    return-object p1

    .line 37
    :goto_24
    monitor-exit p2
    :try_end_25
    .catchall {:try_start_14 .. :try_end_25} :catchall_20

    .line 38
    throw p1

    .line 39
    :cond_26
    return-object p1

    .line 40
    :pswitch_27
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 41
    .line 42
    return-object p1

    .line 43
    :pswitch_2a
    new-instance p1, Lio/sentry/android/core/internal/tombstone/m;

    .line 44
    .line 45
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->access$28000()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    invoke-direct {p1, p2}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 50
    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_34
    new-instance p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 54
    .line 55
    invoke-direct {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;-><init>()V

    .line 56
    .line 57
    .line 58
    return-object p1

    .line 59
    :pswitch_3a
    const-string p1, "fd_"

    .line 60
    .line 61
    const-string p2, "path_"

    .line 62
    .line 63
    const-string p3, "owner_"

    .line 64
    .line 65
    const-string v0, "tag_"

    .line 66
    .line 67
    filled-new-array {p1, p2, p3, v0}, [Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    const-string p2, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0004\u0002\u0208\u0003\u0208\u0004\u0003"

    .line 72
    .line 73
    sget-object p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 74
    .line 75
    invoke-static {p3, p2, p1}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    return-object p1

    .line 80
    :pswitch_4f
    const/4 p1, 0x0

    .line 81
    return-object p1

    .line 82
    :pswitch_51
    const/4 p1, 0x1

    .line 83
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    return-object p1

    .line 88
    nop

    .line 89
    :pswitch_data_58
    .packed-switch 0x0
        :pswitch_51
        :pswitch_4f
        :pswitch_3a
        :pswitch_34
        :pswitch_2a
        :pswitch_27
        :pswitch_d
    .end packed-switch
.end method

.method public getFd()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->fd_:I

    .line 2
    .line 3
    return v0
.end method

.method public getOwner()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->owner_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOwnerBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->owner_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getPath()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->path_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getPathBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->path_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getTag()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;->tag_:J

    .line 2
    .line 3
    return-wide v0
.end method
