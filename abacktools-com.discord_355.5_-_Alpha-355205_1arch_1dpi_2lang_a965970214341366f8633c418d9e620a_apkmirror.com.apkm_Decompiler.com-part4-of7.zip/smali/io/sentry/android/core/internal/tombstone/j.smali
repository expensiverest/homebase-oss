###### Class io.sentry.android.core.internal.tombstone.j (io.sentry.android.core.internal.tombstone.j)
.class public interface abstract Lio/sentry/android/core/internal/tombstone/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
