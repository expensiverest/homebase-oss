###### Class io.sentry.android.core.internal.tombstone.k (io.sentry.android.core.internal.tombstone.k)
.class public final Lio/sentry/android/core/internal/tombstone/k;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/l;
