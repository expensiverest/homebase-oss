###### Class io.sentry.android.core.internal.tombstone.b0 (io.sentry.android.core.internal.tombstone.b0)
.class public interface abstract Lio/sentry/android/core/internal/tombstone/b0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
