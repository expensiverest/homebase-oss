###### Class io.sentry.android.core.internal.tombstone.i (io.sentry.android.core.internal.tombstone.i)
.class public final Lio/sentry/android/core/internal/tombstone/i;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/j;
