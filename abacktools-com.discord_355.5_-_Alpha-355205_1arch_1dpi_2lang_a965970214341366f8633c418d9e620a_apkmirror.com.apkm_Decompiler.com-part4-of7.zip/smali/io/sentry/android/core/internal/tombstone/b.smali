###### Class io.sentry.android.core.internal.tombstone.b (io.sentry.android.core.internal.tombstone.b)
.class public final Lio/sentry/android/core/internal/tombstone/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field public final d:Ljava/io/InputStream;

.field public final e:Ljava/util/List;

.field public final i:Ljava/util/List;

.field public final v:Ljava/lang/String;

.field public final w:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/b;->w:Ljava/util/HashMap;

    .line 10
    .line 11
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/b;->d:Ljava/io/InputStream;

    .line 12
    .line 13
    iput-object p2, p0, Lio/sentry/android/core/internal/tombstone/b;->e:Ljava/util/List;

    .line 14
    .line 15
    iput-object p3, p0, Lio/sentry/android/core/internal/tombstone/b;->i:Ljava/util/List;

    .line 16
    .line 17
    iput-object p4, p0, Lio/sentry/android/core/internal/tombstone/b;->v:Ljava/lang/String;

    .line 18
    .line 19
    const-string p1, "SIGILL"

    .line 20
    .line 21
    const-string p2, "IllegalInstruction"

    .line 22
    .line 23
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    const-string p1, "SIGTRAP"

    .line 27
    .line 28
    const-string p2, "Trap"

    .line 29
    .line 30
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    const-string p1, "SIGABRT"

    .line 34
    .line 35
    const-string p2, "Abort"

    .line 36
    .line 37
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    const-string p1, "SIGBUS"

    .line 41
    .line 42
    const-string p2, "BusError"

    .line 43
    .line 44
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    const-string p1, "SIGFPE"

    .line 48
    .line 49
    const-string p2, "FloatingPointException"

    .line 50
    .line 51
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    const-string p1, "SIGSEGV"

    .line 55
    .line 56
    const-string p2, "Segfault"

    .line 57
    .line 58
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    return-void
.end method


# virtual methods
.method public final c()Lio/sentry/t4;
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lio/sentry/android/core/internal/tombstone/b;->d:Ljava/io/InputStream;

    .line 4
    .line 5
    invoke-static {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    new-instance v2, Lio/sentry/t4;

    .line 10
    .line 11
    invoke-direct {v2}, Lio/sentry/t4;-><init>()V

    .line 12
    .line 13
    .line 14
    sget-object v3, Lio/sentry/a5;->FATAL:Lio/sentry/a5;

    .line 15
    .line 16
    iput-object v3, v2, Lio/sentry/t4;->W:Lio/sentry/a5;

    .line 17
    .line 18
    const-string v3, "native"

    .line 19
    .line 20
    iput-object v3, v2, Lio/sentry/i4;->J:Ljava/lang/String;

    .line 21
    .line 22
    new-instance v3, Lio/sentry/protocol/n;

    .line 23
    .line 24
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getSignalInfo()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getCommandLineList()Ljava/util/List;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    new-instance v6, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 38
    .line 39
    .line 40
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    if-eqz v7, :cond_46

    .line 49
    .line 50
    :goto_31
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    check-cast v7, Ljava/lang/CharSequence;

    .line 55
    .line 56
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    if-eqz v7, :cond_46

    .line 64
    .line 65
    const-string v7, " "

    .line 66
    .line 67
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    goto :goto_31

    .line 71
    :cond_46
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->hasSignalInfo()Z

    .line 76
    .line 77
    .line 78
    move-result v6

    .line 79
    const-string v7, ")"

    .line 80
    .line 81
    const-string v8, " ("

    .line 82
    .line 83
    if-eqz v6, :cond_b9

    .line 84
    .line 85
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getAbortMessage()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v6

    .line 89
    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 90
    .line 91
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 92
    .line 93
    .line 94
    move-result v9

    .line 95
    if-nez v9, :cond_67

    .line 96
    .line 97
    const-string v9, ": "

    .line 98
    .line 99
    invoke-virtual {v6, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v6

    .line 103
    goto :goto_69

    .line 104
    :cond_67
    const-string v6, ""

    .line 105
    .line 106
    :goto_69
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getName()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v9

    .line 110
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getNumber()I

    .line 111
    .line 112
    .line 113
    move-result v10

    .line 114
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getCodeName()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v11

    .line 118
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getCode()I

    .line 119
    .line 120
    .line 121
    move-result v4

    .line 122
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getPid()I

    .line 123
    .line 124
    .line 125
    move-result v12

    .line 126
    new-instance v13, Ljava/lang/StringBuilder;

    .line 127
    .line 128
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    const-string v6, "Fatal signal "

    .line 135
    .line 136
    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    const-string v6, "), "

    .line 149
    .line 150
    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 151
    .line 152
    .line 153
    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 157
    .line 158
    .line 159
    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    const-string v4, "), pid = "

    .line 163
    .line 164
    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    invoke-virtual {v13, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 177
    .line 178
    .line 179
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v4

    .line 183
    iput-object v4, v3, Lio/sentry/protocol/n;->d:Ljava/lang/String;

    .line 184
    .line 185
    goto :goto_d8

    .line 186
    :cond_b9
    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 187
    .line 188
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getPid()I

    .line 189
    .line 190
    .line 191
    move-result v4

    .line 192
    new-instance v6, Ljava/lang/StringBuilder;

    .line 193
    .line 194
    const-string v9, "Fatal exit pid = "

    .line 195
    .line 196
    invoke-direct {v6, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 200
    .line 201
    .line 202
    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 206
    .line 207
    .line 208
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v4

    .line 215
    iput-object v4, v3, Lio/sentry/protocol/n;->d:Ljava/lang/String;

    .line 216
    .line 217
    :goto_d8
    iput-object v3, v2, Lio/sentry/t4;->S:Lio/sentry/protocol/n;

    .line 218
    .line 219
    new-instance v3, Ljava/util/ArrayList;

    .line 220
    .line 221
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getMemoryMappingsList()Ljava/util/List;

    .line 225
    .line 226
    .line 227
    move-result-object v4

    .line 228
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 229
    .line 230
    .line 231
    move-result-object v4

    .line 232
    const/4 v5, 0x0

    .line 233
    :cond_e8
    :goto_e8
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 234
    .line 235
    .line 236
    move-result v6

    .line 237
    const/4 v7, 0x0

    .line 238
    const/4 v8, 0x1

    .line 239
    if-eqz v6, :cond_178

    .line 240
    .line 241
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v6

    .line 245
    check-cast v6, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;

    .line 246
    .line 247
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getRead()Z

    .line 248
    .line 249
    .line 250
    move-result v9

    .line 251
    if-nez v9, :cond_fd

    .line 252
    .line 253
    goto :goto_e8

    .line 254
    :cond_fd
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getMappingName()Ljava/lang/String;

    .line 255
    .line 256
    .line 257
    move-result-object v9

    .line 258
    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    .line 259
    .line 260
    .line 261
    move-result v10

    .line 262
    if-nez v10, :cond_e8

    .line 263
    .line 264
    const-string v10, "/dev/"

    .line 265
    .line 266
    invoke-virtual {v9, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 267
    .line 268
    .line 269
    move-result v10

    .line 270
    if-eqz v10, :cond_110

    .line 271
    .line 272
    goto :goto_e8

    .line 273
    :cond_110
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getBuildId()Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v10

    .line 277
    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    .line 278
    .line 279
    .line 280
    move-result v10

    .line 281
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getOffset()J

    .line 282
    .line 283
    .line 284
    move-result-wide v11

    .line 285
    const-wide/16 v13, 0x0

    .line 286
    .line 287
    cmp-long v11, v11, v13

    .line 288
    .line 289
    if-nez v11, :cond_123

    .line 290
    .line 291
    move v7, v8

    .line 292
    :cond_123
    if-nez v10, :cond_164

    .line 293
    .line 294
    if-eqz v7, :cond_164

    .line 295
    .line 296
    if-eqz v5, :cond_13a

    .line 297
    .line 298
    iget-object v7, v5, Les/c;->v:Ljava/lang/Object;

    .line 299
    .line 300
    check-cast v7, Ljava/lang/String;

    .line 301
    .line 302
    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 303
    .line 304
    .line 305
    move-result v7

    .line 306
    if-eqz v7, :cond_13a

    .line 307
    .line 308
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getEndAddress()J

    .line 309
    .line 310
    .line 311
    move-result-wide v6

    .line 312
    iput-wide v6, v5, Les/c;->i:J

    .line 313
    .line 314
    goto :goto_e8

    .line 315
    :cond_13a
    if-eqz v5, :cond_145

    .line 316
    .line 317
    invoke-virtual {v5}, Les/c;->c()Lio/sentry/protocol/DebugImage;

    .line 318
    .line 319
    .line 320
    move-result-object v5

    .line 321
    if-eqz v5, :cond_145

    .line 322
    .line 323
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    :cond_145
    new-instance v5, Les/c;

    .line 327
    .line 328
    const/4 v7, 0x2

    .line 329
    invoke-direct {v5, v7}, Les/c;-><init>(I)V

    .line 330
    .line 331
    .line 332
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getMappingName()Ljava/lang/String;

    .line 333
    .line 334
    .line 335
    move-result-object v7

    .line 336
    iput-object v7, v5, Les/c;->v:Ljava/lang/Object;

    .line 337
    .line 338
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getBuildId()Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v7

    .line 342
    iput-object v7, v5, Les/c;->w:Ljava/lang/Object;

    .line 343
    .line 344
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getBeginAddress()J

    .line 345
    .line 346
    .line 347
    move-result-wide v7

    .line 348
    iput-wide v7, v5, Les/c;->e:J

    .line 349
    .line 350
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getEndAddress()J

    .line 351
    .line 352
    .line 353
    move-result-wide v6

    .line 354
    iput-wide v6, v5, Les/c;->i:J

    .line 355
    .line 356
    goto :goto_e8

    .line 357
    :cond_164
    if-eqz v5, :cond_e8

    .line 358
    .line 359
    iget-object v7, v5, Les/c;->v:Ljava/lang/Object;

    .line 360
    .line 361
    check-cast v7, Ljava/lang/String;

    .line 362
    .line 363
    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 364
    .line 365
    .line 366
    move-result v7

    .line 367
    if-eqz v7, :cond_e8

    .line 368
    .line 369
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;->getEndAddress()J

    .line 370
    .line 371
    .line 372
    move-result-wide v6

    .line 373
    iput-wide v6, v5, Les/c;->i:J

    .line 374
    .line 375
    goto/16 :goto_e8

    .line 376
    .line 377
    :cond_178
    if-eqz v5, :cond_183

    .line 378
    .line 379
    invoke-virtual {v5}, Les/c;->c()Lio/sentry/protocol/DebugImage;

    .line 380
    .line 381
    .line 382
    move-result-object v4

    .line 383
    if-eqz v4, :cond_183

    .line 384
    .line 385
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 386
    .line 387
    .line 388
    :cond_183
    new-instance v4, Lio/sentry/protocol/d;

    .line 389
    .line 390
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 391
    .line 392
    .line 393
    new-instance v5, Ljava/util/ArrayList;

    .line 394
    .line 395
    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 396
    .line 397
    .line 398
    iput-object v5, v4, Lio/sentry/protocol/d;->e:Ljava/util/List;

    .line 399
    .line 400
    iput-object v4, v2, Lio/sentry/i4;->P:Lio/sentry/protocol/d;

    .line 401
    .line 402
    new-instance v3, Lio/sentry/protocol/u;

    .line 403
    .line 404
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->hasSignalInfo()Z

    .line 408
    .line 409
    .line 410
    move-result v4

    .line 411
    if-eqz v4, :cond_203

    .line 412
    .line 413
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getSignalInfo()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 414
    .line 415
    .line 416
    move-result-object v4

    .line 417
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getName()Ljava/lang/String;

    .line 418
    .line 419
    .line 420
    move-result-object v5

    .line 421
    iput-object v5, v3, Lio/sentry/protocol/u;->d:Ljava/lang/String;

    .line 422
    .line 423
    iget-object v5, v0, Lio/sentry/android/core/internal/tombstone/b;->w:Ljava/util/HashMap;

    .line 424
    .line 425
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getName()Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object v6

    .line 429
    invoke-virtual {v5, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v5

    .line 433
    check-cast v5, Ljava/lang/String;

    .line 434
    .line 435
    iput-object v5, v3, Lio/sentry/protocol/u;->e:Ljava/lang/String;

    .line 436
    .line 437
    new-instance v5, Lio/sentry/protocol/m;

    .line 438
    .line 439
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 440
    .line 441
    .line 442
    sget-object v6, Lio/sentry/android/core/internal/tombstone/a;->TOMBSTONE:Lio/sentry/android/core/internal/tombstone/a;

    .line 443
    .line 444
    invoke-virtual {v6}, Lio/sentry/android/core/internal/tombstone/a;->getValue()Ljava/lang/String;

    .line 445
    .line 446
    .line 447
    move-result-object v6

    .line 448
    iput-object v6, v5, Lio/sentry/protocol/m;->d:Ljava/lang/String;

    .line 449
    .line 450
    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 451
    .line 452
    iput-object v6, v5, Lio/sentry/protocol/m;->v:Ljava/lang/Boolean;

    .line 453
    .line 454
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 455
    .line 456
    iput-object v6, v5, Lio/sentry/protocol/m;->y:Ljava/lang/Boolean;

    .line 457
    .line 458
    new-instance v6, Ljava/util/HashMap;

    .line 459
    .line 460
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 461
    .line 462
    .line 463
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getNumber()I

    .line 464
    .line 465
    .line 466
    move-result v9

    .line 467
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 468
    .line 469
    .line 470
    move-result-object v9

    .line 471
    const-string v10, "number"

    .line 472
    .line 473
    invoke-virtual {v6, v10, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 474
    .line 475
    .line 476
    const-string v9, "name"

    .line 477
    .line 478
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getName()Ljava/lang/String;

    .line 479
    .line 480
    .line 481
    move-result-object v10

    .line 482
    invoke-virtual {v6, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 483
    .line 484
    .line 485
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getCode()I

    .line 486
    .line 487
    .line 488
    move-result v9

    .line 489
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 490
    .line 491
    .line 492
    move-result-object v9

    .line 493
    const-string v10, "code"

    .line 494
    .line 495
    invoke-virtual {v6, v10, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    const-string v9, "code_name"

    .line 499
    .line 500
    invoke-virtual {v4}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getCodeName()Ljava/lang/String;

    .line 501
    .line 502
    .line 503
    move-result-object v4

    .line 504
    invoke-virtual {v6, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 505
    .line 506
    .line 507
    new-instance v4, Ljava/util/HashMap;

    .line 508
    .line 509
    invoke-direct {v4, v6}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 510
    .line 511
    .line 512
    iput-object v4, v5, Lio/sentry/protocol/m;->w:Ljava/util/AbstractMap;

    .line 513
    .line 514
    iput-object v5, v3, Lio/sentry/protocol/u;->x:Lio/sentry/protocol/m;

    .line 515
    .line 516
    :cond_203
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getTid()I

    .line 517
    .line 518
    .line 519
    move-result v4

    .line 520
    int-to-long v4, v4

    .line 521
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 522
    .line 523
    .line 524
    move-result-object v4

    .line 525
    iput-object v4, v3, Lio/sentry/protocol/u;->v:Ljava/lang/Long;

    .line 526
    .line 527
    new-instance v4, Ljava/util/ArrayList;

    .line 528
    .line 529
    invoke-direct {v4, v8}, Ljava/util/ArrayList;-><init>(I)V

    .line 530
    .line 531
    .line 532
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    new-instance v3, Lg8/k;

    .line 536
    .line 537
    invoke-direct {v3, v4}, Lg8/k;-><init>(Ljava/util/List;)V

    .line 538
    .line 539
    .line 540
    iput-object v3, v2, Lio/sentry/t4;->V:Lg8/k;

    .line 541
    .line 542
    invoke-virtual {v2}, Lio/sentry/t4;->d()Ljava/util/ArrayList;

    .line 543
    .line 544
    .line 545
    move-result-object v3

    .line 546
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 547
    .line 548
    .line 549
    invoke-interface {v3, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 550
    .line 551
    .line 552
    move-result-object v3

    .line 553
    check-cast v3, Lio/sentry/protocol/u;

    .line 554
    .line 555
    new-instance v4, Ljava/util/ArrayList;

    .line 556
    .line 557
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 558
    .line 559
    .line 560
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getThreadsMap()Ljava/util/Map;

    .line 561
    .line 562
    .line 563
    move-result-object v5

    .line 564
    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 565
    .line 566
    .line 567
    move-result-object v5

    .line 568
    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 569
    .line 570
    .line 571
    move-result-object v5

    .line 572
    :goto_23b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 573
    .line 574
    .line 575
    move-result v6

    .line 576
    if-eqz v6, :cond_360

    .line 577
    .line 578
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 579
    .line 580
    .line 581
    move-result-object v6

    .line 582
    check-cast v6, Ljava/util/Map$Entry;

    .line 583
    .line 584
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 585
    .line 586
    .line 587
    move-result-object v9

    .line 588
    check-cast v9, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 589
    .line 590
    new-instance v10, Lio/sentry/protocol/d0;

    .line 591
    .line 592
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 593
    .line 594
    .line 595
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 596
    .line 597
    .line 598
    move-result-object v6

    .line 599
    check-cast v6, Ljava/lang/Integer;

    .line 600
    .line 601
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 602
    .line 603
    .line 604
    move-result v6

    .line 605
    int-to-long v11, v6

    .line 606
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 607
    .line 608
    .line 609
    move-result-object v6

    .line 610
    iput-object v6, v10, Lio/sentry/protocol/d0;->d:Ljava/lang/Long;

    .line 611
    .line 612
    invoke-virtual {v9}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getName()Ljava/lang/String;

    .line 613
    .line 614
    .line 615
    move-result-object v6

    .line 616
    iput-object v6, v10, Lio/sentry/protocol/d0;->i:Ljava/lang/String;

    .line 617
    .line 618
    new-instance v6, Ljava/util/ArrayList;

    .line 619
    .line 620
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 621
    .line 622
    .line 623
    invoke-virtual {v9}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getCurrentBacktraceList()Ljava/util/List;

    .line 624
    .line 625
    .line 626
    move-result-object v11

    .line 627
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 628
    .line 629
    .line 630
    move-result-object v11

    .line 631
    :goto_276
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 632
    .line 633
    .line 634
    move-result v12

    .line 635
    const-string v13, "0x%x"

    .line 636
    .line 637
    if-eqz v12, :cond_30a

    .line 638
    .line 639
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 640
    .line 641
    .line 642
    move-result-object v12

    .line 643
    check-cast v12, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;

    .line 644
    .line 645
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFileName()Ljava/lang/String;

    .line 646
    .line 647
    .line 648
    move-result-object v14

    .line 649
    const-string v15, "libart.so"

    .line 650
    .line 651
    invoke-virtual {v14, v15}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 652
    .line 653
    .line 654
    move-result v14

    .line 655
    if-eqz v14, :cond_291

    .line 656
    .line 657
    goto :goto_276

    .line 658
    :cond_291
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFileName()Ljava/lang/String;

    .line 659
    .line 660
    .line 661
    move-result-object v14

    .line 662
    const-string v15, "<anonymous"

    .line 663
    .line 664
    invoke-virtual {v14, v15}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 665
    .line 666
    .line 667
    move-result v14

    .line 668
    if-eqz v14, :cond_2a8

    .line 669
    .line 670
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFunctionName()Ljava/lang/String;

    .line 671
    .line 672
    .line 673
    move-result-object v14

    .line 674
    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    .line 675
    .line 676
    .line 677
    move-result v14

    .line 678
    if-eqz v14, :cond_2a8

    .line 679
    .line 680
    goto :goto_276

    .line 681
    :cond_2a8
    new-instance v14, Lio/sentry/protocol/z;

    .line 682
    .line 683
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 684
    .line 685
    .line 686
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFileName()Ljava/lang/String;

    .line 687
    .line 688
    .line 689
    move-result-object v15

    .line 690
    iput-object v15, v14, Lio/sentry/protocol/z;->N:Ljava/lang/String;

    .line 691
    .line 692
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFunctionName()Ljava/lang/String;

    .line 693
    .line 694
    .line 695
    move-result-object v15

    .line 696
    iput-object v15, v14, Lio/sentry/protocol/z;->w:Ljava/lang/String;

    .line 697
    .line 698
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getPc()J

    .line 699
    .line 700
    .line 701
    move-result-wide v15

    .line 702
    invoke-static/range {v15 .. v16}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 703
    .line 704
    .line 705
    move-result-object v15

    .line 706
    filled-new-array {v15}, [Ljava/lang/Object;

    .line 707
    .line 708
    .line 709
    move-result-object v15

    .line 710
    invoke-static {v13, v15}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 711
    .line 712
    .line 713
    move-result-object v13

    .line 714
    iput-object v13, v14, Lio/sentry/protocol/z;->S:Ljava/lang/String;

    .line 715
    .line 716
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFunctionName()Ljava/lang/String;

    .line 717
    .line 718
    .line 719
    move-result-object v13

    .line 720
    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    .line 721
    .line 722
    .line 723
    move-result v15

    .line 724
    if-eqz v15, :cond_2d8

    .line 725
    .line 726
    sget-object v13, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 727
    .line 728
    goto :goto_2e0

    .line 729
    :cond_2d8
    iget-object v15, v0, Lio/sentry/android/core/internal/tombstone/b;->e:Ljava/util/List;

    .line 730
    .line 731
    iget-object v8, v0, Lio/sentry/android/core/internal/tombstone/b;->i:Ljava/util/List;

    .line 732
    .line 733
    invoke-static {v13, v15, v8}, Landroidx/core/view/d0;->p(Ljava/lang/String;Ljava/util/List;Ljava/util/List;)Ljava/lang/Boolean;

    .line 734
    .line 735
    .line 736
    move-result-object v13

    .line 737
    :goto_2e0
    iget-object v8, v0, Lio/sentry/android/core/internal/tombstone/b;->v:Ljava/lang/String;

    .line 738
    .line 739
    if-eqz v8, :cond_2f0

    .line 740
    .line 741
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;->getFileName()Ljava/lang/String;

    .line 742
    .line 743
    .line 744
    move-result-object v12

    .line 745
    invoke-virtual {v12, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 746
    .line 747
    .line 748
    move-result v8

    .line 749
    if-eqz v8, :cond_2f0

    .line 750
    .line 751
    const/4 v8, 0x1

    .line 752
    goto :goto_2f1

    .line 753
    :cond_2f0
    move v8, v7

    .line 754
    :goto_2f1
    if-eqz v13, :cond_2f9

    .line 755
    .line 756
    invoke-virtual {v13}, Ljava/lang/Boolean;->booleanValue()Z

    .line 757
    .line 758
    .line 759
    move-result v12

    .line 760
    if-nez v12, :cond_2fb

    .line 761
    .line 762
    :cond_2f9
    if-eqz v8, :cond_2fd

    .line 763
    .line 764
    :cond_2fb
    const/4 v8, 0x1

    .line 765
    goto :goto_2fe

    .line 766
    :cond_2fd
    move v8, v7

    .line 767
    :goto_2fe
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 768
    .line 769
    .line 770
    move-result-object v8

    .line 771
    iput-object v8, v14, Lio/sentry/protocol/z;->M:Ljava/lang/Boolean;

    .line 772
    .line 773
    invoke-virtual {v6, v7, v14}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 774
    .line 775
    .line 776
    const/4 v8, 0x1

    .line 777
    goto/16 :goto_276

    .line 778
    .line 779
    :cond_30a
    new-instance v8, Lio/sentry/protocol/b0;

    .line 780
    .line 781
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 782
    .line 783
    .line 784
    iput-object v6, v8, Lio/sentry/protocol/b0;->d:Ljava/util/List;

    .line 785
    .line 786
    sget-object v6, Lio/sentry/protocol/a0;->NONE:Lio/sentry/protocol/a0;

    .line 787
    .line 788
    iput-object v6, v8, Lio/sentry/protocol/b0;->v:Lio/sentry/protocol/a0;

    .line 789
    .line 790
    new-instance v6, Ljava/util/HashMap;

    .line 791
    .line 792
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 793
    .line 794
    .line 795
    invoke-virtual {v9}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getRegistersList()Ljava/util/List;

    .line 796
    .line 797
    .line 798
    move-result-object v11

    .line 799
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 800
    .line 801
    .line 802
    move-result-object v11

    .line 803
    :goto_322
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 804
    .line 805
    .line 806
    move-result v12

    .line 807
    if-eqz v12, :cond_346

    .line 808
    .line 809
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 810
    .line 811
    .line 812
    move-result-object v12

    .line 813
    check-cast v12, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;

    .line 814
    .line 815
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;->getName()Ljava/lang/String;

    .line 816
    .line 817
    .line 818
    move-result-object v14

    .line 819
    invoke-virtual {v12}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;->getU64()J

    .line 820
    .line 821
    .line 822
    move-result-wide v17

    .line 823
    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 824
    .line 825
    .line 826
    move-result-object v12

    .line 827
    filled-new-array {v12}, [Ljava/lang/Object;

    .line 828
    .line 829
    .line 830
    move-result-object v12

    .line 831
    invoke-static {v13, v12}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 832
    .line 833
    .line 834
    move-result-object v12

    .line 835
    invoke-virtual {v6, v14, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 836
    .line 837
    .line 838
    goto :goto_322

    .line 839
    :cond_346
    iput-object v6, v8, Lio/sentry/protocol/b0;->e:Ljava/util/AbstractMap;

    .line 840
    .line 841
    iput-object v8, v10, Lio/sentry/protocol/d0;->K:Lio/sentry/protocol/b0;

    .line 842
    .line 843
    invoke-virtual {v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getTid()I

    .line 844
    .line 845
    .line 846
    move-result v6

    .line 847
    invoke-virtual {v9}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getId()I

    .line 848
    .line 849
    .line 850
    move-result v9

    .line 851
    if-ne v6, v9, :cond_35a

    .line 852
    .line 853
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 854
    .line 855
    iput-object v6, v10, Lio/sentry/protocol/d0;->w:Ljava/lang/Boolean;

    .line 856
    .line 857
    iput-object v8, v3, Lio/sentry/protocol/u;->w:Lio/sentry/protocol/b0;

    .line 858
    .line 859
    :cond_35a
    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 860
    .line 861
    .line 862
    const/4 v8, 0x1

    .line 863
    goto/16 :goto_23b

    .line 864
    .line 865
    :cond_360
    new-instance v1, Lg8/k;

    .line 866
    .line 867
    invoke-direct {v1, v4}, Lg8/k;-><init>(Ljava/util/List;)V

    .line 868
    .line 869
    .line 870
    iput-object v1, v2, Lio/sentry/t4;->U:Lg8/k;

    .line 871
    .line 872
    return-object v2
.end method

.method public final close()V
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/b;->d:Ljava/io/InputStream;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
