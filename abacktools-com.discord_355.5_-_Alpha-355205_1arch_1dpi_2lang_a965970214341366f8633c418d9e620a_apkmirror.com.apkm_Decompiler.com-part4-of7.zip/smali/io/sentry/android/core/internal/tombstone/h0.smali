###### Class io.sentry.android.core.internal.tombstone.h0 (io.sentry.android.core.internal.tombstone.h0)
.class public interface abstract Lio/sentry/android/core/internal/tombstone/h0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
