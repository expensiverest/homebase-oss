###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone (io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lcom/google/protobuf/h2;"
    }
.end annotation


# static fields
.field public static final ABORT_MESSAGE_FIELD_NUMBER:I = 0xe

.field public static final ARCH_FIELD_NUMBER:I = 0x1

.field public static final BUILD_FINGERPRINT_FIELD_NUMBER:I = 0x2

.field public static final CAUSES_FIELD_NUMBER:I = 0xf

.field public static final COMMAND_LINE_FIELD_NUMBER:I = 0x9

.field public static final CRASH_DETAILS_FIELD_NUMBER:I = 0x15

.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

.field public static final GUEST_ARCH_FIELD_NUMBER:I = 0x18

.field public static final GUEST_THREADS_FIELD_NUMBER:I = 0x19

.field public static final HAS_BEEN_16KB_MODE_FIELD_NUMBER:I = 0x17

.field public static final LOG_BUFFERS_FIELD_NUMBER:I = 0x12

.field public static final MEMORY_MAPPINGS_FIELD_NUMBER:I = 0x11

.field public static final OPEN_FDS_FIELD_NUMBER:I = 0x13

.field public static final PAGE_SIZE_FIELD_NUMBER:I = 0x16

.field private static volatile PARSER:Lcom/google/protobuf/u2; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field

.field public static final PID_FIELD_NUMBER:I = 0x5

.field public static final PROCESS_UPTIME_FIELD_NUMBER:I = 0x14

.field public static final REVISION_FIELD_NUMBER:I = 0x3

.field public static final SELINUX_LABEL_FIELD_NUMBER:I = 0x8

.field public static final SIGNAL_INFO_FIELD_NUMBER:I = 0xa

.field public static final STACK_HISTORY_BUFFER_FIELD_NUMBER:I = 0x1a

.field public static final THREADS_FIELD_NUMBER:I = 0x10

.field public static final TID_FIELD_NUMBER:I = 0x6

.field public static final TIMESTAMP_FIELD_NUMBER:I = 0x4

.field public static final UID_FIELD_NUMBER:I = 0x7


# instance fields
.field private abortMessage_:Ljava/lang/String;

.field private arch_:I

.field private bitField0_:I

.field private buildFingerprint_:Ljava/lang/String;

.field private causes_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private commandLine_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private crashDetails_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private guestArch_:I

.field private guestThreads_:Lcom/google/protobuf/b2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/b2;"
        }
    .end annotation
.end field

.field private hasBeen16KbMode_:Z

.field private logBuffers_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private memoryMappings_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private openFds_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private pageSize_:I

.field private pid_:I

.field private processUptime_:I

.field private revision_:Ljava/lang/String;

.field private selinuxLabel_:Ljava/lang/String;

.field private signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

.field private stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

.field private threads_:Lcom/google/protobuf/b2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/b2;"
        }
    .end annotation
.end field

.field private tid_:I

.field private timestamp_:Ljava/lang/String;

.field private uid_:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/google/protobuf/b2;->e:Lcom/google/protobuf/b2;

    .line 5
    .line 6
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->threads_:Lcom/google/protobuf/b2;

    .line 7
    .line 8
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestThreads_:Lcom/google/protobuf/b2;

    .line 9
    .line 10
    const-string v0, ""

    .line 11
    .line 12
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->buildFingerprint_:Ljava/lang/String;

    .line 13
    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->revision_:Ljava/lang/String;

    .line 15
    .line 16
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->timestamp_:Ljava/lang/String;

    .line 17
    .line 18
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->selinuxLabel_:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iput-object v1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 25
    .line 26
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->abortMessage_:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 33
    .line 34
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 39
    .line 40
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 45
    .line 46
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 51
    .line 52
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 57
    .line 58
    return-void
.end method

.method public static synthetic access$10000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->mergeStackHistoryBuffer(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$10100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearStackHistoryBuffer()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$2500()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$2600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setArchValue(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$2700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/e;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setArch(Lio/sentry/android/core/internal/tombstone/e;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$2800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearArch()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$2900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setGuestArchValue(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/e;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setGuestArch(Lio/sentry/android/core/internal/tombstone/e;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearGuestArch()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setBuildFingerprint(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearBuildFingerprint()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setBuildFingerprintBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setRevision(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearRevision()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setRevisionBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setTimestamp(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$3900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearTimestamp()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setTimestampBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setPid(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearPid()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setTid(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearTid()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setUid(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearUid()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setSelinuxLabel(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearSelinuxLabel()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$4900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setSelinuxLabelBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILjava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setCommandLine(ILjava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addCommandLine(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addAllCommandLine(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearCommandLine()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addCommandLineBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setProcessUptime(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearProcessUptime()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setSignalInfo(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->mergeSignalInfo(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$5900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearSignalInfo()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setAbortMessage(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearAbortMessage()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setAbortMessageBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setCrashDetails(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addCrashDetails(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addCrashDetails(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addAllCrashDetails(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearCrashDetails()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->removeCrashDetails(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$6900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setCauses(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addCauses(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addCauses(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addAllCauses(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearCauses()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->removeCauses(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)Ljava/util/Map;
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getMutableThreadsMap()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static synthetic access$7600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)Ljava/util/Map;
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getMutableGuestThreadsMap()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static synthetic access$7700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setMemoryMappings(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addMemoryMappings(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$7900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addMemoryMappings(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addAllMemoryMappings(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearMemoryMappings()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->removeMemoryMappings(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setLogBuffers(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addLogBuffers(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addLogBuffers(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addAllLogBuffers(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearLogBuffers()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->removeLogBuffers(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$8900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setOpenFds(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addOpenFds(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addOpenFds(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->addAllOpenFds(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearOpenFds()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->removeOpenFds(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setPageSize(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearPageSize()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Z)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setHasBeen16KbMode(Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->clearHasBeen16KbMode()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$9900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->setStackHistoryBuffer(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private addAllCauses(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCausesIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllCommandLine(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCommandLineIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllCrashDetails(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCrashDetailsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllLogBuffers(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureLogBuffersIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllMemoryMappings(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureMemoryMappingsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllOpenFds(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureOpenFdsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addCauses(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCausesIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addCauses(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCausesIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addCommandLine(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCommandLineIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private addCommandLineBytes(Lcom/google/protobuf/n;)V
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCommandLineIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method private addCrashDetails(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCrashDetailsIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addCrashDetails(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCrashDetailsIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addLogBuffers(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureLogBuffersIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addLogBuffers(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureLogBuffersIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addMemoryMappings(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureMemoryMappingsIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addMemoryMappings(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureMemoryMappingsIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addOpenFds(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureOpenFdsIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addOpenFds(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureOpenFdsIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearAbortMessage()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getAbortMessage()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->abortMessage_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearArch()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->arch_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearBuildFingerprint()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getBuildFingerprint()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->buildFingerprint_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearCauses()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearCommandLine()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearCrashDetails()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearGuestArch()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestArch_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearHasBeen16KbMode()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->hasBeen16KbMode_:Z

    .line 3
    .line 4
    return-void
.end method

.method private clearLogBuffers()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearMemoryMappings()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearOpenFds()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearPageSize()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->pageSize_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearPid()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->pid_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearProcessUptime()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->processUptime_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearRevision()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getRevision()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->revision_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearSelinuxLabel()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getSelinuxLabel()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->selinuxLabel_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearSignalInfo()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 3
    .line 4
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 5
    .line 6
    and-int/lit8 v0, v0, -0x2

    .line 7
    .line 8
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 9
    .line 10
    return-void
.end method

.method private clearStackHistoryBuffer()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 3
    .line 4
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 5
    .line 6
    and-int/lit8 v0, v0, -0x3

    .line 7
    .line 8
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 9
    .line 10
    return-void
.end method

.method private clearTid()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->tid_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearTimestamp()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getTimestamp()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->timestamp_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearUid()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->uid_:I

    .line 3
    .line 4
    return-void
.end method

.method private ensureCausesIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureCommandLineIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureCrashDetailsIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureLogBuffersIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureMemoryMappingsIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureOpenFdsIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    return-object v0
.end method

.method private getMutableGuestThreadsMap()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetMutableGuestThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method private getMutableThreadsMap()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetMutableThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method private internalGetGuestThreads()Lcom/google/protobuf/b2;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/b2;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestThreads_:Lcom/google/protobuf/b2;

    .line 2
    .line 3
    return-object v0
.end method

.method private internalGetMutableGuestThreads()Lcom/google/protobuf/b2;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/b2;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestThreads_:Lcom/google/protobuf/b2;

    .line 2
    .line 3
    iget-boolean v1, v0, Lcom/google/protobuf/b2;->d:Z

    .line 4
    .line 5
    if-nez v1, :cond_c

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/google/protobuf/b2;->c()Lcom/google/protobuf/b2;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestThreads_:Lcom/google/protobuf/b2;

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestThreads_:Lcom/google/protobuf/b2;

    .line 14
    .line 15
    return-object v0
.end method

.method private internalGetMutableThreads()Lcom/google/protobuf/b2;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/b2;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->threads_:Lcom/google/protobuf/b2;

    .line 2
    .line 3
    iget-boolean v1, v0, Lcom/google/protobuf/b2;->d:Z

    .line 4
    .line 5
    if-nez v1, :cond_c

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/google/protobuf/b2;->c()Lcom/google/protobuf/b2;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->threads_:Lcom/google/protobuf/b2;

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->threads_:Lcom/google/protobuf/b2;

    .line 14
    .line 15
    return-object v0
.end method

.method private internalGetThreads()Lcom/google/protobuf/b2;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/b2;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->threads_:Lcom/google/protobuf/b2;

    .line 2
    .line 3
    return-object v0
.end method

.method private mergeSignalInfo(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 5
    .line 6
    if-eqz v0, :cond_1f

    .line 7
    .line 8
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eq v0, v1, :cond_1f

    .line 13
    .line 14
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 15
    .line 16
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)Lio/sentry/android/core/internal/tombstone/e0;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0, p1}, Lcom/google/protobuf/u0;->e(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Lcom/google/protobuf/u0;->c()Lcom/google/protobuf/a1;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 28
    .line 29
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 33
    .line 34
    :goto_21
    iget p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 35
    .line 36
    or-int/lit8 p1, p1, 0x1

    .line 37
    .line 38
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 39
    .line 40
    return-void
.end method

.method private mergeStackHistoryBuffer(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 5
    .line 6
    if-eqz v0, :cond_1f

    .line 7
    .line 8
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eq v0, v1, :cond_1f

    .line 13
    .line 14
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 15
    .line 16
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;->newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)Lio/sentry/android/core/internal/tombstone/f0;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0, p1}, Lcom/google/protobuf/u0;->e(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Lcom/google/protobuf/u0;->c()Lcom/google/protobuf/a1;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 28
    .line 29
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 33
    .line 34
    :goto_21
    iget p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 35
    .line 36
    or-int/lit8 p1, p1, 0x2

    .line 37
    .line 38
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 39
    .line 40
    return-void
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/j0;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/j0;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;)Lio/sentry/android/core/internal/tombstone/j0;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/j0;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private removeCauses(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCausesIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private removeCrashDetails(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCrashDetailsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private removeLogBuffers(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureLogBuffersIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private removeMemoryMappings(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureMemoryMappingsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private removeOpenFds(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureOpenFdsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private setAbortMessage(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->abortMessage_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setAbortMessageBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->abortMessage_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setArch(Lio/sentry/android/core/internal/tombstone/e;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Lio/sentry/android/core/internal/tombstone/e;->getNumber()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->arch_:I

    .line 6
    .line 7
    return-void
.end method

.method private setArchValue(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->arch_:I

    .line 2
    .line 3
    return-void
.end method

.method private setBuildFingerprint(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->buildFingerprint_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setBuildFingerprintBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->buildFingerprint_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setCauses(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCausesIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setCommandLine(ILjava/lang/String;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCommandLineIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setCrashDetails(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureCrashDetailsIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setGuestArch(Lio/sentry/android/core/internal/tombstone/e;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Lio/sentry/android/core/internal/tombstone/e;->getNumber()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestArch_:I

    .line 6
    .line 7
    return-void
.end method

.method private setGuestArchValue(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestArch_:I

    .line 2
    .line 3
    return-void
.end method

.method private setHasBeen16KbMode(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->hasBeen16KbMode_:Z

    .line 2
    .line 3
    return-void
.end method

.method private setLogBuffers(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureLogBuffersIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setMemoryMappings(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureMemoryMappingsIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setOpenFds(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->ensureOpenFdsIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setPageSize(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->pageSize_:I

    .line 2
    .line 3
    return-void
.end method

.method private setPid(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->pid_:I

    .line 2
    .line 3
    return-void
.end method

.method private setProcessUptime(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->processUptime_:I

    .line 2
    .line 3
    return-void
.end method

.method private setRevision(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->revision_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setRevisionBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->revision_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setSelinuxLabel(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->selinuxLabel_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setSelinuxLabelBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->selinuxLabel_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setSignalInfo(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 5
    .line 6
    iget p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 7
    .line 8
    or-int/lit8 p1, p1, 0x1

    .line 9
    .line 10
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 11
    .line 12
    return-void
.end method

.method private setStackHistoryBuffer(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 5
    .line 6
    iget p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 7
    .line 8
    or-int/lit8 p1, p1, 0x2

    .line 9
    .line 10
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 11
    .line 12
    return-void
.end method

.method private setTid(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->tid_:I

    .line 2
    .line 3
    return-void
.end method

.method private setTimestamp(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->timestamp_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setTimestampBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->timestamp_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setUid(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->uid_:I

    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public containsGuestThreads(I)Z
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetGuestThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    return p1
.end method

.method public containsThreads(I)Z
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    return p1
.end method

.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 37

    .line 1
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    packed-switch v0, :pswitch_data_8e

    .line 6
    .line 7
    .line 8
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw v0

    .line 14
    :pswitch_d
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez v0, :cond_26

    .line 17
    .line 18
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 19
    .line 20
    monitor-enter v1

    .line 21
    :try_start_14
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez v0, :cond_22

    .line 24
    .line 25
    new-instance v0, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :catchall_20
    move-exception v0

    .line 34
    goto :goto_24

    .line 35
    :cond_22
    :goto_22
    monitor-exit v1

    .line 36
    return-object v0

    .line 37
    :goto_24
    monitor-exit v1
    :try_end_25
    .catchall {:try_start_14 .. :try_end_25} :catchall_20

    .line 38
    throw v0

    .line 39
    :cond_26
    return-object v0

    .line 40
    :pswitch_27
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 41
    .line 42
    return-object v0

    .line 43
    :pswitch_2a
    new-instance v0, Lio/sentry/android/core/internal/tombstone/j0;

    .line 44
    .line 45
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->access$2500()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-direct {v0, v1}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 50
    .line 51
    .line 52
    return-object v0

    .line 53
    :pswitch_34
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 54
    .line 55
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;-><init>()V

    .line 56
    .line 57
    .line 58
    return-object v0

    .line 59
    :pswitch_3a
    const-string v2, "bitField0_"

    .line 60
    .line 61
    const-string v3, "arch_"

    .line 62
    .line 63
    const-string v4, "buildFingerprint_"

    .line 64
    .line 65
    const-string v5, "revision_"

    .line 66
    .line 67
    const-string v6, "timestamp_"

    .line 68
    .line 69
    const-string v7, "pid_"

    .line 70
    .line 71
    const-string v8, "tid_"

    .line 72
    .line 73
    const-string v9, "uid_"

    .line 74
    .line 75
    const-string v10, "selinuxLabel_"

    .line 76
    .line 77
    const-string v11, "commandLine_"

    .line 78
    .line 79
    const-string v12, "signalInfo_"

    .line 80
    .line 81
    const-string v13, "abortMessage_"

    .line 82
    .line 83
    const-string v14, "causes_"

    .line 84
    .line 85
    const-class v15, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;

    .line 86
    .line 87
    const-string v16, "threads_"

    .line 88
    .line 89
    sget-object v17, Lio/sentry/android/core/internal/tombstone/l0;->a:Lcom/google/protobuf/a2;

    .line 90
    .line 91
    const-string v18, "memoryMappings_"

    .line 92
    .line 93
    const-class v19, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;

    .line 94
    .line 95
    const-string v20, "logBuffers_"

    .line 96
    .line 97
    const-class v21, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 98
    .line 99
    const-string v22, "openFds_"

    .line 100
    .line 101
    const-class v23, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 102
    .line 103
    const-string v24, "processUptime_"

    .line 104
    .line 105
    const-string v25, "crashDetails_"

    .line 106
    .line 107
    const-class v26, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;

    .line 108
    .line 109
    const-string v27, "pageSize_"

    .line 110
    .line 111
    const-string v28, "hasBeen16KbMode_"

    .line 112
    .line 113
    const-string v29, "guestArch_"

    .line 114
    .line 115
    const-string v30, "guestThreads_"

    .line 116
    .line 117
    sget-object v31, Lio/sentry/android/core/internal/tombstone/k0;->a:Lcom/google/protobuf/a2;

    .line 118
    .line 119
    const-string v32, "stackHistoryBuffer_"

    .line 120
    .line 121
    filled-new-array/range {v2 .. v32}, [Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    const-string v1, "\u0000\u0017\u0000\u0001\u0001\u001a\u0017\u0002\u0006\u0000\u0001\u000c\u0002\u0208\u0003\u0208\u0004\u0208\u0005\u000b\u0006\u000b\u0007\u000b\u0008\u0208\t\u021a\n\u1009\u0000\u000e\u0208\u000f\u001b\u00102\u0011\u001b\u0012\u001b\u0013\u001b\u0014\u000b\u0015\u001b\u0016\u000b\u0017\u0007\u0018\u000c\u00192\u001a\u1009\u0001"

    .line 126
    .line 127
    sget-object v2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;

    .line 128
    .line 129
    invoke-static {v2, v1, v0}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    return-object v0

    .line 134
    :pswitch_85
    const/4 v0, 0x0

    .line 135
    return-object v0

    .line 136
    :pswitch_87
    const/4 v0, 0x1

    .line 137
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    return-object v0

    .line 142
    nop

    .line 143
    :pswitch_data_8e
    .packed-switch 0x0
        :pswitch_87
        :pswitch_85
        :pswitch_3a
        :pswitch_34
        :pswitch_2a
        :pswitch_27
        :pswitch_d
    .end packed-switch
.end method

.method public getAbortMessage()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->abortMessage_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getAbortMessageBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->abortMessage_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getArch()Lio/sentry/android/core/internal/tombstone/e;
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->arch_:I

    .line 2
    .line 3
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/e;->forNumber(I)Lio/sentry/android/core/internal/tombstone/e;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/e;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/e;

    .line 10
    .line 11
    :cond_a
    return-object v0
.end method

.method public getArchValue()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->arch_:I

    .line 2
    .line 3
    return v0
.end method

.method public getBuildFingerprint()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->buildFingerprint_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getBuildFingerprintBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->buildFingerprint_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getCauses(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCausesCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getCausesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Cause;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCausesOrBuilder(I)Lio/sentry/android/core/internal/tombstone/j;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/j;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCausesOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/j;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->causes_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCommandLine(I)Ljava/lang/String;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCommandLineBytes(I)Lcom/google/protobuf/n;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {p1}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method

.method public getCommandLineCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getCommandLineList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->commandLine_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCrashDetails(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCrashDetailsCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getCrashDetailsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$CrashDetail;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCrashDetailsOrBuilder(I)Lio/sentry/android/core/internal/tombstone/l;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/l;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCrashDetailsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/l;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->crashDetails_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getGuestArch()Lio/sentry/android/core/internal/tombstone/e;
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestArch_:I

    .line 2
    .line 3
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/e;->forNumber(I)Lio/sentry/android/core/internal/tombstone/e;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/e;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/e;

    .line 10
    .line 11
    :cond_a
    return-object v0
.end method

.method public getGuestArchValue()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->guestArch_:I

    .line 2
    .line 3
    return v0
.end method

.method public getGuestThreads()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    invoke-virtual {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getGuestThreadsMap()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public getGuestThreadsCount()I
    .registers 2

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetGuestThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/util/AbstractMap;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getGuestThreadsMap()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetGuestThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public getGuestThreadsOrDefault(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 5

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetGuestThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_19

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 24
    .line 25
    return-object p1

    .line 26
    :cond_19
    return-object p2
.end method

.method public getGuestThreadsOrThrow(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 4

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetGuestThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_19

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 24
    .line 25
    return-object p1

    .line 26
    :cond_19
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 27
    .line 28
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 29
    .line 30
    .line 31
    throw p1
.end method

.method public getHasBeen16KbMode()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->hasBeen16KbMode_:Z

    .line 2
    .line 3
    return v0
.end method

.method public getLogBuffers(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 8
    .line 9
    return-object p1
.end method

.method public getLogBuffersCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getLogBuffersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getLogBuffersOrBuilder(I)Lio/sentry/android/core/internal/tombstone/q;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/q;

    .line 8
    .line 9
    return-object p1
.end method

.method public getLogBuffersOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/q;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->logBuffers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMemoryMappings(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;

    .line 8
    .line 9
    return-object p1
.end method

.method public getMemoryMappingsCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getMemoryMappingsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryMapping;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMemoryMappingsOrBuilder(I)Lio/sentry/android/core/internal/tombstone/b0;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/b0;

    .line 8
    .line 9
    return-object p1
.end method

.method public getMemoryMappingsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/b0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->memoryMappings_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOpenFds(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;

    .line 8
    .line 9
    return-object p1
.end method

.method public getOpenFdsCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getOpenFdsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$FD;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getOpenFdsOrBuilder(I)Lio/sentry/android/core/internal/tombstone/n;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/n;

    .line 8
    .line 9
    return-object p1
.end method

.method public getOpenFdsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/n;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->openFds_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getPageSize()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->pageSize_:I

    .line 2
    .line 3
    return v0
.end method

.method public getPid()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->pid_:I

    .line 2
    .line 3
    return v0
.end method

.method public getProcessUptime()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->processUptime_:I

    .line 2
    .line 3
    return v0
.end method

.method public getRevision()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->revision_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getRevisionBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->revision_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getSelinuxLabel()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->selinuxLabel_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getSelinuxLabelBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->selinuxLabel_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getSignalInfo()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->signalInfo_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 2
    .line 3
    if-nez v0, :cond_8

    .line 4
    .line 5
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Signal;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    :cond_8
    return-object v0
.end method

.method public getStackHistoryBuffer()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->stackHistoryBuffer_:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 2
    .line 3
    if-nez v0, :cond_8

    .line 4
    .line 5
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$StackHistoryBuffer;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    :cond_8
    return-object v0
.end method

.method public getThreads()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    invoke-virtual {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->getThreadsMap()Ljava/util/Map;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public getThreadsCount()I
    .registers 2

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/util/AbstractMap;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getThreadsMap()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public getThreadsOrDefault(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 5

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_19

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 24
    .line 25
    return-object p1

    .line 26
    :cond_19
    return-object p2
.end method

.method public getThreadsOrThrow(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 4

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->internalGetThreads()Lcom/google/protobuf/b2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_19

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 24
    .line 25
    return-object p1

    .line 26
    :cond_19
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 27
    .line 28
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 29
    .line 30
    .line 31
    throw p1
.end method

.method public getTid()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->tid_:I

    .line 2
    .line 3
    return v0
.end method

.method public getTimestamp()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->timestamp_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTimestampBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->timestamp_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getUid()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->uid_:I

    .line 2
    .line 3
    return v0
.end method

.method public hasSignalInfo()Z
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    and-int/2addr v0, v1

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    return v1

    .line 8
    :cond_7
    const/4 v0, 0x0

    .line 9
    return v0
.end method

.method public hasStackHistoryBuffer()Z
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Tombstone;->bitField0_:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x2

    .line 4
    .line 5
    if-eqz v0, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    return v0

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    return v0
.end method
