###### Class io.sentry.android.core.internal.tombstone.g0 (io.sentry.android.core.internal.tombstone.g0)
.class public final Lio/sentry/android/core/internal/tombstone/g0;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/h0;
