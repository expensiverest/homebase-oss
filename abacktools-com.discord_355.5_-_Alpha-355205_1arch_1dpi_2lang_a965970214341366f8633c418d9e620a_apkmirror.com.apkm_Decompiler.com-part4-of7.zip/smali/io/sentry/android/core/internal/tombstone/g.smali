###### Class io.sentry.android.core.internal.tombstone.g (io.sentry.android.core.internal.tombstone.g)
.class public final Lio/sentry/android/core/internal/tombstone/g;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/h;
