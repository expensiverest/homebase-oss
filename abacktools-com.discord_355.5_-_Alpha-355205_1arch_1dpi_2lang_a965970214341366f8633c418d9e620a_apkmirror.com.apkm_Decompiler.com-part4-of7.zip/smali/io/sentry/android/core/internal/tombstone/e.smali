###### Class io.sentry.android.core.internal.tombstone.e (io.sentry.android.core.internal.tombstone.e)
.class public final enum Lio/sentry/android/core/internal/tombstone/e;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/g1;


# static fields
.field private static final synthetic $VALUES:[Lio/sentry/android/core/internal/tombstone/e;

.field public static final enum ARM32:Lio/sentry/android/core/internal/tombstone/e;

.field public static final ARM32_VALUE:I = 0x0

.field public static final enum ARM64:Lio/sentry/android/core/internal/tombstone/e;

.field public static final ARM64_VALUE:I = 0x1

.field public static final enum NONE:Lio/sentry/android/core/internal/tombstone/e;

.field public static final NONE_VALUE:I = 0x5

.field public static final enum RISCV64:Lio/sentry/android/core/internal/tombstone/e;

.field public static final RISCV64_VALUE:I = 0x4

.field public static final enum UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/e;

.field public static final enum X86:Lio/sentry/android/core/internal/tombstone/e;

.field public static final enum X86_64:Lio/sentry/android/core/internal/tombstone/e;

.field public static final X86_64_VALUE:I = 0x3

.field public static final X86_VALUE:I = 0x2

.field private static final internalValueMap:Lcom/google/protobuf/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/h1;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method private static synthetic $values()[Lio/sentry/android/core/internal/tombstone/e;
    .registers 7

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/e;->ARM32:Lio/sentry/android/core/internal/tombstone/e;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/android/core/internal/tombstone/e;->ARM64:Lio/sentry/android/core/internal/tombstone/e;

    .line 4
    .line 5
    sget-object v2, Lio/sentry/android/core/internal/tombstone/e;->X86:Lio/sentry/android/core/internal/tombstone/e;

    .line 6
    .line 7
    sget-object v3, Lio/sentry/android/core/internal/tombstone/e;->X86_64:Lio/sentry/android/core/internal/tombstone/e;

    .line 8
    .line 9
    sget-object v4, Lio/sentry/android/core/internal/tombstone/e;->RISCV64:Lio/sentry/android/core/internal/tombstone/e;

    .line 10
    .line 11
    sget-object v5, Lio/sentry/android/core/internal/tombstone/e;->NONE:Lio/sentry/android/core/internal/tombstone/e;

    .line 12
    .line 13
    sget-object v6, Lio/sentry/android/core/internal/tombstone/e;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/e;

    .line 14
    .line 15
    filled-new-array/range {v0 .. v6}, [Lio/sentry/android/core/internal/tombstone/e;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 2
    .line 3
    const-string v1, "ARM32"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->ARM32:Lio/sentry/android/core/internal/tombstone/e;

    .line 10
    .line 11
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 12
    .line 13
    const-string v1, "ARM64"

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 17
    .line 18
    .line 19
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->ARM64:Lio/sentry/android/core/internal/tombstone/e;

    .line 20
    .line 21
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 22
    .line 23
    const-string v1, "X86"

    .line 24
    .line 25
    const/4 v2, 0x2

    .line 26
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->X86:Lio/sentry/android/core/internal/tombstone/e;

    .line 30
    .line 31
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 32
    .line 33
    const-string v1, "X86_64"

    .line 34
    .line 35
    const/4 v2, 0x3

    .line 36
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->X86_64:Lio/sentry/android/core/internal/tombstone/e;

    .line 40
    .line 41
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 42
    .line 43
    const-string v1, "RISCV64"

    .line 44
    .line 45
    const/4 v2, 0x4

    .line 46
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 47
    .line 48
    .line 49
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->RISCV64:Lio/sentry/android/core/internal/tombstone/e;

    .line 50
    .line 51
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 52
    .line 53
    const-string v1, "NONE"

    .line 54
    .line 55
    const/4 v2, 0x5

    .line 56
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 57
    .line 58
    .line 59
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->NONE:Lio/sentry/android/core/internal/tombstone/e;

    .line 60
    .line 61
    new-instance v0, Lio/sentry/android/core/internal/tombstone/e;

    .line 62
    .line 63
    const/4 v1, 0x6

    .line 64
    const/4 v2, -0x1

    .line 65
    const-string v3, "UNRECOGNIZED"

    .line 66
    .line 67
    invoke-direct {v0, v3, v1, v2}, Lio/sentry/android/core/internal/tombstone/e;-><init>(Ljava/lang/String;II)V

    .line 68
    .line 69
    .line 70
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/e;

    .line 71
    .line 72
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/e;->$values()[Lio/sentry/android/core/internal/tombstone/e;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->$VALUES:[Lio/sentry/android/core/internal/tombstone/e;

    .line 77
    .line 78
    new-instance v0, Lio/sentry/android/core/internal/tombstone/c;

    .line 79
    .line 80
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 81
    .line 82
    .line 83
    sput-object v0, Lio/sentry/android/core/internal/tombstone/e;->internalValueMap:Lcom/google/protobuf/h1;

    .line 84
    .line 85
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, Lio/sentry/android/core/internal/tombstone/e;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static forNumber(I)Lio/sentry/android/core/internal/tombstone/e;
    .registers 2

    .line 1
    if-eqz p0, :cond_22

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p0, v0, :cond_1f

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    if-eq p0, v0, :cond_1c

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    if-eq p0, v0, :cond_19

    .line 11
    .line 12
    const/4 v0, 0x4

    .line 13
    if-eq p0, v0, :cond_16

    .line 14
    .line 15
    const/4 v0, 0x5

    .line 16
    if-eq p0, v0, :cond_13

    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    return-object p0

    .line 20
    :cond_13
    sget-object p0, Lio/sentry/android/core/internal/tombstone/e;->NONE:Lio/sentry/android/core/internal/tombstone/e;

    .line 21
    .line 22
    return-object p0

    .line 23
    :cond_16
    sget-object p0, Lio/sentry/android/core/internal/tombstone/e;->RISCV64:Lio/sentry/android/core/internal/tombstone/e;

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lio/sentry/android/core/internal/tombstone/e;->X86_64:Lio/sentry/android/core/internal/tombstone/e;

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1c
    sget-object p0, Lio/sentry/android/core/internal/tombstone/e;->X86:Lio/sentry/android/core/internal/tombstone/e;

    .line 30
    .line 31
    return-object p0

    .line 32
    :cond_1f
    sget-object p0, Lio/sentry/android/core/internal/tombstone/e;->ARM64:Lio/sentry/android/core/internal/tombstone/e;

    .line 33
    .line 34
    return-object p0

    .line 35
    :cond_22
    sget-object p0, Lio/sentry/android/core/internal/tombstone/e;->ARM32:Lio/sentry/android/core/internal/tombstone/e;

    .line 36
    .line 37
    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/h1;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/h1;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/e;->internalValueMap:Lcom/google/protobuf/h1;

    .line 2
    .line 3
    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/i1;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/d;->a:Lio/sentry/android/core/internal/tombstone/d;

    .line 2
    .line 3
    return-object v0
.end method

.method public static valueOf(I)Lio/sentry/android/core/internal/tombstone/e;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 2
    invoke-static {p0}, Lio/sentry/android/core/internal/tombstone/e;->forNumber(I)Lio/sentry/android/core/internal/tombstone/e;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/sentry/android/core/internal/tombstone/e;
    .registers 2

    .line 1
    const-class v0, Lio/sentry/android/core/internal/tombstone/e;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/e;

    return-object p0
.end method

.method public static values()[Lio/sentry/android/core/internal/tombstone/e;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/e;->$VALUES:[Lio/sentry/android/core/internal/tombstone/e;

    .line 2
    .line 3
    invoke-virtual {v0}, [Lio/sentry/android/core/internal/tombstone/e;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lio/sentry/android/core/internal/tombstone/e;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/e;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/e;

    .line 2
    .line 3
    if-eq p0, v0, :cond_7

    .line 4
    .line 5
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/e;->value:I

    .line 6
    .line 7
    return v0

    .line 8
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 9
    .line 10
    const-string v1, "Can\'t get the number of an unknown enum value."

    .line 11
    .line 12
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw v0
.end method
