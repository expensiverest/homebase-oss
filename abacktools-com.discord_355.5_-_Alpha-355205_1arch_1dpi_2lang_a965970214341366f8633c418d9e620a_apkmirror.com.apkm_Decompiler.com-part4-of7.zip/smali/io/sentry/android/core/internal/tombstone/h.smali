###### Class io.sentry.android.core.internal.tombstone.h (io.sentry.android.core.internal.tombstone.h)
.class public interface abstract Lio/sentry/android/core/internal/tombstone/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
