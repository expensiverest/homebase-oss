###### Class io.sentry.android.core.internal.tombstone.k0 (io.sentry.android.core.internal.tombstone.k0)
.class public abstract Lio/sentry/android/core/internal/tombstone/k0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/google/protobuf/a2;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 1
    sget-object v0, Lcom/google/protobuf/j4;->y:Lcom/google/protobuf/j4;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    sget-object v2, Lcom/google/protobuf/j4;->w:Lcom/google/protobuf/h4;

    .line 9
    .line 10
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    new-instance v4, Lcom/google/protobuf/a2;

    .line 15
    .line 16
    invoke-direct {v4, v0, v1, v2, v3}, Lcom/google/protobuf/a2;-><init>(Lcom/google/protobuf/j4;Ljava/lang/Object;Lcom/google/protobuf/j4;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    sput-object v4, Lio/sentry/android/core/internal/tombstone/k0;->a:Lcom/google/protobuf/a2;

    .line 20
    .line 21
    return-void
.end method
