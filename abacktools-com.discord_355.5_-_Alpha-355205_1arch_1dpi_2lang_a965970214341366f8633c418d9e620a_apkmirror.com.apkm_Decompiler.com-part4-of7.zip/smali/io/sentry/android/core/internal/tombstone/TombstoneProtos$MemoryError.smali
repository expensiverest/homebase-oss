###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError (io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;,
        Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;,
        Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lcom/google/protobuf/h2;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

.field public static final HEAP_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/u2; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field

.field public static final TOOL_FIELD_NUMBER:I = 0x1

.field public static final TYPE_FIELD_NUMBER:I = 0x2


# instance fields
.field private locationCase_:I

.field private location_:Ljava/lang/Object;

.field private tool_:I

.field private type_:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 6
    .line 7
    return-void
.end method

.method public static synthetic access$15000()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$15100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->clearLocation()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->setToolValue(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->setTool(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->clearTool()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->setTypeValue(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->setType(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->clearType()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->setHeap(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$15900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->mergeHeap(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$16000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->clearHeap()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private clearHeap()V
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    if-ne v0, v1, :cond_b

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method private clearLocation()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 6
    .line 7
    return-void
.end method

.method private clearTool()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->tool_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearType()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->type_:I

    .line 3
    .line 4
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 2
    .line 3
    return-object v0
.end method

.method private mergeHeap(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 5
    .line 6
    const/4 v1, 0x3

    .line 7
    if-ne v0, v1, :cond_22

    .line 8
    .line 9
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    if-eq v0, v2, :cond_22

    .line 16
    .line 17
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;

    .line 20
    .line 21
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;->newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)Lio/sentry/android/core/internal/tombstone/o;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0, p1}, Lcom/google/protobuf/u0;->e(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/google/protobuf/u0;->c()Lcom/google/protobuf/a1;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 33
    .line 34
    goto :goto_24

    .line 35
    :cond_22
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 36
    .line 37
    :goto_24
    iput v1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 38
    .line 39
    return-void
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/v;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/v;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;)Lio/sentry/android/core/internal/tombstone/v;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/v;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private setHeap(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 5
    .line 6
    const/4 p1, 0x3

    .line 7
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 8
    .line 9
    return-void
.end method

.method private setTool(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->getNumber()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->tool_:I

    .line 6
    .line 7
    return-void
.end method

.method private setToolValue(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->tool_:I

    .line 2
    .line 3
    return-void
.end method

.method private setType(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->getNumber()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->type_:I

    .line 6
    .line 7
    return-void
.end method

.method private setTypeValue(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->type_:I

    .line 2
    .line 3
    return-void
.end method


# virtual methods
.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    packed-switch p1, :pswitch_data_5a

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_d
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez p1, :cond_26

    .line 17
    .line 18
    const-class p2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 19
    .line 20
    monitor-enter p2

    .line 21
    :try_start_14
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez p1, :cond_22

    .line 24
    .line 25
    new-instance p1, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    goto :goto_24

    .line 35
    :cond_22
    :goto_22
    monitor-exit p2

    .line 36
    return-object p1

    .line 37
    :goto_24
    monitor-exit p2
    :try_end_25
    .catchall {:try_start_14 .. :try_end_25} :catchall_20

    .line 38
    throw p1

    .line 39
    :cond_26
    return-object p1

    .line 40
    :pswitch_27
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 41
    .line 42
    return-object p1

    .line 43
    :pswitch_2a
    new-instance p1, Lio/sentry/android/core/internal/tombstone/v;

    .line 44
    .line 45
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->access$15000()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    invoke-direct {p1, p2}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 50
    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_34
    new-instance p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 54
    .line 55
    invoke-direct {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;-><init>()V

    .line 56
    .line 57
    .line 58
    return-object p1

    .line 59
    :pswitch_3a
    const-string p1, "location_"

    .line 60
    .line 61
    const-string p2, "locationCase_"

    .line 62
    .line 63
    const-string p3, "tool_"

    .line 64
    .line 65
    const-string v0, "type_"

    .line 66
    .line 67
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;

    .line 68
    .line 69
    filled-new-array {p1, p2, p3, v0, v1}, [Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    const-string p2, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000c\u0002\u000c\u0003<\u0000"

    .line 74
    .line 75
    sget-object p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;

    .line 76
    .line 77
    invoke-static {p3, p2, p1}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    return-object p1

    .line 82
    :pswitch_51
    const/4 p1, 0x0

    .line 83
    return-object p1

    .line 84
    :pswitch_53
    const/4 p1, 0x1

    .line 85
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    return-object p1

    .line 90
    nop

    .line 91
    :pswitch_data_5a
    .packed-switch 0x0
        :pswitch_53
        :pswitch_51
        :pswitch_3a
        :pswitch_34
        :pswitch_2a
        :pswitch_27
        :pswitch_d
    .end packed-switch
.end method

.method public getHeap()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    if-ne v0, v1, :cond_a

    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->location_:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;

    .line 9
    .line 10
    return-object v0

    .line 11
    :cond_a
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$HeapObject;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public getLocationCase()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 2
    .line 3
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getTool()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->tool_:I

    .line 2
    .line 3
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 10
    .line 11
    :cond_a
    return-object v0
.end method

.method public getToolValue()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->tool_:I

    .line 2
    .line 3
    return v0
.end method

.method public getType()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->type_:I

    .line 2
    .line 3
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 10
    .line 11
    :cond_a
    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->type_:I

    .line 2
    .line 3
    return v0
.end method

.method public hasHeap()Z
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;->locationCase_:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    if-ne v0, v1, :cond_7

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    return v0

    .line 8
    :cond_7
    const/4 v0, 0x0

    .line 9
    return v0
.end method

###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError.a (io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError$a)
.class public final enum Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

.field public static final enum HEAP:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

.field public static final enum LOCATION_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;


# instance fields
.field private final value:I


# direct methods
.method private static synthetic $values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->HEAP:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->LOCATION_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 4
    .line 5
    filled-new-array {v0, v1}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    const-string v2, "HEAP"

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    invoke-direct {v0, v2, v3, v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;-><init>(Ljava/lang/String;II)V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->HEAP:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 11
    .line 12
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 13
    .line 14
    const-string v1, "LOCATION_NOT_SET"

    .line 15
    .line 16
    const/4 v2, 0x1

    .line 17
    invoke-direct {v0, v1, v2, v3}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;-><init>(Ljava/lang/String;II)V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->LOCATION_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 21
    .line 22
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->$values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 27
    .line 28
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    .registers 2

    .line 1
    if-eqz p0, :cond_a

    .line 2
    .line 3
    const/4 v0, 0x3

    .line 4
    if-eq p0, v0, :cond_7

    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    return-object p0

    .line 8
    :cond_7
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->HEAP:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_a
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->LOCATION_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 12
    .line 13
    return-object p0
.end method

.method public static valueOf(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 2
    invoke-static {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    .registers 2

    .line 1
    const-class v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    return-object p0
.end method

.method public static values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 2
    .line 3
    invoke-virtual {v0}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public getNumber()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$a;->value:I

    .line 2
    .line 3
    return v0
.end method

###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError.b (io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError$b)
.class public final enum Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/g1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

.field public static final enum GWP_ASAN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

.field public static final GWP_ASAN_VALUE:I = 0x0

.field public static final enum SCUDO:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

.field public static final SCUDO_VALUE:I = 0x1

.field public static final enum UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

.field private static final internalValueMap:Lcom/google/protobuf/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/h1;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method private static synthetic $values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
    .registers 3

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->GWP_ASAN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->SCUDO:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 4
    .line 5
    sget-object v2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 6
    .line 7
    filled-new-array {v0, v1, v2}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 2
    .line 3
    const-string v1, "GWP_ASAN"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;-><init>(Ljava/lang/String;II)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->GWP_ASAN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 10
    .line 11
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 12
    .line 13
    const-string v1, "SCUDO"

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;-><init>(Ljava/lang/String;II)V

    .line 17
    .line 18
    .line 19
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->SCUDO:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 20
    .line 21
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 22
    .line 23
    const/4 v1, 0x2

    .line 24
    const/4 v2, -0x1

    .line 25
    const-string v3, "UNRECOGNIZED"

    .line 26
    .line 27
    invoke-direct {v0, v3, v1, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;-><init>(Ljava/lang/String;II)V

    .line 28
    .line 29
    .line 30
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 31
    .line 32
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->$values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 37
    .line 38
    new-instance v0, Lio/sentry/android/core/internal/tombstone/w;

    .line 39
    .line 40
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 41
    .line 42
    .line 43
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->internalValueMap:Lcom/google/protobuf/h1;

    .line 44
    .line 45
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
    .registers 2

    .line 1
    if-eqz p0, :cond_a

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p0, v0, :cond_7

    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    return-object p0

    .line 8
    :cond_7
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->SCUDO:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_a
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->GWP_ASAN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 12
    .line 13
    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/h1;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/h1;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->internalValueMap:Lcom/google/protobuf/h1;

    .line 2
    .line 3
    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/i1;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/x;->a:Lio/sentry/android/core/internal/tombstone/x;

    .line 2
    .line 3
    return-object v0
.end method

.method public static valueOf(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 2
    invoke-static {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
    .registers 2

    .line 1
    const-class v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    return-object p0
.end method

.method public static values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 2
    .line 3
    invoke-virtual {v0}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;

    .line 2
    .line 3
    if-eq p0, v0, :cond_7

    .line 4
    .line 5
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$b;->value:I

    .line 6
    .line 7
    return v0

    .line 8
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 9
    .line 10
    const-string v1, "Can\'t get the number of an unknown enum value."

    .line 11
    .line 12
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw v0
.end method

###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError.c (io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryError$c)
.class public final enum Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/g1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "c"
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final enum BUFFER_OVERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final BUFFER_OVERFLOW_VALUE:I = 0x4

.field public static final enum BUFFER_UNDERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final BUFFER_UNDERFLOW_VALUE:I = 0x5

.field public static final enum DOUBLE_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final DOUBLE_FREE_VALUE:I = 0x2

.field public static final enum INVALID_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final INVALID_FREE_VALUE:I = 0x3

.field public static final enum UNKNOWN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final UNKNOWN_VALUE:I = 0x0

.field public static final enum UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final enum USE_AFTER_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

.field public static final USE_AFTER_FREE_VALUE:I = 0x1

.field private static final internalValueMap:Lcom/google/protobuf/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/h1;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method private static synthetic $values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
    .registers 7

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNKNOWN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->USE_AFTER_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 4
    .line 5
    sget-object v2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->DOUBLE_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 6
    .line 7
    sget-object v3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->INVALID_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 8
    .line 9
    sget-object v4, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->BUFFER_OVERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 10
    .line 11
    sget-object v5, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->BUFFER_UNDERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 12
    .line 13
    sget-object v6, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 14
    .line 15
    filled-new-array/range {v0 .. v6}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 2
    .line 3
    const-string v1, "UNKNOWN"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNKNOWN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 10
    .line 11
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 12
    .line 13
    const-string v1, "USE_AFTER_FREE"

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 17
    .line 18
    .line 19
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->USE_AFTER_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 20
    .line 21
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 22
    .line 23
    const-string v1, "DOUBLE_FREE"

    .line 24
    .line 25
    const/4 v2, 0x2

    .line 26
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->DOUBLE_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 30
    .line 31
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 32
    .line 33
    const-string v1, "INVALID_FREE"

    .line 34
    .line 35
    const/4 v2, 0x3

    .line 36
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->INVALID_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 40
    .line 41
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 42
    .line 43
    const-string v1, "BUFFER_OVERFLOW"

    .line 44
    .line 45
    const/4 v2, 0x4

    .line 46
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 47
    .line 48
    .line 49
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->BUFFER_OVERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 50
    .line 51
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 52
    .line 53
    const-string v1, "BUFFER_UNDERFLOW"

    .line 54
    .line 55
    const/4 v2, 0x5

    .line 56
    invoke-direct {v0, v1, v2, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 57
    .line 58
    .line 59
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->BUFFER_UNDERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 60
    .line 61
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 62
    .line 63
    const/4 v1, 0x6

    .line 64
    const/4 v2, -0x1

    .line 65
    const-string v3, "UNRECOGNIZED"

    .line 66
    .line 67
    invoke-direct {v0, v3, v1, v2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;-><init>(Ljava/lang/String;II)V

    .line 68
    .line 69
    .line 70
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 71
    .line 72
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->$values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 77
    .line 78
    new-instance v0, Lio/sentry/android/core/internal/tombstone/y;

    .line 79
    .line 80
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 81
    .line 82
    .line 83
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->internalValueMap:Lcom/google/protobuf/h1;

    .line 84
    .line 85
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
    .registers 2

    .line 1
    if-eqz p0, :cond_22

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p0, v0, :cond_1f

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    if-eq p0, v0, :cond_1c

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    if-eq p0, v0, :cond_19

    .line 11
    .line 12
    const/4 v0, 0x4

    .line 13
    if-eq p0, v0, :cond_16

    .line 14
    .line 15
    const/4 v0, 0x5

    .line 16
    if-eq p0, v0, :cond_13

    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    return-object p0

    .line 20
    :cond_13
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->BUFFER_UNDERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 21
    .line 22
    return-object p0

    .line 23
    :cond_16
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->BUFFER_OVERFLOW:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->INVALID_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1c
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->DOUBLE_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 30
    .line 31
    return-object p0

    .line 32
    :cond_1f
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->USE_AFTER_FREE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 33
    .line 34
    return-object p0

    .line 35
    :cond_22
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNKNOWN:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 36
    .line 37
    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/h1;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/h1;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->internalValueMap:Lcom/google/protobuf/h1;

    .line 2
    .line 3
    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/i1;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/z;->a:Lio/sentry/android/core/internal/tombstone/z;

    .line 2
    .line 3
    return-object v0
.end method

.method public static valueOf(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 2
    invoke-static {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
    .registers 2

    .line 1
    const-class v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    return-object p0
.end method

.method public static values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 2
    .line 3
    invoke-virtual {v0}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->UNRECOGNIZED:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;

    .line 2
    .line 3
    if-eq p0, v0, :cond_7

    .line 4
    .line 5
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryError$c;->value:I

    .line 6
    .line 7
    return v0

    .line 8
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 9
    .line 10
    const-string v1, "Can\'t get the number of an unknown enum value."

    .line 11
    .line 12
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw v0
.end method
