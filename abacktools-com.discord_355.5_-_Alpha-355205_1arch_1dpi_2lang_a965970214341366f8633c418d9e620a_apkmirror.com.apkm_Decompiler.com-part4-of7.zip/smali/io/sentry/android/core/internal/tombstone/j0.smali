###### Class io.sentry.android.core.internal.tombstone.j0 (io.sentry.android.core.internal.tombstone.j0)
.class public final Lio/sentry/android/core/internal/tombstone/j0;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
