###### Class io.sentry.android.core.internal.tombstone.f (io.sentry.android.core.internal.tombstone.f)
.class public final Lio/sentry/android/core/internal/tombstone/f;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
