###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$LogBuffer (io.sentry.android.core.internal.tombstone.TombstoneProtos$LogBuffer)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/q;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lio/sentry/android/core/internal/tombstone/q;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

.field public static final LOGS_FIELD_NUMBER:I = 0x2

.field public static final NAME_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/u2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field


# instance fields
.field private logs_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private name_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, ""

    .line 5
    .line 6
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->name_:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 13
    .line 14
    return-void
.end method

.method public static synthetic access$29200()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$29300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->setName(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->clearName()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->setNameBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->setLogs(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->addLogs(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->addLogs(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$29900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->addAllLogs(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->clearLogs()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->removeLogs(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private addAllLogs(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->ensureLogsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addLogs(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->ensureLogsIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addLogs(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->ensureLogsIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearLogs()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearName()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->getName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->name_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private ensureLogsIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 2
    .line 3
    return-object v0
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/p;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/p;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;)Lio/sentry/android/core/internal/tombstone/p;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/p;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private removeLogs(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->ensureLogsIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private setLogs(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->ensureLogsIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setName(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->name_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setNameBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->name_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    packed-switch p1, :pswitch_data_56

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_d
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez p1, :cond_26

    .line 17
    .line 18
    const-class p2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 19
    .line 20
    monitor-enter p2

    .line 21
    :try_start_14
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez p1, :cond_22

    .line 24
    .line 25
    new-instance p1, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    goto :goto_24

    .line 35
    :cond_22
    :goto_22
    monitor-exit p2

    .line 36
    return-object p1

    .line 37
    :goto_24
    monitor-exit p2
    :try_end_25
    .catchall {:try_start_14 .. :try_end_25} :catchall_20

    .line 38
    throw p1

    .line 39
    :cond_26
    return-object p1

    .line 40
    :pswitch_27
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 41
    .line 42
    return-object p1

    .line 43
    :pswitch_2a
    new-instance p1, Lio/sentry/android/core/internal/tombstone/p;

    .line 44
    .line 45
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->access$29200()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    invoke-direct {p1, p2}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 50
    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_34
    new-instance p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 54
    .line 55
    invoke-direct {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;-><init>()V

    .line 56
    .line 57
    .line 58
    return-object p1

    .line 59
    :pswitch_3a
    const-string p1, "name_"

    .line 60
    .line 61
    const-string p2, "logs_"

    .line 62
    .line 63
    const-class p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 64
    .line 65
    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u0208\u0002\u001b"

    .line 70
    .line 71
    sget-object p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;

    .line 72
    .line 73
    invoke-static {p3, p2, p1}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    return-object p1

    .line 78
    :pswitch_4d
    const/4 p1, 0x0

    .line 79
    return-object p1

    .line 80
    :pswitch_4f
    const/4 p1, 0x1

    .line 81
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    return-object p1

    .line 86
    nop

    .line 87
    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_4f
        :pswitch_4d
        :pswitch_3a
        :pswitch_34
        :pswitch_2a
        :pswitch_27
        :pswitch_d
    .end packed-switch
.end method

.method public getLogs(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 8
    .line 9
    return-object p1
.end method

.method public getLogsCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getLogsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getLogsOrBuilder(I)Lio/sentry/android/core/internal/tombstone/s;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/s;

    .line 8
    .line 9
    return-object p1
.end method

.method public getLogsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/s;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->logs_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->name_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogBuffer;->name_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method
