###### Class io.sentry.android.core.internal.tombstone.e0 (io.sentry.android.core.internal.tombstone.e0)
.class public final Lio/sentry/android/core/internal/tombstone/e0;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
