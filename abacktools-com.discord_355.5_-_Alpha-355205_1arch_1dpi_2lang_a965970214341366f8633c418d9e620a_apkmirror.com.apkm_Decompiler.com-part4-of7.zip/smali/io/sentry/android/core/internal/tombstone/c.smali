###### Class io.sentry.android.core.internal.tombstone.c (io.sentry.android.core.internal.tombstone.c)
.class public final Lio/sentry/android/core/internal/tombstone/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h1;


# virtual methods
.method public final a(I)Lcom/google/protobuf/g1;
    .registers 2

    .line 1
    invoke-static {p1}, Lio/sentry/android/core/internal/tombstone/e;->forNumber(I)Lio/sentry/android/core/internal/tombstone/e;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method
