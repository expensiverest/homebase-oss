###### Class io.sentry.android.core.internal.tombstone.d0 (io.sentry.android.core.internal.tombstone.d0)
.class public interface abstract Lio/sentry/android/core/internal/tombstone/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;
