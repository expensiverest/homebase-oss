###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$LogMessage (io.sentry.android.core.internal.tombstone.TombstoneProtos$LogMessage)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/s;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lio/sentry/android/core/internal/tombstone/s;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

.field public static final MESSAGE_FIELD_NUMBER:I = 0x6

.field private static volatile PARSER:Lcom/google/protobuf/u2; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field

.field public static final PID_FIELD_NUMBER:I = 0x2

.field public static final PRIORITY_FIELD_NUMBER:I = 0x4

.field public static final TAG_FIELD_NUMBER:I = 0x5

.field public static final TID_FIELD_NUMBER:I = 0x3

.field public static final TIMESTAMP_FIELD_NUMBER:I = 0x1


# instance fields
.field private message_:Ljava/lang/String;

.field private pid_:I

.field private priority_:I

.field private tag_:Ljava/lang/String;

.field private tid_:I

.field private timestamp_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, ""

    .line 5
    .line 6
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->timestamp_:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tag_:Ljava/lang/String;

    .line 9
    .line 10
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->message_:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method public static synthetic access$30300()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$30400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setTimestamp(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->clearTimestamp()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setTimestampBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setPid(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->clearPid()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$30900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setTid(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->clearTid()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setPriority(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->clearPriority()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setTag(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->clearTag()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setTagBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setMessage(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->clearMessage()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$31800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->setMessageBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private clearMessage()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->getMessage()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->message_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearPid()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->pid_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearPriority()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->priority_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearTag()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->getTag()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tag_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearTid()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tid_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearTimestamp()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->getTimestamp()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->timestamp_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    return-object v0
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/r;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/r;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;)Lio/sentry/android/core/internal/tombstone/r;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/r;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private setMessage(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->message_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setMessageBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->message_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setPid(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->pid_:I

    .line 2
    .line 3
    return-void
.end method

.method private setPriority(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->priority_:I

    .line 2
    .line 3
    return-void
.end method

.method private setTag(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tag_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setTagBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tag_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setTid(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tid_:I

    .line 2
    .line 3
    return-void
.end method

.method private setTimestamp(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->timestamp_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setTimestampBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->timestamp_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    packed-switch p1, :pswitch_data_5c

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_d
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez p1, :cond_27

    .line 17
    .line 18
    const-class p2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 19
    .line 20
    monitor-enter p2

    .line 21
    :try_start_14
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez p1, :cond_23

    .line 24
    .line 25
    new-instance p1, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_23

    .line 33
    :catchall_20
    move-exception v0

    .line 34
    move-object p1, v0

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    :goto_23
    monitor-exit p2

    .line 37
    return-object p1

    .line 38
    :goto_25
    monitor-exit p2
    :try_end_26
    .catchall {:try_start_14 .. :try_end_26} :catchall_20

    .line 39
    throw p1

    .line 40
    :cond_27
    return-object p1

    .line 41
    :pswitch_28
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 42
    .line 43
    return-object p1

    .line 44
    :pswitch_2b
    new-instance p1, Lio/sentry/android/core/internal/tombstone/r;

    .line 45
    .line 46
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->access$30300()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    invoke-direct {p1, p2}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 51
    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_35
    new-instance p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 55
    .line 56
    invoke-direct {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;-><init>()V

    .line 57
    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_3b
    const-string v0, "timestamp_"

    .line 61
    .line 62
    const-string v1, "pid_"

    .line 63
    .line 64
    const-string v2, "tid_"

    .line 65
    .line 66
    const-string v3, "priority_"

    .line 67
    .line 68
    const-string v4, "tag_"

    .line 69
    .line 70
    const-string v5, "message_"

    .line 71
    .line 72
    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    const-string p2, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0208\u0002\u000b\u0003\u000b\u0004\u000b\u0005\u0208\u0006\u0208"

    .line 77
    .line 78
    sget-object p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;

    .line 79
    .line 80
    invoke-static {p3, p2, p1}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    return-object p1

    .line 85
    :pswitch_54
    const/4 p1, 0x0

    .line 86
    return-object p1

    .line 87
    :pswitch_56
    const/4 p1, 0x1

    .line 88
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    return-object p1

    .line 93
    :pswitch_data_5c
    .packed-switch 0x0
        :pswitch_56
        :pswitch_54
        :pswitch_3b
        :pswitch_35
        :pswitch_2b
        :pswitch_28
        :pswitch_d
    .end packed-switch
.end method

.method public getMessage()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->message_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMessageBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->message_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getPid()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->pid_:I

    .line 2
    .line 3
    return v0
.end method

.method public getPriority()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->priority_:I

    .line 2
    .line 3
    return v0
.end method

.method public getTag()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tag_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTagBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tag_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getTid()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->tid_:I

    .line 2
    .line 3
    return v0
.end method

.method public getTimestamp()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->timestamp_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTimestampBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$LogMessage;->timestamp_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method
