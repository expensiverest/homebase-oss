###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryDump (io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryDump)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/u;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lio/sentry/android/core/internal/tombstone/u;"
    }
.end annotation


# static fields
.field public static final ARM_MTE_METADATA_FIELD_NUMBER:I = 0x6

.field public static final BEGIN_ADDRESS_FIELD_NUMBER:I = 0x3

.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

.field public static final MAPPING_NAME_FIELD_NUMBER:I = 0x2

.field public static final MEMORY_FIELD_NUMBER:I = 0x4

.field private static volatile PARSER:Lcom/google/protobuf/u2; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field

.field public static final REGISTER_NAME_FIELD_NUMBER:I = 0x1


# instance fields
.field private beginAddress_:J

.field private mappingName_:Ljava/lang/String;

.field private memory_:Lcom/google/protobuf/n;

.field private metadataCase_:I

.field private metadata_:Ljava/lang/Object;

.field private registerName_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 6
    .line 7
    const-string v0, ""

    .line 8
    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->registerName_:Ljava/lang/String;

    .line 10
    .line 11
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mappingName_:Ljava/lang/String;

    .line 12
    .line 13
    sget-object v0, Lcom/google/protobuf/n;->e:Lcom/google/protobuf/m;

    .line 14
    .line 15
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->memory_:Lcom/google/protobuf/n;

    .line 16
    .line 17
    return-void
.end method

.method public static synthetic access$24200()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$24300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->clearMetadata()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$24400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setRegisterName(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$24500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->clearRegisterName()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$24600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setRegisterNameBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$24700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setMappingName(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$24800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->clearMappingName()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$24900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setMappingNameBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;J)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setBeginAddress(J)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->clearBeginAddress()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setMemory(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->clearMemory()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->setArmMteMetadata(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mergeArmMteMetadata(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$25600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->clearArmMteMetadata()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private clearArmMteMetadata()V
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    if-ne v0, v1, :cond_b

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method private clearBeginAddress()V
    .registers 3

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->beginAddress_:J

    .line 4
    .line 5
    return-void
.end method

.method private clearMappingName()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->getMappingName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mappingName_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearMemory()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->getMemory()Lcom/google/protobuf/n;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->memory_:Lcom/google/protobuf/n;

    .line 10
    .line 11
    return-void
.end method

.method private clearMetadata()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 6
    .line 7
    return-void
.end method

.method private clearRegisterName()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->getRegisterName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->registerName_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    return-object v0
.end method

.method private mergeArmMteMetadata(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 5
    .line 6
    const/4 v1, 0x6

    .line 7
    if-ne v0, v1, :cond_22

    .line 8
    .line 9
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    if-eq v0, v2, :cond_22

    .line 16
    .line 17
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;

    .line 20
    .line 21
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;->newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)Lio/sentry/android/core/internal/tombstone/f;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0, p1}, Lcom/google/protobuf/u0;->e(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/google/protobuf/u0;->c()Lcom/google/protobuf/a1;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 33
    .line 34
    goto :goto_24

    .line 35
    :cond_22
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 36
    .line 37
    :goto_24
    iput v1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 38
    .line 39
    return-void
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/t;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/t;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)Lio/sentry/android/core/internal/tombstone/t;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/t;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private setArmMteMetadata(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 5
    .line 6
    const/4 p1, 0x6

    .line 7
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 8
    .line 9
    return-void
.end method

.method private setBeginAddress(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->beginAddress_:J

    .line 2
    .line 3
    return-void
.end method

.method private setMappingName(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mappingName_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setMappingNameBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mappingName_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setMemory(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->memory_:Lcom/google/protobuf/n;

    .line 5
    .line 6
    return-void
.end method

.method private setRegisterName(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->registerName_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setRegisterNameBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->registerName_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    packed-switch p1, :pswitch_data_5e

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_d
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez p1, :cond_27

    .line 17
    .line 18
    const-class p2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 19
    .line 20
    monitor-enter p2

    .line 21
    :try_start_14
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez p1, :cond_23

    .line 24
    .line 25
    new-instance p1, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_23

    .line 33
    :catchall_20
    move-exception v0

    .line 34
    move-object p1, v0

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    :goto_23
    monitor-exit p2

    .line 37
    return-object p1

    .line 38
    :goto_25
    monitor-exit p2
    :try_end_26
    .catchall {:try_start_14 .. :try_end_26} :catchall_20

    .line 39
    throw p1

    .line 40
    :cond_27
    return-object p1

    .line 41
    :pswitch_28
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 42
    .line 43
    return-object p1

    .line 44
    :pswitch_2b
    new-instance p1, Lio/sentry/android/core/internal/tombstone/t;

    .line 45
    .line 46
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->access$24200()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    invoke-direct {p1, p2}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 51
    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_35
    new-instance p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 55
    .line 56
    invoke-direct {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;-><init>()V

    .line 57
    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_3b
    const-string v0, "metadata_"

    .line 61
    .line 62
    const-string v1, "metadataCase_"

    .line 63
    .line 64
    const-string v2, "registerName_"

    .line 65
    .line 66
    const-string v3, "mappingName_"

    .line 67
    .line 68
    const-string v4, "beginAddress_"

    .line 69
    .line 70
    const-string v5, "memory_"

    .line 71
    .line 72
    const-class v6, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;

    .line 73
    .line 74
    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    const-string p2, "\u0000\u0005\u0001\u0000\u0001\u0006\u0005\u0000\u0000\u0000\u0001\u0208\u0002\u0208\u0003\u0003\u0004\n\u0006<\u0000"

    .line 79
    .line 80
    sget-object p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 81
    .line 82
    invoke-static {p3, p2, p1}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    return-object p1

    .line 87
    :pswitch_56
    const/4 p1, 0x0

    .line 88
    return-object p1

    .line 89
    :pswitch_58
    const/4 p1, 0x1

    .line 90
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    return-object p1

    .line 95
    :pswitch_data_5e
    .packed-switch 0x0
        :pswitch_58
        :pswitch_56
        :pswitch_3b
        :pswitch_35
        :pswitch_2b
        :pswitch_28
        :pswitch_d
    .end packed-switch
.end method

.method public getArmMteMetadata()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    if-ne v0, v1, :cond_a

    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadata_:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;

    .line 9
    .line 10
    return-object v0

    .line 11
    :cond_a
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$ArmMTEMetadata;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public getBeginAddress()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->beginAddress_:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getMappingName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mappingName_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMappingNameBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->mappingName_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getMemory()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->memory_:Lcom/google/protobuf/n;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMetadataCase()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 2
    .line 3
    invoke-static {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getRegisterName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->registerName_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getRegisterNameBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->registerName_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public hasArmMteMetadata()Z
    .registers 3

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;->metadataCase_:I

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    if-ne v0, v1, :cond_7

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    return v0

    .line 8
    :cond_7
    const/4 v0, 0x0

    .line 9
    return v0
.end method

###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryDump.a (io.sentry.android.core.internal.tombstone.TombstoneProtos$MemoryDump$a)
.class public final enum Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

.field public static final enum ARM_MTE_METADATA:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

.field public static final enum METADATA_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;


# instance fields
.field private final value:I


# direct methods
.method private static synthetic $values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->ARM_MTE_METADATA:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 2
    .line 3
    sget-object v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->METADATA_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 4
    .line 5
    filled-new-array {v0, v1}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    const-string v2, "ARM_MTE_METADATA"

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    invoke-direct {v0, v2, v3, v1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;-><init>(Ljava/lang/String;II)V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->ARM_MTE_METADATA:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 11
    .line 12
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 13
    .line 14
    const-string v1, "METADATA_NOT_SET"

    .line 15
    .line 16
    const/4 v2, 0x1

    .line 17
    invoke-direct {v0, v1, v2, v3}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;-><init>(Ljava/lang/String;II)V

    .line 18
    .line 19
    .line 20
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->METADATA_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 21
    .line 22
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->$values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 27
    .line 28
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->value:I

    .line 5
    .line 6
    return-void
.end method

.method public static forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    .registers 2

    .line 1
    if-eqz p0, :cond_a

    .line 2
    .line 3
    const/4 v0, 0x6

    .line 4
    if-eq p0, v0, :cond_7

    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    return-object p0

    .line 8
    :cond_7
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->ARM_MTE_METADATA:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_a
    sget-object p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->METADATA_NOT_SET:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 12
    .line 13
    return-object p0
.end method

.method public static valueOf(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 2
    invoke-static {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->forNumber(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    .registers 2

    .line 1
    const-class v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    return-object p0
.end method

.method public static values()[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->$VALUES:[Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 2
    .line 3
    invoke-virtual {v0}, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public getNumber()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump$a;->value:I

    .line 2
    .line 3
    return v0
.end method
