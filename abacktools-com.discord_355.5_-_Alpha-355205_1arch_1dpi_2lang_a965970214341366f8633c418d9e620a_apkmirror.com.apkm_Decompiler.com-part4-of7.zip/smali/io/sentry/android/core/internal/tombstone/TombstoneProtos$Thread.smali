###### Class io.sentry.android.core.internal.tombstone.TombstoneProtos$Thread (io.sentry.android.core.internal.tombstone.TombstoneProtos$Thread)
.class public final Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
.super Lcom/google/protobuf/a1;
.source "SourceFile"

# interfaces
.implements Lcom/google/protobuf/h2;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/a1;",
        "Lcom/google/protobuf/h2;"
    }
.end annotation


# static fields
.field public static final BACKTRACE_NOTE_FIELD_NUMBER:I = 0x7

.field public static final CURRENT_BACKTRACE_FIELD_NUMBER:I = 0x4

.field private static final DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

.field public static final ID_FIELD_NUMBER:I = 0x1

.field public static final MEMORY_DUMP_FIELD_NUMBER:I = 0x5

.field public static final NAME_FIELD_NUMBER:I = 0x2

.field public static final PAC_ENABLED_KEYS_FIELD_NUMBER:I = 0x8

.field private static volatile PARSER:Lcom/google/protobuf/u2; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/u2;"
        }
    .end annotation
.end field

.field public static final REGISTERS_FIELD_NUMBER:I = 0x3

.field public static final TAGGED_ADDR_CTRL_FIELD_NUMBER:I = 0x6

.field public static final UNREADABLE_ELF_FILES_FIELD_NUMBER:I = 0x9


# instance fields
.field private backtraceNote_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private currentBacktrace_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private id_:I

.field private memoryDump_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private name_:Ljava/lang/String;

.field private pacEnabledKeys_:J

.field private registers_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field

.field private taggedAddrCtrl_:J

.field private unreadableElfFiles_:Lcom/google/protobuf/m1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/m1;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 7
    .line 8
    const-class v1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lcom/google/protobuf/a1;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/a1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/protobuf/a1;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, ""

    .line 5
    .line 6
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->name_:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 13
    .line 14
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 19
    .line 20
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 25
    .line 26
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 31
    .line 32
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 37
    .line 38
    return-void
.end method

.method public static synthetic access$17800()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic access$17900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setId(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearId()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setName(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearName()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setNameBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setRegisters(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addRegisters(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addRegisters(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addAllRegisters(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearRegisters()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$18900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->removeRegisters(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILjava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setBacktraceNote(ILjava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addBacktraceNote(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addAllBacktraceNote(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearBacktraceNote()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addBacktraceNoteBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILjava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setUnreadableElfFiles(ILjava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addUnreadableElfFiles(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addAllUnreadableElfFiles(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearUnreadableElfFiles()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$19900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addUnreadableElfFilesBytes(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setCurrentBacktrace(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addCurrentBacktrace(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addCurrentBacktrace(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addAllCurrentBacktrace(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearCurrentBacktrace()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->removeCurrentBacktrace(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20600(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setMemoryDump(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20700(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addMemoryDump(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20800(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addMemoryDump(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$20900(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;Ljava/lang/Iterable;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->addAllMemoryDump(Ljava/lang/Iterable;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$21000(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearMemoryDump()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$21100(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;I)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->removeMemoryDump(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$21200(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;J)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setTaggedAddrCtrl(J)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$21300(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearTaggedAddrCtrl()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$21400(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;J)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->setPacEnabledKeys(J)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic access$21500(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->clearPacEnabledKeys()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private addAllBacktraceNote(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureBacktraceNoteIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllCurrentBacktrace(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureCurrentBacktraceIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllMemoryDump(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureMemoryDumpIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllRegisters(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureRegistersIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addAllUnreadableElfFiles(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureUnreadableElfFilesIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-static {p1, v0}, Lcom/google/protobuf/b;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private addBacktraceNote(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureBacktraceNoteIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private addBacktraceNoteBytes(Lcom/google/protobuf/n;)V
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureBacktraceNoteIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method private addCurrentBacktrace(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureCurrentBacktraceIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addCurrentBacktrace(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureCurrentBacktraceIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addMemoryDump(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureMemoryDumpIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addMemoryDump(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureMemoryDumpIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addRegisters(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V
    .registers 4

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureRegistersIsMutable()V

    .line 6
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addRegisters(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureRegistersIsMutable()V

    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addUnreadableElfFiles(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureUnreadableElfFilesIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private addUnreadableElfFilesBytes(Lcom/google/protobuf/n;)V
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureUnreadableElfFilesIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method private clearBacktraceNote()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearCurrentBacktrace()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearId()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->id_:I

    .line 3
    .line 4
    return-void
.end method

.method private clearMemoryDump()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearName()V
    .registers 2

    .line 1
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->getName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->name_:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method private clearPacEnabledKeys()V
    .registers 3

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->pacEnabledKeys_:J

    .line 4
    .line 5
    return-void
.end method

.method private clearRegisters()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private clearTaggedAddrCtrl()V
    .registers 3

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->taggedAddrCtrl_:J

    .line 4
    .line 5
    return-void
.end method

.method private clearUnreadableElfFiles()V
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/protobuf/a1;->emptyProtobufList()Lcom/google/protobuf/m1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 6
    .line 7
    return-void
.end method

.method private ensureBacktraceNoteIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureCurrentBacktraceIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureMemoryDumpIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureRegistersIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method private ensureUnreadableElfFilesIsMutable()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/protobuf/c;

    .line 5
    .line 6
    iget-boolean v1, v1, Lcom/google/protobuf/c;->d:Z

    .line 7
    .line 8
    if-nez v1, :cond_f

    .line 9
    .line 10
    invoke-static {v0}, Lcom/google/protobuf/a1;->mutableCopy(Lcom/google/protobuf/m1;)Lcom/google/protobuf/m1;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method public static getDefaultInstance()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 2
    .line 3
    return-object v0
.end method

.method public static newBuilder()Lio/sentry/android/core/internal/tombstone/i0;
    .registers 1

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-virtual {v0}, Lcom/google/protobuf/a1;->createBuilder()Lcom/google/protobuf/u0;

    move-result-object v0

    check-cast v0, Lio/sentry/android/core/internal/tombstone/i0;

    return-object v0
.end method

.method public static newBuilder(Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;)Lio/sentry/android/core/internal/tombstone/i0;
    .registers 2

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/a1;->createBuilder(Lcom/google/protobuf/a1;)Lcom/google/protobuf/u0;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/i0;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseDelimitedFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 2

    .line 3
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 3

    .line 4
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/n;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 2

    .line 9
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 3

    .line 10
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Lcom/google/protobuf/s;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 2

    .line 7
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 3

    .line 8
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/io/InputStream;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 2

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 3

    .line 2
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;Ljava/nio/ByteBuffer;Lcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom([B)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 2

    .line 5
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[B)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/g0;)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;
    .registers 3

    .line 6
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/a1;->parseFrom(Lcom/google/protobuf/a1;[BLcom/google/protobuf/g0;)Lcom/google/protobuf/a1;

    move-result-object p0

    check-cast p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/u2;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/u2;"
        }
    .end annotation

    .line 1
    sget-object v0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/protobuf/a1;->getParserForType()Lcom/google/protobuf/u2;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private removeCurrentBacktrace(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureCurrentBacktraceIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private removeMemoryDump(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureMemoryDumpIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private removeRegisters(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureRegistersIsMutable()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 5
    .line 6
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method private setBacktraceNote(ILjava/lang/String;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureBacktraceNoteIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setCurrentBacktrace(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureCurrentBacktraceIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setId(I)V
    .registers 2

    .line 1
    iput p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->id_:I

    .line 2
    .line 3
    return-void
.end method

.method private setMemoryDump(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureMemoryDumpIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setName(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->name_:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method private setNameBytes(Lcom/google/protobuf/n;)V
    .registers 2

    .line 1
    invoke-static {p1}, Lcom/google/protobuf/b;->checkByteStringIsUtf8(Lcom/google/protobuf/n;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/google/protobuf/n;->r()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->name_:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method

.method private setPacEnabledKeys(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->pacEnabledKeys_:J

    .line 2
    .line 3
    return-void
.end method

.method private setRegisters(ILio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureRegistersIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method private setTaggedAddrCtrl(J)V
    .registers 3

    .line 1
    iput-wide p1, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->taggedAddrCtrl_:J

    .line 2
    .line 3
    return-void
.end method

.method private setUnreadableElfFiles(ILjava/lang/String;)V
    .registers 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->ensureUnreadableElfFilesIsMutable()V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 8
    .line 9
    invoke-interface {v0, p1, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final dynamicMethod(Lcom/google/protobuf/z0;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    packed-switch p1, :pswitch_data_68

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_d
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->PARSER:Lcom/google/protobuf/u2;

    .line 15
    .line 16
    if-nez p1, :cond_27

    .line 17
    .line 18
    const-class p2, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 19
    .line 20
    monitor-enter p2

    .line 21
    :try_start_14
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->PARSER:Lcom/google/protobuf/u2;

    .line 22
    .line 23
    if-nez p1, :cond_23

    .line 24
    .line 25
    new-instance p1, Lcom/google/protobuf/v0;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->PARSER:Lcom/google/protobuf/u2;

    .line 31
    .line 32
    goto :goto_23

    .line 33
    :catchall_20
    move-exception v0

    .line 34
    move-object p1, v0

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    :goto_23
    monitor-exit p2

    .line 37
    return-object p1

    .line 38
    :goto_25
    monitor-exit p2
    :try_end_26
    .catchall {:try_start_14 .. :try_end_26} :catchall_20

    .line 39
    throw p1

    .line 40
    :cond_27
    return-object p1

    .line 41
    :pswitch_28
    sget-object p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 42
    .line 43
    return-object p1

    .line 44
    :pswitch_2b
    new-instance p1, Lio/sentry/android/core/internal/tombstone/i0;

    .line 45
    .line 46
    invoke-static {}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->access$17800()Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    invoke-direct {p1, p2}, Lcom/google/protobuf/u0;-><init>(Lcom/google/protobuf/a1;)V

    .line 51
    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_35
    new-instance p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 55
    .line 56
    invoke-direct {p1}, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;-><init>()V

    .line 57
    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_3b
    const-string v0, "id_"

    .line 61
    .line 62
    const-string v1, "name_"

    .line 63
    .line 64
    const-string v2, "registers_"

    .line 65
    .line 66
    const-class v3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;

    .line 67
    .line 68
    const-string v4, "currentBacktrace_"

    .line 69
    .line 70
    const-class v5, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;

    .line 71
    .line 72
    const-string v6, "memoryDump_"

    .line 73
    .line 74
    const-class v7, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 75
    .line 76
    const-string v8, "taggedAddrCtrl_"

    .line 77
    .line 78
    const-string v9, "backtraceNote_"

    .line 79
    .line 80
    const-string v10, "pacEnabledKeys_"

    .line 81
    .line 82
    const-string v11, "unreadableElfFiles_"

    .line 83
    .line 84
    filled-new-array/range {v0 .. v11}, [Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    const-string p2, "\u0000\t\u0000\u0000\u0001\t\t\u0000\u0005\u0000\u0001\u0004\u0002\u0208\u0003\u001b\u0004\u001b\u0005\u001b\u0006\u0002\u0007\u021a\u0008\u0002\t\u021a"

    .line 89
    .line 90
    sget-object p3, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->DEFAULT_INSTANCE:Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;

    .line 91
    .line 92
    invoke-static {p3, p2, p1}, Lcom/google/protobuf/a1;->newMessageInfo(Lcom/google/protobuf/g2;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    return-object p1

    .line 97
    :pswitch_60
    const/4 p1, 0x0

    .line 98
    return-object p1

    .line 99
    :pswitch_62
    const/4 p1, 0x1

    .line 100
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    return-object p1

    .line 105
    :pswitch_data_68
    .packed-switch 0x0
        :pswitch_62
        :pswitch_60
        :pswitch_3b
        :pswitch_35
        :pswitch_2b
        :pswitch_28
        :pswitch_d
    .end packed-switch
.end method

.method public getBacktraceNote(I)Ljava/lang/String;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    return-object p1
.end method

.method public getBacktraceNoteBytes(I)Lcom/google/protobuf/n;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {p1}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method

.method public getBacktraceNoteCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getBacktraceNoteList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->backtraceNote_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCurrentBacktrace(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCurrentBacktraceCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getCurrentBacktraceList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$BacktraceFrame;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCurrentBacktraceOrBuilder(I)Lio/sentry/android/core/internal/tombstone/h;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/h;

    .line 8
    .line 9
    return-object p1
.end method

.method public getCurrentBacktraceOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/h;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->currentBacktrace_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getId()I
    .registers 2

    .line 1
    iget v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->id_:I

    .line 2
    .line 3
    return v0
.end method

.method public getMemoryDump(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;

    .line 8
    .line 9
    return-object p1
.end method

.method public getMemoryDumpCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getMemoryDumpList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$MemoryDump;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getMemoryDumpOrBuilder(I)Lio/sentry/android/core/internal/tombstone/u;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/u;

    .line 8
    .line 9
    return-object p1
.end method

.method public getMemoryDumpOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/u;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->memoryDump_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->name_:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/n;
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->name_:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public getPacEnabledKeys()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->pacEnabledKeys_:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getRegisters(I)Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;

    .line 8
    .line 9
    return-object p1
.end method

.method public getRegistersCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getRegistersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Register;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getRegistersOrBuilder(I)Lio/sentry/android/core/internal/tombstone/d0;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lio/sentry/android/core/internal/tombstone/d0;

    .line 8
    .line 9
    return-object p1
.end method

.method public getRegistersOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lio/sentry/android/core/internal/tombstone/d0;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->registers_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getTaggedAddrCtrl()J
    .registers 3

    .line 1
    iget-wide v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->taggedAddrCtrl_:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public getUnreadableElfFiles(I)Ljava/lang/String;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    return-object p1
.end method

.method public getUnreadableElfFilesBytes(I)Lcom/google/protobuf/n;
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-static {p1}, Lcom/google/protobuf/n;->f(Ljava/lang/String;)Lcom/google/protobuf/m;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method

.method public getUnreadableElfFilesCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public getUnreadableElfFilesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/tombstone/TombstoneProtos$Thread;->unreadableElfFiles_:Lcom/google/protobuf/m1;

    .line 2
    .line 3
    return-object v0
.end method
