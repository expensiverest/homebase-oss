###### Class io.sentry.android.core.internal.tombstone.c0 (io.sentry.android.core.internal.tombstone.c0)
.class public final Lio/sentry/android/core/internal/tombstone/c0;
.super Lcom/google/protobuf/u0;
.source "SourceFile"

# interfaces
.implements Lio/sentry/android/core/internal/tombstone/d0;
