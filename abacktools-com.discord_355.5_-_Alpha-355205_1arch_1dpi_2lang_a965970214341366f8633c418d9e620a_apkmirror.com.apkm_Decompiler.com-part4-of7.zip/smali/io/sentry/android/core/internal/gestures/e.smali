###### Class io.sentry.android.core.internal.gestures.e (io.sentry.android.core.internal.gestures.e)
.class public final Lio/sentry/android/core/internal/gestures/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/GestureDetector$OnGestureListener;


# instance fields
.field public final d:Ljava/lang/ref/WeakReference;

.field public final e:Lio/sentry/a1;

.field public final i:Lio/sentry/android/core/SentryAndroidOptions;

.field public v:Lio/sentry/internal/gestures/b;

.field public w:Lio/sentry/j1;

.field public x:Lio/sentry/android/core/internal/gestures/d;

.field public final y:Lc30/d;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->v:Lio/sentry/internal/gestures/b;

    .line 6
    .line 7
    iput-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 8
    .line 9
    sget-object v0, Lio/sentry/android/core/internal/gestures/d;->Unknown:Lio/sentry/android/core/internal/gestures/d;

    .line 10
    .line 11
    iput-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->x:Lio/sentry/android/core/internal/gestures/d;

    .line 12
    .line 13
    new-instance v1, Lc30/d;

    .line 14
    .line 15
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object v0, v1, Lc30/d;->c:Ljava/lang/Object;

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    iput v0, v1, Lc30/d;->a:F

    .line 22
    .line 23
    iput v0, v1, Lc30/d;->b:F

    .line 24
    .line 25
    iput-object v1, p0, Lio/sentry/android/core/internal/gestures/e;->y:Lc30/d;

    .line 26
    .line 27
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 28
    .line 29
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->d:Ljava/lang/ref/WeakReference;

    .line 33
    .line 34
    iput-object p2, p0, Lio/sentry/android/core/internal/gestures/e;->e:Lio/sentry/a1;

    .line 35
    .line 36
    iput-object p3, p0, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final a(Lio/sentry/internal/gestures/b;Lio/sentry/android/core/internal/gestures/d;Ljava/util/Map;Landroid/view/MotionEvent;)V
    .registers 8

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/a6;->isEnableUserInteractionBreadcrumbs()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_9

    .line 8
    .line 9
    return-void

    .line 10
    :cond_9
    sget-object v0, Lio/sentry/android/core/internal/gestures/c;->a:[I

    .line 11
    .line 12
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 13
    .line 14
    .line 15
    move-result p2

    .line 16
    aget p2, v0, p2

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    if-eq p2, v0, :cond_23

    .line 20
    .line 21
    const/4 v0, 0x2

    .line 22
    if-eq p2, v0, :cond_20

    .line 23
    .line 24
    const/4 v0, 0x3

    .line 25
    if-eq p2, v0, :cond_1d

    .line 26
    .line 27
    const-string p2, "unknown"

    .line 28
    .line 29
    goto :goto_25

    .line 30
    :cond_1d
    const-string p2, "swipe"

    .line 31
    .line 32
    goto :goto_25

    .line 33
    :cond_20
    const-string p2, "scroll"

    .line 34
    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const-string p2, "click"

    .line 37
    .line 38
    :goto_25
    new-instance v0, Lio/sentry/h0;

    .line 39
    .line 40
    invoke-direct {v0}, Lio/sentry/h0;-><init>()V

    .line 41
    .line 42
    .line 43
    const-string v1, "android:motionEvent"

    .line 44
    .line 45
    invoke-virtual {v0, p4, v1}, Lio/sentry/h0;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object p4, p1, Lio/sentry/internal/gestures/b;->a:Ljava/lang/ref/WeakReference;

    .line 49
    .line 50
    invoke-virtual {p4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p4

    .line 54
    const-string v1, "android:view"

    .line 55
    .line 56
    invoke-virtual {v0, p4, v1}, Lio/sentry/h0;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    iget-object p4, p1, Lio/sentry/internal/gestures/b;->c:Ljava/lang/String;

    .line 60
    .line 61
    iget-object p1, p1, Lio/sentry/internal/gestures/b;->b:Ljava/lang/String;

    .line 62
    .line 63
    new-instance v1, Lio/sentry/e;

    .line 64
    .line 65
    invoke-direct {v1}, Lio/sentry/e;-><init>()V

    .line 66
    .line 67
    .line 68
    const-string v2, "user"

    .line 69
    .line 70
    iput-object v2, v1, Lio/sentry/e;->w:Ljava/lang/String;

    .line 71
    .line 72
    const-string v2, "ui."

    .line 73
    .line 74
    invoke-virtual {v2, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    iput-object p2, v1, Lio/sentry/e;->y:Ljava/lang/String;

    .line 79
    .line 80
    if-eqz p4, :cond_56

    .line 81
    .line 82
    const-string p2, "view.id"

    .line 83
    .line 84
    invoke-virtual {v1, p4, p2}, Lio/sentry/e;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    :cond_56
    if-eqz p1, :cond_5d

    .line 88
    .line 89
    const-string p2, "view.class"

    .line 90
    .line 91
    invoke-virtual {v1, p1, p2}, Lio/sentry/e;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    :cond_5d
    invoke-interface {p3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    :goto_65
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 103
    .line 104
    .line 105
    move-result p2

    .line 106
    if-eqz p2, :cond_81

    .line 107
    .line 108
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object p2

    .line 112
    check-cast p2, Ljava/util/Map$Entry;

    .line 113
    .line 114
    iget-object p3, v1, Lio/sentry/e;->x:Ljava/util/concurrent/ConcurrentHashMap;

    .line 115
    .line 116
    invoke-interface {p2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object p4

    .line 120
    check-cast p4, Ljava/lang/String;

    .line 121
    .line 122
    invoke-interface {p2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object p2

    .line 126
    invoke-interface {p3, p4, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    goto :goto_65

    .line 130
    :cond_81
    sget-object p1, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 131
    .line 132
    iput-object p1, v1, Lio/sentry/e;->K:Lio/sentry/a5;

    .line 133
    .line 134
    iget-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->e:Lio/sentry/a1;

    .line 135
    .line 136
    invoke-interface {p1, v1, v0}, Lio/sentry/a1;->g(Lio/sentry/e;Lio/sentry/h0;)V

    .line 137
    .line 138
    .line 139
    return-void
.end method

.method public final b(Ljava/lang/String;)Landroid/view/View;
    .registers 8

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->d:Ljava/lang/ref/WeakReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/Activity;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    const/4 v2, 0x0

    .line 11
    const-string v3, ". No breadcrumb captured."

    .line 12
    .line 13
    iget-object v4, p0, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 14
    .line 15
    if-nez v0, :cond_22

    .line 16
    .line 17
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sget-object v4, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 22
    .line 23
    const-string v5, "Activity is null in "

    .line 24
    .line 25
    invoke-static {v5, p1, v3}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    new-array v2, v2, [Ljava/lang/Object;

    .line 30
    .line 31
    invoke-interface {v0, v4, p1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-object v1

    .line 35
    :cond_22
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-nez v0, :cond_3a

    .line 40
    .line 41
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    sget-object v4, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 46
    .line 47
    const-string v5, "Window is null in "

    .line 48
    .line 49
    invoke-static {v5, p1, v3}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    new-array v2, v2, [Ljava/lang/Object;

    .line 54
    .line 55
    invoke-interface {v0, v4, p1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    return-object v1

    .line 59
    :cond_3a
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    if-nez v0, :cond_52

    .line 64
    .line 65
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    sget-object v4, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 70
    .line 71
    const-string v5, "DecorView is null in "

    .line 72
    .line 73
    invoke-static {v5, p1, v3}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    new-array v2, v2, [Ljava/lang/Object;

    .line 78
    .line 79
    invoke-interface {v0, v4, p1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    return-object v1

    .line 83
    :cond_52
    return-object v0
.end method

.method public final c(Lio/sentry/internal/gestures/b;Lio/sentry/android/core/internal/gestures/d;)V
    .registers 14

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->x:Lio/sentry/android/core/internal/gestures/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-ne p2, v0, :cond_10

    .line 6
    .line 7
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->v:Lio/sentry/internal/gestures/b;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Lio/sentry/internal/gestures/b;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_10

    .line 14
    .line 15
    move v0, v2

    .line 16
    goto :goto_11

    .line 17
    :cond_10
    move v0, v1

    .line 18
    :goto_11
    sget-object v3, Lio/sentry/android/core/internal/gestures/d;->Click:Lio/sentry/android/core/internal/gestures/d;

    .line 19
    .line 20
    if-ne p2, v3, :cond_16

    .line 21
    .line 22
    goto :goto_18

    .line 23
    :cond_16
    if-nez v0, :cond_1a

    .line 24
    .line 25
    :goto_18
    move v0, v2

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    move v0, v1

    .line 28
    :goto_1b
    iget-object v3, p0, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 29
    .line 30
    invoke-virtual {v3}, Lio/sentry/a6;->isTracingEnabled()Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    iget-object v5, p0, Lio/sentry/android/core/internal/gestures/e;->e:Lio/sentry/a1;

    .line 35
    .line 36
    const/4 v6, 0x0

    .line 37
    if-eqz v4, :cond_10d

    .line 38
    .line 39
    invoke-virtual {v3}, Lio/sentry/a6;->isEnableUserInteractionTracing()Z

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    if-nez v4, :cond_2e

    .line 44
    .line 45
    goto/16 :goto_10d

    .line 46
    .line 47
    :cond_2e
    iget-object v4, p0, Lio/sentry/android/core/internal/gestures/e;->d:Ljava/lang/ref/WeakReference;

    .line 48
    .line 49
    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    check-cast v4, Landroid/app/Activity;

    .line 54
    .line 55
    if-nez v4, :cond_46

    .line 56
    .line 57
    invoke-virtual {v3}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    sget-object p2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 62
    .line 63
    const-string v0, "Activity is null, no transaction captured."

    .line 64
    .line 65
    new-array v1, v1, [Ljava/lang/Object;

    .line 66
    .line 67
    invoke-interface {p1, p2, v0, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_46
    iget-object v7, p1, Lio/sentry/internal/gestures/b;->c:Ljava/lang/String;

    .line 72
    .line 73
    if-eqz v7, :cond_4b

    .line 74
    .line 75
    goto :goto_51

    .line 76
    :cond_4b
    const-string v7, "UiElement.tag can\'t be null"

    .line 77
    .line 78
    invoke-static {v6, v7}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    move-object v7, v6

    .line 82
    :goto_51
    iget-object v8, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 83
    .line 84
    if-eqz v8, :cond_81

    .line 85
    .line 86
    if-nez v0, :cond_7c

    .line 87
    .line 88
    invoke-interface {v8}, Lio/sentry/h1;->isFinished()Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-nez v0, :cond_7c

    .line 93
    .line 94
    invoke-virtual {v3}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    sget-object p2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 99
    .line 100
    const-string v0, "The view with id: "

    .line 101
    .line 102
    const-string v2, " already has an ongoing transaction assigned. Rescheduling finish"

    .line 103
    .line 104
    invoke-static {v0, v7, v2}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    new-array v1, v1, [Ljava/lang/Object;

    .line 109
    .line 110
    invoke-interface {p1, p2, v0, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v3}, Lio/sentry/a6;->getIdleTimeout()Ljava/lang/Long;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    if-eqz p1, :cond_123

    .line 118
    .line 119
    iget-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 120
    .line 121
    invoke-interface {p1}, Lio/sentry/j1;->m()V

    .line 122
    .line 123
    .line 124
    return-void

    .line 125
    :cond_7c
    sget-object v0, Lio/sentry/p6;->OK:Lio/sentry/p6;

    .line 126
    .line 127
    invoke-virtual {p0, v0}, Lio/sentry/android/core/internal/gestures/e;->d(Lio/sentry/p6;)V

    .line 128
    .line 129
    .line 130
    :cond_81
    new-instance v0, Ljava/lang/StringBuilder;

    .line 131
    .line 132
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 144
    .line 145
    .line 146
    const-string v1, "."

    .line 147
    .line 148
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 149
    .line 150
    .line 151
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 152
    .line 153
    .line 154
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    sget-object v1, Lio/sentry/android/core/internal/gestures/c;->a:[I

    .line 159
    .line 160
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 161
    .line 162
    .line 163
    move-result v4

    .line 164
    aget v1, v1, v4

    .line 165
    .line 166
    if-eq v1, v2, :cond_b6

    .line 167
    .line 168
    const/4 v4, 0x2

    .line 169
    if-eq v1, v4, :cond_b3

    .line 170
    .line 171
    const/4 v4, 0x3

    .line 172
    if-eq v1, v4, :cond_b0

    .line 173
    .line 174
    const-string v1, "unknown"

    .line 175
    .line 176
    goto :goto_b8

    .line 177
    :cond_b0
    const-string v1, "swipe"

    .line 178
    .line 179
    goto :goto_b8

    .line 180
    :cond_b3
    const-string v1, "scroll"

    .line 181
    .line 182
    goto :goto_b8

    .line 183
    :cond_b6
    const-string v1, "click"

    .line 184
    .line 185
    :goto_b8
    const-string v4, "ui.action."

    .line 186
    .line 187
    invoke-virtual {v4, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    new-instance v4, Lio/sentry/u6;

    .line 192
    .line 193
    invoke-direct {v4}, Lio/sentry/u6;-><init>()V

    .line 194
    .line 195
    .line 196
    iput-boolean v2, v4, Lio/sentry/u6;->x:Z

    .line 197
    .line 198
    invoke-virtual {v3}, Lio/sentry/a6;->getDeadlineTimeout()J

    .line 199
    .line 200
    .line 201
    move-result-wide v7

    .line 202
    const-wide/16 v9, 0x0

    .line 203
    .line 204
    cmp-long v9, v7, v9

    .line 205
    .line 206
    if-gtz v9, :cond_d1

    .line 207
    .line 208
    move-object v7, v6

    .line 209
    goto :goto_d5

    .line 210
    :cond_d1
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 211
    .line 212
    .line 213
    move-result-object v7

    .line 214
    :goto_d5
    iput-object v7, v4, Lio/sentry/u6;->J:Ljava/lang/Long;

    .line 215
    .line 216
    invoke-virtual {v3}, Lio/sentry/a6;->getIdleTimeout()Ljava/lang/Long;

    .line 217
    .line 218
    .line 219
    move-result-object v3

    .line 220
    iput-object v3, v4, Lio/sentry/u6;->y:Ljava/lang/Long;

    .line 221
    .line 222
    iput-boolean v2, v4, Lcom/google/firebase/messaging/o;->d:Z

    .line 223
    .line 224
    new-instance v2, Ljava/lang/StringBuilder;

    .line 225
    .line 226
    const-string v3, "auto.ui.gesture_listener."

    .line 227
    .line 228
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    iget-object v3, p1, Lio/sentry/internal/gestures/b;->d:Ljava/lang/String;

    .line 232
    .line 233
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v2

    .line 240
    iput-object v2, v4, Lcom/google/firebase/messaging/o;->v:Ljava/lang/Object;

    .line 241
    .line 242
    new-instance v2, Lio/sentry/t6;

    .line 243
    .line 244
    sget-object v3, Lio/sentry/protocol/h0;->COMPONENT:Lio/sentry/protocol/h0;

    .line 245
    .line 246
    invoke-direct {v2, v0, v3, v1, v6}, Lio/sentry/t6;-><init>(Ljava/lang/String;Lio/sentry/protocol/h0;Ljava/lang/String;Lf10/e;)V

    .line 247
    .line 248
    .line 249
    invoke-interface {v5, v2, v4}, Lio/sentry/a1;->j(Lio/sentry/t6;Lio/sentry/u6;)Lio/sentry/j1;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    new-instance v1, Lc4/s;

    .line 254
    .line 255
    const/16 v2, 0x14

    .line 256
    .line 257
    invoke-direct {v1, v2, p0, v0}, Lc4/s;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    invoke-interface {v5, v6, v1}, Lio/sentry/a1;->q(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 261
    .line 262
    .line 263
    iput-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 264
    .line 265
    iput-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->v:Lio/sentry/internal/gestures/b;

    .line 266
    .line 267
    iput-object p2, p0, Lio/sentry/android/core/internal/gestures/e;->x:Lio/sentry/android/core/internal/gestures/d;

    .line 268
    .line 269
    return-void

    .line 270
    :cond_10d
    :goto_10d
    if-eqz v0, :cond_123

    .line 271
    .line 272
    invoke-virtual {v3}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableAutoTraceIdGeneration()Z

    .line 273
    .line 274
    .line 275
    move-result v0

    .line 276
    if-eqz v0, :cond_11f

    .line 277
    .line 278
    new-instance v0, Lio/sentry/p2;

    .line 279
    .line 280
    const/16 v1, 0x17

    .line 281
    .line 282
    invoke-direct {v0, v1}, Lio/sentry/p2;-><init>(I)V

    .line 283
    .line 284
    .line 285
    invoke-interface {v5, v6, v0}, Lio/sentry/a1;->q(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 286
    .line 287
    .line 288
    :cond_11f
    iput-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->v:Lio/sentry/internal/gestures/b;

    .line 289
    .line 290
    iput-object p2, p0, Lio/sentry/android/core/internal/gestures/e;->x:Lio/sentry/android/core/internal/gestures/d;

    .line 291
    .line 292
    :cond_123
    return-void
.end method

.method public final d(Lio/sentry/p6;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 2
    .line 3
    if-eqz v0, :cond_15

    .line 4
    .line 5
    invoke-interface {v0}, Lio/sentry/h1;->b()Lio/sentry/p6;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-nez v0, :cond_10

    .line 10
    .line 11
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 12
    .line 13
    invoke-interface {v0, p1}, Lio/sentry/h1;->f(Lio/sentry/p6;)V

    .line 14
    .line 15
    .line 16
    goto :goto_15

    .line 17
    :cond_10
    iget-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 18
    .line 19
    invoke-interface {p1}, Lio/sentry/h1;->g()V

    .line 20
    .line 21
    .line 22
    :cond_15
    :goto_15
    new-instance p1, Lio/sentry/android/core/n0;

    .line 23
    .line 24
    const/4 v0, 0x4

    .line 25
    invoke-direct {p1, v0, p0}, Lio/sentry/android/core/n0;-><init>(ILjava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/e;->e:Lio/sentry/a1;

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-interface {v0, v1, p1}, Lio/sentry/a1;->q(Lio/sentry/x3;Lio/sentry/v3;)V

    .line 32
    .line 33
    .line 34
    iput-object v1, p0, Lio/sentry/android/core/internal/gestures/e;->w:Lio/sentry/j1;

    .line 35
    .line 36
    iget-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->v:Lio/sentry/internal/gestures/b;

    .line 37
    .line 38
    if-eqz p1, :cond_29

    .line 39
    .line 40
    iput-object v1, p0, Lio/sentry/android/core/internal/gestures/e;->v:Lio/sentry/internal/gestures/b;

    .line 41
    .line 42
    :cond_29
    sget-object p1, Lio/sentry/android/core/internal/gestures/d;->Unknown:Lio/sentry/android/core/internal/gestures/d;

    .line 43
    .line 44
    iput-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->x:Lio/sentry/android/core/internal/gestures/d;

    .line 45
    .line 46
    return-void
.end method

.method public final onDown(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    const/4 v1, 0x0

    .line 6
    iget-object v2, p0, Lio/sentry/android/core/internal/gestures/e;->y:Lc30/d;

    .line 7
    .line 8
    iput-object v1, v2, Lc30/d;->d:Ljava/lang/Object;

    .line 9
    .line 10
    sget-object v1, Lio/sentry/android/core/internal/gestures/d;->Unknown:Lio/sentry/android/core/internal/gestures/d;

    .line 11
    .line 12
    iput-object v1, v2, Lc30/d;->c:Ljava/lang/Object;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    iput v1, v2, Lc30/d;->a:F

    .line 16
    .line 17
    iput v1, v2, Lc30/d;->b:F

    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    iput v1, v2, Lc30/d;->a:F

    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    iput p1, v2, Lc30/d;->b:F

    .line 30
    .line 31
    return v0
.end method

.method public final onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 5

    .line 1
    iget-object p1, p0, Lio/sentry/android/core/internal/gestures/e;->y:Lc30/d;

    .line 2
    .line 3
    sget-object p2, Lio/sentry/android/core/internal/gestures/d;->Swipe:Lio/sentry/android/core/internal/gestures/d;

    .line 4
    .line 5
    iput-object p2, p1, Lc30/d;->c:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    return p1
.end method

.method public final onLongPress(Landroid/view/MotionEvent;)V
    .registers 2

    return-void
.end method

.method public final onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 9

    .line 1
    const-string p2, "onScroll"

    .line 2
    .line 3
    invoke-virtual {p0, p2}, Lio/sentry/android/core/internal/gestures/e;->b(Ljava/lang/String;)Landroid/view/View;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    const/4 p3, 0x0

    .line 8
    if-eqz p2, :cond_65

    .line 9
    .line 10
    if-nez p1, :cond_c

    .line 11
    .line 12
    goto :goto_65

    .line 13
    :cond_c
    iget-object p4, p0, Lio/sentry/android/core/internal/gestures/e;->y:Lc30/d;

    .line 14
    .line 15
    iget-object v0, p4, Lc30/d;->c:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lio/sentry/android/core/internal/gestures/d;

    .line 18
    .line 19
    sget-object v1, Lio/sentry/android/core/internal/gestures/d;->Unknown:Lio/sentry/android/core/internal/gestures/d;

    .line 20
    .line 21
    if-ne v0, v1, :cond_65

    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    sget-object v1, Lio/sentry/internal/gestures/a;->SCROLLABLE:Lio/sentry/internal/gestures/a;

    .line 32
    .line 33
    iget-object v2, p0, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 34
    .line 35
    invoke-static {v2, p2, v0, p1, v1}, Lio/sentry/android/core/internal/gestures/g;->a(Lio/sentry/android/core/SentryAndroidOptions;Landroid/view/View;FFLio/sentry/internal/gestures/a;)Lio/sentry/internal/gestures/b;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    if-nez p1, :cond_3a

    .line 40
    .line 41
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    sget-object p2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 46
    .line 47
    const-string v0, "Unable to find scroll target. No breadcrumb captured."

    .line 48
    .line 49
    new-array v1, p3, [Ljava/lang/Object;

    .line 50
    .line 51
    invoke-interface {p1, p2, v0, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    sget-object p1, Lio/sentry/android/core/internal/gestures/d;->Scroll:Lio/sentry/android/core/internal/gestures/d;

    .line 55
    .line 56
    iput-object p1, p4, Lc30/d;->c:Ljava/lang/Object;

    .line 57
    .line 58
    return p3

    .line 59
    :cond_3a
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 60
    .line 61
    .line 62
    move-result-object p2

    .line 63
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 64
    .line 65
    new-instance v1, Ljava/lang/StringBuilder;

    .line 66
    .line 67
    const-string v2, "Scroll target found: "

    .line 68
    .line 69
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-object v2, p1, Lio/sentry/internal/gestures/b;->c:Ljava/lang/String;

    .line 73
    .line 74
    if-eqz v2, :cond_4c

    .line 75
    .line 76
    goto :goto_53

    .line 77
    :cond_4c
    const-string v2, "UiElement.tag can\'t be null"

    .line 78
    .line 79
    const/4 v3, 0x0

    .line 80
    invoke-static {v3, v2}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    move-object v2, v3

    .line 84
    :goto_53
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    new-array v2, p3, [Ljava/lang/Object;

    .line 92
    .line 93
    invoke-interface {p2, v0, v1, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    iput-object p1, p4, Lc30/d;->d:Ljava/lang/Object;

    .line 97
    .line 98
    sget-object p1, Lio/sentry/android/core/internal/gestures/d;->Scroll:Lio/sentry/android/core/internal/gestures/d;

    .line 99
    .line 100
    iput-object p1, p4, Lc30/d;->c:Ljava/lang/Object;

    .line 101
    .line 102
    :cond_65
    :goto_65
    return p3
.end method

.method public final onShowPress(Landroid/view/MotionEvent;)V
    .registers 2

    return-void
.end method

.method public final onSingleTapUp(Landroid/view/MotionEvent;)Z
    .registers 8

    .line 1
    const-string v0, "onSingleTapUp"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lio/sentry/android/core/internal/gestures/e;->b(Ljava/lang/String;)Landroid/view/View;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_36

    .line 9
    .line 10
    if-nez p1, :cond_c

    .line 11
    .line 12
    goto :goto_36

    .line 13
    :cond_c
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    sget-object v4, Lio/sentry/internal/gestures/a;->CLICKABLE:Lio/sentry/internal/gestures/a;

    .line 22
    .line 23
    iget-object v5, p0, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 24
    .line 25
    invoke-static {v5, v0, v2, v3, v4}, Lio/sentry/android/core/internal/gestures/g;->a(Lio/sentry/android/core/SentryAndroidOptions;Landroid/view/View;FFLio/sentry/internal/gestures/a;)Lio/sentry/internal/gestures/b;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    if-nez v0, :cond_2c

    .line 30
    .line 31
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 36
    .line 37
    const-string v2, "Unable to find click target. No breadcrumb captured."

    .line 38
    .line 39
    new-array v3, v1, [Ljava/lang/Object;

    .line 40
    .line 41
    invoke-interface {p1, v0, v2, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    return v1

    .line 45
    :cond_2c
    sget-object v2, Lio/sentry/android/core/internal/gestures/d;->Click:Lio/sentry/android/core/internal/gestures/d;

    .line 46
    .line 47
    sget-object v3, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 48
    .line 49
    invoke-virtual {p0, v0, v2, v3, p1}, Lio/sentry/android/core/internal/gestures/e;->a(Lio/sentry/internal/gestures/b;Lio/sentry/android/core/internal/gestures/d;Ljava/util/Map;Landroid/view/MotionEvent;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0, v0, v2}, Lio/sentry/android/core/internal/gestures/e;->c(Lio/sentry/internal/gestures/b;Lio/sentry/android/core/internal/gestures/d;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    :goto_36
    return v1
.end method
