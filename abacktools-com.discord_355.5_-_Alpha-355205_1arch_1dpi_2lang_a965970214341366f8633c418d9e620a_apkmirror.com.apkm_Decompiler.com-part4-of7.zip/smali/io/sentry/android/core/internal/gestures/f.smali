###### Class io.sentry.android.core.internal.gestures.f (io.sentry.android.core.internal.gestures.f)
.class public final Lio/sentry/android/core/internal/gestures/f;
.super Lio/sentry/android/core/internal/gestures/h;
.source "SourceFile"


# instance fields
.field public final e:Landroid/view/Window$Callback;

.field public final i:Lio/sentry/android/core/internal/gestures/e;

.field public final v:Landroidx/core/view/GestureDetectorCompat;

.field public final w:Lio/sentry/a6;

.field public final x:Lcl/a;


# direct methods
.method public constructor <init>(Landroid/view/Window$Callback;Landroid/app/Activity;Lio/sentry/android/core/internal/gestures/e;Lio/sentry/a6;)V
    .registers 8

    .line 1
    new-instance v0, Landroidx/core/view/GestureDetectorCompat;

    .line 2
    .line 3
    new-instance v1, Landroid/os/Handler;

    .line 4
    .line 5
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 10
    .line 11
    .line 12
    invoke-direct {v0, p2, p3, v1}, Landroidx/core/view/GestureDetectorCompat;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;Landroid/os/Handler;)V

    .line 13
    .line 14
    .line 15
    new-instance p2, Lcl/a;

    .line 16
    .line 17
    const/16 v1, 0xa

    .line 18
    .line 19
    invoke-direct {p2, v1}, Lcl/a;-><init>(I)V

    .line 20
    .line 21
    .line 22
    invoke-direct {p0, p1}, Lio/sentry/android/core/internal/gestures/h;-><init>(Landroid/view/Window$Callback;)V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Lio/sentry/android/core/internal/gestures/f;->e:Landroid/view/Window$Callback;

    .line 26
    .line 27
    iput-object p3, p0, Lio/sentry/android/core/internal/gestures/f;->i:Lio/sentry/android/core/internal/gestures/e;

    .line 28
    .line 29
    iput-object p4, p0, Lio/sentry/android/core/internal/gestures/f;->w:Lio/sentry/a6;

    .line 30
    .line 31
    iput-object v0, p0, Lio/sentry/android/core/internal/gestures/f;->v:Landroidx/core/view/GestureDetectorCompat;

    .line 32
    .line 33
    iput-object p2, p0, Lio/sentry/android/core/internal/gestures/f;->x:Lcl/a;

    .line 34
    .line 35
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/MotionEvent;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/f;->v:Landroidx/core/view/GestureDetectorCompat;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/core/view/GestureDetectorCompat;->a:Landroid/view/GestureDetector;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v1, 0x1

    .line 13
    if-ne v0, v1, :cond_85

    .line 14
    .line 15
    const-string v0, "onUp"

    .line 16
    .line 17
    iget-object v1, p0, Lio/sentry/android/core/internal/gestures/f;->i:Lio/sentry/android/core/internal/gestures/e;

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Lio/sentry/android/core/internal/gestures/e;->b(Ljava/lang/String;)Landroid/view/View;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-object v2, v1, Lio/sentry/android/core/internal/gestures/e;->y:Lc30/d;

    .line 24
    .line 25
    iget-object v3, v2, Lc30/d;->d:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v3, Lio/sentry/internal/gestures/b;

    .line 28
    .line 29
    if-eqz v0, :cond_85

    .line 30
    .line 31
    if-nez v3, :cond_21

    .line 32
    .line 33
    goto :goto_85

    .line 34
    :cond_21
    iget-object v0, v2, Lc30/d;->c:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v0, Lio/sentry/android/core/internal/gestures/d;

    .line 37
    .line 38
    sget-object v4, Lio/sentry/android/core/internal/gestures/d;->Unknown:Lio/sentry/android/core/internal/gestures/d;

    .line 39
    .line 40
    if-ne v0, v4, :cond_3a

    .line 41
    .line 42
    iget-object p1, v1, Lio/sentry/android/core/internal/gestures/e;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 43
    .line 44
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 49
    .line 50
    const/4 v1, 0x0

    .line 51
    new-array v1, v1, [Ljava/lang/Object;

    .line 52
    .line 53
    const-string v2, "Unable to define scroll type. No breadcrumb captured."

    .line 54
    .line 55
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    iget v5, v2, Lc30/d;->a:F

    .line 64
    .line 65
    sub-float/2addr v0, v5

    .line 66
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 67
    .line 68
    .line 69
    move-result v5

    .line 70
    iget v6, v2, Lc30/d;->b:F

    .line 71
    .line 72
    sub-float/2addr v5, v6

    .line 73
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 74
    .line 75
    .line 76
    move-result v6

    .line 77
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 78
    .line 79
    .line 80
    move-result v7

    .line 81
    cmpl-float v6, v6, v7

    .line 82
    .line 83
    const/4 v7, 0x0

    .line 84
    if-lez v6, :cond_5f

    .line 85
    .line 86
    cmpl-float v0, v0, v7

    .line 87
    .line 88
    if-lez v0, :cond_5c

    .line 89
    .line 90
    const-string v0, "right"

    .line 91
    .line 92
    goto :goto_68

    .line 93
    :cond_5c
    const-string v0, "left"

    .line 94
    .line 95
    goto :goto_68

    .line 96
    :cond_5f
    cmpl-float v0, v5, v7

    .line 97
    .line 98
    if-lez v0, :cond_66

    .line 99
    .line 100
    const-string v0, "down"

    .line 101
    .line 102
    goto :goto_68

    .line 103
    :cond_66
    const-string v0, "up"

    .line 104
    .line 105
    :goto_68
    iget-object v5, v2, Lc30/d;->c:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v5, Lio/sentry/android/core/internal/gestures/d;

    .line 108
    .line 109
    const-string v6, "direction"

    .line 110
    .line 111
    invoke-static {v6, v0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-virtual {v1, v3, v5, v0, p1}, Lio/sentry/android/core/internal/gestures/e;->a(Lio/sentry/internal/gestures/b;Lio/sentry/android/core/internal/gestures/d;Ljava/util/Map;Landroid/view/MotionEvent;)V

    .line 116
    .line 117
    .line 118
    iget-object p1, v2, Lc30/d;->c:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast p1, Lio/sentry/android/core/internal/gestures/d;

    .line 121
    .line 122
    invoke-virtual {v1, v3, p1}, Lio/sentry/android/core/internal/gestures/e;->c(Lio/sentry/internal/gestures/b;Lio/sentry/android/core/internal/gestures/d;)V

    .line 123
    .line 124
    .line 125
    const/4 p1, 0x0

    .line 126
    iput-object p1, v2, Lc30/d;->d:Ljava/lang/Object;

    .line 127
    .line 128
    iput-object v4, v2, Lc30/d;->c:Ljava/lang/Object;

    .line 129
    .line 130
    iput v7, v2, Lc30/d;->a:F

    .line 131
    .line 132
    iput v7, v2, Lc30/d;->b:F

    .line 133
    .line 134
    :cond_85
    :goto_85
    return-void
.end method

.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 7

    .line 1
    if-eqz p1, :cond_28

    .line 2
    .line 3
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/f;->x:Lcl/a;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    :try_start_b
    invoke-virtual {p0, v0}, Lio/sentry/android/core/internal/gestures/f;->a(Landroid/view/MotionEvent;)V
    :try_end_e
    .catchall {:try_start_b .. :try_end_e} :catchall_12

    .line 13
    .line 14
    .line 15
    :cond_e
    :goto_e
    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    .line 16
    .line 17
    .line 18
    goto :goto_28

    .line 19
    :catchall_12
    move-exception v1

    .line 20
    iget-object v2, p0, Lio/sentry/android/core/internal/gestures/f;->w:Lio/sentry/a6;

    .line 21
    .line 22
    if-eqz v2, :cond_e

    .line 23
    .line 24
    :try_start_17
    invoke-virtual {v2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 29
    .line 30
    const-string v4, "Error dispatching touch event"

    .line 31
    .line 32
    invoke-interface {v2, v3, v4, v1}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_22
    .catchall {:try_start_17 .. :try_end_22} :catchall_23

    .line 33
    .line 34
    .line 35
    goto :goto_e

    .line 36
    :catchall_23
    move-exception p1

    .line 37
    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    .line 38
    .line 39
    .line 40
    throw p1

    .line 41
    :cond_28
    :goto_28
    iget-object v0, p0, Lio/sentry/android/core/internal/gestures/h;->d:Landroid/view/Window$Callback;

    .line 42
    .line 43
    invoke-interface {v0, p1}, Landroid/view/Window$Callback;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    return p1
.end method
