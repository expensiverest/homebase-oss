###### Class io.sentry.android.core.internal.gestures.a (io.sentry.android.core.internal.gestures.a)
.class public final Lio/sentry/android/core/internal/gestures/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lio/sentry/util/e;


# direct methods
.method public constructor <init>(Lio/sentry/util/e;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio/sentry/android/core/internal/gestures/a;->a:Lio/sentry/util/e;

    .line 5
    .line 6
    return-void
.end method
