###### Class io.sentry.android.core.internal.gestures.g (io.sentry.android.core.internal.gestures.g)
.class public abstract Lio/sentry/android/core/internal/gestures/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v0, v0, [I

    .line 3
    .line 4
    sput-object v0, Lio/sentry/android/core/internal/gestures/g;->a:[I

    .line 5
    .line 6
    return-void
.end method

.method public static a(Lio/sentry/android/core/SentryAndroidOptions;Landroid/view/View;FFLio/sentry/internal/gestures/a;)Lio/sentry/internal/gestures/b;
    .registers 15

    .line 1
    invoke-virtual {p0}, Lio/sentry/a6;->getGestureTargetLocators()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    new-instance v0, Ljava/util/LinkedList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    const/4 p1, 0x0

    .line 14
    move-object v1, p1

    .line 15
    :cond_e
    :goto_e
    invoke-virtual {v0}, Ljava/util/LinkedList;->size()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-lez v2, :cond_ef

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Landroid/view/View;

    .line 26
    .line 27
    if-nez v2, :cond_1d

    .line 28
    .line 29
    goto :goto_e

    .line 30
    :cond_1d
    sget-object v3, Lio/sentry/android/core/internal/gestures/g;->a:[I

    .line 31
    .line 32
    invoke-virtual {v2, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 33
    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    aget v5, v3, v4

    .line 37
    .line 38
    const/4 v6, 0x1

    .line 39
    aget v3, v3, v6

    .line 40
    .line 41
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 46
    .line 47
    .line 48
    move-result v8

    .line 49
    int-to-float v9, v5

    .line 50
    cmpg-float v9, p2, v9

    .line 51
    .line 52
    if-ltz v9, :cond_e

    .line 53
    .line 54
    add-int/2addr v5, v7

    .line 55
    int-to-float v5, v5

    .line 56
    cmpl-float v5, p2, v5

    .line 57
    .line 58
    if-gtz v5, :cond_e

    .line 59
    .line 60
    int-to-float v5, v3

    .line 61
    cmpg-float v5, p3, v5

    .line 62
    .line 63
    if-ltz v5, :cond_e

    .line 64
    .line 65
    add-int/2addr v3, v8

    .line 66
    int-to-float v3, v3

    .line 67
    cmpl-float v3, p3, v3

    .line 68
    .line 69
    if-gtz v3, :cond_e

    .line 70
    .line 71
    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 72
    .line 73
    if-eqz v3, :cond_5e

    .line 74
    .line 75
    move-object v3, v2

    .line 76
    check-cast v3, Landroid/view/ViewGroup;

    .line 77
    .line 78
    move v5, v4

    .line 79
    :goto_4e
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    .line 80
    .line 81
    .line 82
    move-result v7

    .line 83
    if-ge v5, v7, :cond_5e

    .line 84
    .line 85
    invoke-virtual {v3, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    invoke-virtual {v0, v7}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    add-int/lit8 v5, v5, 0x1

    .line 93
    .line 94
    goto :goto_4e

    .line 95
    :cond_5e
    move v3, v4

    .line 96
    :goto_5f
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    if-ge v3, v5, :cond_e

    .line 101
    .line 102
    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    check-cast v5, Lio/sentry/android/core/internal/gestures/a;

    .line 107
    .line 108
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    sget-object v7, Lio/sentry/internal/gestures/a;->CLICKABLE:Lio/sentry/internal/gestures/a;

    .line 112
    .line 113
    if-ne p4, v7, :cond_8c

    .line 114
    .line 115
    invoke-virtual {v2}, Landroid/view/View;->isClickable()Z

    .line 116
    .line 117
    .line 118
    move-result v7

    .line 119
    if-eqz v7, :cond_8c

    .line 120
    .line 121
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 122
    .line 123
    .line 124
    move-result v7

    .line 125
    if-nez v7, :cond_8c

    .line 126
    .line 127
    :try_start_7e
    invoke-static {v2}, Lio/sentry/android/core/internal/gestures/g;->b(Landroid/view/View;)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v5

    .line 131
    invoke-static {v2}, Landroid/support/v4/media/session/b;->x(Landroid/view/KeyEvent$Callback;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v7

    .line 135
    new-instance v8, Lio/sentry/internal/gestures/b;

    .line 136
    .line 137
    invoke-direct {v8, v2, v7, v5}, Lio/sentry/internal/gestures/b;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_8b
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_7e .. :try_end_8b} :catch_dd

    .line 138
    .line 139
    .line 140
    goto :goto_de

    .line 141
    :cond_8c
    sget-object v7, Lio/sentry/internal/gestures/a;->SCROLLABLE:Lio/sentry/internal/gestures/a;

    .line 142
    .line 143
    if-ne p4, v7, :cond_dd

    .line 144
    .line 145
    iget-object v5, v5, Lio/sentry/android/core/internal/gestures/a;->a:Lio/sentry/util/e;

    .line 146
    .line 147
    invoke-virtual {v5}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v5

    .line 151
    check-cast v5, Ljava/lang/Boolean;

    .line 152
    .line 153
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 154
    .line 155
    .line 156
    move-result v5

    .line 157
    if-nez v5, :cond_a0

    .line 158
    .line 159
    move v5, v4

    .line 160
    goto :goto_aa

    .line 161
    :cond_a0
    const-class v5, Landroidx/core/view/ScrollingView;

    .line 162
    .line 163
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 164
    .line 165
    .line 166
    move-result-object v7

    .line 167
    invoke-virtual {v5, v7}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 168
    .line 169
    .line 170
    move-result v5

    .line 171
    :goto_aa
    if-nez v5, :cond_c4

    .line 172
    .line 173
    const-class v5, Landroid/widget/AbsListView;

    .line 174
    .line 175
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 176
    .line 177
    .line 178
    move-result-object v7

    .line 179
    invoke-virtual {v5, v7}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 180
    .line 181
    .line 182
    move-result v5

    .line 183
    if-nez v5, :cond_c4

    .line 184
    .line 185
    const-class v5, Landroid/widget/ScrollView;

    .line 186
    .line 187
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 188
    .line 189
    .line 190
    move-result-object v7

    .line 191
    invoke-virtual {v5, v7}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 192
    .line 193
    .line 194
    move-result v5

    .line 195
    if-eqz v5, :cond_cc

    .line 196
    .line 197
    :cond_c4
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 198
    .line 199
    .line 200
    move-result v5

    .line 201
    if-nez v5, :cond_cc

    .line 202
    .line 203
    move v5, v6

    .line 204
    goto :goto_cd

    .line 205
    :cond_cc
    move v5, v4

    .line 206
    :goto_cd
    if-eqz v5, :cond_dd

    .line 207
    .line 208
    :try_start_cf
    invoke-static {v2}, Lio/sentry/android/core/internal/gestures/g;->b(Landroid/view/View;)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v5

    .line 212
    invoke-static {v2}, Landroid/support/v4/media/session/b;->x(Landroid/view/KeyEvent$Callback;)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v7

    .line 216
    new-instance v8, Lio/sentry/internal/gestures/b;

    .line 217
    .line 218
    invoke-direct {v8, v2, v7, v5}, Lio/sentry/internal/gestures/b;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_dc
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_cf .. :try_end_dc} :catch_dd

    .line 219
    .line 220
    .line 221
    goto :goto_de

    .line 222
    :catch_dd
    :cond_dd
    move-object v8, p1

    .line 223
    :goto_de
    if-eqz v8, :cond_eb

    .line 224
    .line 225
    sget-object v5, Lio/sentry/internal/gestures/a;->CLICKABLE:Lio/sentry/internal/gestures/a;

    .line 226
    .line 227
    if-ne p4, v5, :cond_e6

    .line 228
    .line 229
    move-object v1, v8

    .line 230
    goto :goto_eb

    .line 231
    :cond_e6
    sget-object v5, Lio/sentry/internal/gestures/a;->SCROLLABLE:Lio/sentry/internal/gestures/a;

    .line 232
    .line 233
    if-ne p4, v5, :cond_eb

    .line 234
    .line 235
    return-object v8

    .line 236
    :cond_eb
    :goto_eb
    add-int/lit8 v3, v3, 0x1

    .line 237
    .line 238
    goto/16 :goto_5f

    .line 239
    .line 240
    :cond_ef
    return-object v1
.end method

.method public static b(Landroid/view/View;)Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-eq v0, v1, :cond_24

    .line 7
    .line 8
    const/high16 v1, -0x1000000

    .line 9
    .line 10
    and-int/2addr v1, v0

    .line 11
    if-nez v1, :cond_12

    .line 12
    .line 13
    const v1, 0xffffff

    .line 14
    .line 15
    .line 16
    and-int/2addr v1, v0

    .line 17
    if-nez v1, :cond_24

    .line 18
    .line 19
    :cond_12
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    if-eqz p0, :cond_21

    .line 28
    .line 29
    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :cond_21
    const-string p0, ""

    .line 35
    .line 36
    return-object p0

    .line 37
    :cond_24
    new-instance p0, Landroid/content/res/Resources$NotFoundException;

    .line 38
    .line 39
    invoke-direct {p0}, Landroid/content/res/Resources$NotFoundException;-><init>()V

    .line 40
    .line 41
    .line 42
    throw p0
.end method
