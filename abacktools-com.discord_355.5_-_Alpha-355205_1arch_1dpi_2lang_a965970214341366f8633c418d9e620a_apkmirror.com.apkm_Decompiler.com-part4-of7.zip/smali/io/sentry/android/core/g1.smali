###### Class io.sentry.android.core.g1 (io.sentry.android.core.g1)
.class public interface abstract Lio/sentry/android/core/g1;
.super Ljava/lang/Object;
.source "SourceFile"
