###### Class io.sentry.android.core.a0 (io.sentry.android.core.a0)
.class public final synthetic Lio/sentry/android/core/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic i:J

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lio/sentry/android/core/AppComponentsBreadcrumbsIntegration;JI)V
    .registers 6

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lio/sentry/android/core/a0;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lio/sentry/android/core/a0;->v:Ljava/lang/Object;

    iput-wide p2, p0, Lio/sentry/android/core/a0;->i:J

    iput p4, p0, Lio/sentry/android/core/a0;->e:I

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;IJI)V
    .registers 6

    .line 2
    iput p5, p0, Lio/sentry/android/core/a0;->d:I

    iput-object p1, p0, Lio/sentry/android/core/a0;->v:Ljava/lang/Object;

    iput p2, p0, Lio/sentry/android/core/a0;->e:I

    iput-wide p3, p0, Lio/sentry/android/core/a0;->i:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    .line 1
    iget v0, p0, Lio/sentry/android/core/a0;->d:I

    .line 2
    .line 3
    const/16 v1, 0x3fa

    .line 4
    .line 5
    iget-object v2, p0, Lio/sentry/android/core/a0;->v:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_88

    .line 8
    .line 9
    .line 10
    check-cast v2, Lk7/c;

    .line 11
    .line 12
    iget-object v0, v2, Lk7/c;->i:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Lmr/w;

    .line 15
    .line 16
    sget v2, Lqt/x;->a:I

    .line 17
    .line 18
    iget-object v0, v0, Lmr/w;->d:Lmr/z;

    .line 19
    .line 20
    iget-object v0, v0, Lmr/z;->T:Lnr/g;

    .line 21
    .line 22
    iget-object v2, v0, Lnr/g;->v:Lb80/i0;

    .line 23
    .line 24
    iget-object v2, v2, Lb80/i0;->x:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v2, Lss/s;

    .line 27
    .line 28
    invoke-virtual {v0, v2}, Lnr/g;->O(Lss/s;)Lnr/a;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    new-instance v3, Lmr/p;

    .line 33
    .line 34
    const/4 v8, 0x1

    .line 35
    iget v5, p0, Lio/sentry/android/core/a0;->e:I

    .line 36
    .line 37
    iget-wide v6, p0, Lio/sentry/android/core/a0;->i:J

    .line 38
    .line 39
    invoke-direct/range {v3 .. v8}, Lmr/p;-><init>(Ljava/lang/Object;IJI)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0, v4, v1, v3}, Lnr/g;->R(Lnr/a;ILqt/g;)V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :pswitch_2d
    check-cast v2, Lk7/l;

    .line 47
    .line 48
    iget-object v0, v2, Lk7/l;->e:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v0, Lv3/q;

    .line 51
    .line 52
    sget-object v2, Ln3/l0;->a:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v0, v0, Lv3/q;->d:Lv3/w;

    .line 55
    .line 56
    iget-object v0, v0, Lv3/w;->V:Lw3/e;

    .line 57
    .line 58
    iget-object v2, v0, Lw3/e;->v:Lb80/i0;

    .line 59
    .line 60
    iget-object v2, v2, Lb80/i0;->x:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v2, Lf4/d0;

    .line 63
    .line 64
    invoke-virtual {v0, v2}, Lw3/e;->S(Lf4/d0;)Lw3/a;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    new-instance v3, Lmr/p;

    .line 69
    .line 70
    const/4 v8, 0x5

    .line 71
    iget v5, p0, Lio/sentry/android/core/a0;->e:I

    .line 72
    .line 73
    iget-wide v6, p0, Lio/sentry/android/core/a0;->i:J

    .line 74
    .line 75
    invoke-direct/range {v3 .. v8}, Lmr/p;-><init>(Ljava/lang/Object;IJI)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0, v4, v1, v3}, Lw3/e;->W(Lw3/a;ILn3/n;)V

    .line 79
    .line 80
    .line 81
    return-void

    .line 82
    :pswitch_51
    check-cast v2, Lio/sentry/android/core/AppComponentsBreadcrumbsIntegration;

    .line 83
    .line 84
    iget-object v0, v2, Lio/sentry/android/core/AppComponentsBreadcrumbsIntegration;->e:Lio/sentry/z3;

    .line 85
    .line 86
    if-eqz v0, :cond_87

    .line 87
    .line 88
    new-instance v0, Lio/sentry/e;

    .line 89
    .line 90
    iget-wide v3, p0, Lio/sentry/android/core/a0;->i:J

    .line 91
    .line 92
    invoke-direct {v0, v3, v4}, Lio/sentry/e;-><init>(J)V

    .line 93
    .line 94
    .line 95
    const-string v1, "system"

    .line 96
    .line 97
    iput-object v1, v0, Lio/sentry/e;->w:Ljava/lang/String;

    .line 98
    .line 99
    const-string v1, "device.event"

    .line 100
    .line 101
    iput-object v1, v0, Lio/sentry/e;->y:Ljava/lang/String;

    .line 102
    .line 103
    const-string v1, "Low memory"

    .line 104
    .line 105
    iput-object v1, v0, Lio/sentry/e;->v:Ljava/lang/String;

    .line 106
    .line 107
    const-string v1, "action"

    .line 108
    .line 109
    const-string v3, "LOW_MEMORY"

    .line 110
    .line 111
    invoke-virtual {v0, v3, v1}, Lio/sentry/e;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    const-string v1, "level"

    .line 115
    .line 116
    iget v3, p0, Lio/sentry/android/core/a0;->e:I

    .line 117
    .line 118
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    invoke-virtual {v0, v3, v1}, Lio/sentry/e;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sget-object v1, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 126
    .line 127
    iput-object v1, v0, Lio/sentry/e;->K:Lio/sentry/a5;

    .line 128
    .line 129
    iget-object v1, v2, Lio/sentry/android/core/AppComponentsBreadcrumbsIntegration;->e:Lio/sentry/z3;

    .line 130
    .line 131
    sget-object v2, Lio/sentry/android/core/AppComponentsBreadcrumbsIntegration;->w:Lio/sentry/h0;

    .line 132
    .line 133
    invoke-virtual {v1, v0, v2}, Lio/sentry/z3;->g(Lio/sentry/e;Lio/sentry/h0;)V

    .line 134
    .line 135
    .line 136
    :cond_87
    return-void

    .line 137
    :pswitch_data_88
    .packed-switch 0x0
        :pswitch_51
        :pswitch_2d
    .end packed-switch
.end method
