###### Class io.sentry.android.core.e (io.sentry.android.core.e)
.class public final synthetic Lio/sentry/android/core/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/s3;
.implements Lio/sentry/e4;


# instance fields
.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lio/sentry/android/core/e;->d:Ljava/lang/Object;

    iput-object p2, p0, Lio/sentry/android/core/e;->e:Ljava/lang/Object;

    iput-object p3, p0, Lio/sentry/android/core/e;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public e(Lio/sentry/j1;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/e;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/sentry/android/core/ActivityLifecycleIntegration;

    .line 4
    .line 5
    iget-object v1, p0, Lio/sentry/android/core/e;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lio/sentry/y0;

    .line 8
    .line 9
    iget-object v2, p0, Lio/sentry/android/core/e;->i:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lio/sentry/j1;

    .line 12
    .line 13
    if-nez p1, :cond_12

    .line 14
    .line 15
    invoke-interface {v1, v2}, Lio/sentry/y0;->O(Lio/sentry/j1;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    iget-object p1, v0, Lio/sentry/android/core/ActivityLifecycleIntegration;->v:Lio/sentry/android/core/SentryAndroidOptions;

    .line 20
    .line 21
    if-eqz p1, :cond_29

    .line 22
    .line 23
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 28
    .line 29
    invoke-interface {v2}, Lio/sentry/j1;->getName()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v2, "Transaction \'%s\' won\'t be bound to the Scope since there\'s one already in there."

    .line 38
    .line 39
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_29
    return-void
.end method

.method public f(Lio/sentry/a6;)V
    .registers 19

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v0, v1, Lio/sentry/android/core/e;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lio/sentry/android/core/l0;

    .line 6
    .line 7
    iget-object v2, v1, Lio/sentry/android/core/e;->e:Ljava/lang/Object;

    .line 8
    .line 9
    move-object v3, v2

    .line 10
    check-cast v3, Landroid/content/Context;

    .line 11
    .line 12
    iget-object v2, v1, Lio/sentry/android/core/e;->i:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Lio/sentry/e4;

    .line 15
    .line 16
    move-object/from16 v4, p1

    .line 17
    .line 18
    check-cast v4, Lio/sentry/android/core/SentryAndroidOptions;

    .line 19
    .line 20
    const-string v5, "timber.log.Timber"

    .line 21
    .line 22
    invoke-static {v4, v5}, Lio/sentry/util/f;->a(Lio/sentry/a6;Ljava/lang/String;)Z

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    const-string v6, "androidx.fragment.app.FragmentManager$FragmentLifecycleCallbacks"

    .line 27
    .line 28
    invoke-static {v4, v6}, Lio/sentry/util/f;->a(Lio/sentry/a6;Ljava/lang/String;)Z

    .line 29
    .line 30
    .line 31
    move-result v6

    .line 32
    const/4 v7, 0x0

    .line 33
    const/4 v8, 0x1

    .line 34
    if-eqz v6, :cond_2d

    .line 35
    .line 36
    const-string v6, "io.sentry.android.fragment.FragmentLifecycleIntegration"

    .line 37
    .line 38
    invoke-static {v4, v6}, Lio/sentry/util/f;->a(Lio/sentry/a6;Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    if-eqz v6, :cond_2d

    .line 43
    .line 44
    move v6, v8

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    move v6, v8

    .line 47
    move v8, v7

    .line 48
    :goto_2f
    if-eqz v5, :cond_3b

    .line 49
    .line 50
    const-string v5, "io.sentry.android.timber.SentryTimberIntegration"

    .line 51
    .line 52
    invoke-static {v4, v5}, Lio/sentry/util/f;->a(Lio/sentry/a6;Ljava/lang/String;)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_3b

    .line 57
    .line 58
    move v9, v6

    .line 59
    goto :goto_3c

    .line 60
    :cond_3b
    move v9, v7

    .line 61
    :goto_3c
    const-string v5, "io.sentry.android.replay.ReplayIntegration"

    .line 62
    .line 63
    invoke-static {v4, v5}, Lio/sentry/util/f;->a(Lio/sentry/a6;Ljava/lang/String;)Z

    .line 64
    .line 65
    .line 66
    move-result v10

    .line 67
    const-string v5, "io.sentry.android.distribution.DistributionIntegration"

    .line 68
    .line 69
    invoke-static {v4, v5}, Lio/sentry/util/f;->a(Lio/sentry/a6;Ljava/lang/String;)Z

    .line 70
    .line 71
    .line 72
    move-result v11

    .line 73
    new-instance v5, Lio/sentry/android/core/j0;

    .line 74
    .line 75
    invoke-direct {v5, v0}, Lio/sentry/android/core/j0;-><init>(Lio/sentry/ILogger;)V

    .line 76
    .line 77
    .line 78
    new-instance v6, Lio/sentry/util/f;

    .line 79
    .line 80
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 81
    .line 82
    .line 83
    new-instance v7, Lp/r3;

    .line 84
    .line 85
    invoke-direct {v7, v6, v4}, Lp/r3;-><init>(Lio/sentry/util/f;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 86
    .line 87
    .line 88
    const-string v12, "The context is required."

    .line 89
    .line 90
    invoke-static {v3, v12}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 94
    .line 95
    .line 96
    move-result-object v12

    .line 97
    if-eqz v12, :cond_63

    .line 98
    .line 99
    goto :goto_64

    .line 100
    :cond_63
    move-object v12, v3

    .line 101
    :goto_64
    invoke-virtual {v4, v0}, Lio/sentry/a6;->setLogger(Lio/sentry/ILogger;)V

    .line 102
    .line 103
    .line 104
    new-instance v13, Lio/sentry/android/core/t;

    .line 105
    .line 106
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4, v13}, Lio/sentry/a6;->setFatalLogger(Lio/sentry/ILogger;)V

    .line 110
    .line 111
    .line 112
    sget-object v13, Lio/sentry/x3;->CURRENT:Lio/sentry/x3;

    .line 113
    .line 114
    invoke-virtual {v4, v13}, Lio/sentry/a6;->setDefaultScopeType(Lio/sentry/x3;)V

    .line 115
    .line 116
    .line 117
    sget-object v13, Lio/sentry/j5;->OFF:Lio/sentry/j5;

    .line 118
    .line 119
    invoke-virtual {v4, v13}, Lio/sentry/a6;->setOpenTelemetryMode(Lio/sentry/j5;)V

    .line 120
    .line 121
    .line 122
    new-instance v13, Lio/sentry/android/core/f1;

    .line 123
    .line 124
    invoke-direct {v13}, Lio/sentry/android/core/f1;-><init>()V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v4, v13}, Lio/sentry/a6;->setDateProvider(Lio/sentry/m4;)V

    .line 128
    .line 129
    .line 130
    new-instance v13, Lio/sentry/android/core/internal/util/d;

    .line 131
    .line 132
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v4, v13}, Lio/sentry/a6;->setRuntimeManager(Lio/sentry/util/runtime/b;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v4}, Lio/sentry/a6;->getLogs()Lio/sentry/s5;

    .line 139
    .line 140
    .line 141
    move-result-object v13

    .line 142
    new-instance v14, Lio/sentry/android/core/t;

    .line 143
    .line 144
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 145
    .line 146
    .line 147
    iput-object v14, v13, Lio/sentry/s5;->b:Lio/sentry/logger/b;

    .line 148
    .line 149
    invoke-virtual {v4}, Lio/sentry/a6;->getMetrics()Lio/sentry/t5;

    .line 150
    .line 151
    .line 152
    move-result-object v13

    .line 153
    new-instance v14, Lio/sentry/android/core/t;

    .line 154
    .line 155
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 156
    .line 157
    .line 158
    iput-object v14, v13, Lio/sentry/t5;->b:Lio/sentry/metrics/b;

    .line 159
    .line 160
    const-wide/16 v13, 0xfa0

    .line 161
    .line 162
    invoke-virtual {v4, v13, v14}, Lio/sentry/a6;->setFlushTimeoutMillis(J)V

    .line 163
    .line 164
    .line 165
    new-instance v13, Lio/sentry/android/core/internal/util/n;

    .line 166
    .line 167
    invoke-direct {v13, v12, v0, v5}, Lio/sentry/android/core/internal/util/n;-><init>(Landroid/content/Context;Lio/sentry/ILogger;Lio/sentry/android/core/j0;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v4, v13}, Lio/sentry/android/core/SentryAndroidOptions;->setFrameMetricsCollector(Lio/sentry/android/core/internal/util/n;)V

    .line 171
    .line 172
    .line 173
    invoke-static {v12, v5, v4}, Lio/sentry/android/core/v0;->b(Landroid/content/Context;Lio/sentry/android/core/j0;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v4}, Lio/sentry/a6;->getRuntimeManager()Lio/sentry/util/runtime/b;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    new-instance v13, Lc7/n;

    .line 181
    .line 182
    const/4 v14, 0x1

    .line 183
    invoke-direct {v13, v12, v14}, Lc7/n;-><init>(Landroid/content/Context;I)V

    .line 184
    .line 185
    .line 186
    invoke-interface {v0, v13}, Lio/sentry/util/runtime/b;->i(Lio/sentry/util/runtime/a;)Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    check-cast v0, Ljava/lang/String;

    .line 191
    .line 192
    invoke-virtual {v4, v0}, Lio/sentry/a6;->setCacheDirPath(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    invoke-static {v12, v5}, Lio/sentry/android/core/k0;->g(Landroid/content/Context;Lio/sentry/android/core/j0;)Landroid/content/pm/PackageInfo;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    if-eqz v0, :cond_104

    .line 200
    .line 201
    invoke-virtual {v4}, Lio/sentry/a6;->getRelease()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v13

    .line 205
    if-nez v13, :cond_f5

    .line 206
    .line 207
    invoke-static {v0, v5}, Lio/sentry/android/core/k0;->h(Landroid/content/pm/PackageInfo;Lio/sentry/android/core/j0;)Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v13

    .line 211
    new-instance v14, Ljava/lang/StringBuilder;

    .line 212
    .line 213
    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    .line 214
    .line 215
    .line 216
    iget-object v15, v0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    .line 217
    .line 218
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    .line 220
    .line 221
    const-string v15, "@"

    .line 222
    .line 223
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 224
    .line 225
    .line 226
    iget-object v15, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    .line 227
    .line 228
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 229
    .line 230
    .line 231
    const-string v15, "+"

    .line 232
    .line 233
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 237
    .line 238
    .line 239
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v13

    .line 243
    invoke-virtual {v4, v13}, Lio/sentry/a6;->setRelease(Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    :cond_f5
    iget-object v0, v0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    .line 247
    .line 248
    if-eqz v0, :cond_104

    .line 249
    .line 250
    const-string v13, "android."

    .line 251
    .line 252
    invoke-virtual {v0, v13}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 253
    .line 254
    .line 255
    move-result v13

    .line 256
    if-nez v13, :cond_104

    .line 257
    .line 258
    invoke-virtual {v4, v0}, Lio/sentry/a6;->addInAppInclude(Ljava/lang/String;)V

    .line 259
    .line 260
    .line 261
    :cond_104
    invoke-virtual {v4}, Lio/sentry/a6;->getDistinctId()Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    if-nez v0, :cond_12a

    .line 266
    .line 267
    :try_start_10a
    invoke-virtual {v4}, Lio/sentry/a6;->getRuntimeManager()Lio/sentry/util/runtime/b;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    new-instance v13, Lc7/n;

    .line 272
    .line 273
    const/4 v14, 0x2

    .line 274
    invoke-direct {v13, v12, v14}, Lc7/n;-><init>(Landroid/content/Context;I)V

    .line 275
    .line 276
    .line 277
    invoke-interface {v0, v13}, Lio/sentry/util/runtime/b;->i(Lio/sentry/util/runtime/a;)Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    check-cast v0, Ljava/lang/String;

    .line 282
    .line 283
    invoke-virtual {v4, v0}, Lio/sentry/a6;->setDistinctId(Ljava/lang/String;)V
    :try_end_11d
    .catch Ljava/lang/RuntimeException; {:try_start_10a .. :try_end_11d} :catch_11e

    .line 284
    .line 285
    .line 286
    goto :goto_12a

    .line 287
    :catch_11e
    move-exception v0

    .line 288
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 289
    .line 290
    .line 291
    move-result-object v12

    .line 292
    sget-object v13, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 293
    .line 294
    const-string v14, "Could not generate distinct Id."

    .line 295
    .line 296
    invoke-interface {v12, v13, v14, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 297
    .line 298
    .line 299
    :cond_12a
    :goto_12a
    sget-object v0, Lio/sentry/android/core/e0;->w:Lio/sentry/android/core/e0;

    .line 300
    .line 301
    iget-object v12, v0, Lio/sentry/android/core/e0;->e:Lio/sentry/android/core/d0;

    .line 302
    .line 303
    if-eqz v12, :cond_131

    .line 304
    .line 305
    goto :goto_141

    .line 306
    :cond_131
    iget-object v12, v0, Lio/sentry/android/core/e0;->d:Lio/sentry/util/a;

    .line 307
    .line 308
    invoke-virtual {v12}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 309
    .line 310
    .line 311
    move-result-object v12

    .line 312
    :try_start_137
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 313
    .line 314
    .line 315
    move-result-object v13

    .line 316
    invoke-virtual {v0, v13}, Lio/sentry/android/core/e0;->g(Lio/sentry/ILogger;)V
    :try_end_13e
    .catchall {:try_start_137 .. :try_end_13e} :catchall_1a0

    .line 317
    .line 318
    .line 319
    invoke-virtual {v12}, Lio/sentry/s;->close()V

    .line 320
    .line 321
    .line 322
    :goto_141
    invoke-static/range {v3 .. v11}, Lio/sentry/android/core/o;->b(Landroid/content/Context;Lio/sentry/android/core/SentryAndroidOptions;Lio/sentry/android/core/j0;Lio/sentry/util/f;Lp/r3;ZZZZ)V

    .line 323
    .line 324
    .line 325
    move/from16 v16, v9

    .line 326
    .line 327
    move v9, v8

    .line 328
    move v8, v10

    .line 329
    move/from16 v10, v16

    .line 330
    .line 331
    :try_start_14a
    invoke-interface {v2, v4}, Lio/sentry/e4;->f(Lio/sentry/a6;)V
    :try_end_14d
    .catchall {:try_start_14a .. :try_end_14d} :catchall_14e

    .line 332
    .line 333
    .line 334
    goto :goto_15a

    .line 335
    :catchall_14e
    move-exception v0

    .line 336
    invoke-virtual {v4}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 337
    .line 338
    .line 339
    move-result-object v2

    .line 340
    sget-object v11, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 341
    .line 342
    const-string v12, "Error in the \'OptionsConfiguration.configure\' callback."

    .line 343
    .line 344
    invoke-interface {v2, v11, v12, v0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 345
    .line 346
    .line 347
    :goto_15a
    invoke-static {}, Lio/sentry/android/core/performance/g;->c()Lio/sentry/android/core/performance/g;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    invoke-virtual {v4}, Lio/sentry/android/core/SentryAndroidOptions;->isEnablePerformanceV2()Z

    .line 352
    .line 353
    .line 354
    move-result v2

    .line 355
    const-wide/16 v11, 0x0

    .line 356
    .line 357
    if-eqz v2, :cond_175

    .line 358
    .line 359
    iget-object v2, v0, Lio/sentry/android/core/performance/g;->v:Lio/sentry/android/core/performance/h;

    .line 360
    .line 361
    iget-wide v13, v2, Lio/sentry/android/core/performance/h;->i:J

    .line 362
    .line 363
    cmp-long v13, v13, v11

    .line 364
    .line 365
    if-nez v13, :cond_175

    .line 366
    .line 367
    invoke-static {}, Landroid/os/Process;->getStartUptimeMillis()J

    .line 368
    .line 369
    .line 370
    move-result-wide v13

    .line 371
    invoke-virtual {v2, v13, v14}, Lio/sentry/android/core/performance/h;->d(J)V

    .line 372
    .line 373
    .line 374
    :cond_175
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 375
    .line 376
    .line 377
    move-result-object v2

    .line 378
    instance-of v2, v2, Landroid/app/Application;

    .line 379
    .line 380
    if-eqz v2, :cond_186

    .line 381
    .line 382
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 383
    .line 384
    .line 385
    move-result-object v2

    .line 386
    check-cast v2, Landroid/app/Application;

    .line 387
    .line 388
    invoke-virtual {v0, v2}, Lio/sentry/android/core/performance/g;->e(Landroid/app/Application;)V

    .line 389
    .line 390
    .line 391
    :cond_186
    iget-object v0, v0, Lio/sentry/android/core/performance/g;->w:Lio/sentry/android/core/performance/h;

    .line 392
    .line 393
    iget-wide v13, v0, Lio/sentry/android/core/performance/h;->i:J

    .line 394
    .line 395
    cmp-long v2, v13, v11

    .line 396
    .line 397
    if-nez v2, :cond_193

    .line 398
    .line 399
    sget-wide v11, Lio/sentry/android/core/e1;->a:J

    .line 400
    .line 401
    invoke-virtual {v0, v11, v12}, Lio/sentry/android/core/performance/h;->d(J)V

    .line 402
    .line 403
    .line 404
    :cond_193
    move-object/from16 v16, v4

    .line 405
    .line 406
    move-object v4, v3

    .line 407
    move-object/from16 v3, v16

    .line 408
    .line 409
    invoke-static/range {v3 .. v8}, Lio/sentry/android/core/o;->a(Lio/sentry/android/core/SentryAndroidOptions;Landroid/content/Context;Lio/sentry/android/core/j0;Lio/sentry/util/f;Lp/r3;Z)V

    .line 410
    .line 411
    .line 412
    move-object v4, v3

    .line 413
    invoke-static {v4, v9, v10}, Lio/sentry/android/core/e1;->a(Lio/sentry/a6;ZZ)V

    .line 414
    .line 415
    .line 416
    return-void

    .line 417
    :catchall_1a0
    move-exception v0

    .line 418
    move-object v2, v0

    .line 419
    :try_start_1a2
    invoke-virtual {v12}, Lio/sentry/s;->close()V
    :try_end_1a5
    .catchall {:try_start_1a2 .. :try_end_1a5} :catchall_1a6

    .line 420
    .line 421
    .line 422
    goto :goto_1aa

    .line 423
    :catchall_1a6
    move-exception v0

    .line 424
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 425
    .line 426
    .line 427
    :goto_1aa
    throw v2
.end method
