###### Class io.sentry.android.core.i (io.sentry.android.core.i)
.class public abstract Lio/sentry/android/core/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lio/sentry/android/core/f1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lio/sentry/android/core/f1;

    .line 2
    .line 3
    invoke-direct {v0}, Lio/sentry/android/core/f1;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lio/sentry/android/core/i;->a:Lio/sentry/android/core/f1;

    .line 7
    .line 8
    return-void
.end method
