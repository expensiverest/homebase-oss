###### Class io.sentry.android.core.ViewHierarchyEventProcessor (io.sentry.android.core.ViewHierarchyEventProcessor)
.class public final Lio/sentry/android/core/ViewHierarchyEventProcessor;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/c0;


# instance fields
.field public final d:Lio/sentry/android/core/SentryAndroidOptions;

.field public final e:Lio/sentry/android/core/internal/util/g;


# direct methods
.method public constructor <init>(Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "SentryAndroidOptions is required"

    .line 5
    .line 6
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lio/sentry/android/core/ViewHierarchyEventProcessor;->d:Lio/sentry/android/core/SentryAndroidOptions;

    .line 10
    .line 11
    new-instance v0, Lio/sentry/android/core/internal/util/g;

    .line 12
    .line 13
    const-wide/16 v1, 0x7d0

    .line 14
    .line 15
    const/4 v3, 0x3

    .line 16
    invoke-direct {v0, v1, v2, v3}, Lio/sentry/android/core/internal/util/g;-><init>(JI)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Lio/sentry/android/core/ViewHierarchyEventProcessor;->e:Lio/sentry/android/core/internal/util/g;

    .line 20
    .line 21
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isAttachViewHierarchy()Z

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    if-eqz p1, :cond_1f

    .line 26
    .line 27
    const-string p1, "ViewHierarchy"

    .line 28
    .line 29
    invoke-static {p1}, Loq/a;->d(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    :cond_1f
    return-void
.end method

.method public static a(Landroid/view/View;Lio/sentry/protocol/k0;Ljava/util/List;)V
    .registers 8

    .line 1
    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_17

    .line 6
    :cond_5
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-nez v1, :cond_36

    .line 15
    .line 16
    check-cast p0, Landroid/view/ViewGroup;

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_18

    .line 23
    .line 24
    :goto_17
    return-void

    .line 25
    :cond_18
    new-instance v1, Ljava/util/ArrayList;

    .line 26
    .line 27
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 28
    .line 29
    .line 30
    const/4 v2, 0x0

    .line 31
    :goto_1e
    if-ge v2, v0, :cond_33

    .line 32
    .line 33
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    if-eqz v3, :cond_30

    .line 38
    .line 39
    invoke-static {v3}, Lio/sentry/android/core/ViewHierarchyEventProcessor;->e(Landroid/view/View;)Lio/sentry/protocol/k0;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    invoke-static {v3, v4, p2}, Lio/sentry/android/core/ViewHierarchyEventProcessor;->a(Landroid/view/View;Lio/sentry/protocol/k0;Ljava/util/List;)V

    .line 47
    .line 48
    .line 49
    :cond_30
    add-int/lit8 v2, v2, 0x1

    .line 50
    .line 51
    goto :goto_1e

    .line 52
    :cond_33
    iput-object v1, p1, Lio/sentry/protocol/k0;->M:Ljava/util/List;

    .line 53
    .line 54
    return-void

    .line 55
    :cond_36
    invoke-static {v0}, Lcom/google/android/gms/internal/fido/nb;->j(Ljava/util/Iterator;)Ljava/lang/ClassCastException;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    throw p0
.end method

.method public static b(Landroid/app/Activity;Ljava/util/List;Lio/sentry/util/thread/a;Lio/sentry/ILogger;)Lio/sentry/protocol/j0;
    .registers 13

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    if-nez p0, :cond_e

    .line 4
    .line 5
    sget-object p0, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 6
    .line 7
    const-string p1, "Missing activity for view hierarchy snapshot."

    .line 8
    .line 9
    new-array p2, v0, [Ljava/lang/Object;

    .line 10
    .line 11
    invoke-interface {p3, p0, p1, p2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    return-object v1

    .line 15
    :cond_e
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    if-nez v2, :cond_1e

    .line 20
    .line 21
    sget-object p0, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 22
    .line 23
    const-string p1, "Missing window for view hierarchy snapshot."

    .line 24
    .line 25
    new-array p2, v0, [Ljava/lang/Object;

    .line 26
    .line 27
    invoke-interface {p3, p0, p1, p2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object v1

    .line 31
    :cond_1e
    invoke-virtual {v2}, Landroid/view/Window;->peekDecorView()Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    if-nez v4, :cond_2e

    .line 36
    .line 37
    sget-object p0, Lio/sentry/a5;->INFO:Lio/sentry/a5;

    .line 38
    .line 39
    const-string p1, "Missing decor view for view hierarchy snapshot."

    .line 40
    .line 41
    new-array p2, v0, [Ljava/lang/Object;

    .line 42
    .line 43
    invoke-interface {p3, p0, p1, p2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    return-object v1

    .line 47
    :cond_2e
    :try_start_2e
    invoke-interface {p2}, Lio/sentry/util/thread/a;->c()Z

    .line 48
    .line 49
    .line 50
    move-result p2
    :try_end_32
    .catchall {:try_start_2e .. :try_end_32} :catchall_7a

    .line 51
    const/4 v0, 0x1

    .line 52
    if-eqz p2, :cond_50

    .line 53
    .line 54
    :try_start_35
    new-instance p0, Ljava/util/ArrayList;

    .line 55
    .line 56
    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 57
    .line 58
    .line 59
    new-instance p2, Lio/sentry/protocol/j0;

    .line 60
    .line 61
    const-string v0, "android_view_system"

    .line 62
    .line 63
    invoke-direct {p2, v0, p0}, Lio/sentry/protocol/j0;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v4}, Lio/sentry/android/core/ViewHierarchyEventProcessor;->e(Landroid/view/View;)Lio/sentry/protocol/k0;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    invoke-static {v4, v0, p1}, Lio/sentry/android/core/ViewHierarchyEventProcessor;->a(Landroid/view/View;Lio/sentry/protocol/k0;Ljava/util/List;)V
    :try_end_4b
    .catchall {:try_start_35 .. :try_end_4b} :catchall_4c

    .line 74
    .line 75
    .line 76
    return-object p2

    .line 77
    :catchall_4c
    move-exception v0

    .line 78
    move-object p0, v0

    .line 79
    move-object v7, p3

    .line 80
    goto :goto_7d

    .line 81
    :cond_50
    :try_start_50
    new-instance v6, Ljava/util/concurrent/CountDownLatch;

    .line 82
    .line 83
    invoke-direct {v6, v0}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    .line 84
    .line 85
    .line 86
    new-instance v3, Ljava/util/concurrent/atomic/AtomicReference;

    .line 87
    .line 88
    invoke-direct {v3, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    new-instance v2, Lio/sentry/android/core/m1;
    :try_end_5c
    .catchall {:try_start_50 .. :try_end_5c} :catchall_7a

    .line 92
    .line 93
    const/4 v8, 0x0

    .line 94
    move-object v5, p1

    .line 95
    move-object v7, p3

    .line 96
    :try_start_5f
    invoke-direct/range {v2 .. v8}, Lio/sentry/android/core/m1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 100
    .line 101
    .line 102
    sget-object p0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 103
    .line 104
    const-wide/16 p1, 0x3e8

    .line 105
    .line 106
    invoke-virtual {v6, p1, p2, p0}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    .line 107
    .line 108
    .line 109
    move-result p0

    .line 110
    if-eqz p0, :cond_79

    .line 111
    .line 112
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    check-cast p0, Lio/sentry/protocol/j0;
    :try_end_75
    .catchall {:try_start_5f .. :try_end_75} :catchall_76

    .line 117
    .line 118
    return-object p0

    .line 119
    :catchall_76
    move-exception v0

    .line 120
    :goto_77
    move-object p0, v0

    .line 121
    goto :goto_7d

    .line 122
    :cond_79
    return-object v1

    .line 123
    :catchall_7a
    move-exception v0

    .line 124
    move-object v7, p3

    .line 125
    goto :goto_77

    .line 126
    :goto_7d
    sget-object p1, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 127
    .line 128
    const-string p2, "Failed to process view hierarchy."

    .line 129
    .line 130
    invoke-interface {v7, p1, p2, p0}, Lio/sentry/ILogger;->k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 131
    .line 132
    .line 133
    return-object v1
.end method

.method public static e(Landroid/view/View;)Lio/sentry/protocol/k0;
    .registers 4

    .line 1
    new-instance v0, Lio/sentry/protocol/k0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, Landroid/support/v4/media/session/b;->x(Landroid/view/KeyEvent$Callback;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iput-object v1, v0, Lio/sentry/protocol/k0;->e:Ljava/lang/String;

    .line 11
    .line 12
    :try_start_b
    invoke-static {p0}, Lio/sentry/android/core/internal/gestures/g;->b(Landroid/view/View;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    iput-object v1, v0, Lio/sentry/protocol/k0;->i:Ljava/lang/String;
    :try_end_11
    .catchall {:try_start_b .. :try_end_11} :catchall_11

    .line 17
    .line 18
    :catchall_11
    invoke-virtual {p0}, Landroid/view/View;->getX()F

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    float-to-double v1, v1

    .line 23
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    iput-object v1, v0, Lio/sentry/protocol/k0;->y:Ljava/lang/Double;

    .line 28
    .line 29
    invoke-virtual {p0}, Landroid/view/View;->getY()F

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    float-to-double v1, v1

    .line 34
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iput-object v1, v0, Lio/sentry/protocol/k0;->J:Ljava/lang/Double;

    .line 39
    .line 40
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    int-to-double v1, v1

    .line 45
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    iput-object v1, v0, Lio/sentry/protocol/k0;->w:Ljava/lang/Double;

    .line 50
    .line 51
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    int-to-double v1, v1

    .line 56
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    iput-object v1, v0, Lio/sentry/protocol/k0;->x:Ljava/lang/Double;

    .line 61
    .line 62
    invoke-virtual {p0}, Landroid/view/View;->getAlpha()F

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    float-to-double v1, v1

    .line 67
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    iput-object v1, v0, Lio/sentry/protocol/k0;->L:Ljava/lang/Double;

    .line 72
    .line 73
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 74
    .line 75
    .line 76
    move-result p0

    .line 77
    if-eqz p0, :cond_60

    .line 78
    .line 79
    const/4 v1, 0x4

    .line 80
    if-eq p0, v1, :cond_5b

    .line 81
    .line 82
    const/16 v1, 0x8

    .line 83
    .line 84
    if-eq p0, v1, :cond_56

    .line 85
    .line 86
    goto :goto_64

    .line 87
    :cond_56
    const-string p0, "gone"

    .line 88
    .line 89
    iput-object p0, v0, Lio/sentry/protocol/k0;->K:Ljava/lang/String;

    .line 90
    .line 91
    goto :goto_64

    .line 92
    :cond_5b
    const-string p0, "invisible"

    .line 93
    .line 94
    iput-object p0, v0, Lio/sentry/protocol/k0;->K:Ljava/lang/String;

    .line 95
    .line 96
    goto :goto_64

    .line 97
    :cond_60
    const-string p0, "visible"

    .line 98
    .line 99
    iput-object p0, v0, Lio/sentry/protocol/k0;->K:Ljava/lang/String;

    .line 100
    .line 101
    :goto_64
    return-object v0
.end method


# virtual methods
.method public final d(Lio/sentry/t4;Lio/sentry/h0;)Lio/sentry/t4;
    .registers 7

    .line 1
    invoke-virtual {p1}, Lio/sentry/t4;->g()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    goto :goto_5a

    .line 8
    :cond_7
    iget-object v0, p0, Lio/sentry/android/core/ViewHierarchyEventProcessor;->d:Lio/sentry/android/core/SentryAndroidOptions;

    .line 9
    .line 10
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->isAttachViewHierarchy()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-nez v1, :cond_1e

    .line 15
    .line 16
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    new-array v1, v1, [Ljava/lang/Object;

    .line 24
    .line 25
    const-string v2, "attachViewHierarchy is disabled."

    .line 26
    .line 27
    invoke-interface {p2, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object p1

    .line 31
    :cond_1e
    invoke-static {p2}, Lk80/l;->L(Lio/sentry/h0;)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_25

    .line 36
    .line 37
    goto :goto_5a

    .line 38
    :cond_25
    iget-object v1, p0, Lio/sentry/android/core/ViewHierarchyEventProcessor;->e:Lio/sentry/android/core/internal/util/g;

    .line 39
    .line 40
    invoke-virtual {v1}, Lio/sentry/android/core/internal/util/g;->a()Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    invoke-virtual {v0}, Lio/sentry/android/core/SentryAndroidOptions;->getBeforeViewHierarchyCaptureCallback()Lio/sentry/android/core/g1;

    .line 45
    .line 46
    .line 47
    if-eqz v1, :cond_31

    .line 48
    .line 49
    goto :goto_5a

    .line 50
    :cond_31
    sget-object v1, Lio/sentry/android/core/l0;->e:Lio/sentry/android/core/l0;

    .line 51
    .line 52
    iget-object v1, v1, Lio/sentry/android/core/l0;->d:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v1, Ljava/lang/ref/WeakReference;

    .line 55
    .line 56
    if-eqz v1, :cond_40

    .line 57
    .line 58
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    check-cast v1, Landroid/app/Activity;

    .line 63
    .line 64
    goto :goto_41

    .line 65
    :cond_40
    const/4 v1, 0x0

    .line 66
    :goto_41
    invoke-virtual {v0}, Lio/sentry/a6;->getViewHierarchyExporters()Ljava/util/List;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    invoke-virtual {v0}, Lio/sentry/a6;->getThreadChecker()Lio/sentry/util/thread/a;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-static {v1, v2, v3, v0}, Lio/sentry/android/core/ViewHierarchyEventProcessor;->b(Landroid/app/Activity;Ljava/util/List;Lio/sentry/util/thread/a;Lio/sentry/ILogger;)Lio/sentry/protocol/j0;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-eqz v0, :cond_5a

    .line 83
    .line 84
    new-instance v1, Lio/sentry/a;

    .line 85
    .line 86
    invoke-direct {v1, v0}, Lio/sentry/a;-><init>(Lio/sentry/protocol/j0;)V

    .line 87
    .line 88
    .line 89
    iput-object v1, p2, Lio/sentry/h0;->e:Lio/sentry/a;

    .line 90
    .line 91
    :cond_5a
    :goto_5a
    return-object p1
.end method

.method public final g(Lio/sentry/protocol/e0;Lio/sentry/h0;)Lio/sentry/protocol/e0;
    .registers 3

    .line 1
    return-object p1
.end method
