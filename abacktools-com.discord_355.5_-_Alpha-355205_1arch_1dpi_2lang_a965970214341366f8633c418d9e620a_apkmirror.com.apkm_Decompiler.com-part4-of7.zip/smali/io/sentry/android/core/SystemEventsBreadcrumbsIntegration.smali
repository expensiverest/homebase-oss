###### Class io.sentry.android.core.SystemEventsBreadcrumbsIntegration (io.sentry.android.core.SystemEventsBreadcrumbsIntegration)
.class public final Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/sentry/p1;
.implements Ljava/io/Closeable;
.implements Lio/sentry/android/core/b0;


# instance fields
.field public volatile J:Landroid/content/IntentFilter;

.field public volatile K:Landroid/os/HandlerThread;

.field public final L:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final M:Lio/sentry/util/a;

.field public N:Lio/sentry/android/core/j1;

.field public final d:Landroid/content/Context;

.field public volatile e:Lcom/google/android/gms/internal/fido/c2;

.field public i:Lio/sentry/android/core/SentryAndroidOptions;

.field public v:Lio/sentry/z3;

.field public final w:[Ljava/lang/String;

.field public volatile x:Z

.field public volatile y:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-string v18, "android.os.action.DEVICE_IDLE_MODE_CHANGED"

    .line 4
    .line 5
    const-string v19, "android.os.action.POWER_SAVE_MODE_CHANGED"

    .line 6
    .line 7
    const-string v1, "android.intent.action.ACTION_SHUTDOWN"

    .line 8
    .line 9
    const-string v2, "android.intent.action.AIRPLANE_MODE"

    .line 10
    .line 11
    const-string v3, "android.intent.action.BATTERY_CHANGED"

    .line 12
    .line 13
    const-string v4, "android.intent.action.CAMERA_BUTTON"

    .line 14
    .line 15
    const-string v5, "android.intent.action.CONFIGURATION_CHANGED"

    .line 16
    .line 17
    const-string v6, "android.intent.action.DATE_CHANGED"

    .line 18
    .line 19
    const-string v7, "android.intent.action.DEVICE_STORAGE_LOW"

    .line 20
    .line 21
    const-string v8, "android.intent.action.DEVICE_STORAGE_OK"

    .line 22
    .line 23
    const-string v9, "android.intent.action.DOCK_EVENT"

    .line 24
    .line 25
    const-string v10, "android.intent.action.DREAMING_STARTED"

    .line 26
    .line 27
    const-string v11, "android.intent.action.DREAMING_STOPPED"

    .line 28
    .line 29
    const-string v12, "android.intent.action.INPUT_METHOD_CHANGED"

    .line 30
    .line 31
    const-string v13, "android.intent.action.LOCALE_CHANGED"

    .line 32
    .line 33
    const-string v14, "android.intent.action.SCREEN_OFF"

    .line 34
    .line 35
    const-string v15, "android.intent.action.SCREEN_ON"

    .line 36
    .line 37
    const-string v16, "android.intent.action.TIMEZONE_CHANGED"

    .line 38
    .line 39
    const-string v17, "android.intent.action.TIME_SET"

    .line 40
    .line 41
    filled-new-array/range {v1 .. v19}, [Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 46
    .line 47
    .line 48
    const/4 v2, 0x0

    .line 49
    iput-boolean v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->x:Z

    .line 50
    .line 51
    iput-boolean v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->y:Z

    .line 52
    .line 53
    const/4 v3, 0x0

    .line 54
    iput-object v3, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->J:Landroid/content/IntentFilter;

    .line 55
    .line 56
    iput-object v3, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 57
    .line 58
    new-instance v3, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 59
    .line 60
    invoke-direct {v3, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 61
    .line 62
    .line 63
    iput-object v3, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->L:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 64
    .line 65
    new-instance v2, Lio/sentry/util/a;

    .line 66
    .line 67
    invoke-direct {v2}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 68
    .line 69
    .line 70
    iput-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->M:Lio/sentry/util/a;

    .line 71
    .line 72
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    if-eqz v2, :cond_4e

    .line 77
    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    move-object/from16 v2, p1

    .line 80
    .line 81
    :goto_50
    iput-object v2, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->d:Landroid/content/Context;

    .line 82
    .line 83
    iput-object v1, v0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->w:[Ljava/lang/String;

    .line 84
    .line 85
    return-void
.end method


# virtual methods
.method public final c()V
    .registers 3

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->v:Lio/sentry/z3;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 6
    .line 7
    if-nez v0, :cond_9

    .line 8
    .line 9
    goto :goto_13

    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->y:Z

    .line 12
    .line 13
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->v:Lio/sentry/z3;

    .line 14
    .line 15
    iget-object v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 16
    .line 17
    invoke-virtual {p0, v0, v1}, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->g(Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 18
    .line 19
    .line 20
    :cond_13
    :goto_13
    return-void
.end method

.method public final close()V
    .registers 5

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->M:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x1

    .line 8
    :try_start_7
    iput-boolean v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->x:Z

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-object v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->J:Landroid/content/IntentFilter;

    .line 12
    .line 13
    iget-object v2, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 14
    .line 15
    if-eqz v2, :cond_18

    .line 16
    .line 17
    iget-object v2, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;

    .line 18
    .line 19
    invoke-virtual {v2}, Landroid/os/HandlerThread;->quit()Z

    .line 20
    .line 21
    .line 22
    goto :goto_18

    .line 23
    :catchall_16
    move-exception v1

    .line 24
    goto :goto_4c

    .line 25
    :cond_18
    :goto_18
    iput-object v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->K:Landroid/os/HandlerThread;
    :try_end_1a
    .catchall {:try_start_7 .. :try_end_1a} :catchall_16

    .line 26
    .line 27
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 28
    .line 29
    .line 30
    sget-object v0, Lio/sentry/android/core/e0;->w:Lio/sentry/android/core/e0;

    .line 31
    .line 32
    invoke-virtual {v0, p0}, Lio/sentry/android/core/e0;->i(Lio/sentry/android/core/b0;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 36
    .line 37
    if-nez v0, :cond_27

    .line 38
    .line 39
    goto :goto_39

    .line 40
    :cond_27
    :try_start_27
    invoke-virtual {v0}, Lio/sentry/a6;->getExecutorService()Lio/sentry/d1;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    new-instance v1, Le/k;

    .line 45
    .line 46
    const/16 v2, 0x13

    .line 47
    .line 48
    invoke-direct {v1, v2, p0}, Le/k;-><init>(ILjava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-interface {v0, v1}, Lio/sentry/d1;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    :try_end_35
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_27 .. :try_end_35} :catch_36

    .line 52
    .line 53
    .line 54
    goto :goto_39

    .line 55
    :catch_36
    invoke-virtual {p0}, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i()V

    .line 56
    .line 57
    .line 58
    :goto_39
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 59
    .line 60
    if-eqz v0, :cond_4b

    .line 61
    .line 62
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 67
    .line 68
    const/4 v2, 0x0

    .line 69
    new-array v2, v2, [Ljava/lang/Object;

    .line 70
    .line 71
    const-string v3, "SystemEventsBreadcrumbsIntegration removed."

    .line 72
    .line 73
    invoke-interface {v0, v1, v3, v2}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_4b
    return-void

    .line 77
    :goto_4c
    :try_start_4c
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_4f
    .catchall {:try_start_4c .. :try_end_4f} :catchall_50

    .line 78
    .line 79
    .line 80
    goto :goto_54

    .line 81
    :catchall_50
    move-exception v0

    .line 82
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 83
    .line 84
    .line 85
    :goto_54
    throw v1
.end method

.method public final d()V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    :try_start_5
    invoke-virtual {v0}, Lio/sentry/a6;->getExecutorService()Lio/sentry/d1;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    new-instance v1, Le/k;

    .line 11
    .line 12
    const/16 v2, 0x13

    .line 13
    .line 14
    invoke-direct {v1, v2, p0}, Le/k;-><init>(ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-interface {v0, v1}, Lio/sentry/d1;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    :try_end_13
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_5 .. :try_end_13} :catch_14

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :catch_14
    invoke-virtual {p0}, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i()V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final g(Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 5

    .line 1
    invoke-virtual {p2}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableSystemEventBreadcrumbs()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    goto :goto_2f

    .line 8
    :cond_7
    iget-boolean v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->x:Z

    .line 9
    .line 10
    if-nez v0, :cond_2f

    .line 11
    .line 12
    iget-boolean v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->y:Z

    .line 13
    .line 14
    if-nez v0, :cond_2f

    .line 15
    .line 16
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->e:Lcom/google/android/gms/internal/fido/c2;

    .line 17
    .line 18
    if-eqz v0, :cond_14

    .line 19
    .line 20
    goto :goto_2f

    .line 21
    :cond_14
    :try_start_14
    invoke-virtual {p2}, Lio/sentry/a6;->getExecutorService()Lio/sentry/d1;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, Lio/sentry/android/core/d1;

    .line 26
    .line 27
    invoke-direct {v1, p0, p1, p2}, Lio/sentry/android/core/d1;-><init>(Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;Lio/sentry/a1;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {v0, v1}, Lio/sentry/d1;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    :try_end_20
    .catchall {:try_start_14 .. :try_end_20} :catchall_21

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :catchall_21
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    sget-object p2, Lio/sentry/a5;->WARNING:Lio/sentry/a5;

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    new-array v0, v0, [Ljava/lang/Object;

    .line 42
    .line 43
    const-string v1, "Failed to start SystemEventsBreadcrumbsIntegration on executor thread."

    .line 44
    .line 45
    invoke-interface {p1, p2, v1, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_2f
    :goto_2f
    return-void
.end method

.method public final i()V
    .registers 4

    .line 1
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->M:Lio/sentry/util/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lio/sentry/util/a;->a()Lio/sentry/s;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x1

    .line 8
    :try_start_7
    iput-boolean v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->y:Z

    .line 9
    .line 10
    iget-object v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->e:Lcom/google/android/gms/internal/fido/c2;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    iput-object v2, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->e:Lcom/google/android/gms/internal/fido/c2;
    :try_end_e
    .catchall {:try_start_7 .. :try_end_e} :catchall_19

    .line 14
    .line 15
    invoke-virtual {v0}, Lio/sentry/s;->close()V

    .line 16
    .line 17
    .line 18
    if-eqz v1, :cond_18

    .line 19
    .line 20
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->d:Landroid/content/Context;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    return-void

    .line 26
    :catchall_19
    move-exception v1

    .line 27
    :try_start_1a
    invoke-virtual {v0}, Lio/sentry/s;->close()V
    :try_end_1d
    .catchall {:try_start_1a .. :try_end_1d} :catchall_1e

    .line 28
    .line 29
    .line 30
    goto :goto_22

    .line 31
    :catchall_1e
    move-exception v0

    .line 32
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 33
    .line 34
    .line 35
    :goto_22
    throw v1
.end method

.method public final n(Lio/sentry/a6;)V
    .registers 5

    .line 1
    instance-of v0, p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    check-cast p1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 6
    .line 7
    goto :goto_8

    .line 8
    :cond_7
    const/4 p1, 0x0

    .line 9
    :goto_8
    const-string v0, "SentryAndroidOptions is required"

    .line 10
    .line 11
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 15
    .line 16
    sget-object v0, Lio/sentry/z3;->a:Lio/sentry/z3;

    .line 17
    .line 18
    iput-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->v:Lio/sentry/z3;

    .line 19
    .line 20
    invoke-virtual {p1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 25
    .line 26
    iget-object v1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 27
    .line 28
    invoke-virtual {v1}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableSystemEventBreadcrumbs()Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v2, "SystemEventsBreadcrumbsIntegration enabled: %s"

    .line 41
    .line 42
    invoke-interface {p1, v0, v2, v1}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object p1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 46
    .line 47
    invoke-virtual {p1}, Lio/sentry/android/core/SentryAndroidOptions;->isEnableSystemEventBreadcrumbs()Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-eqz p1, :cond_46

    .line 52
    .line 53
    sget-object p1, Lio/sentry/android/core/e0;->w:Lio/sentry/android/core/e0;

    .line 54
    .line 55
    invoke-virtual {p1, p0}, Lio/sentry/android/core/e0;->c(Lio/sentry/android/core/b0;)V

    .line 56
    .line 57
    .line 58
    invoke-static {}, Lio/sentry/android/core/k0;->i()Z

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    if-eqz p1, :cond_46

    .line 63
    .line 64
    iget-object p1, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->v:Lio/sentry/z3;

    .line 65
    .line 66
    iget-object v0, p0, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->i:Lio/sentry/android/core/SentryAndroidOptions;

    .line 67
    .line 68
    invoke-virtual {p0, p1, v0}, Lio/sentry/android/core/SystemEventsBreadcrumbsIntegration;->g(Lio/sentry/z3;Lio/sentry/android/core/SentryAndroidOptions;)V

    .line 69
    .line 70
    .line 71
    :cond_46
    return-void
.end method
