###### Class io.sentry.android.core.h0 (io.sentry.android.core.h0)
.class public interface abstract Lio/sentry/android/core/h0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()Ljava/lang/Long;
.end method

.method public abstract c()Z
.end method

.method public abstract d(Landroid/app/ApplicationExitInfo;Z)Lfb/l;
.end method

.method public abstract getLabel()Ljava/lang/String;
.end method
