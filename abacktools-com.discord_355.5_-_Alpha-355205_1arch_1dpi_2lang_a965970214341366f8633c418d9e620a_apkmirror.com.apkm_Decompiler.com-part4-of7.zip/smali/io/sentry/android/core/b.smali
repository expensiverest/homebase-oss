###### Class io.sentry.android.core.b (io.sentry.android.core.b)
.class public final synthetic Lio/sentry/android/core/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lp/r3;

.field public final synthetic i:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Lp/r3;Landroid/app/Activity;I)V
    .registers 4

    .line 1
    iput p3, p0, Lio/sentry/android/core/b;->d:I

    iput-object p1, p0, Lio/sentry/android/core/b;->e:Lp/r3;

    iput-object p2, p0, Lio/sentry/android/core/b;->i:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    .line 1
    iget v0, p0, Lio/sentry/android/core/b;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_50

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lio/sentry/android/core/b;->e:Lp/r3;

    .line 7
    .line 8
    iget-object v0, v0, Lp/r3;->e:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lio/sentry/util/e;

    .line 11
    .line 12
    invoke-virtual {v0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroidx/core/app/FrameMetricsAggregator;

    .line 17
    .line 18
    iget-object v0, v0, Landroidx/core/app/FrameMetricsAggregator;->a:Lqt/p;

    .line 19
    .line 20
    iget-object v1, v0, Lqt/p;->c:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    :cond_1b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    iget-object v4, p0, Lio/sentry/android/core/b;->i:Landroid/app/Activity;

    .line 33
    .line 34
    if-eqz v3, :cond_32

    .line 35
    .line 36
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    check-cast v3, Ljava/lang/ref/WeakReference;

    .line 41
    .line 42
    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v5

    .line 46
    if-ne v5, v4, :cond_1b

    .line 47
    .line 48
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    :cond_32
    invoke-virtual {v4}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iget-object v0, v0, Lqt/p;->d:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Le1/i;

    .line 58
    .line 59
    invoke-virtual {v1, v0}, Landroid/view/Window;->removeOnFrameMetricsAvailableListener(Landroid/view/Window$OnFrameMetricsAvailableListener;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :pswitch_3e
    iget-object v0, p0, Lio/sentry/android/core/b;->e:Lp/r3;

    .line 64
    .line 65
    iget-object v0, v0, Lp/r3;->e:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v0, Lio/sentry/util/e;

    .line 68
    .line 69
    invoke-virtual {v0}, Lio/sentry/util/e;->a()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    check-cast v0, Landroidx/core/app/FrameMetricsAggregator;

    .line 74
    .line 75
    iget-object v1, p0, Lio/sentry/android/core/b;->i:Landroid/app/Activity;

    .line 76
    .line 77
    invoke-virtual {v0, v1}, Landroidx/core/app/FrameMetricsAggregator;->a(Landroid/app/Activity;)V

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_3e
    .end packed-switch
.end method
