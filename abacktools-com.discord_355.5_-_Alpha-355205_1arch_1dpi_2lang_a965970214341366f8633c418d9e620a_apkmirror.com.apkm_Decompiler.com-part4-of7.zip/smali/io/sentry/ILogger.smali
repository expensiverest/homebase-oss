###### Class io.sentry.ILogger (io.sentry.ILogger)
.class public interface abstract Lio/sentry/ILogger;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public varargs abstract b(Lio/sentry/a5;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V
.end method

.method public abstract k(Lio/sentry/a5;Ljava/lang/String;Ljava/lang/Throwable;)V
.end method

.method public varargs abstract m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
.end method

.method public abstract n(Lio/sentry/a5;)Z
.end method
