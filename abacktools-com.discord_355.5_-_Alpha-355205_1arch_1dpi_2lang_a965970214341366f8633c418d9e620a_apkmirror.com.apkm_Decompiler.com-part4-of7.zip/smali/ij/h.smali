###### Class ij.h (ij.h)
.class public final Lij/h;
.super Lcom/facebook/react/bridge/BaseActivityEventListener;
.source "SourceFile"


# instance fields
.field public final synthetic d:Lcom/discord/samsung/SamsungModule;


# direct methods
.method public constructor <init>(Lcom/discord/samsung/SamsungModule;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lij/h;->d:Lcom/discord/samsung/SamsungModule;

    .line 2
    .line 3
    invoke-direct {p0}, Lcom/facebook/react/bridge/BaseActivityEventListener;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onActivityResult(Landroid/app/Activity;IILandroid/content/Intent;)V
    .registers 8

    .line 1
    const-string v0, "activity"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/16 v0, 0x64

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    iget-object v2, p0, Lij/h;->d:Lcom/discord/samsung/SamsungModule;

    .line 10
    .line 11
    if-eq p2, v0, :cond_53

    .line 12
    .line 13
    const/16 v0, 0x65

    .line 14
    .line 15
    if-eq p2, v0, :cond_14

    .line 16
    .line 17
    invoke-super {p0, p1, p2, p3, p4}, Lcom/facebook/react/bridge/BaseActivityEventListener;->onActivityResult(Landroid/app/Activity;IILandroid/content/Intent;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    const/16 p1, 0x1f4

    .line 22
    .line 23
    const/4 p2, 0x0

    .line 24
    if-ne p3, p1, :cond_2a

    .line 25
    .line 26
    new-instance p1, Lij/a;

    .line 27
    .line 28
    if-eqz p4, :cond_23

    .line 29
    .line 30
    const-string p3, "com.discord.samsung.intent.extra.ATTEMPT_COUNT"

    .line 31
    .line 32
    invoke-virtual {p4, p3, p2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    :cond_23
    invoke-direct {p1, p2, v1}, Lij/a;-><init>(IZ)V

    .line 37
    .line 38
    .line 39
    invoke-static {v2, p1}, Lcom/discord/samsung/SamsungModule;->access$handleAuthResult(Lcom/discord/samsung/SamsungModule;Lij/c;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_2a
    if-nez p4, :cond_35

    .line 44
    .line 45
    new-instance p1, Lij/a;

    .line 46
    .line 47
    invoke-direct {p1, p2, p2}, Lij/a;-><init>(IZ)V

    .line 48
    .line 49
    .line 50
    invoke-static {v2, p1}, Lcom/discord/samsung/SamsungModule;->access$handleAuthResult(Lcom/discord/samsung/SamsungModule;Lij/c;)V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :cond_35
    const-string p1, "com.discord.samsung.intent.extra.AUTH_CODE"

    .line 55
    .line 56
    invoke-virtual {p4, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    const-string p2, ""

    .line 61
    .line 62
    if-nez p1, :cond_40

    .line 63
    .line 64
    move-object p1, p2

    .line 65
    :cond_40
    const-string p3, "com.discord.samsung.intent.extra.SERVER_URL"

    .line 66
    .line 67
    invoke-virtual {p4, p3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p3

    .line 71
    if-nez p3, :cond_49

    .line 72
    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    move-object p2, p3

    .line 75
    :goto_4a
    new-instance p3, Lij/b;

    .line 76
    .line 77
    invoke-direct {p3, p1, p2}, Lij/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-static {v2, p3}, Lcom/discord/samsung/SamsungModule;->access$handleAuthResult(Lcom/discord/samsung/SamsungModule;Lij/c;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_53
    const/4 p1, -0x1

    .line 85
    const/4 p2, 0x0

    .line 86
    if-ne p3, p1, :cond_5b

    .line 87
    .line 88
    invoke-static {v2, p2, v1, p2}, Lcom/discord/samsung/SamsungModule;->resolveConnection$default(Lcom/discord/samsung/SamsungModule;Ljava/lang/Object;ILjava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :cond_5b
    if-eqz p4, :cond_6a

    .line 93
    .line 94
    invoke-virtual {p4}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    if-eqz p1, :cond_6a

    .line 99
    .line 100
    const-string p3, "error_message"

    .line 101
    .line 102
    invoke-virtual {p1, p3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    goto :goto_6b

    .line 107
    :cond_6a
    move-object p1, p2

    .line 108
    :goto_6b
    if-eqz p4, :cond_79

    .line 109
    .line 110
    invoke-virtual {p4}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 111
    .line 112
    .line 113
    move-result-object p3

    .line 114
    if-eqz p3, :cond_79

    .line 115
    .line 116
    const-string p2, "error_code"

    .line 117
    .line 118
    invoke-virtual {p3, p2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p2

    .line 122
    :cond_79
    new-instance p3, Ljava/lang/Throwable;

    .line 123
    .line 124
    const-string p4, "Connection requires disclaimer acceptance. ["

    .line 125
    .line 126
    const-string v0, "] "

    .line 127
    .line 128
    invoke-static {p4, p2, v0, p1}, Lcom/google/android/gms/internal/fido/nb;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    invoke-direct {p3, p1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    invoke-static {v2, p3}, Lcom/discord/samsung/SamsungModule;->access$rejectConnection(Lcom/discord/samsung/SamsungModule;Ljava/lang/Throwable;)V

    .line 136
    .line 137
    .line 138
    return-void
.end method
