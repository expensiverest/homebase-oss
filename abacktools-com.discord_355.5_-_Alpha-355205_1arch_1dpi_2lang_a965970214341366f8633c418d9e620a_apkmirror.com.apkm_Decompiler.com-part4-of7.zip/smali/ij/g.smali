###### Class ij.g (ij.g)
.class public final Lij/g;
.super Ljava/lang/Object;
.source "SourceFile"
