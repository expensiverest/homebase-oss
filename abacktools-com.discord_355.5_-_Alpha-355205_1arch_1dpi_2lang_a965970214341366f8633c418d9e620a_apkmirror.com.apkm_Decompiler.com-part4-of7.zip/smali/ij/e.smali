###### Class ij.e (ij.e)
.class public final Lij/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final synthetic d:Lcom/discord/samsung/SamsungConnectActivity;


# direct methods
.method public constructor <init>(Lcom/discord/samsung/SamsungConnectActivity;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lij/e;->d:Lcom/discord/samsung/SamsungConnectActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .registers 12

    .line 1
    const-string p1, "Samsung Account service connection established: isReqSucc? "

    .line 2
    .line 3
    const-string v0, "Samsung Account service connection established: "

    .line 4
    .line 5
    iget-object v1, p0, Lij/e;->d:Lcom/discord/samsung/SamsungConnectActivity;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    iput-boolean v2, v1, Lcom/discord/samsung/SamsungConnectActivity;->c0:Z

    .line 9
    .line 10
    invoke-static {p2}, Lcom/msc/sa/aidl/ISAService$Stub;->asInterface(Landroid/os/IBinder;)Lcom/msc/sa/aidl/ISAService;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    sget-object v3, Lnf/a;->a:Lnf/a;

    .line 15
    .line 16
    const-string v3, "Samsung Account service connection established"

    .line 17
    .line 18
    const-string v4, "Samsung"

    .line 19
    .line 20
    const/4 v5, 0x0

    .line 21
    invoke-static {v4, v3, v5}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 22
    .line 23
    .line 24
    :try_start_17
    const-string v3, "97t47j218f"

    .line 25
    .line 26
    const-string v6, "dummy"

    .line 27
    .line 28
    const-string v7, "com.discord"

    .line 29
    .line 30
    iget-object v8, v1, Lcom/discord/samsung/SamsungConnectActivity;->b0:Lij/d;

    .line 31
    .line 32
    if-eqz v8, :cond_83

    .line 33
    .line 34
    invoke-interface {p2, v3, v6, v7, v8}, Lcom/msc/sa/aidl/ISAService;->registerCallback(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/msc/sa/aidl/ISACallback;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    new-instance v6, Ljava/lang/StringBuilder;

    .line 39
    .line 40
    invoke-direct {v6, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-static {v4, v0, v5}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 51
    .line 52
    .line 53
    if-nez v3, :cond_59

    .line 54
    .line 55
    const-string p1, "finishedWithRestartRequested"

    .line 56
    .line 57
    invoke-static {v4, p1, v5}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    const-string p2, "com.discord.samsung.intent.extra.ATTEMPT_COUNT"

    .line 65
    .line 66
    const/4 v0, 0x0

    .line 67
    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    new-instance v0, Landroid/content/Intent;

    .line 72
    .line 73
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 74
    .line 75
    .line 76
    add-int/2addr p1, v2

    .line 77
    invoke-virtual {v0, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    const/16 p2, 0x1f4

    .line 82
    .line 83
    invoke-virtual {v1, p2, p1}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1}, Landroid/app/Activity;->finish()V

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    :cond_59
    new-instance v0, Landroid/os/Bundle;

    .line 91
    .line 92
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 93
    .line 94
    .line 95
    const-string v2, "additional"

    .line 96
    .line 97
    const-string v6, "api_server_url"

    .line 98
    .line 99
    const-string v7, "auth_server_url"

    .line 100
    .line 101
    filled-new-array {v6, v7}, [Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    invoke-virtual {v0, v2, v6}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    const/16 v2, 0x4c5

    .line 109
    .line 110
    invoke-interface {p2, v2, v3, v0}, Lcom/msc/sa/aidl/ISAService;->requestAuthCode(ILjava/lang/String;Landroid/os/Bundle;)Z

    .line 111
    .line 112
    .line 113
    move-result p2

    .line 114
    new-instance v0, Ljava/lang/StringBuilder;

    .line 115
    .line 116
    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-static {v4, p1, v5}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :catchall_81
    move-exception p1

    .line 131
    goto :goto_89

    .line 132
    :cond_83
    const-string p1, "samsungAccountServiceCallback"

    .line 133
    .line 134
    invoke-static {p1}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    throw v5
    :try_end_89
    .catchall {:try_start_17 .. :try_end_89} :catchall_81

    .line 138
    :goto_89
    sget-object p2, Lnf/a;->a:Lnf/a;

    .line 139
    .line 140
    const-string p2, "Unable to connect to Samsung"

    .line 141
    .line 142
    invoke-static {v4, p2, p1}, Lnf/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 143
    .line 144
    .line 145
    invoke-static {v1, v5, v5}, Lcom/discord/samsung/SamsungConnectActivity;->r(Lcom/discord/samsung/SamsungConnectActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .registers 4

    .line 1
    sget-object p1, Lnf/a;->a:Lnf/a;

    .line 2
    .line 3
    const-string p1, "Samsung"

    .line 4
    .line 5
    const-string v0, "Samsung Account service connection unbound"

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {p1, v0, v1}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 9
    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    iget-object v0, p0, Lij/e;->d:Lcom/discord/samsung/SamsungConnectActivity;

    .line 13
    .line 14
    iput-boolean p1, v0, Lcom/discord/samsung/SamsungConnectActivity;->c0:Z

    .line 15
    .line 16
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 17
    .line 18
    .line 19
    return-void
.end method
