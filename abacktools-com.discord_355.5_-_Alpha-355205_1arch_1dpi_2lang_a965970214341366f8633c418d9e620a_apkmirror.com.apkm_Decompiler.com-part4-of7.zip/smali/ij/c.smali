###### Class ij.c (ij.c)
.class public abstract Lij/c;
.super Ljava/lang/Object;
.source "SourceFile"
