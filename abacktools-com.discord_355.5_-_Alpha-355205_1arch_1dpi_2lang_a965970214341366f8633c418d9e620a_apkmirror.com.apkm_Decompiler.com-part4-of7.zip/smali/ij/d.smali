###### Class ij.d (ij.d)
.class public final Lij/d;
.super Lcom/msc/sa/aidl/ISACallback$Stub;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/discord/samsung/SamsungConnectActivity;


# direct methods
.method public constructor <init>(Lcom/discord/samsung/SamsungConnectActivity;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lij/d;->f:Lcom/discord/samsung/SamsungConnectActivity;

    .line 2
    .line 3
    invoke-direct {p0}, Lcom/msc/sa/aidl/ISACallback$Stub;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onReceiveAccessToken(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceiveAccessToken"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method

.method public final onReceiveAuthCode(IZLandroid/os/Bundle;)V
    .registers 12

    .line 1
    const/4 p1, 0x0

    .line 2
    if-eqz p3, :cond_a

    .line 3
    .line 4
    const-string v0, "authcode"

    .line 5
    .line 6
    invoke-virtual {p3, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    move-object v0, p1

    .line 12
    :goto_b
    if-eqz p3, :cond_14

    .line 13
    .line 14
    const-string v1, "auth_server_url"

    .line 15
    .line 16
    invoke-virtual {p3, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    goto :goto_15

    .line 21
    :cond_14
    move-object v1, p1

    .line 22
    :goto_15
    sget-object v2, Lnf/a;->a:Lnf/a;

    .line 23
    .line 24
    new-instance v2, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string v3, "Samsung onReceiveAuthCode="

    .line 27
    .line 28
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    const-string v3, "Samsung"

    .line 39
    .line 40
    invoke-static {v3, v2, p1}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    if-eqz p2, :cond_34

    .line 44
    .line 45
    if-eqz v0, :cond_34

    .line 46
    .line 47
    invoke-static {v0}, Lw60/o;->y0(Ljava/lang/CharSequence;)Z

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    if-eqz p2, :cond_78

    .line 52
    .line 53
    :cond_34
    if-eqz p3, :cond_3d

    .line 54
    .line 55
    const-string p2, "error_code"

    .line 56
    .line 57
    invoke-virtual {p3, p2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p2

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    move-object p2, p1

    .line 63
    :goto_3e
    if-eqz p3, :cond_47

    .line 64
    .line 65
    const-string v2, "error_message"

    .line 66
    .line 67
    invoke-virtual {p3, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p3

    .line 71
    goto :goto_48

    .line 72
    :cond_47
    move-object p3, p1

    .line 73
    :goto_48
    new-instance v2, Ljava/lang/StringBuilder;

    .line 74
    .line 75
    const-string v4, "Samsung Account link failure "

    .line 76
    .line 77
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    if-eqz v0, :cond_57

    .line 81
    .line 82
    const/4 v4, 0x4

    .line 83
    invoke-static {v4, v0}, Lw60/o;->V0(ILjava/lang/String;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    goto :goto_58

    .line 88
    :cond_57
    move-object v4, p1

    .line 89
    :goto_58
    const-string v5, ":"

    .line 90
    .line 91
    const-string v6, "]: "

    .line 92
    .line 93
    const-string v7, "["

    .line 94
    .line 95
    invoke-static {v7, p2, v5, v4, v6}, Lp/x2;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    move-result-object p2

    .line 99
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p2

    .line 113
    const-string p3, "toString(...)"

    .line 114
    .line 115
    invoke-static {p2, p3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-static {v3, p2, p1}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 119
    .line 120
    .line 121
    :cond_78
    iget-object p1, p0, Lij/d;->f:Lcom/discord/samsung/SamsungConnectActivity;

    .line 122
    .line 123
    invoke-static {p1, v0, v1}, Lcom/discord/samsung/SamsungConnectActivity;->r(Lcom/discord/samsung/SamsungConnectActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    return-void
.end method

.method public final onReceiveChecklistValidation(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceiveAccessToken"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method

.method public final onReceiveDisclaimerAgreement(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceiveDisclaimerAgreement"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method

.method public final onReceivePasswordConfirmation(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceivePasswordConfirmation"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method

.method public final onReceiveRLControlFMM(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceiveRLControlFMM"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method

.method public final onReceiveRubinRequest(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceiveRubinRequest"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method

.method public final onReceiveSCloudAccessToken(IZLandroid/os/Bundle;)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string p2, "Unexpected call to onReceiveSCloudAccessToken"

    .line 4
    .line 5
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p1
.end method
