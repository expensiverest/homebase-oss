###### Class ij.f (ij.f)
.class public final synthetic Lij/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/discord/samsung/SamsungModule;


# direct methods
.method public synthetic constructor <init>(Lcom/discord/samsung/SamsungModule;I)V
    .registers 3

    .line 1
    iput p2, p0, Lij/f;->a:I

    iput-object p1, p0, Lij/f;->b:Lcom/discord/samsung/SamsungModule;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lij/f;->a:I

    packed-switch v0, :pswitch_data_20

    iget-object v0, p0, Lij/f;->b:Lcom/discord/samsung/SamsungModule;

    check-cast p1, Ljava/lang/Throwable;

    invoke-static {v0, p1}, Lcom/discord/samsung/SamsungModule;->c(Lcom/discord/samsung/SamsungModule;Ljava/lang/Throwable;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_e
    iget-object v0, p0, Lij/f;->b:Lcom/discord/samsung/SamsungModule;

    check-cast p1, Ljava/lang/Throwable;

    invoke-static {v0, p1}, Lcom/discord/samsung/SamsungModule;->a(Lcom/discord/samsung/SamsungModule;Ljava/lang/Throwable;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_17
    iget-object v0, p0, Lij/f;->b:Lcom/discord/samsung/SamsungModule;

    check-cast p1, Ljava/lang/Throwable;

    invoke-static {v0, p1}, Lcom/discord/samsung/SamsungModule;->b(Lcom/discord/samsung/SamsungModule;Ljava/lang/Throwable;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_17
        :pswitch_e
    .end packed-switch
.end method
