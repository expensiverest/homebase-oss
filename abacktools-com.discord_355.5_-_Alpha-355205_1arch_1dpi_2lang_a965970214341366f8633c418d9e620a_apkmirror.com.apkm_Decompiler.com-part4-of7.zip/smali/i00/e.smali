###### Class i00.e (i00.e)
.class public final Li00/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li00/a;


# instance fields
.field public final a:[J


# direct methods
.method public constructor <init>([J)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li00/e;->a:[J

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Landroid/os/Vibrator;)V
    .registers 6

    .line 1
    :try_start_0
    invoke-virtual {p1}, Landroid/os/Vibrator;->hasVibrator()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_39

    .line 6
    .line 7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_28

    .line 8
    .line 9
    const/16 v1, 0x21

    .line 10
    .line 11
    const/4 v2, -0x1

    .line 12
    iget-object v3, p0, Li00/e;->a:[J

    .line 13
    .line 14
    if-lt v0, v1, :cond_2a

    .line 15
    .line 16
    :try_start_f
    invoke-static {v3, v2}, Landroid/os/VibrationEffect;->createWaveform([JI)Landroid/os/VibrationEffect;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    new-instance v1, Landroid/os/VibrationAttributes$Builder;

    .line 21
    .line 22
    new-instance v1, Landroid/os/VibrationAttributes$Builder;

    .line 23
    .line 24
    invoke-direct {v1}, Landroid/os/VibrationAttributes$Builder;-><init>()V

    .line 25
    .line 26
    .line 27
    const/16 v2, 0x12

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Landroid/os/VibrationAttributes$Builder;->setUsage(I)Landroid/os/VibrationAttributes$Builder;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v1}, Landroid/os/VibrationAttributes$Builder;->build()Landroid/os/VibrationAttributes;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-virtual {p1, v0, v1}, Landroid/os/Vibrator;->vibrate(Landroid/os/VibrationEffect;Landroid/os/VibrationAttributes;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :catch_28
    move-exception p1

    .line 42
    goto :goto_3a

    .line 43
    :cond_2a
    const/16 v1, 0x1a

    .line 44
    .line 45
    if-lt v0, v1, :cond_36

    .line 46
    .line 47
    invoke-static {v3, v2}, Landroid/os/VibrationEffect;->createWaveform([JI)Landroid/os/VibrationEffect;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {p1, v0}, Landroid/os/Vibrator;->vibrate(Landroid/os/VibrationEffect;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_36
    invoke-virtual {p1, v3, v2}, Landroid/os/Vibrator;->vibrate([JI)V
    :try_end_39
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_39} :catch_28

    .line 56
    .line 57
    .line 58
    :cond_39
    return-void

    .line 59
    :goto_3a
    const-string v0, "RNHapticFeedback"

    .line 60
    .line 61
    const-string v1, "VibrateWithDuration failed"

    .line 62
    .line 63
    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 64
    .line 65
    .line 66
    return-void
.end method
