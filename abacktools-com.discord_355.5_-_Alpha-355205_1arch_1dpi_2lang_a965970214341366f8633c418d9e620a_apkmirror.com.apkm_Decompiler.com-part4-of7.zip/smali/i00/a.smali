###### Class i00.a (i00.a)
.class public interface abstract Li00/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/os/Vibrator;)V
.end method
