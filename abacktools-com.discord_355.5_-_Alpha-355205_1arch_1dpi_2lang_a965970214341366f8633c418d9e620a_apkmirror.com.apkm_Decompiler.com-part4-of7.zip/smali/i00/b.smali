###### Class i00.b (i00.b)
.class public abstract Li00/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/HashMap;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Li00/b;->a:Ljava/util/HashMap;

    .line 7
    .line 8
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v2, 0x1f

    .line 11
    .line 12
    const-string v5, "notificationError"

    .line 13
    .line 14
    const-string v6, "notificationWarning"

    .line 15
    .line 16
    const-string v7, "notificationSuccess"

    .line 17
    .line 18
    const-string v8, "selection"

    .line 19
    .line 20
    const-string v9, "soft"

    .line 21
    .line 22
    const-string v10, "rigid"

    .line 23
    .line 24
    const/4 v11, 0x2

    .line 25
    const-string v12, "impactHeavy"

    .line 26
    .line 27
    const-string v13, "impactMedium"

    .line 28
    .line 29
    const-string v14, "impactLight"

    .line 30
    .line 31
    if-lt v1, v2, :cond_c8

    .line 32
    .line 33
    new-instance v2, Li00/c;

    .line 34
    .line 35
    new-instance v3, Li00/e;

    .line 36
    .line 37
    new-array v4, v11, [J

    .line 38
    .line 39
    fill-array-data v4, :array_2d4

    .line 40
    .line 41
    .line 42
    invoke-direct {v3, v4}, Li00/e;-><init>([J)V

    .line 43
    .line 44
    .line 45
    const/4 v4, 0x7

    .line 46
    const v15, 0x3e99999a    # 0.3f

    .line 47
    .line 48
    .line 49
    invoke-direct {v2, v4, v15, v3}, Li00/c;-><init>(IFLi00/e;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0, v14, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    new-instance v2, Li00/c;

    .line 56
    .line 57
    new-instance v3, Li00/e;

    .line 58
    .line 59
    new-array v14, v11, [J

    .line 60
    .line 61
    fill-array-data v14, :array_2e0

    .line 62
    .line 63
    .line 64
    invoke-direct {v3, v14}, Li00/e;-><init>([J)V

    .line 65
    .line 66
    .line 67
    const v14, 0x3f19999a    # 0.6f

    .line 68
    .line 69
    .line 70
    const/4 v4, 0x1

    .line 71
    invoke-direct {v2, v4, v14, v3}, Li00/c;-><init>(IFLi00/e;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0, v13, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    new-instance v2, Li00/c;

    .line 78
    .line 79
    new-instance v3, Li00/e;

    .line 80
    .line 81
    new-array v4, v11, [J

    .line 82
    .line 83
    fill-array-data v4, :array_2ec

    .line 84
    .line 85
    .line 86
    invoke-direct {v3, v4}, Li00/e;-><init>([J)V

    .line 87
    .line 88
    .line 89
    const/high16 v4, 0x3f800000    # 1.0f

    .line 90
    .line 91
    invoke-direct {v2, v11, v4, v3}, Li00/c;-><init>(IFLi00/e;)V

    .line 92
    .line 93
    .line 94
    invoke-virtual {v0, v12, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    new-instance v2, Li00/c;

    .line 98
    .line 99
    new-instance v3, Li00/e;

    .line 100
    .line 101
    new-array v4, v11, [J

    .line 102
    .line 103
    fill-array-data v4, :array_2f8

    .line 104
    .line 105
    .line 106
    invoke-direct {v3, v4}, Li00/e;-><init>([J)V

    .line 107
    .line 108
    .line 109
    const v4, 0x3f666666    # 0.9f

    .line 110
    .line 111
    .line 112
    const/4 v12, 0x1

    .line 113
    invoke-direct {v2, v12, v4, v3}, Li00/c;-><init>(IFLi00/e;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0, v10, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    new-instance v2, Li00/c;

    .line 120
    .line 121
    new-instance v3, Li00/e;

    .line 122
    .line 123
    new-array v4, v11, [J

    .line 124
    .line 125
    fill-array-data v4, :array_304

    .line 126
    .line 127
    .line 128
    invoke-direct {v3, v4}, Li00/e;-><init>([J)V

    .line 129
    .line 130
    .line 131
    const/4 v4, 0x7

    .line 132
    invoke-direct {v2, v4, v15, v3}, Li00/c;-><init>(IFLi00/e;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v0, v9, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    new-instance v2, Li00/c;

    .line 139
    .line 140
    new-instance v3, Li00/e;

    .line 141
    .line 142
    new-array v9, v11, [J

    .line 143
    .line 144
    fill-array-data v9, :array_310

    .line 145
    .line 146
    .line 147
    invoke-direct {v3, v9}, Li00/e;-><init>([J)V

    .line 148
    .line 149
    .line 150
    const v9, 0x3ecccccd    # 0.4f

    .line 151
    .line 152
    .line 153
    invoke-direct {v2, v4, v9, v3}, Li00/c;-><init>(IFLi00/e;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v0, v8, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    new-instance v2, Li00/e;

    .line 160
    .line 161
    const/4 v3, 0x4

    .line 162
    new-array v4, v3, [J

    .line 163
    .line 164
    fill-array-data v4, :array_31c

    .line 165
    .line 166
    .line 167
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0, v7, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    new-instance v2, Li00/e;

    .line 174
    .line 175
    new-array v4, v3, [J

    .line 176
    .line 177
    fill-array-data v4, :array_330

    .line 178
    .line 179
    .line 180
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v0, v6, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    new-instance v2, Li00/e;

    .line 187
    .line 188
    const/4 v3, 0x6

    .line 189
    new-array v3, v3, [J

    .line 190
    .line 191
    fill-array-data v3, :array_344

    .line 192
    .line 193
    .line 194
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v0, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    goto :goto_13f

    .line 201
    :cond_c8
    new-instance v2, Li00/e;

    .line 202
    .line 203
    new-array v3, v11, [J

    .line 204
    .line 205
    fill-array-data v3, :array_360

    .line 206
    .line 207
    .line 208
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v0, v14, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    new-instance v2, Li00/e;

    .line 215
    .line 216
    new-array v3, v11, [J

    .line 217
    .line 218
    fill-array-data v3, :array_36c

    .line 219
    .line 220
    .line 221
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v0, v13, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    new-instance v2, Li00/e;

    .line 228
    .line 229
    new-array v3, v11, [J

    .line 230
    .line 231
    fill-array-data v3, :array_378

    .line 232
    .line 233
    .line 234
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v0, v12, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    new-instance v2, Li00/e;

    .line 241
    .line 242
    const/4 v3, 0x4

    .line 243
    new-array v4, v3, [J

    .line 244
    .line 245
    fill-array-data v4, :array_384

    .line 246
    .line 247
    .line 248
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {v0, v7, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    new-instance v2, Li00/e;

    .line 255
    .line 256
    new-array v4, v3, [J

    .line 257
    .line 258
    fill-array-data v4, :array_398

    .line 259
    .line 260
    .line 261
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v0, v6, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    new-instance v2, Li00/e;

    .line 268
    .line 269
    const/4 v3, 0x6

    .line 270
    new-array v3, v3, [J

    .line 271
    .line 272
    fill-array-data v3, :array_3ac

    .line 273
    .line 274
    .line 275
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v0, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    new-instance v2, Li00/e;

    .line 282
    .line 283
    new-array v3, v11, [J

    .line 284
    .line 285
    fill-array-data v3, :array_3c8

    .line 286
    .line 287
    .line 288
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v0, v10, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    new-instance v2, Li00/e;

    .line 295
    .line 296
    new-array v3, v11, [J

    .line 297
    .line 298
    fill-array-data v3, :array_3d4

    .line 299
    .line 300
    .line 301
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v0, v9, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    new-instance v2, Li00/e;

    .line 308
    .line 309
    new-array v3, v11, [J

    .line 310
    .line 311
    fill-array-data v3, :array_3e0

    .line 312
    .line 313
    .line 314
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v0, v8, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    :goto_13f
    new-instance v2, Li00/e;

    .line 321
    .line 322
    new-array v3, v11, [J

    .line 323
    .line 324
    fill-array-data v3, :array_3ec

    .line 325
    .line 326
    .line 327
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 328
    .line 329
    .line 330
    const-string v3, "clockTick"

    .line 331
    .line 332
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 333
    .line 334
    .line 335
    new-instance v2, Li00/e;

    .line 336
    .line 337
    new-array v3, v11, [J

    .line 338
    .line 339
    fill-array-data v3, :array_3f8

    .line 340
    .line 341
    .line 342
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 343
    .line 344
    .line 345
    const-string v3, "contextClick"

    .line 346
    .line 347
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 348
    .line 349
    .line 350
    new-instance v2, Li00/e;

    .line 351
    .line 352
    new-array v3, v11, [J

    .line 353
    .line 354
    fill-array-data v3, :array_404

    .line 355
    .line 356
    .line 357
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 358
    .line 359
    .line 360
    const-string v3, "keyboardPress"

    .line 361
    .line 362
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    new-instance v2, Li00/e;

    .line 366
    .line 367
    new-array v3, v11, [J

    .line 368
    .line 369
    fill-array-data v3, :array_410

    .line 370
    .line 371
    .line 372
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 373
    .line 374
    .line 375
    const-string v3, "keyboardRelease"

    .line 376
    .line 377
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    new-instance v2, Li00/e;

    .line 381
    .line 382
    new-array v3, v11, [J

    .line 383
    .line 384
    fill-array-data v3, :array_41c

    .line 385
    .line 386
    .line 387
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 388
    .line 389
    .line 390
    const-string v3, "keyboardTap"

    .line 391
    .line 392
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    new-instance v2, Li00/e;

    .line 396
    .line 397
    new-array v3, v11, [J

    .line 398
    .line 399
    fill-array-data v3, :array_428

    .line 400
    .line 401
    .line 402
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 403
    .line 404
    .line 405
    const-string v3, "longPress"

    .line 406
    .line 407
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    new-instance v2, Li00/e;

    .line 411
    .line 412
    new-array v3, v11, [J

    .line 413
    .line 414
    fill-array-data v3, :array_434

    .line 415
    .line 416
    .line 417
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 418
    .line 419
    .line 420
    const-string v3, "textHandleMove"

    .line 421
    .line 422
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    new-instance v2, Li00/e;

    .line 426
    .line 427
    new-array v3, v11, [J

    .line 428
    .line 429
    fill-array-data v3, :array_440

    .line 430
    .line 431
    .line 432
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 433
    .line 434
    .line 435
    const-string v3, "virtualKey"

    .line 436
    .line 437
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    new-instance v2, Li00/e;

    .line 441
    .line 442
    new-array v3, v11, [J

    .line 443
    .line 444
    fill-array-data v3, :array_44c

    .line 445
    .line 446
    .line 447
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 448
    .line 449
    .line 450
    const-string v3, "virtualKeyRelease"

    .line 451
    .line 452
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 453
    .line 454
    .line 455
    new-instance v2, Li00/e;

    .line 456
    .line 457
    const/4 v3, 0x4

    .line 458
    new-array v4, v3, [J

    .line 459
    .line 460
    fill-array-data v4, :array_458

    .line 461
    .line 462
    .line 463
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 464
    .line 465
    .line 466
    const-string v4, "confirm"

    .line 467
    .line 468
    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 469
    .line 470
    .line 471
    new-instance v2, Li00/e;

    .line 472
    .line 473
    new-array v4, v3, [J

    .line 474
    .line 475
    fill-array-data v4, :array_46c

    .line 476
    .line 477
    .line 478
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 479
    .line 480
    .line 481
    const-string v3, "reject"

    .line 482
    .line 483
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 484
    .line 485
    .line 486
    new-instance v2, Li00/e;

    .line 487
    .line 488
    new-array v3, v11, [J

    .line 489
    .line 490
    fill-array-data v3, :array_480

    .line 491
    .line 492
    .line 493
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 494
    .line 495
    .line 496
    const-string v3, "gestureStart"

    .line 497
    .line 498
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 499
    .line 500
    .line 501
    new-instance v2, Li00/e;

    .line 502
    .line 503
    new-array v3, v11, [J

    .line 504
    .line 505
    fill-array-data v3, :array_48c

    .line 506
    .line 507
    .line 508
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 509
    .line 510
    .line 511
    const-string v3, "gestureEnd"

    .line 512
    .line 513
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 514
    .line 515
    .line 516
    new-instance v2, Li00/e;

    .line 517
    .line 518
    new-array v3, v11, [J

    .line 519
    .line 520
    fill-array-data v3, :array_498

    .line 521
    .line 522
    .line 523
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 524
    .line 525
    .line 526
    const-string v3, "segmentTick"

    .line 527
    .line 528
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 529
    .line 530
    .line 531
    new-instance v2, Li00/e;

    .line 532
    .line 533
    new-array v3, v11, [J

    .line 534
    .line 535
    fill-array-data v3, :array_4a4

    .line 536
    .line 537
    .line 538
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 539
    .line 540
    .line 541
    const-string v3, "segmentFrequentTick"

    .line 542
    .line 543
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 544
    .line 545
    .line 546
    new-instance v2, Li00/e;

    .line 547
    .line 548
    const/4 v3, 0x4

    .line 549
    new-array v4, v3, [J

    .line 550
    .line 551
    fill-array-data v4, :array_4b0

    .line 552
    .line 553
    .line 554
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 555
    .line 556
    .line 557
    const-string v4, "toggleOn"

    .line 558
    .line 559
    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 560
    .line 561
    .line 562
    new-instance v2, Li00/e;

    .line 563
    .line 564
    new-array v4, v3, [J

    .line 565
    .line 566
    fill-array-data v4, :array_4c4

    .line 567
    .line 568
    .line 569
    invoke-direct {v2, v4}, Li00/e;-><init>([J)V

    .line 570
    .line 571
    .line 572
    const-string v3, "toggleOff"

    .line 573
    .line 574
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 575
    .line 576
    .line 577
    new-instance v2, Li00/e;

    .line 578
    .line 579
    new-array v3, v11, [J

    .line 580
    .line 581
    fill-array-data v3, :array_4d8

    .line 582
    .line 583
    .line 584
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 585
    .line 586
    .line 587
    const-string v3, "dragStart"

    .line 588
    .line 589
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 590
    .line 591
    .line 592
    new-instance v2, Li00/e;

    .line 593
    .line 594
    new-array v3, v11, [J

    .line 595
    .line 596
    fill-array-data v3, :array_4e4

    .line 597
    .line 598
    .line 599
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 600
    .line 601
    .line 602
    const-string v3, "gestureThresholdActivate"

    .line 603
    .line 604
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 605
    .line 606
    .line 607
    new-instance v2, Li00/e;

    .line 608
    .line 609
    new-array v3, v11, [J

    .line 610
    .line 611
    fill-array-data v3, :array_4f0

    .line 612
    .line 613
    .line 614
    invoke-direct {v2, v3}, Li00/e;-><init>([J)V

    .line 615
    .line 616
    .line 617
    const-string v3, "gestureThresholdDeactivate"

    .line 618
    .line 619
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    const/16 v2, 0x1d

    .line 623
    .line 624
    const-string v3, "effectTick"

    .line 625
    .line 626
    const-string v4, "effectHeavyClick"

    .line 627
    .line 628
    const-string v5, "effectDoubleClick"

    .line 629
    .line 630
    const-string v6, "effectClick"

    .line 631
    .line 632
    if-lt v1, v2, :cond_29d

    .line 633
    .line 634
    new-instance v1, Li00/d;

    .line 635
    .line 636
    const/4 v2, 0x0

    .line 637
    invoke-direct {v1, v2}, Li00/d;-><init>(I)V

    .line 638
    .line 639
    .line 640
    invoke-virtual {v0, v6, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 641
    .line 642
    .line 643
    new-instance v1, Li00/d;

    .line 644
    .line 645
    const/4 v12, 0x1

    .line 646
    invoke-direct {v1, v12}, Li00/d;-><init>(I)V

    .line 647
    .line 648
    .line 649
    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 650
    .line 651
    .line 652
    new-instance v1, Li00/d;

    .line 653
    .line 654
    const/4 v2, 0x5

    .line 655
    invoke-direct {v1, v2}, Li00/d;-><init>(I)V

    .line 656
    .line 657
    .line 658
    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 659
    .line 660
    .line 661
    new-instance v1, Li00/d;

    .line 662
    .line 663
    invoke-direct {v1, v11}, Li00/d;-><init>(I)V

    .line 664
    .line 665
    .line 666
    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    return-void

    .line 670
    :cond_29d
    new-instance v1, Li00/e;

    .line 671
    .line 672
    new-array v2, v11, [J

    .line 673
    .line 674
    fill-array-data v2, :array_4fc

    .line 675
    .line 676
    .line 677
    invoke-direct {v1, v2}, Li00/e;-><init>([J)V

    .line 678
    .line 679
    .line 680
    invoke-virtual {v0, v6, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 681
    .line 682
    .line 683
    new-instance v1, Li00/e;

    .line 684
    .line 685
    const/4 v2, 0x4

    .line 686
    new-array v2, v2, [J

    .line 687
    .line 688
    fill-array-data v2, :array_508

    .line 689
    .line 690
    .line 691
    invoke-direct {v1, v2}, Li00/e;-><init>([J)V

    .line 692
    .line 693
    .line 694
    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 695
    .line 696
    .line 697
    new-instance v1, Li00/e;

    .line 698
    .line 699
    new-array v2, v11, [J

    .line 700
    .line 701
    fill-array-data v2, :array_51c

    .line 702
    .line 703
    .line 704
    invoke-direct {v1, v2}, Li00/e;-><init>([J)V

    .line 705
    .line 706
    .line 707
    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 708
    .line 709
    .line 710
    new-instance v1, Li00/e;

    .line 711
    .line 712
    new-array v2, v11, [J

    .line 713
    .line 714
    fill-array-data v2, :array_528

    .line 715
    .line 716
    .line 717
    invoke-direct {v1, v2}, Li00/e;-><init>([J)V

    .line 718
    .line 719
    .line 720
    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 721
    .line 722
    .line 723
    return-void

    .line 724
    nop

    .line 725
    :array_2d4
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    :array_2e0
    .array-data 8
        0x0
        0x28
    .end array-data

    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    :array_2ec
    .array-data 8
        0x0
        0x3c
    .end array-data

    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    :array_2f8
    .array-data 8
        0x0
        0x1e
    .end array-data

    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    :array_304
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    :array_310
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    :array_31c
    .array-data 8
        0x0
        0x28
        0x3c
        0x14
    .end array-data

    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    :array_330
    .array-data 8
        0x0
        0x14
        0x3c
        0x28
    .end array-data

    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    :array_344
    .array-data 8
        0x0
        0x14
        0x28
        0x1e
        0x28
        0x28
    .end array-data

    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    :array_360
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    :array_36c
    .array-data 8
        0x0
        0x28
    .end array-data

    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    :array_378
    .array-data 8
        0x0
        0x3c
    .end array-data

    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    :array_384
    .array-data 8
        0x0
        0x28
        0x3c
        0x14
    .end array-data

    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    :array_398
    .array-data 8
        0x0
        0x14
        0x3c
        0x28
    .end array-data

    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    :array_3ac
    .array-data 8
        0x0
        0x14
        0x28
        0x1e
        0x28
        0x28
    .end array-data

    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    :array_3c8
    .array-data 8
        0x0
        0x1e
    .end array-data

    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    :array_3d4
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    :array_3e0
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    :array_3ec
    .array-data 8
        0x0
        0xf
    .end array-data

    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    :array_3f8
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    :array_404
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    :array_410
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    :array_41c
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    :array_428
    .array-data 8
        0x0
        0x28
    .end array-data

    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    :array_434
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    :array_440
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    :array_44c
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    :array_458
    .array-data 8
        0x0
        0x28
        0x3c
        0x14
    .end array-data

    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    :array_46c
    .array-data 8
        0x0
        0x3c
        0x28
        0x1e
    .end array-data

    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    :array_480
    .array-data 8
        0x0
        0xf
    .end array-data

    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    :array_48c
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    :array_498
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    :array_4a4
    .array-data 8
        0x0
        0x8
    .end array-data

    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    :array_4b0
    .array-data 8
        0x0
        0xf
        0x1e
        0x19
    .end array-data

    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    :array_4c4
    .array-data 8
        0x0
        0x19
        0x1e
        0xf
    .end array-data

    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    :array_4d8
    .array-data 8
        0x0
        0xf
    .end array-data

    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    :array_4e4
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    :array_4f0
    .array-data 8
        0x0
        0xa
    .end array-data

    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    :array_4fc
    .array-data 8
        0x0
        0x14
    .end array-data

    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    :array_508
    .array-data 8
        0x0
        0x14
        0x28
        0x14
    .end array-data

    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    :array_51c
    .array-data 8
        0x0
        0x32
    .end array-data

    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    :array_528
    .array-data 8
        0x0
        0xf
    .end array-data
.end method

.method public static a(Landroid/os/Vibrator;Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    if-eqz v1, :cond_f1

    .line 6
    .line 7
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-nez v2, :cond_e

    .line 12
    .line 13
    goto/16 :goto_f1

    .line 14
    .line 15
    :cond_e
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    new-instance v3, Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-direct {v3, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 22
    .line 23
    .line 24
    const/4 v5, 0x0

    .line 25
    :goto_18
    if-ge v5, v2, :cond_26

    .line 26
    .line 27
    invoke-interface {v1, v5}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 28
    .line 29
    .line 30
    move-result-object v6

    .line 31
    if-eqz v6, :cond_23

    .line 32
    .line 33
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    :cond_23
    add-int/lit8 v5, v5, 0x1

    .line 37
    .line 38
    goto :goto_18

    .line 39
    :cond_26
    new-instance v1, La4/h;

    .line 40
    .line 41
    const/4 v2, 0x4

    .line 42
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 43
    .line 44
    .line 45
    invoke-static {v3, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    mul-int/lit8 v1, v1, 0x2

    .line 53
    .line 54
    new-array v2, v1, [J

    .line 55
    .line 56
    new-array v1, v1, [I

    .line 57
    .line 58
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    const/4 v7, 0x0

    .line 63
    const-wide/16 v8, 0x0

    .line 64
    .line 65
    :goto_40
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 66
    .line 67
    .line 68
    move-result v10

    .line 69
    if-eqz v10, :cond_ae

    .line 70
    .line 71
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v10

    .line 75
    check-cast v10, Lcom/facebook/react/bridge/ReadableMap;

    .line 76
    .line 77
    if-nez v10, :cond_4f

    .line 78
    .line 79
    goto :goto_40

    .line 80
    :cond_4f
    const-string v11, "time"

    .line 81
    .line 82
    invoke-interface {v10, v11}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 83
    .line 84
    .line 85
    move-result v12

    .line 86
    if-eqz v12, :cond_5d

    .line 87
    .line 88
    invoke-interface {v10, v11}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 89
    .line 90
    .line 91
    move-result-wide v11

    .line 92
    double-to-long v11, v11

    .line 93
    goto :goto_5f

    .line 94
    :cond_5d
    const-wide/16 v11, 0x0

    .line 95
    .line 96
    :goto_5f
    const-string v13, "duration"

    .line 97
    .line 98
    invoke-interface {v10, v13}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 99
    .line 100
    .line 101
    move-result v14

    .line 102
    if-eqz v14, :cond_6d

    .line 103
    .line 104
    invoke-interface {v10, v13}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 105
    .line 106
    .line 107
    move-result-wide v13

    .line 108
    double-to-long v13, v13

    .line 109
    goto :goto_6f

    .line 110
    :cond_6d
    const-wide/16 v13, 0x32

    .line 111
    .line 112
    :goto_6f
    const-string v15, "intensity"

    .line 113
    .line 114
    invoke-interface {v10, v15}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 115
    .line 116
    .line 117
    move-result v16

    .line 118
    if-eqz v16, :cond_7c

    .line 119
    .line 120
    invoke-interface {v10, v15}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 121
    .line 122
    .line 123
    move-result-wide v15

    .line 124
    goto :goto_7e

    .line 125
    :cond_7c
    const-wide/high16 v15, 0x3fe0000000000000L    # 0.5

    .line 126
    .line 127
    :goto_7e
    const-wide v17, 0x406fe00000000000L    # 255.0

    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    mul-double v15, v15, v17

    .line 133
    .line 134
    const/4 v10, 0x0

    .line 135
    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->round(D)J

    .line 136
    .line 137
    .line 138
    move-result-wide v4

    .line 139
    long-to-int v4, v4

    .line 140
    sub-long v5, v11, v8

    .line 141
    .line 142
    const-wide/16 v8, 0x0

    .line 143
    .line 144
    invoke-static {v8, v9, v5, v6}, Ljava/lang/Math;->max(JJ)J

    .line 145
    .line 146
    .line 147
    move-result-wide v5

    .line 148
    aput-wide v5, v2, v7

    .line 149
    .line 150
    aput v10, v1, v7

    .line 151
    .line 152
    add-int/lit8 v5, v7, 0x1

    .line 153
    .line 154
    aput-wide v13, v2, v5

    .line 155
    .line 156
    const/16 v6, 0xff

    .line 157
    .line 158
    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    .line 159
    .line 160
    .line 161
    move-result v4

    .line 162
    const/4 v6, 0x1

    .line 163
    invoke-static {v6, v4}, Ljava/lang/Math;->max(II)I

    .line 164
    .line 165
    .line 166
    move-result v4

    .line 167
    aput v4, v1, v5

    .line 168
    .line 169
    add-int/lit8 v7, v7, 0x2

    .line 170
    .line 171
    add-long v4, v11, v13

    .line 172
    .line 173
    move-wide v8, v4

    .line 174
    goto :goto_40

    .line 175
    :cond_ae
    const/4 v10, 0x0

    .line 176
    new-array v3, v7, [J

    .line 177
    .line 178
    new-array v4, v7, [I

    .line 179
    .line 180
    invoke-static {v2, v10, v3, v10, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 181
    .line 182
    .line 183
    invoke-static {v1, v10, v4, v10, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 184
    .line 185
    .line 186
    :try_start_b9
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 187
    .line 188
    const/16 v2, 0x21

    .line 189
    .line 190
    const/4 v5, -0x1

    .line 191
    if-lt v1, v2, :cond_d9

    .line 192
    .line 193
    invoke-static {v3, v4, v5}, Landroid/os/VibrationEffect;->createWaveform([J[II)Landroid/os/VibrationEffect;

    .line 194
    .line 195
    .line 196
    move-result-object v1

    .line 197
    new-instance v2, Landroid/os/VibrationAttributes$Builder;

    .line 198
    .line 199
    new-instance v2, Landroid/os/VibrationAttributes$Builder;

    .line 200
    .line 201
    invoke-direct {v2}, Landroid/os/VibrationAttributes$Builder;-><init>()V

    .line 202
    .line 203
    .line 204
    const/16 v3, 0x12

    .line 205
    .line 206
    invoke-virtual {v2, v3}, Landroid/os/VibrationAttributes$Builder;->setUsage(I)Landroid/os/VibrationAttributes$Builder;

    .line 207
    .line 208
    .line 209
    move-result-object v2

    .line 210
    invoke-virtual {v2}, Landroid/os/VibrationAttributes$Builder;->build()Landroid/os/VibrationAttributes;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    invoke-virtual {v0, v1, v2}, Landroid/os/Vibrator;->vibrate(Landroid/os/VibrationEffect;Landroid/os/VibrationAttributes;)V

    .line 215
    .line 216
    .line 217
    return-void

    .line 218
    :cond_d9
    const/16 v2, 0x1a

    .line 219
    .line 220
    if-lt v1, v2, :cond_e5

    .line 221
    .line 222
    invoke-static {v3, v4, v5}, Landroid/os/VibrationEffect;->createWaveform([J[II)Landroid/os/VibrationEffect;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    invoke-virtual {v0, v1}, Landroid/os/Vibrator;->vibrate(Landroid/os/VibrationEffect;)V

    .line 227
    .line 228
    .line 229
    return-void

    .line 230
    :cond_e5
    invoke-virtual {v0, v3, v5}, Landroid/os/Vibrator;->vibrate([JI)V
    :try_end_e8
    .catch Ljava/lang/Exception; {:try_start_b9 .. :try_end_e8} :catch_e9

    .line 231
    .line 232
    .line 233
    return-void

    .line 234
    :catch_e9
    move-exception v0

    .line 235
    const-string v1, "RNHapticFeedback"

    .line 236
    .line 237
    const-string v2, "vibratePattern failed"

    .line 238
    .line 239
    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 240
    .line 241
    .line 242
    :cond_f1
    :goto_f1
    return-void
.end method
