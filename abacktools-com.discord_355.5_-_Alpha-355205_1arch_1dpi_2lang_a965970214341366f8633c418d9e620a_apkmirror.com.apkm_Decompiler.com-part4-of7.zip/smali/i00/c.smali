###### Class i00.c (i00.c)
.class public final Li00/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li00/a;


# instance fields
.field public final a:I

.field public final b:F

.field public final c:Li00/e;


# direct methods
.method public constructor <init>(IFLi00/e;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Li00/c;->a:I

    .line 5
    .line 6
    iput p2, p0, Li00/c;->b:F

    .line 7
    .line 8
    iput-object p3, p0, Li00/c;->c:Li00/e;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Landroid/os/Vibrator;)V
    .registers 6

    .line 1
    iget v0, p0, Li00/c;->a:I

    .line 2
    .line 3
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 4
    .line 5
    const/16 v2, 0x1f

    .line 6
    .line 7
    if-ge v1, v2, :cond_9

    .line 8
    .line 9
    return-void

    .line 10
    :cond_9
    :try_start_9
    invoke-virtual {p1}, Landroid/os/Vibrator;->hasVibrator()Z

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    if-eqz v2, :cond_50

    .line 15
    .line 16
    filled-new-array {v0}, [I

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {p1, v2}, Landroid/os/Vibrator;->arePrimitivesSupported([I)[Z

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    const/4 v3, 0x0

    .line 25
    aget-boolean v2, v2, v3

    .line 26
    .line 27
    if-eqz v2, :cond_50

    .line 28
    .line 29
    invoke-static {}, Landroid/os/VibrationEffect;->startComposition()Landroid/os/VibrationEffect$Composition;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    iget v3, p0, Li00/c;->b:F

    .line 34
    .line 35
    invoke-virtual {v2, v0, v3}, Landroid/os/VibrationEffect$Composition;->addPrimitive(IF)Landroid/os/VibrationEffect$Composition;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, Landroid/os/VibrationEffect$Composition;->compose()Landroid/os/VibrationEffect;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    const/16 v2, 0x21

    .line 44
    .line 45
    if-lt v1, v2, :cond_45

    .line 46
    .line 47
    new-instance v1, Landroid/os/VibrationAttributes$Builder;

    .line 48
    .line 49
    new-instance v1, Landroid/os/VibrationAttributes$Builder;

    .line 50
    .line 51
    invoke-direct {v1}, Landroid/os/VibrationAttributes$Builder;-><init>()V

    .line 52
    .line 53
    .line 54
    const/16 v2, 0x12

    .line 55
    .line 56
    invoke-virtual {v1, v2}, Landroid/os/VibrationAttributes$Builder;->setUsage(I)Landroid/os/VibrationAttributes$Builder;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    invoke-virtual {v1}, Landroid/os/VibrationAttributes$Builder;->build()Landroid/os/VibrationAttributes;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-virtual {p1, v0, v1}, Landroid/os/Vibrator;->vibrate(Landroid/os/VibrationEffect;Landroid/os/VibrationAttributes;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :catch_43
    move-exception v0

    .line 69
    goto :goto_49

    .line 70
    :cond_45
    invoke-virtual {p1, v0}, Landroid/os/Vibrator;->vibrate(Landroid/os/VibrationEffect;)V
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_48} :catch_43

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :goto_49
    const-string v1, "RNHapticFeedback"

    .line 75
    .line 76
    const-string v2, "VibrateWithComposition failed"

    .line 77
    .line 78
    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 79
    .line 80
    .line 81
    :cond_50
    iget-object v0, p0, Li00/c;->c:Li00/e;

    .line 82
    .line 83
    invoke-virtual {v0, p1}, Li00/e;->a(Landroid/os/Vibrator;)V

    .line 84
    .line 85
    .line 86
    return-void
.end method
