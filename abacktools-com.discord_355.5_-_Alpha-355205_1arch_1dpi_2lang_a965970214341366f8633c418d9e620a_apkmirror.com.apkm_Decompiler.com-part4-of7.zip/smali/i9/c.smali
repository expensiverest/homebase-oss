###### Class i9.c (i9.c)
.class public final synthetic Li9/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcom/discord/browser_manager/BrowserManagerModule;


# direct methods
.method public synthetic constructor <init>(Lcom/discord/browser_manager/BrowserManagerModule;I)V
    .registers 3

    .line 1
    iput p2, p0, Li9/c;->d:I

    iput-object p1, p0, Li9/c;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 1
    iget v0, p0, Li9/c;->d:I

    packed-switch v0, :pswitch_data_14

    iget-object v0, p0, Li9/c;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    invoke-static {v0}, Lcom/discord/browser_manager/BrowserManagerModule;->c(Lcom/discord/browser_manager/BrowserManagerModule;)Ll30/a0;

    move-result-object v0

    return-object v0

    :pswitch_c
    iget-object v0, p0, Li9/c;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    invoke-static {v0}, Lcom/discord/browser_manager/BrowserManagerModule;->g(Lcom/discord/browser_manager/BrowserManagerModule;)Ll30/a0;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_c
    .end packed-switch
.end method
