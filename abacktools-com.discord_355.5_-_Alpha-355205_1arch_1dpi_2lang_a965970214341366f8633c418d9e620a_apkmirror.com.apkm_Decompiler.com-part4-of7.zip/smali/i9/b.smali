###### Class i9.b (i9.b)
.class public final synthetic Li9/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcom/discord/browser_manager/BrowserManagerModule;

.field public final synthetic i:Li9/e;

.field public final synthetic v:Lcom/facebook/react/bridge/Promise;


# direct methods
.method public synthetic constructor <init>(Lcom/discord/browser_manager/BrowserManagerModule;Li9/e;Lcom/facebook/react/bridge/Promise;)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Li9/b;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li9/b;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    iput-object p2, p0, Li9/b;->i:Li9/e;

    iput-object p3, p0, Li9/b;->v:Lcom/facebook/react/bridge/Promise;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/facebook/react/bridge/Promise;Lcom/discord/browser_manager/BrowserManagerModule;Li9/e;)V
    .registers 5

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Li9/b;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li9/b;->v:Lcom/facebook/react/bridge/Promise;

    iput-object p2, p0, Li9/b;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    iput-object p3, p0, Li9/b;->i:Li9/e;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Li9/b;->d:I

    packed-switch v0, :pswitch_data_24

    iget-object v0, p0, Li9/b;->v:Lcom/facebook/react/bridge/Promise;

    check-cast p1, Ljava/lang/Exception;

    iget-object v1, p0, Li9/b;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    iget-object v2, p0, Li9/b;->i:Li9/e;

    invoke-static {v1, v2, v0, p1}, Lcom/discord/browser_manager/BrowserManagerModule;->d(Lcom/discord/browser_manager/BrowserManagerModule;Li9/e;Lcom/facebook/react/bridge/Promise;Ljava/lang/Exception;)Ll30/a0;

    move-result-object p1

    return-object p1

    :pswitch_12
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iget-object v0, p0, Li9/b;->v:Lcom/facebook/react/bridge/Promise;

    iget-object v1, p0, Li9/b;->e:Lcom/discord/browser_manager/BrowserManagerModule;

    iget-object v2, p0, Li9/b;->i:Li9/e;

    invoke-static {v0, v1, v2, p1}, Lcom/discord/browser_manager/BrowserManagerModule;->i(Lcom/facebook/react/bridge/Promise;Lcom/discord/browser_manager/BrowserManagerModule;Li9/e;Z)Ll30/a0;

    move-result-object p1

    return-object p1

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_12
    .end packed-switch
.end method
