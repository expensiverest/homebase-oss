###### Class i9.a (i9.a)
.class public final Li9/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Li9/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Li9/a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Li9/a;->a:Li9/a;

    .line 7
    .line 8
    return-void
.end method

.method public static b(Li9/a;Landroid/content/Context;Landroid/net/Uri;Lkotlin/jvm/functions/Function1;)V
    .registers 7

    .line 1
    new-instance p0, Landroid/content/Intent;

    .line 2
    .line 3
    const-string v0, "android.intent.action.VIEW"

    .line 4
    .line 5
    invoke-direct {p0, v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 6
    .line 7
    .line 8
    const/high16 p2, 0x10000000

    .line 9
    .line 10
    invoke-virtual {p0, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    const-string p2, "addFlags(...)"

    .line 15
    .line 16
    invoke-static {p0, p2}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    const/4 v0, 0x0

    .line 24
    invoke-virtual {p2, p0, v0}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    const-string v0, "queryIntentActivities(...)"

    .line 29
    .line 30
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-static {p2}, Lm30/q;->g0(Ljava/lang/Iterable;)Landroidx/core/view/c1;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    new-instance v0, Lh9/e;

    .line 38
    .line 39
    const/16 v1, 0x9

    .line 40
    .line 41
    invoke-direct {v0, v1}, Lh9/e;-><init>(I)V

    .line 42
    .line 43
    .line 44
    invoke-static {p2, v0}, Lv60/m;->J0(Lv60/k;Lkotlin/jvm/functions/Function1;)Lv60/g;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    new-instance v0, Lb10/c;

    .line 49
    .line 50
    const/16 v1, 0x13

    .line 51
    .line 52
    invoke-direct {v0, v1, p1}, Lb10/c;-><init>(ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    new-instance v1, Lv60/g;

    .line 56
    .line 57
    const/4 v2, 0x1

    .line 58
    invoke-direct {v1, p2, v2, v0}, Lv60/g;-><init>(Lv60/k;ZLkotlin/jvm/functions/Function1;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v1}, Lv60/m;->D0(Lv60/k;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p2

    .line 65
    check-cast p2, Ljava/lang/String;

    .line 66
    .line 67
    invoke-virtual {p0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 68
    .line 69
    .line 70
    invoke-static {p1, p0}, Lig/b;->b(Landroid/content/Context;Landroid/content/Intent;)Ljava/util/concurrent/CompletableFuture;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    new-instance p1, Lcd/c;

    .line 75
    .line 76
    const/4 p2, 0x2

    .line 77
    invoke-direct {p1, p2, p3}, Lcd/c;-><init>(ILjava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0, p1}, Ljava/util/concurrent/CompletableFuture;->exceptionally(Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture;

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public static c(Landroid/content/ContextWrapper;Landroid/net/Uri;Lad/d;)V
    .registers 8

    .line 1
    const v0, 0x7f06084f

    .line 2
    .line 3
    .line 4
    const v1, 0x7f060771

    .line 5
    .line 6
    .line 7
    invoke-static {p0, v0, v1}, Lkk/c;->f(Landroid/content/Context;II)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const-string v1, "uri"

    .line 12
    .line 13
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-static {p0}, Lcd/a;->a(Landroid/content/ContextWrapper;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-eqz v1, :cond_58

    .line 21
    .line 22
    const/high16 v1, -0x1000000

    .line 23
    .line 24
    or-int/2addr v1, v0

    .line 25
    new-instance v2, Llm/a;

    .line 26
    .line 27
    invoke-direct {v2}, Llm/a;-><init>()V

    .line 28
    .line 29
    .line 30
    new-instance v3, Landroid/os/Bundle;

    .line 31
    .line 32
    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 33
    .line 34
    .line 35
    const-string v4, "android.support.customtabs.extra.TOOLBAR_COLOR"

    .line 36
    .line 37
    invoke-virtual {v3, v4, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 38
    .line 39
    .line 40
    const-string v4, "android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR"

    .line 41
    .line 42
    invoke-virtual {v3, v4, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 43
    .line 44
    .line 45
    const-string v0, "androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR"

    .line 46
    .line 47
    invoke-virtual {v3, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 48
    .line 49
    .line 50
    iput-object v3, v2, Llm/a;->f:Ljava/lang/Object;

    .line 51
    .line 52
    iget-object v0, v2, Llm/a;->c:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v0, Landroid/content/Intent;

    .line 55
    .line 56
    const-string v1, "android.support.customtabs.extra.TITLE_VISIBILITY"

    .line 57
    .line 58
    const/4 v3, 0x0

    .line 59
    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v2}, Llm/a;->l()Lk7/l;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    iget-object v1, v0, Lk7/l;->d:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v1, Landroid/content/Intent;

    .line 69
    .line 70
    :try_start_45
    invoke-virtual {v1, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v1, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 74
    .line 75
    .line 76
    iget-object p1, v0, Lk7/l;->e:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast p1, Landroid/os/Bundle;

    .line 79
    .line 80
    invoke-virtual {p0, v1, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V
    :try_end_52
    .catch Landroid/content/ActivityNotFoundException; {:try_start_45 .. :try_end_52} :catch_53

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :catch_53
    move-exception p0

    .line 85
    invoke-virtual {p2, p0}, Lad/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_58
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 90
    .line 91
    const-string p1, "Unable to find custom tabs package."

    .line 92
    .line 93
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p2, p0}, Lad/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    return-void
.end method


# virtual methods
.method public final a(Lcom/facebook/react/bridge/ReactApplicationContext;Ljava/lang/String;Li9/b;Li9/b;)V
    .registers 19

    .line 1
    invoke-static/range {p2 .. p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1}, Lcom/facebook/react/bridge/ReactContext;->getCurrentActivity()Landroid/app/Activity;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-nez v1, :cond_19

    .line 10
    .line 11
    move-object/from16 v4, p2

    .line 12
    .line 13
    move-object/from16 v5, p4

    .line 14
    .line 15
    invoke-virtual {p0, p1, v4, v5}, Li9/a;->d(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 16
    .line 17
    .line 18
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 19
    .line 20
    move-object/from16 v6, p3

    .line 21
    .line 22
    invoke-virtual {v6, p1}, Li9/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_19
    move-object/from16 v4, p2

    .line 27
    .line 28
    move-object/from16 v6, p3

    .line 29
    .line 30
    move-object/from16 v5, p4

    .line 31
    .line 32
    new-instance v12, Landroid/content/Intent;

    .line 33
    .line 34
    const-string v2, "android.intent.action.VIEW"

    .line 35
    .line 36
    invoke-direct {v12, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    const-string v2, "com.android.vending"

    .line 40
    .line 41
    invoke-virtual {v12, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v12, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 45
    .line 46
    .line 47
    const-string v0, "overlay"

    .line 48
    .line 49
    const/4 v2, 0x1

    .line 50
    invoke-virtual {v12, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 51
    .line 52
    .line 53
    const-string v0, "callerId"

    .line 54
    .line 55
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-virtual {v12, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 60
    .line 61
    .line 62
    new-instance v11, Ljava/util/concurrent/CompletableFuture;

    .line 63
    .line 64
    invoke-direct {v11}, Ljava/util/concurrent/CompletableFuture;-><init>()V

    .line 65
    .line 66
    .line 67
    new-instance v10, Ljava/lang/ref/WeakReference;

    .line 68
    .line 69
    invoke-direct {v10, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    new-instance v7, Lig/a;

    .line 73
    .line 74
    const/4 v9, 0x0

    .line 75
    const v8, 0x3951d

    .line 76
    .line 77
    .line 78
    const/4 v13, 0x0

    .line 79
    invoke-direct/range {v7 .. v13}, Lig/a;-><init>(IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1, v7}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 83
    .line 84
    .line 85
    new-instance v2, Lcom/margelo/nitro/nitrofetch/t;

    .line 86
    .line 87
    const/4 v7, 0x2

    .line 88
    move-object v3, p1

    .line 89
    invoke-direct/range {v2 .. v7}, Lcom/margelo/nitro/nitrofetch/t;-><init>(Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 90
    .line 91
    .line 92
    new-instance p1, Lcom/margelo/nitro/nitrofetch/l;

    .line 93
    .line 94
    const/4 v0, 0x3

    .line 95
    invoke-direct {p1, v2, v0}, Lcom/margelo/nitro/nitrofetch/l;-><init>(Lkotlin/jvm/functions/Function2;I)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v11, p1}, Ljava/util/concurrent/CompletableFuture;->whenComplete(Ljava/util/function/BiConsumer;)Ljava/util/concurrent/CompletableFuture;

    .line 99
    .line 100
    .line 101
    return-void
.end method

.method public final d(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .registers 5

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    :try_start_5
    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    invoke-static {p0, p1, p2, p3}, Li9/a;->b(Li9/a;Landroid/content/Context;Landroid/net/Uri;Lkotlin/jvm/functions/Function1;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_c} :catch_d

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :catch_d
    move-exception p1

    .line 15
    invoke-interface {p3, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    return-void
.end method
