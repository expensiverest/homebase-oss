###### Class i9.e (i9.e)
.class public final Li9/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/react/bridge/ActivityEventListener;


# instance fields
.field public final synthetic d:Lcom/discord/browser_manager/BrowserManagerModule;

.field public final synthetic e:Lcom/facebook/react/bridge/Callback;


# direct methods
.method public constructor <init>(Lcom/discord/browser_manager/BrowserManagerModule;Lcom/facebook/react/bridge/Callback;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li9/e;->d:Lcom/discord/browser_manager/BrowserManagerModule;

    .line 5
    .line 6
    iput-object p2, p0, Li9/e;->e:Lcom/facebook/react/bridge/Callback;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onActivityResult(Landroid/app/Activity;IILandroid/content/Intent;)V
    .registers 5

    .line 1
    const-string p3, "activity"

    .line 2
    .line 3
    invoke-static {p1, p3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const p1, 0x3951d

    .line 7
    .line 8
    .line 9
    if-ne p2, p1, :cond_1b

    .line 10
    .line 11
    iget-object p1, p0, Li9/e;->d:Lcom/discord/browser_manager/BrowserManagerModule;

    .line 12
    .line 13
    invoke-virtual {p1}, Lcom/discord/browser_manager/BrowserManagerModule;->getReactContext()Lcom/facebook/react/bridge/ReactApplicationContext;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p1, p0}, Lcom/facebook/react/bridge/ReactContext;->removeActivityEventListener(Lcom/facebook/react/bridge/ActivityEventListener;)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    new-array p1, p1, [Ljava/lang/Object;

    .line 22
    .line 23
    iget-object p2, p0, Li9/e;->e:Lcom/facebook/react/bridge/Callback;

    .line 24
    .line 25
    invoke-interface {p2, p1}, Lcom/facebook/react/bridge/Callback;->invoke([Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .registers 3

    .line 1
    const-string v0, "intent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method
