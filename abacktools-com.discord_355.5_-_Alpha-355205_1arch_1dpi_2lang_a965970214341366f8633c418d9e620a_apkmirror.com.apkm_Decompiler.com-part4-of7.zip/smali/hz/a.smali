###### Class hz.a (hz.a)
.class public final Lhz/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lny/j;


# static fields
.field public static final b:[Lny/n;


# instance fields
.field public final a:Liz/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lny/n;

    .line 3
    .line 4
    sput-object v0, Lhz/a;->b:[Lny/n;

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Liz/b;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Liz/b;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lhz/a;->a:Liz/b;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(Lk7/r;Ljava/util/Map;)Lny/l;
    .registers 44

    .line 1
    move-object/from16 v0, p2

    .line 2
    .line 3
    const/4 v2, 0x3

    .line 4
    move-object/from16 v3, p0

    .line 5
    .line 6
    iget-object v4, v3, Lhz/a;->a:Liz/b;

    .line 7
    .line 8
    const/4 v6, 0x5

    .line 9
    const/4 v7, 0x1

    .line 10
    const/4 v8, 0x0

    .line 11
    if-eqz v0, :cond_e8

    .line 12
    .line 13
    sget-object v9, Lny/c;->d:Lny/c;

    .line 14
    .line 15
    invoke-interface {v0, v9}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v9

    .line 19
    if-eqz v9, :cond_e8

    .line 20
    .line 21
    invoke-virtual/range {p1 .. p1}, Lk7/r;->B()Lry/b;

    .line 22
    .line 23
    .line 24
    move-result-object v9

    .line 25
    invoke-virtual {v9}, Lry/b;->e()[I

    .line 26
    .line 27
    .line 28
    move-result-object v10

    .line 29
    iget v11, v9, Lry/b;->d:I

    .line 30
    .line 31
    invoke-virtual {v9}, Lry/b;->c()[I

    .line 32
    .line 33
    .line 34
    move-result-object v12

    .line 35
    if-eqz v10, :cond_e5

    .line 36
    .line 37
    if-eqz v12, :cond_e5

    .line 38
    .line 39
    iget v13, v9, Lry/b;->e:I

    .line 40
    .line 41
    aget v14, v10, v8

    .line 42
    .line 43
    aget v15, v10, v7

    .line 44
    .line 45
    move v5, v7

    .line 46
    move/from16 v17, v8

    .line 47
    .line 48
    const/high16 v16, 0x40000000    # 2.0f

    .line 49
    .line 50
    :goto_31
    if-ge v14, v11, :cond_4c

    .line 51
    .line 52
    if-ge v15, v13, :cond_4c

    .line 53
    .line 54
    move/from16 v18, v8

    .line 55
    .line 56
    invoke-virtual {v9, v14, v15}, Lry/b;->b(II)Z

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    if-eq v5, v8, :cond_45

    .line 61
    .line 62
    add-int/lit8 v8, v17, 0x1

    .line 63
    .line 64
    if-eq v8, v6, :cond_4e

    .line 65
    .line 66
    xor-int/lit8 v5, v5, 0x1

    .line 67
    .line 68
    move/from16 v17, v8

    .line 69
    .line 70
    :cond_45
    add-int/lit8 v14, v14, 0x1

    .line 71
    .line 72
    add-int/lit8 v15, v15, 0x1

    .line 73
    .line 74
    move/from16 v8, v18

    .line 75
    .line 76
    goto :goto_31

    .line 77
    :cond_4c
    move/from16 v18, v8

    .line 78
    .line 79
    :cond_4e
    if-eq v14, v11, :cond_e2

    .line 80
    .line 81
    if-eq v15, v13, :cond_e2

    .line 82
    .line 83
    aget v5, v10, v18

    .line 84
    .line 85
    sub-int/2addr v14, v5

    .line 86
    int-to-float v6, v14

    .line 87
    const/high16 v8, 0x40e00000    # 7.0f

    .line 88
    .line 89
    div-float/2addr v6, v8

    .line 90
    aget v8, v10, v7

    .line 91
    .line 92
    aget v10, v12, v7

    .line 93
    .line 94
    aget v12, v12, v18

    .line 95
    .line 96
    if-ge v5, v12, :cond_df

    .line 97
    .line 98
    if-ge v8, v10, :cond_df

    .line 99
    .line 100
    sub-int v13, v10, v8

    .line 101
    .line 102
    sub-int v14, v12, v5

    .line 103
    .line 104
    if-eq v13, v14, :cond_71

    .line 105
    .line 106
    add-int v12, v5, v13

    .line 107
    .line 108
    if-ge v12, v11, :cond_6e

    .line 109
    .line 110
    goto :goto_71

    .line 111
    :cond_6e
    sget-object v0, Lny/h;->i:Lny/h;

    .line 112
    .line 113
    throw v0

    .line 114
    :cond_71
    :goto_71
    sub-int v11, v12, v5

    .line 115
    .line 116
    add-int/2addr v11, v7

    .line 117
    int-to-float v11, v11

    .line 118
    div-float/2addr v11, v6

    .line 119
    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    .line 120
    .line 121
    .line 122
    move-result v11

    .line 123
    add-int/2addr v13, v7

    .line 124
    int-to-float v7, v13

    .line 125
    div-float/2addr v7, v6

    .line 126
    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    .line 127
    .line 128
    .line 129
    move-result v7

    .line 130
    if-lez v11, :cond_dc

    .line 131
    .line 132
    if-lez v7, :cond_dc

    .line 133
    .line 134
    if-ne v7, v11, :cond_d9

    .line 135
    .line 136
    div-float v13, v6, v16

    .line 137
    .line 138
    float-to-int v13, v13

    .line 139
    add-int/2addr v8, v13

    .line 140
    add-int/2addr v5, v13

    .line 141
    add-int/lit8 v14, v11, -0x1

    .line 142
    .line 143
    int-to-float v14, v14

    .line 144
    mul-float/2addr v14, v6

    .line 145
    float-to-int v14, v14

    .line 146
    add-int/2addr v14, v5

    .line 147
    sub-int/2addr v14, v12

    .line 148
    if-lez v14, :cond_9c

    .line 149
    .line 150
    if-gt v14, v13, :cond_99

    .line 151
    .line 152
    sub-int/2addr v5, v14

    .line 153
    goto :goto_9c

    .line 154
    :cond_99
    sget-object v0, Lny/h;->i:Lny/h;

    .line 155
    .line 156
    throw v0

    .line 157
    :cond_9c
    :goto_9c
    add-int/lit8 v12, v7, -0x1

    .line 158
    .line 159
    int-to-float v12, v12

    .line 160
    mul-float/2addr v12, v6

    .line 161
    float-to-int v12, v12

    .line 162
    add-int/2addr v12, v8

    .line 163
    sub-int/2addr v12, v10

    .line 164
    if-lez v12, :cond_ac

    .line 165
    .line 166
    if-gt v12, v13, :cond_a9

    .line 167
    .line 168
    sub-int/2addr v8, v12

    .line 169
    goto :goto_ac

    .line 170
    :cond_a9
    sget-object v0, Lny/h;->i:Lny/h;

    .line 171
    .line 172
    throw v0

    .line 173
    :cond_ac
    :goto_ac
    new-instance v10, Lry/b;

    .line 174
    .line 175
    invoke-direct {v10, v11, v7}, Lry/b;-><init>(II)V

    .line 176
    .line 177
    .line 178
    move/from16 v12, v18

    .line 179
    .line 180
    :goto_b3
    if-ge v12, v7, :cond_d0

    .line 181
    .line 182
    int-to-float v13, v12

    .line 183
    mul-float/2addr v13, v6

    .line 184
    float-to-int v13, v13

    .line 185
    add-int/2addr v13, v8

    .line 186
    move/from16 v14, v18

    .line 187
    .line 188
    :goto_bb
    if-ge v14, v11, :cond_cd

    .line 189
    .line 190
    int-to-float v15, v14

    .line 191
    mul-float/2addr v15, v6

    .line 192
    float-to-int v15, v15

    .line 193
    add-int/2addr v15, v5

    .line 194
    invoke-virtual {v9, v15, v13}, Lry/b;->b(II)Z

    .line 195
    .line 196
    .line 197
    move-result v15

    .line 198
    if-eqz v15, :cond_ca

    .line 199
    .line 200
    invoke-virtual {v10, v14, v12}, Lry/b;->f(II)V

    .line 201
    .line 202
    .line 203
    :cond_ca
    add-int/lit8 v14, v14, 0x1

    .line 204
    .line 205
    goto :goto_bb

    .line 206
    :cond_cd
    add-int/lit8 v12, v12, 0x1

    .line 207
    .line 208
    goto :goto_b3

    .line 209
    :cond_d0
    invoke-virtual {v4, v10, v0}, Liz/b;->c(Lry/b;Ljava/util/Map;)Lrx/a;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    sget-object v4, Lhz/a;->b:[Lny/n;

    .line 214
    .line 215
    move v10, v2

    .line 216
    goto/16 :goto_412

    .line 217
    .line 218
    :cond_d9
    sget-object v0, Lny/h;->i:Lny/h;

    .line 219
    .line 220
    throw v0

    .line 221
    :cond_dc
    sget-object v0, Lny/h;->i:Lny/h;

    .line 222
    .line 223
    throw v0

    .line 224
    :cond_df
    sget-object v0, Lny/h;->i:Lny/h;

    .line 225
    .line 226
    throw v0

    .line 227
    :cond_e2
    sget-object v0, Lny/h;->i:Lny/h;

    .line 228
    .line 229
    throw v0

    .line 230
    :cond_e5
    sget-object v0, Lny/h;->i:Lny/h;

    .line 231
    .line 232
    throw v0

    .line 233
    :cond_e8
    move/from16 v18, v8

    .line 234
    .line 235
    const/high16 v16, 0x40000000    # 2.0f

    .line 236
    .line 237
    new-instance v5, Landroidx/core/view/d0;

    .line 238
    .line 239
    invoke-virtual/range {p1 .. p1}, Lk7/r;->B()Lry/b;

    .line 240
    .line 241
    .line 242
    move-result-object v8

    .line 243
    invoke-direct {v5, v8}, Landroidx/core/view/d0;-><init>(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    if-nez v0, :cond_f8

    .line 247
    .line 248
    goto :goto_100

    .line 249
    :cond_f8
    sget-object v9, Lny/c;->K:Lny/c;

    .line 250
    .line 251
    invoke-interface {v0, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v9

    .line 255
    if-nez v9, :cond_476

    .line 256
    .line 257
    :goto_100
    new-instance v9, Lcom/google/firebase/messaging/o;

    .line 258
    .line 259
    const/4 v10, 0x6

    .line 260
    invoke-direct {v9, v8, v10}, Lcom/google/firebase/messaging/o;-><init>(Lry/b;I)V

    .line 261
    .line 262
    .line 263
    iget-object v11, v9, Lcom/google/firebase/messaging/o;->i:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast v11, Ljava/util/ArrayList;

    .line 266
    .line 267
    if-eqz v0, :cond_116

    .line 268
    .line 269
    sget-object v12, Lny/c;->i:Lny/c;

    .line 270
    .line 271
    invoke-interface {v0, v12}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v12

    .line 275
    if-eqz v12, :cond_116

    .line 276
    .line 277
    move v12, v7

    .line 278
    goto :goto_118

    .line 279
    :cond_116
    move/from16 v12, v18

    .line 280
    .line 281
    :goto_118
    iget v13, v8, Lry/b;->e:I

    .line 282
    .line 283
    iget v14, v8, Lry/b;->d:I

    .line 284
    .line 285
    mul-int/lit8 v15, v13, 0x3

    .line 286
    .line 287
    div-int/lit16 v15, v15, 0x184

    .line 288
    .line 289
    if-lt v15, v2, :cond_124

    .line 290
    .line 291
    if-eqz v12, :cond_125

    .line 292
    .line 293
    :cond_124
    move v15, v2

    .line 294
    :cond_125
    new-array v6, v6, [I

    .line 295
    .line 296
    add-int/lit8 v12, v15, -0x1

    .line 297
    .line 298
    move/from16 p1, v10

    .line 299
    .line 300
    move/from16 v17, v18

    .line 301
    .line 302
    :goto_12d
    const/16 v19, 0x0

    .line 303
    .line 304
    if-ge v12, v13, :cond_238

    .line 305
    .line 306
    if-nez v17, :cond_238

    .line 307
    .line 308
    invoke-static {v6}, Lcom/google/firebase/messaging/o;->c([I)V

    .line 309
    .line 310
    .line 311
    move/from16 v20, v2

    .line 312
    .line 313
    move/from16 v1, v18

    .line 314
    .line 315
    move v2, v1

    .line 316
    :goto_13b
    if-ge v2, v14, :cond_217

    .line 317
    .line 318
    invoke-virtual {v8, v2, v12}, Lry/b;->b(II)Z

    .line 319
    .line 320
    .line 321
    move-result v22

    .line 322
    if-eqz v22, :cond_152

    .line 323
    .line 324
    and-int/lit8 v10, v1, 0x1

    .line 325
    .line 326
    if-ne v10, v7, :cond_149

    .line 327
    .line 328
    add-int/lit8 v1, v1, 0x1

    .line 329
    .line 330
    :cond_149
    aget v10, v6, v1

    .line 331
    .line 332
    add-int/2addr v10, v7

    .line 333
    aput v10, v6, v1

    .line 334
    .line 335
    move/from16 v23, v7

    .line 336
    .line 337
    goto/16 :goto_212

    .line 338
    .line 339
    :cond_152
    and-int/lit8 v10, v1, 0x1

    .line 340
    .line 341
    if-nez v10, :cond_20a

    .line 342
    .line 343
    const/4 v10, 0x4

    .line 344
    if-ne v1, v10, :cond_1ff

    .line 345
    .line 346
    invoke-static {v6}, Lcom/google/firebase/messaging/o;->q([I)Z

    .line 347
    .line 348
    .line 349
    move-result v1

    .line 350
    if-eqz v1, :cond_1e8

    .line 351
    .line 352
    invoke-virtual {v9, v12, v2, v6}, Lcom/google/firebase/messaging/o;->s(II[I)Z

    .line 353
    .line 354
    .line 355
    move-result v1

    .line 356
    if-eqz v1, :cond_1cf

    .line 357
    .line 358
    iget-boolean v1, v9, Lcom/google/firebase/messaging/o;->d:Z

    .line 359
    .line 360
    if-eqz v1, :cond_170

    .line 361
    .line 362
    invoke-virtual {v9}, Lcom/google/firebase/messaging/o;->t()Z

    .line 363
    .line 364
    .line 365
    move-result v17

    .line 366
    const/16 v21, 0x2

    .line 367
    .line 368
    goto :goto_1c5

    .line 369
    :cond_170
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 370
    .line 371
    .line 372
    move-result v1

    .line 373
    if-gt v1, v7, :cond_17b

    .line 374
    .line 375
    move/from16 v1, v18

    .line 376
    .line 377
    const/16 v21, 0x2

    .line 378
    .line 379
    goto :goto_1bb

    .line 380
    :cond_17b
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 381
    .line 382
    .line 383
    move-result-object v1

    .line 384
    move-object/from16 v10, v19

    .line 385
    .line 386
    :goto_181
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 387
    .line 388
    .line 389
    move-result v15

    .line 390
    if-eqz v15, :cond_1b7

    .line 391
    .line 392
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    move-result-object v15

    .line 396
    check-cast v15, Ljz/c;

    .line 397
    .line 398
    iget v7, v15, Ljz/c;->d:I

    .line 399
    .line 400
    move-object/from16 v24, v1

    .line 401
    .line 402
    const/4 v1, 0x2

    .line 403
    if-lt v7, v1, :cond_197

    .line 404
    .line 405
    if-nez v10, :cond_19b

    .line 406
    .line 407
    move-object v10, v15

    .line 408
    :cond_197
    move-object/from16 v1, v24

    .line 409
    .line 410
    const/4 v7, 0x1

    .line 411
    goto :goto_181

    .line 412
    :cond_19b
    const/4 v1, 0x1

    .line 413
    iput-boolean v1, v9, Lcom/google/firebase/messaging/o;->d:Z

    .line 414
    .line 415
    iget v1, v10, Lny/n;->a:F

    .line 416
    .line 417
    iget v7, v15, Lny/n;->a:F

    .line 418
    .line 419
    sub-float/2addr v1, v7

    .line 420
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 421
    .line 422
    .line 423
    move-result v1

    .line 424
    iget v7, v10, Lny/n;->b:F

    .line 425
    .line 426
    iget v10, v15, Lny/n;->b:F

    .line 427
    .line 428
    sub-float/2addr v7, v10

    .line 429
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 430
    .line 431
    .line 432
    move-result v7

    .line 433
    sub-float/2addr v1, v7

    .line 434
    float-to-int v1, v1

    .line 435
    const/16 v21, 0x2

    .line 436
    .line 437
    div-int/lit8 v1, v1, 0x2

    .line 438
    .line 439
    goto :goto_1bb

    .line 440
    :cond_1b7
    const/16 v21, 0x2

    .line 441
    .line 442
    move/from16 v1, v18

    .line 443
    .line 444
    :goto_1bb
    aget v7, v6, v21

    .line 445
    .line 446
    if-le v1, v7, :cond_1c5

    .line 447
    .line 448
    sub-int/2addr v1, v7

    .line 449
    add-int/lit8 v1, v1, -0x2

    .line 450
    .line 451
    add-int/2addr v12, v1

    .line 452
    add-int/lit8 v2, v14, -0x1

    .line 453
    .line 454
    :cond_1c5
    :goto_1c5
    invoke-static {v6}, Lcom/google/firebase/messaging/o;->c([I)V

    .line 455
    .line 456
    .line 457
    move/from16 v1, v18

    .line 458
    .line 459
    move/from16 v15, v21

    .line 460
    .line 461
    const/16 v23, 0x1

    .line 462
    .line 463
    goto :goto_212

    .line 464
    :cond_1cf
    const/16 v21, 0x2

    .line 465
    .line 466
    aget v1, v6, v21

    .line 467
    .line 468
    aput v1, v6, v18

    .line 469
    .line 470
    aget v1, v6, v20

    .line 471
    .line 472
    const/16 v23, 0x1

    .line 473
    .line 474
    aput v1, v6, v23

    .line 475
    .line 476
    const/16 v22, 0x4

    .line 477
    .line 478
    aget v1, v6, v22

    .line 479
    .line 480
    aput v1, v6, v21

    .line 481
    .line 482
    aput v23, v6, v20

    .line 483
    .line 484
    aput v18, v6, v22

    .line 485
    .line 486
    :goto_1e5
    move/from16 v1, v20

    .line 487
    .line 488
    goto :goto_212

    .line 489
    :cond_1e8
    move/from16 v23, v7

    .line 490
    .line 491
    const/16 v21, 0x2

    .line 492
    .line 493
    const/16 v22, 0x4

    .line 494
    .line 495
    aget v1, v6, v21

    .line 496
    .line 497
    aput v1, v6, v18

    .line 498
    .line 499
    aget v1, v6, v20

    .line 500
    .line 501
    aput v1, v6, v23

    .line 502
    .line 503
    aget v1, v6, v22

    .line 504
    .line 505
    aput v1, v6, v21

    .line 506
    .line 507
    aput v23, v6, v20

    .line 508
    .line 509
    aput v18, v6, v22

    .line 510
    .line 511
    goto :goto_1e5

    .line 512
    :cond_1ff
    move/from16 v23, v7

    .line 513
    .line 514
    add-int/lit8 v1, v1, 0x1

    .line 515
    .line 516
    aget v7, v6, v1

    .line 517
    .line 518
    add-int/lit8 v7, v7, 0x1

    .line 519
    .line 520
    aput v7, v6, v1

    .line 521
    .line 522
    goto :goto_212

    .line 523
    :cond_20a
    move/from16 v23, v7

    .line 524
    .line 525
    aget v7, v6, v1

    .line 526
    .line 527
    add-int/lit8 v7, v7, 0x1

    .line 528
    .line 529
    aput v7, v6, v1

    .line 530
    .line 531
    :goto_212
    add-int/lit8 v2, v2, 0x1

    .line 532
    .line 533
    const/4 v7, 0x1

    .line 534
    goto/16 :goto_13b

    .line 535
    .line 536
    :cond_217
    invoke-static {v6}, Lcom/google/firebase/messaging/o;->q([I)Z

    .line 537
    .line 538
    .line 539
    move-result v1

    .line 540
    if-eqz v1, :cond_232

    .line 541
    .line 542
    invoke-virtual {v9, v12, v14, v6}, Lcom/google/firebase/messaging/o;->s(II[I)Z

    .line 543
    .line 544
    .line 545
    move-result v1

    .line 546
    if-eqz v1, :cond_232

    .line 547
    .line 548
    aget v1, v6, v18

    .line 549
    .line 550
    iget-boolean v2, v9, Lcom/google/firebase/messaging/o;->d:Z

    .line 551
    .line 552
    if-eqz v2, :cond_231

    .line 553
    .line 554
    invoke-virtual {v9}, Lcom/google/firebase/messaging/o;->t()Z

    .line 555
    .line 556
    .line 557
    move-result v2

    .line 558
    move v15, v1

    .line 559
    move/from16 v17, v2

    .line 560
    .line 561
    goto :goto_232

    .line 562
    :cond_231
    move v15, v1

    .line 563
    :cond_232
    :goto_232
    add-int/2addr v12, v15

    .line 564
    move/from16 v2, v20

    .line 565
    .line 566
    const/4 v7, 0x1

    .line 567
    goto/16 :goto_12d

    .line 568
    .line 569
    :cond_238
    move/from16 v20, v2

    .line 570
    .line 571
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 572
    .line 573
    .line 574
    move-result v1

    .line 575
    move/from16 v2, v20

    .line 576
    .line 577
    if-lt v1, v2, :cond_473

    .line 578
    .line 579
    const/4 v6, 0x0

    .line 580
    if-le v1, v2, :cond_2a4

    .line 581
    .line 582
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 583
    .line 584
    .line 585
    move-result-object v2

    .line 586
    move v7, v6

    .line 587
    move v9, v7

    .line 588
    :goto_24b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 589
    .line 590
    .line 591
    move-result v10

    .line 592
    if-eqz v10, :cond_25d

    .line 593
    .line 594
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 595
    .line 596
    .line 597
    move-result-object v10

    .line 598
    check-cast v10, Ljz/c;

    .line 599
    .line 600
    iget v10, v10, Ljz/c;->c:F

    .line 601
    .line 602
    add-float/2addr v7, v10

    .line 603
    mul-float/2addr v10, v10

    .line 604
    add-float/2addr v9, v10

    .line 605
    goto :goto_24b

    .line 606
    :cond_25d
    int-to-float v1, v1

    .line 607
    div-float/2addr v7, v1

    .line 608
    div-float/2addr v9, v1

    .line 609
    mul-float v1, v7, v7

    .line 610
    .line 611
    sub-float/2addr v9, v1

    .line 612
    float-to-double v1, v9

    .line 613
    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    .line 614
    .line 615
    .line 616
    move-result-wide v1

    .line 617
    double-to-float v1, v1

    .line 618
    new-instance v2, Ljz/d;

    .line 619
    .line 620
    const/4 v9, 0x1

    .line 621
    invoke-direct {v2, v7, v9}, Ljz/d;-><init>(FI)V

    .line 622
    .line 623
    .line 624
    invoke-static {v11, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 625
    .line 626
    .line 627
    const v2, 0x3e4ccccd    # 0.2f

    .line 628
    .line 629
    .line 630
    mul-float/2addr v2, v7

    .line 631
    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    .line 632
    .line 633
    .line 634
    move-result v1

    .line 635
    move/from16 v2, v18

    .line 636
    .line 637
    :goto_27c
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 638
    .line 639
    .line 640
    move-result v9

    .line 641
    if-ge v2, v9, :cond_2a4

    .line 642
    .line 643
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 644
    .line 645
    .line 646
    move-result v9

    .line 647
    const/4 v10, 0x3

    .line 648
    if-le v9, v10, :cond_2a4

    .line 649
    .line 650
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 651
    .line 652
    .line 653
    move-result-object v9

    .line 654
    check-cast v9, Ljz/c;

    .line 655
    .line 656
    iget v9, v9, Ljz/c;->c:F

    .line 657
    .line 658
    sub-float/2addr v9, v7

    .line 659
    invoke-static {v9}, Ljava/lang/Math;->abs(F)F

    .line 660
    .line 661
    .line 662
    move-result v9

    .line 663
    cmpl-float v9, v9, v1

    .line 664
    .line 665
    if-lez v9, :cond_29f

    .line 666
    .line 667
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 668
    .line 669
    .line 670
    add-int/lit8 v2, v2, -0x1

    .line 671
    .line 672
    :cond_29f
    const/16 v23, 0x1

    .line 673
    .line 674
    add-int/lit8 v2, v2, 0x1

    .line 675
    .line 676
    goto :goto_27c

    .line 677
    :cond_2a4
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 678
    .line 679
    .line 680
    move-result v1

    .line 681
    const/4 v2, 0x3

    .line 682
    if-le v1, v2, :cond_2dc

    .line 683
    .line 684
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 685
    .line 686
    .line 687
    move-result-object v1

    .line 688
    :goto_2af
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 689
    .line 690
    .line 691
    move-result v2

    .line 692
    if-eqz v2, :cond_2bf

    .line 693
    .line 694
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 695
    .line 696
    .line 697
    move-result-object v2

    .line 698
    check-cast v2, Ljz/c;

    .line 699
    .line 700
    iget v2, v2, Ljz/c;->c:F

    .line 701
    .line 702
    add-float/2addr v6, v2

    .line 703
    goto :goto_2af

    .line 704
    :cond_2bf
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 705
    .line 706
    .line 707
    move-result v1

    .line 708
    int-to-float v1, v1

    .line 709
    div-float/2addr v6, v1

    .line 710
    new-instance v1, Ljz/d;

    .line 711
    .line 712
    move/from16 v2, v18

    .line 713
    .line 714
    invoke-direct {v1, v6, v2}, Ljz/d;-><init>(FI)V

    .line 715
    .line 716
    .line 717
    invoke-static {v11, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 718
    .line 719
    .line 720
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 721
    .line 722
    .line 723
    move-result v1

    .line 724
    const/4 v10, 0x3

    .line 725
    invoke-virtual {v11, v10, v1}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    .line 726
    .line 727
    .line 728
    move-result-object v1

    .line 729
    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 730
    .line 731
    .line 732
    goto :goto_2de

    .line 733
    :cond_2dc
    move/from16 v2, v18

    .line 734
    .line 735
    :goto_2de
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 736
    .line 737
    .line 738
    move-result-object v1

    .line 739
    check-cast v1, Ljz/c;

    .line 740
    .line 741
    const/4 v9, 0x1

    .line 742
    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 743
    .line 744
    .line 745
    move-result-object v6

    .line 746
    check-cast v6, Ljz/c;

    .line 747
    .line 748
    const/4 v7, 0x2

    .line 749
    invoke-virtual {v11, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 750
    .line 751
    .line 752
    move-result-object v10

    .line 753
    check-cast v10, Ljz/c;

    .line 754
    .line 755
    filled-new-array {v1, v6, v10}, [Ljz/c;

    .line 756
    .line 757
    .line 758
    move-result-object v1

    .line 759
    invoke-static {v1}, Lny/n;->b([Lny/n;)V

    .line 760
    .line 761
    .line 762
    aget-object v6, v1, v2

    .line 763
    .line 764
    aget-object v2, v1, v9

    .line 765
    .line 766
    aget-object v1, v1, v7

    .line 767
    .line 768
    invoke-virtual {v5, v2, v1}, Landroidx/core/view/d0;->h(Ljz/c;Ljz/c;)F

    .line 769
    .line 770
    .line 771
    move-result v7

    .line 772
    iget v9, v2, Lny/n;->b:F

    .line 773
    .line 774
    iget v10, v2, Lny/n;->a:F

    .line 775
    .line 776
    iget v11, v1, Lny/n;->b:F

    .line 777
    .line 778
    iget v12, v1, Lny/n;->a:F

    .line 779
    .line 780
    invoke-virtual {v5, v2, v6}, Landroidx/core/view/d0;->h(Ljz/c;Ljz/c;)F

    .line 781
    .line 782
    .line 783
    move-result v13

    .line 784
    iget v14, v6, Lny/n;->b:F

    .line 785
    .line 786
    iget v15, v6, Lny/n;->a:F

    .line 787
    .line 788
    add-float/2addr v13, v7

    .line 789
    div-float v13, v13, v16

    .line 790
    .line 791
    const/high16 v7, 0x3f800000    # 1.0f

    .line 792
    .line 793
    cmpg-float v16, v13, v7

    .line 794
    .line 795
    if-ltz v16, :cond_470

    .line 796
    .line 797
    invoke-static {v2, v1}, Lny/n;->a(Lny/n;Lny/n;)F

    .line 798
    .line 799
    .line 800
    move-result v16

    .line 801
    div-float v16, v16, v13

    .line 802
    .line 803
    invoke-static/range {v16 .. v16}, Lio/sentry/config/a;->S(F)I

    .line 804
    .line 805
    .line 806
    move-result v16

    .line 807
    invoke-static {v2, v6}, Lny/n;->a(Lny/n;Lny/n;)F

    .line 808
    .line 809
    .line 810
    move-result v17

    .line 811
    div-float v17, v17, v13

    .line 812
    .line 813
    invoke-static/range {v17 .. v17}, Lio/sentry/config/a;->S(F)I

    .line 814
    .line 815
    .line 816
    move-result v17

    .line 817
    add-int v17, v17, v16

    .line 818
    .line 819
    move/from16 v16, v7

    .line 820
    .line 821
    const/4 v7, 0x2

    .line 822
    div-int/lit8 v17, v17, 0x2

    .line 823
    .line 824
    add-int/lit8 v24, v17, 0x7

    .line 825
    .line 826
    and-int/lit8 v3, v24, 0x3

    .line 827
    .line 828
    if-eqz v3, :cond_34b

    .line 829
    .line 830
    if-eq v3, v7, :cond_348

    .line 831
    .line 832
    const/4 v7, 0x3

    .line 833
    if-eq v3, v7, :cond_345

    .line 834
    .line 835
    :goto_342
    move/from16 v3, v24

    .line 836
    .line 837
    goto :goto_34e

    .line 838
    :cond_345
    sget-object v0, Lny/h;->i:Lny/h;

    .line 839
    .line 840
    throw v0

    .line 841
    :cond_348
    add-int/lit8 v24, v17, 0x6

    .line 842
    .line 843
    goto :goto_342

    .line 844
    :cond_34b
    add-int/lit8 v24, v17, 0x8

    .line 845
    .line 846
    goto :goto_342

    .line 847
    :goto_34e
    sget-object v7, Liz/g;->e:[I

    .line 848
    .line 849
    rem-int/lit8 v7, v3, 0x4

    .line 850
    .line 851
    move/from16 v17, v11

    .line 852
    .line 853
    const/4 v11, 0x1

    .line 854
    if-ne v7, v11, :cond_46b

    .line 855
    .line 856
    add-int/lit8 v7, v3, -0x11

    .line 857
    .line 858
    const/16 v22, 0x4

    .line 859
    .line 860
    :try_start_35b
    div-int/lit8 v7, v7, 0x4

    .line 861
    .line 862
    invoke-static {v7}, Liz/g;->c(I)Liz/g;

    .line 863
    .line 864
    .line 865
    move-result-object v7
    :try_end_361
    .catch Ljava/lang/IllegalArgumentException; {:try_start_35b .. :try_end_361} :catch_466

    .line 866
    iget v11, v7, Liz/g;->a:I

    .line 867
    .line 868
    mul-int/lit8 v11, v11, 0x4

    .line 869
    .line 870
    add-int/lit8 v11, v11, 0xa

    .line 871
    .line 872
    iget-object v7, v7, Liz/g;->b:[I

    .line 873
    .line 874
    array-length v7, v7

    .line 875
    const/high16 v24, 0x40400000    # 3.0f

    .line 876
    .line 877
    if-lez v7, :cond_398

    .line 878
    .line 879
    sub-float v7, v12, v10

    .line 880
    .line 881
    add-float/2addr v7, v15

    .line 882
    sub-float v25, v17, v9

    .line 883
    .line 884
    move/from16 p1, v12

    .line 885
    .line 886
    add-float v12, v25, v14

    .line 887
    .line 888
    int-to-float v11, v11

    .line 889
    div-float v11, v24, v11

    .line 890
    .line 891
    sub-float v11, v16, v11

    .line 892
    .line 893
    invoke-static {v7, v10, v11, v10}, Lxw/a;->b(FFFF)F

    .line 894
    .line 895
    .line 896
    move-result v7

    .line 897
    float-to-int v7, v7

    .line 898
    invoke-static {v12, v9, v11, v9}, Lxw/a;->b(FFFF)F

    .line 899
    .line 900
    .line 901
    move-result v11

    .line 902
    float-to-int v11, v11

    .line 903
    move/from16 v16, v9

    .line 904
    .line 905
    const/4 v12, 0x4

    .line 906
    :goto_389
    const/16 v9, 0x10

    .line 907
    .line 908
    if-gt v12, v9, :cond_392

    .line 909
    .line 910
    int-to-float v9, v12

    .line 911
    :try_start_38e
    invoke-virtual {v5, v13, v9, v7, v11}, Landroidx/core/view/d0;->k(FFII)Ljz/a;

    .line 912
    .line 913
    .line 914
    move-result-object v19
    :try_end_392
    .catch Lny/h; {:try_start_38e .. :try_end_392} :catch_395

    .line 915
    :cond_392
    :goto_392
    move-object/from16 v5, v19

    .line 916
    .line 917
    goto :goto_39d

    .line 918
    :catch_395
    shl-int/lit8 v12, v12, 0x1

    .line 919
    .line 920
    goto :goto_389

    .line 921
    :cond_398
    move/from16 v16, v9

    .line 922
    .line 923
    move/from16 p1, v12

    .line 924
    .line 925
    goto :goto_392

    .line 926
    :goto_39d
    int-to-float v7, v3

    .line 927
    const/high16 v9, 0x40600000    # 3.5f

    .line 928
    .line 929
    sub-float v27, v7, v9

    .line 930
    .line 931
    if-eqz v5, :cond_3b1

    .line 932
    .line 933
    iget v7, v5, Lny/n;->a:F

    .line 934
    .line 935
    iget v9, v5, Lny/n;->b:F

    .line 936
    .line 937
    sub-float v10, v27, v24

    .line 938
    .line 939
    move/from16 v29, v10

    .line 940
    .line 941
    :goto_3ac
    move/from16 v37, v7

    .line 942
    .line 943
    move/from16 v38, v9

    .line 944
    .line 945
    goto :goto_3bc

    .line 946
    :cond_3b1
    sub-float v12, p1, v10

    .line 947
    .line 948
    add-float v7, v12, v15

    .line 949
    .line 950
    sub-float v11, v17, v16

    .line 951
    .line 952
    add-float v9, v11, v14

    .line 953
    .line 954
    move/from16 v29, v27

    .line 955
    .line 956
    goto :goto_3ac

    .line 957
    :goto_3bc
    iget v7, v2, Lny/n;->a:F

    .line 958
    .line 959
    iget v9, v2, Lny/n;->b:F

    .line 960
    .line 961
    iget v10, v1, Lny/n;->a:F

    .line 962
    .line 963
    iget v11, v1, Lny/n;->b:F

    .line 964
    .line 965
    iget v12, v6, Lny/n;->a:F

    .line 966
    .line 967
    iget v13, v6, Lny/n;->b:F

    .line 968
    .line 969
    const/high16 v25, 0x40600000    # 3.5f

    .line 970
    .line 971
    const/high16 v26, 0x40600000    # 3.5f

    .line 972
    .line 973
    const/high16 v28, 0x40600000    # 3.5f

    .line 974
    .line 975
    const/high16 v31, 0x40600000    # 3.5f

    .line 976
    .line 977
    move/from16 v30, v29

    .line 978
    .line 979
    move/from16 v32, v27

    .line 980
    .line 981
    move/from16 v33, v7

    .line 982
    .line 983
    move/from16 v34, v9

    .line 984
    .line 985
    move/from16 v35, v10

    .line 986
    .line 987
    move/from16 v36, v11

    .line 988
    .line 989
    move/from16 v39, v12

    .line 990
    .line 991
    move/from16 v40, v13

    .line 992
    .line 993
    invoke-static/range {v25 .. v40}, Lry/e;->a(FFFFFFFFFFFFFFFF)Lry/e;

    .line 994
    .line 995
    .line 996
    move-result-object v7

    .line 997
    invoke-static {v8, v3, v3, v7}, Lk80/d;->R(Lry/b;IILry/e;)Lry/b;

    .line 998
    .line 999
    .line 1000
    move-result-object v3

    .line 1001
    if-nez v5, :cond_3fa

    .line 1002
    .line 1003
    const/4 v10, 0x3

    .line 1004
    new-array v5, v10, [Lny/n;

    .line 1005
    .line 1006
    const/16 v18, 0x0

    .line 1007
    .line 1008
    aput-object v6, v5, v18

    .line 1009
    .line 1010
    const/16 v23, 0x1

    .line 1011
    .line 1012
    aput-object v2, v5, v23

    .line 1013
    .line 1014
    const/16 v21, 0x2

    .line 1015
    .line 1016
    aput-object v1, v5, v21

    .line 1017
    .line 1018
    goto :goto_40d

    .line 1019
    :cond_3fa
    const/4 v7, 0x4

    .line 1020
    const/4 v10, 0x3

    .line 1021
    const/16 v18, 0x0

    .line 1022
    .line 1023
    const/16 v21, 0x2

    .line 1024
    .line 1025
    const/16 v23, 0x1

    .line 1026
    .line 1027
    new-array v7, v7, [Lny/n;

    .line 1028
    .line 1029
    aput-object v6, v7, v18

    .line 1030
    .line 1031
    aput-object v2, v7, v23

    .line 1032
    .line 1033
    aput-object v1, v7, v21

    .line 1034
    .line 1035
    aput-object v5, v7, v10

    .line 1036
    .line 1037
    move-object v5, v7

    .line 1038
    :goto_40d
    invoke-virtual {v4, v3, v0}, Liz/b;->c(Lry/b;Ljava/util/Map;)Lrx/a;

    .line 1039
    .line 1040
    .line 1041
    move-result-object v0

    .line 1042
    move-object v4, v5

    .line 1043
    :goto_412
    iget v1, v0, Lrx/a;->b:I

    .line 1044
    .line 1045
    iget-object v2, v0, Lrx/a;->g:Ljava/lang/Object;

    .line 1046
    .line 1047
    instance-of v2, v2, Liz/f;

    .line 1048
    .line 1049
    if-eqz v2, :cond_42a

    .line 1050
    .line 1051
    array-length v2, v4

    .line 1052
    if-ge v2, v10, :cond_41e

    .line 1053
    .line 1054
    goto :goto_42a

    .line 1055
    :cond_41e
    const/16 v18, 0x0

    .line 1056
    .line 1057
    aget-object v2, v4, v18

    .line 1058
    .line 1059
    const/16 v21, 0x2

    .line 1060
    .line 1061
    aget-object v3, v4, v21

    .line 1062
    .line 1063
    aput-object v3, v4, v18

    .line 1064
    .line 1065
    aput-object v2, v4, v21

    .line 1066
    .line 1067
    :cond_42a
    :goto_42a
    new-instance v2, Lny/l;

    .line 1068
    .line 1069
    iget-object v3, v0, Lrx/a;->a:Ljava/lang/String;

    .line 1070
    .line 1071
    iget-object v5, v0, Lrx/a;->d:Ljava/lang/Object;

    .line 1072
    .line 1073
    check-cast v5, [B

    .line 1074
    .line 1075
    sget-object v6, Lny/a;->N:Lny/a;

    .line 1076
    .line 1077
    invoke-direct {v2, v3, v5, v4, v6}, Lny/l;-><init>(Ljava/lang/String;[B[Lny/n;Lny/a;)V

    .line 1078
    .line 1079
    .line 1080
    iget-object v3, v0, Lrx/a;->e:Ljava/util/Collection;

    .line 1081
    .line 1082
    check-cast v3, Ljava/util/List;

    .line 1083
    .line 1084
    if-eqz v3, :cond_442

    .line 1085
    .line 1086
    sget-object v4, Lny/m;->e:Lny/m;

    .line 1087
    .line 1088
    invoke-virtual {v2, v4, v3}, Lny/l;->b(Lny/m;Ljava/lang/Object;)V

    .line 1089
    .line 1090
    .line 1091
    :cond_442
    iget-object v3, v0, Lrx/a;->f:Ljava/io/Serializable;

    .line 1092
    .line 1093
    check-cast v3, Ljava/lang/String;

    .line 1094
    .line 1095
    if-eqz v3, :cond_44d

    .line 1096
    .line 1097
    sget-object v4, Lny/m;->i:Lny/m;

    .line 1098
    .line 1099
    invoke-virtual {v2, v4, v3}, Lny/l;->b(Lny/m;Ljava/lang/Object;)V

    .line 1100
    .line 1101
    .line 1102
    :cond_44d
    if-ltz v1, :cond_465

    .line 1103
    .line 1104
    iget v0, v0, Lrx/a;->c:I

    .line 1105
    .line 1106
    if-ltz v0, :cond_465

    .line 1107
    .line 1108
    sget-object v3, Lny/m;->K:Lny/m;

    .line 1109
    .line 1110
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1111
    .line 1112
    .line 1113
    move-result-object v0

    .line 1114
    invoke-virtual {v2, v3, v0}, Lny/l;->b(Lny/m;Ljava/lang/Object;)V

    .line 1115
    .line 1116
    .line 1117
    sget-object v0, Lny/m;->L:Lny/m;

    .line 1118
    .line 1119
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1120
    .line 1121
    .line 1122
    move-result-object v1

    .line 1123
    invoke-virtual {v2, v0, v1}, Lny/l;->b(Lny/m;Ljava/lang/Object;)V

    .line 1124
    .line 1125
    .line 1126
    :cond_465
    return-object v2

    .line 1127
    :catch_466
    invoke-static {}, Lny/d;->a()Lny/d;

    .line 1128
    .line 1129
    .line 1130
    move-result-object v0

    .line 1131
    throw v0

    .line 1132
    :cond_46b
    invoke-static {}, Lny/d;->a()Lny/d;

    .line 1133
    .line 1134
    .line 1135
    move-result-object v0

    .line 1136
    throw v0

    .line 1137
    :cond_470
    sget-object v0, Lny/h;->i:Lny/h;

    .line 1138
    .line 1139
    throw v0

    .line 1140
    :cond_473
    sget-object v0, Lny/h;->i:Lny/h;

    .line 1141
    .line 1142
    throw v0

    .line 1143
    :cond_476
    new-instance v0, Ljava/lang/ClassCastException;

    .line 1144
    .line 1145
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 1146
    .line 1147
    .line 1148
    throw v0
.end method

.method public final reset()V
    .registers 1

    .line 1
    return-void
.end method
