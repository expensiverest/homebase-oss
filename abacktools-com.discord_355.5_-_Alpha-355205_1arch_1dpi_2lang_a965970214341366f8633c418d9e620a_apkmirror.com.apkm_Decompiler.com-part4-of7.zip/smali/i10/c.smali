###### Class i10.c (i10.c)
.class public final Li10/c;
.super Llq/g;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/react/uimanager/h0;


# instance fields
.field public final d:Lcom/facebook/react/uimanager/k0;

.field public final e:Lcom/facebook/react/uimanager/h;

.field public final i:Lk7/l;

.field public v:Lcom/facebook/react/uimanager/events/EventDispatcher;

.field public w:Lcom/facebook/react/uimanager/StateWrapper;

.field public x:Z


# direct methods
.method public constructor <init>(Lcom/facebook/react/uimanager/k0;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Llq/g;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li10/c;->d:Lcom/facebook/react/uimanager/k0;

    .line 5
    .line 6
    new-instance p1, Lcom/facebook/react/uimanager/h;

    .line 7
    .line 8
    invoke-direct {p1, p0}, Lcom/facebook/react/uimanager/h;-><init>(Landroid/view/ViewGroup;)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Li10/c;->e:Lcom/facebook/react/uimanager/h;

    .line 12
    .line 13
    sget-boolean p1, Lcom/facebook/react/config/ReactFeatureFlags;->dispatchPointerEvents:Z

    .line 14
    .line 15
    if-eqz p1, :cond_2a

    .line 16
    .line 17
    new-instance p1, Lk7/l;

    .line 18
    .line 19
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    new-instance v0, Lcom/facebook/react/uimanager/g;

    .line 23
    .line 24
    invoke-direct {v0, p0}, Lcom/facebook/react/uimanager/g;-><init>(Landroid/view/ViewGroup;)V

    .line 25
    .line 26
    .line 27
    iput-object v0, p1, Lk7/l;->d:Ljava/lang/Object;

    .line 28
    .line 29
    new-instance v0, Lhh/c;

    .line 30
    .line 31
    const/4 v1, 0x3

    .line 32
    invoke-direct {v0, v1}, Lhh/c;-><init>(I)V

    .line 33
    .line 34
    .line 35
    invoke-static {v0}, La/a;->K(Lkotlin/jvm/functions/Function0;)Ll30/o;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    iput-object v0, p1, Lk7/l;->e:Ljava/lang/Object;

    .line 40
    .line 41
    iput-object p1, p0, Li10/c;->i:Lk7/l;

    .line 42
    .line 43
    :cond_2a
    return-void
.end method


# virtual methods
.method public final c(Landroid/view/View;Landroid/view/MotionEvent;)V
    .registers 6

    .line 1
    const-string v0, "ev"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 7
    .line 8
    if-eqz v0, :cond_1d

    .line 9
    .line 10
    iget-object v1, p0, Li10/c;->e:Lcom/facebook/react/uimanager/h;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-virtual {v1, p2, v0, v2}, Lcom/facebook/react/uimanager/h;->d(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Lcom/facebook/react/bridge/ReactContext;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Li10/c;->i:Lk7/l;

    .line 20
    .line 21
    if-eqz v1, :cond_1d

    .line 22
    .line 23
    iget-object v1, v1, Lk7/l;->d:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v1, Lcom/facebook/react/uimanager/g;

    .line 26
    .line 27
    invoke-virtual {v1, p1, p2, v0}, Lcom/facebook/react/uimanager/g;->f(Landroid/view/View;Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    return-void
.end method

.method public final e(Landroid/view/View;Landroid/view/MotionEvent;)V
    .registers 3

    .line 1
    iget-object p1, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 2
    .line 3
    if-eqz p1, :cond_c

    .line 4
    .line 5
    iget-object p1, p0, Li10/c;->e:Lcom/facebook/react/uimanager/h;

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    const/4 p2, 0x0

    .line 11
    iput-boolean p2, p1, Lcom/facebook/react/uimanager/h;->d:Z

    .line 12
    .line 13
    :cond_c
    iget-object p1, p0, Li10/c;->i:Lk7/l;

    .line 14
    .line 15
    if-eqz p1, :cond_17

    .line 16
    .line 17
    iget-object p1, p1, Lk7/l;->d:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p1, Lcom/facebook/react/uimanager/g;

    .line 20
    .line 21
    const/4 p2, -0x1

    .line 22
    iput p2, p1, Lcom/facebook/react/uimanager/g;->e:I

    .line 23
    .line 24
    :cond_17
    return-void
.end method

.method public final getEventDispatcher$react_native_keyboard_controller_release()Lcom/facebook/react/uimanager/events/EventDispatcher;
    .registers 2

    .line 1
    iget-object v0, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getStateWrapper$react_native_keyboard_controller_release()Lcom/facebook/react/uimanager/StateWrapper;
    .registers 2

    .line 1
    iget-object v0, p0, Li10/c;->w:Lcom/facebook/react/uimanager/StateWrapper;

    .line 2
    .line 3
    return-object v0
.end method

.method public final l(II)V
    .registers 6

    .line 1
    new-instance v0, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 4
    .line 5
    .line 6
    int-to-float p1, p1

    .line 7
    invoke-static {p1}, Ly00/c;->c(F)D

    .line 8
    .line 9
    .line 10
    move-result-wide v1

    .line 11
    const-string p1, "screenWidth"

    .line 12
    .line 13
    invoke-interface {v0, p1, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 14
    .line 15
    .line 16
    int-to-float p1, p2

    .line 17
    invoke-static {p1}, Ly00/c;->c(F)D

    .line 18
    .line 19
    .line 20
    move-result-wide p1

    .line 21
    const-string v1, "screenHeight"

    .line 22
    .line 23
    invoke-interface {v0, v1, p1, p2}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 24
    .line 25
    .line 26
    iget-object p1, p0, Li10/c;->w:Lcom/facebook/react/uimanager/StateWrapper;

    .line 27
    .line 28
    if-eqz p1, :cond_20

    .line 29
    .line 30
    invoke-interface {p1, v0}, Lcom/facebook/react/uimanager/StateWrapper;->updateState(Lcom/facebook/react/bridge/WritableMap;)V

    .line 31
    .line 32
    .line 33
    :cond_20
    return-void
.end method

.method public final onAttachedToWindow()V
    .registers 3

    .line 1
    invoke-super {p0}, Llq/g;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Li10/c;->d:Lcom/facebook/react/uimanager/k0;

    .line 5
    .line 6
    invoke-static {v0}, Ly00/a;->a(Landroid/content/Context;)Landroid/graphics/Point;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget v1, v0, Landroid/graphics/Point;->x:I

    .line 11
    .line 12
    iget v0, v0, Landroid/graphics/Point;->y:I

    .line 13
    .line 14
    invoke-virtual {p0, v1, v0}, Li10/c;->l(II)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    iput-boolean v0, p0, Li10/c;->x:Z

    .line 19
    .line 20
    return-void
.end method

.method public final onDetachedFromWindow()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {p0, v0, v0}, Li10/c;->l(II)V

    .line 6
    .line 7
    .line 8
    iput-boolean v0, p0, Li10/c;->x:Z

    .line 9
    .line 10
    return-void
.end method

.method public final onHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 7
    .line 8
    if-eqz v0, :cond_11

    .line 9
    .line 10
    iget-object v1, p0, Li10/c;->i:Lk7/l;

    .line 11
    .line 12
    if-eqz v1, :cond_11

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {v1, p1, v0, v2}, Lk7/l;->X(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Z)V

    .line 16
    .line 17
    .line 18
    :cond_11
    invoke-super {p0, p1}, Llq/g;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    return p1
.end method

.method public final onInterceptHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 7
    .line 8
    if-eqz v0, :cond_11

    .line 9
    .line 10
    iget-object v1, p0, Li10/c;->i:Lk7/l;

    .line 11
    .line 12
    if-eqz v1, :cond_11

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    invoke-virtual {v1, p1, v0, v2}, Lk7/l;->X(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Z)V

    .line 16
    .line 17
    .line 18
    :cond_11
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInterceptHoverEvent(Landroid/view/MotionEvent;)Z

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    return p1
.end method

.method public final onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 7
    .line 8
    if-eqz v0, :cond_1d

    .line 9
    .line 10
    :try_start_9
    iget-object v1, p0, Li10/c;->e:Lcom/facebook/react/uimanager/h;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-virtual {v1, p1, v0, v2}, Lcom/facebook/react/uimanager/h;->c(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Lcom/facebook/react/bridge/ReactContext;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Li10/c;->i:Lk7/l;

    .line 20
    .line 21
    if-eqz v1, :cond_1d

    .line 22
    .line 23
    const/4 v2, 0x1

    .line 24
    invoke-virtual {v1, p1, v0, v2}, Lk7/l;->X(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Z)V
    :try_end_1a
    .catch Ljava/lang/RuntimeException; {:try_start_9 .. :try_end_1a} :catch_1b

    .line 25
    .line 26
    .line 27
    goto :goto_1d

    .line 28
    :catch_1b
    sget v0, Li10/d;->a:I

    .line 29
    .line 30
    :cond_1d
    :goto_1d
    invoke-super {p0, p1}, Llq/g;->onInterceptTouchEvent(Landroid/view/MotionEvent;)Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    return p1
.end method

.method public final onSizeChanged(IIII)V
    .registers 5

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Llq/g;->onSizeChanged(IIII)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, Li10/c;->l(II)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 7
    .line 8
    if-eqz v0, :cond_1d

    .line 9
    .line 10
    :try_start_9
    iget-object v1, p0, Li10/c;->e:Lcom/facebook/react/uimanager/h;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-virtual {v1, p1, v0, v2}, Lcom/facebook/react/uimanager/h;->c(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Lcom/facebook/react/bridge/ReactContext;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Li10/c;->i:Lk7/l;

    .line 20
    .line 21
    if-eqz v1, :cond_1d

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    invoke-virtual {v1, p1, v0, v2}, Lk7/l;->X(Landroid/view/MotionEvent;Lcom/facebook/react/uimanager/events/EventDispatcher;Z)V
    :try_end_1a
    .catch Ljava/lang/RuntimeException; {:try_start_9 .. :try_end_1a} :catch_1b

    .line 25
    .line 26
    .line 27
    goto :goto_1d

    .line 28
    :catch_1b
    sget v0, Li10/d;->a:I

    .line 29
    .line 30
    :cond_1d
    :goto_1d
    invoke-super {p0, p1}, Llq/g;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 31
    .line 32
    .line 33
    const/4 p1, 0x1

    .line 34
    return p1
.end method

.method public final requestDisallowInterceptTouchEvent(Z)V
    .registers 2

    .line 1
    return-void
.end method

.method public final setAttached$react_native_keyboard_controller_release(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Li10/c;->x:Z

    .line 2
    .line 3
    return-void
.end method

.method public final setEventDispatcher$react_native_keyboard_controller_release(Lcom/facebook/react/uimanager/events/EventDispatcher;)V
    .registers 2

    .line 1
    iput-object p1, p0, Li10/c;->v:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 2
    .line 3
    return-void
.end method

.method public final setStateWrapper$react_native_keyboard_controller_release(Lcom/facebook/react/uimanager/StateWrapper;)V
    .registers 2

    .line 1
    iput-object p1, p0, Li10/c;->w:Lcom/facebook/react/uimanager/StateWrapper;

    .line 2
    .line 3
    return-void
.end method
