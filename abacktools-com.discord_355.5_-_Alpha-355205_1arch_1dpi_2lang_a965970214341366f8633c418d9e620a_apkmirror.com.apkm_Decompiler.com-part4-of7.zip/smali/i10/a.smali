###### Class i10.a (i10.a)
.class public final Li10/a;
.super Lcom/facebook/react/uimanager/j;
.source "SourceFile"
