###### Class i1.d (i1.d)
.class public abstract Li1/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lk80/d;

.field public static final b:Le6/r1;

.field public static c:Landroid/graphics/Paint;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const-string v0, "TypefaceCompat static init"

    .line 2
    .line 3
    invoke-static {v0}, Low/a;->M(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 11
    .line 12
    const/16 v1, 0x1f

    .line 13
    .line 14
    if-lt v0, v1, :cond_17

    .line 15
    .line 16
    new-instance v0, Li1/j;

    .line 17
    .line 18
    invoke-direct {v0}, Lk80/d;-><init>()V

    .line 19
    .line 20
    .line 21
    sput-object v0, Li1/d;->a:Lk80/d;

    .line 22
    .line 23
    goto :goto_57

    .line 24
    :cond_17
    const/16 v1, 0x1d

    .line 25
    .line 26
    if-lt v0, v1, :cond_23

    .line 27
    .line 28
    new-instance v0, Li1/i;

    .line 29
    .line 30
    invoke-direct {v0}, Lk80/d;-><init>()V

    .line 31
    .line 32
    .line 33
    sput-object v0, Li1/d;->a:Lk80/d;

    .line 34
    .line 35
    goto :goto_57

    .line 36
    :cond_23
    const/16 v1, 0x1c

    .line 37
    .line 38
    if-lt v0, v1, :cond_2f

    .line 39
    .line 40
    new-instance v0, Li1/h;

    .line 41
    .line 42
    invoke-direct {v0}, Li1/g;-><init>()V

    .line 43
    .line 44
    .line 45
    sput-object v0, Li1/d;->a:Lk80/d;

    .line 46
    .line 47
    goto :goto_57

    .line 48
    :cond_2f
    const/16 v1, 0x1a

    .line 49
    .line 50
    if-lt v0, v1, :cond_3b

    .line 51
    .line 52
    new-instance v0, Li1/g;

    .line 53
    .line 54
    invoke-direct {v0}, Li1/g;-><init>()V

    .line 55
    .line 56
    .line 57
    sput-object v0, Li1/d;->a:Lk80/d;

    .line 58
    .line 59
    goto :goto_57

    .line 60
    :cond_3b
    sget-object v0, Li1/f;->h:Ljava/lang/reflect/Method;

    .line 61
    .line 62
    if-nez v0, :cond_46

    .line 63
    .line 64
    const-string v1, "TypefaceCompatApi24Impl"

    .line 65
    .line 66
    const-string v2, "Unable to collect necessary private methods.Fallback to legacy implementation."

    .line 67
    .line 68
    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 69
    .line 70
    .line 71
    :cond_46
    if-eqz v0, :cond_50

    .line 72
    .line 73
    new-instance v0, Li1/f;

    .line 74
    .line 75
    invoke-direct {v0}, Lk80/d;-><init>()V

    .line 76
    .line 77
    .line 78
    sput-object v0, Li1/d;->a:Lk80/d;

    .line 79
    .line 80
    goto :goto_57

    .line 81
    :cond_50
    new-instance v0, Li1/e;

    .line 82
    .line 83
    invoke-direct {v0}, Lk80/d;-><init>()V

    .line 84
    .line 85
    .line 86
    sput-object v0, Li1/d;->a:Lk80/d;

    .line 87
    .line 88
    :goto_57
    new-instance v0, Le6/r1;

    .line 89
    .line 90
    const/16 v1, 0x10

    .line 91
    .line 92
    invoke-direct {v0, v1}, Le6/r1;-><init>(I)V

    .line 93
    .line 94
    .line 95
    sput-object v0, Li1/d;->b:Le6/r1;

    .line 96
    .line 97
    const/4 v0, 0x0

    .line 98
    sput-object v0, Li1/d;->c:Landroid/graphics/Paint;

    .line 99
    .line 100
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 101
    .line 102
    .line 103
    return-void
.end method

.method public static a(Landroid/content/Context;Lh1/d;Landroid/content/res/Resources;ILjava/lang/String;IILh1/b;Z)Landroid/graphics/Typeface;
    .registers 25

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move/from16 v4, p6

    .line 6
    .line 7
    move-object/from16 v1, p7

    .line 8
    .line 9
    instance-of v3, v0, Lh1/g;

    .line 10
    .line 11
    const/4 v6, 0x3

    .line 12
    const/4 v7, -0x3

    .line 13
    if-eqz v3, :cond_261

    .line 14
    .line 15
    check-cast v0, Lh1/g;

    .line 16
    .line 17
    const-string v3, "TypefaceCompat"

    .line 18
    .line 19
    iget-object v5, v0, Lh1/g;->d:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 22
    .line 23
    .line 24
    move-result v8

    .line 25
    const/4 v9, 0x0

    .line 26
    const/4 v10, 0x1

    .line 27
    const/4 v11, 0x0

    .line 28
    if-nez v8, :cond_25

    .line 29
    .line 30
    invoke-static {v5}, Li1/d;->c(Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 31
    .line 32
    .line 33
    move-result-object v5

    .line 34
    if-eqz v5, :cond_25

    .line 35
    .line 36
    goto/16 :goto_ea

    .line 37
    .line 38
    :cond_25
    iget-object v5, v0, Lh1/g;->a:Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    if-ne v8, v10, :cond_3b

    .line 45
    .line 46
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    check-cast v3, Lp1/c;

    .line 51
    .line 52
    iget-object v3, v3, Lp1/c;->e:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v3}, Li1/d;->c(Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    goto/16 :goto_ea

    .line 59
    .line 60
    :cond_3b
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 61
    .line 62
    const/16 v12, 0x1f

    .line 63
    .line 64
    if-ge v8, v12, :cond_44

    .line 65
    .line 66
    :goto_41
    move-object v5, v9

    .line 67
    goto/16 :goto_ea

    .line 68
    .line 69
    :cond_44
    move v8, v11

    .line 70
    :goto_45
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 71
    .line 72
    .line 73
    move-result v12

    .line 74
    if-ge v8, v12, :cond_5d

    .line 75
    .line 76
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v12

    .line 80
    check-cast v12, Lp1/c;

    .line 81
    .line 82
    iget-object v12, v12, Lp1/c;->e:Ljava/lang/String;

    .line 83
    .line 84
    invoke-static {v12}, Li1/d;->c(Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 85
    .line 86
    .line 87
    move-result-object v12

    .line 88
    if-nez v12, :cond_5a

    .line 89
    .line 90
    goto :goto_41

    .line 91
    :cond_5a
    add-int/lit8 v8, v8, 0x1

    .line 92
    .line 93
    goto :goto_45

    .line 94
    :cond_5d
    move-object v12, v9

    .line 95
    move v8, v11

    .line 96
    :goto_5f
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 97
    .line 98
    .line 99
    move-result v13

    .line 100
    if-ge v8, v13, :cond_e6

    .line 101
    .line 102
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v13

    .line 106
    check-cast v13, Lp1/c;

    .line 107
    .line 108
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 109
    .line 110
    .line 111
    move-result v14

    .line 112
    sub-int/2addr v14, v10

    .line 113
    if-ne v8, v14, :cond_80

    .line 114
    .line 115
    iget-object v14, v13, Lp1/c;->f:Ljava/lang/String;

    .line 116
    .line 117
    invoke-static {v14}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 118
    .line 119
    .line 120
    move-result v14

    .line 121
    if-eqz v14, :cond_80

    .line 122
    .line 123
    iget-object v3, v13, Lp1/c;->e:Ljava/lang/String;

    .line 124
    .line 125
    invoke-virtual {v12, v3}, Landroid/graphics/Typeface$CustomFallbackBuilder;->setSystemFallback(Ljava/lang/String;)Landroid/graphics/Typeface$CustomFallbackBuilder;

    .line 126
    .line 127
    .line 128
    goto :goto_e6

    .line 129
    :cond_80
    iget-object v14, v13, Lp1/c;->e:Ljava/lang/String;

    .line 130
    .line 131
    iget-object v15, v13, Lp1/c;->f:Ljava/lang/String;

    .line 132
    .line 133
    invoke-static {v14}, Li1/d;->c(Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 134
    .line 135
    .line 136
    move-result-object v14

    .line 137
    invoke-static {v14}, Li1/d;->d(Landroid/graphics/Typeface;)Landroid/graphics/fonts/Font;

    .line 138
    .line 139
    .line 140
    move-result-object v14

    .line 141
    if-nez v14, :cond_a7

    .line 142
    .line 143
    new-instance v5, Ljava/lang/StringBuilder;

    .line 144
    .line 145
    const-string v8, "Unable identify the primary font for "

    .line 146
    .line 147
    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    iget-object v8, v13, Lp1/c;->e:Ljava/lang/String;

    .line 151
    .line 152
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    const-string v8, ". Falling back to provider font."

    .line 156
    .line 157
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v5

    .line 164
    invoke-static {v3, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 165
    .line 166
    .line 167
    goto :goto_41

    .line 168
    :cond_a7
    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 169
    .line 170
    .line 171
    move-result v13

    .line 172
    if-nez v13, :cond_ce

    .line 173
    .line 174
    :try_start_ad
    new-instance v13, Landroid/graphics/fonts/FontFamily$Builder;

    .line 175
    .line 176
    new-instance v13, Landroid/graphics/fonts/Font$Builder;

    .line 177
    .line 178
    invoke-static {v14}, Landroidx/core/view/c;->a(Landroid/graphics/fonts/Font;)Landroid/graphics/fonts/Font$Builder;

    .line 179
    .line 180
    .line 181
    move-result-object v13

    .line 182
    invoke-virtual {v13, v15}, Landroid/graphics/fonts/Font$Builder;->setFontVariationSettings(Ljava/lang/String;)Landroid/graphics/fonts/Font$Builder;

    .line 183
    .line 184
    .line 185
    move-result-object v13

    .line 186
    invoke-virtual {v13}, Landroid/graphics/fonts/Font$Builder;->build()Landroid/graphics/fonts/Font;

    .line 187
    .line 188
    .line 189
    move-result-object v13

    .line 190
    new-instance v14, Landroid/graphics/fonts/FontFamily$Builder;

    .line 191
    .line 192
    invoke-direct {v14, v13}, Landroid/graphics/fonts/FontFamily$Builder;-><init>(Landroid/graphics/fonts/Font;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v14}, Landroid/graphics/fonts/FontFamily$Builder;->build()Landroid/graphics/fonts/FontFamily;

    .line 196
    .line 197
    .line 198
    move-result-object v13
    :try_end_c6
    .catch Ljava/io/IOException; {:try_start_ad .. :try_end_c6} :catch_c7

    .line 199
    goto :goto_d7

    .line 200
    :catch_c7
    const-string v5, "Failed to clone Font instance. Fall back to provider font."

    .line 201
    .line 202
    invoke-static {v3, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 203
    .line 204
    .line 205
    goto/16 :goto_41

    .line 206
    .line 207
    :cond_ce
    new-instance v13, Landroid/graphics/fonts/FontFamily$Builder;

    .line 208
    .line 209
    invoke-direct {v13, v14}, Landroid/graphics/fonts/FontFamily$Builder;-><init>(Landroid/graphics/fonts/Font;)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v13}, Landroid/graphics/fonts/FontFamily$Builder;->build()Landroid/graphics/fonts/FontFamily;

    .line 213
    .line 214
    .line 215
    move-result-object v13

    .line 216
    :goto_d7
    if-nez v12, :cond_df

    .line 217
    .line 218
    new-instance v12, Landroid/graphics/Typeface$CustomFallbackBuilder;

    .line 219
    .line 220
    invoke-direct {v12, v13}, Landroid/graphics/Typeface$CustomFallbackBuilder;-><init>(Landroid/graphics/fonts/FontFamily;)V

    .line 221
    .line 222
    .line 223
    goto :goto_e2

    .line 224
    :cond_df
    invoke-virtual {v12, v13}, Landroid/graphics/Typeface$CustomFallbackBuilder;->addCustomFallback(Landroid/graphics/fonts/FontFamily;)Landroid/graphics/Typeface$CustomFallbackBuilder;

    .line 225
    .line 226
    .line 227
    :goto_e2
    add-int/lit8 v8, v8, 0x1

    .line 228
    .line 229
    goto/16 :goto_5f

    .line 230
    .line 231
    :cond_e6
    :goto_e6
    invoke-virtual {v12}, Landroid/graphics/Typeface$CustomFallbackBuilder;->build()Landroid/graphics/Typeface;

    .line 232
    .line 233
    .line 234
    move-result-object v5

    .line 235
    :goto_ea
    if-eqz v5, :cond_109

    .line 236
    .line 237
    if-eqz v1, :cond_ff

    .line 238
    .line 239
    new-instance v0, Landroid/os/Handler;

    .line 240
    .line 241
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 242
    .line 243
    .line 244
    move-result-object v2

    .line 245
    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 246
    .line 247
    .line 248
    new-instance v2, Lf4/q0;

    .line 249
    .line 250
    invoke-direct {v2, v6, v1, v5}, Lf4/q0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 254
    .line 255
    .line 256
    :cond_ff
    sget-object v0, Li1/d;->b:Le6/r1;

    .line 257
    .line 258
    invoke-static/range {p2 .. p6}, Li1/d;->b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v1

    .line 262
    invoke-virtual {v0, v1, v5}, Le6/r1;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    return-object v5

    .line 266
    :cond_109
    if-eqz p8, :cond_113

    .line 267
    .line 268
    iget v3, v0, Lh1/g;->c:I

    .line 269
    .line 270
    if-nez v3, :cond_111

    .line 271
    .line 272
    :goto_10f
    move v3, v10

    .line 273
    goto :goto_116

    .line 274
    :cond_111
    move v3, v11

    .line 275
    goto :goto_116

    .line 276
    :cond_113
    if-nez v1, :cond_111

    .line 277
    .line 278
    goto :goto_10f

    .line 279
    :goto_116
    const/4 v5, -0x1

    .line 280
    if-eqz p8, :cond_11c

    .line 281
    .line 282
    iget v8, v0, Lh1/g;->b:I

    .line 283
    .line 284
    goto :goto_11d

    .line 285
    :cond_11c
    move v8, v5

    .line 286
    :goto_11d
    new-instance v12, Landroid/os/Handler;

    .line 287
    .line 288
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 289
    .line 290
    .line 291
    move-result-object v13

    .line 292
    invoke-direct {v12, v13}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 293
    .line 294
    .line 295
    new-instance v13, Landroidx/core/view/g0;

    .line 296
    .line 297
    const/16 v14, 0x13

    .line 298
    .line 299
    invoke-direct {v13, v14, v11}, Landroidx/core/view/g0;-><init>(IZ)V

    .line 300
    .line 301
    .line 302
    iput-object v1, v13, Landroidx/core/view/g0;->e:Ljava/lang/Object;

    .line 303
    .line 304
    iget-object v0, v0, Lh1/g;->a:Ljava/util/ArrayList;

    .line 305
    .line 306
    new-instance v14, Lk7/c;

    .line 307
    .line 308
    new-instance v1, Le6/e;

    .line 309
    .line 310
    invoke-direct {v1, v12, v6}, Le6/e;-><init>(Landroid/os/Handler;I)V

    .line 311
    .line 312
    .line 313
    const/16 v12, 0x19

    .line 314
    .line 315
    invoke-direct {v14, v12, v13, v1}, Lk7/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    const/16 v12, 0x1a

    .line 319
    .line 320
    if-eqz v3, :cond_1ea

    .line 321
    .line 322
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 323
    .line 324
    .line 325
    move-result v3

    .line 326
    if-gt v3, v10, :cond_1e2

    .line 327
    .line 328
    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    move-object v3, v0

    .line 333
    check-cast v3, Lp1/c;

    .line 334
    .line 335
    sget-object v0, Lp1/f;->a:Le6/r1;

    .line 336
    .line 337
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    new-instance v15, Ljava/util/ArrayList;

    .line 342
    .line 343
    invoke-direct {v15, v10}, Ljava/util/ArrayList;-><init>(I)V

    .line 344
    .line 345
    .line 346
    aget-object v0, v0, v11

    .line 347
    .line 348
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 352
    .line 353
    .line 354
    invoke-static {v15}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 355
    .line 356
    .line 357
    move-result-object v0

    .line 358
    invoke-static {v4, v0}, Lp1/f;->a(ILjava/util/List;)Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v0

    .line 362
    sget-object v15, Lp1/f;->a:Le6/r1;

    .line 363
    .line 364
    invoke-virtual {v15, v0}, Le6/r1;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v15

    .line 368
    check-cast v15, Landroid/graphics/Typeface;

    .line 369
    .line 370
    if-eqz v15, :cond_17e

    .line 371
    .line 372
    new-instance v0, Lcom/google/android/gms/internal/play_billing/t0;

    .line 373
    .line 374
    invoke-direct {v0, v12, v13, v15}, Lcom/google/android/gms/internal/play_billing/t0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 375
    .line 376
    .line 377
    invoke-virtual {v1, v0}, Le6/e;->execute(Ljava/lang/Runnable;)V

    .line 378
    .line 379
    .line 380
    move-object v9, v15

    .line 381
    goto/16 :goto_25c

    .line 382
    .line 383
    :cond_17e
    if-ne v8, v5, :cond_1a0

    .line 384
    .line 385
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 386
    .line 387
    .line 388
    move-result-object v1

    .line 389
    new-instance v3, Ljava/util/ArrayList;

    .line 390
    .line 391
    invoke-direct {v3, v10}, Ljava/util/ArrayList;-><init>(I)V

    .line 392
    .line 393
    .line 394
    aget-object v1, v1, v11

    .line 395
    .line 396
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 400
    .line 401
    .line 402
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 403
    .line 404
    .line 405
    move-result-object v1

    .line 406
    invoke-static {v0, v2, v1, v4}, Lp1/f;->b(Ljava/lang/String;Landroid/content/Context;Ljava/util/List;I)Lp1/e;

    .line 407
    .line 408
    .line 409
    move-result-object v0

    .line 410
    invoke-virtual {v14, v0}, Lk7/c;->m(Lp1/e;)V

    .line 411
    .line 412
    .line 413
    iget-object v9, v0, Lp1/e;->a:Landroid/graphics/Typeface;

    .line 414
    .line 415
    goto/16 :goto_25c

    .line 416
    .line 417
    :cond_1a0
    move-object v1, v0

    .line 418
    new-instance v0, Lp1/d;

    .line 419
    .line 420
    const/4 v5, 0x0

    .line 421
    invoke-direct/range {v0 .. v5}, Lp1/d;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/Object;II)V

    .line 422
    .line 423
    .line 424
    :try_start_1a7
    sget-object v1, Lp1/f;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 425
    .line 426
    invoke-interface {v1, v0}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    .line 427
    .line 428
    .line 429
    move-result-object v0
    :try_end_1ad
    .catch Ljava/lang/InterruptedException; {:try_start_1a7 .. :try_end_1ad} :catch_1d0

    .line 430
    int-to-long v1, v8

    .line 431
    :try_start_1ae
    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 432
    .line 433
    invoke-interface {v0, v1, v2, v3}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 434
    .line 435
    .line 436
    move-result-object v0
    :try_end_1b4
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1ae .. :try_end_1b4} :catch_1bf
    .catch Ljava/lang/InterruptedException; {:try_start_1ae .. :try_end_1b4} :catch_1bd
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_1ae .. :try_end_1b4} :catch_1c1

    .line 437
    :try_start_1b4
    check-cast v0, Lp1/e;

    .line 438
    .line 439
    invoke-virtual {v14, v0}, Lk7/c;->m(Lp1/e;)V

    .line 440
    .line 441
    .line 442
    iget-object v9, v0, Lp1/e;->a:Landroid/graphics/Typeface;

    .line 443
    .line 444
    goto/16 :goto_25c

    .line 445
    .line 446
    :catch_1bd
    move-exception v0

    .line 447
    goto :goto_1c9

    .line 448
    :catch_1bf
    move-exception v0

    .line 449
    goto :goto_1ca

    .line 450
    :catch_1c1
    new-instance v0, Ljava/lang/InterruptedException;

    .line 451
    .line 452
    const-string v1, "timeout"

    .line 453
    .line 454
    invoke-direct {v0, v1}, Ljava/lang/InterruptedException;-><init>(Ljava/lang/String;)V

    .line 455
    .line 456
    .line 457
    throw v0

    .line 458
    :goto_1c9
    throw v0

    .line 459
    :goto_1ca
    new-instance v1, Ljava/lang/RuntimeException;

    .line 460
    .line 461
    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 462
    .line 463
    .line 464
    throw v1
    :try_end_1d0
    .catch Ljava/lang/InterruptedException; {:try_start_1b4 .. :try_end_1d0} :catch_1d0

    .line 465
    :catch_1d0
    iget-object v0, v14, Lk7/c;->i:Ljava/lang/Object;

    .line 466
    .line 467
    check-cast v0, Le6/e;

    .line 468
    .line 469
    iget-object v1, v14, Lk7/c;->e:Ljava/lang/Object;

    .line 470
    .line 471
    check-cast v1, Landroidx/core/view/g0;

    .line 472
    .line 473
    new-instance v2, Lgu/l;

    .line 474
    .line 475
    invoke-direct {v2, v7, v6, v1}, Lgu/l;-><init>(IILjava/lang/Object;)V

    .line 476
    .line 477
    .line 478
    invoke-virtual {v0, v2}, Le6/e;->execute(Ljava/lang/Runnable;)V

    .line 479
    .line 480
    .line 481
    goto/16 :goto_25c

    .line 482
    .line 483
    :cond_1e2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 484
    .line 485
    const-string v1, "Fallbacks with blocking fetches are not supported for performance reasons"

    .line 486
    .line 487
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 488
    .line 489
    .line 490
    throw v0

    .line 491
    :cond_1ea
    invoke-static {v4, v0}, Lp1/f;->a(ILjava/util/List;)Ljava/lang/String;

    .line 492
    .line 493
    .line 494
    move-result-object v2

    .line 495
    sget-object v3, Lp1/f;->a:Le6/r1;

    .line 496
    .line 497
    invoke-virtual {v3, v2}, Le6/r1;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object v3

    .line 501
    check-cast v3, Landroid/graphics/Typeface;

    .line 502
    .line 503
    if-eqz v3, :cond_202

    .line 504
    .line 505
    new-instance v0, Lcom/google/android/gms/internal/play_billing/t0;

    .line 506
    .line 507
    invoke-direct {v0, v12, v13, v3}, Lcom/google/android/gms/internal/play_billing/t0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 508
    .line 509
    .line 510
    invoke-virtual {v1, v0}, Le6/e;->execute(Ljava/lang/Runnable;)V

    .line 511
    .line 512
    .line 513
    move-object v9, v3

    .line 514
    goto :goto_25c

    .line 515
    :cond_202
    new-instance v1, Lg8/z;

    .line 516
    .line 517
    const/4 v3, 0x2

    .line 518
    invoke-direct {v1, v3, v14}, Lg8/z;-><init>(ILjava/lang/Object;)V

    .line 519
    .line 520
    .line 521
    sget-object v3, Lp1/f;->c:Ljava/lang/Object;

    .line 522
    .line 523
    monitor-enter v3

    .line 524
    :try_start_20b
    sget-object v5, Lp1/f;->d:Lv/s;

    .line 525
    .line 526
    invoke-virtual {v5, v2}, Lv/s;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 527
    .line 528
    .line 529
    move-result-object v7

    .line 530
    check-cast v7, Ljava/util/ArrayList;

    .line 531
    .line 532
    if-eqz v7, :cond_21c

    .line 533
    .line 534
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 535
    .line 536
    .line 537
    monitor-exit v3

    .line 538
    goto :goto_25c

    .line 539
    :catchall_21a
    move-exception v0

    .line 540
    goto :goto_25f

    .line 541
    :cond_21c
    new-instance v7, Ljava/util/ArrayList;

    .line 542
    .line 543
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 544
    .line 545
    .line 546
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 547
    .line 548
    .line 549
    invoke-virtual {v5, v2, v7}, Lv/s;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 550
    .line 551
    .line 552
    monitor-exit v3
    :try_end_228
    .catchall {:try_start_20b .. :try_end_228} :catchall_21a

    .line 553
    move-object v3, v0

    .line 554
    new-instance v0, Lp1/d;

    .line 555
    .line 556
    const/4 v5, 0x1

    .line 557
    move-object v1, v2

    .line 558
    move-object/from16 v2, p0

    .line 559
    .line 560
    invoke-direct/range {v0 .. v5}, Lp1/d;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/Object;II)V

    .line 561
    .line 562
    .line 563
    sget-object v2, Lp1/f;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 564
    .line 565
    new-instance v3, Lg8/z;

    .line 566
    .line 567
    invoke-direct {v3, v6, v1}, Lg8/z;-><init>(ILjava/lang/Object;)V

    .line 568
    .line 569
    .line 570
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 571
    .line 572
    .line 573
    move-result-object v1

    .line 574
    if-nez v1, :cond_249

    .line 575
    .line 576
    new-instance v1, Landroid/os/Handler;

    .line 577
    .line 578
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 579
    .line 580
    .line 581
    move-result-object v5

    .line 582
    invoke-direct {v1, v5}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 583
    .line 584
    .line 585
    goto :goto_24e

    .line 586
    :cond_249
    new-instance v1, Landroid/os/Handler;

    .line 587
    .line 588
    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    .line 589
    .line 590
    .line 591
    :goto_24e
    new-instance v5, Lcom/facebook/imagepipeline/producers/y;

    .line 592
    .line 593
    invoke-direct {v5}, Lcom/facebook/imagepipeline/producers/y;-><init>()V

    .line 594
    .line 595
    .line 596
    iput-object v0, v5, Lcom/facebook/imagepipeline/producers/y;->e:Ljava/lang/Object;

    .line 597
    .line 598
    iput-object v3, v5, Lcom/facebook/imagepipeline/producers/y;->i:Ljava/lang/Object;

    .line 599
    .line 600
    iput-object v1, v5, Lcom/facebook/imagepipeline/producers/y;->v:Ljava/lang/Object;

    .line 601
    .line 602
    invoke-virtual {v2, v5}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 603
    .line 604
    .line 605
    :goto_25c
    move-object/from16 v5, p2

    .line 606
    .line 607
    goto :goto_284

    .line 608
    :goto_25f
    :try_start_25f
    monitor-exit v3
    :try_end_260
    .catchall {:try_start_25f .. :try_end_260} :catchall_21a

    .line 609
    throw v0

    .line 610
    :cond_261
    sget-object v3, Li1/d;->a:Lk80/d;

    .line 611
    .line 612
    check-cast v0, Lh1/e;

    .line 613
    .line 614
    move-object/from16 v5, p2

    .line 615
    .line 616
    invoke-virtual {v3, v2, v0, v5, v4}, Lk80/d;->k(Landroid/content/Context;Lh1/e;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;

    .line 617
    .line 618
    .line 619
    move-result-object v9

    .line 620
    if-eqz v1, :cond_284

    .line 621
    .line 622
    if-eqz v9, :cond_281

    .line 623
    .line 624
    new-instance v0, Landroid/os/Handler;

    .line 625
    .line 626
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 627
    .line 628
    .line 629
    move-result-object v2

    .line 630
    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 631
    .line 632
    .line 633
    new-instance v2, Lf4/q0;

    .line 634
    .line 635
    invoke-direct {v2, v6, v1, v9}, Lf4/q0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 636
    .line 637
    .line 638
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 639
    .line 640
    .line 641
    goto :goto_284

    .line 642
    :cond_281
    invoke-virtual {v1, v7}, Lh1/b;->a(I)V

    .line 643
    .line 644
    .line 645
    :cond_284
    :goto_284
    if-eqz v9, :cond_28f

    .line 646
    .line 647
    sget-object v0, Li1/d;->b:Le6/r1;

    .line 648
    .line 649
    invoke-static/range {p2 .. p6}, Li1/d;->b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;

    .line 650
    .line 651
    .line 652
    move-result-object v1

    .line 653
    invoke-virtual {v0, v1, v9}, Le6/r1;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 654
    .line 655
    .line 656
    :cond_28f
    return-object v9
.end method

.method public static b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;
    .registers 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const/16 p0, 0x2d

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method

.method public static c(Ljava/lang/String;)Landroid/graphics/Typeface;
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p0, :cond_1e

    .line 3
    .line 4
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-eqz v1, :cond_a

    .line 9
    .line 10
    goto :goto_1e

    .line 11
    :cond_a
    const/4 v1, 0x0

    .line 12
    invoke-static {p0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 17
    .line 18
    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-eqz p0, :cond_1e

    .line 23
    .line 24
    invoke-virtual {p0, v1}, Landroid/graphics/Typeface;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-nez v1, :cond_1e

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1e
    :goto_1e
    return-object v0
.end method

.method public static d(Landroid/graphics/Typeface;)Landroid/graphics/fonts/Font;
    .registers 11

    .line 1
    sget-object v0, Li1/d;->c:Landroid/graphics/Paint;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Landroid/graphics/Paint;

    .line 6
    .line 7
    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    .line 8
    .line 9
    .line 10
    sput-object v0, Li1/d;->c:Landroid/graphics/Paint;

    .line 11
    .line 12
    :cond_b
    sget-object v0, Li1/d;->c:Landroid/graphics/Paint;

    .line 13
    .line 14
    const/high16 v1, 0x41200000    # 10.0f

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 17
    .line 18
    .line 19
    sget-object v0, Li1/d;->c:Landroid/graphics/Paint;

    .line 20
    .line 21
    invoke-virtual {v0, p0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 22
    .line 23
    .line 24
    const/4 v8, 0x0

    .line 25
    sget-object v9, Li1/d;->c:Landroid/graphics/Paint;

    .line 26
    .line 27
    const-string v1, " "

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    const/4 v4, 0x0

    .line 32
    const/4 v5, 0x1

    .line 33
    const/4 v6, 0x0

    .line 34
    const/4 v7, 0x0

    .line 35
    invoke-static/range {v1 .. v9}, Landroid/graphics/text/TextRunShaper;->shapeTextRun(Ljava/lang/CharSequence;IIIIFFZLandroid/graphics/Paint;)Landroid/graphics/text/PositionedGlyphs;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-virtual {p0}, Landroid/graphics/text/PositionedGlyphs;->glyphCount()I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-nez v0, :cond_2e

    .line 44
    .line 45
    const/4 p0, 0x0

    .line 46
    return-object p0

    .line 47
    :cond_2e
    const/4 v0, 0x0

    .line 48
    invoke-virtual {p0, v0}, Landroid/graphics/text/PositionedGlyphs;->getFont(I)Landroid/graphics/fonts/Font;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0
.end method
