###### Class i1.g (i1.g)
.class public Li1/g;
.super Li1/e;
.source "SourceFile"


# instance fields
.field public final k:Ljava/lang/Class;

.field public final l:Ljava/lang/reflect/Constructor;

.field public final m:Ljava/lang/reflect/Method;

.field public final n:Ljava/lang/reflect/Method;

.field public final o:Ljava/lang/reflect/Method;

.field public final p:Ljava/lang/reflect/Method;

.field public final q:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>()V
    .registers 10

    .line 1
    invoke-direct {p0}, Lk80/d;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :try_start_4
    const-string v1, "android.graphics.FontFamily"

    .line 6
    .line 7
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-static {v1}, Li1/g;->b0(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    const-string v4, "addFontFromBuffer"

    .line 20
    .line 21
    const-class v5, Ljava/nio/ByteBuffer;

    .line 22
    .line 23
    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 24
    .line 25
    const-class v7, [Landroid/graphics/fonts/FontVariationAxis;

    .line 26
    .line 27
    filled-new-array {v5, v6, v7, v6, v6}, [Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    invoke-virtual {v1, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    const-string v5, "freeze"

    .line 36
    .line 37
    invoke-virtual {v1, v5, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    const-string v6, "abortCreation"

    .line 42
    .line 43
    invoke-virtual {v1, v6, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    invoke-virtual {p0, v1}, Li1/g;->c0(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 48
    .line 49
    .line 50
    move-result-object v0
    :try_end_32
    .catch Ljava/lang/ClassNotFoundException; {:try_start_4 .. :try_end_32} :catch_38
    .catch Ljava/lang/NoSuchMethodException; {:try_start_4 .. :try_end_32} :catch_36

    .line 51
    move-object v8, v1

    .line 52
    move-object v1, v0

    .line 53
    move-object v0, v8

    .line 54
    goto :goto_52

    .line 55
    :catch_36
    move-exception v1

    .line 56
    goto :goto_39

    .line 57
    :catch_38
    move-exception v1

    .line 58
    :goto_39
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    const-string v3, "Unable to collect necessary methods for class "

    .line 67
    .line 68
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    const-string v3, "TypefaceCompatApi26Impl"

    .line 73
    .line 74
    invoke-static {v3, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 75
    .line 76
    .line 77
    move-object v1, v0

    .line 78
    move-object v2, v1

    .line 79
    move-object v3, v2

    .line 80
    move-object v4, v3

    .line 81
    move-object v5, v4

    .line 82
    move-object v6, v5

    .line 83
    :goto_52
    iput-object v0, p0, Li1/g;->k:Ljava/lang/Class;

    .line 84
    .line 85
    iput-object v2, p0, Li1/g;->l:Ljava/lang/reflect/Constructor;

    .line 86
    .line 87
    iput-object v3, p0, Li1/g;->m:Ljava/lang/reflect/Method;

    .line 88
    .line 89
    iput-object v4, p0, Li1/g;->n:Ljava/lang/reflect/Method;

    .line 90
    .line 91
    iput-object v5, p0, Li1/g;->o:Ljava/lang/reflect/Method;

    .line 92
    .line 93
    iput-object v6, p0, Li1/g;->p:Ljava/lang/reflect/Method;

    .line 94
    .line 95
    iput-object v1, p0, Li1/g;->q:Ljava/lang/reflect/Method;

    .line 96
    .line 97
    return-void
.end method

.method public static b0(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .registers 9

    .line 1
    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 2
    .line 3
    const-class v7, [Landroid/graphics/fonts/FontVariationAxis;

    .line 4
    .line 5
    const-class v0, Landroid/content/res/AssetManager;

    .line 6
    .line 7
    const-class v1, Ljava/lang/String;

    .line 8
    .line 9
    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 10
    .line 11
    move-object v4, v2

    .line 12
    move-object v5, v2

    .line 13
    move-object v6, v2

    .line 14
    filled-new-array/range {v0 .. v7}, [Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const-string v1, "addFontFromAssetManager"

    .line 19
    .line 20
    invoke-virtual {p0, v1, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method


# virtual methods
.method public final Y(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;III[Landroid/graphics/fonts/FontVariationAxis;)Z
    .registers 18

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_1
    iget-object v1, p0, Li1/g;->m:Ljava/lang/reflect/Method;

    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 9
    .line 10
    .line 11
    move-result-object v4

    .line 12
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 13
    .line 14
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v6

    .line 18
    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v7

    .line 22
    invoke-static/range {p6 .. p6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v8

    .line 26
    move-object v3, p3

    .line 27
    move-object/from16 v9, p7

    .line 28
    .line 29
    filled-new-array/range {v2 .. v9}, [Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {v1, p2, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    check-cast p1, Ljava/lang/Boolean;

    .line 38
    .line 39
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 40
    .line 41
    .line 42
    move-result p1
    :try_end_2a
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_2a} :catch_2b
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_2a} :catch_2b

    .line 43
    return p1

    .line 44
    :catch_2b
    return v0
.end method

.method public Z(Ljava/lang/Object;)Landroid/graphics/Typeface;
    .registers 6

    .line 1
    const/4 v0, -0x1

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    const/4 v1, 0x0

    .line 7
    :try_start_6
    iget-object v2, p0, Li1/g;->k:Ljava/lang/Class;

    .line 8
    .line 9
    const/4 v3, 0x1

    .line 10
    invoke-static {v2, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-static {v2, v3, p1}, Ljava/lang/reflect/Array;->set(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object p1, p0, Li1/g;->q:Ljava/lang/reflect/Method;

    .line 19
    .line 20
    filled-new-array {v2, v0, v0}, [Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {p1, v1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, Landroid/graphics/Typeface;
    :try_end_1d
    .catch Ljava/lang/IllegalAccessException; {:try_start_6 .. :try_end_1d} :catch_1e
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_6 .. :try_end_1d} :catch_1e

    .line 29
    .line 30
    return-object p1

    .line 31
    :catch_1e
    return-object v1
.end method

.method public final a0(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Li1/g;->o:Ljava/lang/reflect/Method;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    check-cast p1, Ljava/lang/Boolean;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 11
    .line 12
    .line 13
    move-result p1
    :try_end_d
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_d} :catch_e
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_d} :catch_e

    .line 14
    return p1

    .line 15
    :catch_e
    const/4 p1, 0x0

    .line 16
    return p1
.end method

.method public c0(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 11
    .line 12
    filled-new-array {p1, v1, v1}, [Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const-class v1, Landroid/graphics/Typeface;

    .line 17
    .line 18
    const-string v2, "createFromFamiliesWithDefault"

    .line 19
    .line 20
    invoke-virtual {v1, v2, p1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {p1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 25
    .line 26
    .line 27
    return-object p1
.end method

.method public final k(Landroid/content/Context;Lh1/e;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
    .registers 14

    .line 1
    iget-object v0, p0, Li1/g;->m:Ljava/lang/reflect/Method;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    const-string v1, "TypefaceCompatApi26Impl"

    .line 6
    .line 7
    const-string v2, "Unable to collect necessary private methods. Fallback to legacy implementation."

    .line 8
    .line 9
    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    :cond_b
    if-eqz v0, :cond_51

    .line 13
    .line 14
    const/4 p3, 0x0

    .line 15
    :try_start_e
    iget-object p4, p0, Li1/g;->l:Ljava/lang/reflect/Constructor;

    .line 16
    .line 17
    invoke-virtual {p4, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p4
    :try_end_14
    .catch Ljava/lang/IllegalAccessException; {:try_start_e .. :try_end_14} :catch_16
    .catch Ljava/lang/InstantiationException; {:try_start_e .. :try_end_14} :catch_16
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_e .. :try_end_14} :catch_16

    .line 21
    move-object v2, p4

    .line 22
    goto :goto_17

    .line 23
    :catch_16
    move-object v2, p3

    .line 24
    :goto_17
    if-nez v2, :cond_1b

    .line 25
    .line 26
    move-object v0, p0

    .line 27
    goto :goto_4b

    .line 28
    :cond_1b
    iget-object p2, p2, Lh1/e;->a:[Lh1/f;

    .line 29
    .line 30
    array-length p4, p2

    .line 31
    const/4 v0, 0x0

    .line 32
    move v8, v0

    .line 33
    :goto_20
    if-ge v8, p4, :cond_44

    .line 34
    .line 35
    aget-object v0, p2, v8

    .line 36
    .line 37
    iget-object v3, v0, Lh1/f;->a:Ljava/lang/String;

    .line 38
    .line 39
    iget v4, v0, Lh1/f;->e:I

    .line 40
    .line 41
    iget v5, v0, Lh1/f;->b:I

    .line 42
    .line 43
    iget-boolean v6, v0, Lh1/f;->c:Z

    .line 44
    .line 45
    iget-object v0, v0, Lh1/f;->d:Ljava/lang/String;

    .line 46
    .line 47
    invoke-static {v0}, Landroid/graphics/fonts/FontVariationAxis;->fromFontVariationSettings(Ljava/lang/String;)[Landroid/graphics/fonts/FontVariationAxis;

    .line 48
    .line 49
    .line 50
    move-result-object v7

    .line 51
    move-object v0, p0

    .line 52
    move-object v1, p1

    .line 53
    invoke-virtual/range {v0 .. v7}, Li1/g;->Y(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;III[Landroid/graphics/fonts/FontVariationAxis;)Z

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    if-nez p1, :cond_40

    .line 58
    .line 59
    :try_start_3a
    iget-object p1, v0, Li1/g;->p:Ljava/lang/reflect/Method;

    .line 60
    .line 61
    invoke-virtual {p1, v2, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3f
    .catch Ljava/lang/IllegalAccessException; {:try_start_3a .. :try_end_3f} :catch_4b
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3a .. :try_end_3f} :catch_4b

    .line 62
    .line 63
    .line 64
    goto :goto_4b

    .line 65
    :cond_40
    add-int/lit8 v8, v8, 0x1

    .line 66
    .line 67
    move-object p1, v1

    .line 68
    goto :goto_20

    .line 69
    :cond_44
    move-object v0, p0

    .line 70
    invoke-virtual {p0, v2}, Li1/g;->a0(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    if-nez p1, :cond_4c

    .line 75
    .line 76
    :catch_4b
    :goto_4b
    return-object p3

    .line 77
    :cond_4c
    invoke-virtual {p0, v2}, Li1/g;->Z(Ljava/lang/Object;)Landroid/graphics/Typeface;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    return-object p1

    .line 82
    :cond_51
    move-object v0, p0

    .line 83
    move-object v1, p1

    .line 84
    invoke-super {p0, v1, p2, p3, p4}, Li1/e;->k(Landroid/content/Context;Lh1/e;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    return-object p1
.end method

.method public final l(Landroid/content/Context;[Lp1/g;I)Landroid/graphics/Typeface;
    .registers 16

    .line 1
    array-length v0, p2

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x1

    .line 4
    if-ge v0, v2, :cond_7

    .line 5
    .line 6
    goto/16 :goto_e2

    .line 7
    .line 8
    :cond_7
    iget-object v0, p0, Li1/g;->m:Ljava/lang/reflect/Method;

    .line 9
    .line 10
    if-nez v0, :cond_12

    .line 11
    .line 12
    const-string v3, "TypefaceCompatApi26Impl"

    .line 13
    .line 14
    const-string v4, "Unable to collect necessary private methods. Fallback to legacy implementation."

    .line 15
    .line 16
    invoke-static {v3, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 17
    .line 18
    .line 19
    :cond_12
    if-eqz v0, :cond_a3

    .line 20
    .line 21
    new-instance v0, Ljava/util/HashMap;

    .line 22
    .line 23
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 24
    .line 25
    .line 26
    array-length v3, p2

    .line 27
    const/4 v4, 0x0

    .line 28
    move v5, v4

    .line 29
    :goto_1c
    if-ge v5, v3, :cond_38

    .line 30
    .line 31
    aget-object v6, p2, v5

    .line 32
    .line 33
    iget v7, v6, Lp1/g;->f:I

    .line 34
    .line 35
    if-eqz v7, :cond_25

    .line 36
    .line 37
    goto :goto_35

    .line 38
    :cond_25
    iget-object v6, v6, Lp1/g;->a:Landroid/net/Uri;

    .line 39
    .line 40
    invoke-virtual {v0, v6}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v7

    .line 44
    if-eqz v7, :cond_2e

    .line 45
    .line 46
    goto :goto_35

    .line 47
    :cond_2e
    invoke-static {p1, v6}, Lk80/l;->Q(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    .line 48
    .line 49
    .line 50
    move-result-object v7

    .line 51
    invoke-virtual {v0, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    :goto_35
    add-int/lit8 v5, v5, 0x1

    .line 55
    .line 56
    goto :goto_1c

    .line 57
    :cond_38
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    :try_start_3c
    iget-object v0, p0, Li1/g;->l:Ljava/lang/reflect/Constructor;

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0
    :try_end_42
    .catch Ljava/lang/IllegalAccessException; {:try_start_3c .. :try_end_42} :catch_43
    .catch Ljava/lang/InstantiationException; {:try_start_3c .. :try_end_42} :catch_43
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3c .. :try_end_42} :catch_43

    .line 67
    goto :goto_44

    .line 68
    :catch_43
    move-object v0, v1

    .line 69
    :goto_44
    if-nez v0, :cond_48

    .line 70
    .line 71
    goto/16 :goto_e2

    .line 72
    .line 73
    :cond_48
    array-length v3, p2

    .line 74
    move v5, v4

    .line 75
    move v6, v5

    .line 76
    :goto_4b
    iget-object v7, p0, Li1/g;->p:Ljava/lang/reflect/Method;

    .line 77
    .line 78
    if-ge v5, v3, :cond_8a

    .line 79
    .line 80
    aget-object v8, p2, v5

    .line 81
    .line 82
    iget-object v9, v8, Lp1/g;->a:Landroid/net/Uri;

    .line 83
    .line 84
    invoke-interface {p1, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v9

    .line 88
    check-cast v9, Ljava/nio/ByteBuffer;

    .line 89
    .line 90
    if-nez v9, :cond_5c

    .line 91
    .line 92
    goto :goto_87

    .line 93
    :cond_5c
    iget v6, v8, Lp1/g;->b:I

    .line 94
    .line 95
    iget v10, v8, Lp1/g;->c:I

    .line 96
    .line 97
    iget-boolean v8, v8, Lp1/g;->d:Z

    .line 98
    .line 99
    :try_start_62
    iget-object v11, p0, Li1/g;->n:Ljava/lang/reflect/Method;

    .line 100
    .line 101
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 106
    .line 107
    .line 108
    move-result-object v10

    .line 109
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object v8

    .line 113
    filled-new-array {v9, v6, v1, v10, v8}, [Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v6

    .line 117
    invoke-virtual {v11, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    check-cast v6, Ljava/lang/Boolean;

    .line 122
    .line 123
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 124
    .line 125
    .line 126
    move-result v6
    :try_end_7e
    .catch Ljava/lang/IllegalAccessException; {:try_start_62 .. :try_end_7e} :catch_7f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_62 .. :try_end_7e} :catch_7f

    .line 127
    goto :goto_80

    .line 128
    :catch_7f
    move v6, v4

    .line 129
    :goto_80
    if-nez v6, :cond_86

    .line 130
    .line 131
    :try_start_82
    invoke-virtual {v7, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    goto :goto_e2

    .line 135
    :cond_86
    move v6, v2

    .line 136
    :goto_87
    add-int/lit8 v5, v5, 0x1

    .line 137
    .line 138
    goto :goto_4b

    .line 139
    :cond_8a
    if-nez v6, :cond_90

    .line 140
    .line 141
    invoke-virtual {v7, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_8f
    .catch Ljava/lang/IllegalAccessException; {:try_start_82 .. :try_end_8f} :catch_e2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_82 .. :try_end_8f} :catch_e2

    .line 142
    .line 143
    .line 144
    goto :goto_e2

    .line 145
    :cond_90
    invoke-virtual {p0, v0}, Li1/g;->a0(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result p1

    .line 149
    if-nez p1, :cond_97

    .line 150
    .line 151
    goto :goto_e2

    .line 152
    :cond_97
    invoke-virtual {p0, v0}, Li1/g;->Z(Ljava/lang/Object;)Landroid/graphics/Typeface;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    if-nez p1, :cond_9e

    .line 157
    .line 158
    goto :goto_e2

    .line 159
    :cond_9e
    invoke-static {p1, p3}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    return-object p1

    .line 164
    :cond_a3
    invoke-static {p2, p3}, Lk80/d;->t([Lp1/g;I)Lp1/g;

    .line 165
    .line 166
    .line 167
    move-result-object p2

    .line 168
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    :try_start_ab
    iget-object p3, p2, Lp1/g;->a:Landroid/net/Uri;

    .line 173
    .line 174
    const-string v0, "r"

    .line 175
    .line 176
    invoke-virtual {p1, p3, v0, v1}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    if-nez p1, :cond_bb

    .line 181
    .line 182
    if-eqz p1, :cond_e2

    .line 183
    .line 184
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_ba
    .catch Ljava/io/IOException; {:try_start_ab .. :try_end_ba} :catch_e2

    .line 185
    .line 186
    .line 187
    return-object v1

    .line 188
    :cond_bb
    :try_start_bb
    new-instance p3, Landroid/graphics/Typeface$Builder;

    .line 189
    .line 190
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    invoke-direct {p3, v0}, Landroid/graphics/Typeface$Builder;-><init>(Ljava/io/FileDescriptor;)V

    .line 195
    .line 196
    .line 197
    iget v0, p2, Lp1/g;->c:I

    .line 198
    .line 199
    invoke-virtual {p3, v0}, Landroid/graphics/Typeface$Builder;->setWeight(I)Landroid/graphics/Typeface$Builder;

    .line 200
    .line 201
    .line 202
    move-result-object p3

    .line 203
    iget-boolean p2, p2, Lp1/g;->d:Z

    .line 204
    .line 205
    invoke-virtual {p3, p2}, Landroid/graphics/Typeface$Builder;->setItalic(Z)Landroid/graphics/Typeface$Builder;

    .line 206
    .line 207
    .line 208
    move-result-object p2

    .line 209
    invoke-virtual {p2}, Landroid/graphics/Typeface$Builder;->build()Landroid/graphics/Typeface;

    .line 210
    .line 211
    .line 212
    move-result-object p2
    :try_end_d4
    .catchall {:try_start_bb .. :try_end_d4} :catchall_d8

    .line 213
    :try_start_d4
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_d7
    .catch Ljava/io/IOException; {:try_start_d4 .. :try_end_d7} :catch_e2

    .line 214
    .line 215
    .line 216
    return-object p2

    .line 217
    :catchall_d8
    move-exception p2

    .line 218
    :try_start_d9
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_dc
    .catchall {:try_start_d9 .. :try_end_dc} :catchall_dd

    .line 219
    .line 220
    .line 221
    goto :goto_e1

    .line 222
    :catchall_dd
    move-exception p1

    .line 223
    :try_start_de
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 224
    .line 225
    .line 226
    :goto_e1
    throw p2
    :try_end_e2
    .catch Ljava/io/IOException; {:try_start_de .. :try_end_e2} :catch_e2

    .line 227
    :catch_e2
    :cond_e2
    :goto_e2
    return-object v1
.end method

.method public final n(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    .registers 15

    .line 1
    iget-object v0, p0, Li1/g;->m:Ljava/lang/reflect/Method;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    const-string v1, "TypefaceCompatApi26Impl"

    .line 6
    .line 7
    const-string v2, "Unable to collect necessary private methods. Fallback to legacy implementation."

    .line 8
    .line 9
    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    :cond_b
    if-eqz v0, :cond_3a

    .line 13
    .line 14
    const/4 p2, 0x0

    .line 15
    :try_start_e
    iget-object p3, p0, Li1/g;->l:Ljava/lang/reflect/Constructor;

    .line 16
    .line 17
    invoke-virtual {p3, p2}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p3
    :try_end_14
    .catch Ljava/lang/IllegalAccessException; {:try_start_e .. :try_end_14} :catch_16
    .catch Ljava/lang/InstantiationException; {:try_start_e .. :try_end_14} :catch_16
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_e .. :try_end_14} :catch_16

    .line 21
    move-object v2, p3

    .line 22
    goto :goto_17

    .line 23
    :catch_16
    move-object v2, p2

    .line 24
    :goto_17
    if-nez v2, :cond_1b

    .line 25
    .line 26
    move-object v0, p0

    .line 27
    goto :goto_34

    .line 28
    :cond_1b
    const/4 v6, -0x1

    .line 29
    const/4 v7, 0x0

    .line 30
    const/4 v4, 0x0

    .line 31
    const/4 v5, -0x1

    .line 32
    move-object v0, p0

    .line 33
    move-object v1, p1

    .line 34
    move-object v3, p4

    .line 35
    invoke-virtual/range {v0 .. v7}, Li1/g;->Y(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;III[Landroid/graphics/fonts/FontVariationAxis;)Z

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    if-nez p1, :cond_2e

    .line 40
    .line 41
    :try_start_28
    iget-object p1, v0, Li1/g;->p:Ljava/lang/reflect/Method;

    .line 42
    .line 43
    invoke-virtual {p1, v2, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2d
    .catch Ljava/lang/IllegalAccessException; {:try_start_28 .. :try_end_2d} :catch_34
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_28 .. :try_end_2d} :catch_34

    .line 44
    .line 45
    .line 46
    goto :goto_34

    .line 47
    :cond_2e
    invoke-virtual {p0, v2}, Li1/g;->a0(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-nez p1, :cond_35

    .line 52
    .line 53
    :catch_34
    :goto_34
    return-object p2

    .line 54
    :cond_35
    invoke-virtual {p0, v2}, Li1/g;->Z(Ljava/lang/Object;)Landroid/graphics/Typeface;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    return-object p1

    .line 59
    :cond_3a
    move-object v3, p0

    .line 60
    move-object v4, p1

    .line 61
    move-object v5, p2

    .line 62
    move v6, p3

    .line 63
    move-object v7, p4

    .line 64
    move v8, p5

    .line 65
    invoke-super/range {v3 .. v8}, Lk80/d;->n(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    return-object p1
.end method
