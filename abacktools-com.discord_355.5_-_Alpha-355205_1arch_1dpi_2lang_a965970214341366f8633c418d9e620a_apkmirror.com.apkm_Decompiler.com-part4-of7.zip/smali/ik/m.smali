###### Class ik.m (ik.m)
.class public final Lik/m;
.super Ls30/i;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public synthetic d:Ljava/lang/Object;

.field public final synthetic e:Lik/o;

.field public final synthetic i:Lc9/q;

.field public final synthetic v:Ljava/lang/String;

.field public final synthetic w:Ljava/lang/String;

.field public final synthetic x:Ljava/lang/String;

.field public final synthetic y:Z


# direct methods
.method public constructor <init>(Lik/o;Lc9/q;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLq30/c;)V
    .registers 8

    .line 1
    iput-object p1, p0, Lik/m;->e:Lik/o;

    .line 2
    .line 3
    iput-object p2, p0, Lik/m;->i:Lc9/q;

    .line 4
    .line 5
    iput-object p3, p0, Lik/m;->v:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p4, p0, Lik/m;->w:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p5, p0, Lik/m;->x:Ljava/lang/String;

    .line 10
    .line 11
    iput-boolean p6, p0, Lik/m;->y:Z

    .line 12
    .line 13
    const/4 p1, 0x2

    .line 14
    invoke-direct {p0, p1, p7}, Ls30/i;-><init>(ILq30/c;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lq30/c;)Lq30/c;
    .registers 11

    .line 1
    new-instance v0, Lik/m;

    .line 2
    .line 3
    iget-object v5, p0, Lik/m;->x:Ljava/lang/String;

    .line 4
    .line 5
    iget-boolean v6, p0, Lik/m;->y:Z

    .line 6
    .line 7
    iget-object v1, p0, Lik/m;->e:Lik/o;

    .line 8
    .line 9
    iget-object v2, p0, Lik/m;->i:Lc9/q;

    .line 10
    .line 11
    iget-object v3, p0, Lik/m;->v:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v4, p0, Lik/m;->w:Ljava/lang/String;

    .line 14
    .line 15
    move-object v7, p2

    .line 16
    invoke-direct/range {v0 .. v7}, Lik/m;-><init>(Lik/o;Lc9/q;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLq30/c;)V

    .line 17
    .line 18
    .line 19
    iput-object p1, v0, Lik/m;->d:Ljava/lang/Object;

    .line 20
    .line 21
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Lz60/x;

    .line 2
    .line 3
    check-cast p2, Lq30/c;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lik/m;->create(Ljava/lang/Object;Lq30/c;)Lq30/c;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lik/m;

    .line 10
    .line 11
    sget-object p2, Ll30/a0;->a:Ll30/a0;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lik/m;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v1, Lr30/a;->d:Lr30/a;

    .line 4
    .line 5
    invoke-static/range {p1 .. p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lik/m;->d:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lz60/x;

    .line 11
    .line 12
    iget-object v2, v0, Lik/m;->e:Lik/o;

    .line 13
    .line 14
    iget-object v3, v2, Lik/o;->f:Ll30/o;

    .line 15
    .line 16
    iget-object v2, v2, Lik/o;->d:Ljava/util/LinkedHashMap;

    .line 17
    .line 18
    invoke-virtual {v3}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    move-object v6, v3

    .line 23
    check-cast v6, Lq1/l;

    .line 24
    .line 25
    sget-object v3, Ll30/a0;->a:Ll30/a0;

    .line 26
    .line 27
    iget-object v4, v0, Lik/m;->i:Lc9/q;

    .line 28
    .line 29
    if-eqz v6, :cond_73

    .line 30
    .line 31
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 32
    .line 33
    const/16 v7, 0x1a

    .line 34
    .line 35
    if-ge v5, v7, :cond_25

    .line 36
    .line 37
    goto :goto_73

    .line 38
    :cond_25
    iget-object v5, v0, Lik/m;->v:Ljava/lang/String;

    .line 39
    .line 40
    invoke-interface {v2, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v7

    .line 44
    const/4 v11, 0x0

    .line 45
    if-eqz v7, :cond_32

    .line 46
    .line 47
    invoke-virtual {v4, v11}, Lc9/q;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    return-object v3

    .line 51
    :cond_32
    new-instance v8, Lq1/a;

    .line 52
    .line 53
    iget-object v7, v0, Lik/m;->x:Ljava/lang/String;

    .line 54
    .line 55
    const-string v9, "discord:"

    .line 56
    .line 57
    invoke-static {v7, v9}, Lw60/o;->D0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    const-string v9, "discord"

    .line 62
    .line 63
    invoke-static {v9, v7, v11}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 64
    .line 65
    .line 66
    move-result-object v14

    .line 67
    const-string v7, "fromParts(...)"

    .line 68
    .line 69
    invoke-static {v14, v7}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-boolean v7, v0, Lik/m;->y:Z

    .line 73
    .line 74
    if-eqz v7, :cond_4e

    .line 75
    .line 76
    const/4 v7, 0x2

    .line 77
    :goto_4c
    move v15, v7

    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    const/4 v7, 0x1

    .line 80
    goto :goto_4c

    .line 81
    :goto_50
    const/16 v16, 0x0

    .line 82
    .line 83
    const/16 v17, 0x60

    .line 84
    .line 85
    iget-object v13, v0, Lik/m;->w:Ljava/lang/String;

    .line 86
    .line 87
    move-object v12, v8

    .line 88
    invoke-direct/range {v12 .. v17}, Lq1/a;-><init>(Ljava/lang/CharSequence;Landroid/net/Uri;ILq1/e;I)V

    .line 89
    .line 90
    .line 91
    new-instance v7, Lik/a;

    .line 92
    .line 93
    invoke-direct {v7, v5, v4}, Lik/a;-><init>(Ljava/lang/String;Lc9/q;)V

    .line 94
    .line 95
    .line 96
    invoke-interface {v2, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    new-instance v4, Landroidx/lifecycle/j0;

    .line 100
    .line 101
    const/4 v9, 0x0

    .line 102
    const/4 v10, 0x6

    .line 103
    iget-object v5, v0, Lik/m;->e:Lik/o;

    .line 104
    .line 105
    invoke-direct/range {v4 .. v10}, Landroidx/lifecycle/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lq30/c;I)V

    .line 106
    .line 107
    .line 108
    const/4 v2, 0x3

    .line 109
    invoke-static {v1, v11, v4, v2}, Lz60/z;->v(Lz60/x;Lq30/h;Lkotlin/jvm/functions/Function2;I)Lz60/r1;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    iput-object v1, v7, Lik/a;->d:Lz60/r1;

    .line 114
    .line 115
    return-object v3

    .line 116
    :cond_73
    :goto_73
    new-instance v1, Lik/f;

    .line 117
    .line 118
    const-string v2, "UNAVAILABLE"

    .line 119
    .line 120
    const-string v5, "System telecom is unavailable"

    .line 121
    .line 122
    invoke-direct {v1, v2, v5}, Lik/f;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v4, v1}, Lc9/q;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    return-object v3
.end method
