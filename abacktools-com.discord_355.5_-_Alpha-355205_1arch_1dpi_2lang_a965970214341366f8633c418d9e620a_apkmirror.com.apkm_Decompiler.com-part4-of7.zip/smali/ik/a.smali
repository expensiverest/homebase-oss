###### Class ik.a (ik.a)
.class public final Lik/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public b:Lc9/q;

.field public final c:Lb70/h;

.field public d:Lz60/r1;

.field public e:Z

.field public f:Z

.field public g:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Lc9/q;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lik/a;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Lik/a;->b:Lc9/q;

    .line 7
    .line 8
    const/4 p1, 0x0

    .line 9
    const/4 p2, 0x6

    .line 10
    const v0, 0x7fffffff

    .line 11
    .line 12
    .line 13
    invoke-static {v0, p2, p1}, Lu6/a;->a(IILb70/a;)Lb70/h;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    iput-object p1, p0, Lik/a;->c:Lb70/h;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final a(Lik/f;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lik/a;->b:Lc9/q;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v1, 0x0

    .line 7
    iput-object v1, p0, Lik/a;->b:Lc9/q;

    .line 8
    .line 9
    if-nez p1, :cond_c

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 v1, 0x0

    .line 14
    :goto_d
    iput-boolean v1, p0, Lik/a;->e:Z

    .line 15
    .line 16
    invoke-virtual {v0, p1}, Lc9/q;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-void
.end method
