###### Class ik.o (ik.o)
.class public final Lik/o;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroidx/lifecycle/t0;

.field public final b:Landroid/content/Context;

.field public final c:Le70/d;

.field public final d:Ljava/util/LinkedHashMap;

.field public e:Lcom/discord/telecom/system/SystemTelecomModule;

.field public final f:Ll30/o;


# direct methods
.method public constructor <init>(Lcom/facebook/react/bridge/ReactApplicationContext;Landroidx/lifecycle/t0;)V
    .registers 4

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lik/o;->a:Landroidx/lifecycle/t0;

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    iput-object p1, p0, Lik/o;->b:Landroid/content/Context;

    .line 16
    .line 17
    new-instance p1, Lz60/s1;

    .line 18
    .line 19
    invoke-direct {p1}, Lz60/e1;-><init>()V

    .line 20
    .line 21
    .line 22
    sget-object p2, Lz60/k0;->a:Lg70/e;

    .line 23
    .line 24
    sget-object p2, Le70/o;->a:La70/e;

    .line 25
    .line 26
    invoke-static {p1, p2}, Low/a;->y(Lq30/f;Lq30/h;)Lq30/h;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-static {p1}, Lz60/z;->b(Lq30/h;)Le70/d;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    iput-object p1, p0, Lik/o;->c:Le70/d;

    .line 35
    .line 36
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 37
    .line 38
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 39
    .line 40
    .line 41
    iput-object p1, p0, Lik/o;->d:Ljava/util/LinkedHashMap;

    .line 42
    .line 43
    new-instance p1, Landroidx/lifecycle/t0;

    .line 44
    .line 45
    const/16 p2, 0x17

    .line 46
    .line 47
    invoke-direct {p1, p2, p0}, Landroidx/lifecycle/t0;-><init>(ILjava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    invoke-static {p1}, La/a;->K(Lkotlin/jvm/functions/Function0;)Ll30/o;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    iput-object p1, p0, Lik/o;->f:Ll30/o;

    .line 55
    .line 56
    return-void
.end method

.method public static final a(Lik/o;Lq1/l;Lik/a;Lq1/a;Ls30/c;)Ljava/lang/Object;
    .registers 28

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p4

    .line 4
    .line 5
    sget-object v2, Lz60/v;->e:Lz60/v;

    .line 6
    .line 7
    iget-object v3, v1, Lik/o;->d:Ljava/util/LinkedHashMap;

    .line 8
    .line 9
    instance-of v4, v0, Lik/i;

    .line 10
    .line 11
    if-eqz v4, :cond_1b

    .line 12
    .line 13
    move-object v4, v0

    .line 14
    check-cast v4, Lik/i;

    .line 15
    .line 16
    iget v5, v4, Lik/i;->x:I

    .line 17
    .line 18
    const/high16 v6, -0x80000000

    .line 19
    .line 20
    and-int v7, v5, v6

    .line 21
    .line 22
    if-eqz v7, :cond_1b

    .line 23
    .line 24
    sub-int/2addr v5, v6

    .line 25
    iput v5, v4, Lik/i;->x:I

    .line 26
    .line 27
    goto :goto_20

    .line 28
    :cond_1b
    new-instance v4, Lik/i;

    .line 29
    .line 30
    invoke-direct {v4, v1, v0}, Lik/i;-><init>(Lik/o;Ls30/c;)V

    .line 31
    .line 32
    .line 33
    :goto_20
    iget-object v0, v4, Lik/i;->v:Ljava/lang/Object;

    .line 34
    .line 35
    sget-object v5, Lr30/a;->d:Lr30/a;

    .line 36
    .line 37
    iget v6, v4, Lik/i;->x:I

    .line 38
    .line 39
    const-string v7, "System ended call: callId="

    .line 40
    .line 41
    const-string v8, "Call ended before Telecom added it"

    .line 42
    .line 43
    const-string v9, "ADD_CALL_FAILED"

    .line 44
    .line 45
    const/4 v10, 0x2

    .line 46
    const-string v11, "SystemTelecom"

    .line 47
    .line 48
    const/4 v12, 0x1

    .line 49
    const/4 v13, 0x0

    .line 50
    if-eqz v6, :cond_67

    .line 51
    .line 52
    if-eq v6, v12, :cond_5c

    .line 53
    .line 54
    if-ne v6, v10, :cond_54

    .line 55
    .line 56
    iget-object v6, v4, Lik/i;->i:Lq1/a;

    .line 57
    .line 58
    iget-object v14, v4, Lik/i;->e:Lik/a;

    .line 59
    .line 60
    iget-object v15, v4, Lik/i;->d:Lq1/l;

    .line 61
    .line 62
    :try_start_3d
    invoke-static {v0}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V
    :try_end_40
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3d .. :try_end_40} :catch_50
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_40} :catch_4c
    .catchall {:try_start_3d .. :try_end_40} :catchall_48

    .line 63
    .line 64
    .line 65
    move v13, v10

    .line 66
    move-object v10, v0

    .line 67
    move v0, v13

    .line 68
    move v13, v12

    .line 69
    :cond_44
    move-object v12, v4

    .line 70
    move-object v4, v14

    .line 71
    goto/16 :goto_ca

    .line 72
    .line 73
    :catchall_48
    move-exception v0

    .line 74
    move v13, v12

    .line 75
    goto/16 :goto_1f0

    .line 76
    .line 77
    :catch_4c
    move-exception v0

    .line 78
    move v13, v12

    .line 79
    goto/16 :goto_179

    .line 80
    .line 81
    :catch_50
    move-exception v0

    .line 82
    move v13, v12

    .line 83
    goto/16 :goto_1ef

    .line 84
    .line 85
    :cond_54
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 88
    .line 89
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    throw v0

    .line 93
    :cond_5c
    iget-object v6, v4, Lik/i;->i:Lq1/a;

    .line 94
    .line 95
    iget-object v14, v4, Lik/i;->e:Lik/a;

    .line 96
    .line 97
    iget-object v15, v4, Lik/i;->d:Lq1/l;

    .line 98
    .line 99
    :try_start_62
    invoke-static {v0}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V
    :try_end_65
    .catch Ljava/util/concurrent/CancellationException; {:try_start_62 .. :try_end_65} :catch_50
    .catch Ljava/lang/Exception; {:try_start_62 .. :try_end_65} :catch_4c
    .catchall {:try_start_62 .. :try_end_65} :catchall_48

    .line 100
    .line 101
    .line 102
    move v13, v12

    .line 103
    goto :goto_b6

    .line 104
    :cond_67
    invoke-static {v0}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    move-object/from16 v15, p1

    .line 108
    .line 109
    move-object/from16 v0, p3

    .line 110
    .line 111
    move-object v6, v4

    .line 112
    move-object/from16 v4, p2

    .line 113
    .line 114
    :goto_71
    const/4 v14, 0x0

    .line 115
    :try_start_72
    iput-boolean v14, v4, Lik/a;->g:Z
    :try_end_74
    .catch Ljava/util/concurrent/CancellationException; {:try_start_72 .. :try_end_74} :catch_1e9
    .catch Ljava/lang/Exception; {:try_start_72 .. :try_end_74} :catch_174
    .catchall {:try_start_72 .. :try_end_74} :catchall_16f

    .line 116
    .line 117
    :try_start_74
    new-instance v12, Lcom/margelo/nitro/rive/o0;

    .line 118
    .line 119
    const/4 v14, 0x3

    .line 120
    invoke-direct {v12, v10, v13, v14}, Lcom/margelo/nitro/rive/o0;-><init>(ILq30/c;I)V

    .line 121
    .line 122
    .line 123
    new-instance v14, Landroidx/lifecycle/p;

    .line 124
    .line 125
    const/4 v10, 0x7

    .line 126
    invoke-direct {v14, v4, v13, v10}, Landroidx/lifecycle/p;-><init>(Ljava/lang/Object;Lq30/c;I)V

    .line 127
    .line 128
    .line 129
    new-instance v10, Lik/j;
    :try_end_82
    .catch Ljava/util/concurrent/CancellationException; {:try_start_74 .. :try_end_82} :catch_15b
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_82} :catch_156
    .catchall {:try_start_74 .. :try_end_82} :catchall_151

    .line 130
    .line 131
    move-object/from16 v17, v12

    .line 132
    .line 133
    move-object/from16 v18, v14

    .line 134
    .line 135
    const/4 v12, 0x0

    .line 136
    const/4 v14, 0x1

    .line 137
    :try_start_88
    invoke-direct {v10, v14, v13, v12}, Lik/j;-><init>(ILq30/c;I)V

    .line 138
    .line 139
    .line 140
    new-instance v12, Lik/j;

    .line 141
    .line 142
    invoke-direct {v12, v14, v13, v14}, Lik/j;-><init>(ILq30/c;I)V
    :try_end_90
    .catch Ljava/util/concurrent/CancellationException; {:try_start_88 .. :try_end_90} :catch_16a
    .catch Ljava/lang/Exception; {:try_start_88 .. :try_end_90} :catch_165
    .catchall {:try_start_88 .. :try_end_90} :catchall_160

    .line 143
    .line 144
    .line 145
    :try_start_90
    new-instance v14, La70/d;

    .line 146
    .line 147
    const/16 v13, 0x12

    .line 148
    .line 149
    invoke-direct {v14, v13, v1, v4}, La70/d;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    iput-object v15, v6, Lik/i;->d:Lq1/l;

    .line 153
    .line 154
    iput-object v4, v6, Lik/i;->e:Lik/a;

    .line 155
    .line 156
    iput-object v0, v6, Lik/i;->i:Lq1/a;
    :try_end_9d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_90 .. :try_end_9d} :catch_15b
    .catch Ljava/lang/Exception; {:try_start_90 .. :try_end_9d} :catch_156
    .catchall {:try_start_90 .. :try_end_9d} :catchall_151

    .line 157
    .line 158
    const/4 v13, 0x1

    .line 159
    :try_start_9e
    iput v13, v6, Lik/i;->x:I
    :try_end_a0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_9e .. :try_end_a0} :catch_14d
    .catch Ljava/lang/Exception; {:try_start_9e .. :try_end_a0} :catch_149
    .catchall {:try_start_9e .. :try_end_a0} :catchall_145

    .line 160
    .line 161
    move-object/from16 v16, v0

    .line 162
    .line 163
    move-object/from16 v22, v6

    .line 164
    .line 165
    move-object/from16 v19, v10

    .line 166
    .line 167
    move-object/from16 v20, v12

    .line 168
    .line 169
    move-object/from16 v21, v14

    .line 170
    .line 171
    :try_start_aa
    invoke-virtual/range {v15 .. v22}, Lq1/l;->a(Lq1/a;Lcom/margelo/nitro/rive/o0;Landroidx/lifecycle/p;Lik/j;Lik/j;La70/d;Lik/i;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v0
    :try_end_ae
    .catch Ljava/util/concurrent/CancellationException; {:try_start_aa .. :try_end_ae} :catch_13f
    .catch Ljava/lang/Exception; {:try_start_aa .. :try_end_ae} :catch_13a
    .catchall {:try_start_aa .. :try_end_ae} :catchall_134

    .line 175
    if-ne v0, v5, :cond_b1

    .line 176
    .line 177
    goto :goto_c9

    .line 178
    :cond_b1
    move-object v14, v4

    .line 179
    move-object/from16 v6, v16

    .line 180
    .line 181
    move-object/from16 v4, v22

    .line 182
    .line 183
    :goto_b6
    :try_start_b6
    iget-boolean v0, v14, Lik/a;->g:Z

    .line 184
    .line 185
    if-eqz v0, :cond_f3

    .line 186
    .line 187
    iput-object v15, v4, Lik/i;->d:Lq1/l;

    .line 188
    .line 189
    iput-object v14, v4, Lik/i;->e:Lik/a;

    .line 190
    .line 191
    iput-object v6, v4, Lik/i;->i:Lq1/a;

    .line 192
    .line 193
    const/4 v0, 0x2

    .line 194
    iput v0, v4, Lik/i;->x:I

    .line 195
    .line 196
    invoke-virtual {v1, v14, v4}, Lik/o;->d(Lik/a;Ls30/c;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v10
    :try_end_c7
    .catch Ljava/util/concurrent/CancellationException; {:try_start_b6 .. :try_end_c7} :catch_f0
    .catch Ljava/lang/Exception; {:try_start_b6 .. :try_end_c7} :catch_ed
    .catchall {:try_start_b6 .. :try_end_c7} :catchall_ea

    .line 200
    if-ne v10, v5, :cond_44

    .line 201
    .line 202
    :goto_c9
    return-object v5

    .line 203
    :goto_ca
    :try_start_ca
    check-cast v10, Ljava/lang/Boolean;

    .line 204
    .line 205
    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    .line 206
    .line 207
    .line 208
    move-result v10
    :try_end_d0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_ca .. :try_end_d0} :catch_e5
    .catch Ljava/lang/Exception; {:try_start_ca .. :try_end_d0} :catch_e0
    .catchall {:try_start_ca .. :try_end_d0} :catchall_db

    .line 209
    if-nez v10, :cond_d5

    .line 210
    .line 211
    move-object v14, v4

    .line 212
    move-object v4, v12

    .line 213
    goto :goto_f3

    .line 214
    :cond_d5
    move v10, v0

    .line 215
    move-object v0, v6

    .line 216
    move-object v6, v12

    .line 217
    move v12, v13

    .line 218
    const/4 v13, 0x0

    .line 219
    goto :goto_71

    .line 220
    :catchall_db
    move-exception v0

    .line 221
    move-object v14, v4

    .line 222
    move-object v4, v12

    .line 223
    goto/16 :goto_1f0

    .line 224
    .line 225
    :catch_e0
    move-exception v0

    .line 226
    move-object v14, v4

    .line 227
    move-object v4, v12

    .line 228
    goto/16 :goto_179

    .line 229
    .line 230
    :catch_e5
    move-exception v0

    .line 231
    move-object v14, v4

    .line 232
    move-object v4, v12

    .line 233
    goto/16 :goto_1ef

    .line 234
    .line 235
    :catchall_ea
    move-exception v0

    .line 236
    goto/16 :goto_1f0

    .line 237
    .line 238
    :catch_ed
    move-exception v0

    .line 239
    goto/16 :goto_179

    .line 240
    .line 241
    :catch_f0
    move-exception v0

    .line 242
    goto/16 :goto_1ef

    .line 243
    .line 244
    :cond_f3
    :goto_f3
    iget-object v0, v14, Lik/a;->c:Lb70/h;

    .line 245
    .line 246
    iget-object v5, v14, Lik/a;->a:Ljava/lang/String;

    .line 247
    .line 248
    const/4 v6, 0x0

    .line 249
    invoke-virtual {v0, v6}, Lb70/h;->b(Ljava/lang/Throwable;)Z

    .line 250
    .line 251
    .line 252
    invoke-interface {v4}, Lq30/c;->getContext()Lq30/h;

    .line 253
    .line 254
    .line 255
    move-result-object v0

    .line 256
    invoke-interface {v0, v2}, Lq30/h;->Z(Lq30/g;)Lq30/f;

    .line 257
    .line 258
    .line 259
    move-result-object v0

    .line 260
    check-cast v0, Lz60/c1;

    .line 261
    .line 262
    if-eqz v0, :cond_10c

    .line 263
    .line 264
    invoke-interface {v0}, Lz60/c1;->c()Z

    .line 265
    .line 266
    .line 267
    move-result v12

    .line 268
    goto :goto_10d

    .line 269
    :cond_10c
    move v12, v13

    .line 270
    :goto_10d
    if-eqz v12, :cond_117

    .line 271
    .line 272
    new-instance v0, Lik/f;

    .line 273
    .line 274
    invoke-direct {v0, v9, v8}, Lik/f;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {v14, v0}, Lik/a;->a(Lik/f;)V

    .line 278
    .line 279
    .line 280
    :cond_117
    invoke-interface {v3, v5, v14}, Ljava/util/Map;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 281
    .line 282
    .line 283
    move-result v0

    .line 284
    if-eqz v0, :cond_1e6

    .line 285
    .line 286
    iget-boolean v0, v14, Lik/a;->e:Z

    .line 287
    .line 288
    if-eqz v0, :cond_1e6

    .line 289
    .line 290
    sget-object v0, Lnf/a;->a:Lnf/a;

    .line 291
    .line 292
    invoke-virtual {v7, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    const/4 v6, 0x0

    .line 297
    invoke-static {v11, v0, v6}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 298
    .line 299
    .line 300
    iget-object v0, v1, Lik/o;->e:Lcom/discord/telecom/system/SystemTelecomModule;

    .line 301
    .line 302
    if-eqz v0, :cond_1e6

    .line 303
    .line 304
    invoke-virtual {v0, v5}, Lcom/discord/telecom/system/SystemTelecomModule;->onSystemEndCall(Ljava/lang/String;)V

    .line 305
    .line 306
    .line 307
    goto/16 :goto_1e6

    .line 308
    .line 309
    :catchall_134
    move-exception v0

    .line 310
    :goto_135
    move-object v14, v4

    .line 311
    move-object/from16 v4, v22

    .line 312
    .line 313
    goto/16 :goto_1f0

    .line 314
    .line 315
    :catch_13a
    move-exception v0

    .line 316
    :goto_13b
    move-object v14, v4

    .line 317
    move-object/from16 v4, v22

    .line 318
    .line 319
    goto :goto_179

    .line 320
    :catch_13f
    move-exception v0

    .line 321
    :goto_140
    move-object v14, v4

    .line 322
    move-object/from16 v4, v22

    .line 323
    .line 324
    goto/16 :goto_1ef

    .line 325
    .line 326
    :catchall_145
    move-exception v0

    .line 327
    move-object/from16 v22, v6

    .line 328
    .line 329
    goto :goto_135

    .line 330
    :catch_149
    move-exception v0

    .line 331
    move-object/from16 v22, v6

    .line 332
    .line 333
    goto :goto_13b

    .line 334
    :catch_14d
    move-exception v0

    .line 335
    move-object/from16 v22, v6

    .line 336
    .line 337
    goto :goto_140

    .line 338
    :catchall_151
    move-exception v0

    .line 339
    move-object/from16 v22, v6

    .line 340
    .line 341
    const/4 v13, 0x1

    .line 342
    goto :goto_135

    .line 343
    :catch_156
    move-exception v0

    .line 344
    move-object/from16 v22, v6

    .line 345
    .line 346
    const/4 v13, 0x1

    .line 347
    goto :goto_13b

    .line 348
    :catch_15b
    move-exception v0

    .line 349
    move-object/from16 v22, v6

    .line 350
    .line 351
    const/4 v13, 0x1

    .line 352
    goto :goto_140

    .line 353
    :catchall_160
    move-exception v0

    .line 354
    move-object/from16 v22, v6

    .line 355
    .line 356
    move v13, v14

    .line 357
    goto :goto_135

    .line 358
    :catch_165
    move-exception v0

    .line 359
    move-object/from16 v22, v6

    .line 360
    .line 361
    move v13, v14

    .line 362
    goto :goto_13b

    .line 363
    :catch_16a
    move-exception v0

    .line 364
    move-object/from16 v22, v6

    .line 365
    .line 366
    move v13, v14

    .line 367
    goto :goto_140

    .line 368
    :catchall_16f
    move-exception v0

    .line 369
    move-object/from16 v22, v6

    .line 370
    .line 371
    move v13, v12

    .line 372
    goto :goto_135

    .line 373
    :catch_174
    move-exception v0

    .line 374
    move-object/from16 v22, v6

    .line 375
    .line 376
    move v13, v12

    .line 377
    goto :goto_13b

    .line 378
    :goto_179
    :try_start_179
    sget-object v5, Lnf/a;->a:Lnf/a;

    .line 379
    .line 380
    iget-object v5, v14, Lik/a;->a:Ljava/lang/String;

    .line 381
    .line 382
    new-instance v6, Ljava/lang/StringBuilder;

    .line 383
    .line 384
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 385
    .line 386
    .line 387
    const-string v10, "Call failed: callId="

    .line 388
    .line 389
    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 390
    .line 391
    .line 392
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 393
    .line 394
    .line 395
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 396
    .line 397
    .line 398
    move-result-object v5

    .line 399
    invoke-static {v11, v5, v0}, Lnf/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 400
    .line 401
    .line 402
    iget-boolean v5, v14, Lik/a;->e:Z

    .line 403
    .line 404
    if-eqz v5, :cond_19b

    .line 405
    .line 406
    iget-object v0, v14, Lik/a;->a:Ljava/lang/String;

    .line 407
    .line 408
    invoke-interface {v3, v0, v14}, Ljava/util/Map;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 409
    .line 410
    .line 411
    goto :goto_1a5

    .line 412
    :cond_19b
    new-instance v5, Lik/f;

    .line 413
    .line 414
    const-string v6, "Failed to add outgoing call"

    .line 415
    .line 416
    invoke-direct {v5, v9, v6, v0}, Lik/f;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {v14, v5}, Lik/a;->a(Lik/f;)V
    :try_end_1a5
    .catchall {:try_start_179 .. :try_end_1a5} :catchall_ea

    .line 420
    .line 421
    .line 422
    :goto_1a5
    iget-object v0, v14, Lik/a;->c:Lb70/h;

    .line 423
    .line 424
    const/4 v6, 0x0

    .line 425
    invoke-virtual {v0, v6}, Lb70/h;->b(Ljava/lang/Throwable;)Z

    .line 426
    .line 427
    .line 428
    invoke-interface {v4}, Lq30/c;->getContext()Lq30/h;

    .line 429
    .line 430
    .line 431
    move-result-object v0

    .line 432
    invoke-interface {v0, v2}, Lq30/h;->Z(Lq30/g;)Lq30/f;

    .line 433
    .line 434
    .line 435
    move-result-object v0

    .line 436
    check-cast v0, Lz60/c1;

    .line 437
    .line 438
    if-eqz v0, :cond_1bc

    .line 439
    .line 440
    invoke-interface {v0}, Lz60/c1;->c()Z

    .line 441
    .line 442
    .line 443
    move-result v12

    .line 444
    goto :goto_1bd

    .line 445
    :cond_1bc
    move v12, v13

    .line 446
    :goto_1bd
    if-eqz v12, :cond_1c7

    .line 447
    .line 448
    new-instance v0, Lik/f;

    .line 449
    .line 450
    invoke-direct {v0, v9, v8}, Lik/f;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 451
    .line 452
    .line 453
    invoke-virtual {v14, v0}, Lik/a;->a(Lik/f;)V

    .line 454
    .line 455
    .line 456
    :cond_1c7
    iget-object v0, v14, Lik/a;->a:Ljava/lang/String;

    .line 457
    .line 458
    invoke-interface {v3, v0, v14}, Ljava/util/Map;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 459
    .line 460
    .line 461
    move-result v0

    .line 462
    if-eqz v0, :cond_1e6

    .line 463
    .line 464
    iget-boolean v0, v14, Lik/a;->e:Z

    .line 465
    .line 466
    if-eqz v0, :cond_1e6

    .line 467
    .line 468
    iget-object v0, v14, Lik/a;->a:Ljava/lang/String;

    .line 469
    .line 470
    invoke-virtual {v7, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    const/4 v6, 0x0

    .line 475
    invoke-static {v11, v0, v6}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 476
    .line 477
    .line 478
    iget-object v0, v1, Lik/o;->e:Lcom/discord/telecom/system/SystemTelecomModule;

    .line 479
    .line 480
    if-eqz v0, :cond_1e6

    .line 481
    .line 482
    iget-object v1, v14, Lik/a;->a:Ljava/lang/String;

    .line 483
    .line 484
    invoke-virtual {v0, v1}, Lcom/discord/telecom/system/SystemTelecomModule;->onSystemEndCall(Ljava/lang/String;)V

    .line 485
    .line 486
    .line 487
    :cond_1e6
    :goto_1e6
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 488
    .line 489
    return-object v0

    .line 490
    :catch_1e9
    move-exception v0

    .line 491
    move-object/from16 v22, v6

    .line 492
    .line 493
    move v13, v12

    .line 494
    goto/16 :goto_140

    .line 495
    .line 496
    :goto_1ef
    :try_start_1ef
    throw v0
    :try_end_1f0
    .catchall {:try_start_1ef .. :try_end_1f0} :catchall_ea

    .line 497
    :goto_1f0
    iget-object v5, v14, Lik/a;->c:Lb70/h;

    .line 498
    .line 499
    iget-object v6, v14, Lik/a;->a:Ljava/lang/String;

    .line 500
    .line 501
    const/4 v10, 0x0

    .line 502
    invoke-virtual {v5, v10}, Lb70/h;->b(Ljava/lang/Throwable;)Z

    .line 503
    .line 504
    .line 505
    invoke-interface {v4}, Lq30/c;->getContext()Lq30/h;

    .line 506
    .line 507
    .line 508
    move-result-object v4

    .line 509
    invoke-interface {v4, v2}, Lq30/h;->Z(Lq30/g;)Lq30/f;

    .line 510
    .line 511
    .line 512
    move-result-object v2

    .line 513
    check-cast v2, Lz60/c1;

    .line 514
    .line 515
    if-eqz v2, :cond_209

    .line 516
    .line 517
    invoke-interface {v2}, Lz60/c1;->c()Z

    .line 518
    .line 519
    .line 520
    move-result v12

    .line 521
    goto :goto_20a

    .line 522
    :cond_209
    move v12, v13

    .line 523
    :goto_20a
    if-eqz v12, :cond_214

    .line 524
    .line 525
    new-instance v2, Lik/f;

    .line 526
    .line 527
    invoke-direct {v2, v9, v8}, Lik/f;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    invoke-virtual {v14, v2}, Lik/a;->a(Lik/f;)V

    .line 531
    .line 532
    .line 533
    :cond_214
    invoke-interface {v3, v6, v14}, Ljava/util/Map;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 534
    .line 535
    .line 536
    move-result v2

    .line 537
    if-eqz v2, :cond_22f

    .line 538
    .line 539
    iget-boolean v2, v14, Lik/a;->e:Z

    .line 540
    .line 541
    if-eqz v2, :cond_22f

    .line 542
    .line 543
    sget-object v2, Lnf/a;->a:Lnf/a;

    .line 544
    .line 545
    invoke-virtual {v7, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 546
    .line 547
    .line 548
    move-result-object v2

    .line 549
    const/4 v10, 0x0

    .line 550
    invoke-static {v11, v2, v10}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 551
    .line 552
    .line 553
    iget-object v1, v1, Lik/o;->e:Lcom/discord/telecom/system/SystemTelecomModule;

    .line 554
    .line 555
    if-eqz v1, :cond_22f

    .line 556
    .line 557
    invoke-virtual {v1, v6}, Lcom/discord/telecom/system/SystemTelecomModule;->onSystemEndCall(Ljava/lang/String;)V

    .line 558
    .line 559
    .line 560
    :cond_22f
    throw v0
.end method

.method public static final b(Lik/o;Lr1/i;Lik/a;Ls30/c;)Ljava/lang/Object;
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    instance-of v4, v3, Lik/l;

    .line 13
    .line 14
    if-eqz v4, :cond_1e

    .line 15
    .line 16
    move-object v4, v3

    .line 17
    check-cast v4, Lik/l;

    .line 18
    .line 19
    iget v5, v4, Lik/l;->J:I

    .line 20
    .line 21
    const/high16 v6, -0x80000000

    .line 22
    .line 23
    and-int v7, v5, v6

    .line 24
    .line 25
    if-eqz v7, :cond_1e

    .line 26
    .line 27
    sub-int/2addr v5, v6

    .line 28
    iput v5, v4, Lik/l;->J:I

    .line 29
    .line 30
    goto :goto_23

    .line 31
    :cond_1e
    new-instance v4, Lik/l;

    .line 32
    .line 33
    invoke-direct {v4, v0, v3}, Lik/l;-><init>(Lik/o;Ls30/c;)V

    .line 34
    .line 35
    .line 36
    :goto_23
    iget-object v3, v4, Lik/l;->x:Ljava/lang/Object;

    .line 37
    .line 38
    sget-object v5, Lr30/a;->d:Lr30/a;

    .line 39
    .line 40
    iget v6, v4, Lik/l;->J:I

    .line 41
    .line 42
    const/4 v7, 0x3

    .line 43
    const/4 v8, 0x2

    .line 44
    sget-object v9, Ll30/a0;->a:Ll30/a0;

    .line 45
    .line 46
    const/4 v10, 0x1

    .line 47
    const/4 v15, 0x0

    .line 48
    packed-switch v6, :pswitch_data_1e4

    .line 49
    .line 50
    .line 51
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 52
    .line 53
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 54
    .line 55
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw v0

    .line 59
    :pswitch_3a
    iget-object v0, v4, Lik/l;->d:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v0, Ljava/lang/Throwable;

    .line 62
    .line 63
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    goto/16 :goto_1e2

    .line 67
    .line 68
    :pswitch_43
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    return-object v9

    .line 72
    :pswitch_47
    iget-object v0, v4, Lik/l;->d:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v0, Ll30/a0;

    .line 75
    .line 76
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    return-object v0

    .line 80
    :pswitch_4f
    iget-object v0, v4, Lik/l;->d:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, Ll30/a0;

    .line 83
    .line 84
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    return-object v0

    .line 88
    :pswitch_57
    iget-object v1, v4, Lik/l;->w:Lb70/c;

    .line 89
    .line 90
    iget-object v2, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 91
    .line 92
    iget-object v6, v4, Lik/l;->i:Lz60/c1;

    .line 93
    .line 94
    iget-object v11, v4, Lik/l;->e:Lik/a;

    .line 95
    .line 96
    iget-object v12, v4, Lik/l;->d:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v12, Lr1/i;

    .line 99
    .line 100
    :try_start_63
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V
    :try_end_66
    .catchall {:try_start_63 .. :try_end_66} :catchall_6b

    .line 101
    .line 102
    .line 103
    :goto_66
    move-object v3, v12

    .line 104
    move-object v12, v1

    .line 105
    move-object v1, v3

    .line 106
    move-object v3, v2

    .line 107
    goto :goto_c0

    .line 108
    :catchall_6b
    move-exception v0

    .line 109
    :goto_6c
    move-object v14, v11

    .line 110
    goto/16 :goto_1bc

    .line 111
    .line 112
    :pswitch_6f
    iget-object v1, v4, Lik/l;->w:Lb70/c;

    .line 113
    .line 114
    iget-object v2, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 115
    .line 116
    iget-object v6, v4, Lik/l;->i:Lz60/c1;

    .line 117
    .line 118
    iget-object v11, v4, Lik/l;->e:Lik/a;

    .line 119
    .line 120
    iget-object v12, v4, Lik/l;->d:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v12, Lr1/i;

    .line 123
    .line 124
    :try_start_7b
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V
    :try_end_7e
    .catchall {:try_start_7b .. :try_end_7e} :catchall_6b

    .line 125
    .line 126
    .line 127
    :goto_7e
    move-object v14, v11

    .line 128
    goto :goto_db

    .line 129
    :pswitch_80
    iget-object v1, v4, Lik/l;->e:Lik/a;

    .line 130
    .line 131
    iget-object v2, v4, Lik/l;->d:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v2, Lr1/i;

    .line 134
    .line 135
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    move-object/from16 v17, v2

    .line 139
    .line 140
    move-object v2, v1

    .line 141
    move-object/from16 v1, v17

    .line 142
    .line 143
    goto :goto_a7

    .line 144
    :pswitch_8f
    invoke-static {v3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v2, v15}, Lik/a;->a(Lik/f;)V

    .line 148
    .line 149
    .line 150
    iget-boolean v3, v2, Lik/a;->f:Z

    .line 151
    .line 152
    if-eqz v3, :cond_a7

    .line 153
    .line 154
    iput-object v1, v4, Lik/l;->d:Ljava/lang/Object;

    .line 155
    .line 156
    iput-object v2, v4, Lik/l;->e:Lik/a;

    .line 157
    .line 158
    iput v10, v4, Lik/l;->J:I

    .line 159
    .line 160
    invoke-virtual {v0, v1, v2, v4}, Lik/o;->c(Lr1/i;Lik/a;Ls30/c;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v3

    .line 164
    if-ne v3, v5, :cond_a7

    .line 165
    .line 166
    goto/16 :goto_1e1

    .line 167
    .line 168
    :cond_a7
    :goto_a7
    new-instance v3, Lik/k;

    .line 169
    .line 170
    invoke-direct {v3, v1, v0, v2, v15}, Lik/k;-><init>(Lr1/i;Lik/o;Lik/a;Lq30/c;)V

    .line 171
    .line 172
    .line 173
    invoke-static {v1, v15, v3, v7}, Lz60/z;->v(Lz60/x;Lq30/h;Lkotlin/jvm/functions/Function2;I)Lz60/r1;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    new-instance v3, Ljava/lang/Integer;

    .line 178
    .line 179
    invoke-direct {v3, v8}, Ljava/lang/Integer;-><init>(I)V

    .line 180
    .line 181
    .line 182
    :try_start_b5
    iget-object v11, v2, Lik/a;->c:Lb70/h;

    .line 183
    .line 184
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 185
    .line 186
    .line 187
    new-instance v12, Lb70/c;

    .line 188
    .line 189
    invoke-direct {v12, v11}, Lb70/c;-><init>(Lb70/h;)V
    :try_end_bf
    .catchall {:try_start_b5 .. :try_end_bf} :catchall_1ba

    .line 190
    .line 191
    .line 192
    move-object v11, v2

    .line 193
    :goto_c0
    :try_start_c0
    iput-object v1, v4, Lik/l;->d:Ljava/lang/Object;

    .line 194
    .line 195
    iput-object v11, v4, Lik/l;->e:Lik/a;

    .line 196
    .line 197
    iput-object v6, v4, Lik/l;->i:Lz60/c1;

    .line 198
    .line 199
    iput-object v3, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 200
    .line 201
    iput-object v12, v4, Lik/l;->w:Lb70/c;

    .line 202
    .line 203
    iput v8, v4, Lik/l;->J:I

    .line 204
    .line 205
    invoke-virtual {v12, v4}, Lb70/c;->b(Ls30/c;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v2
    :try_end_d0
    .catchall {:try_start_c0 .. :try_end_d0} :catchall_1b1

    .line 209
    if-ne v2, v5, :cond_d4

    .line 210
    .line 211
    goto/16 :goto_1e1

    .line 212
    .line 213
    :cond_d4
    move-object v14, v12

    .line 214
    move-object v12, v1

    .line 215
    move-object v1, v14

    .line 216
    move-object v14, v3

    .line 217
    move-object v3, v2

    .line 218
    move-object v2, v14

    .line 219
    goto :goto_7e

    .line 220
    :goto_db
    :try_start_db
    check-cast v3, Ljava/lang/Boolean;

    .line 221
    .line 222
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 223
    .line 224
    .line 225
    move-result v3

    .line 226
    if-eqz v3, :cond_18a

    .line 227
    .line 228
    invoke-virtual {v1}, Lb70/c;->c()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v3

    .line 232
    check-cast v3, Lik/e;

    .line 233
    .line 234
    sget-object v11, Lik/c;->a:Lik/c;

    .line 235
    .line 236
    invoke-static {v3, v11}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 237
    .line 238
    .line 239
    move-result v11

    .line 240
    if-eqz v11, :cond_10d

    .line 241
    .line 242
    iput-boolean v10, v14, Lik/a;->f:Z

    .line 243
    .line 244
    iput-object v12, v4, Lik/l;->d:Ljava/lang/Object;

    .line 245
    .line 246
    iput-object v14, v4, Lik/l;->e:Lik/a;

    .line 247
    .line 248
    iput-object v6, v4, Lik/l;->i:Lz60/c1;

    .line 249
    .line 250
    iput-object v2, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 251
    .line 252
    iput-object v1, v4, Lik/l;->w:Lb70/c;

    .line 253
    .line 254
    iput v7, v4, Lik/l;->J:I

    .line 255
    .line 256
    invoke-virtual {v0, v12, v14, v4}, Lik/o;->c(Lr1/i;Lik/a;Ls30/c;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object v3

    .line 260
    if-ne v3, v5, :cond_107

    .line 261
    .line 262
    goto/16 :goto_1e1

    .line 263
    .line 264
    :cond_107
    move-object v11, v14

    .line 265
    goto/16 :goto_66

    .line 266
    .line 267
    :catchall_10a
    move-exception v0

    .line 268
    goto/16 :goto_1bc

    .line 269
    .line 270
    :cond_10d
    instance-of v0, v3, Lik/b;

    .line 271
    .line 272
    if-eqz v0, :cond_13f

    .line 273
    .line 274
    check-cast v3, Lik/b;

    .line 275
    .line 276
    iget v0, v3, Lik/b;->a:I

    .line 277
    .line 278
    new-instance v1, Ljava/lang/Integer;

    .line 279
    .line 280
    invoke-direct {v1, v0}, Ljava/lang/Integer;-><init>(I)V
    :try_end_11a
    .catchall {:try_start_db .. :try_end_11a} :catchall_10a

    .line 281
    .line 282
    .line 283
    invoke-interface {v6, v15}, Lz60/c1;->d(Ljava/util/concurrent/CancellationException;)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 287
    .line 288
    .line 289
    move-result v13

    .line 290
    sget-object v0, Lz60/n1;->e:Lz60/n1;

    .line 291
    .line 292
    new-instance v11, Lcom/margelo/nitro/rive/c;

    .line 293
    .line 294
    const/16 v16, 0x1

    .line 295
    .line 296
    invoke-direct/range {v11 .. v16}, Lcom/margelo/nitro/rive/c;-><init>(Ljava/lang/Object;ILjava/lang/Object;Lq30/c;I)V

    .line 297
    .line 298
    .line 299
    iput-object v9, v4, Lik/l;->d:Ljava/lang/Object;

    .line 300
    .line 301
    iput-object v15, v4, Lik/l;->e:Lik/a;

    .line 302
    .line 303
    iput-object v15, v4, Lik/l;->i:Lz60/c1;

    .line 304
    .line 305
    iput-object v15, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 306
    .line 307
    iput-object v15, v4, Lik/l;->w:Lb70/c;

    .line 308
    .line 309
    const/4 v1, 0x4

    .line 310
    iput v1, v4, Lik/l;->J:I

    .line 311
    .line 312
    invoke-static {v0, v11, v4}, Lz60/z;->G(Lq30/h;Lkotlin/jvm/functions/Function2;Lq30/c;)Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    if-ne v0, v5, :cond_1b0

    .line 317
    .line 318
    goto/16 :goto_1e1

    .line 319
    .line 320
    :cond_13f
    :try_start_13f
    instance-of v0, v3, Lik/d;

    .line 321
    .line 322
    const/4 v1, 0x0

    .line 323
    if-eqz v0, :cond_184

    .line 324
    .line 325
    sget-object v0, Lnf/a;->a:Lnf/a;

    .line 326
    .line 327
    const-string v0, "SystemTelecom"

    .line 328
    .line 329
    iget-object v7, v14, Lik/a;->a:Ljava/lang/String;

    .line 330
    .line 331
    move-object v8, v3

    .line 332
    check-cast v8, Lik/d;

    .line 333
    .line 334
    iget-object v8, v8, Lik/d;->a:Landroid/telecom/DisconnectCause;

    .line 335
    .line 336
    new-instance v11, Ljava/lang/StringBuilder;

    .line 337
    .line 338
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 339
    .line 340
    .line 341
    const-string v13, "Telecom disconnected call: callId="

    .line 342
    .line 343
    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    const-string v7, ", cause="

    .line 350
    .line 351
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 352
    .line 353
    .line 354
    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 355
    .line 356
    .line 357
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 358
    .line 359
    .line 360
    move-result-object v7

    .line 361
    invoke-static {v0, v7, v15}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_16b
    .catchall {:try_start_13f .. :try_end_16b} :catchall_10a

    .line 362
    .line 363
    .line 364
    :try_start_16b
    iget-boolean v0, v14, Lik/a;->f:Z

    .line 365
    .line 366
    if-nez v0, :cond_17d

    .line 367
    .line 368
    check-cast v3, Lik/d;

    .line 369
    .line 370
    iget-object v0, v3, Lik/d;->a:Landroid/telecom/DisconnectCause;

    .line 371
    .line 372
    invoke-virtual {v0}, Landroid/telecom/DisconnectCause;->getCode()I

    .line 373
    .line 374
    .line 375
    move-result v0

    .line 376
    if-ne v0, v10, :cond_17d

    .line 377
    .line 378
    goto :goto_17e

    .line 379
    :catchall_17a
    move-exception v0

    .line 380
    move-object v2, v15

    .line 381
    goto :goto_1bc

    .line 382
    :cond_17d
    move v10, v1

    .line 383
    :goto_17e
    iput-boolean v10, v14, Lik/a;->g:Z
    :try_end_180
    .catchall {:try_start_16b .. :try_end_180} :catchall_17a

    .line 384
    .line 385
    invoke-interface {v6, v15}, Lz60/c1;->d(Ljava/util/concurrent/CancellationException;)V

    .line 386
    .line 387
    .line 388
    return-object v9

    .line 389
    :cond_184
    :try_start_184
    new-instance v0, Lan/g;

    .line 390
    .line 391
    invoke-direct {v0, v1}, Lan/g;-><init>(Z)V

    .line 392
    .line 393
    .line 394
    throw v0
    :try_end_18a
    .catchall {:try_start_184 .. :try_end_18a} :catchall_10a

    .line 395
    :cond_18a
    invoke-interface {v6, v15}, Lz60/c1;->d(Ljava/util/concurrent/CancellationException;)V

    .line 396
    .line 397
    .line 398
    if-eqz v2, :cond_1b0

    .line 399
    .line 400
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 401
    .line 402
    .line 403
    move-result v13

    .line 404
    sget-object v0, Lz60/n1;->e:Lz60/n1;

    .line 405
    .line 406
    new-instance v11, Lcom/margelo/nitro/rive/c;

    .line 407
    .line 408
    const/16 v16, 0x1

    .line 409
    .line 410
    invoke-direct/range {v11 .. v16}, Lcom/margelo/nitro/rive/c;-><init>(Ljava/lang/Object;ILjava/lang/Object;Lq30/c;I)V

    .line 411
    .line 412
    .line 413
    iput-object v15, v4, Lik/l;->d:Ljava/lang/Object;

    .line 414
    .line 415
    iput-object v15, v4, Lik/l;->e:Lik/a;

    .line 416
    .line 417
    iput-object v15, v4, Lik/l;->i:Lz60/c1;

    .line 418
    .line 419
    iput-object v15, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 420
    .line 421
    iput-object v15, v4, Lik/l;->w:Lb70/c;

    .line 422
    .line 423
    const/4 v1, 0x6

    .line 424
    iput v1, v4, Lik/l;->J:I

    .line 425
    .line 426
    invoke-static {v0, v11, v4}, Lz60/z;->G(Lq30/h;Lkotlin/jvm/functions/Function2;Lq30/c;)Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    move-result-object v0

    .line 430
    if-ne v0, v5, :cond_1b0

    .line 431
    .line 432
    goto :goto_1e1

    .line 433
    :cond_1b0
    return-object v9

    .line 434
    :catchall_1b1
    move-exception v0

    .line 435
    move-object v12, v1

    .line 436
    move-object v2, v3

    .line 437
    goto/16 :goto_6c

    .line 438
    .line 439
    :goto_1b6
    move-object v12, v1

    .line 440
    move-object v14, v2

    .line 441
    move-object v2, v3

    .line 442
    goto :goto_1bc

    .line 443
    :catchall_1ba
    move-exception v0

    .line 444
    goto :goto_1b6

    .line 445
    :goto_1bc
    invoke-interface {v6, v15}, Lz60/c1;->d(Ljava/util/concurrent/CancellationException;)V

    .line 446
    .line 447
    .line 448
    if-eqz v2, :cond_1e2

    .line 449
    .line 450
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 451
    .line 452
    .line 453
    move-result v13

    .line 454
    sget-object v1, Lz60/n1;->e:Lz60/n1;

    .line 455
    .line 456
    new-instance v11, Lcom/margelo/nitro/rive/c;

    .line 457
    .line 458
    const/16 v16, 0x1

    .line 459
    .line 460
    invoke-direct/range {v11 .. v16}, Lcom/margelo/nitro/rive/c;-><init>(Ljava/lang/Object;ILjava/lang/Object;Lq30/c;I)V

    .line 461
    .line 462
    .line 463
    iput-object v0, v4, Lik/l;->d:Ljava/lang/Object;

    .line 464
    .line 465
    iput-object v15, v4, Lik/l;->e:Lik/a;

    .line 466
    .line 467
    iput-object v15, v4, Lik/l;->i:Lz60/c1;

    .line 468
    .line 469
    iput-object v15, v4, Lik/l;->v:Ljava/lang/Integer;

    .line 470
    .line 471
    iput-object v15, v4, Lik/l;->w:Lb70/c;

    .line 472
    .line 473
    const/4 v2, 0x7

    .line 474
    iput v2, v4, Lik/l;->J:I

    .line 475
    .line 476
    invoke-static {v1, v11, v4}, Lz60/z;->G(Lq30/h;Lkotlin/jvm/functions/Function2;Lq30/c;)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v1

    .line 480
    if-ne v1, v5, :cond_1e2

    .line 481
    .line 482
    :goto_1e1
    return-object v5

    .line 483
    :cond_1e2
    :goto_1e2
    throw v0

    .line 484
    nop

    .line 485
    :pswitch_data_1e4
    .packed-switch 0x0
        :pswitch_8f
        :pswitch_80
        :pswitch_6f
        :pswitch_57
        :pswitch_4f
        :pswitch_47
        :pswitch_43
        :pswitch_3a
    .end packed-switch
.end method


# virtual methods
.method public final c(Lr1/i;Lik/a;Ls30/c;)Ljava/lang/Object;
    .registers 8

    .line 1
    instance-of v0, p3, Lik/g;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lik/g;

    .line 7
    .line 8
    iget v1, v0, Lik/g;->v:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_13

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lik/g;->v:I

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Lik/g;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lik/g;-><init>(Lik/o;Ls30/c;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iget-object p3, v0, Lik/g;->e:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, Lr30/a;->d:Lr30/a;

    .line 28
    .line 29
    iget v2, v0, Lik/g;->v:I

    .line 30
    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_31

    .line 33
    .line 34
    if-ne v2, v3, :cond_29

    .line 35
    .line 36
    iget-object p2, v0, Lik/g;->d:Lik/a;

    .line 37
    .line 38
    invoke-static {p3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_53

    .line 42
    :cond_29
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 43
    .line 44
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    throw p1

    .line 50
    :cond_31
    invoke-static {p3}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iput-object p2, v0, Lik/g;->d:Lik/a;

    .line 54
    .line 55
    iput v3, v0, Lik/g;->v:I

    .line 56
    .line 57
    iget p3, p1, Lr1/i;->d:I

    .line 58
    .line 59
    packed-switch p3, :pswitch_data_7c

    .line 60
    .line 61
    .line 62
    iget-object p1, p1, Lr1/i;->w:Ljava/lang/AutoCloseable;

    .line 63
    .line 64
    check-cast p1, Lr1/v;

    .line 65
    .line 66
    invoke-virtual {p1}, Lr1/v;->x()Lq1/d;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    :goto_45
    move-object p3, p1

    .line 71
    goto :goto_50

    .line 72
    :pswitch_47
    iget-object p1, p1, Lr1/i;->w:Ljava/lang/AutoCloseable;

    .line 73
    .line 74
    check-cast p1, Lr1/s;

    .line 75
    .line 76
    invoke-virtual {p1, v0}, Lr1/s;->u(Ls30/c;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    goto :goto_45

    .line 81
    :goto_50
    if-ne p3, v1, :cond_53

    .line 82
    .line 83
    return-object v1

    .line 84
    :cond_53
    :goto_53
    check-cast p3, Lq1/d;

    .line 85
    .line 86
    instance-of p1, p3, Lq1/c;

    .line 87
    .line 88
    if-nez p1, :cond_79

    .line 89
    .line 90
    sget-object p1, Lnf/a;->a:Lnf/a;

    .line 91
    .line 92
    iget-object p1, p2, Lik/a;->a:Ljava/lang/String;

    .line 93
    .line 94
    new-instance p2, Ljava/lang/StringBuilder;

    .line 95
    .line 96
    const-string v0, "Failed to set call active: callId="

    .line 97
    .line 98
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    const-string p1, ", result="

    .line 105
    .line 106
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    const-string p2, "SystemTelecom"

    .line 117
    .line 118
    const/4 p3, 0x0

    .line 119
    invoke-static {p2, p1, p3}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 120
    .line 121
    .line 122
    :cond_79
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 123
    .line 124
    return-object p1

    .line 125
    :pswitch_data_7c
    .packed-switch 0x0
        :pswitch_47
    .end packed-switch
.end method

.method public final d(Lik/a;Ls30/c;)Ljava/lang/Object;
    .registers 9

    .line 1
    instance-of v0, p2, Lik/n;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lik/n;

    .line 7
    .line 8
    iget v1, v0, Lik/n;->w:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_13

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lik/n;->w:I

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Lik/n;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lik/n;-><init>(Lik/o;Ls30/c;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iget-object p2, v0, Lik/n;->i:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, Lr30/a;->d:Lr30/a;

    .line 28
    .line 29
    iget v2, v0, Lik/n;->w:I

    .line 30
    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_33

    .line 33
    .line 34
    if-ne v2, v3, :cond_2b

    .line 35
    .line 36
    iget-object p1, v0, Lik/n;->e:Lb70/c;

    .line 37
    .line 38
    iget-object v2, v0, Lik/n;->d:Lik/a;

    .line 39
    .line 40
    invoke-static {p2}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_62

    .line 44
    :cond_2b
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 45
    .line 46
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 47
    .line 48
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p1

    .line 52
    :cond_33
    invoke-static {p2}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    sget-object p2, Lnf/a;->a:Lnf/a;

    .line 56
    .line 57
    iget-object p2, p1, Lik/a;->a:Ljava/lang/String;

    .line 58
    .line 59
    const-string v2, "Waiting for someone to join before re-adding call: callId="

    .line 60
    .line 61
    invoke-virtual {v2, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p2

    .line 65
    const-string v2, "SystemTelecom"

    .line 66
    .line 67
    const/4 v4, 0x0

    .line 68
    invoke-static {v2, p2, v4}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 69
    .line 70
    .line 71
    iget-object p2, p1, Lik/a;->c:Lb70/h;

    .line 72
    .line 73
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    new-instance v2, Lb70/c;

    .line 77
    .line 78
    invoke-direct {v2, p2}, Lb70/c;-><init>(Lb70/h;)V

    .line 79
    .line 80
    .line 81
    move-object p2, p1

    .line 82
    move-object p1, v2

    .line 83
    :goto_52
    iput-object p2, v0, Lik/n;->d:Lik/a;

    .line 84
    .line 85
    iput-object p1, v0, Lik/n;->e:Lb70/c;

    .line 86
    .line 87
    iput v3, v0, Lik/n;->w:I

    .line 88
    .line 89
    invoke-virtual {p1, v0}, Lb70/c;->b(Ls30/c;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    if-ne v2, v1, :cond_5f

    .line 94
    .line 95
    return-object v1

    .line 96
    :cond_5f
    move-object v5, v2

    .line 97
    move-object v2, p2

    .line 98
    move-object p2, v5

    .line 99
    :goto_62
    check-cast p2, Ljava/lang/Boolean;

    .line 100
    .line 101
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 102
    .line 103
    .line 104
    move-result p2

    .line 105
    if-eqz p2, :cond_91

    .line 106
    .line 107
    invoke-virtual {p1}, Lb70/c;->c()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object p2

    .line 111
    check-cast p2, Lik/e;

    .line 112
    .line 113
    sget-object v4, Lik/c;->a:Lik/c;

    .line 114
    .line 115
    invoke-static {p2, v4}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v4

    .line 119
    if-eqz v4, :cond_7d

    .line 120
    .line 121
    iput-boolean v3, v2, Lik/a;->f:Z

    .line 122
    .line 123
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 124
    .line 125
    return-object p1

    .line 126
    :cond_7d
    instance-of v4, p2, Lik/b;

    .line 127
    .line 128
    if-eqz v4, :cond_84

    .line 129
    .line 130
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 131
    .line 132
    return-object p1

    .line 133
    :cond_84
    instance-of p2, p2, Lik/d;

    .line 134
    .line 135
    if-eqz p2, :cond_8a

    .line 136
    .line 137
    move-object p2, v2

    .line 138
    goto :goto_52

    .line 139
    :cond_8a
    new-instance p1, Lan/g;

    .line 140
    .line 141
    const/4 p2, 0x0

    .line 142
    invoke-direct {p1, p2}, Lan/g;-><init>(Z)V

    .line 143
    .line 144
    .line 145
    throw p1

    .line 146
    :cond_91
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 147
    .line 148
    return-object p1
.end method
