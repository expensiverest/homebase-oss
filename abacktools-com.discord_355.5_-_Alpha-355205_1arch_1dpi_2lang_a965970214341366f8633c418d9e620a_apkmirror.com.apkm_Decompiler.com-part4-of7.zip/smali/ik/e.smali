###### Class ik.e (ik.e)
.class public interface abstract Lik/e;
.super Ljava/lang/Object;
.source "SourceFile"
