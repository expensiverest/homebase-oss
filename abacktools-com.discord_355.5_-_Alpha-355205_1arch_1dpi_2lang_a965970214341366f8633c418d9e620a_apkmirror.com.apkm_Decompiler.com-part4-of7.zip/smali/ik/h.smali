###### Class ik.h (ik.h)
.class public final Lik/h;
.super Ls30/i;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lik/o;

.field public final synthetic i:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lik/o;Ljava/lang/String;Lq30/c;I)V
    .registers 5

    .line 1
    iput p4, p0, Lik/h;->d:I

    iput-object p1, p0, Lik/h;->e:Lik/o;

    iput-object p2, p0, Lik/h;->i:Ljava/lang/String;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Ls30/i;-><init>(ILq30/c;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lq30/c;)Lq30/c;
    .registers 6

    .line 1
    iget p1, p0, Lik/h;->d:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_1c

    .line 4
    .line 5
    .line 6
    new-instance p1, Lik/h;

    .line 7
    .line 8
    iget-object v0, p0, Lik/h;->i:Ljava/lang/String;

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    iget-object v2, p0, Lik/h;->e:Lik/o;

    .line 12
    .line 13
    invoke-direct {p1, v2, v0, p2, v1}, Lik/h;-><init>(Lik/o;Ljava/lang/String;Lq30/c;I)V

    .line 14
    .line 15
    .line 16
    return-object p1

    .line 17
    :pswitch_10
    new-instance p1, Lik/h;

    .line 18
    .line 19
    iget-object v0, p0, Lik/h;->i:Ljava/lang/String;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    iget-object v2, p0, Lik/h;->e:Lik/o;

    .line 23
    .line 24
    invoke-direct {p1, v2, v0, p2, v1}, Lik/h;-><init>(Lik/o;Ljava/lang/String;Lq30/c;I)V

    .line 25
    .line 26
    .line 27
    return-object p1

    .line 28
    nop

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_10
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lik/h;->d:I

    .line 2
    .line 3
    check-cast p1, Lz60/x;

    .line 4
    .line 5
    check-cast p2, Lq30/c;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_22

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lik/h;->create(Ljava/lang/Object;Lq30/c;)Lq30/c;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lik/h;

    .line 15
    .line 16
    sget-object p2, Ll30/a0;->a:Ll30/a0;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Lik/h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object p2

    .line 22
    :pswitch_15
    invoke-virtual {p0, p1, p2}, Lik/h;->create(Ljava/lang/Object;Lq30/c;)Lq30/c;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    check-cast p1, Lik/h;

    .line 27
    .line 28
    sget-object p2, Ll30/a0;->a:Ll30/a0;

    .line 29
    .line 30
    invoke-virtual {p1, p2}, Lik/h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    return-object p2

    .line 34
    nop

    .line 35
    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_15
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lik/h;->d:I

    .line 2
    .line 3
    sget-object v1, Ll30/a0;->a:Ll30/a0;

    .line 4
    .line 5
    iget-object v2, p0, Lik/h;->i:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v3, p0, Lik/h;->e:Lik/o;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_42

    .line 10
    .line 11
    .line 12
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 13
    .line 14
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iget-object p1, v3, Lik/o;->d:Ljava/util/LinkedHashMap;

    .line 18
    .line 19
    invoke-virtual {p1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lik/a;

    .line 24
    .line 25
    if-eqz p1, :cond_23

    .line 26
    .line 27
    iget-object p1, p1, Lik/a;->c:Lb70/h;

    .line 28
    .line 29
    if-eqz p1, :cond_23

    .line 30
    .line 31
    sget-object v0, Lik/c;->a:Lik/c;

    .line 32
    .line 33
    invoke-interface {p1, v0}, Lb70/z;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    :cond_23
    return-object v1

    .line 37
    :pswitch_24
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 38
    .line 39
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iget-object p1, v3, Lik/o;->d:Ljava/util/LinkedHashMap;

    .line 43
    .line 44
    invoke-interface {p1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Lik/a;

    .line 49
    .line 50
    if-eqz p1, :cond_40

    .line 51
    .line 52
    iget-object p1, p1, Lik/a;->c:Lb70/h;

    .line 53
    .line 54
    if-eqz p1, :cond_40

    .line 55
    .line 56
    new-instance v0, Lik/b;

    .line 57
    .line 58
    const/4 v2, 0x3

    .line 59
    invoke-direct {v0, v2}, Lik/b;-><init>(I)V

    .line 60
    .line 61
    .line 62
    invoke-interface {p1, v0}, Lb70/z;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    :cond_40
    return-object v1

    .line 66
    nop

    .line 67
    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_24
    .end packed-switch
.end method
