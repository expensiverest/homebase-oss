###### Class ik.k (ik.k)
.class public final Lik/k;
.super Ls30/i;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic d:I

.field public e:I

.field public final synthetic i:Lr1/i;

.field public final synthetic v:Lik/o;

.field public final synthetic w:Lik/a;


# direct methods
.method public constructor <init>(Lik/o;Lr1/i;Lik/a;Lq30/c;)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Lik/k;->d:I

    .line 1
    iput-object p1, p0, Lik/k;->v:Lik/o;

    iput-object p2, p0, Lik/k;->i:Lr1/i;

    iput-object p3, p0, Lik/k;->w:Lik/a;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Ls30/i;-><init>(ILq30/c;)V

    return-void
.end method

.method public constructor <init>(Lr1/i;Lik/o;Lik/a;Lq30/c;)V
    .registers 6

    const/4 v0, 0x1

    iput v0, p0, Lik/k;->d:I

    .line 2
    iput-object p1, p0, Lik/k;->i:Lr1/i;

    iput-object p2, p0, Lik/k;->v:Lik/o;

    iput-object p3, p0, Lik/k;->w:Lik/a;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Ls30/i;-><init>(ILq30/c;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lq30/c;)Lq30/c;
    .registers 6

    .line 1
    iget p1, p0, Lik/k;->d:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_1e

    .line 4
    .line 5
    .line 6
    new-instance p1, Lik/k;

    .line 7
    .line 8
    iget-object v0, p0, Lik/k;->v:Lik/o;

    .line 9
    .line 10
    iget-object v1, p0, Lik/k;->w:Lik/a;

    .line 11
    .line 12
    iget-object v2, p0, Lik/k;->i:Lr1/i;

    .line 13
    .line 14
    invoke-direct {p1, v2, v0, v1, p2}, Lik/k;-><init>(Lr1/i;Lik/o;Lik/a;Lq30/c;)V

    .line 15
    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_11
    new-instance p1, Lik/k;

    .line 19
    .line 20
    iget-object v0, p0, Lik/k;->i:Lr1/i;

    .line 21
    .line 22
    iget-object v1, p0, Lik/k;->w:Lik/a;

    .line 23
    .line 24
    iget-object v2, p0, Lik/k;->v:Lik/o;

    .line 25
    .line 26
    invoke-direct {p1, v2, v0, v1, p2}, Lik/k;-><init>(Lik/o;Lr1/i;Lik/a;Lq30/c;)V

    .line 27
    .line 28
    .line 29
    return-object p1

    .line 30
    nop

    .line 31
    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lik/k;->d:I

    .line 2
    .line 3
    check-cast p1, Lz60/x;

    .line 4
    .line 5
    check-cast p2, Lq30/c;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_24

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lik/k;->create(Ljava/lang/Object;Lq30/c;)Lq30/c;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lik/k;

    .line 15
    .line 16
    sget-object p2, Ll30/a0;->a:Ll30/a0;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Lik/k;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1

    .line 23
    :pswitch_16
    invoke-virtual {p0, p1, p2}, Lik/k;->create(Ljava/lang/Object;Lq30/c;)Lq30/c;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lik/k;

    .line 28
    .line 29
    sget-object p2, Ll30/a0;->a:Ll30/a0;

    .line 30
    .line 31
    invoke-virtual {p1, p2}, Lik/k;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    return-object p1

    .line 36
    nop

    .line 37
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_16
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget v0, p0, Lik/k;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_72

    .line 4
    .line 5
    .line 6
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 7
    .line 8
    iget v1, p0, Lik/k;->e:I

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    if-eqz v1, :cond_1a

    .line 12
    .line 13
    if-ne v1, v2, :cond_12

    .line 14
    .line 15
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    goto :goto_44

    .line 19
    :cond_12
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 22
    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1a
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object p1, p0, Lik/k;->i:Lr1/i;

    .line 31
    .line 32
    iget v1, p1, Lr1/i;->d:I

    .line 33
    .line 34
    packed-switch v1, :pswitch_data_78

    .line 35
    .line 36
    .line 37
    iget-object p1, p1, Lr1/i;->v:Lc70/d;

    .line 38
    .line 39
    goto :goto_29

    .line 40
    :pswitch_27
    iget-object p1, p1, Lr1/i;->v:Lc70/d;

    .line 41
    .line 42
    :goto_29
    invoke-static {p1}, Lc70/j0;->h(Lc70/h;)Lc70/h;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-static {p1, v2}, Lc70/j0;->i(Lc70/h;I)Lc70/p;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    new-instance v1, Lbk/f;

    .line 51
    .line 52
    iget-object v3, p0, Lik/k;->w:Lik/a;

    .line 53
    .line 54
    const/4 v4, 0x7

    .line 55
    iget-object v5, p0, Lik/k;->v:Lik/o;

    .line 56
    .line 57
    invoke-direct {v1, v4, v5, v3}, Lbk/f;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iput v2, p0, Lik/k;->e:I

    .line 61
    .line 62
    invoke-virtual {p1, v1, p0}, Lc70/p;->collect(Lc70/i;Lq30/c;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    if-ne p1, v0, :cond_44

    .line 67
    .line 68
    goto :goto_46

    .line 69
    :cond_44
    :goto_44
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 70
    .line 71
    :goto_46
    return-object v0

    .line 72
    :pswitch_47
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 73
    .line 74
    iget v1, p0, Lik/k;->e:I

    .line 75
    .line 76
    const/4 v2, 0x1

    .line 77
    if-eqz v1, :cond_5c

    .line 78
    .line 79
    if-ne v1, v2, :cond_54

    .line 80
    .line 81
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    goto :goto_6e

    .line 85
    :cond_54
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 88
    .line 89
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    throw p1

    .line 93
    :cond_5c
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    iput v2, p0, Lik/k;->e:I

    .line 97
    .line 98
    iget-object p1, p0, Lik/k;->v:Lik/o;

    .line 99
    .line 100
    iget-object v1, p0, Lik/k;->i:Lr1/i;

    .line 101
    .line 102
    iget-object v2, p0, Lik/k;->w:Lik/a;

    .line 103
    .line 104
    invoke-static {p1, v1, v2, p0}, Lik/o;->b(Lik/o;Lr1/i;Lik/a;Ls30/c;)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    if-ne p1, v0, :cond_6e

    .line 109
    .line 110
    goto :goto_70

    .line 111
    :cond_6e
    :goto_6e
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 112
    .line 113
    :goto_70
    return-object v0

    .line 114
    nop

    .line 115
    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_47
    .end packed-switch

    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    :pswitch_data_78
    .packed-switch 0x0
        :pswitch_27
    .end packed-switch
.end method
