###### Class ik.j (ik.j)
.class public final Lik/j;
.super Ls30/i;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(ILq30/c;I)V
    .registers 4

    .line 1
    iput p3, p0, Lik/j;->d:I

    invoke-direct {p0, p1, p2}, Ls30/i;-><init>(ILq30/c;)V

    return-void
.end method


# virtual methods
.method public final create(Lq30/c;)Lq30/c;
    .registers 5

    .line 1
    iget v0, p0, Lik/j;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    new-instance v0, Lik/j;

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    const/4 v2, 0x1

    .line 10
    invoke-direct {v0, v1, p1, v2}, Lik/j;-><init>(ILq30/c;I)V

    .line 11
    .line 12
    .line 13
    return-object v0

    .line 14
    :pswitch_d
    new-instance v0, Lik/j;

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-direct {v0, v1, p1, v2}, Lik/j;-><init>(ILq30/c;I)V

    .line 19
    .line 20
    .line 21
    return-object v0

    .line 22
    nop

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lik/j;->d:I

    .line 2
    .line 3
    check-cast p1, Lq30/c;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_20

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, p1}, Lik/j;->create(Lq30/c;)Lq30/c;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Lik/j;

    .line 13
    .line 14
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 15
    .line 16
    invoke-virtual {p1, v0}, Lik/j;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    :pswitch_13
    invoke-virtual {p0, p1}, Lik/j;->create(Lq30/c;)Lq30/c;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    check-cast p1, Lik/j;

    .line 25
    .line 26
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 27
    .line 28
    invoke-virtual {p1, v0}, Lik/j;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-object v0

    .line 32
    nop

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_13
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lik/j;->d:I

    .line 2
    .line 3
    sget-object v1, Ll30/a0;->a:Ll30/a0;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_14

    .line 6
    .line 7
    .line 8
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 9
    .line 10
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-object v1

    .line 14
    :pswitch_d
    sget-object v0, Lr30/a;->d:Lr30/a;

    .line 15
    .line 16
    invoke-static {p1}, Landroid/support/v4/media/session/b;->i0(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-object v1

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method
