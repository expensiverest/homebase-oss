###### Class ik.n (ik.n)
.class public final Lik/n;
.super Ls30/c;
.source "SourceFile"


# instance fields
.field public d:Lik/a;

.field public e:Lb70/c;

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic v:Lik/o;

.field public w:I


# direct methods
.method public constructor <init>(Lik/o;Ls30/c;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lik/n;->v:Lik/o;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Ls30/c;-><init>(Lq30/c;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lik/n;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lik/n;->w:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lik/n;->w:I

    .line 9
    .line 10
    iget-object p1, p0, Lik/n;->v:Lik/o;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lik/o;->d(Lik/a;Ls30/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
