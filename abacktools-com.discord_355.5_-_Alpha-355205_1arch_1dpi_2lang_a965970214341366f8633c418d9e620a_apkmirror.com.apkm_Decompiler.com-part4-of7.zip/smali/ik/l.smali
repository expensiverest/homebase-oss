###### Class ik.l (ik.l)
.class public final Lik/l;
.super Ls30/c;
.source "SourceFile"


# instance fields
.field public J:I

.field public d:Ljava/lang/Object;

.field public e:Lik/a;

.field public i:Lz60/c1;

.field public v:Ljava/lang/Integer;

.field public w:Lb70/c;

.field public synthetic x:Ljava/lang/Object;

.field public final synthetic y:Lik/o;


# direct methods
.method public constructor <init>(Lik/o;Ls30/c;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lik/l;->y:Lik/o;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Ls30/c;-><init>(Lq30/c;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lik/l;->x:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lik/l;->J:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lik/l;->J:I

    .line 9
    .line 10
    iget-object p1, p0, Lik/l;->y:Lik/o;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0, v0, p0}, Lik/o;->b(Lik/o;Lr1/i;Lik/a;Ls30/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
