###### Class i5.o (i5.o)
.class public final Li5/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo4/n;


# instance fields
.field public A:Z

.field public B:Z

.field public C:I

.field public D:I

.field public E:J

.field public F:Lo4/p;

.field public G:[Li5/n;

.field public H:[[J

.field public I:I

.field public final a:Ll5/k;

.field public final b:I

.field public final c:Z

.field public final d:Ln3/x;

.field public final e:Ln3/x;

.field public final f:Ln3/x;

.field public final g:Ln3/x;

.field public final h:Ljava/util/ArrayDeque;

.field public final i:Li5/r;

.field public final j:Ljava/util/ArrayList;

.field public final k:Ljava/util/ArrayList;

.field public final l:Ljava/util/ArrayList;

.field public m:Lhx/w1;

.field public n:I

.field public o:I

.field public p:J

.field public q:I

.field public r:Ln3/x;

.field public s:I

.field public t:I

.field public u:I

.field public v:I

.field public w:Z

.field public x:Z

.field public y:Z

.field public z:J


# direct methods
.method static constructor <clinit>()V
    .registers 0

    .line 1
    return-void
.end method

.method public constructor <init>(Ll5/k;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li5/o;->a:Ll5/k;

    .line 5
    .line 6
    iput p2, p0, Li5/o;->b:I

    .line 7
    .line 8
    and-int/lit16 p1, p2, 0x100

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    if-eqz p1, :cond_e

    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    move p1, v0

    .line 16
    :goto_f
    iput-boolean p1, p0, Li5/o;->c:Z

    .line 17
    .line 18
    sget-object p1, Lhx/m0;->e:Lhx/k0;

    .line 19
    .line 20
    sget-object p1, Lhx/w1;->w:Lhx/w1;

    .line 21
    .line 22
    iput-object p1, p0, Li5/o;->m:Lhx/w1;

    .line 23
    .line 24
    and-int/lit8 p1, p2, 0x4

    .line 25
    .line 26
    if-eqz p1, :cond_1d

    .line 27
    .line 28
    const/4 p1, 0x3

    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move p1, v0

    .line 31
    :goto_1e
    iput p1, p0, Li5/o;->n:I

    .line 32
    .line 33
    new-instance p1, Li5/r;

    .line 34
    .line 35
    invoke-direct {p1}, Li5/r;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object p1, p0, Li5/o;->i:Li5/r;

    .line 39
    .line 40
    new-instance p1, Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object p1, p0, Li5/o;->j:Ljava/util/ArrayList;

    .line 46
    .line 47
    new-instance p1, Ln3/x;

    .line 48
    .line 49
    const/16 p2, 0x10

    .line 50
    .line 51
    invoke-direct {p1, p2}, Ln3/x;-><init>(I)V

    .line 52
    .line 53
    .line 54
    iput-object p1, p0, Li5/o;->g:Ln3/x;

    .line 55
    .line 56
    new-instance p1, Ljava/util/ArrayDeque;

    .line 57
    .line 58
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    .line 59
    .line 60
    .line 61
    iput-object p1, p0, Li5/o;->h:Ljava/util/ArrayDeque;

    .line 62
    .line 63
    new-instance p1, Ln3/x;

    .line 64
    .line 65
    sget-object p2, Lo3/n;->a:[B

    .line 66
    .line 67
    invoke-direct {p1, p2}, Ln3/x;-><init>([B)V

    .line 68
    .line 69
    .line 70
    iput-object p1, p0, Li5/o;->d:Ln3/x;

    .line 71
    .line 72
    new-instance p1, Ln3/x;

    .line 73
    .line 74
    const/4 p2, 0x6

    .line 75
    invoke-direct {p1, p2}, Ln3/x;-><init>(I)V

    .line 76
    .line 77
    .line 78
    iput-object p1, p0, Li5/o;->e:Ln3/x;

    .line 79
    .line 80
    new-instance p1, Ln3/x;

    .line 81
    .line 82
    invoke-direct {p1}, Ln3/x;-><init>()V

    .line 83
    .line 84
    .line 85
    iput-object p1, p0, Li5/o;->f:Ln3/x;

    .line 86
    .line 87
    const/4 p1, -0x1

    .line 88
    iput p1, p0, Li5/o;->s:I

    .line 89
    .line 90
    sget-object p1, Lo4/p;->t:Lal/c;

    .line 91
    .line 92
    iput-object p1, p0, Li5/o;->F:Lo4/p;

    .line 93
    .line 94
    new-array p1, v0, [Li5/n;

    .line 95
    .line 96
    iput-object p1, p0, Li5/o;->G:[Li5/n;

    .line 97
    .line 98
    new-instance p1, Ljava/util/ArrayList;

    .line 99
    .line 100
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 101
    .line 102
    .line 103
    iput-object p1, p0, Li5/o;->k:Ljava/util/ArrayList;

    .line 104
    .line 105
    new-instance p1, Ljava/util/ArrayList;

    .line 106
    .line 107
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 108
    .line 109
    .line 110
    iput-object p1, p0, Li5/o;->l:Ljava/util/ArrayList;

    .line 111
    .line 112
    return-void
.end method


# virtual methods
.method public final a(J)V
    .registers 47

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    :cond_2
    :goto_2
    iget-object v1, v0, Li5/o;->h:Ljava/util/ArrayDeque;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v5, 0x2

    .line 10
    if-nez v2, :cond_4f1

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    check-cast v2, Lo3/c;

    .line 17
    .line 18
    iget-wide v6, v2, Lo3/c;->i:J

    .line 19
    .line 20
    cmp-long v2, v6, p1

    .line 21
    .line 22
    if-nez v2, :cond_4f1

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    move-object v6, v2

    .line 29
    check-cast v6, Lo3/c;

    .line 30
    .line 31
    iget v2, v6, Lcz/j;->e:I

    .line 32
    .line 33
    const v7, 0x6d6f6f76

    .line 34
    .line 35
    .line 36
    if-ne v2, v7, :cond_4dc

    .line 37
    .line 38
    const v2, 0x6d657461

    .line 39
    .line 40
    .line 41
    invoke-virtual {v6, v2}, Lo3/c;->o(I)Lo3/c;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    new-instance v7, Ljava/util/ArrayList;

    .line 46
    .line 47
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 48
    .line 49
    .line 50
    const/4 v8, 0x1

    .line 51
    iget-object v9, v0, Li5/o;->k:Ljava/util/ArrayList;

    .line 52
    .line 53
    iget-boolean v10, v0, Li5/o;->c:Z

    .line 54
    .line 55
    const-wide/16 v16, 0x0

    .line 56
    .line 57
    iget v11, v0, Li5/o;->b:I

    .line 58
    .line 59
    if-eqz v2, :cond_156

    .line 60
    .line 61
    invoke-static {v2}, Li5/e;->f(Lo3/c;)Lk3/t0;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    iget-boolean v12, v0, Li5/o;->A:Z

    .line 66
    .line 67
    const-class v13, Lo3/a;

    .line 68
    .line 69
    if-eqz v12, :cond_fc

    .line 70
    .line 71
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    iget-object v7, v2, Lk3/t0;->a:[Lk3/s0;

    .line 75
    .line 76
    array-length v12, v7

    .line 77
    const/4 v14, 0x0

    .line 78
    :goto_4d
    if-ge v14, v12, :cond_7a

    .line 79
    .line 80
    aget-object v15, v7, v14

    .line 81
    .line 82
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-virtual {v13, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    if-eqz v4, :cond_71

    .line 91
    .line 92
    invoke-virtual {v13, v15}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    check-cast v4, Lk3/s0;

    .line 97
    .line 98
    move-object v15, v4

    .line 99
    check-cast v15, Lo3/a;

    .line 100
    .line 101
    iget-object v15, v15, Lo3/a;->a:Ljava/lang/String;

    .line 102
    .line 103
    const/16 v18, 0x0

    .line 104
    .line 105
    const-string v3, "auxiliary.tracks.interleaved"

    .line 106
    .line 107
    invoke-virtual {v15, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    if-eqz v3, :cond_73

    .line 112
    .line 113
    goto :goto_74

    .line 114
    :cond_71
    const/16 v18, 0x0

    .line 115
    .line 116
    :cond_73
    const/4 v4, 0x0

    .line 117
    :goto_74
    if-eqz v4, :cond_77

    .line 118
    .line 119
    goto :goto_7d

    .line 120
    :cond_77
    add-int/lit8 v14, v14, 0x1

    .line 121
    .line 122
    goto :goto_4d

    .line 123
    :cond_7a
    const/16 v18, 0x0

    .line 124
    .line 125
    const/4 v4, 0x0

    .line 126
    :goto_7d
    check-cast v4, Lo3/a;

    .line 127
    .line 128
    if-eqz v4, :cond_8e

    .line 129
    .line 130
    iget-object v3, v4, Lo3/a;->b:[B

    .line 131
    .line 132
    aget-byte v3, v3, v18

    .line 133
    .line 134
    if-nez v3, :cond_8e

    .line 135
    .line 136
    iget-wide v3, v0, Li5/o;->z:J

    .line 137
    .line 138
    const-wide/16 v14, 0x10

    .line 139
    .line 140
    add-long/2addr v3, v14

    .line 141
    iput-wide v3, v0, Li5/o;->E:J

    .line 142
    .line 143
    :cond_8e
    array-length v3, v7

    .line 144
    move/from16 v4, v18

    .line 145
    .line 146
    :goto_91
    if-ge v4, v3, :cond_ba

    .line 147
    .line 148
    aget-object v12, v7, v4

    .line 149
    .line 150
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 151
    .line 152
    .line 153
    move-result-object v14

    .line 154
    invoke-virtual {v13, v14}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 155
    .line 156
    .line 157
    move-result v14

    .line 158
    if-eqz v14, :cond_b3

    .line 159
    .line 160
    invoke-virtual {v13, v12}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v12

    .line 164
    check-cast v12, Lk3/s0;

    .line 165
    .line 166
    move-object v14, v12

    .line 167
    check-cast v14, Lo3/a;

    .line 168
    .line 169
    iget-object v14, v14, Lo3/a;->a:Ljava/lang/String;

    .line 170
    .line 171
    const-string v15, "auxiliary.tracks.map"

    .line 172
    .line 173
    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v14

    .line 177
    if-eqz v14, :cond_b3

    .line 178
    .line 179
    goto :goto_b4

    .line 180
    :cond_b3
    const/4 v12, 0x0

    .line 181
    :goto_b4
    if-eqz v12, :cond_b7

    .line 182
    .line 183
    goto :goto_bb

    .line 184
    :cond_b7
    add-int/lit8 v4, v4, 0x1

    .line 185
    .line 186
    goto :goto_91

    .line 187
    :cond_ba
    const/4 v12, 0x0

    .line 188
    :goto_bb
    check-cast v12, Lo3/a;

    .line 189
    .line 190
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 191
    .line 192
    .line 193
    invoke-virtual {v12}, Lo3/a;->d()Ljava/util/ArrayList;

    .line 194
    .line 195
    .line 196
    move-result-object v3

    .line 197
    new-instance v7, Ljava/util/ArrayList;

    .line 198
    .line 199
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 200
    .line 201
    .line 202
    move-result v4

    .line 203
    invoke-direct {v7, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 204
    .line 205
    .line 206
    move/from16 v4, v18

    .line 207
    .line 208
    :goto_cf
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 209
    .line 210
    .line 211
    move-result v12

    .line 212
    if-ge v4, v12, :cond_fa

    .line 213
    .line 214
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v12

    .line 218
    check-cast v12, Ljava/lang/Integer;

    .line 219
    .line 220
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    .line 221
    .line 222
    .line 223
    move-result v12

    .line 224
    if-eqz v12, :cond_ef

    .line 225
    .line 226
    if-eq v12, v8, :cond_ed

    .line 227
    .line 228
    const/4 v13, 0x3

    .line 229
    if-eq v12, v5, :cond_f0

    .line 230
    .line 231
    if-eq v12, v13, :cond_eb

    .line 232
    .line 233
    move/from16 v13, v18

    .line 234
    .line 235
    goto :goto_f0

    .line 236
    :cond_eb
    const/4 v13, 0x4

    .line 237
    goto :goto_f0

    .line 238
    :cond_ed
    move v13, v5

    .line 239
    goto :goto_f0

    .line 240
    :cond_ef
    move v13, v8

    .line 241
    :cond_f0
    :goto_f0
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 242
    .line 243
    .line 244
    move-result-object v12

    .line 245
    invoke-virtual {v7, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 246
    .line 247
    .line 248
    add-int/lit8 v4, v4, 0x1

    .line 249
    .line 250
    goto :goto_cf

    .line 251
    :cond_fa
    :goto_fa
    move-object v3, v7

    .line 252
    goto :goto_15a

    .line 253
    :cond_fc
    const/16 v18, 0x0

    .line 254
    .line 255
    if-eqz v2, :cond_fa

    .line 256
    .line 257
    and-int/lit8 v3, v11, 0x40

    .line 258
    .line 259
    if-nez v3, :cond_105

    .line 260
    .line 261
    goto :goto_fa

    .line 262
    :cond_105
    iget-object v3, v2, Lk3/t0;->a:[Lk3/s0;

    .line 263
    .line 264
    array-length v4, v3

    .line 265
    move/from16 v12, v18

    .line 266
    .line 267
    :goto_10a
    if-ge v12, v4, :cond_134

    .line 268
    .line 269
    aget-object v14, v3, v12

    .line 270
    .line 271
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 272
    .line 273
    .line 274
    move-result-object v15

    .line 275
    invoke-virtual {v13, v15}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 276
    .line 277
    .line 278
    move-result v15

    .line 279
    if-eqz v15, :cond_12c

    .line 280
    .line 281
    invoke-virtual {v13, v14}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v14

    .line 285
    check-cast v14, Lk3/s0;

    .line 286
    .line 287
    move-object v15, v14

    .line 288
    check-cast v15, Lo3/a;

    .line 289
    .line 290
    iget-object v15, v15, Lo3/a;->a:Ljava/lang/String;

    .line 291
    .line 292
    const-string v5, "auxiliary.tracks.offset"

    .line 293
    .line 294
    invoke-virtual {v15, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 295
    .line 296
    .line 297
    move-result v5

    .line 298
    if-eqz v5, :cond_12c

    .line 299
    .line 300
    goto :goto_12d

    .line 301
    :cond_12c
    const/4 v14, 0x0

    .line 302
    :goto_12d
    if-eqz v14, :cond_130

    .line 303
    .line 304
    goto :goto_135

    .line 305
    :cond_130
    add-int/lit8 v12, v12, 0x1

    .line 306
    .line 307
    const/4 v5, 0x2

    .line 308
    goto :goto_10a

    .line 309
    :cond_134
    const/4 v14, 0x0

    .line 310
    :goto_135
    check-cast v14, Lo3/a;

    .line 311
    .line 312
    if-nez v14, :cond_13a

    .line 313
    .line 314
    goto :goto_fa

    .line 315
    :cond_13a
    new-instance v3, Ln3/x;

    .line 316
    .line 317
    iget-object v4, v14, Lo3/a;->b:[B

    .line 318
    .line 319
    invoke-direct {v3, v4}, Ln3/x;-><init>([B)V

    .line 320
    .line 321
    .line 322
    invoke-virtual {v3}, Ln3/x;->G()J

    .line 323
    .line 324
    .line 325
    move-result-wide v3

    .line 326
    cmp-long v5, v3, v16

    .line 327
    .line 328
    if-gtz v5, :cond_14a

    .line 329
    .line 330
    goto :goto_fa

    .line 331
    :cond_14a
    iput-wide v3, v0, Li5/o;->z:J

    .line 332
    .line 333
    iput-boolean v8, v0, Li5/o;->y:Z

    .line 334
    .line 335
    move-object/from16 v23, v1

    .line 336
    .line 337
    move-object/from16 v26, v9

    .line 338
    .line 339
    move/from16 v22, v10

    .line 340
    .line 341
    goto/16 :goto_4c3

    .line 342
    .line 343
    :cond_156
    const/16 v18, 0x0

    .line 344
    .line 345
    move-object v3, v7

    .line 346
    const/4 v2, 0x0

    .line 347
    :goto_15a
    new-instance v4, Ljava/util/ArrayList;

    .line 348
    .line 349
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 350
    .line 351
    .line 352
    iget v5, v0, Li5/o;->I:I

    .line 353
    .line 354
    if-ne v5, v8, :cond_165

    .line 355
    .line 356
    move v12, v8

    .line 357
    goto :goto_167

    .line 358
    :cond_165
    move/from16 v12, v18

    .line 359
    .line 360
    :goto_167
    new-instance v7, Lo4/w;

    .line 361
    .line 362
    invoke-direct {v7}, Lo4/w;-><init>()V

    .line 363
    .line 364
    .line 365
    const v5, 0x75647461

    .line 366
    .line 367
    .line 368
    invoke-virtual {v6, v5}, Lo3/c;->p(I)Lo3/d;

    .line 369
    .line 370
    .line 371
    move-result-object v5

    .line 372
    if-eqz v5, :cond_185

    .line 373
    .line 374
    and-int/lit16 v13, v11, 0x200

    .line 375
    .line 376
    if-eqz v13, :cond_17b

    .line 377
    .line 378
    move v13, v8

    .line 379
    goto :goto_17d

    .line 380
    :cond_17b
    move/from16 v13, v18

    .line 381
    .line 382
    :goto_17d
    invoke-static {v5, v13}, Li5/e;->k(Lo3/d;Z)Lk3/t0;

    .line 383
    .line 384
    .line 385
    move-result-object v5

    .line 386
    invoke-virtual {v7, v5}, Lo4/w;->b(Lk3/t0;)V

    .line 387
    .line 388
    .line 389
    goto :goto_186

    .line 390
    :cond_185
    const/4 v5, 0x0

    .line 391
    :goto_186
    new-instance v15, Lk3/t0;

    .line 392
    .line 393
    const v13, 0x6d766864

    .line 394
    .line 395
    .line 396
    invoke-virtual {v6, v13}, Lo3/c;->p(I)Lo3/d;

    .line 397
    .line 398
    .line 399
    move-result-object v13

    .line 400
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 401
    .line 402
    .line 403
    iget-object v13, v13, Lo3/d;->i:Ln3/x;

    .line 404
    .line 405
    invoke-static {v13}, Li5/e;->g(Ln3/x;)Lo3/f;

    .line 406
    .line 407
    .line 408
    move-result-object v13

    .line 409
    new-array v14, v8, [Lk3/s0;

    .line 410
    .line 411
    aput-object v13, v14, v18

    .line 412
    .line 413
    invoke-direct {v15, v14}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 414
    .line 415
    .line 416
    and-int/lit8 v13, v11, 0x1

    .line 417
    .line 418
    if-eqz v13, :cond_1a6

    .line 419
    .line 420
    move v13, v11

    .line 421
    move v11, v8

    .line 422
    goto :goto_1a9

    .line 423
    :cond_1a6
    move v13, v11

    .line 424
    move/from16 v11, v18

    .line 425
    .line 426
    :goto_1a9
    new-instance v14, Lapp/rive/runtime/kotlin/a;

    .line 427
    .line 428
    const/16 v8, 0x19

    .line 429
    .line 430
    invoke-direct {v14, v8, v0}, Lapp/rive/runtime/kotlin/a;-><init>(ILjava/lang/Object;)V

    .line 431
    .line 432
    .line 433
    move v8, v13

    .line 434
    move-object v13, v14

    .line 435
    iget-boolean v14, v0, Li5/o;->c:Z

    .line 436
    .line 437
    move/from16 v21, v8

    .line 438
    .line 439
    move-object/from16 v20, v9

    .line 440
    .line 441
    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    move/from16 v22, v10

    .line 447
    .line 448
    const/4 v10, 0x0

    .line 449
    move-object/from16 v23, v1

    .line 450
    .line 451
    const/4 v1, 0x1

    .line 452
    invoke-static/range {v6 .. v14}, Li5/e;->j(Lo3/c;Lo4/w;JLk3/r;ZZLgx/k;Z)Ljava/util/ArrayList;

    .line 453
    .line 454
    .line 455
    move-result-object v6

    .line 456
    iget-boolean v8, v0, Li5/o;->A:Z

    .line 457
    .line 458
    if-eqz v8, :cond_1f0

    .line 459
    .line 460
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 461
    .line 462
    .line 463
    move-result v8

    .line 464
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 465
    .line 466
    .line 467
    move-result v9

    .line 468
    if-ne v8, v9, :cond_1d7

    .line 469
    .line 470
    move v8, v1

    .line 471
    goto :goto_1d9

    .line 472
    :cond_1d7
    move/from16 v8, v18

    .line 473
    .line 474
    :goto_1d9
    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 475
    .line 476
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 477
    .line 478
    .line 479
    move-result v9

    .line 480
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 481
    .line 482
    .line 483
    move-result v10

    .line 484
    const-string v11, ") is not same as the number of auxiliary tracks ("

    .line 485
    .line 486
    const-string v12, ")"

    .line 487
    .line 488
    const-string v13, "The number of auxiliary track types from metadata ("

    .line 489
    .line 490
    invoke-static {v9, v13, v10, v11, v12}, Lxw/a;->d(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 491
    .line 492
    .line 493
    move-result-object v9

    .line 494
    invoke-static {v9, v8}, Loq/a;->y(Ljava/lang/String;Z)V

    .line 495
    .line 496
    .line 497
    :cond_1f0
    new-instance v8, Ljava/util/ArrayList;

    .line 498
    .line 499
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 500
    .line 501
    .line 502
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 503
    .line 504
    .line 505
    move-result-object v9

    .line 506
    :cond_1f9
    :goto_1f9
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 507
    .line 508
    .line 509
    move-result v10

    .line 510
    const/4 v11, -0x1

    .line 511
    if-eqz v10, :cond_222

    .line 512
    .line 513
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 514
    .line 515
    .line 516
    move-result-object v10

    .line 517
    check-cast v10, Li5/w;

    .line 518
    .line 519
    iget-object v12, v10, Li5/w;->a:Li5/u;

    .line 520
    .line 521
    iget v12, v12, Li5/u;->l:I

    .line 522
    .line 523
    if-eq v12, v11, :cond_1f9

    .line 524
    .line 525
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 526
    .line 527
    .line 528
    move-result-object v11

    .line 529
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 530
    .line 531
    .line 532
    move-result v11

    .line 533
    if-nez v11, :cond_1f9

    .line 534
    .line 535
    iget-object v10, v10, Li5/w;->a:Li5/u;

    .line 536
    .line 537
    iget v10, v10, Li5/u;->l:I

    .line 538
    .line 539
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 540
    .line 541
    .line 542
    move-result-object v10

    .line 543
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 544
    .line 545
    .line 546
    goto :goto_1f9

    .line 547
    :cond_222
    invoke-virtual/range {v20 .. v20}, Ljava/util/ArrayList;->clear()V

    .line 548
    .line 549
    .line 550
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 551
    .line 552
    .line 553
    move-result-object v9

    .line 554
    :goto_229
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 555
    .line 556
    .line 557
    move-result v10

    .line 558
    if-eqz v10, :cond_24e

    .line 559
    .line 560
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 561
    .line 562
    .line 563
    move-result-object v10

    .line 564
    check-cast v10, Li5/w;

    .line 565
    .line 566
    iget-object v12, v10, Li5/w;->a:Li5/u;

    .line 567
    .line 568
    iget v12, v12, Li5/u;->a:I

    .line 569
    .line 570
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 571
    .line 572
    .line 573
    move-result-object v12

    .line 574
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 575
    .line 576
    .line 577
    move-result v12

    .line 578
    if-eqz v12, :cond_249

    .line 579
    .line 580
    move-object/from16 v12, v20

    .line 581
    .line 582
    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 583
    .line 584
    .line 585
    goto :goto_24b

    .line 586
    :cond_249
    move-object/from16 v12, v20

    .line 587
    .line 588
    :goto_24b
    move-object/from16 v20, v12

    .line 589
    .line 590
    goto :goto_229

    .line 591
    :cond_24e
    move-object/from16 v12, v20

    .line 592
    .line 593
    invoke-static {v6}, Li5/s;->b(Ljava/util/ArrayList;)Ljava/lang/String;

    .line 594
    .line 595
    .line 596
    move-result-object v8

    .line 597
    move v1, v11

    .line 598
    move/from16 v13, v18

    .line 599
    .line 600
    move v14, v13

    .line 601
    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    const-wide v19, -0x7fffffffffffffffL    # -4.9E-324

    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    :goto_262
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 612
    .line 613
    .line 614
    move-result v11

    .line 615
    if-ge v13, v11, :cond_429

    .line 616
    .line 617
    invoke-virtual {v6, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 618
    .line 619
    .line 620
    move-result-object v11

    .line 621
    check-cast v11, Li5/w;

    .line 622
    .line 623
    move-object/from16 v25, v6

    .line 624
    .line 625
    iget v6, v11, Li5/w;->b:I

    .line 626
    .line 627
    move/from16 v26, v6

    .line 628
    .line 629
    iget-object v6, v11, Li5/w;->f:[J

    .line 630
    .line 631
    move-object/from16 v27, v8

    .line 632
    .line 633
    iget v8, v11, Li5/w;->e:I

    .line 634
    .line 635
    move/from16 v28, v8

    .line 636
    .line 637
    iget-object v8, v11, Li5/w;->a:Li5/u;

    .line 638
    .line 639
    if-nez v26, :cond_285

    .line 640
    .line 641
    move-object/from16 v30, v4

    .line 642
    .line 643
    move-object/from16 v26, v12

    .line 644
    .line 645
    goto :goto_297

    .line 646
    :cond_285
    move-object/from16 v26, v12

    .line 647
    .line 648
    iget-boolean v12, v8, Li5/u;->m:Z

    .line 649
    .line 650
    move/from16 v29, v12

    .line 651
    .line 652
    iget-object v12, v8, Li5/u;->g:Lk3/w;

    .line 653
    .line 654
    move-object/from16 v30, v4

    .line 655
    .line 656
    iget v4, v8, Li5/u;->l:I

    .line 657
    .line 658
    move/from16 v31, v4

    .line 659
    .line 660
    iget v4, v8, Li5/u;->b:I

    .line 661
    .line 662
    if-nez v29, :cond_2a2

    .line 663
    .line 664
    :goto_297
    move v4, v1

    .line 665
    move-object v8, v2

    .line 666
    move-object/from16 v28, v3

    .line 667
    .line 668
    move-object v2, v5

    .line 669
    move-object v11, v15

    .line 670
    move-object/from16 v5, v30

    .line 671
    .line 672
    const/4 v1, -0x1

    .line 673
    goto/16 :goto_418

    .line 674
    .line 675
    :cond_2a2
    move-object/from16 v29, v2

    .line 676
    .line 677
    new-instance v2, Li5/n;

    .line 678
    .line 679
    move-object/from16 v32, v5

    .line 680
    .line 681
    iget-object v5, v0, Li5/o;->F:Lo4/p;

    .line 682
    .line 683
    add-int/lit8 v33, v14, 0x1

    .line 684
    .line 685
    invoke-interface {v5, v14, v4}, Lo4/p;->o(II)Lo4/i0;

    .line 686
    .line 687
    .line 688
    move-result-object v5

    .line 689
    invoke-direct {v2, v8, v11, v5}, Li5/n;-><init>(Li5/u;Li5/w;Lo4/i0;)V

    .line 690
    .line 691
    .line 692
    move-object/from16 v34, v15

    .line 693
    .line 694
    iget-wide v14, v8, Li5/u;->e:J

    .line 695
    .line 696
    cmp-long v8, v14, v19

    .line 697
    .line 698
    if-eqz v8, :cond_2bc

    .line 699
    .line 700
    goto :goto_2be

    .line 701
    :cond_2bc
    iget-wide v14, v11, Li5/w;->i:J

    .line 702
    .line 703
    :goto_2be
    invoke-interface {v5, v14, v15}, Lo4/i0;->b(J)V

    .line 704
    .line 705
    .line 706
    invoke-static {v9, v10, v14, v15}, Ljava/lang/Math;->max(JJ)J

    .line 707
    .line 708
    .line 709
    move-result-wide v9

    .line 710
    iget-object v5, v12, Lk3/w;->p:Ljava/lang/String;

    .line 711
    .line 712
    const-string v8, "audio/true-hd"

    .line 713
    .line 714
    invoke-virtual {v8, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 715
    .line 716
    .line 717
    move-result v8

    .line 718
    if-eqz v8, :cond_2d4

    .line 719
    .line 720
    mul-int/lit8 v8, v28, 0x10

    .line 721
    .line 722
    :goto_2d1
    move-wide/from16 v35, v9

    .line 723
    .line 724
    goto :goto_2d7

    .line 725
    :cond_2d4
    add-int/lit8 v8, v28, 0x1e

    .line 726
    .line 727
    goto :goto_2d1

    .line 728
    :goto_2d7
    invoke-virtual {v12}, Lk3/w;->a()Lk3/v;

    .line 729
    .line 730
    .line 731
    move-result-object v9

    .line 732
    iput v8, v9, Lk3/v;->p:I

    .line 733
    .line 734
    const/4 v8, 0x2

    .line 735
    if-ne v4, v8, :cond_303

    .line 736
    .line 737
    iget v8, v12, Lk3/w;->f:I

    .line 738
    .line 739
    and-int/lit8 v10, v21, 0x8

    .line 740
    .line 741
    if-eqz v10, :cond_2ed

    .line 742
    .line 743
    const/4 v10, -0x1

    .line 744
    if-ne v1, v10, :cond_2eb

    .line 745
    .line 746
    const/4 v10, 0x1

    .line 747
    goto :goto_2ec

    .line 748
    :cond_2eb
    const/4 v10, 0x2

    .line 749
    :goto_2ec
    or-int/2addr v8, v10

    .line 750
    :cond_2ed
    iget-boolean v10, v0, Li5/o;->A:Z

    .line 751
    .line 752
    if-eqz v10, :cond_301

    .line 753
    .line 754
    const v10, 0x8000

    .line 755
    .line 756
    .line 757
    or-int/2addr v8, v10

    .line 758
    invoke-interface {v3, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 759
    .line 760
    .line 761
    move-result-object v10

    .line 762
    check-cast v10, Ljava/lang/Integer;

    .line 763
    .line 764
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 765
    .line 766
    .line 767
    move-result v10

    .line 768
    iput v10, v9, Lk3/v;->h:I

    .line 769
    .line 770
    :cond_301
    iput v8, v9, Lk3/v;->f:I

    .line 771
    .line 772
    :cond_303
    iget-object v8, v11, Li5/w;->h:[I

    .line 773
    .line 774
    iget-boolean v10, v11, Li5/w;->j:Z

    .line 775
    .line 776
    move-object/from16 v28, v3

    .line 777
    .line 778
    iget-object v3, v12, Lk3/w;->p:Ljava/lang/String;

    .line 779
    .line 780
    invoke-static {v3}, Lk3/u0;->m(Ljava/lang/String;)Z

    .line 781
    .line 782
    .line 783
    move-result v3

    .line 784
    if-eqz v3, :cond_368

    .line 785
    .line 786
    array-length v3, v6

    .line 787
    if-lez v3, :cond_368

    .line 788
    .line 789
    if-eqz v10, :cond_31b

    .line 790
    .line 791
    iget v3, v11, Li5/w;->b:I

    .line 792
    .line 793
    :goto_318
    move-object/from16 v37, v6

    .line 794
    .line 795
    goto :goto_31d

    .line 796
    :cond_31b
    array-length v3, v8

    .line 797
    goto :goto_318

    .line 798
    :goto_31d
    const/16 v6, 0x14

    .line 799
    .line 800
    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    .line 801
    .line 802
    .line 803
    move-result v3

    .line 804
    cmp-long v6, v14, v19

    .line 805
    .line 806
    if-eqz v6, :cond_329

    .line 807
    .line 808
    const/4 v6, 0x1

    .line 809
    goto :goto_32b

    .line 810
    :cond_329
    move/from16 v6, v18

    .line 811
    .line 812
    :goto_32b
    invoke-static {v6}, Loq/a;->z(Z)V

    .line 813
    .line 814
    .line 815
    move v6, v1

    .line 816
    move-object/from16 v38, v2

    .line 817
    .line 818
    const-wide/32 v1, 0x989680

    .line 819
    .line 820
    .line 821
    invoke-static {v14, v15, v1, v2}, Ljava/lang/Math;->min(JJ)J

    .line 822
    .line 823
    .line 824
    move-result-wide v1

    .line 825
    move-wide/from16 v39, v1

    .line 826
    .line 827
    move/from16 v14, v18

    .line 828
    .line 829
    move v15, v14

    .line 830
    const/4 v1, -0x1

    .line 831
    :goto_33e
    if-ge v14, v3, :cond_34c

    .line 832
    .line 833
    if-eqz v10, :cond_344

    .line 834
    .line 835
    move v2, v14

    .line 836
    goto :goto_346

    .line 837
    :cond_344
    aget v2, v8, v14

    .line 838
    .line 839
    :goto_346
    aget-wide v41, v37, v2

    .line 840
    .line 841
    cmp-long v43, v41, v39

    .line 842
    .line 843
    if-lez v43, :cond_34e

    .line 844
    .line 845
    :cond_34c
    const/4 v10, -0x1

    .line 846
    goto :goto_360

    .line 847
    :cond_34e
    cmp-long v41, v41, v16

    .line 848
    .line 849
    if-ltz v41, :cond_35d

    .line 850
    .line 851
    move/from16 v41, v2

    .line 852
    .line 853
    iget-object v2, v11, Li5/w;->d:[I

    .line 854
    .line 855
    aget v2, v2, v41

    .line 856
    .line 857
    if-le v2, v15, :cond_35d

    .line 858
    .line 859
    move v15, v2

    .line 860
    move/from16 v1, v41

    .line 861
    .line 862
    :cond_35d
    add-int/lit8 v14, v14, 0x1

    .line 863
    .line 864
    goto :goto_33e

    .line 865
    :goto_360
    if-ne v1, v10, :cond_365

    .line 866
    .line 867
    :goto_362
    move-wide/from16 v1, v19

    .line 868
    .line 869
    goto :goto_36c

    .line 870
    :cond_365
    aget-wide v1, v37, v1

    .line 871
    .line 872
    goto :goto_36c

    .line 873
    :cond_368
    move v6, v1

    .line 874
    move-object/from16 v38, v2

    .line 875
    .line 876
    goto :goto_362

    .line 877
    :goto_36c
    cmp-long v3, v1, v19

    .line 878
    .line 879
    if-eqz v3, :cond_380

    .line 880
    .line 881
    new-instance v3, Lk3/t0;

    .line 882
    .line 883
    new-instance v8, Lx4/e;

    .line 884
    .line 885
    invoke-direct {v8, v1, v2}, Lx4/e;-><init>(J)V

    .line 886
    .line 887
    .line 888
    const/4 v1, 0x1

    .line 889
    new-array v2, v1, [Lk3/s0;

    .line 890
    .line 891
    aput-object v8, v2, v18

    .line 892
    .line 893
    invoke-direct {v3, v2}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 894
    .line 895
    .line 896
    goto :goto_382

    .line 897
    :cond_380
    const/4 v1, 0x1

    .line 898
    const/4 v3, 0x0

    .line 899
    :goto_382
    if-ne v4, v1, :cond_391

    .line 900
    .line 901
    iget v1, v7, Lo4/w;->a:I

    .line 902
    .line 903
    const/4 v10, -0x1

    .line 904
    if-eq v1, v10, :cond_391

    .line 905
    .line 906
    iget v2, v7, Lo4/w;->b:I

    .line 907
    .line 908
    if-eq v2, v10, :cond_391

    .line 909
    .line 910
    iput v1, v9, Lk3/v;->M:I

    .line 911
    .line 912
    iput v2, v9, Lk3/v;->N:I

    .line 913
    .line 914
    :cond_391
    iget-object v1, v12, Lk3/w;->m:Lk3/t0;

    .line 915
    .line 916
    iget-object v2, v0, Li5/o;->j:Ljava/util/ArrayList;

    .line 917
    .line 918
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 919
    .line 920
    .line 921
    move-result v8

    .line 922
    if-eqz v8, :cond_3a1

    .line 923
    .line 924
    const/4 v8, 0x0

    .line 925
    :goto_39c
    move-object/from16 v2, v32

    .line 926
    .line 927
    move-object/from16 v11, v34

    .line 928
    .line 929
    goto :goto_3a7

    .line 930
    :cond_3a1
    new-instance v8, Lk3/t0;

    .line 931
    .line 932
    invoke-direct {v8, v2}, Lk3/t0;-><init>(Ljava/util/List;)V

    .line 933
    .line 934
    .line 935
    goto :goto_39c

    .line 936
    :goto_3a7
    filled-new-array {v8, v2, v11, v3}, [Lk3/t0;

    .line 937
    .line 938
    .line 939
    move-result-object v3

    .line 940
    move-object/from16 v8, v29

    .line 941
    .line 942
    invoke-static {v4, v8, v9, v1, v3}, Li5/s;->k(ILk3/t0;Lk3/v;Lk3/t0;[Lk3/t0;)V

    .line 943
    .line 944
    .line 945
    invoke-static/range {v27 .. v27}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 946
    .line 947
    .line 948
    move-result-object v1

    .line 949
    iput-object v1, v9, Lk3/v;->n:Ljava/lang/String;

    .line 950
    .line 951
    new-instance v1, Lk3/w;

    .line 952
    .line 953
    invoke-direct {v1, v9}, Lk3/w;-><init>(Lk3/v;)V

    .line 954
    .line 955
    .line 956
    const-string v3, "audio/mpeg"

    .line 957
    .line 958
    invoke-static {v5, v3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 959
    .line 960
    .line 961
    move-result v3

    .line 962
    if-nez v3, :cond_3cd

    .line 963
    .line 964
    invoke-static {v5}, Lo4/a;->n(Ljava/lang/String;)Z

    .line 965
    .line 966
    .line 967
    move-result v3

    .line 968
    if-eqz v3, :cond_3ca

    .line 969
    .line 970
    goto :goto_3cd

    .line 971
    :cond_3ca
    move/from16 v3, v18

    .line 972
    .line 973
    goto :goto_3ce

    .line 974
    :cond_3cd
    :goto_3cd
    const/4 v3, 0x1

    .line 975
    :goto_3ce
    if-nez v22, :cond_3ed

    .line 976
    .line 977
    move/from16 v5, v31

    .line 978
    .line 979
    const/4 v10, -0x1

    .line 980
    if-eq v5, v10, :cond_3ed

    .line 981
    .line 982
    invoke-virtual/range {v26 .. v26}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 983
    .line 984
    .line 985
    move-result-object v9

    .line 986
    :cond_3d9
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 987
    .line 988
    .line 989
    move-result v10

    .line 990
    if-eqz v10, :cond_3ed

    .line 991
    .line 992
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 993
    .line 994
    .line 995
    move-result-object v10

    .line 996
    check-cast v10, Li5/w;

    .line 997
    .line 998
    iget-object v10, v10, Li5/w;->a:Li5/u;

    .line 999
    .line 1000
    iget v10, v10, Li5/u;->a:I

    .line 1001
    .line 1002
    if-ne v10, v5, :cond_3d9

    .line 1003
    .line 1004
    const/4 v5, 0x1

    .line 1005
    goto :goto_3ef

    .line 1006
    :cond_3ed
    move/from16 v5, v18

    .line 1007
    .line 1008
    :goto_3ef
    if-nez v3, :cond_3f3

    .line 1009
    .line 1010
    if-eqz v5, :cond_3f6

    .line 1011
    .line 1012
    :cond_3f3
    move-object/from16 v3, v38

    .line 1013
    .line 1014
    goto :goto_3ff

    .line 1015
    :cond_3f6
    move-object/from16 v3, v38

    .line 1016
    .line 1017
    iget-object v5, v3, Li5/n;->c:Lo4/i0;

    .line 1018
    .line 1019
    invoke-interface {v5, v1}, Lo4/i0;->d(Lk3/w;)V

    .line 1020
    .line 1021
    .line 1022
    :goto_3fd
    const/4 v1, 0x2

    .line 1023
    goto :goto_402

    .line 1024
    :goto_3ff
    iput-object v1, v3, Li5/n;->h:Lk3/w;

    .line 1025
    .line 1026
    goto :goto_3fd

    .line 1027
    :goto_402
    if-ne v4, v1, :cond_40e

    .line 1028
    .line 1029
    const/4 v1, -0x1

    .line 1030
    if-ne v6, v1, :cond_40f

    .line 1031
    .line 1032
    invoke-virtual/range {v30 .. v30}, Ljava/util/ArrayList;->size()I

    .line 1033
    .line 1034
    .line 1035
    move-result v4

    .line 1036
    :goto_40b
    move-object/from16 v5, v30

    .line 1037
    .line 1038
    goto :goto_411

    .line 1039
    :cond_40e
    const/4 v1, -0x1

    .line 1040
    :cond_40f
    move v4, v6

    .line 1041
    goto :goto_40b

    .line 1042
    :goto_411
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1043
    .line 1044
    .line 1045
    move/from16 v14, v33

    .line 1046
    .line 1047
    move-wide/from16 v9, v35

    .line 1048
    .line 1049
    :goto_418
    add-int/lit8 v13, v13, 0x1

    .line 1050
    .line 1051
    move v1, v4

    .line 1052
    move-object v4, v5

    .line 1053
    move-object v15, v11

    .line 1054
    move-object/from16 v6, v25

    .line 1055
    .line 1056
    move-object/from16 v12, v26

    .line 1057
    .line 1058
    move-object/from16 v3, v28

    .line 1059
    .line 1060
    move-object v5, v2

    .line 1061
    move-object v2, v8

    .line 1062
    move-object/from16 v8, v27

    .line 1063
    .line 1064
    goto/16 :goto_262

    .line 1065
    .line 1066
    :cond_429
    move v6, v1

    .line 1067
    move-object v5, v4

    .line 1068
    move-object/from16 v26, v12

    .line 1069
    .line 1070
    move/from16 v3, v18

    .line 1071
    .line 1072
    const/4 v1, -0x1

    .line 1073
    new-array v2, v3, [Li5/n;

    .line 1074
    .line 1075
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 1076
    .line 1077
    .line 1078
    move-result-object v2

    .line 1079
    check-cast v2, [Li5/n;

    .line 1080
    .line 1081
    iput-object v2, v0, Li5/o;->G:[Li5/n;

    .line 1082
    .line 1083
    if-nez v22, :cond_4af

    .line 1084
    .line 1085
    array-length v3, v2

    .line 1086
    new-array v15, v3, [[J

    .line 1087
    .line 1088
    array-length v3, v2

    .line 1089
    new-array v3, v3, [I

    .line 1090
    .line 1091
    array-length v4, v2

    .line 1092
    new-array v4, v4, [J

    .line 1093
    .line 1094
    array-length v5, v2

    .line 1095
    new-array v5, v5, [Z

    .line 1096
    .line 1097
    const/4 v7, 0x0

    .line 1098
    :goto_449
    array-length v8, v2

    .line 1099
    if-ge v7, v8, :cond_465

    .line 1100
    .line 1101
    aget-object v8, v2, v7

    .line 1102
    .line 1103
    iget-object v8, v8, Li5/n;->b:Li5/w;

    .line 1104
    .line 1105
    iget v8, v8, Li5/w;->b:I

    .line 1106
    .line 1107
    new-array v8, v8, [J

    .line 1108
    .line 1109
    aput-object v8, v15, v7

    .line 1110
    .line 1111
    aget-object v8, v2, v7

    .line 1112
    .line 1113
    iget-object v8, v8, Li5/n;->b:Li5/w;

    .line 1114
    .line 1115
    iget-object v8, v8, Li5/w;->f:[J

    .line 1116
    .line 1117
    const/16 v18, 0x0

    .line 1118
    .line 1119
    aget-wide v11, v8, v18

    .line 1120
    .line 1121
    aput-wide v11, v4, v7

    .line 1122
    .line 1123
    add-int/lit8 v7, v7, 0x1

    .line 1124
    .line 1125
    goto :goto_449

    .line 1126
    :cond_465
    const/4 v7, 0x0

    .line 1127
    :goto_466
    array-length v8, v2

    .line 1128
    if-ge v7, v8, :cond_4b0

    .line 1129
    .line 1130
    const-wide v11, 0x7fffffffffffffffL

    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    move-wide v12, v11

    .line 1136
    const/4 v8, 0x0

    .line 1137
    move v11, v1

    .line 1138
    :goto_471
    array-length v14, v2

    .line 1139
    if-ge v8, v14, :cond_484

    .line 1140
    .line 1141
    aget-boolean v14, v5, v8

    .line 1142
    .line 1143
    if-nez v14, :cond_481

    .line 1144
    .line 1145
    aget-wide v19, v4, v8

    .line 1146
    .line 1147
    cmp-long v14, v19, v12

    .line 1148
    .line 1149
    if-gtz v14, :cond_481

    .line 1150
    .line 1151
    move v11, v8

    .line 1152
    move-wide/from16 v12, v19

    .line 1153
    .line 1154
    :cond_481
    add-int/lit8 v8, v8, 0x1

    .line 1155
    .line 1156
    goto :goto_471

    .line 1157
    :cond_484
    aget v8, v3, v11

    .line 1158
    .line 1159
    aget-object v12, v15, v11

    .line 1160
    .line 1161
    aput-wide v16, v12, v8

    .line 1162
    .line 1163
    aget-object v13, v2, v11

    .line 1164
    .line 1165
    iget-object v13, v13, Li5/n;->b:Li5/w;

    .line 1166
    .line 1167
    iget-object v14, v13, Li5/w;->d:[I

    .line 1168
    .line 1169
    aget v14, v14, v8

    .line 1170
    .line 1171
    move-object/from16 v19, v2

    .line 1172
    .line 1173
    int-to-long v1, v14

    .line 1174
    add-long v16, v16, v1

    .line 1175
    .line 1176
    const/16 v24, 0x1

    .line 1177
    .line 1178
    add-int/lit8 v8, v8, 0x1

    .line 1179
    .line 1180
    aput v8, v3, v11

    .line 1181
    .line 1182
    array-length v1, v12

    .line 1183
    if-ge v8, v1, :cond_4a7

    .line 1184
    .line 1185
    iget-object v1, v13, Li5/w;->f:[J

    .line 1186
    .line 1187
    aget-wide v12, v1, v8

    .line 1188
    .line 1189
    aput-wide v12, v4, v11

    .line 1190
    .line 1191
    goto :goto_4ab

    .line 1192
    :cond_4a7
    aput-boolean v24, v5, v11

    .line 1193
    .line 1194
    add-int/lit8 v7, v7, 0x1

    .line 1195
    .line 1196
    :goto_4ab
    move-object/from16 v2, v19

    .line 1197
    .line 1198
    const/4 v1, -0x1

    .line 1199
    goto :goto_466

    .line 1200
    :cond_4af
    const/4 v15, 0x0

    .line 1201
    :cond_4b0
    iput-object v15, v0, Li5/o;->H:[[J

    .line 1202
    .line 1203
    iget-object v1, v0, Li5/o;->F:Lo4/p;

    .line 1204
    .line 1205
    invoke-interface {v1}, Lo4/p;->k()V

    .line 1206
    .line 1207
    .line 1208
    iget-object v1, v0, Li5/o;->F:Lo4/p;

    .line 1209
    .line 1210
    new-instance v2, Li5/m;

    .line 1211
    .line 1212
    iget-object v3, v0, Li5/o;->G:[Li5/n;

    .line 1213
    .line 1214
    invoke-direct {v2, v9, v10, v3, v6}, Li5/m;-><init>(J[Li5/n;I)V

    .line 1215
    .line 1216
    .line 1217
    invoke-interface {v1, v2}, Lo4/p;->E(Lo4/b0;)V

    .line 1218
    .line 1219
    .line 1220
    :goto_4c3
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayDeque;->clear()V

    .line 1221
    .line 1222
    .line 1223
    const/4 v1, 0x1

    .line 1224
    iput-boolean v1, v0, Li5/o;->B:Z

    .line 1225
    .line 1226
    iget-boolean v1, v0, Li5/o;->y:Z

    .line 1227
    .line 1228
    if-nez v1, :cond_2

    .line 1229
    .line 1230
    if-nez v22, :cond_2

    .line 1231
    .line 1232
    invoke-virtual/range {v26 .. v26}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1233
    .line 1234
    .line 1235
    move-result v1

    .line 1236
    if-nez v1, :cond_4d7

    .line 1237
    .line 1238
    const/4 v4, 0x4

    .line 1239
    goto :goto_4d8

    .line 1240
    :cond_4d7
    const/4 v4, 0x2

    .line 1241
    :goto_4d8
    iput v4, v0, Li5/o;->n:I

    .line 1242
    .line 1243
    goto/16 :goto_2

    .line 1244
    .line 1245
    :cond_4dc
    move-object/from16 v23, v1

    .line 1246
    .line 1247
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 1248
    .line 1249
    .line 1250
    move-result v1

    .line 1251
    if-nez v1, :cond_2

    .line 1252
    .line 1253
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 1254
    .line 1255
    .line 1256
    move-result-object v1

    .line 1257
    check-cast v1, Lo3/c;

    .line 1258
    .line 1259
    iget-object v1, v1, Lo3/c;->w:Ljava/util/ArrayList;

    .line 1260
    .line 1261
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1262
    .line 1263
    .line 1264
    goto/16 :goto_2

    .line 1265
    .line 1266
    :cond_4f1
    iget v1, v0, Li5/o;->n:I

    .line 1267
    .line 1268
    const/4 v2, 0x4

    .line 1269
    if-eq v1, v2, :cond_4fe

    .line 1270
    .line 1271
    const/4 v8, 0x2

    .line 1272
    if-eq v1, v8, :cond_4fe

    .line 1273
    .line 1274
    const/4 v3, 0x0

    .line 1275
    iput v3, v0, Li5/o;->n:I

    .line 1276
    .line 1277
    iput v3, v0, Li5/o;->q:I

    .line 1278
    .line 1279
    :cond_4fe
    return-void
.end method

.method public final d(JJ)V
    .registers 11

    .line 1
    iget-object v0, p0, Li5/o;->h:Ljava/util/ArrayDeque;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput v0, p0, Li5/o;->q:I

    .line 8
    .line 9
    const/4 v1, -0x1

    .line 10
    iput v1, p0, Li5/o;->s:I

    .line 11
    .line 12
    iput v0, p0, Li5/o;->t:I

    .line 13
    .line 14
    iput v0, p0, Li5/o;->u:I

    .line 15
    .line 16
    iput v0, p0, Li5/o;->v:I

    .line 17
    .line 18
    iput-boolean v0, p0, Li5/o;->w:Z

    .line 19
    .line 20
    iput-boolean v0, p0, Li5/o;->B:Z

    .line 21
    .line 22
    iput v0, p0, Li5/o;->C:I

    .line 23
    .line 24
    iput v0, p0, Li5/o;->D:I

    .line 25
    .line 26
    iget-object v2, p0, Li5/o;->k:Ljava/util/ArrayList;

    .line 27
    .line 28
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 29
    .line 30
    .line 31
    iget-object v2, p0, Li5/o;->l:Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 34
    .line 35
    .line 36
    const-wide/16 v2, 0x0

    .line 37
    .line 38
    cmp-long p1, p1, v2

    .line 39
    .line 40
    if-nez p1, :cond_42

    .line 41
    .line 42
    iget p1, p0, Li5/o;->n:I

    .line 43
    .line 44
    const/4 p2, 0x3

    .line 45
    if-eq p1, p2, :cond_33

    .line 46
    .line 47
    iput v0, p0, Li5/o;->n:I

    .line 48
    .line 49
    iput v0, p0, Li5/o;->q:I

    .line 50
    .line 51
    return-void

    .line 52
    :cond_33
    iget-object p1, p0, Li5/o;->i:Li5/r;

    .line 53
    .line 54
    iget-object p2, p1, Li5/r;->a:Ljava/util/ArrayList;

    .line 55
    .line 56
    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    .line 57
    .line 58
    .line 59
    iput v0, p1, Li5/r;->b:I

    .line 60
    .line 61
    iget-object p1, p0, Li5/o;->j:Ljava/util/ArrayList;

    .line 62
    .line 63
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_42
    iget-object p1, p0, Li5/o;->G:[Li5/n;

    .line 68
    .line 69
    array-length p2, p1

    .line 70
    move v2, v0

    .line 71
    :goto_46
    if-ge v2, p2, :cond_63

    .line 72
    .line 73
    aget-object v3, p1, v2

    .line 74
    .line 75
    iget-object v4, v3, Li5/n;->b:Li5/w;

    .line 76
    .line 77
    invoke-virtual {v4, p3, p4}, Li5/w;->a(J)I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    if-ne v5, v1, :cond_56

    .line 82
    .line 83
    invoke-virtual {v4, p3, p4}, Li5/w;->b(J)I

    .line 84
    .line 85
    .line 86
    move-result v5

    .line 87
    :cond_56
    iput v5, v3, Li5/n;->g:I

    .line 88
    .line 89
    iget-object v3, v3, Li5/n;->d:Lo4/j0;

    .line 90
    .line 91
    if-eqz v3, :cond_60

    .line 92
    .line 93
    iput-boolean v0, v3, Lo4/j0;->b:Z

    .line 94
    .line 95
    iput v0, v3, Lo4/j0;->c:I

    .line 96
    .line 97
    :cond_60
    add-int/lit8 v2, v2, 0x1

    .line 98
    .line 99
    goto :goto_46

    .line 100
    :cond_63
    return-void
.end method

.method public final e(Lo4/p;)V
    .registers 4

    .line 1
    iget v0, p0, Li5/o;->b:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x10

    .line 4
    .line 5
    if-nez v0, :cond_e

    .line 6
    .line 7
    new-instance v0, Lcom/google/firebase/messaging/o;

    .line 8
    .line 9
    iget-object v1, p0, Li5/o;->a:Ll5/k;

    .line 10
    .line 11
    invoke-direct {v0, p1, v1}, Lcom/google/firebase/messaging/o;-><init>(Lo4/p;Ll5/k;)V

    .line 12
    .line 13
    .line 14
    move-object p1, v0

    .line 15
    :cond_e
    iput-object p1, p0, Li5/o;->F:Lo4/p;

    .line 16
    .line 17
    return-void
.end method

.method public final f(Lo4/o;)Z
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, Li5/s;->l(Lo4/o;Z)Lo4/f0;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    if-eqz p1, :cond_c

    .line 7
    .line 8
    invoke-static {p1}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    goto :goto_10

    .line 13
    :cond_c
    sget-object v1, Lhx/m0;->e:Lhx/k0;

    .line 14
    .line 15
    sget-object v1, Lhx/w1;->w:Lhx/w1;

    .line 16
    .line 17
    :goto_10
    iput-object v1, p0, Li5/o;->m:Lhx/w1;

    .line 18
    .line 19
    if-nez p1, :cond_16

    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    return p1

    .line 23
    :cond_16
    return v0
.end method

.method public final g(Lo4/o;Lo4/r;)I
    .registers 46

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-boolean v3, v1, Li5/o;->c:Z

    .line 8
    .line 9
    if-eqz v3, :cond_12

    .line 10
    .line 11
    iget-boolean v3, v1, Li5/o;->B:Z

    .line 12
    .line 13
    if-eqz v3, :cond_12

    .line 14
    .line 15
    :goto_e
    const/16 v25, -0x1

    .line 16
    .line 17
    goto/16 :goto_892

    .line 18
    .line 19
    :cond_12
    :goto_12
    iget v3, v1, Li5/o;->n:I

    .line 20
    .line 21
    const v5, 0x66747970

    .line 22
    .line 23
    .line 24
    iget-object v6, v1, Li5/o;->h:Ljava/util/ArrayDeque;

    .line 25
    .line 26
    iget-object v12, v1, Li5/o;->f:Ln3/x;

    .line 27
    .line 28
    const/4 v13, 0x0

    .line 29
    const/4 v14, 0x0

    .line 30
    const/4 v15, 0x1

    .line 31
    if-eqz v3, :cond_6f8

    .line 32
    .line 33
    const-wide/32 v16, 0x40000

    .line 34
    .line 35
    .line 36
    const-wide/16 v18, -0x1

    .line 37
    .line 38
    const/4 v7, 0x4

    .line 39
    const/4 v8, 0x2

    .line 40
    if-eq v3, v15, :cond_653

    .line 41
    .line 42
    const-wide/16 v20, 0x8

    .line 43
    .line 44
    const-string v5, "audio/mpeg"

    .line 45
    .line 46
    if-eq v3, v8, :cond_38a

    .line 47
    .line 48
    const/4 v6, 0x3

    .line 49
    if-eq v3, v6, :cond_178

    .line 50
    .line 51
    if-ne v3, v7, :cond_172

    .line 52
    .line 53
    iget v3, v1, Li5/o;->C:I

    .line 54
    .line 55
    iget-object v4, v1, Li5/o;->k:Ljava/util/ArrayList;

    .line 56
    .line 57
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    check-cast v3, Li5/w;

    .line 62
    .line 63
    iget v6, v1, Li5/o;->D:I

    .line 64
    .line 65
    iget v7, v3, Li5/w;->b:I

    .line 66
    .line 67
    iget-object v9, v3, Li5/w;->f:[J

    .line 68
    .line 69
    iget-object v10, v1, Li5/o;->l:Ljava/util/ArrayList;

    .line 70
    .line 71
    if-ge v6, v7, :cond_af

    .line 72
    .line 73
    iget-object v4, v3, Li5/w;->c:[J

    .line 74
    .line 75
    aget-wide v5, v4, v6

    .line 76
    .line 77
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 78
    .line 79
    .line 80
    move-result-wide v7

    .line 81
    cmp-long v4, v7, v5

    .line 82
    .line 83
    if-eqz v4, :cond_57

    .line 84
    .line 85
    iput-wide v5, v2, Lo4/r;->b:J

    .line 86
    .line 87
    return v15

    .line 88
    :cond_57
    iget-object v2, v3, Li5/w;->d:[I

    .line 89
    .line 90
    iget v4, v1, Li5/o;->D:I

    .line 91
    .line 92
    aget v2, v2, v4

    .line 93
    .line 94
    invoke-virtual {v12, v2}, Ln3/x;->K(I)V

    .line 95
    .line 96
    .line 97
    iget-object v4, v12, Ln3/x;->a:[B

    .line 98
    .line 99
    invoke-interface {v0, v4, v14, v2}, Lo4/o;->readFully([BII)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v12}, Ln3/x;->H()I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    invoke-virtual {v12}, Ln3/x;->a()I

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 115
    .line 116
    invoke-virtual {v12, v0, v2}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    iget v2, v1, Li5/o;->D:I

    .line 121
    .line 122
    aget-wide v4, v9, v2

    .line 123
    .line 124
    invoke-static {v4, v5}, Ln3/l0;->g0(J)J

    .line 125
    .line 126
    .line 127
    move-result-wide v17

    .line 128
    iget v2, v1, Li5/o;->D:I

    .line 129
    .line 130
    add-int/2addr v2, v15

    .line 131
    iget v4, v3, Li5/w;->b:I

    .line 132
    .line 133
    if-ge v2, v4, :cond_8f

    .line 134
    .line 135
    aget-wide v2, v9, v2

    .line 136
    .line 137
    invoke-static {v2, v3}, Ln3/l0;->g0(J)J

    .line 138
    .line 139
    .line 140
    move-result-wide v2

    .line 141
    :goto_8c
    move-wide/from16 v19, v2

    .line 142
    .line 143
    goto :goto_96

    .line 144
    :cond_8f
    iget-wide v2, v3, Li5/w;->i:J

    .line 145
    .line 146
    invoke-static {v2, v3}, Ln3/l0;->g0(J)J

    .line 147
    .line 148
    .line 149
    move-result-wide v2

    .line 150
    goto :goto_8c

    .line 151
    :goto_96
    new-instance v2, Lk3/z;

    .line 152
    .line 153
    invoke-direct {v2, v13, v0}, Lk3/z;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    new-instance v16, Lx4/b;

    .line 157
    .line 158
    const/16 v21, 0x0

    .line 159
    .line 160
    move-object/from16 v22, v2

    .line 161
    .line 162
    invoke-direct/range {v16 .. v22}, Lx4/b;-><init>(JJZLk3/z;)V

    .line 163
    .line 164
    .line 165
    move-object/from16 v0, v16

    .line 166
    .line 167
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    iget v0, v1, Li5/o;->D:I

    .line 171
    .line 172
    add-int/2addr v0, v15

    .line 173
    iput v0, v1, Li5/o;->D:I

    .line 174
    .line 175
    return v14

    .line 176
    :cond_af
    iget-object v0, v1, Li5/o;->G:[Li5/n;

    .line 177
    .line 178
    array-length v2, v0

    .line 179
    move v6, v14

    .line 180
    :goto_b3
    if-ge v6, v2, :cond_158

    .line 181
    .line 182
    aget-object v7, v0, v6

    .line 183
    .line 184
    iget-object v9, v7, Li5/n;->a:Li5/u;

    .line 185
    .line 186
    iget v9, v9, Li5/u;->l:I

    .line 187
    .line 188
    iget-object v11, v3, Li5/w;->a:Li5/u;

    .line 189
    .line 190
    iget v11, v11, Li5/u;->a:I

    .line 191
    .line 192
    if-ne v9, v11, :cond_145

    .line 193
    .line 194
    iget-object v9, v7, Li5/n;->h:Lk3/w;

    .line 195
    .line 196
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 197
    .line 198
    .line 199
    iget-object v11, v9, Lk3/w;->m:Lk3/t0;

    .line 200
    .line 201
    new-instance v12, Ljava/util/ArrayList;

    .line 202
    .line 203
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 204
    .line 205
    .line 206
    if-eqz v11, :cond_111

    .line 207
    .line 208
    move/from16 v22, v15

    .line 209
    .line 210
    invoke-static {}, Lhx/m0;->p()Lhx/j0;

    .line 211
    .line 212
    .line 213
    move-result-object v15

    .line 214
    iget-object v11, v11, Lk3/t0;->a:[Lk3/s0;

    .line 215
    .line 216
    array-length v8, v11

    .line 217
    :goto_d8
    if-ge v14, v8, :cond_105

    .line 218
    .line 219
    aget-object v13, v11, v14

    .line 220
    .line 221
    move-object/from16 v16, v0

    .line 222
    .line 223
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    move/from16 v17, v2

    .line 228
    .line 229
    const-class v2, Lk3/s0;

    .line 230
    .line 231
    invoke-virtual {v2, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    if-eqz v0, :cond_f7

    .line 236
    .line 237
    invoke-virtual {v2, v13}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    check-cast v0, Lk3/s0;

    .line 242
    .line 243
    instance-of v2, v0, Lx4/a;

    .line 244
    .line 245
    if-nez v2, :cond_f7

    .line 246
    .line 247
    goto :goto_f8

    .line 248
    :cond_f7
    const/4 v0, 0x0

    .line 249
    :goto_f8
    if-eqz v0, :cond_fd

    .line 250
    .line 251
    invoke-virtual {v15, v0}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    :cond_fd
    add-int/lit8 v14, v14, 0x1

    .line 255
    .line 256
    move-object/from16 v0, v16

    .line 257
    .line 258
    move/from16 v2, v17

    .line 259
    .line 260
    const/4 v13, 0x0

    .line 261
    goto :goto_d8

    .line 262
    :cond_105
    move-object/from16 v16, v0

    .line 263
    .line 264
    move/from16 v17, v2

    .line 265
    .line 266
    invoke-virtual {v15}, Lhx/j0;->g()Lhx/w1;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 271
    .line 272
    .line 273
    goto :goto_117

    .line 274
    :cond_111
    move-object/from16 v16, v0

    .line 275
    .line 276
    move/from16 v17, v2

    .line 277
    .line 278
    move/from16 v22, v15

    .line 279
    .line 280
    :goto_117
    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 281
    .line 282
    .line 283
    invoke-virtual {v9}, Lk3/w;->a()Lk3/v;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    new-instance v2, Lk3/t0;

    .line 288
    .line 289
    invoke-direct {v2, v12}, Lk3/t0;-><init>(Ljava/util/List;)V

    .line 290
    .line 291
    .line 292
    iput-object v2, v0, Lk3/v;->l:Lk3/t0;

    .line 293
    .line 294
    new-instance v2, Lk3/w;

    .line 295
    .line 296
    invoke-direct {v2, v0}, Lk3/w;-><init>(Lk3/v;)V

    .line 297
    .line 298
    .line 299
    iget-object v0, v2, Lk3/w;->p:Ljava/lang/String;

    .line 300
    .line 301
    invoke-static {v0, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    move-result v8

    .line 305
    if-nez v8, :cond_142

    .line 306
    .line 307
    invoke-static {v0}, Lo4/a;->n(Ljava/lang/String;)Z

    .line 308
    .line 309
    .line 310
    move-result v0

    .line 311
    if-eqz v0, :cond_139

    .line 312
    .line 313
    goto :goto_142

    .line 314
    :cond_139
    iget-object v0, v7, Li5/n;->c:Lo4/i0;

    .line 315
    .line 316
    invoke-interface {v0, v2}, Lo4/i0;->d(Lk3/w;)V

    .line 317
    .line 318
    .line 319
    const/4 v2, 0x0

    .line 320
    iput-object v2, v7, Li5/n;->h:Lk3/w;

    .line 321
    .line 322
    goto :goto_14b

    .line 323
    :cond_142
    :goto_142
    iput-object v2, v7, Li5/n;->h:Lk3/w;

    .line 324
    .line 325
    goto :goto_14b

    .line 326
    :cond_145
    move-object/from16 v16, v0

    .line 327
    .line 328
    move/from16 v17, v2

    .line 329
    .line 330
    move/from16 v22, v15

    .line 331
    .line 332
    :goto_14b
    add-int/lit8 v6, v6, 0x1

    .line 333
    .line 334
    move-object/from16 v0, v16

    .line 335
    .line 336
    move/from16 v2, v17

    .line 337
    .line 338
    move/from16 v15, v22

    .line 339
    .line 340
    const/4 v8, 0x2

    .line 341
    const/4 v13, 0x0

    .line 342
    const/4 v14, 0x0

    .line 343
    goto/16 :goto_b3

    .line 344
    .line 345
    :cond_158
    move/from16 v22, v15

    .line 346
    .line 347
    iget v0, v1, Li5/o;->C:I

    .line 348
    .line 349
    add-int/lit8 v0, v0, 0x1

    .line 350
    .line 351
    iput v0, v1, Li5/o;->C:I

    .line 352
    .line 353
    const/4 v0, 0x0

    .line 354
    iput v0, v1, Li5/o;->D:I

    .line 355
    .line 356
    invoke-virtual {v10}, Ljava/util/ArrayList;->clear()V

    .line 357
    .line 358
    .line 359
    iget v2, v1, Li5/o;->C:I

    .line 360
    .line 361
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 362
    .line 363
    .line 364
    move-result v3

    .line 365
    if-ne v2, v3, :cond_171

    .line 366
    .line 367
    const/4 v2, 0x2

    .line 368
    iput v2, v1, Li5/o;->n:I

    .line 369
    .line 370
    :cond_171
    return v0

    .line 371
    :cond_172
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 372
    .line 373
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 374
    .line 375
    .line 376
    throw v0

    .line 377
    :cond_178
    move/from16 v22, v15

    .line 378
    .line 379
    iget-object v3, v1, Li5/o;->i:Li5/r;

    .line 380
    .line 381
    iget-object v5, v3, Li5/r;->a:Ljava/util/ArrayList;

    .line 382
    .line 383
    iget v8, v3, Li5/r;->b:I

    .line 384
    .line 385
    if-eqz v8, :cond_365

    .line 386
    .line 387
    move/from16 v12, v22

    .line 388
    .line 389
    if-eq v8, v12, :cond_331

    .line 390
    .line 391
    const/16 v12, 0xb01

    .line 392
    .line 393
    const/16 v13, 0xb04

    .line 394
    .line 395
    const/16 v14, 0xb00

    .line 396
    .line 397
    const/16 v15, 0xb03

    .line 398
    .line 399
    const/16 v4, 0x890

    .line 400
    .line 401
    const/4 v11, 0x2

    .line 402
    if-eq v8, v11, :cond_2c5

    .line 403
    .line 404
    if-ne v8, v6, :cond_2bf

    .line 405
    .line 406
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 407
    .line 408
    .line 409
    move-result-wide v16

    .line 410
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 411
    .line 412
    .line 413
    move-result-wide v18

    .line 414
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 415
    .line 416
    .line 417
    move-result-wide v20

    .line 418
    sub-long v18, v18, v20

    .line 419
    .line 420
    iget v3, v3, Li5/r;->c:I

    .line 421
    .line 422
    int-to-long v9, v3

    .line 423
    sub-long v8, v18, v9

    .line 424
    .line 425
    long-to-int v3, v8

    .line 426
    new-instance v8, Ln3/x;

    .line 427
    .line 428
    invoke-direct {v8, v3}, Ln3/x;-><init>(I)V

    .line 429
    .line 430
    .line 431
    iget-object v9, v8, Ln3/x;->a:[B

    .line 432
    .line 433
    const/4 v10, 0x0

    .line 434
    invoke-interface {v0, v9, v10, v3}, Lo4/o;->readFully([BII)V

    .line 435
    .line 436
    .line 437
    const/4 v0, 0x0

    .line 438
    :goto_1b5
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 439
    .line 440
    .line 441
    move-result v3

    .line 442
    if-ge v0, v3, :cond_2b8

    .line 443
    .line 444
    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    move-result-object v3

    .line 448
    check-cast v3, Li5/q;

    .line 449
    .line 450
    iget-wide v9, v3, Li5/q;->a:J

    .line 451
    .line 452
    sub-long v9, v9, v16

    .line 453
    .line 454
    long-to-int v9, v9

    .line 455
    invoke-virtual {v8, v9}, Ln3/x;->N(I)V

    .line 456
    .line 457
    .line 458
    invoke-virtual {v8, v7}, Ln3/x;->O(I)V

    .line 459
    .line 460
    .line 461
    invoke-virtual {v8}, Ln3/x;->o()I

    .line 462
    .line 463
    .line 464
    move-result v9

    .line 465
    sget-object v10, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 466
    .line 467
    invoke-virtual {v8, v9, v10}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v11

    .line 471
    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    .line 472
    .line 473
    .line 474
    move-result v18

    .line 475
    sparse-switch v18, :sswitch_data_898

    .line 476
    .line 477
    .line 478
    :goto_1dd
    const/4 v7, -0x1

    .line 479
    goto :goto_215

    .line 480
    :sswitch_1df
    const-string v7, "Super_SlowMotion_BGM"

    .line 481
    .line 482
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    move-result v7

    .line 486
    if-nez v7, :cond_1e8

    .line 487
    .line 488
    goto :goto_1dd

    .line 489
    :cond_1e8
    const/4 v7, 0x4

    .line 490
    goto :goto_215

    .line 491
    :sswitch_1ea
    const-string v7, "Super_SlowMotion_Deflickering_On"

    .line 492
    .line 493
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 494
    .line 495
    .line 496
    move-result v7

    .line 497
    if-nez v7, :cond_1f3

    .line 498
    .line 499
    goto :goto_1dd

    .line 500
    :cond_1f3
    move v7, v6

    .line 501
    goto :goto_215

    .line 502
    :sswitch_1f5
    const-string v7, "Super_SlowMotion_Data"

    .line 503
    .line 504
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 505
    .line 506
    .line 507
    move-result v7

    .line 508
    if-nez v7, :cond_1fe

    .line 509
    .line 510
    goto :goto_1dd

    .line 511
    :cond_1fe
    const/4 v7, 0x2

    .line 512
    goto :goto_215

    .line 513
    :sswitch_200
    const-string v7, "Super_SlowMotion_Edit_Data"

    .line 514
    .line 515
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 516
    .line 517
    .line 518
    move-result v7

    .line 519
    if-nez v7, :cond_209

    .line 520
    .line 521
    goto :goto_1dd

    .line 522
    :cond_209
    const/4 v7, 0x1

    .line 523
    goto :goto_215

    .line 524
    :sswitch_20b
    const-string v7, "SlowMotion_Data"

    .line 525
    .line 526
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 527
    .line 528
    .line 529
    move-result v7

    .line 530
    if-nez v7, :cond_214

    .line 531
    .line 532
    goto :goto_1dd

    .line 533
    :cond_214
    const/4 v7, 0x0

    .line 534
    :goto_215
    packed-switch v7, :pswitch_data_8ae

    .line 535
    .line 536
    .line 537
    const-string v0, "Invalid SEF name"

    .line 538
    .line 539
    const/4 v2, 0x0

    .line 540
    invoke-static {v0, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 541
    .line 542
    .line 543
    move-result-object v0

    .line 544
    throw v0

    .line 545
    :pswitch_220
    move v7, v12

    .line 546
    goto :goto_229

    .line 547
    :pswitch_222
    move v7, v13

    .line 548
    goto :goto_229

    .line 549
    :pswitch_224
    move v7, v14

    .line 550
    goto :goto_229

    .line 551
    :pswitch_226
    move v7, v15

    .line 552
    goto :goto_229

    .line 553
    :pswitch_228
    move v7, v4

    .line 554
    :goto_229
    iget v3, v3, Li5/q;->b:I

    .line 555
    .line 556
    add-int/lit8 v9, v9, 0x8

    .line 557
    .line 558
    sub-int/2addr v3, v9

    .line 559
    if-eq v7, v4, :cond_240

    .line 560
    .line 561
    if-eq v7, v14, :cond_2b3

    .line 562
    .line 563
    if-eq v7, v12, :cond_2b3

    .line 564
    .line 565
    if-eq v7, v15, :cond_2b3

    .line 566
    .line 567
    if-ne v7, v13, :cond_23a

    .line 568
    .line 569
    goto/16 :goto_2b3

    .line 570
    .line 571
    :cond_23a
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 572
    .line 573
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 574
    .line 575
    .line 576
    throw v0

    .line 577
    :cond_240
    new-instance v7, Ljava/util/ArrayList;

    .line 578
    .line 579
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 580
    .line 581
    .line 582
    invoke-virtual {v8, v3, v10}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 583
    .line 584
    .line 585
    move-result-object v3

    .line 586
    sget-object v9, Li5/r;->e:Lcom/google/android/gms/internal/fido/f8;

    .line 587
    .line 588
    invoke-virtual {v9, v3}, Lcom/google/android/gms/internal/fido/f8;->V(Ljava/lang/CharSequence;)Ljava/util/List;

    .line 589
    .line 590
    .line 591
    move-result-object v3

    .line 592
    const/4 v9, 0x0

    .line 593
    :goto_250
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 594
    .line 595
    .line 596
    move-result v10

    .line 597
    if-ge v9, v10, :cond_2a9

    .line 598
    .line 599
    sget-object v10, Li5/r;->d:Lcom/google/android/gms/internal/fido/f8;

    .line 600
    .line 601
    invoke-interface {v3, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 602
    .line 603
    .line 604
    move-result-object v11

    .line 605
    check-cast v11, Ljava/lang/CharSequence;

    .line 606
    .line 607
    invoke-virtual {v10, v11}, Lcom/google/android/gms/internal/fido/f8;->V(Ljava/lang/CharSequence;)Ljava/util/List;

    .line 608
    .line 609
    .line 610
    move-result-object v10

    .line 611
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 612
    .line 613
    .line 614
    move-result v11

    .line 615
    if-ne v11, v6, :cond_2a3

    .line 616
    .line 617
    const/4 v11, 0x0

    .line 618
    :try_start_269
    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 619
    .line 620
    .line 621
    move-result-object v18

    .line 622
    check-cast v18, Ljava/lang/String;

    .line 623
    .line 624
    invoke-static/range {v18 .. v18}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 625
    .line 626
    .line 627
    move-result-wide v30

    .line 628
    const/4 v11, 0x1

    .line 629
    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 630
    .line 631
    .line 632
    move-result-object v18

    .line 633
    check-cast v18, Ljava/lang/String;

    .line 634
    .line 635
    invoke-static/range {v18 .. v18}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 636
    .line 637
    .line 638
    move-result-wide v33

    .line 639
    const/4 v11, 0x2

    .line 640
    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 641
    .line 642
    .line 643
    move-result-object v10

    .line 644
    check-cast v10, Ljava/lang/String;

    .line 645
    .line 646
    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 647
    .line 648
    .line 649
    move-result v10

    .line 650
    const/16 v22, 0x1

    .line 651
    .line 652
    add-int/lit8 v10, v10, -0x1

    .line 653
    .line 654
    shl-int v32, v22, v10

    .line 655
    .line 656
    new-instance v29, Ld5/a;

    .line 657
    .line 658
    invoke-direct/range {v29 .. v34}, Ld5/a;-><init>(JIJ)V

    .line 659
    .line 660
    .line 661
    move-object/from16 v10, v29

    .line 662
    .line 663
    invoke-virtual {v7, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_299
    .catch Ljava/lang/NumberFormatException; {:try_start_269 .. :try_end_299} :catch_29c

    .line 664
    .line 665
    .line 666
    add-int/lit8 v9, v9, 0x1

    .line 667
    .line 668
    goto :goto_250

    .line 669
    :catch_29c
    move-exception v0

    .line 670
    const/4 v2, 0x0

    .line 671
    invoke-static {v2, v0}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 672
    .line 673
    .line 674
    move-result-object v0

    .line 675
    throw v0

    .line 676
    :cond_2a3
    const/4 v2, 0x0

    .line 677
    invoke-static {v2, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 678
    .line 679
    .line 680
    move-result-object v0

    .line 681
    throw v0

    .line 682
    :cond_2a9
    new-instance v3, Ld5/b;

    .line 683
    .line 684
    invoke-direct {v3, v7}, Ld5/b;-><init>(Ljava/util/ArrayList;)V

    .line 685
    .line 686
    .line 687
    iget-object v7, v1, Li5/o;->j:Ljava/util/ArrayList;

    .line 688
    .line 689
    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 690
    .line 691
    .line 692
    :cond_2b3
    :goto_2b3
    add-int/lit8 v0, v0, 0x1

    .line 693
    .line 694
    const/4 v7, 0x4

    .line 695
    goto/16 :goto_1b5

    .line 696
    .line 697
    :cond_2b8
    const-wide/16 v9, 0x0

    .line 698
    .line 699
    iput-wide v9, v2, Lo4/r;->b:J

    .line 700
    .line 701
    :goto_2bc
    const/4 v11, 0x1

    .line 702
    goto/16 :goto_37c

    .line 703
    .line 704
    :cond_2bf
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 705
    .line 706
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 707
    .line 708
    .line 709
    throw v0

    .line 710
    :cond_2c5
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 711
    .line 712
    .line 713
    move-result-wide v7

    .line 714
    iget v9, v3, Li5/r;->c:I

    .line 715
    .line 716
    add-int/lit8 v9, v9, -0x14

    .line 717
    .line 718
    new-instance v10, Ln3/x;

    .line 719
    .line 720
    invoke-direct {v10, v9}, Ln3/x;-><init>(I)V

    .line 721
    .line 722
    .line 723
    iget-object v11, v10, Ln3/x;->a:[B

    .line 724
    .line 725
    const/4 v6, 0x0

    .line 726
    invoke-interface {v0, v11, v6, v9}, Lo4/o;->readFully([BII)V

    .line 727
    .line 728
    .line 729
    const/4 v0, 0x0

    .line 730
    :goto_2d9
    div-int/lit8 v6, v9, 0xc

    .line 731
    .line 732
    if-ge v0, v6, :cond_316

    .line 733
    .line 734
    const/4 v11, 0x2

    .line 735
    invoke-virtual {v10, v11}, Ln3/x;->O(I)V

    .line 736
    .line 737
    .line 738
    invoke-virtual {v10}, Ln3/x;->q()S

    .line 739
    .line 740
    .line 741
    move-result v6

    .line 742
    if-eq v6, v4, :cond_2f5

    .line 743
    .line 744
    if-eq v6, v14, :cond_2f5

    .line 745
    .line 746
    if-eq v6, v12, :cond_2f5

    .line 747
    .line 748
    if-eq v6, v15, :cond_2f5

    .line 749
    .line 750
    if-eq v6, v13, :cond_2f5

    .line 751
    .line 752
    const/16 v6, 0x8

    .line 753
    .line 754
    invoke-virtual {v10, v6}, Ln3/x;->O(I)V

    .line 755
    .line 756
    .line 757
    goto :goto_30f

    .line 758
    :cond_2f5
    iget v6, v3, Li5/r;->c:I

    .line 759
    .line 760
    int-to-long v12, v6

    .line 761
    sub-long v12, v7, v12

    .line 762
    .line 763
    invoke-virtual {v10}, Ln3/x;->o()I

    .line 764
    .line 765
    .line 766
    move-result v6

    .line 767
    move-wide/from16 v18, v12

    .line 768
    .line 769
    int-to-long v11, v6

    .line 770
    sub-long v12, v18, v11

    .line 771
    .line 772
    invoke-virtual {v10}, Ln3/x;->o()I

    .line 773
    .line 774
    .line 775
    move-result v6

    .line 776
    new-instance v11, Li5/q;

    .line 777
    .line 778
    invoke-direct {v11, v12, v13, v6}, Li5/q;-><init>(JI)V

    .line 779
    .line 780
    .line 781
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 782
    .line 783
    .line 784
    :goto_30f
    add-int/lit8 v0, v0, 0x1

    .line 785
    .line 786
    const/16 v12, 0xb01

    .line 787
    .line 788
    const/16 v13, 0xb04

    .line 789
    .line 790
    goto :goto_2d9

    .line 791
    :cond_316
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 792
    .line 793
    .line 794
    move-result v0

    .line 795
    if-eqz v0, :cond_322

    .line 796
    .line 797
    const-wide/16 v9, 0x0

    .line 798
    .line 799
    iput-wide v9, v2, Lo4/r;->b:J

    .line 800
    .line 801
    const/4 v6, 0x0

    .line 802
    goto :goto_2bc

    .line 803
    :cond_322
    const/4 v0, 0x3

    .line 804
    iput v0, v3, Li5/r;->b:I

    .line 805
    .line 806
    const/4 v6, 0x0

    .line 807
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 808
    .line 809
    .line 810
    move-result-object v0

    .line 811
    check-cast v0, Li5/q;

    .line 812
    .line 813
    iget-wide v3, v0, Li5/q;->a:J

    .line 814
    .line 815
    iput-wide v3, v2, Lo4/r;->b:J

    .line 816
    .line 817
    goto :goto_2bc

    .line 818
    :cond_331
    const/4 v6, 0x0

    .line 819
    new-instance v4, Ln3/x;

    .line 820
    .line 821
    const/16 v5, 0x8

    .line 822
    .line 823
    invoke-direct {v4, v5}, Ln3/x;-><init>(I)V

    .line 824
    .line 825
    .line 826
    iget-object v7, v4, Ln3/x;->a:[B

    .line 827
    .line 828
    invoke-interface {v0, v7, v6, v5}, Lo4/o;->readFully([BII)V

    .line 829
    .line 830
    .line 831
    invoke-virtual {v4}, Ln3/x;->o()I

    .line 832
    .line 833
    .line 834
    move-result v6

    .line 835
    add-int/2addr v6, v5

    .line 836
    iput v6, v3, Li5/r;->c:I

    .line 837
    .line 838
    invoke-virtual {v4}, Ln3/x;->m()I

    .line 839
    .line 840
    .line 841
    move-result v4

    .line 842
    const v5, 0x53454654

    .line 843
    .line 844
    .line 845
    if-eq v4, v5, :cond_354

    .line 846
    .line 847
    const-wide/16 v9, 0x0

    .line 848
    .line 849
    iput-wide v9, v2, Lo4/r;->b:J

    .line 850
    .line 851
    goto/16 :goto_2bc

    .line 852
    .line 853
    :cond_354
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 854
    .line 855
    .line 856
    move-result-wide v4

    .line 857
    iget v0, v3, Li5/r;->c:I

    .line 858
    .line 859
    add-int/lit8 v0, v0, -0xc

    .line 860
    .line 861
    int-to-long v6, v0

    .line 862
    sub-long/2addr v4, v6

    .line 863
    iput-wide v4, v2, Lo4/r;->b:J

    .line 864
    .line 865
    const/4 v11, 0x2

    .line 866
    iput v11, v3, Li5/r;->b:I

    .line 867
    .line 868
    goto/16 :goto_2bc

    .line 869
    .line 870
    :cond_365
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 871
    .line 872
    .line 873
    move-result-wide v4

    .line 874
    cmp-long v0, v4, v18

    .line 875
    .line 876
    if-eqz v0, :cond_375

    .line 877
    .line 878
    cmp-long v0, v4, v20

    .line 879
    .line 880
    if-gez v0, :cond_372

    .line 881
    .line 882
    goto :goto_375

    .line 883
    :cond_372
    sub-long v4, v4, v20

    .line 884
    .line 885
    goto :goto_377

    .line 886
    :cond_375
    :goto_375
    const-wide/16 v4, 0x0

    .line 887
    .line 888
    :goto_377
    iput-wide v4, v2, Lo4/r;->b:J

    .line 889
    .line 890
    const/4 v11, 0x1

    .line 891
    iput v11, v3, Li5/r;->b:I

    .line 892
    .line 893
    :goto_37c
    iget-wide v2, v2, Lo4/r;->b:J

    .line 894
    .line 895
    const-wide/16 v27, 0x0

    .line 896
    .line 897
    cmp-long v0, v2, v27

    .line 898
    .line 899
    if-nez v0, :cond_6f7

    .line 900
    .line 901
    const/4 v6, 0x0

    .line 902
    iput v6, v1, Li5/o;->n:I

    .line 903
    .line 904
    iput v6, v1, Li5/o;->q:I

    .line 905
    .line 906
    return v11

    .line 907
    :cond_38a
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 908
    .line 909
    .line 910
    move-result-wide v3

    .line 911
    iget v6, v1, Li5/o;->s:I

    .line 912
    .line 913
    const/4 v7, -0x1

    .line 914
    if-ne v6, v7, :cond_45c

    .line 915
    .line 916
    const-wide v6, 0x7fffffffffffffffL

    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    const/4 v8, 0x1

    .line 922
    const/4 v9, 0x1

    .line 923
    const/4 v10, 0x0

    .line 924
    const/4 v11, -0x1

    .line 925
    const/4 v13, -0x1

    .line 926
    const/4 v14, -0x1

    .line 927
    const-wide v18, 0x7fffffffffffffffL

    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    const-wide v29, 0x7fffffffffffffffL

    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    const-wide v31, 0x7fffffffffffffffL

    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    const-wide v33, 0x7fffffffffffffffL

    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    const-wide v35, 0x7fffffffffffffffL

    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    :goto_3b7
    iget-object v15, v1, Li5/o;->G:[Li5/n;

    .line 953
    .line 954
    move-wide/from16 v37, v3

    .line 955
    .line 956
    array-length v3, v15

    .line 957
    if-ge v10, v3, :cond_42c

    .line 958
    .line 959
    aget-object v3, v15, v10

    .line 960
    .line 961
    iget v4, v3, Li5/n;->g:I

    .line 962
    .line 963
    iget-object v15, v3, Li5/n;->b:Li5/w;

    .line 964
    .line 965
    move/from16 v26, v8

    .line 966
    .line 967
    iget v8, v15, Li5/w;->b:I

    .line 968
    .line 969
    if-ne v4, v8, :cond_3ce

    .line 970
    .line 971
    move/from16 v8, v26

    .line 972
    .line 973
    goto/16 :goto_427

    .line 974
    .line 975
    :cond_3ce
    iget-object v8, v15, Li5/w;->f:[J

    .line 976
    .line 977
    move/from16 v39, v13

    .line 978
    .line 979
    move/from16 v40, v14

    .line 980
    .line 981
    aget-wide v13, v8, v4

    .line 982
    .line 983
    iget-boolean v8, v3, Li5/n;->e:Z

    .line 984
    .line 985
    if-eqz v8, :cond_3df

    .line 986
    .line 987
    invoke-static {v6, v7, v13, v14}, Ljava/lang/Math;->min(JJ)J

    .line 988
    .line 989
    .line 990
    move-result-wide v6

    .line 991
    goto :goto_3ea

    .line 992
    :cond_3df
    iget-boolean v3, v3, Li5/n;->f:Z

    .line 993
    .line 994
    if-eqz v3, :cond_3ea

    .line 995
    .line 996
    cmp-long v3, v13, v29

    .line 997
    .line 998
    if-gez v3, :cond_3ea

    .line 999
    .line 1000
    move v11, v10

    .line 1001
    move-wide/from16 v29, v13

    .line 1002
    .line 1003
    :cond_3ea
    :goto_3ea
    iget-object v3, v15, Li5/w;->c:[J

    .line 1004
    .line 1005
    aget-wide v13, v3, v4

    .line 1006
    .line 1007
    iget-object v3, v1, Li5/o;->H:[[J

    .line 1008
    .line 1009
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1010
    .line 1011
    .line 1012
    aget-object v3, v3, v10

    .line 1013
    .line 1014
    aget-wide v41, v3, v4

    .line 1015
    .line 1016
    sub-long v13, v13, v37

    .line 1017
    .line 1018
    const-wide/16 v27, 0x0

    .line 1019
    .line 1020
    cmp-long v3, v13, v27

    .line 1021
    .line 1022
    if-ltz v3, :cond_406

    .line 1023
    .line 1024
    cmp-long v3, v13, v16

    .line 1025
    .line 1026
    if-ltz v3, :cond_404

    .line 1027
    .line 1028
    goto :goto_406

    .line 1029
    :cond_404
    const/4 v3, 0x0

    .line 1030
    goto :goto_407

    .line 1031
    :cond_406
    :goto_406
    const/4 v3, 0x1

    .line 1032
    :goto_407
    if-nez v3, :cond_40b

    .line 1033
    .line 1034
    if-nez v9, :cond_411

    .line 1035
    .line 1036
    :cond_40b
    if-ne v3, v9, :cond_418

    .line 1037
    .line 1038
    cmp-long v4, v13, v35

    .line 1039
    .line 1040
    if-gez v4, :cond_418

    .line 1041
    .line 1042
    :cond_411
    move v9, v3

    .line 1043
    move-wide/from16 v35, v13

    .line 1044
    .line 1045
    move-wide/from16 v31, v41

    .line 1046
    .line 1047
    move v14, v10

    .line 1048
    goto :goto_41a

    .line 1049
    :cond_418
    move/from16 v14, v40

    .line 1050
    .line 1051
    :goto_41a
    cmp-long v4, v41, v33

    .line 1052
    .line 1053
    if-gez v4, :cond_423

    .line 1054
    .line 1055
    move v8, v3

    .line 1056
    move v13, v10

    .line 1057
    move-wide/from16 v33, v41

    .line 1058
    .line 1059
    goto :goto_427

    .line 1060
    :cond_423
    move/from16 v8, v26

    .line 1061
    .line 1062
    move/from16 v13, v39

    .line 1063
    .line 1064
    :goto_427
    add-int/lit8 v10, v10, 0x1

    .line 1065
    .line 1066
    move-wide/from16 v3, v37

    .line 1067
    .line 1068
    goto :goto_3b7

    .line 1069
    :cond_42c
    move/from16 v26, v8

    .line 1070
    .line 1071
    move/from16 v39, v13

    .line 1072
    .line 1073
    move/from16 v40, v14

    .line 1074
    .line 1075
    cmp-long v3, v6, v18

    .line 1076
    .line 1077
    if-eqz v3, :cond_43e

    .line 1078
    .line 1079
    const/4 v3, -0x1

    .line 1080
    if-eq v11, v3, :cond_43e

    .line 1081
    .line 1082
    cmp-long v3, v29, v6

    .line 1083
    .line 1084
    if-gtz v3, :cond_43e

    .line 1085
    .line 1086
    goto :goto_453

    .line 1087
    :cond_43e
    cmp-long v3, v33, v18

    .line 1088
    .line 1089
    if-eqz v3, :cond_451

    .line 1090
    .line 1091
    if-eqz v26, :cond_451

    .line 1092
    .line 1093
    const-wide/32 v3, 0xa00000

    .line 1094
    .line 1095
    .line 1096
    add-long v33, v33, v3

    .line 1097
    .line 1098
    cmp-long v3, v31, v33

    .line 1099
    .line 1100
    if-gez v3, :cond_44e

    .line 1101
    .line 1102
    goto :goto_451

    .line 1103
    :cond_44e
    move/from16 v11, v39

    .line 1104
    .line 1105
    goto :goto_453

    .line 1106
    :cond_451
    :goto_451
    move/from16 v11, v40

    .line 1107
    .line 1108
    :goto_453
    iput v11, v1, Li5/o;->s:I

    .line 1109
    .line 1110
    const/4 v3, -0x1

    .line 1111
    if-ne v11, v3, :cond_45e

    .line 1112
    .line 1113
    move/from16 v25, v3

    .line 1114
    .line 1115
    goto/16 :goto_892

    .line 1116
    .line 1117
    :cond_45c
    move-wide/from16 v37, v3

    .line 1118
    .line 1119
    :cond_45e
    iget-object v3, v1, Li5/o;->G:[Li5/n;

    .line 1120
    .line 1121
    iget v4, v1, Li5/o;->s:I

    .line 1122
    .line 1123
    aget-object v3, v3, v4

    .line 1124
    .line 1125
    iget-object v4, v3, Li5/n;->c:Lo4/i0;

    .line 1126
    .line 1127
    iget-object v6, v3, Li5/n;->b:Li5/w;

    .line 1128
    .line 1129
    iget-object v7, v3, Li5/n;->a:Li5/u;

    .line 1130
    .line 1131
    iget v8, v3, Li5/n;->g:I

    .line 1132
    .line 1133
    iget-object v9, v6, Li5/w;->c:[J

    .line 1134
    .line 1135
    iget-object v10, v6, Li5/w;->d:[I

    .line 1136
    .line 1137
    aget-wide v13, v9, v8

    .line 1138
    .line 1139
    move v11, v8

    .line 1140
    iget-wide v8, v1, Li5/o;->E:J

    .line 1141
    .line 1142
    add-long/2addr v13, v8

    .line 1143
    aget v8, v10, v11

    .line 1144
    .line 1145
    iget-object v9, v3, Li5/n;->d:Lo4/j0;

    .line 1146
    .line 1147
    sub-long v18, v13, v37

    .line 1148
    .line 1149
    iget v15, v1, Li5/o;->t:I

    .line 1150
    .line 1151
    move-object/from16 v26, v10

    .line 1152
    .line 1153
    move/from16 v37, v11

    .line 1154
    .line 1155
    int-to-long v10, v15

    .line 1156
    add-long v18, v18, v10

    .line 1157
    .line 1158
    const-wide/16 v27, 0x0

    .line 1159
    .line 1160
    cmp-long v10, v18, v27

    .line 1161
    .line 1162
    if-ltz v10, :cond_48f

    .line 1163
    .line 1164
    cmp-long v10, v18, v16

    .line 1165
    .line 1166
    if-ltz v10, :cond_493

    .line 1167
    .line 1168
    :cond_48f
    const/16 v22, 0x1

    .line 1169
    .line 1170
    goto/16 :goto_650

    .line 1171
    .line 1172
    :cond_493
    iget v2, v7, Li5/u;->h:I

    .line 1173
    .line 1174
    iget v10, v7, Li5/u;->k:I

    .line 1175
    .line 1176
    iget-object v7, v7, Li5/u;->g:Lk3/w;

    .line 1177
    .line 1178
    const/4 v11, 0x1

    .line 1179
    if-ne v2, v11, :cond_4a0

    .line 1180
    .line 1181
    add-long v18, v18, v20

    .line 1182
    .line 1183
    add-int/lit8 v8, v8, -0x8

    .line 1184
    .line 1185
    :cond_4a0
    move-wide/from16 v13, v18

    .line 1186
    .line 1187
    long-to-int v2, v13

    .line 1188
    invoke-interface {v0, v2}, Lo4/o;->n(I)V

    .line 1189
    .line 1190
    .line 1191
    iget-object v2, v7, Lk3/w;->p:Ljava/lang/String;

    .line 1192
    .line 1193
    iget-object v11, v7, Lk3/w;->p:Ljava/lang/String;

    .line 1194
    .line 1195
    const-string v13, "video/avc"

    .line 1196
    .line 1197
    invoke-static {v2, v13}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1198
    .line 1199
    .line 1200
    move-result v13

    .line 1201
    iget v14, v1, Li5/o;->b:I

    .line 1202
    .line 1203
    if-eqz v13, :cond_4bc

    .line 1204
    .line 1205
    and-int/lit8 v2, v14, 0x20

    .line 1206
    .line 1207
    if-eqz v2, :cond_4ba

    .line 1208
    .line 1209
    :goto_4b8
    const/4 v2, 0x1

    .line 1210
    goto :goto_4cf

    .line 1211
    :cond_4ba
    const/4 v2, 0x0

    .line 1212
    goto :goto_4cf

    .line 1213
    :cond_4bc
    const-string v13, "video/hevc"

    .line 1214
    .line 1215
    invoke-static {v2, v13}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1216
    .line 1217
    .line 1218
    move-result v13

    .line 1219
    if-eqz v13, :cond_4c9

    .line 1220
    .line 1221
    and-int/lit16 v2, v14, 0x80

    .line 1222
    .line 1223
    if-eqz v2, :cond_4ba

    .line 1224
    .line 1225
    goto :goto_4b8

    .line 1226
    :cond_4c9
    const-string v13, "video/apv"

    .line 1227
    .line 1228
    invoke-static {v2, v13}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1229
    .line 1230
    .line 1231
    move-result v2

    .line 1232
    :goto_4cf
    if-nez v2, :cond_4d5

    .line 1233
    .line 1234
    const/4 v2, 0x1

    .line 1235
    iput-boolean v2, v1, Li5/o;->w:Z

    .line 1236
    .line 1237
    goto :goto_4d6

    .line 1238
    :cond_4d5
    const/4 v2, 0x1

    .line 1239
    :goto_4d6
    if-eqz v10, :cond_562

    .line 1240
    .line 1241
    iget-object v5, v1, Li5/o;->e:Ln3/x;

    .line 1242
    .line 1243
    iget-object v11, v5, Ln3/x;->a:[B

    .line 1244
    .line 1245
    const/16 v24, 0x0

    .line 1246
    .line 1247
    aput-byte v24, v11, v24

    .line 1248
    .line 1249
    aput-byte v24, v11, v2

    .line 1250
    .line 1251
    const/16 v23, 0x2

    .line 1252
    .line 1253
    aput-byte v24, v11, v23

    .line 1254
    .line 1255
    rsub-int/lit8 v2, v10, 0x4

    .line 1256
    .line 1257
    add-int/2addr v8, v2

    .line 1258
    :cond_4e9
    :goto_4e9
    iget v12, v1, Li5/o;->u:I

    .line 1259
    .line 1260
    if-ge v12, v8, :cond_55e

    .line 1261
    .line 1262
    iget v12, v1, Li5/o;->v:I

    .line 1263
    .line 1264
    if-nez v12, :cond_549

    .line 1265
    .line 1266
    iget-boolean v12, v1, Li5/o;->w:Z

    .line 1267
    .line 1268
    if-nez v12, :cond_508

    .line 1269
    .line 1270
    invoke-static {v7}, Lo3/n;->i(Lk3/w;)I

    .line 1271
    .line 1272
    .line 1273
    move-result v12

    .line 1274
    add-int/2addr v12, v10

    .line 1275
    aget v13, v26, v37

    .line 1276
    .line 1277
    iget v14, v1, Li5/o;->t:I

    .line 1278
    .line 1279
    sub-int/2addr v13, v14

    .line 1280
    if-gt v12, v13, :cond_508

    .line 1281
    .line 1282
    invoke-static {v7}, Lo3/n;->i(Lk3/w;)I

    .line 1283
    .line 1284
    .line 1285
    move-result v12

    .line 1286
    add-int v13, v10, v12

    .line 1287
    .line 1288
    goto :goto_50a

    .line 1289
    :cond_508
    move v13, v10

    .line 1290
    const/4 v12, 0x0

    .line 1291
    :goto_50a
    invoke-interface {v0, v11, v2, v13}, Lo4/o;->readFully([BII)V

    .line 1292
    .line 1293
    .line 1294
    iget v14, v1, Li5/o;->t:I

    .line 1295
    .line 1296
    add-int/2addr v14, v13

    .line 1297
    iput v14, v1, Li5/o;->t:I

    .line 1298
    .line 1299
    const/4 v13, 0x0

    .line 1300
    invoke-virtual {v5, v13}, Ln3/x;->N(I)V

    .line 1301
    .line 1302
    .line 1303
    invoke-virtual {v5}, Ln3/x;->m()I

    .line 1304
    .line 1305
    .line 1306
    move-result v14

    .line 1307
    if-ltz v14, :cond_541

    .line 1308
    .line 1309
    sub-int/2addr v14, v12

    .line 1310
    iput v14, v1, Li5/o;->v:I

    .line 1311
    .line 1312
    iget-object v14, v1, Li5/o;->d:Ln3/x;

    .line 1313
    .line 1314
    invoke-virtual {v14, v13}, Ln3/x;->N(I)V

    .line 1315
    .line 1316
    .line 1317
    const/4 v13, 0x4

    .line 1318
    invoke-interface {v4, v13, v14}, Lo4/i0;->g(ILn3/x;)V

    .line 1319
    .line 1320
    .line 1321
    iget v14, v1, Li5/o;->u:I

    .line 1322
    .line 1323
    add-int/2addr v14, v13

    .line 1324
    iput v14, v1, Li5/o;->u:I

    .line 1325
    .line 1326
    if-lez v12, :cond_4e9

    .line 1327
    .line 1328
    invoke-interface {v4, v12, v5}, Lo4/i0;->g(ILn3/x;)V

    .line 1329
    .line 1330
    .line 1331
    iget v13, v1, Li5/o;->u:I

    .line 1332
    .line 1333
    add-int/2addr v13, v12

    .line 1334
    iput v13, v1, Li5/o;->u:I

    .line 1335
    .line 1336
    invoke-static {v11, v12, v7}, Lo3/n;->g([BILk3/w;)Z

    .line 1337
    .line 1338
    .line 1339
    move-result v12

    .line 1340
    if-eqz v12, :cond_4e9

    .line 1341
    .line 1342
    const/4 v12, 0x1

    .line 1343
    iput-boolean v12, v1, Li5/o;->w:Z

    .line 1344
    .line 1345
    goto :goto_4e9

    .line 1346
    :cond_541
    const-string v0, "Invalid NAL length"

    .line 1347
    .line 1348
    const/4 v2, 0x0

    .line 1349
    invoke-static {v0, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1350
    .line 1351
    .line 1352
    move-result-object v0

    .line 1353
    throw v0

    .line 1354
    :cond_549
    const/4 v13, 0x0

    .line 1355
    invoke-interface {v4, v0, v12, v13}, Lo4/i0;->e(Lk3/n;IZ)I

    .line 1356
    .line 1357
    .line 1358
    move-result v12

    .line 1359
    iget v13, v1, Li5/o;->t:I

    .line 1360
    .line 1361
    add-int/2addr v13, v12

    .line 1362
    iput v13, v1, Li5/o;->t:I

    .line 1363
    .line 1364
    iget v13, v1, Li5/o;->u:I

    .line 1365
    .line 1366
    add-int/2addr v13, v12

    .line 1367
    iput v13, v1, Li5/o;->u:I

    .line 1368
    .line 1369
    iget v13, v1, Li5/o;->v:I

    .line 1370
    .line 1371
    sub-int/2addr v13, v12

    .line 1372
    iput v13, v1, Li5/o;->v:I

    .line 1373
    .line 1374
    goto :goto_4e9

    .line 1375
    :cond_55e
    move/from16 v33, v8

    .line 1376
    .line 1377
    goto/16 :goto_5fc

    .line 1378
    .line 1379
    :cond_562
    iget-object v2, v3, Li5/n;->h:Lk3/w;

    .line 1380
    .line 1381
    const-string v7, "audio/ac4"

    .line 1382
    .line 1383
    invoke-virtual {v7, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1384
    .line 1385
    .line 1386
    move-result v7

    .line 1387
    if-eqz v7, :cond_57f

    .line 1388
    .line 1389
    iget v2, v1, Li5/o;->u:I

    .line 1390
    .line 1391
    if-nez v2, :cond_57c

    .line 1392
    .line 1393
    invoke-static {v8, v12}, Lo4/a;->f(ILn3/x;)V

    .line 1394
    .line 1395
    .line 1396
    const/4 v2, 0x7

    .line 1397
    invoke-interface {v4, v2, v12}, Lo4/i0;->g(ILn3/x;)V

    .line 1398
    .line 1399
    .line 1400
    iget v5, v1, Li5/o;->u:I

    .line 1401
    .line 1402
    add-int/2addr v5, v2

    .line 1403
    iput v5, v1, Li5/o;->u:I

    .line 1404
    .line 1405
    :cond_57c
    add-int/lit8 v8, v8, 0x7

    .line 1406
    .line 1407
    goto :goto_5e1

    .line 1408
    :cond_57f
    if-eqz v2, :cond_5c9

    .line 1409
    .line 1410
    invoke-static {v11, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1411
    .line 1412
    .line 1413
    move-result v5

    .line 1414
    if-eqz v5, :cond_5c9

    .line 1415
    .line 1416
    const/4 v13, 0x4

    .line 1417
    invoke-virtual {v12, v13}, Ln3/x;->K(I)V

    .line 1418
    .line 1419
    .line 1420
    iget-object v5, v12, Ln3/x;->a:[B

    .line 1421
    .line 1422
    const/4 v10, 0x0

    .line 1423
    invoke-interface {v0, v5, v10, v13}, Lo4/o;->q([BII)V

    .line 1424
    .line 1425
    .line 1426
    invoke-interface {v0}, Lo4/o;->m()V

    .line 1427
    .line 1428
    .line 1429
    new-instance v5, Lo4/z;

    .line 1430
    .line 1431
    invoke-direct {v5, v10}, Lo4/z;-><init>(I)V

    .line 1432
    .line 1433
    .line 1434
    invoke-virtual {v12}, Ln3/x;->m()I

    .line 1435
    .line 1436
    .line 1437
    move-result v7

    .line 1438
    invoke-virtual {v5, v7}, Lo4/z;->a(I)Z

    .line 1439
    .line 1440
    .line 1441
    move-result v7

    .line 1442
    if-eqz v7, :cond_5c2

    .line 1443
    .line 1444
    iget-object v7, v2, Lk3/w;->p:Ljava/lang/String;

    .line 1445
    .line 1446
    iget-object v10, v5, Lo4/z;->c:Ljava/lang/String;

    .line 1447
    .line 1448
    invoke-static {v7, v10}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1449
    .line 1450
    .line 1451
    move-result v7

    .line 1452
    if-nez v7, :cond_5c2

    .line 1453
    .line 1454
    invoke-virtual {v2}, Lk3/w;->a()Lk3/v;

    .line 1455
    .line 1456
    .line 1457
    move-result-object v2

    .line 1458
    iget-object v5, v5, Lo4/z;->c:Ljava/lang/String;

    .line 1459
    .line 1460
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1461
    .line 1462
    .line 1463
    invoke-static {v5}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 1464
    .line 1465
    .line 1466
    move-result-object v5

    .line 1467
    iput-object v5, v2, Lk3/v;->o:Ljava/lang/String;

    .line 1468
    .line 1469
    new-instance v5, Lk3/w;

    .line 1470
    .line 1471
    invoke-direct {v5, v2}, Lk3/w;-><init>(Lk3/v;)V

    .line 1472
    .line 1473
    .line 1474
    move-object v2, v5

    .line 1475
    :cond_5c2
    invoke-interface {v4, v2}, Lo4/i0;->d(Lk3/w;)V

    .line 1476
    .line 1477
    .line 1478
    const/4 v5, 0x0

    .line 1479
    iput-object v5, v3, Li5/n;->h:Lk3/w;

    .line 1480
    .line 1481
    goto :goto_5e1

    .line 1482
    :cond_5c9
    const/4 v5, 0x0

    .line 1483
    if-eqz v2, :cond_5dc

    .line 1484
    .line 1485
    invoke-static {v11}, Lo4/a;->n(Ljava/lang/String;)Z

    .line 1486
    .line 1487
    .line 1488
    move-result v7

    .line 1489
    if-eqz v7, :cond_5dc

    .line 1490
    .line 1491
    invoke-static {v0, v8, v2}, Lo4/a;->y(Lo4/o;ILk3/w;)Lk3/w;

    .line 1492
    .line 1493
    .line 1494
    move-result-object v2

    .line 1495
    invoke-interface {v4, v2}, Lo4/i0;->d(Lk3/w;)V

    .line 1496
    .line 1497
    .line 1498
    iput-object v5, v3, Li5/n;->h:Lk3/w;

    .line 1499
    .line 1500
    goto :goto_5e1

    .line 1501
    :cond_5dc
    if-eqz v9, :cond_5e1

    .line 1502
    .line 1503
    invoke-virtual {v9, v0}, Lo4/j0;->e(Lo4/o;)V

    .line 1504
    .line 1505
    .line 1506
    :cond_5e1
    :goto_5e1
    iget v2, v1, Li5/o;->u:I

    .line 1507
    .line 1508
    if-ge v2, v8, :cond_55e

    .line 1509
    .line 1510
    sub-int v2, v8, v2

    .line 1511
    .line 1512
    const/4 v13, 0x0

    .line 1513
    invoke-interface {v4, v0, v2, v13}, Lo4/i0;->e(Lk3/n;IZ)I

    .line 1514
    .line 1515
    .line 1516
    move-result v2

    .line 1517
    iget v5, v1, Li5/o;->t:I

    .line 1518
    .line 1519
    add-int/2addr v5, v2

    .line 1520
    iput v5, v1, Li5/o;->t:I

    .line 1521
    .line 1522
    iget v5, v1, Li5/o;->u:I

    .line 1523
    .line 1524
    add-int/2addr v5, v2

    .line 1525
    iput v5, v1, Li5/o;->u:I

    .line 1526
    .line 1527
    iget v5, v1, Li5/o;->v:I

    .line 1528
    .line 1529
    sub-int/2addr v5, v2

    .line 1530
    iput v5, v1, Li5/o;->v:I

    .line 1531
    .line 1532
    goto :goto_5e1

    .line 1533
    :goto_5fc
    iget-object v0, v6, Li5/w;->f:[J

    .line 1534
    .line 1535
    aget-wide v30, v0, v37

    .line 1536
    .line 1537
    iget-object v0, v6, Li5/w;->g:[I

    .line 1538
    .line 1539
    aget v0, v0, v37

    .line 1540
    .line 1541
    iget-boolean v2, v1, Li5/o;->w:Z

    .line 1542
    .line 1543
    if-nez v2, :cond_60b

    .line 1544
    .line 1545
    const/high16 v2, 0x4000000

    .line 1546
    .line 1547
    or-int/2addr v0, v2

    .line 1548
    :cond_60b
    move/from16 v32, v0

    .line 1549
    .line 1550
    if-eqz v9, :cond_631

    .line 1551
    .line 1552
    const/16 v35, 0x0

    .line 1553
    .line 1554
    const/16 v36, 0x0

    .line 1555
    .line 1556
    move-object/from16 v29, v9

    .line 1557
    .line 1558
    move/from16 v34, v33

    .line 1559
    .line 1560
    move/from16 v33, v32

    .line 1561
    .line 1562
    move-wide/from16 v31, v30

    .line 1563
    .line 1564
    move-object/from16 v30, v4

    .line 1565
    .line 1566
    invoke-virtual/range {v29 .. v36}, Lo4/j0;->c(Lo4/i0;JIIILo4/h0;)V

    .line 1567
    .line 1568
    .line 1569
    move-object/from16 v2, v29

    .line 1570
    .line 1571
    move-object/from16 v0, v30

    .line 1572
    .line 1573
    const/16 v22, 0x1

    .line 1574
    .line 1575
    add-int/lit8 v8, v37, 0x1

    .line 1576
    .line 1577
    iget v4, v6, Li5/w;->b:I

    .line 1578
    .line 1579
    if-ne v8, v4, :cond_63d

    .line 1580
    .line 1581
    const/4 v5, 0x0

    .line 1582
    invoke-virtual {v2, v0, v5}, Lo4/j0;->a(Lo4/i0;Lo4/h0;)V

    .line 1583
    .line 1584
    .line 1585
    goto :goto_63d

    .line 1586
    :cond_631
    move-object v0, v4

    .line 1587
    const/16 v22, 0x1

    .line 1588
    .line 1589
    const/16 v34, 0x0

    .line 1590
    .line 1591
    const/16 v35, 0x0

    .line 1592
    .line 1593
    move-object/from16 v29, v0

    .line 1594
    .line 1595
    invoke-interface/range {v29 .. v35}, Lo4/i0;->f(JIIILo4/h0;)V

    .line 1596
    .line 1597
    .line 1598
    :cond_63d
    :goto_63d
    iget v0, v3, Li5/n;->g:I

    .line 1599
    .line 1600
    add-int/lit8 v0, v0, 0x1

    .line 1601
    .line 1602
    iput v0, v3, Li5/n;->g:I

    .line 1603
    .line 1604
    const/4 v3, -0x1

    .line 1605
    iput v3, v1, Li5/o;->s:I

    .line 1606
    .line 1607
    const/4 v13, 0x0

    .line 1608
    iput v13, v1, Li5/o;->t:I

    .line 1609
    .line 1610
    iput v13, v1, Li5/o;->u:I

    .line 1611
    .line 1612
    iput v13, v1, Li5/o;->v:I

    .line 1613
    .line 1614
    iput-boolean v13, v1, Li5/o;->w:Z

    .line 1615
    .line 1616
    return v13

    .line 1617
    :goto_650
    iput-wide v13, v2, Lo4/r;->b:J

    .line 1618
    .line 1619
    return v22

    .line 1620
    :cond_653
    iget-wide v3, v1, Li5/o;->p:J

    .line 1621
    .line 1622
    iget v7, v1, Li5/o;->q:I

    .line 1623
    .line 1624
    int-to-long v7, v7

    .line 1625
    sub-long/2addr v3, v7

    .line 1626
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1627
    .line 1628
    .line 1629
    move-result-wide v7

    .line 1630
    add-long/2addr v7, v3

    .line 1631
    iget-object v9, v1, Li5/o;->r:Ln3/x;

    .line 1632
    .line 1633
    if-eqz v9, :cond_6b8

    .line 1634
    .line 1635
    iget-object v10, v9, Ln3/x;->a:[B

    .line 1636
    .line 1637
    iget v11, v1, Li5/o;->q:I

    .line 1638
    .line 1639
    long-to-int v3, v3

    .line 1640
    invoke-interface {v0, v10, v11, v3}, Lo4/o;->readFully([BII)V

    .line 1641
    .line 1642
    .line 1643
    iget v3, v1, Li5/o;->o:I

    .line 1644
    .line 1645
    if-ne v3, v5, :cond_69f

    .line 1646
    .line 1647
    const/4 v11, 0x1

    .line 1648
    iput-boolean v11, v1, Li5/o;->x:Z

    .line 1649
    .line 1650
    const/16 v5, 0x8

    .line 1651
    .line 1652
    invoke-virtual {v9, v5}, Ln3/x;->N(I)V

    .line 1653
    .line 1654
    .line 1655
    invoke-virtual {v9}, Ln3/x;->m()I

    .line 1656
    .line 1657
    .line 1658
    move-result v3

    .line 1659
    const v4, 0x71742020

    .line 1660
    .line 1661
    .line 1662
    if-eq v3, v4, :cond_681

    .line 1663
    .line 1664
    const/4 v3, 0x0

    .line 1665
    goto :goto_682

    .line 1666
    :cond_681
    const/4 v3, 0x1

    .line 1667
    :goto_682
    if-eqz v3, :cond_685

    .line 1668
    .line 1669
    goto :goto_69c

    .line 1670
    :cond_685
    const/4 v13, 0x4

    .line 1671
    invoke-virtual {v9, v13}, Ln3/x;->O(I)V

    .line 1672
    .line 1673
    .line 1674
    :cond_689
    invoke-virtual {v9}, Ln3/x;->a()I

    .line 1675
    .line 1676
    .line 1677
    move-result v3

    .line 1678
    if-lez v3, :cond_69b

    .line 1679
    .line 1680
    invoke-virtual {v9}, Ln3/x;->m()I

    .line 1681
    .line 1682
    .line 1683
    move-result v3

    .line 1684
    if-eq v3, v4, :cond_697

    .line 1685
    .line 1686
    const/4 v3, 0x0

    .line 1687
    goto :goto_698

    .line 1688
    :cond_697
    const/4 v3, 0x1

    .line 1689
    :goto_698
    if-eqz v3, :cond_689

    .line 1690
    .line 1691
    goto :goto_69c

    .line 1692
    :cond_69b
    const/4 v3, 0x0

    .line 1693
    :goto_69c
    iput v3, v1, Li5/o;->I:I

    .line 1694
    .line 1695
    goto :goto_6ce

    .line 1696
    :cond_69f
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 1697
    .line 1698
    .line 1699
    move-result v3

    .line 1700
    if-nez v3, :cond_6ce

    .line 1701
    .line 1702
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 1703
    .line 1704
    .line 1705
    move-result-object v3

    .line 1706
    check-cast v3, Lo3/c;

    .line 1707
    .line 1708
    new-instance v4, Lo3/d;

    .line 1709
    .line 1710
    iget v5, v1, Li5/o;->o:I

    .line 1711
    .line 1712
    invoke-direct {v4, v5, v9}, Lo3/d;-><init>(ILn3/x;)V

    .line 1713
    .line 1714
    .line 1715
    iget-object v3, v3, Lo3/c;->v:Ljava/util/ArrayList;

    .line 1716
    .line 1717
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1718
    .line 1719
    .line 1720
    goto :goto_6ce

    .line 1721
    :cond_6b8
    iget-boolean v5, v1, Li5/o;->x:Z

    .line 1722
    .line 1723
    if-nez v5, :cond_6c6

    .line 1724
    .line 1725
    iget v5, v1, Li5/o;->o:I

    .line 1726
    .line 1727
    const v6, 0x6d646174

    .line 1728
    .line 1729
    .line 1730
    if-ne v5, v6, :cond_6c6

    .line 1731
    .line 1732
    const/4 v11, 0x1

    .line 1733
    iput v11, v1, Li5/o;->I:I

    .line 1734
    .line 1735
    :cond_6c6
    cmp-long v5, v3, v16

    .line 1736
    .line 1737
    if-gez v5, :cond_6d0

    .line 1738
    .line 1739
    long-to-int v3, v3

    .line 1740
    invoke-interface {v0, v3}, Lo4/o;->n(I)V

    .line 1741
    .line 1742
    .line 1743
    :cond_6ce
    :goto_6ce
    const/4 v3, 0x0

    .line 1744
    goto :goto_6d8

    .line 1745
    :cond_6d0
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1746
    .line 1747
    .line 1748
    move-result-wide v5

    .line 1749
    add-long/2addr v5, v3

    .line 1750
    iput-wide v5, v2, Lo4/r;->b:J

    .line 1751
    .line 1752
    const/4 v3, 0x1

    .line 1753
    :goto_6d8
    invoke-virtual {v1, v7, v8}, Li5/o;->a(J)V

    .line 1754
    .line 1755
    .line 1756
    iget-boolean v4, v1, Li5/o;->y:Z

    .line 1757
    .line 1758
    if-eqz v4, :cond_6ea

    .line 1759
    .line 1760
    const/4 v11, 0x1

    .line 1761
    iput-boolean v11, v1, Li5/o;->A:Z

    .line 1762
    .line 1763
    iget-wide v3, v1, Li5/o;->z:J

    .line 1764
    .line 1765
    iput-wide v3, v2, Lo4/r;->b:J

    .line 1766
    .line 1767
    const/4 v13, 0x0

    .line 1768
    iput-boolean v13, v1, Li5/o;->y:Z

    .line 1769
    .line 1770
    const/4 v3, 0x1

    .line 1771
    :cond_6ea
    if-eqz v3, :cond_6f3

    .line 1772
    .line 1773
    iget v3, v1, Li5/o;->n:I

    .line 1774
    .line 1775
    const/4 v11, 0x2

    .line 1776
    if-eq v3, v11, :cond_6f3

    .line 1777
    .line 1778
    const/4 v14, 0x1

    .line 1779
    goto :goto_6f4

    .line 1780
    :cond_6f3
    const/4 v14, 0x0

    .line 1781
    :goto_6f4
    if-eqz v14, :cond_12

    .line 1782
    .line 1783
    const/4 v11, 0x1

    .line 1784
    :cond_6f7
    return v11

    .line 1785
    :cond_6f8
    move v11, v15

    .line 1786
    const-wide/16 v18, -0x1

    .line 1787
    .line 1788
    iget v3, v1, Li5/o;->q:I

    .line 1789
    .line 1790
    iget-object v4, v1, Li5/o;->g:Ln3/x;

    .line 1791
    .line 1792
    if-nez v3, :cond_720

    .line 1793
    .line 1794
    iget-object v3, v4, Ln3/x;->a:[B

    .line 1795
    .line 1796
    const/16 v7, 0x8

    .line 1797
    .line 1798
    const/4 v13, 0x0

    .line 1799
    invoke-interface {v0, v3, v13, v7, v11}, Lo4/o;->b([BIIZ)Z

    .line 1800
    .line 1801
    .line 1802
    move-result v3

    .line 1803
    if-nez v3, :cond_70f

    .line 1804
    .line 1805
    move v14, v13

    .line 1806
    goto/16 :goto_88e

    .line 1807
    .line 1808
    :cond_70f
    iput v7, v1, Li5/o;->q:I

    .line 1809
    .line 1810
    invoke-virtual {v4, v13}, Ln3/x;->N(I)V

    .line 1811
    .line 1812
    .line 1813
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1814
    .line 1815
    .line 1816
    move-result-wide v7

    .line 1817
    iput-wide v7, v1, Li5/o;->p:J

    .line 1818
    .line 1819
    invoke-virtual {v4}, Ln3/x;->m()I

    .line 1820
    .line 1821
    .line 1822
    move-result v3

    .line 1823
    iput v3, v1, Li5/o;->o:I

    .line 1824
    .line 1825
    :cond_720
    iget-wide v7, v1, Li5/o;->p:J

    .line 1826
    .line 1827
    const-wide/16 v9, 0x1

    .line 1828
    .line 1829
    cmp-long v3, v7, v9

    .line 1830
    .line 1831
    if-nez v3, :cond_73b

    .line 1832
    .line 1833
    iget-object v3, v4, Ln3/x;->a:[B

    .line 1834
    .line 1835
    const/16 v7, 0x8

    .line 1836
    .line 1837
    invoke-interface {v0, v3, v7, v7}, Lo4/o;->readFully([BII)V

    .line 1838
    .line 1839
    .line 1840
    iget v3, v1, Li5/o;->q:I

    .line 1841
    .line 1842
    add-int/2addr v3, v7

    .line 1843
    iput v3, v1, Li5/o;->q:I

    .line 1844
    .line 1845
    invoke-virtual {v4}, Ln3/x;->G()J

    .line 1846
    .line 1847
    .line 1848
    move-result-wide v7

    .line 1849
    iput-wide v7, v1, Li5/o;->p:J

    .line 1850
    .line 1851
    goto :goto_762

    .line 1852
    :cond_73b
    const-wide/16 v27, 0x0

    .line 1853
    .line 1854
    cmp-long v3, v7, v27

    .line 1855
    .line 1856
    if-nez v3, :cond_762

    .line 1857
    .line 1858
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 1859
    .line 1860
    .line 1861
    move-result-wide v7

    .line 1862
    cmp-long v3, v7, v18

    .line 1863
    .line 1864
    if-nez v3, :cond_753

    .line 1865
    .line 1866
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 1867
    .line 1868
    .line 1869
    move-result-object v3

    .line 1870
    check-cast v3, Lo3/c;

    .line 1871
    .line 1872
    if-eqz v3, :cond_753

    .line 1873
    .line 1874
    iget-wide v7, v3, Lo3/c;->i:J

    .line 1875
    .line 1876
    :cond_753
    cmp-long v3, v7, v18

    .line 1877
    .line 1878
    if-eqz v3, :cond_762

    .line 1879
    .line 1880
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1881
    .line 1882
    .line 1883
    move-result-wide v9

    .line 1884
    sub-long/2addr v7, v9

    .line 1885
    iget v3, v1, Li5/o;->q:I

    .line 1886
    .line 1887
    int-to-long v9, v3

    .line 1888
    add-long/2addr v7, v9

    .line 1889
    iput-wide v7, v1, Li5/o;->p:J

    .line 1890
    .line 1891
    :cond_762
    :goto_762
    iget-wide v7, v1, Li5/o;->p:J

    .line 1892
    .line 1893
    iget v3, v1, Li5/o;->q:I

    .line 1894
    .line 1895
    int-to-long v9, v3

    .line 1896
    cmp-long v7, v7, v9

    .line 1897
    .line 1898
    if-gez v7, :cond_780

    .line 1899
    .line 1900
    iget v7, v1, Li5/o;->o:I

    .line 1901
    .line 1902
    const v8, 0x66726565

    .line 1903
    .line 1904
    .line 1905
    if-ne v7, v8, :cond_779

    .line 1906
    .line 1907
    const/16 v7, 0x8

    .line 1908
    .line 1909
    if-ne v3, v7, :cond_779

    .line 1910
    .line 1911
    iput-wide v9, v1, Li5/o;->p:J

    .line 1912
    .line 1913
    goto :goto_780

    .line 1914
    :cond_779
    const-string v0, "Atom size less than header length (unsupported)."

    .line 1915
    .line 1916
    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 1917
    .line 1918
    .line 1919
    move-result-object v0

    .line 1920
    throw v0

    .line 1921
    :cond_780
    :goto_780
    iget v7, v1, Li5/o;->o:I

    .line 1922
    .line 1923
    const v8, 0x6d6f6f76

    .line 1924
    .line 1925
    .line 1926
    const v9, 0x6d657461

    .line 1927
    .line 1928
    .line 1929
    if-eq v7, v8, :cond_7af

    .line 1930
    .line 1931
    const v8, 0x7472616b

    .line 1932
    .line 1933
    .line 1934
    if-eq v7, v8, :cond_7af

    .line 1935
    .line 1936
    const v8, 0x6d646961

    .line 1937
    .line 1938
    .line 1939
    if-eq v7, v8, :cond_7af

    .line 1940
    .line 1941
    const v8, 0x6d696e66

    .line 1942
    .line 1943
    .line 1944
    if-eq v7, v8, :cond_7af

    .line 1945
    .line 1946
    const v8, 0x7374626c

    .line 1947
    .line 1948
    .line 1949
    if-eq v7, v8, :cond_7af

    .line 1950
    .line 1951
    const v8, 0x65647473

    .line 1952
    .line 1953
    .line 1954
    if-eq v7, v8, :cond_7af

    .line 1955
    .line 1956
    if-eq v7, v9, :cond_7af

    .line 1957
    .line 1958
    const v8, 0x61787465

    .line 1959
    .line 1960
    .line 1961
    if-eq v7, v8, :cond_7af

    .line 1962
    .line 1963
    const v8, 0x74726566

    .line 1964
    .line 1965
    .line 1966
    if-ne v7, v8, :cond_7b2

    .line 1967
    .line 1968
    :cond_7af
    const/4 v11, 0x1

    .line 1969
    goto/16 :goto_848

    .line 1970
    .line 1971
    :cond_7b2
    const v6, 0x6d646864

    .line 1972
    .line 1973
    .line 1974
    if-eq v7, v6, :cond_80e

    .line 1975
    .line 1976
    const v6, 0x6d766864

    .line 1977
    .line 1978
    .line 1979
    if-eq v7, v6, :cond_80e

    .line 1980
    .line 1981
    const v6, 0x68646c72    # 4.3148E24f

    .line 1982
    .line 1983
    .line 1984
    if-eq v7, v6, :cond_80e

    .line 1985
    .line 1986
    const v6, 0x73747364

    .line 1987
    .line 1988
    .line 1989
    if-eq v7, v6, :cond_80e

    .line 1990
    .line 1991
    const v6, 0x73747473

    .line 1992
    .line 1993
    .line 1994
    if-eq v7, v6, :cond_80e

    .line 1995
    .line 1996
    const v6, 0x73747373

    .line 1997
    .line 1998
    .line 1999
    if-eq v7, v6, :cond_80e

    .line 2000
    .line 2001
    const v6, 0x63747473

    .line 2002
    .line 2003
    .line 2004
    if-eq v7, v6, :cond_80e

    .line 2005
    .line 2006
    const v6, 0x656c7374

    .line 2007
    .line 2008
    .line 2009
    if-eq v7, v6, :cond_80e

    .line 2010
    .line 2011
    const v6, 0x73747363

    .line 2012
    .line 2013
    .line 2014
    if-eq v7, v6, :cond_80e

    .line 2015
    .line 2016
    const v6, 0x7374737a

    .line 2017
    .line 2018
    .line 2019
    if-eq v7, v6, :cond_80e

    .line 2020
    .line 2021
    const v6, 0x73747a32

    .line 2022
    .line 2023
    .line 2024
    if-eq v7, v6, :cond_80e

    .line 2025
    .line 2026
    const v6, 0x7374636f

    .line 2027
    .line 2028
    .line 2029
    if-eq v7, v6, :cond_80e

    .line 2030
    .line 2031
    const v6, 0x636f3634

    .line 2032
    .line 2033
    .line 2034
    if-eq v7, v6, :cond_80e

    .line 2035
    .line 2036
    const v6, 0x746b6864

    .line 2037
    .line 2038
    .line 2039
    if-eq v7, v6, :cond_80e

    .line 2040
    .line 2041
    if-eq v7, v5, :cond_80e

    .line 2042
    .line 2043
    const v5, 0x75647461

    .line 2044
    .line 2045
    .line 2046
    if-eq v7, v5, :cond_80e

    .line 2047
    .line 2048
    const v5, 0x6b657973

    .line 2049
    .line 2050
    .line 2051
    if-eq v7, v5, :cond_80e

    .line 2052
    .line 2053
    const v5, 0x696c7374

    .line 2054
    .line 2055
    .line 2056
    if-eq v7, v5, :cond_80e

    .line 2057
    .line 2058
    const v5, 0x63686170

    .line 2059
    .line 2060
    .line 2061
    if-ne v7, v5, :cond_811

    .line 2062
    .line 2063
    :cond_80e
    const/16 v7, 0x8

    .line 2064
    .line 2065
    goto :goto_819

    .line 2066
    :cond_811
    const/4 v5, 0x0

    .line 2067
    iput-object v5, v1, Li5/o;->r:Ln3/x;

    .line 2068
    .line 2069
    const/4 v11, 0x1

    .line 2070
    iput v11, v1, Li5/o;->n:I

    .line 2071
    .line 2072
    goto/16 :goto_88d

    .line 2073
    .line 2074
    :goto_819
    if-ne v3, v7, :cond_81d

    .line 2075
    .line 2076
    const/4 v3, 0x1

    .line 2077
    goto :goto_81e

    .line 2078
    :cond_81d
    const/4 v3, 0x0

    .line 2079
    :goto_81e
    invoke-static {v3}, Loq/a;->z(Z)V

    .line 2080
    .line 2081
    .line 2082
    iget-wide v5, v1, Li5/o;->p:J

    .line 2083
    .line 2084
    const-wide/32 v7, 0x7fffffff

    .line 2085
    .line 2086
    .line 2087
    cmp-long v3, v5, v7

    .line 2088
    .line 2089
    if-gtz v3, :cond_82c

    .line 2090
    .line 2091
    const/4 v3, 0x1

    .line 2092
    goto :goto_82d

    .line 2093
    :cond_82c
    const/4 v3, 0x0

    .line 2094
    :goto_82d
    invoke-static {v3}, Loq/a;->z(Z)V

    .line 2095
    .line 2096
    .line 2097
    new-instance v3, Ln3/x;

    .line 2098
    .line 2099
    iget-wide v5, v1, Li5/o;->p:J

    .line 2100
    .line 2101
    long-to-int v5, v5

    .line 2102
    invoke-direct {v3, v5}, Ln3/x;-><init>(I)V

    .line 2103
    .line 2104
    .line 2105
    iget-object v4, v4, Ln3/x;->a:[B

    .line 2106
    .line 2107
    iget-object v5, v3, Ln3/x;->a:[B

    .line 2108
    .line 2109
    const/16 v7, 0x8

    .line 2110
    .line 2111
    const/4 v13, 0x0

    .line 2112
    invoke-static {v4, v13, v5, v13, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2113
    .line 2114
    .line 2115
    iput-object v3, v1, Li5/o;->r:Ln3/x;

    .line 2116
    .line 2117
    const/4 v11, 0x1

    .line 2118
    iput v11, v1, Li5/o;->n:I

    .line 2119
    .line 2120
    goto :goto_88d

    .line 2121
    :goto_848
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 2122
    .line 2123
    .line 2124
    move-result-wide v3

    .line 2125
    iget-wide v7, v1, Li5/o;->p:J

    .line 2126
    .line 2127
    add-long/2addr v3, v7

    .line 2128
    iget v5, v1, Li5/o;->q:I

    .line 2129
    .line 2130
    int-to-long v13, v5

    .line 2131
    sub-long/2addr v3, v13

    .line 2132
    cmp-long v5, v7, v13

    .line 2133
    .line 2134
    if-eqz v5, :cond_871

    .line 2135
    .line 2136
    iget v5, v1, Li5/o;->o:I

    .line 2137
    .line 2138
    if-ne v5, v9, :cond_871

    .line 2139
    .line 2140
    const/16 v7, 0x8

    .line 2141
    .line 2142
    invoke-virtual {v12, v7}, Ln3/x;->K(I)V

    .line 2143
    .line 2144
    .line 2145
    iget-object v5, v12, Ln3/x;->a:[B

    .line 2146
    .line 2147
    const/4 v13, 0x0

    .line 2148
    invoke-interface {v0, v5, v13, v7}, Lo4/o;->q([BII)V

    .line 2149
    .line 2150
    .line 2151
    invoke-static {v12}, Li5/e;->a(Ln3/x;)V

    .line 2152
    .line 2153
    .line 2154
    iget v5, v12, Ln3/x;->b:I

    .line 2155
    .line 2156
    invoke-interface {v0, v5}, Lo4/o;->n(I)V

    .line 2157
    .line 2158
    .line 2159
    invoke-interface {v0}, Lo4/o;->m()V

    .line 2160
    .line 2161
    .line 2162
    :cond_871
    new-instance v5, Lo3/c;

    .line 2163
    .line 2164
    iget v7, v1, Li5/o;->o:I

    .line 2165
    .line 2166
    invoke-direct {v5, v7, v3, v4}, Lo3/c;-><init>(IJ)V

    .line 2167
    .line 2168
    .line 2169
    invoke-virtual {v6, v5}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    .line 2170
    .line 2171
    .line 2172
    iget-wide v5, v1, Li5/o;->p:J

    .line 2173
    .line 2174
    iget v7, v1, Li5/o;->q:I

    .line 2175
    .line 2176
    int-to-long v7, v7

    .line 2177
    cmp-long v5, v5, v7

    .line 2178
    .line 2179
    if-nez v5, :cond_888

    .line 2180
    .line 2181
    invoke-virtual {v1, v3, v4}, Li5/o;->a(J)V

    .line 2182
    .line 2183
    .line 2184
    goto :goto_88d

    .line 2185
    :cond_888
    const/4 v13, 0x0

    .line 2186
    iput v13, v1, Li5/o;->n:I

    .line 2187
    .line 2188
    iput v13, v1, Li5/o;->q:I

    .line 2189
    .line 2190
    :goto_88d
    move v14, v11

    .line 2191
    :goto_88e
    if-nez v14, :cond_893

    .line 2192
    .line 2193
    goto/16 :goto_e

    .line 2194
    .line 2195
    :goto_892
    return v25

    .line 2196
    :cond_893
    const/16 v25, -0x1

    .line 2197
    .line 2198
    goto/16 :goto_12

    .line 2199
    .line 2200
    nop

    .line 2201
    :sswitch_data_898
    .sparse-switch
        -0x6604662e -> :sswitch_20b
        -0x4f6659e5 -> :sswitch_200
        -0x4a96a712 -> :sswitch_1f5
        -0x3182f331 -> :sswitch_1ea
        0x68f2d704 -> :sswitch_1df
    .end sparse-switch

    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    :pswitch_data_8ae
    .packed-switch 0x0
        :pswitch_228
        :pswitch_226
        :pswitch_224
        :pswitch_222
        :pswitch_220
    .end packed-switch
.end method

.method public final h()Ljava/util/List;
    .registers 2

    .line 1
    iget-object v0, p0, Li5/o;->m:Lhx/w1;

    .line 2
    .line 3
    return-object v0
.end method

.method public final release()V
    .registers 1

    .line 1
    return-void
.end method
