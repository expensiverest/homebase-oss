###### Class i5.u (i5.u)
.class public final Li5/u;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:J

.field public final d:J

.field public final e:J

.field public final f:J

.field public final g:Lk3/w;

.field public final h:I

.field public final i:Llx/b;

.field public final j:Llx/b;

.field public final k:I

.field public final l:I

.field public final m:Z

.field public final n:[Li5/v;


# direct methods
.method public constructor <init>(Li5/t;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget v0, p1, Li5/t;->a:I

    .line 5
    .line 6
    iput v0, p0, Li5/u;->a:I

    .line 7
    .line 8
    iget v0, p1, Li5/t;->b:I

    .line 9
    .line 10
    iput v0, p0, Li5/u;->b:I

    .line 11
    .line 12
    iget-wide v0, p1, Li5/t;->c:J

    .line 13
    .line 14
    iput-wide v0, p0, Li5/u;->c:J

    .line 15
    .line 16
    iget-wide v0, p1, Li5/t;->d:J

    .line 17
    .line 18
    iput-wide v0, p0, Li5/u;->d:J

    .line 19
    .line 20
    iget-wide v0, p1, Li5/t;->e:J

    .line 21
    .line 22
    iput-wide v0, p0, Li5/u;->e:J

    .line 23
    .line 24
    iget-wide v0, p1, Li5/t;->f:J

    .line 25
    .line 26
    iput-wide v0, p0, Li5/u;->f:J

    .line 27
    .line 28
    iget-object v0, p1, Li5/t;->g:Lk3/w;

    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Li5/u;->g:Lk3/w;

    .line 34
    .line 35
    iget v0, p1, Li5/t;->h:I

    .line 36
    .line 37
    iput v0, p0, Li5/u;->h:I

    .line 38
    .line 39
    iget-object v0, p1, Li5/t;->i:[Li5/v;

    .line 40
    .line 41
    iput-object v0, p0, Li5/u;->n:[Li5/v;

    .line 42
    .line 43
    iget v0, p1, Li5/t;->j:I

    .line 44
    .line 45
    iput v0, p0, Li5/u;->k:I

    .line 46
    .line 47
    iget-object v0, p1, Li5/t;->k:Llx/b;

    .line 48
    .line 49
    iput-object v0, p0, Li5/u;->i:Llx/b;

    .line 50
    .line 51
    iget-object v0, p1, Li5/t;->l:Llx/b;

    .line 52
    .line 53
    iput-object v0, p0, Li5/u;->j:Llx/b;

    .line 54
    .line 55
    iget-boolean v0, p1, Li5/t;->m:Z

    .line 56
    .line 57
    iput-boolean v0, p0, Li5/u;->m:Z

    .line 58
    .line 59
    iget p1, p1, Li5/t;->n:I

    .line 60
    .line 61
    iput p1, p0, Li5/u;->l:I

    .line 62
    .line 63
    return-void
.end method


# virtual methods
.method public final a()Li5/t;
    .registers 4

    .line 1
    new-instance v0, Li5/t;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iget v1, p0, Li5/u;->a:I

    .line 7
    .line 8
    iput v1, v0, Li5/t;->a:I

    .line 9
    .line 10
    iget v1, p0, Li5/u;->b:I

    .line 11
    .line 12
    iput v1, v0, Li5/t;->b:I

    .line 13
    .line 14
    iget-wide v1, p0, Li5/u;->c:J

    .line 15
    .line 16
    iput-wide v1, v0, Li5/t;->c:J

    .line 17
    .line 18
    iget-wide v1, p0, Li5/u;->d:J

    .line 19
    .line 20
    iput-wide v1, v0, Li5/t;->d:J

    .line 21
    .line 22
    iget-wide v1, p0, Li5/u;->e:J

    .line 23
    .line 24
    iput-wide v1, v0, Li5/t;->e:J

    .line 25
    .line 26
    iget-wide v1, p0, Li5/u;->f:J

    .line 27
    .line 28
    iput-wide v1, v0, Li5/t;->f:J

    .line 29
    .line 30
    iget-object v1, p0, Li5/u;->g:Lk3/w;

    .line 31
    .line 32
    iput-object v1, v0, Li5/t;->g:Lk3/w;

    .line 33
    .line 34
    iget v1, p0, Li5/u;->h:I

    .line 35
    .line 36
    iput v1, v0, Li5/t;->h:I

    .line 37
    .line 38
    iget-object v1, p0, Li5/u;->n:[Li5/v;

    .line 39
    .line 40
    iput-object v1, v0, Li5/t;->i:[Li5/v;

    .line 41
    .line 42
    iget v1, p0, Li5/u;->k:I

    .line 43
    .line 44
    iput v1, v0, Li5/t;->j:I

    .line 45
    .line 46
    iget-object v1, p0, Li5/u;->i:Llx/b;

    .line 47
    .line 48
    iput-object v1, v0, Li5/t;->k:Llx/b;

    .line 49
    .line 50
    iget-object v1, p0, Li5/u;->j:Llx/b;

    .line 51
    .line 52
    iput-object v1, v0, Li5/t;->l:Llx/b;

    .line 53
    .line 54
    iget-boolean v1, p0, Li5/u;->m:Z

    .line 55
    .line 56
    iput-boolean v1, v0, Li5/t;->m:Z

    .line 57
    .line 58
    iget v1, p0, Li5/u;->l:I

    .line 59
    .line 60
    iput v1, v0, Li5/t;->n:I

    .line 61
    .line 62
    return-object v0
.end method
