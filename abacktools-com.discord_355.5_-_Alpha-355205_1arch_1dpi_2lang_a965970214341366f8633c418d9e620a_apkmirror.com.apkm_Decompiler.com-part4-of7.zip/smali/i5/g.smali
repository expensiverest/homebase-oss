###### Class i5.g (i5.g)
.class public final synthetic Li5/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lgx/k;
.implements Lo3/s;


# instance fields
.field public final synthetic d:Li5/k;


# direct methods
.method public synthetic constructor <init>(Li5/k;)V
    .registers 2

    .line 1
    iput-object p1, p0, Li5/g;->d:Li5/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, Li5/u;

    .line 2
    .line 3
    iget-object v0, p0, Li5/g;->d:Li5/k;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez p1, :cond_b

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    return-object v1

    .line 12
    :cond_b
    iget v0, v0, Li5/k;->b:I

    .line 13
    .line 14
    and-int/lit16 v0, v0, 0x800

    .line 15
    .line 16
    if-eqz v0, :cond_1a

    .line 17
    .line 18
    iget-object v0, p1, Li5/u;->g:Lk3/w;

    .line 19
    .line 20
    invoke-static {v0}, Ln3/g;->e(Lk3/w;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1a

    .line 25
    .line 26
    return-object v1

    .line 27
    :cond_1a
    return-object p1
.end method

.method public b(JLn3/x;)V
    .registers 5

    .line 1
    iget-object v0, p0, Li5/g;->d:Li5/k;

    .line 2
    .line 3
    iget-object v0, v0, Li5/k;->J:[Lo4/i0;

    .line 4
    .line 5
    invoke-static {p1, p2, p3, v0}, Lo4/a;->c(JLn3/x;[Lo4/i0;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
