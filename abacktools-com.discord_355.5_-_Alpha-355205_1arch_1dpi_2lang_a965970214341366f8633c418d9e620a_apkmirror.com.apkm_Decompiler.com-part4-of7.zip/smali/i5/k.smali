###### Class i5.k (i5.k)
.class public final Li5/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo4/n;


# static fields
.field public static final O:[B

.field public static final P:Lk3/w;


# instance fields
.field public A:J

.field public B:Li5/j;

.field public C:I

.field public D:I

.field public E:I

.field public F:Z

.field public G:Z

.field public H:Lo4/p;

.field public I:[Lo4/i0;

.field public J:[Lo4/i0;

.field public K:Z

.field public L:Z

.field public M:J

.field public N:J

.field public final a:Ll5/k;

.field public final b:I

.field public final c:Ljava/util/List;

.field public final d:Landroid/util/SparseArray;

.field public final e:Ln3/x;

.field public final f:Ln3/x;

.field public final g:Ln3/x;

.field public final h:[B

.field public final i:Ln3/x;

.field public final j:Ln3/j0;

.field public final k:Lks/b;

.field public final l:Ln3/x;

.field public final m:Ljava/util/ArrayDeque;

.field public final n:Ljava/util/ArrayDeque;

.field public final o:Le6/b;

.field public final p:Lf6/i;

.field public q:Lhx/w1;

.field public r:I

.field public s:I

.field public t:J

.field public u:I

.field public v:Ln3/x;

.field public w:J

.field public x:I

.field public y:J

.field public z:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const/16 v0, 0x10

    .line 2
    .line 3
    new-array v0, v0, [B

    .line 4
    .line 5
    fill-array-data v0, :array_1e

    .line 6
    .line 7
    .line 8
    sput-object v0, Li5/k;->O:[B

    .line 9
    .line 10
    new-instance v0, Lk3/v;

    .line 11
    .line 12
    invoke-direct {v0}, Lk3/v;-><init>()V

    .line 13
    .line 14
    .line 15
    const-string v1, "application/x-emsg"

    .line 16
    .line 17
    invoke-static {v1}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iput-object v1, v0, Lk3/v;->o:Ljava/lang/String;

    .line 22
    .line 23
    new-instance v1, Lk3/w;

    .line 24
    .line 25
    invoke-direct {v1, v0}, Lk3/w;-><init>(Lk3/v;)V

    .line 26
    .line 27
    .line 28
    sput-object v1, Li5/k;->P:Lk3/w;

    .line 29
    .line 30
    return-void

    .line 31
    :array_1e
    .array-data 1
        -0x5et
        0x39t
        0x4ft
        0x52t
        0x5at
        -0x65t
        0x4ft
        0x14t
        -0x5et
        0x44t
        0x6ct
        0x42t
        0x7ct
        0x64t
        -0x73t
        -0xct
    .end array-data
.end method

.method public constructor <init>(Ll5/k;ILn3/j0;Ljava/util/List;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li5/k;->a:Ll5/k;

    .line 5
    .line 6
    iput p2, p0, Li5/k;->b:I

    .line 7
    .line 8
    iput-object p3, p0, Li5/k;->j:Ln3/j0;

    .line 9
    .line 10
    invoke-static {p4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iput-object p1, p0, Li5/k;->c:Ljava/util/List;

    .line 15
    .line 16
    new-instance p1, Lks/b;

    .line 17
    .line 18
    const/4 p2, 0x1

    .line 19
    invoke-direct {p1, p2}, Lks/b;-><init>(I)V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, Li5/k;->k:Lks/b;

    .line 23
    .line 24
    new-instance p1, Ln3/x;

    .line 25
    .line 26
    const/16 p2, 0x10

    .line 27
    .line 28
    invoke-direct {p1, p2}, Ln3/x;-><init>(I)V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, Li5/k;->l:Ln3/x;

    .line 32
    .line 33
    new-instance p1, Ln3/x;

    .line 34
    .line 35
    sget-object p3, Lo3/n;->a:[B

    .line 36
    .line 37
    invoke-direct {p1, p3}, Ln3/x;-><init>([B)V

    .line 38
    .line 39
    .line 40
    iput-object p1, p0, Li5/k;->e:Ln3/x;

    .line 41
    .line 42
    new-instance p1, Ln3/x;

    .line 43
    .line 44
    const/4 p3, 0x6

    .line 45
    invoke-direct {p1, p3}, Ln3/x;-><init>(I)V

    .line 46
    .line 47
    .line 48
    iput-object p1, p0, Li5/k;->f:Ln3/x;

    .line 49
    .line 50
    new-instance p1, Ln3/x;

    .line 51
    .line 52
    invoke-direct {p1}, Ln3/x;-><init>()V

    .line 53
    .line 54
    .line 55
    iput-object p1, p0, Li5/k;->g:Ln3/x;

    .line 56
    .line 57
    new-array p1, p2, [B

    .line 58
    .line 59
    iput-object p1, p0, Li5/k;->h:[B

    .line 60
    .line 61
    new-instance p2, Ln3/x;

    .line 62
    .line 63
    invoke-direct {p2, p1}, Ln3/x;-><init>([B)V

    .line 64
    .line 65
    .line 66
    iput-object p2, p0, Li5/k;->i:Ln3/x;

    .line 67
    .line 68
    new-instance p1, Ljava/util/ArrayDeque;

    .line 69
    .line 70
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    .line 71
    .line 72
    .line 73
    iput-object p1, p0, Li5/k;->m:Ljava/util/ArrayDeque;

    .line 74
    .line 75
    new-instance p1, Ljava/util/ArrayDeque;

    .line 76
    .line 77
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    .line 78
    .line 79
    .line 80
    iput-object p1, p0, Li5/k;->n:Ljava/util/ArrayDeque;

    .line 81
    .line 82
    new-instance p1, Landroid/util/SparseArray;

    .line 83
    .line 84
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    .line 85
    .line 86
    .line 87
    iput-object p1, p0, Li5/k;->d:Landroid/util/SparseArray;

    .line 88
    .line 89
    sget-object p1, Lhx/m0;->e:Lhx/k0;

    .line 90
    .line 91
    sget-object p1, Lhx/w1;->w:Lhx/w1;

    .line 92
    .line 93
    iput-object p1, p0, Li5/k;->q:Lhx/w1;

    .line 94
    .line 95
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    iput-wide p1, p0, Li5/k;->z:J

    .line 101
    .line 102
    iput-wide p1, p0, Li5/k;->y:J

    .line 103
    .line 104
    iput-wide p1, p0, Li5/k;->A:J

    .line 105
    .line 106
    sget-object p1, Lo4/p;->t:Lal/c;

    .line 107
    .line 108
    iput-object p1, p0, Li5/k;->H:Lo4/p;

    .line 109
    .line 110
    const/4 p1, 0x0

    .line 111
    new-array p2, p1, [Lo4/i0;

    .line 112
    .line 113
    iput-object p2, p0, Li5/k;->I:[Lo4/i0;

    .line 114
    .line 115
    new-array p1, p1, [Lo4/i0;

    .line 116
    .line 117
    iput-object p1, p0, Li5/k;->J:[Lo4/i0;

    .line 118
    .line 119
    new-instance p1, Le6/b;

    .line 120
    .line 121
    new-instance p2, Li5/g;

    .line 122
    .line 123
    invoke-direct {p2, p0}, Li5/g;-><init>(Li5/k;)V

    .line 124
    .line 125
    .line 126
    invoke-direct {p1, p2}, Le6/b;-><init>(Lo3/s;)V

    .line 127
    .line 128
    .line 129
    iput-object p1, p0, Li5/k;->o:Le6/b;

    .line 130
    .line 131
    new-instance p1, Lf6/i;

    .line 132
    .line 133
    const/4 p2, 0x2

    .line 134
    invoke-direct {p1, p2}, Lf6/i;-><init>(I)V

    .line 135
    .line 136
    .line 137
    iput-object p1, p0, Li5/k;->p:Lf6/i;

    .line 138
    .line 139
    const-wide/16 p1, -0x1

    .line 140
    .line 141
    iput-wide p1, p0, Li5/k;->M:J

    .line 142
    .line 143
    iput-wide p1, p0, Li5/k;->N:J

    .line 144
    .line 145
    return-void
.end method

.method public static b(Ljava/util/List;)Lk3/r;
    .registers 10

    .line 1
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x0

    .line 7
    move-object v4, v1

    .line 8
    move v3, v2

    .line 9
    :goto_8
    if-ge v3, v0, :cond_45

    .line 10
    .line 11
    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v5

    .line 15
    check-cast v5, Lo3/d;

    .line 16
    .line 17
    iget v6, v5, Lcz/j;->e:I

    .line 18
    .line 19
    const v7, 0x70737368    # 3.013775E29f

    .line 20
    .line 21
    .line 22
    if-ne v6, v7, :cond_42

    .line 23
    .line 24
    if-nez v4, :cond_1e

    .line 25
    .line 26
    new-instance v4, Ljava/util/ArrayList;

    .line 27
    .line 28
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 29
    .line 30
    .line 31
    :cond_1e
    iget-object v5, v5, Lo3/d;->i:Ln3/x;

    .line 32
    .line 33
    iget-object v5, v5, Ln3/x;->a:[B

    .line 34
    .line 35
    invoke-static {v5}, Li5/s;->h([B)Ldu/n;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    if-nez v6, :cond_2a

    .line 40
    .line 41
    move-object v6, v1

    .line 42
    goto :goto_2e

    .line 43
    :cond_2a
    iget-object v6, v6, Ldu/n;->i:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v6, Ljava/util/UUID;

    .line 46
    .line 47
    :goto_2e
    if-nez v6, :cond_38

    .line 48
    .line 49
    const-string v5, "FragmentedMp4Extractor"

    .line 50
    .line 51
    const-string v6, "Skipped pssh atom (failed to extract uuid)"

    .line 52
    .line 53
    invoke-static {v5, v6}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    goto :goto_42

    .line 57
    :cond_38
    new-instance v7, Lk3/q;

    .line 58
    .line 59
    const-string v8, "video/mp4"

    .line 60
    .line 61
    invoke-direct {v7, v6, v1, v8, v5}, Lk3/q;-><init>(Ljava/util/UUID;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    :cond_42
    :goto_42
    add-int/lit8 v3, v3, 0x1

    .line 68
    .line 69
    goto :goto_8

    .line 70
    :cond_45
    if-nez v4, :cond_48

    .line 71
    .line 72
    return-object v1

    .line 73
    :cond_48
    new-instance p0, Lk3/r;

    .line 74
    .line 75
    new-array v0, v2, [Lk3/q;

    .line 76
    .line 77
    invoke-interface {v4, v0}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    check-cast v0, [Lk3/q;

    .line 82
    .line 83
    invoke-direct {p0, v1, v2, v0}, Lk3/r;-><init>(Ljava/lang/String;Z[Lk3/q;)V

    .line 84
    .line 85
    .line 86
    return-object p0
.end method

.method public static i(Ln3/x;ILds/t;)V
    .registers 8

    .line 1
    add-int/lit8 p1, p1, 0x8

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Ln3/x;->N(I)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    sget-object v0, Li5/e;->a:[B

    .line 11
    .line 12
    and-int/lit8 v0, p1, 0x1

    .line 13
    .line 14
    if-nez v0, :cond_62

    .line 15
    .line 16
    and-int/lit8 p1, p1, 0x2

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    const/4 v1, 0x1

    .line 20
    if-eqz p1, :cond_17

    .line 21
    .line 22
    move p1, v1

    .line 23
    goto :goto_18

    .line 24
    :cond_17
    move p1, v0

    .line 25
    :goto_18
    invoke-virtual {p0}, Ln3/x;->E()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-nez v2, :cond_26

    .line 30
    .line 31
    iget-object p0, p2, Lds/t;->k:[Z

    .line 32
    .line 33
    iget p1, p2, Lds/t;->d:I

    .line 34
    .line 35
    invoke-static {p0, v0, p1, v0}, Ljava/util/Arrays;->fill([ZIIZ)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_26
    iget v3, p2, Lds/t;->d:I

    .line 40
    .line 41
    iget-object v4, p2, Lds/t;->q:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v4, Ln3/x;

    .line 44
    .line 45
    if-ne v2, v3, :cond_4b

    .line 46
    .line 47
    iget-object v3, p2, Lds/t;->k:[Z

    .line 48
    .line 49
    invoke-static {v3, v0, v2, p1}, Ljava/util/Arrays;->fill([ZIIZ)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0}, Ln3/x;->a()I

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    invoke-virtual {v4, p1}, Ln3/x;->K(I)V

    .line 57
    .line 58
    .line 59
    iput-boolean v1, p2, Lds/t;->j:Z

    .line 60
    .line 61
    iput-boolean v1, p2, Lds/t;->l:Z

    .line 62
    .line 63
    iget-object p1, v4, Ln3/x;->a:[B

    .line 64
    .line 65
    iget v1, v4, Ln3/x;->c:I

    .line 66
    .line 67
    invoke-virtual {p0, p1, v0, v1}, Ln3/x;->k([BII)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v4, v0}, Ln3/x;->N(I)V

    .line 71
    .line 72
    .line 73
    iput-boolean v0, p2, Lds/t;->l:Z

    .line 74
    .line 75
    return-void

    .line 76
    :cond_4b
    const-string p0, "Senc sample count "

    .line 77
    .line 78
    const-string p1, " is different from fragment sample count"

    .line 79
    .line 80
    invoke-static {v2, p0, p1}, Lp/x2;->l(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    iget p1, p2, Lds/t;->d:I

    .line 85
    .line 86
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    const/4 p1, 0x0

    .line 94
    invoke-static {p0, p1}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    throw p0

    .line 99
    :cond_62
    const-string p0, "Overriding TrackEncryptionBox parameters is unsupported."

    .line 100
    .line 101
    invoke-static {p0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    throw p0
.end method

.method public static j(JLn3/x;)Landroid/util/Pair;
    .registers 25

    .line 1
    move-object/from16 v0, p2

    .line 2
    .line 3
    const/16 v1, 0x8

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ln3/x;->N(I)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    invoke-static {v1}, Li5/e;->e(I)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v2, 0x4

    .line 17
    invoke-virtual {v0, v2}, Ln3/x;->O(I)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 21
    .line 22
    .line 23
    move-result-wide v7

    .line 24
    if-nez v1, :cond_25

    .line 25
    .line 26
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 27
    .line 28
    .line 29
    move-result-wide v3

    .line 30
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 31
    .line 32
    .line 33
    move-result-wide v5

    .line 34
    :goto_21
    add-long v5, v5, p0

    .line 35
    .line 36
    move-wide v10, v5

    .line 37
    goto :goto_2e

    .line 38
    :cond_25
    invoke-virtual {v0}, Ln3/x;->G()J

    .line 39
    .line 40
    .line 41
    move-result-wide v3

    .line 42
    invoke-virtual {v0}, Ln3/x;->G()J

    .line 43
    .line 44
    .line 45
    move-result-wide v5

    .line 46
    goto :goto_21

    .line 47
    :goto_2e
    sget-object v1, Ln3/l0;->a:Ljava/lang/String;

    .line 48
    .line 49
    sget-object v9, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 50
    .line 51
    const-wide/32 v5, 0xf4240

    .line 52
    .line 53
    .line 54
    invoke-static/range {v3 .. v9}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 55
    .line 56
    .line 57
    move-result-wide v12

    .line 58
    const/4 v1, 0x2

    .line 59
    invoke-virtual {v0, v1}, Ln3/x;->O(I)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    new-array v14, v1, [I

    .line 67
    .line 68
    new-array v15, v1, [J

    .line 69
    .line 70
    new-array v5, v1, [J

    .line 71
    .line 72
    new-array v6, v1, [J

    .line 73
    .line 74
    const/4 v9, 0x0

    .line 75
    move-wide/from16 v16, v10

    .line 76
    .line 77
    move-wide/from16 v18, v12

    .line 78
    .line 79
    move v10, v9

    .line 80
    :goto_4f
    if-ge v10, v1, :cond_9f

    .line 81
    .line 82
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 83
    .line 84
    .line 85
    move-result v9

    .line 86
    const/high16 v11, -0x80000000

    .line 87
    .line 88
    and-int/2addr v11, v9

    .line 89
    if-nez v11, :cond_97

    .line 90
    .line 91
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 92
    .line 93
    .line 94
    move-result-wide v20

    .line 95
    const v11, 0x7fffffff

    .line 96
    .line 97
    .line 98
    and-int/2addr v9, v11

    .line 99
    aput v9, v14, v10

    .line 100
    .line 101
    aput-wide v16, v15, v10

    .line 102
    .line 103
    aput-wide v18, v6, v10

    .line 104
    .line 105
    add-long v3, v3, v20

    .line 106
    .line 107
    move-object v9, v5

    .line 108
    move-object v11, v6

    .line 109
    const-wide/32 v5, 0xf4240

    .line 110
    .line 111
    .line 112
    move-object/from16 v18, v9

    .line 113
    .line 114
    sget-object v9, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 115
    .line 116
    move-object v2, v11

    .line 117
    move-object/from16 v11, v18

    .line 118
    .line 119
    invoke-static/range {v3 .. v9}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 120
    .line 121
    .line 122
    move-result-wide v5

    .line 123
    aget-wide v19, v2, v10

    .line 124
    .line 125
    sub-long v19, v5, v19

    .line 126
    .line 127
    aput-wide v19, v11, v10

    .line 128
    .line 129
    const/4 v9, 0x4

    .line 130
    invoke-virtual {v0, v9}, Ln3/x;->O(I)V

    .line 131
    .line 132
    .line 133
    aget v9, v14, v10

    .line 134
    .line 135
    move/from16 p0, v1

    .line 136
    .line 137
    int-to-long v0, v9

    .line 138
    add-long v16, v16, v0

    .line 139
    .line 140
    add-int/lit8 v10, v10, 0x1

    .line 141
    .line 142
    move/from16 v1, p0

    .line 143
    .line 144
    move-object/from16 v0, p2

    .line 145
    .line 146
    move-wide/from16 v18, v5

    .line 147
    .line 148
    move-object v5, v11

    .line 149
    move-object v6, v2

    .line 150
    const/4 v2, 0x4

    .line 151
    goto :goto_4f

    .line 152
    :cond_97
    const-string v0, "Unhandled indirect reference"

    .line 153
    .line 154
    const/4 v1, 0x0

    .line 155
    invoke-static {v0, v1}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    throw v0

    .line 160
    :cond_9f
    move-object v11, v5

    .line 161
    move-object v2, v6

    .line 162
    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    new-instance v1, Lo4/j;

    .line 167
    .line 168
    invoke-direct {v1, v14, v15, v11, v2}, Lo4/j;-><init>([I[J[J[J)V

    .line 169
    .line 170
    .line 171
    invoke-static {v0, v1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    return-object v0
.end method


# virtual methods
.method public final a()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Li5/k;->r:I

    .line 3
    .line 4
    iput v0, p0, Li5/k;->u:I

    .line 5
    .line 6
    return-void
.end method

.method public final c(Lo4/b0;Lo4/r;)V
    .registers 5

    .line 1
    iget-object v0, p0, Li5/k;->H:Lo4/p;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Lo4/p;->E(Lo4/b0;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, Li5/k;->K:Z

    .line 8
    .line 9
    iget-wide v0, p0, Li5/k;->N:J

    .line 10
    .line 11
    iput-wide v0, p2, Lo4/r;->b:J

    .line 12
    .line 13
    invoke-virtual {p0}, Li5/k;->a()V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final d(JJ)V
    .registers 8

    .line 1
    iget-object p1, p0, Li5/k;->d:Landroid/util/SparseArray;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    const/4 v0, 0x0

    .line 8
    move v1, v0

    .line 9
    :goto_8
    if-ge v1, p2, :cond_16

    .line 10
    .line 11
    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    check-cast v2, Li5/j;

    .line 16
    .line 17
    invoke-virtual {v2}, Li5/j;->e()V

    .line 18
    .line 19
    .line 20
    add-int/lit8 v1, v1, 0x1

    .line 21
    .line 22
    goto :goto_8

    .line 23
    :cond_16
    iget-object p1, p0, Li5/k;->n:Ljava/util/ArrayDeque;

    .line 24
    .line 25
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->clear()V

    .line 26
    .line 27
    .line 28
    iput v0, p0, Li5/k;->x:I

    .line 29
    .line 30
    iget-object p1, p0, Li5/k;->o:Le6/b;

    .line 31
    .line 32
    iget-object p1, p1, Le6/b;->e:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p1, Ljava/util/PriorityQueue;

    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/util/PriorityQueue;->clear()V

    .line 37
    .line 38
    .line 39
    iput-wide p3, p0, Li5/k;->y:J

    .line 40
    .line 41
    iget-object p1, p0, Li5/k;->m:Ljava/util/ArrayDeque;

    .line 42
    .line 43
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->clear()V

    .line 44
    .line 45
    .line 46
    const-wide/16 p1, -0x1

    .line 47
    .line 48
    iput-wide p1, p0, Li5/k;->N:J

    .line 49
    .line 50
    invoke-virtual {p0}, Li5/k;->a()V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public final e(Lo4/p;)V
    .registers 8

    .line 1
    iget v0, p0, Li5/k;->b:I

    .line 2
    .line 3
    and-int/lit8 v1, v0, 0x20

    .line 4
    .line 5
    if-nez v1, :cond_e

    .line 6
    .line 7
    new-instance v1, Lcom/google/firebase/messaging/o;

    .line 8
    .line 9
    iget-object v2, p0, Li5/k;->a:Ll5/k;

    .line 10
    .line 11
    invoke-direct {v1, p1, v2}, Lcom/google/firebase/messaging/o;-><init>(Lo4/p;Ll5/k;)V

    .line 12
    .line 13
    .line 14
    move-object p1, v1

    .line 15
    :cond_e
    iput-object p1, p0, Li5/k;->H:Lo4/p;

    .line 16
    .line 17
    invoke-virtual {p0}, Li5/k;->a()V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x2

    .line 21
    new-array p1, p1, [Lo4/i0;

    .line 22
    .line 23
    iput-object p1, p0, Li5/k;->I:[Lo4/i0;

    .line 24
    .line 25
    and-int/lit8 v0, v0, 0x4

    .line 26
    .line 27
    const/16 v1, 0x64

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    if-eqz v0, :cond_2c

    .line 31
    .line 32
    iget-object v0, p0, Li5/k;->H:Lo4/p;

    .line 33
    .line 34
    const/4 v3, 0x5

    .line 35
    invoke-interface {v0, v1, v3}, Lo4/p;->o(II)Lo4/i0;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    aput-object v0, p1, v2

    .line 40
    .line 41
    const/4 p1, 0x1

    .line 42
    const/16 v1, 0x65

    .line 43
    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    move p1, v2

    .line 46
    :goto_2d
    iget-object v0, p0, Li5/k;->I:[Lo4/i0;

    .line 47
    .line 48
    invoke-static {p1, v0}, Ln3/l0;->U(I[Ljava/lang/Object;)[Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    check-cast p1, [Lo4/i0;

    .line 53
    .line 54
    iput-object p1, p0, Li5/k;->I:[Lo4/i0;

    .line 55
    .line 56
    array-length v0, p1

    .line 57
    move v3, v2

    .line 58
    :goto_39
    if-ge v3, v0, :cond_45

    .line 59
    .line 60
    aget-object v4, p1, v3

    .line 61
    .line 62
    sget-object v5, Li5/k;->P:Lk3/w;

    .line 63
    .line 64
    invoke-interface {v4, v5}, Lo4/i0;->d(Lk3/w;)V

    .line 65
    .line 66
    .line 67
    add-int/lit8 v3, v3, 0x1

    .line 68
    .line 69
    goto :goto_39

    .line 70
    :cond_45
    iget-object p1, p0, Li5/k;->c:Ljava/util/List;

    .line 71
    .line 72
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    new-array v0, v0, [Lo4/i0;

    .line 77
    .line 78
    iput-object v0, p0, Li5/k;->J:[Lo4/i0;

    .line 79
    .line 80
    :goto_4f
    iget-object v0, p0, Li5/k;->J:[Lo4/i0;

    .line 81
    .line 82
    array-length v0, v0

    .line 83
    if-ge v2, v0, :cond_6e

    .line 84
    .line 85
    iget-object v0, p0, Li5/k;->H:Lo4/p;

    .line 86
    .line 87
    add-int/lit8 v3, v1, 0x1

    .line 88
    .line 89
    const/4 v4, 0x3

    .line 90
    invoke-interface {v0, v1, v4}, Lo4/p;->o(II)Lo4/i0;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    check-cast v1, Lk3/w;

    .line 99
    .line 100
    invoke-interface {v0, v1}, Lo4/i0;->d(Lk3/w;)V

    .line 101
    .line 102
    .line 103
    iget-object v1, p0, Li5/k;->J:[Lo4/i0;

    .line 104
    .line 105
    aput-object v0, v1, v2

    .line 106
    .line 107
    add-int/lit8 v2, v2, 0x1

    .line 108
    .line 109
    move v1, v3

    .line 110
    goto :goto_4f

    .line 111
    :cond_6e
    return-void
.end method

.method public final f(Lo4/o;)Z
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, v0}, Li5/s;->l(Lo4/o;Z)Lo4/f0;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    if-eqz p1, :cond_c

    .line 7
    .line 8
    invoke-static {p1}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    goto :goto_10

    .line 13
    :cond_c
    sget-object v1, Lhx/m0;->e:Lhx/k0;

    .line 14
    .line 15
    sget-object v1, Lhx/w1;->w:Lhx/w1;

    .line 16
    .line 17
    :goto_10
    iput-object v1, p0, Li5/k;->q:Lhx/w1;

    .line 18
    .line 19
    if-nez p1, :cond_15

    .line 20
    .line 21
    return v0

    .line 22
    :cond_15
    const/4 p1, 0x0

    .line 23
    return p1
.end method

.method public final g(Lo4/o;Lo4/r;)I
    .registers 53

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    :goto_4
    move-object/from16 v2, p2

    .line 6
    .line 7
    :cond_6
    :goto_6
    iget v3, v1, Li5/k;->r:I

    .line 8
    .line 9
    iget-object v6, v1, Li5/k;->m:Ljava/util/ArrayDeque;

    .line 10
    .line 11
    iget-object v15, v1, Li5/k;->o:Le6/b;

    .line 12
    .line 13
    const-wide/32 v16, 0x7fffffff

    .line 14
    .line 15
    .line 16
    iget-object v7, v1, Li5/k;->p:Lf6/i;

    .line 17
    .line 18
    const-wide/16 v18, 0x0

    .line 19
    .line 20
    const-wide/16 v20, 0x8

    .line 21
    .line 22
    iget v9, v1, Li5/k;->b:I

    .line 23
    .line 24
    const-wide/16 v22, 0x10

    .line 25
    .line 26
    iget-object v11, v1, Li5/k;->d:Landroid/util/SparseArray;

    .line 27
    .line 28
    const-wide/16 v24, 0x1

    .line 29
    .line 30
    iget-object v13, v1, Li5/k;->i:Ln3/x;

    .line 31
    .line 32
    const/4 v14, 0x5

    .line 33
    const/4 v4, 0x2

    .line 34
    const/4 v8, 0x1

    .line 35
    if-eqz v3, :cond_87f

    .line 36
    .line 37
    const-wide v29, -0x7fffffffffffffffL    # -4.9E-324

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    const/16 v31, 0x0

    .line 43
    .line 44
    iget-object v5, v1, Li5/k;->n:Ljava/util/ArrayDeque;

    .line 45
    .line 46
    const/16 v32, 0x8

    .line 47
    .line 48
    const-string v12, "FragmentedMp4Extractor"

    .line 49
    .line 50
    iget-object v10, v1, Li5/k;->j:Ln3/j0;

    .line 51
    .line 52
    if-eq v3, v8, :cond_6a7

    .line 53
    .line 54
    if-eq v3, v4, :cond_64f

    .line 55
    .line 56
    move/from16 v34, v4

    .line 57
    .line 58
    const/4 v4, 0x6

    .line 59
    if-eq v3, v14, :cond_5d9

    .line 60
    .line 61
    if-eq v3, v4, :cond_3ee

    .line 62
    .line 63
    iget-object v3, v1, Li5/k;->B:Li5/j;

    .line 64
    .line 65
    if-nez v3, :cond_e4

    .line 66
    .line 67
    invoke-virtual {v11}, Landroid/util/SparseArray;->size()I

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    move/from16 v36, v4

    .line 72
    .line 73
    move/from16 v35, v14

    .line 74
    .line 75
    move/from16 v14, v31

    .line 76
    .line 77
    const/4 v4, 0x0

    .line 78
    const-wide v26, 0x7fffffffffffffffL

    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    :goto_52
    if-ge v14, v3, :cond_9b

    .line 84
    .line 85
    invoke-virtual {v11, v14}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v16

    .line 89
    move-object/from16 v7, v16

    .line 90
    .line 91
    check-cast v7, Li5/j;

    .line 92
    .line 93
    move/from16 v38, v8

    .line 94
    .line 95
    iget-boolean v8, v7, Li5/j;->n:Z

    .line 96
    .line 97
    iget-object v6, v7, Li5/j;->b:Lds/t;

    .line 98
    .line 99
    move/from16 v16, v3

    .line 100
    .line 101
    if-nez v8, :cond_71

    .line 102
    .line 103
    iget v3, v7, Li5/j;->f:I

    .line 104
    .line 105
    move/from16 v17, v8

    .line 106
    .line 107
    iget-object v8, v7, Li5/j;->d:Li5/w;

    .line 108
    .line 109
    iget v8, v8, Li5/w;->b:I

    .line 110
    .line 111
    if-eq v3, v8, :cond_94

    .line 112
    .line 113
    goto :goto_73

    .line 114
    :cond_71
    move/from16 v17, v8

    .line 115
    .line 116
    :goto_73
    if-eqz v17, :cond_7c

    .line 117
    .line 118
    iget v3, v7, Li5/j;->h:I

    .line 119
    .line 120
    iget v8, v6, Lds/t;->c:I

    .line 121
    .line 122
    if-ne v3, v8, :cond_7c

    .line 123
    .line 124
    goto :goto_94

    .line 125
    :cond_7c
    if-nez v17, :cond_87

    .line 126
    .line 127
    iget-object v3, v7, Li5/j;->d:Li5/w;

    .line 128
    .line 129
    iget-object v3, v3, Li5/w;->c:[J

    .line 130
    .line 131
    iget v6, v7, Li5/j;->f:I

    .line 132
    .line 133
    aget-wide v17, v3, v6

    .line 134
    .line 135
    goto :goto_8d

    .line 136
    :cond_87
    iget-object v3, v6, Lds/t;->e:[J

    .line 137
    .line 138
    iget v6, v7, Li5/j;->h:I

    .line 139
    .line 140
    aget-wide v17, v3, v6

    .line 141
    .line 142
    :goto_8d
    cmp-long v3, v17, v26

    .line 143
    .line 144
    if-gez v3, :cond_94

    .line 145
    .line 146
    move-object v4, v7

    .line 147
    move-wide/from16 v26, v17

    .line 148
    .line 149
    :cond_94
    :goto_94
    add-int/lit8 v14, v14, 0x1

    .line 150
    .line 151
    move/from16 v3, v16

    .line 152
    .line 153
    move/from16 v8, v38

    .line 154
    .line 155
    goto :goto_52

    .line 156
    :cond_9b
    move/from16 v38, v8

    .line 157
    .line 158
    if-nez v4, :cond_b9

    .line 159
    .line 160
    iget-wide v3, v1, Li5/k;->w:J

    .line 161
    .line 162
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 163
    .line 164
    .line 165
    move-result-wide v5

    .line 166
    sub-long/2addr v3, v5

    .line 167
    long-to-int v3, v3

    .line 168
    if-ltz v3, :cond_b1

    .line 169
    .line 170
    invoke-interface {v0, v3}, Lo4/o;->n(I)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v1}, Li5/k;->a()V

    .line 174
    .line 175
    .line 176
    goto/16 :goto_6

    .line 177
    .line 178
    :cond_b1
    const-string v0, "Offset to end of mdat was negative."

    .line 179
    .line 180
    const/4 v2, 0x0

    .line 181
    invoke-static {v0, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    throw v0

    .line 186
    :cond_b9
    iget-boolean v2, v4, Li5/j;->n:Z

    .line 187
    .line 188
    if-nez v2, :cond_c6

    .line 189
    .line 190
    iget-object v2, v4, Li5/j;->d:Li5/w;

    .line 191
    .line 192
    iget-object v2, v2, Li5/w;->c:[J

    .line 193
    .line 194
    iget v3, v4, Li5/j;->f:I

    .line 195
    .line 196
    aget-wide v6, v2, v3

    .line 197
    .line 198
    goto :goto_ce

    .line 199
    :cond_c6
    iget-object v2, v4, Li5/j;->b:Lds/t;

    .line 200
    .line 201
    iget-object v2, v2, Lds/t;->e:[J

    .line 202
    .line 203
    iget v3, v4, Li5/j;->h:I

    .line 204
    .line 205
    aget-wide v6, v2, v3

    .line 206
    .line 207
    :goto_ce
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 208
    .line 209
    .line 210
    move-result-wide v2

    .line 211
    sub-long/2addr v6, v2

    .line 212
    long-to-int v2, v6

    .line 213
    if-gez v2, :cond_dd

    .line 214
    .line 215
    const-string v2, "Ignoring negative offset to sample data."

    .line 216
    .line 217
    invoke-static {v12, v2}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    move/from16 v2, v31

    .line 221
    .line 222
    :cond_dd
    invoke-interface {v0, v2}, Lo4/o;->n(I)V

    .line 223
    .line 224
    .line 225
    iput-object v4, v1, Li5/k;->B:Li5/j;

    .line 226
    .line 227
    move-object v3, v4

    .line 228
    goto :goto_ea

    .line 229
    :cond_e4
    move/from16 v36, v4

    .line 230
    .line 231
    move/from16 v38, v8

    .line 232
    .line 233
    move/from16 v35, v14

    .line 234
    .line 235
    :goto_ea
    iget-object v2, v3, Li5/j;->a:Lo4/i0;

    .line 236
    .line 237
    iget-object v4, v3, Li5/j;->b:Lds/t;

    .line 238
    .line 239
    iget v6, v1, Li5/k;->r:I

    .line 240
    .line 241
    const-string v7, "video/hevc"

    .line 242
    .line 243
    const-string v8, "video/avc"

    .line 244
    .line 245
    const/4 v11, 0x3

    .line 246
    if-ne v6, v11, :cond_1c8

    .line 247
    .line 248
    iget-boolean v6, v3, Li5/j;->n:Z

    .line 249
    .line 250
    if-nez v6, :cond_104

    .line 251
    .line 252
    iget-object v6, v3, Li5/j;->d:Li5/w;

    .line 253
    .line 254
    iget-object v6, v6, Li5/w;->d:[I

    .line 255
    .line 256
    iget v11, v3, Li5/j;->f:I

    .line 257
    .line 258
    aget v6, v6, v11

    .line 259
    .line 260
    goto :goto_10a

    .line 261
    :cond_104
    iget-object v6, v4, Lds/t;->g:[I

    .line 262
    .line 263
    iget v11, v3, Li5/j;->f:I

    .line 264
    .line 265
    aget v6, v6, v11

    .line 266
    .line 267
    :goto_10a
    iput v6, v1, Li5/k;->C:I

    .line 268
    .line 269
    iget-object v6, v3, Li5/j;->d:Li5/w;

    .line 270
    .line 271
    iget-object v6, v6, Li5/w;->a:Li5/u;

    .line 272
    .line 273
    iget-object v6, v6, Li5/u;->g:Lk3/w;

    .line 274
    .line 275
    iget-object v11, v6, Lk3/w;->p:Ljava/lang/String;

    .line 276
    .line 277
    invoke-static {v11, v8}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-result v11

    .line 281
    if-eqz v11, :cond_124

    .line 282
    .line 283
    and-int/lit8 v6, v9, 0x40

    .line 284
    .line 285
    if-eqz v6, :cond_121

    .line 286
    .line 287
    :goto_11e
    move/from16 v6, v38

    .line 288
    .line 289
    goto :goto_131

    .line 290
    :cond_121
    move/from16 v6, v31

    .line 291
    .line 292
    goto :goto_131

    .line 293
    :cond_124
    iget-object v6, v6, Lk3/w;->p:Ljava/lang/String;

    .line 294
    .line 295
    invoke-static {v6, v7}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    move-result v6

    .line 299
    if-eqz v6, :cond_121

    .line 300
    .line 301
    and-int/lit16 v6, v9, 0x80

    .line 302
    .line 303
    if-eqz v6, :cond_121

    .line 304
    .line 305
    goto :goto_11e

    .line 306
    :goto_131
    xor-int/lit8 v6, v6, 0x1

    .line 307
    .line 308
    iput-boolean v6, v1, Li5/k;->F:Z

    .line 309
    .line 310
    iget v6, v3, Li5/j;->f:I

    .line 311
    .line 312
    iget v9, v3, Li5/j;->i:I

    .line 313
    .line 314
    if-ge v6, v9, :cond_174

    .line 315
    .line 316
    iget v2, v1, Li5/k;->C:I

    .line 317
    .line 318
    invoke-interface {v0, v2}, Lo4/o;->n(I)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {v3}, Li5/j;->b()Li5/v;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    if-nez v0, :cond_147

    .line 326
    .line 327
    goto :goto_167

    .line 328
    :cond_147
    iget-object v2, v4, Lds/t;->q:Ljava/lang/Object;

    .line 329
    .line 330
    check-cast v2, Ln3/x;

    .line 331
    .line 332
    iget v0, v0, Li5/v;->d:I

    .line 333
    .line 334
    if-eqz v0, :cond_152

    .line 335
    .line 336
    invoke-virtual {v2, v0}, Ln3/x;->O(I)V

    .line 337
    .line 338
    .line 339
    :cond_152
    iget v0, v3, Li5/j;->f:I

    .line 340
    .line 341
    iget-boolean v5, v4, Lds/t;->j:Z

    .line 342
    .line 343
    if-eqz v5, :cond_167

    .line 344
    .line 345
    iget-object v4, v4, Lds/t;->k:[Z

    .line 346
    .line 347
    aget-boolean v0, v4, v0

    .line 348
    .line 349
    if-eqz v0, :cond_167

    .line 350
    .line 351
    invoke-virtual {v2}, Ln3/x;->H()I

    .line 352
    .line 353
    .line 354
    move-result v0

    .line 355
    mul-int/lit8 v0, v0, 0x6

    .line 356
    .line 357
    invoke-virtual {v2, v0}, Ln3/x;->O(I)V

    .line 358
    .line 359
    .line 360
    :cond_167
    :goto_167
    invoke-virtual {v3}, Li5/j;->c()Z

    .line 361
    .line 362
    .line 363
    move-result v0

    .line 364
    if-nez v0, :cond_170

    .line 365
    .line 366
    const/4 v2, 0x0

    .line 367
    iput-object v2, v1, Li5/k;->B:Li5/j;

    .line 368
    .line 369
    :cond_170
    const/4 v11, 0x3

    .line 370
    iput v11, v1, Li5/k;->r:I

    .line 371
    .line 372
    return v31

    .line 373
    :cond_174
    iget-object v6, v3, Li5/j;->d:Li5/w;

    .line 374
    .line 375
    iget-object v6, v6, Li5/w;->a:Li5/u;

    .line 376
    .line 377
    iget v6, v6, Li5/u;->h:I

    .line 378
    .line 379
    move/from16 v9, v38

    .line 380
    .line 381
    if-ne v6, v9, :cond_189

    .line 382
    .line 383
    iget v6, v1, Li5/k;->C:I

    .line 384
    .line 385
    add-int/lit8 v6, v6, -0x8

    .line 386
    .line 387
    iput v6, v1, Li5/k;->C:I

    .line 388
    .line 389
    move/from16 v6, v32

    .line 390
    .line 391
    invoke-interface {v0, v6}, Lo4/o;->n(I)V

    .line 392
    .line 393
    .line 394
    :cond_189
    iget-object v6, v3, Li5/j;->d:Li5/w;

    .line 395
    .line 396
    iget-object v6, v6, Li5/w;->a:Li5/u;

    .line 397
    .line 398
    iget-object v6, v6, Li5/u;->g:Lk3/w;

    .line 399
    .line 400
    iget-object v6, v6, Lk3/w;->p:Ljava/lang/String;

    .line 401
    .line 402
    const-string v9, "audio/ac4"

    .line 403
    .line 404
    invoke-virtual {v9, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 405
    .line 406
    .line 407
    move-result v6

    .line 408
    if-eqz v6, :cond_1b2

    .line 409
    .line 410
    iget v6, v1, Li5/k;->C:I

    .line 411
    .line 412
    const/4 v9, 0x7

    .line 413
    invoke-virtual {v3, v6, v9}, Li5/j;->d(II)I

    .line 414
    .line 415
    .line 416
    move-result v6

    .line 417
    iput v6, v1, Li5/k;->D:I

    .line 418
    .line 419
    iget v6, v1, Li5/k;->C:I

    .line 420
    .line 421
    invoke-static {v6, v13}, Lo4/a;->f(ILn3/x;)V

    .line 422
    .line 423
    .line 424
    invoke-interface {v2, v9, v13}, Lo4/i0;->g(ILn3/x;)V

    .line 425
    .line 426
    .line 427
    iget v6, v1, Li5/k;->D:I

    .line 428
    .line 429
    add-int/2addr v6, v9

    .line 430
    iput v6, v1, Li5/k;->D:I

    .line 431
    .line 432
    move/from16 v9, v31

    .line 433
    .line 434
    goto :goto_1bc

    .line 435
    :cond_1b2
    iget v6, v1, Li5/k;->C:I

    .line 436
    .line 437
    move/from16 v9, v31

    .line 438
    .line 439
    invoke-virtual {v3, v6, v9}, Li5/j;->d(II)I

    .line 440
    .line 441
    .line 442
    move-result v6

    .line 443
    iput v6, v1, Li5/k;->D:I

    .line 444
    .line 445
    :goto_1bc
    iget v6, v1, Li5/k;->C:I

    .line 446
    .line 447
    iget v11, v1, Li5/k;->D:I

    .line 448
    .line 449
    add-int/2addr v6, v11

    .line 450
    iput v6, v1, Li5/k;->C:I

    .line 451
    .line 452
    const/4 v6, 0x4

    .line 453
    iput v6, v1, Li5/k;->r:I

    .line 454
    .line 455
    iput v9, v1, Li5/k;->E:I

    .line 456
    .line 457
    :cond_1c8
    iget-object v6, v3, Li5/j;->d:Li5/w;

    .line 458
    .line 459
    iget-object v9, v6, Li5/w;->a:Li5/u;

    .line 460
    .line 461
    iget-boolean v11, v3, Li5/j;->n:Z

    .line 462
    .line 463
    if-nez v11, :cond_1d7

    .line 464
    .line 465
    iget-object v4, v6, Li5/w;->f:[J

    .line 466
    .line 467
    iget v6, v3, Li5/j;->f:I

    .line 468
    .line 469
    aget-wide v11, v4, v6

    .line 470
    .line 471
    goto :goto_1dd

    .line 472
    :cond_1d7
    iget v6, v3, Li5/j;->f:I

    .line 473
    .line 474
    iget-object v4, v4, Lds/t;->h:[J

    .line 475
    .line 476
    aget-wide v11, v4, v6

    .line 477
    .line 478
    :goto_1dd
    if-eqz v10, :cond_1e3

    .line 479
    .line 480
    invoke-virtual {v10, v11, v12}, Ln3/j0;->a(J)J

    .line 481
    .line 482
    .line 483
    move-result-wide v11

    .line 484
    :cond_1e3
    iget v4, v9, Li5/u;->k:I

    .line 485
    .line 486
    iget-object v6, v9, Li5/u;->g:Lk3/w;

    .line 487
    .line 488
    if-eqz v4, :cond_344

    .line 489
    .line 490
    iget-object v9, v1, Li5/k;->f:Ln3/x;

    .line 491
    .line 492
    iget-object v13, v9, Ln3/x;->a:[B

    .line 493
    .line 494
    const/16 v31, 0x0

    .line 495
    .line 496
    aput-byte v31, v13, v31

    .line 497
    .line 498
    const/16 v38, 0x1

    .line 499
    .line 500
    aput-byte v31, v13, v38

    .line 501
    .line 502
    aput-byte v31, v13, v34

    .line 503
    .line 504
    rsub-int/lit8 v14, v4, 0x4

    .line 505
    .line 506
    move/from16 v16, v4

    .line 507
    .line 508
    :goto_1fb
    iget v4, v1, Li5/k;->D:I

    .line 509
    .line 510
    move-object/from16 v40, v5

    .line 511
    .line 512
    iget v5, v1, Li5/k;->C:I

    .line 513
    .line 514
    if-ge v4, v5, :cond_37c

    .line 515
    .line 516
    iget v4, v1, Li5/k;->E:I

    .line 517
    .line 518
    if-nez v4, :cond_2da

    .line 519
    .line 520
    iget-object v4, v1, Li5/k;->J:[Lo4/i0;

    .line 521
    .line 522
    array-length v4, v4

    .line 523
    if-gtz v4, :cond_210

    .line 524
    .line 525
    iget-boolean v4, v1, Li5/k;->F:Z

    .line 526
    .line 527
    if-nez v4, :cond_225

    .line 528
    .line 529
    :cond_210
    invoke-static {v6}, Lo3/n;->i(Lk3/w;)I

    .line 530
    .line 531
    .line 532
    move-result v4

    .line 533
    add-int v5, v16, v4

    .line 534
    .line 535
    move/from16 p2, v4

    .line 536
    .line 537
    iget v4, v1, Li5/k;->C:I

    .line 538
    .line 539
    move/from16 v17, v4

    .line 540
    .line 541
    iget v4, v1, Li5/k;->D:I

    .line 542
    .line 543
    sub-int v4, v17, v4

    .line 544
    .line 545
    if-gt v5, v4, :cond_225

    .line 546
    .line 547
    move/from16 v4, p2

    .line 548
    .line 549
    goto :goto_226

    .line 550
    :cond_225
    const/4 v4, 0x0

    .line 551
    :goto_226
    add-int v5, v16, v4

    .line 552
    .line 553
    invoke-interface {v0, v13, v14, v5}, Lo4/o;->readFully([BII)V

    .line 554
    .line 555
    .line 556
    const/4 v5, 0x0

    .line 557
    invoke-virtual {v9, v5}, Ln3/x;->N(I)V

    .line 558
    .line 559
    .line 560
    invoke-virtual {v9}, Ln3/x;->m()I

    .line 561
    .line 562
    .line 563
    move-result v17

    .line 564
    if-ltz v17, :cond_2d2

    .line 565
    .line 566
    sub-int v5, v17, v4

    .line 567
    .line 568
    iput v5, v1, Li5/k;->E:I

    .line 569
    .line 570
    iget-object v5, v1, Li5/k;->e:Ln3/x;

    .line 571
    .line 572
    move/from16 p2, v14

    .line 573
    .line 574
    const/4 v14, 0x0

    .line 575
    invoke-virtual {v5, v14}, Ln3/x;->N(I)V

    .line 576
    .line 577
    .line 578
    const/4 v14, 0x4

    .line 579
    invoke-interface {v2, v14, v5}, Lo4/i0;->g(ILn3/x;)V

    .line 580
    .line 581
    .line 582
    iget v5, v1, Li5/k;->D:I

    .line 583
    .line 584
    add-int/2addr v5, v14

    .line 585
    iput v5, v1, Li5/k;->D:I

    .line 586
    .line 587
    iget v5, v1, Li5/k;->C:I

    .line 588
    .line 589
    add-int v5, v5, p2

    .line 590
    .line 591
    iput v5, v1, Li5/k;->C:I

    .line 592
    .line 593
    iget-object v5, v1, Li5/k;->J:[Lo4/i0;

    .line 594
    .line 595
    array-length v5, v5

    .line 596
    if-lez v5, :cond_2b0

    .line 597
    .line 598
    if-lez v4, :cond_2b0

    .line 599
    .line 600
    invoke-static {v6}, Lo3/n;->d(Lk3/w;)Ljava/lang/String;

    .line 601
    .line 602
    .line 603
    move-result-object v5

    .line 604
    if-nez v5, :cond_25e

    .line 605
    .line 606
    goto :goto_2b0

    .line 607
    :cond_25e
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 608
    .line 609
    .line 610
    move-result v14

    .line 611
    sparse-switch v14, :sswitch_data_b4e

    .line 612
    .line 613
    .line 614
    :goto_265
    const/4 v5, -0x1

    .line 615
    goto :goto_284

    .line 616
    :sswitch_267
    const-string v14, "video/vvc"

    .line 617
    .line 618
    invoke-virtual {v5, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 619
    .line 620
    .line 621
    move-result v5

    .line 622
    if-nez v5, :cond_270

    .line 623
    .line 624
    goto :goto_265

    .line 625
    :cond_270
    move/from16 v5, v34

    .line 626
    .line 627
    goto :goto_284

    .line 628
    :sswitch_273
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 629
    .line 630
    .line 631
    move-result v5

    .line 632
    if-nez v5, :cond_27a

    .line 633
    .line 634
    goto :goto_265

    .line 635
    :cond_27a
    const/4 v5, 0x1

    .line 636
    goto :goto_284

    .line 637
    :sswitch_27c
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 638
    .line 639
    .line 640
    move-result v5

    .line 641
    if-nez v5, :cond_283

    .line 642
    .line 643
    goto :goto_265

    .line 644
    :cond_283
    const/4 v5, 0x0

    .line 645
    :goto_284
    packed-switch v5, :pswitch_data_b5c

    .line 646
    .line 647
    .line 648
    goto :goto_2b0

    .line 649
    :pswitch_288
    aget-byte v5, v13, v35

    .line 650
    .line 651
    and-int/lit16 v5, v5, 0xf8

    .line 652
    .line 653
    const/16 v39, 0x3

    .line 654
    .line 655
    shr-int/lit8 v5, v5, 0x3

    .line 656
    .line 657
    const/16 v14, 0x17

    .line 658
    .line 659
    if-ne v5, v14, :cond_2b0

    .line 660
    .line 661
    goto :goto_2ae

    .line 662
    :pswitch_295
    const/16 v37, 0x4

    .line 663
    .line 664
    aget-byte v5, v13, v37

    .line 665
    .line 666
    and-int/lit8 v5, v5, 0x1f

    .line 667
    .line 668
    move/from16 v14, v36

    .line 669
    .line 670
    if-ne v5, v14, :cond_2b0

    .line 671
    .line 672
    goto :goto_2ae

    .line 673
    :pswitch_2a0
    const/16 v37, 0x4

    .line 674
    .line 675
    aget-byte v5, v13, v37

    .line 676
    .line 677
    and-int/lit8 v5, v5, 0x7e

    .line 678
    .line 679
    const/16 v38, 0x1

    .line 680
    .line 681
    shr-int/lit8 v5, v5, 0x1

    .line 682
    .line 683
    const/16 v14, 0x27

    .line 684
    .line 685
    if-ne v5, v14, :cond_2b0

    .line 686
    .line 687
    :goto_2ae
    const/4 v5, 0x1

    .line 688
    goto :goto_2b1

    .line 689
    :cond_2b0
    :goto_2b0
    const/4 v5, 0x0

    .line 690
    :goto_2b1
    iput-boolean v5, v1, Li5/k;->G:Z

    .line 691
    .line 692
    invoke-interface {v2, v4, v9}, Lo4/i0;->g(ILn3/x;)V

    .line 693
    .line 694
    .line 695
    iget v5, v1, Li5/k;->D:I

    .line 696
    .line 697
    add-int/2addr v5, v4

    .line 698
    iput v5, v1, Li5/k;->D:I

    .line 699
    .line 700
    if-lez v4, :cond_2ca

    .line 701
    .line 702
    iget-boolean v5, v1, Li5/k;->F:Z

    .line 703
    .line 704
    if-nez v5, :cond_2ca

    .line 705
    .line 706
    invoke-static {v13, v4, v6}, Lo3/n;->g([BILk3/w;)Z

    .line 707
    .line 708
    .line 709
    move-result v4

    .line 710
    if-eqz v4, :cond_2ca

    .line 711
    .line 712
    const/4 v4, 0x1

    .line 713
    iput-boolean v4, v1, Li5/k;->F:Z

    .line 714
    .line 715
    :cond_2ca
    move/from16 v14, p2

    .line 716
    .line 717
    :goto_2cc
    move-object/from16 v5, v40

    .line 718
    .line 719
    const/16 v36, 0x6

    .line 720
    .line 721
    goto/16 :goto_1fb

    .line 722
    .line 723
    :cond_2d2
    const-string v0, "Invalid NAL length"

    .line 724
    .line 725
    const/4 v2, 0x0

    .line 726
    invoke-static {v0, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 727
    .line 728
    .line 729
    move-result-object v0

    .line 730
    throw v0

    .line 731
    :cond_2da
    move/from16 p2, v14

    .line 732
    .line 733
    iget-boolean v5, v1, Li5/k;->G:Z

    .line 734
    .line 735
    if-eqz v5, :cond_32e

    .line 736
    .line 737
    iget-object v5, v1, Li5/k;->g:Ln3/x;

    .line 738
    .line 739
    invoke-virtual {v5, v4}, Ln3/x;->K(I)V

    .line 740
    .line 741
    .line 742
    iget-object v4, v5, Ln3/x;->a:[B

    .line 743
    .line 744
    iget v14, v1, Li5/k;->E:I

    .line 745
    .line 746
    move-object/from16 v17, v7

    .line 747
    .line 748
    const/4 v7, 0x0

    .line 749
    invoke-interface {v0, v4, v7, v14}, Lo4/o;->readFully([BII)V

    .line 750
    .line 751
    .line 752
    iget v4, v1, Li5/k;->E:I

    .line 753
    .line 754
    invoke-interface {v2, v4, v5}, Lo4/i0;->g(ILn3/x;)V

    .line 755
    .line 756
    .line 757
    iget v4, v1, Li5/k;->E:I

    .line 758
    .line 759
    iget-object v14, v5, Ln3/x;->a:[B

    .line 760
    .line 761
    move/from16 v18, v4

    .line 762
    .line 763
    iget v4, v5, Ln3/x;->c:I

    .line 764
    .line 765
    invoke-static {v14, v4}, Lo3/n;->s([BI)I

    .line 766
    .line 767
    .line 768
    move-result v4

    .line 769
    invoke-virtual {v5, v7}, Ln3/x;->N(I)V

    .line 770
    .line 771
    .line 772
    invoke-virtual {v5, v4}, Ln3/x;->M(I)V

    .line 773
    .line 774
    .line 775
    iget v4, v6, Lk3/w;->r:I

    .line 776
    .line 777
    const/4 v14, -0x1

    .line 778
    if-ne v4, v14, :cond_313

    .line 779
    .line 780
    iget v4, v15, Le6/b;->a:I

    .line 781
    .line 782
    if-eqz v4, :cond_31a

    .line 783
    .line 784
    invoke-virtual {v15, v7}, Le6/b;->w(I)V

    .line 785
    .line 786
    .line 787
    goto :goto_31a

    .line 788
    :cond_313
    iget v7, v15, Le6/b;->a:I

    .line 789
    .line 790
    if-eq v7, v4, :cond_31a

    .line 791
    .line 792
    invoke-virtual {v15, v4}, Le6/b;->w(I)V

    .line 793
    .line 794
    .line 795
    :cond_31a
    :goto_31a
    invoke-virtual {v15, v11, v12, v5}, Le6/b;->a(JLn3/x;)V

    .line 796
    .line 797
    .line 798
    invoke-virtual {v3}, Li5/j;->a()I

    .line 799
    .line 800
    .line 801
    move-result v4

    .line 802
    const/16 v37, 0x4

    .line 803
    .line 804
    and-int/lit8 v4, v4, 0x4

    .line 805
    .line 806
    const/4 v14, 0x0

    .line 807
    if-eqz v4, :cond_32b

    .line 808
    .line 809
    invoke-virtual {v15, v14}, Le6/b;->i(I)V

    .line 810
    .line 811
    .line 812
    :cond_32b
    move/from16 v4, v18

    .line 813
    .line 814
    goto :goto_335

    .line 815
    :cond_32e
    move-object/from16 v17, v7

    .line 816
    .line 817
    const/4 v14, 0x0

    .line 818
    invoke-interface {v2, v0, v4, v14}, Lo4/i0;->e(Lk3/n;IZ)I

    .line 819
    .line 820
    .line 821
    move-result v4

    .line 822
    :goto_335
    iget v5, v1, Li5/k;->D:I

    .line 823
    .line 824
    add-int/2addr v5, v4

    .line 825
    iput v5, v1, Li5/k;->D:I

    .line 826
    .line 827
    iget v5, v1, Li5/k;->E:I

    .line 828
    .line 829
    sub-int/2addr v5, v4

    .line 830
    iput v5, v1, Li5/k;->E:I

    .line 831
    .line 832
    move/from16 v14, p2

    .line 833
    .line 834
    move-object/from16 v7, v17

    .line 835
    .line 836
    goto :goto_2cc

    .line 837
    :cond_344
    move-object/from16 v40, v5

    .line 838
    .line 839
    iget-object v4, v3, Li5/j;->l:Lk3/w;

    .line 840
    .line 841
    if-eqz v4, :cond_36a

    .line 842
    .line 843
    iget-object v5, v6, Lk3/w;->p:Ljava/lang/String;

    .line 844
    .line 845
    invoke-static {v5}, Lo4/a;->n(Ljava/lang/String;)Z

    .line 846
    .line 847
    .line 848
    move-result v5

    .line 849
    if-eqz v5, :cond_36a

    .line 850
    .line 851
    iget v5, v1, Li5/k;->C:I

    .line 852
    .line 853
    iget-object v6, v3, Li5/j;->m:Lk3/w;

    .line 854
    .line 855
    invoke-static {v0, v5, v6}, Lo4/a;->y(Lo4/o;ILk3/w;)Lk3/w;

    .line 856
    .line 857
    .line 858
    move-result-object v5

    .line 859
    iput-object v5, v3, Li5/j;->m:Lk3/w;

    .line 860
    .line 861
    invoke-virtual {v5}, Lk3/w;->a()Lk3/v;

    .line 862
    .line 863
    .line 864
    move-result-object v5

    .line 865
    iget-object v4, v4, Lk3/w;->t:Lk3/r;

    .line 866
    .line 867
    iput-object v4, v5, Lk3/v;->s:Lk3/r;

    .line 868
    .line 869
    invoke-static {v5, v2}, Lxw/a;->h(Lk3/v;Lo4/i0;)V

    .line 870
    .line 871
    .line 872
    const/4 v4, 0x0

    .line 873
    iput-object v4, v3, Li5/j;->l:Lk3/w;

    .line 874
    .line 875
    :cond_36a
    :goto_36a
    iget v4, v1, Li5/k;->D:I

    .line 876
    .line 877
    iget v5, v1, Li5/k;->C:I

    .line 878
    .line 879
    if-ge v4, v5, :cond_37c

    .line 880
    .line 881
    sub-int/2addr v5, v4

    .line 882
    const/4 v14, 0x0

    .line 883
    invoke-interface {v2, v0, v5, v14}, Lo4/i0;->e(Lk3/n;IZ)I

    .line 884
    .line 885
    .line 886
    move-result v4

    .line 887
    iget v5, v1, Li5/k;->D:I

    .line 888
    .line 889
    add-int/2addr v5, v4

    .line 890
    iput v5, v1, Li5/k;->D:I

    .line 891
    .line 892
    goto :goto_36a

    .line 893
    :cond_37c
    invoke-virtual {v3}, Li5/j;->a()I

    .line 894
    .line 895
    .line 896
    move-result v0

    .line 897
    iget-boolean v4, v1, Li5/k;->F:Z

    .line 898
    .line 899
    if-nez v4, :cond_387

    .line 900
    .line 901
    const/high16 v4, 0x4000000

    .line 902
    .line 903
    or-int/2addr v0, v4

    .line 904
    :cond_387
    move/from16 v19, v0

    .line 905
    .line 906
    invoke-virtual {v3}, Li5/j;->b()Li5/v;

    .line 907
    .line 908
    .line 909
    move-result-object v0

    .line 910
    if-eqz v0, :cond_394

    .line 911
    .line 912
    iget-object v0, v0, Li5/v;->c:Lo4/h0;

    .line 913
    .line 914
    move-object/from16 v22, v0

    .line 915
    .line 916
    goto :goto_396

    .line 917
    :cond_394
    const/16 v22, 0x0

    .line 918
    .line 919
    :goto_396
    iget v0, v1, Li5/k;->C:I

    .line 920
    .line 921
    const/16 v21, 0x0

    .line 922
    .line 923
    move/from16 v20, v0

    .line 924
    .line 925
    move-object/from16 v16, v2

    .line 926
    .line 927
    move-wide/from16 v17, v11

    .line 928
    .line 929
    invoke-interface/range {v16 .. v22}, Lo4/i0;->f(JIIILo4/h0;)V

    .line 930
    .line 931
    .line 932
    :cond_3a3
    invoke-virtual/range {v40 .. v40}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 933
    .line 934
    .line 935
    move-result v0

    .line 936
    if-nez v0, :cond_3e0

    .line 937
    .line 938
    invoke-virtual/range {v40 .. v40}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    .line 939
    .line 940
    .line 941
    move-result-object v0

    .line 942
    check-cast v0, Li5/h;

    .line 943
    .line 944
    iget v2, v1, Li5/k;->x:I

    .line 945
    .line 946
    iget v4, v0, Li5/h;->c:I

    .line 947
    .line 948
    sub-int/2addr v2, v4

    .line 949
    iput v2, v1, Li5/k;->x:I

    .line 950
    .line 951
    iget-wide v4, v0, Li5/h;->a:J

    .line 952
    .line 953
    iget-boolean v2, v0, Li5/h;->b:Z

    .line 954
    .line 955
    if-eqz v2, :cond_3be

    .line 956
    .line 957
    add-long v4, v4, v17

    .line 958
    .line 959
    :cond_3be
    if-eqz v10, :cond_3c4

    .line 960
    .line 961
    invoke-virtual {v10, v4, v5}, Ln3/j0;->a(J)J

    .line 962
    .line 963
    .line 964
    move-result-wide v4

    .line 965
    :cond_3c4
    move-wide/from16 v20, v4

    .line 966
    .line 967
    iget-object v2, v1, Li5/k;->I:[Lo4/i0;

    .line 968
    .line 969
    array-length v4, v2

    .line 970
    const/4 v5, 0x0

    .line 971
    :goto_3ca
    if-ge v5, v4, :cond_3a3

    .line 972
    .line 973
    aget-object v19, v2, v5

    .line 974
    .line 975
    iget v6, v0, Li5/h;->c:I

    .line 976
    .line 977
    iget v7, v1, Li5/k;->x:I

    .line 978
    .line 979
    const/16 v25, 0x0

    .line 980
    .line 981
    const/16 v22, 0x1

    .line 982
    .line 983
    move/from16 v23, v6

    .line 984
    .line 985
    move/from16 v24, v7

    .line 986
    .line 987
    invoke-interface/range {v19 .. v25}, Lo4/i0;->f(JIIILo4/h0;)V

    .line 988
    .line 989
    .line 990
    add-int/lit8 v5, v5, 0x1

    .line 991
    .line 992
    goto :goto_3ca

    .line 993
    :cond_3e0
    invoke-virtual {v3}, Li5/j;->c()Z

    .line 994
    .line 995
    .line 996
    move-result v0

    .line 997
    if-nez v0, :cond_3e9

    .line 998
    .line 999
    const/4 v2, 0x0

    .line 1000
    iput-object v2, v1, Li5/k;->B:Li5/j;

    .line 1001
    .line 1002
    :cond_3e9
    const/4 v11, 0x3

    .line 1003
    iput v11, v1, Li5/k;->r:I

    .line 1004
    .line 1005
    const/4 v14, 0x0

    .line 1006
    return v14

    .line 1007
    :cond_3ee
    move/from16 v14, v31

    .line 1008
    .line 1009
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 1010
    .line 1011
    .line 1012
    move-result-wide v3

    .line 1013
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1014
    .line 1015
    .line 1016
    move-result-wide v5

    .line 1017
    sub-long/2addr v3, v5

    .line 1018
    const/16 v6, 0x8

    .line 1019
    .line 1020
    invoke-virtual {v13, v6}, Ln3/x;->K(I)V

    .line 1021
    .line 1022
    .line 1023
    iget-object v5, v13, Ln3/x;->a:[B

    .line 1024
    .line 1025
    const/4 v9, 0x1

    .line 1026
    invoke-interface {v0, v5, v14, v6, v9}, Lo4/o;->f([BIIZ)Z

    .line 1027
    .line 1028
    .line 1029
    move-result v5

    .line 1030
    if-nez v5, :cond_415

    .line 1031
    .line 1032
    new-instance v3, Lo4/s;

    .line 1033
    .line 1034
    iget-wide v4, v1, Li5/k;->z:J

    .line 1035
    .line 1036
    iget-wide v6, v1, Li5/k;->N:J

    .line 1037
    .line 1038
    invoke-direct {v3, v4, v5, v6, v7}, Lo4/s;-><init>(JJ)V

    .line 1039
    .line 1040
    .line 1041
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1042
    .line 1043
    .line 1044
    goto/16 :goto_5d1

    .line 1045
    .line 1046
    :cond_415
    invoke-virtual {v13, v14}, Ln3/x;->N(I)V

    .line 1047
    .line 1048
    .line 1049
    invoke-virtual {v13}, Ln3/x;->m()I

    .line 1050
    .line 1051
    .line 1052
    move-result v5

    .line 1053
    invoke-virtual {v13}, Ln3/x;->m()I

    .line 1054
    .line 1055
    .line 1056
    move-result v6

    .line 1057
    const v7, 0x6d667261

    .line 1058
    .line 1059
    .line 1060
    if-eq v6, v7, :cond_433

    .line 1061
    .line 1062
    new-instance v3, Lo4/s;

    .line 1063
    .line 1064
    iget-wide v4, v1, Li5/k;->z:J

    .line 1065
    .line 1066
    iget-wide v6, v1, Li5/k;->N:J

    .line 1067
    .line 1068
    invoke-direct {v3, v4, v5, v6, v7}, Lo4/s;-><init>(JJ)V

    .line 1069
    .line 1070
    .line 1071
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1072
    .line 1073
    .line 1074
    goto/16 :goto_5d1

    .line 1075
    .line 1076
    :cond_433
    new-instance v6, Ln3/x;

    .line 1077
    .line 1078
    long-to-int v3, v3

    .line 1079
    invoke-direct {v6, v3}, Ln3/x;-><init>(I)V

    .line 1080
    .line 1081
    .line 1082
    iget-object v4, v6, Ln3/x;->a:[B

    .line 1083
    .line 1084
    const/4 v14, 0x0

    .line 1085
    invoke-interface {v0, v4, v14, v3}, Lo4/o;->readFully([BII)V

    .line 1086
    .line 1087
    .line 1088
    const/4 v9, 0x1

    .line 1089
    if-ne v5, v9, :cond_445

    .line 1090
    .line 1091
    const/16 v3, 0x10

    .line 1092
    .line 1093
    goto :goto_447

    .line 1094
    :cond_445
    const/16 v3, 0x8

    .line 1095
    .line 1096
    :goto_447
    invoke-virtual {v6, v3}, Ln3/x;->N(I)V

    .line 1097
    .line 1098
    .line 1099
    new-instance v3, Landroid/util/SparseArray;

    .line 1100
    .line 1101
    invoke-direct {v3}, Landroid/util/SparseArray;-><init>()V

    .line 1102
    .line 1103
    .line 1104
    new-instance v4, Landroid/util/SparseArray;

    .line 1105
    .line 1106
    invoke-direct {v4}, Landroid/util/SparseArray;-><init>()V

    .line 1107
    .line 1108
    .line 1109
    :goto_454
    invoke-virtual {v6}, Ln3/x;->a()I

    .line 1110
    .line 1111
    .line 1112
    move-result v5

    .line 1113
    const/16 v7, 0x8

    .line 1114
    .line 1115
    if-lt v5, v7, :cond_566

    .line 1116
    .line 1117
    iget v5, v6, Ln3/x;->b:I

    .line 1118
    .line 1119
    invoke-virtual {v6}, Ln3/x;->C()J

    .line 1120
    .line 1121
    .line 1122
    move-result-wide v8

    .line 1123
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 1124
    .line 1125
    .line 1126
    move-result v10

    .line 1127
    cmp-long v12, v8, v24

    .line 1128
    .line 1129
    if-nez v12, :cond_477

    .line 1130
    .line 1131
    invoke-virtual {v6}, Ln3/x;->a()I

    .line 1132
    .line 1133
    .line 1134
    move-result v8

    .line 1135
    if-ge v8, v7, :cond_472

    .line 1136
    .line 1137
    goto/16 :goto_566

    .line 1138
    .line 1139
    :cond_472
    invoke-virtual {v6}, Ln3/x;->u()J

    .line 1140
    .line 1141
    .line 1142
    move-result-wide v8

    .line 1143
    goto :goto_481

    .line 1144
    :cond_477
    cmp-long v7, v8, v18

    .line 1145
    .line 1146
    if-nez v7, :cond_481

    .line 1147
    .line 1148
    iget v7, v6, Ln3/x;->c:I

    .line 1149
    .line 1150
    int-to-long v7, v7

    .line 1151
    int-to-long v13, v5

    .line 1152
    sub-long v8, v7, v13

    .line 1153
    .line 1154
    :cond_481
    :goto_481
    if-nez v12, :cond_486

    .line 1155
    .line 1156
    const/16 v7, 0x10

    .line 1157
    .line 1158
    goto :goto_488

    .line 1159
    :cond_486
    const/16 v7, 0x8

    .line 1160
    .line 1161
    :goto_488
    int-to-long v12, v7

    .line 1162
    cmp-long v12, v8, v12

    .line 1163
    .line 1164
    if-ltz v12, :cond_566

    .line 1165
    .line 1166
    iget v12, v6, Ln3/x;->c:I

    .line 1167
    .line 1168
    int-to-long v12, v12

    .line 1169
    int-to-long v14, v5

    .line 1170
    sub-long/2addr v12, v14

    .line 1171
    cmp-long v5, v8, v12

    .line 1172
    .line 1173
    if-lez v5, :cond_498

    .line 1174
    .line 1175
    goto/16 :goto_566

    .line 1176
    .line 1177
    :cond_498
    const v5, 0x74667261

    .line 1178
    .line 1179
    .line 1180
    if-ne v10, v5, :cond_55a

    .line 1181
    .line 1182
    add-int/lit8 v7, v7, 0x10

    .line 1183
    .line 1184
    int-to-long v12, v7

    .line 1185
    cmp-long v5, v8, v12

    .line 1186
    .line 1187
    if-gez v5, :cond_4aa

    .line 1188
    .line 1189
    add-long/2addr v14, v8

    .line 1190
    long-to-int v5, v14

    .line 1191
    invoke-virtual {v6, v5}, Ln3/x;->N(I)V

    .line 1192
    .line 1193
    .line 1194
    goto :goto_454

    .line 1195
    :cond_4aa
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 1196
    .line 1197
    .line 1198
    move-result v5

    .line 1199
    invoke-static {v5}, Li5/e;->e(I)I

    .line 1200
    .line 1201
    .line 1202
    move-result v5

    .line 1203
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 1204
    .line 1205
    .line 1206
    move-result v7

    .line 1207
    invoke-virtual {v11, v7}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 1208
    .line 1209
    .line 1210
    move-result-object v10

    .line 1211
    check-cast v10, Li5/j;

    .line 1212
    .line 1213
    if-nez v10, :cond_4c4

    .line 1214
    .line 1215
    add-long/2addr v14, v8

    .line 1216
    long-to-int v5, v14

    .line 1217
    invoke-virtual {v6, v5}, Ln3/x;->N(I)V

    .line 1218
    .line 1219
    .line 1220
    goto :goto_454

    .line 1221
    :cond_4c4
    iget-object v10, v10, Li5/j;->d:Li5/w;

    .line 1222
    .line 1223
    iget-object v10, v10, Li5/w;->a:Li5/u;

    .line 1224
    .line 1225
    iget-wide v12, v10, Li5/u;->c:J

    .line 1226
    .line 1227
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 1228
    .line 1229
    .line 1230
    move-result v10

    .line 1231
    shr-int/lit8 v16, v10, 0x4

    .line 1232
    .line 1233
    const/16 v39, 0x3

    .line 1234
    .line 1235
    and-int/lit8 v16, v16, 0x3

    .line 1236
    .line 1237
    shr-int/lit8 v17, v10, 0x2

    .line 1238
    .line 1239
    and-int/lit8 v17, v17, 0x3

    .line 1240
    .line 1241
    and-int/lit8 v10, v10, 0x3

    .line 1242
    .line 1243
    move-wide/from16 v26, v8

    .line 1244
    .line 1245
    invoke-virtual {v6}, Ln3/x;->C()J

    .line 1246
    .line 1247
    .line 1248
    move-result-wide v8

    .line 1249
    move/from16 v33, v10

    .line 1250
    .line 1251
    const/4 v10, 0x1

    .line 1252
    if-ne v5, v10, :cond_4ea

    .line 1253
    .line 1254
    move-wide/from16 v35, v22

    .line 1255
    .line 1256
    :goto_4e7
    move/from16 v38, v10

    .line 1257
    .line 1258
    goto :goto_4ed

    .line 1259
    :cond_4ea
    move-wide/from16 v35, v20

    .line 1260
    .line 1261
    goto :goto_4e7

    .line 1262
    :goto_4ed
    add-int/lit8 v10, v16, 0x1

    .line 1263
    .line 1264
    move-wide/from16 v44, v12

    .line 1265
    .line 1266
    int-to-long v12, v10

    .line 1267
    add-long v35, v35, v12

    .line 1268
    .line 1269
    add-int/lit8 v12, v17, 0x1

    .line 1270
    .line 1271
    move-wide/from16 v16, v14

    .line 1272
    .line 1273
    int-to-long v13, v12

    .line 1274
    add-long v35, v35, v13

    .line 1275
    .line 1276
    add-int/lit8 v13, v33, 0x1

    .line 1277
    .line 1278
    int-to-long v14, v13

    .line 1279
    add-long v35, v35, v14

    .line 1280
    .line 1281
    mul-long v35, v35, v8

    .line 1282
    .line 1283
    invoke-virtual {v6}, Ln3/x;->a()I

    .line 1284
    .line 1285
    .line 1286
    move-result v14

    .line 1287
    int-to-long v14, v14

    .line 1288
    cmp-long v14, v35, v14

    .line 1289
    .line 1290
    if-lez v14, :cond_513

    .line 1291
    .line 1292
    add-long v14, v16, v26

    .line 1293
    .line 1294
    long-to-int v5, v14

    .line 1295
    invoke-virtual {v6, v5}, Ln3/x;->N(I)V

    .line 1296
    .line 1297
    .line 1298
    goto/16 :goto_454

    .line 1299
    .line 1300
    :cond_513
    long-to-int v8, v8

    .line 1301
    new-array v9, v8, [J

    .line 1302
    .line 1303
    new-array v14, v8, [J

    .line 1304
    .line 1305
    const/4 v15, 0x0

    .line 1306
    :goto_519
    if-ge v15, v8, :cond_553

    .line 1307
    .line 1308
    move/from16 v33, v8

    .line 1309
    .line 1310
    const/4 v8, 0x1

    .line 1311
    if-ne v5, v8, :cond_527

    .line 1312
    .line 1313
    invoke-virtual {v6}, Ln3/x;->G()J

    .line 1314
    .line 1315
    .line 1316
    move-result-wide v35

    .line 1317
    :goto_524
    move-wide/from16 v40, v35

    .line 1318
    .line 1319
    goto :goto_52c

    .line 1320
    :cond_527
    invoke-virtual {v6}, Ln3/x;->C()J

    .line 1321
    .line 1322
    .line 1323
    move-result-wide v35

    .line 1324
    goto :goto_524

    .line 1325
    :goto_52c
    if-ne v5, v8, :cond_533

    .line 1326
    .line 1327
    invoke-virtual {v6}, Ln3/x;->G()J

    .line 1328
    .line 1329
    .line 1330
    move-result-wide v35

    .line 1331
    goto :goto_537

    .line 1332
    :cond_533
    invoke-virtual {v6}, Ln3/x;->C()J

    .line 1333
    .line 1334
    .line 1335
    move-result-wide v35

    .line 1336
    :goto_537
    add-int v8, v10, v12

    .line 1337
    .line 1338
    add-int/2addr v8, v13

    .line 1339
    invoke-virtual {v6, v8}, Ln3/x;->O(I)V

    .line 1340
    .line 1341
    .line 1342
    cmp-long v8, v44, v29

    .line 1343
    .line 1344
    if-eqz v8, :cond_54a

    .line 1345
    .line 1346
    const-wide/32 v42, 0xf4240

    .line 1347
    .line 1348
    .line 1349
    sget-object v46, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 1350
    .line 1351
    invoke-static/range {v40 .. v46}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1352
    .line 1353
    .line 1354
    move-result-wide v40

    .line 1355
    :cond_54a
    aput-wide v40, v9, v15

    .line 1356
    .line 1357
    aput-wide v35, v14, v15

    .line 1358
    .line 1359
    add-int/lit8 v15, v15, 0x1

    .line 1360
    .line 1361
    move/from16 v8, v33

    .line 1362
    .line 1363
    goto :goto_519

    .line 1364
    :cond_553
    invoke-virtual {v3, v7, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 1365
    .line 1366
    .line 1367
    invoke-virtual {v4, v7, v14}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 1368
    .line 1369
    .line 1370
    goto :goto_55e

    .line 1371
    :cond_55a
    move-wide/from16 v26, v8

    .line 1372
    .line 1373
    move-wide/from16 v16, v14

    .line 1374
    .line 1375
    :goto_55e
    add-long v14, v16, v26

    .line 1376
    .line 1377
    long-to-int v5, v14

    .line 1378
    invoke-virtual {v6, v5}, Ln3/x;->N(I)V

    .line 1379
    .line 1380
    .line 1381
    goto/16 :goto_454

    .line 1382
    .line 1383
    :cond_566
    :goto_566
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 1384
    .line 1385
    .line 1386
    move-result v5

    .line 1387
    if-nez v5, :cond_579

    .line 1388
    .line 1389
    new-instance v3, Lo4/s;

    .line 1390
    .line 1391
    iget-wide v4, v1, Li5/k;->z:J

    .line 1392
    .line 1393
    iget-wide v6, v1, Li5/k;->N:J

    .line 1394
    .line 1395
    invoke-direct {v3, v4, v5, v6, v7}, Lo4/s;-><init>(JJ)V

    .line 1396
    .line 1397
    .line 1398
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1399
    .line 1400
    .line 1401
    goto :goto_5d1

    .line 1402
    :cond_579
    const/4 v5, -0x1

    .line 1403
    const/4 v6, -0x1

    .line 1404
    const/4 v7, 0x0

    .line 1405
    :goto_57c
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 1406
    .line 1407
    .line 1408
    move-result v8

    .line 1409
    if-ge v7, v8, :cond_5aa

    .line 1410
    .line 1411
    invoke-virtual {v3, v7}, Landroid/util/SparseArray;->keyAt(I)I

    .line 1412
    .line 1413
    .line 1414
    move-result v8

    .line 1415
    invoke-virtual {v11, v8}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 1416
    .line 1417
    .line 1418
    move-result-object v9

    .line 1419
    check-cast v9, Li5/j;

    .line 1420
    .line 1421
    if-nez v9, :cond_590

    .line 1422
    .line 1423
    const/4 v14, -0x1

    .line 1424
    goto :goto_5a5

    .line 1425
    :cond_590
    iget-object v9, v9, Li5/j;->d:Li5/w;

    .line 1426
    .line 1427
    iget-object v9, v9, Li5/w;->a:Li5/u;

    .line 1428
    .line 1429
    iget v9, v9, Li5/u;->b:I

    .line 1430
    .line 1431
    const/4 v14, -0x1

    .line 1432
    if-ne v5, v14, :cond_59f

    .line 1433
    .line 1434
    move/from16 v10, v34

    .line 1435
    .line 1436
    if-ne v9, v10, :cond_59f

    .line 1437
    .line 1438
    move v5, v8

    .line 1439
    goto :goto_5a5

    .line 1440
    :cond_59f
    if-ne v6, v14, :cond_5a5

    .line 1441
    .line 1442
    const/4 v10, 0x1

    .line 1443
    if-ne v9, v10, :cond_5a5

    .line 1444
    .line 1445
    move v6, v8

    .line 1446
    :cond_5a5
    :goto_5a5
    add-int/lit8 v7, v7, 0x1

    .line 1447
    .line 1448
    const/16 v34, 0x2

    .line 1449
    .line 1450
    goto :goto_57c

    .line 1451
    :cond_5aa
    const/4 v14, -0x1

    .line 1452
    if-eq v5, v14, :cond_5b0

    .line 1453
    .line 1454
    :goto_5ad
    move/from16 v47, v5

    .line 1455
    .line 1456
    goto :goto_5bb

    .line 1457
    :cond_5b0
    if-eq v6, v14, :cond_5b5

    .line 1458
    .line 1459
    move/from16 v47, v6

    .line 1460
    .line 1461
    goto :goto_5bb

    .line 1462
    :cond_5b5
    const/4 v14, 0x0

    .line 1463
    invoke-virtual {v3, v14}, Landroid/util/SparseArray;->keyAt(I)I

    .line 1464
    .line 1465
    .line 1466
    move-result v5

    .line 1467
    goto :goto_5ad

    .line 1468
    :goto_5bb
    new-instance v40, Li5/i;

    .line 1469
    .line 1470
    iget-wide v5, v1, Li5/k;->z:J

    .line 1471
    .line 1472
    iget-wide v7, v1, Li5/k;->N:J

    .line 1473
    .line 1474
    move-object/from16 v41, v3

    .line 1475
    .line 1476
    move-object/from16 v42, v4

    .line 1477
    .line 1478
    move-wide/from16 v43, v5

    .line 1479
    .line 1480
    move-wide/from16 v45, v7

    .line 1481
    .line 1482
    invoke-direct/range {v40 .. v47}, Li5/i;-><init>(Landroid/util/SparseArray;Landroid/util/SparseArray;JJI)V

    .line 1483
    .line 1484
    .line 1485
    move-object/from16 v3, v40

    .line 1486
    .line 1487
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1488
    .line 1489
    .line 1490
    :goto_5d1
    iget v3, v1, Li5/k;->r:I

    .line 1491
    .line 1492
    if-nez v3, :cond_6

    .line 1493
    .line 1494
    :cond_5d5
    :goto_5d5
    const/16 v38, 0x1

    .line 1495
    .line 1496
    goto/16 :goto_b4c

    .line 1497
    .line 1498
    :cond_5d9
    const/16 v3, 0x10

    .line 1499
    .line 1500
    invoke-virtual {v13, v3}, Ln3/x;->K(I)V

    .line 1501
    .line 1502
    .line 1503
    iget-object v4, v13, Ln3/x;->a:[B

    .line 1504
    .line 1505
    const/4 v9, 0x1

    .line 1506
    const/4 v14, 0x0

    .line 1507
    invoke-interface {v0, v4, v14, v3, v9}, Lo4/o;->b([BIIZ)Z

    .line 1508
    .line 1509
    .line 1510
    move-result v4

    .line 1511
    if-nez v4, :cond_5f5

    .line 1512
    .line 1513
    new-instance v3, Lo4/s;

    .line 1514
    .line 1515
    iget-wide v4, v1, Li5/k;->z:J

    .line 1516
    .line 1517
    iget-wide v6, v1, Li5/k;->N:J

    .line 1518
    .line 1519
    invoke-direct {v3, v4, v5, v6, v7}, Lo4/s;-><init>(JJ)V

    .line 1520
    .line 1521
    .line 1522
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1523
    .line 1524
    .line 1525
    goto :goto_647

    .line 1526
    :cond_5f5
    invoke-virtual {v13, v14}, Ln3/x;->N(I)V

    .line 1527
    .line 1528
    .line 1529
    invoke-virtual {v13}, Ln3/x;->m()I

    .line 1530
    .line 1531
    .line 1532
    move-result v4

    .line 1533
    invoke-virtual {v13}, Ln3/x;->m()I

    .line 1534
    .line 1535
    .line 1536
    move-result v5

    .line 1537
    if-ne v4, v3, :cond_63b

    .line 1538
    .line 1539
    const v3, 0x6d66726f

    .line 1540
    .line 1541
    .line 1542
    if-eq v5, v3, :cond_608

    .line 1543
    .line 1544
    goto :goto_63b

    .line 1545
    :cond_608
    const/4 v14, 0x4

    .line 1546
    invoke-virtual {v13, v14}, Ln3/x;->O(I)V

    .line 1547
    .line 1548
    .line 1549
    invoke-virtual {v13}, Ln3/x;->C()J

    .line 1550
    .line 1551
    .line 1552
    move-result-wide v3

    .line 1553
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 1554
    .line 1555
    .line 1556
    move-result-wide v5

    .line 1557
    sub-long/2addr v5, v3

    .line 1558
    cmp-long v7, v3, v18

    .line 1559
    .line 1560
    if-lez v7, :cond_62e

    .line 1561
    .line 1562
    cmp-long v3, v3, v16

    .line 1563
    .line 1564
    if-gtz v3, :cond_62e

    .line 1565
    .line 1566
    cmp-long v3, v5, v18

    .line 1567
    .line 1568
    if-ltz v3, :cond_62e

    .line 1569
    .line 1570
    iget-wide v3, v1, Li5/k;->N:J

    .line 1571
    .line 1572
    cmp-long v3, v5, v3

    .line 1573
    .line 1574
    if-gez v3, :cond_628

    .line 1575
    .line 1576
    goto :goto_62e

    .line 1577
    :cond_628
    iput-wide v5, v2, Lo4/r;->b:J

    .line 1578
    .line 1579
    const/4 v14, 0x6

    .line 1580
    iput v14, v1, Li5/k;->r:I

    .line 1581
    .line 1582
    goto :goto_647

    .line 1583
    :cond_62e
    :goto_62e
    new-instance v3, Lo4/s;

    .line 1584
    .line 1585
    iget-wide v4, v1, Li5/k;->z:J

    .line 1586
    .line 1587
    iget-wide v6, v1, Li5/k;->N:J

    .line 1588
    .line 1589
    invoke-direct {v3, v4, v5, v6, v7}, Lo4/s;-><init>(JJ)V

    .line 1590
    .line 1591
    .line 1592
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1593
    .line 1594
    .line 1595
    goto :goto_647

    .line 1596
    :cond_63b
    :goto_63b
    new-instance v3, Lo4/s;

    .line 1597
    .line 1598
    iget-wide v4, v1, Li5/k;->z:J

    .line 1599
    .line 1600
    iget-wide v6, v1, Li5/k;->N:J

    .line 1601
    .line 1602
    invoke-direct {v3, v4, v5, v6, v7}, Lo4/s;-><init>(JJ)V

    .line 1603
    .line 1604
    .line 1605
    invoke-virtual {v1, v3, v2}, Li5/k;->c(Lo4/b0;Lo4/r;)V

    .line 1606
    .line 1607
    .line 1608
    :goto_647
    iget v3, v1, Li5/k;->r:I

    .line 1609
    .line 1610
    const/4 v14, 0x6

    .line 1611
    if-eq v3, v14, :cond_5d5

    .line 1612
    .line 1613
    if-nez v3, :cond_6

    .line 1614
    .line 1615
    goto :goto_5d5

    .line 1616
    :cond_64f
    invoke-virtual {v11}, Landroid/util/SparseArray;->size()I

    .line 1617
    .line 1618
    .line 1619
    move-result v3

    .line 1620
    const/4 v4, 0x0

    .line 1621
    const/4 v5, 0x0

    .line 1622
    const-wide v6, 0x7fffffffffffffffL

    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    :goto_65a
    if-ge v4, v3, :cond_678

    .line 1628
    .line 1629
    invoke-virtual {v11, v4}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 1630
    .line 1631
    .line 1632
    move-result-object v8

    .line 1633
    check-cast v8, Li5/j;

    .line 1634
    .line 1635
    iget-object v8, v8, Li5/j;->b:Lds/t;

    .line 1636
    .line 1637
    iget-boolean v9, v8, Lds/t;->l:Z

    .line 1638
    .line 1639
    if-eqz v9, :cond_675

    .line 1640
    .line 1641
    iget-wide v8, v8, Lds/t;->b:J

    .line 1642
    .line 1643
    cmp-long v10, v8, v6

    .line 1644
    .line 1645
    if-gez v10, :cond_675

    .line 1646
    .line 1647
    invoke-virtual {v11, v4}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 1648
    .line 1649
    .line 1650
    move-result-object v5

    .line 1651
    check-cast v5, Li5/j;

    .line 1652
    .line 1653
    move-wide v6, v8

    .line 1654
    :cond_675
    add-int/lit8 v4, v4, 0x1

    .line 1655
    .line 1656
    goto :goto_65a

    .line 1657
    :cond_678
    if-nez v5, :cond_67f

    .line 1658
    .line 1659
    const/4 v11, 0x3

    .line 1660
    iput v11, v1, Li5/k;->r:I

    .line 1661
    .line 1662
    goto/16 :goto_6

    .line 1663
    .line 1664
    :cond_67f
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1665
    .line 1666
    .line 1667
    move-result-wide v3

    .line 1668
    sub-long/2addr v6, v3

    .line 1669
    long-to-int v3, v6

    .line 1670
    if-ltz v3, :cond_69f

    .line 1671
    .line 1672
    invoke-interface {v0, v3}, Lo4/o;->n(I)V

    .line 1673
    .line 1674
    .line 1675
    iget-object v3, v5, Li5/j;->b:Lds/t;

    .line 1676
    .line 1677
    iget-object v4, v3, Lds/t;->q:Ljava/lang/Object;

    .line 1678
    .line 1679
    check-cast v4, Ln3/x;

    .line 1680
    .line 1681
    iget-object v5, v4, Ln3/x;->a:[B

    .line 1682
    .line 1683
    iget v6, v4, Ln3/x;->c:I

    .line 1684
    .line 1685
    const/4 v14, 0x0

    .line 1686
    invoke-interface {v0, v5, v14, v6}, Lo4/o;->readFully([BII)V

    .line 1687
    .line 1688
    .line 1689
    invoke-virtual {v4, v14}, Ln3/x;->N(I)V

    .line 1690
    .line 1691
    .line 1692
    iput-boolean v14, v3, Lds/t;->l:Z

    .line 1693
    .line 1694
    goto/16 :goto_6

    .line 1695
    .line 1696
    :cond_69f
    const-string v0, "Offset to encryption data was negative."

    .line 1697
    .line 1698
    const/4 v2, 0x0

    .line 1699
    invoke-static {v0, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1700
    .line 1701
    .line 1702
    move-result-object v0

    .line 1703
    throw v0

    .line 1704
    :cond_6a7
    move-object/from16 v40, v5

    .line 1705
    .line 1706
    iget-wide v3, v1, Li5/k;->t:J

    .line 1707
    .line 1708
    iget v5, v1, Li5/k;->u:I

    .line 1709
    .line 1710
    int-to-long v13, v5

    .line 1711
    sub-long/2addr v3, v13

    .line 1712
    long-to-int v3, v3

    .line 1713
    iget-object v4, v1, Li5/k;->v:Ln3/x;

    .line 1714
    .line 1715
    if-eqz v4, :cond_873

    .line 1716
    .line 1717
    iget-object v5, v4, Ln3/x;->a:[B

    .line 1718
    .line 1719
    const/16 v8, 0x8

    .line 1720
    .line 1721
    invoke-interface {v0, v5, v8, v3}, Lo4/o;->readFully([BII)V

    .line 1722
    .line 1723
    .line 1724
    new-instance v3, Lo3/d;

    .line 1725
    .line 1726
    iget v5, v1, Li5/k;->s:I

    .line 1727
    .line 1728
    invoke-direct {v3, v5, v4}, Lo3/d;-><init>(ILn3/x;)V

    .line 1729
    .line 1730
    .line 1731
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 1732
    .line 1733
    .line 1734
    move-result v8

    .line 1735
    if-nez v8, :cond_6d5

    .line 1736
    .line 1737
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 1738
    .line 1739
    .line 1740
    move-result-object v4

    .line 1741
    check-cast v4, Lo3/c;

    .line 1742
    .line 1743
    iget-object v4, v4, Lo3/c;->v:Ljava/util/ArrayList;

    .line 1744
    .line 1745
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1746
    .line 1747
    .line 1748
    goto/16 :goto_870

    .line 1749
    .line 1750
    :cond_6d5
    const v3, 0x73696478

    .line 1751
    .line 1752
    .line 1753
    if-ne v5, v3, :cond_728

    .line 1754
    .line 1755
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1756
    .line 1757
    .line 1758
    move-result-wide v5

    .line 1759
    invoke-static {v5, v6, v4}, Li5/k;->j(JLn3/x;)Landroid/util/Pair;

    .line 1760
    .line 1761
    .line 1762
    move-result-object v3

    .line 1763
    iget-object v4, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 1764
    .line 1765
    check-cast v4, Lo4/j;

    .line 1766
    .line 1767
    invoke-virtual {v7, v4}, Lf6/i;->a(Lo4/j;)V

    .line 1768
    .line 1769
    .line 1770
    iget-object v4, v7, Lf6/i;->a:Ljava/util/LinkedHashMap;

    .line 1771
    .line 1772
    iget-object v5, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 1773
    .line 1774
    check-cast v5, Ljava/lang/Long;

    .line 1775
    .line 1776
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 1777
    .line 1778
    .line 1779
    move-result-wide v5

    .line 1780
    iput-wide v5, v1, Li5/k;->A:J

    .line 1781
    .line 1782
    iget-boolean v5, v1, Li5/k;->L:Z

    .line 1783
    .line 1784
    if-nez v5, :cond_711

    .line 1785
    .line 1786
    iget-object v5, v1, Li5/k;->H:Lo4/p;

    .line 1787
    .line 1788
    invoke-interface {v4}, Ljava/util/Map;->size()I

    .line 1789
    .line 1790
    .line 1791
    move-result v6

    .line 1792
    const/4 v10, 0x1

    .line 1793
    if-ne v6, v10, :cond_707

    .line 1794
    .line 1795
    iget-object v3, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 1796
    .line 1797
    check-cast v3, Lo4/b0;

    .line 1798
    .line 1799
    goto :goto_70b

    .line 1800
    :cond_707
    invoke-virtual {v7}, Lf6/i;->c()Lo4/j;

    .line 1801
    .line 1802
    .line 1803
    move-result-object v3

    .line 1804
    :goto_70b
    invoke-interface {v5, v3}, Lo4/p;->E(Lo4/b0;)V

    .line 1805
    .line 1806
    .line 1807
    iput-boolean v10, v1, Li5/k;->K:Z

    .line 1808
    .line 1809
    goto :goto_712

    .line 1810
    :cond_711
    const/4 v10, 0x1

    .line 1811
    :goto_712
    and-int/lit16 v3, v9, 0x100

    .line 1812
    .line 1813
    if-eqz v3, :cond_870

    .line 1814
    .line 1815
    iget-boolean v3, v1, Li5/k;->L:Z

    .line 1816
    .line 1817
    if-nez v3, :cond_870

    .line 1818
    .line 1819
    invoke-interface {v4}, Ljava/util/Map;->size()I

    .line 1820
    .line 1821
    .line 1822
    move-result v3

    .line 1823
    if-le v3, v10, :cond_870

    .line 1824
    .line 1825
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 1826
    .line 1827
    .line 1828
    move-result-wide v3

    .line 1829
    iput-wide v3, v1, Li5/k;->M:J

    .line 1830
    .line 1831
    goto/16 :goto_870

    .line 1832
    .line 1833
    :cond_728
    const v3, 0x656d7367

    .line 1834
    .line 1835
    .line 1836
    if-ne v5, v3, :cond_870

    .line 1837
    .line 1838
    iget-object v3, v1, Li5/k;->I:[Lo4/i0;

    .line 1839
    .line 1840
    array-length v3, v3

    .line 1841
    if-nez v3, :cond_734

    .line 1842
    .line 1843
    goto/16 :goto_870

    .line 1844
    .line 1845
    :cond_734
    const/16 v6, 0x8

    .line 1846
    .line 1847
    invoke-virtual {v4, v6}, Ln3/x;->N(I)V

    .line 1848
    .line 1849
    .line 1850
    invoke-virtual {v4}, Ln3/x;->m()I

    .line 1851
    .line 1852
    .line 1853
    move-result v3

    .line 1854
    invoke-static {v3}, Li5/e;->e(I)I

    .line 1855
    .line 1856
    .line 1857
    move-result v3

    .line 1858
    if-eqz v3, :cond_77f

    .line 1859
    .line 1860
    const/4 v9, 0x1

    .line 1861
    if-eq v3, v9, :cond_74d

    .line 1862
    .line 1863
    const-string v4, "Skipping unsupported emsg version: "

    .line 1864
    .line 1865
    invoke-static {v3, v4, v12}, Lhs/q;->r(ILjava/lang/String;Ljava/lang/String;)V

    .line 1866
    .line 1867
    .line 1868
    goto/16 :goto_870

    .line 1869
    .line 1870
    :cond_74d
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1871
    .line 1872
    .line 1873
    move-result-wide v17

    .line 1874
    invoke-virtual {v4}, Ln3/x;->G()J

    .line 1875
    .line 1876
    .line 1877
    move-result-wide v13

    .line 1878
    sget-object v19, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 1879
    .line 1880
    const-wide/32 v15, 0xf4240

    .line 1881
    .line 1882
    .line 1883
    invoke-static/range {v13 .. v19}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1884
    .line 1885
    .line 1886
    move-result-wide v5

    .line 1887
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1888
    .line 1889
    .line 1890
    move-result-wide v13

    .line 1891
    const-wide/16 v15, 0x3e8

    .line 1892
    .line 1893
    invoke-static/range {v13 .. v19}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1894
    .line 1895
    .line 1896
    move-result-wide v7

    .line 1897
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1898
    .line 1899
    .line 1900
    move-result-wide v11

    .line 1901
    invoke-virtual {v4}, Ln3/x;->v()Ljava/lang/String;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v3

    .line 1905
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1906
    .line 1907
    .line 1908
    invoke-virtual {v4}, Ln3/x;->v()Ljava/lang/String;

    .line 1909
    .line 1910
    .line 1911
    move-result-object v9

    .line 1912
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1913
    .line 1914
    .line 1915
    move-wide v13, v11

    .line 1916
    move-wide v11, v7

    .line 1917
    move-wide/from16 v7, v29

    .line 1918
    .line 1919
    goto :goto_7bb

    .line 1920
    :cond_77f
    invoke-virtual {v4}, Ln3/x;->v()Ljava/lang/String;

    .line 1921
    .line 1922
    .line 1923
    move-result-object v3

    .line 1924
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1925
    .line 1926
    .line 1927
    invoke-virtual {v4}, Ln3/x;->v()Ljava/lang/String;

    .line 1928
    .line 1929
    .line 1930
    move-result-object v9

    .line 1931
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1932
    .line 1933
    .line 1934
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1935
    .line 1936
    .line 1937
    move-result-wide v15

    .line 1938
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1939
    .line 1940
    .line 1941
    move-result-wide v11

    .line 1942
    sget-object v17, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 1943
    .line 1944
    const-wide/32 v13, 0xf4240

    .line 1945
    .line 1946
    .line 1947
    invoke-static/range {v11 .. v17}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1948
    .line 1949
    .line 1950
    move-result-wide v5

    .line 1951
    iget-wide v7, v1, Li5/k;->A:J

    .line 1952
    .line 1953
    cmp-long v11, v7, v29

    .line 1954
    .line 1955
    if-eqz v11, :cond_7a6

    .line 1956
    .line 1957
    add-long/2addr v7, v5

    .line 1958
    goto :goto_7a8

    .line 1959
    :cond_7a6
    move-wide/from16 v7, v29

    .line 1960
    .line 1961
    :goto_7a8
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1962
    .line 1963
    .line 1964
    move-result-wide v11

    .line 1965
    const-wide/16 v13, 0x3e8

    .line 1966
    .line 1967
    invoke-static/range {v11 .. v17}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1968
    .line 1969
    .line 1970
    move-result-wide v11

    .line 1971
    invoke-virtual {v4}, Ln3/x;->C()J

    .line 1972
    .line 1973
    .line 1974
    move-result-wide v13

    .line 1975
    move-wide/from16 v48, v7

    .line 1976
    .line 1977
    move-wide v7, v5

    .line 1978
    move-wide/from16 v5, v48

    .line 1979
    .line 1980
    :goto_7bb
    invoke-virtual {v4}, Ln3/x;->a()I

    .line 1981
    .line 1982
    .line 1983
    move-result v15

    .line 1984
    new-array v15, v15, [B

    .line 1985
    .line 1986
    invoke-virtual {v4}, Ln3/x;->a()I

    .line 1987
    .line 1988
    .line 1989
    move-result v2

    .line 1990
    const/4 v0, 0x0

    .line 1991
    invoke-virtual {v4, v15, v0, v2}, Ln3/x;->k([BII)V

    .line 1992
    .line 1993
    .line 1994
    new-instance v2, Lz4/a;

    .line 1995
    .line 1996
    new-instance v2, Ln3/x;

    .line 1997
    .line 1998
    iget-object v4, v1, Li5/k;->k:Lks/b;

    .line 1999
    .line 2000
    iget-object v0, v4, Lks/b;->b:Ljava/io/DataOutputStream;

    .line 2001
    .line 2002
    iget-object v4, v4, Lks/b;->a:Ljava/io/ByteArrayOutputStream;

    .line 2003
    .line 2004
    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->reset()V

    .line 2005
    .line 2006
    .line 2007
    :try_start_7d6
    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 2008
    .line 2009
    .line 2010
    const/4 v3, 0x0

    .line 2011
    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeByte(I)V

    .line 2012
    .line 2013
    .line 2014
    invoke-virtual {v0, v9}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 2015
    .line 2016
    .line 2017
    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeByte(I)V

    .line 2018
    .line 2019
    .line 2020
    invoke-virtual {v0, v11, v12}, Ljava/io/DataOutputStream;->writeLong(J)V

    .line 2021
    .line 2022
    .line 2023
    invoke-virtual {v0, v13, v14}, Ljava/io/DataOutputStream;->writeLong(J)V

    .line 2024
    .line 2025
    .line 2026
    invoke-virtual {v0, v15}, Ljava/io/OutputStream;->write([B)V

    .line 2027
    .line 2028
    .line 2029
    invoke-virtual {v0}, Ljava/io/DataOutputStream;->flush()V

    .line 2030
    .line 2031
    .line 2032
    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 2033
    .line 2034
    .line 2035
    move-result-object v0
    :try_end_7f3
    .catch Ljava/io/IOException; {:try_start_7d6 .. :try_end_7f3} :catch_869

    .line 2036
    invoke-direct {v2, v0}, Ln3/x;-><init>([B)V

    .line 2037
    .line 2038
    .line 2039
    invoke-virtual {v2}, Ln3/x;->a()I

    .line 2040
    .line 2041
    .line 2042
    move-result v15

    .line 2043
    iget-object v0, v1, Li5/k;->I:[Lo4/i0;

    .line 2044
    .line 2045
    array-length v3, v0

    .line 2046
    const/4 v4, 0x0

    .line 2047
    :goto_7fe
    if-ge v4, v3, :cond_80c

    .line 2048
    .line 2049
    aget-object v9, v0, v4

    .line 2050
    .line 2051
    const/4 v14, 0x0

    .line 2052
    invoke-virtual {v2, v14}, Ln3/x;->N(I)V

    .line 2053
    .line 2054
    .line 2055
    invoke-interface {v9, v15, v2}, Lo4/i0;->g(ILn3/x;)V

    .line 2056
    .line 2057
    .line 2058
    add-int/lit8 v4, v4, 0x1

    .line 2059
    .line 2060
    goto :goto_7fe

    .line 2061
    :cond_80c
    cmp-long v0, v5, v29

    .line 2062
    .line 2063
    if-nez v0, :cond_821

    .line 2064
    .line 2065
    new-instance v0, Li5/h;

    .line 2066
    .line 2067
    const/4 v9, 0x1

    .line 2068
    invoke-direct {v0, v15, v7, v8, v9}, Li5/h;-><init>(IJZ)V

    .line 2069
    .line 2070
    .line 2071
    move-object/from16 v2, v40

    .line 2072
    .line 2073
    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 2074
    .line 2075
    .line 2076
    iget v0, v1, Li5/k;->x:I

    .line 2077
    .line 2078
    add-int/2addr v0, v15

    .line 2079
    iput v0, v1, Li5/k;->x:I

    .line 2080
    .line 2081
    goto :goto_870

    .line 2082
    :cond_821
    move-object/from16 v2, v40

    .line 2083
    .line 2084
    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 2085
    .line 2086
    .line 2087
    move-result v0

    .line 2088
    if-nez v0, :cond_838

    .line 2089
    .line 2090
    new-instance v0, Li5/h;

    .line 2091
    .line 2092
    const/4 v14, 0x0

    .line 2093
    invoke-direct {v0, v15, v5, v6, v14}, Li5/h;-><init>(IJZ)V

    .line 2094
    .line 2095
    .line 2096
    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 2097
    .line 2098
    .line 2099
    iget v0, v1, Li5/k;->x:I

    .line 2100
    .line 2101
    add-int/2addr v0, v15

    .line 2102
    iput v0, v1, Li5/k;->x:I

    .line 2103
    .line 2104
    goto :goto_870

    .line 2105
    :cond_838
    const/4 v14, 0x0

    .line 2106
    if-eqz v10, :cond_84f

    .line 2107
    .line 2108
    invoke-virtual {v10}, Ln3/j0;->e()Z

    .line 2109
    .line 2110
    .line 2111
    move-result v0

    .line 2112
    if-nez v0, :cond_84f

    .line 2113
    .line 2114
    new-instance v0, Li5/h;

    .line 2115
    .line 2116
    invoke-direct {v0, v15, v5, v6, v14}, Li5/h;-><init>(IJZ)V

    .line 2117
    .line 2118
    .line 2119
    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 2120
    .line 2121
    .line 2122
    iget v0, v1, Li5/k;->x:I

    .line 2123
    .line 2124
    add-int/2addr v0, v15

    .line 2125
    iput v0, v1, Li5/k;->x:I

    .line 2126
    .line 2127
    goto :goto_870

    .line 2128
    :cond_84f
    if-eqz v10, :cond_855

    .line 2129
    .line 2130
    invoke-virtual {v10, v5, v6}, Ln3/j0;->a(J)J

    .line 2131
    .line 2132
    .line 2133
    move-result-wide v5

    .line 2134
    :cond_855
    move-wide v12, v5

    .line 2135
    iget-object v0, v1, Li5/k;->I:[Lo4/i0;

    .line 2136
    .line 2137
    array-length v2, v0

    .line 2138
    const/4 v5, 0x0

    .line 2139
    :goto_85a
    if-ge v5, v2, :cond_870

    .line 2140
    .line 2141
    aget-object v11, v0, v5

    .line 2142
    .line 2143
    const/16 v16, 0x0

    .line 2144
    .line 2145
    const/16 v17, 0x0

    .line 2146
    .line 2147
    const/4 v14, 0x1

    .line 2148
    invoke-interface/range {v11 .. v17}, Lo4/i0;->f(JIIILo4/h0;)V

    .line 2149
    .line 2150
    .line 2151
    add-int/lit8 v5, v5, 0x1

    .line 2152
    .line 2153
    goto :goto_85a

    .line 2154
    :catch_869
    move-exception v0

    .line 2155
    new-instance v2, Ljava/lang/RuntimeException;

    .line 2156
    .line 2157
    invoke-direct {v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 2158
    .line 2159
    .line 2160
    throw v2

    .line 2161
    :cond_870
    :goto_870
    move-object/from16 v0, p1

    .line 2162
    .line 2163
    goto :goto_876

    .line 2164
    :cond_873
    invoke-interface {v0, v3}, Lo4/o;->n(I)V

    .line 2165
    .line 2166
    .line 2167
    :goto_876
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 2168
    .line 2169
    .line 2170
    move-result-wide v2

    .line 2171
    invoke-virtual {v1, v2, v3}, Li5/k;->k(J)V

    .line 2172
    .line 2173
    .line 2174
    goto/16 :goto_4

    .line 2175
    .line 2176
    :cond_87f
    move/from16 v35, v14

    .line 2177
    .line 2178
    iget v2, v1, Li5/k;->u:I

    .line 2179
    .line 2180
    const-wide/16 v3, -0x1

    .line 2181
    .line 2182
    iget-object v5, v1, Li5/k;->l:Ln3/x;

    .line 2183
    .line 2184
    if-nez v2, :cond_8cb

    .line 2185
    .line 2186
    iget-object v2, v5, Ln3/x;->a:[B

    .line 2187
    .line 2188
    const/16 v8, 0x8

    .line 2189
    .line 2190
    const/4 v10, 0x1

    .line 2191
    const/4 v14, 0x0

    .line 2192
    invoke-interface {v0, v2, v14, v8, v10}, Lo4/o;->b([BIIZ)Z

    .line 2193
    .line 2194
    .line 2195
    move-result v2

    .line 2196
    if-nez v2, :cond_8b4

    .line 2197
    .line 2198
    iget-wide v5, v1, Li5/k;->M:J

    .line 2199
    .line 2200
    cmp-long v0, v5, v3

    .line 2201
    .line 2202
    if-eqz v0, :cond_8ad

    .line 2203
    .line 2204
    move-object/from16 v2, p2

    .line 2205
    .line 2206
    iput-wide v5, v2, Lo4/r;->b:J

    .line 2207
    .line 2208
    iput-wide v3, v1, Li5/k;->M:J

    .line 2209
    .line 2210
    iget-object v0, v1, Li5/k;->H:Lo4/p;

    .line 2211
    .line 2212
    invoke-virtual {v7}, Lf6/i;->c()Lo4/j;

    .line 2213
    .line 2214
    .line 2215
    move-result-object v2

    .line 2216
    invoke-interface {v0, v2}, Lo4/p;->E(Lo4/b0;)V

    .line 2217
    .line 2218
    .line 2219
    iput-boolean v10, v1, Li5/k;->L:Z

    .line 2220
    .line 2221
    return v10

    .line 2222
    :cond_8ad
    const/4 v14, 0x0

    .line 2223
    invoke-virtual {v15, v14}, Le6/b;->i(I)V

    .line 2224
    .line 2225
    .line 2226
    const/16 v28, -0x1

    .line 2227
    .line 2228
    return v28

    .line 2229
    :cond_8b4
    move-object/from16 v2, p2

    .line 2230
    .line 2231
    const/16 v8, 0x8

    .line 2232
    .line 2233
    const/4 v14, 0x0

    .line 2234
    iput v8, v1, Li5/k;->u:I

    .line 2235
    .line 2236
    invoke-virtual {v5, v14}, Ln3/x;->N(I)V

    .line 2237
    .line 2238
    .line 2239
    invoke-virtual {v5}, Ln3/x;->C()J

    .line 2240
    .line 2241
    .line 2242
    move-result-wide v14

    .line 2243
    iput-wide v14, v1, Li5/k;->t:J

    .line 2244
    .line 2245
    invoke-virtual {v5}, Ln3/x;->m()I

    .line 2246
    .line 2247
    .line 2248
    move-result v8

    .line 2249
    iput v8, v1, Li5/k;->s:I

    .line 2250
    .line 2251
    goto :goto_8cd

    .line 2252
    :cond_8cb
    move-object/from16 v2, p2

    .line 2253
    .line 2254
    :goto_8cd
    iget-wide v14, v1, Li5/k;->t:J

    .line 2255
    .line 2256
    cmp-long v8, v14, v24

    .line 2257
    .line 2258
    if-nez v8, :cond_8e8

    .line 2259
    .line 2260
    iget-object v8, v5, Ln3/x;->a:[B

    .line 2261
    .line 2262
    const/16 v10, 0x8

    .line 2263
    .line 2264
    invoke-interface {v0, v8, v10, v10}, Lo4/o;->readFully([BII)V

    .line 2265
    .line 2266
    .line 2267
    iget v8, v1, Li5/k;->u:I

    .line 2268
    .line 2269
    add-int/2addr v8, v10

    .line 2270
    iput v8, v1, Li5/k;->u:I

    .line 2271
    .line 2272
    invoke-virtual {v5}, Ln3/x;->G()J

    .line 2273
    .line 2274
    .line 2275
    move-result-wide v14

    .line 2276
    iput-wide v14, v1, Li5/k;->t:J

    .line 2277
    .line 2278
    :cond_8e5
    move-wide/from16 v18, v3

    .line 2279
    .line 2280
    goto :goto_914

    .line 2281
    :cond_8e8
    cmp-long v8, v14, v18

    .line 2282
    .line 2283
    if-nez v8, :cond_8e5

    .line 2284
    .line 2285
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 2286
    .line 2287
    .line 2288
    move-result-wide v14

    .line 2289
    cmp-long v8, v14, v3

    .line 2290
    .line 2291
    if-nez v8, :cond_902

    .line 2292
    .line 2293
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 2294
    .line 2295
    .line 2296
    move-result v8

    .line 2297
    if-nez v8, :cond_902

    .line 2298
    .line 2299
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 2300
    .line 2301
    .line 2302
    move-result-object v8

    .line 2303
    check-cast v8, Lo3/c;

    .line 2304
    .line 2305
    iget-wide v14, v8, Lo3/c;->i:J

    .line 2306
    .line 2307
    :cond_902
    cmp-long v8, v14, v3

    .line 2308
    .line 2309
    if-eqz v8, :cond_8e5

    .line 2310
    .line 2311
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 2312
    .line 2313
    .line 2314
    move-result-wide v18

    .line 2315
    sub-long v14, v14, v18

    .line 2316
    .line 2317
    iget v8, v1, Li5/k;->u:I

    .line 2318
    .line 2319
    move-wide/from16 v18, v3

    .line 2320
    .line 2321
    int-to-long v3, v8

    .line 2322
    add-long/2addr v14, v3

    .line 2323
    iput-wide v14, v1, Li5/k;->t:J

    .line 2324
    .line 2325
    :goto_914
    iget-wide v3, v1, Li5/k;->t:J

    .line 2326
    .line 2327
    iget v8, v1, Li5/k;->u:I

    .line 2328
    .line 2329
    int-to-long v14, v8

    .line 2330
    cmp-long v3, v3, v14

    .line 2331
    .line 2332
    if-gez v3, :cond_932

    .line 2333
    .line 2334
    iget v3, v1, Li5/k;->s:I

    .line 2335
    .line 2336
    const v4, 0x66726565

    .line 2337
    .line 2338
    .line 2339
    if-ne v3, v4, :cond_92b

    .line 2340
    .line 2341
    const/16 v10, 0x8

    .line 2342
    .line 2343
    if-ne v8, v10, :cond_92b

    .line 2344
    .line 2345
    iput-wide v14, v1, Li5/k;->t:J

    .line 2346
    .line 2347
    goto :goto_932

    .line 2348
    :cond_92b
    const-string v0, "Atom size less than header length (unsupported)."

    .line 2349
    .line 2350
    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 2351
    .line 2352
    .line 2353
    move-result-object v0

    .line 2354
    throw v0

    .line 2355
    :cond_932
    :goto_932
    iget-wide v3, v1, Li5/k;->M:J

    .line 2356
    .line 2357
    cmp-long v3, v3, v18

    .line 2358
    .line 2359
    if-eqz v3, :cond_978

    .line 2360
    .line 2361
    iget v3, v1, Li5/k;->s:I

    .line 2362
    .line 2363
    const v4, 0x73696478

    .line 2364
    .line 2365
    .line 2366
    if-ne v3, v4, :cond_96b

    .line 2367
    .line 2368
    iget-wide v3, v1, Li5/k;->t:J

    .line 2369
    .line 2370
    long-to-int v3, v3

    .line 2371
    invoke-virtual {v13, v3}, Ln3/x;->K(I)V

    .line 2372
    .line 2373
    .line 2374
    iget-object v3, v5, Ln3/x;->a:[B

    .line 2375
    .line 2376
    iget-object v4, v13, Ln3/x;->a:[B

    .line 2377
    .line 2378
    const/16 v6, 0x8

    .line 2379
    .line 2380
    const/4 v14, 0x0

    .line 2381
    invoke-static {v3, v14, v4, v14, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2382
    .line 2383
    .line 2384
    iget-object v3, v13, Ln3/x;->a:[B

    .line 2385
    .line 2386
    iget-wide v4, v1, Li5/k;->t:J

    .line 2387
    .line 2388
    iget v8, v1, Li5/k;->u:I

    .line 2389
    .line 2390
    int-to-long v8, v8

    .line 2391
    sub-long/2addr v4, v8

    .line 2392
    long-to-int v4, v4

    .line 2393
    invoke-interface {v0, v3, v6, v4}, Lo4/o;->readFully([BII)V

    .line 2394
    .line 2395
    .line 2396
    invoke-interface {v0}, Lo4/o;->g()J

    .line 2397
    .line 2398
    .line 2399
    move-result-wide v3

    .line 2400
    invoke-static {v3, v4, v13}, Li5/k;->j(JLn3/x;)Landroid/util/Pair;

    .line 2401
    .line 2402
    .line 2403
    move-result-object v3

    .line 2404
    iget-object v3, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 2405
    .line 2406
    check-cast v3, Lo4/j;

    .line 2407
    .line 2408
    invoke-virtual {v7, v3}, Lf6/i;->a(Lo4/j;)V

    .line 2409
    .line 2410
    .line 2411
    goto :goto_973

    .line 2412
    :cond_96b
    iget-wide v3, v1, Li5/k;->t:J

    .line 2413
    .line 2414
    sub-long/2addr v3, v14

    .line 2415
    long-to-int v3, v3

    .line 2416
    const/4 v9, 0x1

    .line 2417
    invoke-interface {v0, v3, v9}, Lo4/o;->u(IZ)Z

    .line 2418
    .line 2419
    .line 2420
    :goto_973
    invoke-virtual {v1}, Li5/k;->a()V

    .line 2421
    .line 2422
    .line 2423
    goto/16 :goto_b45

    .line 2424
    .line 2425
    :cond_978
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 2426
    .line 2427
    .line 2428
    move-result-wide v3

    .line 2429
    iget v7, v1, Li5/k;->u:I

    .line 2430
    .line 2431
    int-to-long v7, v7

    .line 2432
    sub-long/2addr v3, v7

    .line 2433
    iget v7, v1, Li5/k;->s:I

    .line 2434
    .line 2435
    const v8, 0x6d646174

    .line 2436
    .line 2437
    .line 2438
    const v10, 0x6d6f6f66

    .line 2439
    .line 2440
    .line 2441
    if-eq v7, v10, :cond_98c

    .line 2442
    .line 2443
    if-ne v7, v8, :cond_9c1

    .line 2444
    .line 2445
    :cond_98c
    iget-boolean v7, v1, Li5/k;->K:Z

    .line 2446
    .line 2447
    if-nez v7, :cond_9c1

    .line 2448
    .line 2449
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 2450
    .line 2451
    .line 2452
    move-result-wide v14

    .line 2453
    cmp-long v7, v14, v18

    .line 2454
    .line 2455
    if-eqz v7, :cond_9b2

    .line 2456
    .line 2457
    iget-wide v14, v1, Li5/k;->N:J

    .line 2458
    .line 2459
    cmp-long v7, v14, v18

    .line 2460
    .line 2461
    if-nez v7, :cond_9b2

    .line 2462
    .line 2463
    and-int/lit16 v7, v9, 0x200

    .line 2464
    .line 2465
    if-eqz v7, :cond_9b2

    .line 2466
    .line 2467
    iput-wide v3, v1, Li5/k;->N:J

    .line 2468
    .line 2469
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 2470
    .line 2471
    .line 2472
    move-result-wide v3

    .line 2473
    sub-long v3, v3, v22

    .line 2474
    .line 2475
    iput-wide v3, v2, Lo4/r;->b:J

    .line 2476
    .line 2477
    move/from16 v3, v35

    .line 2478
    .line 2479
    iput v3, v1, Li5/k;->r:I

    .line 2480
    .line 2481
    goto/16 :goto_b45

    .line 2482
    .line 2483
    :cond_9b2
    iget-object v7, v1, Li5/k;->H:Lo4/p;

    .line 2484
    .line 2485
    new-instance v9, Lo4/s;

    .line 2486
    .line 2487
    iget-wide v14, v1, Li5/k;->z:J

    .line 2488
    .line 2489
    invoke-direct {v9, v14, v15, v3, v4}, Lo4/s;-><init>(JJ)V

    .line 2490
    .line 2491
    .line 2492
    invoke-interface {v7, v9}, Lo4/p;->E(Lo4/b0;)V

    .line 2493
    .line 2494
    .line 2495
    const/4 v9, 0x1

    .line 2496
    iput-boolean v9, v1, Li5/k;->K:Z

    .line 2497
    .line 2498
    :cond_9c1
    iget v7, v1, Li5/k;->s:I

    .line 2499
    .line 2500
    if-ne v7, v10, :cond_9de

    .line 2501
    .line 2502
    invoke-virtual {v11}, Landroid/util/SparseArray;->size()I

    .line 2503
    .line 2504
    .line 2505
    move-result v7

    .line 2506
    const/4 v9, 0x0

    .line 2507
    :goto_9ca
    if-ge v9, v7, :cond_9de

    .line 2508
    .line 2509
    invoke-virtual {v11, v9}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 2510
    .line 2511
    .line 2512
    move-result-object v12

    .line 2513
    check-cast v12, Li5/j;

    .line 2514
    .line 2515
    iget-object v12, v12, Li5/j;->b:Lds/t;

    .line 2516
    .line 2517
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2518
    .line 2519
    .line 2520
    iput-wide v3, v12, Lds/t;->b:J

    .line 2521
    .line 2522
    iput-wide v3, v12, Lds/t;->a:J

    .line 2523
    .line 2524
    add-int/lit8 v9, v9, 0x1

    .line 2525
    .line 2526
    goto :goto_9ca

    .line 2527
    :cond_9de
    iget v7, v1, Li5/k;->s:I

    .line 2528
    .line 2529
    if-ne v7, v8, :cond_9ef

    .line 2530
    .line 2531
    const/4 v8, 0x0

    .line 2532
    iput-object v8, v1, Li5/k;->B:Li5/j;

    .line 2533
    .line 2534
    iget-wide v5, v1, Li5/k;->t:J

    .line 2535
    .line 2536
    add-long/2addr v3, v5

    .line 2537
    iput-wide v3, v1, Li5/k;->w:J

    .line 2538
    .line 2539
    const/4 v10, 0x2

    .line 2540
    iput v10, v1, Li5/k;->r:I

    .line 2541
    .line 2542
    goto/16 :goto_b45

    .line 2543
    .line 2544
    :cond_9ef
    const v3, 0x6d6f6f76

    .line 2545
    .line 2546
    .line 2547
    const v4, 0x6d657461

    .line 2548
    .line 2549
    .line 2550
    if-eq v7, v3, :cond_b01

    .line 2551
    .line 2552
    const v3, 0x7472616b

    .line 2553
    .line 2554
    .line 2555
    if-eq v7, v3, :cond_b01

    .line 2556
    .line 2557
    const v3, 0x6d646961

    .line 2558
    .line 2559
    .line 2560
    if-eq v7, v3, :cond_b01

    .line 2561
    .line 2562
    const v3, 0x6d696e66

    .line 2563
    .line 2564
    .line 2565
    if-eq v7, v3, :cond_b01

    .line 2566
    .line 2567
    const v3, 0x7374626c

    .line 2568
    .line 2569
    .line 2570
    if-eq v7, v3, :cond_b01

    .line 2571
    .line 2572
    if-eq v7, v10, :cond_b01

    .line 2573
    .line 2574
    const v3, 0x74726166

    .line 2575
    .line 2576
    .line 2577
    if-eq v7, v3, :cond_b01

    .line 2578
    .line 2579
    const v3, 0x6d766578

    .line 2580
    .line 2581
    .line 2582
    if-eq v7, v3, :cond_b01

    .line 2583
    .line 2584
    const v3, 0x65647473

    .line 2585
    .line 2586
    .line 2587
    if-eq v7, v3, :cond_b01

    .line 2588
    .line 2589
    if-ne v7, v4, :cond_a20

    .line 2590
    .line 2591
    goto/16 :goto_b01

    .line 2592
    .line 2593
    :cond_a20
    const v3, 0x68646c72    # 4.3148E24f

    .line 2594
    .line 2595
    .line 2596
    if-eq v7, v3, :cond_ad1

    .line 2597
    .line 2598
    const v3, 0x6d646864

    .line 2599
    .line 2600
    .line 2601
    if-eq v7, v3, :cond_ad1

    .line 2602
    .line 2603
    const v3, 0x6d766864

    .line 2604
    .line 2605
    .line 2606
    if-eq v7, v3, :cond_ad1

    .line 2607
    .line 2608
    const v3, 0x73696478

    .line 2609
    .line 2610
    .line 2611
    if-eq v7, v3, :cond_ad1

    .line 2612
    .line 2613
    const v3, 0x73747364

    .line 2614
    .line 2615
    .line 2616
    if-eq v7, v3, :cond_ad1

    .line 2617
    .line 2618
    const v3, 0x73747473

    .line 2619
    .line 2620
    .line 2621
    if-eq v7, v3, :cond_ad1

    .line 2622
    .line 2623
    const v3, 0x63747473

    .line 2624
    .line 2625
    .line 2626
    if-eq v7, v3, :cond_ad1

    .line 2627
    .line 2628
    const v3, 0x73747363

    .line 2629
    .line 2630
    .line 2631
    if-eq v7, v3, :cond_ad1

    .line 2632
    .line 2633
    const v3, 0x7374737a

    .line 2634
    .line 2635
    .line 2636
    if-eq v7, v3, :cond_ad1

    .line 2637
    .line 2638
    const v3, 0x73747a32

    .line 2639
    .line 2640
    .line 2641
    if-eq v7, v3, :cond_ad1

    .line 2642
    .line 2643
    const v3, 0x7374636f

    .line 2644
    .line 2645
    .line 2646
    if-eq v7, v3, :cond_ad1

    .line 2647
    .line 2648
    const v3, 0x636f3634

    .line 2649
    .line 2650
    .line 2651
    if-eq v7, v3, :cond_ad1

    .line 2652
    .line 2653
    const v3, 0x73747373

    .line 2654
    .line 2655
    .line 2656
    if-eq v7, v3, :cond_ad1

    .line 2657
    .line 2658
    const v3, 0x74666474

    .line 2659
    .line 2660
    .line 2661
    if-eq v7, v3, :cond_ad1

    .line 2662
    .line 2663
    const v3, 0x74666864

    .line 2664
    .line 2665
    .line 2666
    if-eq v7, v3, :cond_ad1

    .line 2667
    .line 2668
    const v3, 0x746b6864

    .line 2669
    .line 2670
    .line 2671
    if-eq v7, v3, :cond_ad1

    .line 2672
    .line 2673
    const v3, 0x74726578

    .line 2674
    .line 2675
    .line 2676
    if-eq v7, v3, :cond_ad1

    .line 2677
    .line 2678
    const v3, 0x7472756e

    .line 2679
    .line 2680
    .line 2681
    if-eq v7, v3, :cond_ad1

    .line 2682
    .line 2683
    const v3, 0x70737368    # 3.013775E29f

    .line 2684
    .line 2685
    .line 2686
    if-eq v7, v3, :cond_ad1

    .line 2687
    .line 2688
    const v3, 0x7361697a

    .line 2689
    .line 2690
    .line 2691
    if-eq v7, v3, :cond_ad1

    .line 2692
    .line 2693
    const v3, 0x7361696f

    .line 2694
    .line 2695
    .line 2696
    if-eq v7, v3, :cond_ad1

    .line 2697
    .line 2698
    const v3, 0x73656e63

    .line 2699
    .line 2700
    .line 2701
    if-eq v7, v3, :cond_ad1

    .line 2702
    .line 2703
    const v3, 0x75756964

    .line 2704
    .line 2705
    .line 2706
    if-eq v7, v3, :cond_ad1

    .line 2707
    .line 2708
    const v3, 0x73626770

    .line 2709
    .line 2710
    .line 2711
    if-eq v7, v3, :cond_ad1

    .line 2712
    .line 2713
    const v3, 0x73677064

    .line 2714
    .line 2715
    .line 2716
    if-eq v7, v3, :cond_ad1

    .line 2717
    .line 2718
    const v3, 0x656c7374

    .line 2719
    .line 2720
    .line 2721
    if-eq v7, v3, :cond_ad1

    .line 2722
    .line 2723
    const v3, 0x6d656864

    .line 2724
    .line 2725
    .line 2726
    if-eq v7, v3, :cond_ad1

    .line 2727
    .line 2728
    const v3, 0x656d7367

    .line 2729
    .line 2730
    .line 2731
    if-eq v7, v3, :cond_ad1

    .line 2732
    .line 2733
    const v3, 0x75647461

    .line 2734
    .line 2735
    .line 2736
    if-eq v7, v3, :cond_ad1

    .line 2737
    .line 2738
    const v3, 0x6b657973

    .line 2739
    .line 2740
    .line 2741
    if-eq v7, v3, :cond_ad1

    .line 2742
    .line 2743
    const v3, 0x696c7374

    .line 2744
    .line 2745
    .line 2746
    if-ne v7, v3, :cond_abc

    .line 2747
    .line 2748
    goto :goto_ad1

    .line 2749
    :cond_abc
    iget-wide v3, v1, Li5/k;->t:J

    .line 2750
    .line 2751
    cmp-long v3, v3, v16

    .line 2752
    .line 2753
    if-gtz v3, :cond_aca

    .line 2754
    .line 2755
    const/4 v4, 0x0

    .line 2756
    iput-object v4, v1, Li5/k;->v:Ln3/x;

    .line 2757
    .line 2758
    const/4 v9, 0x1

    .line 2759
    iput v9, v1, Li5/k;->r:I

    .line 2760
    .line 2761
    goto/16 :goto_b45

    .line 2762
    .line 2763
    :cond_aca
    const-string v0, "Skipping atom with length > 2147483647 (unsupported)."

    .line 2764
    .line 2765
    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 2766
    .line 2767
    .line 2768
    move-result-object v0

    .line 2769
    throw v0

    .line 2770
    :cond_ad1
    :goto_ad1
    iget v3, v1, Li5/k;->u:I

    .line 2771
    .line 2772
    const/16 v6, 0x8

    .line 2773
    .line 2774
    if-ne v3, v6, :cond_afa

    .line 2775
    .line 2776
    iget-wide v3, v1, Li5/k;->t:J

    .line 2777
    .line 2778
    cmp-long v3, v3, v16

    .line 2779
    .line 2780
    if-gtz v3, :cond_af3

    .line 2781
    .line 2782
    new-instance v3, Ln3/x;

    .line 2783
    .line 2784
    iget-wide v7, v1, Li5/k;->t:J

    .line 2785
    .line 2786
    long-to-int v4, v7

    .line 2787
    invoke-direct {v3, v4}, Ln3/x;-><init>(I)V

    .line 2788
    .line 2789
    .line 2790
    iget-object v4, v5, Ln3/x;->a:[B

    .line 2791
    .line 2792
    iget-object v5, v3, Ln3/x;->a:[B

    .line 2793
    .line 2794
    const/4 v14, 0x0

    .line 2795
    invoke-static {v4, v14, v5, v14, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2796
    .line 2797
    .line 2798
    iput-object v3, v1, Li5/k;->v:Ln3/x;

    .line 2799
    .line 2800
    const/4 v9, 0x1

    .line 2801
    iput v9, v1, Li5/k;->r:I

    .line 2802
    .line 2803
    goto :goto_b45

    .line 2804
    :cond_af3
    const-string v0, "Leaf atom with length > 2147483647 (unsupported)."

    .line 2805
    .line 2806
    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 2807
    .line 2808
    .line 2809
    move-result-object v0

    .line 2810
    throw v0

    .line 2811
    :cond_afa
    const-string v0, "Leaf atom defines extended atom size (unsupported)."

    .line 2812
    .line 2813
    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 2814
    .line 2815
    .line 2816
    move-result-object v0

    .line 2817
    throw v0

    .line 2818
    :cond_b01
    :goto_b01
    invoke-interface {v0}, Lo4/o;->getPosition()J

    .line 2819
    .line 2820
    .line 2821
    move-result-wide v7

    .line 2822
    iget-wide v9, v1, Li5/k;->t:J

    .line 2823
    .line 2824
    add-long/2addr v7, v9

    .line 2825
    sub-long v7, v7, v20

    .line 2826
    .line 2827
    iget v3, v1, Li5/k;->u:I

    .line 2828
    .line 2829
    int-to-long v11, v3

    .line 2830
    cmp-long v3, v9, v11

    .line 2831
    .line 2832
    if-eqz v3, :cond_b2b

    .line 2833
    .line 2834
    iget v3, v1, Li5/k;->s:I

    .line 2835
    .line 2836
    if-ne v3, v4, :cond_b2b

    .line 2837
    .line 2838
    const/16 v10, 0x8

    .line 2839
    .line 2840
    invoke-virtual {v13, v10}, Ln3/x;->K(I)V

    .line 2841
    .line 2842
    .line 2843
    iget-object v3, v13, Ln3/x;->a:[B

    .line 2844
    .line 2845
    const/4 v14, 0x0

    .line 2846
    invoke-interface {v0, v3, v14, v10}, Lo4/o;->q([BII)V

    .line 2847
    .line 2848
    .line 2849
    invoke-static {v13}, Li5/e;->a(Ln3/x;)V

    .line 2850
    .line 2851
    .line 2852
    iget v3, v13, Ln3/x;->b:I

    .line 2853
    .line 2854
    invoke-interface {v0, v3}, Lo4/o;->n(I)V

    .line 2855
    .line 2856
    .line 2857
    invoke-interface {v0}, Lo4/o;->m()V

    .line 2858
    .line 2859
    .line 2860
    :cond_b2b
    new-instance v3, Lo3/c;

    .line 2861
    .line 2862
    iget v4, v1, Li5/k;->s:I

    .line 2863
    .line 2864
    invoke-direct {v3, v4, v7, v8}, Lo3/c;-><init>(IJ)V

    .line 2865
    .line 2866
    .line 2867
    invoke-virtual {v6, v3}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    .line 2868
    .line 2869
    .line 2870
    iget-wide v3, v1, Li5/k;->t:J

    .line 2871
    .line 2872
    iget v5, v1, Li5/k;->u:I

    .line 2873
    .line 2874
    int-to-long v5, v5

    .line 2875
    cmp-long v3, v3, v5

    .line 2876
    .line 2877
    if-nez v3, :cond_b42

    .line 2878
    .line 2879
    invoke-virtual {v1, v7, v8}, Li5/k;->k(J)V

    .line 2880
    .line 2881
    .line 2882
    goto :goto_b45

    .line 2883
    :cond_b42
    invoke-virtual {v1}, Li5/k;->a()V

    .line 2884
    .line 2885
    .line 2886
    :goto_b45
    iget v3, v1, Li5/k;->r:I

    .line 2887
    .line 2888
    const/4 v4, 0x5

    .line 2889
    if-ne v3, v4, :cond_6

    .line 2890
    .line 2891
    goto/16 :goto_5d5

    .line 2892
    .line 2893
    :goto_b4c
    return v38

    .line 2894
    nop

    :sswitch_data_b4e
    .sparse-switch
        -0x63185e82 -> :sswitch_27c
        0x4f62373a -> :sswitch_273
        0x4f62860f -> :sswitch_267
    .end sparse-switch

    :pswitch_data_b5c
    .packed-switch 0x0
        :pswitch_2a0
        :pswitch_295
        :pswitch_288
    .end packed-switch
.end method

.method public final h()Ljava/util/List;
    .registers 2

    .line 1
    iget-object v0, p0, Li5/k;->q:Lhx/w1;

    .line 2
    .line 3
    return-object v0
.end method

.method public final k(J)V
    .registers 59

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    :cond_2
    :goto_2
    iget-object v1, v0, Li5/k;->m:Ljava/util/ArrayDeque;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-nez v2, :cond_85b

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    check-cast v2, Lo3/c;

    .line 16
    .line 17
    iget-wide v2, v2, Lo3/c;->i:J

    .line 18
    .line 19
    cmp-long v2, v2, p1

    .line 20
    .line 21
    if-nez v2, :cond_85b

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    move-object v3, v2

    .line 28
    check-cast v3, Lo3/c;

    .line 29
    .line 30
    iget v2, v3, Lcz/j;->e:I

    .line 31
    .line 32
    iget-object v4, v3, Lo3/c;->w:Ljava/util/ArrayList;

    .line 33
    .line 34
    iget-object v5, v3, Lo3/c;->v:Ljava/util/ArrayList;

    .line 35
    .line 36
    const v6, 0x6d6f6f76

    .line 37
    .line 38
    .line 39
    const/4 v7, 0x0

    .line 40
    const/16 v9, 0xc

    .line 41
    .line 42
    iget-object v14, v0, Li5/k;->d:Landroid/util/SparseArray;

    .line 43
    .line 44
    iget v15, v0, Li5/k;->b:I

    .line 45
    .line 46
    if-ne v2, v6, :cond_241

    .line 47
    .line 48
    move-object v6, v7

    .line 49
    invoke-static {v5}, Li5/k;->b(Ljava/util/List;)Lk3/r;

    .line 50
    .line 51
    .line 52
    move-result-object v7

    .line 53
    const v1, 0x6d766578

    .line 54
    .line 55
    .line 56
    invoke-virtual {v3, v1}, Lo3/c;->o(I)Lo3/c;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    new-instance v2, Landroid/util/SparseArray;

    .line 64
    .line 65
    invoke-direct {v2}, Landroid/util/SparseArray;-><init>()V

    .line 66
    .line 67
    .line 68
    iget-object v1, v1, Lo3/c;->v:Ljava/util/ArrayList;

    .line 69
    .line 70
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 71
    .line 72
    .line 73
    move-result v4

    .line 74
    const/4 v5, 0x0

    .line 75
    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    :goto_4f
    if-ge v5, v4, :cond_c6

    .line 81
    .line 82
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v16

    .line 86
    move-object/from16 v6, v16

    .line 87
    .line 88
    check-cast v6, Lo3/d;

    .line 89
    .line 90
    const/16 v16, 0x0

    .line 91
    .line 92
    iget v12, v6, Lcz/j;->e:I

    .line 93
    .line 94
    iget-object v6, v6, Lo3/d;->i:Ln3/x;

    .line 95
    .line 96
    const/16 v18, 0x1

    .line 97
    .line 98
    const v13, 0x74726578

    .line 99
    .line 100
    .line 101
    if-ne v12, v13, :cond_9e

    .line 102
    .line 103
    invoke-virtual {v6, v9}, Ln3/x;->N(I)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 107
    .line 108
    .line 109
    move-result v12

    .line 110
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 111
    .line 112
    .line 113
    move-result v13

    .line 114
    add-int/lit8 v13, v13, -0x1

    .line 115
    .line 116
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 117
    .line 118
    .line 119
    move-result v9

    .line 120
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 121
    .line 122
    .line 123
    move-result v8

    .line 124
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 125
    .line 126
    .line 127
    move-result v6

    .line 128
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 129
    .line 130
    .line 131
    move-result-object v12

    .line 132
    move-object/from16 v21, v1

    .line 133
    .line 134
    new-instance v1, Li5/f;

    .line 135
    .line 136
    invoke-direct {v1, v13, v9, v8, v6}, Li5/f;-><init>(IIII)V

    .line 137
    .line 138
    .line 139
    invoke-static {v12, v1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    iget-object v6, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v6, Ljava/lang/Integer;

    .line 146
    .line 147
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 148
    .line 149
    .line 150
    move-result v6

    .line 151
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast v1, Li5/f;

    .line 154
    .line 155
    invoke-virtual {v2, v6, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    goto :goto_be

    .line 159
    :cond_9e
    move-object/from16 v21, v1

    .line 160
    .line 161
    const v1, 0x6d656864

    .line 162
    .line 163
    .line 164
    if-ne v12, v1, :cond_be

    .line 165
    .line 166
    const/16 v1, 0x8

    .line 167
    .line 168
    invoke-virtual {v6, v1}, Ln3/x;->N(I)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    invoke-static {v1}, Li5/e;->e(I)I

    .line 176
    .line 177
    .line 178
    move-result v1

    .line 179
    if-nez v1, :cond_b9

    .line 180
    .line 181
    invoke-virtual {v6}, Ln3/x;->C()J

    .line 182
    .line 183
    .line 184
    move-result-wide v8

    .line 185
    goto :goto_bd

    .line 186
    :cond_b9
    invoke-virtual {v6}, Ln3/x;->G()J

    .line 187
    .line 188
    .line 189
    move-result-wide v8

    .line 190
    :goto_bd
    move-wide v10, v8

    .line 191
    :cond_be
    :goto_be
    add-int/lit8 v5, v5, 0x1

    .line 192
    .line 193
    move-object/from16 v1, v21

    .line 194
    .line 195
    const/4 v6, 0x0

    .line 196
    const/16 v9, 0xc

    .line 197
    .line 198
    goto :goto_4f

    .line 199
    :cond_c6
    const/16 v16, 0x0

    .line 200
    .line 201
    const/16 v18, 0x1

    .line 202
    .line 203
    const v1, 0x6d657461

    .line 204
    .line 205
    .line 206
    invoke-virtual {v3, v1}, Lo3/c;->o(I)Lo3/c;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    if-eqz v1, :cond_d8

    .line 211
    .line 212
    invoke-static {v1}, Li5/e;->f(Lo3/c;)Lk3/t0;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    goto :goto_d9

    .line 217
    :cond_d8
    const/4 v1, 0x0

    .line 218
    :goto_d9
    new-instance v4, Lo4/w;

    .line 219
    .line 220
    invoke-direct {v4}, Lo4/w;-><init>()V

    .line 221
    .line 222
    .line 223
    const v5, 0x75647461

    .line 224
    .line 225
    .line 226
    invoke-virtual {v3, v5}, Lo3/c;->p(I)Lo3/d;

    .line 227
    .line 228
    .line 229
    move-result-object v5

    .line 230
    if-eqz v5, :cond_f9

    .line 231
    .line 232
    and-int/lit16 v6, v15, 0x400

    .line 233
    .line 234
    if-eqz v6, :cond_ee

    .line 235
    .line 236
    move/from16 v6, v18

    .line 237
    .line 238
    goto :goto_f0

    .line 239
    :cond_ee
    move/from16 v6, v16

    .line 240
    .line 241
    :goto_f0
    invoke-static {v5, v6}, Li5/e;->k(Lo3/d;Z)Lk3/t0;

    .line 242
    .line 243
    .line 244
    move-result-object v5

    .line 245
    invoke-virtual {v4, v5}, Lo4/w;->b(Lk3/t0;)V

    .line 246
    .line 247
    .line 248
    move-object v12, v5

    .line 249
    goto :goto_fa

    .line 250
    :cond_f9
    const/4 v12, 0x0

    .line 251
    :goto_fa
    new-instance v13, Lk3/t0;

    .line 252
    .line 253
    const v5, 0x6d766864

    .line 254
    .line 255
    .line 256
    invoke-virtual {v3, v5}, Lo3/c;->p(I)Lo3/d;

    .line 257
    .line 258
    .line 259
    move-result-object v5

    .line 260
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 261
    .line 262
    .line 263
    iget-object v5, v5, Lo3/d;->i:Ln3/x;

    .line 264
    .line 265
    invoke-static {v5}, Li5/e;->g(Ln3/x;)Lo3/f;

    .line 266
    .line 267
    .line 268
    move-result-object v5

    .line 269
    move/from16 v6, v18

    .line 270
    .line 271
    new-array v8, v6, [Lk3/s0;

    .line 272
    .line 273
    aput-object v5, v8, v16

    .line 274
    .line 275
    invoke-direct {v13, v8}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 276
    .line 277
    .line 278
    and-int/lit8 v5, v15, 0x10

    .line 279
    .line 280
    if-eqz v5, :cond_11c

    .line 281
    .line 282
    const/4 v8, 0x1

    .line 283
    :goto_11a
    move-wide v5, v10

    .line 284
    goto :goto_11f

    .line 285
    :cond_11c
    move/from16 v8, v16

    .line 286
    .line 287
    goto :goto_11a

    .line 288
    :goto_11f
    new-instance v10, Li5/g;

    .line 289
    .line 290
    invoke-direct {v10, v0}, Li5/g;-><init>(Li5/k;)V

    .line 291
    .line 292
    .line 293
    const/4 v11, 0x0

    .line 294
    const/4 v9, 0x0

    .line 295
    invoke-static/range {v3 .. v11}, Li5/e;->j(Lo3/c;Lo4/w;JLk3/r;ZZLgx/k;Z)Ljava/util/ArrayList;

    .line 296
    .line 297
    .line 298
    move-result-object v3

    .line 299
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 300
    .line 301
    .line 302
    move-result v5

    .line 303
    invoke-virtual {v14}, Landroid/util/SparseArray;->size()I

    .line 304
    .line 305
    .line 306
    move-result v6

    .line 307
    if-nez v6, :cond_1d2

    .line 308
    .line 309
    invoke-static {v3}, Li5/s;->b(Ljava/util/ArrayList;)Ljava/lang/String;

    .line 310
    .line 311
    .line 312
    move-result-object v6

    .line 313
    move/from16 v7, v16

    .line 314
    .line 315
    :goto_13a
    if-ge v7, v5, :cond_1cb

    .line 316
    .line 317
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object v8

    .line 321
    check-cast v8, Li5/w;

    .line 322
    .line 323
    iget-object v9, v8, Li5/w;->a:Li5/u;

    .line 324
    .line 325
    iget-boolean v10, v9, Li5/u;->m:Z

    .line 326
    .line 327
    iget v11, v9, Li5/u;->a:I

    .line 328
    .line 329
    iget-object v15, v9, Li5/u;->g:Lk3/w;

    .line 330
    .line 331
    move/from16 v17, v5

    .line 332
    .line 333
    move-object/from16 v19, v6

    .line 334
    .line 335
    iget-wide v5, v9, Li5/u;->e:J

    .line 336
    .line 337
    iget v9, v9, Li5/u;->b:I

    .line 338
    .line 339
    if-nez v10, :cond_159

    .line 340
    .line 341
    move-object/from16 v21, v3

    .line 342
    .line 343
    move/from16 v20, v7

    .line 344
    .line 345
    goto :goto_1bf

    .line 346
    :cond_159
    iget-object v10, v0, Li5/k;->H:Lo4/p;

    .line 347
    .line 348
    invoke-interface {v10, v7, v9}, Lo4/p;->o(II)Lo4/i0;

    .line 349
    .line 350
    .line 351
    move-result-object v10

    .line 352
    invoke-interface {v10, v5, v6}, Lo4/i0;->b(J)V

    .line 353
    .line 354
    .line 355
    move/from16 v20, v7

    .line 356
    .line 357
    invoke-virtual {v15}, Lk3/w;->a()Lk3/v;

    .line 358
    .line 359
    .line 360
    move-result-object v7

    .line 361
    move-object/from16 v21, v3

    .line 362
    .line 363
    invoke-static/range {v19 .. v19}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 364
    .line 365
    .line 366
    move-result-object v3

    .line 367
    iput-object v3, v7, Lk3/v;->n:Ljava/lang/String;

    .line 368
    .line 369
    const/4 v3, 0x1

    .line 370
    if-ne v9, v3, :cond_183

    .line 371
    .line 372
    iget v3, v4, Lo4/w;->a:I

    .line 373
    .line 374
    move-wide/from16 v22, v5

    .line 375
    .line 376
    const/4 v5, -0x1

    .line 377
    if-eq v3, v5, :cond_185

    .line 378
    .line 379
    iget v6, v4, Lo4/w;->b:I

    .line 380
    .line 381
    if-eq v6, v5, :cond_185

    .line 382
    .line 383
    iput v3, v7, Lk3/v;->M:I

    .line 384
    .line 385
    iput v6, v7, Lk3/v;->N:I

    .line 386
    .line 387
    goto :goto_185

    .line 388
    :cond_183
    move-wide/from16 v22, v5

    .line 389
    .line 390
    :cond_185
    :goto_185
    iget-object v3, v15, Lk3/w;->m:Lk3/t0;

    .line 391
    .line 392
    filled-new-array {v12, v13}, [Lk3/t0;

    .line 393
    .line 394
    .line 395
    move-result-object v5

    .line 396
    invoke-static {v9, v1, v7, v3, v5}, Li5/s;->k(ILk3/t0;Lk3/v;Lk3/t0;[Lk3/t0;)V

    .line 397
    .line 398
    .line 399
    new-instance v3, Li5/j;

    .line 400
    .line 401
    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    .line 402
    .line 403
    .line 404
    move-result v5

    .line 405
    const/4 v6, 0x1

    .line 406
    if-ne v5, v6, :cond_1a0

    .line 407
    .line 408
    move/from16 v5, v16

    .line 409
    .line 410
    invoke-virtual {v2, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 411
    .line 412
    .line 413
    move-result-object v6

    .line 414
    check-cast v6, Li5/f;

    .line 415
    .line 416
    goto :goto_1aa

    .line 417
    :cond_1a0
    invoke-virtual {v2, v11}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object v5

    .line 421
    move-object v6, v5

    .line 422
    check-cast v6, Li5/f;

    .line 423
    .line 424
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 425
    .line 426
    .line 427
    :goto_1aa
    new-instance v5, Lk3/w;

    .line 428
    .line 429
    invoke-direct {v5, v7}, Lk3/w;-><init>(Lk3/v;)V

    .line 430
    .line 431
    .line 432
    invoke-direct {v3, v10, v8, v6, v5}, Li5/j;-><init>(Lo4/i0;Li5/w;Li5/f;Lk3/w;)V

    .line 433
    .line 434
    .line 435
    invoke-virtual {v14, v11, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    iget-wide v5, v0, Li5/k;->z:J

    .line 439
    .line 440
    move-wide/from16 v7, v22

    .line 441
    .line 442
    invoke-static {v5, v6, v7, v8}, Ljava/lang/Math;->max(JJ)J

    .line 443
    .line 444
    .line 445
    move-result-wide v5

    .line 446
    iput-wide v5, v0, Li5/k;->z:J

    .line 447
    .line 448
    :goto_1bf
    add-int/lit8 v7, v20, 0x1

    .line 449
    .line 450
    move/from16 v5, v17

    .line 451
    .line 452
    move-object/from16 v6, v19

    .line 453
    .line 454
    move-object/from16 v3, v21

    .line 455
    .line 456
    const/16 v16, 0x0

    .line 457
    .line 458
    goto/16 :goto_13a

    .line 459
    .line 460
    :cond_1cb
    iget-object v1, v0, Li5/k;->H:Lo4/p;

    .line 461
    .line 462
    invoke-interface {v1}, Lo4/p;->k()V

    .line 463
    .line 464
    .line 465
    goto/16 :goto_2

    .line 466
    .line 467
    :cond_1d2
    move-object/from16 v21, v3

    .line 468
    .line 469
    move v4, v5

    .line 470
    const/4 v1, 0x0

    .line 471
    const/4 v3, 0x0

    .line 472
    :goto_1d7
    if-ge v1, v4, :cond_1ee

    .line 473
    .line 474
    move-object/from16 v5, v21

    .line 475
    .line 476
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v6

    .line 480
    check-cast v6, Li5/w;

    .line 481
    .line 482
    iget-object v6, v6, Li5/w;->a:Li5/u;

    .line 483
    .line 484
    iget-boolean v6, v6, Li5/u;->m:Z

    .line 485
    .line 486
    if-eqz v6, :cond_1e9

    .line 487
    .line 488
    add-int/lit8 v3, v3, 0x1

    .line 489
    .line 490
    :cond_1e9
    add-int/lit8 v1, v1, 0x1

    .line 491
    .line 492
    move-object/from16 v21, v5

    .line 493
    .line 494
    goto :goto_1d7

    .line 495
    :cond_1ee
    move-object/from16 v5, v21

    .line 496
    .line 497
    invoke-virtual {v14}, Landroid/util/SparseArray;->size()I

    .line 498
    .line 499
    .line 500
    move-result v1

    .line 501
    if-ne v1, v3, :cond_1f8

    .line 502
    .line 503
    const/4 v1, 0x1

    .line 504
    goto :goto_1f9

    .line 505
    :cond_1f8
    const/4 v1, 0x0

    .line 506
    :goto_1f9
    invoke-static {v1}, Loq/a;->z(Z)V

    .line 507
    .line 508
    .line 509
    const/4 v1, 0x0

    .line 510
    :goto_1fd
    if-ge v1, v4, :cond_2

    .line 511
    .line 512
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object v3

    .line 516
    check-cast v3, Li5/w;

    .line 517
    .line 518
    iget-object v6, v3, Li5/w;->a:Li5/u;

    .line 519
    .line 520
    iget-boolean v7, v6, Li5/u;->m:Z

    .line 521
    .line 522
    iget v6, v6, Li5/u;->a:I

    .line 523
    .line 524
    if-nez v7, :cond_20e

    .line 525
    .line 526
    goto :goto_23e

    .line 527
    :cond_20e
    invoke-virtual {v14, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object v7

    .line 531
    check-cast v7, Li5/j;

    .line 532
    .line 533
    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    .line 534
    .line 535
    .line 536
    move-result v8

    .line 537
    const/4 v9, 0x1

    .line 538
    if-ne v8, v9, :cond_223

    .line 539
    .line 540
    const/4 v8, 0x0

    .line 541
    invoke-virtual {v2, v8}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 542
    .line 543
    .line 544
    move-result-object v6

    .line 545
    check-cast v6, Li5/f;

    .line 546
    .line 547
    goto :goto_22c

    .line 548
    :cond_223
    invoke-virtual {v2, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 549
    .line 550
    .line 551
    move-result-object v6

    .line 552
    check-cast v6, Li5/f;

    .line 553
    .line 554
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 555
    .line 556
    .line 557
    :goto_22c
    iput-object v3, v7, Li5/j;->d:Li5/w;

    .line 558
    .line 559
    iput-object v6, v7, Li5/j;->e:Li5/f;

    .line 560
    .line 561
    iget-object v3, v7, Li5/j;->l:Lk3/w;

    .line 562
    .line 563
    if-nez v3, :cond_23b

    .line 564
    .line 565
    iget-object v3, v7, Li5/j;->a:Lo4/i0;

    .line 566
    .line 567
    iget-object v6, v7, Li5/j;->m:Lk3/w;

    .line 568
    .line 569
    invoke-interface {v3, v6}, Lo4/i0;->d(Lk3/w;)V

    .line 570
    .line 571
    .line 572
    :cond_23b
    invoke-virtual {v7}, Li5/j;->e()V

    .line 573
    .line 574
    .line 575
    :goto_23e
    add-int/lit8 v1, v1, 0x1

    .line 576
    .line 577
    goto :goto_1fd

    .line 578
    :cond_241
    const v6, 0x6d6f6f66

    .line 579
    .line 580
    .line 581
    if-ne v2, v6, :cond_848

    .line 582
    .line 583
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 584
    .line 585
    .line 586
    move-result v1

    .line 587
    const/4 v2, 0x0

    .line 588
    :goto_24b
    if-ge v2, v1, :cond_7b7

    .line 589
    .line 590
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 591
    .line 592
    .line 593
    move-result-object v3

    .line 594
    check-cast v3, Lo3/c;

    .line 595
    .line 596
    iget v6, v3, Lcz/j;->e:I

    .line 597
    .line 598
    const v7, 0x74726166

    .line 599
    .line 600
    .line 601
    if-ne v6, v7, :cond_798

    .line 602
    .line 603
    const v6, 0x74666864

    .line 604
    .line 605
    .line 606
    invoke-virtual {v3, v6}, Lo3/c;->p(I)Lo3/d;

    .line 607
    .line 608
    .line 609
    move-result-object v6

    .line 610
    iget-object v7, v3, Lo3/c;->v:Ljava/util/ArrayList;

    .line 611
    .line 612
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 613
    .line 614
    .line 615
    iget-object v6, v6, Lo3/d;->i:Ln3/x;

    .line 616
    .line 617
    const/16 v8, 0x8

    .line 618
    .line 619
    invoke-virtual {v6, v8}, Ln3/x;->N(I)V

    .line 620
    .line 621
    .line 622
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 623
    .line 624
    .line 625
    move-result v8

    .line 626
    sget-object v9, Li5/e;->a:[B

    .line 627
    .line 628
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 629
    .line 630
    .line 631
    move-result v9

    .line 632
    invoke-virtual {v14, v9}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 633
    .line 634
    .line 635
    move-result-object v9

    .line 636
    check-cast v9, Li5/j;

    .line 637
    .line 638
    if-nez v9, :cond_288

    .line 639
    .line 640
    move/from16 v23, v1

    .line 641
    .line 642
    const/4 v9, 0x0

    .line 643
    const-wide v21, -0x7fffffffffffffffL    # -4.9E-324

    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    goto :goto_2dc

    .line 649
    :cond_288
    iget-object v12, v9, Li5/j;->b:Lds/t;

    .line 650
    .line 651
    and-int/lit8 v13, v8, 0x1

    .line 652
    .line 653
    const-wide v21, -0x7fffffffffffffffL    # -4.9E-324

    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    if-eqz v13, :cond_29b

    .line 659
    .line 660
    invoke-virtual {v6}, Ln3/x;->G()J

    .line 661
    .line 662
    .line 663
    move-result-wide v10

    .line 664
    iput-wide v10, v12, Lds/t;->a:J

    .line 665
    .line 666
    iput-wide v10, v12, Lds/t;->b:J

    .line 667
    .line 668
    :cond_29b
    iget-object v10, v9, Li5/j;->e:Li5/f;

    .line 669
    .line 670
    and-int/lit8 v11, v8, 0x2

    .line 671
    .line 672
    if-eqz v11, :cond_2aa

    .line 673
    .line 674
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 675
    .line 676
    .line 677
    move-result v11

    .line 678
    const/16 v18, 0x1

    .line 679
    .line 680
    add-int/lit8 v11, v11, -0x1

    .line 681
    .line 682
    goto :goto_2ac

    .line 683
    :cond_2aa
    iget v11, v10, Li5/f;->a:I

    .line 684
    .line 685
    :goto_2ac
    and-int/lit8 v13, v8, 0x8

    .line 686
    .line 687
    if-eqz v13, :cond_2b5

    .line 688
    .line 689
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 690
    .line 691
    .line 692
    move-result v13

    .line 693
    goto :goto_2b7

    .line 694
    :cond_2b5
    iget v13, v10, Li5/f;->b:I

    .line 695
    .line 696
    :goto_2b7
    and-int/lit8 v23, v8, 0x10

    .line 697
    .line 698
    if-eqz v23, :cond_2c6

    .line 699
    .line 700
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 701
    .line 702
    .line 703
    move-result v23

    .line 704
    move/from16 v55, v23

    .line 705
    .line 706
    move/from16 v23, v1

    .line 707
    .line 708
    move/from16 v1, v55

    .line 709
    .line 710
    goto :goto_2ca

    .line 711
    :cond_2c6
    move/from16 v23, v1

    .line 712
    .line 713
    iget v1, v10, Li5/f;->c:I

    .line 714
    .line 715
    :goto_2ca
    and-int/lit8 v8, v8, 0x20

    .line 716
    .line 717
    if-eqz v8, :cond_2d3

    .line 718
    .line 719
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 720
    .line 721
    .line 722
    move-result v6

    .line 723
    goto :goto_2d5

    .line 724
    :cond_2d3
    iget v6, v10, Li5/f;->d:I

    .line 725
    .line 726
    :goto_2d5
    new-instance v8, Li5/f;

    .line 727
    .line 728
    invoke-direct {v8, v11, v13, v1, v6}, Li5/f;-><init>(IIII)V

    .line 729
    .line 730
    .line 731
    iput-object v8, v12, Lds/t;->o:Ljava/lang/Object;

    .line 732
    .line 733
    :goto_2dc
    if-nez v9, :cond_2ed

    .line 734
    .line 735
    move/from16 v24, v2

    .line 736
    .line 737
    move-object/from16 v31, v4

    .line 738
    .line 739
    move-object/from16 v32, v5

    .line 740
    .line 741
    const/4 v2, 0x0

    .line 742
    const/4 v9, 0x1

    .line 743
    const/16 v12, 0xc

    .line 744
    .line 745
    :cond_2e8
    const/16 v8, 0x8

    .line 746
    .line 747
    const/4 v10, 0x0

    .line 748
    goto/16 :goto_7ac

    .line 749
    .line 750
    :cond_2ed
    iget-object v1, v9, Li5/j;->b:Lds/t;

    .line 751
    .line 752
    iget-wide v10, v1, Lds/t;->m:J

    .line 753
    .line 754
    iget-boolean v6, v1, Lds/t;->n:Z

    .line 755
    .line 756
    invoke-virtual {v9}, Li5/j;->e()V

    .line 757
    .line 758
    .line 759
    const/4 v8, 0x1

    .line 760
    iput-boolean v8, v9, Li5/j;->n:Z

    .line 761
    .line 762
    const v12, 0x74666474

    .line 763
    .line 764
    .line 765
    invoke-virtual {v3, v12}, Lo3/c;->p(I)Lo3/d;

    .line 766
    .line 767
    .line 768
    move-result-object v12

    .line 769
    if-eqz v12, :cond_325

    .line 770
    .line 771
    and-int/lit8 v13, v15, 0x2

    .line 772
    .line 773
    if-nez v13, :cond_325

    .line 774
    .line 775
    iget-object v6, v12, Lo3/d;->i:Ln3/x;

    .line 776
    .line 777
    const/16 v10, 0x8

    .line 778
    .line 779
    invoke-virtual {v6, v10}, Ln3/x;->N(I)V

    .line 780
    .line 781
    .line 782
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 783
    .line 784
    .line 785
    move-result v10

    .line 786
    invoke-static {v10}, Li5/e;->e(I)I

    .line 787
    .line 788
    .line 789
    move-result v10

    .line 790
    if-ne v10, v8, :cond_31c

    .line 791
    .line 792
    invoke-virtual {v6}, Ln3/x;->G()J

    .line 793
    .line 794
    .line 795
    move-result-wide v10

    .line 796
    goto :goto_320

    .line 797
    :cond_31c
    invoke-virtual {v6}, Ln3/x;->C()J

    .line 798
    .line 799
    .line 800
    move-result-wide v10

    .line 801
    :goto_320
    iput-wide v10, v1, Lds/t;->m:J

    .line 802
    .line 803
    iput-boolean v8, v1, Lds/t;->n:Z

    .line 804
    .line 805
    goto :goto_329

    .line 806
    :cond_325
    iput-wide v10, v1, Lds/t;->m:J

    .line 807
    .line 808
    iput-boolean v6, v1, Lds/t;->n:Z

    .line 809
    .line 810
    :goto_329
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 811
    .line 812
    .line 813
    move-result v6

    .line 814
    const/4 v8, 0x0

    .line 815
    const/4 v10, 0x0

    .line 816
    const/4 v11, 0x0

    .line 817
    :goto_330
    const v12, 0x7472756e

    .line 818
    .line 819
    .line 820
    if-ge v8, v6, :cond_356

    .line 821
    .line 822
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object v13

    .line 826
    check-cast v13, Lo3/d;

    .line 827
    .line 828
    move/from16 v24, v2

    .line 829
    .line 830
    iget v2, v13, Lcz/j;->e:I

    .line 831
    .line 832
    if-ne v2, v12, :cond_351

    .line 833
    .line 834
    iget-object v2, v13, Lo3/d;->i:Ln3/x;

    .line 835
    .line 836
    const/16 v12, 0xc

    .line 837
    .line 838
    invoke-virtual {v2, v12}, Ln3/x;->N(I)V

    .line 839
    .line 840
    .line 841
    invoke-virtual {v2}, Ln3/x;->E()I

    .line 842
    .line 843
    .line 844
    move-result v2

    .line 845
    if-lez v2, :cond_351

    .line 846
    .line 847
    add-int/2addr v11, v2

    .line 848
    add-int/lit8 v10, v10, 0x1

    .line 849
    .line 850
    :cond_351
    add-int/lit8 v8, v8, 0x1

    .line 851
    .line 852
    move/from16 v2, v24

    .line 853
    .line 854
    goto :goto_330

    .line 855
    :cond_356
    move/from16 v24, v2

    .line 856
    .line 857
    const/4 v8, 0x0

    .line 858
    iput v8, v9, Li5/j;->h:I

    .line 859
    .line 860
    iput v8, v9, Li5/j;->g:I

    .line 861
    .line 862
    iput v8, v9, Li5/j;->f:I

    .line 863
    .line 864
    iput v10, v1, Lds/t;->c:I

    .line 865
    .line 866
    iput v11, v1, Lds/t;->d:I

    .line 867
    .line 868
    iget-object v2, v1, Lds/t;->f:[I

    .line 869
    .line 870
    array-length v2, v2

    .line 871
    if-ge v2, v10, :cond_370

    .line 872
    .line 873
    new-array v2, v10, [J

    .line 874
    .line 875
    iput-object v2, v1, Lds/t;->e:[J

    .line 876
    .line 877
    new-array v2, v10, [I

    .line 878
    .line 879
    iput-object v2, v1, Lds/t;->f:[I

    .line 880
    .line 881
    :cond_370
    iget-object v2, v1, Lds/t;->g:[I

    .line 882
    .line 883
    array-length v2, v2

    .line 884
    if-ge v2, v11, :cond_389

    .line 885
    .line 886
    mul-int/lit8 v11, v11, 0x7d

    .line 887
    .line 888
    div-int/lit8 v11, v11, 0x64

    .line 889
    .line 890
    new-array v2, v11, [I

    .line 891
    .line 892
    iput-object v2, v1, Lds/t;->g:[I

    .line 893
    .line 894
    new-array v2, v11, [J

    .line 895
    .line 896
    iput-object v2, v1, Lds/t;->h:[J

    .line 897
    .line 898
    new-array v2, v11, [Z

    .line 899
    .line 900
    iput-object v2, v1, Lds/t;->i:[Z

    .line 901
    .line 902
    new-array v2, v11, [Z

    .line 903
    .line 904
    iput-object v2, v1, Lds/t;->k:[Z

    .line 905
    .line 906
    :cond_389
    const/4 v2, 0x0

    .line 907
    const/4 v8, 0x0

    .line 908
    const/4 v10, 0x0

    .line 909
    :goto_38c
    const-wide/16 v25, 0x0

    .line 910
    .line 911
    if-ge v2, v6, :cond_573

    .line 912
    .line 913
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 914
    .line 915
    .line 916
    move-result-object v27

    .line 917
    const/16 v28, 0x10

    .line 918
    .line 919
    move-object/from16 v11, v27

    .line 920
    .line 921
    check-cast v11, Lo3/d;

    .line 922
    .line 923
    iget v13, v11, Lcz/j;->e:I

    .line 924
    .line 925
    if-ne v13, v12, :cond_558

    .line 926
    .line 927
    add-int/lit8 v13, v8, 0x1

    .line 928
    .line 929
    iget-object v11, v11, Lo3/d;->i:Ln3/x;

    .line 930
    .line 931
    const/16 v12, 0x8

    .line 932
    .line 933
    invoke-virtual {v11, v12}, Ln3/x;->N(I)V

    .line 934
    .line 935
    .line 936
    invoke-virtual {v11}, Ln3/x;->m()I

    .line 937
    .line 938
    .line 939
    move-result v12

    .line 940
    sget-object v30, Li5/e;->a:[B

    .line 941
    .line 942
    move/from16 v30, v2

    .line 943
    .line 944
    iget-object v2, v9, Li5/j;->d:Li5/w;

    .line 945
    .line 946
    iget-object v2, v2, Li5/w;->a:Li5/u;

    .line 947
    .line 948
    move-object/from16 v31, v4

    .line 949
    .line 950
    iget-object v4, v1, Lds/t;->o:Ljava/lang/Object;

    .line 951
    .line 952
    check-cast v4, Li5/f;

    .line 953
    .line 954
    sget-object v32, Ln3/l0;->a:Ljava/lang/String;

    .line 955
    .line 956
    move-object/from16 v32, v5

    .line 957
    .line 958
    iget-object v5, v1, Lds/t;->f:[I

    .line 959
    .line 960
    invoke-virtual {v11}, Ln3/x;->E()I

    .line 961
    .line 962
    .line 963
    move-result v33

    .line 964
    aput v33, v5, v8

    .line 965
    .line 966
    iget-object v5, v1, Lds/t;->e:[J

    .line 967
    .line 968
    move-object/from16 v34, v5

    .line 969
    .line 970
    move/from16 v33, v6

    .line 971
    .line 972
    iget-wide v5, v1, Lds/t;->a:J

    .line 973
    .line 974
    aput-wide v5, v34, v8

    .line 975
    .line 976
    and-int/lit8 v35, v12, 0x1

    .line 977
    .line 978
    if-eqz v35, :cond_3de

    .line 979
    .line 980
    move-wide/from16 v35, v5

    .line 981
    .line 982
    invoke-virtual {v11}, Ln3/x;->m()I

    .line 983
    .line 984
    .line 985
    move-result v5

    .line 986
    int-to-long v5, v5

    .line 987
    add-long v5, v35, v5

    .line 988
    .line 989
    aput-wide v5, v34, v8

    .line 990
    .line 991
    :cond_3de
    and-int/lit8 v5, v12, 0x4

    .line 992
    .line 993
    if-eqz v5, :cond_3e4

    .line 994
    .line 995
    const/4 v5, 0x1

    .line 996
    goto :goto_3e5

    .line 997
    :cond_3e4
    const/4 v5, 0x0

    .line 998
    :goto_3e5
    iget v6, v4, Li5/f;->d:I

    .line 999
    .line 1000
    if-eqz v5, :cond_3ed

    .line 1001
    .line 1002
    invoke-virtual {v11}, Ln3/x;->m()I

    .line 1003
    .line 1004
    .line 1005
    move-result v6

    .line 1006
    :cond_3ed
    move/from16 v34, v5

    .line 1007
    .line 1008
    and-int/lit16 v5, v12, 0x100

    .line 1009
    .line 1010
    if-eqz v5, :cond_3f5

    .line 1011
    .line 1012
    const/4 v5, 0x1

    .line 1013
    goto :goto_3f6

    .line 1014
    :cond_3f5
    const/4 v5, 0x0

    .line 1015
    :goto_3f6
    move/from16 v35, v5

    .line 1016
    .line 1017
    and-int/lit16 v5, v12, 0x200

    .line 1018
    .line 1019
    if-eqz v5, :cond_3fe

    .line 1020
    .line 1021
    const/4 v5, 0x1

    .line 1022
    goto :goto_3ff

    .line 1023
    :cond_3fe
    const/4 v5, 0x0

    .line 1024
    :goto_3ff
    move/from16 v36, v5

    .line 1025
    .line 1026
    and-int/lit16 v5, v12, 0x400

    .line 1027
    .line 1028
    if-eqz v5, :cond_407

    .line 1029
    .line 1030
    const/4 v5, 0x1

    .line 1031
    goto :goto_408

    .line 1032
    :cond_407
    const/4 v5, 0x0

    .line 1033
    :goto_408
    and-int/lit16 v12, v12, 0x800

    .line 1034
    .line 1035
    if-eqz v12, :cond_410

    .line 1036
    .line 1037
    const/4 v12, 0x1

    .line 1038
    :goto_40d
    move/from16 v37, v5

    .line 1039
    .line 1040
    goto :goto_412

    .line 1041
    :cond_410
    const/4 v12, 0x0

    .line 1042
    goto :goto_40d

    .line 1043
    :goto_412
    iget-object v5, v2, Li5/u;->i:Llx/b;

    .line 1044
    .line 1045
    move/from16 v38, v6

    .line 1046
    .line 1047
    iget-object v6, v2, Li5/u;->j:Llx/b;

    .line 1048
    .line 1049
    move/from16 v39, v8

    .line 1050
    .line 1051
    if-eqz v5, :cond_469

    .line 1052
    .line 1053
    iget v8, v5, Llx/b;->e:I

    .line 1054
    .line 1055
    move/from16 v40, v10

    .line 1056
    .line 1057
    const/4 v10, 0x1

    .line 1058
    if-ne v8, v10, :cond_425

    .line 1059
    .line 1060
    if-nez v6, :cond_429

    .line 1061
    .line 1062
    :cond_425
    move-object v5, v9

    .line 1063
    :goto_426
    move-object/from16 v41, v11

    .line 1064
    .line 1065
    goto :goto_46d

    .line 1066
    :cond_429
    const/4 v8, 0x0

    .line 1067
    invoke-virtual {v5, v8}, Llx/b;->a(I)J

    .line 1068
    .line 1069
    .line 1070
    move-result-wide v41

    .line 1071
    cmp-long v10, v41, v25

    .line 1072
    .line 1073
    if-nez v10, :cond_436

    .line 1074
    .line 1075
    move-object v5, v9

    .line 1076
    move-object/from16 v41, v11

    .line 1077
    .line 1078
    goto :goto_464

    .line 1079
    :cond_436
    invoke-virtual {v5, v8}, Llx/b;->a(I)J

    .line 1080
    .line 1081
    .line 1082
    move-result-wide v41

    .line 1083
    move-object v5, v9

    .line 1084
    iget-wide v8, v2, Li5/u;->d:J

    .line 1085
    .line 1086
    sget-object v47, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 1087
    .line 1088
    const-wide/32 v43, 0xf4240

    .line 1089
    .line 1090
    .line 1091
    move-wide/from16 v45, v8

    .line 1092
    .line 1093
    invoke-static/range {v41 .. v47}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1094
    .line 1095
    .line 1096
    move-result-wide v8

    .line 1097
    const/4 v10, 0x0

    .line 1098
    invoke-virtual {v6, v10}, Llx/b;->a(I)J

    .line 1099
    .line 1100
    .line 1101
    move-result-wide v43

    .line 1102
    const-wide/32 v45, 0xf4240

    .line 1103
    .line 1104
    .line 1105
    move-object/from16 v41, v11

    .line 1106
    .line 1107
    iget-wide v10, v2, Li5/u;->c:J

    .line 1108
    .line 1109
    move-object/from16 v49, v47

    .line 1110
    .line 1111
    move-wide/from16 v47, v10

    .line 1112
    .line 1113
    invoke-static/range {v43 .. v49}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1114
    .line 1115
    .line 1116
    move-result-wide v10

    .line 1117
    add-long/2addr v8, v10

    .line 1118
    iget-wide v10, v2, Li5/u;->e:J

    .line 1119
    .line 1120
    cmp-long v8, v8, v10

    .line 1121
    .line 1122
    if-ltz v8, :cond_46d

    .line 1123
    .line 1124
    const/4 v8, 0x0

    .line 1125
    :goto_464
    invoke-virtual {v6, v8}, Llx/b;->a(I)J

    .line 1126
    .line 1127
    .line 1128
    move-result-wide v25

    .line 1129
    goto :goto_46d

    .line 1130
    :cond_469
    move-object v5, v9

    .line 1131
    move/from16 v40, v10

    .line 1132
    .line 1133
    goto :goto_426

    .line 1134
    :cond_46d
    :goto_46d
    iget-object v6, v1, Lds/t;->g:[I

    .line 1135
    .line 1136
    iget-object v8, v1, Lds/t;->h:[J

    .line 1137
    .line 1138
    iget-object v9, v1, Lds/t;->i:[Z

    .line 1139
    .line 1140
    iget v10, v2, Li5/u;->b:I

    .line 1141
    .line 1142
    const/4 v11, 0x2

    .line 1143
    if-ne v10, v11, :cond_47e

    .line 1144
    .line 1145
    and-int/lit8 v10, v15, 0x1

    .line 1146
    .line 1147
    if-eqz v10, :cond_47e

    .line 1148
    .line 1149
    const/4 v10, 0x1

    .line 1150
    goto :goto_47f

    .line 1151
    :cond_47e
    const/4 v10, 0x0

    .line 1152
    :goto_47f
    iget-object v11, v1, Lds/t;->f:[I

    .line 1153
    .line 1154
    aget v11, v11, v39

    .line 1155
    .line 1156
    add-int v11, v40, v11

    .line 1157
    .line 1158
    move-object/from16 v27, v5

    .line 1159
    .line 1160
    move-object/from16 v49, v6

    .line 1161
    .line 1162
    iget-wide v5, v2, Li5/u;->c:J

    .line 1163
    .line 1164
    move-wide/from16 v46, v5

    .line 1165
    .line 1166
    iget-wide v5, v1, Lds/t;->m:J

    .line 1167
    .line 1168
    move/from16 v2, v40

    .line 1169
    .line 1170
    :goto_491
    if-ge v2, v11, :cond_54e

    .line 1171
    .line 1172
    if-eqz v35, :cond_4a2

    .line 1173
    .line 1174
    invoke-virtual/range {v41 .. v41}, Ln3/x;->m()I

    .line 1175
    .line 1176
    .line 1177
    move-result v39

    .line 1178
    move/from16 v50, v39

    .line 1179
    .line 1180
    move/from16 v39, v2

    .line 1181
    .line 1182
    move/from16 v2, v50

    .line 1183
    .line 1184
    :goto_49f
    move-object/from16 v50, v8

    .line 1185
    .line 1186
    goto :goto_4a7

    .line 1187
    :cond_4a2
    move/from16 v39, v2

    .line 1188
    .line 1189
    iget v2, v4, Li5/f;->b:I

    .line 1190
    .line 1191
    goto :goto_49f

    .line 1192
    :goto_4a7
    const-string v8, "Unexpected negative value: "

    .line 1193
    .line 1194
    if-ltz v2, :cond_53c

    .line 1195
    .line 1196
    if-eqz v36, :cond_4b6

    .line 1197
    .line 1198
    invoke-virtual/range {v41 .. v41}, Ln3/x;->m()I

    .line 1199
    .line 1200
    .line 1201
    move-result v40

    .line 1202
    move-object/from16 v51, v9

    .line 1203
    .line 1204
    move/from16 v9, v40

    .line 1205
    .line 1206
    goto :goto_4ba

    .line 1207
    :cond_4b6
    move-object/from16 v51, v9

    .line 1208
    .line 1209
    iget v9, v4, Li5/f;->c:I

    .line 1210
    .line 1211
    :goto_4ba
    if-ltz v9, :cond_52a

    .line 1212
    .line 1213
    if-eqz v37, :cond_4c3

    .line 1214
    .line 1215
    invoke-virtual/range {v41 .. v41}, Ln3/x;->m()I

    .line 1216
    .line 1217
    .line 1218
    move-result v8

    .line 1219
    goto :goto_4cc

    .line 1220
    :cond_4c3
    if-nez v39, :cond_4ca

    .line 1221
    .line 1222
    if-eqz v34, :cond_4ca

    .line 1223
    .line 1224
    move/from16 v8, v38

    .line 1225
    .line 1226
    goto :goto_4cc

    .line 1227
    :cond_4ca
    iget v8, v4, Li5/f;->d:I

    .line 1228
    .line 1229
    :goto_4cc
    if-eqz v12, :cond_4db

    .line 1230
    .line 1231
    invoke-virtual/range {v41 .. v41}, Ln3/x;->m()I

    .line 1232
    .line 1233
    .line 1234
    move-result v40

    .line 1235
    move-object/from16 v52, v4

    .line 1236
    .line 1237
    move/from16 v4, v40

    .line 1238
    .line 1239
    :goto_4d6
    move/from16 v53, v10

    .line 1240
    .line 1241
    move/from16 v54, v11

    .line 1242
    .line 1243
    goto :goto_4df

    .line 1244
    :cond_4db
    move-object/from16 v52, v4

    .line 1245
    .line 1246
    const/4 v4, 0x0

    .line 1247
    goto :goto_4d6

    .line 1248
    :goto_4df
    int-to-long v10, v4

    .line 1249
    add-long/2addr v10, v5

    .line 1250
    sub-long v42, v10, v25

    .line 1251
    .line 1252
    const-wide/32 v44, 0xf4240

    .line 1253
    .line 1254
    .line 1255
    sget-object v48, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 1256
    .line 1257
    invoke-static/range {v42 .. v48}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    .line 1258
    .line 1259
    .line 1260
    move-result-wide v10

    .line 1261
    aput-wide v10, v50, v39

    .line 1262
    .line 1263
    iget-boolean v4, v1, Lds/t;->n:Z

    .line 1264
    .line 1265
    if-nez v4, :cond_501

    .line 1266
    .line 1267
    move-object/from16 v4, v27

    .line 1268
    .line 1269
    move/from16 v27, v8

    .line 1270
    .line 1271
    iget-object v8, v4, Li5/j;->d:Li5/w;

    .line 1272
    .line 1273
    move-wide/from16 v42, v10

    .line 1274
    .line 1275
    iget-wide v10, v8, Li5/w;->i:J

    .line 1276
    .line 1277
    add-long v10, v42, v10

    .line 1278
    .line 1279
    aput-wide v10, v50, v39

    .line 1280
    .line 1281
    goto :goto_505

    .line 1282
    :cond_501
    move-object/from16 v4, v27

    .line 1283
    .line 1284
    move/from16 v27, v8

    .line 1285
    .line 1286
    :goto_505
    aput v9, v49, v39

    .line 1287
    .line 1288
    shr-int/lit8 v8, v27, 0x10

    .line 1289
    .line 1290
    const/16 v18, 0x1

    .line 1291
    .line 1292
    and-int/lit8 v8, v8, 0x1

    .line 1293
    .line 1294
    if-nez v8, :cond_515

    .line 1295
    .line 1296
    if-eqz v53, :cond_513

    .line 1297
    .line 1298
    if-nez v39, :cond_515

    .line 1299
    .line 1300
    :cond_513
    const/4 v8, 0x1

    .line 1301
    goto :goto_516

    .line 1302
    :cond_515
    const/4 v8, 0x0

    .line 1303
    :goto_516
    aput-boolean v8, v51, v39

    .line 1304
    .line 1305
    int-to-long v8, v2

    .line 1306
    add-long/2addr v5, v8

    .line 1307
    add-int/lit8 v2, v39, 0x1

    .line 1308
    .line 1309
    move-object/from16 v27, v4

    .line 1310
    .line 1311
    move-object/from16 v8, v50

    .line 1312
    .line 1313
    move-object/from16 v9, v51

    .line 1314
    .line 1315
    move-object/from16 v4, v52

    .line 1316
    .line 1317
    move/from16 v10, v53

    .line 1318
    .line 1319
    move/from16 v11, v54

    .line 1320
    .line 1321
    goto/16 :goto_491

    .line 1322
    .line 1323
    :cond_52a
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1324
    .line 1325
    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1326
    .line 1327
    .line 1328
    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1329
    .line 1330
    .line 1331
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1332
    .line 1333
    .line 1334
    move-result-object v1

    .line 1335
    const/4 v6, 0x0

    .line 1336
    invoke-static {v1, v6}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1337
    .line 1338
    .line 1339
    move-result-object v1

    .line 1340
    throw v1

    .line 1341
    :cond_53c
    const/4 v6, 0x0

    .line 1342
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1343
    .line 1344
    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1345
    .line 1346
    .line 1347
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1348
    .line 1349
    .line 1350
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1351
    .line 1352
    .line 1353
    move-result-object v1

    .line 1354
    invoke-static {v1, v6}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1355
    .line 1356
    .line 1357
    move-result-object v1

    .line 1358
    throw v1

    .line 1359
    :cond_54e
    move/from16 v54, v11

    .line 1360
    .line 1361
    move-object/from16 v4, v27

    .line 1362
    .line 1363
    iput-wide v5, v1, Lds/t;->m:J

    .line 1364
    .line 1365
    move v8, v13

    .line 1366
    move/from16 v10, v54

    .line 1367
    .line 1368
    goto :goto_565

    .line 1369
    :cond_558
    move/from16 v30, v2

    .line 1370
    .line 1371
    move-object/from16 v31, v4

    .line 1372
    .line 1373
    move-object/from16 v32, v5

    .line 1374
    .line 1375
    move/from16 v33, v6

    .line 1376
    .line 1377
    move/from16 v39, v8

    .line 1378
    .line 1379
    move-object v4, v9

    .line 1380
    move/from16 v40, v10

    .line 1381
    .line 1382
    :goto_565
    add-int/lit8 v2, v30, 0x1

    .line 1383
    .line 1384
    move-object v9, v4

    .line 1385
    move-object/from16 v4, v31

    .line 1386
    .line 1387
    move-object/from16 v5, v32

    .line 1388
    .line 1389
    move/from16 v6, v33

    .line 1390
    .line 1391
    const v12, 0x7472756e

    .line 1392
    .line 1393
    .line 1394
    goto/16 :goto_38c

    .line 1395
    .line 1396
    :cond_573
    move-object/from16 v31, v4

    .line 1397
    .line 1398
    move-object/from16 v32, v5

    .line 1399
    .line 1400
    move-object v4, v9

    .line 1401
    const/16 v28, 0x10

    .line 1402
    .line 1403
    iget-object v2, v4, Li5/j;->d:Li5/w;

    .line 1404
    .line 1405
    iget-object v2, v2, Li5/w;->a:Li5/u;

    .line 1406
    .line 1407
    iget-object v4, v1, Lds/t;->o:Ljava/lang/Object;

    .line 1408
    .line 1409
    check-cast v4, Li5/f;

    .line 1410
    .line 1411
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1412
    .line 1413
    .line 1414
    iget v4, v4, Li5/f;->a:I

    .line 1415
    .line 1416
    iget-object v2, v2, Li5/u;->n:[Li5/v;

    .line 1417
    .line 1418
    if-nez v2, :cond_58d

    .line 1419
    .line 1420
    const/4 v6, 0x0

    .line 1421
    goto :goto_590

    .line 1422
    :cond_58d
    aget-object v2, v2, v4

    .line 1423
    .line 1424
    move-object v6, v2

    .line 1425
    :goto_590
    const v2, 0x7361697a

    .line 1426
    .line 1427
    .line 1428
    invoke-virtual {v3, v2}, Lo3/c;->p(I)Lo3/d;

    .line 1429
    .line 1430
    .line 1431
    move-result-object v2

    .line 1432
    if-eqz v2, :cond_611

    .line 1433
    .line 1434
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1435
    .line 1436
    .line 1437
    iget-object v2, v2, Lo3/d;->i:Ln3/x;

    .line 1438
    .line 1439
    iget v4, v6, Li5/v;->d:I

    .line 1440
    .line 1441
    const/16 v8, 0x8

    .line 1442
    .line 1443
    invoke-virtual {v2, v8}, Ln3/x;->N(I)V

    .line 1444
    .line 1445
    .line 1446
    invoke-virtual {v2}, Ln3/x;->m()I

    .line 1447
    .line 1448
    .line 1449
    move-result v5

    .line 1450
    sget-object v9, Li5/e;->a:[B

    .line 1451
    .line 1452
    const/4 v9, 0x1

    .line 1453
    and-int/2addr v5, v9

    .line 1454
    if-ne v5, v9, :cond_5b2

    .line 1455
    .line 1456
    invoke-virtual {v2, v8}, Ln3/x;->O(I)V

    .line 1457
    .line 1458
    .line 1459
    :cond_5b2
    invoke-virtual {v2}, Ln3/x;->A()I

    .line 1460
    .line 1461
    .line 1462
    move-result v5

    .line 1463
    invoke-virtual {v2}, Ln3/x;->E()I

    .line 1464
    .line 1465
    .line 1466
    move-result v8

    .line 1467
    iget v9, v1, Lds/t;->d:I

    .line 1468
    .line 1469
    if-gt v8, v9, :cond_5fa

    .line 1470
    .line 1471
    if-nez v5, :cond_5d7

    .line 1472
    .line 1473
    iget-object v5, v1, Lds/t;->k:[Z

    .line 1474
    .line 1475
    const/4 v9, 0x0

    .line 1476
    const/4 v10, 0x0

    .line 1477
    :goto_5c4
    if-ge v9, v8, :cond_5d5

    .line 1478
    .line 1479
    invoke-virtual {v2}, Ln3/x;->A()I

    .line 1480
    .line 1481
    .line 1482
    move-result v11

    .line 1483
    add-int/2addr v10, v11

    .line 1484
    if-le v11, v4, :cond_5cf

    .line 1485
    .line 1486
    const/4 v11, 0x1

    .line 1487
    goto :goto_5d0

    .line 1488
    :cond_5cf
    const/4 v11, 0x0

    .line 1489
    :goto_5d0
    aput-boolean v11, v5, v9

    .line 1490
    .line 1491
    add-int/lit8 v9, v9, 0x1

    .line 1492
    .line 1493
    goto :goto_5c4

    .line 1494
    :cond_5d5
    const/4 v5, 0x0

    .line 1495
    goto :goto_5e4

    .line 1496
    :cond_5d7
    if-le v5, v4, :cond_5db

    .line 1497
    .line 1498
    const/4 v2, 0x1

    .line 1499
    goto :goto_5dc

    .line 1500
    :cond_5db
    const/4 v2, 0x0

    .line 1501
    :goto_5dc
    mul-int v10, v5, v8

    .line 1502
    .line 1503
    iget-object v4, v1, Lds/t;->k:[Z

    .line 1504
    .line 1505
    const/4 v5, 0x0

    .line 1506
    invoke-static {v4, v5, v8, v2}, Ljava/util/Arrays;->fill([ZIIZ)V

    .line 1507
    .line 1508
    .line 1509
    :goto_5e4
    iget-object v2, v1, Lds/t;->k:[Z

    .line 1510
    .line 1511
    iget v4, v1, Lds/t;->d:I

    .line 1512
    .line 1513
    invoke-static {v2, v8, v4, v5}, Ljava/util/Arrays;->fill([ZIIZ)V

    .line 1514
    .line 1515
    .line 1516
    if-lez v10, :cond_611

    .line 1517
    .line 1518
    iget-object v2, v1, Lds/t;->q:Ljava/lang/Object;

    .line 1519
    .line 1520
    check-cast v2, Ln3/x;

    .line 1521
    .line 1522
    invoke-virtual {v2, v10}, Ln3/x;->K(I)V

    .line 1523
    .line 1524
    .line 1525
    const/4 v9, 0x1

    .line 1526
    iput-boolean v9, v1, Lds/t;->j:Z

    .line 1527
    .line 1528
    iput-boolean v9, v1, Lds/t;->l:Z

    .line 1529
    .line 1530
    goto :goto_611

    .line 1531
    :cond_5fa
    const-string v2, "Saiz sample count "

    .line 1532
    .line 1533
    const-string v3, " is greater than fragment sample count"

    .line 1534
    .line 1535
    invoke-static {v8, v2, v3}, Lp/x2;->l(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1536
    .line 1537
    .line 1538
    move-result-object v2

    .line 1539
    iget v1, v1, Lds/t;->d:I

    .line 1540
    .line 1541
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1542
    .line 1543
    .line 1544
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1545
    .line 1546
    .line 1547
    move-result-object v1

    .line 1548
    const/4 v6, 0x0

    .line 1549
    invoke-static {v1, v6}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1550
    .line 1551
    .line 1552
    move-result-object v1

    .line 1553
    throw v1

    .line 1554
    :cond_611
    :goto_611
    const v2, 0x7361696f

    .line 1555
    .line 1556
    .line 1557
    invoke-virtual {v3, v2}, Lo3/c;->p(I)Lo3/d;

    .line 1558
    .line 1559
    .line 1560
    move-result-object v2

    .line 1561
    if-eqz v2, :cond_649

    .line 1562
    .line 1563
    iget-object v2, v2, Lo3/d;->i:Ln3/x;

    .line 1564
    .line 1565
    const/16 v8, 0x8

    .line 1566
    .line 1567
    invoke-virtual {v2, v8}, Ln3/x;->N(I)V

    .line 1568
    .line 1569
    .line 1570
    invoke-virtual {v2}, Ln3/x;->m()I

    .line 1571
    .line 1572
    .line 1573
    move-result v4

    .line 1574
    sget-object v5, Li5/e;->a:[B

    .line 1575
    .line 1576
    and-int/lit8 v5, v4, 0x1

    .line 1577
    .line 1578
    const/4 v9, 0x1

    .line 1579
    if-ne v5, v9, :cond_62f

    .line 1580
    .line 1581
    invoke-virtual {v2, v8}, Ln3/x;->O(I)V

    .line 1582
    .line 1583
    .line 1584
    :cond_62f
    invoke-virtual {v2}, Ln3/x;->E()I

    .line 1585
    .line 1586
    .line 1587
    move-result v5

    .line 1588
    if-ne v5, v9, :cond_64b

    .line 1589
    .line 1590
    invoke-static {v4}, Li5/e;->e(I)I

    .line 1591
    .line 1592
    .line 1593
    move-result v4

    .line 1594
    iget-wide v8, v1, Lds/t;->b:J

    .line 1595
    .line 1596
    if-nez v4, :cond_642

    .line 1597
    .line 1598
    invoke-virtual {v2}, Ln3/x;->C()J

    .line 1599
    .line 1600
    .line 1601
    move-result-wide v4

    .line 1602
    goto :goto_646

    .line 1603
    :cond_642
    invoke-virtual {v2}, Ln3/x;->G()J

    .line 1604
    .line 1605
    .line 1606
    move-result-wide v4

    .line 1607
    :goto_646
    add-long/2addr v8, v4

    .line 1608
    iput-wide v8, v1, Lds/t;->b:J

    .line 1609
    .line 1610
    :cond_649
    const/4 v2, 0x0

    .line 1611
    goto :goto_65f

    .line 1612
    :cond_64b
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1613
    .line 1614
    const-string v2, "Unexpected saio entry count: "

    .line 1615
    .line 1616
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1617
    .line 1618
    .line 1619
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1620
    .line 1621
    .line 1622
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1623
    .line 1624
    .line 1625
    move-result-object v1

    .line 1626
    const/4 v2, 0x0

    .line 1627
    invoke-static {v1, v2}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1628
    .line 1629
    .line 1630
    move-result-object v1

    .line 1631
    throw v1

    .line 1632
    :goto_65f
    const v4, 0x73656e63

    .line 1633
    .line 1634
    .line 1635
    invoke-virtual {v3, v4}, Lo3/c;->p(I)Lo3/d;

    .line 1636
    .line 1637
    .line 1638
    move-result-object v3

    .line 1639
    if-eqz v3, :cond_66e

    .line 1640
    .line 1641
    iget-object v3, v3, Lo3/d;->i:Ln3/x;

    .line 1642
    .line 1643
    const/4 v8, 0x0

    .line 1644
    invoke-static {v3, v8, v1}, Li5/k;->i(Ln3/x;ILds/t;)V

    .line 1645
    .line 1646
    .line 1647
    :cond_66e
    if-eqz v6, :cond_675

    .line 1648
    .line 1649
    iget-object v6, v6, Li5/v;->b:Ljava/lang/String;

    .line 1650
    .line 1651
    move-object/from16 v35, v6

    .line 1652
    .line 1653
    goto :goto_677

    .line 1654
    :cond_675
    move-object/from16 v35, v2

    .line 1655
    .line 1656
    :goto_677
    move-object v3, v2

    .line 1657
    move-object v6, v3

    .line 1658
    const/4 v4, 0x0

    .line 1659
    :goto_67a
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 1660
    .line 1661
    .line 1662
    move-result v5

    .line 1663
    if-ge v4, v5, :cond_6b3

    .line 1664
    .line 1665
    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1666
    .line 1667
    .line 1668
    move-result-object v5

    .line 1669
    check-cast v5, Lo3/d;

    .line 1670
    .line 1671
    iget-object v8, v5, Lo3/d;->i:Ln3/x;

    .line 1672
    .line 1673
    iget v5, v5, Lcz/j;->e:I

    .line 1674
    .line 1675
    const v9, 0x73626770

    .line 1676
    .line 1677
    .line 1678
    const v10, 0x73656967

    .line 1679
    .line 1680
    .line 1681
    if-ne v5, v9, :cond_69f

    .line 1682
    .line 1683
    const/16 v12, 0xc

    .line 1684
    .line 1685
    invoke-virtual {v8, v12}, Ln3/x;->N(I)V

    .line 1686
    .line 1687
    .line 1688
    invoke-virtual {v8}, Ln3/x;->m()I

    .line 1689
    .line 1690
    .line 1691
    move-result v5

    .line 1692
    if-ne v5, v10, :cond_6b0

    .line 1693
    .line 1694
    move-object v6, v8

    .line 1695
    goto :goto_6b0

    .line 1696
    :cond_69f
    const/16 v12, 0xc

    .line 1697
    .line 1698
    const v9, 0x73677064

    .line 1699
    .line 1700
    .line 1701
    if-ne v5, v9, :cond_6b0

    .line 1702
    .line 1703
    invoke-virtual {v8, v12}, Ln3/x;->N(I)V

    .line 1704
    .line 1705
    .line 1706
    invoke-virtual {v8}, Ln3/x;->m()I

    .line 1707
    .line 1708
    .line 1709
    move-result v5

    .line 1710
    if-ne v5, v10, :cond_6b0

    .line 1711
    .line 1712
    move-object v3, v8

    .line 1713
    :cond_6b0
    :goto_6b0
    add-int/lit8 v4, v4, 0x1

    .line 1714
    .line 1715
    goto :goto_67a

    .line 1716
    :cond_6b3
    const/16 v12, 0xc

    .line 1717
    .line 1718
    if-eqz v6, :cond_6b9

    .line 1719
    .line 1720
    if-nez v3, :cond_6bc

    .line 1721
    .line 1722
    :cond_6b9
    :goto_6b9
    const/4 v9, 0x1

    .line 1723
    goto/16 :goto_760

    .line 1724
    .line 1725
    :cond_6bc
    const/16 v8, 0x8

    .line 1726
    .line 1727
    invoke-virtual {v6, v8}, Ln3/x;->N(I)V

    .line 1728
    .line 1729
    .line 1730
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 1731
    .line 1732
    .line 1733
    move-result v4

    .line 1734
    invoke-static {v4}, Li5/e;->e(I)I

    .line 1735
    .line 1736
    .line 1737
    move-result v4

    .line 1738
    const/4 v5, 0x4

    .line 1739
    invoke-virtual {v6, v5}, Ln3/x;->O(I)V

    .line 1740
    .line 1741
    .line 1742
    const/4 v9, 0x1

    .line 1743
    if-ne v4, v9, :cond_6d3

    .line 1744
    .line 1745
    invoke-virtual {v6, v5}, Ln3/x;->O(I)V

    .line 1746
    .line 1747
    .line 1748
    :cond_6d3
    invoke-virtual {v6}, Ln3/x;->m()I

    .line 1749
    .line 1750
    .line 1751
    move-result v4

    .line 1752
    if-ne v4, v9, :cond_759

    .line 1753
    .line 1754
    invoke-virtual {v3, v8}, Ln3/x;->N(I)V

    .line 1755
    .line 1756
    .line 1757
    invoke-virtual {v3}, Ln3/x;->m()I

    .line 1758
    .line 1759
    .line 1760
    move-result v4

    .line 1761
    invoke-static {v4}, Li5/e;->e(I)I

    .line 1762
    .line 1763
    .line 1764
    move-result v4

    .line 1765
    invoke-virtual {v3, v5}, Ln3/x;->O(I)V

    .line 1766
    .line 1767
    .line 1768
    if-lt v4, v9, :cond_6ef

    .line 1769
    .line 1770
    invoke-virtual {v3}, Ln3/x;->C()J

    .line 1771
    .line 1772
    .line 1773
    move-result-wide v8

    .line 1774
    :goto_6ed
    const/4 v11, 0x2

    .line 1775
    goto :goto_6f2

    .line 1776
    :cond_6ef
    move-wide/from16 v8, v25

    .line 1777
    .line 1778
    goto :goto_6ed

    .line 1779
    :goto_6f2
    if-lt v4, v11, :cond_6f7

    .line 1780
    .line 1781
    invoke-virtual {v3, v5}, Ln3/x;->O(I)V

    .line 1782
    .line 1783
    .line 1784
    :cond_6f7
    invoke-virtual {v3}, Ln3/x;->C()J

    .line 1785
    .line 1786
    .line 1787
    move-result-wide v10

    .line 1788
    const-wide/16 v29, 0x1

    .line 1789
    .line 1790
    cmp-long v6, v10, v29

    .line 1791
    .line 1792
    if-nez v6, :cond_752

    .line 1793
    .line 1794
    const/4 v6, 0x1

    .line 1795
    if-lt v4, v6, :cond_70b

    .line 1796
    .line 1797
    cmp-long v4, v8, v25

    .line 1798
    .line 1799
    if-nez v4, :cond_70b

    .line 1800
    .line 1801
    invoke-virtual {v3, v5}, Ln3/x;->O(I)V

    .line 1802
    .line 1803
    .line 1804
    :cond_70b
    invoke-virtual {v3, v6}, Ln3/x;->O(I)V

    .line 1805
    .line 1806
    .line 1807
    invoke-virtual {v3}, Ln3/x;->A()I

    .line 1808
    .line 1809
    .line 1810
    move-result v4

    .line 1811
    and-int/lit16 v8, v4, 0xf0

    .line 1812
    .line 1813
    shr-int/lit8 v38, v8, 0x4

    .line 1814
    .line 1815
    and-int/lit8 v39, v4, 0xf

    .line 1816
    .line 1817
    invoke-virtual {v3}, Ln3/x;->A()I

    .line 1818
    .line 1819
    .line 1820
    move-result v4

    .line 1821
    if-ne v4, v6, :cond_721

    .line 1822
    .line 1823
    const/16 v34, 0x1

    .line 1824
    .line 1825
    goto :goto_723

    .line 1826
    :cond_721
    const/16 v34, 0x0

    .line 1827
    .line 1828
    :goto_723
    if-nez v34, :cond_726

    .line 1829
    .line 1830
    goto :goto_6b9

    .line 1831
    :cond_726
    invoke-virtual {v3}, Ln3/x;->A()I

    .line 1832
    .line 1833
    .line 1834
    move-result v36

    .line 1835
    move/from16 v4, v28

    .line 1836
    .line 1837
    new-array v5, v4, [B

    .line 1838
    .line 1839
    const/4 v8, 0x0

    .line 1840
    invoke-virtual {v3, v5, v8, v4}, Ln3/x;->k([BII)V

    .line 1841
    .line 1842
    .line 1843
    if-nez v36, :cond_741

    .line 1844
    .line 1845
    invoke-virtual {v3}, Ln3/x;->A()I

    .line 1846
    .line 1847
    .line 1848
    move-result v4

    .line 1849
    new-array v6, v4, [B

    .line 1850
    .line 1851
    invoke-virtual {v3, v6, v8, v4}, Ln3/x;->k([BII)V

    .line 1852
    .line 1853
    .line 1854
    move-object/from16 v40, v6

    .line 1855
    .line 1856
    :goto_73f
    const/4 v9, 0x1

    .line 1857
    goto :goto_744

    .line 1858
    :cond_741
    move-object/from16 v40, v2

    .line 1859
    .line 1860
    goto :goto_73f

    .line 1861
    :goto_744
    iput-boolean v9, v1, Lds/t;->j:Z

    .line 1862
    .line 1863
    new-instance v33, Li5/v;

    .line 1864
    .line 1865
    move-object/from16 v37, v5

    .line 1866
    .line 1867
    invoke-direct/range {v33 .. v40}, Li5/v;-><init>(ZLjava/lang/String;I[BII[B)V

    .line 1868
    .line 1869
    .line 1870
    move-object/from16 v3, v33

    .line 1871
    .line 1872
    iput-object v3, v1, Lds/t;->p:Ljava/lang/Object;

    .line 1873
    .line 1874
    goto :goto_760

    .line 1875
    :cond_752
    const-string v1, "Entry count in sgpd != 1 (unsupported)."

    .line 1876
    .line 1877
    invoke-static {v1}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 1878
    .line 1879
    .line 1880
    move-result-object v1

    .line 1881
    throw v1

    .line 1882
    :cond_759
    const-string v1, "Entry count in sbgp != 1 (unsupported)."

    .line 1883
    .line 1884
    invoke-static {v1}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    .line 1885
    .line 1886
    .line 1887
    move-result-object v1

    .line 1888
    throw v1

    .line 1889
    :goto_760
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 1890
    .line 1891
    .line 1892
    move-result v3

    .line 1893
    const/4 v5, 0x0

    .line 1894
    :goto_765
    if-ge v5, v3, :cond_2e8

    .line 1895
    .line 1896
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1897
    .line 1898
    .line 1899
    move-result-object v4

    .line 1900
    check-cast v4, Lo3/d;

    .line 1901
    .line 1902
    iget v6, v4, Lcz/j;->e:I

    .line 1903
    .line 1904
    const v8, 0x75756964

    .line 1905
    .line 1906
    .line 1907
    if-ne v6, v8, :cond_790

    .line 1908
    .line 1909
    iget-object v4, v4, Lo3/d;->i:Ln3/x;

    .line 1910
    .line 1911
    const/16 v8, 0x8

    .line 1912
    .line 1913
    invoke-virtual {v4, v8}, Ln3/x;->N(I)V

    .line 1914
    .line 1915
    .line 1916
    iget-object v6, v0, Li5/k;->h:[B

    .line 1917
    .line 1918
    const/4 v10, 0x0

    .line 1919
    const/16 v11, 0x10

    .line 1920
    .line 1921
    invoke-virtual {v4, v6, v10, v11}, Ln3/x;->k([BII)V

    .line 1922
    .line 1923
    .line 1924
    sget-object v13, Li5/k;->O:[B

    .line 1925
    .line 1926
    invoke-static {v6, v13}, Ljava/util/Arrays;->equals([B[B)Z

    .line 1927
    .line 1928
    .line 1929
    move-result v6

    .line 1930
    if-nez v6, :cond_78c

    .line 1931
    .line 1932
    goto :goto_795

    .line 1933
    :cond_78c
    invoke-static {v4, v11, v1}, Li5/k;->i(Ln3/x;ILds/t;)V

    .line 1934
    .line 1935
    .line 1936
    goto :goto_795

    .line 1937
    :cond_790
    const/16 v8, 0x8

    .line 1938
    .line 1939
    const/4 v10, 0x0

    .line 1940
    const/16 v11, 0x10

    .line 1941
    .line 1942
    :goto_795
    add-int/lit8 v5, v5, 0x1

    .line 1943
    .line 1944
    goto :goto_765

    .line 1945
    :cond_798
    move/from16 v23, v1

    .line 1946
    .line 1947
    move/from16 v24, v2

    .line 1948
    .line 1949
    move-object/from16 v31, v4

    .line 1950
    .line 1951
    move-object/from16 v32, v5

    .line 1952
    .line 1953
    const/4 v2, 0x0

    .line 1954
    const/16 v8, 0x8

    .line 1955
    .line 1956
    const/4 v9, 0x1

    .line 1957
    const/4 v10, 0x0

    .line 1958
    const/16 v12, 0xc

    .line 1959
    .line 1960
    const-wide v21, -0x7fffffffffffffffL    # -4.9E-324

    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    :goto_7ac
    add-int/lit8 v1, v24, 0x1

    .line 1966
    .line 1967
    move v2, v1

    .line 1968
    move/from16 v1, v23

    .line 1969
    .line 1970
    move-object/from16 v4, v31

    .line 1971
    .line 1972
    move-object/from16 v5, v32

    .line 1973
    .line 1974
    goto/16 :goto_24b

    .line 1975
    .line 1976
    :cond_7b7
    move-object/from16 v32, v5

    .line 1977
    .line 1978
    const/4 v2, 0x0

    .line 1979
    const/4 v10, 0x0

    .line 1980
    const-wide v21, -0x7fffffffffffffffL    # -4.9E-324

    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    invoke-static/range {v32 .. v32}, Li5/k;->b(Ljava/util/List;)Lk3/r;

    .line 1986
    .line 1987
    .line 1988
    move-result-object v1

    .line 1989
    if-eqz v1, :cond_80f

    .line 1990
    .line 1991
    invoke-virtual {v14}, Landroid/util/SparseArray;->size()I

    .line 1992
    .line 1993
    .line 1994
    move-result v3

    .line 1995
    move v5, v10

    .line 1996
    :goto_7cb
    if-ge v5, v3, :cond_80f

    .line 1997
    .line 1998
    invoke-virtual {v14, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 1999
    .line 2000
    .line 2001
    move-result-object v4

    .line 2002
    check-cast v4, Li5/j;

    .line 2003
    .line 2004
    iget-object v6, v4, Li5/j;->d:Li5/w;

    .line 2005
    .line 2006
    iget-object v6, v6, Li5/w;->a:Li5/u;

    .line 2007
    .line 2008
    iget-object v7, v4, Li5/j;->b:Lds/t;

    .line 2009
    .line 2010
    iget-object v7, v7, Lds/t;->o:Ljava/lang/Object;

    .line 2011
    .line 2012
    check-cast v7, Li5/f;

    .line 2013
    .line 2014
    sget-object v8, Ln3/l0;->a:Ljava/lang/String;

    .line 2015
    .line 2016
    iget v7, v7, Li5/f;->a:I

    .line 2017
    .line 2018
    iget-object v6, v6, Li5/u;->n:[Li5/v;

    .line 2019
    .line 2020
    if-nez v6, :cond_7e7

    .line 2021
    .line 2022
    move-object v6, v2

    .line 2023
    goto :goto_7e9

    .line 2024
    :cond_7e7
    aget-object v6, v6, v7

    .line 2025
    .line 2026
    :goto_7e9
    if-eqz v6, :cond_7ee

    .line 2027
    .line 2028
    iget-object v6, v6, Li5/v;->b:Ljava/lang/String;

    .line 2029
    .line 2030
    goto :goto_7ef

    .line 2031
    :cond_7ee
    move-object v6, v2

    .line 2032
    :goto_7ef
    invoke-virtual {v1, v6}, Lk3/r;->z(Ljava/lang/String;)Lk3/r;

    .line 2033
    .line 2034
    .line 2035
    move-result-object v6

    .line 2036
    iget-object v7, v4, Li5/j;->m:Lk3/w;

    .line 2037
    .line 2038
    invoke-virtual {v7}, Lk3/w;->a()Lk3/v;

    .line 2039
    .line 2040
    .line 2041
    move-result-object v7

    .line 2042
    iput-object v6, v7, Lk3/v;->s:Lk3/r;

    .line 2043
    .line 2044
    new-instance v6, Lk3/w;

    .line 2045
    .line 2046
    invoke-direct {v6, v7}, Lk3/w;-><init>(Lk3/v;)V

    .line 2047
    .line 2048
    .line 2049
    iget-object v7, v4, Li5/j;->l:Lk3/w;

    .line 2050
    .line 2051
    if-eqz v7, :cond_807

    .line 2052
    .line 2053
    iput-object v6, v4, Li5/j;->l:Lk3/w;

    .line 2054
    .line 2055
    goto :goto_80c

    .line 2056
    :cond_807
    iget-object v4, v4, Li5/j;->a:Lo4/i0;

    .line 2057
    .line 2058
    invoke-interface {v4, v6}, Lo4/i0;->d(Lk3/w;)V

    .line 2059
    .line 2060
    .line 2061
    :goto_80c
    add-int/lit8 v5, v5, 0x1

    .line 2062
    .line 2063
    goto :goto_7cb

    .line 2064
    :cond_80f
    iget-wide v1, v0, Li5/k;->y:J

    .line 2065
    .line 2066
    cmp-long v1, v1, v21

    .line 2067
    .line 2068
    if-eqz v1, :cond_2

    .line 2069
    .line 2070
    invoke-virtual {v14}, Landroid/util/SparseArray;->size()I

    .line 2071
    .line 2072
    .line 2073
    move-result v1

    .line 2074
    move v12, v10

    .line 2075
    :goto_81a
    if-ge v12, v1, :cond_842

    .line 2076
    .line 2077
    invoke-virtual {v14, v12}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 2078
    .line 2079
    .line 2080
    move-result-object v2

    .line 2081
    check-cast v2, Li5/j;

    .line 2082
    .line 2083
    iget-wide v3, v0, Li5/k;->y:J

    .line 2084
    .line 2085
    iget v5, v2, Li5/j;->f:I

    .line 2086
    .line 2087
    :goto_826
    iget-object v6, v2, Li5/j;->b:Lds/t;

    .line 2088
    .line 2089
    iget v7, v6, Lds/t;->d:I

    .line 2090
    .line 2091
    if-ge v5, v7, :cond_83f

    .line 2092
    .line 2093
    iget-object v7, v6, Lds/t;->h:[J

    .line 2094
    .line 2095
    aget-wide v8, v7, v5

    .line 2096
    .line 2097
    cmp-long v7, v8, v3

    .line 2098
    .line 2099
    if-gtz v7, :cond_83f

    .line 2100
    .line 2101
    iget-object v6, v6, Lds/t;->i:[Z

    .line 2102
    .line 2103
    aget-boolean v6, v6, v5

    .line 2104
    .line 2105
    if-eqz v6, :cond_83c

    .line 2106
    .line 2107
    iput v5, v2, Li5/j;->i:I

    .line 2108
    .line 2109
    :cond_83c
    add-int/lit8 v5, v5, 0x1

    .line 2110
    .line 2111
    goto :goto_826

    .line 2112
    :cond_83f
    add-int/lit8 v12, v12, 0x1

    .line 2113
    .line 2114
    goto :goto_81a

    .line 2115
    :cond_842
    move-wide/from16 v2, v21

    .line 2116
    .line 2117
    iput-wide v2, v0, Li5/k;->y:J

    .line 2118
    .line 2119
    goto/16 :goto_2

    .line 2120
    .line 2121
    :cond_848
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 2122
    .line 2123
    .line 2124
    move-result v2

    .line 2125
    if-nez v2, :cond_2

    .line 2126
    .line 2127
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    .line 2128
    .line 2129
    .line 2130
    move-result-object v1

    .line 2131
    check-cast v1, Lo3/c;

    .line 2132
    .line 2133
    iget-object v1, v1, Lo3/c;->w:Ljava/util/ArrayList;

    .line 2134
    .line 2135
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2136
    .line 2137
    .line 2138
    goto/16 :goto_2

    .line 2139
    .line 2140
    :cond_85b
    invoke-virtual {v0}, Li5/k;->a()V

    .line 2141
    .line 2142
    .line 2143
    return-void
.end method

.method public final release()V
    .registers 1

    .line 1
    return-void
.end method
