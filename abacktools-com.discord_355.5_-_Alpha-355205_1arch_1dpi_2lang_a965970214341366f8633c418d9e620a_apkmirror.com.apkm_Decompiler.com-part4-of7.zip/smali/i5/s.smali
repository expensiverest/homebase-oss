###### Class i5.s (i5.s)
.class public abstract Li5/s;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const/16 v0, 0x1d

    .line 2
    .line 3
    new-array v0, v0, [I

    .line 4
    .line 5
    fill-array-data v0, :array_a

    .line 6
    .line 7
    .line 8
    sput-object v0, Li5/s;->a:[I

    .line 9
    .line 10
    return-void

    .line 11
    :array_a
    .array-data 4
        0x69736f6d
        0x69736f32
        0x69736f33
        0x69736f34
        0x69736f35
        0x69736f36
        0x69736f39
        0x61766331
        0x68766331
        0x68657631
        0x61763031
        0x6d703431
        0x6d703432
        0x33673261
        0x33673262
        0x33677236
        0x33677336
        0x33676536
        0x33676736
        0x4d345620    # 1.8909645E8f
        0x4d344120    # 1.8901043E8f
        0x66347620
        0x6b646469
        0x4d345650
        0x71742020
        0x4d534e56    # 2.215704E8f
        0x64627931
        0x69736d6c
        0x70696666
    .end array-data
.end method

.method public static a(Ljava/util/UUID;[Ljava/util/UUID;[B)[B
    .registers 9

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p2, :cond_5

    .line 3
    .line 4
    array-length v1, p2

    .line 5
    goto :goto_6

    .line 6
    :cond_5
    move v1, v0

    .line 7
    :goto_6
    add-int/lit8 v1, v1, 0x20

    .line 8
    .line 9
    if-eqz p1, :cond_10

    .line 10
    .line 11
    array-length v2, p1

    .line 12
    mul-int/lit8 v2, v2, 0x10

    .line 13
    .line 14
    add-int/lit8 v2, v2, 0x4

    .line 15
    .line 16
    add-int/2addr v1, v2

    .line 17
    :cond_10
    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 22
    .line 23
    .line 24
    const v1, 0x70737368    # 3.013775E29f

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 28
    .line 29
    .line 30
    if-eqz p1, :cond_22

    .line 31
    .line 32
    const/high16 v1, 0x1000000

    .line 33
    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v1, v0

    .line 36
    :goto_23
    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 37
    .line 38
    .line 39
    invoke-virtual {p0}, Ljava/util/UUID;->getMostSignificantBits()J

    .line 40
    .line 41
    .line 42
    move-result-wide v3

    .line 43
    invoke-virtual {v2, v3, v4}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0}, Ljava/util/UUID;->getLeastSignificantBits()J

    .line 47
    .line 48
    .line 49
    move-result-wide v3

    .line 50
    invoke-virtual {v2, v3, v4}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 51
    .line 52
    .line 53
    if-eqz p1, :cond_51

    .line 54
    .line 55
    array-length p0, p1

    .line 56
    invoke-virtual {v2, p0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 57
    .line 58
    .line 59
    array-length p0, p1

    .line 60
    move v1, v0

    .line 61
    :goto_3c
    if-ge v1, p0, :cond_51

    .line 62
    .line 63
    aget-object v3, p1, v1

    .line 64
    .line 65
    invoke-virtual {v3}, Ljava/util/UUID;->getMostSignificantBits()J

    .line 66
    .line 67
    .line 68
    move-result-wide v4

    .line 69
    invoke-virtual {v2, v4, v5}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v3}, Ljava/util/UUID;->getLeastSignificantBits()J

    .line 73
    .line 74
    .line 75
    move-result-wide v3

    .line 76
    invoke-virtual {v2, v3, v4}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 77
    .line 78
    .line 79
    add-int/lit8 v1, v1, 0x1

    .line 80
    .line 81
    goto :goto_3c

    .line 82
    :cond_51
    if-eqz p2, :cond_5e

    .line 83
    .line 84
    array-length p0, p2

    .line 85
    if-eqz p0, :cond_5e

    .line 86
    .line 87
    array-length p0, p2

    .line 88
    invoke-virtual {v2, p0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2, p2}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    .line 92
    .line 93
    .line 94
    goto :goto_61

    .line 95
    :cond_5e
    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 96
    .line 97
    .line 98
    :goto_61
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    return-object p0
.end method

.method public static b(Ljava/util/ArrayList;)Ljava/lang/String;
    .registers 5

    .line 1
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x0

    .line 6
    const/4 v1, 0x0

    .line 7
    :cond_6
    :goto_6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eqz v2, :cond_44

    .line 12
    .line 13
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Li5/w;

    .line 18
    .line 19
    iget-object v2, v2, Li5/w;->a:Li5/u;

    .line 20
    .line 21
    iget-object v2, v2, Li5/u;->g:Lk3/w;

    .line 22
    .line 23
    iget-object v2, v2, Lk3/w;->p:Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {v2}, Lk3/u0;->m(Ljava/lang/String;)Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_21

    .line 30
    .line 31
    const-string p0, "video/mp4"

    .line 32
    .line 33
    return-object p0

    .line 34
    :cond_21
    invoke-static {v2}, Lk3/u0;->i(Ljava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    if-eqz v3, :cond_29

    .line 39
    .line 40
    const/4 v0, 0x1

    .line 41
    goto :goto_6

    .line 42
    :cond_29
    invoke-static {v2}, Lk3/u0;->k(Ljava/lang/String;)Z

    .line 43
    .line 44
    .line 45
    move-result v3

    .line 46
    if-eqz v3, :cond_6

    .line 47
    .line 48
    const-string v3, "image/heic"

    .line 49
    .line 50
    invoke-static {v2, v3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eqz v3, :cond_3a

    .line 55
    .line 56
    const-string v1, "image/heif"

    .line 57
    .line 58
    goto :goto_6

    .line 59
    :cond_3a
    const-string v3, "image/avif"

    .line 60
    .line 61
    invoke-static {v2, v3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    if-eqz v2, :cond_6

    .line 66
    .line 67
    move-object v1, v3

    .line 68
    goto :goto_6

    .line 69
    :cond_44
    if-eqz v0, :cond_49

    .line 70
    .line 71
    const-string p0, "audio/mp4"

    .line 72
    .line 73
    return-object p0

    .line 74
    :cond_49
    if-eqz v1, :cond_4c

    .line 75
    .line 76
    return-object v1

    .line 77
    :cond_4c
    const-string p0, "application/mp4"

    .line 78
    .line 79
    return-object p0
.end method

.method public static c(ILn3/x;)Lc5/e;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ln3/x;->m()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p1}, Ln3/x;->m()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, 0x64617461

    .line 10
    .line 11
    .line 12
    if-ne v1, v2, :cond_20

    .line 13
    .line 14
    const/16 p0, 0x8

    .line 15
    .line 16
    invoke-virtual {p1, p0}, Ln3/x;->O(I)V

    .line 17
    .line 18
    .line 19
    add-int/lit8 v0, v0, -0x10

    .line 20
    .line 21
    invoke-virtual {p1, v0}, Ln3/x;->w(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    new-instance p1, Lc5/e;

    .line 26
    .line 27
    const-string v0, "und"

    .line 28
    .line 29
    invoke-direct {p1, v0, p0, p0}, Lc5/e;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-object p1

    .line 33
    :cond_20
    new-instance p1, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    const-string v0, "Failed to parse comment attribute: "

    .line 36
    .line 37
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-static {p0}, Lcz/j;->f(I)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    const-string p1, "MetadataUtil"

    .line 52
    .line 53
    invoke-static {p1, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    const/4 p0, 0x0

    .line 57
    return-object p0
.end method

.method public static d(Ln3/x;)Lc5/a;
    .registers 6

    .line 1
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, 0x64617461

    .line 10
    .line 11
    .line 12
    const-string v3, "MetadataUtil"

    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    if-ne v1, v2, :cond_44

    .line 16
    .line 17
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    sget-object v2, Li5/e;->a:[B

    .line 22
    .line 23
    const v2, 0xffffff

    .line 24
    .line 25
    .line 26
    and-int/2addr v1, v2

    .line 27
    const/16 v2, 0xd

    .line 28
    .line 29
    if-ne v1, v2, :cond_21

    .line 30
    .line 31
    const-string v2, "image/jpeg"

    .line 32
    .line 33
    goto :goto_29

    .line 34
    :cond_21
    const/16 v2, 0xe

    .line 35
    .line 36
    if-ne v1, v2, :cond_28

    .line 37
    .line 38
    const-string v2, "image/png"

    .line 39
    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move-object v2, v4

    .line 42
    :goto_29
    if-nez v2, :cond_31

    .line 43
    .line 44
    const-string p0, "Unrecognized cover art flags: "

    .line 45
    .line 46
    invoke-static {v1, p0, v3}, Lhs/q;->r(ILjava/lang/String;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v4

    .line 50
    :cond_31
    const/4 v1, 0x4

    .line 51
    invoke-virtual {p0, v1}, Ln3/x;->O(I)V

    .line 52
    .line 53
    .line 54
    add-int/lit8 v0, v0, -0x10

    .line 55
    .line 56
    new-array v1, v0, [B

    .line 57
    .line 58
    const/4 v3, 0x0

    .line 59
    invoke-virtual {p0, v1, v3, v0}, Ln3/x;->k([BII)V

    .line 60
    .line 61
    .line 62
    new-instance p0, Lc5/a;

    .line 63
    .line 64
    const/4 v0, 0x3

    .line 65
    invoke-direct {p0, v2, v4, v0, v1}, Lc5/a;-><init>(Ljava/lang/String;Ljava/lang/String;I[B)V

    .line 66
    .line 67
    .line 68
    return-object p0

    .line 69
    :cond_44
    const-string p0, "Failed to parse cover art attribute"

    .line 70
    .line 71
    invoke-static {v3, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    return-object v4
.end method

.method public static e(ILjava/lang/String;Ln3/x;)Lc5/o;
    .registers 7

    .line 1
    invoke-virtual {p2}, Ln3/x;->m()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p2}, Ln3/x;->m()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, 0x64617461

    .line 10
    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    if-ne v1, v2, :cond_47

    .line 14
    .line 15
    const/16 v1, 0x16

    .line 16
    .line 17
    if-lt v0, v1, :cond_47

    .line 18
    .line 19
    const/16 v0, 0xa

    .line 20
    .line 21
    invoke-virtual {p2, v0}, Ln3/x;->O(I)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p2}, Ln3/x;->H()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-lez v0, :cond_47

    .line 29
    .line 30
    const-string p0, ""

    .line 31
    .line 32
    invoke-static {v0, p0}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    invoke-virtual {p2}, Ln3/x;->H()I

    .line 37
    .line 38
    .line 39
    move-result p2

    .line 40
    if-lez p2, :cond_3d

    .line 41
    .line 42
    new-instance v0, Ljava/lang/StringBuilder;

    .line 43
    .line 44
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    const-string p0, "/"

    .line 51
    .line 52
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    :cond_3d
    new-instance p2, Lc5/o;

    .line 63
    .line 64
    invoke-static {p0}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    invoke-direct {p2, p1, v3, p0}, Lc5/o;-><init>(Ljava/lang/String;Ljava/lang/String;Lhx/w1;)V

    .line 69
    .line 70
    .line 71
    return-object p2

    .line 72
    :cond_47
    new-instance p1, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    const-string p2, "Failed to parse index/count attribute: "

    .line 75
    .line 76
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    invoke-static {p0}, Lcz/j;->f(I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    const-string p1, "MetadataUtil"

    .line 91
    .line 92
    invoke-static {p1, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    return-object v3
.end method

.method public static f(Ln3/x;)I
    .registers 4

    .line 1
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, 0x64617461

    .line 10
    .line 11
    .line 12
    if-ne v1, v2, :cond_3d

    .line 13
    .line 14
    const/16 v1, 0x8

    .line 15
    .line 16
    invoke-virtual {p0, v1}, Ln3/x;->O(I)V

    .line 17
    .line 18
    .line 19
    add-int/lit8 v0, v0, -0x10

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    if-eq v0, v1, :cond_38

    .line 23
    .line 24
    const/4 v1, 0x2

    .line 25
    if-eq v0, v1, :cond_33

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    if-eq v0, v1, :cond_2e

    .line 29
    .line 30
    const/4 v1, 0x4

    .line 31
    if-eq v0, v1, :cond_21

    .line 32
    .line 33
    goto :goto_3d

    .line 34
    :cond_21
    invoke-virtual {p0}, Ln3/x;->j()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    and-int/lit16 v0, v0, 0x80

    .line 39
    .line 40
    if-nez v0, :cond_3d

    .line 41
    .line 42
    invoke-virtual {p0}, Ln3/x;->E()I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    return p0

    .line 47
    :cond_2e
    invoke-virtual {p0}, Ln3/x;->D()I

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    return p0

    .line 52
    :cond_33
    invoke-virtual {p0}, Ln3/x;->H()I

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    return p0

    .line 57
    :cond_38
    invoke-virtual {p0}, Ln3/x;->A()I

    .line 58
    .line 59
    .line 60
    move-result p0

    .line 61
    return p0

    .line 62
    :cond_3d
    :goto_3d
    const-string p0, "MetadataUtil"

    .line 63
    .line 64
    const-string v0, "Failed to parse data atom to int"

    .line 65
    .line 66
    invoke-static {p0, v0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    const/4 p0, -0x1

    .line 70
    return p0
.end method

.method public static g(ILjava/lang/String;Ln3/x;ZZ)Lc5/j;
    .registers 5

    .line 1
    invoke-static {p2}, Li5/s;->f(Ln3/x;)I

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    if-eqz p4, :cond_b

    .line 6
    .line 7
    const/4 p4, 0x1

    .line 8
    invoke-static {p4, p2}, Ljava/lang/Math;->min(II)I

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    :cond_b
    const/4 p4, 0x0

    .line 13
    if-ltz p2, :cond_2a

    .line 14
    .line 15
    if-eqz p3, :cond_1e

    .line 16
    .line 17
    new-instance p0, Lc5/o;

    .line 18
    .line 19
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    invoke-static {p2}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 24
    .line 25
    .line 26
    move-result-object p2

    .line 27
    invoke-direct {p0, p1, p4, p2}, Lc5/o;-><init>(Ljava/lang/String;Ljava/lang/String;Lhx/w1;)V

    .line 28
    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1e
    new-instance p0, Lc5/e;

    .line 32
    .line 33
    const-string p3, "und"

    .line 34
    .line 35
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    invoke-direct {p0, p3, p1, p2}, Lc5/e;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    return-object p0

    .line 43
    :cond_2a
    new-instance p1, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string p2, "Failed to parse uint8 attribute: "

    .line 46
    .line 47
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-static {p0}, Lcz/j;->f(I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    const-string p1, "MetadataUtil"

    .line 62
    .line 63
    invoke-static {p1, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    return-object p4
.end method

.method public static h([B)Ldu/n;
    .registers 14

    .line 1
    new-instance v0, Ln3/x;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ln3/x;-><init>([B)V

    .line 4
    .line 5
    .line 6
    iget p0, v0, Ln3/x;->c:I

    .line 7
    .line 8
    const/16 v1, 0x20

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    if-ge p0, v1, :cond_d

    .line 12
    .line 13
    return-object v2

    .line 14
    :cond_d
    const/4 p0, 0x0

    .line 15
    invoke-virtual {v0, p0}, Ln3/x;->N(I)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Ln3/x;->a()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    const-string v4, "PsshAtomUtil"

    .line 27
    .line 28
    if-eq v3, v1, :cond_37

    .line 29
    .line 30
    new-instance p0, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string v0, "Advertised atom size ("

    .line 33
    .line 34
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v0, ") does not match buffer size: "

    .line 41
    .line 42
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    invoke-static {v4, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    return-object v2

    .line 56
    :cond_37
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const v3, 0x70737368    # 3.013775E29f

    .line 61
    .line 62
    .line 63
    if-eq v1, v3, :cond_46

    .line 64
    .line 65
    const-string p0, "Atom type is not pssh: "

    .line 66
    .line 67
    invoke-static {v1, p0, v4}, Lhs/q;->r(ILjava/lang/String;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    return-object v2

    .line 71
    :cond_46
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    invoke-static {v1}, Li5/e;->e(I)I

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    const/4 v3, 0x1

    .line 80
    if-le v1, v3, :cond_57

    .line 81
    .line 82
    const-string p0, "Unsupported pssh version: "

    .line 83
    .line 84
    invoke-static {v1, p0, v4}, Lhs/q;->r(ILjava/lang/String;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    return-object v2

    .line 88
    :cond_57
    new-instance v5, Ljava/util/UUID;

    .line 89
    .line 90
    invoke-virtual {v0}, Ln3/x;->u()J

    .line 91
    .line 92
    .line 93
    move-result-wide v6

    .line 94
    invoke-virtual {v0}, Ln3/x;->u()J

    .line 95
    .line 96
    .line 97
    move-result-wide v8

    .line 98
    invoke-direct {v5, v6, v7, v8, v9}, Ljava/util/UUID;-><init>(JJ)V

    .line 99
    .line 100
    .line 101
    if-ne v1, v3, :cond_81

    .line 102
    .line 103
    invoke-virtual {v0}, Ln3/x;->E()I

    .line 104
    .line 105
    .line 106
    move-result v3

    .line 107
    new-array v6, v3, [Ljava/util/UUID;

    .line 108
    .line 109
    move v7, p0

    .line 110
    :goto_6d
    if-ge v7, v3, :cond_82

    .line 111
    .line 112
    new-instance v8, Ljava/util/UUID;

    .line 113
    .line 114
    invoke-virtual {v0}, Ln3/x;->u()J

    .line 115
    .line 116
    .line 117
    move-result-wide v9

    .line 118
    invoke-virtual {v0}, Ln3/x;->u()J

    .line 119
    .line 120
    .line 121
    move-result-wide v11

    .line 122
    invoke-direct {v8, v9, v10, v11, v12}, Ljava/util/UUID;-><init>(JJ)V

    .line 123
    .line 124
    .line 125
    aput-object v8, v6, v7

    .line 126
    .line 127
    add-int/lit8 v7, v7, 0x1

    .line 128
    .line 129
    goto :goto_6d

    .line 130
    :cond_81
    move-object v6, v2

    .line 131
    :cond_82
    invoke-virtual {v0}, Ln3/x;->E()I

    .line 132
    .line 133
    .line 134
    move-result v3

    .line 135
    invoke-virtual {v0}, Ln3/x;->a()I

    .line 136
    .line 137
    .line 138
    move-result v7

    .line 139
    if-eq v3, v7, :cond_a6

    .line 140
    .line 141
    new-instance p0, Ljava/lang/StringBuilder;

    .line 142
    .line 143
    const-string v0, "Atom data size ("

    .line 144
    .line 145
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 149
    .line 150
    .line 151
    const-string v0, ") does not match the bytes left: "

    .line 152
    .line 153
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {p0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 157
    .line 158
    .line 159
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object p0

    .line 163
    invoke-static {v4, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    return-object v2

    .line 167
    :cond_a6
    new-array v2, v3, [B

    .line 168
    .line 169
    invoke-virtual {v0, v2, p0, v3}, Ln3/x;->k([BII)V

    .line 170
    .line 171
    .line 172
    new-instance p0, Ldu/n;

    .line 173
    .line 174
    invoke-direct {p0, v5, v1, v2, v6}, Ldu/n;-><init>(Ljava/util/UUID;I[B[Ljava/util/UUID;)V

    .line 175
    .line 176
    .line 177
    return-object p0
.end method

.method public static i(Ljava/util/UUID;[B)[B
    .registers 5

    .line 1
    invoke-static {p1}, Li5/s;->h([B)Ldu/n;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 v0, 0x0

    .line 6
    if-nez p1, :cond_8

    .line 7
    .line 8
    return-object v0

    .line 9
    :cond_8
    iget-object v1, p1, Ldu/n;->i:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, Ljava/util/UUID;

    .line 12
    .line 13
    invoke-virtual {p0, v1}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-nez v2, :cond_33

    .line 18
    .line 19
    new-instance p1, Ljava/lang/StringBuilder;

    .line 20
    .line 21
    const-string v2, "UUID mismatch. Expected: "

    .line 22
    .line 23
    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const-string p0, ", got: "

    .line 30
    .line 31
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const-string p0, "."

    .line 38
    .line 39
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    const-string p1, "PsshAtomUtil"

    .line 47
    .line 48
    invoke-static {p1, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    return-object v0

    .line 52
    :cond_33
    iget-object p0, p1, Ldu/n;->v:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p0, [B

    .line 55
    .line 56
    return-object p0
.end method

.method public static j(ILjava/lang/String;Ln3/x;)Lc5/o;
    .registers 7

    .line 1
    invoke-virtual {p2}, Ln3/x;->m()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p2}, Ln3/x;->m()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, 0x64617461

    .line 10
    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    if-ne v1, v2, :cond_23

    .line 14
    .line 15
    const/16 p0, 0x8

    .line 16
    .line 17
    invoke-virtual {p2, p0}, Ln3/x;->O(I)V

    .line 18
    .line 19
    .line 20
    add-int/lit8 v0, v0, -0x10

    .line 21
    .line 22
    invoke-virtual {p2, v0}, Ln3/x;->w(I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    new-instance p2, Lc5/o;

    .line 27
    .line 28
    invoke-static {p0}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-direct {p2, p1, v3, p0}, Lc5/o;-><init>(Ljava/lang/String;Ljava/lang/String;Lhx/w1;)V

    .line 33
    .line 34
    .line 35
    return-object p2

    .line 36
    :cond_23
    new-instance p1, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    const-string p2, "Failed to parse text attribute: "

    .line 39
    .line 40
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    invoke-static {p0}, Lcz/j;->f(I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    const-string p1, "MetadataUtil"

    .line 55
    .line 56
    invoke-static {p1, p0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    return-object v3
.end method

.method public static varargs k(ILk3/t0;Lk3/v;Lk3/t0;[Lk3/t0;)V
    .registers 12

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p3, :cond_4

    .line 3
    .line 4
    goto :goto_b

    .line 5
    :cond_4
    new-instance p3, Lk3/t0;

    .line 6
    .line 7
    new-array v1, v0, [Lk3/s0;

    .line 8
    .line 9
    invoke-direct {p3, v1}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 10
    .line 11
    .line 12
    :goto_b
    if-eqz p1, :cond_5c

    .line 13
    .line 14
    invoke-static {}, Lhx/m0;->p()Lhx/j0;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iget-object p1, p1, Lk3/t0;->a:[Lk3/s0;

    .line 19
    .line 20
    array-length v2, p1

    .line 21
    move v3, v0

    .line 22
    :goto_15
    if-ge v3, v2, :cond_31

    .line 23
    .line 24
    aget-object v4, p1, v3

    .line 25
    .line 26
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    const-class v6, Lo3/a;

    .line 31
    .line 32
    invoke-virtual {v6, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-eqz v5, :cond_2e

    .line 37
    .line 38
    invoke-virtual {v6, v4}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    check-cast v4, Lk3/s0;

    .line 43
    .line 44
    invoke-virtual {v1, v4}, Lhx/f0;->c(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    add-int/lit8 v3, v3, 0x1

    .line 48
    .line 49
    goto :goto_15

    .line 50
    :cond_31
    invoke-virtual {v1}, Lhx/j0;->g()Lhx/w1;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-virtual {p1, v0}, Lhx/m0;->s(I)Lhx/k0;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    :cond_39
    :goto_39
    invoke-virtual {p1}, Lhx/a;->hasNext()Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_5c

    .line 63
    .line 64
    invoke-virtual {p1}, Lhx/a;->next()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    check-cast v1, Lo3/a;

    .line 69
    .line 70
    iget-object v2, v1, Lo3/a;->a:Ljava/lang/String;

    .line 71
    .line 72
    const-string v3, "com.android.capture.fps"

    .line 73
    .line 74
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    if-eqz v2, :cond_52

    .line 79
    .line 80
    const/4 v2, 0x2

    .line 81
    if-ne p0, v2, :cond_39

    .line 82
    .line 83
    :cond_52
    const/4 v2, 0x1

    .line 84
    new-array v2, v2, [Lk3/s0;

    .line 85
    .line 86
    aput-object v1, v2, v0

    .line 87
    .line 88
    invoke-virtual {p3, v2}, Lk3/t0;->a([Lk3/s0;)Lk3/t0;

    .line 89
    .line 90
    .line 91
    move-result-object p3

    .line 92
    goto :goto_39

    .line 93
    :cond_5c
    array-length p0, p4

    .line 94
    :goto_5d
    if-ge v0, p0, :cond_68

    .line 95
    .line 96
    aget-object p1, p4, v0

    .line 97
    .line 98
    invoke-virtual {p3, p1}, Lk3/t0;->b(Lk3/t0;)Lk3/t0;

    .line 99
    .line 100
    .line 101
    move-result-object p3

    .line 102
    add-int/lit8 v0, v0, 0x1

    .line 103
    .line 104
    goto :goto_5d

    .line 105
    :cond_68
    iget-object p0, p3, Lk3/t0;->a:[Lk3/s0;

    .line 106
    .line 107
    array-length p0, p0

    .line 108
    if-lez p0, :cond_6f

    .line 109
    .line 110
    iput-object p3, p2, Lk3/v;->l:Lk3/t0;

    .line 111
    .line 112
    :cond_6f
    return-void
.end method

.method public static l(Lo4/o;Z)Lo4/f0;
    .registers 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    const-wide/16 v3, -0x1

    .line 8
    .line 9
    cmp-long v5, v1, v3

    .line 10
    .line 11
    const-wide/16 v6, 0x1000

    .line 12
    .line 13
    if-eqz v5, :cond_14

    .line 14
    .line 15
    cmp-long v8, v1, v6

    .line 16
    .line 17
    if-lez v8, :cond_13

    .line 18
    .line 19
    goto :goto_14

    .line 20
    :cond_13
    move-wide v6, v1

    .line 21
    :cond_14
    :goto_14
    long-to-int v6, v6

    .line 22
    new-instance v7, Ln3/x;

    .line 23
    .line 24
    const/16 v8, 0x40

    .line 25
    .line 26
    invoke-direct {v7, v8}, Ln3/x;-><init>(I)V

    .line 27
    .line 28
    .line 29
    const/4 v8, 0x0

    .line 30
    move v9, v8

    .line 31
    move v10, v9

    .line 32
    :goto_1f
    if-ge v9, v6, :cond_2f

    .line 33
    .line 34
    const/16 v12, 0x8

    .line 35
    .line 36
    invoke-virtual {v7, v12}, Ln3/x;->K(I)V

    .line 37
    .line 38
    .line 39
    iget-object v13, v7, Ln3/x;->a:[B

    .line 40
    .line 41
    const/4 v14, 0x1

    .line 42
    invoke-interface {v0, v13, v8, v12, v14}, Lo4/o;->f([BIIZ)Z

    .line 43
    .line 44
    .line 45
    move-result v13

    .line 46
    if-nez v13, :cond_33

    .line 47
    .line 48
    :cond_2f
    const/16 v18, 0x0

    .line 49
    .line 50
    goto/16 :goto_da

    .line 51
    .line 52
    :cond_33
    invoke-virtual {v7}, Ln3/x;->C()J

    .line 53
    .line 54
    .line 55
    move-result-wide v15

    .line 56
    invoke-virtual {v7}, Ln3/x;->m()I

    .line 57
    .line 58
    .line 59
    move-result v13

    .line 60
    const-wide/16 v17, 0x1

    .line 61
    .line 62
    cmp-long v17, v15, v17

    .line 63
    .line 64
    if-nez v17, :cond_54

    .line 65
    .line 66
    iget-object v15, v7, Ln3/x;->a:[B

    .line 67
    .line 68
    invoke-interface {v0, v15, v12, v12}, Lo4/o;->q([BII)V

    .line 69
    .line 70
    .line 71
    const/16 v15, 0x10

    .line 72
    .line 73
    invoke-virtual {v7, v15}, Ln3/x;->M(I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v7}, Ln3/x;->u()J

    .line 77
    .line 78
    .line 79
    move-result-wide v16

    .line 80
    move-wide/from16 v3, v16

    .line 81
    .line 82
    move/from16 v17, v9

    .line 83
    .line 84
    goto :goto_6f

    .line 85
    :cond_54
    const-wide/16 v17, 0x0

    .line 86
    .line 87
    cmp-long v17, v15, v17

    .line 88
    .line 89
    if-nez v17, :cond_6b

    .line 90
    .line 91
    invoke-interface {v0}, Lo4/o;->getLength()J

    .line 92
    .line 93
    .line 94
    move-result-wide v17

    .line 95
    cmp-long v19, v17, v3

    .line 96
    .line 97
    if-eqz v19, :cond_6b

    .line 98
    .line 99
    invoke-interface {v0}, Lo4/o;->g()J

    .line 100
    .line 101
    .line 102
    move-result-wide v15

    .line 103
    sub-long v17, v17, v15

    .line 104
    .line 105
    int-to-long v3, v12

    .line 106
    add-long v15, v17, v3

    .line 107
    .line 108
    :cond_6b
    move/from16 v17, v9

    .line 109
    .line 110
    move-wide v3, v15

    .line 111
    move v15, v12

    .line 112
    :goto_6f
    int-to-long v8, v15

    .line 113
    cmp-long v18, v3, v8

    .line 114
    .line 115
    if-gez v18, :cond_85

    .line 116
    .line 117
    const/16 v18, 0x0

    .line 118
    .line 119
    const v11, 0x66726565

    .line 120
    .line 121
    .line 122
    if-ne v13, v11, :cond_7f

    .line 123
    .line 124
    if-ne v15, v12, :cond_7f

    .line 125
    .line 126
    move-wide v3, v8

    .line 127
    goto :goto_87

    .line 128
    :cond_7f
    new-instance v0, Li5/a;

    .line 129
    .line 130
    invoke-direct {v0, v13, v15, v3, v4}, Li5/a;-><init>(IIJ)V

    .line 131
    .line 132
    .line 133
    return-object v0

    .line 134
    :cond_85
    const/16 v18, 0x0

    .line 135
    .line 136
    :goto_87
    add-int v11, v17, v15

    .line 137
    .line 138
    const v15, 0x6d6f6f76

    .line 139
    .line 140
    .line 141
    if-eq v13, v15, :cond_96

    .line 142
    .line 143
    const v14, 0x75756964

    .line 144
    .line 145
    .line 146
    if-ne v13, v14, :cond_94

    .line 147
    .line 148
    goto :goto_96

    .line 149
    :cond_94
    move v14, v13

    .line 150
    goto :goto_a9

    .line 151
    :cond_96
    :goto_96
    long-to-int v14, v3

    .line 152
    add-int/2addr v6, v14

    .line 153
    move v14, v13

    .line 154
    if-eqz v5, :cond_a1

    .line 155
    .line 156
    int-to-long v12, v6

    .line 157
    cmp-long v12, v12, v1

    .line 158
    .line 159
    if-lez v12, :cond_a1

    .line 160
    .line 161
    long-to-int v6, v1

    .line 162
    :cond_a1
    if-ne v14, v15, :cond_a9

    .line 163
    .line 164
    move v9, v11

    .line 165
    :goto_a4
    const-wide/16 v3, -0x1

    .line 166
    .line 167
    const/4 v8, 0x0

    .line 168
    goto/16 :goto_1f

    .line 169
    .line 170
    :cond_a9
    :goto_a9
    const v12, 0x7472616b

    .line 171
    .line 172
    .line 173
    if-eq v14, v12, :cond_b8

    .line 174
    .line 175
    const v12, 0x6d646961

    .line 176
    .line 177
    .line 178
    if-eq v14, v12, :cond_b8

    .line 179
    .line 180
    const v12, 0x6d696e66

    .line 181
    .line 182
    .line 183
    if-ne v14, v12, :cond_bc

    .line 184
    .line 185
    :cond_b8
    move-wide/from16 v20, v1

    .line 186
    .line 187
    goto/16 :goto_16b

    .line 188
    .line 189
    :cond_bc
    const v12, 0x6d6f6f66

    .line 190
    .line 191
    .line 192
    if-eq v14, v12, :cond_169

    .line 193
    .line 194
    const v12, 0x6d766578

    .line 195
    .line 196
    .line 197
    if-ne v14, v12, :cond_c8

    .line 198
    .line 199
    goto/16 :goto_169

    .line 200
    .line 201
    :cond_c8
    const v12, 0x6d646174

    .line 202
    .line 203
    .line 204
    if-ne v14, v12, :cond_ce

    .line 205
    .line 206
    const/4 v10, 0x1

    .line 207
    :cond_ce
    const v12, 0x7374626c

    .line 208
    .line 209
    .line 210
    if-ne v14, v12, :cond_dd

    .line 211
    .line 212
    const-wide/32 v12, 0xf4240

    .line 213
    .line 214
    .line 215
    cmp-long v12, v3, v12

    .line 216
    .line 217
    if-lez v12, :cond_dd

    .line 218
    .line 219
    :goto_da
    const/4 v8, 0x0

    .line 220
    goto/16 :goto_16d

    .line 221
    .line 222
    :cond_dd
    int-to-long v12, v11

    .line 223
    add-long/2addr v12, v3

    .line 224
    sub-long/2addr v12, v8

    .line 225
    move-wide/from16 v20, v1

    .line 226
    .line 227
    int-to-long v1, v6

    .line 228
    cmp-long v1, v12, v1

    .line 229
    .line 230
    if-ltz v1, :cond_e8

    .line 231
    .line 232
    goto :goto_da

    .line 233
    :cond_e8
    sub-long/2addr v3, v8

    .line 234
    long-to-int v1, v3

    .line 235
    add-int v9, v11, v1

    .line 236
    .line 237
    const v2, 0x66747970

    .line 238
    .line 239
    .line 240
    if-ne v14, v2, :cond_160

    .line 241
    .line 242
    const/16 v2, 0x8

    .line 243
    .line 244
    if-ge v1, v2, :cond_fc

    .line 245
    .line 246
    new-instance v0, Li5/a;

    .line 247
    .line 248
    int-to-long v3, v1

    .line 249
    invoke-direct {v0, v14, v2, v3, v4}, Li5/a;-><init>(IIJ)V

    .line 250
    .line 251
    .line 252
    return-object v0

    .line 253
    :cond_fc
    invoke-virtual {v7, v1}, Ln3/x;->K(I)V

    .line 254
    .line 255
    .line 256
    iget-object v2, v7, Ln3/x;->a:[B

    .line 257
    .line 258
    const/4 v3, 0x0

    .line 259
    invoke-interface {v0, v2, v3, v1}, Lo4/o;->q([BII)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v7}, Ln3/x;->m()I

    .line 263
    .line 264
    .line 265
    move-result v1

    .line 266
    ushr-int/lit8 v2, v1, 0x8

    .line 267
    .line 268
    const/16 v4, 0x1d

    .line 269
    .line 270
    sget-object v8, Li5/s;->a:[I

    .line 271
    .line 272
    const v11, 0x336770

    .line 273
    .line 274
    .line 275
    if-ne v2, v11, :cond_115

    .line 276
    .line 277
    goto :goto_11c

    .line 278
    :cond_115
    move v2, v3

    .line 279
    :goto_116
    if-ge v2, v4, :cond_121

    .line 280
    .line 281
    aget v12, v8, v2

    .line 282
    .line 283
    if-ne v12, v1, :cond_11e

    .line 284
    .line 285
    :goto_11c
    const/4 v10, 0x1

    .line 286
    goto :goto_121

    .line 287
    :cond_11e
    add-int/lit8 v2, v2, 0x1

    .line 288
    .line 289
    goto :goto_116

    .line 290
    :cond_121
    :goto_121
    const/4 v2, 0x4

    .line 291
    invoke-virtual {v7, v2}, Ln3/x;->O(I)V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v7}, Ln3/x;->a()I

    .line 295
    .line 296
    .line 297
    move-result v12

    .line 298
    div-int/2addr v12, v2

    .line 299
    if-nez v10, :cond_153

    .line 300
    .line 301
    if-lez v12, :cond_153

    .line 302
    .line 303
    new-array v2, v12, [I

    .line 304
    .line 305
    move v13, v3

    .line 306
    :goto_131
    if-ge v13, v12, :cond_150

    .line 307
    .line 308
    invoke-virtual {v7}, Ln3/x;->m()I

    .line 309
    .line 310
    .line 311
    move-result v14

    .line 312
    aput v14, v2, v13

    .line 313
    .line 314
    ushr-int/lit8 v15, v14, 0x8

    .line 315
    .line 316
    if-ne v15, v11, :cond_13e

    .line 317
    .line 318
    goto :goto_145

    .line 319
    :cond_13e
    move v15, v3

    .line 320
    :goto_13f
    if-ge v15, v4, :cond_14c

    .line 321
    .line 322
    aget v3, v8, v15

    .line 323
    .line 324
    if-ne v3, v14, :cond_148

    .line 325
    .line 326
    :goto_145
    move-object v11, v2

    .line 327
    const/4 v14, 0x1

    .line 328
    goto :goto_156

    .line 329
    :cond_148
    add-int/lit8 v15, v15, 0x1

    .line 330
    .line 331
    const/4 v3, 0x0

    .line 332
    goto :goto_13f

    .line 333
    :cond_14c
    add-int/lit8 v13, v13, 0x1

    .line 334
    .line 335
    const/4 v3, 0x0

    .line 336
    goto :goto_131

    .line 337
    :cond_150
    move-object v11, v2

    .line 338
    move v14, v10

    .line 339
    goto :goto_156

    .line 340
    :cond_153
    move v14, v10

    .line 341
    move-object/from16 v11, v18

    .line 342
    .line 343
    :goto_156
    if-nez v14, :cond_15e

    .line 344
    .line 345
    new-instance v0, Lg8/a0;

    .line 346
    .line 347
    invoke-direct {v0, v1, v11}, Lg8/a0;-><init>(I[I)V

    .line 348
    .line 349
    .line 350
    return-object v0

    .line 351
    :cond_15e
    move v10, v14

    .line 352
    goto :goto_165

    .line 353
    :cond_160
    if-eqz v1, :cond_165

    .line 354
    .line 355
    invoke-interface {v0, v1}, Lo4/o;->h(I)V

    .line 356
    .line 357
    .line 358
    :cond_165
    :goto_165
    move-wide/from16 v1, v20

    .line 359
    .line 360
    goto/16 :goto_a4

    .line 361
    .line 362
    :cond_169
    :goto_169
    const/4 v8, 0x1

    .line 363
    goto :goto_16d

    .line 364
    :goto_16b
    move v9, v11

    .line 365
    goto :goto_165

    .line 366
    :goto_16d
    if-nez v10, :cond_172

    .line 367
    .line 368
    sget-object v0, Li5/p;->d:Li5/p;

    .line 369
    .line 370
    return-object v0

    .line 371
    :cond_172
    move/from16 v0, p1

    .line 372
    .line 373
    if-eq v0, v8, :cond_17e

    .line 374
    .line 375
    if-eqz v8, :cond_17b

    .line 376
    .line 377
    sget-object v0, Li5/l;->e:Li5/l;

    .line 378
    .line 379
    return-object v0

    .line 380
    :cond_17b
    sget-object v0, Li5/l;->i:Li5/l;

    .line 381
    .line 382
    return-object v0

    .line 383
    :cond_17e
    return-object v18
.end method
