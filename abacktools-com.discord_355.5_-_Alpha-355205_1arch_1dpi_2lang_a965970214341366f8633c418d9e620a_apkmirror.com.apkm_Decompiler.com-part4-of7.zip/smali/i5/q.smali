###### Class i5.q (i5.q)
.class public final Li5/q;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:I


# direct methods
.method public constructor <init>(JI)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Li5/q;->a:J

    .line 5
    .line 6
    iput p3, p0, Li5/q;->b:I

    .line 7
    .line 8
    return-void
.end method
