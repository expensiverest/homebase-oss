###### Class i5.h (i5.h)
.class public final Li5/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:Z

.field public final c:I


# direct methods
.method public constructor <init>(IJZ)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p2, p0, Li5/h;->a:J

    .line 5
    .line 6
    iput-boolean p4, p0, Li5/h;->b:Z

    .line 7
    .line 8
    iput p1, p0, Li5/h;->c:I

    .line 9
    .line 10
    return-void
.end method
