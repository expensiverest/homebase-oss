###### Class i5.p (i5.p)
.class public final Li5/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo4/f0;


# static fields
.field public static final d:Li5/p;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Li5/p;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Li5/p;->d:Li5/p;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 1
    const-string v0, "NoDeclaredBrand"

    .line 2
    .line 3
    return-object v0
.end method
