###### Class i5.n (i5.n)
.class public final Li5/n;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Li5/u;

.field public final b:Li5/w;

.field public final c:Lo4/i0;

.field public final d:Lo4/j0;

.field public final e:Z

.field public final f:Z

.field public g:I

.field public h:Lk3/w;


# direct methods
.method public constructor <init>(Li5/u;Li5/w;Lo4/i0;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li5/n;->a:Li5/u;

    .line 5
    .line 6
    iput-object p2, p0, Li5/n;->b:Li5/w;

    .line 7
    .line 8
    iput-object p3, p0, Li5/n;->c:Lo4/i0;

    .line 9
    .line 10
    iget p2, p1, Li5/u;->b:I

    .line 11
    .line 12
    iget-object p1, p1, Li5/u;->g:Lk3/w;

    .line 13
    .line 14
    const/4 p3, 0x2

    .line 15
    if-ne p2, p3, :cond_12

    .line 16
    .line 17
    const/4 p2, 0x1

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 p2, 0x0

    .line 20
    :goto_13
    iput-boolean p2, p0, Li5/n;->e:Z

    .line 21
    .line 22
    iget-object p2, p1, Lk3/w;->p:Ljava/lang/String;

    .line 23
    .line 24
    const-string p3, "application/x-itut-t35"

    .line 25
    .line 26
    invoke-static {p2, p3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result p2

    .line 30
    iput-boolean p2, p0, Li5/n;->f:Z

    .line 31
    .line 32
    const-string p2, "audio/true-hd"

    .line 33
    .line 34
    iget-object p1, p1, Lk3/w;->p:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    if-eqz p1, :cond_30

    .line 41
    .line 42
    new-instance p1, Lo4/j0;

    .line 43
    .line 44
    const/4 p2, 0x0

    .line 45
    invoke-direct {p1, p2}, Lo4/j0;-><init>(I)V

    .line 46
    .line 47
    .line 48
    goto :goto_31

    .line 49
    :cond_30
    const/4 p1, 0x0

    .line 50
    :goto_31
    iput-object p1, p0, Li5/n;->d:Lo4/j0;

    .line 51
    .line 52
    return-void
.end method
