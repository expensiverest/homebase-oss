###### Class i5.e (i5.e)
.class public abstract Li5/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Ln3/l0;->a:Ljava/lang/String;

    .line 2
    .line 3
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 4
    .line 5
    const-string v1, "OpusHead"

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Li5/e;->a:[B

    .line 12
    .line 13
    return-void
.end method

.method public static a(Ln3/x;)V
    .registers 4

    .line 1
    iget v0, p0, Ln3/x;->b:I

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-virtual {p0, v1}, Ln3/x;->O(I)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const v2, 0x68646c72    # 4.3148E24f

    .line 12
    .line 13
    .line 14
    if-eq v1, v2, :cond_11

    .line 15
    .line 16
    add-int/lit8 v0, v0, 0x4

    .line 17
    .line 18
    :cond_11
    invoke-virtual {p0, v0}, Ln3/x;->N(I)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public static b(Ln3/x;IIIILjava/lang/String;ZLk3/r;Lcom/google/android/gms/internal/play_billing/s1;I)V
    .registers 56

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p5

    move-object/from16 v5, p7

    move-object/from16 v6, p8

    .line 1
    sget-object v7, Lo4/a;->f:[I

    sget-object v8, Lo4/a;->d:[I

    add-int/lit8 v9, v2, 0x10

    invoke-virtual {v0, v9}, Ln3/x;->N(I)V

    const/4 v9, 0x6

    const/16 v10, 0x8

    if-eqz p6, :cond_24

    .line 2
    invoke-virtual {v0}, Ln3/x;->H()I

    move-result v12

    .line 3
    invoke-virtual {v0, v9}, Ln3/x;->O(I)V

    goto :goto_28

    .line 4
    :cond_24
    invoke-virtual {v0, v10}, Ln3/x;->O(I)V

    const/4 v12, 0x0

    :goto_28
    const/4 v13, 0x4

    const/4 v14, 0x2

    const/4 v11, 0x1

    const/16 v15, 0x10

    if-eqz v12, :cond_31

    if-ne v12, v11, :cond_36

    :cond_31
    move/from16 v18, v13

    move/from16 v19, v14

    goto :goto_93

    :cond_36
    if-ne v12, v14, :cond_c43

    .line 5
    invoke-virtual {v0, v15}, Ln3/x;->O(I)V

    .line 6
    invoke-virtual {v0}, Ln3/x;->u()J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v17

    move/from16 v19, v14

    .line 7
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->round(D)J

    move-result-wide v14

    long-to-int v12, v14

    .line 8
    invoke-virtual {v0}, Ln3/x;->E()I

    move-result v14

    .line 9
    invoke-virtual {v0, v13}, Ln3/x;->O(I)V

    .line 10
    invoke-virtual {v0}, Ln3/x;->E()I

    move-result v15

    .line 11
    invoke-virtual {v0}, Ln3/x;->E()I

    move-result v17

    and-int/lit8 v18, v17, 0x1

    if-eqz v18, :cond_60

    move/from16 v18, v11

    goto :goto_62

    :cond_60
    const/16 v18, 0x0

    :goto_62
    and-int/lit8 v17, v17, 0x2

    if-eqz v17, :cond_69

    move/from16 v17, v11

    goto :goto_6b

    :cond_69
    const/16 v17, 0x0

    :goto_6b
    if-eqz v18, :cond_7e

    if-eqz v17, :cond_76

    .line 12
    sget-object v17, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    :goto_71
    move/from16 v18, v13

    move-object/from16 v13, v17

    goto :goto_79

    :cond_76
    sget-object v17, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    goto :goto_71

    :goto_79
    invoke-static {v15, v13}, Ln3/l0;->B(ILjava/nio/ByteOrder;)I

    move-result v13

    goto :goto_8b

    :cond_7e
    move/from16 v18, v13

    if-eqz v17, :cond_85

    .line 13
    sget-object v13, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    goto :goto_87

    :cond_85
    sget-object v13, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    :goto_87
    invoke-static {v15, v13}, Ln3/l0;->E(ILjava/nio/ByteOrder;)I

    move-result v13

    :goto_8b
    if-nez v13, :cond_8e

    const/4 v13, -0x1

    .line 14
    :cond_8e
    invoke-virtual {v0, v10}, Ln3/x;->O(I)V

    const/4 v15, 0x0

    goto :goto_b3

    .line 15
    :goto_93
    invoke-virtual {v0}, Ln3/x;->H()I

    move-result v13

    .line 16
    invoke-virtual {v0, v9}, Ln3/x;->O(I)V

    .line 17
    invoke-virtual {v0}, Ln3/x;->B()I

    move-result v14

    .line 18
    iget v15, v0, Ln3/x;->b:I

    add-int/lit8 v15, v15, -0x4

    .line 19
    invoke-virtual {v0, v15}, Ln3/x;->N(I)V

    .line 20
    invoke-virtual {v0}, Ln3/x;->m()I

    move-result v15

    if-ne v12, v11, :cond_b0

    const/16 v12, 0x10

    .line 21
    invoke-virtual {v0, v12}, Ln3/x;->O(I)V

    :cond_b0
    move v12, v14

    move v14, v13

    const/4 v13, -0x1

    :goto_b3
    const v9, 0x73617762

    const v10, 0x73616d72

    const v11, 0x69616d66

    if-ne v1, v11, :cond_c1

    const/4 v12, -0x1

    const/4 v14, -0x1

    goto :goto_cc

    :cond_c1
    if-ne v1, v10, :cond_c7

    const/16 v12, 0x1f40

    :goto_c5
    const/4 v14, 0x1

    goto :goto_cc

    :cond_c7
    if-ne v1, v9, :cond_cc

    const/16 v12, 0x3e80

    goto :goto_c5

    .line 22
    :cond_cc
    :goto_cc
    iget v11, v0, Ln3/x;->b:I

    const v9, 0x656e6361

    if-ne v1, v9, :cond_100

    .line 23
    invoke-static {v0, v2, v3}, Li5/e;->h(Ln3/x;II)Landroid/util/Pair;

    move-result-object v9

    if-eqz v9, :cond_fb

    .line 24
    iget-object v1, v9, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-nez v5, :cond_e5

    const/4 v10, 0x0

    goto :goto_f0

    .line 25
    :cond_e5
    iget-object v10, v9, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v10, Li5/v;

    iget-object v10, v10, Li5/v;->b:Ljava/lang/String;

    invoke-virtual {v5, v10}, Lk3/r;->z(Ljava/lang/String;)Lk3/r;

    move-result-object v5

    move-object v10, v5

    .line 26
    :goto_f0
    iget-object v5, v6, Lcom/google/android/gms/internal/play_billing/s1;->i:Ljava/lang/Object;

    check-cast v5, [Li5/v;

    iget-object v9, v9, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v9, Li5/v;

    aput-object v9, v5, p9

    goto :goto_fc

    :cond_fb
    move-object v10, v5

    .line 27
    :goto_fc
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    goto :goto_101

    :cond_100
    move-object v10, v5

    :goto_101
    const v5, 0x61632d33

    .line 28
    const-string v9, "audio/mhm1"

    const-string v25, "audio/ac4"

    const-string v26, "audio/eac3"

    const-string v27, "audio/ac3"

    const-string v28, "audio/raw"

    if-ne v1, v5, :cond_114

    move-object/from16 v5, v27

    goto/16 :goto_1d5

    :cond_114
    const v5, 0x65632d33

    if-ne v1, v5, :cond_11d

    move-object/from16 v5, v26

    goto/16 :goto_1d5

    :cond_11d
    const v5, 0x61632d34

    if-ne v1, v5, :cond_126

    move-object/from16 v5, v25

    goto/16 :goto_1d5

    :cond_126
    const v5, 0x64747363

    if-ne v1, v5, :cond_12f

    .line 29
    const-string v5, "audio/vnd.dts"

    goto/16 :goto_1d5

    :cond_12f
    const v5, 0x64747368

    if-eq v1, v5, :cond_1d3

    const v5, 0x6474736c

    if-ne v1, v5, :cond_13b

    goto/16 :goto_1d3

    :cond_13b
    const v5, 0x64747365

    if-ne v1, v5, :cond_144

    .line 30
    const-string v5, "audio/vnd.dts.hd;profile=lbr"

    goto/16 :goto_1d5

    :cond_144
    const v5, 0x64747378

    if-ne v1, v5, :cond_14d

    .line 31
    const-string v5, "audio/vnd.dts.uhd;profile=p2"

    goto/16 :goto_1d5

    :cond_14d
    const v5, 0x73616d72

    if-ne v1, v5, :cond_156

    .line 32
    const-string v5, "audio/3gpp"

    goto/16 :goto_1d5

    :cond_156
    const v5, 0x73617762

    if-ne v1, v5, :cond_15f

    .line 33
    const-string v5, "audio/amr-wb"

    goto/16 :goto_1d5

    :cond_15f
    const v5, 0x736f7774

    if-ne v1, v5, :cond_16a

    :goto_164
    move/from16 v13, v19

    :cond_166
    :goto_166
    move-object/from16 v5, v28

    goto/16 :goto_1d5

    :cond_16a
    const v5, 0x74776f73

    if-ne v1, v5, :cond_173

    const/high16 v5, 0x10000000

    move v13, v5

    goto :goto_166

    :cond_173
    const v5, 0x6c70636d

    if-ne v1, v5, :cond_17c

    const/4 v5, -0x1

    if-ne v13, v5, :cond_166

    goto :goto_164

    :cond_17c
    const v5, 0x2e6d7032

    if-eq v1, v5, :cond_1d0

    const v5, 0x2e6d7033

    if-ne v1, v5, :cond_187

    goto :goto_1d0

    :cond_187
    const v5, 0x6d686131

    if-ne v1, v5, :cond_18f

    .line 34
    const-string v5, "audio/mha1"

    goto :goto_1d5

    :cond_18f
    const v5, 0x6d686d31

    if-ne v1, v5, :cond_196

    move-object v5, v9

    goto :goto_1d5

    :cond_196
    const v5, 0x616c6163

    if-ne v1, v5, :cond_19e

    .line 35
    const-string v5, "audio/alac"

    goto :goto_1d5

    :cond_19e
    const v5, 0x616c6177

    if-ne v1, v5, :cond_1a6

    .line 36
    const-string v5, "audio/g711-alaw"

    goto :goto_1d5

    :cond_1a6
    const v5, 0x756c6177

    if-ne v1, v5, :cond_1ae

    .line 37
    const-string v5, "audio/g711-mlaw"

    goto :goto_1d5

    :cond_1ae
    const v5, 0x4f707573

    if-ne v1, v5, :cond_1b6

    .line 38
    const-string v5, "audio/opus"

    goto :goto_1d5

    :cond_1b6
    const v5, 0x664c6143

    if-ne v1, v5, :cond_1be

    .line 39
    const-string v5, "audio/flac"

    goto :goto_1d5

    :cond_1be
    const v5, 0x6d6c7061

    if-ne v1, v5, :cond_1c6

    .line 40
    const-string v5, "audio/true-hd"

    goto :goto_1d5

    :cond_1c6
    const v5, 0x69616d66

    if-ne v1, v5, :cond_1ce

    .line 41
    const-string v5, "audio/iamf"

    goto :goto_1d5

    :cond_1ce
    const/4 v5, 0x0

    goto :goto_1d5

    .line 42
    :cond_1d0
    :goto_1d0
    const-string v5, "audio/mpeg"

    goto :goto_1d5

    .line 43
    :cond_1d3
    :goto_1d3
    const-string v5, "audio/vnd.dts.hd"

    :goto_1d5
    move-object/from16 v22, v7

    move-object/from16 v23, v8

    const/16 p7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/16 v29, 0x0

    :goto_1df
    sub-int v8, v11, p2

    if-ge v8, v3, :cond_bdd

    .line 44
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    .line 45
    invoke-virtual {v0}, Ln3/x;->m()I

    move-result v8

    if-lez v8, :cond_1f0

    const/4 v3, 0x1

    :goto_1ed
    move/from16 v24, v13

    goto :goto_1f2

    :cond_1f0
    const/4 v3, 0x0

    goto :goto_1ed

    .line 46
    :goto_1f2
    const-string v13, "childAtomSize must be positive"

    invoke-static {v13, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 47
    invoke-virtual {v0}, Ln3/x;->m()I

    move-result v3

    move-object/from16 p9, v2

    const v2, 0x6d686143

    if-ne v3, v2, :cond_266

    add-int/lit8 v2, v11, 0x8

    .line 48
    invoke-virtual {v0, v2}, Ln3/x;->N(I)V

    const/4 v2, 0x1

    .line 49
    invoke-virtual {v0, v2}, Ln3/x;->O(I)V

    .line 50
    invoke-virtual {v0}, Ln3/x;->A()I

    move-result v3

    .line 51
    invoke-virtual {v0, v2}, Ln3/x;->O(I)V

    .line 52
    invoke-static {v5, v9}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_227

    .line 53
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "mhm1.%02X"

    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    goto :goto_235

    .line 54
    :cond_227
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "mha1.%02X"

    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 55
    :goto_235
    invoke-virtual {v0}, Ln3/x;->H()I

    move-result v3

    .line 56
    new-array v13, v3, [B

    move-object/from16 p9, v2

    const/4 v2, 0x0

    .line 57
    invoke-virtual {v0, v13, v2, v3}, Ln3/x;->k([BII)V

    if-nez v7, :cond_249

    .line 58
    invoke-static {v13}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    move-result-object v3

    move-object v7, v3

    goto :goto_254

    .line 59
    :cond_249
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [B

    invoke-static {v13, v3}, Lhx/m0;->w(Ljava/lang/Object;Ljava/lang/Object;)Lhx/w1;

    move-result-object v2

    move-object v7, v2

    :cond_254
    :goto_254
    move-object/from16 v0, p7

    move-object/from16 v2, p9

    move-object/from16 v34, v5

    move-object/from16 v36, v9

    move/from16 v9, v19

    :goto_25e
    const/4 v13, 0x0

    const/16 v17, 0x6

    const/16 v20, 0x8

    move v5, v1

    goto/16 :goto_bc9

    :cond_266
    const v2, 0x6d686150

    if-ne v3, v2, :cond_28e

    add-int/lit8 v2, v11, 0x8

    .line 60
    invoke-virtual {v0, v2}, Ln3/x;->N(I)V

    .line 61
    invoke-virtual {v0}, Ln3/x;->A()I

    move-result v2

    if-lez v2, :cond_254

    .line 62
    new-array v3, v2, [B

    const/4 v13, 0x0

    .line 63
    invoke-virtual {v0, v3, v13, v2}, Ln3/x;->k([BII)V

    if-nez v7, :cond_283

    .line 64
    invoke-static {v3}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    move-result-object v7

    goto :goto_254

    .line 65
    :cond_283
    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [B

    invoke-static {v2, v3}, Lhx/m0;->w(Ljava/lang/Object;Ljava/lang/Object;)Lhx/w1;

    move-result-object v7

    goto :goto_254

    :cond_28e
    const v2, 0x65736473

    if-eq v3, v2, :cond_29a

    if-eqz p6, :cond_2b1

    const v2, 0x77617665

    if-ne v3, v2, :cond_2b1

    :cond_29a
    move-object/from16 v34, v5

    move-object/from16 v33, v7

    move/from16 v32, v8

    move-object/from16 v36, v9

    move/from16 v40, v11

    move v2, v12

    const/16 v12, 0x10

    const/16 v17, 0x6

    const/16 v20, 0x8

    move v5, v1

    const v1, 0x65736473

    goto/16 :goto_ad2

    :cond_2b1
    const v2, 0x62747274

    if-ne v3, v2, :cond_2e3

    add-int/lit8 v2, v11, 0x8

    .line 66
    invoke-virtual {v0, v2}, Ln3/x;->N(I)V

    move/from16 v2, v18

    .line 67
    invoke-virtual {v0, v2}, Ln3/x;->O(I)V

    .line 68
    invoke-virtual {v0}, Ln3/x;->C()J

    move-result-wide v2

    move-object/from16 v33, v7

    move/from16 v32, v8

    .line 69
    invoke-virtual {v0}, Ln3/x;->C()J

    move-result-wide v7

    .line 70
    new-instance v13, Lbl/h;

    invoke-direct {v13, v7, v8, v2, v3}, Lbl/h;-><init>(JJ)V

    move-object/from16 v0, p7

    move-object/from16 v2, p9

    move-object/from16 v34, v5

    move-object/from16 v36, v9

    move-object/from16 v29, v13

    move/from16 v9, v19

    move/from16 v8, v32

    move-object/from16 v7, v33

    goto/16 :goto_25e

    :cond_2e3
    move-object/from16 v33, v7

    move/from16 v32, v8

    const v2, 0x64616333

    const/4 v8, 0x3

    if-ne v3, v2, :cond_35f

    add-int/lit8 v2, v11, 0x8

    .line 71
    invoke-virtual {v0, v2}, Ln3/x;->N(I)V

    .line 72
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    .line 73
    new-instance v3, Lct/f;

    move/from16 v13, v19

    invoke-direct {v3, v13}, Lct/f;-><init>(I)V

    .line 74
    invoke-virtual {v3, v0}, Lct/f;->o(Ln3/x;)V

    .line 75
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v30

    .line 76
    aget v13, v23, v30

    const/16 v7, 0x8

    .line 77
    invoke-virtual {v3, v7}, Lct/f;->u(I)V

    .line 78
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v7

    aget v7, v22, v7

    const/4 v8, 0x1

    .line 79
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v30

    if-eqz v30, :cond_31a

    add-int/lit8 v7, v7, 0x1

    :cond_31a
    const/4 v8, 0x5

    .line 80
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v8

    .line 81
    sget-object v30, Lo4/a;->g:[I

    aget v8, v30, v8

    mul-int/lit16 v8, v8, 0x3e8

    .line 82
    invoke-virtual {v3}, Lct/f;->c()V

    .line 83
    invoke-virtual {v3}, Lct/f;->f()I

    move-result v3

    invoke-virtual {v0, v3}, Ln3/x;->N(I)V

    .line 84
    new-instance v3, Lk3/v;

    invoke-direct {v3}, Lk3/v;-><init>()V

    .line 85
    iput-object v2, v3, Lk3/v;->a:Ljava/lang/String;

    .line 86
    invoke-static/range {v27 .. v27}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v3, Lk3/v;->o:Ljava/lang/String;

    .line 87
    iput v7, v3, Lk3/v;->I:I

    .line 88
    iput v13, v3, Lk3/v;->K:I

    .line 89
    iput-object v10, v3, Lk3/v;->s:Lk3/r;

    .line 90
    iput-object v4, v3, Lk3/v;->d:Ljava/lang/String;

    .line 91
    iput v8, v3, Lk3/v;->i:I

    .line 92
    iput v8, v3, Lk3/v;->j:I

    .line 93
    new-instance v2, Lk3/w;

    invoke-direct {v2, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 94
    iput-object v2, v6, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    move-object/from16 v34, v5

    move-object/from16 v36, v9

    move/from16 v40, v11

    move v2, v12

    const/16 v12, 0x10

    const/16 v17, 0x6

    const/16 v20, 0x8

    move v5, v1

    goto/16 :goto_ac3

    :cond_35f
    const v2, 0x64656333

    const/16 v13, 0xd

    if-ne v3, v2, :cond_40c

    add-int/lit8 v2, v11, 0x8

    .line 95
    invoke-virtual {v0, v2}, Ln3/x;->N(I)V

    .line 96
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    .line 97
    new-instance v3, Lct/f;

    const/4 v7, 0x2

    invoke-direct {v3, v7}, Lct/f;-><init>(I)V

    .line 98
    invoke-virtual {v3, v0}, Lct/f;->o(Ln3/x;)V

    .line 99
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v13

    mul-int/lit16 v13, v13, 0x3e8

    .line 100
    invoke-virtual {v3, v8}, Lct/f;->u(I)V

    .line 101
    invoke-virtual {v3, v7}, Lct/f;->i(I)I

    move-result v30

    .line 102
    aget v7, v23, v30

    move-object/from16 v34, v5

    const/16 v5, 0xa

    .line 103
    invoke-virtual {v3, v5}, Lct/f;->u(I)V

    .line 104
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v5

    aget v5, v22, v5

    const/4 v8, 0x1

    .line 105
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v21

    if-eqz v21, :cond_39d

    add-int/lit8 v5, v5, 0x1

    :cond_39d
    const/4 v8, 0x3

    .line 106
    invoke-virtual {v3, v8}, Lct/f;->u(I)V

    const/4 v8, 0x4

    .line 107
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v30

    const/4 v8, 0x1

    .line 108
    invoke-virtual {v3, v8}, Lct/f;->u(I)V

    move/from16 v21, v5

    if-lez v30, :cond_3c0

    const/4 v5, 0x6

    .line 109
    invoke-virtual {v3, v5}, Lct/f;->u(I)V

    .line 110
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v5

    if-eqz v5, :cond_3bb

    add-int/lit8 v5, v21, 0x2

    goto :goto_3bd

    :cond_3bb
    move/from16 v5, v21

    .line 111
    :goto_3bd
    invoke-virtual {v3, v8}, Lct/f;->u(I)V

    .line 112
    :cond_3c0
    invoke-virtual {v3}, Lct/f;->b()I

    move-result v8

    move-object/from16 v36, v9

    const/4 v9, 0x7

    if-le v8, v9, :cond_3d6

    .line 113
    invoke-virtual {v3, v9}, Lct/f;->u(I)V

    const/4 v8, 0x1

    .line 114
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v9

    if-eqz v9, :cond_3d6

    .line 115
    const-string v8, "audio/eac3-joc"

    goto :goto_3d8

    :cond_3d6
    move-object/from16 v8, v26

    .line 116
    :goto_3d8
    invoke-virtual {v3}, Lct/f;->c()V

    .line 117
    invoke-virtual {v3}, Lct/f;->f()I

    move-result v3

    invoke-virtual {v0, v3}, Ln3/x;->N(I)V

    .line 118
    new-instance v3, Lk3/v;

    invoke-direct {v3}, Lk3/v;-><init>()V

    .line 119
    iput-object v2, v3, Lk3/v;->a:Ljava/lang/String;

    .line 120
    invoke-static {v8}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v3, Lk3/v;->o:Ljava/lang/String;

    .line 121
    iput v5, v3, Lk3/v;->I:I

    .line 122
    iput v7, v3, Lk3/v;->K:I

    .line 123
    iput-object v10, v3, Lk3/v;->s:Lk3/r;

    .line 124
    iput-object v4, v3, Lk3/v;->d:Ljava/lang/String;

    .line 125
    iput v13, v3, Lk3/v;->j:I

    .line 126
    new-instance v2, Lk3/w;

    invoke-direct {v2, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 127
    iput-object v2, v6, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    move v5, v1

    move/from16 v40, v11

    move v2, v12

    const/16 v12, 0x10

    const/16 v17, 0x6

    const/16 v20, 0x8

    goto/16 :goto_ac3

    :cond_40c
    move-object/from16 v34, v5

    move-object/from16 v36, v9

    const v2, 0x64616334

    const/16 v9, 0x9

    if-ne v3, v2, :cond_815

    add-int/lit8 v2, v11, 0x8

    .line 128
    invoke-virtual {v0, v2}, Ln3/x;->N(I)V

    .line 129
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    .line 130
    new-instance v3, Lct/f;

    const/4 v13, 0x2

    invoke-direct {v3, v13}, Lct/f;-><init>(I)V

    .line 131
    invoke-virtual {v3, v0}, Lct/f;->o(Ln3/x;)V

    .line 132
    invoke-virtual {v3}, Lct/f;->b()I

    move-result v13

    const/4 v7, 0x3

    .line 133
    invoke-virtual {v3, v7}, Lct/f;->i(I)I

    move-result v5

    const/4 v7, 0x1

    if-gt v5, v7, :cond_802

    const/4 v8, 0x7

    .line 134
    invoke-virtual {v3, v8}, Lct/f;->i(I)I

    move-result v7

    .line 135
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v8

    if-eqz v8, :cond_447

    const v8, 0xbb80

    :goto_443
    move/from16 v38, v13

    const/4 v13, 0x4

    goto :goto_44b

    :cond_447
    const v8, 0xac44

    goto :goto_443

    .line 136
    :goto_44b
    invoke-virtual {v3, v13}, Lct/f;->u(I)V

    .line 137
    invoke-virtual {v3, v9}, Lct/f;->i(I)I

    move-result v9

    const/4 v13, 0x1

    if-le v7, v13, :cond_481

    if-eqz v5, :cond_46e

    .line 138
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v13

    if-eqz v13, :cond_481

    const/16 v13, 0x10

    .line 139
    invoke-virtual {v3, v13}, Lct/f;->u(I)V

    .line 140
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v13

    if-eqz v13, :cond_481

    const/16 v13, 0x80

    .line 141
    invoke-virtual {v3, v13}, Lct/f;->u(I)V

    goto :goto_481

    .line 142
    :cond_46e
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid AC-4 DSI version: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    :cond_481
    :goto_481
    const/4 v13, 0x1

    if-ne v5, v13, :cond_49c

    .line 143
    invoke-virtual {v3}, Lct/f;->b()I

    move-result v13

    move/from16 v39, v7

    const/16 v7, 0x42

    if-lt v13, v7, :cond_495

    .line 144
    invoke-virtual {v3, v7}, Lct/f;->u(I)V

    .line 145
    invoke-virtual {v3}, Lct/f;->c()V

    goto :goto_49e

    .line 146
    :cond_495
    const-string v0, "Invalid AC-4 DSI bitrate."

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    :cond_49c
    move/from16 v39, v7

    .line 147
    :goto_49e
    new-instance v7, Lo4/b;

    .line 148
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    const/4 v13, 0x1

    .line 149
    iput-boolean v13, v7, Lo4/b;->a:Z

    const/4 v13, -0x1

    .line 150
    iput v13, v7, Lo4/b;->b:I

    .line 151
    iput v13, v7, Lo4/b;->c:I

    const/4 v13, 0x1

    .line 152
    iput-boolean v13, v7, Lo4/b;->d:Z

    move/from16 v40, v11

    const/4 v11, 0x2

    .line 153
    iput v11, v7, Lo4/b;->e:I

    .line 154
    iput v13, v7, Lo4/b;->f:I

    const/4 v13, 0x0

    .line 155
    iput v13, v7, Lo4/b;->g:I

    const/4 v11, 0x0

    :goto_4b9
    if-ge v11, v9, :cond_6f6

    if-nez v5, :cond_4d8

    .line 156
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v9

    const/4 v13, 0x5

    .line 157
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v30

    .line 158
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v37

    move/from16 v42, v12

    move/from16 v12, v37

    const/4 v13, 0x0

    const/16 v41, 0x0

    move/from16 v37, v9

    move/from16 v9, v30

    const/16 v30, 0x0

    goto :goto_52a

    :cond_4d8
    move/from16 v41, v9

    const/16 v13, 0x8

    .line 159
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v9

    move/from16 v42, v12

    .line 160
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v12

    const/16 v13, 0xff

    if-ne v12, v13, :cond_4f4

    const/16 v13, 0x10

    .line 161
    invoke-virtual {v3, v13}, Lct/f;->i(I)I

    move-result v43

    add-int v43, v43, v12

    move/from16 v12, v43

    :cond_4f4
    const/4 v13, 0x2

    if-le v9, v13, :cond_503

    mul-int/lit8 v12, v12, 0x8

    .line 162
    invoke-virtual {v3, v12}, Lct/f;->u(I)V

    add-int/lit8 v11, v11, 0x1

    move/from16 v9, v41

    move/from16 v12, v42

    goto :goto_4b9

    .line 163
    :cond_503
    invoke-virtual {v3}, Lct/f;->b()I

    move-result v13

    sub-int v13, v38, v13

    const/16 v20, 0x8

    div-int/lit8 v13, v13, 0x8

    move/from16 v41, v9

    move/from16 v43, v12

    const/4 v9, 0x5

    .line 164
    invoke-virtual {v3, v9}, Lct/f;->i(I)I

    move-result v12

    const/16 v9, 0x1f

    if-ne v12, v9, :cond_51c

    const/4 v9, 0x1

    goto :goto_51d

    :cond_51c
    const/4 v9, 0x0

    :goto_51d
    move/from16 v30, v41

    move/from16 v41, v9

    move v9, v12

    move/from16 v12, v30

    move/from16 v30, v13

    move/from16 v13, v43

    const/16 v37, 0x0

    .line 165
    :goto_52a
    iput v12, v7, Lo4/b;->f:I

    move/from16 v43, v14

    if-nez v37, :cond_53c

    if-nez v41, :cond_53c

    const/4 v14, 0x6

    if-ne v9, v14, :cond_53c

    move/from16 v44, v1

    move/from16 v45, v12

    const/4 v1, 0x1

    goto/16 :goto_65c

    :cond_53c
    move/from16 v44, v1

    const/4 v14, 0x3

    .line 166
    invoke-virtual {v3, v14}, Lct/f;->i(I)I

    move-result v1

    iput v1, v7, Lo4/b;->g:I

    .line 167
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    if-eqz v1, :cond_54f

    const/4 v1, 0x5

    .line 168
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    :cond_54f
    const/4 v1, 0x2

    .line 169
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    const/4 v14, 0x1

    if-ne v5, v14, :cond_55b

    if-eq v12, v14, :cond_55d

    if-ne v12, v1, :cond_55b

    goto :goto_55d

    :cond_55b
    :goto_55b
    const/4 v1, 0x5

    goto :goto_561

    .line 170
    :cond_55d
    :goto_55d
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    goto :goto_55b

    .line 171
    :goto_561
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    const/16 v1, 0xa

    .line 172
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    if-ne v5, v14, :cond_5b0

    if-lez v12, :cond_573

    .line 173
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    iput-boolean v1, v7, Lo4/b;->a:Z

    .line 174
    :cond_573
    iget-boolean v1, v7, Lo4/b;->a:Z

    if-eqz v1, :cond_5aa

    if-eq v12, v14, :cond_57c

    const/4 v1, 0x2

    if-ne v12, v1, :cond_57e

    :cond_57c
    const/4 v1, 0x5

    goto :goto_581

    :cond_57e
    :goto_57e
    const/16 v14, 0x18

    goto :goto_5a5

    .line 175
    :goto_581
    invoke-virtual {v3, v1}, Lct/f;->i(I)I

    move-result v14

    if-ltz v14, :cond_58d

    const/16 v1, 0xf

    if-gt v14, v1, :cond_58d

    .line 176
    iput v14, v7, Lo4/b;->b:I

    :cond_58d
    const/16 v1, 0xb

    if-lt v14, v1, :cond_5a3

    const/16 v1, 0xe

    if-gt v14, v1, :cond_5a3

    .line 177
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    iput-boolean v1, v7, Lo4/b;->d:Z

    const/4 v1, 0x2

    .line 178
    invoke-virtual {v3, v1}, Lct/f;->i(I)I

    move-result v14

    iput v14, v7, Lo4/b;->e:I

    goto :goto_57e

    :cond_5a3
    const/4 v1, 0x2

    goto :goto_57e

    .line 179
    :goto_5a5
    invoke-virtual {v3, v14}, Lct/f;->u(I)V

    const/4 v14, 0x1

    goto :goto_5ab

    :cond_5aa
    const/4 v1, 0x2

    :goto_5ab
    if-eq v12, v14, :cond_5b3

    if-ne v12, v1, :cond_5b0

    goto :goto_5b3

    :cond_5b0
    move/from16 v45, v12

    goto :goto_5de

    .line 180
    :cond_5b3
    :goto_5b3
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v14

    if-eqz v14, :cond_5c2

    .line 181
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v14

    if-eqz v14, :cond_5c2

    .line 182
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    .line 183
    :cond_5c2
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    if-eqz v1, :cond_5b0

    .line 184
    invoke-virtual {v3}, Lct/f;->t()V

    const/16 v1, 0x8

    .line 185
    invoke-virtual {v3, v1}, Lct/f;->i(I)I

    move-result v14

    move/from16 v45, v12

    const/4 v12, 0x0

    :goto_5d4
    if-ge v12, v14, :cond_5de

    .line 186
    invoke-virtual {v3, v1}, Lct/f;->u(I)V

    add-int/lit8 v12, v12, 0x1

    const/16 v1, 0x8

    goto :goto_5d4

    :cond_5de
    :goto_5de
    if-nez v37, :cond_64c

    if-eqz v41, :cond_5e4

    goto/16 :goto_64c

    .line 187
    :cond_5e4
    invoke-virtual {v3}, Lct/f;->t()V

    if-eqz v9, :cond_636

    const/4 v14, 0x1

    if-eq v9, v14, :cond_636

    const/4 v1, 0x2

    if-eq v9, v1, :cond_636

    const/4 v14, 0x3

    if-eq v9, v14, :cond_620

    const/4 v1, 0x4

    if-eq v9, v1, :cond_620

    const/4 v1, 0x5

    if-eq v9, v1, :cond_608

    const/4 v9, 0x7

    .line 188
    invoke-virtual {v3, v9}, Lct/f;->i(I)I

    move-result v1

    const/4 v9, 0x0

    :goto_5fe
    if-ge v9, v1, :cond_655

    const/16 v12, 0x8

    .line 189
    invoke-virtual {v3, v12}, Lct/f;->u(I)V

    add-int/lit8 v9, v9, 0x1

    goto :goto_5fe

    :cond_608
    if-nez v45, :cond_60e

    .line 190
    invoke-static {v3, v7}, Lo4/a;->q(Lct/f;Lo4/b;)V

    goto :goto_655

    :cond_60e
    const/4 v14, 0x3

    .line 191
    invoke-virtual {v3, v14}, Lct/f;->i(I)I

    move-result v1

    const/4 v9, 0x0

    :goto_614
    const/16 v19, 0x2

    add-int/lit8 v14, v1, 0x2

    if-ge v9, v14, :cond_655

    .line 192
    invoke-static {v3, v7}, Lo4/a;->r(Lct/f;Lo4/b;)V

    add-int/lit8 v9, v9, 0x1

    goto :goto_614

    :cond_620
    if-nez v45, :cond_62c

    const/4 v1, 0x0

    const/4 v14, 0x3

    :goto_624
    if-ge v1, v14, :cond_655

    .line 193
    invoke-static {v3, v7}, Lo4/a;->q(Lct/f;Lo4/b;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_624

    :cond_62c
    const/4 v1, 0x0

    :goto_62d
    const/4 v14, 0x3

    if-ge v1, v14, :cond_655

    .line 194
    invoke-static {v3, v7}, Lo4/a;->r(Lct/f;Lo4/b;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_62d

    :cond_636
    if-nez v45, :cond_642

    const/4 v1, 0x0

    const/4 v9, 0x2

    :goto_63a
    if-ge v1, v9, :cond_655

    .line 195
    invoke-static {v3, v7}, Lo4/a;->q(Lct/f;Lo4/b;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_63a

    :cond_642
    const/4 v1, 0x0

    :goto_643
    const/4 v9, 0x2

    if-ge v1, v9, :cond_655

    .line 196
    invoke-static {v3, v7}, Lo4/a;->r(Lct/f;Lo4/b;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_643

    :cond_64c
    :goto_64c
    if-nez v45, :cond_652

    .line 197
    invoke-static {v3, v7}, Lo4/a;->q(Lct/f;Lo4/b;)V

    goto :goto_655

    .line 198
    :cond_652
    invoke-static {v3, v7}, Lo4/a;->r(Lct/f;Lo4/b;)V

    .line 199
    :cond_655
    :goto_655
    invoke-virtual {v3}, Lct/f;->t()V

    .line 200
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    :goto_65c
    const/4 v9, 0x7

    if-eqz v1, :cond_66e

    .line 201
    invoke-virtual {v3, v9}, Lct/f;->i(I)I

    move-result v1

    const/4 v12, 0x0

    :goto_664
    if-ge v12, v1, :cond_66e

    const/16 v14, 0xf

    .line 202
    invoke-virtual {v3, v14}, Lct/f;->u(I)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_664

    :cond_66e
    if-lez v45, :cond_6b8

    .line 203
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    if-eqz v1, :cond_68e

    .line 204
    invoke-virtual {v3}, Lct/f;->b()I

    move-result v1

    const/16 v12, 0x42

    if-ge v1, v12, :cond_680

    const/4 v1, 0x0

    goto :goto_684

    .line 205
    :cond_680
    invoke-virtual {v3, v12}, Lct/f;->u(I)V

    const/4 v1, 0x1

    :goto_684
    if-eqz v1, :cond_687

    goto :goto_68e

    .line 206
    :cond_687
    const-string v0, "Can\'t parse bitrate DSI."

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    .line 207
    :cond_68e
    :goto_68e
    invoke-virtual {v3}, Lct/f;->h()Z

    move-result v1

    if-eqz v1, :cond_6b8

    .line 208
    invoke-virtual {v3}, Lct/f;->c()V

    const/16 v12, 0x10

    .line 209
    invoke-virtual {v3, v12}, Lct/f;->i(I)I

    move-result v1

    .line 210
    invoke-virtual {v3, v1}, Lct/f;->v(I)V

    const/4 v1, 0x5

    .line 211
    invoke-virtual {v3, v1}, Lct/f;->i(I)I

    move-result v14

    const/4 v1, 0x0

    :goto_6a6
    if-ge v1, v14, :cond_6b5

    const/4 v9, 0x3

    .line 212
    invoke-virtual {v3, v9}, Lct/f;->u(I)V

    const/16 v9, 0x8

    .line 213
    invoke-virtual {v3, v9}, Lct/f;->u(I)V

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x7

    goto :goto_6a6

    :cond_6b5
    const/16 v9, 0x8

    goto :goto_6bc

    :cond_6b8
    const/16 v9, 0x8

    const/16 v12, 0x10

    .line 214
    :goto_6bc
    invoke-virtual {v3}, Lct/f;->c()V

    const/4 v14, 0x1

    if-ne v5, v14, :cond_6d9

    .line 215
    invoke-virtual {v3}, Lct/f;->b()I

    move-result v1

    sub-int v1, v38, v1

    div-int/2addr v1, v9

    sub-int v1, v1, v30

    if-lt v13, v1, :cond_6d2

    sub-int/2addr v13, v1

    .line 216
    invoke-virtual {v3, v13}, Lct/f;->v(I)V

    goto :goto_6d9

    .line 217
    :cond_6d2
    const-string v0, "pres_bytes is smaller than presentation bytes read."

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    .line 218
    :cond_6d9
    :goto_6d9
    iget-boolean v1, v7, Lo4/b;->a:Z

    if-eqz v1, :cond_700

    iget v1, v7, Lo4/b;->b:I

    const/4 v13, -0x1

    if-eq v1, v13, :cond_6e3

    goto :goto_700

    .line 219
    :cond_6e3
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Can\'t determine channel mode of presentation "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    :cond_6f6
    move/from16 v44, v1

    move/from16 v42, v12

    move/from16 v43, v14

    const/16 v9, 0x8

    const/16 v12, 0x10

    .line 220
    :cond_700
    :goto_700
    iget-boolean v1, v7, Lo4/b;->a:Z

    const/16 v3, 0xc

    if-eqz v1, :cond_76b

    .line 221
    iget v1, v7, Lo4/b;->b:I

    iget-boolean v5, v7, Lo4/b;->d:Z

    iget v11, v7, Lo4/b;->e:I

    packed-switch v1, :pswitch_data_c44

    const/16 v13, 0xb

    const/16 v31, -0x1

    goto :goto_74d

    :pswitch_714
    const/16 v13, 0xb

    const/16 v31, 0x18

    goto :goto_74d

    :pswitch_719
    const/16 v13, 0xb

    const/16 v31, 0xe

    goto :goto_74d

    :pswitch_71e
    const/16 v13, 0xb

    const/16 v31, 0xd

    goto :goto_74d

    :pswitch_723
    move/from16 v31, v3

    :goto_725
    const/16 v13, 0xb

    goto :goto_74d

    :pswitch_728
    const/16 v13, 0xb

    const/16 v31, 0xb

    goto :goto_74d

    :pswitch_72d
    move/from16 v31, v9

    goto :goto_725

    :pswitch_730
    const/16 v13, 0xb

    const/16 v31, 0x7

    goto :goto_74d

    :pswitch_735
    const/16 v13, 0xb

    const/16 v31, 0x6

    goto :goto_74d

    :pswitch_73a
    const/16 v13, 0xb

    const/16 v31, 0x5

    goto :goto_74d

    :pswitch_73f
    const/16 v13, 0xb

    const/16 v31, 0x3

    goto :goto_74d

    :pswitch_744
    const/16 v13, 0xb

    const/16 v31, 0x2

    goto :goto_74d

    :pswitch_749
    const/16 v13, 0xb

    const/16 v31, 0x1

    :goto_74d
    if-eq v1, v13, :cond_759

    if-eq v1, v3, :cond_759

    const/16 v3, 0xd

    if-eq v1, v3, :cond_759

    const/16 v3, 0xe

    if-ne v1, v3, :cond_768

    :cond_759
    if-nez v5, :cond_75d

    add-int/lit8 v31, v31, -0x2

    :cond_75d
    if-eqz v11, :cond_766

    const/4 v13, 0x1

    if-eq v11, v13, :cond_763

    goto :goto_768

    :cond_763
    add-int/lit8 v31, v31, -0x2

    goto :goto_768

    :cond_766
    add-int/lit8 v31, v31, -0x4

    :cond_768
    :goto_768
    move/from16 v1, v31

    goto :goto_7b1

    .line 222
    :cond_76b
    iget v1, v7, Lo4/b;->c:I

    if-lez v1, :cond_77d

    add-int/lit8 v1, v1, 0x1

    .line 223
    iget v3, v7, Lo4/b;->g:I

    const/4 v13, 0x4

    if-ne v3, v13, :cond_7b1

    const/16 v3, 0x11

    if-ne v1, v3, :cond_7b1

    const/16 v1, 0x15

    goto :goto_7b1

    .line 224
    :cond_77d
    iget v1, v7, Lo4/b;->g:I

    if-eqz v1, :cond_7a7

    const/4 v13, 0x1

    if-eq v1, v13, :cond_7b0

    const/4 v13, 0x2

    if-eq v1, v13, :cond_7ae

    const/4 v14, 0x3

    if-eq v1, v14, :cond_7ab

    const/4 v13, 0x4

    if-eq v1, v13, :cond_7a9

    .line 225
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "AC-4 level "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v3, v7, Lo4/b;->g:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " has not been defined."

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "Ac4Util"

    invoke-static {v3, v1}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7a7
    const/4 v1, 0x2

    goto :goto_7b1

    :cond_7a9
    move v1, v3

    goto :goto_7b1

    :cond_7ab
    const/16 v1, 0xa

    goto :goto_7b1

    :cond_7ae
    move v1, v9

    goto :goto_7b1

    :cond_7b0
    const/4 v1, 0x6

    :cond_7b1
    :goto_7b1
    if-lez v1, :cond_7fb

    .line 226
    iget v3, v7, Lo4/b;->f:I

    iget v5, v7, Lo4/b;->g:I

    .line 227
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    filled-new-array {v7, v3, v5}, [Ljava/lang/Object;

    move-result-object v3

    .line 228
    sget-object v5, Ln3/l0;->a:Ljava/lang/String;

    .line 229
    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v7, "ac-4.%02d.%02d.%02d"

    invoke-static {v5, v7, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 230
    new-instance v5, Lk3/v;

    invoke-direct {v5}, Lk3/v;-><init>()V

    .line 231
    iput-object v2, v5, Lk3/v;->a:Ljava/lang/String;

    .line 232
    invoke-static/range {v25 .. v25}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v5, Lk3/v;->o:Ljava/lang/String;

    .line 233
    iput v1, v5, Lk3/v;->I:I

    .line 234
    iput v8, v5, Lk3/v;->K:I

    .line 235
    iput-object v10, v5, Lk3/v;->s:Lk3/r;

    .line 236
    iput-object v4, v5, Lk3/v;->d:Ljava/lang/String;

    .line 237
    iput-object v3, v5, Lk3/v;->k:Ljava/lang/String;

    .line 238
    new-instance v1, Lk3/w;

    invoke-direct {v1, v5}, Lk3/w;-><init>(Lk3/v;)V

    .line 239
    iput-object v1, v6, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    move/from16 v20, v9

    move/from16 v2, v42

    move/from16 v14, v43

    move/from16 v5, v44

    const/16 v17, 0x6

    goto/16 :goto_ac3

    .line 240
    :cond_7fb
    const-string v0, "Cannot determine channel count of presentation."

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    .line 241
    :cond_802
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unsupported AC-4 DSI version: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lk3/v0;->d(Ljava/lang/String;)Lk3/v0;

    move-result-object v0

    throw v0

    :cond_815
    move/from16 v44, v1

    move/from16 v40, v11

    move/from16 v42, v12

    move/from16 v43, v14

    const/16 v12, 0x10

    const/16 v20, 0x8

    const v1, 0x646d6c70

    if-ne v3, v1, :cond_850

    if-lez v15, :cond_83c

    move-object/from16 v0, p7

    move-object/from16 v2, p9

    move v12, v15

    move/from16 v8, v32

    move-object/from16 v7, v33

    move/from16 v11, v40

    move/from16 v5, v44

    const/4 v9, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x2

    :goto_838
    const/16 v17, 0x6

    goto/16 :goto_bc9

    .line 242
    :cond_83c
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid sample rate for Dolby TrueHD MLP stream: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    move-result-object v0

    throw v0

    :cond_850
    const v1, 0x64647473

    if-eq v3, v1, :cond_85a

    const v1, 0x75647473

    if-ne v3, v1, :cond_860

    :cond_85a
    move/from16 v5, v44

    const/16 v17, 0x6

    goto/16 :goto_a9f

    :cond_860
    const v1, 0x644f7073

    if-ne v3, v1, :cond_88d

    add-int/lit8 v8, v32, -0x8

    .line 243
    sget-object v1, Li5/e;->a:[B

    array-length v2, v1

    add-int/2addr v2, v8

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v2

    add-int/lit8 v11, v40, 0x8

    .line 244
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    .line 245
    array-length v1, v1

    invoke-virtual {v0, v2, v1, v8}, Ln3/x;->k([BII)V

    .line 246
    invoke-static {v2}, Lo3/n;->a([B)Ljava/util/ArrayList;

    move-result-object v7

    :goto_87c
    move-object/from16 v0, p7

    move-object/from16 v2, p9

    move/from16 v8, v32

    move/from16 v11, v40

    move/from16 v12, v42

    move/from16 v14, v43

    move/from16 v5, v44

    const/4 v9, 0x2

    const/4 v13, 0x0

    goto :goto_838

    :cond_88d
    const v1, 0x64664c61

    if-ne v3, v1, :cond_8be

    add-int/lit8 v8, v32, -0xc

    add-int/lit8 v1, v32, -0x8

    .line 247
    new-array v1, v1, [B

    const/16 v2, 0x66

    const/16 v16, 0x0

    .line 248
    aput-byte v2, v1, v16

    const/16 v2, 0x4c

    const/16 v21, 0x1

    .line 249
    aput-byte v2, v1, v21

    const/16 v2, 0x61

    const/16 v19, 0x2

    .line 250
    aput-byte v2, v1, v19

    const/16 v2, 0x43

    const/16 v35, 0x3

    .line 251
    aput-byte v2, v1, v35

    add-int/lit8 v11, v40, 0xc

    .line 252
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    const/4 v13, 0x4

    .line 253
    invoke-virtual {v0, v1, v13, v8}, Ln3/x;->k([BII)V

    .line 254
    invoke-static {v1}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    move-result-object v7

    goto :goto_87c

    :cond_8be
    const v5, 0x616c6163

    if-ne v3, v5, :cond_923

    add-int/lit8 v8, v32, -0xc

    .line 255
    new-array v1, v8, [B

    add-int/lit8 v11, v40, 0xc

    .line 256
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    const/4 v13, 0x0

    .line 257
    invoke-virtual {v0, v1, v13, v8}, Ln3/x;->k([BII)V

    .line 258
    sget-object v2, Ln3/g;->a:[B

    .line 259
    new-instance v2, Ln3/x;

    invoke-direct {v2, v1}, Ln3/x;-><init>([B)V

    const/4 v8, 0x5

    .line 260
    invoke-virtual {v2, v8}, Ln3/x;->N(I)V

    .line 261
    invoke-virtual {v2}, Ln3/x;->A()I

    move-result v3

    .line 262
    invoke-virtual {v2, v9}, Ln3/x;->N(I)V

    .line 263
    invoke-virtual {v2}, Ln3/x;->A()I

    move-result v7

    const/16 v8, 0x14

    .line 264
    invoke-virtual {v2, v8}, Ln3/x;->N(I)V

    .line 265
    invoke-virtual {v2}, Ln3/x;->E()I

    move-result v2

    .line 266
    filled-new-array {v2, v7, v3}, [I

    move-result-object v2

    const/16 v16, 0x0

    .line 267
    aget v3, v2, v16

    const/16 v21, 0x1

    .line 268
    aget v7, v2, v21

    const/16 v19, 0x2

    .line 269
    aget v2, v2, v19

    .line 270
    sget-object v8, Ln3/l0;->a:Ljava/lang/String;

    .line 271
    sget-object v8, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-static {v2, v8}, Ln3/l0;->E(ILjava/nio/ByteOrder;)I

    move-result v2

    if-nez v2, :cond_90a

    const/4 v2, -0x1

    .line 272
    :cond_90a
    invoke-static {v1}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    move-result-object v1

    move-object/from16 v0, p7

    move/from16 v24, v2

    move v12, v3

    move v14, v7

    move/from16 v8, v32

    move/from16 v11, v40

    move/from16 v5, v44

    const/4 v9, 0x2

    const/4 v13, 0x0

    const/16 v17, 0x6

    move-object/from16 v2, p9

    move-object v7, v1

    goto/16 :goto_bc9

    :cond_923
    const v1, 0x69616362

    if-ne v3, v1, :cond_a48

    add-int/lit8 v11, v40, 0x9

    .line 273
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    .line 274
    invoke-virtual {v0}, Ln3/x;->F()I

    move-result v1

    .line 275
    new-array v2, v1, [B

    const/4 v13, 0x0

    .line 276
    invoke-virtual {v0, v2, v13, v1}, Ln3/x;->k([BII)V

    .line 277
    sget-object v1, Ln3/g;->a:[B

    .line 278
    new-instance v1, Ln3/x;

    invoke-direct {v1, v2}, Ln3/x;-><init>([B)V

    const/4 v3, 0x0

    const/4 v7, 0x0

    .line 279
    :goto_940
    invoke-virtual {v1}, Ln3/x;->a()I

    move-result v8

    if-lez v8, :cond_94b

    if-eqz v3, :cond_94f

    if-nez v7, :cond_94b

    goto :goto_94f

    :cond_94b
    const/16 v17, 0x6

    goto/16 :goto_a27

    .line 280
    :cond_94f
    :goto_94f
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v8

    shr-int/lit8 v9, v8, 0x3

    and-int/lit8 v11, v8, 0x2

    if-eqz v11, :cond_95b

    const/4 v11, 0x1

    goto :goto_95c

    :cond_95b
    const/4 v11, 0x0

    :goto_95c
    and-int/lit8 v8, v8, 0x1

    if-eqz v8, :cond_962

    const/4 v8, 0x1

    goto :goto_963

    :cond_962
    const/4 v8, 0x0

    .line 281
    :goto_963
    invoke-virtual {v1}, Ln3/x;->F()I

    move-result v13

    const/4 v14, 0x4

    if-le v9, v14, :cond_987

    const/16 v14, 0x18

    if-ge v9, v14, :cond_989

    if-eqz v11, :cond_989

    .line 282
    :goto_970
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v11

    const/16 v5, 0x80

    and-int/2addr v11, v5

    if-eqz v11, :cond_97d

    const v5, 0x616c6163

    goto :goto_970

    .line 283
    :cond_97d
    :goto_97d
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v11

    and-int/2addr v11, v5

    if-eqz v11, :cond_989

    const/16 v5, 0x80

    goto :goto_97d

    :cond_987
    const/16 v14, 0x18

    :cond_989
    if-eqz v8, :cond_992

    .line 284
    invoke-virtual {v1}, Ln3/x;->F()I

    move-result v5

    .line 285
    invoke-virtual {v1, v5}, Ln3/x;->O(I)V

    .line 286
    :cond_992
    iget v5, v1, Ln3/x;->b:I

    add-int/2addr v5, v13

    const/16 v8, 0x1f

    if-ne v9, v8, :cond_9c2

    const/4 v13, 0x4

    .line 287
    invoke-virtual {v1, v13}, Ln3/x;->O(I)V

    .line 288
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v3

    .line 289
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v8

    .line 290
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    filled-new-array {v3, v8}, [Ljava/lang/Object;

    move-result-object v3

    sget-object v8, Ln3/l0;->a:Ljava/lang/String;

    .line 291
    sget-object v8, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v9, "iamf.%03X.%03X"

    invoke-static {v8, v9, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    :cond_9bb
    const/16 v9, 0x1f

    const/16 v13, 0x80

    :goto_9bf
    const/16 v17, 0x6

    goto :goto_a1f

    :cond_9c2
    if-nez v9, :cond_9bb

    .line 292
    :goto_9c4
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v7

    const/16 v13, 0x80

    and-int/2addr v7, v13

    if-eqz v7, :cond_9ce

    goto :goto_9c4

    .line 293
    :cond_9ce
    sget-object v7, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v8, 0x4

    invoke-virtual {v1, v8, v7}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v7

    .line 294
    const-string v9, "mp4a"

    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_a1c

    .line 295
    :goto_9dd
    invoke-virtual {v1}, Ln3/x;->A()I

    move-result v9

    and-int/2addr v9, v13

    if-eqz v9, :cond_9e5

    goto :goto_9dd

    :cond_9e5
    const/4 v9, 0x2

    .line 296
    invoke-virtual {v1, v9}, Ln3/x;->O(I)V

    .line 297
    new-instance v11, Lct/f;

    invoke-direct {v11, v9}, Lct/f;-><init>(I)V

    .line 298
    invoke-virtual {v11, v1}, Lct/f;->o(Ln3/x;)V

    const/4 v9, 0x5

    .line 299
    invoke-virtual {v11, v9}, Lct/f;->i(I)I

    move-result v8

    const/16 v9, 0x1f

    if-ne v8, v9, :cond_a05

    const/4 v8, 0x6

    .line 300
    invoke-virtual {v11, v8}, Lct/f;->i(I)I

    move-result v11

    add-int/lit8 v11, v11, 0x20

    move/from16 v17, v8

    move v8, v11

    goto :goto_a07

    :cond_a05
    const/16 v17, 0x6

    .line 301
    :goto_a07
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, ".40."

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    goto :goto_a1f

    :cond_a1c
    const/16 v9, 0x1f

    goto :goto_9bf

    .line 302
    :goto_a1f
    invoke-virtual {v1, v5}, Ln3/x;->N(I)V

    const v5, 0x616c6163

    goto/16 :goto_940

    :goto_a27
    if-eqz v3, :cond_a32

    if-eqz v7, :cond_a32

    .line 303
    const-string v1, "."

    .line 304
    invoke-static {v3, v1, v7}, Lp/x2;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_a33

    :cond_a32
    const/4 v1, 0x0

    .line 305
    :goto_a33
    invoke-static {v2}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    move-result-object v7

    move-object/from16 v0, p7

    move-object v2, v1

    move/from16 v8, v32

    move/from16 v11, v40

    move/from16 v12, v42

    move/from16 v14, v43

    move/from16 v5, v44

    :goto_a44
    const/4 v9, 0x2

    const/4 v13, 0x0

    goto/16 :goto_bc9

    :cond_a48
    const/16 v17, 0x6

    const v1, 0x70636d43

    if-ne v3, v1, :cond_a98

    add-int/lit8 v11, v40, 0xc

    .line 306
    invoke-virtual {v0, v11}, Ln3/x;->N(I)V

    .line 307
    invoke-virtual {v0}, Ln3/x;->A()I

    move-result v1

    const/16 v21, 0x1

    and-int/lit8 v1, v1, 0x1

    if-eqz v1, :cond_a61

    .line 308
    sget-object v1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    goto :goto_a63

    :cond_a61
    sget-object v1, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 309
    :goto_a63
    invoke-virtual {v0}, Ln3/x;->A()I

    move-result v2

    const v3, 0x6970636d

    move/from16 v5, v44

    if-ne v5, v3, :cond_a73

    .line 310
    invoke-static {v2, v1}, Ln3/l0;->E(ILjava/nio/ByteOrder;)I

    move-result v1

    goto :goto_a7f

    :cond_a73
    const v3, 0x6670636d

    if-ne v5, v3, :cond_a7d

    .line 311
    invoke-static {v2, v1}, Ln3/l0;->B(ILjava/nio/ByteOrder;)I

    move-result v1

    goto :goto_a7f

    :cond_a7d
    move/from16 v1, v24

    :goto_a7f
    if-nez v1, :cond_a82

    const/4 v1, -0x1

    :cond_a82
    const/4 v13, -0x1

    move-object/from16 v0, p7

    move-object/from16 v2, p9

    move/from16 v24, v1

    if-eq v1, v13, :cond_a8d

    move-object/from16 v34, v28

    :cond_a8d
    move/from16 v8, v32

    move-object/from16 v7, v33

    move/from16 v11, v40

    move/from16 v12, v42

    move/from16 v14, v43

    goto :goto_a44

    :cond_a98
    move/from16 v5, v44

    move/from16 v2, v42

    move/from16 v14, v43

    goto :goto_ac3

    .line 312
    :goto_a9f
    new-instance v1, Lk3/v;

    invoke-direct {v1}, Lk3/v;-><init>()V

    .line 313
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lk3/v;->a:Ljava/lang/String;

    .line 314
    invoke-static/range {v34 .. v34}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lk3/v;->o:Ljava/lang/String;

    move/from16 v14, v43

    .line 315
    iput v14, v1, Lk3/v;->I:I

    move/from16 v2, v42

    .line 316
    iput v2, v1, Lk3/v;->K:I

    .line 317
    iput-object v10, v1, Lk3/v;->s:Lk3/r;

    .line 318
    iput-object v4, v1, Lk3/v;->d:Ljava/lang/String;

    .line 319
    new-instance v3, Lk3/w;

    invoke-direct {v3, v1}, Lk3/w;-><init>(Lk3/v;)V

    .line 320
    iput-object v3, v6, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    :goto_ac3
    move-object/from16 v0, p7

    move v12, v2

    move/from16 v8, v32

    move-object/from16 v7, v33

    move/from16 v11, v40

    const/4 v9, 0x2

    const/4 v13, 0x0

    move-object/from16 v2, p9

    goto/16 :goto_bc9

    :goto_ad2
    if-ne v3, v1, :cond_adb

    move/from16 v8, v32

    move/from16 v1, v40

    move v11, v1

    :goto_ad9
    const/4 v13, -0x1

    goto :goto_b0f

    .line 321
    :cond_adb
    iget v1, v0, Ln3/x;->b:I

    move/from16 v11, v40

    if-lt v1, v11, :cond_ae4

    const/4 v3, 0x1

    :goto_ae2
    const/4 v7, 0x0

    goto :goto_ae6

    :cond_ae4
    const/4 v3, 0x0

    goto :goto_ae2

    .line 322
    :goto_ae6
    invoke-static {v7, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    :goto_ae9
    sub-int v3, v1, v11

    move/from16 v8, v32

    if-ge v3, v8, :cond_b0d

    .line 323
    invoke-virtual {v0, v1}, Ln3/x;->N(I)V

    .line 324
    invoke-virtual {v0}, Ln3/x;->m()I

    move-result v3

    if-lez v3, :cond_afa

    const/4 v9, 0x1

    goto :goto_afb

    :cond_afa
    const/4 v9, 0x0

    .line 325
    :goto_afb
    invoke-static {v13, v9}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 326
    invoke-virtual {v0}, Ln3/x;->m()I

    move-result v9

    const v7, 0x65736473

    if-ne v9, v7, :cond_b08

    goto :goto_ad9

    :cond_b08
    add-int/2addr v1, v3

    move/from16 v32, v8

    const/4 v7, 0x0

    goto :goto_ae9

    :cond_b0d
    const/4 v1, -0x1

    goto :goto_ad9

    :goto_b0f
    if-eq v1, v13, :cond_bbd

    .line 327
    invoke-static {v1, v0}, Li5/e;->c(ILn3/x;)Lds/d;

    move-result-object v1

    .line 328
    iget-object v3, v1, Lds/d;->a:Ljava/lang/String;

    .line 329
    iget-object v7, v1, Lds/d;->b:[B

    if-eqz v7, :cond_bb3

    .line 330
    const-string v9, "audio/vorbis"

    invoke-virtual {v9, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_b8b

    .line 331
    sget-object v9, Lo4/k0;->a:Llx/a;

    .line 332
    new-instance v9, Ln3/x;

    invoke-direct {v9, v7}, Ln3/x;-><init>([B)V

    const/4 v12, 0x1

    .line 333
    invoke-virtual {v9, v12}, Ln3/x;->O(I)V

    const/4 v13, 0x0

    .line 334
    :goto_b2f
    invoke-virtual {v9}, Ln3/x;->a()I

    move-result v21

    if-lez v21, :cond_b46

    invoke-virtual {v9}, Ln3/x;->j()I

    move-result v12

    const/16 v0, 0xff

    if-ne v12, v0, :cond_b46

    add-int/lit16 v13, v13, 0xff

    const/4 v12, 0x1

    .line 335
    invoke-virtual {v9, v12}, Ln3/x;->O(I)V

    move-object/from16 v0, p0

    goto :goto_b2f

    .line 336
    :cond_b46
    invoke-virtual {v9}, Ln3/x;->A()I

    move-result v0

    add-int/2addr v0, v13

    const/4 v12, 0x0

    .line 337
    :goto_b4c
    invoke-virtual {v9}, Ln3/x;->a()I

    move-result v13

    if-lez v13, :cond_b67

    invoke-virtual {v9}, Ln3/x;->j()I

    move-result v13

    move-object/from16 p7, v1

    const/16 v1, 0xff

    if-ne v13, v1, :cond_b65

    add-int/lit16 v12, v12, 0xff

    const/4 v13, 0x1

    .line 338
    invoke-virtual {v9, v13}, Ln3/x;->O(I)V

    move-object/from16 v1, p7

    goto :goto_b4c

    :cond_b65
    :goto_b65
    const/4 v13, 0x1

    goto :goto_b6a

    :cond_b67
    move-object/from16 p7, v1

    goto :goto_b65

    .line 339
    :goto_b6a
    invoke-virtual {v9}, Ln3/x;->A()I

    move-result v1

    add-int/2addr v1, v12

    .line 340
    new-array v12, v0, [B

    .line 341
    iget v9, v9, Ln3/x;->b:I

    const/4 v13, 0x0

    .line 342
    invoke-static {v7, v9, v12, v13, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr v9, v0

    add-int/2addr v9, v1

    .line 343
    array-length v0, v7

    sub-int/2addr v0, v9

    .line 344
    new-array v1, v0, [B

    .line 345
    invoke-static {v7, v9, v1, v13, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 346
    invoke-static {v12, v1}, Lhx/m0;->w(Ljava/lang/Object;Ljava/lang/Object;)Lhx/w1;

    move-result-object v7

    move-object/from16 v0, p7

    move v12, v2

    const/4 v9, 0x2

    :goto_b88
    move-object/from16 v2, p9

    goto :goto_bc7

    :cond_b8b
    move-object/from16 p7, v1

    const/4 v13, 0x0

    .line 347
    const-string v0, "audio/mp4a-latm"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_ba8

    .line 348
    new-instance v0, Lct/f;

    .line 349
    array-length v1, v7

    const/4 v9, 0x2

    invoke-direct {v0, v7, v1, v9, v13}, Lct/f;-><init>([BIIB)V

    .line 350
    invoke-static {v0, v13}, Lo4/a;->p(Lct/f;Z)Lg8/f;

    move-result-object v0

    .line 351
    iget v12, v0, Lg8/f;->a:I

    .line 352
    iget v14, v0, Lg8/f;->b:I

    .line 353
    iget-object v2, v0, Lg8/f;->c:Ljava/lang/String;

    goto :goto_bac

    :cond_ba8
    const/4 v9, 0x2

    move v12, v2

    move-object/from16 v2, p9

    .line 354
    :goto_bac
    invoke-static {v7}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    move-result-object v7

    move-object/from16 v0, p7

    goto :goto_bc7

    :cond_bb3
    move-object/from16 p7, v1

    const/4 v9, 0x2

    const/4 v13, 0x0

    move-object/from16 v0, p7

    move v12, v2

    move-object/from16 v7, v33

    goto :goto_b88

    :cond_bbd
    const/4 v9, 0x2

    const/4 v13, 0x0

    move-object/from16 v0, p7

    move v12, v2

    move-object/from16 v7, v33

    move-object/from16 v3, v34

    goto :goto_b88

    :goto_bc7
    move-object/from16 v34, v3

    :goto_bc9
    add-int/2addr v11, v8

    move/from16 v3, p3

    move-object/from16 p7, v0

    move v1, v5

    move/from16 v19, v9

    move/from16 v13, v24

    move-object/from16 v5, v34

    move-object/from16 v9, v36

    const/16 v18, 0x4

    move-object/from16 v0, p0

    goto/16 :goto_1df

    :cond_bdd
    move-object/from16 p9, v2

    move-object/from16 v34, v5

    move-object/from16 v33, v7

    move v2, v12

    move/from16 v24, v13

    .line 355
    iget-object v0, v6, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    check-cast v0, Lk3/w;

    if-nez v0, :cond_c43

    if-eqz v34, :cond_c43

    .line 356
    new-instance v0, Lk3/v;

    invoke-direct {v0}, Lk3/v;-><init>()V

    .line 357
    invoke-static/range {p4 .. p4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lk3/v;->a:Ljava/lang/String;

    .line 358
    invoke-static/range {v34 .. v34}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lk3/v;->o:Ljava/lang/String;

    move-object/from16 v1, p9

    .line 359
    iput-object v1, v0, Lk3/v;->k:Ljava/lang/String;

    .line 360
    iput v14, v0, Lk3/v;->I:I

    .line 361
    iput v2, v0, Lk3/v;->K:I

    move/from16 v13, v24

    .line 362
    iput v13, v0, Lk3/v;->L:I

    move-object/from16 v7, v33

    .line 363
    iput-object v7, v0, Lk3/v;->r:Ljava/util/List;

    .line 364
    iput-object v10, v0, Lk3/v;->s:Lk3/r;

    .line 365
    iput-object v4, v0, Lk3/v;->d:Ljava/lang/String;

    if-eqz p7, :cond_c28

    move-object/from16 v1, p7

    .line 366
    iget-wide v2, v1, Lds/d;->c:J

    .line 367
    invoke-static {v2, v3}, Lc7/t;->M(J)I

    move-result v2

    .line 368
    iput v2, v0, Lk3/v;->i:I

    .line 369
    iget-wide v1, v1, Lds/d;->d:J

    .line 370
    invoke-static {v1, v2}, Lc7/t;->M(J)I

    move-result v1

    .line 371
    iput v1, v0, Lk3/v;->j:I

    goto :goto_c3c

    :cond_c28
    move-object/from16 v1, v29

    if-eqz v1, :cond_c3c

    .line 372
    iget-wide v2, v1, Lbl/h;->a:J

    .line 373
    invoke-static {v2, v3}, Lc7/t;->M(J)I

    move-result v2

    .line 374
    iput v2, v0, Lk3/v;->i:I

    .line 375
    iget-wide v1, v1, Lbl/h;->b:J

    .line 376
    invoke-static {v1, v2}, Lc7/t;->M(J)I

    move-result v1

    .line 377
    iput v1, v0, Lk3/v;->j:I

    .line 378
    :cond_c3c
    :goto_c3c
    new-instance v1, Lk3/w;

    invoke-direct {v1, v0}, Lk3/w;-><init>(Lk3/v;)V

    .line 379
    iput-object v1, v6, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    :cond_c43
    return-void

    :pswitch_data_c44
    .packed-switch 0x0
        :pswitch_749
        :pswitch_744
        :pswitch_73f
        :pswitch_73a
        :pswitch_735
        :pswitch_730
        :pswitch_72d
        :pswitch_730
        :pswitch_72d
        :pswitch_730
        :pswitch_72d
        :pswitch_728
        :pswitch_723
        :pswitch_71e
        :pswitch_719
        :pswitch_714
    .end packed-switch
.end method

.method public static c(ILn3/x;)Lds/d;
    .registers 12

    .line 1
    add-int/lit8 p0, p0, 0xc

    .line 2
    .line 3
    invoke-virtual {p1, p0}, Ln3/x;->N(I)V

    .line 4
    .line 5
    .line 6
    const/4 p0, 0x1

    .line 7
    invoke-virtual {p1, p0}, Ln3/x;->O(I)V

    .line 8
    .line 9
    .line 10
    invoke-static {p1}, Li5/e;->d(Ln3/x;)I

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    invoke-virtual {p1, v0}, Ln3/x;->O(I)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1}, Ln3/x;->A()I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    and-int/lit16 v2, v1, 0x80

    .line 22
    .line 23
    if-eqz v2, :cond_1b

    .line 24
    .line 25
    invoke-virtual {p1, v0}, Ln3/x;->O(I)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    and-int/lit8 v2, v1, 0x40

    .line 29
    .line 30
    if-eqz v2, :cond_26

    .line 31
    .line 32
    invoke-virtual {p1}, Ln3/x;->A()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    invoke-virtual {p1, v2}, Ln3/x;->O(I)V

    .line 37
    .line 38
    .line 39
    :cond_26
    and-int/lit8 v1, v1, 0x20

    .line 40
    .line 41
    if-eqz v1, :cond_2d

    .line 42
    .line 43
    invoke-virtual {p1, v0}, Ln3/x;->O(I)V

    .line 44
    .line 45
    .line 46
    :cond_2d
    invoke-virtual {p1, p0}, Ln3/x;->O(I)V

    .line 47
    .line 48
    .line 49
    invoke-static {p1}, Li5/e;->d(Ln3/x;)I

    .line 50
    .line 51
    .line 52
    invoke-virtual {p1}, Ln3/x;->A()I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    invoke-static {v0}, Lk3/u0;->e(I)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    const-string v0, "audio/mpeg"

    .line 61
    .line 62
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-nez v0, :cond_86

    .line 67
    .line 68
    const-string v0, "audio/vnd.dts"

    .line 69
    .line 70
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-nez v0, :cond_86

    .line 75
    .line 76
    const-string v0, "audio/vnd.dts.hd"

    .line 77
    .line 78
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_54

    .line 83
    .line 84
    goto :goto_86

    .line 85
    :cond_54
    const/4 v0, 0x4

    .line 86
    invoke-virtual {p1, v0}, Ln3/x;->O(I)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {p1}, Ln3/x;->C()J

    .line 90
    .line 91
    .line 92
    move-result-wide v0

    .line 93
    invoke-virtual {p1}, Ln3/x;->C()J

    .line 94
    .line 95
    .line 96
    move-result-wide v3

    .line 97
    invoke-virtual {p1, p0}, Ln3/x;->O(I)V

    .line 98
    .line 99
    .line 100
    invoke-static {p1}, Li5/e;->d(Ln3/x;)I

    .line 101
    .line 102
    .line 103
    move-result p0

    .line 104
    move-wide v4, v3

    .line 105
    new-array v3, p0, [B

    .line 106
    .line 107
    const/4 v6, 0x0

    .line 108
    invoke-virtual {p1, v3, v6, p0}, Ln3/x;->k([BII)V

    .line 109
    .line 110
    .line 111
    move-wide p0, v0

    .line 112
    new-instance v1, Lds/d;

    .line 113
    .line 114
    const-wide/16 v6, 0x0

    .line 115
    .line 116
    cmp-long v0, v4, v6

    .line 117
    .line 118
    const-wide/16 v8, -0x1

    .line 119
    .line 120
    if-lez v0, :cond_7a

    .line 121
    .line 122
    goto :goto_7b

    .line 123
    :cond_7a
    move-wide v4, v8

    .line 124
    :goto_7b
    cmp-long v0, p0, v6

    .line 125
    .line 126
    if-lez v0, :cond_81

    .line 127
    .line 128
    move-wide v6, p0

    .line 129
    goto :goto_82

    .line 130
    :cond_81
    move-wide v6, v8

    .line 131
    :goto_82
    invoke-direct/range {v1 .. v7}, Lds/d;-><init>(Ljava/lang/String;[BJJ)V

    .line 132
    .line 133
    .line 134
    return-object v1

    .line 135
    :cond_86
    :goto_86
    new-instance v1, Lds/d;

    .line 136
    .line 137
    const-wide/16 v4, -0x1

    .line 138
    .line 139
    const-wide/16 v6, -0x1

    .line 140
    .line 141
    const/4 v3, 0x0

    .line 142
    invoke-direct/range {v1 .. v7}, Lds/d;-><init>(Ljava/lang/String;[BJJ)V

    .line 143
    .line 144
    .line 145
    return-object v1
.end method

.method public static d(Ln3/x;)I
    .registers 4

    .line 1
    invoke-virtual {p0}, Ln3/x;->A()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    and-int/lit8 v1, v0, 0x7f

    .line 6
    .line 7
    :goto_6
    const/16 v2, 0x80

    .line 8
    .line 9
    and-int/2addr v0, v2

    .line 10
    if-ne v0, v2, :cond_15

    .line 11
    .line 12
    invoke-virtual {p0}, Ln3/x;->A()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    shl-int/lit8 v1, v1, 0x7

    .line 17
    .line 18
    and-int/lit8 v2, v0, 0x7f

    .line 19
    .line 20
    or-int/2addr v1, v2

    .line 21
    goto :goto_6

    .line 22
    :cond_15
    return v1
.end method

.method public static e(I)I
    .registers 1

    .line 1
    shr-int/lit8 p0, p0, 0x18

    .line 2
    .line 3
    and-int/lit16 p0, p0, 0xff

    .line 4
    .line 5
    return p0
.end method

.method public static f(Lo3/c;)Lk3/t0;
    .registers 15

    .line 1
    const v0, 0x68646c72    # 4.3148E24f

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, v0}, Lo3/c;->p(I)Lo3/d;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const v1, 0x6b657973

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, v1}, Lo3/c;->p(I)Lo3/d;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const v2, 0x696c7374

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, v2}, Lo3/c;->p(I)Lo3/d;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    const/4 v2, 0x0

    .line 23
    if-eqz v0, :cond_cb

    .line 24
    .line 25
    if-eqz v1, :cond_cb

    .line 26
    .line 27
    if-eqz p0, :cond_cb

    .line 28
    .line 29
    iget-object v0, v0, Lo3/d;->i:Ln3/x;

    .line 30
    .line 31
    const/16 v3, 0x10

    .line 32
    .line 33
    invoke-virtual {v0, v3}, Ln3/x;->N(I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    const v3, 0x6d647461

    .line 41
    .line 42
    .line 43
    if-eq v0, v3, :cond_2e

    .line 44
    .line 45
    goto/16 :goto_cb

    .line 46
    .line 47
    :cond_2e
    iget-object v0, v1, Lo3/d;->i:Ln3/x;

    .line 48
    .line 49
    const/16 v1, 0xc

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Ln3/x;->N(I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    new-array v3, v1, [Ljava/lang/String;

    .line 59
    .line 60
    const/4 v4, 0x0

    .line 61
    move v5, v4

    .line 62
    :goto_3d
    const/16 v6, 0x8

    .line 63
    .line 64
    if-ge v5, v1, :cond_55

    .line 65
    .line 66
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 67
    .line 68
    .line 69
    move-result v7

    .line 70
    const/4 v8, 0x4

    .line 71
    invoke-virtual {v0, v8}, Ln3/x;->O(I)V

    .line 72
    .line 73
    .line 74
    sub-int/2addr v7, v6

    .line 75
    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 76
    .line 77
    invoke-virtual {v0, v7, v6}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    aput-object v6, v3, v5

    .line 82
    .line 83
    add-int/lit8 v5, v5, 0x1

    .line 84
    .line 85
    goto :goto_3d

    .line 86
    :cond_55
    iget-object p0, p0, Lo3/d;->i:Ln3/x;

    .line 87
    .line 88
    invoke-virtual {p0, v6}, Ln3/x;->N(I)V

    .line 89
    .line 90
    .line 91
    new-instance v0, Ljava/util/ArrayList;

    .line 92
    .line 93
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 94
    .line 95
    .line 96
    :goto_5f
    invoke-virtual {p0}, Ln3/x;->a()I

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    if-le v5, v6, :cond_bf

    .line 101
    .line 102
    iget v5, p0, Ln3/x;->b:I

    .line 103
    .line 104
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 105
    .line 106
    .line 107
    move-result v7

    .line 108
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 109
    .line 110
    .line 111
    move-result v8

    .line 112
    add-int/lit8 v8, v8, -0x1

    .line 113
    .line 114
    if-ltz v8, :cond_b3

    .line 115
    .line 116
    if-ge v8, v1, :cond_b3

    .line 117
    .line 118
    aget-object v8, v3, v8

    .line 119
    .line 120
    add-int v9, v5, v7

    .line 121
    .line 122
    :goto_79
    iget v10, p0, Ln3/x;->b:I

    .line 123
    .line 124
    if-ge v10, v9, :cond_ac

    .line 125
    .line 126
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 127
    .line 128
    .line 129
    move-result v11

    .line 130
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 131
    .line 132
    .line 133
    move-result v12

    .line 134
    const v13, 0x64617461

    .line 135
    .line 136
    .line 137
    if-ne v12, v13, :cond_a7

    .line 138
    .line 139
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 140
    .line 141
    .line 142
    move-result v9

    .line 143
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 144
    .line 145
    .line 146
    move-result v10

    .line 147
    add-int/lit8 v11, v11, -0x10

    .line 148
    .line 149
    new-array v12, v11, [B

    .line 150
    .line 151
    invoke-virtual {p0, v12, v4, v11}, Ln3/x;->k([BII)V

    .line 152
    .line 153
    .line 154
    :try_start_99
    new-instance v11, Lo3/a;

    .line 155
    .line 156
    invoke-direct {v11, v8, v12, v10, v9}, Lo3/a;-><init>(Ljava/lang/String;[BII)V
    :try_end_9e
    .catch Ljava/lang/Exception; {:try_start_99 .. :try_end_9e} :catch_9f

    .line 157
    .line 158
    .line 159
    goto :goto_ad

    .line 160
    :catch_9f
    const-string v9, "MetadataUtil"

    .line 161
    .line 162
    const-string v10, "Failed to parse metadata entry with key: "

    .line 163
    .line 164
    invoke-static {v10, v8, v9}, Lhs/q;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    goto :goto_ac

    .line 168
    :cond_a7
    add-int/2addr v10, v11

    .line 169
    invoke-virtual {p0, v10}, Ln3/x;->N(I)V

    .line 170
    .line 171
    .line 172
    goto :goto_79

    .line 173
    :cond_ac
    :goto_ac
    move-object v11, v2

    .line 174
    :goto_ad
    if-eqz v11, :cond_ba

    .line 175
    .line 176
    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    goto :goto_ba

    .line 180
    :cond_b3
    const-string v9, "BoxParsers"

    .line 181
    .line 182
    const-string v10, "Skipped metadata with unknown key index: "

    .line 183
    .line 184
    invoke-static {v8, v10, v9}, Lhs/q;->r(ILjava/lang/String;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    :cond_ba
    :goto_ba
    add-int/2addr v5, v7

    .line 188
    invoke-virtual {p0, v5}, Ln3/x;->N(I)V

    .line 189
    .line 190
    .line 191
    goto :goto_5f

    .line 192
    :cond_bf
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 193
    .line 194
    .line 195
    move-result p0

    .line 196
    if-eqz p0, :cond_c6

    .line 197
    .line 198
    goto :goto_cb

    .line 199
    :cond_c6
    new-instance v2, Lk3/t0;

    .line 200
    .line 201
    invoke-direct {v2, v0}, Lk3/t0;-><init>(Ljava/util/List;)V

    .line 202
    .line 203
    .line 204
    :cond_cb
    :goto_cb
    return-object v2
.end method

.method public static g(Ln3/x;)Lo3/f;
    .registers 12

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ln3/x;->N(I)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Ln3/x;->m()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-static {v0}, Li5/e;->e(I)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_1a

    .line 15
    .line 16
    invoke-virtual {p0}, Ln3/x;->C()J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    invoke-virtual {p0}, Ln3/x;->C()J

    .line 21
    .line 22
    .line 23
    move-result-wide v2

    .line 24
    :goto_17
    move-wide v5, v0

    .line 25
    move-wide v7, v2

    .line 26
    goto :goto_23

    .line 27
    :cond_1a
    invoke-virtual {p0}, Ln3/x;->u()J

    .line 28
    .line 29
    .line 30
    move-result-wide v0

    .line 31
    invoke-virtual {p0}, Ln3/x;->u()J

    .line 32
    .line 33
    .line 34
    move-result-wide v2

    .line 35
    goto :goto_17

    .line 36
    :goto_23
    invoke-virtual {p0}, Ln3/x;->C()J

    .line 37
    .line 38
    .line 39
    move-result-wide v9

    .line 40
    new-instance v4, Lo3/f;

    .line 41
    .line 42
    invoke-direct/range {v4 .. v10}, Lo3/f;-><init>(JJJ)V

    .line 43
    .line 44
    .line 45
    return-object v4
.end method

.method public static h(Ln3/x;II)Landroid/util/Pair;
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Ln3/x;->b:I

    .line 4
    .line 5
    :goto_4
    sub-int v2, v1, p1

    .line 6
    .line 7
    move/from16 v4, p2

    .line 8
    .line 9
    if-ge v2, v4, :cond_11b

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Ln3/x;->N(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/4 v5, 0x0

    .line 19
    const/4 v6, 0x1

    .line 20
    if-lez v2, :cond_17

    .line 21
    .line 22
    move v7, v6

    .line 23
    goto :goto_18

    .line 24
    :cond_17
    move v7, v5

    .line 25
    :goto_18
    const-string v8, "childAtomSize must be positive"

    .line 26
    .line 27
    invoke-static {v8, v7}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    const v8, 0x73696e66

    .line 35
    .line 36
    .line 37
    if-ne v7, v8, :cond_118

    .line 38
    .line 39
    add-int/lit8 v7, v1, 0x8

    .line 40
    .line 41
    const/4 v8, -0x1

    .line 42
    move v12, v5

    .line 43
    move v9, v8

    .line 44
    const/4 v10, 0x0

    .line 45
    const/4 v11, 0x0

    .line 46
    :goto_2d
    sub-int v13, v7, v1

    .line 47
    .line 48
    const/4 v14, 0x4

    .line 49
    if-ge v13, v2, :cond_65

    .line 50
    .line 51
    invoke-virtual {v0, v7}, Ln3/x;->N(I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 55
    .line 56
    .line 57
    move-result v13

    .line 58
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 59
    .line 60
    .line 61
    move-result v15

    .line 62
    const/16 v16, 0x0

    .line 63
    .line 64
    const v3, 0x66726d61

    .line 65
    .line 66
    .line 67
    if-ne v15, v3, :cond_4d

    .line 68
    .line 69
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 74
    .line 75
    .line 76
    move-result-object v10

    .line 77
    goto :goto_63

    .line 78
    :cond_4d
    const v3, 0x7363686d

    .line 79
    .line 80
    .line 81
    if-ne v15, v3, :cond_5c

    .line 82
    .line 83
    invoke-virtual {v0, v14}, Ln3/x;->O(I)V

    .line 84
    .line 85
    .line 86
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 87
    .line 88
    invoke-virtual {v0, v14, v3}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v11

    .line 92
    goto :goto_63

    .line 93
    :cond_5c
    const v3, 0x73636869

    .line 94
    .line 95
    .line 96
    if-ne v15, v3, :cond_63

    .line 97
    .line 98
    move v9, v7

    .line 99
    move v12, v13

    .line 100
    :cond_63
    :goto_63
    add-int/2addr v7, v13

    .line 101
    goto :goto_2d

    .line 102
    :cond_65
    const/16 v16, 0x0

    .line 103
    .line 104
    const-string v3, "cenc"

    .line 105
    .line 106
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v3

    .line 110
    if-nez v3, :cond_8c

    .line 111
    .line 112
    const-string v3, "cbc1"

    .line 113
    .line 114
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v3

    .line 118
    if-nez v3, :cond_8c

    .line 119
    .line 120
    const-string v3, "cens"

    .line 121
    .line 122
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v3

    .line 126
    if-nez v3, :cond_8c

    .line 127
    .line 128
    const-string v3, "cbcs"

    .line 129
    .line 130
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v3

    .line 134
    if-eqz v3, :cond_88

    .line 135
    .line 136
    goto :goto_8c

    .line 137
    :cond_88
    move-object/from16 v3, v16

    .line 138
    .line 139
    goto/16 :goto_115

    .line 140
    .line 141
    :cond_8c
    :goto_8c
    if-eqz v10, :cond_90

    .line 142
    .line 143
    move v3, v6

    .line 144
    goto :goto_91

    .line 145
    :cond_90
    move v3, v5

    .line 146
    :goto_91
    const-string v7, "frma atom is mandatory"

    .line 147
    .line 148
    invoke-static {v7, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 149
    .line 150
    .line 151
    if-eq v9, v8, :cond_9a

    .line 152
    .line 153
    move v3, v6

    .line 154
    goto :goto_9b

    .line 155
    :cond_9a
    move v3, v5

    .line 156
    :goto_9b
    const-string v7, "schi atom is mandatory"

    .line 157
    .line 158
    invoke-static {v7, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 159
    .line 160
    .line 161
    add-int/lit8 v3, v9, 0x8

    .line 162
    .line 163
    :goto_a2
    sub-int v7, v3, v9

    .line 164
    .line 165
    if-ge v7, v12, :cond_104

    .line 166
    .line 167
    invoke-virtual {v0, v3}, Ln3/x;->N(I)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 171
    .line 172
    .line 173
    move-result v7

    .line 174
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 175
    .line 176
    .line 177
    move-result v8

    .line 178
    const v13, 0x74656e63

    .line 179
    .line 180
    .line 181
    if-ne v8, v13, :cond_101

    .line 182
    .line 183
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 184
    .line 185
    .line 186
    move-result v3

    .line 187
    invoke-static {v3}, Li5/e;->e(I)I

    .line 188
    .line 189
    .line 190
    move-result v3

    .line 191
    invoke-virtual {v0, v6}, Ln3/x;->O(I)V

    .line 192
    .line 193
    .line 194
    if-nez v3, :cond_c9

    .line 195
    .line 196
    invoke-virtual {v0, v6}, Ln3/x;->O(I)V

    .line 197
    .line 198
    .line 199
    move v14, v5

    .line 200
    move v15, v14

    .line 201
    goto :goto_d4

    .line 202
    :cond_c9
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 203
    .line 204
    .line 205
    move-result v3

    .line 206
    and-int/lit16 v7, v3, 0xf0

    .line 207
    .line 208
    shr-int/2addr v7, v14

    .line 209
    and-int/lit8 v3, v3, 0xf

    .line 210
    .line 211
    move v15, v3

    .line 212
    move v14, v7

    .line 213
    :goto_d4
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 214
    .line 215
    .line 216
    move-result v3

    .line 217
    if-ne v3, v6, :cond_dd

    .line 218
    .line 219
    move-object v3, v10

    .line 220
    move v10, v6

    .line 221
    goto :goto_df

    .line 222
    :cond_dd
    move-object v3, v10

    .line 223
    move v10, v5

    .line 224
    :goto_df
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 225
    .line 226
    .line 227
    move-result v12

    .line 228
    const/16 v7, 0x10

    .line 229
    .line 230
    new-array v13, v7, [B

    .line 231
    .line 232
    invoke-virtual {v0, v13, v5, v7}, Ln3/x;->k([BII)V

    .line 233
    .line 234
    .line 235
    if-eqz v10, :cond_f9

    .line 236
    .line 237
    if-nez v12, :cond_f9

    .line 238
    .line 239
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 240
    .line 241
    .line 242
    move-result v7

    .line 243
    new-array v8, v7, [B

    .line 244
    .line 245
    invoke-virtual {v0, v8, v5, v7}, Ln3/x;->k([BII)V

    .line 246
    .line 247
    .line 248
    move-object/from16 v16, v8

    .line 249
    .line 250
    :cond_f9
    new-instance v9, Li5/v;

    .line 251
    .line 252
    move-object v8, v3

    .line 253
    invoke-direct/range {v9 .. v16}, Li5/v;-><init>(ZLjava/lang/String;I[BII[B)V

    .line 254
    .line 255
    .line 256
    move-object v3, v9

    .line 257
    goto :goto_107

    .line 258
    :cond_101
    move-object v8, v10

    .line 259
    add-int/2addr v3, v7

    .line 260
    goto :goto_a2

    .line 261
    :cond_104
    move-object v8, v10

    .line 262
    move-object/from16 v3, v16

    .line 263
    .line 264
    :goto_107
    if-eqz v3, :cond_10a

    .line 265
    .line 266
    move v5, v6

    .line 267
    :cond_10a
    const-string v6, "tenc atom is mandatory"

    .line 268
    .line 269
    invoke-static {v6, v5}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 270
    .line 271
    .line 272
    sget-object v5, Ln3/l0;->a:Ljava/lang/String;

    .line 273
    .line 274
    invoke-static {v8, v3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 275
    .line 276
    .line 277
    move-result-object v3

    .line 278
    :goto_115
    if-eqz v3, :cond_118

    .line 279
    .line 280
    return-object v3

    .line 281
    :cond_118
    add-int/2addr v1, v2

    .line 282
    goto/16 :goto_4

    .line 283
    .line 284
    :cond_11b
    const/16 v16, 0x0

    .line 285
    .line 286
    return-object v16
.end method

.method public static i(Ln3/x;Li5/d;Ljava/lang/String;Lk3/r;Z)Lcom/google/android/gms/internal/play_billing/s1;
    .registers 68

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v10, p1

    .line 4
    .line 5
    move-object/from16 v5, p2

    .line 6
    .line 7
    iget v11, v10, Li5/d;->a:I

    .line 8
    .line 9
    const/16 v12, 0xc

    .line 10
    .line 11
    invoke-virtual {v0, v12}, Ln3/x;->N(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 15
    .line 16
    .line 17
    move-result v13

    .line 18
    new-instance v8, Lcom/google/android/gms/internal/play_billing/s1;

    .line 19
    .line 20
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    new-array v1, v13, [Li5/v;

    .line 24
    .line 25
    iput-object v1, v8, Lcom/google/android/gms/internal/play_billing/s1;->i:Ljava/lang/Object;

    .line 26
    .line 27
    const/4 v14, 0x0

    .line 28
    iput v14, v8, Lcom/google/android/gms/internal/play_billing/s1;->e:I

    .line 29
    .line 30
    move v9, v14

    .line 31
    :goto_1e
    if-ge v9, v13, :cond_d63

    .line 32
    .line 33
    iget v2, v0, Ln3/x;->b:I

    .line 34
    .line 35
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    if-lez v3, :cond_2a

    .line 40
    .line 41
    const/4 v4, 0x1

    .line 42
    goto :goto_2b

    .line 43
    :cond_2a
    move v4, v14

    .line 44
    :goto_2b
    const-string v6, "childAtomSize must be positive"

    .line 45
    .line 46
    invoke-static {v6, v4}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 50
    .line 51
    .line 52
    move-result v4

    .line 53
    const v7, 0x61766331

    .line 54
    .line 55
    .line 56
    const/16 v17, 0x3

    .line 57
    .line 58
    const/16 v18, 0x8

    .line 59
    .line 60
    const v15, 0x48323633

    .line 61
    .line 62
    .line 63
    const v1, 0x6d317620

    .line 64
    .line 65
    .line 66
    const v14, 0x656e6376

    .line 67
    .line 68
    .line 69
    if-eq v4, v7, :cond_a1

    .line 70
    .line 71
    const v7, 0x61766333

    .line 72
    .line 73
    .line 74
    if-eq v4, v7, :cond_a1

    .line 75
    .line 76
    if-eq v4, v14, :cond_a1

    .line 77
    .line 78
    if-eq v4, v1, :cond_a1

    .line 79
    .line 80
    const v7, 0x6d703476

    .line 81
    .line 82
    .line 83
    if-eq v4, v7, :cond_a1

    .line 84
    .line 85
    const v7, 0x68766331

    .line 86
    .line 87
    .line 88
    if-eq v4, v7, :cond_a1

    .line 89
    .line 90
    const v7, 0x68657631

    .line 91
    .line 92
    .line 93
    if-eq v4, v7, :cond_a1

    .line 94
    .line 95
    const v7, 0x76766331

    .line 96
    .line 97
    .line 98
    if-eq v4, v7, :cond_a1

    .line 99
    .line 100
    const v7, 0x76766931

    .line 101
    .line 102
    .line 103
    if-eq v4, v7, :cond_a1

    .line 104
    .line 105
    const v7, 0x73323633

    .line 106
    .line 107
    .line 108
    if-eq v4, v7, :cond_a1

    .line 109
    .line 110
    if-eq v4, v15, :cond_a1

    .line 111
    .line 112
    const v7, 0x68323633

    .line 113
    .line 114
    .line 115
    if-eq v4, v7, :cond_a1

    .line 116
    .line 117
    const v7, 0x76703038

    .line 118
    .line 119
    .line 120
    if-eq v4, v7, :cond_a1

    .line 121
    .line 122
    const v7, 0x76703039

    .line 123
    .line 124
    .line 125
    if-eq v4, v7, :cond_a1

    .line 126
    .line 127
    const v7, 0x61763031

    .line 128
    .line 129
    .line 130
    if-eq v4, v7, :cond_a1

    .line 131
    .line 132
    const v7, 0x64766176

    .line 133
    .line 134
    .line 135
    if-eq v4, v7, :cond_a1

    .line 136
    .line 137
    const v7, 0x64766131

    .line 138
    .line 139
    .line 140
    if-eq v4, v7, :cond_a1

    .line 141
    .line 142
    const v7, 0x64766865

    .line 143
    .line 144
    .line 145
    if-eq v4, v7, :cond_a1

    .line 146
    .line 147
    const v7, 0x64766831

    .line 148
    .line 149
    .line 150
    if-eq v4, v7, :cond_a1

    .line 151
    .line 152
    const v7, 0x61707631

    .line 153
    .line 154
    .line 155
    if-eq v4, v7, :cond_a1

    .line 156
    .line 157
    const v7, 0x64617631

    .line 158
    .line 159
    .line 160
    if-ne v4, v7, :cond_a5

    .line 161
    .line 162
    :cond_a1
    move-object/from16 v7, p3

    .line 163
    .line 164
    goto/16 :goto_396

    .line 165
    .line 166
    :cond_a5
    const v1, 0x6d703461

    .line 167
    .line 168
    .line 169
    if-eq v4, v1, :cond_131

    .line 170
    .line 171
    const v1, 0x656e6361

    .line 172
    .line 173
    .line 174
    if-eq v4, v1, :cond_131

    .line 175
    .line 176
    const v1, 0x61632d33

    .line 177
    .line 178
    .line 179
    if-eq v4, v1, :cond_131

    .line 180
    .line 181
    const v1, 0x65632d33

    .line 182
    .line 183
    .line 184
    if-eq v4, v1, :cond_131

    .line 185
    .line 186
    const v1, 0x61632d34

    .line 187
    .line 188
    .line 189
    if-eq v4, v1, :cond_131

    .line 190
    .line 191
    const v1, 0x6d6c7061

    .line 192
    .line 193
    .line 194
    if-eq v4, v1, :cond_131

    .line 195
    .line 196
    const v1, 0x64747363

    .line 197
    .line 198
    .line 199
    if-eq v4, v1, :cond_131

    .line 200
    .line 201
    const v1, 0x64747365

    .line 202
    .line 203
    .line 204
    if-eq v4, v1, :cond_131

    .line 205
    .line 206
    const v1, 0x64747368

    .line 207
    .line 208
    .line 209
    if-eq v4, v1, :cond_131

    .line 210
    .line 211
    const v1, 0x6474736c

    .line 212
    .line 213
    .line 214
    if-eq v4, v1, :cond_131

    .line 215
    .line 216
    const v1, 0x64747378

    .line 217
    .line 218
    .line 219
    if-eq v4, v1, :cond_131

    .line 220
    .line 221
    const v1, 0x73616d72

    .line 222
    .line 223
    .line 224
    if-eq v4, v1, :cond_131

    .line 225
    .line 226
    const v1, 0x73617762

    .line 227
    .line 228
    .line 229
    if-eq v4, v1, :cond_131

    .line 230
    .line 231
    const v1, 0x6c70636d

    .line 232
    .line 233
    .line 234
    if-eq v4, v1, :cond_131

    .line 235
    .line 236
    const v1, 0x736f7774

    .line 237
    .line 238
    .line 239
    if-eq v4, v1, :cond_131

    .line 240
    .line 241
    const v1, 0x74776f73

    .line 242
    .line 243
    .line 244
    if-eq v4, v1, :cond_131

    .line 245
    .line 246
    const v1, 0x2e6d7032

    .line 247
    .line 248
    .line 249
    if-eq v4, v1, :cond_131

    .line 250
    .line 251
    const v1, 0x2e6d7033

    .line 252
    .line 253
    .line 254
    if-eq v4, v1, :cond_131

    .line 255
    .line 256
    const v1, 0x6d686131

    .line 257
    .line 258
    .line 259
    if-eq v4, v1, :cond_131

    .line 260
    .line 261
    const v1, 0x6d686d31

    .line 262
    .line 263
    .line 264
    if-eq v4, v1, :cond_131

    .line 265
    .line 266
    const v1, 0x616c6163

    .line 267
    .line 268
    .line 269
    if-eq v4, v1, :cond_131

    .line 270
    .line 271
    const v1, 0x616c6177

    .line 272
    .line 273
    .line 274
    if-eq v4, v1, :cond_131

    .line 275
    .line 276
    const v1, 0x756c6177

    .line 277
    .line 278
    .line 279
    if-eq v4, v1, :cond_131

    .line 280
    .line 281
    const v1, 0x4f707573

    .line 282
    .line 283
    .line 284
    if-eq v4, v1, :cond_131

    .line 285
    .line 286
    const v1, 0x664c6143

    .line 287
    .line 288
    .line 289
    if-eq v4, v1, :cond_131

    .line 290
    .line 291
    const v1, 0x69616d66

    .line 292
    .line 293
    .line 294
    if-eq v4, v1, :cond_131

    .line 295
    .line 296
    const v1, 0x6970636d

    .line 297
    .line 298
    .line 299
    if-eq v4, v1, :cond_131

    .line 300
    .line 301
    const v1, 0x6670636d

    .line 302
    .line 303
    .line 304
    if-ne v4, v1, :cond_138

    .line 305
    .line 306
    :cond_131
    move/from16 v26, v2

    .line 307
    .line 308
    move/from16 v29, v3

    .line 309
    .line 310
    move v1, v4

    .line 311
    goto/16 :goto_375

    .line 312
    .line 313
    :cond_138
    const v6, 0x6d703473

    .line 314
    .line 315
    .line 316
    const v7, 0x63363038

    .line 317
    .line 318
    .line 319
    const v14, 0x73747070

    .line 320
    .line 321
    .line 322
    const v15, 0x77767474

    .line 323
    .line 324
    .line 325
    const v12, 0x74783367

    .line 326
    .line 327
    .line 328
    const v1, 0x54544d4c

    .line 329
    .line 330
    .line 331
    if-eq v4, v1, :cond_1ee

    .line 332
    .line 333
    if-eq v4, v12, :cond_1ee

    .line 334
    .line 335
    if-eq v4, v15, :cond_1ee

    .line 336
    .line 337
    if-eq v4, v14, :cond_1ee

    .line 338
    .line 339
    if-eq v4, v7, :cond_1ee

    .line 340
    .line 341
    if-eq v4, v6, :cond_1ee

    .line 342
    .line 343
    const v6, 0x74657874

    .line 344
    .line 345
    .line 346
    if-ne v4, v6, :cond_15d

    .line 347
    .line 348
    goto/16 :goto_1ee

    .line 349
    .line 350
    :cond_15d
    const v1, 0x69743335

    .line 351
    .line 352
    .line 353
    const v6, 0x6d657474

    .line 354
    .line 355
    .line 356
    if-eq v4, v6, :cond_198

    .line 357
    .line 358
    if-ne v4, v1, :cond_168

    .line 359
    .line 360
    goto :goto_198

    .line 361
    :cond_168
    const v1, 0x63616d6d

    .line 362
    .line 363
    .line 364
    if-ne v4, v1, :cond_187

    .line 365
    .line 366
    new-instance v1, Lk3/v;

    .line 367
    .line 368
    invoke-direct {v1}, Lk3/v;-><init>()V

    .line 369
    .line 370
    .line 371
    invoke-static {v11}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v4

    .line 375
    iput-object v4, v1, Lk3/v;->a:Ljava/lang/String;

    .line 376
    .line 377
    const-string v4, "application/x-camera-motion"

    .line 378
    .line 379
    invoke-static {v4}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object v4

    .line 383
    iput-object v4, v1, Lk3/v;->o:Ljava/lang/String;

    .line 384
    .line 385
    new-instance v4, Lk3/w;

    .line 386
    .line 387
    invoke-direct {v4, v1}, Lk3/w;-><init>(Lk3/v;)V

    .line 388
    .line 389
    .line 390
    iput-object v4, v8, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    .line 391
    .line 392
    :cond_187
    :goto_187
    move/from16 v28, v2

    .line 393
    .line 394
    move/from16 v48, v3

    .line 395
    .line 396
    move-object v2, v5

    .line 397
    move/from16 v27, v9

    .line 398
    .line 399
    move-object v1, v10

    .line 400
    move/from16 v29, v11

    .line 401
    .line 402
    move/from16 v30, v13

    .line 403
    .line 404
    const/4 v12, 0x0

    .line 405
    const/16 v16, 0xc

    .line 406
    .line 407
    goto/16 :goto_d51

    .line 408
    .line 409
    :cond_198
    :goto_198
    add-int/lit8 v7, v2, 0x10

    .line 410
    .line 411
    invoke-virtual {v0, v7}, Ln3/x;->N(I)V

    .line 412
    .line 413
    .line 414
    if-ne v4, v6, :cond_1c1

    .line 415
    .line 416
    invoke-virtual {v0}, Ln3/x;->v()Ljava/lang/String;

    .line 417
    .line 418
    .line 419
    invoke-virtual {v0}, Ln3/x;->v()Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v1

    .line 423
    if-eqz v1, :cond_187

    .line 424
    .line 425
    new-instance v4, Lk3/v;

    .line 426
    .line 427
    invoke-direct {v4}, Lk3/v;-><init>()V

    .line 428
    .line 429
    .line 430
    invoke-static {v11}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object v6

    .line 434
    iput-object v6, v4, Lk3/v;->a:Ljava/lang/String;

    .line 435
    .line 436
    invoke-static {v1}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 437
    .line 438
    .line 439
    move-result-object v1

    .line 440
    iput-object v1, v4, Lk3/v;->o:Ljava/lang/String;

    .line 441
    .line 442
    new-instance v1, Lk3/w;

    .line 443
    .line 444
    invoke-direct {v1, v4}, Lk3/w;-><init>(Lk3/v;)V

    .line 445
    .line 446
    .line 447
    iput-object v1, v8, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    .line 448
    .line 449
    goto :goto_187

    .line 450
    :cond_1c1
    if-ne v4, v1, :cond_187

    .line 451
    .line 452
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 453
    .line 454
    .line 455
    move-result v1

    .line 456
    new-array v4, v1, [B

    .line 457
    .line 458
    const/4 v6, 0x0

    .line 459
    invoke-virtual {v0, v4, v6, v1}, Ln3/x;->k([BII)V

    .line 460
    .line 461
    .line 462
    new-instance v1, Lk3/v;

    .line 463
    .line 464
    invoke-direct {v1}, Lk3/v;-><init>()V

    .line 465
    .line 466
    .line 467
    invoke-static {v11}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v6

    .line 471
    iput-object v6, v1, Lk3/v;->a:Ljava/lang/String;

    .line 472
    .line 473
    const-string v6, "application/x-itut-t35"

    .line 474
    .line 475
    invoke-static {v6}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 476
    .line 477
    .line 478
    move-result-object v6

    .line 479
    iput-object v6, v1, Lk3/v;->o:Ljava/lang/String;

    .line 480
    .line 481
    invoke-static {v4}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 482
    .line 483
    .line 484
    move-result-object v4

    .line 485
    iput-object v4, v1, Lk3/v;->r:Ljava/util/List;

    .line 486
    .line 487
    new-instance v4, Lk3/w;

    .line 488
    .line 489
    invoke-direct {v4, v1}, Lk3/w;-><init>(Lk3/v;)V

    .line 490
    .line 491
    .line 492
    iput-object v4, v8, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    .line 493
    .line 494
    goto :goto_187

    .line 495
    :cond_1ee
    :goto_1ee
    add-int/lit8 v6, v2, 0x10

    .line 496
    .line 497
    invoke-virtual {v0, v6}, Ln3/x;->N(I)V

    .line 498
    .line 499
    .line 500
    const-string v6, "application/ttml+xml"

    .line 501
    .line 502
    const-wide v27, 0x7fffffffffffffffL

    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    if-ne v4, v1, :cond_205

    .line 508
    .line 509
    :goto_1fc
    move/from16 v26, v2

    .line 510
    .line 511
    move/from16 v29, v3

    .line 512
    .line 513
    :goto_200
    move-wide/from16 v0, v27

    .line 514
    .line 515
    const/4 v15, 0x0

    .line 516
    goto/16 :goto_33c

    .line 517
    .line 518
    :cond_205
    if-ne v4, v12, :cond_21d

    .line 519
    .line 520
    add-int/lit8 v1, v3, -0x10

    .line 521
    .line 522
    new-array v4, v1, [B

    .line 523
    .line 524
    const/4 v6, 0x0

    .line 525
    invoke-virtual {v0, v4, v6, v1}, Ln3/x;->k([BII)V

    .line 526
    .line 527
    .line 528
    invoke-static {v4}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 529
    .line 530
    .line 531
    move-result-object v15

    .line 532
    const-string v6, "application/x-quicktime-tx3g"

    .line 533
    .line 534
    move/from16 v26, v2

    .line 535
    .line 536
    move/from16 v29, v3

    .line 537
    .line 538
    :goto_219
    move-wide/from16 v0, v27

    .line 539
    .line 540
    goto/16 :goto_33c

    .line 541
    .line 542
    :cond_21d
    if-ne v4, v15, :cond_222

    .line 543
    .line 544
    const-string v6, "application/x-mp4-vtt"

    .line 545
    .line 546
    goto :goto_1fc

    .line 547
    :cond_222
    if-ne v4, v14, :cond_227

    .line 548
    .line 549
    const-wide/16 v27, 0x0

    .line 550
    .line 551
    goto :goto_1fc

    .line 552
    :cond_227
    if-ne v4, v7, :cond_22f

    .line 553
    .line 554
    const/4 v1, 0x1

    .line 555
    iput v1, v8, Lcom/google/android/gms/internal/play_billing/s1;->e:I

    .line 556
    .line 557
    const-string v6, "application/x-mp4-cea-608"

    .line 558
    .line 559
    goto :goto_1fc

    .line 560
    :cond_22f
    const v1, 0x6d703473

    .line 561
    .line 562
    .line 563
    if-ne v4, v1, :cond_32f

    .line 564
    .line 565
    iget v1, v0, Ln3/x;->b:I

    .line 566
    .line 567
    const/4 v4, 0x4

    .line 568
    invoke-virtual {v0, v4}, Ln3/x;->O(I)V

    .line 569
    .line 570
    .line 571
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 572
    .line 573
    .line 574
    move-result v4

    .line 575
    const v6, 0x65736473

    .line 576
    .line 577
    .line 578
    if-ne v4, v6, :cond_326

    .line 579
    .line 580
    invoke-static {v1, v0}, Li5/e;->c(ILn3/x;)Lds/d;

    .line 581
    .line 582
    .line 583
    move-result-object v1

    .line 584
    iget-object v1, v1, Lds/d;->b:[B

    .line 585
    .line 586
    if-eqz v1, :cond_250

    .line 587
    .line 588
    array-length v4, v1

    .line 589
    const/16 v6, 0x40

    .line 590
    .line 591
    if-eq v4, v6, :cond_256

    .line 592
    .line 593
    :cond_250
    move/from16 v26, v2

    .line 594
    .line 595
    move/from16 v29, v3

    .line 596
    .line 597
    goto/16 :goto_35c

    .line 598
    .line 599
    :cond_256
    iget v4, v10, Li5/d;->e:I

    .line 600
    .line 601
    iget v7, v10, Li5/d;->f:I

    .line 602
    .line 603
    array-length v12, v1

    .line 604
    if-ne v12, v6, :cond_260

    .line 605
    .line 606
    const/16 v23, 0x1

    .line 607
    .line 608
    goto :goto_262

    .line 609
    :cond_260
    const/16 v23, 0x0

    .line 610
    .line 611
    :goto_262
    invoke-static/range {v23 .. v23}, Loq/a;->z(Z)V

    .line 612
    .line 613
    .line 614
    new-instance v6, Ljava/util/ArrayList;

    .line 615
    .line 616
    const/16 v12, 0x10

    .line 617
    .line 618
    invoke-direct {v6, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 619
    .line 620
    .line 621
    const/4 v12, 0x0

    .line 622
    :goto_26d
    array-length v14, v1

    .line 623
    add-int/lit8 v14, v14, -0x3

    .line 624
    .line 625
    if-ge v12, v14, :cond_2e5

    .line 626
    .line 627
    aget-byte v14, v1, v12

    .line 628
    .line 629
    add-int/lit8 v15, v12, 0x1

    .line 630
    .line 631
    aget-byte v15, v1, v15

    .line 632
    .line 633
    add-int/lit8 v20, v12, 0x2

    .line 634
    .line 635
    aget-byte v0, v1, v20

    .line 636
    .line 637
    add-int/lit8 v20, v12, 0x3

    .line 638
    .line 639
    move-object/from16 v21, v1

    .line 640
    .line 641
    aget-byte v1, v21, v20

    .line 642
    .line 643
    invoke-static {v14, v15, v0, v1}, Lc7/t;->r(BBBB)I

    .line 644
    .line 645
    .line 646
    move-result v0

    .line 647
    shr-int/lit8 v1, v0, 0x10

    .line 648
    .line 649
    const/16 v14, 0xff

    .line 650
    .line 651
    and-int/2addr v1, v14

    .line 652
    shr-int/lit8 v15, v0, 0x8

    .line 653
    .line 654
    and-int/2addr v15, v14

    .line 655
    and-int/2addr v0, v14

    .line 656
    add-int/lit8 v15, v15, -0x80

    .line 657
    .line 658
    const/16 v14, 0x36fb

    .line 659
    .line 660
    move/from16 v20, v0

    .line 661
    .line 662
    const/16 v0, 0x2710

    .line 663
    .line 664
    invoke-static {v15, v14, v0, v1}, La1/h;->y(IIII)I

    .line 665
    .line 666
    .line 667
    move-result v14

    .line 668
    add-int/lit8 v0, v20, -0x80

    .line 669
    .line 670
    move/from16 v26, v2

    .line 671
    .line 672
    mul-int/lit16 v2, v0, 0xd7f

    .line 673
    .line 674
    move/from16 v29, v3

    .line 675
    .line 676
    const/16 v3, 0x2710

    .line 677
    .line 678
    div-int/2addr v2, v3

    .line 679
    sub-int v2, v1, v2

    .line 680
    .line 681
    mul-int/lit16 v15, v15, 0x1c01

    .line 682
    .line 683
    div-int/2addr v15, v3

    .line 684
    sub-int/2addr v2, v15

    .line 685
    const/16 v15, 0x457e

    .line 686
    .line 687
    invoke-static {v0, v15, v3, v1}, La1/h;->y(IIII)I

    .line 688
    .line 689
    .line 690
    move-result v0

    .line 691
    const/16 v1, 0xff

    .line 692
    .line 693
    const/4 v3, 0x0

    .line 694
    invoke-static {v14, v3, v1}, Ln3/l0;->j(III)I

    .line 695
    .line 696
    .line 697
    move-result v14

    .line 698
    const/16 v25, 0x10

    .line 699
    .line 700
    shl-int/lit8 v14, v14, 0x10

    .line 701
    .line 702
    invoke-static {v2, v3, v1}, Ln3/l0;->j(III)I

    .line 703
    .line 704
    .line 705
    move-result v2

    .line 706
    shl-int/lit8 v2, v2, 0x8

    .line 707
    .line 708
    or-int/2addr v2, v14

    .line 709
    invoke-static {v0, v3, v1}, Ln3/l0;->j(III)I

    .line 710
    .line 711
    .line 712
    move-result v0

    .line 713
    or-int/2addr v0, v2

    .line 714
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 715
    .line 716
    .line 717
    move-result-object v0

    .line 718
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 719
    .line 720
    .line 721
    move-result-object v0

    .line 722
    const-string v1, "%06x"

    .line 723
    .line 724
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 725
    .line 726
    .line 727
    move-result-object v0

    .line 728
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 729
    .line 730
    .line 731
    add-int/lit8 v12, v12, 0x4

    .line 732
    .line 733
    move-object/from16 v0, p0

    .line 734
    .line 735
    move-object/from16 v1, v21

    .line 736
    .line 737
    move/from16 v2, v26

    .line 738
    .line 739
    move/from16 v3, v29

    .line 740
    .line 741
    goto :goto_26d

    .line 742
    :cond_2e5
    move/from16 v26, v2

    .line 743
    .line 744
    move/from16 v29, v3

    .line 745
    .line 746
    const-string v0, "x"

    .line 747
    .line 748
    const-string v1, "\npalette: "

    .line 749
    .line 750
    const-string v2, "size: "

    .line 751
    .line 752
    invoke-static {v4, v2, v7, v0, v1}, La1/h;->m(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 753
    .line 754
    .line 755
    move-result-object v0

    .line 756
    new-instance v1, Lgx/l;

    .line 757
    .line 758
    const-string v2, ", "

    .line 759
    .line 760
    const/4 v3, 0x0

    .line 761
    invoke-direct {v1, v2, v3}, Lgx/l;-><init>(Ljava/lang/String;I)V

    .line 762
    .line 763
    .line 764
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 765
    .line 766
    .line 767
    move-result-object v2

    .line 768
    new-instance v3, Ljava/lang/StringBuilder;

    .line 769
    .line 770
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 771
    .line 772
    .line 773
    invoke-virtual {v1, v3, v2}, Lgx/l;->a(Ljava/lang/StringBuilder;Ljava/util/Iterator;)V

    .line 774
    .line 775
    .line 776
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 777
    .line 778
    .line 779
    move-result-object v1

    .line 780
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 781
    .line 782
    .line 783
    const-string v1, "\n"

    .line 784
    .line 785
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 786
    .line 787
    .line 788
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 789
    .line 790
    .line 791
    move-result-object v0

    .line 792
    sget-object v1, Ln3/l0;->a:Ljava/lang/String;

    .line 793
    .line 794
    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 795
    .line 796
    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 797
    .line 798
    .line 799
    move-result-object v0

    .line 800
    invoke-static {v0}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 801
    .line 802
    .line 803
    move-result-object v15

    .line 804
    const-string v0, "application/vobsub"

    .line 805
    .line 806
    goto :goto_32c

    .line 807
    :cond_326
    move/from16 v26, v2

    .line 808
    .line 809
    move/from16 v29, v3

    .line 810
    .line 811
    const/4 v0, 0x0

    .line 812
    const/4 v15, 0x0

    .line 813
    :goto_32c
    move-object v6, v0

    .line 814
    goto/16 :goto_219

    .line 815
    .line 816
    :cond_32f
    move/from16 v26, v2

    .line 817
    .line 818
    move/from16 v29, v3

    .line 819
    .line 820
    const v6, 0x74657874

    .line 821
    .line 822
    .line 823
    if-ne v4, v6, :cond_36f

    .line 824
    .line 825
    const-string v6, "text/x-unknown"

    .line 826
    .line 827
    goto/16 :goto_200

    .line 828
    .line 829
    :goto_33c
    if-eqz v6, :cond_35c

    .line 830
    .line 831
    new-instance v2, Lk3/v;

    .line 832
    .line 833
    invoke-direct {v2}, Lk3/v;-><init>()V

    .line 834
    .line 835
    .line 836
    invoke-static {v11}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 837
    .line 838
    .line 839
    move-result-object v3

    .line 840
    iput-object v3, v2, Lk3/v;->a:Ljava/lang/String;

    .line 841
    .line 842
    invoke-static {v6}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 843
    .line 844
    .line 845
    move-result-object v3

    .line 846
    iput-object v3, v2, Lk3/v;->o:Ljava/lang/String;

    .line 847
    .line 848
    iput-object v5, v2, Lk3/v;->d:Ljava/lang/String;

    .line 849
    .line 850
    iput-wide v0, v2, Lk3/v;->t:J

    .line 851
    .line 852
    iput-object v15, v2, Lk3/v;->r:Ljava/util/List;

    .line 853
    .line 854
    new-instance v0, Lk3/w;

    .line 855
    .line 856
    invoke-direct {v0, v2}, Lk3/w;-><init>(Lk3/v;)V

    .line 857
    .line 858
    .line 859
    iput-object v0, v8, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    .line 860
    .line 861
    :cond_35c
    :goto_35c
    move-object/from16 v0, p0

    .line 862
    .line 863
    move-object v2, v5

    .line 864
    move/from16 v27, v9

    .line 865
    .line 866
    move-object v1, v10

    .line 867
    move/from16 v30, v13

    .line 868
    .line 869
    move/from16 v28, v26

    .line 870
    .line 871
    move/from16 v48, v29

    .line 872
    .line 873
    const/4 v12, 0x0

    .line 874
    const/16 v16, 0xc

    .line 875
    .line 876
    move/from16 v29, v11

    .line 877
    .line 878
    goto/16 :goto_d51

    .line 879
    .line 880
    :cond_36f
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 881
    .line 882
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 883
    .line 884
    .line 885
    throw v0

    .line 886
    :goto_375
    iget v4, v10, Li5/d;->a:I

    .line 887
    .line 888
    move-object/from16 v0, p0

    .line 889
    .line 890
    move-object/from16 v7, p3

    .line 891
    .line 892
    move/from16 v6, p4

    .line 893
    .line 894
    move/from16 v2, v26

    .line 895
    .line 896
    move/from16 v3, v29

    .line 897
    .line 898
    invoke-static/range {v0 .. v9}, Li5/e;->b(Ln3/x;IIIILjava/lang/String;ZLk3/r;Lcom/google/android/gms/internal/play_billing/s1;I)V

    .line 899
    .line 900
    .line 901
    move/from16 v28, v2

    .line 902
    .line 903
    move/from16 v48, v3

    .line 904
    .line 905
    move/from16 v27, v9

    .line 906
    .line 907
    move-object v1, v10

    .line 908
    move/from16 v29, v11

    .line 909
    .line 910
    move/from16 v30, v13

    .line 911
    .line 912
    const/4 v12, 0x0

    .line 913
    const/16 v16, 0xc

    .line 914
    .line 915
    :goto_392
    move-object/from16 v2, p2

    .line 916
    .line 917
    goto/16 :goto_d51

    .line 918
    .line 919
    :goto_396
    add-int/lit8 v12, v2, 0x10

    .line 920
    .line 921
    invoke-virtual {v0, v12}, Ln3/x;->N(I)V

    .line 922
    .line 923
    .line 924
    const/16 v12, 0x10

    .line 925
    .line 926
    invoke-virtual {v0, v12}, Ln3/x;->O(I)V

    .line 927
    .line 928
    .line 929
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 930
    .line 931
    .line 932
    move-result v12

    .line 933
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 934
    .line 935
    .line 936
    move-result v15

    .line 937
    const/16 v1, 0x32

    .line 938
    .line 939
    invoke-virtual {v0, v1}, Ln3/x;->O(I)V

    .line 940
    .line 941
    .line 942
    iget v1, v0, Ln3/x;->b:I

    .line 943
    .line 944
    if-ne v4, v14, :cond_3e9

    .line 945
    .line 946
    invoke-static {v0, v2, v3}, Li5/e;->h(Ln3/x;II)Landroid/util/Pair;

    .line 947
    .line 948
    .line 949
    move-result-object v14

    .line 950
    if-eqz v14, :cond_3df

    .line 951
    .line 952
    iget-object v4, v14, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 953
    .line 954
    check-cast v4, Ljava/lang/Integer;

    .line 955
    .line 956
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 957
    .line 958
    .line 959
    move-result v4

    .line 960
    if-nez v7, :cond_3c6

    .line 961
    .line 962
    move/from16 v28, v2

    .line 963
    .line 964
    const/16 v29, 0x0

    .line 965
    .line 966
    goto :goto_3d4

    .line 967
    :cond_3c6
    move/from16 v28, v2

    .line 968
    .line 969
    iget-object v2, v14, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 970
    .line 971
    check-cast v2, Li5/v;

    .line 972
    .line 973
    iget-object v2, v2, Li5/v;->b:Ljava/lang/String;

    .line 974
    .line 975
    invoke-virtual {v7, v2}, Lk3/r;->z(Ljava/lang/String;)Lk3/r;

    .line 976
    .line 977
    .line 978
    move-result-object v2

    .line 979
    move-object/from16 v29, v2

    .line 980
    .line 981
    :goto_3d4
    iget-object v2, v8, Lcom/google/android/gms/internal/play_billing/s1;->i:Ljava/lang/Object;

    .line 982
    .line 983
    check-cast v2, [Li5/v;

    .line 984
    .line 985
    iget-object v14, v14, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 986
    .line 987
    check-cast v14, Li5/v;

    .line 988
    .line 989
    aput-object v14, v2, v9

    .line 990
    .line 991
    goto :goto_3e3

    .line 992
    :cond_3df
    move/from16 v28, v2

    .line 993
    .line 994
    move-object/from16 v29, v7

    .line 995
    .line 996
    :goto_3e3
    invoke-virtual {v0, v1}, Ln3/x;->N(I)V

    .line 997
    .line 998
    .line 999
    move-object/from16 v2, v29

    .line 1000
    .line 1001
    goto :goto_3ec

    .line 1002
    :cond_3e9
    move/from16 v28, v2

    .line 1003
    .line 1004
    move-object v2, v7

    .line 1005
    :goto_3ec
    const-string v14, "video/3gpp"

    .line 1006
    .line 1007
    move/from16 v29, v1

    .line 1008
    .line 1009
    const v1, 0x6d317620

    .line 1010
    .line 1011
    .line 1012
    if-ne v4, v1, :cond_3fa

    .line 1013
    .line 1014
    const-string v1, "video/mpeg"

    .line 1015
    .line 1016
    move-object/from16 v26, v1

    .line 1017
    .line 1018
    goto :goto_404

    .line 1019
    :cond_3fa
    const v1, 0x48323633

    .line 1020
    .line 1021
    .line 1022
    if-ne v4, v1, :cond_402

    .line 1023
    .line 1024
    move-object/from16 v26, v14

    .line 1025
    .line 1026
    goto :goto_404

    .line 1027
    :cond_402
    const/16 v26, 0x0

    .line 1028
    .line 1029
    :goto_404
    const/high16 v27, 0x3f800000    # 1.0f

    .line 1030
    .line 1031
    move-object/from16 v33, v2

    .line 1032
    .line 1033
    move/from16 v42, v12

    .line 1034
    .line 1035
    move/from16 v30, v13

    .line 1036
    .line 1037
    move-object/from16 v31, v14

    .line 1038
    .line 1039
    move/from16 v41, v15

    .line 1040
    .line 1041
    move/from16 v15, v18

    .line 1042
    .line 1043
    move-object/from16 v7, v26

    .line 1044
    .line 1045
    move/from16 v37, v27

    .line 1046
    .line 1047
    move/from16 v1, v29

    .line 1048
    .line 1049
    const/4 v2, -0x1

    .line 1050
    const/4 v5, -0x1

    .line 1051
    const/4 v10, -0x1

    .line 1052
    const/4 v12, 0x0

    .line 1053
    const/4 v14, 0x0

    .line 1054
    const/16 v26, 0x0

    .line 1055
    .line 1056
    const/16 v32, 0x0

    .line 1057
    .line 1058
    const/16 v34, -0x1

    .line 1059
    .line 1060
    const/16 v35, -0x1

    .line 1061
    .line 1062
    const/16 v36, 0x0

    .line 1063
    .line 1064
    const/16 v38, -0x1

    .line 1065
    .line 1066
    const/16 v39, 0x0

    .line 1067
    .line 1068
    const/16 v40, -0x1

    .line 1069
    .line 1070
    const/16 v43, 0x0

    .line 1071
    .line 1072
    const/16 v44, 0x0

    .line 1073
    .line 1074
    const/16 v45, 0x0

    .line 1075
    .line 1076
    move/from16 v27, v9

    .line 1077
    .line 1078
    move/from16 v29, v11

    .line 1079
    .line 1080
    move v9, v15

    .line 1081
    const/4 v11, -0x1

    .line 1082
    :goto_439
    sub-int v13, v1, v28

    .line 1083
    .line 1084
    if-ge v13, v3, :cond_452

    .line 1085
    .line 1086
    invoke-virtual {v0, v1}, Ln3/x;->N(I)V

    .line 1087
    .line 1088
    .line 1089
    iget v13, v0, Ln3/x;->b:I

    .line 1090
    .line 1091
    move/from16 v46, v1

    .line 1092
    .line 1093
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1094
    .line 1095
    .line 1096
    move-result v1

    .line 1097
    move/from16 v47, v13

    .line 1098
    .line 1099
    if-nez v1, :cond_461

    .line 1100
    .line 1101
    iget v13, v0, Ln3/x;->b:I

    .line 1102
    .line 1103
    sub-int v13, v13, v28

    .line 1104
    .line 1105
    if-ne v13, v3, :cond_461

    .line 1106
    .line 1107
    :cond_452
    move/from16 v48, v3

    .line 1108
    .line 1109
    move-object/from16 v50, v7

    .line 1110
    .line 1111
    move/from16 v56, v9

    .line 1112
    .line 1113
    move/from16 v54, v11

    .line 1114
    .line 1115
    move/from16 v62, v15

    .line 1116
    .line 1117
    const/4 v12, 0x0

    .line 1118
    const/16 v16, 0xc

    .line 1119
    .line 1120
    goto/16 :goto_ca7

    .line 1121
    .line 1122
    :cond_461
    if-lez v1, :cond_465

    .line 1123
    .line 1124
    const/4 v13, 0x1

    .line 1125
    goto :goto_466

    .line 1126
    :cond_465
    const/4 v13, 0x0

    .line 1127
    :goto_466
    invoke-static {v6, v13}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1128
    .line 1129
    .line 1130
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1131
    .line 1132
    .line 1133
    move-result v13

    .line 1134
    move/from16 v48, v3

    .line 1135
    .line 1136
    const v3, 0x61766343

    .line 1137
    .line 1138
    .line 1139
    if-ne v13, v3, :cond_4c5

    .line 1140
    .line 1141
    if-nez v7, :cond_479

    .line 1142
    .line 1143
    const/4 v3, 0x1

    .line 1144
    :goto_477
    const/4 v5, 0x0

    .line 1145
    goto :goto_47b

    .line 1146
    :cond_479
    const/4 v3, 0x0

    .line 1147
    goto :goto_477

    .line 1148
    :goto_47b
    invoke-static {v5, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1149
    .line 1150
    .line 1151
    add-int/lit8 v13, v47, 0x8

    .line 1152
    .line 1153
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 1154
    .line 1155
    .line 1156
    invoke-static {v0}, Lo4/c;->a(Ln3/x;)Lo4/c;

    .line 1157
    .line 1158
    .line 1159
    move-result-object v3

    .line 1160
    iget-object v14, v3, Lo4/c;->a:Ljava/util/ArrayList;

    .line 1161
    .line 1162
    iget v5, v3, Lo4/c;->b:I

    .line 1163
    .line 1164
    iput v5, v8, Lcom/google/android/gms/internal/play_billing/s1;->d:I

    .line 1165
    .line 1166
    if-nez v26, :cond_492

    .line 1167
    .line 1168
    iget v11, v3, Lo4/c;->k:F

    .line 1169
    .line 1170
    goto :goto_494

    .line 1171
    :cond_492
    move/from16 v11, v37

    .line 1172
    .line 1173
    :goto_494
    iget-object v5, v3, Lo4/c;->l:Ljava/lang/String;

    .line 1174
    .line 1175
    iget v7, v3, Lo4/c;->j:I

    .line 1176
    .line 1177
    iget v10, v3, Lo4/c;->g:I

    .line 1178
    .line 1179
    iget v9, v3, Lo4/c;->h:I

    .line 1180
    .line 1181
    iget v13, v3, Lo4/c;->i:I

    .line 1182
    .line 1183
    iget v15, v3, Lo4/c;->e:I

    .line 1184
    .line 1185
    iget v3, v3, Lo4/c;->f:I

    .line 1186
    .line 1187
    const-string v32, "video/avc"

    .line 1188
    .line 1189
    move/from16 v62, v3

    .line 1190
    .line 1191
    move/from16 v49, v4

    .line 1192
    .line 1193
    move-object/from16 v58, v6

    .line 1194
    .line 1195
    move/from16 v35, v7

    .line 1196
    .line 1197
    move/from16 v54, v9

    .line 1198
    .line 1199
    move/from16 v37, v11

    .line 1200
    .line 1201
    move-object/from16 v59, v12

    .line 1202
    .line 1203
    move/from16 v56, v15

    .line 1204
    .line 1205
    move/from16 v9, v18

    .line 1206
    .line 1207
    move-object/from16 v7, v32

    .line 1208
    .line 1209
    const/4 v3, -0x1

    .line 1210
    const/4 v4, 0x4

    .line 1211
    const/16 v11, 0xff

    .line 1212
    .line 1213
    const/4 v12, 0x0

    .line 1214
    const/4 v15, 0x1

    .line 1215
    const/16 v16, 0xc

    .line 1216
    .line 1217
    move-object/from16 v32, v5

    .line 1218
    .line 1219
    move v5, v13

    .line 1220
    goto/16 :goto_c91

    .line 1221
    .line 1222
    :cond_4c5
    const v3, 0x68766343

    .line 1223
    .line 1224
    .line 1225
    move/from16 v49, v4

    .line 1226
    .line 1227
    const-string v4, "video/hevc"

    .line 1228
    .line 1229
    if-ne v13, v3, :cond_539

    .line 1230
    .line 1231
    if-nez v7, :cond_4d3

    .line 1232
    .line 1233
    const/4 v3, 0x1

    .line 1234
    :goto_4d1
    const/4 v5, 0x0

    .line 1235
    goto :goto_4d5

    .line 1236
    :cond_4d3
    const/4 v3, 0x0

    .line 1237
    goto :goto_4d1

    .line 1238
    :goto_4d5
    invoke-static {v5, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1239
    .line 1240
    .line 1241
    add-int/lit8 v13, v47, 0x8

    .line 1242
    .line 1243
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 1244
    .line 1245
    .line 1246
    const/4 v3, 0x0

    .line 1247
    invoke-static {v0, v3, v5}, Lo4/x;->a(Ln3/x;ZLcom/google/firebase/messaging/t;)Lo4/x;

    .line 1248
    .line 1249
    .line 1250
    move-result-object v7

    .line 1251
    iget-object v14, v7, Lo4/x;->a:Ljava/util/List;

    .line 1252
    .line 1253
    iget v3, v7, Lo4/x;->b:I

    .line 1254
    .line 1255
    iput v3, v8, Lcom/google/android/gms/internal/play_billing/s1;->d:I

    .line 1256
    .line 1257
    if-nez v26, :cond_4ed

    .line 1258
    .line 1259
    iget v11, v7, Lo4/x;->l:F

    .line 1260
    .line 1261
    goto :goto_4ef

    .line 1262
    :cond_4ed
    move/from16 v11, v37

    .line 1263
    .line 1264
    :goto_4ef
    iget v12, v7, Lo4/x;->m:I

    .line 1265
    .line 1266
    iget v3, v7, Lo4/x;->c:I

    .line 1267
    .line 1268
    iget-object v5, v7, Lo4/x;->n:Ljava/lang/String;

    .line 1269
    .line 1270
    iget v9, v7, Lo4/x;->k:I

    .line 1271
    .line 1272
    const/4 v10, -0x1

    .line 1273
    if-eq v9, v10, :cond_4fb

    .line 1274
    .line 1275
    move v2, v9

    .line 1276
    :cond_4fb
    iget v9, v7, Lo4/x;->d:I

    .line 1277
    .line 1278
    iget v10, v7, Lo4/x;->e:I

    .line 1279
    .line 1280
    iget v13, v7, Lo4/x;->h:I

    .line 1281
    .line 1282
    iget v15, v7, Lo4/x;->i:I

    .line 1283
    .line 1284
    move/from16 v32, v2

    .line 1285
    .line 1286
    iget v2, v7, Lo4/x;->j:I

    .line 1287
    .line 1288
    move/from16 v34, v2

    .line 1289
    .line 1290
    iget v2, v7, Lo4/x;->f:I

    .line 1291
    .line 1292
    move/from16 v35, v2

    .line 1293
    .line 1294
    iget v2, v7, Lo4/x;->g:I

    .line 1295
    .line 1296
    iget-object v7, v7, Lo4/x;->o:Lcom/google/firebase/messaging/t;

    .line 1297
    .line 1298
    move/from16 v62, v2

    .line 1299
    .line 1300
    move-object/from16 v58, v6

    .line 1301
    .line 1302
    move-object/from16 v59, v7

    .line 1303
    .line 1304
    move/from16 v40, v9

    .line 1305
    .line 1306
    move/from16 v38, v10

    .line 1307
    .line 1308
    move/from16 v37, v11

    .line 1309
    .line 1310
    move v10, v13

    .line 1311
    move/from16 v54, v15

    .line 1312
    .line 1313
    move/from16 v9, v18

    .line 1314
    .line 1315
    move/from16 v2, v32

    .line 1316
    .line 1317
    move/from16 v56, v35

    .line 1318
    .line 1319
    const/16 v11, 0xff

    .line 1320
    .line 1321
    const/4 v15, 0x1

    .line 1322
    const/16 v16, 0xc

    .line 1323
    .line 1324
    move-object v7, v4

    .line 1325
    move-object/from16 v32, v5

    .line 1326
    .line 1327
    move/from16 v35, v12

    .line 1328
    .line 1329
    move/from16 v5, v34

    .line 1330
    .line 1331
    const/4 v4, 0x4

    .line 1332
    const/4 v12, 0x0

    .line 1333
    move/from16 v34, v3

    .line 1334
    .line 1335
    :goto_536
    const/4 v3, -0x1

    .line 1336
    goto/16 :goto_c91

    .line 1337
    .line 1338
    :cond_539
    const v3, 0x6c687643

    .line 1339
    .line 1340
    .line 1341
    move/from16 v50, v2

    .line 1342
    .line 1343
    const/4 v2, 0x2

    .line 1344
    if-ne v13, v3, :cond_5f4

    .line 1345
    .line 1346
    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1347
    .line 1348
    .line 1349
    move-result v3

    .line 1350
    const-string v4, "lhvC must follow hvcC atom"

    .line 1351
    .line 1352
    invoke-static {v4, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1353
    .line 1354
    .line 1355
    if-eqz v12, :cond_558

    .line 1356
    .line 1357
    iget-object v3, v12, Lcom/google/firebase/messaging/t;->e:Ljava/lang/Object;

    .line 1358
    .line 1359
    check-cast v3, Lhx/m0;

    .line 1360
    .line 1361
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    .line 1362
    .line 1363
    .line 1364
    move-result v3

    .line 1365
    if-lt v3, v2, :cond_558

    .line 1366
    .line 1367
    const/4 v2, 0x1

    .line 1368
    goto :goto_559

    .line 1369
    :cond_558
    const/4 v2, 0x0

    .line 1370
    :goto_559
    const-string v3, "must have at least two layers"

    .line 1371
    .line 1372
    invoke-static {v3, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1373
    .line 1374
    .line 1375
    add-int/lit8 v13, v47, 0x8

    .line 1376
    .line 1377
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 1378
    .line 1379
    .line 1380
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1381
    .line 1382
    .line 1383
    const/4 v2, 0x1

    .line 1384
    invoke-static {v0, v2, v12}, Lo4/x;->a(Ln3/x;ZLcom/google/firebase/messaging/t;)Lo4/x;

    .line 1385
    .line 1386
    .line 1387
    move-result-object v3

    .line 1388
    iget v2, v8, Lcom/google/android/gms/internal/play_billing/s1;->d:I

    .line 1389
    .line 1390
    iget v4, v3, Lo4/x;->b:I

    .line 1391
    .line 1392
    if-ne v2, v4, :cond_573

    .line 1393
    .line 1394
    const/4 v2, 0x1

    .line 1395
    goto :goto_574

    .line 1396
    :cond_573
    const/4 v2, 0x0

    .line 1397
    :goto_574
    const-string v4, "nalUnitLengthFieldLength must be same for both hvcC and lhvC atoms"

    .line 1398
    .line 1399
    invoke-static {v4, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1400
    .line 1401
    .line 1402
    iget v2, v3, Lo4/x;->h:I

    .line 1403
    .line 1404
    const/4 v4, -0x1

    .line 1405
    if-eq v2, v4, :cond_588

    .line 1406
    .line 1407
    if-ne v10, v2, :cond_582

    .line 1408
    .line 1409
    const/4 v2, 0x1

    .line 1410
    goto :goto_583

    .line 1411
    :cond_582
    const/4 v2, 0x0

    .line 1412
    :goto_583
    const-string v7, "colorSpace must be the same for both views"

    .line 1413
    .line 1414
    invoke-static {v7, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1415
    .line 1416
    .line 1417
    :cond_588
    iget v2, v3, Lo4/x;->i:I

    .line 1418
    .line 1419
    if-eq v2, v4, :cond_596

    .line 1420
    .line 1421
    if-ne v11, v2, :cond_590

    .line 1422
    .line 1423
    const/4 v2, 0x1

    .line 1424
    goto :goto_591

    .line 1425
    :cond_590
    const/4 v2, 0x0

    .line 1426
    :goto_591
    const-string v7, "colorRange must be the same for both views"

    .line 1427
    .line 1428
    invoke-static {v7, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1429
    .line 1430
    .line 1431
    :cond_596
    iget v2, v3, Lo4/x;->j:I

    .line 1432
    .line 1433
    if-eq v2, v4, :cond_5a4

    .line 1434
    .line 1435
    if-ne v5, v2, :cond_59e

    .line 1436
    .line 1437
    const/4 v2, 0x1

    .line 1438
    goto :goto_59f

    .line 1439
    :cond_59e
    const/4 v2, 0x0

    .line 1440
    :goto_59f
    const-string v4, "colorTransfer must be the same for both views"

    .line 1441
    .line 1442
    invoke-static {v4, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1443
    .line 1444
    .line 1445
    :cond_5a4
    iget v2, v3, Lo4/x;->f:I

    .line 1446
    .line 1447
    if-ne v9, v2, :cond_5aa

    .line 1448
    .line 1449
    const/4 v2, 0x1

    .line 1450
    goto :goto_5ab

    .line 1451
    :cond_5aa
    const/4 v2, 0x0

    .line 1452
    :goto_5ab
    const-string v4, "bitdepthLuma must be the same for both views"

    .line 1453
    .line 1454
    invoke-static {v4, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1455
    .line 1456
    .line 1457
    iget v2, v3, Lo4/x;->g:I

    .line 1458
    .line 1459
    if-ne v15, v2, :cond_5b6

    .line 1460
    .line 1461
    const/4 v2, 0x1

    .line 1462
    goto :goto_5b7

    .line 1463
    :cond_5b6
    const/4 v2, 0x0

    .line 1464
    :goto_5b7
    const-string v4, "bitdepthChroma must be the same for both views"

    .line 1465
    .line 1466
    invoke-static {v4, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1467
    .line 1468
    .line 1469
    if-eqz v14, :cond_5cf

    .line 1470
    .line 1471
    invoke-static {}, Lhx/m0;->p()Lhx/j0;

    .line 1472
    .line 1473
    .line 1474
    move-result-object v2

    .line 1475
    invoke-virtual {v2, v14}, Lhx/f0;->e(Ljava/lang/Iterable;)V

    .line 1476
    .line 1477
    .line 1478
    iget-object v4, v3, Lo4/x;->a:Ljava/util/List;

    .line 1479
    .line 1480
    invoke-virtual {v2, v4}, Lhx/f0;->e(Ljava/lang/Iterable;)V

    .line 1481
    .line 1482
    .line 1483
    invoke-virtual {v2}, Lhx/j0;->g()Lhx/w1;

    .line 1484
    .line 1485
    .line 1486
    move-result-object v14

    .line 1487
    goto :goto_5d5

    .line 1488
    :cond_5cf
    const-string v2, "initializationData must be already set from hvcC atom"

    .line 1489
    .line 1490
    const/4 v4, 0x0

    .line 1491
    invoke-static {v2, v4}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1492
    .line 1493
    .line 1494
    :goto_5d5
    iget-object v2, v3, Lo4/x;->n:Ljava/lang/String;

    .line 1495
    .line 1496
    const-string v3, "video/mv-hevc"

    .line 1497
    .line 1498
    move-object/from16 v32, v2

    .line 1499
    .line 1500
    move-object v7, v3

    .line 1501
    move-object/from16 v58, v6

    .line 1502
    .line 1503
    move/from16 v56, v9

    .line 1504
    .line 1505
    move/from16 v54, v11

    .line 1506
    .line 1507
    move-object/from16 v59, v12

    .line 1508
    .line 1509
    move/from16 v62, v15

    .line 1510
    .line 1511
    move/from16 v9, v18

    .line 1512
    .line 1513
    move/from16 v2, v50

    .line 1514
    .line 1515
    const/4 v3, -0x1

    .line 1516
    const/4 v4, 0x4

    .line 1517
    :goto_5ec
    const/16 v11, 0xff

    .line 1518
    .line 1519
    const/4 v12, 0x0

    .line 1520
    const/4 v15, 0x1

    .line 1521
    const/16 v16, 0xc

    .line 1522
    .line 1523
    goto/16 :goto_c91

    .line 1524
    .line 1525
    :cond_5f4
    const v3, 0x76766343

    .line 1526
    .line 1527
    .line 1528
    const/16 v51, 0x5

    .line 1529
    .line 1530
    const/16 v52, 0x7

    .line 1531
    .line 1532
    if-ne v13, v3, :cond_76e

    .line 1533
    .line 1534
    if-nez v7, :cond_602

    .line 1535
    .line 1536
    const/4 v2, 0x1

    .line 1537
    :goto_600
    const/4 v3, 0x0

    .line 1538
    goto :goto_604

    .line 1539
    :cond_602
    const/4 v2, 0x0

    .line 1540
    goto :goto_600

    .line 1541
    :goto_604
    invoke-static {v3, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1542
    .line 1543
    .line 1544
    add-int/lit8 v13, v47, 0x8

    .line 1545
    .line 1546
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 1547
    .line 1548
    .line 1549
    :try_start_60c
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1550
    .line 1551
    .line 1552
    move-result v2

    .line 1553
    if-nez v2, :cond_75e

    .line 1554
    .line 1555
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1556
    .line 1557
    .line 1558
    move-result v2
    :try_end_616
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_60c .. :try_end_616} :catch_766

    .line 1559
    shr-int/lit8 v3, v2, 0x1

    .line 1560
    .line 1561
    and-int/lit8 v3, v3, 0x3

    .line 1562
    .line 1563
    const/4 v7, 0x1

    .line 1564
    and-int/2addr v2, v7

    .line 1565
    if-eqz v2, :cond_621

    .line 1566
    .line 1567
    move/from16 v23, v7

    .line 1568
    .line 1569
    goto :goto_623

    .line 1570
    :cond_621
    const/16 v23, 0x0

    .line 1571
    .line 1572
    :goto_623
    add-int/2addr v3, v7

    .line 1573
    const-string v2, "L"

    .line 1574
    .line 1575
    if-eqz v23, :cond_689

    .line 1576
    .line 1577
    :try_start_628
    invoke-virtual {v0, v7}, Ln3/x;->O(I)V

    .line 1578
    .line 1579
    .line 1580
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1581
    .line 1582
    .line 1583
    move-result v7

    .line 1584
    const/16 v22, 0x4

    .line 1585
    .line 1586
    shr-int/lit8 v7, v7, 0x4

    .line 1587
    .line 1588
    and-int/lit8 v7, v7, 0x7

    .line 1589
    .line 1590
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1591
    .line 1592
    .line 1593
    move-result v9

    .line 1594
    shr-int/lit8 v9, v9, 0x5

    .line 1595
    .line 1596
    and-int/lit8 v9, v9, 0x7

    .line 1597
    .line 1598
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1599
    .line 1600
    .line 1601
    move-result v13

    .line 1602
    and-int/lit8 v13, v13, 0x3f

    .line 1603
    .line 1604
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1605
    .line 1606
    .line 1607
    move-result v14

    .line 1608
    shr-int/lit8 v15, v14, 0x1

    .line 1609
    .line 1610
    and-int/lit8 v15, v15, 0x7f

    .line 1611
    .line 1612
    const/16 v23, 0x1

    .line 1613
    .line 1614
    and-int/lit8 v14, v14, 0x1

    .line 1615
    .line 1616
    if-eqz v14, :cond_653

    .line 1617
    .line 1618
    const-string v2, "H"

    .line 1619
    .line 1620
    :cond_653
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1621
    .line 1622
    .line 1623
    move-result v14

    .line 1624
    invoke-virtual {v0, v13}, Ln3/x;->O(I)V

    .line 1625
    .line 1626
    .line 1627
    const/4 v13, 0x1

    .line 1628
    if-le v7, v13, :cond_679

    .line 1629
    .line 1630
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1631
    .line 1632
    .line 1633
    move-result v32

    .line 1634
    const/4 v4, 0x0

    .line 1635
    :goto_662
    move/from16 v23, v13

    .line 1636
    .line 1637
    add-int/lit8 v13, v7, -0x1

    .line 1638
    .line 1639
    if-ge v4, v13, :cond_679

    .line 1640
    .line 1641
    rsub-int/lit8 v13, v4, 0x7

    .line 1642
    .line 1643
    shr-int v13, v32, v13

    .line 1644
    .line 1645
    and-int/lit8 v13, v13, 0x1

    .line 1646
    .line 1647
    if-eqz v13, :cond_675

    .line 1648
    .line 1649
    move/from16 v13, v23

    .line 1650
    .line 1651
    invoke-virtual {v0, v13}, Ln3/x;->O(I)V

    .line 1652
    .line 1653
    .line 1654
    :cond_675
    add-int/lit8 v4, v4, 0x1

    .line 1655
    .line 1656
    const/4 v13, 0x1

    .line 1657
    goto :goto_662

    .line 1658
    :cond_679
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1659
    .line 1660
    .line 1661
    move-result v4

    .line 1662
    const/16 v22, 0x4

    .line 1663
    .line 1664
    mul-int/lit8 v4, v4, 0x4

    .line 1665
    .line 1666
    invoke-virtual {v0, v4}, Ln3/x;->O(I)V

    .line 1667
    .line 1668
    .line 1669
    const/4 v4, 0x6

    .line 1670
    invoke-virtual {v0, v4}, Ln3/x;->O(I)V

    .line 1671
    .line 1672
    .line 1673
    goto :goto_68c

    .line 1674
    :cond_689
    const/4 v9, 0x0

    .line 1675
    const/4 v14, 0x0

    .line 1676
    const/4 v15, 0x0

    .line 1677
    :goto_68c
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1678
    .line 1679
    .line 1680
    move-result v4

    .line 1681
    iget v7, v0, Ln3/x;->b:I

    .line 1682
    .line 1683
    move/from16 v32, v9

    .line 1684
    .line 1685
    move/from16 v54, v11

    .line 1686
    .line 1687
    const/4 v9, 0x0

    .line 1688
    const/4 v13, 0x0

    .line 1689
    :goto_698
    const/16 v11, 0xd

    .line 1690
    .line 1691
    if-ge v13, v4, :cond_6ca

    .line 1692
    .line 1693
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1694
    .line 1695
    .line 1696
    move-result v35

    .line 1697
    move/from16 v47, v13

    .line 1698
    .line 1699
    and-int/lit8 v13, v35, 0x1f

    .line 1700
    .line 1701
    if-eq v13, v11, :cond_6af

    .line 1702
    .line 1703
    const/16 v11, 0xc

    .line 1704
    .line 1705
    if-eq v13, v11, :cond_6af

    .line 1706
    .line 1707
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 1708
    .line 1709
    .line 1710
    move-result v11

    .line 1711
    goto :goto_6b0

    .line 1712
    :cond_6af
    const/4 v11, 0x1

    .line 1713
    :goto_6b0
    const/4 v13, 0x0

    .line 1714
    :goto_6b1
    if-ge v13, v11, :cond_6c5

    .line 1715
    .line 1716
    move/from16 v35, v9

    .line 1717
    .line 1718
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 1719
    .line 1720
    .line 1721
    move-result v9

    .line 1722
    add-int/lit8 v51, v9, 0x4

    .line 1723
    .line 1724
    add-int v35, v51, v35

    .line 1725
    .line 1726
    invoke-virtual {v0, v9}, Ln3/x;->O(I)V

    .line 1727
    .line 1728
    .line 1729
    add-int/lit8 v13, v13, 0x1

    .line 1730
    .line 1731
    move/from16 v9, v35

    .line 1732
    .line 1733
    goto :goto_6b1

    .line 1734
    :cond_6c5
    move/from16 v35, v9

    .line 1735
    .line 1736
    add-int/lit8 v13, v47, 0x1

    .line 1737
    .line 1738
    goto :goto_698

    .line 1739
    :cond_6ca
    invoke-virtual {v0, v7}, Ln3/x;->N(I)V

    .line 1740
    .line 1741
    .line 1742
    new-array v7, v9, [B

    .line 1743
    .line 1744
    const/4 v9, 0x0

    .line 1745
    const/4 v13, 0x0

    .line 1746
    :goto_6d1
    if-ge v9, v4, :cond_717

    .line 1747
    .line 1748
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1749
    .line 1750
    .line 1751
    move-result v35

    .line 1752
    move/from16 v47, v4

    .line 1753
    .line 1754
    and-int/lit8 v4, v35, 0x1f

    .line 1755
    .line 1756
    if-eq v4, v11, :cond_6e6

    .line 1757
    .line 1758
    const/16 v11, 0xc

    .line 1759
    .line 1760
    if-eq v4, v11, :cond_6e6

    .line 1761
    .line 1762
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 1763
    .line 1764
    .line 1765
    move-result v4

    .line 1766
    goto :goto_6e7

    .line 1767
    :cond_6e6
    const/4 v4, 0x1

    .line 1768
    :goto_6e7
    const/4 v11, 0x0

    .line 1769
    :goto_6e8
    if-ge v11, v4, :cond_70c

    .line 1770
    .line 1771
    move/from16 v51, v4

    .line 1772
    .line 1773
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 1774
    .line 1775
    .line 1776
    move-result v4

    .line 1777
    move/from16 v52, v9

    .line 1778
    .line 1779
    sget-object v9, Lo3/n;->a:[B

    .line 1780
    .line 1781
    move/from16 v55, v5

    .line 1782
    .line 1783
    move/from16 v53, v11

    .line 1784
    .line 1785
    const/4 v5, 0x0

    .line 1786
    const/4 v11, 0x4

    .line 1787
    invoke-static {v9, v5, v7, v13, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1788
    .line 1789
    .line 1790
    add-int/lit8 v13, v13, 0x4

    .line 1791
    .line 1792
    invoke-virtual {v0, v7, v13, v4}, Ln3/x;->k([BII)V

    .line 1793
    .line 1794
    .line 1795
    add-int/2addr v13, v4

    .line 1796
    add-int/lit8 v11, v53, 0x1

    .line 1797
    .line 1798
    move/from16 v4, v51

    .line 1799
    .line 1800
    move/from16 v9, v52

    .line 1801
    .line 1802
    move/from16 v5, v55

    .line 1803
    .line 1804
    goto :goto_6e8

    .line 1805
    :cond_70c
    move/from16 v55, v5

    .line 1806
    .line 1807
    move/from16 v52, v9

    .line 1808
    .line 1809
    add-int/lit8 v9, v52, 0x1

    .line 1810
    .line 1811
    move/from16 v4, v47

    .line 1812
    .line 1813
    const/16 v11, 0xd

    .line 1814
    .line 1815
    goto :goto_6d1

    .line 1816
    :cond_717
    move/from16 v55, v5

    .line 1817
    .line 1818
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 1819
    .line 1820
    new-instance v4, Ljava/lang/StringBuilder;

    .line 1821
    .line 1822
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 1823
    .line 1824
    .line 1825
    const-string v5, "vvc1."

    .line 1826
    .line 1827
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1828
    .line 1829
    .line 1830
    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1831
    .line 1832
    .line 1833
    const-string v5, "."

    .line 1834
    .line 1835
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1836
    .line 1837
    .line 1838
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1839
    .line 1840
    .line 1841
    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1842
    .line 1843
    .line 1844
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1845
    .line 1846
    .line 1847
    move-result-object v2

    .line 1848
    invoke-static {v7}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 1849
    .line 1850
    .line 1851
    move-result-object v14
    :try_end_73b
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_628 .. :try_end_73b} :catch_766

    .line 1852
    add-int/lit8 v9, v32, 0x8

    .line 1853
    .line 1854
    iput v3, v8, Lcom/google/android/gms/internal/play_billing/s1;->d:I

    .line 1855
    .line 1856
    const-string v3, "video/vvc"

    .line 1857
    .line 1858
    move-object/from16 v32, v2

    .line 1859
    .line 1860
    move-object v7, v3

    .line 1861
    move-object/from16 v58, v6

    .line 1862
    .line 1863
    move/from16 v56, v9

    .line 1864
    .line 1865
    move/from16 v62, v56

    .line 1866
    .line 1867
    move-object/from16 v59, v12

    .line 1868
    .line 1869
    move/from16 v9, v18

    .line 1870
    .line 1871
    move/from16 v2, v50

    .line 1872
    .line 1873
    move/from16 v5, v55

    .line 1874
    .line 1875
    const/4 v3, -0x1

    .line 1876
    const/4 v4, 0x4

    .line 1877
    const/16 v11, 0xff

    .line 1878
    .line 1879
    const/4 v12, 0x0

    .line 1880
    const/4 v15, 0x1

    .line 1881
    const/16 v16, 0xc

    .line 1882
    .line 1883
    const/16 v35, 0x10

    .line 1884
    .line 1885
    goto/16 :goto_c91

    .line 1886
    .line 1887
    :cond_75e
    :try_start_75e
    const-string v0, "Unsupported VVC version"

    .line 1888
    .line 1889
    const/4 v5, 0x0

    .line 1890
    invoke-static {v0, v5}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1891
    .line 1892
    .line 1893
    move-result-object v0

    .line 1894
    throw v0
    :try_end_766
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_75e .. :try_end_766} :catch_766

    .line 1895
    :catch_766
    move-exception v0

    .line 1896
    const-string v1, "Error parsing VVC configuration"

    .line 1897
    .line 1898
    invoke-static {v1, v0}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    .line 1899
    .line 1900
    .line 1901
    move-result-object v0

    .line 1902
    throw v0

    .line 1903
    :cond_76e
    move/from16 v55, v5

    .line 1904
    .line 1905
    move/from16 v54, v11

    .line 1906
    .line 1907
    const v3, 0x76657875

    .line 1908
    .line 1909
    .line 1910
    if-ne v13, v3, :cond_86d

    .line 1911
    .line 1912
    add-int/lit8 v13, v47, 0x8

    .line 1913
    .line 1914
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 1915
    .line 1916
    .line 1917
    iget v3, v0, Ln3/x;->b:I

    .line 1918
    .line 1919
    const/4 v5, 0x0

    .line 1920
    :goto_77f
    sub-int v11, v3, v47

    .line 1921
    .line 1922
    if-ge v11, v1, :cond_813

    .line 1923
    .line 1924
    invoke-virtual {v0, v3}, Ln3/x;->N(I)V

    .line 1925
    .line 1926
    .line 1927
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1928
    .line 1929
    .line 1930
    move-result v11

    .line 1931
    if-lez v11, :cond_78e

    .line 1932
    .line 1933
    const/4 v13, 0x1

    .line 1934
    goto :goto_78f

    .line 1935
    :cond_78e
    const/4 v13, 0x0

    .line 1936
    :goto_78f
    invoke-static {v6, v13}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1937
    .line 1938
    .line 1939
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1940
    .line 1941
    .line 1942
    move-result v13

    .line 1943
    const v4, 0x65796573

    .line 1944
    .line 1945
    .line 1946
    if-ne v13, v4, :cond_806

    .line 1947
    .line 1948
    add-int/lit8 v4, v3, 0x8

    .line 1949
    .line 1950
    invoke-virtual {v0, v4}, Ln3/x;->N(I)V

    .line 1951
    .line 1952
    .line 1953
    iget v4, v0, Ln3/x;->b:I

    .line 1954
    .line 1955
    :goto_7a2
    sub-int v5, v4, v3

    .line 1956
    .line 1957
    if-ge v5, v11, :cond_7ff

    .line 1958
    .line 1959
    invoke-virtual {v0, v4}, Ln3/x;->N(I)V

    .line 1960
    .line 1961
    .line 1962
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1963
    .line 1964
    .line 1965
    move-result v5

    .line 1966
    if-lez v5, :cond_7b1

    .line 1967
    .line 1968
    const/4 v13, 0x1

    .line 1969
    goto :goto_7b2

    .line 1970
    :cond_7b1
    const/4 v13, 0x0

    .line 1971
    :goto_7b2
    invoke-static {v6, v13}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 1972
    .line 1973
    .line 1974
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 1975
    .line 1976
    .line 1977
    move-result v13

    .line 1978
    const v2, 0x73747269

    .line 1979
    .line 1980
    .line 1981
    if-ne v13, v2, :cond_7f6

    .line 1982
    .line 1983
    const/4 v2, 0x4

    .line 1984
    invoke-virtual {v0, v2}, Ln3/x;->O(I)V

    .line 1985
    .line 1986
    .line 1987
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 1988
    .line 1989
    .line 1990
    move-result v2

    .line 1991
    new-instance v4, La8/c;

    .line 1992
    .line 1993
    new-instance v5, Li5/c;

    .line 1994
    .line 1995
    and-int/lit8 v13, v2, 0x1

    .line 1996
    .line 1997
    move/from16 v52, v2

    .line 1998
    .line 1999
    const/4 v2, 0x1

    .line 2000
    if-ne v13, v2, :cond_7d3

    .line 2001
    .line 2002
    const/4 v2, 0x1

    .line 2003
    goto :goto_7d4

    .line 2004
    :cond_7d3
    const/4 v2, 0x0

    .line 2005
    :goto_7d4
    and-int/lit8 v13, v52, 0x2

    .line 2006
    .line 2007
    move/from16 v53, v3

    .line 2008
    .line 2009
    const/4 v3, 0x2

    .line 2010
    if-ne v13, v3, :cond_7dd

    .line 2011
    .line 2012
    const/4 v3, 0x1

    .line 2013
    goto :goto_7de

    .line 2014
    :cond_7dd
    const/4 v3, 0x0

    .line 2015
    :goto_7de
    and-int/lit8 v13, v52, 0x8

    .line 2016
    .line 2017
    move-object/from16 v58, v6

    .line 2018
    .line 2019
    move/from16 v6, v18

    .line 2020
    .line 2021
    if-ne v13, v6, :cond_7e8

    .line 2022
    .line 2023
    const/4 v6, 0x1

    .line 2024
    goto :goto_7e9

    .line 2025
    :cond_7e8
    const/4 v6, 0x0

    .line 2026
    :goto_7e9
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 2027
    .line 2028
    .line 2029
    iput-boolean v2, v5, Li5/c;->a:Z

    .line 2030
    .line 2031
    iput-boolean v3, v5, Li5/c;->b:Z

    .line 2032
    .line 2033
    iput-boolean v6, v5, Li5/c;->c:Z

    .line 2034
    .line 2035
    invoke-direct {v4, v5}, La8/c;-><init>(Ljava/lang/Object;)V

    .line 2036
    .line 2037
    .line 2038
    goto :goto_804

    .line 2039
    :cond_7f6
    move/from16 v53, v3

    .line 2040
    .line 2041
    move-object/from16 v58, v6

    .line 2042
    .line 2043
    add-int/2addr v4, v5

    .line 2044
    const/4 v2, 0x2

    .line 2045
    const/16 v18, 0x8

    .line 2046
    .line 2047
    goto :goto_7a2

    .line 2048
    :cond_7ff
    move/from16 v53, v3

    .line 2049
    .line 2050
    move-object/from16 v58, v6

    .line 2051
    .line 2052
    const/4 v4, 0x0

    .line 2053
    :goto_804
    move-object v5, v4

    .line 2054
    goto :goto_80a

    .line 2055
    :cond_806
    move/from16 v53, v3

    .line 2056
    .line 2057
    move-object/from16 v58, v6

    .line 2058
    .line 2059
    :goto_80a
    add-int v3, v53, v11

    .line 2060
    .line 2061
    move-object/from16 v6, v58

    .line 2062
    .line 2063
    const/4 v2, 0x2

    .line 2064
    const/16 v18, 0x8

    .line 2065
    .line 2066
    goto/16 :goto_77f

    .line 2067
    .line 2068
    :cond_813
    move-object/from16 v58, v6

    .line 2069
    .line 2070
    if-nez v5, :cond_819

    .line 2071
    .line 2072
    const/4 v2, 0x0

    .line 2073
    goto :goto_820

    .line 2074
    :cond_819
    new-instance v2, La8/d;

    .line 2075
    .line 2076
    const/16 v3, 0x15

    .line 2077
    .line 2078
    invoke-direct {v2, v3, v5}, La8/d;-><init>(ILjava/lang/Object;)V

    .line 2079
    .line 2080
    .line 2081
    :goto_820
    if-eqz v2, :cond_850

    .line 2082
    .line 2083
    iget-object v2, v2, La8/d;->e:Ljava/lang/Object;

    .line 2084
    .line 2085
    check-cast v2, La8/c;

    .line 2086
    .line 2087
    iget-object v2, v2, La8/c;->d:Ljava/lang/Object;

    .line 2088
    .line 2089
    check-cast v2, Li5/c;

    .line 2090
    .line 2091
    iget-boolean v3, v2, Li5/c;->c:Z

    .line 2092
    .line 2093
    if-eqz v12, :cond_853

    .line 2094
    .line 2095
    iget-object v4, v12, Lcom/google/firebase/messaging/t;->e:Ljava/lang/Object;

    .line 2096
    .line 2097
    check-cast v4, Lhx/m0;

    .line 2098
    .line 2099
    invoke-virtual {v4}, Ljava/util/AbstractCollection;->size()I

    .line 2100
    .line 2101
    .line 2102
    move-result v4

    .line 2103
    const/4 v5, 0x2

    .line 2104
    if-lt v4, v5, :cond_853

    .line 2105
    .line 2106
    iget-boolean v4, v2, Li5/c;->a:Z

    .line 2107
    .line 2108
    if-eqz v4, :cond_843

    .line 2109
    .line 2110
    iget-boolean v2, v2, Li5/c;->b:Z

    .line 2111
    .line 2112
    if-eqz v2, :cond_843

    .line 2113
    .line 2114
    const/4 v2, 0x1

    .line 2115
    goto :goto_844

    .line 2116
    :cond_843
    const/4 v2, 0x0

    .line 2117
    :goto_844
    const-string v4, "both eye views must be marked as available"

    .line 2118
    .line 2119
    invoke-static {v4, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 2120
    .line 2121
    .line 2122
    xor-int/lit8 v2, v3, 0x1

    .line 2123
    .line 2124
    const-string v3, "for MV-HEVC, eye_views_reversed must be set to false"

    .line 2125
    .line 2126
    invoke-static {v3, v2}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 2127
    .line 2128
    .line 2129
    :cond_850
    move/from16 v2, v50

    .line 2130
    .line 2131
    goto :goto_85f

    .line 2132
    :cond_853
    move/from16 v2, v50

    .line 2133
    .line 2134
    const/4 v4, -0x1

    .line 2135
    if-ne v2, v4, :cond_85f

    .line 2136
    .line 2137
    if-eqz v3, :cond_85b

    .line 2138
    .line 2139
    goto :goto_85d

    .line 2140
    :cond_85b
    const/16 v51, 0x4

    .line 2141
    .line 2142
    :goto_85d
    move/from16 v2, v51

    .line 2143
    .line 2144
    :cond_85f
    :goto_85f
    move/from16 v56, v9

    .line 2145
    .line 2146
    move-object/from16 v59, v12

    .line 2147
    .line 2148
    move/from16 v62, v15

    .line 2149
    .line 2150
    move/from16 v5, v55

    .line 2151
    .line 2152
    const/4 v3, -0x1

    .line 2153
    const/4 v4, 0x4

    .line 2154
    const/16 v9, 0x8

    .line 2155
    .line 2156
    goto/16 :goto_5ec

    .line 2157
    .line 2158
    :cond_86d
    move-object/from16 v58, v6

    .line 2159
    .line 2160
    move/from16 v2, v50

    .line 2161
    .line 2162
    const v3, 0x64766343

    .line 2163
    .line 2164
    .line 2165
    if-eq v13, v3, :cond_880

    .line 2166
    .line 2167
    const v3, 0x64767643

    .line 2168
    .line 2169
    .line 2170
    if-eq v13, v3, :cond_880

    .line 2171
    .line 2172
    const v3, 0x64767743

    .line 2173
    .line 2174
    .line 2175
    if-ne v13, v3, :cond_896

    .line 2176
    .line 2177
    :cond_880
    move-object/from16 v50, v7

    .line 2178
    .line 2179
    move/from16 v56, v9

    .line 2180
    .line 2181
    move-object/from16 v59, v12

    .line 2182
    .line 2183
    move/from16 v62, v15

    .line 2184
    .line 2185
    move/from16 v5, v55

    .line 2186
    .line 2187
    const/4 v3, -0x1

    .line 2188
    const/4 v4, 0x4

    .line 2189
    const/16 v9, 0x8

    .line 2190
    .line 2191
    const/16 v11, 0xff

    .line 2192
    .line 2193
    const/4 v12, 0x0

    .line 2194
    const/4 v15, 0x1

    .line 2195
    const/16 v16, 0xc

    .line 2196
    .line 2197
    goto/16 :goto_c8a

    .line 2198
    .line 2199
    :cond_896
    const v3, 0x76706343

    .line 2200
    .line 2201
    .line 2202
    const/16 v4, 0xb

    .line 2203
    .line 2204
    if-ne v13, v3, :cond_93f

    .line 2205
    .line 2206
    if-nez v7, :cond_8a2

    .line 2207
    .line 2208
    const/4 v3, 0x1

    .line 2209
    :goto_8a0
    const/4 v5, 0x0

    .line 2210
    goto :goto_8a4

    .line 2211
    :cond_8a2
    const/4 v3, 0x0

    .line 2212
    goto :goto_8a0

    .line 2213
    :goto_8a4
    invoke-static {v5, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 2214
    .line 2215
    .line 2216
    const-string v3, "video/x-vnd.on2.vp9"

    .line 2217
    .line 2218
    move/from16 v5, v49

    .line 2219
    .line 2220
    const v6, 0x76703038

    .line 2221
    .line 2222
    .line 2223
    if-ne v5, v6, :cond_8b3

    .line 2224
    .line 2225
    const-string v7, "video/x-vnd.on2.vp8"

    .line 2226
    .line 2227
    goto :goto_8b4

    .line 2228
    :cond_8b3
    move-object v7, v3

    .line 2229
    :goto_8b4
    add-int/lit8 v13, v47, 0xc

    .line 2230
    .line 2231
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 2232
    .line 2233
    .line 2234
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2235
    .line 2236
    .line 2237
    move-result v9

    .line 2238
    int-to-byte v9, v9

    .line 2239
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2240
    .line 2241
    .line 2242
    move-result v10

    .line 2243
    int-to-byte v10, v10

    .line 2244
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2245
    .line 2246
    .line 2247
    move-result v11

    .line 2248
    shr-int/lit8 v13, v11, 0x4

    .line 2249
    .line 2250
    shr-int/lit8 v15, v11, 0x1

    .line 2251
    .line 2252
    and-int/lit8 v15, v15, 0x7

    .line 2253
    .line 2254
    int-to-byte v15, v15

    .line 2255
    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2256
    .line 2257
    .line 2258
    move-result v3

    .line 2259
    if-eqz v3, :cond_90b

    .line 2260
    .line 2261
    int-to-byte v3, v13

    .line 2262
    sget-object v14, Ln3/g;->a:[B

    .line 2263
    .line 2264
    const/16 v14, 0xc

    .line 2265
    .line 2266
    new-array v6, v14, [B

    .line 2267
    .line 2268
    const/16 v23, 0x1

    .line 2269
    .line 2270
    const/16 v24, 0x0

    .line 2271
    .line 2272
    aput-byte v23, v6, v24

    .line 2273
    .line 2274
    aput-byte v23, v6, v23

    .line 2275
    .line 2276
    const/16 v57, 0x2

    .line 2277
    .line 2278
    aput-byte v9, v6, v57

    .line 2279
    .line 2280
    aput-byte v57, v6, v17

    .line 2281
    .line 2282
    const/16 v22, 0x4

    .line 2283
    .line 2284
    aput-byte v23, v6, v22

    .line 2285
    .line 2286
    aput-byte v10, v6, v51

    .line 2287
    .line 2288
    const/16 v53, 0x6

    .line 2289
    .line 2290
    aput-byte v17, v6, v53

    .line 2291
    .line 2292
    aput-byte v23, v6, v52

    .line 2293
    .line 2294
    const/16 v18, 0x8

    .line 2295
    .line 2296
    aput-byte v3, v6, v18

    .line 2297
    .line 2298
    const/16 v3, 0x9

    .line 2299
    .line 2300
    aput-byte v22, v6, v3

    .line 2301
    .line 2302
    const/16 v3, 0xa

    .line 2303
    .line 2304
    aput-byte v23, v6, v3

    .line 2305
    .line 2306
    aput-byte v15, v6, v4

    .line 2307
    .line 2308
    invoke-static {v6}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 2309
    .line 2310
    .line 2311
    move-result-object v3

    .line 2312
    move/from16 v16, v14

    .line 2313
    .line 2314
    move-object v14, v3

    .line 2315
    goto :goto_90d

    .line 2316
    :cond_90b
    const/16 v16, 0xc

    .line 2317
    .line 2318
    :goto_90d
    and-int/lit8 v3, v11, 0x1

    .line 2319
    .line 2320
    if-eqz v3, :cond_913

    .line 2321
    .line 2322
    const/4 v3, 0x1

    .line 2323
    goto :goto_914

    .line 2324
    :cond_913
    const/4 v3, 0x0

    .line 2325
    :goto_914
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2326
    .line 2327
    .line 2328
    move-result v4

    .line 2329
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2330
    .line 2331
    .line 2332
    move-result v6

    .line 2333
    invoke-static {v4}, Lk3/m;->f(I)I

    .line 2334
    .line 2335
    .line 2336
    move-result v10

    .line 2337
    if-eqz v3, :cond_925

    .line 2338
    .line 2339
    const/16 v57, 0x1

    .line 2340
    .line 2341
    goto :goto_927

    .line 2342
    :cond_925
    const/16 v57, 0x2

    .line 2343
    .line 2344
    :goto_927
    invoke-static {v6}, Lk3/m;->g(I)I

    .line 2345
    .line 2346
    .line 2347
    move-result v3

    .line 2348
    move/from16 v49, v5

    .line 2349
    .line 2350
    move-object/from16 v59, v12

    .line 2351
    .line 2352
    move/from16 v56, v13

    .line 2353
    .line 2354
    move/from16 v62, v56

    .line 2355
    .line 2356
    move/from16 v54, v57

    .line 2357
    .line 2358
    const/4 v4, 0x4

    .line 2359
    const/16 v9, 0x8

    .line 2360
    .line 2361
    const/16 v11, 0xff

    .line 2362
    .line 2363
    const/4 v12, 0x0

    .line 2364
    const/4 v15, 0x1

    .line 2365
    move v5, v3

    .line 2366
    goto/16 :goto_536

    .line 2367
    .line 2368
    :cond_93f
    move/from16 v5, v49

    .line 2369
    .line 2370
    const/16 v16, 0xc

    .line 2371
    .line 2372
    const v3, 0x61763143

    .line 2373
    .line 2374
    .line 2375
    if-ne v13, v3, :cond_986

    .line 2376
    .line 2377
    add-int/lit8 v3, v1, -0x8

    .line 2378
    .line 2379
    new-array v4, v3, [B

    .line 2380
    .line 2381
    const/4 v6, 0x0

    .line 2382
    invoke-virtual {v0, v4, v6, v3}, Ln3/x;->k([BII)V

    .line 2383
    .line 2384
    .line 2385
    invoke-static {v4}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 2386
    .line 2387
    .line 2388
    move-result-object v14

    .line 2389
    invoke-static {v4}, Lds/g;->f([B)Lds/g;

    .line 2390
    .line 2391
    .line 2392
    move-result-object v3

    .line 2393
    if-eqz v3, :cond_96a

    .line 2394
    .line 2395
    iget v9, v3, Lds/g;->e:I

    .line 2396
    .line 2397
    iget v10, v3, Lds/g;->i:I

    .line 2398
    .line 2399
    iget v11, v3, Lds/g;->v:I

    .line 2400
    .line 2401
    iget v4, v3, Lds/g;->w:I

    .line 2402
    .line 2403
    iget-object v3, v3, Lds/g;->x:Ljava/lang/Object;

    .line 2404
    .line 2405
    move-object/from16 v32, v3

    .line 2406
    .line 2407
    check-cast v32, Ljava/lang/String;

    .line 2408
    .line 2409
    move v15, v9

    .line 2410
    goto :goto_96e

    .line 2411
    :cond_96a
    move/from16 v11, v54

    .line 2412
    .line 2413
    move/from16 v4, v55

    .line 2414
    .line 2415
    :goto_96e
    const-string v3, "video/av01"

    .line 2416
    .line 2417
    move-object v7, v3

    .line 2418
    move/from16 v49, v5

    .line 2419
    .line 2420
    move/from16 v56, v9

    .line 2421
    .line 2422
    move/from16 v54, v11

    .line 2423
    .line 2424
    move-object/from16 v59, v12

    .line 2425
    .line 2426
    move/from16 v62, v15

    .line 2427
    .line 2428
    const/4 v3, -0x1

    .line 2429
    const/16 v9, 0x8

    .line 2430
    .line 2431
    const/16 v11, 0xff

    .line 2432
    .line 2433
    const/4 v12, 0x0

    .line 2434
    const/4 v15, 0x1

    .line 2435
    move v5, v4

    .line 2436
    const/4 v4, 0x4

    .line 2437
    goto/16 :goto_c91

    .line 2438
    .line 2439
    :cond_986
    const v3, 0x636c6c69

    .line 2440
    .line 2441
    .line 2442
    const/16 v6, 0x19

    .line 2443
    .line 2444
    if-ne v13, v3, :cond_9c4

    .line 2445
    .line 2446
    if-nez v39, :cond_999

    .line 2447
    .line 2448
    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 2449
    .line 2450
    .line 2451
    move-result-object v3

    .line 2452
    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 2453
    .line 2454
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 2455
    .line 2456
    .line 2457
    move-result-object v39

    .line 2458
    :cond_999
    move-object/from16 v3, v39

    .line 2459
    .line 2460
    const/16 v4, 0x15

    .line 2461
    .line 2462
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 2463
    .line 2464
    .line 2465
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2466
    .line 2467
    .line 2468
    move-result v4

    .line 2469
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2470
    .line 2471
    .line 2472
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2473
    .line 2474
    .line 2475
    move-result v4

    .line 2476
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2477
    .line 2478
    .line 2479
    move-object/from16 v39, v3

    .line 2480
    .line 2481
    move/from16 v49, v5

    .line 2482
    .line 2483
    move/from16 v56, v9

    .line 2484
    .line 2485
    move-object/from16 v59, v12

    .line 2486
    .line 2487
    move/from16 v62, v15

    .line 2488
    .line 2489
    :goto_9b8
    move/from16 v5, v55

    .line 2490
    .line 2491
    :goto_9ba
    const/4 v3, -0x1

    .line 2492
    const/4 v4, 0x4

    .line 2493
    const/16 v9, 0x8

    .line 2494
    .line 2495
    const/16 v11, 0xff

    .line 2496
    .line 2497
    const/4 v12, 0x0

    .line 2498
    const/4 v15, 0x1

    .line 2499
    goto/16 :goto_c91

    .line 2500
    .line 2501
    :cond_9c4
    const v3, 0x6d646376

    .line 2502
    .line 2503
    .line 2504
    if-ne v13, v3, :cond_a3b

    .line 2505
    .line 2506
    if-nez v39, :cond_9d5

    .line 2507
    .line 2508
    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 2509
    .line 2510
    .line 2511
    move-result-object v3

    .line 2512
    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 2513
    .line 2514
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 2515
    .line 2516
    .line 2517
    move-result-object v39

    .line 2518
    :cond_9d5
    move-object/from16 v3, v39

    .line 2519
    .line 2520
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2521
    .line 2522
    .line 2523
    move-result v4

    .line 2524
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2525
    .line 2526
    .line 2527
    move-result v6

    .line 2528
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2529
    .line 2530
    .line 2531
    move-result v11

    .line 2532
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2533
    .line 2534
    .line 2535
    move-result v13

    .line 2536
    move/from16 v49, v5

    .line 2537
    .line 2538
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2539
    .line 2540
    .line 2541
    move-result v5

    .line 2542
    move-object/from16 v50, v7

    .line 2543
    .line 2544
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2545
    .line 2546
    .line 2547
    move-result v7

    .line 2548
    move/from16 v56, v9

    .line 2549
    .line 2550
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2551
    .line 2552
    .line 2553
    move-result v9

    .line 2554
    move-object/from16 v59, v12

    .line 2555
    .line 2556
    invoke-virtual {v0}, Ln3/x;->x()S

    .line 2557
    .line 2558
    .line 2559
    move-result v12

    .line 2560
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 2561
    .line 2562
    .line 2563
    move-result-wide v51

    .line 2564
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 2565
    .line 2566
    .line 2567
    move-result-wide v60

    .line 2568
    move/from16 v62, v15

    .line 2569
    .line 2570
    const/4 v15, 0x1

    .line 2571
    invoke-virtual {v3, v15}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 2572
    .line 2573
    .line 2574
    invoke-virtual {v3, v5}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2575
    .line 2576
    .line 2577
    invoke-virtual {v3, v7}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2578
    .line 2579
    .line 2580
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2581
    .line 2582
    .line 2583
    invoke-virtual {v3, v6}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2584
    .line 2585
    .line 2586
    invoke-virtual {v3, v11}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2587
    .line 2588
    .line 2589
    invoke-virtual {v3, v13}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2590
    .line 2591
    .line 2592
    invoke-virtual {v3, v9}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2593
    .line 2594
    .line 2595
    invoke-virtual {v3, v12}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2596
    .line 2597
    .line 2598
    const-wide/16 v4, 0x2710

    .line 2599
    .line 2600
    div-long v6, v51, v4

    .line 2601
    .line 2602
    long-to-int v6, v6

    .line 2603
    int-to-short v6, v6

    .line 2604
    invoke-virtual {v3, v6}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2605
    .line 2606
    .line 2607
    div-long v4, v60, v4

    .line 2608
    .line 2609
    long-to-int v4, v4

    .line 2610
    int-to-short v4, v4

    .line 2611
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 2612
    .line 2613
    .line 2614
    move-object/from16 v39, v3

    .line 2615
    .line 2616
    :goto_a37
    move-object/from16 v7, v50

    .line 2617
    .line 2618
    goto/16 :goto_9b8

    .line 2619
    .line 2620
    :cond_a3b
    move/from16 v49, v5

    .line 2621
    .line 2622
    move-object/from16 v50, v7

    .line 2623
    .line 2624
    move/from16 v56, v9

    .line 2625
    .line 2626
    move-object/from16 v59, v12

    .line 2627
    .line 2628
    move/from16 v62, v15

    .line 2629
    .line 2630
    const v3, 0x64323633

    .line 2631
    .line 2632
    .line 2633
    if-ne v13, v3, :cond_a58

    .line 2634
    .line 2635
    if-nez v50, :cond_a4f

    .line 2636
    .line 2637
    const/4 v3, 0x1

    .line 2638
    :goto_a4d
    const/4 v5, 0x0

    .line 2639
    goto :goto_a51

    .line 2640
    :cond_a4f
    const/4 v3, 0x0

    .line 2641
    goto :goto_a4d

    .line 2642
    :goto_a51
    invoke-static {v5, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 2643
    .line 2644
    .line 2645
    move-object/from16 v7, v31

    .line 2646
    .line 2647
    goto/16 :goto_9b8

    .line 2648
    .line 2649
    :cond_a58
    const/4 v5, 0x0

    .line 2650
    const v6, 0x65736473

    .line 2651
    .line 2652
    .line 2653
    if-ne v13, v6, :cond_a7b

    .line 2654
    .line 2655
    if-nez v50, :cond_a62

    .line 2656
    .line 2657
    const/4 v3, 0x1

    .line 2658
    goto :goto_a63

    .line 2659
    :cond_a62
    const/4 v3, 0x0

    .line 2660
    :goto_a63
    invoke-static {v5, v3}, Lo4/a;->b(Ljava/lang/String;Z)V

    .line 2661
    .line 2662
    .line 2663
    move/from16 v3, v47

    .line 2664
    .line 2665
    invoke-static {v3, v0}, Li5/e;->c(ILn3/x;)Lds/d;

    .line 2666
    .line 2667
    .line 2668
    move-result-object v3

    .line 2669
    iget-object v4, v3, Lds/d;->a:Ljava/lang/String;

    .line 2670
    .line 2671
    iget-object v7, v3, Lds/d;->b:[B

    .line 2672
    .line 2673
    if-eqz v7, :cond_a76

    .line 2674
    .line 2675
    invoke-static {v7}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 2676
    .line 2677
    .line 2678
    move-result-object v14

    .line 2679
    :cond_a76
    move-object/from16 v45, v3

    .line 2680
    .line 2681
    move-object v7, v4

    .line 2682
    goto/16 :goto_9b8

    .line 2683
    .line 2684
    :cond_a7b
    move/from16 v3, v47

    .line 2685
    .line 2686
    const v7, 0x62747274

    .line 2687
    .line 2688
    .line 2689
    if-ne v13, v7, :cond_a9b

    .line 2690
    .line 2691
    add-int/lit8 v13, v3, 0x8

    .line 2692
    .line 2693
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 2694
    .line 2695
    .line 2696
    const/4 v11, 0x4

    .line 2697
    invoke-virtual {v0, v11}, Ln3/x;->O(I)V

    .line 2698
    .line 2699
    .line 2700
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 2701
    .line 2702
    .line 2703
    move-result-wide v3

    .line 2704
    invoke-virtual {v0}, Ln3/x;->C()J

    .line 2705
    .line 2706
    .line 2707
    move-result-wide v11

    .line 2708
    new-instance v7, Lbl/h;

    .line 2709
    .line 2710
    invoke-direct {v7, v11, v12, v3, v4}, Lbl/h;-><init>(JJ)V

    .line 2711
    .line 2712
    .line 2713
    move-object/from16 v44, v7

    .line 2714
    .line 2715
    goto :goto_a37

    .line 2716
    :cond_a9b
    const v7, 0x70617370

    .line 2717
    .line 2718
    .line 2719
    if-ne v13, v7, :cond_ac2

    .line 2720
    .line 2721
    add-int/lit8 v13, v3, 0x8

    .line 2722
    .line 2723
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 2724
    .line 2725
    .line 2726
    invoke-virtual {v0}, Ln3/x;->E()I

    .line 2727
    .line 2728
    .line 2729
    move-result v3

    .line 2730
    invoke-virtual {v0}, Ln3/x;->E()I

    .line 2731
    .line 2732
    .line 2733
    move-result v4

    .line 2734
    int-to-float v3, v3

    .line 2735
    int-to-float v4, v4

    .line 2736
    div-float/2addr v3, v4

    .line 2737
    move/from16 v37, v3

    .line 2738
    .line 2739
    move-object/from16 v7, v50

    .line 2740
    .line 2741
    move/from16 v5, v55

    .line 2742
    .line 2743
    const/4 v3, -0x1

    .line 2744
    const/4 v4, 0x4

    .line 2745
    const/16 v9, 0x8

    .line 2746
    .line 2747
    const/16 v11, 0xff

    .line 2748
    .line 2749
    const/4 v12, 0x0

    .line 2750
    const/4 v15, 0x1

    .line 2751
    const/16 v26, 0x1

    .line 2752
    .line 2753
    goto/16 :goto_c91

    .line 2754
    .line 2755
    :cond_ac2
    const v7, 0x73763364

    .line 2756
    .line 2757
    .line 2758
    if-ne v13, v7, :cond_aec

    .line 2759
    .line 2760
    add-int/lit8 v13, v3, 0x8

    .line 2761
    .line 2762
    :goto_ac9
    sub-int v4, v13, v3

    .line 2763
    .line 2764
    if-ge v4, v1, :cond_ae7

    .line 2765
    .line 2766
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 2767
    .line 2768
    .line 2769
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 2770
    .line 2771
    .line 2772
    move-result v4

    .line 2773
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 2774
    .line 2775
    .line 2776
    move-result v7

    .line 2777
    const v9, 0x70726f6a

    .line 2778
    .line 2779
    .line 2780
    if-ne v7, v9, :cond_ae5

    .line 2781
    .line 2782
    iget-object v3, v0, Ln3/x;->a:[B

    .line 2783
    .line 2784
    add-int/2addr v4, v13

    .line 2785
    invoke-static {v3, v13, v4}, Ljava/util/Arrays;->copyOfRange([BII)[B

    .line 2786
    .line 2787
    .line 2788
    move-result-object v3

    .line 2789
    goto :goto_ae8

    .line 2790
    :cond_ae5
    add-int/2addr v13, v4

    .line 2791
    goto :goto_ac9

    .line 2792
    :cond_ae7
    move-object v3, v5

    .line 2793
    :goto_ae8
    move-object/from16 v36, v3

    .line 2794
    .line 2795
    goto/16 :goto_a37

    .line 2796
    .line 2797
    :cond_aec
    const v7, 0x73743364

    .line 2798
    .line 2799
    .line 2800
    if-ne v13, v7, :cond_b21

    .line 2801
    .line 2802
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2803
    .line 2804
    .line 2805
    move-result v3

    .line 2806
    move/from16 v7, v17

    .line 2807
    .line 2808
    invoke-virtual {v0, v7}, Ln3/x;->O(I)V

    .line 2809
    .line 2810
    .line 2811
    if-nez v3, :cond_b17

    .line 2812
    .line 2813
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 2814
    .line 2815
    .line 2816
    move-result v3

    .line 2817
    if-eqz v3, :cond_b14

    .line 2818
    .line 2819
    const/4 v13, 0x1

    .line 2820
    if-eq v3, v13, :cond_b11

    .line 2821
    .line 2822
    const/4 v4, 0x2

    .line 2823
    if-eq v3, v4, :cond_b0e

    .line 2824
    .line 2825
    if-eq v3, v7, :cond_b0b

    .line 2826
    .line 2827
    goto :goto_b17

    .line 2828
    :cond_b0b
    move/from16 v57, v7

    .line 2829
    .line 2830
    goto :goto_b19

    .line 2831
    :cond_b0e
    const/16 v57, 0x2

    .line 2832
    .line 2833
    goto :goto_b19

    .line 2834
    :cond_b11
    const/16 v57, 0x1

    .line 2835
    .line 2836
    goto :goto_b19

    .line 2837
    :cond_b14
    const/16 v57, 0x0

    .line 2838
    .line 2839
    goto :goto_b19

    .line 2840
    :cond_b17
    :goto_b17
    move/from16 v57, v2

    .line 2841
    .line 2842
    :goto_b19
    move-object/from16 v7, v50

    .line 2843
    .line 2844
    move/from16 v5, v55

    .line 2845
    .line 2846
    move/from16 v2, v57

    .line 2847
    .line 2848
    goto/16 :goto_9ba

    .line 2849
    .line 2850
    :cond_b21
    move/from16 v7, v17

    .line 2851
    .line 2852
    const v9, 0x61707643

    .line 2853
    .line 2854
    .line 2855
    if-ne v13, v9, :cond_c21

    .line 2856
    .line 2857
    add-int/lit8 v9, v1, -0xc

    .line 2858
    .line 2859
    new-array v10, v9, [B

    .line 2860
    .line 2861
    add-int/lit8 v13, v3, 0xc

    .line 2862
    .line 2863
    invoke-virtual {v0, v13}, Ln3/x;->N(I)V

    .line 2864
    .line 2865
    .line 2866
    const/4 v3, 0x0

    .line 2867
    invoke-virtual {v0, v10, v3, v9}, Ln3/x;->k([BII)V

    .line 2868
    .line 2869
    .line 2870
    sget-object v11, Ln3/g;->a:[B

    .line 2871
    .line 2872
    const/16 v11, 0x11

    .line 2873
    .line 2874
    if-lt v9, v11, :cond_b3d

    .line 2875
    .line 2876
    const/4 v11, 0x1

    .line 2877
    goto :goto_b3e

    .line 2878
    :cond_b3d
    move v11, v3

    .line 2879
    :goto_b3e
    const-string v12, "Invalid APV CSD length: %s"

    .line 2880
    .line 2881
    invoke-static {v12, v9, v11}, Loq/a;->l(Ljava/lang/String;IZ)V

    .line 2882
    .line 2883
    .line 2884
    aget-byte v11, v10, v3

    .line 2885
    .line 2886
    const/4 v13, 0x1

    .line 2887
    if-ne v11, v13, :cond_b4a

    .line 2888
    .line 2889
    const/4 v3, 0x1

    .line 2890
    goto :goto_b4b

    .line 2891
    :cond_b4a
    const/4 v3, 0x0

    .line 2892
    :goto_b4b
    const-string v12, "Invalid APV CSD version: %s"

    .line 2893
    .line 2894
    invoke-static {v12, v11, v3}, Loq/a;->l(Ljava/lang/String;IZ)V

    .line 2895
    .line 2896
    .line 2897
    aget-byte v3, v10, v51

    .line 2898
    .line 2899
    const/16 v11, 0xff

    .line 2900
    .line 2901
    and-int/2addr v3, v11

    .line 2902
    const/16 v53, 0x6

    .line 2903
    .line 2904
    aget-byte v12, v10, v53

    .line 2905
    .line 2906
    and-int/2addr v12, v11

    .line 2907
    aget-byte v13, v10, v52

    .line 2908
    .line 2909
    and-int/2addr v13, v11

    .line 2910
    sget-object v14, Ln3/l0;->a:Ljava/lang/String;

    .line 2911
    .line 2912
    sget-object v14, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 2913
    .line 2914
    const-string v14, ".apvl"

    .line 2915
    .line 2916
    const-string v15, ".apvb"

    .line 2917
    .line 2918
    const-string v5, "apv1.apvf"

    .line 2919
    .line 2920
    invoke-static {v3, v5, v12, v14, v15}, La1/h;->m(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2921
    .line 2922
    .line 2923
    move-result-object v3

    .line 2924
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2925
    .line 2926
    .line 2927
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2928
    .line 2929
    .line 2930
    move-result-object v32

    .line 2931
    invoke-static {v10}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 2932
    .line 2933
    .line 2934
    move-result-object v14

    .line 2935
    new-instance v3, Ln3/x;

    .line 2936
    .line 2937
    invoke-direct {v3, v10}, Ln3/x;-><init>([B)V

    .line 2938
    .line 2939
    .line 2940
    new-instance v5, Lct/f;

    .line 2941
    .line 2942
    const/4 v12, 0x0

    .line 2943
    const/4 v13, 0x2

    .line 2944
    invoke-direct {v5, v10, v9, v13, v12}, Lct/f;-><init>([BIIB)V

    .line 2945
    .line 2946
    .line 2947
    iget v3, v3, Ln3/x;->b:I

    .line 2948
    .line 2949
    const/16 v9, 0x8

    .line 2950
    .line 2951
    mul-int/2addr v3, v9

    .line 2952
    invoke-virtual {v5, v3}, Lct/f;->r(I)V

    .line 2953
    .line 2954
    .line 2955
    const/4 v15, 0x1

    .line 2956
    invoke-virtual {v5, v15}, Lct/f;->v(I)V

    .line 2957
    .line 2958
    .line 2959
    invoke-virtual {v5, v9}, Lct/f;->i(I)I

    .line 2960
    .line 2961
    .line 2962
    move-result v3

    .line 2963
    move v13, v12

    .line 2964
    const/4 v10, -0x1

    .line 2965
    const/16 v17, -0x1

    .line 2966
    .line 2967
    const/16 v18, -0x1

    .line 2968
    .line 2969
    const/16 v19, -0x1

    .line 2970
    .line 2971
    const/16 v21, -0x1

    .line 2972
    .line 2973
    :goto_b9c
    if-ge v13, v3, :cond_c10

    .line 2974
    .line 2975
    invoke-virtual {v5, v15}, Lct/f;->v(I)V

    .line 2976
    .line 2977
    .line 2978
    invoke-virtual {v5, v9}, Lct/f;->i(I)I

    .line 2979
    .line 2980
    .line 2981
    move-result v6

    .line 2982
    move/from16 v24, v21

    .line 2983
    .line 2984
    move/from16 v21, v19

    .line 2985
    .line 2986
    move/from16 v19, v18

    .line 2987
    .line 2988
    move/from16 v18, v17

    .line 2989
    .line 2990
    move/from16 v17, v10

    .line 2991
    .line 2992
    move v10, v12

    .line 2993
    :goto_bb0
    if-ge v10, v6, :cond_bfb

    .line 2994
    .line 2995
    const/4 v7, 0x6

    .line 2996
    invoke-virtual {v5, v7}, Lct/f;->u(I)V

    .line 2997
    .line 2998
    .line 2999
    invoke-virtual {v5}, Lct/f;->h()Z

    .line 3000
    .line 3001
    .line 3002
    move-result v18

    .line 3003
    invoke-virtual {v5}, Lct/f;->t()V

    .line 3004
    .line 3005
    .line 3006
    invoke-virtual {v5, v4}, Lct/f;->v(I)V

    .line 3007
    .line 3008
    .line 3009
    const/4 v4, 0x4

    .line 3010
    invoke-virtual {v5, v4}, Lct/f;->u(I)V

    .line 3011
    .line 3012
    .line 3013
    invoke-virtual {v5, v4}, Lct/f;->i(I)I

    .line 3014
    .line 3015
    .line 3016
    move-result v22

    .line 3017
    add-int/lit8 v24, v22, 0x8

    .line 3018
    .line 3019
    invoke-virtual {v5, v15}, Lct/f;->v(I)V

    .line 3020
    .line 3021
    .line 3022
    if-eqz v18, :cond_bf3

    .line 3023
    .line 3024
    invoke-virtual {v5, v9}, Lct/f;->i(I)I

    .line 3025
    .line 3026
    .line 3027
    move-result v17

    .line 3028
    invoke-virtual {v5, v9}, Lct/f;->i(I)I

    .line 3029
    .line 3030
    .line 3031
    move-result v18

    .line 3032
    invoke-virtual {v5, v15}, Lct/f;->v(I)V

    .line 3033
    .line 3034
    .line 3035
    invoke-virtual {v5}, Lct/f;->h()Z

    .line 3036
    .line 3037
    .line 3038
    move-result v19

    .line 3039
    invoke-static/range {v17 .. v17}, Lk3/m;->f(I)I

    .line 3040
    .line 3041
    .line 3042
    move-result v17

    .line 3043
    if-eqz v19, :cond_be7

    .line 3044
    .line 3045
    move/from16 v19, v15

    .line 3046
    .line 3047
    goto :goto_be9

    .line 3048
    :cond_be7
    const/16 v19, 0x2

    .line 3049
    .line 3050
    :goto_be9
    invoke-static/range {v18 .. v18}, Lk3/m;->g(I)I

    .line 3051
    .line 3052
    .line 3053
    move-result v18

    .line 3054
    move/from16 v21, v19

    .line 3055
    .line 3056
    move/from16 v19, v17

    .line 3057
    .line 3058
    move/from16 v17, v18

    .line 3059
    .line 3060
    :cond_bf3
    add-int/lit8 v10, v10, 0x1

    .line 3061
    .line 3062
    move/from16 v18, v24

    .line 3063
    .line 3064
    const/16 v4, 0xb

    .line 3065
    .line 3066
    const/4 v7, 0x3

    .line 3067
    goto :goto_bb0

    .line 3068
    :cond_bfb
    const/4 v4, 0x4

    .line 3069
    const/4 v7, 0x6

    .line 3070
    add-int/lit8 v13, v13, 0x1

    .line 3071
    .line 3072
    move/from16 v10, v17

    .line 3073
    .line 3074
    move/from16 v17, v18

    .line 3075
    .line 3076
    move/from16 v18, v19

    .line 3077
    .line 3078
    move/from16 v19, v21

    .line 3079
    .line 3080
    move/from16 v21, v24

    .line 3081
    .line 3082
    const/16 v4, 0xb

    .line 3083
    .line 3084
    const v6, 0x65736473

    .line 3085
    .line 3086
    .line 3087
    const/4 v7, 0x3

    .line 3088
    goto :goto_b9c

    .line 3089
    :cond_c10
    const/4 v4, 0x4

    .line 3090
    new-instance v3, Lk3/m;

    .line 3091
    .line 3092
    const-string v3, "video/apv"

    .line 3093
    .line 3094
    move-object v7, v3

    .line 3095
    move v5, v10

    .line 3096
    move/from16 v56, v17

    .line 3097
    .line 3098
    move/from16 v10, v18

    .line 3099
    .line 3100
    move/from16 v54, v19

    .line 3101
    .line 3102
    move/from16 v62, v21

    .line 3103
    .line 3104
    goto/16 :goto_536

    .line 3105
    .line 3106
    :cond_c21
    const/4 v4, 0x4

    .line 3107
    const/16 v9, 0x8

    .line 3108
    .line 3109
    const/16 v11, 0xff

    .line 3110
    .line 3111
    const/4 v12, 0x0

    .line 3112
    const/4 v15, 0x1

    .line 3113
    const v3, 0x636f6c72

    .line 3114
    .line 3115
    .line 3116
    if-ne v13, v3, :cond_c86

    .line 3117
    .line 3118
    const/4 v3, -0x1

    .line 3119
    move/from16 v5, v55

    .line 3120
    .line 3121
    if-ne v10, v3, :cond_c83

    .line 3122
    .line 3123
    if-ne v5, v3, :cond_c83

    .line 3124
    .line 3125
    invoke-virtual {v0}, Ln3/x;->m()I

    .line 3126
    .line 3127
    .line 3128
    move-result v6

    .line 3129
    const v7, 0x6e636c78

    .line 3130
    .line 3131
    .line 3132
    if-eq v6, v7, :cond_c5b

    .line 3133
    .line 3134
    const v7, 0x6e636c63

    .line 3135
    .line 3136
    .line 3137
    if-ne v6, v7, :cond_c43

    .line 3138
    .line 3139
    goto :goto_c5b

    .line 3140
    :cond_c43
    new-instance v7, Ljava/lang/StringBuilder;

    .line 3141
    .line 3142
    const-string v13, "Unsupported color type: "

    .line 3143
    .line 3144
    invoke-direct {v7, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3145
    .line 3146
    .line 3147
    invoke-static {v6}, Lcz/j;->f(I)Ljava/lang/String;

    .line 3148
    .line 3149
    .line 3150
    move-result-object v6

    .line 3151
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3152
    .line 3153
    .line 3154
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3155
    .line 3156
    .line 3157
    move-result-object v6

    .line 3158
    const-string v7, "BoxParsers"

    .line 3159
    .line 3160
    invoke-static {v7, v6}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 3161
    .line 3162
    .line 3163
    goto :goto_c83

    .line 3164
    :cond_c5b
    :goto_c5b
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 3165
    .line 3166
    .line 3167
    move-result v5

    .line 3168
    invoke-virtual {v0}, Ln3/x;->H()I

    .line 3169
    .line 3170
    .line 3171
    move-result v6

    .line 3172
    const/4 v13, 0x2

    .line 3173
    invoke-virtual {v0, v13}, Ln3/x;->O(I)V

    .line 3174
    .line 3175
    .line 3176
    const/16 v7, 0x13

    .line 3177
    .line 3178
    if-ne v1, v7, :cond_c75

    .line 3179
    .line 3180
    invoke-virtual {v0}, Ln3/x;->A()I

    .line 3181
    .line 3182
    .line 3183
    move-result v7

    .line 3184
    and-int/lit16 v7, v7, 0x80

    .line 3185
    .line 3186
    if-eqz v7, :cond_c75

    .line 3187
    .line 3188
    move v7, v15

    .line 3189
    goto :goto_c76

    .line 3190
    :cond_c75
    move v7, v12

    .line 3191
    :goto_c76
    invoke-static {v5}, Lk3/m;->f(I)I

    .line 3192
    .line 3193
    .line 3194
    move-result v10

    .line 3195
    if-eqz v7, :cond_c7d

    .line 3196
    .line 3197
    move v13, v15

    .line 3198
    :cond_c7d
    invoke-static {v6}, Lk3/m;->g(I)I

    .line 3199
    .line 3200
    .line 3201
    move-result v5

    .line 3202
    move/from16 v54, v13

    .line 3203
    .line 3204
    :cond_c83
    :goto_c83
    move-object/from16 v7, v50

    .line 3205
    .line 3206
    goto :goto_c91

    .line 3207
    :cond_c86
    move/from16 v5, v55

    .line 3208
    .line 3209
    const/4 v3, -0x1

    .line 3210
    goto :goto_c83

    .line 3211
    :goto_c8a
    invoke-static {v0}, Lgx/l;->b(Ln3/x;)Lgx/l;

    .line 3212
    .line 3213
    .line 3214
    move-result-object v13

    .line 3215
    move-object/from16 v43, v13

    .line 3216
    .line 3217
    goto :goto_c83

    .line 3218
    :goto_c91
    add-int v1, v46, v1

    .line 3219
    .line 3220
    move/from16 v18, v9

    .line 3221
    .line 3222
    move/from16 v3, v48

    .line 3223
    .line 3224
    move/from16 v4, v49

    .line 3225
    .line 3226
    move/from16 v11, v54

    .line 3227
    .line 3228
    move/from16 v9, v56

    .line 3229
    .line 3230
    move-object/from16 v6, v58

    .line 3231
    .line 3232
    move-object/from16 v12, v59

    .line 3233
    .line 3234
    move/from16 v15, v62

    .line 3235
    .line 3236
    const/16 v17, 0x3

    .line 3237
    .line 3238
    goto/16 :goto_439

    .line 3239
    .line 3240
    :goto_ca7
    if-eqz v43, :cond_cb0

    .line 3241
    .line 3242
    move-object/from16 v1, v43

    .line 3243
    .line 3244
    iget-object v1, v1, Lgx/l;->a:Ljava/lang/String;

    .line 3245
    .line 3246
    const-string v7, "video/dolby-vision"

    .line 3247
    .line 3248
    goto :goto_cb4

    .line 3249
    :cond_cb0
    move-object/from16 v1, v32

    .line 3250
    .line 3251
    move-object/from16 v7, v50

    .line 3252
    .line 3253
    :goto_cb4
    if-nez v7, :cond_cba

    .line 3254
    .line 3255
    move-object/from16 v1, p1

    .line 3256
    .line 3257
    goto/16 :goto_392

    .line 3258
    .line 3259
    :cond_cba
    new-instance v3, Lk3/v;

    .line 3260
    .line 3261
    invoke-direct {v3}, Lk3/v;-><init>()V

    .line 3262
    .line 3263
    .line 3264
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 3265
    .line 3266
    .line 3267
    move-result-object v4

    .line 3268
    iput-object v4, v3, Lk3/v;->a:Ljava/lang/String;

    .line 3269
    .line 3270
    invoke-static {v7}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 3271
    .line 3272
    .line 3273
    move-result-object v4

    .line 3274
    iput-object v4, v3, Lk3/v;->o:Ljava/lang/String;

    .line 3275
    .line 3276
    iput-object v1, v3, Lk3/v;->k:Ljava/lang/String;

    .line 3277
    .line 3278
    move/from16 v1, v42

    .line 3279
    .line 3280
    iput v1, v3, Lk3/v;->v:I

    .line 3281
    .line 3282
    move/from16 v1, v41

    .line 3283
    .line 3284
    iput v1, v3, Lk3/v;->w:I

    .line 3285
    .line 3286
    move/from16 v1, v40

    .line 3287
    .line 3288
    iput v1, v3, Lk3/v;->y:I

    .line 3289
    .line 3290
    move/from16 v1, v38

    .line 3291
    .line 3292
    iput v1, v3, Lk3/v;->z:I

    .line 3293
    .line 3294
    move/from16 v1, v37

    .line 3295
    .line 3296
    iput v1, v3, Lk3/v;->D:F

    .line 3297
    .line 3298
    move-object/from16 v1, p1

    .line 3299
    .line 3300
    iget v4, v1, Li5/d;->c:I

    .line 3301
    .line 3302
    iput v4, v3, Lk3/v;->B:I

    .line 3303
    .line 3304
    iget-boolean v4, v1, Li5/d;->d:Z

    .line 3305
    .line 3306
    iput-boolean v4, v3, Lk3/v;->C:Z

    .line 3307
    .line 3308
    move-object/from16 v4, v36

    .line 3309
    .line 3310
    iput-object v4, v3, Lk3/v;->E:[B

    .line 3311
    .line 3312
    iput v2, v3, Lk3/v;->F:I

    .line 3313
    .line 3314
    iput-object v14, v3, Lk3/v;->r:Ljava/util/List;

    .line 3315
    .line 3316
    move/from16 v2, v35

    .line 3317
    .line 3318
    iput v2, v3, Lk3/v;->q:I

    .line 3319
    .line 3320
    move/from16 v2, v34

    .line 3321
    .line 3322
    iput v2, v3, Lk3/v;->H:I

    .line 3323
    .line 3324
    move-object/from16 v7, v33

    .line 3325
    .line 3326
    iput-object v7, v3, Lk3/v;->s:Lk3/r;

    .line 3327
    .line 3328
    move-object/from16 v2, p2

    .line 3329
    .line 3330
    iput-object v2, v3, Lk3/v;->d:Ljava/lang/String;

    .line 3331
    .line 3332
    if-eqz v39, :cond_d0c

    .line 3333
    .line 3334
    invoke-virtual/range {v39 .. v39}, Ljava/nio/ByteBuffer;->array()[B

    .line 3335
    .line 3336
    .line 3337
    move-result-object v15

    .line 3338
    move-object/from16 v41, v15

    .line 3339
    .line 3340
    goto :goto_d0e

    .line 3341
    :cond_d0c
    const/16 v41, 0x0

    .line 3342
    .line 3343
    :goto_d0e
    new-instance v37, Lk3/m;

    .line 3344
    .line 3345
    move/from16 v40, v5

    .line 3346
    .line 3347
    move/from16 v38, v10

    .line 3348
    .line 3349
    move/from16 v39, v54

    .line 3350
    .line 3351
    move/from16 v42, v56

    .line 3352
    .line 3353
    move/from16 v43, v62

    .line 3354
    .line 3355
    invoke-direct/range {v37 .. v43}, Lk3/m;-><init>(III[BII)V

    .line 3356
    .line 3357
    .line 3358
    move-object/from16 v4, v37

    .line 3359
    .line 3360
    iput-object v4, v3, Lk3/v;->G:Lk3/m;

    .line 3361
    .line 3362
    move-object/from16 v4, v44

    .line 3363
    .line 3364
    if-eqz v4, :cond_d36

    .line 3365
    .line 3366
    iget-wide v5, v4, Lbl/h;->a:J

    .line 3367
    .line 3368
    invoke-static {v5, v6}, Lc7/t;->M(J)I

    .line 3369
    .line 3370
    .line 3371
    move-result v5

    .line 3372
    iput v5, v3, Lk3/v;->i:I

    .line 3373
    .line 3374
    iget-wide v4, v4, Lbl/h;->b:J

    .line 3375
    .line 3376
    invoke-static {v4, v5}, Lc7/t;->M(J)I

    .line 3377
    .line 3378
    .line 3379
    move-result v4

    .line 3380
    iput v4, v3, Lk3/v;->j:I

    .line 3381
    .line 3382
    goto :goto_d4a

    .line 3383
    :cond_d36
    move-object/from16 v4, v45

    .line 3384
    .line 3385
    if-eqz v4, :cond_d4a

    .line 3386
    .line 3387
    iget-wide v5, v4, Lds/d;->c:J

    .line 3388
    .line 3389
    invoke-static {v5, v6}, Lc7/t;->M(J)I

    .line 3390
    .line 3391
    .line 3392
    move-result v5

    .line 3393
    iput v5, v3, Lk3/v;->i:I

    .line 3394
    .line 3395
    iget-wide v4, v4, Lds/d;->d:J

    .line 3396
    .line 3397
    invoke-static {v4, v5}, Lc7/t;->M(J)I

    .line 3398
    .line 3399
    .line 3400
    move-result v4

    .line 3401
    iput v4, v3, Lk3/v;->j:I

    .line 3402
    .line 3403
    :cond_d4a
    :goto_d4a
    new-instance v4, Lk3/w;

    .line 3404
    .line 3405
    invoke-direct {v4, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 3406
    .line 3407
    .line 3408
    iput-object v4, v8, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    .line 3409
    .line 3410
    :goto_d51
    add-int v3, v28, v48

    .line 3411
    .line 3412
    invoke-virtual {v0, v3}, Ln3/x;->N(I)V

    .line 3413
    .line 3414
    .line 3415
    add-int/lit8 v9, v27, 0x1

    .line 3416
    .line 3417
    move-object v10, v1

    .line 3418
    move-object v5, v2

    .line 3419
    move v14, v12

    .line 3420
    move/from16 v12, v16

    .line 3421
    .line 3422
    move/from16 v11, v29

    .line 3423
    .line 3424
    move/from16 v13, v30

    .line 3425
    .line 3426
    goto/16 :goto_1e

    .line 3427
    .line 3428
    :cond_d63
    return-object v8
.end method

.method public static j(Lo3/c;Lo4/w;JLk3/r;ZZLgx/k;Z)Ljava/util/ArrayList;
    .registers 67

    move-object/from16 v0, p0

    .line 1
    iget-object v2, v0, Lo3/c;->w:Ljava/util/ArrayList;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    .line 2
    :goto_a
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v5, v6, :cond_bcb

    .line 3
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lo3/c;

    .line 4
    iget v7, v6, Lcz/j;->e:I

    const v8, 0x7472616b

    if-eq v7, v8, :cond_26

    move-object/from16 v34, v2

    move-object v9, v3

    move/from16 v21, v5

    const/16 v16, 0x0

    goto/16 :goto_bba

    :cond_26
    const v7, 0x6d766864

    .line 5
    invoke-virtual {v0, v7}, Lo3/c;->p(I)Lo3/d;

    move-result-object v7

    .line 6
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v8, 0x6d646961

    .line 7
    invoke-virtual {v6, v8}, Lo3/c;->o(I)Lo3/c;

    move-result-object v9

    .line 8
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v10, 0x68646c72    # 4.3148E24f

    .line 9
    invoke-virtual {v9, v10}, Lo3/c;->p(I)Lo3/d;

    move-result-object v10

    .line 10
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    iget-object v10, v10, Lo3/d;->i:Ln3/x;

    const/16 v11, 0x10

    .line 12
    invoke-virtual {v10, v11}, Ln3/x;->N(I)V

    .line 13
    invoke-virtual {v10}, Ln3/x;->m()I

    move-result v10

    const v12, 0x736f756e

    const/4 v14, -0x1

    const/16 v16, 0x0

    if-ne v10, v12, :cond_59

    const/4 v10, 0x1

    goto :goto_84

    :cond_59
    const v12, 0x76696465

    if-ne v10, v12, :cond_60

    const/4 v10, 0x2

    goto :goto_84

    :cond_60
    const v12, 0x74657874

    if-eq v10, v12, :cond_83

    const v12, 0x7362746c

    if-eq v10, v12, :cond_83

    const v12, 0x73756274

    if-eq v10, v12, :cond_83

    const v12, 0x636c6370

    if-eq v10, v12, :cond_83

    const v12, 0x73756270

    if-ne v10, v12, :cond_7a

    goto :goto_83

    :cond_7a
    const v12, 0x6d657461

    if-ne v10, v12, :cond_81

    const/4 v10, 0x5

    goto :goto_84

    :cond_81
    move v10, v14

    goto :goto_84

    :cond_83
    :goto_83
    const/4 v10, 0x3

    .line 14
    :goto_84
    const-string v12, "BoxParsers"

    const/16 v18, 0x1

    const/4 v13, 0x4

    move/from16 v21, v5

    if-ne v10, v14, :cond_9c

    move-object/from16 v1, p7

    move-object/from16 v34, v2

    move-object/from16 v19, v3

    move-object/from16 v27, v6

    move-object/from16 v26, v12

    const/4 v0, 0x0

    const-wide/16 v23, 0x0

    goto/16 :goto_46d

    :cond_9c
    const-wide/16 v23, 0x0

    const v4, 0x746b6864

    .line 15
    invoke-virtual {v6, v4}, Lo3/c;->p(I)Lo3/d;

    move-result-object v4

    .line 16
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    iget-object v4, v4, Lo3/d;->i:Ln3/x;

    const/16 v5, 0x8

    .line 18
    invoke-virtual {v4, v5}, Ln3/x;->N(I)V

    .line 19
    invoke-virtual {v4}, Ln3/x;->m()I

    move-result v25

    .line 20
    invoke-static/range {v25 .. v25}, Li5/e;->e(I)I

    move-result v25

    if-nez v25, :cond_ba

    goto :goto_bb

    :cond_ba
    move v5, v11

    .line 21
    :goto_bb
    invoke-virtual {v4, v5}, Ln3/x;->O(I)V

    .line 22
    invoke-virtual {v4}, Ln3/x;->m()I

    move-result v28

    .line 23
    invoke-virtual {v4, v13}, Ln3/x;->O(I)V

    .line 24
    iget v5, v4, Ln3/x;->b:I

    if-nez v25, :cond_cb

    move v8, v13

    goto :goto_cd

    :cond_cb
    const/16 v8, 0x8

    :goto_cd
    move/from16 v15, v16

    :goto_cf
    const-wide v38, -0x7fffffffffffffffL    # -4.9E-324

    if-ge v15, v8, :cond_f5

    .line 25
    iget-object v11, v4, Ln3/x;->a:[B

    add-int v27, v5, v15

    .line 26
    aget-byte v11, v11, v27

    if-eq v11, v14, :cond_f0

    if-nez v25, :cond_e5

    .line 27
    invoke-virtual {v4}, Ln3/x;->C()J

    move-result-wide v29

    goto :goto_e9

    :cond_e5
    invoke-virtual {v4}, Ln3/x;->G()J

    move-result-wide v29

    :goto_e9
    cmp-long v5, v29, v23

    if-nez v5, :cond_f9

    :goto_ed
    move-wide/from16 v29, v38

    goto :goto_f9

    :cond_f0
    add-int/lit8 v15, v15, 0x1

    const/16 v11, 0x10

    goto :goto_cf

    .line 28
    :cond_f5
    invoke-virtual {v4, v8}, Ln3/x;->O(I)V

    goto :goto_ed

    :cond_f9
    :goto_f9
    const/16 v5, 0xa

    .line 29
    invoke-virtual {v4, v5}, Ln3/x;->O(I)V

    .line 30
    invoke-virtual {v4}, Ln3/x;->H()I

    move-result v31

    .line 31
    invoke-virtual {v4, v13}, Ln3/x;->O(I)V

    .line 32
    invoke-virtual {v4}, Ln3/x;->m()I

    move-result v5

    .line 33
    invoke-virtual {v4}, Ln3/x;->m()I

    move-result v8

    .line 34
    invoke-virtual {v4, v13}, Ln3/x;->O(I)V

    .line 35
    invoke-virtual {v4}, Ln3/x;->m()I

    move-result v11

    .line 36
    invoke-virtual {v4}, Ln3/x;->m()I

    move-result v15

    const/high16 v13, -0x10000

    const/high16 v14, 0x10000

    if-nez v5, :cond_12d

    if-ne v8, v14, :cond_12d

    if-eq v11, v13, :cond_124

    if-ne v11, v14, :cond_12d

    :cond_124
    if-nez v15, :cond_12d

    const/16 v13, 0x5a

    :goto_128
    move/from16 v32, v13

    :goto_12a
    const/16 v13, 0x10

    goto :goto_14a

    :cond_12d
    if-nez v5, :cond_13a

    if-ne v8, v13, :cond_13a

    if-eq v11, v14, :cond_135

    if-ne v11, v13, :cond_13a

    :cond_135
    if-nez v15, :cond_13a

    const/16 v13, 0x10e

    goto :goto_128

    :cond_13a
    if-eq v5, v13, :cond_13e

    if-ne v5, v14, :cond_147

    :cond_13e
    if-nez v8, :cond_147

    if-nez v11, :cond_147

    if-ne v15, v13, :cond_147

    const/16 v13, 0xb4

    goto :goto_128

    :cond_147
    move/from16 v32, v16

    goto :goto_12a

    .line 37
    :goto_14a
    invoke-virtual {v4, v13}, Ln3/x;->O(I)V

    .line 38
    invoke-virtual {v4}, Ln3/x;->x()S

    move-result v34

    const/4 v14, 0x2

    .line 39
    invoke-virtual {v4, v14}, Ln3/x;->O(I)V

    .line 40
    invoke-virtual {v4}, Ln3/x;->x()S

    move-result v35

    int-to-long v4, v5

    int-to-long v14, v15

    mul-long/2addr v4, v14

    int-to-long v14, v8

    move-wide/from16 v42, v14

    int-to-long v13, v11

    mul-long v14, v42, v13

    sub-long/2addr v4, v14

    cmp-long v4, v4, v23

    if-gez v4, :cond_16a

    move/from16 v33, v18

    goto :goto_16c

    :cond_16a
    move/from16 v33, v16

    .line 41
    :goto_16c
    new-instance v27, Li5/d;

    invoke-direct/range {v27 .. v35}, Li5/d;-><init>(IJIIZII)V

    move-object/from16 v4, v27

    cmp-long v5, p2, v38

    if-nez v5, :cond_17a

    move-wide/from16 v42, v29

    goto :goto_17c

    :cond_17a
    move-wide/from16 v42, p2

    .line 42
    :goto_17c
    iget-object v5, v7, Lo3/d;->i:Ln3/x;

    invoke-static {v5}, Li5/e;->g(Ln3/x;)Lo3/f;

    move-result-object v5

    iget-wide v7, v5, Lo3/f;->c:J

    cmp-long v5, v42, v38

    if-nez v5, :cond_18f

    move-wide v13, v7

    move-wide/from16 v7, v38

    :goto_18b
    const v5, 0x6d696e66

    goto :goto_19f

    .line 43
    :cond_18f
    sget-object v5, Ln3/l0;->a:Ljava/lang/String;

    .line 44
    sget-object v48, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v44, 0xf4240

    move-wide/from16 v46, v7

    invoke-static/range {v42 .. v48}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v7

    move-wide/from16 v13, v46

    goto :goto_18b

    .line 45
    :goto_19f
    invoke-virtual {v9, v5}, Lo3/c;->o(I)Lo3/c;

    move-result-object v11

    .line 46
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v5, 0x7374626c

    .line 47
    invoke-virtual {v11, v5}, Lo3/c;->o(I)Lo3/c;

    move-result-object v11

    .line 48
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v5, 0x6d646864

    .line 49
    invoke-virtual {v9, v5}, Lo3/c;->p(I)Lo3/d;

    move-result-object v5

    .line 50
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    iget-object v5, v5, Lo3/d;->i:Ln3/x;

    const/16 v9, 0x8

    .line 52
    invoke-virtual {v5, v9}, Ln3/x;->N(I)V

    .line 53
    invoke-virtual {v5}, Ln3/x;->m()I

    move-result v9

    .line 54
    invoke-static {v9}, Li5/e;->e(I)I

    move-result v9

    if-nez v9, :cond_1ce

    const/16 v15, 0x8

    goto :goto_1d0

    :cond_1ce
    const/16 v15, 0x10

    .line 55
    :goto_1d0
    invoke-virtual {v5, v15}, Ln3/x;->O(I)V

    .line 56
    invoke-virtual {v5}, Ln3/x;->C()J

    move-result-wide v31

    .line 57
    iget v15, v5, Ln3/x;->b:I

    if-nez v9, :cond_1dd

    const/4 v0, 0x4

    goto :goto_1df

    :cond_1dd
    const/16 v0, 0x8

    :goto_1df
    move-object/from16 v34, v2

    move/from16 v2, v16

    :goto_1e3
    if-ge v2, v0, :cond_21e

    move/from16 v27, v2

    .line 58
    iget-object v2, v5, Ln3/x;->a:[B

    add-int v28, v15, v27

    .line 59
    aget-byte v2, v2, v28

    move/from16 v28, v9

    const/4 v9, -0x1

    if-eq v2, v9, :cond_213

    if-nez v28, :cond_1f9

    .line 60
    invoke-virtual {v5}, Ln3/x;->C()J

    move-result-wide v27

    goto :goto_1fd

    :cond_1f9
    invoke-virtual {v5}, Ln3/x;->G()J

    move-result-wide v27

    :goto_1fd
    cmp-long v0, v27, v23

    if-nez v0, :cond_207

    :goto_201
    move-object v9, v3

    move-wide/from16 v2, v31

    :goto_204
    move-wide/from16 v0, v38

    goto :goto_225

    .line 61
    :cond_207
    sget-object v0, Ln3/l0;->a:Ljava/lang/String;

    .line 62
    sget-object v33, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v29, 0xf4240

    invoke-static/range {v27 .. v33}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v38

    goto :goto_201

    :cond_213
    move-object v9, v3

    move-wide/from16 v2, v31

    add-int/lit8 v27, v27, 0x1

    move-object v3, v9

    move/from16 v2, v27

    move/from16 v9, v28

    goto :goto_1e3

    :cond_21e
    move-object v9, v3

    move-wide/from16 v2, v31

    .line 63
    invoke-virtual {v5, v0}, Ln3/x;->O(I)V

    goto :goto_204

    .line 64
    :goto_225
    invoke-virtual {v5}, Ln3/x;->H()I

    move-result v5

    shr-int/lit8 v15, v5, 0xa

    and-int/lit8 v15, v15, 0x1f

    add-int/lit8 v15, v15, 0x60

    int-to-char v15, v15

    shr-int/lit8 v27, v5, 0x5

    and-int/lit8 v27, v27, 0x1f

    move/from16 v28, v5

    add-int/lit8 v5, v27, 0x60

    int-to-char v5, v5

    and-int/lit8 v27, v28, 0x1f

    move/from16 v28, v5

    add-int/lit8 v5, v27, 0x60

    int-to-char v5, v5

    move/from16 v27, v5

    move-object/from16 v19, v9

    const/4 v5, 0x3

    .line 65
    new-array v9, v5, [C

    aput-char v15, v9, v16

    aput-char v28, v9, v18

    const/16 v37, 0x2

    aput-char v27, v9, v37

    move/from16 v15, v16

    :goto_251
    if-ge v15, v5, :cond_266

    .line 66
    aget-char v5, v9, v15

    move/from16 v28, v15

    const/16 v15, 0x61

    if-lt v5, v15, :cond_264

    const/16 v15, 0x7a

    if-le v5, v15, :cond_260

    goto :goto_264

    :cond_260
    add-int/lit8 v15, v28, 0x1

    const/4 v5, 0x3

    goto :goto_251

    :cond_264
    :goto_264
    const/4 v5, 0x0

    goto :goto_26b

    .line 67
    :cond_266
    new-instance v5, Ljava/lang/String;

    invoke-direct {v5, v9}, Ljava/lang/String;-><init>([C)V

    :goto_26b
    const v9, 0x73747364

    .line 68
    invoke-virtual {v11, v9}, Lo3/c;->p(I)Lo3/d;

    move-result-object v9

    if-nez v9, :cond_282

    .line 69
    const-string v0, "Ignoring track where sample table (stbl) box is missing a sample description (stsd)."

    invoke-static {v12, v0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    move-object/from16 v1, p7

    move-object/from16 v27, v6

    move-object/from16 v26, v12

    :goto_27f
    const/4 v0, 0x0

    goto/16 :goto_46d

    .line 70
    :cond_282
    iget-object v9, v9, Lo3/d;->i:Ln3/x;

    move-object/from16 v11, p4

    move/from16 v15, p6

    invoke-static {v9, v4, v5, v11, v15}, Li5/e;->i(Ln3/x;Li5/d;Ljava/lang/String;Lk3/r;Z)Lcom/google/android/gms/internal/play_billing/s1;

    move-result-object v5

    const v9, 0x74726566

    .line 71
    invoke-virtual {v6, v9}, Lo3/c;->o(I)Lo3/c;

    move-result-object v9

    if-eqz v9, :cond_2b3

    const v11, 0x63686170

    .line 72
    invoke-virtual {v9, v11}, Lo3/c;->p(I)Lo3/d;

    move-result-object v9

    if-eqz v9, :cond_2b3

    .line 73
    iget-object v9, v9, Lo3/d;->i:Ln3/x;

    const/16 v11, 0x8

    .line 74
    invoke-virtual {v9, v11}, Ln3/x;->N(I)V

    .line 75
    invoke-virtual {v9}, Ln3/x;->a()I

    move-result v11

    move-object/from16 v27, v9

    const/4 v9, 0x4

    if-lt v11, v9, :cond_2b3

    .line 76
    invoke-virtual/range {v27 .. v27}, Ln3/x;->m()I

    move-result v9

    goto :goto_2b4

    :cond_2b3
    const/4 v9, -0x1

    :goto_2b4
    if-nez p5, :cond_3d4

    const v11, 0x65647473

    .line 77
    invoke-virtual {v6, v11}, Lo3/c;->o(I)Lo3/c;

    move-result-object v11

    if-eqz v11, :cond_3d4

    const v15, 0x656c7374

    .line 78
    invoke-virtual {v11, v15}, Lo3/c;->p(I)Lo3/d;

    move-result-object v11

    if-nez v11, :cond_2d5

    move-wide/from16 v29, v0

    move-object/from16 v27, v6

    move-wide/from16 v31, v7

    move/from16 v28, v9

    move-object/from16 v26, v12

    const/4 v0, 0x0

    goto/16 :goto_3c9

    .line 79
    :cond_2d5
    iget-object v11, v11, Lo3/d;->i:Ln3/x;

    const/16 v15, 0x8

    .line 80
    invoke-virtual {v11, v15}, Ln3/x;->N(I)V

    .line 81
    invoke-virtual {v11}, Ln3/x;->m()I

    move-result v15

    .line 82
    invoke-static {v15}, Li5/e;->e(I)I

    move-result v15

    move-object/from16 v26, v12

    .line 83
    invoke-virtual {v11}, Ln3/x;->E()I

    move-result v12

    move-object/from16 v27, v6

    if-ltz v12, :cond_2f3

    move/from16 v6, v18

    :goto_2f0
    move/from16 v28, v9

    goto :goto_2f6

    :cond_2f3
    move/from16 v6, v16

    goto :goto_2f0

    .line 84
    :goto_2f6
    const-string v9, "Invalid initialCapacity: %s"

    invoke-static {v9, v12, v6}, Loq/a;->l(Ljava/lang/String;IZ)V

    .line 85
    new-array v6, v12, [J

    move-object/from16 v29, v6

    if-ltz v12, :cond_304

    move/from16 v6, v18

    goto :goto_306

    :cond_304
    move/from16 v6, v16

    .line 86
    :goto_306
    invoke-static {v9, v12, v6}, Loq/a;->l(Ljava/lang/String;IZ)V

    .line 87
    new-array v6, v12, [J

    move-object v9, v6

    move-wide/from16 v31, v7

    move/from16 v7, v16

    move-object/from16 v6, v29

    move-wide/from16 v29, v0

    move v0, v7

    move v1, v0

    :goto_316
    if-ge v0, v12, :cond_3b2

    move/from16 v8, v18

    if-ne v15, v8, :cond_321

    .line 88
    invoke-virtual {v11}, Ln3/x;->G()J

    move-result-wide v38

    goto :goto_325

    :cond_321
    invoke-virtual {v11}, Ln3/x;->C()J

    move-result-wide v38

    :goto_325
    add-int/lit8 v8, v1, 0x1

    move/from16 v33, v0

    .line 89
    array-length v0, v6

    move/from16 v35, v12

    const-string v12, "cannot store more than MAX_VALUE elements"

    const v40, 0x7fffffff

    if-le v8, v0, :cond_356

    .line 90
    array-length v0, v6

    if-ltz v8, :cond_350

    shr-int/lit8 v42, v0, 0x1

    add-int v0, v0, v42

    const/16 v18, 0x1

    add-int/lit8 v0, v0, 0x1

    if-ge v0, v8, :cond_346

    .line 91
    invoke-static {v1}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    shl-int/lit8 v0, v0, 0x1

    :cond_346
    if-gez v0, :cond_34a

    move/from16 v0, v40

    .line 92
    :cond_34a
    invoke-static {v6, v0}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    move-object v6, v0

    goto :goto_356

    .line 93
    :cond_350
    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0, v12}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    .line 94
    :cond_356
    :goto_356
    aput-wide v38, v6, v1

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x1

    if-ne v15, v8, :cond_363

    .line 95
    invoke-virtual {v11}, Ln3/x;->u()J

    move-result-wide v38

    move v8, v1

    goto :goto_36b

    :cond_363
    invoke-virtual {v11}, Ln3/x;->m()I

    move-result v0

    move v8, v1

    int-to-long v0, v0

    move-wide/from16 v38, v0

    :goto_36b
    add-int/lit8 v0, v7, 0x1

    .line 96
    array-length v1, v9

    if-le v0, v1, :cond_392

    .line 97
    array-length v1, v9

    if-ltz v0, :cond_38c

    shr-int/lit8 v12, v1, 0x1

    add-int/2addr v1, v12

    const/16 v18, 0x1

    add-int/lit8 v1, v1, 0x1

    if-ge v1, v0, :cond_382

    .line 98
    invoke-static {v7}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    shl-int/lit8 v1, v0, 0x1

    :cond_382
    if-gez v1, :cond_386

    move/from16 v1, v40

    .line 99
    :cond_386
    invoke-static {v9, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    move-object v9, v0

    goto :goto_392

    .line 100
    :cond_38c
    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0, v12}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    .line 101
    :cond_392
    :goto_392
    aput-wide v38, v9, v7

    add-int/lit8 v7, v7, 0x1

    .line 102
    invoke-virtual {v11}, Ln3/x;->x()S

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_3aa

    const/4 v0, 0x2

    .line 103
    invoke-virtual {v11, v0}, Ln3/x;->O(I)V

    add-int/lit8 v0, v33, 0x1

    move v1, v8

    move/from16 v12, v35

    const/16 v18, 0x1

    goto/16 :goto_316

    .line 104
    :cond_3aa
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unsupported media rate."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 105
    :cond_3b2
    sget-object v0, Llx/b;->i:Llx/b;

    if-nez v1, :cond_3b8

    move-object v8, v0

    goto :goto_3bd

    :cond_3b8
    new-instance v8, Llx/b;

    .line 106
    invoke-direct {v8, v6, v1}, Llx/b;-><init>([JI)V

    :goto_3bd
    if-nez v7, :cond_3c0

    goto :goto_3c5

    .line 107
    :cond_3c0
    new-instance v0, Llx/b;

    .line 108
    invoke-direct {v0, v9, v7}, Llx/b;-><init>([JI)V

    .line 109
    :goto_3c5
    invoke-static {v8, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v0

    :goto_3c9
    if-eqz v0, :cond_3de

    .line 110
    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Llx/b;

    .line 111
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, Llx/b;

    goto :goto_3e0

    :cond_3d4
    move-wide/from16 v29, v0

    move-object/from16 v27, v6

    move-wide/from16 v31, v7

    move/from16 v28, v9

    move-object/from16 v26, v12

    :cond_3de
    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 112
    :goto_3e0
    iget-object v6, v5, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    check-cast v6, Lk3/w;

    if-nez v6, :cond_3ea

    move-object/from16 v1, p7

    goto/16 :goto_27f

    .line 113
    :cond_3ea
    iget v7, v4, Li5/d;->b:I

    if-eqz v7, :cond_41b

    .line 114
    new-instance v8, Lo3/b;

    .line 115
    invoke-direct {v8, v7}, Lo3/b;-><init>(I)V

    .line 116
    invoke-virtual {v6}, Lk3/w;->a()Lk3/v;

    move-result-object v6

    .line 117
    iget-object v7, v5, Lcom/google/android/gms/internal/play_billing/s1;->v:Ljava/lang/Object;

    check-cast v7, Lk3/w;

    iget-object v7, v7, Lk3/w;->m:Lk3/t0;

    if-eqz v7, :cond_409

    const/4 v9, 0x1

    .line 118
    new-array v11, v9, [Lk3/s0;

    aput-object v8, v11, v16

    invoke-virtual {v7, v11}, Lk3/t0;->a([Lk3/s0;)Lk3/t0;

    move-result-object v7

    goto :goto_413

    :cond_409
    const/4 v9, 0x1

    .line 119
    new-instance v7, Lk3/t0;

    new-array v11, v9, [Lk3/s0;

    aput-object v8, v11, v16

    invoke-direct {v7, v11}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 120
    :goto_413
    iput-object v7, v6, Lk3/v;->l:Lk3/t0;

    .line 121
    new-instance v7, Lk3/w;

    invoke-direct {v7, v6}, Lk3/w;-><init>(Lk3/v;)V

    move-object v6, v7

    .line 122
    :cond_41b
    iget-object v7, v6, Lk3/w;->p:Ljava/lang/String;

    const-string v8, "text/x-unknown"

    invoke-static {v7, v8}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const/4 v8, 0x1

    xor-int/2addr v7, v8

    .line 123
    new-instance v9, Li5/t;

    .line 124
    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    .line 125
    iput-boolean v8, v9, Li5/t;->m:Z

    const/4 v8, -0x1

    .line 126
    iput v8, v9, Li5/t;->n:I

    .line 127
    iget v4, v4, Li5/d;->a:I

    .line 128
    iput v4, v9, Li5/t;->a:I

    .line 129
    iput v10, v9, Li5/t;->b:I

    .line 130
    iput-wide v2, v9, Li5/t;->c:J

    .line 131
    iput-wide v13, v9, Li5/t;->d:J

    move-wide/from16 v2, v31

    .line 132
    iput-wide v2, v9, Li5/t;->e:J

    move-wide/from16 v2, v29

    .line 133
    iput-wide v2, v9, Li5/t;->f:J

    .line 134
    iput-object v6, v9, Li5/t;->g:Lk3/w;

    .line 135
    iget v2, v5, Lcom/google/android/gms/internal/play_billing/s1;->e:I

    .line 136
    iput v2, v9, Li5/t;->h:I

    .line 137
    iget-object v2, v5, Lcom/google/android/gms/internal/play_billing/s1;->i:Ljava/lang/Object;

    check-cast v2, [Li5/v;

    .line 138
    invoke-virtual {v2}, [Li5/v;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Li5/v;

    iput-object v2, v9, Li5/t;->i:[Li5/v;

    .line 139
    iget v2, v5, Lcom/google/android/gms/internal/play_billing/s1;->d:I

    .line 140
    iput v2, v9, Li5/t;->j:I

    .line 141
    iput-object v1, v9, Li5/t;->k:Llx/b;

    .line 142
    iput-object v0, v9, Li5/t;->l:Llx/b;

    .line 143
    iput-boolean v7, v9, Li5/t;->m:Z

    move/from16 v0, v28

    .line 144
    iput v0, v9, Li5/t;->n:I

    .line 145
    iget-object v0, v9, Li5/t;->g:Lk3/w;

    .line 146
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    new-instance v0, Li5/u;

    invoke-direct {v0, v9}, Li5/u;-><init>(Li5/t;)V

    move-object/from16 v1, p7

    .line 148
    :goto_46d
    invoke-interface {v1, v0}, Lgx/k;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Li5/u;

    if-nez v3, :cond_47a

    move-object/from16 v9, v19

    goto/16 :goto_bba

    .line 149
    :cond_47a
    iget-object v0, v3, Li5/u;->g:Lk3/w;

    move-object/from16 v6, v27

    const v2, 0x6d646961

    .line 150
    invoke-virtual {v6, v2}, Lo3/c;->o(I)Lo3/c;

    move-result-object v2

    .line 151
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v5, 0x6d696e66

    .line 152
    invoke-virtual {v2, v5}, Lo3/c;->o(I)Lo3/c;

    move-result-object v2

    .line 153
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v5, 0x7374626c

    .line 154
    invoke-virtual {v2, v5}, Lo3/c;->o(I)Lo3/c;

    move-result-object v2

    .line 155
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v4, 0x7374737a

    .line 156
    invoke-virtual {v2, v4}, Lo3/c;->p(I)Lo3/d;

    move-result-object v4

    if-eqz v4, :cond_4ab

    .line 157
    new-instance v5, Lds/f;

    invoke-direct {v5, v4, v0}, Lds/f;-><init>(Lo3/d;Lk3/w;)V

    goto :goto_4b9

    :cond_4ab
    const v4, 0x73747a32

    .line 158
    invoke-virtual {v2, v4}, Lo3/c;->p(I)Lo3/d;

    move-result-object v4

    if-eqz v4, :cond_bc3

    .line 159
    new-instance v5, Lds/g;

    invoke-direct {v5, v4}, Lds/g;-><init>(Lo3/d;)V

    .line 160
    :goto_4b9
    invoke-interface {v5}, Li5/b;->b()I

    move-result v4

    if-nez v4, :cond_4db

    .line 161
    new-instance v2, Li5/w;

    move/from16 v0, v16

    new-array v4, v0, [J

    new-array v5, v0, [I

    new-array v7, v0, [J

    new-array v8, v0, [I

    new-array v9, v0, [I

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v6, 0x0

    const/4 v10, 0x0

    invoke-direct/range {v2 .. v13}, Li5/w;-><init>(Li5/u;[J[II[J[I[IZJI)V

    move-object/from16 v9, v19

    :goto_4d7
    const/16 v16, 0x0

    goto/16 :goto_bb7

    .line 162
    :cond_4db
    iget v6, v3, Li5/u;->b:I

    const/4 v14, 0x2

    if-ne v6, v14, :cond_504

    iget-wide v6, v3, Li5/u;->f:J

    cmp-long v8, v6, v23

    if-lez v8, :cond_504

    int-to-float v8, v4

    long-to-float v6, v6

    const v7, 0x49742400    # 1000000.0f

    div-float/2addr v6, v7

    div-float/2addr v8, v6

    .line 163
    invoke-virtual {v0}, Lk3/w;->a()Lk3/v;

    move-result-object v0

    invoke-virtual {v0, v8}, Lk3/v;->b(F)V

    .line 164
    new-instance v6, Lk3/w;

    invoke-direct {v6, v0}, Lk3/w;-><init>(Lk3/v;)V

    .line 165
    invoke-virtual {v3}, Li5/u;->a()Li5/t;

    move-result-object v0

    .line 166
    iput-object v6, v0, Li5/t;->g:Lk3/w;

    .line 167
    new-instance v3, Li5/u;

    invoke-direct {v3, v0}, Li5/u;-><init>(Li5/t;)V

    .line 168
    :cond_504
    iget-object v0, v3, Li5/u;->g:Lk3/w;

    const v6, 0x7374636f

    invoke-virtual {v2, v6}, Lo3/c;->p(I)Lo3/d;

    move-result-object v6

    if-nez v6, :cond_51b

    const v6, 0x636f3634

    .line 169
    invoke-virtual {v2, v6}, Lo3/c;->p(I)Lo3/d;

    move-result-object v6

    .line 170
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, 0x1

    goto :goto_51c

    :cond_51b
    const/4 v7, 0x0

    .line 171
    :goto_51c
    iget-object v6, v6, Lo3/d;->i:Ln3/x;

    const v8, 0x73747363

    .line 172
    invoke-virtual {v2, v8}, Lo3/c;->p(I)Lo3/d;

    move-result-object v8

    .line 173
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 174
    iget-object v8, v8, Lo3/d;->i:Ln3/x;

    const v9, 0x73747473

    .line 175
    invoke-virtual {v2, v9}, Lo3/c;->p(I)Lo3/d;

    move-result-object v9

    .line 176
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 177
    iget-object v9, v9, Lo3/d;->i:Ln3/x;

    const v10, 0x73747373

    .line 178
    invoke-virtual {v2, v10}, Lo3/c;->p(I)Lo3/d;

    move-result-object v10

    if-eqz v10, :cond_542

    .line 179
    iget-object v10, v10, Lo3/d;->i:Ln3/x;

    goto :goto_543

    :cond_542
    const/4 v10, 0x0

    :goto_543
    const v11, 0x63747473

    .line 180
    invoke-virtual {v2, v11}, Lo3/c;->p(I)Lo3/d;

    move-result-object v2

    if-eqz v2, :cond_54f

    .line 181
    iget-object v2, v2, Lo3/d;->i:Ln3/x;

    goto :goto_550

    :cond_54f
    const/4 v2, 0x0

    .line 182
    :goto_550
    new-instance v11, Lds/c;

    invoke-direct {v11, v8, v6, v7}, Lds/c;-><init>(Ln3/x;Ln3/x;Z)V

    const/16 v6, 0xc

    .line 183
    invoke-virtual {v9, v6}, Ln3/x;->N(I)V

    .line 184
    invoke-virtual {v9}, Ln3/x;->E()I

    move-result v7

    const/16 v18, 0x1

    add-int/lit8 v7, v7, -0x1

    .line 185
    invoke-virtual {v9}, Ln3/x;->E()I

    move-result v8

    .line 186
    invoke-virtual {v9}, Ln3/x;->E()I

    move-result v12

    if-eqz v2, :cond_574

    .line 187
    invoke-virtual {v2, v6}, Ln3/x;->N(I)V

    .line 188
    invoke-virtual {v2}, Ln3/x;->E()I

    move-result v13

    goto :goto_575

    :cond_574
    const/4 v13, 0x0

    :goto_575
    if-eqz v10, :cond_58c

    .line 189
    invoke-virtual {v10, v6}, Ln3/x;->N(I)V

    .line 190
    invoke-virtual {v10}, Ln3/x;->E()I

    move-result v6

    if-lez v6, :cond_589

    .line 191
    invoke-virtual {v10}, Ln3/x;->E()I

    move-result v14

    const/16 v18, 0x1

    add-int/lit8 v14, v14, -0x1

    goto :goto_58e

    :cond_589
    const/4 v10, 0x0

    :goto_58a
    const/4 v14, -0x1

    goto :goto_58e

    :cond_58c
    const/4 v6, 0x0

    goto :goto_58a

    .line 192
    :goto_58e
    invoke-interface {v5}, Li5/b;->a()I

    move-result v15

    .line 193
    iget-object v1, v0, Lk3/w;->p:Ljava/lang/String;

    move-object/from16 v17, v0

    const/4 v0, -0x1

    if-eq v15, v0, :cond_5b9

    .line 194
    const-string v0, "audio/raw"

    .line 195
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b1

    const-string v0, "audio/g711-mlaw"

    .line 196
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b1

    const-string v0, "audio/g711-alaw"

    .line 197
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5b9

    :cond_5b1
    if-nez v7, :cond_5b9

    if-nez v13, :cond_5b9

    if-nez v6, :cond_5b9

    const/4 v0, 0x1

    goto :goto_5ba

    :cond_5b9
    const/4 v0, 0x0

    .line 198
    :goto_5ba
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    if-nez v10, :cond_5c4

    const/16 v46, 0x1

    goto :goto_5c6

    :cond_5c4
    const/16 v46, 0x0

    :goto_5c6
    if-eqz v0, :cond_684

    .line 199
    iget v0, v11, Lds/c;->b:I

    new-array v2, v0, [J

    .line 200
    new-array v4, v0, [I

    .line 201
    :goto_5ce
    invoke-virtual {v11}, Lds/c;->a()Z

    move-result v5

    if-eqz v5, :cond_5df

    .line 202
    iget v5, v11, Lds/c;->c:I

    iget-wide v6, v11, Lds/c;->e:J

    aput-wide v6, v2, v5

    .line 203
    iget v6, v11, Lds/c;->d:I

    aput v6, v4, v5

    goto :goto_5ce

    :cond_5df
    int-to-long v5, v12

    const/16 v7, 0x2000

    .line 204
    div-int/2addr v7, v15

    const/4 v8, 0x1

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    const/4 v8, 0x0

    const/4 v9, 0x0

    :goto_5ea
    if-ge v8, v0, :cond_5f6

    .line 205
    aget v10, v4, v8

    .line 206
    invoke-static {v10, v7}, Ln3/l0;->g(II)I

    move-result v10

    add-int/2addr v9, v10

    add-int/lit8 v8, v8, 0x1

    goto :goto_5ea

    .line 207
    :cond_5f6
    new-array v8, v9, [J

    .line 208
    new-array v10, v9, [I

    .line 209
    new-array v11, v9, [J

    .line 210
    new-array v12, v9, [I

    move-object/from16 v22, v2

    const/4 v2, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v20, 0x0

    const/16 v26, 0x0

    :goto_607
    if-ge v13, v0, :cond_65d

    .line 211
    aget v27, v4, v13

    .line 212
    aget-wide v28, v22, v13

    move/from16 v57, v26

    move/from16 v26, v0

    move/from16 v0, v20

    move/from16 v20, v57

    move/from16 v57, v27

    move/from16 v27, v2

    move/from16 v2, v57

    :goto_61b
    if-lez v2, :cond_64c

    .line 213
    invoke-static {v7, v2}, Ljava/lang/Math;->min(II)I

    move-result v30

    .line 214
    aput-wide v28, v8, v20

    move/from16 v31, v2

    mul-int v2, v15, v30

    .line 215
    aput v2, v10, v20

    add-int v27, v27, v2

    .line 216
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    move-object/from16 v32, v4

    move-wide/from16 v35, v5

    int-to-long v4, v14

    mul-long v5, v35, v4

    .line 217
    aput-wide v5, v11, v20

    const/16 v18, 0x1

    .line 218
    aput v18, v12, v20

    .line 219
    aget v2, v10, v20

    int-to-long v4, v2

    add-long v28, v28, v4

    add-int v14, v14, v30

    sub-int v2, v31, v30

    add-int/lit8 v20, v20, 0x1

    move-object/from16 v4, v32

    move-wide/from16 v5, v35

    goto :goto_61b

    :cond_64c
    move-object/from16 v32, v4

    move-wide/from16 v35, v5

    add-int/lit8 v13, v13, 0x1

    move/from16 v2, v20

    move/from16 v20, v0

    move/from16 v0, v26

    move/from16 v26, v2

    move/from16 v2, v27

    goto :goto_607

    :cond_65d
    move-wide/from16 v35, v5

    int-to-long v4, v14

    mul-long v5, v35, v4

    int-to-long v13, v2

    const/4 v0, 0x0

    if-eqz p8, :cond_668

    .line 220
    new-array v8, v0, [J

    :cond_668
    if-eqz p8, :cond_66c

    .line 221
    new-array v10, v0, [I

    :cond_66c
    if-eqz p8, :cond_670

    .line 222
    new-array v11, v0, [J

    :cond_670
    if-eqz p8, :cond_674

    .line 223
    new-array v12, v0, [I

    :cond_674
    move-wide/from16 v26, v5

    move/from16 v49, v9

    move-object/from16 v41, v10

    move/from16 v42, v20

    move-object/from16 v20, v1

    :goto_67e
    move-object/from16 v40, v8

    move-object/from16 v44, v12

    goto/16 :goto_812

    :cond_684
    const/4 v0, 0x0

    if-eqz p8, :cond_68a

    .line 224
    new-array v15, v0, [J

    goto :goto_68c

    :cond_68a
    new-array v15, v4, [J

    :goto_68c
    move-object/from16 v22, v2

    if-eqz p8, :cond_693

    .line 225
    new-array v2, v0, [I

    goto :goto_695

    :cond_693
    new-array v2, v4, [I

    :goto_695
    move-object/from16 v27, v5

    if-eqz p8, :cond_69c

    .line 226
    new-array v5, v0, [J

    goto :goto_69e

    :cond_69c
    new-array v5, v4, [J

    :goto_69e
    move/from16 v20, v6

    if-eqz p8, :cond_6a5

    .line 227
    new-array v6, v0, [I

    goto :goto_6a7

    :cond_6a5
    new-array v6, v4, [I

    :goto_6a7
    move-object/from16 v28, v9

    move-object/from16 v29, v10

    move/from16 v30, v13

    move/from16 v0, v20

    move-wide/from16 v32, v23

    move-wide/from16 v35, v32

    move-wide/from16 v38, v35

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v13, 0x0

    const/16 v20, 0x0

    const/16 v31, 0x0

    :goto_6bc
    if-ge v9, v4, :cond_790

    move-wide/from16 v39, v38

    move/from16 v38, v20

    const/16 v20, 0x1

    :goto_6c4
    if-nez v38, :cond_6e1

    .line 228
    invoke-virtual {v11}, Lds/c;->a()Z

    move-result v20

    if-eqz v20, :cond_6e1

    move/from16 v41, v7

    move/from16 v42, v8

    .line 229
    iget-wide v7, v11, Lds/c;->e:J

    move/from16 v43, v4

    .line 230
    iget v4, v11, Lds/c;->d:I

    move/from16 v38, v4

    move-wide/from16 v39, v7

    move/from16 v7, v41

    move/from16 v8, v42

    move/from16 v4, v43

    goto :goto_6c4

    :cond_6e1
    move/from16 v43, v4

    move/from16 v41, v7

    move/from16 v42, v8

    if-nez v20, :cond_70f

    .line 231
    const-string v4, "Unexpected end of chunk data"

    move-object/from16 v7, v26

    invoke-static {v7, v4}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    if-nez p8, :cond_70a

    .line 232
    invoke-static {v15, v9}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v4

    .line 233
    invoke-static {v2, v9}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v2

    .line 234
    invoke-static {v5, v9}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v5

    .line 235
    invoke-static {v6, v9}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v6

    move-object v8, v4

    move-object v11, v5

    move-object v12, v6

    move v4, v9

    :goto_706
    move/from16 v5, v38

    goto/16 :goto_7a1

    :cond_70a
    move-object v11, v5

    move-object v12, v6

    move v4, v9

    move-object v8, v15

    goto :goto_706

    :cond_70f
    move-object/from16 v7, v26

    if-eqz v22, :cond_724

    :goto_713
    if-nez v31, :cond_722

    if-lez v30, :cond_722

    .line 236
    invoke-virtual/range {v22 .. v22}, Ln3/x;->E()I

    move-result v31

    .line 237
    invoke-virtual/range {v22 .. v22}, Ln3/x;->m()I

    move-result v10

    add-int/lit8 v30, v30, -0x1

    goto :goto_713

    :cond_722
    add-int/lit8 v31, v31, -0x1

    .line 238
    :cond_724
    invoke-interface/range {v27 .. v27}, Li5/b;->c()I

    move-result v4

    move-object v8, v5

    move-object/from16 v26, v6

    int-to-long v5, v4

    add-long v35, v35, v5

    if-le v4, v13, :cond_731

    move v13, v4

    :cond_731
    if-nez p8, :cond_753

    .line 239
    aput-wide v39, v15, v9

    .line 240
    aput v4, v2, v9

    move-wide/from16 v44, v5

    int-to-long v4, v10

    add-long v4, v32, v4

    .line 241
    aput-wide v4, v8, v9

    if-nez v29, :cond_742

    const/4 v4, 0x1

    goto :goto_743

    :cond_742
    const/4 v4, 0x0

    .line 242
    :goto_743
    aput v4, v26, v9

    if-ne v9, v14, :cond_755

    const/16 v18, 0x1

    .line 243
    aput v18, v26, v9

    .line 244
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_755

    :cond_753
    move-wide/from16 v44, v5

    :cond_755
    :goto_755
    if-eqz v29, :cond_766

    if-ne v9, v14, :cond_766

    add-int/lit8 v0, v0, -0x1

    if-lez v0, :cond_766

    .line 245
    invoke-virtual/range {v29 .. v29}, Ln3/x;->E()I

    move-result v4

    const/16 v18, 0x1

    add-int/lit8 v4, v4, -0x1

    move v14, v4

    :cond_766
    int-to-long v4, v12

    add-long v32, v32, v4

    add-int/lit8 v4, v42, -0x1

    if-nez v4, :cond_77c

    if-lez v41, :cond_77c

    .line 246
    invoke-virtual/range {v28 .. v28}, Ln3/x;->E()I

    move-result v4

    .line 247
    invoke-virtual/range {v28 .. v28}, Ln3/x;->m()I

    move-result v5

    add-int/lit8 v6, v41, -0x1

    move v12, v5

    move/from16 v41, v6

    :cond_77c
    add-long v5, v39, v44

    add-int/lit8 v20, v38, -0x1

    add-int/lit8 v9, v9, 0x1

    move-wide/from16 v38, v5

    move-object v5, v8

    move-object/from16 v6, v26

    move v8, v4

    move-object/from16 v26, v7

    move/from16 v7, v41

    move/from16 v4, v43

    goto/16 :goto_6bc

    :cond_790
    move/from16 v43, v4

    move/from16 v41, v7

    move/from16 v42, v8

    move-object/from16 v7, v26

    move-object v8, v5

    move-object/from16 v26, v6

    move-object v11, v8

    move-object v8, v15

    move/from16 v5, v20

    move-object/from16 v12, v26

    :goto_7a1
    int-to-long v9, v10

    add-long v9, v32, v9

    if-eqz v22, :cond_7b6

    :goto_7a6
    if-lez v30, :cond_7b6

    .line 248
    invoke-virtual/range {v22 .. v22}, Ln3/x;->E()I

    move-result v6

    if-eqz v6, :cond_7b0

    const/4 v6, 0x0

    goto :goto_7b7

    .line 249
    :cond_7b0
    invoke-virtual/range {v22 .. v22}, Ln3/x;->m()I

    add-int/lit8 v30, v30, -0x1

    goto :goto_7a6

    :cond_7b6
    const/4 v6, 0x1

    :goto_7b7
    if-nez v0, :cond_7c9

    if-nez v42, :cond_7c9

    if-nez v5, :cond_7c9

    if-nez v41, :cond_7c9

    if-nez v31, :cond_7c9

    if-nez v6, :cond_7c4

    goto :goto_7c9

    :cond_7c4
    move-object/from16 v20, v1

    move-object/from16 v22, v2

    goto :goto_806

    .line 250
    :cond_7c9
    :goto_7c9
    new-instance v14, Ljava/lang/StringBuilder;

    const-string v15, "Inconsistent stbl box for track "

    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v15, v3, Li5/u;->a:I

    move-object/from16 v20, v1

    const-string v1, ": remainingSynchronizationSamples "

    move-object/from16 v22, v2

    const-string v2, ", remainingSamplesAtTimestampDelta "

    .line 251
    invoke-static {v14, v15, v1, v0, v2}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 252
    const-string v0, ", remainingSamplesInChunk "

    const-string v1, ", remainingTimestampDeltaChanges "

    move/from16 v2, v42

    .line 253
    invoke-static {v14, v2, v0, v5, v1}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    move/from16 v0, v41

    .line 254
    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ", remainingSamplesAtTimestampOffset "

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move/from16 v0, v31

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    if-nez v6, :cond_7fa

    .line 255
    const-string v0, ", ctts invalid"

    goto :goto_7fc

    :cond_7fa
    const-string v0, ""

    :goto_7fc
    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 256
    invoke-static {v7, v0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    :goto_806
    move/from16 v49, v4

    move-wide/from16 v26, v9

    move/from16 v42, v13

    move-object/from16 v41, v22

    move-wide/from16 v13, v35

    goto/16 :goto_67e

    .line 257
    :goto_812
    iget-wide v8, v3, Li5/u;->f:J

    cmp-long v0, v8, v23

    const-wide/32 v1, 0x7fffffff

    if-lez v0, :cond_846

    const-wide/16 v4, 0x8

    mul-long/2addr v4, v13

    const-wide/32 v6, 0xf4240

    .line 258
    sget-object v10, Ljava/math/RoundingMode;->HALF_DOWN:Ljava/math/RoundingMode;

    .line 259
    invoke-static/range {v4 .. v10}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v4

    cmp-long v0, v4, v23

    if-lez v0, :cond_846

    cmp-long v0, v4, v1

    if-gez v0, :cond_846

    .line 260
    invoke-virtual/range {v17 .. v17}, Lk3/w;->a()Lk3/v;

    move-result-object v0

    long-to-int v4, v4

    .line 261
    iput v4, v0, Lk3/v;->i:I

    .line 262
    new-instance v4, Lk3/w;

    invoke-direct {v4, v0}, Lk3/w;-><init>(Lk3/v;)V

    .line 263
    invoke-virtual {v3}, Li5/u;->a()Li5/t;

    move-result-object v0

    .line 264
    iput-object v4, v0, Li5/t;->g:Lk3/w;

    .line 265
    new-instance v3, Li5/u;

    invoke-direct {v3, v0}, Li5/u;-><init>(Li5/t;)V

    .line 266
    :cond_846
    iget v0, v3, Li5/u;->b:I

    iget-wide v4, v3, Li5/u;->c:J

    iget-object v6, v3, Li5/u;->g:Lk3/w;

    iget-object v7, v3, Li5/u;->j:Llx/b;

    iget-object v8, v3, Li5/u;->i:Llx/b;

    .line 267
    sget-object v56, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v28, 0xf4240

    move-wide/from16 v30, v4

    move-object/from16 v32, v56

    invoke-static/range {v26 .. v32}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v47

    .line 268
    invoke-static/range {v20 .. v20}, Lc7/t;->O(Ljava/util/Collection;)[I

    move-result-object v45

    if-nez v8, :cond_877

    if-nez p8, :cond_868

    .line 269
    invoke-static {v11, v4, v5}, Ln3/l0;->Z([JJ)V

    .line 270
    :cond_868
    new-instance v38, Li5/w;

    move-object/from16 v39, v3

    move-object/from16 v43, v11

    invoke-direct/range {v38 .. v49}, Li5/w;-><init>(Li5/u;[J[II[J[I[IZJI)V

    :goto_871
    move-object/from16 v9, v19

    move-object/from16 v2, v38

    goto/16 :goto_4d7

    :cond_877
    move-object/from16 v43, v11

    .line 271
    iget v9, v8, Llx/b;->e:I

    const-wide/16 v10, -0x1

    if-eqz p8, :cond_8cc

    .line 272
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    if-ne v9, v1, :cond_8a2

    const/4 v0, 0x0

    .line 273
    invoke-virtual {v8, v0}, Llx/b;->a(I)J

    move-result-wide v1

    cmp-long v1, v1, v23

    if-nez v1, :cond_8a2

    .line 274
    invoke-virtual {v7, v0}, Llx/b;->a(I)J

    move-result-wide v1

    sub-long v50, v26, v1

    const-wide/32 v52, 0xf4240

    .line 275
    iget-wide v0, v3, Li5/u;->c:J

    move-wide/from16 v54, v0

    .line 276
    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v0

    :goto_89f
    move-wide/from16 v47, v0

    goto :goto_8c4

    :cond_8a2
    move-wide/from16 v4, v23

    const/4 v0, 0x0

    :goto_8a5
    if-ge v0, v9, :cond_8b8

    .line 277
    invoke-virtual {v7, v0}, Llx/b;->a(I)J

    move-result-wide v1

    cmp-long v1, v1, v10

    if-eqz v1, :cond_8b5

    .line 278
    invoke-virtual {v8, v0}, Llx/b;->a(I)J

    move-result-wide v1

    add-long/2addr v1, v4

    move-wide v4, v1

    :cond_8b5
    add-int/lit8 v0, v0, 0x1

    goto :goto_8a5

    .line 279
    :cond_8b8
    iget-wide v8, v3, Li5/u;->d:J

    .line 280
    sget-object v10, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v6, 0xf4240

    invoke-static/range {v4 .. v10}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v0

    goto :goto_89f

    .line 281
    :goto_8c4
    new-instance v38, Li5/w;

    move-object/from16 v39, v3

    invoke-direct/range {v38 .. v49}, Li5/w;-><init>(Li5/u;[J[II[J[I[IZJI)V

    goto :goto_871

    :cond_8cc
    move-object v12, v3

    move-object/from16 v3, v43

    const/4 v13, 0x1

    if-ne v9, v13, :cond_987

    if-ne v0, v13, :cond_987

    .line 282
    array-length v14, v3

    const/4 v15, 0x2

    if-lt v14, v15, :cond_987

    .line 283
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v14, 0x0

    .line 284
    invoke-virtual {v7, v14}, Llx/b;->a(I)J

    move-result-wide v28

    .line 285
    invoke-virtual {v8, v14}, Llx/b;->a(I)J

    move-result-wide v50

    move-wide/from16 v30, v1

    iget-wide v1, v12, Li5/u;->c:J

    move-wide/from16 v32, v10

    iget-wide v10, v12, Li5/u;->d:J

    move-wide/from16 v52, v1

    move-wide/from16 v54, v10

    .line 286
    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v1

    add-long v1, v28, v1

    .line 287
    array-length v10, v3

    sub-int/2addr v10, v13

    const/4 v11, 0x4

    .line 288
    invoke-static {v11, v14, v10}, Ln3/l0;->j(III)I

    move-result v13

    .line 289
    array-length v15, v3

    sub-int/2addr v15, v11

    .line 290
    invoke-static {v15, v14, v10}, Ln3/l0;->j(III)I

    move-result v10

    .line 291
    aget-wide v35, v3, v14

    cmp-long v11, v35, v28

    if-gtz v11, :cond_91f

    aget-wide v13, v3, v13

    cmp-long v11, v28, v13

    if-gez v11, :cond_91f

    aget-wide v10, v3, v10

    cmp-long v10, v10, v1

    if-gez v10, :cond_91f

    const-wide/16 v10, 0x2

    add-long v10, v26, v10

    cmp-long v10, v1, v10

    if-gtz v10, :cond_91f

    const/4 v10, 0x1

    goto :goto_920

    :cond_91f
    const/4 v10, 0x0

    :goto_920
    if-eqz v10, :cond_955

    sub-long v1, v26, v1

    move-wide/from16 v10, v23

    .line 292
    invoke-static {v10, v11, v1, v2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    const/16 v16, 0x0

    .line 293
    aget-wide v13, v3, v16

    sub-long v50, v28, v13

    iget v13, v6, Lk3/w;->L:I

    int-to-long v13, v13

    iget-wide v10, v12, Li5/u;->c:J

    move-wide/from16 v54, v10

    move-wide/from16 v52, v13

    .line 294
    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v10

    .line 295
    iget v13, v6, Lk3/w;->L:I

    int-to-long v13, v13

    move-wide/from16 v50, v1

    iget-wide v1, v12, Li5/u;->c:J

    move-wide/from16 v54, v1

    move-wide/from16 v52, v13

    .line 296
    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v1

    cmp-long v13, v10, v23

    if-nez v13, :cond_959

    cmp-long v13, v1, v23

    if-eqz v13, :cond_955

    goto :goto_959

    :cond_955
    move-object/from16 v10, p1

    const/4 v1, 0x1

    goto :goto_98c

    :cond_959
    :goto_959
    cmp-long v13, v10, v30

    if-gtz v13, :cond_955

    cmp-long v13, v1, v30

    if-gtz v13, :cond_955

    long-to-int v0, v10

    move-object/from16 v10, p1

    .line 297
    iput v0, v10, Lo4/w;->a:I

    long-to-int v0, v1

    .line 298
    iput v0, v10, Lo4/w;->b:I

    .line 299
    invoke-static {v3, v4, v5}, Ln3/l0;->Z([JJ)V

    const/4 v0, 0x0

    .line 300
    invoke-virtual {v8, v0}, Llx/b;->a(I)J

    move-result-wide v50

    const-wide/32 v52, 0xf4240

    iget-wide v0, v12, Li5/u;->d:J

    move-wide/from16 v54, v0

    .line 301
    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v47

    .line 302
    new-instance v38, Li5/w;

    move-object/from16 v43, v3

    move-object/from16 v39, v12

    invoke-direct/range {v38 .. v49}, Li5/w;-><init>(Li5/u;[J[II[J[I[IZJI)V

    goto/16 :goto_871

    :cond_987
    move-wide/from16 v32, v10

    move-object/from16 v10, p1

    move v1, v13

    :goto_98c
    if-ne v9, v1, :cond_9d4

    const/4 v14, 0x0

    .line 303
    invoke-virtual {v8, v14}, Llx/b;->a(I)J

    move-result-wide v1

    const-wide/16 v23, 0x0

    cmp-long v1, v1, v23

    if-nez v1, :cond_9d4

    .line 304
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 305
    invoke-virtual {v7, v14}, Llx/b;->a(I)J

    move-result-wide v0

    const/4 v2, 0x0

    .line 306
    :goto_9a1
    array-length v4, v3

    if-ge v2, v4, :cond_9ba

    .line 307
    aget-wide v4, v3, v2

    sub-long v50, v4, v0

    iget-wide v4, v12, Li5/u;->c:J

    .line 308
    sget-object v56, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v52, 0xf4240

    move-wide/from16 v54, v4

    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v4

    .line 309
    aput-wide v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_9a1

    :cond_9ba
    sub-long v50, v26, v0

    .line 310
    iget-wide v0, v12, Li5/u;->c:J

    .line 311
    sget-object v56, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v52, 0xf4240

    move-wide/from16 v54, v0

    invoke-static/range {v50 .. v56}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v47

    .line 312
    new-instance v38, Li5/w;

    move-object/from16 v43, v3

    move-object/from16 v39, v12

    invoke-direct/range {v38 .. v49}, Li5/w;-><init>(Li5/u;[J[II[J[I[IZJI)V

    goto/16 :goto_871

    :cond_9d4
    move-object v11, v3

    move-object/from16 v1, v40

    move-object/from16 v2, v41

    move-object/from16 v3, v44

    move/from16 v4, v49

    const/4 v13, 0x1

    if-ne v0, v13, :cond_9e2

    const/4 v0, 0x1

    goto :goto_9e3

    :cond_9e2
    const/4 v0, 0x0

    .line 313
    :goto_9e3
    new-array v5, v9, [I

    .line 314
    new-array v13, v9, [I

    .line 315
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v17, v5

    const/4 v5, 0x0

    const/4 v10, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    :goto_9f0
    if-ge v14, v9, :cond_a9f

    move-object/from16 v41, v2

    move-object/from16 v44, v3

    .line 316
    invoke-virtual {v7, v14}, Llx/b;->a(I)J

    move-result-wide v2

    cmp-long v22, v2, v32

    if-eqz v22, :cond_a89

    .line 317
    invoke-virtual {v8, v14}, Llx/b;->a(I)J

    move-result-wide v25

    move-object/from16 v22, v13

    move/from16 v35, v14

    iget-wide v13, v12, Li5/u;->c:J

    move-wide/from16 v27, v13

    iget-wide v13, v12, Li5/u;->d:J

    .line 318
    sget-object v31, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    move-wide/from16 v29, v13

    invoke-static/range {v25 .. v31}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v13

    add-long/2addr v13, v2

    move/from16 v25, v15

    const/4 v15, 0x1

    .line 319
    invoke-static {v11, v2, v3, v15}, Ln3/l0;->f([JJZ)I

    move-result v2

    aput v2, v17, v35

    .line 320
    invoke-static {v11, v13, v14, v0}, Ln3/l0;->b([JJZ)I

    move-result v2

    add-int/lit8 v3, v2, -0x1

    move/from16 v26, v0

    move v15, v3

    move v3, v2

    const/4 v2, 0x0

    .line 321
    :goto_a29
    array-length v0, v11

    if-ge v3, v0, :cond_a3e

    .line 322
    aget-wide v27, v11, v3

    cmp-long v0, v27, v13

    if-gez v0, :cond_a34

    move v15, v3

    goto :goto_a3b

    :cond_a34
    add-int/lit8 v2, v2, 0x1

    .line 323
    iget v0, v6, Lk3/w;->r:I

    if-le v2, v0, :cond_a3b

    goto :goto_a3e

    :cond_a3b
    :goto_a3b
    add-int/lit8 v3, v3, 0x1

    goto :goto_a29

    :cond_a3e
    :goto_a3e
    add-int/lit8 v15, v15, 0x1

    .line 324
    aput v15, v22, v35

    .line 325
    aget v0, v17, v35

    .line 326
    :goto_a44
    aget v2, v17, v35

    if-lez v2, :cond_a55

    aget v3, v44, v2

    const/16 v18, 0x1

    and-int/lit8 v3, v3, 0x1

    if-nez v3, :cond_a57

    add-int/lit8 v2, v2, -0x1

    .line 327
    aput v2, v17, v35

    goto :goto_a44

    :cond_a55
    const/16 v18, 0x1

    :cond_a57
    const/16 v16, 0x0

    if-nez v2, :cond_a76

    .line 328
    aget v2, v44, v16

    and-int/lit8 v2, v2, 0x1

    if-nez v2, :cond_a76

    .line 329
    aput v0, v17, v35

    .line 330
    :goto_a63
    aget v0, v17, v35

    aget v2, v22, v35

    if-ge v0, v2, :cond_a76

    aget v2, v44, v0

    and-int/lit8 v2, v2, 0x1

    if-nez v2, :cond_a76

    add-int/lit8 v0, v0, 0x1

    .line 331
    aput v0, v17, v35

    const/16 v18, 0x1

    goto :goto_a63

    .line 332
    :cond_a76
    aget v0, v22, v35

    aget v2, v17, v35

    sub-int v3, v0, v2

    add-int/2addr v3, v5

    if-eq v10, v2, :cond_a81

    const/4 v2, 0x1

    goto :goto_a83

    :cond_a81
    move/from16 v2, v16

    :goto_a83
    or-int v2, v25, v2

    move v10, v0

    move v15, v2

    move v5, v3

    goto :goto_a93

    :cond_a89
    move/from16 v26, v0

    move-object/from16 v22, v13

    move/from16 v35, v14

    move/from16 v25, v15

    const/16 v16, 0x0

    :goto_a93
    add-int/lit8 v14, v35, 0x1

    move-object/from16 v13, v22

    move/from16 v0, v26

    move-object/from16 v2, v41

    move-object/from16 v3, v44

    goto/16 :goto_9f0

    :cond_a9f
    move-object/from16 v41, v2

    move-object/from16 v44, v3

    move-object/from16 v22, v13

    move/from16 v25, v15

    const/16 v16, 0x0

    if-eq v5, v4, :cond_aad

    const/4 v0, 0x1

    goto :goto_aaf

    :cond_aad
    move/from16 v0, v16

    :goto_aaf
    or-int v0, v25, v0

    if-eqz v0, :cond_ab6

    .line 333
    new-array v2, v5, [J

    goto :goto_ab7

    :cond_ab6
    move-object v2, v1

    :goto_ab7
    if-eqz v0, :cond_abc

    .line 334
    new-array v3, v5, [I

    goto :goto_abe

    :cond_abc
    move-object/from16 v3, v41

    :goto_abe
    if-eqz v0, :cond_ac2

    move/from16 v42, v16

    :cond_ac2
    if-eqz v0, :cond_ac7

    .line 335
    new-array v4, v5, [I

    goto :goto_ac9

    :cond_ac7
    move-object/from16 v4, v44

    :goto_ac9
    if-eqz v0, :cond_ad1

    .line 336
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    goto :goto_ad3

    :cond_ad1
    move-object/from16 v10, v20

    .line 337
    :goto_ad3
    new-array v5, v5, [J

    move/from16 v13, v16

    move v14, v13

    move v15, v14

    const-wide/16 v25, 0x0

    :goto_adb
    if-ge v13, v9, :cond_b72

    .line 338
    invoke-virtual {v7, v13}, Llx/b;->a(I)J

    move-result-wide v32

    move/from16 v20, v0

    .line 339
    aget v0, v17, v13

    move-object/from16 v43, v5

    .line 340
    aget v5, v22, v13

    if-eqz v20, :cond_aff

    move-object/from16 v35, v6

    sub-int v6, v5, v0

    .line 341
    invoke-static {v1, v0, v2, v15, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object/from16 v40, v1

    move-object/from16 v1, v41

    .line 342
    invoke-static {v1, v0, v3, v15, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object/from16 v1, v44

    .line 343
    invoke-static {v1, v0, v4, v15, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_b05

    :cond_aff
    move-object/from16 v40, v1

    move-object/from16 v35, v6

    move-object/from16 v1, v44

    :goto_b05
    move/from16 v6, v42

    :goto_b07
    if-ge v0, v5, :cond_b5a

    move/from16 v36, v0

    move-object/from16 v44, v1

    .line 344
    iget-wide v0, v12, Li5/u;->d:J

    .line 345
    sget-object v31, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v27, 0xf4240

    move-wide/from16 v29, v0

    invoke-static/range {v25 .. v31}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v0

    .line 346
    aget-wide v27, v11, v36

    sub-long v47, v27, v32

    const-wide/32 v49, 0xf4240

    move-wide/from16 v27, v0

    iget-wide v0, v12, Li5/u;->c:J

    move-wide/from16 v51, v0

    move-object/from16 v53, v31

    .line 347
    invoke-static/range {v47 .. v53}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v0

    const-wide/16 v23, 0x0

    cmp-long v29, v0, v23

    if-gez v29, :cond_b34

    const/4 v14, 0x1

    :cond_b34
    add-long v0, v27, v0

    .line 348
    aput-wide v0, v43, v15

    if-eqz v20, :cond_b40

    .line 349
    aget v0, v3, v15

    if-le v0, v6, :cond_b40

    .line 350
    aget v6, v41, v36

    :cond_b40
    if-eqz v20, :cond_b53

    if-nez v46, :cond_b53

    .line 351
    aget v0, v4, v15

    const/16 v18, 0x1

    and-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_b53

    .line 352
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v10, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_b53
    add-int/lit8 v15, v15, 0x1

    add-int/lit8 v0, v36, 0x1

    move-object/from16 v1, v44

    goto :goto_b07

    :cond_b5a
    move-object/from16 v44, v1

    const-wide/16 v23, 0x0

    .line 353
    invoke-virtual {v8, v13}, Llx/b;->a(I)J

    move-result-wide v0

    add-long v25, v0, v25

    add-int/lit8 v13, v13, 0x1

    move/from16 v42, v6

    move/from16 v0, v20

    move-object/from16 v6, v35

    move-object/from16 v1, v40

    move-object/from16 v5, v43

    goto/16 :goto_adb

    :cond_b72
    move-object/from16 v43, v5

    move-object/from16 v35, v6

    .line 354
    iget-wide v0, v12, Li5/u;->d:J

    .line 355
    sget-object v31, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    const-wide/32 v27, 0xf4240

    move-wide/from16 v29, v0

    invoke-static/range {v25 .. v31}, Ln3/l0;->a0(JJJLjava/math/RoundingMode;)J

    move-result-wide v47

    if-eqz v14, :cond_b9f

    .line 356
    invoke-virtual/range {v35 .. v35}, Lk3/w;->a()Lk3/v;

    move-result-object v0

    const/4 v8, 0x1

    .line 357
    iput-boolean v8, v0, Lk3/v;->u:Z

    .line 358
    new-instance v1, Lk3/w;

    invoke-direct {v1, v0}, Lk3/w;-><init>(Lk3/v;)V

    .line 359
    invoke-virtual {v12}, Li5/u;->a()Li5/t;

    move-result-object v0

    .line 360
    iput-object v1, v0, Li5/t;->g:Lk3/w;

    .line 361
    new-instance v1, Li5/u;

    invoke-direct {v1, v0}, Li5/u;-><init>(Li5/t;)V

    move-object/from16 v39, v1

    goto :goto_ba1

    :cond_b9f
    move-object/from16 v39, v12

    .line 362
    :goto_ba1
    new-instance v38, Li5/w;

    .line 363
    invoke-static {v10}, Lc7/t;->O(Ljava/util/Collection;)[I

    move-result-object v45

    array-length v0, v2

    move/from16 v49, v0

    move-object/from16 v40, v2

    move-object/from16 v41, v3

    move-object/from16 v44, v4

    invoke-direct/range {v38 .. v49}, Li5/w;-><init>(Li5/u;[J[II[J[I[IZJI)V

    move-object/from16 v9, v19

    move-object/from16 v2, v38

    .line 364
    :goto_bb7
    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_bba
    add-int/lit8 v5, v21, 0x1

    move-object/from16 v0, p0

    move-object v3, v9

    move-object/from16 v2, v34

    goto/16 :goto_a

    .line 365
    :cond_bc3
    const-string v0, "Track has no sample table size information"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lk3/v0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lk3/v0;

    move-result-object v0

    throw v0

    :cond_bcb
    move-object v9, v3

    return-object v9
.end method

.method public static k(Lo3/d;Z)Lk3/t0;
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lo3/d;->i:Ln3/x;

    .line 4
    .line 5
    const/16 v0, 0x8

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Ln3/x;->N(I)V

    .line 8
    .line 9
    .line 10
    new-instance v2, Lk3/t0;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    new-array v4, v3, [Lk3/s0;

    .line 14
    .line 15
    invoke-direct {v2, v4}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 16
    .line 17
    .line 18
    :goto_11
    invoke-virtual {v1}, Ln3/x;->a()I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    if-lt v4, v0, :cond_454

    .line 23
    .line 24
    iget v4, v1, Ln3/x;->b:I

    .line 25
    .line 26
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 31
    .line 32
    .line 33
    move-result v6

    .line 34
    const v7, 0x6d657461

    .line 35
    .line 36
    .line 37
    const/4 v11, 0x1

    .line 38
    const/4 v12, 0x0

    .line 39
    if-ne v6, v7, :cond_2df

    .line 40
    .line 41
    invoke-virtual {v1, v4}, Ln3/x;->N(I)V

    .line 42
    .line 43
    .line 44
    add-int v6, v4, v5

    .line 45
    .line 46
    invoke-virtual {v1, v0}, Ln3/x;->O(I)V

    .line 47
    .line 48
    .line 49
    invoke-static {v1}, Li5/e;->a(Ln3/x;)V

    .line 50
    .line 51
    .line 52
    :goto_33
    iget v7, v1, Ln3/x;->b:I

    .line 53
    .line 54
    if-ge v7, v6, :cond_2c1

    .line 55
    .line 56
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 57
    .line 58
    .line 59
    move-result v13

    .line 60
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 61
    .line 62
    .line 63
    move-result v14

    .line 64
    const v15, 0x696c7374

    .line 65
    .line 66
    .line 67
    if-ne v14, v15, :cond_2c9

    .line 68
    .line 69
    invoke-virtual {v1, v7}, Ln3/x;->N(I)V

    .line 70
    .line 71
    .line 72
    add-int/2addr v7, v13

    .line 73
    invoke-virtual {v1, v0}, Ln3/x;->O(I)V

    .line 74
    .line 75
    .line 76
    new-instance v6, Ljava/util/ArrayList;

    .line 77
    .line 78
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 79
    .line 80
    .line 81
    :goto_50
    iget v13, v1, Ln3/x;->b:I

    .line 82
    .line 83
    if-ge v13, v7, :cond_2bb

    .line 84
    .line 85
    const-string v14, "Skipped unknown metadata entry: "

    .line 86
    .line 87
    const-string v15, "Skipped empty metadata entry: "

    .line 88
    .line 89
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 90
    .line 91
    .line 92
    move-result v10

    .line 93
    const-string v9, "MetadataUtil"

    .line 94
    .line 95
    if-ge v10, v0, :cond_69

    .line 96
    .line 97
    const-string v10, "Skipped empty metadata entry"

    .line 98
    .line 99
    invoke-static {v9, v10}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    :goto_65
    move-object v8, v12

    .line 103
    :goto_66
    const/4 v0, -0x1

    .line 104
    goto/16 :goto_2ac

    .line 105
    .line 106
    :cond_69
    add-int/2addr v13, v10

    .line 107
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 108
    .line 109
    .line 110
    move-result v10

    .line 111
    shr-int/lit8 v8, v10, 0x18

    .line 112
    .line 113
    and-int/lit16 v8, v8, 0xff

    .line 114
    .line 115
    :try_start_72
    iget v3, v1, Ln3/x;->b:I

    .line 116
    .line 117
    sub-int v3, v13, v3

    .line 118
    .line 119
    if-ge v3, v0, :cond_92

    .line 120
    .line 121
    new-instance v3, Ljava/lang/StringBuilder;

    .line 122
    .line 123
    invoke-direct {v3, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    invoke-static {v10}, Lcz/j;->f(I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v8

    .line 130
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v3

    .line 137
    invoke-static {v9, v3}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_8b
    .catchall {:try_start_72 .. :try_end_8b} :catchall_8f

    .line 138
    .line 139
    .line 140
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 141
    .line 142
    .line 143
    goto :goto_65

    .line 144
    :catchall_8f
    move-exception v0

    .line 145
    goto/16 :goto_2b7

    .line 146
    .line 147
    :cond_92
    const/16 v3, 0xa9

    .line 148
    .line 149
    const-string v15, "TCON"

    .line 150
    .line 151
    if-eq v8, v3, :cond_9c

    .line 152
    .line 153
    const/16 v3, 0xfd

    .line 154
    .line 155
    if-ne v8, v3, :cond_9f

    .line 156
    .line 157
    :cond_9c
    const/4 v0, -0x1

    .line 158
    goto/16 :goto_1ee

    .line 159
    .line 160
    :cond_9f
    const v3, 0x676e7265

    .line 161
    .line 162
    .line 163
    if-ne v10, v3, :cond_c3

    .line 164
    .line 165
    :try_start_a4
    invoke-static {v1}, Li5/s;->f(Ln3/x;)I

    .line 166
    .line 167
    .line 168
    move-result v3

    .line 169
    sub-int/2addr v3, v11

    .line 170
    invoke-static {v3}, Lc5/k;->a(I)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v3

    .line 174
    if-eqz v3, :cond_b9

    .line 175
    .line 176
    new-instance v8, Lc5/o;

    .line 177
    .line 178
    invoke-static {v3}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    invoke-direct {v8, v15, v12, v3}, Lc5/o;-><init>(Ljava/lang/String;Ljava/lang/String;Lhx/w1;)V

    .line 183
    .line 184
    .line 185
    goto :goto_bf

    .line 186
    :cond_b9
    const-string v3, "Failed to parse standard genre code"

    .line 187
    .line 188
    invoke-static {v9, v3}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_be
    .catchall {:try_start_a4 .. :try_end_be} :catchall_8f

    .line 189
    .line 190
    .line 191
    :goto_be
    move-object v8, v12

    .line 192
    :goto_bf
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 193
    .line 194
    .line 195
    goto :goto_66

    .line 196
    :cond_c3
    const v3, 0x6469736b

    .line 197
    .line 198
    .line 199
    if-ne v10, v3, :cond_cf

    .line 200
    .line 201
    :try_start_c8
    const-string v3, "TPOS"

    .line 202
    .line 203
    invoke-static {v10, v3, v1}, Li5/s;->e(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 204
    .line 205
    .line 206
    move-result-object v8

    .line 207
    goto :goto_bf

    .line 208
    :cond_cf
    const v3, 0x74726b6e

    .line 209
    .line 210
    .line 211
    if-ne v10, v3, :cond_db

    .line 212
    .line 213
    const-string v3, "TRCK"

    .line 214
    .line 215
    invoke-static {v10, v3, v1}, Li5/s;->e(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 216
    .line 217
    .line 218
    move-result-object v8

    .line 219
    goto :goto_bf

    .line 220
    :cond_db
    const v3, 0x746d706f

    .line 221
    .line 222
    .line 223
    if-ne v10, v3, :cond_ed

    .line 224
    .line 225
    const-string v3, "TBPM"

    .line 226
    .line 227
    const/4 v8, 0x0

    .line 228
    invoke-static {v10, v3, v1, v11, v8}, Li5/s;->g(ILjava/lang/String;Ln3/x;ZZ)Lc5/j;

    .line 229
    .line 230
    .line 231
    move-result-object v3
    :try_end_e7
    .catchall {:try_start_c8 .. :try_end_e7} :catchall_8f

    .line 232
    :goto_e7
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 233
    .line 234
    .line 235
    move-object v8, v3

    .line 236
    goto/16 :goto_66

    .line 237
    .line 238
    :cond_ed
    const v3, 0x6370696c

    .line 239
    .line 240
    .line 241
    if-ne v10, v3, :cond_f9

    .line 242
    .line 243
    :try_start_f2
    const-string v3, "TCMP"

    .line 244
    .line 245
    invoke-static {v10, v3, v1, v11, v11}, Li5/s;->g(ILjava/lang/String;Ln3/x;ZZ)Lc5/j;

    .line 246
    .line 247
    .line 248
    move-result-object v8

    .line 249
    goto :goto_bf

    .line 250
    :cond_f9
    const v3, 0x636f7672

    .line 251
    .line 252
    .line 253
    if-ne v10, v3, :cond_107

    .line 254
    .line 255
    if-eqz p1, :cond_101

    .line 256
    .line 257
    goto :goto_be

    .line 258
    :cond_101
    invoke-static {v1}, Li5/s;->d(Ln3/x;)Lc5/a;

    .line 259
    .line 260
    .line 261
    move-result-object v3

    .line 262
    move-object v8, v3

    .line 263
    goto :goto_bf

    .line 264
    :cond_107
    const v3, 0x61415254

    .line 265
    .line 266
    .line 267
    if-ne v10, v3, :cond_113

    .line 268
    .line 269
    const-string v3, "TPE2"

    .line 270
    .line 271
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 272
    .line 273
    .line 274
    move-result-object v8

    .line 275
    goto :goto_bf

    .line 276
    :cond_113
    const v3, 0x736f6e6d

    .line 277
    .line 278
    .line 279
    if-ne v10, v3, :cond_11f

    .line 280
    .line 281
    const-string v3, "TSOT"

    .line 282
    .line 283
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 284
    .line 285
    .line 286
    move-result-object v8

    .line 287
    goto :goto_bf

    .line 288
    :cond_11f
    const v3, 0x736f616c

    .line 289
    .line 290
    .line 291
    if-ne v10, v3, :cond_12b

    .line 292
    .line 293
    const-string v3, "TSOA"

    .line 294
    .line 295
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 296
    .line 297
    .line 298
    move-result-object v8

    .line 299
    goto :goto_bf

    .line 300
    :cond_12b
    const v3, 0x736f6172

    .line 301
    .line 302
    .line 303
    if-ne v10, v3, :cond_137

    .line 304
    .line 305
    const-string v3, "TSOP"

    .line 306
    .line 307
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 308
    .line 309
    .line 310
    move-result-object v8

    .line 311
    goto :goto_bf

    .line 312
    :cond_137
    const v3, 0x736f6161

    .line 313
    .line 314
    .line 315
    if-ne v10, v3, :cond_144

    .line 316
    .line 317
    const-string v3, "TSO2"

    .line 318
    .line 319
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 320
    .line 321
    .line 322
    move-result-object v8

    .line 323
    goto/16 :goto_bf

    .line 324
    .line 325
    :cond_144
    const v3, 0x736f636f

    .line 326
    .line 327
    .line 328
    if-ne v10, v3, :cond_151

    .line 329
    .line 330
    const-string v3, "TSOC"

    .line 331
    .line 332
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 333
    .line 334
    .line 335
    move-result-object v8

    .line 336
    goto/16 :goto_bf

    .line 337
    .line 338
    :cond_151
    const v3, 0x72746e67

    .line 339
    .line 340
    .line 341
    if-ne v10, v3, :cond_15e

    .line 342
    .line 343
    const-string v3, "ITUNESADVISORY"

    .line 344
    .line 345
    const/4 v8, 0x0

    .line 346
    invoke-static {v10, v3, v1, v8, v8}, Li5/s;->g(ILjava/lang/String;Ln3/x;ZZ)Lc5/j;

    .line 347
    .line 348
    .line 349
    move-result-object v3

    .line 350
    goto :goto_e7

    .line 351
    :cond_15e
    const v3, 0x70676170

    .line 352
    .line 353
    .line 354
    if-ne v10, v3, :cond_16c

    .line 355
    .line 356
    const-string v3, "ITUNESGAPLESS"

    .line 357
    .line 358
    const/4 v8, 0x0

    .line 359
    invoke-static {v10, v3, v1, v8, v11}, Li5/s;->g(ILjava/lang/String;Ln3/x;ZZ)Lc5/j;

    .line 360
    .line 361
    .line 362
    move-result-object v3

    .line 363
    goto/16 :goto_e7

    .line 364
    .line 365
    :cond_16c
    const v3, 0x736f736e

    .line 366
    .line 367
    .line 368
    if-ne v10, v3, :cond_179

    .line 369
    .line 370
    const-string v3, "TVSHOWSORT"

    .line 371
    .line 372
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 373
    .line 374
    .line 375
    move-result-object v8

    .line 376
    goto/16 :goto_bf

    .line 377
    .line 378
    :cond_179
    const v3, 0x74767368

    .line 379
    .line 380
    .line 381
    if-ne v10, v3, :cond_186

    .line 382
    .line 383
    const-string v3, "TVSHOW"

    .line 384
    .line 385
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 386
    .line 387
    .line 388
    move-result-object v8

    .line 389
    goto/16 :goto_bf

    .line 390
    .line 391
    :cond_186
    const v3, 0x2d2d2d2d

    .line 392
    .line 393
    .line 394
    if-ne v10, v3, :cond_1eb

    .line 395
    .line 396
    move-object v3, v12

    .line 397
    move-object v8, v3

    .line 398
    const/4 v9, -0x1

    .line 399
    const/4 v10, -0x1

    .line 400
    :goto_18f
    iget v14, v1, Ln3/x;->b:I

    .line 401
    .line 402
    if-ge v14, v13, :cond_1c7

    .line 403
    .line 404
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 405
    .line 406
    .line 407
    move-result v15

    .line 408
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 409
    .line 410
    .line 411
    move-result v12

    .line 412
    const/4 v0, 0x4

    .line 413
    invoke-virtual {v1, v0}, Ln3/x;->O(I)V

    .line 414
    .line 415
    .line 416
    const v0, 0x6d65616e

    .line 417
    .line 418
    .line 419
    if-ne v12, v0, :cond_1ab

    .line 420
    .line 421
    add-int/lit8 v15, v15, -0xc

    .line 422
    .line 423
    invoke-virtual {v1, v15}, Ln3/x;->w(I)Ljava/lang/String;

    .line 424
    .line 425
    .line 426
    move-result-object v3

    .line 427
    goto :goto_1c3

    .line 428
    :cond_1ab
    const v0, 0x6e616d65

    .line 429
    .line 430
    .line 431
    if-ne v12, v0, :cond_1b7

    .line 432
    .line 433
    add-int/lit8 v15, v15, -0xc

    .line 434
    .line 435
    invoke-virtual {v1, v15}, Ln3/x;->w(I)Ljava/lang/String;

    .line 436
    .line 437
    .line 438
    move-result-object v8

    .line 439
    goto :goto_1c3

    .line 440
    :cond_1b7
    const v0, 0x64617461

    .line 441
    .line 442
    .line 443
    if-ne v12, v0, :cond_1be

    .line 444
    .line 445
    move v9, v14

    .line 446
    move v10, v15

    .line 447
    :cond_1be
    add-int/lit8 v15, v15, -0xc

    .line 448
    .line 449
    invoke-virtual {v1, v15}, Ln3/x;->O(I)V

    .line 450
    .line 451
    .line 452
    :goto_1c3
    const/16 v0, 0x8

    .line 453
    .line 454
    const/4 v12, 0x0

    .line 455
    goto :goto_18f

    .line 456
    :cond_1c7
    if-eqz v3, :cond_1e4

    .line 457
    .line 458
    if-eqz v8, :cond_1e4

    .line 459
    .line 460
    const/4 v0, -0x1

    .line 461
    if-ne v9, v0, :cond_1cf

    .line 462
    .line 463
    goto :goto_1e5

    .line 464
    :cond_1cf
    invoke-virtual {v1, v9}, Ln3/x;->N(I)V

    .line 465
    .line 466
    .line 467
    const/16 v9, 0x10

    .line 468
    .line 469
    invoke-virtual {v1, v9}, Ln3/x;->O(I)V

    .line 470
    .line 471
    .line 472
    add-int/lit8 v10, v10, -0x10

    .line 473
    .line 474
    invoke-virtual {v1, v10}, Ln3/x;->w(I)Ljava/lang/String;

    .line 475
    .line 476
    .line 477
    move-result-object v9

    .line 478
    new-instance v10, Lc5/l;

    .line 479
    .line 480
    invoke-direct {v10, v3, v8, v9}, Lc5/l;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1e2
    .catchall {:try_start_f2 .. :try_end_1e2} :catchall_8f

    .line 481
    .line 482
    .line 483
    move-object v8, v10

    .line 484
    goto :goto_1e6

    .line 485
    :cond_1e4
    const/4 v0, -0x1

    .line 486
    :goto_1e5
    const/4 v8, 0x0

    .line 487
    :goto_1e6
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 488
    .line 489
    .line 490
    goto/16 :goto_2ac

    .line 491
    .line 492
    :cond_1eb
    const/4 v0, -0x1

    .line 493
    goto/16 :goto_284

    .line 494
    .line 495
    :goto_1ee
    const v3, 0xffffff

    .line 496
    .line 497
    .line 498
    and-int/2addr v3, v10

    .line 499
    const v8, 0x636d74

    .line 500
    .line 501
    .line 502
    if-ne v3, v8, :cond_1fc

    .line 503
    .line 504
    :try_start_1f7
    invoke-static {v10, v1}, Li5/s;->c(ILn3/x;)Lc5/e;

    .line 505
    .line 506
    .line 507
    move-result-object v8

    .line 508
    goto :goto_1e6

    .line 509
    :cond_1fc
    const v8, 0x6e616d

    .line 510
    .line 511
    .line 512
    if-eq v3, v8, :cond_2a4

    .line 513
    .line 514
    const v8, 0x74726b

    .line 515
    .line 516
    .line 517
    if-ne v3, v8, :cond_208

    .line 518
    .line 519
    goto/16 :goto_2a4

    .line 520
    .line 521
    :cond_208
    const v8, 0x636f6d

    .line 522
    .line 523
    .line 524
    if-eq v3, v8, :cond_29c

    .line 525
    .line 526
    const v8, 0x777274

    .line 527
    .line 528
    .line 529
    if-ne v3, v8, :cond_214

    .line 530
    .line 531
    goto/16 :goto_29c

    .line 532
    .line 533
    :cond_214
    const v8, 0x646179

    .line 534
    .line 535
    .line 536
    if-ne v3, v8, :cond_220

    .line 537
    .line 538
    const-string v3, "TDRC"

    .line 539
    .line 540
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 541
    .line 542
    .line 543
    move-result-object v8

    .line 544
    goto :goto_1e6

    .line 545
    :cond_220
    const v8, 0x415254

    .line 546
    .line 547
    .line 548
    if-ne v3, v8, :cond_22c

    .line 549
    .line 550
    const-string v3, "TPE1"

    .line 551
    .line 552
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 553
    .line 554
    .line 555
    move-result-object v8

    .line 556
    goto :goto_1e6

    .line 557
    :cond_22c
    const v8, 0x746f6f

    .line 558
    .line 559
    .line 560
    if-ne v3, v8, :cond_238

    .line 561
    .line 562
    const-string v3, "TSSE"

    .line 563
    .line 564
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 565
    .line 566
    .line 567
    move-result-object v8

    .line 568
    goto :goto_1e6

    .line 569
    :cond_238
    const v8, 0x616c62

    .line 570
    .line 571
    .line 572
    if-ne v3, v8, :cond_244

    .line 573
    .line 574
    const-string v3, "TALB"

    .line 575
    .line 576
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 577
    .line 578
    .line 579
    move-result-object v8

    .line 580
    goto :goto_1e6

    .line 581
    :cond_244
    const v8, 0x6c7972

    .line 582
    .line 583
    .line 584
    if-ne v3, v8, :cond_250

    .line 585
    .line 586
    const-string v3, "USLT"

    .line 587
    .line 588
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 589
    .line 590
    .line 591
    move-result-object v8

    .line 592
    goto :goto_1e6

    .line 593
    :cond_250
    const v8, 0x67656e

    .line 594
    .line 595
    .line 596
    if-ne v3, v8, :cond_25a

    .line 597
    .line 598
    invoke-static {v10, v15, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 599
    .line 600
    .line 601
    move-result-object v8

    .line 602
    goto :goto_1e6

    .line 603
    :cond_25a
    const v8, 0x677270

    .line 604
    .line 605
    .line 606
    if-ne v3, v8, :cond_266

    .line 607
    .line 608
    const-string v3, "TIT1"

    .line 609
    .line 610
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 611
    .line 612
    .line 613
    move-result-object v8

    .line 614
    goto :goto_1e6

    .line 615
    :cond_266
    const v8, 0x6d766e

    .line 616
    .line 617
    .line 618
    if-ne v3, v8, :cond_273

    .line 619
    .line 620
    const-string v3, "MVNM"

    .line 621
    .line 622
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 623
    .line 624
    .line 625
    move-result-object v8

    .line 626
    goto/16 :goto_1e6

    .line 627
    .line 628
    :cond_273
    const v8, 0x6d7669

    .line 629
    .line 630
    .line 631
    if-ne v3, v8, :cond_284

    .line 632
    .line 633
    const-string v3, "MVIN"

    .line 634
    .line 635
    const/4 v8, 0x0

    .line 636
    invoke-static {v10, v3, v1, v11, v8}, Li5/s;->g(ILjava/lang/String;Ln3/x;ZZ)Lc5/j;

    .line 637
    .line 638
    .line 639
    move-result-object v3
    :try_end_27f
    .catchall {:try_start_1f7 .. :try_end_27f} :catchall_8f

    .line 640
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 641
    .line 642
    .line 643
    move-object v8, v3

    .line 644
    goto :goto_2ac

    .line 645
    :cond_284
    :goto_284
    :try_start_284
    new-instance v3, Ljava/lang/StringBuilder;

    .line 646
    .line 647
    invoke-direct {v3, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 648
    .line 649
    .line 650
    invoke-static {v10}, Lcz/j;->f(I)Ljava/lang/String;

    .line 651
    .line 652
    .line 653
    move-result-object v8

    .line 654
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 655
    .line 656
    .line 657
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 658
    .line 659
    .line 660
    move-result-object v3

    .line 661
    invoke-static {v9, v3}, Ln3/b;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_297
    .catchall {:try_start_284 .. :try_end_297} :catchall_8f

    .line 662
    .line 663
    .line 664
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 665
    .line 666
    .line 667
    const/4 v8, 0x0

    .line 668
    goto :goto_2ac

    .line 669
    :cond_29c
    :goto_29c
    :try_start_29c
    const-string v3, "TCOM"

    .line 670
    .line 671
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 672
    .line 673
    .line 674
    move-result-object v8

    .line 675
    goto/16 :goto_1e6

    .line 676
    .line 677
    :cond_2a4
    :goto_2a4
    const-string v3, "TIT2"

    .line 678
    .line 679
    invoke-static {v10, v3, v1}, Li5/s;->j(ILjava/lang/String;Ln3/x;)Lc5/o;

    .line 680
    .line 681
    .line 682
    move-result-object v8
    :try_end_2aa
    .catchall {:try_start_29c .. :try_end_2aa} :catchall_8f

    .line 683
    goto/16 :goto_1e6

    .line 684
    .line 685
    :goto_2ac
    if-eqz v8, :cond_2b1

    .line 686
    .line 687
    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 688
    .line 689
    .line 690
    :cond_2b1
    const/16 v0, 0x8

    .line 691
    .line 692
    const/4 v3, 0x0

    .line 693
    const/4 v12, 0x0

    .line 694
    goto/16 :goto_50

    .line 695
    .line 696
    :goto_2b7
    invoke-virtual {v1, v13}, Ln3/x;->N(I)V

    .line 697
    .line 698
    .line 699
    throw v0

    .line 700
    :cond_2bb
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    .line 701
    .line 702
    .line 703
    move-result v0

    .line 704
    if-eqz v0, :cond_2c3

    .line 705
    .line 706
    :cond_2c1
    const/4 v12, 0x0

    .line 707
    goto :goto_2d4

    .line 708
    :cond_2c3
    new-instance v12, Lk3/t0;

    .line 709
    .line 710
    invoke-direct {v12, v6}, Lk3/t0;-><init>(Ljava/util/List;)V

    .line 711
    .line 712
    .line 713
    goto :goto_2d4

    .line 714
    :cond_2c9
    const/4 v0, -0x1

    .line 715
    add-int/2addr v7, v13

    .line 716
    invoke-virtual {v1, v7}, Ln3/x;->N(I)V

    .line 717
    .line 718
    .line 719
    const/16 v0, 0x8

    .line 720
    .line 721
    const/4 v3, 0x0

    .line 722
    const/4 v12, 0x0

    .line 723
    goto/16 :goto_33

    .line 724
    .line 725
    :goto_2d4
    invoke-virtual {v2, v12}, Lk3/t0;->b(Lk3/t0;)Lk3/t0;

    .line 726
    .line 727
    .line 728
    move-result-object v0

    .line 729
    move-object v2, v0

    .line 730
    const/16 v13, 0x8

    .line 731
    .line 732
    :goto_2db
    const/16 v16, 0x0

    .line 733
    .line 734
    goto/16 :goto_44b

    .line 735
    .line 736
    :cond_2df
    const/4 v0, -0x1

    .line 737
    const v3, 0x736d7461

    .line 738
    .line 739
    .line 740
    const/4 v7, 0x2

    .line 741
    if-ne v6, v3, :cond_38b

    .line 742
    .line 743
    invoke-virtual {v1, v4}, Ln3/x;->N(I)V

    .line 744
    .line 745
    .line 746
    add-int v3, v4, v5

    .line 747
    .line 748
    const/16 v6, 0xc

    .line 749
    .line 750
    invoke-virtual {v1, v6}, Ln3/x;->O(I)V

    .line 751
    .line 752
    .line 753
    :goto_2f0
    iget v8, v1, Ln3/x;->b:I

    .line 754
    .line 755
    if-ge v8, v3, :cond_381

    .line 756
    .line 757
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 758
    .line 759
    .line 760
    move-result v9

    .line 761
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 762
    .line 763
    .line 764
    move-result v10

    .line 765
    const v12, 0x73617574

    .line 766
    .line 767
    .line 768
    if-ne v10, v12, :cond_376

    .line 769
    .line 770
    const/16 v10, 0x10

    .line 771
    .line 772
    if-ge v9, v10, :cond_30a

    .line 773
    .line 774
    const/4 v12, 0x0

    .line 775
    const/16 v13, 0x8

    .line 776
    .line 777
    goto/16 :goto_384

    .line 778
    .line 779
    :cond_30a
    const/4 v12, 0x4

    .line 780
    invoke-virtual {v1, v12}, Ln3/x;->O(I)V

    .line 781
    .line 782
    .line 783
    move v9, v0

    .line 784
    const/4 v0, 0x0

    .line 785
    const/4 v8, 0x0

    .line 786
    :goto_311
    if-ge v0, v7, :cond_325

    .line 787
    .line 788
    invoke-virtual {v1}, Ln3/x;->A()I

    .line 789
    .line 790
    .line 791
    move-result v10

    .line 792
    invoke-virtual {v1}, Ln3/x;->A()I

    .line 793
    .line 794
    .line 795
    move-result v12

    .line 796
    if-nez v10, :cond_31f

    .line 797
    .line 798
    move v9, v12

    .line 799
    goto :goto_322

    .line 800
    :cond_31f
    if-ne v10, v11, :cond_322

    .line 801
    .line 802
    move v8, v12

    .line 803
    :cond_322
    :goto_322
    add-int/lit8 v0, v0, 0x1

    .line 804
    .line 805
    goto :goto_311

    .line 806
    :cond_325
    const v0, -0x7fffffff

    .line 807
    .line 808
    .line 809
    if-ne v9, v6, :cond_32f

    .line 810
    .line 811
    const/16 v3, 0xf0

    .line 812
    .line 813
    :goto_32c
    const/16 v13, 0x8

    .line 814
    .line 815
    goto :goto_360

    .line 816
    :cond_32f
    const/16 v7, 0xd

    .line 817
    .line 818
    if-ne v9, v7, :cond_336

    .line 819
    .line 820
    const/16 v3, 0x78

    .line 821
    .line 822
    goto :goto_32c

    .line 823
    :cond_336
    const/16 v7, 0x15

    .line 824
    .line 825
    if-eq v9, v7, :cond_33c

    .line 826
    .line 827
    move v3, v0

    .line 828
    goto :goto_32c

    .line 829
    :cond_33c
    invoke-virtual {v1}, Ln3/x;->a()I

    .line 830
    .line 831
    .line 832
    move-result v7

    .line 833
    const/16 v13, 0x8

    .line 834
    .line 835
    if-lt v7, v13, :cond_35f

    .line 836
    .line 837
    iget v7, v1, Ln3/x;->b:I

    .line 838
    .line 839
    add-int/2addr v7, v13

    .line 840
    if-le v7, v3, :cond_34a

    .line 841
    .line 842
    goto :goto_35f

    .line 843
    :cond_34a
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 844
    .line 845
    .line 846
    move-result v3

    .line 847
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 848
    .line 849
    .line 850
    move-result v7

    .line 851
    if-lt v3, v6, :cond_35f

    .line 852
    .line 853
    const v3, 0x73726672

    .line 854
    .line 855
    .line 856
    if-eq v7, v3, :cond_35a

    .line 857
    .line 858
    goto :goto_35f

    .line 859
    :cond_35a
    invoke-virtual {v1}, Ln3/x;->B()I

    .line 860
    .line 861
    .line 862
    move-result v3

    .line 863
    goto :goto_360

    .line 864
    :cond_35f
    :goto_35f
    move v3, v0

    .line 865
    :goto_360
    if-ne v3, v0, :cond_364

    .line 866
    .line 867
    :goto_362
    const/4 v12, 0x0

    .line 868
    goto :goto_384

    .line 869
    :cond_364
    new-instance v12, Lk3/t0;

    .line 870
    .line 871
    new-instance v0, Ld5/c;

    .line 872
    .line 873
    int-to-float v3, v3

    .line 874
    invoke-direct {v0, v3, v8}, Ld5/c;-><init>(FI)V

    .line 875
    .line 876
    .line 877
    new-array v3, v11, [Lk3/s0;

    .line 878
    .line 879
    const/16 v16, 0x0

    .line 880
    .line 881
    aput-object v0, v3, v16

    .line 882
    .line 883
    invoke-direct {v12, v3}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 884
    .line 885
    .line 886
    goto :goto_384

    .line 887
    :cond_376
    const/16 v10, 0x10

    .line 888
    .line 889
    const/4 v12, 0x4

    .line 890
    const/16 v13, 0x8

    .line 891
    .line 892
    add-int/2addr v8, v9

    .line 893
    invoke-virtual {v1, v8}, Ln3/x;->N(I)V

    .line 894
    .line 895
    .line 896
    goto/16 :goto_2f0

    .line 897
    .line 898
    :cond_381
    const/16 v13, 0x8

    .line 899
    .line 900
    goto :goto_362

    .line 901
    :goto_384
    invoke-virtual {v2, v12}, Lk3/t0;->b(Lk3/t0;)Lk3/t0;

    .line 902
    .line 903
    .line 904
    move-result-object v0

    .line 905
    move-object v2, v0

    .line 906
    goto/16 :goto_2db

    .line 907
    .line 908
    :cond_38b
    const/16 v13, 0x8

    .line 909
    .line 910
    const v0, -0x56878686

    .line 911
    .line 912
    .line 913
    if-ne v6, v0, :cond_3e3

    .line 914
    .line 915
    invoke-virtual {v1}, Ln3/x;->x()S

    .line 916
    .line 917
    .line 918
    move-result v0

    .line 919
    invoke-virtual {v1, v7}, Ln3/x;->O(I)V

    .line 920
    .line 921
    .line 922
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 923
    .line 924
    invoke-virtual {v1, v0, v3}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 925
    .line 926
    .line 927
    move-result-object v0

    .line 928
    const/16 v3, 0x2b

    .line 929
    .line 930
    invoke-virtual {v0, v3}, Ljava/lang/String;->lastIndexOf(I)I

    .line 931
    .line 932
    .line 933
    move-result v3

    .line 934
    const/16 v6, 0x2d

    .line 935
    .line 936
    invoke-virtual {v0, v6}, Ljava/lang/String;->lastIndexOf(I)I

    .line 937
    .line 938
    .line 939
    move-result v6

    .line 940
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    .line 941
    .line 942
    .line 943
    move-result v3

    .line 944
    const/4 v8, 0x0

    .line 945
    :try_start_3b0
    invoke-virtual {v0, v8, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 946
    .line 947
    .line 948
    move-result-object v6
    :try_end_3b4
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_3b0 .. :try_end_3b4} :catch_3da
    .catch Ljava/lang/NumberFormatException; {:try_start_3b0 .. :try_end_3b4} :catch_3da

    .line 949
    :try_start_3b4
    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 950
    .line 951
    .line 952
    move-result v6

    .line 953
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 954
    .line 955
    .line 956
    move-result v7

    .line 957
    sub-int/2addr v7, v11

    .line 958
    invoke-virtual {v0, v3, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 959
    .line 960
    .line 961
    move-result-object v0

    .line 962
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 963
    .line 964
    .line 965
    move-result v0

    .line 966
    new-instance v3, Lk3/t0;

    .line 967
    .line 968
    new-instance v7, Lo3/e;

    .line 969
    .line 970
    invoke-direct {v7, v6, v0}, Lo3/e;-><init>(FF)V

    .line 971
    .line 972
    .line 973
    new-array v0, v11, [Lk3/s0;
    :try_end_3ce
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_3b4 .. :try_end_3ce} :catch_3d7
    .catch Ljava/lang/NumberFormatException; {:try_start_3b4 .. :try_end_3ce} :catch_3d7

    .line 974
    .line 975
    const/16 v16, 0x0

    .line 976
    .line 977
    :try_start_3d0
    aput-object v7, v0, v16

    .line 978
    .line 979
    invoke-direct {v3, v0}, Lk3/t0;-><init>([Lk3/s0;)V
    :try_end_3d5
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_3d0 .. :try_end_3d5} :catch_3dc
    .catch Ljava/lang/NumberFormatException; {:try_start_3d0 .. :try_end_3d5} :catch_3dc

    .line 980
    .line 981
    .line 982
    move-object v12, v3

    .line 983
    goto :goto_3dd

    .line 984
    :catch_3d7
    const/16 v16, 0x0

    .line 985
    .line 986
    goto :goto_3dc

    .line 987
    :catch_3da
    move/from16 v16, v8

    .line 988
    .line 989
    :catch_3dc
    :goto_3dc
    const/4 v12, 0x0

    .line 990
    :goto_3dd
    invoke-virtual {v2, v12}, Lk3/t0;->b(Lk3/t0;)Lk3/t0;

    .line 991
    .line 992
    .line 993
    move-result-object v0

    .line 994
    :goto_3e1
    move-object v2, v0

    .line 995
    goto :goto_44b

    .line 996
    :cond_3e3
    const/16 v16, 0x0

    .line 997
    .line 998
    const v0, 0x6368706c

    .line 999
    .line 1000
    .line 1001
    if-ne v6, v0, :cond_44b

    .line 1002
    .line 1003
    const/4 v0, 0x5

    .line 1004
    :try_start_3eb
    invoke-virtual {v1, v0}, Ln3/x;->O(I)V

    .line 1005
    .line 1006
    .line 1007
    invoke-virtual {v1}, Ln3/x;->m()I

    .line 1008
    .line 1009
    .line 1010
    move-result v0

    .line 1011
    new-instance v3, Ljava/util/ArrayList;

    .line 1012
    .line 1013
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1014
    .line 1015
    .line 1016
    move/from16 v8, v16

    .line 1017
    .line 1018
    :goto_3f9
    if-ge v8, v0, :cond_437

    .line 1019
    .line 1020
    invoke-virtual {v1}, Ln3/x;->u()J

    .line 1021
    .line 1022
    .line 1023
    move-result-wide v6

    .line 1024
    const-wide/16 v9, 0x2710

    .line 1025
    .line 1026
    div-long/2addr v6, v9

    .line 1027
    const-wide/16 v9, 0x0

    .line 1028
    .line 1029
    cmp-long v9, v6, v9

    .line 1030
    .line 1031
    if-gez v9, :cond_40d

    .line 1032
    .line 1033
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    :cond_40d
    move-wide/from16 v18, v6

    .line 1039
    .line 1040
    invoke-virtual {v1}, Ln3/x;->A()I

    .line 1041
    .line 1042
    .line 1043
    move-result v6

    .line 1044
    sget-object v7, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 1045
    .line 1046
    invoke-virtual {v1, v6, v7}, Ln3/x;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 1047
    .line 1048
    .line 1049
    move-result-object v6

    .line 1050
    new-instance v7, Lk3/z;
    :try_end_41b
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_3eb .. :try_end_41b} :catch_435

    .line 1051
    .line 1052
    const/4 v9, 0x0

    .line 1053
    :try_start_41c
    invoke-direct {v7, v9, v6}, Lk3/z;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1054
    .line 1055
    .line 1056
    new-instance v17, Lx4/b;

    .line 1057
    .line 1058
    const/16 v22, 0x0

    .line 1059
    .line 1060
    const-wide v20, -0x7fffffffffffffffL    # -4.9E-324

    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    move-object/from16 v23, v7

    .line 1066
    .line 1067
    invoke-direct/range {v17 .. v23}, Lx4/b;-><init>(JJZLk3/z;)V

    .line 1068
    .line 1069
    .line 1070
    move-object/from16 v6, v17

    .line 1071
    .line 1072
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1073
    .line 1074
    .line 1075
    add-int/lit8 v8, v8, 0x1

    .line 1076
    .line 1077
    goto :goto_3f9

    .line 1078
    :catch_435
    const/4 v9, 0x0

    .line 1079
    goto :goto_43e

    .line 1080
    :cond_437
    const/4 v9, 0x0

    .line 1081
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1082
    .line 1083
    .line 1084
    move-result v0

    .line 1085
    if-eqz v0, :cond_440

    .line 1086
    .line 1087
    :catch_43e
    :goto_43e
    move-object v12, v9

    .line 1088
    goto :goto_446

    .line 1089
    :cond_440
    new-instance v0, Lk3/t0;

    .line 1090
    .line 1091
    invoke-direct {v0, v3}, Lk3/t0;-><init>(Ljava/util/List;)V
    :try_end_445
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_41c .. :try_end_445} :catch_43e

    .line 1092
    .line 1093
    .line 1094
    move-object v12, v0

    .line 1095
    :goto_446
    invoke-virtual {v2, v12}, Lk3/t0;->b(Lk3/t0;)Lk3/t0;

    .line 1096
    .line 1097
    .line 1098
    move-result-object v0

    .line 1099
    goto :goto_3e1

    .line 1100
    :cond_44b
    :goto_44b
    add-int/2addr v4, v5

    .line 1101
    invoke-virtual {v1, v4}, Ln3/x;->N(I)V

    .line 1102
    .line 1103
    .line 1104
    move v0, v13

    .line 1105
    move/from16 v3, v16

    .line 1106
    .line 1107
    goto/16 :goto_11

    .line 1108
    .line 1109
    :cond_454
    return-object v2
.end method
