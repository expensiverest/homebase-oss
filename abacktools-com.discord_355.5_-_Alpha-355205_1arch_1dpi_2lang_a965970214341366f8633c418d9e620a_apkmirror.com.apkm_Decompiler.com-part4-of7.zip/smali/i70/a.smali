###### Class i70.a (i70.a)
.class public interface abstract Li70/a;
.super Ljava/lang/Object;
.source "SourceFile"
