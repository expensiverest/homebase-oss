###### Class i70.b (i70.b)
.class public final Li70/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz60/j;
.implements Lz60/b2;


# instance fields
.field public final d:Lz60/k;

.field public final synthetic e:Li70/c;


# direct methods
.method public constructor <init>(Li70/c;Lz60/k;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li70/b;->e:Li70/c;

    .line 5
    .line 6
    iput-object p2, p0, Li70/b;->d:Lz60/k;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Le70/s;I)V
    .registers 4

    .line 1
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, Lz60/k;->a(Le70/s;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final getContext()Lq30/h;
    .registers 2

    .line 1
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 2
    .line 3
    iget-object v0, v0, Lz60/k;->w:Lq30/h;

    .line 4
    .line 5
    return-object v0
.end method

.method public final isCancelled()Z
    .registers 2

    .line 1
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 2
    .line 3
    invoke-virtual {v0}, Lz60/k;->isCancelled()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final k(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V
    .registers 4

    .line 1
    check-cast p2, Ll30/a0;

    .line 2
    .line 3
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, Lz60/k;->k(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final m(Ljava/lang/Object;La40/a;)La6/q0;
    .registers 5

    .line 1
    check-cast p1, Ll30/a0;

    .line 2
    .line 3
    new-instance p2, Lde/c;

    .line 4
    .line 5
    iget-object v0, p0, Li70/b;->e:Li70/c;

    .line 6
    .line 7
    invoke-direct {p2, v0, p0}, Lde/c;-><init>(Li70/c;Li70/b;)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Li70/b;->d:Lz60/k;

    .line 11
    .line 12
    invoke-virtual {v1, p1, p2}, Lz60/k;->F(Ljava/lang/Object;La40/a;)La6/q0;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    if-eqz p1, :cond_17

    .line 17
    .line 18
    sget-object p2, Li70/c;->g:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {p2, v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    return-object p1
.end method

.method public final o(Ljava/lang/Throwable;)Z
    .registers 3

    .line 1
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lz60/k;->o(Ljava/lang/Throwable;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final q(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lz60/k;->q(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final resumeWith(Ljava/lang/Object;)V
    .registers 3

    .line 1
    iget-object v0, p0, Li70/b;->d:Lz60/k;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lz60/k;->resumeWith(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
