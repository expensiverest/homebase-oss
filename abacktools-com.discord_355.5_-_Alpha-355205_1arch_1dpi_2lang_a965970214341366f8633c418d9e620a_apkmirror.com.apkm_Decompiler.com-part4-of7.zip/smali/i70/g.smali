###### Class i70.g (i70.g)
.class public Li70/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field public static final synthetic c:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field public static final synthetic d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field public static final synthetic e:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field public static final synthetic f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field private volatile synthetic _availablePermits$volatile:I

.field public final a:Lde/c;

.field private volatile synthetic deqIdx$volatile:J

.field private volatile synthetic enqIdx$volatile:J

.field private volatile synthetic head$volatile:Ljava/lang/Object;

.field private volatile synthetic tail$volatile:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const-string v0, "head$volatile"

    .line 2
    .line 3
    const-class v1, Li70/g;

    .line 4
    .line 5
    const-class v2, Ljava/lang/Object;

    .line 6
    .line 7
    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Li70/g;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 12
    .line 13
    const-string v0, "deqIdx$volatile"

    .line 14
    .line 15
    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, Li70/g;->c:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 20
    .line 21
    const-string v0, "tail$volatile"

    .line 22
    .line 23
    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sput-object v0, Li70/g;->d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 28
    .line 29
    const-string v0, "enqIdx$volatile"

    .line 30
    .line 31
    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    sput-object v0, Li70/g;->e:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 36
    .line 37
    const-string v0, "_availablePermits$volatile"

    .line 38
    .line 39
    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sput-object v0, Li70/g;->f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 44
    .line 45
    return-void
.end method

.method public constructor <init>()V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Li70/i;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    const/4 v2, 0x2

    .line 8
    const-wide/16 v3, 0x0

    .line 9
    .line 10
    invoke-direct {v0, v3, v4, v1, v2}, Li70/i;-><init>(JLi70/i;I)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Li70/g;->head$volatile:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object v0, p0, Li70/g;->tail$volatile:Ljava/lang/Object;

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    iput v0, p0, Li70/g;->_availablePermits$volatile:I

    .line 19
    .line 20
    new-instance v0, Lde/c;

    .line 21
    .line 22
    const/4 v1, 0x2

    .line 23
    invoke-direct {v0, v1, p0}, Lde/c;-><init>(ILjava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, Li70/g;->a:Lde/c;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final a(Li70/b;)V
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v1, Li70/b;->d:Lz60/k;

    .line 6
    .line 7
    iget-object v3, v1, Li70/b;->e:Li70/c;

    .line 8
    .line 9
    :cond_8
    :goto_8
    sget-object v4, Li70/g;->f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 10
    .line 11
    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->getAndDecrement(Ljava/lang/Object;)I

    .line 12
    .line 13
    .line 14
    move-result v4

    .line 15
    const/4 v5, 0x1

    .line 16
    if-gt v4, v5, :cond_8

    .line 17
    .line 18
    sget-object v5, Ll30/a0;->a:Ll30/a0;

    .line 19
    .line 20
    const/4 v6, 0x0

    .line 21
    if-lez v4, :cond_24

    .line 22
    .line 23
    sget-object v4, Li70/c;->g:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 24
    .line 25
    invoke-virtual {v4, v3, v6}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    new-instance v4, Lb10/c;

    .line 29
    .line 30
    invoke-direct {v4, v3, v1}, Lb10/c;-><init>(Li70/c;Li70/b;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v2, v4, v5}, Lz60/k;->k(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_24
    sget-object v4, Li70/g;->d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 38
    .line 39
    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v7

    .line 43
    check-cast v7, Li70/i;

    .line 44
    .line 45
    sget-object v8, Li70/g;->e:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 46
    .line 47
    invoke-virtual {v8, v0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    .line 48
    .line 49
    .line 50
    move-result-wide v8

    .line 51
    sget-object v10, Li70/e;->d:Li70/e;

    .line 52
    .line 53
    sget v11, Li70/h;->f:I

    .line 54
    .line 55
    int-to-long v11, v11

    .line 56
    div-long v11, v8, v11

    .line 57
    .line 58
    :goto_39
    invoke-static {v7, v11, v12, v10}, Le70/b;->b(Le70/s;JLkotlin/jvm/functions/Function2;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v13

    .line 62
    invoke-static {v13}, Le70/b;->e(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v14

    .line 66
    if-nez v14, :cond_87

    .line 67
    .line 68
    invoke-static {v13}, Le70/b;->c(Ljava/lang/Object;)Le70/s;

    .line 69
    .line 70
    .line 71
    move-result-object v14

    .line 72
    :goto_47
    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v15

    .line 76
    check-cast v15, Le70/s;

    .line 77
    .line 78
    move-object/from16 v16, v7

    .line 79
    .line 80
    iget-wide v6, v15, Le70/s;->i:J

    .line 81
    .line 82
    move-wide/from16 v17, v6

    .line 83
    .line 84
    iget-wide v6, v14, Le70/s;->i:J

    .line 85
    .line 86
    cmp-long v6, v17, v6

    .line 87
    .line 88
    if-ltz v6, :cond_5a

    .line 89
    .line 90
    goto :goto_87

    .line 91
    :cond_5a
    invoke-virtual {v14}, Le70/s;->j()Z

    .line 92
    .line 93
    .line 94
    move-result v6

    .line 95
    if-nez v6, :cond_64

    .line 96
    .line 97
    move-object/from16 v7, v16

    .line 98
    .line 99
    const/4 v6, 0x0

    .line 100
    goto :goto_39

    .line 101
    :cond_64
    invoke-virtual {v4, v0, v15, v14}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v6

    .line 105
    if-eqz v6, :cond_74

    .line 106
    .line 107
    invoke-virtual {v15}, Le70/s;->f()Z

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    if-eqz v4, :cond_87

    .line 112
    .line 113
    invoke-virtual {v15}, Le70/c;->e()V

    .line 114
    .line 115
    .line 116
    goto :goto_87

    .line 117
    :cond_74
    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    if-eq v6, v15, :cond_64

    .line 122
    .line 123
    invoke-virtual {v14}, Le70/s;->f()Z

    .line 124
    .line 125
    .line 126
    move-result v6

    .line 127
    if-eqz v6, :cond_83

    .line 128
    .line 129
    invoke-virtual {v14}, Le70/c;->e()V

    .line 130
    .line 131
    .line 132
    :cond_83
    move-object/from16 v7, v16

    .line 133
    .line 134
    const/4 v6, 0x0

    .line 135
    goto :goto_47

    .line 136
    :cond_87
    :goto_87
    invoke-static {v13}, Le70/b;->c(Ljava/lang/Object;)Le70/s;

    .line 137
    .line 138
    .line 139
    move-result-object v4

    .line 140
    check-cast v4, Li70/i;

    .line 141
    .line 142
    iget-object v6, v4, Li70/i;->w:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 143
    .line 144
    sget v7, Li70/h;->f:I

    .line 145
    .line 146
    int-to-long v10, v7

    .line 147
    rem-long/2addr v8, v10

    .line 148
    long-to-int v7, v8

    .line 149
    :cond_94
    const/4 v8, 0x0

    .line 150
    invoke-virtual {v6, v7, v8, v1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->compareAndSet(ILjava/lang/Object;Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v9

    .line 154
    if-eqz v9, :cond_9f

    .line 155
    .line 156
    invoke-interface {v1, v4, v7}, Lz60/b2;->a(Le70/s;I)V

    .line 157
    .line 158
    .line 159
    return-void

    .line 160
    :cond_9f
    invoke-virtual {v6, v7}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v8

    .line 164
    if-eqz v8, :cond_94

    .line 165
    .line 166
    sget-object v8, Li70/h;->b:La6/q0;

    .line 167
    .line 168
    sget-object v9, Li70/h;->c:La6/q0;

    .line 169
    .line 170
    :cond_a9
    invoke-virtual {v6, v7, v8, v9}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->compareAndSet(ILjava/lang/Object;Ljava/lang/Object;)Z

    .line 171
    .line 172
    .line 173
    move-result v4

    .line 174
    if-eqz v4, :cond_be

    .line 175
    .line 176
    sget-object v4, Li70/c;->g:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 177
    .line 178
    const/4 v10, 0x0

    .line 179
    invoke-virtual {v4, v3, v10}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    new-instance v4, Lb10/c;

    .line 183
    .line 184
    invoke-direct {v4, v3, v1}, Lb10/c;-><init>(Li70/c;Li70/b;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v2, v4, v5}, Lz60/k;->k(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    return-void

    .line 191
    :cond_be
    const/4 v10, 0x0

    .line 192
    invoke-virtual {v6, v7}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v4

    .line 196
    if-eq v4, v8, :cond_a9

    .line 197
    .line 198
    goto/16 :goto_8
.end method

.method public final b()V
    .registers 16

    .line 1
    :cond_0
    sget-object v0, Li70/g;->f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->getAndIncrement(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x1

    .line 8
    if-ge v1, v2, :cond_ee

    .line 9
    .line 10
    if-ltz v1, :cond_d

    .line 11
    .line 12
    goto/16 :goto_d5

    .line 13
    .line 14
    :cond_d
    sget-object v0, Li70/g;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Li70/i;

    .line 21
    .line 22
    sget-object v3, Li70/g;->c:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 23
    .line 24
    invoke-virtual {v3, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->getAndIncrement(Ljava/lang/Object;)J

    .line 25
    .line 26
    .line 27
    move-result-wide v3

    .line 28
    sget v5, Li70/h;->f:I

    .line 29
    .line 30
    int-to-long v5, v5

    .line 31
    div-long v5, v3, v5

    .line 32
    .line 33
    sget-object v7, Li70/f;->d:Li70/f;

    .line 34
    .line 35
    :goto_22
    invoke-static {v1, v5, v6, v7}, Le70/b;->b(Le70/s;JLkotlin/jvm/functions/Function2;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    invoke-static {v8}, Le70/b;->e(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v9

    .line 43
    if-nez v9, :cond_66

    .line 44
    .line 45
    invoke-static {v8}, Le70/b;->c(Ljava/lang/Object;)Le70/s;

    .line 46
    .line 47
    .line 48
    move-result-object v9

    .line 49
    :cond_30
    :goto_30
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v10

    .line 53
    check-cast v10, Le70/s;

    .line 54
    .line 55
    iget-wide v11, v10, Le70/s;->i:J

    .line 56
    .line 57
    iget-wide v13, v9, Le70/s;->i:J

    .line 58
    .line 59
    cmp-long v11, v11, v13

    .line 60
    .line 61
    if-ltz v11, :cond_3f

    .line 62
    .line 63
    goto :goto_66

    .line 64
    :cond_3f
    invoke-virtual {v9}, Le70/s;->j()Z

    .line 65
    .line 66
    .line 67
    move-result v11

    .line 68
    if-nez v11, :cond_46

    .line 69
    .line 70
    goto :goto_22

    .line 71
    :cond_46
    invoke-virtual {v0, p0, v10, v9}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v11

    .line 75
    if-eqz v11, :cond_56

    .line 76
    .line 77
    invoke-virtual {v10}, Le70/s;->f()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_66

    .line 82
    .line 83
    invoke-virtual {v10}, Le70/c;->e()V

    .line 84
    .line 85
    .line 86
    goto :goto_66

    .line 87
    :cond_56
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v11

    .line 91
    if-eq v11, v10, :cond_46

    .line 92
    .line 93
    invoke-virtual {v9}, Le70/s;->f()Z

    .line 94
    .line 95
    .line 96
    move-result v10

    .line 97
    if-eqz v10, :cond_30

    .line 98
    .line 99
    invoke-virtual {v9}, Le70/c;->e()V

    .line 100
    .line 101
    .line 102
    goto :goto_30

    .line 103
    :cond_66
    :goto_66
    invoke-static {v8}, Le70/b;->c(Ljava/lang/Object;)Le70/s;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    check-cast v0, Li70/i;

    .line 108
    .line 109
    iget-object v1, v0, Li70/i;->w:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 110
    .line 111
    invoke-virtual {v0}, Le70/c;->a()V

    .line 112
    .line 113
    .line 114
    iget-wide v7, v0, Le70/s;->i:J

    .line 115
    .line 116
    cmp-long v0, v7, v5

    .line 117
    .line 118
    const/4 v5, 0x0

    .line 119
    if-lez v0, :cond_7a

    .line 120
    .line 121
    :cond_78
    :goto_78
    move v2, v5

    .line 122
    goto :goto_d3

    .line 123
    :cond_7a
    sget v0, Li70/h;->f:I

    .line 124
    .line 125
    int-to-long v6, v0

    .line 126
    rem-long/2addr v3, v6

    .line 127
    long-to-int v0, v3

    .line 128
    sget-object v3, Li70/h;->b:La6/q0;

    .line 129
    .line 130
    invoke-virtual {v1, v0, v3}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->getAndSet(ILjava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    if-nez v3, :cond_ac

    .line 135
    .line 136
    sget v3, Li70/h;->a:I

    .line 137
    .line 138
    move v4, v5

    .line 139
    :goto_8a
    if-ge v4, v3, :cond_98

    .line 140
    .line 141
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v6

    .line 145
    sget-object v7, Li70/h;->c:La6/q0;

    .line 146
    .line 147
    if-ne v6, v7, :cond_95

    .line 148
    .line 149
    goto :goto_d3

    .line 150
    :cond_95
    add-int/lit8 v4, v4, 0x1

    .line 151
    .line 152
    goto :goto_8a

    .line 153
    :cond_98
    sget-object v4, Li70/h;->b:La6/q0;

    .line 154
    .line 155
    sget-object v6, Li70/h;->d:La6/q0;

    .line 156
    .line 157
    :cond_9c
    invoke-virtual {v1, v0, v4, v6}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->compareAndSet(ILjava/lang/Object;Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v3

    .line 161
    if-eqz v3, :cond_a4

    .line 162
    .line 163
    move v5, v2

    .line 164
    goto :goto_aa

    .line 165
    :cond_a4
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    if-eq v3, v4, :cond_9c

    .line 170
    .line 171
    :goto_aa
    xor-int/2addr v2, v5

    .line 172
    goto :goto_d3

    .line 173
    :cond_ac
    sget-object v0, Li70/h;->e:La6/q0;

    .line 174
    .line 175
    if-ne v3, v0, :cond_b1

    .line 176
    .line 177
    goto :goto_78

    .line 178
    :cond_b1
    instance-of v0, v3, Lz60/j;

    .line 179
    .line 180
    sget-object v1, Ll30/a0;->a:Ll30/a0;

    .line 181
    .line 182
    if-eqz v0, :cond_c5

    .line 183
    .line 184
    check-cast v3, Lz60/j;

    .line 185
    .line 186
    iget-object v0, p0, Li70/g;->a:Lde/c;

    .line 187
    .line 188
    invoke-interface {v3, v1, v0}, Lz60/j;->m(Ljava/lang/Object;La40/a;)La6/q0;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    if-eqz v0, :cond_78

    .line 193
    .line 194
    invoke-interface {v3, v0}, Lz60/j;->q(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    goto :goto_d3

    .line 198
    :cond_c5
    instance-of v0, v3, Lh70/f;

    .line 199
    .line 200
    if-eqz v0, :cond_d6

    .line 201
    .line 202
    check-cast v3, Lh70/f;

    .line 203
    .line 204
    check-cast v3, Lh70/e;

    .line 205
    .line 206
    invoke-virtual {v3, p0, v1}, Lh70/e;->g(Ljava/lang/Object;Ljava/lang/Object;)I

    .line 207
    .line 208
    .line 209
    move-result v0

    .line 210
    if-nez v0, :cond_78

    .line 211
    .line 212
    :goto_d3
    if-eqz v2, :cond_0

    .line 213
    .line 214
    :goto_d5
    return-void

    .line 215
    :cond_d6
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 216
    .line 217
    new-instance v1, Ljava/lang/StringBuilder;

    .line 218
    .line 219
    const-string v2, "unexpected: "

    .line 220
    .line 221
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 225
    .line 226
    .line 227
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v1

    .line 235
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    throw v0

    .line 239
    :cond_ee
    :goto_ee
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->get(Ljava/lang/Object;)I

    .line 240
    .line 241
    .line 242
    move-result v1

    .line 243
    if-le v1, v2, :cond_fb

    .line 244
    .line 245
    invoke-virtual {v0, p0, v1, v2}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->compareAndSet(Ljava/lang/Object;II)Z

    .line 246
    .line 247
    .line 248
    move-result v1

    .line 249
    if-nez v1, :cond_fb

    .line 250
    .line 251
    goto :goto_ee

    .line 252
    :cond_fb
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 253
    .line 254
    const-string v1, "The number of released permits cannot be greater than 1"

    .line 255
    .line 256
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 257
    .line 258
    .line 259
    move-result-object v1

    .line 260
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    throw v0
.end method
