d50.k
d50.i
d50.q
