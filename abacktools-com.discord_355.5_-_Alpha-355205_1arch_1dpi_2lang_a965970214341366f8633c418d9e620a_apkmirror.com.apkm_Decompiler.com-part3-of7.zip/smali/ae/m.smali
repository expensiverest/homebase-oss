###### Class ae.m (ae.m)
.class public final Lae/m;
.super Lmg/a;
.source "SourceFile"


# instance fields
.field public final a:Lae/h;

.field public final b:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Lae/h;)V
    .registers 4

    .line 1
    const-string v0, "config"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lae/m;->a:Lae/h;

    .line 10
    .line 11
    new-instance v0, Landroid/graphics/Paint;

    .line 12
    .line 13
    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 18
    .line 19
    .line 20
    iget p1, p1, Lae/h;->b:I

    .line 21
    .line 22
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Lae/m;->b:Landroid/graphics/Paint;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const-string v2, "canvas"

    .line 6
    .line 7
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    int-to-float v2, v2

    .line 19
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    int-to-float v9, v3

    .line 28
    iget-object v10, v0, Lae/m;->a:Lae/h;

    .line 29
    .line 30
    iget-object v3, v10, Lae/h;->g:Ljava/lang/Float;

    .line 31
    .line 32
    const/4 v11, 0x2

    .line 33
    if-eqz v3, :cond_28

    .line 34
    .line 35
    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    :goto_26
    move v12, v3

    .line 40
    goto :goto_3a

    .line 41
    :cond_28
    iget v3, v10, Lae/h;->e:F

    .line 42
    .line 43
    int-to-float v4, v11

    .line 44
    mul-float/2addr v3, v4

    .line 45
    sub-float v3, v2, v3

    .line 46
    .line 47
    iget v4, v10, Lae/h;->d:F

    .line 48
    .line 49
    iget v5, v10, Lae/h;->c:I

    .line 50
    .line 51
    add-int/lit8 v6, v5, -0x1

    .line 52
    .line 53
    int-to-float v6, v6

    .line 54
    mul-float/2addr v4, v6

    .line 55
    sub-float/2addr v3, v4

    .line 56
    int-to-float v4, v5

    .line 57
    div-float/2addr v3, v4

    .line 58
    goto :goto_26

    .line 59
    :goto_3a
    iget-object v3, v10, Lae/h;->h:Ljava/lang/Float;

    .line 60
    .line 61
    if-eqz v3, :cond_44

    .line 62
    .line 63
    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    :goto_42
    move v13, v3

    .line 68
    goto :goto_4b

    .line 69
    :cond_44
    iget v3, v10, Lae/h;->f:F

    .line 70
    .line 71
    int-to-float v4, v11

    .line 72
    mul-float/2addr v3, v4

    .line 73
    sub-float v3, v9, v3

    .line 74
    .line 75
    goto :goto_42

    .line 76
    :goto_4b
    iget v14, v10, Lae/h;->c:I

    .line 77
    .line 78
    const/4 v15, 0x1

    .line 79
    if-le v14, v15, :cond_5a

    .line 80
    .line 81
    int-to-float v3, v14

    .line 82
    mul-float/2addr v3, v12

    .line 83
    sub-float/2addr v2, v3

    .line 84
    add-int/lit8 v3, v14, -0x1

    .line 85
    .line 86
    int-to-float v3, v3

    .line 87
    :goto_56
    div-float/2addr v2, v3

    .line 88
    move/from16 v16, v2

    .line 89
    .line 90
    goto :goto_5d

    .line 91
    :cond_5a
    sub-float/2addr v2, v12

    .line 92
    int-to-float v3, v11

    .line 93
    goto :goto_56

    .line 94
    :goto_5d
    const/4 v2, 0x0

    .line 95
    :goto_5e
    if-ge v2, v14, :cond_bd

    .line 96
    .line 97
    iget v3, v10, Lae/h;->c:I

    .line 98
    .line 99
    if-ne v3, v15, :cond_67

    .line 100
    .line 101
    move/from16 v4, v16

    .line 102
    .line 103
    goto :goto_6b

    .line 104
    :cond_67
    int-to-float v3, v2

    .line 105
    add-float v4, v12, v16

    .line 106
    .line 107
    mul-float/2addr v4, v3

    .line 108
    :goto_6b
    iget-object v3, v10, Lae/h;->i:Lae/g;

    .line 109
    .line 110
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 111
    .line 112
    .line 113
    move-result v3

    .line 114
    iget-object v8, v0, Lae/m;->b:Landroid/graphics/Paint;

    .line 115
    .line 116
    const/high16 v5, 0x40000000    # 2.0f

    .line 117
    .line 118
    if-eqz v3, :cond_ae

    .line 119
    .line 120
    if-ne v3, v15, :cond_a7

    .line 121
    .line 122
    move v3, v2

    .line 123
    move v2, v4

    .line 124
    add-float v4, v2, v12

    .line 125
    .line 126
    iget-object v6, v10, Lae/h;->j:Lae/c;

    .line 127
    .line 128
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 129
    .line 130
    .line 131
    move-result v6

    .line 132
    if-eqz v6, :cond_99

    .line 133
    .line 134
    if-eq v6, v15, :cond_96

    .line 135
    .line 136
    if-ne v6, v11, :cond_8f

    .line 137
    .line 138
    div-float v6, v9, v5

    .line 139
    .line 140
    div-float v5, v13, v5

    .line 141
    .line 142
    sub-float/2addr v6, v5

    .line 143
    goto :goto_9a

    .line 144
    :cond_8f
    new-instance v1, Lan/g;

    .line 145
    .line 146
    const/4 v2, 0x0

    .line 147
    invoke-direct {v1, v2}, Lan/g;-><init>(Z)V

    .line 148
    .line 149
    .line 150
    throw v1

    .line 151
    :cond_96
    sub-float v6, v9, v13

    .line 152
    .line 153
    goto :goto_9a

    .line 154
    :cond_99
    const/4 v6, 0x0

    .line 155
    :goto_9a
    add-float v5, v6, v13

    .line 156
    .line 157
    move v7, v3

    .line 158
    move v3, v6

    .line 159
    iget v6, v10, Lae/h;->a:F

    .line 160
    .line 161
    move/from16 v17, v7

    .line 162
    .line 163
    move v7, v6

    .line 164
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 165
    .line 166
    .line 167
    goto :goto_ba

    .line 168
    :cond_a7
    new-instance v1, Lan/g;

    .line 169
    .line 170
    const/4 v2, 0x0

    .line 171
    invoke-direct {v1, v2}, Lan/g;-><init>(Z)V

    .line 172
    .line 173
    .line 174
    throw v1

    .line 175
    :cond_ae
    move/from16 v17, v2

    .line 176
    .line 177
    move v2, v4

    .line 178
    div-float v3, v12, v5

    .line 179
    .line 180
    add-float v4, v2, v3

    .line 181
    .line 182
    div-float v2, v9, v5

    .line 183
    .line 184
    invoke-virtual {v1, v4, v2, v3, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 185
    .line 186
    .line 187
    :goto_ba
    add-int/lit8 v2, v17, 0x1

    .line 188
    .line 189
    goto :goto_5e

    .line 190
    :cond_bd
    return-void
.end method
