###### Class ae.i (ae.i)
.class public abstract Lae/i;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .registers 0

    .line 1
    return-void
.end method

.method public static a(Lae/i;)Lae/a;
    .registers 4

    .line 1
    const-string v0, "placeholderType"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lae/a;->a:Le6/r1;

    .line 7
    .line 8
    invoke-virtual {v0, p0}, Le6/r1;->f(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Lae/a;

    .line 13
    .line 14
    if-eqz v1, :cond_10

    .line 15
    .line 16
    return-object v1

    .line 17
    :cond_10
    instance-of v1, p0, Lae/e;

    .line 18
    .line 19
    if-eqz v1, :cond_1d

    .line 20
    .line 21
    new-instance v1, Lae/k;

    .line 22
    .line 23
    move-object v2, p0

    .line 24
    check-cast v2, Lae/e;

    .line 25
    .line 26
    invoke-direct {v1, v2}, Lae/k;-><init>(Lae/e;)V

    .line 27
    .line 28
    .line 29
    goto :goto_30

    .line 30
    :cond_1d
    instance-of v1, p0, Lae/h;

    .line 31
    .line 32
    if-eqz v1, :cond_2a

    .line 33
    .line 34
    new-instance v1, Lae/n;

    .line 35
    .line 36
    move-object v2, p0

    .line 37
    check-cast v2, Lae/h;

    .line 38
    .line 39
    invoke-direct {v1, v2}, Lae/n;-><init>(Lae/h;)V

    .line 40
    .line 41
    .line 42
    goto :goto_30

    .line 43
    :cond_2a
    instance-of v1, p0, Lae/f;

    .line 44
    .line 45
    if-eqz v1, :cond_34

    .line 46
    .line 47
    sget-object v1, Lae/l;->b:Lae/l;

    .line 48
    .line 49
    :goto_30
    invoke-virtual {v0, p0, v1}, Le6/r1;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    return-object v1

    .line 53
    :cond_34
    new-instance p0, Lan/g;

    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    invoke-direct {p0, v0}, Lan/g;-><init>(Z)V

    .line 57
    .line 58
    .line 59
    throw p0
.end method
