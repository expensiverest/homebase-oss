###### Class ae.g (ae.g)
.class public final enum Lae/g;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final d:Lzm/n;

.field public static final enum e:Lae/g;

.field public static final enum i:Lae/g;

.field public static final synthetic v:[Lae/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lae/g;

    .line 2
    .line 3
    const-string v1, "CIRCLE"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lae/g;->e:Lae/g;

    .line 10
    .line 11
    new-instance v1, Lae/g;

    .line 12
    .line 13
    const-string v2, "RECT"

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    sput-object v1, Lae/g;->i:Lae/g;

    .line 20
    .line 21
    filled-new-array {v0, v1}, [Lae/g;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Lae/g;->v:[Lae/g;

    .line 26
    .line 27
    invoke-static {v0}, Loq/a;->G([Ljava/lang/Enum;)Lt30/a;

    .line 28
    .line 29
    .line 30
    new-instance v0, Lzm/n;

    .line 31
    .line 32
    const/4 v1, 0x1

    .line 33
    invoke-direct {v0, v1}, Lzm/n;-><init>(I)V

    .line 34
    .line 35
    .line 36
    sput-object v0, Lae/g;->d:Lzm/n;

    .line 37
    .line 38
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lae/g;
    .registers 2

    .line 1
    const-class v0, Lae/g;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lae/g;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lae/g;
    .registers 1

    .line 1
    sget-object v0, Lae/g;->v:[Lae/g;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lae/g;

    .line 8
    .line 9
    return-object v0
.end method
