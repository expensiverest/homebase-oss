###### Class ae.j (ae.j)
.class public final Lae/j;
.super Lmg/a;
.source "SourceFile"


# instance fields
.field public final a:Lae/e;

.field public final b:F

.field public final c:F

.field public final d:Landroid/graphics/Paint;

.field public final e:Landroid/graphics/Path;

.field public final f:Landroid/graphics/RectF;

.field public final g:[F


# direct methods
.method public constructor <init>(Lae/e;FF)V
    .registers 15

    .line 1
    const-string v0, "config"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget v0, p1, Lae/e;->e:F

    .line 7
    .line 8
    iget v1, p1, Lae/e;->f:F

    .line 9
    .line 10
    iget v2, p1, Lae/e;->d:F

    .line 11
    .line 12
    iget v3, p1, Lae/e;->b:F

    .line 13
    .line 14
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, Lae/j;->a:Lae/e;

    .line 18
    .line 19
    iput p2, p0, Lae/j;->b:F

    .line 20
    .line 21
    iput p3, p0, Lae/j;->c:F

    .line 22
    .line 23
    new-instance p2, Landroid/graphics/Paint;

    .line 24
    .line 25
    invoke-direct {p2}, Landroid/graphics/Paint;-><init>()V

    .line 26
    .line 27
    .line 28
    const/4 p3, 0x1

    .line 29
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 30
    .line 31
    .line 32
    iget v4, p1, Lae/e;->g:I

    .line 33
    .line 34
    invoke-virtual {p2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 35
    .line 36
    .line 37
    iput-object p2, p0, Lae/j;->d:Landroid/graphics/Paint;

    .line 38
    .line 39
    new-instance p2, Landroid/graphics/Path;

    .line 40
    .line 41
    invoke-direct {p2}, Landroid/graphics/Path;-><init>()V

    .line 42
    .line 43
    .line 44
    iput-object p2, p0, Lae/j;->e:Landroid/graphics/Path;

    .line 45
    .line 46
    new-instance p2, Landroid/graphics/RectF;

    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-direct {p2, v4, v4, v4, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 50
    .line 51
    .line 52
    iput-object p2, p0, Lae/j;->f:Landroid/graphics/RectF;

    .line 53
    .line 54
    iget p1, p1, Lae/e;->c:F

    .line 55
    .line 56
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    cmpg-float v5, v5, v4

    .line 65
    .line 66
    const/4 v6, 0x0

    .line 67
    if-nez v5, :cond_46

    .line 68
    .line 69
    move v5, p3

    .line 70
    goto :goto_47

    .line 71
    :cond_46
    move v5, v6

    .line 72
    :goto_47
    const/4 v7, 0x0

    .line 73
    if-nez v5, :cond_4b

    .line 74
    .line 75
    goto :goto_4c

    .line 76
    :cond_4b
    move-object p2, v7

    .line 77
    :goto_4c
    if-eqz p2, :cond_53

    .line 78
    .line 79
    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    .line 80
    .line 81
    .line 82
    move-result p2

    .line 83
    goto :goto_54

    .line 84
    :cond_53
    move p2, v3

    .line 85
    :goto_54
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 90
    .line 91
    .line 92
    move-result v5

    .line 93
    cmpg-float v5, v5, v4

    .line 94
    .line 95
    if-nez v5, :cond_62

    .line 96
    .line 97
    move v5, p3

    .line 98
    goto :goto_63

    .line 99
    :cond_62
    move v5, v6

    .line 100
    :goto_63
    if-nez v5, :cond_66

    .line 101
    .line 102
    goto :goto_67

    .line 103
    :cond_66
    move-object p1, v7

    .line 104
    :goto_67
    if-eqz p1, :cond_6e

    .line 105
    .line 106
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    goto :goto_6f

    .line 111
    :cond_6e
    move p1, v3

    .line 112
    :goto_6f
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 113
    .line 114
    .line 115
    move-result-object v5

    .line 116
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 117
    .line 118
    .line 119
    move-result v8

    .line 120
    cmpg-float v8, v8, v4

    .line 121
    .line 122
    if-nez v8, :cond_7d

    .line 123
    .line 124
    move v8, p3

    .line 125
    goto :goto_7e

    .line 126
    :cond_7d
    move v8, v6

    .line 127
    :goto_7e
    if-nez v8, :cond_81

    .line 128
    .line 129
    goto :goto_82

    .line 130
    :cond_81
    move-object v5, v7

    .line 131
    :goto_82
    if-eqz v5, :cond_89

    .line 132
    .line 133
    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    .line 134
    .line 135
    .line 136
    move-result v5

    .line 137
    goto :goto_8a

    .line 138
    :cond_89
    move v5, v3

    .line 139
    :goto_8a
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 144
    .line 145
    .line 146
    move-result v8

    .line 147
    cmpg-float v8, v8, v4

    .line 148
    .line 149
    if-nez v8, :cond_98

    .line 150
    .line 151
    move v8, p3

    .line 152
    goto :goto_99

    .line 153
    :cond_98
    move v8, v6

    .line 154
    :goto_99
    if-nez v8, :cond_9c

    .line 155
    .line 156
    goto :goto_9d

    .line 157
    :cond_9c
    move-object v2, v7

    .line 158
    :goto_9d
    if-eqz v2, :cond_a4

    .line 159
    .line 160
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    goto :goto_a5

    .line 165
    :cond_a4
    move v2, v3

    .line 166
    :goto_a5
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 167
    .line 168
    .line 169
    move-result-object v8

    .line 170
    invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F

    .line 171
    .line 172
    .line 173
    move-result v9

    .line 174
    cmpg-float v9, v9, v4

    .line 175
    .line 176
    if-nez v9, :cond_b3

    .line 177
    .line 178
    move v9, p3

    .line 179
    goto :goto_b4

    .line 180
    :cond_b3
    move v9, v6

    .line 181
    :goto_b4
    if-nez v9, :cond_b7

    .line 182
    .line 183
    goto :goto_b8

    .line 184
    :cond_b7
    move-object v8, v7

    .line 185
    :goto_b8
    if-eqz v8, :cond_bf

    .line 186
    .line 187
    invoke-virtual {v8}, Ljava/lang/Float;->floatValue()F

    .line 188
    .line 189
    .line 190
    move-result v8

    .line 191
    goto :goto_c0

    .line 192
    :cond_bf
    move v8, v3

    .line 193
    :goto_c0
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 194
    .line 195
    .line 196
    move-result-object v1

    .line 197
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 198
    .line 199
    .line 200
    move-result v9

    .line 201
    cmpg-float v9, v9, v4

    .line 202
    .line 203
    if-nez v9, :cond_ce

    .line 204
    .line 205
    move v9, p3

    .line 206
    goto :goto_cf

    .line 207
    :cond_ce
    move v9, v6

    .line 208
    :goto_cf
    if-nez v9, :cond_d2

    .line 209
    .line 210
    goto :goto_d3

    .line 211
    :cond_d2
    move-object v1, v7

    .line 212
    :goto_d3
    if-eqz v1, :cond_da

    .line 213
    .line 214
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 215
    .line 216
    .line 217
    move-result v1

    .line 218
    goto :goto_db

    .line 219
    :cond_da
    move v1, v3

    .line 220
    :goto_db
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 221
    .line 222
    .line 223
    move-result-object v9

    .line 224
    invoke-virtual {v9}, Ljava/lang/Number;->floatValue()F

    .line 225
    .line 226
    .line 227
    move-result v10

    .line 228
    cmpg-float v10, v10, v4

    .line 229
    .line 230
    if-nez v10, :cond_e9

    .line 231
    .line 232
    move v10, p3

    .line 233
    goto :goto_ea

    .line 234
    :cond_e9
    move v10, v6

    .line 235
    :goto_ea
    if-nez v10, :cond_ed

    .line 236
    .line 237
    goto :goto_ee

    .line 238
    :cond_ed
    move-object v9, v7

    .line 239
    :goto_ee
    if-eqz v9, :cond_f5

    .line 240
    .line 241
    invoke-virtual {v9}, Ljava/lang/Float;->floatValue()F

    .line 242
    .line 243
    .line 244
    move-result v9

    .line 245
    goto :goto_f6

    .line 246
    :cond_f5
    move v9, v3

    .line 247
    :goto_f6
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 252
    .line 253
    .line 254
    move-result v10

    .line 255
    cmpg-float v4, v10, v4

    .line 256
    .line 257
    if-nez v4, :cond_104

    .line 258
    .line 259
    move v4, p3

    .line 260
    goto :goto_105

    .line 261
    :cond_104
    move v4, v6

    .line 262
    :goto_105
    if-nez v4, :cond_108

    .line 263
    .line 264
    move-object v7, v0

    .line 265
    :cond_108
    if-eqz v7, :cond_10e

    .line 266
    .line 267
    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    .line 268
    .line 269
    .line 270
    move-result v3

    .line 271
    :cond_10e
    const/16 v0, 0x8

    .line 272
    .line 273
    new-array v0, v0, [F

    .line 274
    .line 275
    aput p2, v0, v6

    .line 276
    .line 277
    aput p1, v0, p3

    .line 278
    .line 279
    const/4 p1, 0x2

    .line 280
    aput v5, v0, p1

    .line 281
    .line 282
    const/4 p1, 0x3

    .line 283
    aput v2, v0, p1

    .line 284
    .line 285
    const/4 p1, 0x4

    .line 286
    aput v8, v0, p1

    .line 287
    .line 288
    const/4 p1, 0x5

    .line 289
    aput v1, v0, p1

    .line 290
    .line 291
    const/4 p1, 0x6

    .line 292
    aput v9, v0, p1

    .line 293
    .line 294
    const/4 p1, 0x7

    .line 295
    aput v3, v0, p1

    .line 296
    .line 297
    iput-object v0, p0, Lae/j;->g:[F

    .line 298
    .line 299
    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const-string v2, "canvas"

    .line 6
    .line 7
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    .line 15
    .line 16
    .line 17
    move-result v7

    .line 18
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    .line 23
    .line 24
    .line 25
    move-result v8

    .line 26
    iget-object v9, v0, Lae/j;->a:Lae/e;

    .line 27
    .line 28
    iget v2, v9, Lae/e;->a:I

    .line 29
    .line 30
    iget-object v6, v0, Lae/j;->d:Landroid/graphics/Paint;

    .line 31
    .line 32
    if-eqz v2, :cond_42

    .line 33
    .line 34
    iget-object v2, v0, Lae/j;->e:Landroid/graphics/Path;

    .line 35
    .line 36
    invoke-virtual {v2}, Landroid/graphics/Path;->reset()V

    .line 37
    .line 38
    .line 39
    int-to-float v3, v7

    .line 40
    int-to-float v4, v8

    .line 41
    iget-object v5, v0, Lae/j;->f:Landroid/graphics/RectF;

    .line 42
    .line 43
    const/4 v10, 0x0

    .line 44
    invoke-virtual {v5, v10, v10, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    .line 45
    .line 46
    .line 47
    iget-object v3, v0, Lae/j;->g:[F

    .line 48
    .line 49
    sget-object v4, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 50
    .line 51
    invoke-virtual {v2, v5, v3, v4}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    .line 52
    .line 53
    .line 54
    iget v3, v9, Lae/e;->a:I

    .line 55
    .line 56
    invoke-virtual {v6, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1, v2, v6}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 60
    .line 61
    .line 62
    iget v2, v9, Lae/e;->g:I

    .line 63
    .line 64
    invoke-virtual {v6, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 65
    .line 66
    .line 67
    :cond_42
    iget-object v2, v9, Lae/e;->m:Lae/g;

    .line 68
    .line 69
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    const/4 v10, 0x1

    .line 74
    const/high16 v11, 0x40000000    # 2.0f

    .line 75
    .line 76
    if-eqz v2, :cond_63

    .line 77
    .line 78
    if-ne v2, v10, :cond_5c

    .line 79
    .line 80
    iget v2, v9, Lae/e;->l:F

    .line 81
    .line 82
    iget v4, v9, Lae/e;->n:F

    .line 83
    .line 84
    int-to-float v3, v8

    .line 85
    sub-float/2addr v3, v4

    .line 86
    div-float/2addr v3, v11

    .line 87
    add-float v5, v4, v3

    .line 88
    .line 89
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 90
    .line 91
    .line 92
    goto :goto_74

    .line 93
    :cond_5c
    new-instance v1, Lan/g;

    .line 94
    .line 95
    const/4 v2, 0x0

    .line 96
    invoke-direct {v1, v2}, Lan/g;-><init>(Z)V

    .line 97
    .line 98
    .line 99
    throw v1

    .line 100
    :cond_63
    int-to-float v2, v8

    .line 101
    iget v3, v9, Lae/e;->n:F

    .line 102
    .line 103
    sub-float/2addr v2, v3

    .line 104
    div-float/2addr v2, v11

    .line 105
    div-float v4, v3, v11

    .line 106
    .line 107
    iget v5, v9, Lae/e;->l:F

    .line 108
    .line 109
    add-float/2addr v4, v5

    .line 110
    div-float v5, v3, v11

    .line 111
    .line 112
    add-float/2addr v5, v2

    .line 113
    div-float/2addr v3, v11

    .line 114
    invoke-virtual {v1, v4, v5, v3, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 115
    .line 116
    .line 117
    :goto_74
    iget v2, v9, Lae/e;->q:F

    .line 118
    .line 119
    iget v12, v9, Lae/e;->r:F

    .line 120
    .line 121
    add-float v3, v2, v12

    .line 122
    .line 123
    const/4 v4, 0x2

    .line 124
    int-to-float v4, v4

    .line 125
    move-object v5, v6

    .line 126
    div-float v6, v2, v4

    .line 127
    .line 128
    div-float v13, v12, v4

    .line 129
    .line 130
    iget v14, v9, Lae/e;->p:F

    .line 131
    .line 132
    mul-float v15, v2, v14

    .line 133
    .line 134
    div-float/2addr v15, v4

    .line 135
    mul-float/2addr v14, v12

    .line 136
    div-float/2addr v14, v4

    .line 137
    iget v4, v9, Lae/e;->l:F

    .line 138
    .line 139
    move/from16 v16, v11

    .line 140
    .line 141
    iget v11, v9, Lae/e;->n:F

    .line 142
    .line 143
    add-float/2addr v11, v4

    .line 144
    iget v10, v9, Lae/e;->o:F

    .line 145
    .line 146
    add-float/2addr v11, v10

    .line 147
    int-to-float v7, v7

    .line 148
    sub-float v4, v7, v4

    .line 149
    .line 150
    sub-float v10, v4, v10

    .line 151
    .line 152
    int-to-float v4, v8

    .line 153
    sub-float v3, v4, v3

    .line 154
    .line 155
    div-float v3, v3, v16

    .line 156
    .line 157
    move v8, v3

    .line 158
    add-float v3, v8, v15

    .line 159
    .line 160
    iget v1, v0, Lae/j;->b:F

    .line 161
    .line 162
    mul-float/2addr v1, v10

    .line 163
    add-float v16, v8, v2

    .line 164
    .line 165
    sub-float v2, v16, v15

    .line 166
    .line 167
    move v8, v7

    .line 168
    move v7, v6

    .line 169
    move-object v15, v5

    .line 170
    move v5, v2

    .line 171
    move v2, v11

    .line 172
    move v11, v8

    .line 173
    move-object v8, v15

    .line 174
    move v15, v4

    .line 175
    move v4, v1

    .line 176
    move-object/from16 v1, p1

    .line 177
    .line 178
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 179
    .line 180
    .line 181
    move-object v6, v8

    .line 182
    add-float v3, v16, v14

    .line 183
    .line 184
    iget v1, v0, Lae/j;->c:F

    .line 185
    .line 186
    mul-float v4, v10, v1

    .line 187
    .line 188
    add-float v16, v16, v12

    .line 189
    .line 190
    sub-float v5, v16, v14

    .line 191
    .line 192
    move v7, v13

    .line 193
    move-object/from16 v1, p1

    .line 194
    .line 195
    move v6, v13

    .line 196
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 197
    .line 198
    .line 199
    move-object v6, v8

    .line 200
    iget-boolean v1, v9, Lae/e;->h:Z

    .line 201
    .line 202
    if-eqz v1, :cond_ea

    .line 203
    .line 204
    iget v1, v9, Lae/e;->i:I

    .line 205
    .line 206
    invoke-virtual {v6, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 207
    .line 208
    .line 209
    iget v2, v9, Lae/e;->j:F

    .line 210
    .line 211
    const/4 v1, 0x1

    .line 212
    int-to-float v1, v1

    .line 213
    invoke-static {v1}, Lox/b;->k(F)I

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    int-to-float v1, v1

    .line 218
    sub-float v3, v15, v1

    .line 219
    .line 220
    iget v1, v9, Lae/e;->k:F

    .line 221
    .line 222
    sub-float v4, v11, v1

    .line 223
    .line 224
    move-object/from16 v1, p1

    .line 225
    .line 226
    move v5, v15

    .line 227
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 228
    .line 229
    .line 230
    iget v1, v9, Lae/e;->g:I

    .line 231
    .line 232
    invoke-virtual {v6, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 233
    .line 234
    .line 235
    :cond_ea
    return-void
.end method
