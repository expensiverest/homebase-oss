###### Class a9.f (a9.f)
.class public final La9/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, La9/e;->a:La9/e;

    .line 2
    .line 3
    return-object v0
.end method
