###### Class a9.b (a9.b)
.class public final La9/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, La9/a;->a:La9/a;

    .line 2
    .line 3
    return-object v0
.end method
