###### Class a70.d (a70.d)
.class public final synthetic La70/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, La70/d;->d:I

    iput-object p2, p0, La70/d;->e:Ljava/lang/Object;

    iput-object p3, p0, La70/d;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 40

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, La70/d;->d:I

    .line 4
    .line 5
    const-class v3, Landroidx/credentials/playservices/controllers/identityauth/HiddenActivity;

    .line 6
    .line 7
    const-string v4, "result"

    .line 8
    .line 9
    const/4 v5, 0x3

    .line 10
    const/4 v6, 0x6

    .line 11
    const-string v7, "event"

    .line 12
    .line 13
    const-string v8, "EXTRA_FLOW_PENDING_INTENT"

    .line 14
    .line 15
    const/4 v9, 0x0

    .line 16
    const/4 v10, 0x1

    .line 17
    const/4 v11, 0x0

    .line 18
    const-string v12, "it"

    .line 19
    .line 20
    const-string v13, "node"

    .line 21
    .line 22
    sget-object v14, Ll30/a0;->a:Ll30/a0;

    .line 23
    .line 24
    iget-object v15, v0, La70/d;->i:Ljava/lang/Object;

    .line 25
    .line 26
    iget-object v2, v0, La70/d;->e:Ljava/lang/Object;

    .line 27
    .line 28
    packed-switch v1, :pswitch_data_5c6

    .line 29
    .line 30
    .line 31
    check-cast v2, Ljava/lang/String;

    .line 32
    .line 33
    check-cast v15, Lcom/facebook/react/bridge/WritableMap;

    .line 34
    .line 35
    move-object/from16 v1, p1

    .line 36
    .line 37
    check-cast v1, Lcom/facebook/react/bridge/Promise;

    .line 38
    .line 39
    invoke-static {v1, v12}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v1, v2, v15}, Lcom/facebook/react/bridge/Promise;->reject(Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 43
    .line 44
    .line 45
    return-object v14

    .line 46
    :pswitch_2d
    check-cast v2, Ljava/lang/Throwable;

    .line 47
    .line 48
    check-cast v15, Lcom/facebook/react/bridge/WritableMap;

    .line 49
    .line 50
    move-object/from16 v1, p1

    .line 51
    .line 52
    check-cast v1, Lcom/facebook/react/bridge/Promise;

    .line 53
    .line 54
    invoke-static {v1, v12}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-interface {v1, v2, v15}, Lcom/facebook/react/bridge/Promise;->reject(Ljava/lang/Throwable;Lcom/facebook/react/bridge/WritableMap;)V

    .line 58
    .line 59
    .line 60
    return-object v14

    .line 61
    :pswitch_3c
    check-cast v2, Ljava/lang/String;

    .line 62
    .line 63
    check-cast v15, Ljava/lang/Throwable;

    .line 64
    .line 65
    move-object/from16 v1, p1

    .line 66
    .line 67
    check-cast v1, Lcom/facebook/react/bridge/Promise;

    .line 68
    .line 69
    invoke-static {v1, v12}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-interface {v1, v2, v15}, Lcom/facebook/react/bridge/Promise;->reject(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 73
    .line 74
    .line 75
    return-object v14

    .line 76
    :pswitch_4b
    check-cast v2, Lcom/facebook/react/bridge/PromiseImpl;

    .line 77
    .line 78
    check-cast v15, Lcom/facebook/react/bridge/ReactApplicationContext;

    .line 79
    .line 80
    move-object/from16 v1, p1

    .line 81
    .line 82
    check-cast v1, Lcom/facebook/react/bridge/Promise;

    .line 83
    .line 84
    sget-object v3, Lqh/d;->a:Ljava/util/List;

    .line 85
    .line 86
    invoke-static {v1, v12}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    const-string v1, "android.permission.FOREGROUND_SERVICE_MICROPHONE"

    .line 90
    .line 91
    const-string v3, "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"

    .line 92
    .line 93
    const-string v4, "android.permission.RECORD_AUDIO"

    .line 94
    .line 95
    filled-new-array {v4, v1, v3}, [Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-static {v1}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    new-instance v3, Ljava/util/ArrayList;

    .line 104
    .line 105
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 106
    .line 107
    .line 108
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    :goto_6f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 113
    .line 114
    .line 115
    move-result v4

    .line 116
    if-eqz v4, :cond_87

    .line 117
    .line 118
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v4

    .line 122
    move-object v5, v4

    .line 123
    check-cast v5, Ljava/lang/String;

    .line 124
    .line 125
    invoke-static {v15, v5}, Landroidx/core/view/j1;->d(Landroid/content/Context;Ljava/lang/String;)I

    .line 126
    .line 127
    .line 128
    move-result v5

    .line 129
    if-nez v5, :cond_83

    .line 130
    .line 131
    goto :goto_6f

    .line 132
    :cond_83
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    goto :goto_6f

    .line 136
    :cond_87
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 137
    .line 138
    .line 139
    move-result v1

    .line 140
    if-eqz v1, :cond_9e

    .line 141
    .line 142
    const-string v1, "AUTHORIZED"

    .line 143
    .line 144
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 145
    .line 146
    invoke-virtual {v1, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    const-string v3, "toLowerCase(...)"

    .line 151
    .line 152
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    invoke-interface {v2, v1}, Lcom/facebook/react/bridge/Promise;->resolve(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    goto :goto_a1

    .line 159
    :cond_9e
    invoke-static {v15, v3, v2}, Lqh/d;->d(Lcom/facebook/react/bridge/ReactApplicationContext;Ljava/util/List;Lcom/facebook/react/bridge/Promise;)V

    .line 160
    .line 161
    .line 162
    :goto_a1
    return-object v14

    .line 163
    :pswitch_a2
    check-cast v2, Ljj/c;

    .line 164
    .line 165
    check-cast v15, Lbc/i0;

    .line 166
    .line 167
    move-object/from16 v1, p1

    .line 168
    .line 169
    check-cast v1, Ljava/lang/String;

    .line 170
    .line 171
    const-string v3, "answerId"

    .line 172
    .line 173
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    iget-wide v3, v15, Lbc/i0;->d:J

    .line 177
    .line 178
    new-instance v5, Lcom/discord/primitives/ChannelId;

    .line 179
    .line 180
    invoke-direct {v5, v3, v4}, Lcom/discord/primitives/ChannelId;-><init>(J)V

    .line 181
    .line 182
    .line 183
    iget-object v3, v15, Lbc/i0;->e:Ljava/lang/String;

    .line 184
    .line 185
    new-instance v4, Lcom/discord/primitives/MessageId;

    .line 186
    .line 187
    invoke-direct {v4, v3}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    invoke-virtual {v2, v5, v4, v1}, Ljj/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    return-object v14

    .line 194
    :pswitch_c1
    check-cast v2, Loi/d;

    .line 195
    .line 196
    check-cast v15, Landroid/view/View;

    .line 197
    .line 198
    move-object/from16 v1, p1

    .line 199
    .line 200
    check-cast v1, Landroid/view/MotionEvent;

    .line 201
    .line 202
    invoke-static {v1, v7}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    iget-object v2, v2, Loi/d;->d:Loi/f;

    .line 206
    .line 207
    invoke-virtual {v2, v15, v1, v10}, Loi/f;->b(Landroid/view/View;Landroid/view/MotionEvent;Z)Z

    .line 208
    .line 209
    .line 210
    return-object v14

    .line 211
    :pswitch_d2
    check-cast v2, Lo20/h;

    .line 212
    .line 213
    check-cast v15, Ljava/lang/String;

    .line 214
    .line 215
    move-object/from16 v1, p1

    .line 216
    .line 217
    check-cast v1, Lo20/i;

    .line 218
    .line 219
    const-string v3, "observer"

    .line 220
    .line 221
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    check-cast v1, Lp20/a;

    .line 225
    .line 226
    const-string v3, "currentNavState"

    .line 227
    .line 228
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v1}, Lp20/a;->getEventEmitter$react_native_screens_release()Lp20/c;

    .line 232
    .line 233
    .line 234
    move-result-object v1

    .line 235
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 236
    .line 237
    .line 238
    iget-object v3, v1, La20/a;->c:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v3, Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 241
    .line 242
    new-instance v4, Lq20/b;

    .line 243
    .line 244
    iget-object v5, v1, La20/a;->b:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast v5, Lcom/facebook/react/bridge/ReactContext;

    .line 247
    .line 248
    invoke-static {v5}, Lcom/facebook/react/uimanager/t0;->i(Landroid/content/Context;)I

    .line 249
    .line 250
    .line 251
    move-result v5

    .line 252
    iget v1, v1, La20/a;->a:I

    .line 253
    .line 254
    invoke-direct {v4, v5, v1, v2, v15}, Lq20/b;-><init>(IILo20/h;Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    invoke-interface {v3, v4}, Lcom/facebook/react/uimanager/events/EventDispatcher;->b(Lqp/f;)V

    .line 258
    .line 259
    .line 260
    return-object v14

    .line 261
    :pswitch_104
    check-cast v2, Lio/sentry/internal/debugmeta/c;

    .line 262
    .line 263
    check-cast v15, Ljava/lang/String;

    .line 264
    .line 265
    move-object/from16 v1, p1

    .line 266
    .line 267
    check-cast v1, Landroid/graphics/Bitmap;

    .line 268
    .line 269
    const-string v3, "bitmap"

    .line 270
    .line 271
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 272
    .line 273
    .line 274
    iget-object v3, v2, Lio/sentry/internal/debugmeta/c;->e:Ljava/lang/Object;

    .line 275
    .line 276
    check-cast v3, Lcom/discord/chat/input/views/DCDChatInput;

    .line 277
    .line 278
    invoke-virtual {v3}, Landroid/widget/TextView;->getEditableText()Landroid/text/Editable;

    .line 279
    .line 280
    .line 281
    move-result-object v3

    .line 282
    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    .line 283
    .line 284
    .line 285
    move-result v4

    .line 286
    const-class v5, Lkb/d;

    .line 287
    .line 288
    invoke-interface {v3, v11, v4, v5}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v4

    .line 292
    const-string v5, "getSpans(...)"

    .line 293
    .line 294
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    check-cast v4, [Lkb/d;

    .line 298
    .line 299
    array-length v5, v4

    .line 300
    :goto_12b
    if-ge v11, v5, :cond_151

    .line 301
    .line 302
    aget-object v6, v4, v11

    .line 303
    .line 304
    iget-object v7, v6, Lkb/d;->d:Ljava/lang/String;

    .line 305
    .line 306
    invoke-static {v7, v15}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v7

    .line 310
    if-eqz v7, :cond_14e

    .line 311
    .line 312
    invoke-interface {v3, v6}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 313
    .line 314
    .line 315
    move-result v7

    .line 316
    invoke-interface {v3, v6}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 317
    .line 318
    .line 319
    move-result v8

    .line 320
    iget v9, v6, Lkb/d;->i:I

    .line 321
    .line 322
    iget v10, v6, Lkb/d;->v:F

    .line 323
    .line 324
    invoke-virtual {v2, v1, v9, v10}, Lio/sentry/internal/debugmeta/c;->A(Landroid/graphics/Bitmap;IF)Lj1/a;

    .line 325
    .line 326
    .line 327
    move-result-object v9

    .line 328
    iput-object v9, v6, Lkb/d;->e:Landroid/graphics/drawable/Drawable;

    .line 329
    .line 330
    const/16 v9, 0x21

    .line 331
    .line 332
    invoke-interface {v3, v6, v7, v8, v9}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 333
    .line 334
    .line 335
    :cond_14e
    add-int/lit8 v11, v11, 0x1

    .line 336
    .line 337
    goto :goto_12b

    .line 338
    :cond_151
    return-object v14

    .line 339
    :pswitch_152
    check-cast v2, Lgh/s;

    .line 340
    .line 341
    check-cast v15, Lgh/e0;

    .line 342
    .line 343
    move-object/from16 v1, p1

    .line 344
    .line 345
    check-cast v1, Lti/d;

    .line 346
    .line 347
    const-string v3, "$this$i18nFormat"

    .line 348
    .line 349
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 350
    .line 351
    .line 352
    iget-object v1, v1, Lti/d;->a:Ljava/util/HashMap;

    .line 353
    .line 354
    if-eqz v2, :cond_18b

    .line 355
    .line 356
    iget-object v2, v2, Lgh/s;->a:Ljava/util/List;

    .line 357
    .line 358
    if-eqz v2, :cond_18b

    .line 359
    .line 360
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 361
    .line 362
    .line 363
    move-result-object v2

    .line 364
    :cond_16b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 365
    .line 366
    .line 367
    move-result v3

    .line 368
    if-eqz v3, :cond_183

    .line 369
    .line 370
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    move-result-object v3

    .line 374
    move-object v4, v3

    .line 375
    check-cast v4, Lgh/v;

    .line 376
    .line 377
    iget-object v4, v4, Lgh/v;->a:Ljava/lang/String;

    .line 378
    .line 379
    const-string v5, "poll_question_text"

    .line 380
    .line 381
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 382
    .line 383
    .line 384
    move-result v4

    .line 385
    if-eqz v4, :cond_16b

    .line 386
    .line 387
    move-object v9, v3

    .line 388
    :cond_183
    check-cast v9, Lgh/v;

    .line 389
    .line 390
    if-eqz v9, :cond_18b

    .line 391
    .line 392
    iget-object v2, v9, Lgh/v;->b:Ljava/lang/String;

    .line 393
    .line 394
    if-nez v2, :cond_191

    .line 395
    .line 396
    :cond_18b
    iget-object v2, v15, Lgh/e0;->k0:Ljava/lang/String;

    .line 397
    .line 398
    if-nez v2, :cond_191

    .line 399
    .line 400
    const-string v2, ""

    .line 401
    .line 402
    :cond_191
    const-string v3, "question"

    .line 403
    .line 404
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 405
    .line 406
    .line 407
    return-object v14

    .line 408
    :pswitch_197
    check-cast v2, Lad/d;

    .line 409
    .line 410
    check-cast v15, Lcom/facebook/react/bridge/ReactApplicationContext;

    .line 411
    .line 412
    move-object/from16 v1, p1

    .line 413
    .line 414
    check-cast v1, Lld/g;

    .line 415
    .line 416
    if-eqz v1, :cond_1ca

    .line 417
    .line 418
    iget-object v3, v1, Lld/g;->a:Ljava/lang/String;

    .line 419
    .line 420
    const-string v4, "\n"

    .line 421
    .line 422
    filled-new-array {v4}, [Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object v4

    .line 426
    invoke-static {v3, v4, v6}, Lw60/o;->K0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    .line 427
    .line 428
    .line 429
    move-result-object v3

    .line 430
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 431
    .line 432
    .line 433
    move-result-object v3

    .line 434
    :goto_1b1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 435
    .line 436
    .line 437
    move-result v4

    .line 438
    if-eqz v4, :cond_1c3

    .line 439
    .line 440
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 441
    .line 442
    .line 443
    move-result-object v4

    .line 444
    check-cast v4, Ljava/lang/String;

    .line 445
    .line 446
    const-string v5, "Tombstone"

    .line 447
    .line 448
    invoke-static {v4, v5}, Lsg/a;->U(Ljava/lang/String;Ljava/lang/String;)V

    .line 449
    .line 450
    .line 451
    goto :goto_1b1

    .line 452
    :cond_1c3
    iget-object v3, v1, Lld/g;->e:Ljava/lang/String;

    .line 453
    .line 454
    const-string v4, "Tombstone-Hash"

    .line 455
    .line 456
    invoke-static {v3, v4}, Lsg/a;->U(Ljava/lang/String;Ljava/lang/String;)V

    .line 457
    .line 458
    .line 459
    :cond_1ca
    new-instance v3, Lld/e;

    .line 460
    .line 461
    invoke-static {v15}, Lld/b;->a(Lcom/facebook/react/bridge/ReactApplicationContext;)Lld/a;

    .line 462
    .line 463
    .line 464
    move-result-object v4

    .line 465
    invoke-direct {v3, v4, v1}, Lld/e;-><init>(Lld/a;Lld/g;)V

    .line 466
    .line 467
    .line 468
    invoke-virtual {v2, v3}, Lad/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 469
    .line 470
    .line 471
    return-object v14

    .line 472
    :pswitch_1d7
    check-cast v2, Landroid/os/CancellationSignal;

    .line 473
    .line 474
    check-cast v15, Lj2/a;

    .line 475
    .line 476
    iget-object v1, v15, Lj2/a;->e:Landroid/content/Context;

    .line 477
    .line 478
    move-object/from16 v3, p1

    .line 479
    .line 480
    check-cast v3, Lxu/l;

    .line 481
    .line 482
    sget-object v4, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->Companion:Ld2/e;

    .line 483
    .line 484
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 485
    .line 486
    .line 487
    invoke-static {v2}, Ld2/e;->a(Landroid/os/CancellationSignal;)Z

    .line 488
    .line 489
    .line 490
    move-result v2

    .line 491
    if-eqz v2, :cond_1ed

    .line 492
    .line 493
    goto :goto_213

    .line 494
    :cond_1ed
    new-instance v2, Landroid/content/Intent;

    .line 495
    .line 496
    const-class v4, Landroidx/credentials/playservices/controllers/identitycredentials/IdentityCredentialApiHiddenActivity;

    .line 497
    .line 498
    invoke-direct {v2, v1, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 499
    .line 500
    .line 501
    const/high16 v4, 0x10000

    .line 502
    .line 503
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 504
    .line 505
    .line 506
    iget-object v4, v15, Lj2/a;->i:Lf2/c;

    .line 507
    .line 508
    invoke-static {v4}, Le2/d;->d(Landroid/os/ResultReceiver;)Landroid/os/ResultReceiver;

    .line 509
    .line 510
    .line 511
    move-result-object v4

    .line 512
    const-string v5, "RESULT_RECEIVER"

    .line 513
    .line 514
    invoke-virtual {v2, v5, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 515
    .line 516
    .line 517
    iget-object v3, v3, Lxu/l;->d:Landroid/app/PendingIntent;

    .line 518
    .line 519
    invoke-virtual {v2, v8, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 520
    .line 521
    .line 522
    const-string v3, "EXTRA_ERROR_NAME"

    .line 523
    .line 524
    const-string v4, "GET_UNKNOWN"

    .line 525
    .line 526
    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 527
    .line 528
    .line 529
    invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 530
    .line 531
    .line 532
    :goto_213
    return-object v14

    .line 533
    :pswitch_214
    check-cast v2, Lik/o;

    .line 534
    .line 535
    check-cast v15, Lik/a;

    .line 536
    .line 537
    move-object/from16 v1, p1

    .line 538
    .line 539
    check-cast v1, Lr1/i;

    .line 540
    .line 541
    const-string v3, "$this$addCall"

    .line 542
    .line 543
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    new-instance v3, Lik/k;

    .line 547
    .line 548
    invoke-direct {v3, v2, v1, v15, v9}, Lik/k;-><init>(Lik/o;Lr1/i;Lik/a;Lq30/c;)V

    .line 549
    .line 550
    .line 551
    invoke-static {v1, v9, v3, v5}, Lz60/z;->v(Lz60/x;Lq30/h;Lkotlin/jvm/functions/Function2;I)Lz60/r1;

    .line 552
    .line 553
    .line 554
    return-object v14

    .line 555
    :pswitch_22a
    check-cast v2, Lcom/discord/metric_monitor/MetricMonitorModule;

    .line 556
    .line 557
    check-cast v15, Lcom/facebook/react/bridge/ReactApplicationContext;

    .line 558
    .line 559
    move-object/from16 v1, p1

    .line 560
    .line 561
    check-cast v1, Lgg/c;

    .line 562
    .line 563
    invoke-static {v2, v15, v1}, Lcom/discord/metric_monitor/MetricMonitorModule;->a(Lcom/discord/metric_monitor/MetricMonitorModule;Lcom/facebook/react/bridge/ReactApplicationContext;Lgg/c;)Ll30/a0;

    .line 564
    .line 565
    .line 566
    move-result-object v1

    .line 567
    return-object v1

    .line 568
    :pswitch_237
    check-cast v2, Lg20/c;

    .line 569
    .line 570
    check-cast v15, Ljava/lang/String;

    .line 571
    .line 572
    move-object/from16 v1, p1

    .line 573
    .line 574
    check-cast v1, Lb20/c;

    .line 575
    .line 576
    invoke-static {v1, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 577
    .line 578
    .line 579
    sget-object v3, Lb20/b;->a:Lb20/b;

    .line 580
    .line 581
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 582
    .line 583
    .line 584
    move-result v3

    .line 585
    if-eqz v3, :cond_253

    .line 586
    .line 587
    iget-object v1, v2, Lg20/c;->d0:Ljava/util/Map;

    .line 588
    .line 589
    invoke-interface {v1, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 590
    .line 591
    .line 592
    move-result-object v1

    .line 593
    check-cast v1, Landroid/graphics/drawable/Drawable;

    .line 594
    .line 595
    goto :goto_268

    .line 596
    :cond_253
    instance-of v3, v1, Lb20/a;

    .line 597
    .line 598
    if-eqz v3, :cond_28f

    .line 599
    .line 600
    iget-object v3, v2, Lg20/c;->d0:Ljava/util/Map;

    .line 601
    .line 602
    check-cast v1, Lb20/a;

    .line 603
    .line 604
    iget-object v1, v1, Lb20/a;->a:Landroid/graphics/drawable/Drawable;

    .line 605
    .line 606
    new-instance v4, Ll30/j;

    .line 607
    .line 608
    invoke-direct {v4, v15, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 609
    .line 610
    .line 611
    invoke-static {v3, v4}, Lm30/x;->u0(Ljava/util/Map;Ll30/j;)Ljava/util/Map;

    .line 612
    .line 613
    .line 614
    move-result-object v3

    .line 615
    iput-object v3, v2, Lg20/c;->d0:Ljava/util/Map;

    .line 616
    .line 617
    :goto_268
    invoke-virtual {v2}, Lg20/c;->getToolbarMenu()Li20/e;

    .line 618
    .line 619
    .line 620
    move-result-object v3

    .line 621
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 622
    .line 623
    .line 624
    const-string v4, "id"

    .line 625
    .line 626
    invoke-static {v15, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 627
    .line 628
    .line 629
    iget-object v4, v3, Li20/e;->b:Ljava/util/List;

    .line 630
    .line 631
    invoke-static {v4, v15, v1}, Li20/e;->b(Ljava/util/List;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Ljava/util/List;

    .line 632
    .line 633
    .line 634
    move-result-object v1

    .line 635
    if-eq v1, v4, :cond_281

    .line 636
    .line 637
    invoke-static {v3, v1}, Li20/e;->a(Li20/e;Ljava/util/List;)Li20/e;

    .line 638
    .line 639
    .line 640
    move-result-object v1

    .line 641
    goto :goto_282

    .line 642
    :cond_281
    move-object v1, v3

    .line 643
    :goto_282
    if-eq v1, v3, :cond_28e

    .line 644
    .line 645
    invoke-virtual {v2, v1}, Lg20/c;->setToolbarMenu$react_native_screens_release(Li20/e;)V

    .line 646
    .line 647
    .line 648
    iget-boolean v1, v2, Lg20/c;->l0:Z

    .line 649
    .line 650
    if-nez v1, :cond_28e

    .line 651
    .line 652
    invoke-virtual {v2}, Lg20/c;->n()V

    .line 653
    .line 654
    .line 655
    :cond_28e
    return-object v14

    .line 656
    :cond_28f
    new-instance v1, Lan/g;

    .line 657
    .line 658
    invoke-direct {v1, v11}, Lan/g;-><init>(Z)V

    .line 659
    .line 660
    .line 661
    throw v1

    .line 662
    :pswitch_295
    check-cast v2, Landroid/os/CancellationSignal;

    .line 663
    .line 664
    check-cast v15, Lg2/e;

    .line 665
    .line 666
    iget-object v1, v15, Lg2/e;->e:Landroid/content/Context;

    .line 667
    .line 668
    move-object/from16 v5, p1

    .line 669
    .line 670
    check-cast v5, Landroid/app/PendingIntent;

    .line 671
    .line 672
    invoke-static {v5, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 673
    .line 674
    .line 675
    sget-object v4, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->Companion:Ld2/e;

    .line 676
    .line 677
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 678
    .line 679
    .line 680
    invoke-static {v2}, Ld2/e;->a(Landroid/os/CancellationSignal;)Z

    .line 681
    .line 682
    .line 683
    move-result v4

    .line 684
    if-eqz v4, :cond_2ae

    .line 685
    .line 686
    goto :goto_2d9

    .line 687
    :cond_2ae
    new-instance v4, Landroid/content/Intent;

    .line 688
    .line 689
    invoke-direct {v4, v1, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 690
    .line 691
    .line 692
    iget-object v3, v15, Lg2/e;->i:Lf2/c;

    .line 693
    .line 694
    const-string v6, "CREATE_PUBLIC_KEY_CREDENTIAL"

    .line 695
    .line 696
    invoke-static {v3, v4, v6}, Le2/d;->a(Landroid/os/ResultReceiver;Landroid/content/Intent;Ljava/lang/String;)V

    .line 697
    .line 698
    .line 699
    invoke-virtual {v4, v8, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 700
    .line 701
    .line 702
    :try_start_2bd
    invoke-virtual {v1, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_2c0
    .catch Ljava/lang/Exception; {:try_start_2bd .. :try_end_2c0} :catch_2c1

    .line 703
    .line 704
    .line 705
    goto :goto_2d9

    .line 706
    :catch_2c1
    sget-object v1, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->Companion:Ld2/e;

    .line 707
    .line 708
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 709
    .line 710
    .line 711
    invoke-static {v2}, Ld2/e;->a(Landroid/os/CancellationSignal;)Z

    .line 712
    .line 713
    .line 714
    move-result v1

    .line 715
    if-eqz v1, :cond_2cd

    .line 716
    .line 717
    goto :goto_2d9

    .line 718
    :cond_2cd
    iget-object v1, v15, Lg2/e;->g:Ljava/util/concurrent/Executor;

    .line 719
    .line 720
    if-eqz v1, :cond_2da

    .line 721
    .line 722
    new-instance v2, Lg2/c;

    .line 723
    .line 724
    invoke-direct {v2, v15, v11}, Lg2/c;-><init>(Lg2/e;I)V

    .line 725
    .line 726
    .line 727
    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 728
    .line 729
    .line 730
    :goto_2d9
    return-object v14

    .line 731
    :cond_2da
    const-string v1, "executor"

    .line 732
    .line 733
    invoke-static {v1}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 734
    .line 735
    .line 736
    throw v9

    .line 737
    :pswitch_2e0
    check-cast v2, Lf2/b;

    .line 738
    .line 739
    check-cast v15, Ljava/lang/String;

    .line 740
    .line 741
    move-object/from16 v1, p1

    .line 742
    .line 743
    check-cast v1, Ly9/c1;

    .line 744
    .line 745
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 746
    .line 747
    .line 748
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 749
    .line 750
    invoke-direct {v3, v15}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 751
    .line 752
    .line 753
    invoke-virtual {v2, v3, v1}, Lf2/b;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 754
    .line 755
    .line 756
    return-object v14

    .line 757
    :pswitch_2f4
    check-cast v2, Lzb/k;

    .line 758
    .line 759
    check-cast v15, Lbc/m0;

    .line 760
    .line 761
    move-object/from16 v1, p1

    .line 762
    .line 763
    check-cast v1, Ly9/c1;

    .line 764
    .line 765
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 766
    .line 767
    .line 768
    iget-object v3, v15, Lbc/m0;->d:Ljava/lang/String;

    .line 769
    .line 770
    new-instance v4, Lcom/discord/primitives/MessageId;

    .line 771
    .line 772
    invoke-direct {v4, v3}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 773
    .line 774
    .line 775
    invoke-virtual {v2, v4, v1}, Lzb/k;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 776
    .line 777
    .line 778
    return-object v14

    .line 779
    :pswitch_30a
    check-cast v2, Lzb/k;

    .line 780
    .line 781
    check-cast v15, Lbc/k0;

    .line 782
    .line 783
    move-object/from16 v1, p1

    .line 784
    .line 785
    check-cast v1, Ly9/c1;

    .line 786
    .line 787
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 788
    .line 789
    .line 790
    iget-object v3, v15, Lbc/k0;->d:Ljava/lang/String;

    .line 791
    .line 792
    new-instance v4, Lcom/discord/primitives/MessageId;

    .line 793
    .line 794
    invoke-direct {v4, v3}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 795
    .line 796
    .line 797
    invoke-virtual {v2, v4, v1}, Lzb/k;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 798
    .line 799
    .line 800
    return-object v14

    .line 801
    :pswitch_320
    check-cast v2, Leg/e0;

    .line 802
    .line 803
    check-cast v15, Lcom/discord/chat/presentation/message/view/MediaView;

    .line 804
    .line 805
    move-object/from16 v1, p1

    .line 806
    .line 807
    check-cast v1, Landroid/view/View;

    .line 808
    .line 809
    sget v3, Lcom/discord/chat/presentation/message/view/MediaView;->i0:I

    .line 810
    .line 811
    invoke-static {v1, v12}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 812
    .line 813
    .line 814
    iget-object v1, v2, Leg/e0;->k:Ljava/lang/Double;

    .line 815
    .line 816
    iget-object v2, v15, Lcom/discord/chat/presentation/message/view/MediaView;->i:Leg/e0;

    .line 817
    .line 818
    if-eqz v2, :cond_336

    .line 819
    .line 820
    iget-object v2, v2, Leg/e0;->k:Ljava/lang/Double;

    .line 821
    .line 822
    goto :goto_337

    .line 823
    :cond_336
    move-object v2, v9

    .line 824
    :goto_337
    if-nez v1, :cond_33c

    .line 825
    .line 826
    if-nez v2, :cond_383

    .line 827
    .line 828
    goto :goto_34a

    .line 829
    :cond_33c
    if-eqz v2, :cond_383

    .line 830
    .line 831
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 832
    .line 833
    .line 834
    move-result-wide v3

    .line 835
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 836
    .line 837
    .line 838
    move-result-wide v1

    .line 839
    cmpl-double v1, v3, v1

    .line 840
    .line 841
    if-nez v1, :cond_383

    .line 842
    .line 843
    :goto_34a
    iget-object v1, v15, Lcom/discord/chat/presentation/message/view/MediaView;->v:Leg/h0;

    .line 844
    .line 845
    if-eqz v1, :cond_351

    .line 846
    .line 847
    invoke-virtual {v15}, Lcom/discord/chat/presentation/message/view/MediaView;->e()V

    .line 848
    .line 849
    .line 850
    :cond_351
    iput-object v9, v15, Lcom/discord/chat/presentation/message/view/MediaView;->e:Leg/d0;

    .line 851
    .line 852
    const/16 v36, 0x0

    .line 853
    .line 854
    const v37, 0xfffef

    .line 855
    .line 856
    .line 857
    const/16 v17, 0x0

    .line 858
    .line 859
    const/16 v18, 0x0

    .line 860
    .line 861
    const/16 v19, 0x0

    .line 862
    .line 863
    const/16 v20, 0x0

    .line 864
    .line 865
    const/16 v21, 0x0

    .line 866
    .line 867
    const/16 v22, 0x0

    .line 868
    .line 869
    const/16 v23, 0x0

    .line 870
    .line 871
    const/16 v24, 0x0

    .line 872
    .line 873
    const/16 v25, 0x0

    .line 874
    .line 875
    const/16 v26, 0x0

    .line 876
    .line 877
    const/16 v27, 0x0

    .line 878
    .line 879
    const/16 v28, 0x0

    .line 880
    .line 881
    const/16 v29, 0x0

    .line 882
    .line 883
    const/16 v30, 0x0

    .line 884
    .line 885
    const/16 v31, 0x0

    .line 886
    .line 887
    const/16 v32, 0x0

    .line 888
    .line 889
    const/16 v33, 0x0

    .line 890
    .line 891
    const/16 v34, 0x0

    .line 892
    .line 893
    const/16 v35, 0x0

    .line 894
    .line 895
    move-object/from16 v16, v15

    .line 896
    .line 897
    invoke-static/range {v16 .. v37}, Lcom/discord/chat/presentation/message/view/MediaView;->f(Lcom/discord/chat/presentation/message/view/MediaView;Leg/e0;ZZZLeg/n;ZLjava/lang/Integer;Lwh/b;IZZZILkotlin/jvm/functions/Function0;Ljava/lang/String;Lii/a;Ljava/lang/Integer;Ljava/lang/Integer;Leg/o;Lam/p;I)V

    .line 898
    .line 899
    .line 900
    :cond_383
    iget-object v1, v15, Lcom/discord/chat/presentation/message/view/MediaView;->g0:Lnc/a;

    .line 901
    .line 902
    invoke-virtual {v15, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 903
    .line 904
    .line 905
    return-object v14

    .line 906
    :pswitch_389
    check-cast v2, Lf2/b;

    .line 907
    .line 908
    check-cast v15, Ljava/lang/String;

    .line 909
    .line 910
    move-object/from16 v1, p1

    .line 911
    .line 912
    check-cast v1, Ly9/c1;

    .line 913
    .line 914
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 915
    .line 916
    .line 917
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 918
    .line 919
    invoke-direct {v3, v15}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 920
    .line 921
    .line 922
    invoke-virtual {v2, v3, v1}, Lf2/b;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 923
    .line 924
    .line 925
    return-object v14

    .line 926
    :pswitch_39d
    check-cast v2, Lzb/l;

    .line 927
    .line 928
    check-cast v15, Ljava/lang/String;

    .line 929
    .line 930
    move-object/from16 v1, p1

    .line 931
    .line 932
    check-cast v1, Ly9/c1;

    .line 933
    .line 934
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 935
    .line 936
    .line 937
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 938
    .line 939
    invoke-direct {v3, v15}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 940
    .line 941
    .line 942
    invoke-virtual {v2, v3, v1}, Lzb/l;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 943
    .line 944
    .line 945
    return-object v14

    .line 946
    :pswitch_3b1
    check-cast v2, Lf2/b;

    .line 947
    .line 948
    check-cast v15, Ljava/lang/String;

    .line 949
    .line 950
    move-object/from16 v1, p1

    .line 951
    .line 952
    check-cast v1, Ly9/c1;

    .line 953
    .line 954
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 955
    .line 956
    .line 957
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 958
    .line 959
    invoke-direct {v3, v15}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 960
    .line 961
    .line 962
    invoke-virtual {v2, v3, v1}, Lf2/b;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 963
    .line 964
    .line 965
    return-object v14

    .line 966
    :pswitch_3c5
    check-cast v2, Lf2/b;

    .line 967
    .line 968
    check-cast v15, Ljava/lang/String;

    .line 969
    .line 970
    move-object/from16 v1, p1

    .line 971
    .line 972
    check-cast v1, Ly9/c1;

    .line 973
    .line 974
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 975
    .line 976
    .line 977
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 978
    .line 979
    invoke-direct {v3, v15}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 980
    .line 981
    .line 982
    invoke-virtual {v2, v3, v1}, Lf2/b;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 983
    .line 984
    .line 985
    return-object v14

    .line 986
    :pswitch_3d9
    check-cast v2, Lkotlin/jvm/functions/Function2;

    .line 987
    .line 988
    check-cast v15, Ljava/lang/String;

    .line 989
    .line 990
    move-object/from16 v1, p1

    .line 991
    .line 992
    check-cast v1, Ly9/c1;

    .line 993
    .line 994
    invoke-static {v1, v13}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 995
    .line 996
    .line 997
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 998
    .line 999
    invoke-direct {v3, v15}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 1000
    .line 1001
    .line 1002
    invoke-interface {v2, v3, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1003
    .line 1004
    .line 1005
    return-object v14

    .line 1006
    :pswitch_3ed
    check-cast v2, Landroid/os/CancellationSignal;

    .line 1007
    .line 1008
    check-cast v15, Lf2/d;

    .line 1009
    .line 1010
    iget-object v1, v15, Lf2/d;->e:Landroid/content/Context;

    .line 1011
    .line 1012
    move-object/from16 v4, p1

    .line 1013
    .line 1014
    check-cast v4, Lyt/f;

    .line 1015
    .line 1016
    sget-object v5, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->Companion:Ld2/e;

    .line 1017
    .line 1018
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1019
    .line 1020
    .line 1021
    invoke-static {v2}, Ld2/e;->a(Landroid/os/CancellationSignal;)Z

    .line 1022
    .line 1023
    .line 1024
    move-result v5

    .line 1025
    if-eqz v5, :cond_403

    .line 1026
    .line 1027
    goto :goto_431

    .line 1028
    :cond_403
    new-instance v5, Landroid/content/Intent;

    .line 1029
    .line 1030
    invoke-direct {v5, v1, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1031
    .line 1032
    .line 1033
    iget-object v3, v15, Lf2/d;->i:Lf2/c;

    .line 1034
    .line 1035
    const-string v6, "BEGIN_SIGN_IN"

    .line 1036
    .line 1037
    invoke-static {v3, v5, v6}, Le2/d;->a(Landroid/os/ResultReceiver;Landroid/content/Intent;Ljava/lang/String;)V

    .line 1038
    .line 1039
    .line 1040
    iget-object v3, v4, Lyt/f;->d:Landroid/app/PendingIntent;

    .line 1041
    .line 1042
    invoke-virtual {v5, v8, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 1043
    .line 1044
    .line 1045
    :try_start_414
    invoke-virtual {v1, v5}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_417
    .catch Ljava/lang/Exception; {:try_start_414 .. :try_end_417} :catch_418

    .line 1046
    .line 1047
    .line 1048
    goto :goto_431

    .line 1049
    :catch_418
    sget-object v1, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->Companion:Ld2/e;

    .line 1050
    .line 1051
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1052
    .line 1053
    .line 1054
    invoke-static {v2}, Ld2/e;->a(Landroid/os/CancellationSignal;)Z

    .line 1055
    .line 1056
    .line 1057
    move-result v1

    .line 1058
    if-eqz v1, :cond_424

    .line 1059
    .line 1060
    goto :goto_431

    .line 1061
    :cond_424
    invoke-virtual {v15}, Lf2/d;->g()Ljava/util/concurrent/Executor;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v1

    .line 1065
    new-instance v2, Le/k;

    .line 1066
    .line 1067
    const/4 v3, 0x2

    .line 1068
    invoke-direct {v2, v3, v15}, Le/k;-><init>(ILjava/lang/Object;)V

    .line 1069
    .line 1070
    .line 1071
    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 1072
    .line 1073
    .line 1074
    :goto_431
    return-object v14

    .line 1075
    :pswitch_432
    check-cast v2, Ldg/c;

    .line 1076
    .line 1077
    check-cast v15, Lcg/h;

    .line 1078
    .line 1079
    move-object/from16 v1, p1

    .line 1080
    .line 1081
    check-cast v1, Lcg/g0;

    .line 1082
    .line 1083
    invoke-static {v1, v7}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1084
    .line 1085
    .line 1086
    iget-object v3, v2, Ldg/c;->P:Lcg/h;

    .line 1087
    .line 1088
    if-ne v3, v15, :cond_563

    .line 1089
    .line 1090
    iget-boolean v3, v2, Ldg/c;->V:Z

    .line 1091
    .line 1092
    if-nez v3, :cond_563

    .line 1093
    .line 1094
    sget-object v3, Lcg/z;->a:Lcg/z;

    .line 1095
    .line 1096
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1097
    .line 1098
    .line 1099
    move-result v3

    .line 1100
    if-nez v3, :cond_563

    .line 1101
    .line 1102
    sget-object v3, Lcg/y;->a:Lcg/y;

    .line 1103
    .line 1104
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1105
    .line 1106
    .line 1107
    move-result v3

    .line 1108
    const/16 v4, 0x18

    .line 1109
    .line 1110
    if-eqz v3, :cond_463

    .line 1111
    .line 1112
    new-instance v1, Lac/b;

    .line 1113
    .line 1114
    invoke-direct {v1, v4}, Lac/b;-><init>(I)V

    .line 1115
    .line 1116
    .line 1117
    const-string v3, "loading"

    .line 1118
    .line 1119
    invoke-virtual {v2, v3, v1}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1120
    .line 1121
    .line 1122
    goto/16 :goto_563

    .line 1123
    .line 1124
    :cond_463
    instance-of v3, v1, Lcg/x;

    .line 1125
    .line 1126
    if-eqz v3, :cond_473

    .line 1127
    .line 1128
    new-instance v3, Ldg/b;

    .line 1129
    .line 1130
    invoke-direct {v3, v1, v11}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1131
    .line 1132
    .line 1133
    const-string v1, "loaded"

    .line 1134
    .line 1135
    invoke-virtual {v2, v1, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1136
    .line 1137
    .line 1138
    goto/16 :goto_563

    .line 1139
    .line 1140
    :cond_473
    sget-object v3, Lcg/w;->a:Lcg/w;

    .line 1141
    .line 1142
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1143
    .line 1144
    .line 1145
    move-result v3

    .line 1146
    if-eqz v3, :cond_487

    .line 1147
    .line 1148
    new-instance v1, Lac/b;

    .line 1149
    .line 1150
    invoke-direct {v1, v4}, Lac/b;-><init>(I)V

    .line 1151
    .line 1152
    .line 1153
    const-string v3, "firstFrame"

    .line 1154
    .line 1155
    invoke-virtual {v2, v3, v1}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1156
    .line 1157
    .line 1158
    goto/16 :goto_563

    .line 1159
    .line 1160
    :cond_487
    instance-of v3, v1, Lcg/s;

    .line 1161
    .line 1162
    if-eqz v3, :cond_4b1

    .line 1163
    .line 1164
    new-instance v3, Ldg/b;

    .line 1165
    .line 1166
    invoke-direct {v3, v1, v10}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1167
    .line 1168
    .line 1169
    const-string v5, "buffering"

    .line 1170
    .line 1171
    invoke-virtual {v2, v5, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1172
    .line 1173
    .line 1174
    check-cast v1, Lcg/s;

    .line 1175
    .line 1176
    iget-boolean v1, v1, Lcg/s;->a:Z

    .line 1177
    .line 1178
    if-eqz v1, :cond_563

    .line 1179
    .line 1180
    iget-boolean v1, v2, Ldg/c;->W:Z

    .line 1181
    .line 1182
    if-eqz v1, :cond_563

    .line 1183
    .line 1184
    iget-boolean v1, v2, Ldg/c;->a0:Z

    .line 1185
    .line 1186
    if-nez v1, :cond_563

    .line 1187
    .line 1188
    iput-boolean v10, v2, Ldg/c;->a0:Z

    .line 1189
    .line 1190
    new-instance v1, Lac/b;

    .line 1191
    .line 1192
    invoke-direct {v1, v4}, Lac/b;-><init>(I)V

    .line 1193
    .line 1194
    .line 1195
    const-string v3, "stalled"

    .line 1196
    .line 1197
    invoke-virtual {v2, v3, v1}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1198
    .line 1199
    .line 1200
    goto/16 :goto_563

    .line 1201
    .line 1202
    :cond_4b1
    instance-of v3, v1, Lcg/a0;

    .line 1203
    .line 1204
    if-eqz v3, :cond_4e4

    .line 1205
    .line 1206
    check-cast v1, Lcg/a0;

    .line 1207
    .line 1208
    iget-boolean v1, v1, Lcg/a0;->a:Z

    .line 1209
    .line 1210
    if-eqz v1, :cond_4cd

    .line 1211
    .line 1212
    iput-boolean v10, v2, Ldg/c;->W:Z

    .line 1213
    .line 1214
    iget-boolean v1, v2, Ldg/c;->a0:Z

    .line 1215
    .line 1216
    if-eqz v1, :cond_4cd

    .line 1217
    .line 1218
    iput-boolean v11, v2, Ldg/c;->a0:Z

    .line 1219
    .line 1220
    new-instance v1, Lac/b;

    .line 1221
    .line 1222
    invoke-direct {v1, v4}, Lac/b;-><init>(I)V

    .line 1223
    .line 1224
    .line 1225
    const-string v3, "resumed"

    .line 1226
    .line 1227
    invoke-virtual {v2, v3, v1}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1228
    .line 1229
    .line 1230
    :cond_4cd
    iget-boolean v1, v2, Ldg/c;->M:Z

    .line 1231
    .line 1232
    if-eqz v1, :cond_4de

    .line 1233
    .line 1234
    iget-object v1, v2, Ldg/c;->P:Lcg/h;

    .line 1235
    .line 1236
    if-eqz v1, :cond_4de

    .line 1237
    .line 1238
    invoke-virtual {v1}, Lcg/h;->f()Lcg/n0;

    .line 1239
    .line 1240
    .line 1241
    move-result-object v1

    .line 1242
    iget-boolean v1, v1, Lcg/n0;->d:Z

    .line 1243
    .line 1244
    if-ne v1, v10, :cond_4de

    .line 1245
    .line 1246
    goto :goto_4df

    .line 1247
    :cond_4de
    move v10, v11

    .line 1248
    :goto_4df
    invoke-virtual {v2, v10}, Landroid/view/View;->setKeepScreenOn(Z)V

    .line 1249
    .line 1250
    .line 1251
    goto/16 :goto_563

    .line 1252
    .line 1253
    :cond_4e4
    instance-of v3, v1, Lcg/c0;

    .line 1254
    .line 1255
    if-eqz v3, :cond_4f5

    .line 1256
    .line 1257
    new-instance v3, Ldg/b;

    .line 1258
    .line 1259
    const/4 v4, 0x2

    .line 1260
    invoke-direct {v3, v1, v4}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1261
    .line 1262
    .line 1263
    const-string v1, "rate"

    .line 1264
    .line 1265
    invoke-virtual {v2, v1, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1266
    .line 1267
    .line 1268
    goto/16 :goto_563

    .line 1269
    .line 1270
    :cond_4f5
    instance-of v3, v1, Lcg/b0;

    .line 1271
    .line 1272
    if-eqz v3, :cond_504

    .line 1273
    .line 1274
    new-instance v1, Lac/b;

    .line 1275
    .line 1276
    invoke-direct {v1, v4}, Lac/b;-><init>(I)V

    .line 1277
    .line 1278
    .line 1279
    const-string v3, "progress"

    .line 1280
    .line 1281
    invoke-virtual {v2, v3, v1}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1282
    .line 1283
    .line 1284
    goto :goto_563

    .line 1285
    :cond_504
    instance-of v3, v1, Lcg/e0;

    .line 1286
    .line 1287
    if-eqz v3, :cond_513

    .line 1288
    .line 1289
    new-instance v3, Ldg/b;

    .line 1290
    .line 1291
    invoke-direct {v3, v1, v5}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1292
    .line 1293
    .line 1294
    const-string v1, "seek"

    .line 1295
    .line 1296
    invoke-virtual {v2, v1, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1297
    .line 1298
    .line 1299
    goto :goto_563

    .line 1300
    :cond_513
    instance-of v3, v1, Lcg/t;

    .line 1301
    .line 1302
    if-eqz v3, :cond_523

    .line 1303
    .line 1304
    new-instance v3, Ldg/b;

    .line 1305
    .line 1306
    const/4 v4, 0x4

    .line 1307
    invoke-direct {v3, v1, v4}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1308
    .line 1309
    .line 1310
    const-string v1, "downloadProgress"

    .line 1311
    .line 1312
    invoke-virtual {v2, v1, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1313
    .line 1314
    .line 1315
    goto :goto_563

    .line 1316
    :cond_523
    instance-of v3, v1, Lcg/f0;

    .line 1317
    .line 1318
    if-eqz v3, :cond_533

    .line 1319
    .line 1320
    new-instance v3, Ldg/b;

    .line 1321
    .line 1322
    const/4 v4, 0x5

    .line 1323
    invoke-direct {v3, v1, v4}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1324
    .line 1325
    .line 1326
    const-string v1, "tracks"

    .line 1327
    .line 1328
    invoke-virtual {v2, v1, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1329
    .line 1330
    .line 1331
    goto :goto_563

    .line 1332
    :cond_533
    sget-object v3, Lcg/u;->a:Lcg/u;

    .line 1333
    .line 1334
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1335
    .line 1336
    .line 1337
    move-result v3

    .line 1338
    if-nez v3, :cond_559

    .line 1339
    .line 1340
    sget-object v3, Lcg/d0;->a:Lcg/d0;

    .line 1341
    .line 1342
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1343
    .line 1344
    .line 1345
    move-result v3

    .line 1346
    if-eqz v3, :cond_544

    .line 1347
    .line 1348
    goto :goto_559

    .line 1349
    :cond_544
    instance-of v3, v1, Lcg/v;

    .line 1350
    .line 1351
    if-eqz v3, :cond_553

    .line 1352
    .line 1353
    new-instance v3, Ldg/b;

    .line 1354
    .line 1355
    invoke-direct {v3, v1, v6}, Ldg/b;-><init>(Lcg/g0;I)V

    .line 1356
    .line 1357
    .line 1358
    const-string v1, "error"

    .line 1359
    .line 1360
    invoke-virtual {v2, v1, v3}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1361
    .line 1362
    .line 1363
    goto :goto_563

    .line 1364
    :cond_553
    new-instance v1, Lan/g;

    .line 1365
    .line 1366
    invoke-direct {v1, v11}, Lan/g;-><init>(Z)V

    .line 1367
    .line 1368
    .line 1369
    throw v1

    .line 1370
    :cond_559
    :goto_559
    new-instance v1, Lac/b;

    .line 1371
    .line 1372
    invoke-direct {v1, v4}, Lac/b;-><init>(I)V

    .line 1373
    .line 1374
    .line 1375
    const-string v3, "ended"

    .line 1376
    .line 1377
    invoke-virtual {v2, v3, v1}, Ldg/c;->d(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 1378
    .line 1379
    .line 1380
    :cond_563
    :goto_563
    return-object v14

    .line 1381
    :pswitch_564
    check-cast v2, Lcom/margelo/nitro/nitrofetch/z;

    .line 1382
    .line 1383
    check-cast v15, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;

    .line 1384
    .line 1385
    move-object/from16 v1, p1

    .line 1386
    .line 1387
    check-cast v1, Lorg/chromium/net/UrlRequest$Builder;

    .line 1388
    .line 1389
    invoke-static {v1, v12}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1390
    .line 1391
    .line 1392
    iget-boolean v3, v15, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->b:Z

    .line 1393
    .line 1394
    const-string v4, "getValue(...)"

    .line 1395
    .line 1396
    if-eqz v3, :cond_581

    .line 1397
    .line 1398
    sget-object v3, Lcom/margelo/nitro/nitrofetch/HybridNitroFetch;->c:Ll30/o;

    .line 1399
    .line 1400
    invoke-virtual {v3}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 1401
    .line 1402
    .line 1403
    move-result-object v3

    .line 1404
    invoke-static {v3, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1405
    .line 1406
    .line 1407
    check-cast v3, Ljava/util/concurrent/Executor;

    .line 1408
    .line 1409
    goto :goto_58c

    .line 1410
    :cond_581
    sget-object v3, Lcom/margelo/nitro/nitrofetch/HybridNitroCronet;->c:Ll30/o;

    .line 1411
    .line 1412
    invoke-virtual {v3}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 1413
    .line 1414
    .line 1415
    move-result-object v3

    .line 1416
    invoke-static {v3, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1417
    .line 1418
    .line 1419
    check-cast v3, Ljava/util/concurrent/Executor;

    .line 1420
    .line 1421
    :goto_58c
    invoke-virtual {v1, v2, v3}, Lorg/chromium/net/UrlRequest$Builder;->setUploadDataProvider(Lorg/chromium/net/UploadDataProvider;Ljava/util/concurrent/Executor;)Lorg/chromium/net/UrlRequest$Builder;

    .line 1422
    .line 1423
    .line 1424
    return-object v14

    .line 1425
    :pswitch_590
    check-cast v2, Lcom/discord/qr/scanner/QRScannerViewManager;

    .line 1426
    .line 1427
    check-cast v15, Lci/a;

    .line 1428
    .line 1429
    move-object/from16 v1, p1

    .line 1430
    .line 1431
    check-cast v1, Ljava/lang/String;

    .line 1432
    .line 1433
    invoke-static {v2, v15, v1}, Lcom/discord/qr/scanner/QRScannerViewManager;->b(Lcom/discord/qr/scanner/QRScannerViewManager;Lci/a;Ljava/lang/String;)Ll30/a0;

    .line 1434
    .line 1435
    .line 1436
    move-result-object v1

    .line 1437
    return-object v1

    .line 1438
    :pswitch_59d
    check-cast v2, Lbg/s;

    .line 1439
    .line 1440
    check-cast v15, Landroid/net/Uri;

    .line 1441
    .line 1442
    move-object/from16 v1, p1

    .line 1443
    .line 1444
    check-cast v1, Ljava/lang/Float;

    .line 1445
    .line 1446
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 1447
    .line 1448
    .line 1449
    move-result v1

    .line 1450
    iget-object v2, v2, Lbg/s;->b:Lc9/r;

    .line 1451
    .line 1452
    const/16 v3, 0x64

    .line 1453
    .line 1454
    int-to-float v3, v3

    .line 1455
    mul-float/2addr v1, v3

    .line 1456
    float-to-int v1, v1

    .line 1457
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1458
    .line 1459
    .line 1460
    move-result-object v1

    .line 1461
    invoke-virtual {v2, v15, v1}, Lc9/r;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1462
    .line 1463
    .line 1464
    return-object v14

    .line 1465
    :pswitch_5b8
    check-cast v2, La70/e;

    .line 1466
    .line 1467
    check-cast v15, La4/c;

    .line 1468
    .line 1469
    move-object/from16 v1, p1

    .line 1470
    .line 1471
    check-cast v1, Ljava/lang/Throwable;

    .line 1472
    .line 1473
    iget-object v1, v2, La70/e;->i:Landroid/os/Handler;

    .line 1474
    .line 1475
    invoke-virtual {v1, v15}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1476
    .line 1477
    .line 1478
    return-object v14

    .line 1479
    :pswitch_data_5c6
    .packed-switch 0x0
        :pswitch_5b8
        :pswitch_59d
        :pswitch_590
        :pswitch_564
        :pswitch_432
        :pswitch_3ed
        :pswitch_3d9
        :pswitch_3c5
        :pswitch_3b1
        :pswitch_39d
        :pswitch_389
        :pswitch_320
        :pswitch_30a
        :pswitch_2f4
        :pswitch_2e0
        :pswitch_295
        :pswitch_237
        :pswitch_22a
        :pswitch_214
        :pswitch_1d7
        :pswitch_197
        :pswitch_152
        :pswitch_104
        :pswitch_d2
        :pswitch_c1
        :pswitch_a2
        :pswitch_4b
        :pswitch_3c
        :pswitch_2d
    .end packed-switch
.end method

###### Class dg.b (dg.b)
.class public final synthetic Ldg/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lcg/g0;


# direct methods
.method public synthetic constructor <init>(Lcg/g0;I)V
    .registers 3

    .line 1
    iput p2, p0, Ldg/b;->d:I

    iput-object p1, p0, Ldg/b;->e:Lcg/g0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget v0, p0, Ldg/b;->d:I

    .line 2
    .line 3
    check-cast p1, Lcom/facebook/react/bridge/WritableMap;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_f4

    .line 6
    .line 7
    .line 8
    const-string v0, "$this$emit"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Ldg/b;->e:Lcg/g0;

    .line 14
    .line 15
    check-cast v0, Lcg/v;

    .line 16
    .line 17
    iget-object v1, v0, Lcg/v;->a:Ljava/lang/Exception;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    if-nez v1, :cond_1a

    .line 24
    .line 25
    const-string v1, ""

    .line 26
    .line 27
    :cond_1a
    const-string v2, "errorMessage"

    .line 28
    .line 29
    invoke-interface {p1, v2, v1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    iget v0, v0, Lcg/v;->b:I

    .line 33
    .line 34
    int-to-double v0, v0

    .line 35
    const-string v2, "errorCode"

    .line 36
    .line 37
    invoke-interface {p1, v2, v0, v1}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 38
    .line 39
    .line 40
    :goto_27
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 41
    .line 42
    return-object p1

    .line 43
    :pswitch_2a
    const-string v0, "$this$emit"

    .line 44
    .line 45
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createArray()Lcom/facebook/react/bridge/WritableArray;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iget-object v1, p0, Ldg/b;->e:Lcg/g0;

    .line 53
    .line 54
    check-cast v1, Lcg/f0;

    .line 55
    .line 56
    iget-object v2, v1, Lcg/f0;->a:Ljava/util/List;

    .line 57
    .line 58
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    :goto_3d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    if-eqz v3, :cond_70

    .line 67
    .line 68
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    check-cast v3, Lcg/p0;

    .line 73
    .line 74
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 75
    .line 76
    .line 77
    move-result-object v4

    .line 78
    const-string v5, "trackId"

    .line 79
    .line 80
    iget-object v6, v3, Lcg/p0;->a:Ljava/lang/String;

    .line 81
    .line 82
    invoke-interface {v4, v5, v6}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    iget v5, v3, Lcg/p0;->b:I

    .line 86
    .line 87
    int-to-double v5, v5

    .line 88
    const-string v7, "width"

    .line 89
    .line 90
    invoke-interface {v4, v7, v5, v6}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 91
    .line 92
    .line 93
    iget v5, v3, Lcg/p0;->c:I

    .line 94
    .line 95
    int-to-double v5, v5

    .line 96
    const-string v7, "height"

    .line 97
    .line 98
    invoke-interface {v4, v7, v5, v6}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 99
    .line 100
    .line 101
    iget v3, v3, Lcg/p0;->d:I

    .line 102
    .line 103
    int-to-double v5, v3

    .line 104
    const-string v3, "bitrate"

    .line 105
    .line 106
    invoke-interface {v4, v3, v5, v6}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 107
    .line 108
    .line 109
    invoke-interface {v0, v4}, Lcom/facebook/react/bridge/WritableArray;->pushMap(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 110
    .line 111
    .line 112
    goto :goto_3d

    .line 113
    :cond_70
    const-string v2, "videoTracks"

    .line 114
    .line 115
    invoke-interface {p1, v2, v0}, Lcom/facebook/react/bridge/WritableMap;->putArray(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V

    .line 116
    .line 117
    .line 118
    iget-object v0, v1, Lcg/f0;->b:Ljava/lang/String;

    .line 119
    .line 120
    if-nez v0, :cond_7b

    .line 121
    .line 122
    const-string v0, ""

    .line 123
    .line 124
    :cond_7b
    const-string v1, "selectedTrackId"

    .line 125
    .line 126
    invoke-interface {p1, v1, v0}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    goto :goto_27

    .line 130
    :pswitch_81
    const-string v0, "$this$emit"

    .line 131
    .line 132
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    iget-object v0, p0, Ldg/b;->e:Lcg/g0;

    .line 136
    .line 137
    check-cast v0, Lcg/t;

    .line 138
    .line 139
    iget-wide v1, v0, Lcg/t;->a:J

    .line 140
    .line 141
    long-to-double v1, v1

    .line 142
    iget-wide v3, v0, Lcg/t;->b:J

    .line 143
    .line 144
    long-to-double v3, v3

    .line 145
    div-double v5, v1, v3

    .line 146
    .line 147
    const-wide/16 v7, 0x0

    .line 148
    .line 149
    const-wide/high16 v9, 0x3ff0000000000000L    # 1.0

    .line 150
    .line 151
    invoke-static/range {v5 .. v10}, Lsg/a;->l(DDD)D

    .line 152
    .line 153
    .line 154
    move-result-wide v0

    .line 155
    const-string v2, "downloadProgress"

    .line 156
    .line 157
    invoke-interface {p1, v2, v0, v1}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 158
    .line 159
    .line 160
    goto :goto_27

    .line 161
    :pswitch_a0
    const-string v0, "$this$emit"

    .line 162
    .line 163
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    iget-object v0, p0, Ldg/b;->e:Lcg/g0;

    .line 167
    .line 168
    check-cast v0, Lcg/e0;

    .line 169
    .line 170
    iget-wide v0, v0, Lcg/e0;->b:J

    .line 171
    .line 172
    long-to-double v0, v0

    .line 173
    const-string v2, "requestedPositionMs"

    .line 174
    .line 175
    invoke-interface {p1, v2, v0, v1}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 176
    .line 177
    .line 178
    goto/16 :goto_27

    .line 179
    .line 180
    :pswitch_b3
    const-string v0, "$this$emit"

    .line 181
    .line 182
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    iget-object v0, p0, Ldg/b;->e:Lcg/g0;

    .line 186
    .line 187
    check-cast v0, Lcg/c0;

    .line 188
    .line 189
    iget v0, v0, Lcg/c0;->a:F

    .line 190
    .line 191
    float-to-double v0, v0

    .line 192
    const-string v2, "playbackRate"

    .line 193
    .line 194
    invoke-interface {p1, v2, v0, v1}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 195
    .line 196
    .line 197
    goto/16 :goto_27

    .line 198
    .line 199
    :pswitch_c6
    const-string v0, "$this$emit"

    .line 200
    .line 201
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    iget-object v0, p0, Ldg/b;->e:Lcg/g0;

    .line 205
    .line 206
    check-cast v0, Lcg/s;

    .line 207
    .line 208
    iget-boolean v0, v0, Lcg/s;->a:Z

    .line 209
    .line 210
    const-string v1, "buffering"

    .line 211
    .line 212
    invoke-interface {p1, v1, v0}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    .line 213
    .line 214
    .line 215
    goto/16 :goto_27

    .line 216
    .line 217
    :pswitch_d8
    const-string v0, "$this$emit"

    .line 218
    .line 219
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    iget-object v0, p0, Ldg/b;->e:Lcg/g0;

    .line 223
    .line 224
    check-cast v0, Lcg/x;

    .line 225
    .line 226
    iget v1, v0, Lcg/x;->b:I

    .line 227
    .line 228
    int-to-double v1, v1

    .line 229
    const-string v3, "width"

    .line 230
    .line 231
    invoke-interface {p1, v3, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 232
    .line 233
    .line 234
    iget v0, v0, Lcg/x;->c:I

    .line 235
    .line 236
    int-to-double v0, v0

    .line 237
    const-string v2, "height"

    .line 238
    .line 239
    invoke-interface {p1, v2, v0, v1}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_27

    .line 243
    .line 244
    nop

    .line 245
    :pswitch_data_f4
    .packed-switch 0x0
        :pswitch_d8
        :pswitch_c6
        :pswitch_b3
        :pswitch_a0
        :pswitch_81
        :pswitch_2a
    .end packed-switch
.end method
