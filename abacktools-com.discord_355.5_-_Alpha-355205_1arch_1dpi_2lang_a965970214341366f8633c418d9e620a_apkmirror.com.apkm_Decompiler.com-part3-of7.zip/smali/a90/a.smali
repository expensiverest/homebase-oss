###### Class a90.a (a90.a)
.class public final La90/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lsn/p;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, La90/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createNativeModules(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;
    .registers 7

    .line 1
    iget v0, p0, La90/a;->a:I

    .line 2
    .line 3
    sget-object v1, Lm30/s;->d:Lm30/s;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    const-string v4, "reactContext"

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_7e

    .line 10
    .line 11
    .line 12
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lcom/github/yamill/orientation/OrientationModule;

    .line 16
    .line 17
    invoke-direct {v0, p1}, Lcom/github/yamill/orientation/OrientationModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    return-object p1

    .line 25
    :pswitch_18
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 26
    .line 27
    return-object p1

    .line 28
    :pswitch_1b
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-object v1

    .line 32
    :pswitch_1f
    new-instance v0, Lcom/reactnativecommunity/netinfo/NetInfoModule;

    .line 33
    .line 34
    invoke-direct {v0, p1}, Lcom/reactnativecommunity/netinfo/NetInfoModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 35
    .line 36
    .line 37
    new-array p1, v3, [Lcom/facebook/react/bridge/NativeModule;

    .line 38
    .line 39
    aput-object v0, p1, v2

    .line 40
    .line 41
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    return-object p1

    .line 46
    :pswitch_2d
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v1

    .line 50
    :pswitch_31
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_34
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    new-instance v0, Lcom/releaseprofiler/ReleaseProfilerModule;

    .line 57
    .line 58
    invoke-direct {v0, p1}, Lcom/releaseprofiler/ReleaseProfilerModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    return-object p1

    .line 66
    :pswitch_41
    new-instance v0, Lfr/greweb/reactnativeviewshot/RNViewShotModule;

    .line 67
    .line 68
    invoke-direct {v0, p1}, Lfr/greweb/reactnativeviewshot/RNViewShotModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 69
    .line 70
    .line 71
    new-array p1, v3, [Lcom/facebook/react/bridge/NativeModule;

    .line 72
    .line 73
    aput-object v0, p1, v2

    .line 74
    .line 75
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    return-object p1

    .line 80
    :pswitch_4f
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 81
    .line 82
    return-object p1

    .line 83
    :pswitch_52
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    new-instance v0, Lcom/reactnativecommunity/webview/RNCWebViewModule;

    .line 87
    .line 88
    invoke-direct {v0, p1}, Lcom/reactnativecommunity/webview/RNCWebViewModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 89
    .line 90
    .line 91
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    return-object p1

    .line 96
    :pswitch_5f
    new-instance v0, Ljava/util/ArrayList;

    .line 97
    .line 98
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 99
    .line 100
    .line 101
    new-instance v1, Lcom/imagepicker/ImagePickerModule;

    .line 102
    .line 103
    invoke-direct {v1, p1}, Lcom/imagepicker/ImagePickerModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    return-object v0

    .line 110
    :pswitch_6d
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 111
    .line 112
    return-object p1

    .line 113
    :pswitch_70
    new-instance v0, Lorg/linusu/RNGetRandomValuesModule;

    .line 114
    .line 115
    invoke-direct {v0, p1}, Lorg/linusu/RNGetRandomValuesModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 116
    .line 117
    .line 118
    new-array p1, v3, [Lcom/facebook/react/bridge/NativeModule;

    .line 119
    .line 120
    aput-object v0, p1, v2

    .line 121
    .line 122
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    return-object p1

    .line 127
    :pswitch_data_7e
    .packed-switch 0x0
        :pswitch_70
        :pswitch_6d
        :pswitch_5f
        :pswitch_52
        :pswitch_4f
        :pswitch_41
        :pswitch_34
        :pswitch_31
        :pswitch_2d
        :pswitch_1f
        :pswitch_1b
        :pswitch_18
    .end packed-switch
.end method

.method public final createViewManagers(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;
    .registers 6

    .line 1
    iget p1, p0, La90/a;->a:I

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    const/4 v1, 0x1

    .line 5
    sget-object v2, Lm30/s;->d:Lm30/s;

    .line 6
    .line 7
    packed-switch p1, :pswitch_data_62

    .line 8
    .line 9
    .line 10
    return-object v2

    .line 11
    :pswitch_a
    new-instance p1, Lcom/reactnativecommunity/slider/ReactSliderManager;

    .line 12
    .line 13
    invoke-direct {p1}, Lcom/reactnativecommunity/slider/ReactSliderManager;-><init>()V

    .line 14
    .line 15
    .line 16
    new-array v1, v1, [Lcom/facebook/react/uimanager/ViewManager;

    .line 17
    .line 18
    aput-object p1, v1, v0

    .line 19
    .line 20
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    return-object p1

    .line 25
    :pswitch_18
    new-instance p1, Lcom/airbnb/android/react/lottie/LottieAnimationViewManager;

    .line 26
    .line 27
    invoke-direct {p1}, Lcom/airbnb/android/react/lottie/LottieAnimationViewManager;-><init>()V

    .line 28
    .line 29
    .line 30
    invoke-static {p1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    return-object p1

    .line 35
    :pswitch_22
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 36
    .line 37
    return-object p1

    .line 38
    :pswitch_25
    return-object v2

    .line 39
    :pswitch_26
    new-instance p1, Lcom/rnlineargradient/LinearGradientManager;

    .line 40
    .line 41
    invoke-direct {p1}, Lcom/rnlineargradient/LinearGradientManager;-><init>()V

    .line 42
    .line 43
    .line 44
    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    return-object p1

    .line 49
    :pswitch_30
    return-object v2

    .line 50
    :pswitch_31
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_34
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 54
    .line 55
    return-object p1

    .line 56
    :pswitch_37
    new-instance p1, Lcom/reactnativecommunity/webview/RNCWebViewManager;

    .line 57
    .line 58
    invoke-direct {p1}, Lcom/reactnativecommunity/webview/RNCWebViewManager;-><init>()V

    .line 59
    .line 60
    .line 61
    new-instance v2, Lcom/reactnativecommunity/webview/RNCWebViewTargetManager;

    .line 62
    .line 63
    invoke-direct {v2}, Lcom/reactnativecommunity/webview/RNCWebViewTargetManager;-><init>()V

    .line 64
    .line 65
    .line 66
    const/4 v3, 0x2

    .line 67
    new-array v3, v3, [Lcom/facebook/react/uimanager/SimpleViewManager;

    .line 68
    .line 69
    aput-object p1, v3, v0

    .line 70
    .line 71
    aput-object v2, v3, v1

    .line 72
    .line 73
    invoke-static {v3}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    return-object p1

    .line 78
    :pswitch_4d
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 79
    .line 80
    return-object p1

    .line 81
    :pswitch_50
    new-instance p1, Lorg/reactnative/maskedview/RNCMaskedViewManager;

    .line 82
    .line 83
    invoke-direct {p1}, Lorg/reactnative/maskedview/RNCMaskedViewManager;-><init>()V

    .line 84
    .line 85
    .line 86
    new-array v1, v1, [Lcom/facebook/react/uimanager/ViewManager;

    .line 87
    .line 88
    aput-object p1, v1, v0

    .line 89
    .line 90
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    return-object p1

    .line 95
    :pswitch_5e
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 96
    .line 97
    return-object p1

    .line 98
    nop

    .line 99
    :pswitch_data_62
    .packed-switch 0x0
        :pswitch_5e
        :pswitch_50
        :pswitch_4d
        :pswitch_37
        :pswitch_34
        :pswitch_31
        :pswitch_30
        :pswitch_26
        :pswitch_25
        :pswitch_22
        :pswitch_18
        :pswitch_a
    .end packed-switch
.end method
