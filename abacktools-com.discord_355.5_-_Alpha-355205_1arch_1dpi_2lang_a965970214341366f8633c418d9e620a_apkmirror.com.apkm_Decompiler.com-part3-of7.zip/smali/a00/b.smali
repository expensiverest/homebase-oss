###### Class a00.b (a00.b)
.class public abstract synthetic La00/b;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static synthetic a()Landroid/graphics/SurfaceTexture;
    .registers 2

    .line 1
    new-instance v0, Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroid/graphics/SurfaceTexture;-><init>(Z)V

    return-object v0
.end method

.method public static synthetic b(Ljava/io/FileDescriptor;I)Landroid/media/MediaMuxer;
    .registers 3

    .line 1
    new-instance v0, Landroid/media/MediaMuxer;

    invoke-direct {v0, p0, p1}, Landroid/media/MediaMuxer;-><init>(Ljava/io/FileDescriptor;I)V

    return-object v0
.end method
