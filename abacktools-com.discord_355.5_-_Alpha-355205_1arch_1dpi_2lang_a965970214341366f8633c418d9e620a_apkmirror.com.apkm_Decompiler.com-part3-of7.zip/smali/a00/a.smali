###### Class a00.a (a00.a)
.class public La00/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/media/MediaExtractor;

.field public final b:Lal/c;

.field public final c:I

.field public final d:J

.field public final e:J


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/net/Uri;Lal/c;)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, La00/a;->b:Lal/c;

    .line 5
    .line 6
    new-instance p3, Landroid/media/MediaExtractor;

    .line 7
    .line 8
    invoke-direct {p3}, Landroid/media/MediaExtractor;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p3, p0, La00/a;->a:Landroid/media/MediaExtractor;

    .line 12
    .line 13
    new-instance v0, Landroid/media/MediaMetadataRetriever;

    .line 14
    .line 15
    invoke-direct {v0}, Landroid/media/MediaMetadataRetriever;-><init>()V

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    :try_start_12
    invoke-virtual {p3, p1, p2, v1}, Landroid/media/MediaExtractor;->setDataSource(Landroid/content/Context;Landroid/net/Uri;Ljava/util/Map;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0, p1, p2}, Landroid/media/MediaMetadataRetriever;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V
    :try_end_18
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_18} :catch_dd

    .line 23
    .line 24
    .line 25
    const/16 p3, 0x18

    .line 26
    .line 27
    invoke-virtual {v0, p3}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p3

    .line 31
    if-eqz p3, :cond_26

    .line 32
    .line 33
    invoke-static {p3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 34
    .line 35
    .line 36
    move-result p3

    .line 37
    iput p3, p0, La00/a;->c:I

    .line 38
    .line 39
    :cond_26
    const/16 p3, 0x9

    .line 40
    .line 41
    invoke-virtual {v0, p3}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p3

    .line 45
    const-wide/16 v2, -0x1

    .line 46
    .line 47
    if-eqz p3, :cond_35

    .line 48
    .line 49
    invoke-static {p3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 50
    .line 51
    .line 52
    move-result-wide v4

    .line 53
    goto :goto_36

    .line 54
    :cond_35
    move-wide v4, v2

    .line 55
    :goto_36
    iput-wide v4, p0, La00/a;->e:J

    .line 56
    .line 57
    const-string p3, "Unable to close file descriptor from targetFile: "

    .line 58
    .line 59
    const-string v4, "a"

    .line 60
    .line 61
    const-string v5, "Unable to extract length from targetFile: "

    .line 62
    .line 63
    const-string v6, "content"

    .line 64
    .line 65
    invoke-virtual {p2}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v7

    .line 69
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v6

    .line 73
    if-eqz v6, :cond_b8

    .line 74
    .line 75
    :try_start_4a
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    const-string v6, "r"

    .line 80
    .line 81
    invoke-virtual {p1, p2, v6}, Landroid/content/ContentResolver;->openAssetFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    const-wide/16 v6, 0x0

    .line 86
    .line 87
    if-eqz v1, :cond_67

    .line 88
    .line 89
    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->getParcelFileDescriptor()Landroid/os/ParcelFileDescriptor;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getStatSize()J

    .line 94
    .line 95
    .line 96
    move-result-wide v8
    :try_end_60
    .catch Ljava/io/FileNotFoundException; {:try_start_4a .. :try_end_60} :catch_65
    .catch Ljava/lang/IllegalStateException; {:try_start_4a .. :try_end_60} :catch_63
    .catchall {:try_start_4a .. :try_end_60} :catchall_61

    .line 97
    goto :goto_68

    .line 98
    :catchall_61
    move-exception p1

    .line 99
    goto :goto_a1

    .line 100
    :catch_63
    move-exception p1

    .line 101
    goto :goto_85

    .line 102
    :catch_65
    move-exception p1

    .line 103
    goto :goto_85

    .line 104
    :cond_67
    move-wide v8, v6

    .line 105
    :goto_68
    cmp-long p1, v8, v6

    .line 106
    .line 107
    if-gez p1, :cond_6d

    .line 108
    .line 109
    goto :goto_6e

    .line 110
    :cond_6d
    move-wide v2, v8

    .line 111
    :goto_6e
    if-eqz v1, :cond_d7

    .line 112
    .line 113
    :try_start_70
    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_73
    .catch Ljava/io/IOException; {:try_start_70 .. :try_end_73} :catch_74

    .line 114
    .line 115
    .line 116
    goto :goto_d7

    .line 117
    :catch_74
    move-exception p1

    .line 118
    new-instance v1, Ljava/lang/StringBuilder;

    .line 119
    .line 120
    invoke-direct {v1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    :goto_7a
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p2

    .line 130
    invoke-static {v4, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 131
    .line 132
    .line 133
    goto :goto_d7

    .line 134
    :goto_85
    :try_start_85
    new-instance v6, Ljava/lang/StringBuilder;

    .line 135
    .line 136
    invoke-direct {v6, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v6, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    invoke-static {v4, v5, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_94
    .catchall {:try_start_85 .. :try_end_94} :catchall_61

    .line 147
    .line 148
    .line 149
    if-eqz v1, :cond_d7

    .line 150
    .line 151
    :try_start_96
    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_99
    .catch Ljava/io/IOException; {:try_start_96 .. :try_end_99} :catch_9a

    .line 152
    .line 153
    .line 154
    goto :goto_d7

    .line 155
    :catch_9a
    move-exception p1

    .line 156
    new-instance v1, Ljava/lang/StringBuilder;

    .line 157
    .line 158
    invoke-direct {v1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    goto :goto_7a

    .line 162
    :goto_a1
    if-eqz v1, :cond_b7

    .line 163
    .line 164
    :try_start_a3
    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_a6
    .catch Ljava/io/IOException; {:try_start_a3 .. :try_end_a6} :catch_a7

    .line 165
    .line 166
    .line 167
    goto :goto_b7

    .line 168
    :catch_a7
    move-exception v0

    .line 169
    new-instance v1, Ljava/lang/StringBuilder;

    .line 170
    .line 171
    invoke-direct {v1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p2

    .line 181
    invoke-static {v4, p2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 182
    .line 183
    .line 184
    :cond_b7
    :goto_b7
    throw p1

    .line 185
    :cond_b8
    const-string p1, "file"

    .line 186
    .line 187
    invoke-virtual {p2}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object p3

    .line 191
    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result p1

    .line 195
    if-eqz p1, :cond_d7

    .line 196
    .line 197
    invoke-virtual {p2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    if-eqz p1, :cond_d7

    .line 202
    .line 203
    new-instance p1, Ljava/io/File;

    .line 204
    .line 205
    invoke-virtual {p2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object p2

    .line 209
    invoke-direct {p1, p2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {p1}, Ljava/io/File;->length()J

    .line 213
    .line 214
    .line 215
    move-result-wide v2

    .line 216
    :cond_d7
    :goto_d7
    iput-wide v2, p0, La00/a;->d:J

    .line 217
    .line 218
    :try_start_d9
    invoke-virtual {v0}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_dc
    .catch Ljava/io/IOException; {:try_start_d9 .. :try_end_dc} :catch_dc

    .line 219
    .line 220
    .line 221
    :catch_dc
    return-void

    .line 222
    :catch_dd
    move-exception p1

    .line 223
    :try_start_de
    invoke-virtual {v0}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_e1
    .catch Ljava/io/IOException; {:try_start_de .. :try_end_e1} :catch_e1

    .line 224
    .line 225
    .line 226
    :catch_e1
    new-instance p3, Lxz/b;

    .line 227
    .line 228
    invoke-direct {p3, p2, p1}, Lxz/b;-><init>(Landroid/net/Uri;Ljava/io/IOException;)V

    .line 229
    .line 230
    .line 231
    throw p3
.end method
