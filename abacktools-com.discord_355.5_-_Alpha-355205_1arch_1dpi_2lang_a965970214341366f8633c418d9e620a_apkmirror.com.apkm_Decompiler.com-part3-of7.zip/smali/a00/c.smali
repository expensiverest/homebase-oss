###### Class a00.c (a00.c)
.class public final La00/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/util/LinkedList;

.field public b:Z

.field public c:Landroid/media/MediaMuxer;

.field public d:[Landroid/media/MediaFormat;

.field public e:Landroid/os/ParcelFileDescriptor;

.field public f:I

.field public g:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/net/Uri;III)V
    .registers 9

    .line 1
    const-string v0, "Inaccessible URI "

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    :try_start_5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    .line 8
    const/16 v2, 0x1a

    .line 9
    .line 10
    if-lt v1, v2, :cond_3c

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const-string v1, "rwt"

    .line 17
    .line 18
    invoke-virtual {p1, p2, v1}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iput-object p1, p0, La00/c;->e:Landroid/os/ParcelFileDescriptor;

    .line 23
    .line 24
    if-eqz p1, :cond_2a

    .line 25
    .line 26
    new-instance p1, Landroid/media/MediaMuxer;

    .line 27
    .line 28
    iget-object p1, p0, La00/c;->e:Landroid/os/ParcelFileDescriptor;

    .line 29
    .line 30
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    invoke-static {p1, p5}, La00/b;->b(Ljava/io/FileDescriptor;I)Landroid/media/MediaMuxer;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    goto :goto_57

    .line 39
    :catch_26
    move-exception p1

    .line 40
    goto :goto_67

    .line 41
    :catch_28
    move-exception p1

    .line 42
    goto :goto_78

    .line 43
    :cond_2a
    new-instance p1, Ljava/io/IOException;

    .line 44
    .line 45
    new-instance p3, Ljava/lang/StringBuilder;

    .line 46
    .line 47
    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p3

    .line 57
    invoke-direct {p1, p3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    throw p1

    .line 61
    :cond_3c
    const-string p1, "file"

    .line 62
    .line 63
    invoke-virtual {p2}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    if-eqz p1, :cond_5b

    .line 72
    .line 73
    invoke-virtual {p2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-eqz p1, :cond_5b

    .line 78
    .line 79
    new-instance p1, Landroid/media/MediaMuxer;

    .line 80
    .line 81
    invoke-virtual {p2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-direct {p1, v0, p5}, Landroid/media/MediaMuxer;-><init>(Ljava/lang/String;I)V

    .line 86
    .line 87
    .line 88
    :goto_57
    invoke-virtual {p0, p1, p3, p4}, La00/c;->b(Landroid/media/MediaMuxer;II)V

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :cond_5b
    new-instance p1, Lxz/c;

    .line 93
    .line 94
    new-instance p3, Ljava/lang/Throwable;

    .line 95
    .line 96
    invoke-direct {p3}, Ljava/lang/Throwable;-><init>()V

    .line 97
    .line 98
    .line 99
    const/4 p4, 0x3

    .line 100
    invoke-direct {p1, p4, p2, p5, p3}, Lxz/c;-><init>(ILandroid/net/Uri;ILjava/lang/Throwable;)V

    .line 101
    .line 102
    .line 103
    throw p1
    :try_end_67
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_67} :catch_28
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_67} :catch_26

    .line 104
    :goto_67
    :try_start_67
    iget-object p3, p0, La00/c;->e:Landroid/os/ParcelFileDescriptor;

    .line 105
    .line 106
    if-eqz p3, :cond_71

    .line 107
    .line 108
    invoke-virtual {p3}, Landroid/os/ParcelFileDescriptor;->close()V

    .line 109
    .line 110
    .line 111
    const/4 p3, 0x0

    .line 112
    iput-object p3, p0, La00/c;->e:Landroid/os/ParcelFileDescriptor;
    :try_end_71
    .catch Ljava/io/IOException; {:try_start_67 .. :try_end_71} :catch_71

    .line 113
    .line 114
    :catch_71
    :cond_71
    new-instance p3, Lxz/c;

    .line 115
    .line 116
    const/4 p4, 0x2

    .line 117
    invoke-direct {p3, p4, p2, p5, p1}, Lxz/c;-><init>(ILandroid/net/Uri;ILjava/lang/Throwable;)V

    .line 118
    .line 119
    .line 120
    throw p3

    .line 121
    :goto_78
    new-instance p3, Lxz/c;

    .line 122
    .line 123
    const/4 p4, 0x1

    .line 124
    invoke-direct {p3, p4, p2, p5, p1}, Lxz/c;-><init>(ILandroid/net/Uri;ILjava/lang/Throwable;)V

    .line 125
    .line 126
    .line 127
    throw p3
.end method


# virtual methods
.method public final a(Landroid/media/MediaFormat;I)I
    .registers 8

    .line 1
    iget-object v0, p0, La00/c;->d:[Landroid/media/MediaFormat;

    .line 2
    .line 3
    aput-object p1, v0, p2

    .line 4
    .line 5
    iget p1, p0, La00/c;->f:I

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    add-int/2addr p1, v0

    .line 9
    iput p1, p0, La00/c;->f:I

    .line 10
    .line 11
    iget v1, p0, La00/c;->g:I

    .line 12
    .line 13
    if-ne p1, v1, :cond_5f

    .line 14
    .line 15
    new-instance p1, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v1, "All tracks added, starting MediaMuxer, writing out "

    .line 18
    .line 19
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, La00/c;->a:Ljava/util/LinkedList;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/util/LinkedList;->size()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, " queued samples"

    .line 32
    .line 33
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    const-string v1, "c"

    .line 41
    .line 42
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    iget-object p1, p0, La00/c;->d:[Landroid/media/MediaFormat;

    .line 46
    .line 47
    array-length v1, p1

    .line 48
    const/4 v2, 0x0

    .line 49
    :goto_30
    if-ge v2, v1, :cond_3c

    .line 50
    .line 51
    aget-object v3, p1, v2

    .line 52
    .line 53
    iget-object v4, p0, La00/c;->c:Landroid/media/MediaMuxer;

    .line 54
    .line 55
    invoke-virtual {v4, v3}, Landroid/media/MediaMuxer;->addTrack(Landroid/media/MediaFormat;)I

    .line 56
    .line 57
    .line 58
    add-int/lit8 v2, v2, 0x1

    .line 59
    .line 60
    goto :goto_30

    .line 61
    :cond_3c
    iget-object p1, p0, La00/c;->c:Landroid/media/MediaMuxer;

    .line 62
    .line 63
    invoke-virtual {p1}, Landroid/media/MediaMuxer;->start()V

    .line 64
    .line 65
    .line 66
    iput-boolean v0, p0, La00/c;->b:Z

    .line 67
    .line 68
    :goto_43
    iget-object p1, p0, La00/c;->a:Ljava/util/LinkedList;

    .line 69
    .line 70
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    if-nez p1, :cond_5f

    .line 75
    .line 76
    iget-object p1, p0, La00/c;->a:Ljava/util/LinkedList;

    .line 77
    .line 78
    invoke-virtual {p1}, Ljava/util/LinkedList;->removeFirst()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    check-cast p1, La00/d;

    .line 83
    .line 84
    iget-object v0, p0, La00/c;->c:Landroid/media/MediaMuxer;

    .line 85
    .line 86
    iget v1, p1, La00/d;->a:I

    .line 87
    .line 88
    iget-object v2, p1, La00/d;->b:Ljava/nio/ByteBuffer;

    .line 89
    .line 90
    iget-object p1, p1, La00/d;->c:Landroid/media/MediaCodec$BufferInfo;

    .line 91
    .line 92
    invoke-virtual {v0, v1, v2, p1}, Landroid/media/MediaMuxer;->writeSampleData(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;)V

    .line 93
    .line 94
    .line 95
    goto :goto_43

    .line 96
    :cond_5f
    return p2
.end method

.method public final b(Landroid/media/MediaMuxer;II)V
    .registers 4

    .line 1
    iput p2, p0, La00/c;->g:I

    .line 2
    .line 3
    iput-object p1, p0, La00/c;->c:Landroid/media/MediaMuxer;

    .line 4
    .line 5
    invoke-virtual {p1, p3}, Landroid/media/MediaMuxer;->setOrientationHint(I)V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x0

    .line 9
    iput p1, p0, La00/c;->f:I

    .line 10
    .line 11
    iput-boolean p1, p0, La00/c;->b:Z

    .line 12
    .line 13
    new-instance p1, Ljava/util/LinkedList;

    .line 14
    .line 15
    invoke-direct {p1}, Ljava/util/LinkedList;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, La00/c;->a:Ljava/util/LinkedList;

    .line 19
    .line 20
    new-array p1, p2, [Landroid/media/MediaFormat;

    .line 21
    .line 22
    iput-object p1, p0, La00/c;->d:[Landroid/media/MediaFormat;

    .line 23
    .line 24
    return-void
.end method

.method public final c(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;)V
    .registers 5

    .line 1
    iget-boolean v0, p0, La00/c;->b:Z

    .line 2
    .line 3
    if-eqz v0, :cond_14

    .line 4
    .line 5
    if-nez p2, :cond_e

    .line 6
    .line 7
    const-string p1, "c"

    .line 8
    .line 9
    const-string p2, "Trying to write a null buffer, skipping"

    .line 10
    .line 11
    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_e
    iget-object v0, p0, La00/c;->c:Landroid/media/MediaMuxer;

    .line 16
    .line 17
    invoke-virtual {v0, p1, p2, p3}, Landroid/media/MediaMuxer;->writeSampleData(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    new-instance v0, La00/d;

    .line 22
    .line 23
    invoke-direct {v0, p1, p2, p3}, La00/d;-><init>(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;)V

    .line 24
    .line 25
    .line 26
    iget-object p1, p0, La00/c;->a:Ljava/util/LinkedList;

    .line 27
    .line 28
    invoke-virtual {p1, v0}, Ljava/util/LinkedList;->addLast(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method
