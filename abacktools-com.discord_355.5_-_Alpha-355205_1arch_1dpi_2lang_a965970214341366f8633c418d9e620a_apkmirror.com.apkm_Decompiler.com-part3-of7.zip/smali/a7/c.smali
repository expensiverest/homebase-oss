###### Class a7.c (a7.c)
.class public final La7/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La7/b;
.implements La7/f;
.implements La7/h;


# static fields
.field public static final c:La7/c;

.field public static final d:La7/c;

.field public static final e:La7/c;

.field public static final f:La7/c;

.field public static final g:La7/c;

.field public static final h:La7/c;

.field public static final i:La7/c;


# instance fields
.field public final synthetic b:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, La7/c;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, La7/c;->c:La7/c;

    .line 8
    .line 9
    new-instance v0, La7/c;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, La7/c;->d:La7/c;

    .line 16
    .line 17
    new-instance v0, La7/c;

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 21
    .line 22
    .line 23
    sput-object v0, La7/c;->e:La7/c;

    .line 24
    .line 25
    new-instance v0, La7/c;

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 29
    .line 30
    .line 31
    sput-object v0, La7/c;->f:La7/c;

    .line 32
    .line 33
    new-instance v0, La7/c;

    .line 34
    .line 35
    const/4 v1, 0x4

    .line 36
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 37
    .line 38
    .line 39
    sput-object v0, La7/c;->g:La7/c;

    .line 40
    .line 41
    new-instance v0, La7/c;

    .line 42
    .line 43
    const/4 v1, 0x5

    .line 44
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 45
    .line 46
    .line 47
    sput-object v0, La7/c;->h:La7/c;

    .line 48
    .line 49
    new-instance v0, La7/c;

    .line 50
    .line 51
    const/4 v1, 0x6

    .line 52
    invoke-direct {v0, v1}, La7/c;-><init>(I)V

    .line 53
    .line 54
    .line 55
    sput-object v0, La7/c;->i:La7/c;

    .line 56
    .line 57
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, La7/c;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/app/Activity;)F
    .registers 3

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    .line 15
    .line 16
    return p1
.end method

.method public b(Landroid/app/Activity;)Landroid/graphics/Rect;
    .registers 10

    .line 1
    iget v0, p0, La7/c;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1d2

    .line 4
    .line 5
    .line 6
    const-string v0, "activity"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    :try_start_12
    const-class v1, Landroid/content/res/Configuration;

    .line 20
    .line 21
    const-string v2, "windowConfiguration"

    .line 22
    .line 23
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const/4 v2, 0x1

    .line 28
    invoke-virtual {v1, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    const-string v2, "getBounds"

    .line 40
    .line 41
    const/4 v3, 0x0

    .line 42
    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    new-instance v2, Landroid/graphics/Rect;

    .line 47
    .line 48
    invoke-virtual {v1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    const-string v1, "null cannot be cast to non-null type android.graphics.Rect"

    .line 53
    .line 54
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    check-cast v0, Landroid/graphics/Rect;

    .line 58
    .line 59
    invoke-direct {v2, v0}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V
    :try_end_3d
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_3d} :catch_3e

    .line 60
    .line 61
    .line 62
    goto :goto_61

    .line 63
    :catch_3e
    move-exception v0

    .line 64
    instance-of v1, v0, Ljava/lang/NoSuchFieldException;

    .line 65
    .line 66
    if-nez v1, :cond_51

    .line 67
    .line 68
    instance-of v1, v0, Ljava/lang/NoSuchMethodException;

    .line 69
    .line 70
    if-nez v1, :cond_51

    .line 71
    .line 72
    instance-of v1, v0, Ljava/lang/IllegalAccessException;

    .line 73
    .line 74
    if-nez v1, :cond_51

    .line 75
    .line 76
    instance-of v1, v0, Ljava/lang/reflect/InvocationTargetException;

    .line 77
    .line 78
    if-eqz v1, :cond_50

    .line 79
    .line 80
    goto :goto_51

    .line 81
    :cond_50
    throw v0

    .line 82
    :cond_51
    :goto_51
    sget-object v1, La7/b;->a:La7/a;

    .line 83
    .line 84
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    sget-object v1, La7/a;->b:Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 90
    .line 91
    .line 92
    sget-object v0, La7/c;->d:La7/c;

    .line 93
    .line 94
    invoke-virtual {v0, p1}, La7/c;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    :goto_61
    return-object v2

    .line 99
    :pswitch_62
    const-string v0, "activity"

    .line 100
    .line 101
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    new-instance v0, Landroid/graphics/Rect;

    .line 105
    .line 106
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    :try_start_74
    const-class v2, Landroid/content/res/Configuration;

    .line 118
    .line 119
    const-string v3, "windowConfiguration"

    .line 120
    .line 121
    invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    const/4 v3, 0x1

    .line 126
    invoke-virtual {v2, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v2, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    invoke-virtual {p1}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 134
    .line 135
    .line 136
    move-result v2
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_88} :catch_a4

    .line 137
    const-string v3, "null cannot be cast to non-null type android.graphics.Rect"

    .line 138
    .line 139
    const/4 v4, 0x0

    .line 140
    if-eqz v2, :cond_a6

    .line 141
    .line 142
    :try_start_8d
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    const-string v5, "getBounds"

    .line 147
    .line 148
    invoke-virtual {v2, v5, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 149
    .line 150
    .line 151
    move-result-object v2

    .line 152
    invoke-virtual {v2, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    check-cast v1, Landroid/graphics/Rect;

    .line 160
    .line 161
    invoke-virtual {v0, v1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 162
    .line 163
    .line 164
    goto :goto_e4

    .line 165
    :catch_a4
    move-exception v1

    .line 166
    goto :goto_bd

    .line 167
    :cond_a6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    const-string v5, "getAppBounds"

    .line 172
    .line 173
    invoke-virtual {v2, v5, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    invoke-virtual {v2, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v1

    .line 181
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    check-cast v1, Landroid/graphics/Rect;

    .line 185
    .line 186
    invoke-virtual {v0, v1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V
    :try_end_bc
    .catch Ljava/lang/Exception; {:try_start_8d .. :try_end_bc} :catch_a4

    .line 187
    .line 188
    .line 189
    goto :goto_e4

    .line 190
    :goto_bd
    instance-of v2, v1, Ljava/lang/NoSuchFieldException;

    .line 191
    .line 192
    if-nez v2, :cond_cf

    .line 193
    .line 194
    instance-of v2, v1, Ljava/lang/NoSuchMethodException;

    .line 195
    .line 196
    if-nez v2, :cond_cf

    .line 197
    .line 198
    instance-of v2, v1, Ljava/lang/IllegalAccessException;

    .line 199
    .line 200
    if-nez v2, :cond_cf

    .line 201
    .line 202
    instance-of v2, v1, Ljava/lang/reflect/InvocationTargetException;

    .line 203
    .line 204
    if-eqz v2, :cond_ce

    .line 205
    .line 206
    goto :goto_cf

    .line 207
    :cond_ce
    throw v1

    .line 208
    :cond_cf
    :goto_cf
    sget-object v2, La7/b;->a:La7/a;

    .line 209
    .line 210
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 211
    .line 212
    .line 213
    sget-object v2, La7/a;->b:Ljava/lang/String;

    .line 214
    .line 215
    invoke-static {v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 216
    .line 217
    .line 218
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    invoke-virtual {v1, v0}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 227
    .line 228
    .line 229
    :goto_e4
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 230
    .line 231
    .line 232
    move-result-object v1

    .line 233
    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    new-instance v2, Landroid/graphics/Point;

    .line 238
    .line 239
    invoke-direct {v2}, Landroid/graphics/Point;-><init>()V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v1, v2}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {p1}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 246
    .line 247
    .line 248
    move-result v3

    .line 249
    const/4 v4, 0x0

    .line 250
    if-nez v3, :cond_12b

    .line 251
    .line 252
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 253
    .line 254
    .line 255
    move-result-object v3

    .line 256
    const-string v5, "dimen"

    .line 257
    .line 258
    const-string v6, "android"

    .line 259
    .line 260
    const-string v7, "navigation_bar_height"

    .line 261
    .line 262
    invoke-virtual {v3, v7, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 263
    .line 264
    .line 265
    move-result v5

    .line 266
    if-lez v5, :cond_110

    .line 267
    .line 268
    invoke-virtual {v3, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    goto :goto_111

    .line 273
    :cond_110
    move v3, v4

    .line 274
    :goto_111
    iget v5, v0, Landroid/graphics/Rect;->bottom:I

    .line 275
    .line 276
    add-int/2addr v5, v3

    .line 277
    iget v6, v2, Landroid/graphics/Point;->y:I

    .line 278
    .line 279
    if-ne v5, v6, :cond_11b

    .line 280
    .line 281
    iput v5, v0, Landroid/graphics/Rect;->bottom:I

    .line 282
    .line 283
    goto :goto_12b

    .line 284
    :cond_11b
    iget v5, v0, Landroid/graphics/Rect;->right:I

    .line 285
    .line 286
    add-int/2addr v5, v3

    .line 287
    iget v6, v2, Landroid/graphics/Point;->x:I

    .line 288
    .line 289
    if-ne v5, v6, :cond_125

    .line 290
    .line 291
    iput v5, v0, Landroid/graphics/Rect;->right:I

    .line 292
    .line 293
    goto :goto_12b

    .line 294
    :cond_125
    iget v5, v0, Landroid/graphics/Rect;->left:I

    .line 295
    .line 296
    if-ne v5, v3, :cond_12b

    .line 297
    .line 298
    iput v4, v0, Landroid/graphics/Rect;->left:I

    .line 299
    .line 300
    :cond_12b
    :goto_12b
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 301
    .line 302
    .line 303
    move-result v3

    .line 304
    iget v5, v2, Landroid/graphics/Point;->x:I

    .line 305
    .line 306
    if-lt v3, v5, :cond_13b

    .line 307
    .line 308
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    .line 309
    .line 310
    .line 311
    move-result v3

    .line 312
    iget v5, v2, Landroid/graphics/Point;->y:I

    .line 313
    .line 314
    if-ge v3, v5, :cond_183

    .line 315
    .line 316
    :cond_13b
    invoke-virtual {p1}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 317
    .line 318
    .line 319
    move-result p1

    .line 320
    if-nez p1, :cond_183

    .line 321
    .line 322
    invoke-static {v1}, La7/e;->a(Landroid/view/Display;)Landroid/view/DisplayCutout;

    .line 323
    .line 324
    .line 325
    move-result-object p1

    .line 326
    if-eqz p1, :cond_183

    .line 327
    .line 328
    iget v1, v0, Landroid/graphics/Rect;->left:I

    .line 329
    .line 330
    invoke-static {p1}, La7/e;->G(Landroid/view/DisplayCutout;)I

    .line 331
    .line 332
    .line 333
    move-result v3

    .line 334
    if-ne v1, v3, :cond_151

    .line 335
    .line 336
    iput v4, v0, Landroid/graphics/Rect;->left:I

    .line 337
    .line 338
    :cond_151
    iget v1, v2, Landroid/graphics/Point;->x:I

    .line 339
    .line 340
    iget v3, v0, Landroid/graphics/Rect;->right:I

    .line 341
    .line 342
    sub-int/2addr v1, v3

    .line 343
    invoke-static {p1}, La7/e;->H(Landroid/view/DisplayCutout;)I

    .line 344
    .line 345
    .line 346
    move-result v3

    .line 347
    if-ne v1, v3, :cond_165

    .line 348
    .line 349
    iget v1, v0, Landroid/graphics/Rect;->right:I

    .line 350
    .line 351
    invoke-static {p1}, La7/e;->H(Landroid/view/DisplayCutout;)I

    .line 352
    .line 353
    .line 354
    move-result v3

    .line 355
    add-int/2addr v3, v1

    .line 356
    iput v3, v0, Landroid/graphics/Rect;->right:I

    .line 357
    .line 358
    :cond_165
    iget v1, v0, Landroid/graphics/Rect;->top:I

    .line 359
    .line 360
    invoke-static {p1}, La7/e;->I(Landroid/view/DisplayCutout;)I

    .line 361
    .line 362
    .line 363
    move-result v3

    .line 364
    if-ne v1, v3, :cond_16f

    .line 365
    .line 366
    iput v4, v0, Landroid/graphics/Rect;->top:I

    .line 367
    .line 368
    :cond_16f
    iget v1, v2, Landroid/graphics/Point;->y:I

    .line 369
    .line 370
    iget v2, v0, Landroid/graphics/Rect;->bottom:I

    .line 371
    .line 372
    sub-int/2addr v1, v2

    .line 373
    invoke-static {p1}, La7/e;->F(Landroid/view/DisplayCutout;)I

    .line 374
    .line 375
    .line 376
    move-result v2

    .line 377
    if-ne v1, v2, :cond_183

    .line 378
    .line 379
    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 380
    .line 381
    invoke-static {p1}, La7/e;->F(Landroid/view/DisplayCutout;)I

    .line 382
    .line 383
    .line 384
    move-result p1

    .line 385
    add-int/2addr p1, v1

    .line 386
    iput p1, v0, Landroid/graphics/Rect;->bottom:I

    .line 387
    .line 388
    :cond_183
    return-object v0

    .line 389
    :pswitch_184
    const-string v0, "activity"

    .line 390
    .line 391
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 392
    .line 393
    .line 394
    new-instance v0, Landroid/graphics/Rect;

    .line 395
    .line 396
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 397
    .line 398
    .line 399
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 400
    .line 401
    .line 402
    move-result-object v1

    .line 403
    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 404
    .line 405
    .line 406
    move-result-object v1

    .line 407
    invoke-virtual {v1, v0}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 408
    .line 409
    .line 410
    invoke-virtual {p1}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 411
    .line 412
    .line 413
    move-result v2

    .line 414
    if-nez v2, :cond_1d0

    .line 415
    .line 416
    new-instance v2, Landroid/graphics/Point;

    .line 417
    .line 418
    invoke-direct {v2}, Landroid/graphics/Point;-><init>()V

    .line 419
    .line 420
    .line 421
    invoke-virtual {v1, v2}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 422
    .line 423
    .line 424
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 425
    .line 426
    .line 427
    move-result-object p1

    .line 428
    const-string v1, "dimen"

    .line 429
    .line 430
    const-string v3, "android"

    .line 431
    .line 432
    const-string v4, "navigation_bar_height"

    .line 433
    .line 434
    invoke-virtual {p1, v4, v1, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 435
    .line 436
    .line 437
    move-result v1

    .line 438
    if-lez v1, :cond_1bc

    .line 439
    .line 440
    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 441
    .line 442
    .line 443
    move-result p1

    .line 444
    goto :goto_1bd

    .line 445
    :cond_1bc
    const/4 p1, 0x0

    .line 446
    :goto_1bd
    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 447
    .line 448
    add-int/2addr v1, p1

    .line 449
    iget v3, v2, Landroid/graphics/Point;->y:I

    .line 450
    .line 451
    if-ne v1, v3, :cond_1c7

    .line 452
    .line 453
    iput v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 454
    .line 455
    goto :goto_1d0

    .line 456
    :cond_1c7
    iget v1, v0, Landroid/graphics/Rect;->right:I

    .line 457
    .line 458
    add-int/2addr v1, p1

    .line 459
    iget p1, v2, Landroid/graphics/Point;->x:I

    .line 460
    .line 461
    if-ne v1, p1, :cond_1d0

    .line 462
    .line 463
    iput v1, v0, Landroid/graphics/Rect;->right:I

    .line 464
    .line 465
    :cond_1d0
    :goto_1d0
    return-object v0

    .line 466
    nop

    .line 467
    :pswitch_data_1d2
    .packed-switch 0x0
        :pswitch_184
        :pswitch_62
    .end packed-switch
.end method

.method public c(Landroid/app/Activity;La7/f;)Lz6/a;
    .registers 6

    .line 1
    iget v0, p0, La7/c;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_78

    .line 4
    .line 5
    .line 6
    const-string v0, "activity"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "densityCompatHelper"

    .line 12
    .line 13
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lz6/a;

    .line 17
    .line 18
    new-instance v1, Ly6/a;

    .line 19
    .line 20
    sget-object v2, La7/b;->a:La7/a;

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-static {}, La7/a;->a()La7/b;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    invoke-interface {v2, p1}, La7/b;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    invoke-direct {v1, v2}, Ly6/a;-><init>(Landroid/graphics/Rect;)V

    .line 34
    .line 35
    .line 36
    invoke-interface {p2, p1}, La7/f;->a(Landroid/app/Activity;)F

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    invoke-direct {v0, v1, p1}, Lz6/a;-><init>(Ly6/a;F)V

    .line 41
    .line 42
    .line 43
    return-object v0

    .line 44
    :pswitch_2b
    const-string v0, "activity"

    .line 45
    .line 46
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const-string v0, "densityCompatHelper"

    .line 50
    .line 51
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    new-instance v0, Lz6/a;

    .line 55
    .line 56
    new-instance v1, Ly6/a;

    .line 57
    .line 58
    sget-object v2, La7/b;->a:La7/a;

    .line 59
    .line 60
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    invoke-static {}, La7/a;->a()La7/b;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-interface {v2, p1}, La7/b;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    invoke-direct {v1, v2}, Ly6/a;-><init>(Landroid/graphics/Rect;)V

    .line 72
    .line 73
    .line 74
    invoke-interface {p2, p1}, La7/f;->a(Landroid/app/Activity;)F

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    invoke-direct {v0, v1, p1}, Lz6/a;-><init>(Ly6/a;F)V

    .line 79
    .line 80
    .line 81
    return-object v0

    .line 82
    :pswitch_51
    const-string v0, "activity"

    .line 83
    .line 84
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    const-string v0, "densityCompatHelper"

    .line 88
    .line 89
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    new-instance v0, Lz6/a;

    .line 93
    .line 94
    new-instance v1, Ly6/a;

    .line 95
    .line 96
    sget-object v2, La7/b;->a:La7/a;

    .line 97
    .line 98
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    .line 100
    .line 101
    invoke-static {}, La7/a;->a()La7/b;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    invoke-interface {v2, p1}, La7/b;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 106
    .line 107
    .line 108
    move-result-object v2

    .line 109
    invoke-direct {v1, v2}, Ly6/a;-><init>(Landroid/graphics/Rect;)V

    .line 110
    .line 111
    .line 112
    invoke-interface {p2, p1}, La7/f;->a(Landroid/app/Activity;)F

    .line 113
    .line 114
    .line 115
    move-result p1

    .line 116
    invoke-direct {v0, v1, p1}, Lz6/a;-><init>(Ly6/a;F)V

    .line 117
    .line 118
    .line 119
    return-object v0

    .line 120
    nop

    .line 121
    :pswitch_data_78
    .packed-switch 0x4
        :pswitch_51
        :pswitch_2b
    .end packed-switch
.end method
