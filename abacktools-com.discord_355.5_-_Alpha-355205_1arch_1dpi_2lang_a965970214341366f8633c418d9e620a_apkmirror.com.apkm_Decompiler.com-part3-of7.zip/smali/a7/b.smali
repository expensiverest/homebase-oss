###### Class a7.b (a7.b)
.class public interface abstract La7/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La7/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, La7/a;->a:La7/a;

    .line 2
    .line 3
    sput-object v0, La7/b;->a:La7/a;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public abstract b(Landroid/app/Activity;)Landroid/graphics/Rect;
.end method
