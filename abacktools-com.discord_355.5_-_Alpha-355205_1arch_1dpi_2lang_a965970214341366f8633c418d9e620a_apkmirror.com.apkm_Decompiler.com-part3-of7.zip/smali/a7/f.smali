###### Class a7.f (a7.f)
.class public interface abstract La7/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/app/Activity;)F
.end method
