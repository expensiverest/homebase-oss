###### Class a7.a (a7.a)
.class public final La7/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:La7/a;

.field public static final b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, La7/a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La7/a;->a:La7/a;

    .line 7
    .line 8
    const-class v0, La7/b;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, La7/a;->b:Ljava/lang/String;

    .line 15
    .line 16
    return-void
.end method

.method public static a()La7/b;
    .registers 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1e

    .line 4
    .line 5
    if-lt v0, v1, :cond_9

    .line 6
    .line 7
    sget-object v0, La7/d;->b:La7/d;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_9
    const/16 v1, 0x1d

    .line 11
    .line 12
    if-lt v0, v1, :cond_10

    .line 13
    .line 14
    sget-object v0, La7/c;->e:La7/c;

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_10
    const/16 v1, 0x1c

    .line 18
    .line 19
    if-lt v0, v1, :cond_17

    .line 20
    .line 21
    sget-object v0, La7/c;->d:La7/c;

    .line 22
    .line 23
    return-object v0

    .line 24
    :cond_17
    sget-object v0, La7/c;->c:La7/c;

    .line 25
    .line 26
    return-object v0
.end method
