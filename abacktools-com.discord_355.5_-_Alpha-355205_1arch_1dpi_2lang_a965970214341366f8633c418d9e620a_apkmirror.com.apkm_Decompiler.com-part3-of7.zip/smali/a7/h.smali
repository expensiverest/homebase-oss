###### Class a7.h (a7.h)
.class public interface abstract La7/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Landroid/app/Activity;La7/f;)Lz6/a;
.end method
