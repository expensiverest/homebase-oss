###### Class aa.a (aa.a)
.class public final synthetic Laa/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Laa/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lbn/d;Lbn/c;)V
    .registers 3

    .line 2
    const/16 p1, 0xa

    iput p1, p0, Laa/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 21

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Laa/a;->d:I

    .line 4
    .line 5
    sget-object v2, Ll30/a0;->a:Ll30/a0;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    packed-switch v0, :pswitch_data_170

    .line 9
    .line 10
    .line 11
    new-instance v0, Landroid/net/http/X509TrustManagerExtensions;

    .line 12
    .line 13
    sget-object v2, Lcom/margelo/nitro/nitrofetch/h;->a:Lcom/margelo/nitro/nitrofetch/h;

    .line 14
    .line 15
    sget-object v2, Lcom/margelo/nitro/nitrofetch/h;->h:Ll30/o;

    .line 16
    .line 17
    invoke-virtual {v2}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Ljavax/net/ssl/X509TrustManager;

    .line 22
    .line 23
    invoke-direct {v0, v2}, Landroid/net/http/X509TrustManagerExtensions;-><init>(Ljavax/net/ssl/X509TrustManager;)V

    .line 24
    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_1a
    invoke-static {}, Ljavax/net/ssl/TrustManagerFactory;->getDefaultAlgorithm()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0}, Ljavax/net/ssl/TrustManagerFactory;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/TrustManagerFactory;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const/4 v2, 0x0

    .line 36
    invoke-virtual {v0, v2}, Ljavax/net/ssl/TrustManagerFactory;->init(Ljava/security/KeyStore;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ljavax/net/ssl/TrustManagerFactory;->getTrustManagers()[Ljavax/net/ssl/TrustManager;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    const-string v2, "getTrustManagers(...)"

    .line 44
    .line 45
    invoke-static {v0, v2}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    new-instance v2, Ljava/util/ArrayList;

    .line 49
    .line 50
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 51
    .line 52
    .line 53
    array-length v4, v0

    .line 54
    :goto_35
    if-ge v3, v4, :cond_43

    .line 55
    .line 56
    aget-object v5, v0, v3

    .line 57
    .line 58
    instance-of v6, v5, Ljavax/net/ssl/X509TrustManager;

    .line 59
    .line 60
    if-eqz v6, :cond_40

    .line 61
    .line 62
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    :cond_40
    add-int/lit8 v3, v3, 0x1

    .line 66
    .line 67
    goto :goto_35

    .line 68
    :cond_43
    invoke-static {v2}, Lm30/q;->n0(Ljava/util/List;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    check-cast v0, Ljavax/net/ssl/X509TrustManager;

    .line 73
    .line 74
    return-object v0

    .line 75
    :pswitch_4a
    new-instance v0, Lw60/m;

    .line 76
    .line 77
    const-string v2, "^[A-Za-z0-9+/]{43}=$"

    .line 78
    .line 79
    invoke-direct {v0, v2}, Lw60/m;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    return-object v0

    .line 83
    :pswitch_52
    new-instance v0, Lw60/m;

    .line 84
    .line 85
    const-string v2, "^\\d{4}-\\d{2}-\\d{2}$"

    .line 86
    .line 87
    invoke-direct {v0, v2}, Lw60/m;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    return-object v0

    .line 91
    :pswitch_5a
    new-instance v0, Lw60/m;

    .line 92
    .line 93
    const-string v2, "^[0-9.]+$"

    .line 94
    .line 95
    invoke-direct {v0, v2}, Lw60/m;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    return-object v0

    .line 99
    :pswitch_62
    new-instance v0, Lw60/m;

    .line 100
    .line 101
    const-string v2, "^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$"

    .line 102
    .line 103
    invoke-direct {v0, v2}, Lw60/m;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    return-object v0

    .line 107
    :pswitch_6a
    invoke-static {}, Lcom/facebook/react/bridge/UiThreadUtil;->a()Landroid/os/Handler;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    return-object v0

    .line 112
    :pswitch_6f
    invoke-static {}, Lcom/facebook/imageutils/BitmapUtil;->a()Lu1/d;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    return-object v0

    .line 117
    :pswitch_74
    new-instance v0, Lcom/discord/crash_reporting/q;

    .line 118
    .line 119
    invoke-direct {v0, v3}, Lcom/discord/crash_reporting/q;-><init>(I)V

    .line 120
    .line 121
    .line 122
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    return-object v0

    .line 127
    :pswitch_7e
    sget v0, Lci/a;->w:I

    .line 128
    .line 129
    return-object v2

    .line 130
    :pswitch_81
    sget-boolean v0, Llf/g;->a:Z

    .line 131
    .line 132
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    return-object v0

    .line 137
    :pswitch_88
    new-instance v0, Lb80/f0;

    .line 138
    .line 139
    invoke-direct {v0}, Lb80/f0;-><init>()V

    .line 140
    .line 141
    .line 142
    new-instance v2, Lb80/g0;

    .line 143
    .line 144
    invoke-direct {v2, v0}, Lb80/g0;-><init>(Lb80/f0;)V

    .line 145
    .line 146
    .line 147
    return-object v2

    .line 148
    :pswitch_93
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    return-object v0

    .line 153
    :pswitch_98
    invoke-static {}, Lca/d0;->values()[Lca/d0;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    const-string v17, "components"

    .line 158
    .line 159
    const-string v18, "unknown"

    .line 160
    .line 161
    const-string v2, "article"

    .line 162
    .line 163
    const-string v3, "image"

    .line 164
    .line 165
    const-string v4, "video"

    .line 166
    .line 167
    const-string v5, "audio"

    .line 168
    .line 169
    const-string v6, "tweet"

    .line 170
    .line 171
    const-string v7, "link"

    .line 172
    .line 173
    const-string v8, "html"

    .line 174
    .line 175
    const-string v9, "file"

    .line 176
    .line 177
    const-string v10, "gifv"

    .line 178
    .line 179
    const-string v11, "rich"

    .line 180
    .line 181
    const-string v12, "text"

    .line 182
    .line 183
    const-string v13, "application_news"

    .line 184
    .line 185
    const-string v14, "post_preview"

    .line 186
    .line 187
    const-string v15, "safety_policy_notice"

    .line 188
    .line 189
    const-string v16, "safety_system_notification"

    .line 190
    .line 191
    filled-new-array/range {v2 .. v18}, [Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v2

    .line 195
    const/16 v18, 0x0

    .line 196
    .line 197
    const/16 v19, 0x0

    .line 198
    .line 199
    const/4 v3, 0x0

    .line 200
    const/4 v4, 0x0

    .line 201
    const/4 v5, 0x0

    .line 202
    const/4 v6, 0x0

    .line 203
    const/4 v7, 0x0

    .line 204
    const/4 v8, 0x0

    .line 205
    const/4 v9, 0x0

    .line 206
    const/4 v10, 0x0

    .line 207
    const/4 v11, 0x0

    .line 208
    const/4 v12, 0x0

    .line 209
    const/4 v13, 0x0

    .line 210
    const/4 v14, 0x0

    .line 211
    const/4 v15, 0x0

    .line 212
    const/16 v16, 0x0

    .line 213
    .line 214
    const/16 v17, 0x0

    .line 215
    .line 216
    filled-new-array/range {v3 .. v19}, [[Ljava/lang/annotation/Annotation;

    .line 217
    .line 218
    .line 219
    move-result-object v3

    .line 220
    const-string v4, "com.discord.chat.bridge.embed.EmbedType"

    .line 221
    .line 222
    invoke-static {v4, v0, v2, v3}, Ln70/t0;->e(Ljava/lang/String;[Ljava/lang/Enum;[Ljava/lang/String;[[Ljava/lang/annotation/Annotation;)Lj70/a;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    return-object v0

    .line 227
    :pswitch_e2
    new-instance v0, Ln70/d;

    .line 228
    .line 229
    sget-object v2, Lu9/g1;->d:Lu9/g1;

    .line 230
    .line 231
    invoke-direct {v0, v2, v3}, Ln70/d;-><init>(Lj70/b;I)V

    .line 232
    .line 233
    .line 234
    return-object v0

    .line 235
    :pswitch_ea
    new-instance v0, Ln70/d;

    .line 236
    .line 237
    sget-object v2, Lca/s;->a:Lca/s;

    .line 238
    .line 239
    invoke-direct {v0, v2, v3}, Ln70/d;-><init>(Lj70/b;I)V

    .line 240
    .line 241
    .line 242
    return-object v0

    .line 243
    :pswitch_f2
    new-instance v0, Ln70/d;

    .line 244
    .line 245
    sget-object v2, Lca/m;->a:Lca/m;

    .line 246
    .line 247
    invoke-direct {v0, v2, v3}, Ln70/d;-><init>(Lj70/b;I)V

    .line 248
    .line 249
    .line 250
    return-object v0

    .line 251
    :pswitch_fa
    sget-object v0, Lca/d0;->Companion:Lca/c0;

    .line 252
    .line 253
    invoke-virtual {v0}, Lca/c0;->serializer()Lj70/b;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    return-object v0

    .line 258
    :pswitch_101
    return-object v2

    .line 259
    :pswitch_102
    sget-object v0, Lm30/t;->d:Lm30/t;

    .line 260
    .line 261
    return-object v0

    .line 262
    :pswitch_105
    :try_start_105
    const-string v0, "dsti"

    .line 263
    .line 264
    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    const/4 v0, 0x1

    .line 268
    sput-boolean v0, Lk80/d;->e:Z
    :try_end_10d
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_105 .. :try_end_10d} :catch_10e

    .line 269
    .line 270
    goto :goto_118

    .line 271
    :catch_10e
    move-exception v0

    .line 272
    sget-object v3, Lnf/a;->a:Lnf/a;

    .line 273
    .line 274
    const-string v3, "RLottie"

    .line 275
    .line 276
    const-string v4, "Unable to load animated sticker library."

    .line 277
    .line 278
    invoke-static {v3, v4, v0}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 279
    .line 280
    .line 281
    :goto_118
    return-object v2

    .line 282
    :pswitch_119
    new-instance v0, Ln70/d;

    .line 283
    .line 284
    sget-object v2, Lbi/d;->a:Lbi/d;

    .line 285
    .line 286
    invoke-direct {v0, v2, v3}, Ln70/d;-><init>(Lj70/b;I)V

    .line 287
    .line 288
    .line 289
    return-object v0

    .line 290
    :pswitch_121
    sget v0, Lbh/i;->e0:I

    .line 291
    .line 292
    return-object v2

    .line 293
    :pswitch_124
    new-instance v0, Ln70/d;

    .line 294
    .line 295
    sget-object v2, Lyh/p;->a:Lyh/p;

    .line 296
    .line 297
    invoke-direct {v0, v2, v3}, Ln70/d;-><init>(Lj70/b;I)V

    .line 298
    .line 299
    .line 300
    return-object v0

    .line 301
    :pswitch_12c
    const-string v0, "[-/ ]"

    .line 302
    .line 303
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 304
    .line 305
    .line 306
    move-result-object v0

    .line 307
    return-object v0

    .line 308
    :pswitch_133
    new-instance v0, Lj70/a;

    .line 309
    .line 310
    sget-object v2, Lad/j8;->INSTANCE:Lad/j8;

    .line 311
    .line 312
    new-array v3, v3, [Ljava/lang/annotation/Annotation;

    .line 313
    .line 314
    const-string v4, "com.discord.chat.reactevents.TapTimeoutIconData"

    .line 315
    .line 316
    invoke-direct {v0, v4, v2, v3}, Lj70/a;-><init>(Ljava/lang/String;Lui/a;[Ljava/lang/annotation/Annotation;)V

    .line 317
    .line 318
    .line 319
    return-object v0

    .line 320
    :pswitch_13f
    new-instance v0, Lj70/a;

    .line 321
    .line 322
    sget-object v2, Lad/c8;->INSTANCE:Lad/c8;

    .line 323
    .line 324
    new-array v3, v3, [Ljava/lang/annotation/Annotation;

    .line 325
    .line 326
    const-string v4, "com.discord.chat.reactevents.TapSuppressNotificationsIconData"

    .line 327
    .line 328
    invoke-direct {v0, v4, v2, v3}, Lj70/a;-><init>(Ljava/lang/String;Lui/a;[Ljava/lang/annotation/Annotation;)V

    .line 329
    .line 330
    .line 331
    return-object v0

    .line 332
    :pswitch_14b
    new-instance v0, Lj70/a;

    .line 333
    .line 334
    sget-object v2, Lad/c6;->INSTANCE:Lad/c6;

    .line 335
    .line 336
    new-array v3, v3, [Ljava/lang/annotation/Annotation;

    .line 337
    .line 338
    const-string v4, "com.discord.chat.reactevents.TapOpTagData"

    .line 339
    .line 340
    invoke-direct {v0, v4, v2, v3}, Lj70/a;-><init>(Ljava/lang/String;Lui/a;[Ljava/lang/annotation/Annotation;)V

    .line 341
    .line 342
    .line 343
    return-object v0

    .line 344
    :pswitch_157
    new-instance v0, Lj70/e;

    .line 345
    .line 346
    const-class v2, Ljava/lang/CharSequence;

    .line 347
    .line 348
    sget-object v4, Lkotlin/jvm/internal/v;->a:Lkotlin/jvm/internal/w;

    .line 349
    .line 350
    invoke-virtual {v4, v2}, Lkotlin/jvm/internal/w;->b(Ljava/lang/Class;)Lh40/d;

    .line 351
    .line 352
    .line 353
    move-result-object v2

    .line 354
    new-array v3, v3, [Ljava/lang/annotation/Annotation;

    .line 355
    .line 356
    invoke-direct {v0, v2, v3}, Lj70/e;-><init>(Lh40/d;[Ljava/lang/annotation/Annotation;)V

    .line 357
    .line 358
    .line 359
    return-object v0

    .line 360
    :pswitch_167
    new-instance v0, Ln70/d;

    .line 361
    .line 362
    sget-object v2, Ln70/h1;->a:Ln70/h1;

    .line 363
    .line 364
    invoke-direct {v0, v2, v3}, Ln70/d;-><init>(Lj70/b;I)V

    .line 365
    .line 366
    .line 367
    return-object v0

    .line 368
    nop

    .line 369
    :pswitch_data_170
    .packed-switch 0x0
        :pswitch_167
        :pswitch_157
        :pswitch_14b
        :pswitch_13f
        :pswitch_133
        :pswitch_12c
        :pswitch_124
        :pswitch_121
        :pswitch_119
        :pswitch_105
        :pswitch_102
        :pswitch_101
        :pswitch_fa
        :pswitch_f2
        :pswitch_ea
        :pswitch_e2
        :pswitch_98
        :pswitch_93
        :pswitch_88
        :pswitch_81
        :pswitch_7e
        :pswitch_74
        :pswitch_6f
        :pswitch_6a
        :pswitch_62
        :pswitch_5a
        :pswitch_52
        :pswitch_4a
        :pswitch_1a
    .end packed-switch
.end method
