###### Class aa.b (aa.b)
.class public final synthetic Laa/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Laa/b;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Laa/b;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Laa/b;->a:Laa/b;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.bridge.customthemes.SharedCustomThemeData"

    .line 11
    .line 12
    const/16 v3, 0x8

    .line 13
    .line 14
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 15
    .line 16
    .line 17
    const-string v0, "colors"

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 21
    .line 22
    .line 23
    const-string v0, "gradientAngle"

    .line 24
    .line 25
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 26
    .line 27
    .line 28
    const-string v0, "createdBy"

    .line 29
    .line 30
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    const-string v0, "createdByAvatarUrl"

    .line 34
    .line 35
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    const-string v0, "nitroWheelIconUrl"

    .line 39
    .line 40
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v0, "previewLabel"

    .line 44
    .line 45
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    const-string v0, "previewHeading"

    .line 49
    .line 50
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 51
    .line 52
    .line 53
    const-string v0, "createdByLabel"

    .line 54
    .line 55
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 56
    .line 57
    .line 58
    sput-object v1, Laa/b;->descriptor:Ll70/g;

    .line 59
    .line 60
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 33

    .line 1
    sget-object v0, Laa/b;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    sget-object v2, Laa/d;->i:[Lkotlin/Lazy;

    .line 10
    .line 11
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    const/4 v4, 0x7

    .line 16
    const/4 v5, 0x6

    .line 17
    const/4 v6, 0x5

    .line 18
    const/4 v7, 0x3

    .line 19
    const/4 v8, 0x4

    .line 20
    const/4 v9, 0x2

    .line 21
    const/4 v10, 0x1

    .line 22
    const/4 v11, 0x0

    .line 23
    const/4 v12, 0x0

    .line 24
    if-eqz v3, :cond_59

    .line 25
    .line 26
    aget-object v2, v2, v11

    .line 27
    .line 28
    invoke-interface {v2}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Lj70/b;

    .line 33
    .line 34
    invoke-interface {v1, v0, v11, v2, v12}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    check-cast v2, Ljava/util/List;

    .line 39
    .line 40
    invoke-interface {v1, v0, v10}, Lm70/a;->y(Ll70/g;I)F

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    invoke-interface {v1, v0, v9}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v9

    .line 48
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v7

    .line 52
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v8

    .line 56
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v5

    .line 64
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    const/16 v10, 0xff

    .line 69
    .line 70
    move-object/from16 v23, v2

    .line 71
    .line 72
    move-object/from16 v30, v4

    .line 73
    .line 74
    move-object/from16 v29, v5

    .line 75
    .line 76
    move-object/from16 v28, v6

    .line 77
    .line 78
    move-object/from16 v26, v7

    .line 79
    .line 80
    move-object/from16 v27, v8

    .line 81
    .line 82
    move-object/from16 v25, v9

    .line 83
    .line 84
    move/from16 v22, v10

    .line 85
    .line 86
    :goto_55
    move/from16 v24, v3

    .line 87
    .line 88
    goto/16 :goto_da

    .line 89
    .line 90
    :cond_59
    const/4 v3, 0x0

    .line 91
    move/from16 v20, v10

    .line 92
    .line 93
    move-object v13, v12

    .line 94
    move-object v14, v13

    .line 95
    move-object v15, v14

    .line 96
    move-object/from16 v16, v15

    .line 97
    .line 98
    move-object/from16 v17, v16

    .line 99
    .line 100
    move-object/from16 v18, v17

    .line 101
    .line 102
    move-object/from16 v19, v18

    .line 103
    .line 104
    move v12, v11

    .line 105
    :goto_68
    if-eqz v20, :cond_c8

    .line 106
    .line 107
    move/from16 p1, v11

    .line 108
    .line 109
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 110
    .line 111
    .line 112
    move-result v11

    .line 113
    packed-switch v11, :pswitch_data_e4

    .line 114
    .line 115
    .line 116
    new-instance v0, Lj70/k;

    .line 117
    .line 118
    invoke-direct {v0, v11}, Lj70/k;-><init>(I)V

    .line 119
    .line 120
    .line 121
    throw v0

    .line 122
    :pswitch_79
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v19

    .line 126
    or-int/lit16 v12, v12, 0x80

    .line 127
    .line 128
    :goto_7f
    move/from16 v11, p1

    .line 129
    .line 130
    goto :goto_68

    .line 131
    :pswitch_82
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v18

    .line 135
    or-int/lit8 v12, v12, 0x40

    .line 136
    .line 137
    goto :goto_7f

    .line 138
    :pswitch_89
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v17

    .line 142
    or-int/lit8 v12, v12, 0x20

    .line 143
    .line 144
    goto :goto_7f

    .line 145
    :pswitch_90
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v16

    .line 149
    or-int/lit8 v12, v12, 0x10

    .line 150
    .line 151
    goto :goto_7f

    .line 152
    :pswitch_97
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v15

    .line 156
    or-int/lit8 v12, v12, 0x8

    .line 157
    .line 158
    goto :goto_7f

    .line 159
    :pswitch_9e
    invoke-interface {v1, v0, v9}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v14

    .line 163
    or-int/lit8 v12, v12, 0x4

    .line 164
    .line 165
    goto :goto_7f

    .line 166
    :pswitch_a5
    invoke-interface {v1, v0, v10}, Lm70/a;->y(Ll70/g;I)F

    .line 167
    .line 168
    .line 169
    move-result v3

    .line 170
    or-int/lit8 v12, v12, 0x2

    .line 171
    .line 172
    goto :goto_7f

    .line 173
    :pswitch_ac
    aget-object v11, v2, p1

    .line 174
    .line 175
    invoke-interface {v11}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v11

    .line 179
    check-cast v11, Lj70/b;

    .line 180
    .line 181
    move/from16 v4, p1

    .line 182
    .line 183
    invoke-interface {v1, v0, v4, v11, v13}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v11

    .line 187
    move-object v13, v11

    .line 188
    check-cast v13, Ljava/util/List;

    .line 189
    .line 190
    or-int/lit8 v12, v12, 0x1

    .line 191
    .line 192
    move v11, v4

    .line 193
    :goto_c0
    const/4 v4, 0x7

    .line 194
    goto :goto_68

    .line 195
    :pswitch_c2
    move/from16 v4, p1

    .line 196
    .line 197
    move v11, v4

    .line 198
    move/from16 v20, v11

    .line 199
    .line 200
    goto :goto_c0

    .line 201
    :cond_c8
    move/from16 v22, v12

    .line 202
    .line 203
    move-object/from16 v23, v13

    .line 204
    .line 205
    move-object/from16 v25, v14

    .line 206
    .line 207
    move-object/from16 v26, v15

    .line 208
    .line 209
    move-object/from16 v27, v16

    .line 210
    .line 211
    move-object/from16 v28, v17

    .line 212
    .line 213
    move-object/from16 v29, v18

    .line 214
    .line 215
    move-object/from16 v30, v19

    .line 216
    .line 217
    goto/16 :goto_55

    .line 218
    .line 219
    :goto_da
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 220
    .line 221
    .line 222
    new-instance v21, Laa/d;

    .line 223
    .line 224
    invoke-direct/range {v21 .. v30}, Laa/d;-><init>(ILjava/util/List;FLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    return-object v21

    .line 228
    nop

    .line 229
    :pswitch_data_e4
    .packed-switch -0x1
        :pswitch_c2
        :pswitch_ac
        :pswitch_a5
        :pswitch_9e
        :pswitch_97
        :pswitch_90
        :pswitch_89
        :pswitch_82
        :pswitch_79
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    sget-object v0, Laa/d;->i:[Lkotlin/Lazy;

    .line 2
    .line 3
    const/16 v1, 0x8

    .line 4
    .line 5
    new-array v1, v1, [Lj70/b;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    aget-object v0, v0, v2

    .line 9
    .line 10
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    aput-object v0, v1, v2

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    sget-object v2, Ln70/y;->a:Ln70/y;

    .line 18
    .line 19
    aput-object v2, v1, v0

    .line 20
    .line 21
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 22
    .line 23
    const/4 v2, 0x2

    .line 24
    aput-object v0, v1, v2

    .line 25
    .line 26
    const/4 v2, 0x3

    .line 27
    aput-object v0, v1, v2

    .line 28
    .line 29
    const/4 v2, 0x4

    .line 30
    aput-object v0, v1, v2

    .line 31
    .line 32
    const/4 v2, 0x5

    .line 33
    aput-object v0, v1, v2

    .line 34
    .line 35
    const/4 v2, 0x6

    .line 36
    aput-object v0, v1, v2

    .line 37
    .line 38
    const/4 v2, 0x7

    .line 39
    aput-object v0, v1, v2

    .line 40
    .line 41
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Laa/d;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Laa/b;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Laa/d;->i:[Lkotlin/Lazy;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    aget-object v1, v1, v2

    .line 18
    .line 19
    invoke-interface {v1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Lj70/j;

    .line 24
    .line 25
    iget-object v3, p2, Laa/d;->a:Ljava/util/List;

    .line 26
    .line 27
    invoke-interface {p1, v0, v2, v1, v3}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    const/4 v1, 0x1

    .line 31
    iget v2, p2, Laa/d;->b:F

    .line 32
    .line 33
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->y(Ll70/g;IF)V

    .line 34
    .line 35
    .line 36
    const/4 v1, 0x2

    .line 37
    iget-object v2, p2, Laa/d;->c:Ljava/lang/String;

    .line 38
    .line 39
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const/4 v1, 0x3

    .line 43
    iget-object v2, p2, Laa/d;->d:Ljava/lang/String;

    .line 44
    .line 45
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 46
    .line 47
    .line 48
    const/4 v1, 0x4

    .line 49
    iget-object v2, p2, Laa/d;->e:Ljava/lang/String;

    .line 50
    .line 51
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const/4 v1, 0x5

    .line 55
    iget-object v2, p2, Laa/d;->f:Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 58
    .line 59
    .line 60
    const/4 v1, 0x6

    .line 61
    iget-object v2, p2, Laa/d;->g:Ljava/lang/String;

    .line 62
    .line 63
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 64
    .line 65
    .line 66
    const/4 v1, 0x7

    .line 67
    iget-object p2, p2, Laa/d;->h:Ljava/lang/String;

    .line 68
    .line 69
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 73
    .line 74
    .line 75
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Laa/b;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
