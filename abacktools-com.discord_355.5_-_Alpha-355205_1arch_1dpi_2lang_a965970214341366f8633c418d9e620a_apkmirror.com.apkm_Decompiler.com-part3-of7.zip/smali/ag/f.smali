###### Class ag.f (ag.f)
.class public final Lag/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lag/e;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lag/e;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lag/f;->Companion:Lag/e;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final bridge a()Lcom/facebook/react/bridge/WritableMap;
    .registers 2

    .line 1
    invoke-static {p0}, Ls1/e;->J(Lui/a;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
