###### Class ag.b (ag.b)
.class public final Lag/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lag/a;->a:Lag/a;

    .line 2
    .line 3
    return-object v0
.end method
