###### Class ag.d (ag.d)
.class public final synthetic Lag/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lag/d;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lag/d;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lag/d;->a:Lag/d;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.media.react.events.PhotoLibraryChangedEvent"

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    sput-object v1, Lag/d;->descriptor:Ll70/g;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 5

    .line 1
    sget-object v0, Lag/d;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_1a

    .line 12
    .line 13
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const/4 v2, -0x1

    .line 18
    if-ne v1, v2, :cond_14

    .line 19
    .line 20
    goto :goto_1a

    .line 21
    :cond_14
    new-instance p1, Lj70/k;

    .line 22
    .line 23
    invoke-direct {p1, v1}, Lj70/k;-><init>(I)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1a
    :goto_1a
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 28
    .line 29
    .line 30
    new-instance p1, Lag/f;

    .line 31
    .line 32
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 4

    .line 1
    check-cast p2, Lag/f;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object p2, Lag/d;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, p2}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-interface {p1, p2}, Lm70/b;->c(Ll70/g;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lag/d;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
