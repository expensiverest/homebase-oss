###### Class a1.d (a1.d)
.class public final La1/d;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source "SourceFile"


# instance fields
.field public A:I

.field public B:I

.field public C:I

.field public D:F

.field public E:F

.field public F:Ljava/lang/String;

.field public G:F

.field public H:F

.field public I:I

.field public J:I

.field public K:I

.field public L:I

.field public M:I

.field public N:I

.field public O:I

.field public P:I

.field public Q:F

.field public R:F

.field public S:I

.field public T:I

.field public U:I

.field public V:Z

.field public W:Z

.field public X:Ljava/lang/String;

.field public Y:I

.field public Z:Z

.field public a:I

.field public a0:Z

.field public b:I

.field public b0:Z

.field public c:F

.field public c0:Z

.field public d:I

.field public d0:Z

.field public e:I

.field public e0:I

.field public f:I

.field public f0:I

.field public g:I

.field public g0:I

.field public h:I

.field public h0:I

.field public i:I

.field public i0:I

.field public j:I

.field public j0:I

.field public k:I

.field public k0:F

.field public l:I

.field public l0:I

.field public m:I

.field public m0:I

.field public n:I

.field public n0:F

.field public o:I

.field public o0:Lx0/d;

.field public p:I

.field public q:F

.field public r:I

.field public s:I

.field public t:I

.field public u:I

.field public v:I

.field public w:I

.field public x:I

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>(II)V
    .registers 7

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    .line 2
    .line 3
    .line 4
    const/4 p1, -0x1

    .line 5
    iput p1, p0, La1/d;->a:I

    .line 6
    .line 7
    iput p1, p0, La1/d;->b:I

    .line 8
    .line 9
    const/high16 p2, -0x40800000    # -1.0f

    .line 10
    .line 11
    iput p2, p0, La1/d;->c:F

    .line 12
    .line 13
    iput p1, p0, La1/d;->d:I

    .line 14
    .line 15
    iput p1, p0, La1/d;->e:I

    .line 16
    .line 17
    iput p1, p0, La1/d;->f:I

    .line 18
    .line 19
    iput p1, p0, La1/d;->g:I

    .line 20
    .line 21
    iput p1, p0, La1/d;->h:I

    .line 22
    .line 23
    iput p1, p0, La1/d;->i:I

    .line 24
    .line 25
    iput p1, p0, La1/d;->j:I

    .line 26
    .line 27
    iput p1, p0, La1/d;->k:I

    .line 28
    .line 29
    iput p1, p0, La1/d;->l:I

    .line 30
    .line 31
    iput p1, p0, La1/d;->m:I

    .line 32
    .line 33
    iput p1, p0, La1/d;->n:I

    .line 34
    .line 35
    iput p1, p0, La1/d;->o:I

    .line 36
    .line 37
    const/4 v0, 0x0

    .line 38
    iput v0, p0, La1/d;->p:I

    .line 39
    .line 40
    const/4 v1, 0x0

    .line 41
    iput v1, p0, La1/d;->q:F

    .line 42
    .line 43
    iput p1, p0, La1/d;->r:I

    .line 44
    .line 45
    iput p1, p0, La1/d;->s:I

    .line 46
    .line 47
    iput p1, p0, La1/d;->t:I

    .line 48
    .line 49
    iput p1, p0, La1/d;->u:I

    .line 50
    .line 51
    const/high16 v1, -0x80000000

    .line 52
    .line 53
    iput v1, p0, La1/d;->v:I

    .line 54
    .line 55
    iput v1, p0, La1/d;->w:I

    .line 56
    .line 57
    iput v1, p0, La1/d;->x:I

    .line 58
    .line 59
    iput v1, p0, La1/d;->y:I

    .line 60
    .line 61
    iput v1, p0, La1/d;->z:I

    .line 62
    .line 63
    iput v1, p0, La1/d;->A:I

    .line 64
    .line 65
    iput v1, p0, La1/d;->B:I

    .line 66
    .line 67
    iput v0, p0, La1/d;->C:I

    .line 68
    .line 69
    const/high16 v2, 0x3f000000    # 0.5f

    .line 70
    .line 71
    iput v2, p0, La1/d;->D:F

    .line 72
    .line 73
    iput v2, p0, La1/d;->E:F

    .line 74
    .line 75
    const/4 v3, 0x0

    .line 76
    iput-object v3, p0, La1/d;->F:Ljava/lang/String;

    .line 77
    .line 78
    iput p2, p0, La1/d;->G:F

    .line 79
    .line 80
    iput p2, p0, La1/d;->H:F

    .line 81
    .line 82
    iput v0, p0, La1/d;->I:I

    .line 83
    .line 84
    iput v0, p0, La1/d;->J:I

    .line 85
    .line 86
    iput v0, p0, La1/d;->K:I

    .line 87
    .line 88
    iput v0, p0, La1/d;->L:I

    .line 89
    .line 90
    iput v0, p0, La1/d;->M:I

    .line 91
    .line 92
    iput v0, p0, La1/d;->N:I

    .line 93
    .line 94
    iput v0, p0, La1/d;->O:I

    .line 95
    .line 96
    iput v0, p0, La1/d;->P:I

    .line 97
    .line 98
    const/high16 p2, 0x3f800000    # 1.0f

    .line 99
    .line 100
    iput p2, p0, La1/d;->Q:F

    .line 101
    .line 102
    iput p2, p0, La1/d;->R:F

    .line 103
    .line 104
    iput p1, p0, La1/d;->S:I

    .line 105
    .line 106
    iput p1, p0, La1/d;->T:I

    .line 107
    .line 108
    iput p1, p0, La1/d;->U:I

    .line 109
    .line 110
    iput-boolean v0, p0, La1/d;->V:Z

    .line 111
    .line 112
    iput-boolean v0, p0, La1/d;->W:Z

    .line 113
    .line 114
    iput-object v3, p0, La1/d;->X:Ljava/lang/String;

    .line 115
    .line 116
    iput v0, p0, La1/d;->Y:I

    .line 117
    .line 118
    const/4 p2, 0x1

    .line 119
    iput-boolean p2, p0, La1/d;->Z:Z

    .line 120
    .line 121
    iput-boolean p2, p0, La1/d;->a0:Z

    .line 122
    .line 123
    iput-boolean v0, p0, La1/d;->b0:Z

    .line 124
    .line 125
    iput-boolean v0, p0, La1/d;->c0:Z

    .line 126
    .line 127
    iput-boolean v0, p0, La1/d;->d0:Z

    .line 128
    .line 129
    iput p1, p0, La1/d;->e0:I

    .line 130
    .line 131
    iput p1, p0, La1/d;->f0:I

    .line 132
    .line 133
    iput p1, p0, La1/d;->g0:I

    .line 134
    .line 135
    iput p1, p0, La1/d;->h0:I

    .line 136
    .line 137
    iput v1, p0, La1/d;->i0:I

    .line 138
    .line 139
    iput v1, p0, La1/d;->j0:I

    .line 140
    .line 141
    iput v2, p0, La1/d;->k0:F

    .line 142
    .line 143
    new-instance p1, Lx0/d;

    .line 144
    .line 145
    invoke-direct {p1}, Lx0/d;-><init>()V

    .line 146
    .line 147
    .line 148
    iput-object p1, p0, La1/d;->o0:Lx0/d;

    .line 149
    .line 150
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, La1/d;->c0:Z

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    iput-boolean v1, p0, La1/d;->Z:Z

    .line 6
    .line 7
    iput-boolean v1, p0, La1/d;->a0:Z

    .line 8
    .line 9
    iget v2, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 10
    .line 11
    const/4 v3, -0x2

    .line 12
    if-ne v2, v3, :cond_19

    .line 13
    .line 14
    iget-boolean v4, p0, La1/d;->V:Z

    .line 15
    .line 16
    if-eqz v4, :cond_19

    .line 17
    .line 18
    iput-boolean v0, p0, La1/d;->Z:Z

    .line 19
    .line 20
    iget v4, p0, La1/d;->K:I

    .line 21
    .line 22
    if-nez v4, :cond_19

    .line 23
    .line 24
    iput v1, p0, La1/d;->K:I

    .line 25
    .line 26
    :cond_19
    iget v4, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 27
    .line 28
    if-ne v4, v3, :cond_29

    .line 29
    .line 30
    iget-boolean v5, p0, La1/d;->W:Z

    .line 31
    .line 32
    if-eqz v5, :cond_29

    .line 33
    .line 34
    iput-boolean v0, p0, La1/d;->a0:Z

    .line 35
    .line 36
    iget v5, p0, La1/d;->L:I

    .line 37
    .line 38
    if-nez v5, :cond_29

    .line 39
    .line 40
    iput v1, p0, La1/d;->L:I

    .line 41
    .line 42
    :cond_29
    const/4 v5, -0x1

    .line 43
    if-eqz v2, :cond_2e

    .line 44
    .line 45
    if-ne v2, v5, :cond_3a

    .line 46
    .line 47
    :cond_2e
    iput-boolean v0, p0, La1/d;->Z:Z

    .line 48
    .line 49
    if-nez v2, :cond_3a

    .line 50
    .line 51
    iget v2, p0, La1/d;->K:I

    .line 52
    .line 53
    if-ne v2, v1, :cond_3a

    .line 54
    .line 55
    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 56
    .line 57
    iput-boolean v1, p0, La1/d;->V:Z

    .line 58
    .line 59
    :cond_3a
    if-eqz v4, :cond_3e

    .line 60
    .line 61
    if-ne v4, v5, :cond_4a

    .line 62
    .line 63
    :cond_3e
    iput-boolean v0, p0, La1/d;->a0:Z

    .line 64
    .line 65
    if-nez v4, :cond_4a

    .line 66
    .line 67
    iget v0, p0, La1/d;->L:I

    .line 68
    .line 69
    if-ne v0, v1, :cond_4a

    .line 70
    .line 71
    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 72
    .line 73
    iput-boolean v1, p0, La1/d;->W:Z

    .line 74
    .line 75
    :cond_4a
    iget v0, p0, La1/d;->c:F

    .line 76
    .line 77
    const/high16 v2, -0x40800000    # -1.0f

    .line 78
    .line 79
    cmpl-float v0, v0, v2

    .line 80
    .line 81
    if-nez v0, :cond_5c

    .line 82
    .line 83
    iget v0, p0, La1/d;->a:I

    .line 84
    .line 85
    if-ne v0, v5, :cond_5c

    .line 86
    .line 87
    iget v0, p0, La1/d;->b:I

    .line 88
    .line 89
    if-eq v0, v5, :cond_5b

    .line 90
    .line 91
    goto :goto_5c

    .line 92
    :cond_5b
    return-void

    .line 93
    :cond_5c
    :goto_5c
    iput-boolean v1, p0, La1/d;->c0:Z

    .line 94
    .line 95
    iput-boolean v1, p0, La1/d;->Z:Z

    .line 96
    .line 97
    iput-boolean v1, p0, La1/d;->a0:Z

    .line 98
    .line 99
    iget-object v0, p0, La1/d;->o0:Lx0/d;

    .line 100
    .line 101
    instance-of v0, v0, Lx0/h;

    .line 102
    .line 103
    if-nez v0, :cond_6f

    .line 104
    .line 105
    new-instance v0, Lx0/h;

    .line 106
    .line 107
    invoke-direct {v0}, Lx0/h;-><init>()V

    .line 108
    .line 109
    .line 110
    iput-object v0, p0, La1/d;->o0:Lx0/d;

    .line 111
    .line 112
    :cond_6f
    iget-object v0, p0, La1/d;->o0:Lx0/d;

    .line 113
    .line 114
    check-cast v0, Lx0/h;

    .line 115
    .line 116
    iget v1, p0, La1/d;->U:I

    .line 117
    .line 118
    invoke-virtual {v0, v1}, Lx0/h;->N(I)V

    .line 119
    .line 120
    .line 121
    return-void
.end method

.method public final resolveLayoutDirection(I)V
    .registers 12

    .line 1
    iget v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 2
    .line 3
    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->resolveLayoutDirection(I)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/ViewGroup$MarginLayoutParams;->getLayoutDirection()I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x1

    .line 14
    if-ne v3, p1, :cond_11

    .line 15
    .line 16
    move p1, v3

    .line 17
    goto :goto_12

    .line 18
    :cond_11
    move p1, v2

    .line 19
    :goto_12
    const/4 v4, -0x1

    .line 20
    iput v4, p0, La1/d;->g0:I

    .line 21
    .line 22
    iput v4, p0, La1/d;->h0:I

    .line 23
    .line 24
    iput v4, p0, La1/d;->e0:I

    .line 25
    .line 26
    iput v4, p0, La1/d;->f0:I

    .line 27
    .line 28
    iget v5, p0, La1/d;->v:I

    .line 29
    .line 30
    iput v5, p0, La1/d;->i0:I

    .line 31
    .line 32
    iget v5, p0, La1/d;->x:I

    .line 33
    .line 34
    iput v5, p0, La1/d;->j0:I

    .line 35
    .line 36
    iget v5, p0, La1/d;->D:F

    .line 37
    .line 38
    iput v5, p0, La1/d;->k0:F

    .line 39
    .line 40
    iget v6, p0, La1/d;->a:I

    .line 41
    .line 42
    iput v6, p0, La1/d;->l0:I

    .line 43
    .line 44
    iget v7, p0, La1/d;->b:I

    .line 45
    .line 46
    iput v7, p0, La1/d;->m0:I

    .line 47
    .line 48
    iget v8, p0, La1/d;->c:F

    .line 49
    .line 50
    iput v8, p0, La1/d;->n0:F

    .line 51
    .line 52
    const/high16 v9, -0x80000000

    .line 53
    .line 54
    if-eqz p1, :cond_90

    .line 55
    .line 56
    iget p1, p0, La1/d;->r:I

    .line 57
    .line 58
    if-eq p1, v4, :cond_3f

    .line 59
    .line 60
    iput p1, p0, La1/d;->g0:I

    .line 61
    .line 62
    :goto_3d
    move v2, v3

    .line 63
    goto :goto_46

    .line 64
    :cond_3f
    iget p1, p0, La1/d;->s:I

    .line 65
    .line 66
    if-eq p1, v4, :cond_46

    .line 67
    .line 68
    iput p1, p0, La1/d;->h0:I

    .line 69
    .line 70
    goto :goto_3d

    .line 71
    :cond_46
    :goto_46
    iget p1, p0, La1/d;->t:I

    .line 72
    .line 73
    if-eq p1, v4, :cond_4d

    .line 74
    .line 75
    iput p1, p0, La1/d;->f0:I

    .line 76
    .line 77
    move v2, v3

    .line 78
    :cond_4d
    iget p1, p0, La1/d;->u:I

    .line 79
    .line 80
    if-eq p1, v4, :cond_54

    .line 81
    .line 82
    iput p1, p0, La1/d;->e0:I

    .line 83
    .line 84
    move v2, v3

    .line 85
    :cond_54
    iget p1, p0, La1/d;->z:I

    .line 86
    .line 87
    if-eq p1, v9, :cond_5a

    .line 88
    .line 89
    iput p1, p0, La1/d;->j0:I

    .line 90
    .line 91
    :cond_5a
    iget p1, p0, La1/d;->A:I

    .line 92
    .line 93
    if-eq p1, v9, :cond_60

    .line 94
    .line 95
    iput p1, p0, La1/d;->i0:I

    .line 96
    .line 97
    :cond_60
    const/high16 p1, 0x3f800000    # 1.0f

    .line 98
    .line 99
    if-eqz v2, :cond_68

    .line 100
    .line 101
    sub-float v2, p1, v5

    .line 102
    .line 103
    iput v2, p0, La1/d;->k0:F

    .line 104
    .line 105
    :cond_68
    iget-boolean v2, p0, La1/d;->c0:Z

    .line 106
    .line 107
    if-eqz v2, :cond_b4

    .line 108
    .line 109
    iget v2, p0, La1/d;->U:I

    .line 110
    .line 111
    if-ne v2, v3, :cond_b4

    .line 112
    .line 113
    const/high16 v2, -0x40800000    # -1.0f

    .line 114
    .line 115
    cmpl-float v3, v8, v2

    .line 116
    .line 117
    if-eqz v3, :cond_7e

    .line 118
    .line 119
    sub-float/2addr p1, v8

    .line 120
    iput p1, p0, La1/d;->n0:F

    .line 121
    .line 122
    iput v4, p0, La1/d;->l0:I

    .line 123
    .line 124
    iput v4, p0, La1/d;->m0:I

    .line 125
    .line 126
    goto :goto_b4

    .line 127
    :cond_7e
    if-eq v6, v4, :cond_87

    .line 128
    .line 129
    iput v6, p0, La1/d;->m0:I

    .line 130
    .line 131
    iput v4, p0, La1/d;->l0:I

    .line 132
    .line 133
    iput v2, p0, La1/d;->n0:F

    .line 134
    .line 135
    goto :goto_b4

    .line 136
    :cond_87
    if-eq v7, v4, :cond_b4

    .line 137
    .line 138
    iput v7, p0, La1/d;->l0:I

    .line 139
    .line 140
    iput v4, p0, La1/d;->m0:I

    .line 141
    .line 142
    iput v2, p0, La1/d;->n0:F

    .line 143
    .line 144
    goto :goto_b4

    .line 145
    :cond_90
    iget p1, p0, La1/d;->r:I

    .line 146
    .line 147
    if-eq p1, v4, :cond_96

    .line 148
    .line 149
    iput p1, p0, La1/d;->f0:I

    .line 150
    .line 151
    :cond_96
    iget p1, p0, La1/d;->s:I

    .line 152
    .line 153
    if-eq p1, v4, :cond_9c

    .line 154
    .line 155
    iput p1, p0, La1/d;->e0:I

    .line 156
    .line 157
    :cond_9c
    iget p1, p0, La1/d;->t:I

    .line 158
    .line 159
    if-eq p1, v4, :cond_a2

    .line 160
    .line 161
    iput p1, p0, La1/d;->g0:I

    .line 162
    .line 163
    :cond_a2
    iget p1, p0, La1/d;->u:I

    .line 164
    .line 165
    if-eq p1, v4, :cond_a8

    .line 166
    .line 167
    iput p1, p0, La1/d;->h0:I

    .line 168
    .line 169
    :cond_a8
    iget p1, p0, La1/d;->z:I

    .line 170
    .line 171
    if-eq p1, v9, :cond_ae

    .line 172
    .line 173
    iput p1, p0, La1/d;->i0:I

    .line 174
    .line 175
    :cond_ae
    iget p1, p0, La1/d;->A:I

    .line 176
    .line 177
    if-eq p1, v9, :cond_b4

    .line 178
    .line 179
    iput p1, p0, La1/d;->j0:I

    .line 180
    .line 181
    :cond_b4
    :goto_b4
    iget p1, p0, La1/d;->t:I

    .line 182
    .line 183
    if-ne p1, v4, :cond_fe

    .line 184
    .line 185
    iget p1, p0, La1/d;->u:I

    .line 186
    .line 187
    if-ne p1, v4, :cond_fe

    .line 188
    .line 189
    iget p1, p0, La1/d;->s:I

    .line 190
    .line 191
    if-ne p1, v4, :cond_fe

    .line 192
    .line 193
    iget p1, p0, La1/d;->r:I

    .line 194
    .line 195
    if-ne p1, v4, :cond_fe

    .line 196
    .line 197
    iget p1, p0, La1/d;->f:I

    .line 198
    .line 199
    if-eq p1, v4, :cond_d3

    .line 200
    .line 201
    iput p1, p0, La1/d;->g0:I

    .line 202
    .line 203
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 204
    .line 205
    if-gtz p1, :cond_e1

    .line 206
    .line 207
    if-lez v1, :cond_e1

    .line 208
    .line 209
    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 210
    .line 211
    goto :goto_e1

    .line 212
    :cond_d3
    iget p1, p0, La1/d;->g:I

    .line 213
    .line 214
    if-eq p1, v4, :cond_e1

    .line 215
    .line 216
    iput p1, p0, La1/d;->h0:I

    .line 217
    .line 218
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 219
    .line 220
    if-gtz p1, :cond_e1

    .line 221
    .line 222
    if-lez v1, :cond_e1

    .line 223
    .line 224
    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 225
    .line 226
    :cond_e1
    :goto_e1
    iget p1, p0, La1/d;->d:I

    .line 227
    .line 228
    if-eq p1, v4, :cond_f0

    .line 229
    .line 230
    iput p1, p0, La1/d;->e0:I

    .line 231
    .line 232
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 233
    .line 234
    if-gtz p1, :cond_fe

    .line 235
    .line 236
    if-lez v0, :cond_fe

    .line 237
    .line 238
    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 239
    .line 240
    return-void

    .line 241
    :cond_f0
    iget p1, p0, La1/d;->e:I

    .line 242
    .line 243
    if-eq p1, v4, :cond_fe

    .line 244
    .line 245
    iput p1, p0, La1/d;->f0:I

    .line 246
    .line 247
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 248
    .line 249
    if-gtz p1, :cond_fe

    .line 250
    .line 251
    if-lez v0, :cond_fe

    .line 252
    .line 253
    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 254
    .line 255
    :cond_fe
    return-void
.end method
