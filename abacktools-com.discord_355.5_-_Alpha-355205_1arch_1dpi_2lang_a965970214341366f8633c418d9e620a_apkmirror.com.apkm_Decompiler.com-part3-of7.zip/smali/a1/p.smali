###### Class a1.p (a1.p)
.class public abstract La1/p;
.super Ljava/lang/Object;
.source "SourceFile"
