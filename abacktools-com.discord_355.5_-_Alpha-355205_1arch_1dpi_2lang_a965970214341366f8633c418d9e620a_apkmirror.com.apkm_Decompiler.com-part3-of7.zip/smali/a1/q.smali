###### Class a1.q (a1.q)
.class public abstract La1/q;
.super Ljava/lang/Object;
