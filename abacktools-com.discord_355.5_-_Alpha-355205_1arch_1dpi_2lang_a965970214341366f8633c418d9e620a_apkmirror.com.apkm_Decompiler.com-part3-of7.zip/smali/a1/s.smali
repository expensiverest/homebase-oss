###### Class a1.s (a1.s)
.class public final La1/s;
.super Ljava/lang/Object;
.source "SourceFile"
