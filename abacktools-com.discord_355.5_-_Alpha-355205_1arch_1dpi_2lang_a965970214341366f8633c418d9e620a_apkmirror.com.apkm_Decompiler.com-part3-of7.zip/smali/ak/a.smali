###### Class ak.a (ak.a)
.class public final Lak/a;
.super Lsn/c;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lak/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createViewManagers(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget v2, v0, Lak/a;->a:I

    .line 6
    .line 7
    sget-object v3, Lm30/s;->d:Lm30/s;

    .line 8
    .line 9
    const/4 v4, 0x5

    .line 10
    const/4 v5, 0x4

    .line 11
    const/4 v6, 0x6

    .line 12
    const/4 v7, 0x3

    .line 13
    const/4 v8, 0x0

    .line 14
    const/4 v9, 0x2

    .line 15
    const/4 v10, 0x1

    .line 16
    const-string v11, "reactContext"

    .line 17
    .line 18
    packed-switch v2, :pswitch_data_1fe

    .line 19
    .line 20
    .line 21
    :pswitch_14
    invoke-super/range {p0 .. p1}, Lsn/c;->createViewManagers(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    return-object v1

    .line 26
    :pswitch_19
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    new-instance v1, Lcom/th3rdwave/safeareacontext/SafeAreaProviderManager;

    .line 30
    .line 31
    invoke-direct {v1}, Lcom/th3rdwave/safeareacontext/SafeAreaProviderManager;-><init>()V

    .line 32
    .line 33
    .line 34
    new-instance v2, Lcom/th3rdwave/safeareacontext/SafeAreaViewManager;

    .line 35
    .line 36
    invoke-direct {v2}, Lcom/th3rdwave/safeareacontext/SafeAreaViewManager;-><init>()V

    .line 37
    .line 38
    .line 39
    new-array v3, v9, [Lcom/facebook/react/uimanager/ViewManager;

    .line 40
    .line 41
    aput-object v1, v3, v8

    .line 42
    .line 43
    aput-object v2, v3, v10

    .line 44
    .line 45
    invoke-static {v3}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    return-object v1

    .line 50
    :pswitch_31
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    new-instance v1, Lcom/discord/zoom_layout/ZoomLayoutViewManager;

    .line 54
    .line 55
    invoke-direct {v1}, Lcom/discord/zoom_layout/ZoomLayoutViewManager;-><init>()V

    .line 56
    .line 57
    .line 58
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    return-object v1

    .line 63
    :pswitch_3e
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    new-instance v1, Lcom/reactnativekeyboardcontroller/KeyboardControllerViewManager;

    .line 67
    .line 68
    invoke-direct {v1}, Lcom/reactnativekeyboardcontroller/KeyboardControllerViewManager;-><init>()V

    .line 69
    .line 70
    .line 71
    new-instance v2, Lcom/reactnativekeyboardcontroller/KeyboardGestureAreaViewManager;

    .line 72
    .line 73
    invoke-direct {v2}, Lcom/reactnativekeyboardcontroller/KeyboardGestureAreaViewManager;-><init>()V

    .line 74
    .line 75
    .line 76
    new-instance v3, Lcom/reactnativekeyboardcontroller/OverKeyboardViewManager;

    .line 77
    .line 78
    invoke-direct {v3}, Lcom/reactnativekeyboardcontroller/OverKeyboardViewManager;-><init>()V

    .line 79
    .line 80
    .line 81
    new-instance v11, Lcom/reactnativekeyboardcontroller/KeyboardBackgroundViewManager;

    .line 82
    .line 83
    invoke-direct {v11}, Lcom/reactnativekeyboardcontroller/KeyboardBackgroundViewManager;-><init>()V

    .line 84
    .line 85
    .line 86
    new-instance v12, Ljava/com/reactnativekeyboardcontroller/ClippingScrollViewDecoratorViewManager;

    .line 87
    .line 88
    invoke-direct {v12}, Ljava/com/reactnativekeyboardcontroller/ClippingScrollViewDecoratorViewManager;-><init>()V

    .line 89
    .line 90
    .line 91
    new-instance v13, Lcom/reactnativekeyboardcontroller/KeyboardToolbarGroupViewManager;

    .line 92
    .line 93
    invoke-direct {v13}, Lcom/reactnativekeyboardcontroller/KeyboardToolbarGroupViewManager;-><init>()V

    .line 94
    .line 95
    .line 96
    new-array v6, v6, [Lcom/facebook/react/uimanager/ViewManager;

    .line 97
    .line 98
    aput-object v1, v6, v8

    .line 99
    .line 100
    aput-object v2, v6, v10

    .line 101
    .line 102
    aput-object v3, v6, v9

    .line 103
    .line 104
    aput-object v11, v6, v7

    .line 105
    .line 106
    aput-object v12, v6, v5

    .line 107
    .line 108
    aput-object v13, v6, v4

    .line 109
    .line 110
    invoke-static {v6}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    return-object v1

    .line 115
    :pswitch_72
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    new-instance v1, Lcom/discord/emoji_picker/react/EmojiPickerViewManager;

    .line 119
    .line 120
    invoke-direct {v1}, Lcom/discord/emoji_picker/react/EmojiPickerViewManager;-><init>()V

    .line 121
    .line 122
    .line 123
    new-instance v2, Lcom/discord/emoji_picker/react/EmojiPickerRowViewManager;

    .line 124
    .line 125
    invoke-direct {v2}, Lcom/discord/emoji_picker/react/EmojiPickerRowViewManager;-><init>()V

    .line 126
    .line 127
    .line 128
    new-array v3, v9, [Lcom/facebook/react/uimanager/ViewManager;

    .line 129
    .line 130
    aput-object v1, v3, v8

    .line 131
    .line 132
    aput-object v2, v3, v10

    .line 133
    .line 134
    invoke-static {v3}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    return-object v1

    .line 139
    :pswitch_8a
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    new-instance v2, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;

    .line 143
    .line 144
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 145
    .line 146
    .line 147
    sget-object v3, Lx20/a;->c:Lx20/a;

    .line 148
    .line 149
    iput-object v3, v2, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->x:Lx20/a;

    .line 150
    .line 151
    new-instance v3, Ljava/lang/ref/WeakReference;

    .line 152
    .line 153
    invoke-direct {v3, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    iput-object v3, v2, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->y:Ljava/lang/ref/WeakReference;

    .line 157
    .line 158
    :try_start_9d
    const-string v3, "react_codegen_rnscreens"

    .line 159
    .line 160
    invoke-static {v3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_a2
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_9d .. :try_end_a2} :catch_a3

    .line 161
    .line 162
    .line 163
    goto :goto_aa

    .line 164
    :catch_a3
    const-string v3, "ScreenDummyLayoutHelper"

    .line 165
    .line 166
    const-string v11, "[RNScreens] Failed to load react_codegen_rnscreens library."

    .line 167
    .line 168
    invoke-static {v3, v11}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 169
    .line 170
    .line 171
    :goto_aa
    new-instance v3, Ljava/lang/ref/WeakReference;

    .line 172
    .line 173
    invoke-direct {v3, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    sput-object v3, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->M:Ljava/lang/ref/WeakReference;

    .line 177
    .line 178
    invoke-virtual {v2, v1}, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->b(Lcom/facebook/react/bridge/ReactApplicationContext;)Z

    .line 179
    .line 180
    .line 181
    invoke-virtual {v1, v2}, Lcom/facebook/react/bridge/ReactContext;->addLifecycleEventListener(Lcom/facebook/react/bridge/LifecycleEventListener;)V

    .line 182
    .line 183
    .line 184
    sget-object v2, Lt10/f;->d:Lt10/f;

    .line 185
    .line 186
    sget-boolean v3, Lt10/f;->w:Z

    .line 187
    .line 188
    if-eqz v3, :cond_c4

    .line 189
    .line 190
    const-string v3, "[RNScreens]"

    .line 191
    .line 192
    const-string v11, "InsetObserverProxy registers on new context while it has not been invalidated on the old one. Please report this as issue at https://github.com/software-mansion/react-native-screens/issues"

    .line 193
    .line 194
    invoke-static {v3, v11}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 195
    .line 196
    .line 197
    :cond_c4
    sput-boolean v10, Lt10/f;->w:Z

    .line 198
    .line 199
    invoke-virtual {v1, v2}, Lcom/facebook/react/bridge/ReactContext;->addLifecycleEventListener(Lcom/facebook/react/bridge/LifecycleEventListener;)V

    .line 200
    .line 201
    .line 202
    new-instance v1, Lcom/swmansion/rnscreens/ScreenContainerViewManager;

    .line 203
    .line 204
    invoke-direct {v1}, Lcom/swmansion/rnscreens/ScreenContainerViewManager;-><init>()V

    .line 205
    .line 206
    .line 207
    new-instance v2, Lcom/swmansion/rnscreens/ScreenViewManager;

    .line 208
    .line 209
    invoke-direct {v2}, Lcom/swmansion/rnscreens/ScreenViewManager;-><init>()V

    .line 210
    .line 211
    .line 212
    new-instance v3, Lcom/swmansion/rnscreens/ModalScreenViewManager;

    .line 213
    .line 214
    invoke-direct {v3}, Lcom/swmansion/rnscreens/ModalScreenViewManager;-><init>()V

    .line 215
    .line 216
    .line 217
    new-instance v11, Lcom/swmansion/rnscreens/ScreenStackViewManager;

    .line 218
    .line 219
    invoke-direct {v11}, Lcom/swmansion/rnscreens/ScreenStackViewManager;-><init>()V

    .line 220
    .line 221
    .line 222
    new-instance v12, Lcom/swmansion/rnscreens/ScreenStackHeaderConfigViewManager;

    .line 223
    .line 224
    invoke-direct {v12}, Lcom/swmansion/rnscreens/ScreenStackHeaderConfigViewManager;-><init>()V

    .line 225
    .line 226
    .line 227
    new-instance v13, Lcom/swmansion/rnscreens/ScreenStackHeaderSubviewManager;

    .line 228
    .line 229
    invoke-direct {v13}, Lcom/swmansion/rnscreens/ScreenStackHeaderSubviewManager;-><init>()V

    .line 230
    .line 231
    .line 232
    new-instance v14, Lcom/swmansion/rnscreens/SearchBarManager;

    .line 233
    .line 234
    invoke-direct {v14}, Lcom/swmansion/rnscreens/SearchBarManager;-><init>()V

    .line 235
    .line 236
    .line 237
    new-instance v15, Lcom/swmansion/rnscreens/ScreenFooterManager;

    .line 238
    .line 239
    invoke-direct {v15}, Lcom/swmansion/rnscreens/ScreenFooterManager;-><init>()V

    .line 240
    .line 241
    .line 242
    new-instance v16, Lcom/swmansion/rnscreens/ScreenContentWrapperManager;

    .line 243
    .line 244
    invoke-direct/range {v16 .. v16}, Lcom/swmansion/rnscreens/ScreenContentWrapperManager;-><init>()V

    .line 245
    .line 246
    .line 247
    new-instance v17, Lcom/swmansion/rnscreens/gamma/tabs/host/TabsHostViewManager;

    .line 248
    .line 249
    invoke-direct/range {v17 .. v17}, Lcom/swmansion/rnscreens/gamma/tabs/host/TabsHostViewManager;-><init>()V

    .line 250
    .line 251
    .line 252
    new-instance v18, Lcom/swmansion/rnscreens/gamma/tabs/screen/TabsScreenViewManager;

    .line 253
    .line 254
    invoke-direct/range {v18 .. v18}, Lcom/swmansion/rnscreens/gamma/tabs/screen/TabsScreenViewManager;-><init>()V

    .line 255
    .line 256
    .line 257
    new-instance v19, Lcom/swmansion/rnscreens/safearea/SafeAreaViewManager;

    .line 258
    .line 259
    invoke-direct/range {v19 .. v19}, Lcom/swmansion/rnscreens/safearea/SafeAreaViewManager;-><init>()V

    .line 260
    .line 261
    .line 262
    new-instance v20, Lcom/swmansion/rnscreens/gamma/stack/host/StackHostViewManager;

    .line 263
    .line 264
    invoke-direct/range {v20 .. v20}, Lcom/swmansion/rnscreens/gamma/stack/host/StackHostViewManager;-><init>()V

    .line 265
    .line 266
    .line 267
    new-instance v21, Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenViewManager;

    .line 268
    .line 269
    invoke-direct/range {v21 .. v21}, Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenViewManager;-><init>()V

    .line 270
    .line 271
    .line 272
    new-instance v22, Lcom/swmansion/rnscreens/gamma/scrollviewmarker/ScrollViewMarkerViewManager;

    .line 273
    .line 274
    invoke-direct/range {v22 .. v22}, Lcom/swmansion/rnscreens/gamma/scrollviewmarker/ScrollViewMarkerViewManager;-><init>()V

    .line 275
    .line 276
    .line 277
    new-instance v23, Lcom/swmansion/rnscreens/gamma/stack/header/config/StackHeaderConfigViewManager;

    .line 278
    .line 279
    invoke-direct/range {v23 .. v23}, Lcom/swmansion/rnscreens/gamma/stack/header/config/StackHeaderConfigViewManager;-><init>()V

    .line 280
    .line 281
    .line 282
    new-instance v24, Lcom/swmansion/rnscreens/gamma/stack/header/subview/StackHeaderSubviewViewManager;

    .line 283
    .line 284
    invoke-direct/range {v24 .. v24}, Lcom/swmansion/rnscreens/gamma/stack/header/subview/StackHeaderSubviewViewManager;-><init>()V

    .line 285
    .line 286
    .line 287
    new-instance v25, Lcom/swmansion/rnscreens/gamma/modals/formsheet/FormSheetHostViewManager;

    .line 288
    .line 289
    invoke-direct/range {v25 .. v25}, Lcom/swmansion/rnscreens/gamma/modals/formsheet/FormSheetHostViewManager;-><init>()V

    .line 290
    .line 291
    .line 292
    new-instance v26, Lcom/swmansion/rnscreens/gamma/modals/formsheet/FormSheetContentWrapperViewManager;

    .line 293
    .line 294
    invoke-direct/range {v26 .. v26}, Lcom/swmansion/rnscreens/gamma/modals/formsheet/FormSheetContentWrapperViewManager;-><init>()V

    .line 295
    .line 296
    .line 297
    move/from16 v27, v4

    .line 298
    .line 299
    const/16 v4, 0x13

    .line 300
    .line 301
    new-array v4, v4, [Lcom/facebook/react/uimanager/ViewManager;

    .line 302
    .line 303
    aput-object v1, v4, v8

    .line 304
    .line 305
    aput-object v2, v4, v10

    .line 306
    .line 307
    aput-object v3, v4, v9

    .line 308
    .line 309
    aput-object v11, v4, v7

    .line 310
    .line 311
    aput-object v12, v4, v5

    .line 312
    .line 313
    aput-object v13, v4, v27

    .line 314
    .line 315
    aput-object v14, v4, v6

    .line 316
    .line 317
    const/4 v1, 0x7

    .line 318
    aput-object v15, v4, v1

    .line 319
    .line 320
    const/16 v1, 0x8

    .line 321
    .line 322
    aput-object v16, v4, v1

    .line 323
    .line 324
    const/16 v1, 0x9

    .line 325
    .line 326
    aput-object v17, v4, v1

    .line 327
    .line 328
    const/16 v1, 0xa

    .line 329
    .line 330
    aput-object v18, v4, v1

    .line 331
    .line 332
    const/16 v1, 0xb

    .line 333
    .line 334
    aput-object v19, v4, v1

    .line 335
    .line 336
    const/16 v1, 0xc

    .line 337
    .line 338
    aput-object v20, v4, v1

    .line 339
    .line 340
    const/16 v1, 0xd

    .line 341
    .line 342
    aput-object v21, v4, v1

    .line 343
    .line 344
    const/16 v1, 0xe

    .line 345
    .line 346
    aput-object v22, v4, v1

    .line 347
    .line 348
    const/16 v1, 0xf

    .line 349
    .line 350
    aput-object v23, v4, v1

    .line 351
    .line 352
    const/16 v1, 0x10

    .line 353
    .line 354
    aput-object v24, v4, v1

    .line 355
    .line 356
    const/16 v1, 0x11

    .line 357
    .line 358
    aput-object v25, v4, v1

    .line 359
    .line 360
    const/16 v1, 0x12

    .line 361
    .line 362
    aput-object v26, v4, v1

    .line 363
    .line 364
    invoke-static {v4}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    return-object v1

    .line 369
    :pswitch_170
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 370
    .line 371
    .line 372
    new-instance v1, Lcom/discord/tti_measurement_view/TTIMeasurementViewManager;

    .line 373
    .line 374
    invoke-direct {v1}, Lcom/discord/tti_measurement_view/TTIMeasurementViewManager;-><init>()V

    .line 375
    .line 376
    .line 377
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    return-object v1

    .line 382
    :pswitch_17d
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 383
    .line 384
    .line 385
    return-object v3

    .line 386
    :pswitch_181
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 387
    .line 388
    .line 389
    new-instance v1, Lcom/discord/thumbhash/ImageWithThumbhashPlaceholderViewManager;

    .line 390
    .line 391
    invoke-direct {v1}, Lcom/discord/thumbhash/ImageWithThumbhashPlaceholderViewManager;-><init>()V

    .line 392
    .line 393
    .line 394
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 395
    .line 396
    .line 397
    move-result-object v1

    .line 398
    return-object v1

    .line 399
    :pswitch_18e
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 400
    .line 401
    .line 402
    new-instance v1, Lcom/discord/react_gesture_handler/accessibility_focus/AccessibilityFocusViewManager;

    .line 403
    .line 404
    invoke-direct {v1}, Lcom/discord/react_gesture_handler/accessibility_focus/AccessibilityFocusViewManager;-><init>()V

    .line 405
    .line 406
    .line 407
    new-instance v2, Lcom/discord/react_gesture_handler/passthrough_touch/PassthroughTouchViewManager;

    .line 408
    .line 409
    invoke-direct {v2}, Lcom/discord/react_gesture_handler/passthrough_touch/PassthroughTouchViewManager;-><init>()V

    .line 410
    .line 411
    .line 412
    new-instance v3, Lcom/discord/react_gesture_handler/DiscordGestureHandlerRootViewManager;

    .line 413
    .line 414
    invoke-direct {v3}, Lcom/discord/react_gesture_handler/DiscordGestureHandlerRootViewManager;-><init>()V

    .line 415
    .line 416
    .line 417
    new-array v4, v7, [Lcom/facebook/react/uimanager/ViewManager;

    .line 418
    .line 419
    aput-object v1, v4, v8

    .line 420
    .line 421
    aput-object v2, v4, v10

    .line 422
    .line 423
    aput-object v3, v4, v9

    .line 424
    .line 425
    invoke-static {v4}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 426
    .line 427
    .line 428
    move-result-object v1

    .line 429
    return-object v1

    .line 430
    :pswitch_1ad
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 431
    .line 432
    .line 433
    new-instance v1, Lcom/mdjstack/plaintext/PlainTextViewManager;

    .line 434
    .line 435
    invoke-direct {v1}, Lcom/mdjstack/plaintext/PlainTextViewManager;-><init>()V

    .line 436
    .line 437
    .line 438
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 439
    .line 440
    .line 441
    move-result-object v1

    .line 442
    return-object v1

    .line 443
    :pswitch_1ba
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    new-instance v1, Lcom/discord/blur/BlurViewManager;

    .line 447
    .line 448
    invoke-direct {v1}, Lcom/discord/blur/BlurViewManager;-><init>()V

    .line 449
    .line 450
    .line 451
    new-instance v2, Lcom/discord/blur/BlurViewTargetManager;

    .line 452
    .line 453
    invoke-direct {v2}, Lcom/discord/blur/BlurViewTargetManager;-><init>()V

    .line 454
    .line 455
    .line 456
    new-array v3, v9, [Lcom/facebook/react/uimanager/ViewManager;

    .line 457
    .line 458
    aput-object v1, v3, v8

    .line 459
    .line 460
    aput-object v2, v3, v10

    .line 461
    .line 462
    invoke-static {v3}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 463
    .line 464
    .line 465
    move-result-object v1

    .line 466
    return-object v1

    .line 467
    :pswitch_1d2
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 468
    .line 469
    .line 470
    return-object v3

    .line 471
    :pswitch_1d6
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 472
    .line 473
    .line 474
    new-instance v1, Lcom/discord/sticker_picker/react/StickerPickerRowViewManager;

    .line 475
    .line 476
    invoke-direct {v1}, Lcom/discord/sticker_picker/react/StickerPickerRowViewManager;-><init>()V

    .line 477
    .line 478
    .line 479
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 480
    .line 481
    .line 482
    move-result-object v1

    .line 483
    return-object v1

    .line 484
    :pswitch_1e3
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 485
    .line 486
    .line 487
    new-instance v1, Lcom/discord/fastest_list/react/FastestListViewManager;

    .line 488
    .line 489
    invoke-direct {v1}, Lcom/discord/fastest_list/react/FastestListViewManager;-><init>()V

    .line 490
    .line 491
    .line 492
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 493
    .line 494
    .line 495
    move-result-object v1

    .line 496
    return-object v1

    .line 497
    :pswitch_1f0
    invoke-static {v1, v11}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 498
    .line 499
    .line 500
    new-instance v1, Lcom/discord/sticker/react/StickerViewManagerLottie;

    .line 501
    .line 502
    invoke-direct {v1}, Lcom/discord/sticker/react/StickerViewManagerLottie;-><init>()V

    .line 503
    .line 504
    .line 505
    invoke-static {v1}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 506
    .line 507
    .line 508
    move-result-object v1

    .line 509
    return-object v1

    .line 510
    nop

    .line 511
    :pswitch_data_1fe
    .packed-switch 0x0
        :pswitch_1f0
        :pswitch_14
        :pswitch_1e3
        :pswitch_14
        :pswitch_1d6
        :pswitch_14
        :pswitch_1d2
        :pswitch_14
        :pswitch_1ba
        :pswitch_14
        :pswitch_1ad
        :pswitch_18e
        :pswitch_181
        :pswitch_17d
        :pswitch_170
        :pswitch_8a
        :pswitch_72
        :pswitch_14
        :pswitch_3e
        :pswitch_14
        :pswitch_14
        :pswitch_31
        :pswitch_19
    .end packed-switch
.end method

.method public final getModule(Ljava/lang/String;Lcom/facebook/react/bridge/ReactApplicationContext;)Lcom/facebook/react/bridge/NativeModule;
    .registers 4

    .line 1
    iget v0, p0, Lak/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_278

    .line 4
    .line 5
    .line 6
    const-string v0, "name"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "reactContext"

    .line 12
    .line 13
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "RNCSafeAreaContext"

    .line 17
    .line 18
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    if-eqz p1, :cond_1d

    .line 23
    .line 24
    new-instance p1, Lcom/th3rdwave/safeareacontext/SafeAreaContextModule;

    .line 25
    .line 26
    invoke-direct {p1, p2}, Lcom/th3rdwave/safeareacontext/SafeAreaContextModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 27
    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    const/4 p1, 0x0

    .line 31
    :goto_1e
    return-object p1

    .line 32
    :pswitch_1f
    const-string v0, "name"

    .line 33
    .line 34
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string p1, "reactContext"

    .line 38
    .line 39
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    :goto_29
    const/4 p1, 0x0

    .line 43
    return-object p1

    .line 44
    :pswitch_2b
    const-string v0, "name"

    .line 45
    .line 46
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const-string v0, "reactContext"

    .line 50
    .line 51
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const-string v0, "NativeFastConnectModule"

    .line 55
    .line 56
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    if-eqz p1, :cond_43

    .line 61
    .line 62
    new-instance p1, Lcom/discord/fast_connect/FastConnectModule;

    .line 63
    .line 64
    invoke-direct {p1, p2}, Lcom/discord/fast_connect/FastConnectModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 65
    .line 66
    .line 67
    goto :goto_44

    .line 68
    :cond_43
    const/4 p1, 0x0

    .line 69
    :goto_44
    return-object p1

    .line 70
    :pswitch_45
    const-string v0, "name"

    .line 71
    .line 72
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    const-string v0, "reactContext"

    .line 76
    .line 77
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    const-string v0, "NativeScreenWakeLockModule"

    .line 81
    .line 82
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_5d

    .line 87
    .line 88
    new-instance p1, Lcom/discord/wakelock/ScreenWakeLockModule;

    .line 89
    .line 90
    invoke-direct {p1, p2}, Lcom/discord/wakelock/ScreenWakeLockModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 91
    .line 92
    .line 93
    goto :goto_6c

    .line 94
    :cond_5d
    const-string v0, "NativeProximitySensorManagerModule"

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-eqz p1, :cond_6b

    .line 101
    .line 102
    new-instance p1, Lcom/discord/wakelock/ProximitySensorManagerModule;

    .line 103
    .line 104
    invoke-direct {p1, p2}, Lcom/discord/wakelock/ProximitySensorManagerModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 105
    .line 106
    .line 107
    goto :goto_6c

    .line 108
    :cond_6b
    const/4 p1, 0x0

    .line 109
    :goto_6c
    return-object p1

    .line 110
    :pswitch_6d
    const-string v0, "name"

    .line 111
    .line 112
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    const-string v0, "reactContext"

    .line 116
    .line 117
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    const-string v0, "KeyboardController"

    .line 121
    .line 122
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_85

    .line 127
    .line 128
    new-instance p1, Lcom/reactnativekeyboardcontroller/KeyboardControllerModule;

    .line 129
    .line 130
    invoke-direct {p1, p2}, Lcom/reactnativekeyboardcontroller/KeyboardControllerModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 131
    .line 132
    .line 133
    goto :goto_94

    .line 134
    :cond_85
    const-string v0, "StatusBarManager"

    .line 135
    .line 136
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result p1

    .line 140
    if-eqz p1, :cond_93

    .line 141
    .line 142
    new-instance p1, Lcom/reactnativekeyboardcontroller/StatusBarManagerCompatModule;

    .line 143
    .line 144
    invoke-direct {p1, p2}, Lcom/reactnativekeyboardcontroller/StatusBarManagerCompatModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 145
    .line 146
    .line 147
    goto :goto_94

    .line 148
    :cond_93
    const/4 p1, 0x0

    .line 149
    :goto_94
    return-object p1

    .line 150
    :pswitch_95
    const-string v0, "name"

    .line 151
    .line 152
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    const-string v0, "reactContext"

    .line 156
    .line 157
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    const-string v0, "RNDocumentPicker"

    .line 161
    .line 162
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result p1

    .line 166
    if-eqz p1, :cond_ad

    .line 167
    .line 168
    new-instance p1, Lcom/reactnativedocumentpicker/RNDocumentPickerModule;

    .line 169
    .line 170
    invoke-direct {p1, p2}, Lcom/reactnativedocumentpicker/RNDocumentPickerModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 171
    .line 172
    .line 173
    goto :goto_ae

    .line 174
    :cond_ad
    const/4 p1, 0x0

    .line 175
    :goto_ae
    return-object p1

    .line 176
    :pswitch_af
    const-string v0, "name"

    .line 177
    .line 178
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    const-string p1, "reactContext"

    .line 182
    .line 183
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    goto/16 :goto_29

    .line 187
    .line 188
    :pswitch_bb
    const-string v0, "s"

    .line 189
    .line 190
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    const-string v0, "reactApplicationContext"

    .line 194
    .line 195
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    const-string v0, "RNSModule"

    .line 199
    .line 200
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    move-result p1

    .line 204
    if-eqz p1, :cond_d3

    .line 205
    .line 206
    new-instance p1, Lcom/swmansion/rnscreens/ScreensModule;

    .line 207
    .line 208
    invoke-direct {p1, p2}, Lcom/swmansion/rnscreens/ScreensModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 209
    .line 210
    .line 211
    goto :goto_d4

    .line 212
    :cond_d3
    const/4 p1, 0x0

    .line 213
    :goto_d4
    return-object p1

    .line 214
    :pswitch_d5
    const-string v0, "name"

    .line 215
    .line 216
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    const-string p1, "reactContext"

    .line 220
    .line 221
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    goto/16 :goto_29

    .line 225
    .line 226
    :pswitch_e1
    const-string v0, "name"

    .line 227
    .line 228
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    const-string v0, "reactContext"

    .line 232
    .line 233
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 237
    .line 238
    .line 239
    move-result v0

    .line 240
    sparse-switch v0, :sswitch_data_2a8

    .line 241
    .line 242
    .line 243
    goto/16 :goto_156

    .line 244
    .line 245
    :sswitch_f4
    const-string v0, "NativeDeviceThermalStateModule"

    .line 246
    .line 247
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result p1

    .line 251
    if-nez p1, :cond_fd

    .line 252
    .line 253
    goto :goto_156

    .line 254
    :cond_fd
    new-instance p1, Lcom/discord/device/DeviceThermalStateModule;

    .line 255
    .line 256
    invoke-direct {p1, p2}, Lcom/discord/device/DeviceThermalStateModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 257
    .line 258
    .line 259
    goto :goto_15d

    .line 260
    :sswitch_103
    const-string v0, "NativeMetaQuestModule"

    .line 261
    .line 262
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-result p1

    .line 266
    if-nez p1, :cond_10c

    .line 267
    .line 268
    goto :goto_156

    .line 269
    :cond_10c
    new-instance p1, Lcom/discord/device/MetaQuestModule;

    .line 270
    .line 271
    invoke-direct {p1, p2}, Lcom/discord/device/MetaQuestModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 272
    .line 273
    .line 274
    goto :goto_15d

    .line 275
    :sswitch_112
    const-string v0, "NativeDeviceSilentModeModule"

    .line 276
    .line 277
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-result p1

    .line 281
    if-nez p1, :cond_11b

    .line 282
    .line 283
    goto :goto_156

    .line 284
    :cond_11b
    new-instance p1, Lcom/discord/device/DeviceSilentModeModule;

    .line 285
    .line 286
    invoke-direct {p1, p2}, Lcom/discord/device/DeviceSilentModeModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 287
    .line 288
    .line 289
    goto :goto_15d

    .line 290
    :sswitch_121
    const-string v0, "NativeDeviceAccessibilityModule"

    .line 291
    .line 292
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    move-result p1

    .line 296
    if-nez p1, :cond_12a

    .line 297
    .line 298
    goto :goto_156

    .line 299
    :cond_12a
    new-instance p1, Lcom/discord/device/DeviceAccessibilityModule;

    .line 300
    .line 301
    invoke-direct {p1, p2}, Lcom/discord/device/DeviceAccessibilityModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 302
    .line 303
    .line 304
    goto :goto_15d

    .line 305
    :sswitch_130
    const-string v0, "NativeDeviceLocaleModule"

    .line 306
    .line 307
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 308
    .line 309
    .line 310
    move-result p1

    .line 311
    if-nez p1, :cond_139

    .line 312
    .line 313
    goto :goto_156

    .line 314
    :cond_139
    new-instance p1, Lcom/discord/device/DeviceLocaleModule;

    .line 315
    .line 316
    invoke-direct {p1, p2}, Lcom/discord/device/DeviceLocaleModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 317
    .line 318
    .line 319
    goto :goto_15d

    .line 320
    :sswitch_13f
    const-string v0, "NativeDeviceSettingsModule"

    .line 321
    .line 322
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 323
    .line 324
    .line 325
    move-result p1

    .line 326
    if-nez p1, :cond_148

    .line 327
    .line 328
    goto :goto_156

    .line 329
    :cond_148
    new-instance p1, Lcom/discord/device/DeviceSettingsModule;

    .line 330
    .line 331
    invoke-direct {p1, p2}, Lcom/discord/device/DeviceSettingsModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 332
    .line 333
    .line 334
    goto :goto_15d

    .line 335
    :sswitch_14e
    const-string v0, "NativeDeviceModule"

    .line 336
    .line 337
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 338
    .line 339
    .line 340
    move-result p1

    .line 341
    if-nez p1, :cond_158

    .line 342
    .line 343
    :goto_156
    const/4 p1, 0x0

    .line 344
    goto :goto_15d

    .line 345
    :cond_158
    new-instance p1, Lcom/discord/device/DeviceModule;

    .line 346
    .line 347
    invoke-direct {p1, p2}, Lcom/discord/device/DeviceModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 348
    .line 349
    .line 350
    :goto_15d
    return-object p1

    .line 351
    :pswitch_15e
    const-string v0, "name"

    .line 352
    .line 353
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    const-string p1, "reactContext"

    .line 357
    .line 358
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    goto/16 :goto_29

    .line 362
    .line 363
    :pswitch_16a
    const-string v0, "name"

    .line 364
    .line 365
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 366
    .line 367
    .line 368
    const-string p1, "reactContext"

    .line 369
    .line 370
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 371
    .line 372
    .line 373
    goto/16 :goto_29

    .line 374
    .line 375
    :pswitch_176
    const-string v0, "name"

    .line 376
    .line 377
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    const-string p1, "reactContext"

    .line 381
    .line 382
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 383
    .line 384
    .line 385
    goto/16 :goto_29

    .line 386
    .line 387
    :pswitch_182
    const-string v0, "name"

    .line 388
    .line 389
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 390
    .line 391
    .line 392
    const-string v0, "reactContext"

    .line 393
    .line 394
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 395
    .line 396
    .line 397
    const-string v0, "NativeSafeAreaInsetsModule"

    .line 398
    .line 399
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 400
    .line 401
    .line 402
    move-result p1

    .line 403
    if-eqz p1, :cond_19a

    .line 404
    .line 405
    new-instance p1, Lcom/discord/safearea/SafeAreaInsetsModule;

    .line 406
    .line 407
    invoke-direct {p1, p2}, Lcom/discord/safearea/SafeAreaInsetsModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 408
    .line 409
    .line 410
    goto :goto_19b

    .line 411
    :cond_19a
    const/4 p1, 0x0

    .line 412
    :goto_19b
    return-object p1

    .line 413
    :pswitch_19c
    const-string v0, "name"

    .line 414
    .line 415
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 416
    .line 417
    .line 418
    const-string p1, "reactContext"

    .line 419
    .line 420
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 421
    .line 422
    .line 423
    goto/16 :goto_29

    .line 424
    .line 425
    :pswitch_1a8
    const-string v0, "name"

    .line 426
    .line 427
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 428
    .line 429
    .line 430
    const-string v0, "reactContext"

    .line 431
    .line 432
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    const-string v0, "NativeFontModule"

    .line 436
    .line 437
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 438
    .line 439
    .line 440
    move-result p1

    .line 441
    if-eqz p1, :cond_1c0

    .line 442
    .line 443
    new-instance p1, Lcom/discord/react/FontModule;

    .line 444
    .line 445
    invoke-direct {p1, p2}, Lcom/discord/react/FontModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 446
    .line 447
    .line 448
    goto :goto_1c1

    .line 449
    :cond_1c0
    const/4 p1, 0x0

    .line 450
    :goto_1c1
    return-object p1

    .line 451
    :pswitch_1c2
    const-string v0, "name"

    .line 452
    .line 453
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 454
    .line 455
    .line 456
    const-string v0, "reactContext"

    .line 457
    .line 458
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 459
    .line 460
    .line 461
    const-string v0, "NativeClientInfoModule"

    .line 462
    .line 463
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 464
    .line 465
    .line 466
    move-result v0

    .line 467
    if-eqz v0, :cond_1da

    .line 468
    .line 469
    new-instance p1, Lcom/discord/client_info/react/ClientInfoModule;

    .line 470
    .line 471
    invoke-direct {p1, p2}, Lcom/discord/client_info/react/ClientInfoModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 472
    .line 473
    .line 474
    goto :goto_1e9

    .line 475
    :cond_1da
    const-string v0, "NativeInstallTimeModule"

    .line 476
    .line 477
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 478
    .line 479
    .line 480
    move-result p1

    .line 481
    if-eqz p1, :cond_1e8

    .line 482
    .line 483
    new-instance p1, Lcom/discord/client_info/react/InstallTimeModule;

    .line 484
    .line 485
    invoke-direct {p1, p2}, Lcom/discord/client_info/react/InstallTimeModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 486
    .line 487
    .line 488
    goto :goto_1e9

    .line 489
    :cond_1e8
    const/4 p1, 0x0

    .line 490
    :goto_1e9
    return-object p1

    .line 491
    :pswitch_1ea
    const-string v0, "name"

    .line 492
    .line 493
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 494
    .line 495
    .line 496
    const-string v0, "reactContext"

    .line 497
    .line 498
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 499
    .line 500
    .line 501
    const-string v0, "NitroModules"

    .line 502
    .line 503
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 504
    .line 505
    .line 506
    move-result p1

    .line 507
    if-eqz p1, :cond_202

    .line 508
    .line 509
    new-instance p1, Lcom/margelo/nitro/NitroModules;

    .line 510
    .line 511
    invoke-direct {p1, p2}, Lcom/margelo/nitro/NitroModules;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 512
    .line 513
    .line 514
    goto :goto_203

    .line 515
    :cond_202
    const/4 p1, 0x0

    .line 516
    :goto_203
    return-object p1

    .line 517
    :pswitch_204
    const-string v0, "name"

    .line 518
    .line 519
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 520
    .line 521
    .line 522
    const-string p1, "reactContext"

    .line 523
    .line 524
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 525
    .line 526
    .line 527
    goto/16 :goto_29

    .line 528
    .line 529
    :pswitch_210
    const-string v0, "name"

    .line 530
    .line 531
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 532
    .line 533
    .line 534
    const-string v0, "reactContext"

    .line 535
    .line 536
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 537
    .line 538
    .line 539
    const-string v0, "NativeIntentsModule"

    .line 540
    .line 541
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 542
    .line 543
    .line 544
    move-result v0

    .line 545
    if-eqz v0, :cond_228

    .line 546
    .line 547
    new-instance p1, Lcom/discord/intents/IntentsModule;

    .line 548
    .line 549
    invoke-direct {p1, p2}, Lcom/discord/intents/IntentsModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 550
    .line 551
    .line 552
    goto :goto_237

    .line 553
    :cond_228
    const-string v0, "NativeLinkingModule"

    .line 554
    .line 555
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 556
    .line 557
    .line 558
    move-result p1

    .line 559
    if-eqz p1, :cond_236

    .line 560
    .line 561
    new-instance p1, Lcom/discord/intents/LinkingModule;

    .line 562
    .line 563
    invoke-direct {p1, p2}, Lcom/discord/intents/LinkingModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 564
    .line 565
    .line 566
    goto :goto_237

    .line 567
    :cond_236
    const/4 p1, 0x0

    .line 568
    :goto_237
    return-object p1

    .line 569
    :pswitch_238
    const-string v0, "name"

    .line 570
    .line 571
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 572
    .line 573
    .line 574
    const-string p1, "reactContext"

    .line 575
    .line 576
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 577
    .line 578
    .line 579
    goto/16 :goto_29

    .line 580
    .line 581
    :pswitch_244
    const-string v0, "name"

    .line 582
    .line 583
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 584
    .line 585
    .line 586
    const-string v0, "reactContext"

    .line 587
    .line 588
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 589
    .line 590
    .line 591
    const-string v0, "NativeAuthenticationModule"

    .line 592
    .line 593
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 594
    .line 595
    .line 596
    move-result v0

    .line 597
    if-eqz v0, :cond_25c

    .line 598
    .line 599
    new-instance p1, Lcom/discord/authentication/AuthenticationModule;

    .line 600
    .line 601
    invoke-direct {p1, p2}, Lcom/discord/authentication/AuthenticationModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 602
    .line 603
    .line 604
    goto :goto_26b

    .line 605
    :cond_25c
    const-string v0, "NativeRemoteAuthCryptoModule"

    .line 606
    .line 607
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 608
    .line 609
    .line 610
    move-result p1

    .line 611
    if-eqz p1, :cond_26a

    .line 612
    .line 613
    new-instance p1, Lcom/discord/authentication/RemoteAuthCryptoModule;

    .line 614
    .line 615
    invoke-direct {p1, p2}, Lcom/discord/authentication/RemoteAuthCryptoModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 616
    .line 617
    .line 618
    goto :goto_26b

    .line 619
    :cond_26a
    const/4 p1, 0x0

    .line 620
    :goto_26b
    return-object p1

    .line 621
    :pswitch_26c
    const-string v0, "name"

    .line 622
    .line 623
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 624
    .line 625
    .line 626
    const-string p1, "reactContext"

    .line 627
    .line 628
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 629
    .line 630
    .line 631
    goto/16 :goto_29

    .line 632
    .line 633
    :pswitch_data_278
    .packed-switch 0x0
        :pswitch_26c
        :pswitch_244
        :pswitch_238
        :pswitch_210
        :pswitch_204
        :pswitch_1ea
        :pswitch_1c2
        :pswitch_1a8
        :pswitch_19c
        :pswitch_182
        :pswitch_176
        :pswitch_16a
        :pswitch_15e
        :pswitch_e1
        :pswitch_d5
        :pswitch_bb
        :pswitch_af
        :pswitch_95
        :pswitch_6d
        :pswitch_45
        :pswitch_2b
        :pswitch_1f
    .end packed-switch

    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    :sswitch_data_2a8
    .sparse-switch
        -0x7c3bf1c7 -> :sswitch_14e
        -0x6c614cc4 -> :sswitch_13f
        -0x85e708d -> :sswitch_130
        0x3cf0ead -> :sswitch_121
        0x25835bb1 -> :sswitch_112
        0x2715ad72 -> :sswitch_103
        0x49503e93 -> :sswitch_f4
    .end sparse-switch
.end method

.method public final getReactModuleInfoProvider()Ljo/a;
    .registers 11

    .line 1
    iget v0, p0, Lak/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_130

    .line 4
    .line 5
    .line 6
    const-class v0, Lcom/th3rdwave/safeareacontext/SafeAreaContextModule;

    .line 7
    .line 8
    filled-new-array {v0}, [Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    new-instance v1, Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    aget-object v0, v0, v2

    .line 19
    .line 20
    const-class v2, Lio/a;

    .line 21
    .line 22
    invoke-virtual {v0, v2}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Lio/a;

    .line 27
    .line 28
    if-nez v2, :cond_1e

    .line 29
    .line 30
    goto :goto_3b

    .line 31
    :cond_1e
    invoke-interface {v2}, Lio/a;->name()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    new-instance v4, Lcom/facebook/react/module/model/ReactModuleInfo;

    .line 36
    .line 37
    invoke-interface {v2}, Lio/a;->name()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    invoke-interface {v2}, Lio/a;->needsEagerInit()Z

    .line 46
    .line 47
    .line 48
    move-result v8

    .line 49
    invoke-interface {v2}, Lio/a;->isCxxModule()Z

    .line 50
    .line 51
    .line 52
    const/4 v9, 0x1

    .line 53
    const/4 v7, 0x1

    .line 54
    invoke-direct/range {v4 .. v9}, Lcom/facebook/react/module/model/ReactModuleInfo;-><init>(Ljava/lang/String;Ljava/lang/String;ZZZ)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    :goto_3b
    new-instance v0, Lcom/swmansion/reanimated/d;

    .line 61
    .line 62
    const/4 v2, 0x2

    .line 63
    invoke-direct {v0, v1, v2}, Lcom/swmansion/reanimated/d;-><init>(Ljava/util/HashMap;I)V

    .line 64
    .line 65
    .line 66
    return-object v0

    .line 67
    :pswitch_42
    const/4 v0, 0x0

    .line 68
    const/4 v1, 0x3

    .line 69
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    return-object v0

    .line 74
    :pswitch_49
    const-string v0, "NativeFastConnectModule"

    .line 75
    .line 76
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    new-instance v1, Lgi/i;

    .line 81
    .line 82
    const/4 v2, 0x1

    .line 83
    invoke-direct {v1, v0, v2}, Lgi/i;-><init>(Ljava/util/List;Z)V

    .line 84
    .line 85
    .line 86
    return-object v1

    .line 87
    :pswitch_56
    const-string v0, "NativeScreenWakeLockModule"

    .line 88
    .line 89
    const-string v1, "NativeProximitySensorManagerModule"

    .line 90
    .line 91
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-static {v0}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    const/4 v1, 0x2

    .line 100
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    return-object v0

    .line 105
    :pswitch_68
    new-instance v0, Lcom/margelo/nitro/nitrofetch/t0;

    .line 106
    .line 107
    const/16 v1, 0x9

    .line 108
    .line 109
    invoke-direct {v0, v1}, Lcom/margelo/nitro/nitrofetch/t0;-><init>(I)V

    .line 110
    .line 111
    .line 112
    return-object v0

    .line 113
    :pswitch_70
    new-instance v0, Lcom/margelo/nitro/nitrofetch/t0;

    .line 114
    .line 115
    const/16 v1, 0x8

    .line 116
    .line 117
    invoke-direct {v0, v1}, Lcom/margelo/nitro/nitrofetch/t0;-><init>(I)V

    .line 118
    .line 119
    .line 120
    return-object v0

    .line 121
    :pswitch_78
    const/4 v0, 0x0

    .line 122
    const/4 v1, 0x3

    .line 123
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    return-object v0

    .line 128
    :pswitch_7f
    new-instance v0, Lcom/margelo/nitro/nitrofetch/t0;

    .line 129
    .line 130
    const/4 v1, 0x7

    .line 131
    invoke-direct {v0, v1}, Lcom/margelo/nitro/nitrofetch/t0;-><init>(I)V

    .line 132
    .line 133
    .line 134
    return-object v0

    .line 135
    :pswitch_86
    const/4 v0, 0x0

    .line 136
    const/4 v1, 0x3

    .line 137
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    return-object v0

    .line 142
    :pswitch_8d
    const-string v6, "NativeDeviceThermalStateModule"

    .line 143
    .line 144
    const-string v7, "NativeMetaQuestModule"

    .line 145
    .line 146
    const-string v1, "NativeDeviceAccessibilityModule"

    .line 147
    .line 148
    const-string v2, "NativeDeviceLocaleModule"

    .line 149
    .line 150
    const-string v3, "NativeDeviceModule"

    .line 151
    .line 152
    const-string v4, "NativeDeviceSettingsModule"

    .line 153
    .line 154
    const-string v5, "NativeDeviceSilentModeModule"

    .line 155
    .line 156
    filled-new-array/range {v1 .. v7}, [Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    invoke-static {v0}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    const/4 v1, 0x2

    .line 165
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    return-object v0

    .line 170
    :pswitch_a9
    const/4 v0, 0x0

    .line 171
    const/4 v1, 0x3

    .line 172
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    return-object v0

    .line 177
    :pswitch_b0
    const/4 v0, 0x0

    .line 178
    const/4 v1, 0x3

    .line 179
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    return-object v0

    .line 184
    :pswitch_b7
    new-instance v0, Lcom/margelo/nitro/nitrofetch/t0;

    .line 185
    .line 186
    const/4 v1, 0x2

    .line 187
    invoke-direct {v0, v1}, Lcom/margelo/nitro/nitrofetch/t0;-><init>(I)V

    .line 188
    .line 189
    .line 190
    return-object v0

    .line 191
    :pswitch_be
    const-string v0, "NativeSafeAreaInsetsModule"

    .line 192
    .line 193
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    const/4 v1, 0x2

    .line 198
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    return-object v0

    .line 203
    :pswitch_ca
    const/4 v0, 0x0

    .line 204
    const/4 v1, 0x3

    .line 205
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    return-object v0

    .line 210
    :pswitch_d1
    const-string v0, "NativeFontModule"

    .line 211
    .line 212
    invoke-static {v0}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    const/4 v1, 0x2

    .line 217
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    return-object v0

    .line 222
    :pswitch_dd
    const-string v0, "NativeClientInfoModule"

    .line 223
    .line 224
    const-string v1, "NativeInstallTimeModule"

    .line 225
    .line 226
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    invoke-static {v0}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    const/4 v1, 0x2

    .line 235
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    return-object v0

    .line 240
    :pswitch_ef
    new-instance v0, Lcom/margelo/nitro/nitrofetch/t0;

    .line 241
    .line 242
    const/4 v1, 0x1

    .line 243
    invoke-direct {v0, v1}, Lcom/margelo/nitro/nitrofetch/t0;-><init>(I)V

    .line 244
    .line 245
    .line 246
    return-object v0

    .line 247
    :pswitch_f6
    const/4 v0, 0x0

    .line 248
    const/4 v1, 0x3

    .line 249
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    return-object v0

    .line 254
    :pswitch_fd
    const-string v0, "NativeIntentsModule"

    .line 255
    .line 256
    const-string v1, "NativeLinkingModule"

    .line 257
    .line 258
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    invoke-static {v0}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    const/4 v1, 0x2

    .line 267
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    return-object v0

    .line 272
    :pswitch_10f
    const/4 v0, 0x0

    .line 273
    const/4 v1, 0x3

    .line 274
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    return-object v0

    .line 279
    :pswitch_116
    const-string v0, "NativeAuthenticationModule"

    .line 280
    .line 281
    const-string v1, "NativeRemoteAuthCryptoModule"

    .line 282
    .line 283
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    invoke-static {v0}, Ls1/e;->u([Ljava/lang/Object;)Ljava/util/List;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    const/4 v1, 0x2

    .line 292
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    return-object v0

    .line 297
    :pswitch_128
    const/4 v0, 0x0

    .line 298
    const/4 v1, 0x3

    .line 299
    invoke-static {v1, v0}, Lh40/f0;->k(ILjava/util/List;)Lgi/i;

    .line 300
    .line 301
    .line 302
    move-result-object v0

    .line 303
    return-object v0

    .line 304
    nop

    .line 305
    :pswitch_data_130
    .packed-switch 0x0
        :pswitch_128
        :pswitch_116
        :pswitch_10f
        :pswitch_fd
        :pswitch_f6
        :pswitch_ef
        :pswitch_dd
        :pswitch_d1
        :pswitch_ca
        :pswitch_be
        :pswitch_b7
        :pswitch_b0
        :pswitch_a9
        :pswitch_8d
        :pswitch_86
        :pswitch_7f
        :pswitch_78
        :pswitch_70
        :pswitch_68
        :pswitch_56
        :pswitch_49
        :pswitch_42
    .end packed-switch
.end method
