###### Class ad.d0 (ad.d0)
.class public final synthetic Lad/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/d0;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/d0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/d0;->a:Lad/d0;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.InitiateReplyData"

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "triggerHaptic"

    .line 28
    .line 29
    const/4 v3, 0x1

    .line 30
    invoke-virtual {v1, v0, v3}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    const-string v0, "location"

    .line 34
    .line 35
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    sput-object v1, Lad/d0;->descriptor:Ll70/g;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 21

    .line 1
    sget-object v0, Lad/d0;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v2, :cond_45

    .line 19
    .line 20
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 21
    .line 22
    invoke-interface {v1, v0, v6, v2, v7}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 27
    .line 28
    if-eqz v2, :cond_20

    .line 29
    .line 30
    iget-object v2, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 31
    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move-object v2, v7

    .line 34
    :goto_21
    sget-object v6, Lyh/c;->a:Lyh/c;

    .line 35
    .line 36
    invoke-interface {v1, v0, v5, v6, v7}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    check-cast v5, Lcom/discord/primitives/ChannelId;

    .line 41
    .line 42
    sget-object v6, Ln70/g;->a:Ln70/g;

    .line 43
    .line 44
    invoke-interface {v1, v0, v4, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    check-cast v4, Ljava/lang/Boolean;

    .line 49
    .line 50
    sget-object v6, Ln70/h1;->a:Ln70/h1;

    .line 51
    .line 52
    invoke-interface {v1, v0, v3, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Ljava/lang/String;

    .line 57
    .line 58
    const/16 v6, 0xf

    .line 59
    .line 60
    move-object/from16 v18, v3

    .line 61
    .line 62
    move-object/from16 v17, v4

    .line 63
    .line 64
    move-object/from16 v16, v5

    .line 65
    .line 66
    move v14, v6

    .line 67
    :goto_42
    move-object v15, v2

    .line 68
    goto/16 :goto_a7

    .line 69
    .line 70
    :cond_45
    move v12, v5

    .line 71
    move v11, v6

    .line 72
    move-object v2, v7

    .line 73
    move-object v8, v2

    .line 74
    move-object v9, v8

    .line 75
    move-object v10, v9

    .line 76
    :goto_4b
    if-eqz v12, :cond_9f

    .line 77
    .line 78
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 79
    .line 80
    .line 81
    move-result v13

    .line 82
    const/4 v14, -0x1

    .line 83
    if-eq v13, v14, :cond_9d

    .line 84
    .line 85
    if-eqz v13, :cond_83

    .line 86
    .line 87
    if-eq v13, v5, :cond_78

    .line 88
    .line 89
    if-eq v13, v4, :cond_6d

    .line 90
    .line 91
    if-ne v13, v3, :cond_67

    .line 92
    .line 93
    sget-object v13, Ln70/h1;->a:Ln70/h1;

    .line 94
    .line 95
    invoke-interface {v1, v0, v3, v13, v8}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v8

    .line 99
    check-cast v8, Ljava/lang/String;

    .line 100
    .line 101
    or-int/lit8 v11, v11, 0x8

    .line 102
    .line 103
    goto :goto_4b

    .line 104
    :cond_67
    new-instance v0, Lj70/k;

    .line 105
    .line 106
    invoke-direct {v0, v13}, Lj70/k;-><init>(I)V

    .line 107
    .line 108
    .line 109
    throw v0

    .line 110
    :cond_6d
    sget-object v13, Ln70/g;->a:Ln70/g;

    .line 111
    .line 112
    invoke-interface {v1, v0, v4, v13, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v9

    .line 116
    check-cast v9, Ljava/lang/Boolean;

    .line 117
    .line 118
    or-int/lit8 v11, v11, 0x4

    .line 119
    .line 120
    goto :goto_4b

    .line 121
    :cond_78
    sget-object v13, Lyh/c;->a:Lyh/c;

    .line 122
    .line 123
    invoke-interface {v1, v0, v5, v13, v10}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v10

    .line 127
    check-cast v10, Lcom/discord/primitives/ChannelId;

    .line 128
    .line 129
    or-int/lit8 v11, v11, 0x2

    .line 130
    .line 131
    goto :goto_4b

    .line 132
    :cond_83
    sget-object v13, Lyh/h;->a:Lyh/h;

    .line 133
    .line 134
    if-eqz v2, :cond_8d

    .line 135
    .line 136
    new-instance v14, Lcom/discord/primitives/MessageId;

    .line 137
    .line 138
    invoke-direct {v14, v2}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    goto :goto_8e

    .line 142
    :cond_8d
    move-object v14, v7

    .line 143
    :goto_8e
    invoke-interface {v1, v0, v6, v13, v14}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 148
    .line 149
    if-eqz v2, :cond_99

    .line 150
    .line 151
    iget-object v2, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 152
    .line 153
    goto :goto_9a

    .line 154
    :cond_99
    move-object v2, v7

    .line 155
    :goto_9a
    or-int/lit8 v11, v11, 0x1

    .line 156
    .line 157
    goto :goto_4b

    .line 158
    :cond_9d
    move v12, v6

    .line 159
    goto :goto_4b

    .line 160
    :cond_9f
    move-object/from16 v18, v8

    .line 161
    .line 162
    move-object/from16 v17, v9

    .line 163
    .line 164
    move-object/from16 v16, v10

    .line 165
    .line 166
    move v14, v11

    .line 167
    goto :goto_42

    .line 168
    :goto_a7
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 169
    .line 170
    .line 171
    new-instance v13, Lad/f0;

    .line 172
    .line 173
    invoke-direct/range {v13 .. v18}, Lad/f0;-><init>(ILjava/lang/String;Lcom/discord/primitives/ChannelId;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    return-object v13
.end method

.method public final b()[Lj70/b;
    .registers 6

    .line 1
    sget-object v0, Ln70/g;->a:Ln70/g;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 8
    .line 9
    invoke-static {v1}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/4 v2, 0x4

    .line 14
    new-array v2, v2, [Lj70/b;

    .line 15
    .line 16
    sget-object v3, Lyh/h;->a:Lyh/h;

    .line 17
    .line 18
    const/4 v4, 0x0

    .line 19
    aput-object v3, v2, v4

    .line 20
    .line 21
    sget-object v3, Lyh/c;->a:Lyh/c;

    .line 22
    .line 23
    const/4 v4, 0x1

    .line 24
    aput-object v3, v2, v4

    .line 25
    .line 26
    const/4 v3, 0x2

    .line 27
    aput-object v0, v2, v3

    .line 28
    .line 29
    const/4 v0, 0x3

    .line 30
    aput-object v1, v2, v0

    .line 31
    .line 32
    return-object v2
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 9

    .line 1
    check-cast p2, Lad/f0;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/d0;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/f0;->a:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v3, p2, Lad/f0;->c:Ljava/lang/Boolean;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    invoke-static {v2, p1, v0, v4, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, Lyh/c;->a:Lyh/c;

    .line 25
    .line 26
    iget-wide v4, p2, Lad/f0;->b:J

    .line 27
    .line 28
    new-instance v2, Lcom/discord/primitives/ChannelId;

    .line 29
    .line 30
    invoke-direct {v2, v4, v5}, Lcom/discord/primitives/ChannelId;-><init>(J)V

    .line 31
    .line 32
    .line 33
    const/4 v4, 0x1

    .line 34
    invoke-interface {p1, v0, v4, v1, v2}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    const/4 v1, 0x2

    .line 38
    invoke-interface {p1, v0, v1}, Lm70/b;->D(Ll70/g;I)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-eqz v2, :cond_2c

    .line 43
    .line 44
    goto :goto_34

    .line 45
    :cond_2c
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 46
    .line 47
    invoke-static {v3, v2}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-nez v2, :cond_39

    .line 52
    .line 53
    :goto_34
    sget-object v2, Ln70/g;->a:Ln70/g;

    .line 54
    .line 55
    invoke-interface {p1, v0, v1, v2, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    :cond_39
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 59
    .line 60
    iget-object p2, p2, Lad/f0;->d:Ljava/lang/String;

    .line 61
    .line 62
    const/4 v2, 0x3

    .line 63
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 67
    .line 68
    .line 69
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/d0;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
