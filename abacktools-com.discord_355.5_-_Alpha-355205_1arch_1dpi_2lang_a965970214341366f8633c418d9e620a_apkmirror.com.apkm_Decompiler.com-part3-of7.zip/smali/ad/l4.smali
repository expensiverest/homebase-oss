###### Class ad.l4 (ad.l4)
.class public final synthetic Lad/l4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/l4;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/l4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/l4;->a:Lad/l4;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapGiftCodeAcceptData"

    .line 11
    .line 12
    const/4 v3, 0x2

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "giftCode"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "messageId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    sput-object v1, Lad/l4;->descriptor:Ll70/g;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 12

    .line 1
    sget-object v0, Lad/l4;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_21

    .line 15
    .line 16
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    sget-object v3, Lyh/h;->a:Lyh/h;

    .line 21
    .line 22
    invoke-interface {p1, v0, v2, v3, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 27
    .line 28
    if-eqz v2, :cond_1f

    .line 29
    .line 30
    iget-object v4, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 31
    .line 32
    :cond_1f
    const/4 v2, 0x3

    .line 33
    goto :goto_5d

    .line 34
    :cond_21
    move v7, v2

    .line 35
    move v5, v3

    .line 36
    move-object v1, v4

    .line 37
    move-object v6, v1

    .line 38
    :goto_25
    if-eqz v7, :cond_5b

    .line 39
    .line 40
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    const/4 v9, -0x1

    .line 45
    if-eq v8, v9, :cond_59

    .line 46
    .line 47
    if-eqz v8, :cond_52

    .line 48
    .line 49
    if-ne v8, v2, :cond_4c

    .line 50
    .line 51
    sget-object v8, Lyh/h;->a:Lyh/h;

    .line 52
    .line 53
    if-eqz v6, :cond_3c

    .line 54
    .line 55
    new-instance v9, Lcom/discord/primitives/MessageId;

    .line 56
    .line 57
    invoke-direct {v9, v6}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    goto :goto_3d

    .line 61
    :cond_3c
    move-object v9, v4

    .line 62
    :goto_3d
    invoke-interface {p1, v0, v2, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    check-cast v6, Lcom/discord/primitives/MessageId;

    .line 67
    .line 68
    if-eqz v6, :cond_48

    .line 69
    .line 70
    iget-object v6, v6, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 71
    .line 72
    goto :goto_49

    .line 73
    :cond_48
    move-object v6, v4

    .line 74
    :goto_49
    or-int/lit8 v5, v5, 0x2

    .line 75
    .line 76
    goto :goto_25

    .line 77
    :cond_4c
    new-instance p1, Lj70/k;

    .line 78
    .line 79
    invoke-direct {p1, v8}, Lj70/k;-><init>(I)V

    .line 80
    .line 81
    .line 82
    throw p1

    .line 83
    :cond_52
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    or-int/lit8 v5, v5, 0x1

    .line 88
    .line 89
    goto :goto_25

    .line 90
    :cond_59
    move v7, v3

    .line 91
    goto :goto_25

    .line 92
    :cond_5b
    move v2, v5

    .line 93
    move-object v4, v6

    .line 94
    :goto_5d
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 95
    .line 96
    .line 97
    new-instance p1, Lad/n4;

    .line 98
    .line 99
    invoke-direct {p1, v2, v1, v4}, Lad/n4;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 5

    .line 1
    sget-object v0, Lyh/h;->a:Lyh/h;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x2

    .line 8
    new-array v1, v1, [Lj70/b;

    .line 9
    .line 10
    sget-object v2, Ln70/h1;->a:Ln70/h1;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    aput-object v2, v1, v3

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    aput-object v0, v1, v2

    .line 17
    .line 18
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/n4;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/l4;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lad/n4;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 21
    .line 22
    iget-object p2, p2, Lad/n4;->b:Ljava/lang/String;

    .line 23
    .line 24
    if-eqz p2, :cond_1f

    .line 25
    .line 26
    new-instance v2, Lcom/discord/primitives/MessageId;

    .line 27
    .line 28
    invoke-direct {v2, p2}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    const/4 v2, 0x0

    .line 33
    :goto_20
    const/4 p2, 0x1

    .line 34
    invoke-interface {p1, v0, p2, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/l4;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
