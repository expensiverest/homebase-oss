###### Class ad.p0 (ad.p0)
.class public final synthetic Lad/p0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/p0;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/p0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/p0;->a:Lad/p0;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.LongPressChannelData"

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "guildId"

    .line 17
    .line 18
    const/4 v2, 0x1

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "messageId"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "originalLink"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    sput-object v1, Lad/p0;->descriptor:Ll70/g;

    .line 38
    .line 39
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 20

    .line 1
    sget-object v0, Lad/p0;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v2, :cond_37

    .line 19
    .line 20
    sget-object v2, Ln70/h1;->a:Ln70/h1;

    .line 21
    .line 22
    invoke-interface {v1, v0, v6, v2, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v6

    .line 26
    check-cast v6, Ljava/lang/String;

    .line 27
    .line 28
    invoke-interface {v1, v0, v5, v2, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    check-cast v5, Ljava/lang/String;

    .line 33
    .line 34
    invoke-interface {v1, v0, v4, v2, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    check-cast v4, Ljava/lang/String;

    .line 39
    .line 40
    invoke-interface {v1, v0, v3, v2, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    check-cast v2, Ljava/lang/String;

    .line 45
    .line 46
    const/16 v3, 0xf

    .line 47
    .line 48
    move-object/from16 v17, v2

    .line 49
    .line 50
    move v13, v3

    .line 51
    move-object/from16 v16, v4

    .line 52
    .line 53
    move-object v15, v5

    .line 54
    move-object v14, v6

    .line 55
    goto :goto_88

    .line 56
    :cond_37
    move v11, v5

    .line 57
    move v2, v6

    .line 58
    move-object v8, v7

    .line 59
    move-object v9, v8

    .line 60
    move-object v10, v9

    .line 61
    :goto_3c
    if-eqz v11, :cond_81

    .line 62
    .line 63
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 64
    .line 65
    .line 66
    move-result v12

    .line 67
    const/4 v13, -0x1

    .line 68
    if-eq v12, v13, :cond_7f

    .line 69
    .line 70
    if-eqz v12, :cond_74

    .line 71
    .line 72
    if-eq v12, v5, :cond_69

    .line 73
    .line 74
    if-eq v12, v4, :cond_5e

    .line 75
    .line 76
    if-ne v12, v3, :cond_58

    .line 77
    .line 78
    sget-object v12, Ln70/h1;->a:Ln70/h1;

    .line 79
    .line 80
    invoke-interface {v1, v0, v3, v12, v10}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v10

    .line 84
    check-cast v10, Ljava/lang/String;

    .line 85
    .line 86
    or-int/lit8 v2, v2, 0x8

    .line 87
    .line 88
    goto :goto_3c

    .line 89
    :cond_58
    new-instance v0, Lj70/k;

    .line 90
    .line 91
    invoke-direct {v0, v12}, Lj70/k;-><init>(I)V

    .line 92
    .line 93
    .line 94
    throw v0

    .line 95
    :cond_5e
    sget-object v12, Ln70/h1;->a:Ln70/h1;

    .line 96
    .line 97
    invoke-interface {v1, v0, v4, v12, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v9

    .line 101
    check-cast v9, Ljava/lang/String;

    .line 102
    .line 103
    or-int/lit8 v2, v2, 0x4

    .line 104
    .line 105
    goto :goto_3c

    .line 106
    :cond_69
    sget-object v12, Ln70/h1;->a:Ln70/h1;

    .line 107
    .line 108
    invoke-interface {v1, v0, v5, v12, v8}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v8

    .line 112
    check-cast v8, Ljava/lang/String;

    .line 113
    .line 114
    or-int/lit8 v2, v2, 0x2

    .line 115
    .line 116
    goto :goto_3c

    .line 117
    :cond_74
    sget-object v12, Ln70/h1;->a:Ln70/h1;

    .line 118
    .line 119
    invoke-interface {v1, v0, v6, v12, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v7

    .line 123
    check-cast v7, Ljava/lang/String;

    .line 124
    .line 125
    or-int/lit8 v2, v2, 0x1

    .line 126
    .line 127
    goto :goto_3c

    .line 128
    :cond_7f
    move v11, v6

    .line 129
    goto :goto_3c

    .line 130
    :cond_81
    move v13, v2

    .line 131
    move-object v14, v7

    .line 132
    move-object v15, v8

    .line 133
    move-object/from16 v16, v9

    .line 134
    .line 135
    move-object/from16 v17, v10

    .line 136
    .line 137
    :goto_88
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 138
    .line 139
    .line 140
    new-instance v12, Lad/r0;

    .line 141
    .line 142
    invoke-direct/range {v12 .. v17}, Lad/r0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    return-object v12
.end method

.method public final b()[Lj70/b;
    .registers 7

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const/4 v4, 0x4

    .line 20
    new-array v4, v4, [Lj70/b;

    .line 21
    .line 22
    const/4 v5, 0x0

    .line 23
    aput-object v1, v4, v5

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    aput-object v2, v4, v1

    .line 27
    .line 28
    const/4 v1, 0x2

    .line 29
    aput-object v3, v4, v1

    .line 30
    .line 31
    const/4 v1, 0x3

    .line 32
    aput-object v0, v4, v1

    .line 33
    .line 34
    return-object v4
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 9

    .line 1
    check-cast p2, Lad/r0;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p2, Lad/r0;->d:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v1, p2, Lad/r0;->c:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v2, p2, Lad/r0;->b:Ljava/lang/String;

    .line 13
    .line 14
    iget-object p2, p2, Lad/r0;->a:Ljava/lang/String;

    .line 15
    .line 16
    sget-object v3, Lad/p0;->descriptor:Ll70/g;

    .line 17
    .line 18
    invoke-interface {p1, v3}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const/4 v4, 0x0

    .line 23
    invoke-interface {p1, v3, v4}, Lm70/b;->D(Ll70/g;I)Z

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    if-eqz v5, :cond_1d

    .line 28
    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    if-eqz p2, :cond_24

    .line 31
    .line 32
    :goto_1f
    sget-object v5, Ln70/h1;->a:Ln70/h1;

    .line 33
    .line 34
    invoke-interface {p1, v3, v4, v5, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :cond_24
    const/4 p2, 0x1

    .line 38
    invoke-interface {p1, v3, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 39
    .line 40
    .line 41
    move-result v4

    .line 42
    if-eqz v4, :cond_2c

    .line 43
    .line 44
    goto :goto_2e

    .line 45
    :cond_2c
    if-eqz v2, :cond_33

    .line 46
    .line 47
    :goto_2e
    sget-object v4, Ln70/h1;->a:Ln70/h1;

    .line 48
    .line 49
    invoke-interface {p1, v3, p2, v4, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    :cond_33
    const/4 p2, 0x2

    .line 53
    invoke-interface {p1, v3, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    if-eqz v2, :cond_3b

    .line 58
    .line 59
    goto :goto_3d

    .line 60
    :cond_3b
    if-eqz v1, :cond_42

    .line 61
    .line 62
    :goto_3d
    sget-object v2, Ln70/h1;->a:Ln70/h1;

    .line 63
    .line 64
    invoke-interface {p1, v3, p2, v2, v1}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :cond_42
    const/4 p2, 0x3

    .line 68
    invoke-interface {p1, v3, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-eqz v1, :cond_4a

    .line 73
    .line 74
    goto :goto_4c

    .line 75
    :cond_4a
    if-eqz v0, :cond_51

    .line 76
    .line 77
    :goto_4c
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 78
    .line 79
    invoke-interface {p1, v3, p2, v1, v0}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    invoke-interface {p1, v3}, Lm70/b;->c(Ll70/g;)V

    .line 83
    .line 84
    .line 85
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/p0;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
