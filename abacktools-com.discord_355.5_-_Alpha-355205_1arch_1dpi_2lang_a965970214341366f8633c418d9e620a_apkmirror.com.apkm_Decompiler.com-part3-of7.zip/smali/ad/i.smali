###### Class ad.i (ad.i)
.class public final synthetic Lad/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/i;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/i;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/i;->a:Lad/i;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.ContentPaintStateData"

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "changesetUpdateId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "painted"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "monotonicTimestamp"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lad/i;->descriptor:Ll70/g;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 19

    .line 1
    sget-object v0, Lad/i;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x2

    .line 14
    const/4 v4, 0x1

    .line 15
    const/4 v5, 0x0

    .line 16
    if-eqz v2, :cond_23

    .line 17
    .line 18
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    invoke-interface {v1, v0, v4}, Lm70/a;->v(Ll70/g;I)Z

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    invoke-interface {v1, v0, v3}, Lm70/a;->D(Ll70/g;I)D

    .line 27
    .line 28
    .line 29
    move-result-wide v5

    .line 30
    const/4 v3, 0x7

    .line 31
    move v12, v3

    .line 32
    move v14, v4

    .line 33
    move-wide v15, v5

    .line 34
    :goto_21
    move v13, v2

    .line 35
    goto :goto_5a

    .line 36
    :cond_23
    const-wide/16 v6, 0x0

    .line 37
    .line 38
    move v10, v4

    .line 39
    move v2, v5

    .line 40
    move-wide v8, v6

    .line 41
    move v6, v2

    .line 42
    move v7, v6

    .line 43
    :goto_2a
    if-eqz v10, :cond_56

    .line 44
    .line 45
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 46
    .line 47
    .line 48
    move-result v11

    .line 49
    const/4 v12, -0x1

    .line 50
    if-eq v11, v12, :cond_54

    .line 51
    .line 52
    if-eqz v11, :cond_4d

    .line 53
    .line 54
    if-eq v11, v4, :cond_46

    .line 55
    .line 56
    if-ne v11, v3, :cond_40

    .line 57
    .line 58
    invoke-interface {v1, v0, v3}, Lm70/a;->D(Ll70/g;I)D

    .line 59
    .line 60
    .line 61
    move-result-wide v8

    .line 62
    or-int/lit8 v6, v6, 0x4

    .line 63
    .line 64
    goto :goto_2a

    .line 65
    :cond_40
    new-instance v0, Lj70/k;

    .line 66
    .line 67
    invoke-direct {v0, v11}, Lj70/k;-><init>(I)V

    .line 68
    .line 69
    .line 70
    throw v0

    .line 71
    :cond_46
    invoke-interface {v1, v0, v4}, Lm70/a;->v(Ll70/g;I)Z

    .line 72
    .line 73
    .line 74
    move-result v7

    .line 75
    or-int/lit8 v6, v6, 0x2

    .line 76
    .line 77
    goto :goto_2a

    .line 78
    :cond_4d
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    or-int/lit8 v6, v6, 0x1

    .line 83
    .line 84
    goto :goto_2a

    .line 85
    :cond_54
    move v10, v5

    .line 86
    goto :goto_2a

    .line 87
    :cond_56
    move v12, v6

    .line 88
    move v14, v7

    .line 89
    move-wide v15, v8

    .line 90
    goto :goto_21

    .line 91
    :goto_5a
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 92
    .line 93
    .line 94
    new-instance v11, Lad/k;

    .line 95
    .line 96
    invoke-direct/range {v11 .. v16}, Lad/k;-><init>(IIZD)V

    .line 97
    .line 98
    .line 99
    return-object v11
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    sget-object v1, Ln70/r;->a:Ln70/r;

    .line 15
    .line 16
    const/4 v2, 0x2

    .line 17
    aput-object v1, v0, v2

    .line 18
    .line 19
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/k;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/i;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget v2, p2, Lad/k;->a:I

    .line 16
    .line 17
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-boolean v2, p2, Lad/k;->b:Z

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-wide v2, p2, Lad/k;->c:D

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2, v3}, Lm70/b;->r(Ll70/g;ID)V

    .line 30
    .line 31
    .line 32
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/i;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
