###### Class ad.a6 (ad.a6)
.class public final Lad/a6;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/z5;->a:Lad/z5;

    .line 2
    .line 3
    return-object v0
.end method
