###### Class ad.m4 (ad.m4)
.class public final Lad/m4;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/l4;->a:Lad/l4;

    .line 2
    .line 3
    return-object v0
.end method
