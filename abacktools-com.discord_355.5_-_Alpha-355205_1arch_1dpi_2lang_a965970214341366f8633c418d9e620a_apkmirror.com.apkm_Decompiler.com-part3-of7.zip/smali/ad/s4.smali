###### Class ad.s4 (ad.s4)
.class public final Lad/s4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:Ljava/lang/String;

.field public final d:Lad/r4;

.field public final e:Ljava/lang/Double;

.field public final f:Ljava/lang/Integer;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/Integer;

.field public final i:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Lad/r4;Ljava/lang/Double;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V
    .registers 11

    .line 1
    const-string v0, "id"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lad/s4;->a:Ljava/lang/String;

    .line 10
    .line 11
    iput p2, p0, Lad/s4;->b:I

    .line 12
    .line 13
    iput-object p3, p0, Lad/s4;->c:Ljava/lang/String;

    .line 14
    .line 15
    iput-object p4, p0, Lad/s4;->d:Lad/r4;

    .line 16
    .line 17
    iput-object p5, p0, Lad/s4;->e:Ljava/lang/Double;

    .line 18
    .line 19
    iput-object p6, p0, Lad/s4;->f:Ljava/lang/Integer;

    .line 20
    .line 21
    iput-object p7, p0, Lad/s4;->g:Ljava/lang/String;

    .line 22
    .line 23
    iput-object p8, p0, Lad/s4;->h:Ljava/lang/Integer;

    .line 24
    .line 25
    iput-object p9, p0, Lad/s4;->i:Ljava/lang/String;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableMap;
    .registers 12

    .line 1
    new-instance v0, Ll30/j;

    .line 2
    .line 3
    const-string v1, "id"

    .line 4
    .line 5
    iget-object v2, p0, Lad/s4;->a:Ljava/lang/String;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    iget v1, p0, Lad/s4;->b:I

    .line 11
    .line 12
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    move-object v2, v1

    .line 17
    new-instance v1, Ll30/j;

    .line 18
    .line 19
    const-string v3, "index"

    .line 20
    .line 21
    invoke-direct {v1, v3, v2}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    new-instance v2, Ll30/j;

    .line 25
    .line 26
    const-string v3, "type"

    .line 27
    .line 28
    iget-object v4, p0, Lad/s4;->c:Ljava/lang/String;

    .line 29
    .line 30
    invoke-direct {v2, v3, v4}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-object v3, p0, Lad/s4;->d:Lad/r4;

    .line 34
    .line 35
    invoke-virtual {v3}, Lad/r4;->a()Lcom/facebook/react/bridge/WritableNativeMap;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    move-object v4, v3

    .line 40
    new-instance v3, Ll30/j;

    .line 41
    .line 42
    const-string v5, "layout"

    .line 43
    .line 44
    invoke-direct {v3, v5, v4}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    new-instance v4, Ll30/j;

    .line 48
    .line 49
    const-string v5, "portal"

    .line 50
    .line 51
    iget-object v6, p0, Lad/s4;->e:Ljava/lang/Double;

    .line 52
    .line 53
    invoke-direct {v4, v5, v6}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    new-instance v5, Ll30/j;

    .line 57
    .line 58
    const-string v6, "embedIndex"

    .line 59
    .line 60
    iget-object v7, p0, Lad/s4;->f:Ljava/lang/Integer;

    .line 61
    .line 62
    invoke-direct {v5, v6, v7}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    new-instance v6, Ll30/j;

    .line 66
    .line 67
    const-string v7, "componentId"

    .line 68
    .line 69
    iget-object v8, p0, Lad/s4;->g:Ljava/lang/String;

    .line 70
    .line 71
    invoke-direct {v6, v7, v8}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    new-instance v7, Ll30/j;

    .line 75
    .line 76
    const-string v8, "componentMediaIndex"

    .line 77
    .line 78
    iget-object v9, p0, Lad/s4;->h:Ljava/lang/Integer;

    .line 79
    .line 80
    invoke-direct {v7, v8, v9}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    new-instance v8, Ll30/j;

    .line 84
    .line 85
    const-string v9, "embedId"

    .line 86
    .line 87
    iget-object v10, p0, Lad/s4;->i:Ljava/lang/String;

    .line 88
    .line 89
    invoke-direct {v8, v9, v10}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    filled-new-array/range {v0 .. v8}, [Ll30/j;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lad/s4;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lad/s4;

    .line 12
    .line 13
    iget-object v1, p0, Lad/s4;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lad/s4;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    iget v1, p0, Lad/s4;->b:I

    .line 25
    .line 26
    iget v3, p1, Lad/s4;->b:I

    .line 27
    .line 28
    if-eq v1, v3, :cond_1e

    .line 29
    .line 30
    return v2

    .line 31
    :cond_1e
    iget-object v1, p0, Lad/s4;->c:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v3, p1, Lad/s4;->c:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-nez v1, :cond_29

    .line 40
    .line 41
    return v2

    .line 42
    :cond_29
    iget-object v1, p0, Lad/s4;->d:Lad/r4;

    .line 43
    .line 44
    iget-object v3, p1, Lad/s4;->d:Lad/r4;

    .line 45
    .line 46
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-nez v1, :cond_34

    .line 51
    .line 52
    return v2

    .line 53
    :cond_34
    iget-object v1, p0, Lad/s4;->e:Ljava/lang/Double;

    .line 54
    .line 55
    iget-object v3, p1, Lad/s4;->e:Ljava/lang/Double;

    .line 56
    .line 57
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-nez v1, :cond_3f

    .line 62
    .line 63
    return v2

    .line 64
    :cond_3f
    iget-object v1, p0, Lad/s4;->f:Ljava/lang/Integer;

    .line 65
    .line 66
    iget-object v3, p1, Lad/s4;->f:Ljava/lang/Integer;

    .line 67
    .line 68
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-nez v1, :cond_4a

    .line 73
    .line 74
    return v2

    .line 75
    :cond_4a
    iget-object v1, p0, Lad/s4;->g:Ljava/lang/String;

    .line 76
    .line 77
    iget-object v3, p1, Lad/s4;->g:Ljava/lang/String;

    .line 78
    .line 79
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    if-nez v1, :cond_55

    .line 84
    .line 85
    return v2

    .line 86
    :cond_55
    iget-object v1, p0, Lad/s4;->h:Ljava/lang/Integer;

    .line 87
    .line 88
    iget-object v3, p1, Lad/s4;->h:Ljava/lang/Integer;

    .line 89
    .line 90
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    if-nez v1, :cond_60

    .line 95
    .line 96
    return v2

    .line 97
    :cond_60
    iget-object v1, p0, Lad/s4;->i:Ljava/lang/String;

    .line 98
    .line 99
    iget-object p1, p1, Lad/s4;->i:Ljava/lang/String;

    .line 100
    .line 101
    invoke-static {v1, p1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result p1

    .line 105
    if-nez p1, :cond_6b

    .line 106
    .line 107
    return v2

    .line 108
    :cond_6b
    return v0
.end method

.method public final hashCode()I
    .registers 5

    .line 1
    iget-object v0, p0, Lad/s4;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lad/s4;->b:I

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lad/s4;->c:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lhs/q;->c(IILjava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v2, p0, Lad/s4;->d:Lad/r4;

    .line 23
    .line 24
    invoke-virtual {v2}, Lad/r4;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    add-int/2addr v2, v0

    .line 29
    mul-int/2addr v2, v1

    .line 30
    const/4 v0, 0x0

    .line 31
    iget-object v3, p0, Lad/s4;->e:Ljava/lang/Double;

    .line 32
    .line 33
    if-nez v3, :cond_24

    .line 34
    .line 35
    move v3, v0

    .line 36
    goto :goto_28

    .line 37
    :cond_24
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    :goto_28
    add-int/2addr v2, v3

    .line 42
    mul-int/2addr v2, v1

    .line 43
    iget-object v3, p0, Lad/s4;->f:Ljava/lang/Integer;

    .line 44
    .line 45
    if-nez v3, :cond_30

    .line 46
    .line 47
    move v3, v0

    .line 48
    goto :goto_34

    .line 49
    :cond_30
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    :goto_34
    add-int/2addr v2, v3

    .line 54
    mul-int/2addr v2, v1

    .line 55
    iget-object v3, p0, Lad/s4;->g:Ljava/lang/String;

    .line 56
    .line 57
    if-nez v3, :cond_3c

    .line 58
    .line 59
    move v3, v0

    .line 60
    goto :goto_40

    .line 61
    :cond_3c
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    :goto_40
    add-int/2addr v2, v3

    .line 66
    mul-int/2addr v2, v1

    .line 67
    iget-object v3, p0, Lad/s4;->h:Ljava/lang/Integer;

    .line 68
    .line 69
    if-nez v3, :cond_48

    .line 70
    .line 71
    move v3, v0

    .line 72
    goto :goto_4c

    .line 73
    :cond_48
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 74
    .line 75
    .line 76
    move-result v3

    .line 77
    :goto_4c
    add-int/2addr v2, v3

    .line 78
    mul-int/2addr v2, v1

    .line 79
    iget-object v1, p0, Lad/s4;->i:Ljava/lang/String;

    .line 80
    .line 81
    if-nez v1, :cond_53

    .line 82
    .line 83
    goto :goto_57

    .line 84
    :cond_53
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    :goto_57
    add-int/2addr v2, v0

    .line 89
    return v2
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    const-string v0, ", index="

    .line 2
    .line 3
    const-string v1, ", type="

    .line 4
    .line 5
    iget v2, p0, Lad/s4;->b:I

    .line 6
    .line 7
    const-string v3, "TapImageData(id="

    .line 8
    .line 9
    iget-object v4, p0, Lad/s4;->a:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v2, v3, v4, v0, v1}, La1/h;->n(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-object v1, p0, Lad/s4;->c:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-string v1, ", layout="

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lad/s4;->d:Lad/r4;

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string v1, ", portal="

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lad/s4;->e:Ljava/lang/Double;

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v1, ", embedIndex="

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    iget-object v1, p0, Lad/s4;->f:Ljava/lang/Integer;

    .line 46
    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    const-string v1, ", componentId="

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    const-string v1, ", componentMediaIndex="

    .line 56
    .line 57
    const-string v2, ", embedId="

    .line 58
    .line 59
    iget-object v3, p0, Lad/s4;->h:Ljava/lang/Integer;

    .line 60
    .line 61
    iget-object v4, p0, Lad/s4;->g:Ljava/lang/String;

    .line 62
    .line 63
    invoke-static {v3, v4, v1, v2, v0}, Lhs/q;->t(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;)V

    .line 64
    .line 65
    .line 66
    const-string v1, ")"

    .line 67
    .line 68
    iget-object v2, p0, Lad/s4;->i:Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v0, v2, v1}, Lcom/google/android/gms/internal/fido/nb;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    return-object v0
.end method
