###### Class ad.d8 (ad.d8)
.class public final synthetic Lad/d8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/d8;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/d8;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/d8;->a:Lad/d8;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapTagData"

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "tagType"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lad/d8;->descriptor:Ll70/g;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 14

    .line 1
    sget-object v0, Lad/d8;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x2

    .line 12
    const/4 v3, 0x1

    .line 13
    const/4 v4, 0x0

    .line 14
    const/4 v5, 0x0

    .line 15
    if-eqz v1, :cond_30

    .line 16
    .line 17
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 18
    .line 19
    invoke-interface {p1, v0, v4, v1, v5}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 24
    .line 25
    if-eqz v1, :cond_1d

    .line 26
    .line 27
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move-object v1, v5

    .line 31
    :goto_1e
    sget-object v4, Lyh/c;->a:Lyh/c;

    .line 32
    .line 33
    invoke-interface {p1, v0, v3, v4, v5}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    check-cast v3, Lcom/discord/primitives/ChannelId;

    .line 38
    .line 39
    sget-object v4, Ln70/h1;->a:Ln70/h1;

    .line 40
    .line 41
    invoke-interface {p1, v0, v2, v4, v5}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    check-cast v2, Ljava/lang/String;

    .line 46
    .line 47
    const/4 v4, 0x7

    .line 48
    goto :goto_7f

    .line 49
    :cond_30
    move v9, v3

    .line 50
    move v8, v4

    .line 51
    move-object v1, v5

    .line 52
    move-object v6, v1

    .line 53
    move-object v7, v6

    .line 54
    :goto_35
    if-eqz v9, :cond_7c

    .line 55
    .line 56
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 57
    .line 58
    .line 59
    move-result v10

    .line 60
    const/4 v11, -0x1

    .line 61
    if-eq v10, v11, :cond_7a

    .line 62
    .line 63
    if-eqz v10, :cond_60

    .line 64
    .line 65
    if-eq v10, v3, :cond_55

    .line 66
    .line 67
    if-ne v10, v2, :cond_4f

    .line 68
    .line 69
    sget-object v10, Ln70/h1;->a:Ln70/h1;

    .line 70
    .line 71
    invoke-interface {p1, v0, v2, v10, v6}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    check-cast v6, Ljava/lang/String;

    .line 76
    .line 77
    or-int/lit8 v8, v8, 0x4

    .line 78
    .line 79
    goto :goto_35

    .line 80
    :cond_4f
    new-instance p1, Lj70/k;

    .line 81
    .line 82
    invoke-direct {p1, v10}, Lj70/k;-><init>(I)V

    .line 83
    .line 84
    .line 85
    throw p1

    .line 86
    :cond_55
    sget-object v10, Lyh/c;->a:Lyh/c;

    .line 87
    .line 88
    invoke-interface {p1, v0, v3, v10, v7}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v7

    .line 92
    check-cast v7, Lcom/discord/primitives/ChannelId;

    .line 93
    .line 94
    or-int/lit8 v8, v8, 0x2

    .line 95
    .line 96
    goto :goto_35

    .line 97
    :cond_60
    sget-object v10, Lyh/h;->a:Lyh/h;

    .line 98
    .line 99
    if-eqz v1, :cond_6a

    .line 100
    .line 101
    new-instance v11, Lcom/discord/primitives/MessageId;

    .line 102
    .line 103
    invoke-direct {v11, v1}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    goto :goto_6b

    .line 107
    :cond_6a
    move-object v11, v5

    .line 108
    :goto_6b
    invoke-interface {p1, v0, v4, v10, v11}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 113
    .line 114
    if-eqz v1, :cond_76

    .line 115
    .line 116
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 117
    .line 118
    goto :goto_77

    .line 119
    :cond_76
    move-object v1, v5

    .line 120
    :goto_77
    or-int/lit8 v8, v8, 0x1

    .line 121
    .line 122
    goto :goto_35

    .line 123
    :cond_7a
    move v9, v4

    .line 124
    goto :goto_35

    .line 125
    :cond_7c
    move-object v2, v6

    .line 126
    move-object v3, v7

    .line 127
    move v4, v8

    .line 128
    :goto_7f
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 129
    .line 130
    .line 131
    new-instance p1, Lad/f8;

    .line 132
    .line 133
    invoke-direct {p1, v4, v1, v3, v2}, Lad/f8;-><init>(ILjava/lang/String;Lcom/discord/primitives/ChannelId;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 5

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    new-array v1, v1, [Lj70/b;

    .line 9
    .line 10
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    aput-object v2, v1, v3

    .line 14
    .line 15
    sget-object v2, Lyh/c;->a:Lyh/c;

    .line 16
    .line 17
    const/4 v3, 0x1

    .line 18
    aput-object v2, v1, v3

    .line 19
    .line 20
    const/4 v2, 0x2

    .line 21
    aput-object v0, v1, v2

    .line 22
    .line 23
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 8

    .line 1
    check-cast p2, Lad/f8;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/d8;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/f8;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v2, p1, v0, v3, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 20
    .line 21
    .line 22
    sget-object v1, Lyh/c;->a:Lyh/c;

    .line 23
    .line 24
    iget-wide v2, p2, Lad/f8;->b:J

    .line 25
    .line 26
    new-instance v4, Lcom/discord/primitives/ChannelId;

    .line 27
    .line 28
    invoke-direct {v4, v2, v3}, Lcom/discord/primitives/ChannelId;-><init>(J)V

    .line 29
    .line 30
    .line 31
    const/4 v2, 0x1

    .line 32
    invoke-interface {p1, v0, v2, v1, v4}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 36
    .line 37
    iget-object p2, p2, Lad/f8;->c:Ljava/lang/String;

    .line 38
    .line 39
    const/4 v2, 0x2

    .line 40
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/d8;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
