###### Class ad.y3 (ad.y3)
.class public final Lad/y3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# instance fields
.field public final a:Ly9/d0;


# direct methods
.method public constructor <init>(Ly9/d0;)V
    .registers 3

    .line 1
    const-string v0, "emoji"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lad/y3;->a:Ly9/d0;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableMap;
    .registers 6

    .line 1
    iget-object v0, p0, Lad/y3;->a:Ly9/d0;

    .line 2
    .line 3
    instance-of v1, v0, Ly9/m5;

    .line 4
    .line 5
    if-eqz v1, :cond_26

    .line 6
    .line 7
    move-object v1, v0

    .line 8
    check-cast v1, Ly9/m5;

    .line 9
    .line 10
    iget-object v1, v1, Ly9/m5;->c:Ljava/lang/String;

    .line 11
    .line 12
    new-instance v2, Ll30/j;

    .line 13
    .line 14
    const-string v3, "surrogate"

    .line 15
    .line 16
    invoke-direct {v2, v3, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    check-cast v0, Ly9/m5;

    .line 20
    .line 21
    iget-object v0, v0, Ly9/m5;->b:Ljava/lang/String;

    .line 22
    .line 23
    new-instance v1, Ll30/j;

    .line 24
    .line 25
    const-string v3, "content"

    .line 26
    .line 27
    invoke-direct {v1, v3, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    filled-new-array {v2, v1}, [Ll30/j;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    goto :goto_59

    .line 39
    :cond_26
    instance-of v1, v0, Ly9/b0;

    .line 40
    .line 41
    if-eqz v1, :cond_69

    .line 42
    .line 43
    move-object v1, v0

    .line 44
    check-cast v1, Ly9/b0;

    .line 45
    .line 46
    iget-wide v1, v1, Ly9/b0;->b:J

    .line 47
    .line 48
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    new-instance v2, Ll30/j;

    .line 53
    .line 54
    const-string v3, "id"

    .line 55
    .line 56
    invoke-direct {v2, v3, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    move-object v1, v0

    .line 60
    check-cast v1, Ly9/b0;

    .line 61
    .line 62
    iget-object v1, v1, Ly9/b0;->c:Ljava/lang/String;

    .line 63
    .line 64
    new-instance v3, Ll30/j;

    .line 65
    .line 66
    const-string v4, "alt"

    .line 67
    .line 68
    invoke-direct {v3, v4, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    check-cast v0, Ly9/b0;

    .line 72
    .line 73
    iget-object v0, v0, Ly9/b0;->d:Ljava/lang/String;

    .line 74
    .line 75
    new-instance v1, Ll30/j;

    .line 76
    .line 77
    const-string v4, "src"

    .line 78
    .line 79
    invoke-direct {v1, v4, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    filled-new-array {v2, v3, v1}, [Ll30/j;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    :goto_59
    new-instance v1, Ll30/j;

    .line 91
    .line 92
    const-string v2, "node"

    .line 93
    .line 94
    invoke-direct {v1, v2, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    filled-new-array {v1}, [Ll30/j;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    return-object v0

    .line 106
    :cond_69
    new-instance v0, Lan/g;

    .line 107
    .line 108
    const/4 v1, 0x0

    .line 109
    invoke-direct {v0, v1}, Lan/g;-><init>(Z)V

    .line 110
    .line 111
    .line 112
    throw v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lad/y3;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lad/y3;

    .line 12
    .line 13
    iget-object v1, p0, Lad/y3;->a:Ly9/d0;

    .line 14
    .line 15
    iget-object p1, p1, Lad/y3;->a:Ly9/d0;

    .line 16
    .line 17
    invoke-static {v1, p1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    if-nez p1, :cond_17

    .line 22
    .line 23
    return v2

    .line 24
    :cond_17
    return v0
.end method

.method public final hashCode()I
    .registers 2

    .line 1
    iget-object v0, p0, Lad/y3;->a:Ly9/d0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "TapEmojiData(emoji="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lad/y3;->a:Ly9/d0;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ")"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0
.end method
