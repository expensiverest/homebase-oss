###### Class ad.p3 (ad.p3)
.class public final synthetic Lad/p3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/p3;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/p3;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/p3;->a:Lad/p3;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapCopyText"

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "text"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    sput-object v1, Lad/p3;->descriptor:Ll70/g;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 11

    .line 1
    sget-object v0, Lad/p3;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    sget-object v1, Lad/r3;->b:[Lkotlin/Lazy;

    .line 8
    .line 9
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x1

    .line 14
    const/4 v4, 0x0

    .line 15
    const/4 v5, 0x0

    .line 16
    if-eqz v2, :cond_20

    .line 17
    .line 18
    aget-object v1, v1, v4

    .line 19
    .line 20
    invoke-interface {v1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Lj70/b;

    .line 25
    .line 26
    invoke-interface {p1, v0, v4, v1, v5}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Ljava/lang/CharSequence;

    .line 31
    .line 32
    goto :goto_47

    .line 33
    :cond_20
    move v2, v3

    .line 34
    move v6, v4

    .line 35
    :goto_22
    if-eqz v2, :cond_45

    .line 36
    .line 37
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 38
    .line 39
    .line 40
    move-result v7

    .line 41
    const/4 v8, -0x1

    .line 42
    if-eq v7, v8, :cond_43

    .line 43
    .line 44
    if-nez v7, :cond_3d

    .line 45
    .line 46
    aget-object v6, v1, v4

    .line 47
    .line 48
    invoke-interface {v6}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    check-cast v6, Lj70/b;

    .line 53
    .line 54
    invoke-interface {p1, v0, v4, v6, v5}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    check-cast v5, Ljava/lang/CharSequence;

    .line 59
    .line 60
    move v6, v3

    .line 61
    goto :goto_22

    .line 62
    :cond_3d
    new-instance p1, Lj70/k;

    .line 63
    .line 64
    invoke-direct {p1, v7}, Lj70/k;-><init>(I)V

    .line 65
    .line 66
    .line 67
    throw p1

    .line 68
    :cond_43
    move v2, v4

    .line 69
    goto :goto_22

    .line 70
    :cond_45
    move-object v1, v5

    .line 71
    move v3, v6

    .line 72
    :goto_47
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 73
    .line 74
    .line 75
    new-instance p1, Lad/r3;

    .line 76
    .line 77
    invoke-direct {p1, v3, v1}, Lad/r3;-><init>(ILjava/lang/CharSequence;)V

    .line 78
    .line 79
    .line 80
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    sget-object v0, Lad/r3;->b:[Lkotlin/Lazy;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    new-array v1, v1, [Lj70/b;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aget-object v0, v0, v2

    .line 8
    .line 9
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    aput-object v0, v1, v2

    .line 14
    .line 15
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/r3;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/p3;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lad/r3;->b:[Lkotlin/Lazy;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    aget-object v1, v1, v2

    .line 18
    .line 19
    invoke-interface {v1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Lj70/j;

    .line 24
    .line 25
    iget-object p2, p2, Lad/r3;->a:Ljava/lang/CharSequence;

    .line 26
    .line 27
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/p3;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
