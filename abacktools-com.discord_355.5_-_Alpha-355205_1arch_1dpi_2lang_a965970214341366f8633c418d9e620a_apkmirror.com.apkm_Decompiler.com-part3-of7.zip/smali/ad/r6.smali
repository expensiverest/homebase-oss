###### Class ad.r6 (ad.r6)
.class public final Lad/r6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lad/q6;


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lad/q6;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/r6;->Companion:Lad/q6;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    and-int/lit8 p1, p1, 0x1

    if-nez p1, :cond_b

    const/4 p1, 0x0

    iput-object p1, p0, Lad/r6;->a:Ljava/lang/String;

    return-void

    :cond_b
    iput-object p2, p0, Lad/r6;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lad/r6;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final bridge a()Lcom/facebook/react/bridge/WritableMap;
    .registers 2

    .line 1
    invoke-static {p0}, Ls1/e;->J(Lui/a;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lad/r6;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lad/r6;

    .line 12
    .line 13
    iget-object p1, p1, Lad/r6;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v1, p0, Lad/r6;->a:Ljava/lang/String;

    .line 16
    .line 17
    if-nez v1, :cond_18

    .line 18
    .line 19
    if-nez p1, :cond_16

    .line 20
    .line 21
    move p1, v0

    .line 22
    goto :goto_1f

    .line 23
    :cond_16
    :goto_16
    move p1, v2

    .line 24
    goto :goto_1f

    .line 25
    :cond_18
    if-nez p1, :cond_1b

    .line 26
    .line 27
    goto :goto_16

    .line 28
    :cond_1b
    invoke-static {v1, p1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    :goto_1f
    if-nez p1, :cond_22

    .line 33
    .line 34
    return v2

    .line 35
    :cond_22
    return v0
.end method

.method public final hashCode()I
    .registers 2

    .line 1
    iget-object v0, p0, Lad/r6;->a:Ljava/lang/String;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    return v0

    .line 7
    :cond_6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lad/r6;->a:Ljava/lang/String;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const-string v0, "null"

    .line 6
    .line 7
    :cond_6
    const-string v1, "TapPreviewSharedClientThemeData(messageId="

    .line 8
    .line 9
    const-string v2, ")"

    .line 10
    .line 11
    invoke-static {v1, v0, v2}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method
