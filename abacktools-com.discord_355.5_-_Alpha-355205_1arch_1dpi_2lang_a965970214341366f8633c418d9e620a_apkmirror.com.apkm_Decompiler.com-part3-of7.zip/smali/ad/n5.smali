###### Class ad.n5 (ad.n5)
.class public final synthetic Lad/n5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/n5;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/n5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/n5;->a:Lad/n5;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapMentionData"

    .line 11
    .line 12
    const/4 v3, 0x6

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "userId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "roleName"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "parsedUserId"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "roleId"

    .line 38
    .line 39
    const/4 v2, 0x1

    .line 40
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v0, "guildId"

    .line 44
    .line 45
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    sput-object v1, Lad/n5;->descriptor:Ll70/g;

    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 26

    .line 1
    sget-object v0, Lad/n5;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v5, 0x4

    .line 16
    const/4 v6, 0x2

    .line 17
    const/4 v7, 0x1

    .line 18
    const/4 v8, 0x0

    .line 19
    const/4 v9, 0x0

    .line 20
    if-eqz v2, :cond_4b

    .line 21
    .line 22
    sget-object v2, Ln70/h1;->a:Ln70/h1;

    .line 23
    .line 24
    invoke-interface {v1, v0, v8, v2, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v8

    .line 28
    check-cast v8, Ljava/lang/String;

    .line 29
    .line 30
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v7

    .line 34
    invoke-interface {v1, v0, v6, v2, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v6

    .line 38
    check-cast v6, Ljava/lang/String;

    .line 39
    .line 40
    invoke-interface {v1, v0, v4, v2, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    check-cast v4, Ljava/lang/String;

    .line 45
    .line 46
    invoke-interface {v1, v0, v5, v2, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    check-cast v5, Ljava/lang/String;

    .line 51
    .line 52
    invoke-interface {v1, v0, v3, v2, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    check-cast v2, Ljava/lang/String;

    .line 57
    .line 58
    const/16 v3, 0x3f

    .line 59
    .line 60
    move-object/from16 v23, v2

    .line 61
    .line 62
    move/from16 v17, v3

    .line 63
    .line 64
    move-object/from16 v21, v4

    .line 65
    .line 66
    move-object/from16 v22, v5

    .line 67
    .line 68
    move-object/from16 v20, v6

    .line 69
    .line 70
    move-object/from16 v19, v7

    .line 71
    .line 72
    move-object/from16 v18, v8

    .line 73
    .line 74
    goto/16 :goto_ba

    .line 75
    .line 76
    :cond_4b
    move v15, v7

    .line 77
    move v2, v8

    .line 78
    move-object v10, v9

    .line 79
    move-object v11, v10

    .line 80
    move-object v12, v11

    .line 81
    move-object v13, v12

    .line 82
    move-object v14, v13

    .line 83
    :goto_52
    if-eqz v15, :cond_ac

    .line 84
    .line 85
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 86
    .line 87
    .line 88
    move-result v8

    .line 89
    packed-switch v8, :pswitch_data_c4

    .line 90
    .line 91
    .line 92
    new-instance v0, Lj70/k;

    .line 93
    .line 94
    invoke-direct {v0, v8}, Lj70/k;-><init>(I)V

    .line 95
    .line 96
    .line 97
    throw v0

    .line 98
    :pswitch_61
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 99
    .line 100
    invoke-interface {v1, v0, v3, v8, v14}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v8

    .line 104
    move-object v14, v8

    .line 105
    check-cast v14, Ljava/lang/String;

    .line 106
    .line 107
    or-int/lit8 v2, v2, 0x20

    .line 108
    .line 109
    :goto_6c
    const/4 v8, 0x0

    .line 110
    goto :goto_52

    .line 111
    :pswitch_6e
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 112
    .line 113
    invoke-interface {v1, v0, v5, v8, v13}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    move-object v13, v8

    .line 118
    check-cast v13, Ljava/lang/String;

    .line 119
    .line 120
    or-int/lit8 v2, v2, 0x10

    .line 121
    .line 122
    goto :goto_6c

    .line 123
    :pswitch_7a
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 124
    .line 125
    invoke-interface {v1, v0, v4, v8, v12}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v8

    .line 129
    move-object v12, v8

    .line 130
    check-cast v12, Ljava/lang/String;

    .line 131
    .line 132
    or-int/lit8 v2, v2, 0x8

    .line 133
    .line 134
    goto :goto_6c

    .line 135
    :pswitch_86
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 136
    .line 137
    invoke-interface {v1, v0, v6, v8, v11}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    move-object v11, v8

    .line 142
    check-cast v11, Ljava/lang/String;

    .line 143
    .line 144
    or-int/lit8 v2, v2, 0x4

    .line 145
    .line 146
    goto :goto_6c

    .line 147
    :pswitch_92
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v10

    .line 151
    or-int/lit8 v2, v2, 0x2

    .line 152
    .line 153
    goto :goto_6c

    .line 154
    :pswitch_99
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 155
    .line 156
    const/4 v3, 0x0

    .line 157
    invoke-interface {v1, v0, v3, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v8

    .line 161
    move-object v9, v8

    .line 162
    check-cast v9, Ljava/lang/String;

    .line 163
    .line 164
    or-int/lit8 v2, v2, 0x1

    .line 165
    .line 166
    move v8, v3

    .line 167
    :goto_a6
    const/4 v3, 0x5

    .line 168
    goto :goto_52

    .line 169
    :pswitch_a8
    const/4 v3, 0x0

    .line 170
    move v8, v3

    .line 171
    move v15, v8

    .line 172
    goto :goto_a6

    .line 173
    :cond_ac
    move/from16 v17, v2

    .line 174
    .line 175
    move-object/from16 v18, v9

    .line 176
    .line 177
    move-object/from16 v19, v10

    .line 178
    .line 179
    move-object/from16 v20, v11

    .line 180
    .line 181
    move-object/from16 v21, v12

    .line 182
    .line 183
    move-object/from16 v22, v13

    .line 184
    .line 185
    move-object/from16 v23, v14

    .line 186
    .line 187
    :goto_ba
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 188
    .line 189
    .line 190
    new-instance v16, Lad/p5;

    .line 191
    .line 192
    invoke-direct/range {v16 .. v23}, Lad/p5;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    return-object v16

    .line 196
    nop

    .line 197
    :pswitch_data_c4
    .packed-switch -0x1
        :pswitch_a8
        :pswitch_99
        :pswitch_92
        :pswitch_86
        :pswitch_7a
        :pswitch_6e
        :pswitch_61
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 9

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    const/4 v6, 0x6

    .line 24
    new-array v6, v6, [Lj70/b;

    .line 25
    .line 26
    const/4 v7, 0x0

    .line 27
    aput-object v1, v6, v7

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    aput-object v0, v6, v1

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    aput-object v2, v6, v0

    .line 34
    .line 35
    const/4 v0, 0x3

    .line 36
    aput-object v3, v6, v0

    .line 37
    .line 38
    const/4 v0, 0x4

    .line 39
    aput-object v4, v6, v0

    .line 40
    .line 41
    const/4 v0, 0x5

    .line 42
    aput-object v5, v6, v0

    .line 43
    .line 44
    return-object v6
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 9

    .line 1
    check-cast p2, Lad/p5;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/n5;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 15
    .line 16
    iget-object v2, p2, Lad/p5;->a:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v3, p2, Lad/p5;->f:Ljava/lang/String;

    .line 19
    .line 20
    iget-object v4, p2, Lad/p5;->e:Ljava/lang/String;

    .line 21
    .line 22
    const/4 v5, 0x0

    .line 23
    invoke-interface {p1, v0, v5, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    const/4 v2, 0x1

    .line 27
    iget-object v5, p2, Lad/p5;->b:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v2, v5}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const/4 v2, 0x2

    .line 33
    iget-object v5, p2, Lad/p5;->c:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v2, v1, v5}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v2, 0x3

    .line 39
    iget-object p2, p2, Lad/p5;->d:Ljava/lang/String;

    .line 40
    .line 41
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    const/4 p2, 0x4

    .line 45
    invoke-interface {p1, v0, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_33

    .line 50
    .line 51
    goto :goto_35

    .line 52
    :cond_33
    if-eqz v4, :cond_38

    .line 53
    .line 54
    :goto_35
    invoke-interface {p1, v0, p2, v1, v4}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    const/4 p2, 0x5

    .line 58
    invoke-interface {p1, v0, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    if-eqz v2, :cond_40

    .line 63
    .line 64
    goto :goto_42

    .line 65
    :cond_40
    if-eqz v3, :cond_45

    .line 66
    .line 67
    :goto_42
    invoke-interface {p1, v0, p2, v1, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :cond_45
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 71
    .line 72
    .line 73
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/n5;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
