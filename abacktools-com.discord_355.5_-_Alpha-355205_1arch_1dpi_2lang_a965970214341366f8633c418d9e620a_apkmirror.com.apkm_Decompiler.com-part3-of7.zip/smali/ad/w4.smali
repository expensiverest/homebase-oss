###### Class ad.w4 (ad.w4)
.class public final synthetic Lad/w4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/w4;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/w4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/w4;->a:Lad/w4;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapInlineForwardData"

    .line 11
    .line 12
    const/4 v3, 0x6

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "channelId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "messageId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "targetKind"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "embedIndex"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "triggerHaptic"

    .line 38
    .line 39
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "location"

    .line 43
    .line 44
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    sput-object v1, Lad/w4;->descriptor:Ll70/g;

    .line 48
    .line 49
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 26

    .line 1
    sget-object v0, Lad/w4;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v5, 0x4

    .line 16
    const/4 v6, 0x2

    .line 17
    const/4 v7, 0x1

    .line 18
    const/4 v8, 0x0

    .line 19
    const/4 v9, 0x0

    .line 20
    if-eqz v2, :cond_4b

    .line 21
    .line 22
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v7

    .line 30
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v6

    .line 34
    sget-object v8, Ln70/e0;->a:Ln70/e0;

    .line 35
    .line 36
    invoke-interface {v1, v0, v4, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    check-cast v4, Ljava/lang/Integer;

    .line 41
    .line 42
    sget-object v8, Ln70/g;->a:Ln70/g;

    .line 43
    .line 44
    invoke-interface {v1, v0, v5, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    check-cast v5, Ljava/lang/Boolean;

    .line 49
    .line 50
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 51
    .line 52
    invoke-interface {v1, v0, v3, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Ljava/lang/String;

    .line 57
    .line 58
    const/16 v8, 0x3f

    .line 59
    .line 60
    move-object/from16 v18, v2

    .line 61
    .line 62
    move-object/from16 v23, v3

    .line 63
    .line 64
    move-object/from16 v21, v4

    .line 65
    .line 66
    move-object/from16 v22, v5

    .line 67
    .line 68
    move-object/from16 v20, v6

    .line 69
    .line 70
    move-object/from16 v19, v7

    .line 71
    .line 72
    move/from16 v17, v8

    .line 73
    .line 74
    goto/16 :goto_ad

    .line 75
    .line 76
    :cond_4b
    move v15, v7

    .line 77
    move v2, v8

    .line 78
    move-object v10, v9

    .line 79
    move-object v11, v10

    .line 80
    move-object v12, v11

    .line 81
    move-object v13, v12

    .line 82
    move-object v14, v13

    .line 83
    :goto_52
    if-eqz v15, :cond_9f

    .line 84
    .line 85
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 86
    .line 87
    .line 88
    move-result v8

    .line 89
    packed-switch v8, :pswitch_data_b6

    .line 90
    .line 91
    .line 92
    new-instance v0, Lj70/k;

    .line 93
    .line 94
    invoke-direct {v0, v8}, Lj70/k;-><init>(I)V

    .line 95
    .line 96
    .line 97
    throw v0

    .line 98
    :pswitch_61
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 99
    .line 100
    invoke-interface {v1, v0, v3, v8, v14}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v8

    .line 104
    move-object v14, v8

    .line 105
    check-cast v14, Ljava/lang/String;

    .line 106
    .line 107
    or-int/lit8 v2, v2, 0x20

    .line 108
    .line 109
    :goto_6c
    const/4 v8, 0x0

    .line 110
    goto :goto_52

    .line 111
    :pswitch_6e
    sget-object v8, Ln70/g;->a:Ln70/g;

    .line 112
    .line 113
    invoke-interface {v1, v0, v5, v8, v13}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    move-object v13, v8

    .line 118
    check-cast v13, Ljava/lang/Boolean;

    .line 119
    .line 120
    or-int/lit8 v2, v2, 0x10

    .line 121
    .line 122
    goto :goto_6c

    .line 123
    :pswitch_7a
    sget-object v8, Ln70/e0;->a:Ln70/e0;

    .line 124
    .line 125
    invoke-interface {v1, v0, v4, v8, v12}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v8

    .line 129
    move-object v12, v8

    .line 130
    check-cast v12, Ljava/lang/Integer;

    .line 131
    .line 132
    or-int/lit8 v2, v2, 0x8

    .line 133
    .line 134
    goto :goto_6c

    .line 135
    :pswitch_86
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v11

    .line 139
    or-int/lit8 v2, v2, 0x4

    .line 140
    .line 141
    goto :goto_6c

    .line 142
    :pswitch_8d
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v10

    .line 146
    or-int/lit8 v2, v2, 0x2

    .line 147
    .line 148
    goto :goto_6c

    .line 149
    :pswitch_94
    const/4 v8, 0x0

    .line 150
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v9

    .line 154
    or-int/lit8 v2, v2, 0x1

    .line 155
    .line 156
    goto :goto_52

    .line 157
    :pswitch_9c
    const/4 v8, 0x0

    .line 158
    move v15, v8

    .line 159
    goto :goto_52

    .line 160
    :cond_9f
    move/from16 v17, v2

    .line 161
    .line 162
    move-object/from16 v18, v9

    .line 163
    .line 164
    move-object/from16 v19, v10

    .line 165
    .line 166
    move-object/from16 v20, v11

    .line 167
    .line 168
    move-object/from16 v21, v12

    .line 169
    .line 170
    move-object/from16 v22, v13

    .line 171
    .line 172
    move-object/from16 v23, v14

    .line 173
    .line 174
    :goto_ad
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 175
    .line 176
    .line 177
    new-instance v16, Lad/y4;

    .line 178
    .line 179
    invoke-direct/range {v16 .. v23}, Lad/y4;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    return-object v16

    .line 183
    :pswitch_data_b6
    .packed-switch -0x1
        :pswitch_9c
        :pswitch_94
        :pswitch_8d
        :pswitch_86
        :pswitch_7a
        :pswitch_6e
        :pswitch_61
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 7

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 4
    .line 5
    invoke-static {v1}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    sget-object v2, Ln70/g;->a:Ln70/g;

    .line 10
    .line 11
    invoke-static {v2}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    const/4 v4, 0x6

    .line 20
    new-array v4, v4, [Lj70/b;

    .line 21
    .line 22
    const/4 v5, 0x0

    .line 23
    aput-object v0, v4, v5

    .line 24
    .line 25
    const/4 v5, 0x1

    .line 26
    aput-object v0, v4, v5

    .line 27
    .line 28
    const/4 v5, 0x2

    .line 29
    aput-object v0, v4, v5

    .line 30
    .line 31
    const/4 v0, 0x3

    .line 32
    aput-object v1, v4, v0

    .line 33
    .line 34
    const/4 v0, 0x4

    .line 35
    aput-object v2, v4, v0

    .line 36
    .line 37
    const/4 v0, 0x5

    .line 38
    aput-object v3, v4, v0

    .line 39
    .line 40
    return-object v4
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/y4;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/w4;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lad/y4;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-object v2, p2, Lad/y4;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object v2, p2, Lad/y4;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 33
    .line 34
    iget-object v2, p2, Lad/y4;->d:Ljava/lang/Integer;

    .line 35
    .line 36
    const/4 v3, 0x3

    .line 37
    invoke-interface {p1, v0, v3, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 41
    .line 42
    iget-object v2, p2, Lad/y4;->e:Ljava/lang/Boolean;

    .line 43
    .line 44
    const/4 v3, 0x4

    .line 45
    invoke-interface {p1, v0, v3, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 49
    .line 50
    iget-object p2, p2, Lad/y4;->f:Ljava/lang/String;

    .line 51
    .line 52
    const/4 v2, 0x5

    .line 53
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 57
    .line 58
    .line 59
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/w4;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
