###### Class ad.t6 (ad.t6)
.class public final synthetic Lad/t6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/t6;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/t6;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/t6;->a:Lad/t6;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapReferralRedeemData"

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "referralId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    sput-object v1, Lad/t6;->descriptor:Ll70/g;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 10

    .line 1
    sget-object v0, Lad/t6;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_18

    .line 15
    .line 16
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 17
    .line 18
    invoke-interface {p1, v0, v3, v1, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Ljava/lang/String;

    .line 23
    .line 24
    goto :goto_39

    .line 25
    :cond_18
    move v1, v2

    .line 26
    move v5, v3

    .line 27
    :goto_1a
    if-eqz v1, :cond_37

    .line 28
    .line 29
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 30
    .line 31
    .line 32
    move-result v6

    .line 33
    const/4 v7, -0x1

    .line 34
    if-eq v6, v7, :cond_35

    .line 35
    .line 36
    if-nez v6, :cond_2f

    .line 37
    .line 38
    sget-object v5, Ln70/h1;->a:Ln70/h1;

    .line 39
    .line 40
    invoke-interface {p1, v0, v3, v5, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    check-cast v4, Ljava/lang/String;

    .line 45
    .line 46
    move v5, v2

    .line 47
    goto :goto_1a

    .line 48
    :cond_2f
    new-instance p1, Lj70/k;

    .line 49
    .line 50
    invoke-direct {p1, v6}, Lj70/k;-><init>(I)V

    .line 51
    .line 52
    .line 53
    throw p1

    .line 54
    :cond_35
    move v1, v3

    .line 55
    goto :goto_1a

    .line 56
    :cond_37
    move-object v1, v4

    .line 57
    move v2, v5

    .line 58
    :goto_39
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 59
    .line 60
    .line 61
    new-instance p1, Lad/v6;

    .line 62
    .line 63
    invoke-direct {p1, v2, v1}, Lad/v6;-><init>(ILjava/lang/String;)V

    .line 64
    .line 65
    .line 66
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x1

    .line 8
    new-array v1, v1, [Lj70/b;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    aput-object v0, v1, v2

    .line 12
    .line 13
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/v6;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/t6;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 15
    .line 16
    iget-object p2, p2, Lad/v6;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/t6;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
