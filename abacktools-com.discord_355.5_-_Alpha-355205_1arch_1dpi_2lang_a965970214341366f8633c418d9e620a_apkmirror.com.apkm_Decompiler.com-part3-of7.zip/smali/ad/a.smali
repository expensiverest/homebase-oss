###### Class ad.a (ad.a)
.class public final synthetic Lad/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/a;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/a;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/a;->a:Lad/a;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.ChatScrollPositionEvent"

    .line 11
    .line 12
    const/16 v3, 0xc

    .line 13
    .line 14
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 15
    .line 16
    .line 17
    const-string v0, "isAtBottom"

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 21
    .line 22
    .line 23
    const-string v0, "isNearBottom"

    .line 24
    .line 25
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 26
    .line 27
    .line 28
    const-string v0, "isNearTop"

    .line 29
    .line 30
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    const-string v0, "dragging"

    .line 34
    .line 35
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    const-string v0, "decelerating"

    .line 39
    .line 40
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v0, "shouldShowJumpToPresent"

    .line 44
    .line 45
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    const-string v0, "isFirstMessageVisible"

    .line 49
    .line 50
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 51
    .line 52
    .line 53
    const-string v0, "firstVisibleMessageIndex"

    .line 54
    .line 55
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 56
    .line 57
    .line 58
    const-string v0, "firstVisibleMessagePercentVisible"

    .line 59
    .line 60
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 61
    .line 62
    .line 63
    const-string v0, "lastVisibleMessageIndex"

    .line 64
    .line 65
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 66
    .line 67
    .line 68
    const-string v0, "lastVisibleMessagePercentVisible"

    .line 69
    .line 70
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 71
    .line 72
    .line 73
    const-string v0, "changesetUpdateId"

    .line 74
    .line 75
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 76
    .line 77
    .line 78
    sput-object v1, Lad/a;->descriptor:Ll70/g;

    .line 79
    .line 80
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 42

    .line 1
    sget-object v0, Lad/a;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/16 v3, 0xb

    .line 14
    .line 15
    const/16 v4, 0xa

    .line 16
    .line 17
    const/16 v5, 0x9

    .line 18
    .line 19
    const/4 v6, 0x7

    .line 20
    const/4 v7, 0x6

    .line 21
    const/4 v8, 0x5

    .line 22
    const/4 v9, 0x3

    .line 23
    const/16 v10, 0x8

    .line 24
    .line 25
    const/4 v11, 0x4

    .line 26
    const/4 v12, 0x2

    .line 27
    const/4 v13, 0x1

    .line 28
    const/4 v14, 0x0

    .line 29
    const/4 v15, 0x0

    .line 30
    if-eqz v2, :cond_73

    .line 31
    .line 32
    invoke-interface {v1, v0, v14}, Lm70/a;->v(Ll70/g;I)Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    invoke-interface {v1, v0, v13}, Lm70/a;->v(Ll70/g;I)Z

    .line 37
    .line 38
    .line 39
    move-result v13

    .line 40
    invoke-interface {v1, v0, v12}, Lm70/a;->v(Ll70/g;I)Z

    .line 41
    .line 42
    .line 43
    move-result v12

    .line 44
    invoke-interface {v1, v0, v9}, Lm70/a;->v(Ll70/g;I)Z

    .line 45
    .line 46
    .line 47
    move-result v9

    .line 48
    invoke-interface {v1, v0, v11}, Lm70/a;->v(Ll70/g;I)Z

    .line 49
    .line 50
    .line 51
    move-result v11

    .line 52
    invoke-interface {v1, v0, v8}, Lm70/a;->v(Ll70/g;I)Z

    .line 53
    .line 54
    .line 55
    move-result v8

    .line 56
    invoke-interface {v1, v0, v7}, Lm70/a;->v(Ll70/g;I)Z

    .line 57
    .line 58
    .line 59
    move-result v7

    .line 60
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 61
    .line 62
    .line 63
    move-result v6

    .line 64
    sget-object v14, Ln70/r;->a:Ln70/r;

    .line 65
    .line 66
    invoke-interface {v1, v0, v10, v14, v15}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v10

    .line 70
    check-cast v10, Ljava/lang/Double;

    .line 71
    .line 72
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 73
    .line 74
    .line 75
    move-result v5

    .line 76
    invoke-interface {v1, v0, v4, v14, v15}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    check-cast v4, Ljava/lang/Double;

    .line 81
    .line 82
    invoke-interface {v1, v0, v3}, Lm70/a;->p(Ll70/g;I)I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    const/16 v14, 0xfff

    .line 87
    .line 88
    move/from16 v39, v3

    .line 89
    .line 90
    move-object/from16 v38, v4

    .line 91
    .line 92
    move/from16 v37, v5

    .line 93
    .line 94
    move/from16 v35, v6

    .line 95
    .line 96
    move/from16 v34, v7

    .line 97
    .line 98
    move/from16 v33, v8

    .line 99
    .line 100
    move/from16 v31, v9

    .line 101
    .line 102
    move-object/from16 v36, v10

    .line 103
    .line 104
    move/from16 v32, v11

    .line 105
    .line 106
    move/from16 v30, v12

    .line 107
    .line 108
    move/from16 v29, v13

    .line 109
    .line 110
    :goto_6d
    move/from16 v28, v2

    .line 111
    .line 112
    move/from16 v27, v14

    .line 113
    .line 114
    goto/16 :goto_123

    .line 115
    .line 116
    :cond_73
    move/from16 v25, v13

    .line 117
    .line 118
    move v2, v14

    .line 119
    move/from16 v16, v2

    .line 120
    .line 121
    move/from16 v17, v16

    .line 122
    .line 123
    move/from16 v18, v17

    .line 124
    .line 125
    move/from16 v19, v18

    .line 126
    .line 127
    move/from16 v20, v19

    .line 128
    .line 129
    move/from16 v21, v20

    .line 130
    .line 131
    move/from16 v22, v21

    .line 132
    .line 133
    move/from16 v23, v22

    .line 134
    .line 135
    move-object v12, v15

    .line 136
    move-object v13, v12

    .line 137
    move/from16 v15, v23

    .line 138
    .line 139
    :goto_8a
    if-eqz v25, :cond_10b

    .line 140
    .line 141
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 142
    .line 143
    .line 144
    move-result v9

    .line 145
    packed-switch v9, :pswitch_data_12c

    .line 146
    .line 147
    .line 148
    new-instance v0, Lj70/k;

    .line 149
    .line 150
    invoke-direct {v0, v9}, Lj70/k;-><init>(I)V

    .line 151
    .line 152
    .line 153
    throw v0

    .line 154
    :pswitch_99
    invoke-interface {v1, v0, v3}, Lm70/a;->p(Ll70/g;I)I

    .line 155
    .line 156
    .line 157
    move-result v15

    .line 158
    or-int/lit16 v14, v14, 0x800

    .line 159
    .line 160
    :goto_9f
    const/4 v9, 0x3

    .line 161
    goto :goto_8a

    .line 162
    :pswitch_a1
    sget-object v9, Ln70/r;->a:Ln70/r;

    .line 163
    .line 164
    invoke-interface {v1, v0, v4, v9, v12}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v9

    .line 168
    move-object v12, v9

    .line 169
    check-cast v12, Ljava/lang/Double;

    .line 170
    .line 171
    or-int/lit16 v14, v14, 0x400

    .line 172
    .line 173
    goto :goto_9f

    .line 174
    :pswitch_ad
    invoke-interface {v1, v0, v5}, Lm70/a;->p(Ll70/g;I)I

    .line 175
    .line 176
    .line 177
    move-result v16

    .line 178
    or-int/lit16 v14, v14, 0x200

    .line 179
    .line 180
    goto :goto_9f

    .line 181
    :pswitch_b4
    sget-object v9, Ln70/r;->a:Ln70/r;

    .line 182
    .line 183
    invoke-interface {v1, v0, v10, v9, v13}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v9

    .line 187
    move-object v13, v9

    .line 188
    check-cast v13, Ljava/lang/Double;

    .line 189
    .line 190
    or-int/lit16 v14, v14, 0x100

    .line 191
    .line 192
    goto :goto_9f

    .line 193
    :pswitch_c0
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 194
    .line 195
    .line 196
    move-result v17

    .line 197
    or-int/lit16 v14, v14, 0x80

    .line 198
    .line 199
    goto :goto_9f

    .line 200
    :pswitch_c7
    invoke-interface {v1, v0, v7}, Lm70/a;->v(Ll70/g;I)Z

    .line 201
    .line 202
    .line 203
    move-result v18

    .line 204
    or-int/lit8 v14, v14, 0x40

    .line 205
    .line 206
    goto :goto_9f

    .line 207
    :pswitch_ce
    invoke-interface {v1, v0, v8}, Lm70/a;->v(Ll70/g;I)Z

    .line 208
    .line 209
    .line 210
    move-result v19

    .line 211
    or-int/lit8 v14, v14, 0x20

    .line 212
    .line 213
    goto :goto_9f

    .line 214
    :pswitch_d5
    invoke-interface {v1, v0, v11}, Lm70/a;->v(Ll70/g;I)Z

    .line 215
    .line 216
    .line 217
    move-result v21

    .line 218
    or-int/lit8 v14, v14, 0x10

    .line 219
    .line 220
    goto :goto_9f

    .line 221
    :pswitch_dc
    const/4 v9, 0x3

    .line 222
    invoke-interface {v1, v0, v9}, Lm70/a;->v(Ll70/g;I)Z

    .line 223
    .line 224
    .line 225
    move-result v20

    .line 226
    or-int/lit8 v14, v14, 0x8

    .line 227
    .line 228
    goto :goto_8a

    .line 229
    :pswitch_e4
    const/4 v3, 0x2

    .line 230
    const/4 v9, 0x3

    .line 231
    invoke-interface {v1, v0, v3}, Lm70/a;->v(Ll70/g;I)Z

    .line 232
    .line 233
    .line 234
    move-result v22

    .line 235
    or-int/lit8 v14, v14, 0x4

    .line 236
    .line 237
    :goto_ec
    const/16 v3, 0xb

    .line 238
    .line 239
    goto :goto_8a

    .line 240
    :pswitch_ef
    const/4 v3, 0x1

    .line 241
    const/4 v9, 0x3

    .line 242
    invoke-interface {v1, v0, v3}, Lm70/a;->v(Ll70/g;I)Z

    .line 243
    .line 244
    .line 245
    move-result v23

    .line 246
    or-int/lit8 v14, v14, 0x2

    .line 247
    .line 248
    goto :goto_ec

    .line 249
    :pswitch_f8
    const/4 v2, 0x0

    .line 250
    const/4 v3, 0x1

    .line 251
    const/4 v9, 0x3

    .line 252
    invoke-interface {v1, v0, v2}, Lm70/a;->v(Ll70/g;I)Z

    .line 253
    .line 254
    .line 255
    move-result v24

    .line 256
    or-int/lit8 v14, v14, 0x1

    .line 257
    .line 258
    move/from16 v2, v24

    .line 259
    .line 260
    goto :goto_ec

    .line 261
    :pswitch_104
    const/4 v3, 0x1

    .line 262
    const/4 v9, 0x3

    .line 263
    const/16 v24, 0x0

    .line 264
    .line 265
    move/from16 v25, v24

    .line 266
    .line 267
    goto :goto_ec

    .line 268
    :cond_10b
    move-object/from16 v38, v12

    .line 269
    .line 270
    move-object/from16 v36, v13

    .line 271
    .line 272
    move/from16 v39, v15

    .line 273
    .line 274
    move/from16 v37, v16

    .line 275
    .line 276
    move/from16 v35, v17

    .line 277
    .line 278
    move/from16 v34, v18

    .line 279
    .line 280
    move/from16 v33, v19

    .line 281
    .line 282
    move/from16 v31, v20

    .line 283
    .line 284
    move/from16 v32, v21

    .line 285
    .line 286
    move/from16 v30, v22

    .line 287
    .line 288
    move/from16 v29, v23

    .line 289
    .line 290
    goto/16 :goto_6d

    .line 291
    .line 292
    :goto_123
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 293
    .line 294
    .line 295
    new-instance v26, Lad/c;

    .line 296
    .line 297
    invoke-direct/range {v26 .. v39}, Lad/c;-><init>(IZZZZZZZILjava/lang/Double;ILjava/lang/Double;I)V

    .line 298
    .line 299
    .line 300
    return-object v26

    .line 301
    :pswitch_data_12c
    .packed-switch -0x1
        :pswitch_104
        :pswitch_f8
        :pswitch_ef
        :pswitch_e4
        :pswitch_dc
        :pswitch_d5
        :pswitch_ce
        :pswitch_c7
        :pswitch_c0
        :pswitch_b4
        :pswitch_ad
        :pswitch_a1
        :pswitch_99
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 6

    .line 1
    sget-object v0, Ln70/r;->a:Ln70/r;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/16 v2, 0xc

    .line 12
    .line 13
    new-array v2, v2, [Lj70/b;

    .line 14
    .line 15
    sget-object v3, Ln70/g;->a:Ln70/g;

    .line 16
    .line 17
    const/4 v4, 0x0

    .line 18
    aput-object v3, v2, v4

    .line 19
    .line 20
    const/4 v4, 0x1

    .line 21
    aput-object v3, v2, v4

    .line 22
    .line 23
    const/4 v4, 0x2

    .line 24
    aput-object v3, v2, v4

    .line 25
    .line 26
    const/4 v4, 0x3

    .line 27
    aput-object v3, v2, v4

    .line 28
    .line 29
    const/4 v4, 0x4

    .line 30
    aput-object v3, v2, v4

    .line 31
    .line 32
    const/4 v4, 0x5

    .line 33
    aput-object v3, v2, v4

    .line 34
    .line 35
    const/4 v4, 0x6

    .line 36
    aput-object v3, v2, v4

    .line 37
    .line 38
    sget-object v3, Ln70/e0;->a:Ln70/e0;

    .line 39
    .line 40
    const/4 v4, 0x7

    .line 41
    aput-object v3, v2, v4

    .line 42
    .line 43
    const/16 v4, 0x8

    .line 44
    .line 45
    aput-object v1, v2, v4

    .line 46
    .line 47
    const/16 v1, 0x9

    .line 48
    .line 49
    aput-object v3, v2, v1

    .line 50
    .line 51
    const/16 v1, 0xa

    .line 52
    .line 53
    aput-object v0, v2, v1

    .line 54
    .line 55
    const/16 v0, 0xb

    .line 56
    .line 57
    aput-object v3, v2, v0

    .line 58
    .line 59
    return-object v2
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/c;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/a;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-boolean v2, p2, Lad/c;->a:Z

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-boolean v2, p2, Lad/c;->b:Z

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-boolean v2, p2, Lad/c;->c:Z

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    iget-boolean v2, p2, Lad/c;->d:Z

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 36
    .line 37
    .line 38
    const/4 v1, 0x4

    .line 39
    iget-boolean v2, p2, Lad/c;->e:Z

    .line 40
    .line 41
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 42
    .line 43
    .line 44
    const/4 v1, 0x5

    .line 45
    iget-boolean v2, p2, Lad/c;->f:Z

    .line 46
    .line 47
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 48
    .line 49
    .line 50
    const/4 v1, 0x6

    .line 51
    iget-boolean v2, p2, Lad/c;->g:Z

    .line 52
    .line 53
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 54
    .line 55
    .line 56
    const/4 v1, 0x7

    .line 57
    iget v2, p2, Lad/c;->h:I

    .line 58
    .line 59
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 60
    .line 61
    .line 62
    sget-object v1, Ln70/r;->a:Ln70/r;

    .line 63
    .line 64
    iget-object v2, p2, Lad/c;->i:Ljava/lang/Double;

    .line 65
    .line 66
    const/16 v3, 0x8

    .line 67
    .line 68
    invoke-interface {p1, v0, v3, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    const/16 v2, 0x9

    .line 72
    .line 73
    iget v3, p2, Lad/c;->j:I

    .line 74
    .line 75
    invoke-interface {p1, v2, v3, v0}, Lm70/b;->n(IILl70/g;)V

    .line 76
    .line 77
    .line 78
    const/16 v2, 0xa

    .line 79
    .line 80
    iget-object v3, p2, Lad/c;->k:Ljava/lang/Double;

    .line 81
    .line 82
    invoke-interface {p1, v0, v2, v1, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    const/16 v1, 0xb

    .line 86
    .line 87
    iget p2, p2, Lad/c;->l:I

    .line 88
    .line 89
    invoke-interface {p1, v1, p2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 90
    .line 91
    .line 92
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 93
    .line 94
    .line 95
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/a;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
