###### Class ad.c4 (ad.c4)
.class public final synthetic Lad/c4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/c4;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/c4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/c4;->a:Lad/c4;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapForwardFooterData"

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "snapshotIndex"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "messageId"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lad/c4;->descriptor:Ll70/g;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 13

    .line 1
    sget-object v0, Lad/c4;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x2

    .line 12
    const/4 v3, 0x1

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_1d

    .line 15
    .line 16
    invoke-interface {p1, v0, v4}, Lm70/a;->p(Ll70/g;I)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-interface {p1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    const/4 v4, 0x7

    .line 29
    goto :goto_52

    .line 30
    :cond_1d
    const/4 v1, 0x0

    .line 31
    move-object v5, v1

    .line 32
    move-object v6, v5

    .line 33
    move v8, v3

    .line 34
    move v1, v4

    .line 35
    move v7, v1

    .line 36
    :goto_23
    if-eqz v8, :cond_4f

    .line 37
    .line 38
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 39
    .line 40
    .line 41
    move-result v9

    .line 42
    const/4 v10, -0x1

    .line 43
    if-eq v9, v10, :cond_4d

    .line 44
    .line 45
    if-eqz v9, :cond_46

    .line 46
    .line 47
    if-eq v9, v3, :cond_3f

    .line 48
    .line 49
    if-ne v9, v2, :cond_39

    .line 50
    .line 51
    invoke-interface {p1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    or-int/lit8 v7, v7, 0x4

    .line 56
    .line 57
    goto :goto_23

    .line 58
    :cond_39
    new-instance p1, Lj70/k;

    .line 59
    .line 60
    invoke-direct {p1, v9}, Lj70/k;-><init>(I)V

    .line 61
    .line 62
    .line 63
    throw p1

    .line 64
    :cond_3f
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    or-int/lit8 v7, v7, 0x2

    .line 69
    .line 70
    goto :goto_23

    .line 71
    :cond_46
    invoke-interface {p1, v0, v4}, Lm70/a;->p(Ll70/g;I)I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    or-int/lit8 v7, v7, 0x1

    .line 76
    .line 77
    goto :goto_23

    .line 78
    :cond_4d
    move v8, v4

    .line 79
    goto :goto_23

    .line 80
    :cond_4f
    move-object v2, v5

    .line 81
    move-object v3, v6

    .line 82
    move v4, v7

    .line 83
    :goto_52
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 84
    .line 85
    .line 86
    new-instance p1, Lad/e4;

    .line 87
    .line 88
    invoke-direct {p1, v3, v4, v1, v2}, Lad/e4;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    .line 89
    .line 90
    .line 91
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    aput-object v1, v0, v2

    .line 16
    .line 17
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/e4;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/c4;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget v2, p2, Lad/e4;->a:I

    .line 16
    .line 17
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-object v2, p2, Lad/e4;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object p2, p2, Lad/e4;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/c4;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
