###### Class ad.h1 (ad.h1)
.class public final synthetic Lad/h1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/h1;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/h1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/h1;->a:Lad/h1;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.MediaAttachmentPlaybackEndedData"

    .line 11
    .line 12
    const/4 v3, 0x7

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "totalDurationSecs"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "endDurationSecs"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "senderUserId"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "durationListeningSecs"

    .line 38
    .line 39
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "isVoiceMessage"

    .line 43
    .line 44
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    const-string v0, "attachmentId"

    .line 48
    .line 49
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 50
    .line 51
    .line 52
    sput-object v1, Lad/h1;->descriptor:Ll70/g;

    .line 53
    .line 54
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 30

    .line 1
    sget-object v0, Lad/h1;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x6

    .line 14
    const/4 v4, 0x5

    .line 15
    const/4 v5, 0x3

    .line 16
    const/4 v6, 0x4

    .line 17
    const/4 v7, 0x2

    .line 18
    const/4 v8, 0x1

    .line 19
    const/4 v9, 0x0

    .line 20
    const/4 v10, 0x0

    .line 21
    if-eqz v2, :cond_54

    .line 22
    .line 23
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 24
    .line 25
    invoke-interface {v1, v0, v9, v2, v10}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 30
    .line 31
    if-eqz v2, :cond_23

    .line 32
    .line 33
    iget-object v2, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 34
    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move-object v2, v10

    .line 37
    :goto_24
    invoke-interface {v1, v0, v8}, Lm70/a;->y(Ll70/g;I)F

    .line 38
    .line 39
    .line 40
    move-result v8

    .line 41
    invoke-interface {v1, v0, v7}, Lm70/a;->y(Ll70/g;I)F

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    sget-object v9, Lyh/p;->a:Lyh/p;

    .line 46
    .line 47
    invoke-interface {v1, v0, v5, v9, v10}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    check-cast v5, Lcom/discord/primitives/UserId;

    .line 52
    .line 53
    invoke-interface {v1, v0, v6}, Lm70/a;->y(Ll70/g;I)F

    .line 54
    .line 55
    .line 56
    move-result v6

    .line 57
    invoke-interface {v1, v0, v4}, Lm70/a;->v(Ll70/g;I)Z

    .line 58
    .line 59
    .line 60
    move-result v4

    .line 61
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    const/16 v9, 0x7f

    .line 66
    .line 67
    move-object/from16 v27, v3

    .line 68
    .line 69
    move/from16 v26, v4

    .line 70
    .line 71
    move-object/from16 v24, v5

    .line 72
    .line 73
    move/from16 v25, v6

    .line 74
    .line 75
    move/from16 v23, v7

    .line 76
    .line 77
    move/from16 v22, v8

    .line 78
    .line 79
    move/from16 v20, v9

    .line 80
    .line 81
    :goto_50
    move-object/from16 v21, v2

    .line 82
    .line 83
    goto/16 :goto_cd

    .line 84
    .line 85
    :cond_54
    const/4 v2, 0x0

    .line 86
    move v14, v2

    .line 87
    move v15, v14

    .line 88
    move/from16 v16, v15

    .line 89
    .line 90
    move/from16 v18, v8

    .line 91
    .line 92
    move v12, v9

    .line 93
    move/from16 v17, v12

    .line 94
    .line 95
    move-object v2, v10

    .line 96
    move-object v11, v2

    .line 97
    move-object v13, v11

    .line 98
    :goto_61
    if-eqz v18, :cond_be

    .line 99
    .line 100
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 101
    .line 102
    .line 103
    move-result v10

    .line 104
    packed-switch v10, :pswitch_data_d6

    .line 105
    .line 106
    .line 107
    new-instance v0, Lj70/k;

    .line 108
    .line 109
    invoke-direct {v0, v10}, Lj70/k;-><init>(I)V

    .line 110
    .line 111
    .line 112
    throw v0

    .line 113
    :pswitch_70
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v11

    .line 117
    or-int/lit8 v17, v17, 0x40

    .line 118
    .line 119
    :goto_76
    const/4 v10, 0x0

    .line 120
    goto :goto_61

    .line 121
    :pswitch_78
    invoke-interface {v1, v0, v4}, Lm70/a;->v(Ll70/g;I)Z

    .line 122
    .line 123
    .line 124
    move-result v12

    .line 125
    or-int/lit8 v17, v17, 0x20

    .line 126
    .line 127
    goto :goto_76

    .line 128
    :pswitch_7f
    invoke-interface {v1, v0, v6}, Lm70/a;->y(Ll70/g;I)F

    .line 129
    .line 130
    .line 131
    move-result v14

    .line 132
    or-int/lit8 v17, v17, 0x10

    .line 133
    .line 134
    goto :goto_76

    .line 135
    :pswitch_86
    sget-object v10, Lyh/p;->a:Lyh/p;

    .line 136
    .line 137
    invoke-interface {v1, v0, v5, v10, v13}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v10

    .line 141
    move-object v13, v10

    .line 142
    check-cast v13, Lcom/discord/primitives/UserId;

    .line 143
    .line 144
    or-int/lit8 v17, v17, 0x8

    .line 145
    .line 146
    goto :goto_76

    .line 147
    :pswitch_92
    invoke-interface {v1, v0, v7}, Lm70/a;->y(Ll70/g;I)F

    .line 148
    .line 149
    .line 150
    move-result v15

    .line 151
    or-int/lit8 v17, v17, 0x4

    .line 152
    .line 153
    goto :goto_76

    .line 154
    :pswitch_99
    invoke-interface {v1, v0, v8}, Lm70/a;->y(Ll70/g;I)F

    .line 155
    .line 156
    .line 157
    move-result v16

    .line 158
    or-int/lit8 v17, v17, 0x2

    .line 159
    .line 160
    goto :goto_76

    .line 161
    :pswitch_a0
    sget-object v10, Lyh/h;->a:Lyh/h;

    .line 162
    .line 163
    if-eqz v2, :cond_aa

    .line 164
    .line 165
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 166
    .line 167
    invoke-direct {v3, v2}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    goto :goto_ab

    .line 171
    :cond_aa
    const/4 v3, 0x0

    .line 172
    :goto_ab
    invoke-interface {v1, v0, v9, v10, v3}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 177
    .line 178
    if-eqz v2, :cond_b6

    .line 179
    .line 180
    iget-object v2, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 181
    .line 182
    goto :goto_b7

    .line 183
    :cond_b6
    const/4 v2, 0x0

    .line 184
    :goto_b7
    or-int/lit8 v17, v17, 0x1

    .line 185
    .line 186
    const/4 v3, 0x6

    .line 187
    goto :goto_76

    .line 188
    :pswitch_bb
    move/from16 v18, v9

    .line 189
    .line 190
    goto :goto_76

    .line 191
    :cond_be
    move-object/from16 v27, v11

    .line 192
    .line 193
    move/from16 v26, v12

    .line 194
    .line 195
    move-object/from16 v24, v13

    .line 196
    .line 197
    move/from16 v25, v14

    .line 198
    .line 199
    move/from16 v23, v15

    .line 200
    .line 201
    move/from16 v22, v16

    .line 202
    .line 203
    move/from16 v20, v17

    .line 204
    .line 205
    goto :goto_50

    .line 206
    :goto_cd
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 207
    .line 208
    .line 209
    new-instance v19, Lad/j1;

    .line 210
    .line 211
    invoke-direct/range {v19 .. v27}, Lad/j1;-><init>(ILjava/lang/String;FFLcom/discord/primitives/UserId;FZLjava/lang/String;)V

    .line 212
    .line 213
    .line 214
    return-object v19

    .line 215
    :pswitch_data_d6
    .packed-switch -0x1
        :pswitch_bb
        :pswitch_a0
        :pswitch_99
        :pswitch_92
        :pswitch_86
        :pswitch_7f
        :pswitch_78
        :pswitch_70
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 5

    .line 1
    const/4 v0, 0x7

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Ln70/y;->a:Ln70/y;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    aput-object v1, v0, v2

    .line 16
    .line 17
    sget-object v2, Lyh/p;->a:Lyh/p;

    .line 18
    .line 19
    const/4 v3, 0x3

    .line 20
    aput-object v2, v0, v3

    .line 21
    .line 22
    const/4 v2, 0x4

    .line 23
    aput-object v1, v0, v2

    .line 24
    .line 25
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 26
    .line 27
    const/4 v2, 0x5

    .line 28
    aput-object v1, v0, v2

    .line 29
    .line 30
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 31
    .line 32
    const/4 v2, 0x6

    .line 33
    aput-object v1, v0, v2

    .line 34
    .line 35
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 8

    .line 1
    check-cast p2, Lad/j1;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/h1;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/j1;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v2, p1, v0, v3, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 20
    .line 21
    .line 22
    const/4 v1, 0x1

    .line 23
    iget v2, p2, Lad/j1;->b:F

    .line 24
    .line 25
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->y(Ll70/g;IF)V

    .line 26
    .line 27
    .line 28
    const/4 v1, 0x2

    .line 29
    iget v2, p2, Lad/j1;->c:F

    .line 30
    .line 31
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->y(Ll70/g;IF)V

    .line 32
    .line 33
    .line 34
    sget-object v1, Lyh/p;->a:Lyh/p;

    .line 35
    .line 36
    iget-wide v2, p2, Lad/j1;->d:J

    .line 37
    .line 38
    new-instance v4, Lcom/discord/primitives/UserId;

    .line 39
    .line 40
    invoke-direct {v4, v2, v3}, Lcom/discord/primitives/UserId;-><init>(J)V

    .line 41
    .line 42
    .line 43
    const/4 v2, 0x3

    .line 44
    invoke-interface {p1, v0, v2, v1, v4}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    const/4 v1, 0x4

    .line 48
    iget v2, p2, Lad/j1;->e:F

    .line 49
    .line 50
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->y(Ll70/g;IF)V

    .line 51
    .line 52
    .line 53
    const/4 v1, 0x5

    .line 54
    iget-boolean v2, p2, Lad/j1;->f:Z

    .line 55
    .line 56
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 57
    .line 58
    .line 59
    const/4 v1, 0x6

    .line 60
    iget-object p2, p2, Lad/j1;->g:Ljava/lang/String;

    .line 61
    .line 62
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/h1;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
