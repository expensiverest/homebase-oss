###### Class ad.h6 (ad.h6)
.class public final Lad/h6;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/g6;->a:Lad/g6;

    .line 2
    .line 3
    return-object v0
.end method
