###### Class ad.y4 (ad.y4)
.class public final Lad/y4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lad/x4;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/Integer;

.field public final e:Ljava/lang/Boolean;

.field public final f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lad/x4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/y4;->Companion:Lad/x4;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;)V
    .registers 10

    .line 1
    and-int/lit8 v0, p1, 0x3f

    .line 2
    .line 3
    const/16 v1, 0x3f

    .line 4
    .line 5
    if-ne v1, v0, :cond_16

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p2, p0, Lad/y4;->a:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p3, p0, Lad/y4;->b:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p4, p0, Lad/y4;->c:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p5, p0, Lad/y4;->d:Ljava/lang/Integer;

    .line 17
    .line 18
    iput-object p6, p0, Lad/y4;->e:Ljava/lang/Boolean;

    .line 19
    .line 20
    iput-object p7, p0, Lad/y4;->f:Ljava/lang/String;

    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    sget-object p2, Lad/w4;->a:Lad/w4;

    .line 24
    .line 25
    invoke-virtual {p2}, Lad/w4;->d()Ll70/g;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    invoke-static {p1, v1, p2}, Ln70/t0;->j(IILl70/g;)V

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    throw p1
.end method


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableMap;
    .registers 8

    .line 1
    new-instance v0, Ll30/j;

    .line 2
    .line 3
    const-string v1, "channelId"

    .line 4
    .line 5
    iget-object v2, p0, Lad/y4;->a:Ljava/lang/String;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    new-instance v1, Ll30/j;

    .line 11
    .line 12
    const-string v2, "messageId"

    .line 13
    .line 14
    iget-object v3, p0, Lad/y4;->b:Ljava/lang/String;

    .line 15
    .line 16
    invoke-direct {v1, v2, v3}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    new-instance v2, Ll30/j;

    .line 20
    .line 21
    const-string v3, "targetKind"

    .line 22
    .line 23
    iget-object v4, p0, Lad/y4;->c:Ljava/lang/String;

    .line 24
    .line 25
    invoke-direct {v2, v3, v4}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    new-instance v3, Ll30/j;

    .line 29
    .line 30
    const-string v4, "triggerHaptic"

    .line 31
    .line 32
    iget-object v5, p0, Lad/y4;->e:Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-direct {v3, v4, v5}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    new-instance v4, Ll30/j;

    .line 38
    .line 39
    const-string v5, "location"

    .line 40
    .line 41
    iget-object v6, p0, Lad/y4;->f:Ljava/lang/String;

    .line 42
    .line 43
    invoke-direct {v4, v5, v6}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    filled-new-array {v0, v1, v2, v3, v4}, [Ll30/j;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iget-object v1, p0, Lad/y4;->d:Ljava/lang/Integer;

    .line 55
    .line 56
    if-eqz v1, :cond_3e

    .line 57
    .line 58
    const-string v2, "embedIndex"

    .line 59
    .line 60
    invoke-static {v0, v2, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :cond_3e
    return-object v0
.end method
