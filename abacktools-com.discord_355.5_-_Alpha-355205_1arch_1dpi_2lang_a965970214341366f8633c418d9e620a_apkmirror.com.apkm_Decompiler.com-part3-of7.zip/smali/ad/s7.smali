###### Class ad.s7 (ad.s7)
.class public final synthetic Lad/s7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/s7;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/s7;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/s7;->a:Lad/s7;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapSoundmojiData"

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "soundId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "guildId"

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    const-string v0, "messageId"

    .line 34
    .line 35
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    sput-object v1, Lad/s7;->descriptor:Ll70/g;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 21

    .line 1
    sget-object v0, Lad/s7;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v2, :cond_3b

    .line 19
    .line 20
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    sget-object v6, Ln70/h1;->a:Ln70/h1;

    .line 29
    .line 30
    invoke-interface {v1, v0, v4, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Ljava/lang/String;

    .line 35
    .line 36
    sget-object v6, Lyh/h;->a:Lyh/h;

    .line 37
    .line 38
    invoke-interface {v1, v0, v3, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    check-cast v3, Lcom/discord/primitives/MessageId;

    .line 43
    .line 44
    if-eqz v3, :cond_2f

    .line 45
    .line 46
    iget-object v7, v3, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 47
    .line 48
    :cond_2f
    const/16 v3, 0xf

    .line 49
    .line 50
    move v14, v3

    .line 51
    move-object/from16 v17, v4

    .line 52
    .line 53
    move-object/from16 v16, v5

    .line 54
    .line 55
    move-object/from16 v18, v7

    .line 56
    .line 57
    :goto_38
    move-object v15, v2

    .line 58
    goto/16 :goto_95

    .line 59
    .line 60
    :cond_3b
    move v12, v5

    .line 61
    move v8, v6

    .line 62
    move-object v2, v7

    .line 63
    move-object v9, v2

    .line 64
    move-object v10, v9

    .line 65
    move-object v11, v10

    .line 66
    :goto_41
    if-eqz v12, :cond_8d

    .line 67
    .line 68
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 69
    .line 70
    .line 71
    move-result v13

    .line 72
    const/4 v14, -0x1

    .line 73
    if-eq v13, v14, :cond_8b

    .line 74
    .line 75
    if-eqz v13, :cond_84

    .line 76
    .line 77
    if-eq v13, v5, :cond_7d

    .line 78
    .line 79
    if-eq v13, v4, :cond_72

    .line 80
    .line 81
    if-ne v13, v3, :cond_6c

    .line 82
    .line 83
    sget-object v13, Lyh/h;->a:Lyh/h;

    .line 84
    .line 85
    if-eqz v11, :cond_5c

    .line 86
    .line 87
    new-instance v14, Lcom/discord/primitives/MessageId;

    .line 88
    .line 89
    invoke-direct {v14, v11}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    goto :goto_5d

    .line 93
    :cond_5c
    move-object v14, v7

    .line 94
    :goto_5d
    invoke-interface {v1, v0, v3, v13, v14}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v11

    .line 98
    check-cast v11, Lcom/discord/primitives/MessageId;

    .line 99
    .line 100
    if-eqz v11, :cond_68

    .line 101
    .line 102
    iget-object v11, v11, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 103
    .line 104
    goto :goto_69

    .line 105
    :cond_68
    move-object v11, v7

    .line 106
    :goto_69
    or-int/lit8 v8, v8, 0x8

    .line 107
    .line 108
    goto :goto_41

    .line 109
    :cond_6c
    new-instance v0, Lj70/k;

    .line 110
    .line 111
    invoke-direct {v0, v13}, Lj70/k;-><init>(I)V

    .line 112
    .line 113
    .line 114
    throw v0

    .line 115
    :cond_72
    sget-object v13, Ln70/h1;->a:Ln70/h1;

    .line 116
    .line 117
    invoke-interface {v1, v0, v4, v13, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v9

    .line 121
    check-cast v9, Ljava/lang/String;

    .line 122
    .line 123
    or-int/lit8 v8, v8, 0x4

    .line 124
    .line 125
    goto :goto_41

    .line 126
    :cond_7d
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v10

    .line 130
    or-int/lit8 v8, v8, 0x2

    .line 131
    .line 132
    goto :goto_41

    .line 133
    :cond_84
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    or-int/lit8 v8, v8, 0x1

    .line 138
    .line 139
    goto :goto_41

    .line 140
    :cond_8b
    move v12, v6

    .line 141
    goto :goto_41

    .line 142
    :cond_8d
    move v14, v8

    .line 143
    move-object/from16 v17, v9

    .line 144
    .line 145
    move-object/from16 v16, v10

    .line 146
    .line 147
    move-object/from16 v18, v11

    .line 148
    .line 149
    goto :goto_38

    .line 150
    :goto_95
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 151
    .line 152
    .line 153
    new-instance v13, Lad/u7;

    .line 154
    .line 155
    invoke-direct/range {v13 .. v18}, Lad/u7;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    return-object v13
.end method

.method public final b()[Lj70/b;
    .registers 6

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 8
    .line 9
    invoke-static {v2}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const/4 v3, 0x4

    .line 14
    new-array v3, v3, [Lj70/b;

    .line 15
    .line 16
    const/4 v4, 0x0

    .line 17
    aput-object v0, v3, v4

    .line 18
    .line 19
    const/4 v4, 0x1

    .line 20
    aput-object v0, v3, v4

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    aput-object v1, v3, v0

    .line 24
    .line 25
    const/4 v0, 0x3

    .line 26
    aput-object v2, v3, v0

    .line 27
    .line 28
    return-object v3
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 8

    .line 1
    check-cast p2, Lad/u7;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/s7;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iget-object v1, p2, Lad/u7;->a:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v2, p2, Lad/u7;->d:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v3, p2, Lad/u7;->c:Ljava/lang/String;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    invoke-interface {p1, v0, v4, v1}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    iget-object p2, p2, Lad/u7;->b:Ljava/lang/String;

    .line 26
    .line 27
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const/4 p2, 0x2

    .line 31
    invoke-interface {p1, v0, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_25

    .line 36
    .line 37
    goto :goto_27

    .line 38
    :cond_25
    if-eqz v3, :cond_2c

    .line 39
    .line 40
    :goto_27
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 41
    .line 42
    invoke-interface {p1, v0, p2, v1, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_2c
    const/4 p2, 0x3

    .line 46
    invoke-interface {p1, v0, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_34

    .line 51
    .line 52
    goto :goto_36

    .line 53
    :cond_34
    if-eqz v2, :cond_44

    .line 54
    .line 55
    :goto_36
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 56
    .line 57
    if-eqz v2, :cond_40

    .line 58
    .line 59
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 60
    .line 61
    invoke-direct {v3, v2}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    goto :goto_41

    .line 65
    :cond_40
    const/4 v3, 0x0

    .line 66
    :goto_41
    invoke-interface {p1, v0, p2, v1, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    :cond_44
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 70
    .line 71
    .line 72
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/s7;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
