###### Class ad.z5 (ad.z5)
.class public final synthetic Lad/z5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/z5;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/z5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/z5;->a:Lad/z5;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapObscuredMediaToggleData"

    .line 11
    .line 12
    const/4 v3, 0x5

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "attachmentId"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "embedId"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "isReveal"

    .line 38
    .line 39
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    sput-object v1, Lad/z5;->descriptor:Ll70/g;

    .line 43
    .line 44
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 23

    .line 1
    sget-object v0, Lad/z5;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x4

    .line 15
    const/4 v5, 0x2

    .line 16
    const/4 v6, 0x1

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v2, :cond_35

    .line 19
    .line 20
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-interface {v1, v0, v4}, Lm70/a;->v(Ll70/g;I)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    const/16 v7, 0x1f

    .line 41
    .line 42
    move-object/from16 v20, v3

    .line 43
    .line 44
    move/from16 v19, v4

    .line 45
    .line 46
    move-object/from16 v17, v5

    .line 47
    .line 48
    move-object/from16 v16, v6

    .line 49
    .line 50
    move/from16 v18, v7

    .line 51
    .line 52
    :goto_33
    move-object v15, v2

    .line 53
    goto :goto_85

    .line 54
    :cond_35
    const/4 v2, 0x0

    .line 55
    move-object v8, v2

    .line 56
    move-object v10, v8

    .line 57
    move-object v11, v10

    .line 58
    move v13, v6

    .line 59
    move v9, v7

    .line 60
    move v12, v9

    .line 61
    :goto_3c
    if-eqz v13, :cond_7a

    .line 62
    .line 63
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 64
    .line 65
    .line 66
    move-result v14

    .line 67
    const/4 v15, -0x1

    .line 68
    if-eq v14, v15, :cond_78

    .line 69
    .line 70
    if-eqz v14, :cond_71

    .line 71
    .line 72
    if-eq v14, v6, :cond_6a

    .line 73
    .line 74
    if-eq v14, v5, :cond_63

    .line 75
    .line 76
    if-eq v14, v3, :cond_5c

    .line 77
    .line 78
    if-ne v14, v4, :cond_56

    .line 79
    .line 80
    invoke-interface {v1, v0, v4}, Lm70/a;->v(Ll70/g;I)Z

    .line 81
    .line 82
    .line 83
    move-result v9

    .line 84
    or-int/lit8 v12, v12, 0x10

    .line 85
    .line 86
    goto :goto_3c

    .line 87
    :cond_56
    new-instance v0, Lj70/k;

    .line 88
    .line 89
    invoke-direct {v0, v14}, Lj70/k;-><init>(I)V

    .line 90
    .line 91
    .line 92
    throw v0

    .line 93
    :cond_5c
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v8

    .line 97
    or-int/lit8 v12, v12, 0x8

    .line 98
    .line 99
    goto :goto_3c

    .line 100
    :cond_63
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v10

    .line 104
    or-int/lit8 v12, v12, 0x4

    .line 105
    .line 106
    goto :goto_3c

    .line 107
    :cond_6a
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v11

    .line 111
    or-int/lit8 v12, v12, 0x2

    .line 112
    .line 113
    goto :goto_3c

    .line 114
    :cond_71
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    or-int/lit8 v12, v12, 0x1

    .line 119
    .line 120
    goto :goto_3c

    .line 121
    :cond_78
    move v13, v7

    .line 122
    goto :goto_3c

    .line 123
    :cond_7a
    move-object/from16 v20, v8

    .line 124
    .line 125
    move/from16 v19, v9

    .line 126
    .line 127
    move-object/from16 v17, v10

    .line 128
    .line 129
    move-object/from16 v16, v11

    .line 130
    .line 131
    move/from16 v18, v12

    .line 132
    .line 133
    goto :goto_33

    .line 134
    :goto_85
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 135
    .line 136
    .line 137
    new-instance v14, Lad/b6;

    .line 138
    .line 139
    invoke-direct/range {v14 .. v20}, Lad/b6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZLjava/lang/String;)V

    .line 140
    .line 141
    .line 142
    return-object v14
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x5

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    aput-object v1, v0, v2

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    aput-object v1, v0, v2

    .line 14
    .line 15
    const/4 v2, 0x3

    .line 16
    aput-object v1, v0, v2

    .line 17
    .line 18
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 19
    .line 20
    const/4 v2, 0x4

    .line 21
    aput-object v1, v0, v2

    .line 22
    .line 23
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/b6;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/z5;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lad/b6;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-object v2, p2, Lad/b6;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object v2, p2, Lad/b6;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    iget-object v2, p2, Lad/b6;->d:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    const/4 v1, 0x4

    .line 39
    iget-boolean p2, p2, Lad/b6;->e:Z

    .line 40
    .line 41
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 42
    .line 43
    .line 44
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/z5;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
