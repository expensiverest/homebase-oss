###### Class ad.c5 (ad.c5)
.class public final synthetic Lad/c5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/c5;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/c5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/c5;->a:Lad/c5;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapInviteEvent"

    .line 11
    .line 12
    const/4 v3, 0x6

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "index"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "primary"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "secondary"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "skuId"

    .line 38
    .line 39
    const/4 v2, 0x1

    .line 40
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v0, "action"

    .line 44
    .line 45
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    sput-object v1, Lad/c5;->descriptor:Ll70/g;

    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 26

    .line 1
    sget-object v0, Lad/c5;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v5, 0x4

    .line 16
    const/4 v6, 0x2

    .line 17
    const/4 v7, 0x1

    .line 18
    const/4 v8, 0x0

    .line 19
    const/4 v9, 0x0

    .line 20
    if-eqz v2, :cond_4b

    .line 21
    .line 22
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-interface {v1, v0, v7}, Lm70/a;->p(Ll70/g;I)I

    .line 27
    .line 28
    .line 29
    move-result v7

    .line 30
    sget-object v8, Ln70/g;->a:Ln70/g;

    .line 31
    .line 32
    invoke-interface {v1, v0, v6, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v6

    .line 36
    check-cast v6, Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-interface {v1, v0, v4, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    check-cast v4, Ljava/lang/Boolean;

    .line 43
    .line 44
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 45
    .line 46
    invoke-interface {v1, v0, v5, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    check-cast v5, Ljava/lang/String;

    .line 51
    .line 52
    invoke-interface {v1, v0, v3, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Ljava/lang/String;

    .line 57
    .line 58
    const/16 v8, 0x3f

    .line 59
    .line 60
    move-object/from16 v18, v2

    .line 61
    .line 62
    move-object/from16 v23, v3

    .line 63
    .line 64
    move-object/from16 v21, v4

    .line 65
    .line 66
    move-object/from16 v22, v5

    .line 67
    .line 68
    move-object/from16 v20, v6

    .line 69
    .line 70
    move/from16 v19, v7

    .line 71
    .line 72
    move/from16 v17, v8

    .line 73
    .line 74
    goto/16 :goto_b3

    .line 75
    .line 76
    :cond_4b
    move v15, v7

    .line 77
    move v2, v8

    .line 78
    move-object v10, v9

    .line 79
    move-object v11, v10

    .line 80
    move-object v12, v11

    .line 81
    move-object v13, v12

    .line 82
    move-object v14, v13

    .line 83
    move v9, v2

    .line 84
    :goto_53
    if-eqz v15, :cond_a5

    .line 85
    .line 86
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 87
    .line 88
    .line 89
    move-result v8

    .line 90
    packed-switch v8, :pswitch_data_bc

    .line 91
    .line 92
    .line 93
    new-instance v0, Lj70/k;

    .line 94
    .line 95
    invoke-direct {v0, v8}, Lj70/k;-><init>(I)V

    .line 96
    .line 97
    .line 98
    throw v0

    .line 99
    :pswitch_62
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 100
    .line 101
    invoke-interface {v1, v0, v3, v8, v14}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v8

    .line 105
    move-object v14, v8

    .line 106
    check-cast v14, Ljava/lang/String;

    .line 107
    .line 108
    or-int/lit8 v9, v9, 0x20

    .line 109
    .line 110
    :goto_6d
    const/4 v8, 0x0

    .line 111
    goto :goto_53

    .line 112
    :pswitch_6f
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 113
    .line 114
    invoke-interface {v1, v0, v5, v8, v13}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    move-object v13, v8

    .line 119
    check-cast v13, Ljava/lang/String;

    .line 120
    .line 121
    or-int/lit8 v9, v9, 0x10

    .line 122
    .line 123
    goto :goto_6d

    .line 124
    :pswitch_7b
    sget-object v8, Ln70/g;->a:Ln70/g;

    .line 125
    .line 126
    invoke-interface {v1, v0, v4, v8, v12}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v8

    .line 130
    move-object v12, v8

    .line 131
    check-cast v12, Ljava/lang/Boolean;

    .line 132
    .line 133
    or-int/lit8 v9, v9, 0x8

    .line 134
    .line 135
    goto :goto_6d

    .line 136
    :pswitch_87
    sget-object v8, Ln70/g;->a:Ln70/g;

    .line 137
    .line 138
    invoke-interface {v1, v0, v6, v8, v11}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v8

    .line 142
    move-object v11, v8

    .line 143
    check-cast v11, Ljava/lang/Boolean;

    .line 144
    .line 145
    or-int/lit8 v9, v9, 0x4

    .line 146
    .line 147
    goto :goto_6d

    .line 148
    :pswitch_93
    invoke-interface {v1, v0, v7}, Lm70/a;->p(Ll70/g;I)I

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    or-int/lit8 v9, v9, 0x2

    .line 153
    .line 154
    goto :goto_6d

    .line 155
    :pswitch_9a
    const/4 v8, 0x0

    .line 156
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v10

    .line 160
    or-int/lit8 v9, v9, 0x1

    .line 161
    .line 162
    goto :goto_53

    .line 163
    :pswitch_a2
    const/4 v8, 0x0

    .line 164
    move v15, v8

    .line 165
    goto :goto_53

    .line 166
    :cond_a5
    move/from16 v19, v2

    .line 167
    .line 168
    move/from16 v17, v9

    .line 169
    .line 170
    move-object/from16 v18, v10

    .line 171
    .line 172
    move-object/from16 v20, v11

    .line 173
    .line 174
    move-object/from16 v21, v12

    .line 175
    .line 176
    move-object/from16 v22, v13

    .line 177
    .line 178
    move-object/from16 v23, v14

    .line 179
    .line 180
    :goto_b3
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 181
    .line 182
    .line 183
    new-instance v16, Lad/e5;

    .line 184
    .line 185
    invoke-direct/range {v16 .. v23}, Lad/e5;-><init>(ILjava/lang/String;ILjava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    return-object v16

    .line 189
    :pswitch_data_bc
    .packed-switch -0x1
        :pswitch_a2
        :pswitch_9a
        :pswitch_93
        :pswitch_87
        :pswitch_7b
        :pswitch_6f
        :pswitch_62
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 8

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 4
    .line 5
    invoke-static {v1}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-static {v1}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    const/4 v5, 0x6

    .line 22
    new-array v5, v5, [Lj70/b;

    .line 23
    .line 24
    const/4 v6, 0x0

    .line 25
    aput-object v0, v5, v6

    .line 26
    .line 27
    sget-object v0, Ln70/e0;->a:Ln70/e0;

    .line 28
    .line 29
    const/4 v6, 0x1

    .line 30
    aput-object v0, v5, v6

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    aput-object v2, v5, v0

    .line 34
    .line 35
    const/4 v0, 0x3

    .line 36
    aput-object v1, v5, v0

    .line 37
    .line 38
    const/4 v0, 0x4

    .line 39
    aput-object v3, v5, v0

    .line 40
    .line 41
    const/4 v0, 0x5

    .line 42
    aput-object v4, v5, v0

    .line 43
    .line 44
    return-object v5
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 9

    .line 1
    check-cast p2, Lad/e5;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/c5;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iget-object v1, p2, Lad/e5;->a:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v2, p2, Lad/e5;->f:Ljava/lang/String;

    .line 17
    .line 18
    iget-object v3, p2, Lad/e5;->e:Ljava/lang/String;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    invoke-interface {p1, v0, v4, v1}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x1

    .line 25
    iget v4, p2, Lad/e5;->b:I

    .line 26
    .line 27
    invoke-interface {p1, v1, v4, v0}, Lm70/b;->n(IILl70/g;)V

    .line 28
    .line 29
    .line 30
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 31
    .line 32
    iget-object v4, p2, Lad/e5;->c:Ljava/lang/Boolean;

    .line 33
    .line 34
    const/4 v5, 0x2

    .line 35
    invoke-interface {p1, v0, v5, v1, v4}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    const/4 v4, 0x3

    .line 39
    iget-object p2, p2, Lad/e5;->d:Ljava/lang/Boolean;

    .line 40
    .line 41
    invoke-interface {p1, v0, v4, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    const/4 p2, 0x4

    .line 45
    invoke-interface {p1, v0, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_33

    .line 50
    .line 51
    goto :goto_35

    .line 52
    :cond_33
    if-eqz v3, :cond_3a

    .line 53
    .line 54
    :goto_35
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 55
    .line 56
    invoke-interface {p1, v0, p2, v1, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :cond_3a
    const/4 p2, 0x5

    .line 60
    invoke-interface {p1, v0, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_42

    .line 65
    .line 66
    goto :goto_44

    .line 67
    :cond_42
    if-eqz v2, :cond_49

    .line 68
    .line 69
    :goto_44
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 70
    .line 71
    invoke-interface {p1, v0, p2, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    :cond_49
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 75
    .line 76
    .line 77
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/c5;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
