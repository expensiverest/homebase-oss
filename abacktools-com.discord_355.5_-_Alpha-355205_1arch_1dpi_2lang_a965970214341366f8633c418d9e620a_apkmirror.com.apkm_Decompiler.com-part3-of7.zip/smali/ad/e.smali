###### Class ad.e (ad.e)
.class public final Lad/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lad/g;


# direct methods
.method public synthetic constructor <init>(Lad/g;I)V
    .registers 3

    .line 1
    iput p2, p0, Lad/e;->d:I

    iput-object p1, p0, Lad/e;->e:Lad/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lad/e;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_46

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/discord/primitives/MessageId;

    .line 7
    .line 8
    iget-object p1, p1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 9
    .line 10
    check-cast p2, Lcom/discord/primitives/ChannelId;

    .line 11
    .line 12
    iget-wide v0, p2, Lcom/discord/primitives/ChannelId;->d:J

    .line 13
    .line 14
    const-string p2, "$v$c$com-discord-primitives-MessageId$-messageId$0"

    .line 15
    .line 16
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object p2, p0, Lad/e;->e:Lad/g;

    .line 20
    .line 21
    iget-object p2, p2, Lad/g;->a:Lad/d;

    .line 22
    .line 23
    new-instance v2, Lad/s5;

    .line 24
    .line 25
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-direct {v2, p1, v0}, Lad/s5;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p2, v2}, Lad/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 36
    .line 37
    return-object p1

    .line 38
    :pswitch_25
    check-cast p1, Lcom/discord/primitives/MessageId;

    .line 39
    .line 40
    iget-object p1, p1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 41
    .line 42
    check-cast p2, Lcom/discord/primitives/ChannelId;

    .line 43
    .line 44
    iget-wide v0, p2, Lcom/discord/primitives/ChannelId;->d:J

    .line 45
    .line 46
    const-string p2, "$v$c$com-discord-primitives-MessageId$-messageId$0"

    .line 47
    .line 48
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object p2, p0, Lad/e;->e:Lad/g;

    .line 52
    .line 53
    iget-object p2, p2, Lad/g;->a:Lad/d;

    .line 54
    .line 55
    new-instance v2, Lad/n;

    .line 56
    .line 57
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-direct {v2, p1, v0}, Lad/n;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p2, v2}, Lad/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 68
    .line 69
    return-object p1

    .line 70
    nop

    .line 71
    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_25
    .end packed-switch
.end method
