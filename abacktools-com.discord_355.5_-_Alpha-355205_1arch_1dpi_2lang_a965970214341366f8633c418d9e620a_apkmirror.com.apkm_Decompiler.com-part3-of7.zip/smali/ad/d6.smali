###### Class ad.d6 (ad.d6)
.class public final synthetic Lad/d6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/d6;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/d6;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/d6;->a:Lad/d6;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapPollAction"

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "channelId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "messageId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "type"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lad/d6;->descriptor:Ll70/g;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 13

    .line 1
    sget-object v0, Lad/d6;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x2

    .line 12
    const/4 v3, 0x1

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_1d

    .line 15
    .line 16
    invoke-interface {p1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-interface {p1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    const/4 v4, 0x7

    .line 29
    goto :goto_51

    .line 30
    :cond_1d
    const/4 v1, 0x0

    .line 31
    move-object v5, v1

    .line 32
    move-object v6, v5

    .line 33
    move v8, v3

    .line 34
    move v7, v4

    .line 35
    :goto_22
    if-eqz v8, :cond_4e

    .line 36
    .line 37
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 38
    .line 39
    .line 40
    move-result v9

    .line 41
    const/4 v10, -0x1

    .line 42
    if-eq v9, v10, :cond_4c

    .line 43
    .line 44
    if-eqz v9, :cond_45

    .line 45
    .line 46
    if-eq v9, v3, :cond_3e

    .line 47
    .line 48
    if-ne v9, v2, :cond_38

    .line 49
    .line 50
    invoke-interface {p1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    or-int/lit8 v7, v7, 0x4

    .line 55
    .line 56
    goto :goto_22

    .line 57
    :cond_38
    new-instance p1, Lj70/k;

    .line 58
    .line 59
    invoke-direct {p1, v9}, Lj70/k;-><init>(I)V

    .line 60
    .line 61
    .line 62
    throw p1

    .line 63
    :cond_3e
    invoke-interface {p1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    or-int/lit8 v7, v7, 0x2

    .line 68
    .line 69
    goto :goto_22

    .line 70
    :cond_45
    invoke-interface {p1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    or-int/lit8 v7, v7, 0x1

    .line 75
    .line 76
    goto :goto_22

    .line 77
    :cond_4c
    move v8, v4

    .line 78
    goto :goto_22

    .line 79
    :cond_4e
    move-object v2, v5

    .line 80
    move-object v3, v6

    .line 81
    move v4, v7

    .line 82
    :goto_51
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 83
    .line 84
    .line 85
    new-instance p1, Lad/f6;

    .line 86
    .line 87
    invoke-direct {p1, v1, v4, v3, v2}, Lad/f6;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    aput-object v1, v0, v2

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    aput-object v1, v0, v2

    .line 14
    .line 15
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/f6;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/d6;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lad/f6;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-object v2, p2, Lad/f6;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object p2, p2, Lad/f6;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/d6;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
