###### Class ad.v2 (ad.v2)
.class public final Lad/v2;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/u2;->a:Lad/u2;

    .line 2
    .line 3
    return-object v0
.end method
