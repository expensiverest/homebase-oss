###### Class ad.n3 (ad.n3)
.class public final Lad/n3;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/m3;->a:Lad/m3;

    .line 2
    .line 3
    return-object v0
.end method
