###### Class ad.v8 (ad.v8)
.class public final synthetic Lad/v8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/v8;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/v8;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/v8;->a:Lad/v8;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.VoiceMessagePlaybackFailedData"

    .line 11
    .line 12
    const/4 v3, 0x2

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "errorMessage"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    sput-object v1, Lad/v8;->descriptor:Ll70/g;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 12

    .line 1
    sget-object v0, Lad/v8;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_27

    .line 15
    .line 16
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 17
    .line 18
    invoke-interface {p1, v0, v3, v1, v4}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 23
    .line 24
    if-eqz v1, :cond_1c

    .line 25
    .line 26
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 27
    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    move-object v1, v4

    .line 30
    :goto_1d
    sget-object v3, Ln70/h1;->a:Ln70/h1;

    .line 31
    .line 32
    invoke-interface {p1, v0, v2, v3, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    check-cast v2, Ljava/lang/String;

    .line 37
    .line 38
    const/4 v3, 0x3

    .line 39
    goto :goto_67

    .line 40
    :cond_27
    move v7, v2

    .line 41
    move v6, v3

    .line 42
    move-object v1, v4

    .line 43
    move-object v5, v1

    .line 44
    :goto_2b
    if-eqz v7, :cond_65

    .line 45
    .line 46
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 47
    .line 48
    .line 49
    move-result v8

    .line 50
    const/4 v9, -0x1

    .line 51
    if-eq v8, v9, :cond_63

    .line 52
    .line 53
    if-eqz v8, :cond_49

    .line 54
    .line 55
    if-ne v8, v2, :cond_43

    .line 56
    .line 57
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 58
    .line 59
    invoke-interface {p1, v0, v2, v8, v5}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v5

    .line 63
    check-cast v5, Ljava/lang/String;

    .line 64
    .line 65
    or-int/lit8 v6, v6, 0x2

    .line 66
    .line 67
    goto :goto_2b

    .line 68
    :cond_43
    new-instance p1, Lj70/k;

    .line 69
    .line 70
    invoke-direct {p1, v8}, Lj70/k;-><init>(I)V

    .line 71
    .line 72
    .line 73
    throw p1

    .line 74
    :cond_49
    sget-object v8, Lyh/h;->a:Lyh/h;

    .line 75
    .line 76
    if-eqz v1, :cond_53

    .line 77
    .line 78
    new-instance v9, Lcom/discord/primitives/MessageId;

    .line 79
    .line 80
    invoke-direct {v9, v1}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    goto :goto_54

    .line 84
    :cond_53
    move-object v9, v4

    .line 85
    :goto_54
    invoke-interface {p1, v0, v3, v8, v9}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 90
    .line 91
    if-eqz v1, :cond_5f

    .line 92
    .line 93
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 94
    .line 95
    goto :goto_60

    .line 96
    :cond_5f
    move-object v1, v4

    .line 97
    :goto_60
    or-int/lit8 v6, v6, 0x1

    .line 98
    .line 99
    goto :goto_2b

    .line 100
    :cond_63
    move v7, v3

    .line 101
    goto :goto_2b

    .line 102
    :cond_65
    move-object v2, v5

    .line 103
    move v3, v6

    .line 104
    :goto_67
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 105
    .line 106
    .line 107
    new-instance p1, Lad/x8;

    .line 108
    .line 109
    invoke-direct {p1, v3, v1, v2}, Lad/x8;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 5

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x2

    .line 8
    new-array v1, v1, [Lj70/b;

    .line 9
    .line 10
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    aput-object v2, v1, v3

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    aput-object v0, v1, v2

    .line 17
    .line 18
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/x8;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/v8;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/x8;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v2, p1, v0, v3, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 20
    .line 21
    .line 22
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 23
    .line 24
    iget-object p2, p2, Lad/x8;->b:Ljava/lang/String;

    .line 25
    .line 26
    const/4 v2, 0x1

    .line 27
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/v8;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
