###### Class ad.k1 (ad.k1)
.class public final synthetic Lad/k1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/k1;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/k1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/k1;->a:Lad/k1;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.MediaAttachmentPlaybackStartedData"

    .line 11
    .line 12
    const/4 v3, 0x6

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "totalDurationSecs"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "startDurationSecs"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "senderUserId"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "isVoiceMessage"

    .line 38
    .line 39
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "attachmentId"

    .line 43
    .line 44
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    sput-object v1, Lad/k1;->descriptor:Ll70/g;

    .line 48
    .line 49
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 27

    .line 1
    sget-object v0, Lad/k1;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v5, 0x4

    .line 16
    const/4 v6, 0x2

    .line 17
    const/4 v7, 0x1

    .line 18
    const/4 v8, 0x0

    .line 19
    const/4 v9, 0x0

    .line 20
    if-eqz v2, :cond_4d

    .line 21
    .line 22
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 23
    .line 24
    invoke-interface {v1, v0, v8, v2, v9}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 29
    .line 30
    if-eqz v2, :cond_22

    .line 31
    .line 32
    iget-object v2, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 33
    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move-object v2, v9

    .line 36
    :goto_23
    invoke-interface {v1, v0, v7}, Lm70/a;->y(Ll70/g;I)F

    .line 37
    .line 38
    .line 39
    move-result v7

    .line 40
    invoke-interface {v1, v0, v6}, Lm70/a;->y(Ll70/g;I)F

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    sget-object v8, Lyh/p;->a:Lyh/p;

    .line 45
    .line 46
    invoke-interface {v1, v0, v4, v8, v9}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    check-cast v4, Lcom/discord/primitives/UserId;

    .line 51
    .line 52
    invoke-interface {v1, v0, v5}, Lm70/a;->v(Ll70/g;I)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    const/16 v8, 0x3f

    .line 61
    .line 62
    move-object/from16 v24, v3

    .line 63
    .line 64
    move-object/from16 v22, v4

    .line 65
    .line 66
    move/from16 v23, v5

    .line 67
    .line 68
    move/from16 v21, v6

    .line 69
    .line 70
    move/from16 v20, v7

    .line 71
    .line 72
    move/from16 v18, v8

    .line 73
    .line 74
    :goto_49
    move-object/from16 v19, v2

    .line 75
    .line 76
    goto/16 :goto_ba

    .line 77
    .line 78
    :cond_4d
    const/4 v2, 0x0

    .line 79
    move v13, v2

    .line 80
    move v14, v13

    .line 81
    move/from16 v16, v7

    .line 82
    .line 83
    move v12, v8

    .line 84
    move v15, v12

    .line 85
    move-object v2, v9

    .line 86
    move-object v10, v2

    .line 87
    move-object v11, v10

    .line 88
    :goto_57
    if-eqz v16, :cond_ad

    .line 89
    .line 90
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 91
    .line 92
    .line 93
    move-result v9

    .line 94
    packed-switch v9, :pswitch_data_c4

    .line 95
    .line 96
    .line 97
    new-instance v0, Lj70/k;

    .line 98
    .line 99
    invoke-direct {v0, v9}, Lj70/k;-><init>(I)V

    .line 100
    .line 101
    .line 102
    throw v0

    .line 103
    :pswitch_66
    invoke-interface {v1, v0, v3}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v10

    .line 107
    or-int/lit8 v15, v15, 0x20

    .line 108
    .line 109
    :goto_6c
    const/4 v9, 0x0

    .line 110
    goto :goto_57

    .line 111
    :pswitch_6e
    invoke-interface {v1, v0, v5}, Lm70/a;->v(Ll70/g;I)Z

    .line 112
    .line 113
    .line 114
    move-result v12

    .line 115
    or-int/lit8 v15, v15, 0x10

    .line 116
    .line 117
    goto :goto_6c

    .line 118
    :pswitch_75
    sget-object v9, Lyh/p;->a:Lyh/p;

    .line 119
    .line 120
    invoke-interface {v1, v0, v4, v9, v11}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v9

    .line 124
    move-object v11, v9

    .line 125
    check-cast v11, Lcom/discord/primitives/UserId;

    .line 126
    .line 127
    or-int/lit8 v15, v15, 0x8

    .line 128
    .line 129
    goto :goto_6c

    .line 130
    :pswitch_81
    invoke-interface {v1, v0, v6}, Lm70/a;->y(Ll70/g;I)F

    .line 131
    .line 132
    .line 133
    move-result v13

    .line 134
    or-int/lit8 v15, v15, 0x4

    .line 135
    .line 136
    goto :goto_6c

    .line 137
    :pswitch_88
    invoke-interface {v1, v0, v7}, Lm70/a;->y(Ll70/g;I)F

    .line 138
    .line 139
    .line 140
    move-result v14

    .line 141
    or-int/lit8 v15, v15, 0x2

    .line 142
    .line 143
    goto :goto_6c

    .line 144
    :pswitch_8f
    sget-object v9, Lyh/h;->a:Lyh/h;

    .line 145
    .line 146
    if-eqz v2, :cond_99

    .line 147
    .line 148
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 149
    .line 150
    invoke-direct {v3, v2}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    goto :goto_9a

    .line 154
    :cond_99
    const/4 v3, 0x0

    .line 155
    :goto_9a
    invoke-interface {v1, v0, v8, v9, v3}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    check-cast v2, Lcom/discord/primitives/MessageId;

    .line 160
    .line 161
    if-eqz v2, :cond_a5

    .line 162
    .line 163
    iget-object v2, v2, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 164
    .line 165
    goto :goto_a6

    .line 166
    :cond_a5
    const/4 v2, 0x0

    .line 167
    :goto_a6
    or-int/lit8 v15, v15, 0x1

    .line 168
    .line 169
    const/4 v3, 0x5

    .line 170
    goto :goto_6c

    .line 171
    :pswitch_aa
    move/from16 v16, v8

    .line 172
    .line 173
    goto :goto_6c

    .line 174
    :cond_ad
    move-object/from16 v24, v10

    .line 175
    .line 176
    move-object/from16 v22, v11

    .line 177
    .line 178
    move/from16 v23, v12

    .line 179
    .line 180
    move/from16 v21, v13

    .line 181
    .line 182
    move/from16 v20, v14

    .line 183
    .line 184
    move/from16 v18, v15

    .line 185
    .line 186
    goto :goto_49

    .line 187
    :goto_ba
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 188
    .line 189
    .line 190
    new-instance v17, Lad/m1;

    .line 191
    .line 192
    invoke-direct/range {v17 .. v24}, Lad/m1;-><init>(ILjava/lang/String;FFLcom/discord/primitives/UserId;ZLjava/lang/String;)V

    .line 193
    .line 194
    .line 195
    return-object v17

    .line 196
    nop

    .line 197
    :pswitch_data_c4
    .packed-switch -0x1
        :pswitch_aa
        :pswitch_8f
        :pswitch_88
        :pswitch_81
        :pswitch_75
        :pswitch_6e
        :pswitch_66
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x6

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Ln70/y;->a:Ln70/y;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const/4 v2, 0x2

    .line 15
    aput-object v1, v0, v2

    .line 16
    .line 17
    sget-object v1, Lyh/p;->a:Lyh/p;

    .line 18
    .line 19
    const/4 v2, 0x3

    .line 20
    aput-object v1, v0, v2

    .line 21
    .line 22
    sget-object v1, Ln70/g;->a:Ln70/g;

    .line 23
    .line 24
    const/4 v2, 0x4

    .line 25
    aput-object v1, v0, v2

    .line 26
    .line 27
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 28
    .line 29
    const/4 v2, 0x5

    .line 30
    aput-object v1, v0, v2

    .line 31
    .line 32
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 8

    .line 1
    check-cast p2, Lad/m1;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/k1;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/m1;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v2, p1, v0, v3, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 20
    .line 21
    .line 22
    const/4 v1, 0x1

    .line 23
    iget v2, p2, Lad/m1;->b:F

    .line 24
    .line 25
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->y(Ll70/g;IF)V

    .line 26
    .line 27
    .line 28
    const/4 v1, 0x2

    .line 29
    iget v2, p2, Lad/m1;->c:F

    .line 30
    .line 31
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->y(Ll70/g;IF)V

    .line 32
    .line 33
    .line 34
    sget-object v1, Lyh/p;->a:Lyh/p;

    .line 35
    .line 36
    iget-wide v2, p2, Lad/m1;->d:J

    .line 37
    .line 38
    new-instance v4, Lcom/discord/primitives/UserId;

    .line 39
    .line 40
    invoke-direct {v4, v2, v3}, Lcom/discord/primitives/UserId;-><init>(J)V

    .line 41
    .line 42
    .line 43
    const/4 v2, 0x3

    .line 44
    invoke-interface {p1, v0, v2, v1, v4}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    const/4 v1, 0x4

    .line 48
    iget-boolean v2, p2, Lad/m1;->e:Z

    .line 49
    .line 50
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->F(Ll70/g;IZ)V

    .line 51
    .line 52
    .line 53
    const/4 v1, 0x5

    .line 54
    iget-object p2, p2, Lad/m1;->f:Ljava/lang/String;

    .line 55
    .line 56
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 60
    .line 61
    .line 62
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/k1;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
