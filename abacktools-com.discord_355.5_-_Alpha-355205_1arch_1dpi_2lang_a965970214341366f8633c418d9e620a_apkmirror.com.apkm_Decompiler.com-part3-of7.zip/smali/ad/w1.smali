###### Class ad.w1 (ad.w1)
.class public final synthetic Lad/w1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/w1;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/w1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/w1;->a:Lad/w1;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapAttachmentTextPreviewData"

    .line 11
    .line 12
    const/4 v3, 0x2

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "attachmentUrl"

    .line 17
    .line 18
    const/4 v2, 0x1

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "fileName"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    sput-object v1, Lad/w1;->descriptor:Ll70/g;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 11

    .line 1
    sget-object v0, Lad/w1;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_1f

    .line 15
    .line 16
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 17
    .line 18
    invoke-interface {p1, v0, v3, v1, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    check-cast v3, Ljava/lang/String;

    .line 23
    .line 24
    invoke-interface {p1, v0, v2, v1, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    check-cast v1, Ljava/lang/String;

    .line 29
    .line 30
    const/4 v2, 0x3

    .line 31
    goto :goto_50

    .line 32
    :cond_1f
    move v6, v2

    .line 33
    move v1, v3

    .line 34
    move-object v5, v4

    .line 35
    :goto_22
    if-eqz v6, :cond_4d

    .line 36
    .line 37
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 38
    .line 39
    .line 40
    move-result v7

    .line 41
    const/4 v8, -0x1

    .line 42
    if-eq v7, v8, :cond_4b

    .line 43
    .line 44
    if-eqz v7, :cond_40

    .line 45
    .line 46
    if-ne v7, v2, :cond_3a

    .line 47
    .line 48
    sget-object v7, Ln70/h1;->a:Ln70/h1;

    .line 49
    .line 50
    invoke-interface {p1, v0, v2, v7, v5}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    check-cast v5, Ljava/lang/String;

    .line 55
    .line 56
    or-int/lit8 v1, v1, 0x2

    .line 57
    .line 58
    goto :goto_22

    .line 59
    :cond_3a
    new-instance p1, Lj70/k;

    .line 60
    .line 61
    invoke-direct {p1, v7}, Lj70/k;-><init>(I)V

    .line 62
    .line 63
    .line 64
    throw p1

    .line 65
    :cond_40
    sget-object v7, Ln70/h1;->a:Ln70/h1;

    .line 66
    .line 67
    invoke-interface {p1, v0, v3, v7, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    check-cast v4, Ljava/lang/String;

    .line 72
    .line 73
    or-int/lit8 v1, v1, 0x1

    .line 74
    .line 75
    goto :goto_22

    .line 76
    :cond_4b
    move v6, v3

    .line 77
    goto :goto_22

    .line 78
    :cond_4d
    move v2, v1

    .line 79
    move-object v3, v4

    .line 80
    move-object v1, v5

    .line 81
    :goto_50
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 82
    .line 83
    .line 84
    new-instance p1, Lad/y1;

    .line 85
    .line 86
    invoke-direct {p1, v2, v3, v1}, Lad/y1;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 5

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v2, 0x2

    .line 12
    new-array v2, v2, [Lj70/b;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    aput-object v1, v2, v3

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    aput-object v0, v2, v1

    .line 19
    .line 20
    return-object v2
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/y1;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p2, Lad/y1;->b:Ljava/lang/String;

    .line 9
    .line 10
    iget-object p2, p2, Lad/y1;->a:Ljava/lang/String;

    .line 11
    .line 12
    sget-object v1, Lad/w1;->descriptor:Ll70/g;

    .line 13
    .line 14
    invoke-interface {p1, v1}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-interface {p1, v1, v2}, Lm70/b;->D(Ll70/g;I)Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_19

    .line 24
    .line 25
    goto :goto_1b

    .line 26
    :cond_19
    if-eqz p2, :cond_20

    .line 27
    .line 28
    :goto_1b
    sget-object v3, Ln70/h1;->a:Ln70/h1;

    .line 29
    .line 30
    invoke-interface {p1, v1, v2, v3, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_20
    const/4 p2, 0x1

    .line 34
    invoke-interface {p1, v1, p2}, Lm70/b;->D(Ll70/g;I)Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_28

    .line 39
    .line 40
    goto :goto_2a

    .line 41
    :cond_28
    if-eqz v0, :cond_2f

    .line 42
    .line 43
    :goto_2a
    sget-object v2, Ln70/h1;->a:Ln70/h1;

    .line 44
    .line 45
    invoke-interface {p1, v1, p2, v2, v0}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_2f
    invoke-interface {p1, v1}, Lm70/b;->c(Ll70/g;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/w1;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
