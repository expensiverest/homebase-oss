###### Class ad.h (ad.h)
.class public final Lad/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableMap;
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Ll30/j;

    .line 3
    .line 4
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    return-object v0
.end method
