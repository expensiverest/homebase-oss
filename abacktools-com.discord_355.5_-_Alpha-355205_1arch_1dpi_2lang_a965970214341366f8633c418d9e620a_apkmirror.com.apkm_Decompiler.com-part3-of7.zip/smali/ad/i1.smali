###### Class ad.i1 (ad.i1)
.class public final Lad/i1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/h1;->a:Lad/h1;

    .line 2
    .line 3
    return-object v0
.end method
