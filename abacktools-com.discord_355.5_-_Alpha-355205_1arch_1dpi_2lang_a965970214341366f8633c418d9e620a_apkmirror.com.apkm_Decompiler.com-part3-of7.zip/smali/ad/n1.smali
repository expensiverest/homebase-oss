###### Class ad.n1 (ad.n1)
.class public final synthetic Lad/n1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/n1;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/n1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/n1;->a:Lad/n1;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.SharedClientThemeViewedData"

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    invoke-virtual {v1, v0, v3}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 19
    .line 20
    .line 21
    sput-object v1, Lad/n1;->descriptor:Ll70/g;

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 11

    .line 1
    sget-object v0, Lad/n1;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_1c

    .line 15
    .line 16
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 17
    .line 18
    invoke-interface {p1, v0, v3, v1, v4}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 23
    .line 24
    if-eqz v1, :cond_4d

    .line 25
    .line 26
    iget-object v4, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 27
    .line 28
    goto :goto_4d

    .line 29
    :cond_1c
    move v5, v2

    .line 30
    move v6, v3

    .line 31
    move-object v1, v4

    .line 32
    :goto_1f
    if-eqz v5, :cond_4b

    .line 33
    .line 34
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 35
    .line 36
    .line 37
    move-result v7

    .line 38
    const/4 v8, -0x1

    .line 39
    if-eq v7, v8, :cond_49

    .line 40
    .line 41
    if-nez v7, :cond_43

    .line 42
    .line 43
    sget-object v6, Lyh/h;->a:Lyh/h;

    .line 44
    .line 45
    if-eqz v1, :cond_34

    .line 46
    .line 47
    new-instance v7, Lcom/discord/primitives/MessageId;

    .line 48
    .line 49
    invoke-direct {v7, v1}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    goto :goto_35

    .line 53
    :cond_34
    move-object v7, v4

    .line 54
    :goto_35
    invoke-interface {p1, v0, v3, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 59
    .line 60
    if-eqz v1, :cond_40

    .line 61
    .line 62
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 63
    .line 64
    goto :goto_41

    .line 65
    :cond_40
    move-object v1, v4

    .line 66
    :goto_41
    move v6, v2

    .line 67
    goto :goto_1f

    .line 68
    :cond_43
    new-instance p1, Lj70/k;

    .line 69
    .line 70
    invoke-direct {p1, v7}, Lj70/k;-><init>(I)V

    .line 71
    .line 72
    .line 73
    throw p1

    .line 74
    :cond_49
    move v5, v3

    .line 75
    goto :goto_1f

    .line 76
    :cond_4b
    move-object v4, v1

    .line 77
    move v2, v6

    .line 78
    :cond_4d
    :goto_4d
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 79
    .line 80
    .line 81
    new-instance p1, Lad/p1;

    .line 82
    .line 83
    invoke-direct {p1, v2, v4}, Lad/p1;-><init>(ILjava/lang/String;)V

    .line 84
    .line 85
    .line 86
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    sget-object v0, Lyh/h;->a:Lyh/h;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x1

    .line 8
    new-array v1, v1, [Lj70/b;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    aput-object v0, v1, v2

    .line 12
    .line 13
    return-object v1
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/p1;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object p2, p2, Lad/p1;->a:Ljava/lang/String;

    .line 9
    .line 10
    sget-object v0, Lad/n1;->descriptor:Ll70/g;

    .line 11
    .line 12
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-interface {p1, v0, v1}, Lm70/b;->D(Ll70/g;I)Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_17

    .line 22
    .line 23
    goto :goto_19

    .line 24
    :cond_17
    if-eqz p2, :cond_27

    .line 25
    .line 26
    :goto_19
    sget-object v2, Lyh/h;->a:Lyh/h;

    .line 27
    .line 28
    if-eqz p2, :cond_23

    .line 29
    .line 30
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 31
    .line 32
    invoke-direct {v3, p2}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    goto :goto_24

    .line 36
    :cond_23
    const/4 v3, 0x0

    .line 37
    :goto_24
    invoke-interface {p1, v0, v1, v2, v3}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    :cond_27
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/n1;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
