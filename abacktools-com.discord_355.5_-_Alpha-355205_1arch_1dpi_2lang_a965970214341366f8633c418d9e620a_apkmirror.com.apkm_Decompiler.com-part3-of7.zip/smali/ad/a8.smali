###### Class ad.a8 (ad.a8)
.class public final Lad/a8;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/z7;->a:Lad/z7;

    .line 2
    .line 3
    return-object v0
.end method
