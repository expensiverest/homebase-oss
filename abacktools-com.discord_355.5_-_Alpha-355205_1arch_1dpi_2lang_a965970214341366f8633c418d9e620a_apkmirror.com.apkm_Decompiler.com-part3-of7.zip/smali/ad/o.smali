###### Class ad.o (ad.o)
.class public final synthetic Lad/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/o;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/o;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/o;->a:Lad/o;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.FirstLayoutData"

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "firstVisibleMessageIndex"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "firstVisibleMessagePercentVisible"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "lastVisibleMessageIndex"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "lastVisibleMessagePercentVisible"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    sput-object v1, Lad/o;->descriptor:Ll70/g;

    .line 38
    .line 39
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 20

    .line 1
    sget-object v0, Lad/o;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v2, :cond_33

    .line 19
    .line 20
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    sget-object v6, Ln70/r;->a:Ln70/r;

    .line 25
    .line 26
    invoke-interface {v1, v0, v5, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    check-cast v5, Ljava/lang/Double;

    .line 31
    .line 32
    invoke-interface {v1, v0, v4}, Lm70/a;->p(Ll70/g;I)I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    invoke-interface {v1, v0, v3, v6, v7}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    check-cast v3, Ljava/lang/Double;

    .line 41
    .line 42
    const/16 v6, 0xf

    .line 43
    .line 44
    move-object/from16 v17, v3

    .line 45
    .line 46
    move/from16 v16, v4

    .line 47
    .line 48
    move-object v15, v5

    .line 49
    move v13, v6

    .line 50
    :goto_31
    move v14, v2

    .line 51
    goto :goto_7d

    .line 52
    :cond_33
    move v11, v5

    .line 53
    move v2, v6

    .line 54
    move v8, v2

    .line 55
    move-object v9, v7

    .line 56
    move-object v10, v9

    .line 57
    move v7, v8

    .line 58
    :goto_39
    if-eqz v11, :cond_76

    .line 59
    .line 60
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 61
    .line 62
    .line 63
    move-result v12

    .line 64
    const/4 v13, -0x1

    .line 65
    if-eq v12, v13, :cond_74

    .line 66
    .line 67
    if-eqz v12, :cond_6d

    .line 68
    .line 69
    if-eq v12, v5, :cond_62

    .line 70
    .line 71
    if-eq v12, v4, :cond_5b

    .line 72
    .line 73
    if-ne v12, v3, :cond_55

    .line 74
    .line 75
    sget-object v12, Ln70/r;->a:Ln70/r;

    .line 76
    .line 77
    invoke-interface {v1, v0, v3, v12, v10}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v10

    .line 81
    check-cast v10, Ljava/lang/Double;

    .line 82
    .line 83
    or-int/lit8 v8, v8, 0x8

    .line 84
    .line 85
    goto :goto_39

    .line 86
    :cond_55
    new-instance v0, Lj70/k;

    .line 87
    .line 88
    invoke-direct {v0, v12}, Lj70/k;-><init>(I)V

    .line 89
    .line 90
    .line 91
    throw v0

    .line 92
    :cond_5b
    invoke-interface {v1, v0, v4}, Lm70/a;->p(Ll70/g;I)I

    .line 93
    .line 94
    .line 95
    move-result v7

    .line 96
    or-int/lit8 v8, v8, 0x4

    .line 97
    .line 98
    goto :goto_39

    .line 99
    :cond_62
    sget-object v12, Ln70/r;->a:Ln70/r;

    .line 100
    .line 101
    invoke-interface {v1, v0, v5, v12, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v9

    .line 105
    check-cast v9, Ljava/lang/Double;

    .line 106
    .line 107
    or-int/lit8 v8, v8, 0x2

    .line 108
    .line 109
    goto :goto_39

    .line 110
    :cond_6d
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    or-int/lit8 v8, v8, 0x1

    .line 115
    .line 116
    goto :goto_39

    .line 117
    :cond_74
    move v11, v6

    .line 118
    goto :goto_39

    .line 119
    :cond_76
    move/from16 v16, v7

    .line 120
    .line 121
    move v13, v8

    .line 122
    move-object v15, v9

    .line 123
    move-object/from16 v17, v10

    .line 124
    .line 125
    goto :goto_31

    .line 126
    :goto_7d
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 127
    .line 128
    .line 129
    new-instance v12, Lad/q;

    .line 130
    .line 131
    invoke-direct/range {v12 .. v17}, Lad/q;-><init>(IILjava/lang/Double;ILjava/lang/Double;)V

    .line 132
    .line 133
    .line 134
    return-object v12
.end method

.method public final b()[Lj70/b;
    .registers 6

    .line 1
    sget-object v0, Ln70/r;->a:Ln70/r;

    .line 2
    .line 3
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v2, 0x4

    .line 12
    new-array v2, v2, [Lj70/b;

    .line 13
    .line 14
    sget-object v3, Ln70/e0;->a:Ln70/e0;

    .line 15
    .line 16
    const/4 v4, 0x0

    .line 17
    aput-object v3, v2, v4

    .line 18
    .line 19
    const/4 v4, 0x1

    .line 20
    aput-object v1, v2, v4

    .line 21
    .line 22
    const/4 v1, 0x2

    .line 23
    aput-object v3, v2, v1

    .line 24
    .line 25
    const/4 v1, 0x3

    .line 26
    aput-object v0, v2, v1

    .line 27
    .line 28
    return-object v2
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/q;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/o;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget v2, p2, Lad/q;->a:I

    .line 16
    .line 17
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 18
    .line 19
    .line 20
    sget-object v1, Ln70/r;->a:Ln70/r;

    .line 21
    .line 22
    iget-object v2, p2, Lad/q;->b:Ljava/lang/Double;

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    invoke-interface {p1, v0, v3, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    const/4 v2, 0x2

    .line 29
    iget v3, p2, Lad/q;->c:I

    .line 30
    .line 31
    invoke-interface {p1, v2, v3, v0}, Lm70/b;->n(IILl70/g;)V

    .line 32
    .line 33
    .line 34
    const/4 v2, 0x3

    .line 35
    iget-object p2, p2, Lad/q;->d:Ljava/lang/Double;

    .line 36
    .line 37
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/o;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
