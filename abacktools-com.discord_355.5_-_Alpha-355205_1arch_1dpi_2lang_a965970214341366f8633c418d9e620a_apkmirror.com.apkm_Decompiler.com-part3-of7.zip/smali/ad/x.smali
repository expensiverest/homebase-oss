###### Class ad.x (ad.x)
.class public final synthetic Lad/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/x;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/x;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/x;->a:Lad/x;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.GiftIntentSecondaryCtaData"

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "recipientUserId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "giftIntentType"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    sput-object v1, Lad/x;->descriptor:Ll70/g;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 14

    .line 1
    sget-object v0, Lad/x;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x2

    .line 12
    const/4 v3, 0x1

    .line 13
    const/4 v4, 0x0

    .line 14
    const/4 v5, 0x0

    .line 15
    if-eqz v1, :cond_2c

    .line 16
    .line 17
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 18
    .line 19
    invoke-interface {p1, v0, v4, v1, v5}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 24
    .line 25
    if-eqz v1, :cond_1d

    .line 26
    .line 27
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move-object v1, v5

    .line 31
    :goto_1e
    sget-object v4, Lyh/p;->a:Lyh/p;

    .line 32
    .line 33
    invoke-interface {p1, v0, v3, v4, v5}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    check-cast v3, Lcom/discord/primitives/UserId;

    .line 38
    .line 39
    invoke-interface {p1, v0, v2}, Lm70/a;->p(Ll70/g;I)I

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    const/4 v4, 0x7

    .line 44
    goto :goto_77

    .line 45
    :cond_2c
    move v9, v3

    .line 46
    move v6, v4

    .line 47
    move v8, v6

    .line 48
    move-object v1, v5

    .line 49
    move-object v7, v1

    .line 50
    :goto_31
    if-eqz v9, :cond_74

    .line 51
    .line 52
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 53
    .line 54
    .line 55
    move-result v10

    .line 56
    const/4 v11, -0x1

    .line 57
    if-eq v10, v11, :cond_72

    .line 58
    .line 59
    if-eqz v10, :cond_58

    .line 60
    .line 61
    if-eq v10, v3, :cond_4d

    .line 62
    .line 63
    if-ne v10, v2, :cond_47

    .line 64
    .line 65
    invoke-interface {p1, v0, v2}, Lm70/a;->p(Ll70/g;I)I

    .line 66
    .line 67
    .line 68
    move-result v6

    .line 69
    or-int/lit8 v8, v8, 0x4

    .line 70
    .line 71
    goto :goto_31

    .line 72
    :cond_47
    new-instance p1, Lj70/k;

    .line 73
    .line 74
    invoke-direct {p1, v10}, Lj70/k;-><init>(I)V

    .line 75
    .line 76
    .line 77
    throw p1

    .line 78
    :cond_4d
    sget-object v10, Lyh/p;->a:Lyh/p;

    .line 79
    .line 80
    invoke-interface {p1, v0, v3, v10, v7}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v7

    .line 84
    check-cast v7, Lcom/discord/primitives/UserId;

    .line 85
    .line 86
    or-int/lit8 v8, v8, 0x2

    .line 87
    .line 88
    goto :goto_31

    .line 89
    :cond_58
    sget-object v10, Lyh/h;->a:Lyh/h;

    .line 90
    .line 91
    if-eqz v1, :cond_62

    .line 92
    .line 93
    new-instance v11, Lcom/discord/primitives/MessageId;

    .line 94
    .line 95
    invoke-direct {v11, v1}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    goto :goto_63

    .line 99
    :cond_62
    move-object v11, v5

    .line 100
    :goto_63
    invoke-interface {p1, v0, v4, v10, v11}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 105
    .line 106
    if-eqz v1, :cond_6e

    .line 107
    .line 108
    iget-object v1, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 109
    .line 110
    goto :goto_6f

    .line 111
    :cond_6e
    move-object v1, v5

    .line 112
    :goto_6f
    or-int/lit8 v8, v8, 0x1

    .line 113
    .line 114
    goto :goto_31

    .line 115
    :cond_72
    move v9, v4

    .line 116
    goto :goto_31

    .line 117
    :cond_74
    move v2, v6

    .line 118
    move-object v3, v7

    .line 119
    move v4, v8

    .line 120
    :goto_77
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 121
    .line 122
    .line 123
    new-instance p1, Lad/z;

    .line 124
    .line 125
    invoke-direct {p1, v4, v1, v3, v2}, Lad/z;-><init>(ILjava/lang/String;Lcom/discord/primitives/UserId;I)V

    .line 126
    .line 127
    .line 128
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Lyh/p;->a:Lyh/p;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 15
    .line 16
    const/4 v2, 0x2

    .line 17
    aput-object v1, v0, v2

    .line 18
    .line 19
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 8

    .line 1
    check-cast p2, Lad/z;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/x;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/z;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v2, p1, v0, v3, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 20
    .line 21
    .line 22
    sget-object v1, Lyh/p;->a:Lyh/p;

    .line 23
    .line 24
    iget-wide v2, p2, Lad/z;->b:J

    .line 25
    .line 26
    new-instance v4, Lcom/discord/primitives/UserId;

    .line 27
    .line 28
    invoke-direct {v4, v2, v3}, Lcom/discord/primitives/UserId;-><init>(J)V

    .line 29
    .line 30
    .line 31
    const/4 v2, 0x1

    .line 32
    invoke-interface {p1, v0, v2, v1, v4}, Lm70/b;->s(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const/4 v1, 0x2

    .line 36
    iget p2, p2, Lad/z;->c:I

    .line 37
    .line 38
    invoke-interface {p1, v1, p2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 39
    .line 40
    .line 41
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/x;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
