###### Class ad.i2 (ad.i2)
.class public final synthetic Lad/i2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/i2;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/i2;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/i2;->a:Lad/i2;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapButtonActionComponent"

    .line 11
    .line 12
    const/4 v3, 0x2

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "componentId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    sput-object v1, Lad/i2;->descriptor:Ll70/g;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 12

    .line 1
    sget-object v0, Lad/i2;->descriptor:Ll70/g;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p1}, Lm70/a;->z()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x1

    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v4, 0x0

    .line 14
    if-eqz v1, :cond_21

    .line 15
    .line 16
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 17
    .line 18
    invoke-interface {p1, v0, v3, v1, v4}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lcom/discord/primitives/MessageId;

    .line 23
    .line 24
    if-eqz v1, :cond_1b

    .line 25
    .line 26
    iget-object v4, v1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 27
    .line 28
    :cond_1b
    invoke-interface {p1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const/4 v2, 0x3

    .line 33
    goto :goto_5d

    .line 34
    :cond_21
    move v7, v2

    .line 35
    move v5, v3

    .line 36
    move-object v1, v4

    .line 37
    move-object v6, v1

    .line 38
    :goto_25
    if-eqz v7, :cond_5b

    .line 39
    .line 40
    invoke-interface {p1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    const/4 v9, -0x1

    .line 45
    if-eq v8, v9, :cond_59

    .line 46
    .line 47
    if-eqz v8, :cond_3f

    .line 48
    .line 49
    if-ne v8, v2, :cond_39

    .line 50
    .line 51
    invoke-interface {p1, v0, v2}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    or-int/lit8 v5, v5, 0x2

    .line 56
    .line 57
    goto :goto_25

    .line 58
    :cond_39
    new-instance p1, Lj70/k;

    .line 59
    .line 60
    invoke-direct {p1, v8}, Lj70/k;-><init>(I)V

    .line 61
    .line 62
    .line 63
    throw p1

    .line 64
    :cond_3f
    sget-object v8, Lyh/h;->a:Lyh/h;

    .line 65
    .line 66
    if-eqz v6, :cond_49

    .line 67
    .line 68
    new-instance v9, Lcom/discord/primitives/MessageId;

    .line 69
    .line 70
    invoke-direct {v9, v6}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    move-object v9, v4

    .line 75
    :goto_4a
    invoke-interface {p1, v0, v3, v8, v9}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    check-cast v6, Lcom/discord/primitives/MessageId;

    .line 80
    .line 81
    if-eqz v6, :cond_55

    .line 82
    .line 83
    iget-object v6, v6, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 84
    .line 85
    goto :goto_56

    .line 86
    :cond_55
    move-object v6, v4

    .line 87
    :goto_56
    or-int/lit8 v5, v5, 0x1

    .line 88
    .line 89
    goto :goto_25

    .line 90
    :cond_59
    move v7, v3

    .line 91
    goto :goto_25

    .line 92
    :cond_5b
    move v2, v5

    .line 93
    move-object v4, v6

    .line 94
    :goto_5d
    invoke-interface {p1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 95
    .line 96
    .line 97
    new-instance p1, Lad/k2;

    .line 98
    .line 99
    invoke-direct {p1, v2, v4, v1}, Lad/k2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    return-object p1
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/k2;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/i2;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 15
    .line 16
    iget-object v2, p2, Lad/k2;->a:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-static {v2, p1, v0, v3, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 20
    .line 21
    .line 22
    const/4 v1, 0x1

    .line 23
    iget-object p2, p2, Lad/k2;->b:Ljava/lang/String;

    .line 24
    .line 25
    invoke-interface {p1, v0, v1, p2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/i2;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
