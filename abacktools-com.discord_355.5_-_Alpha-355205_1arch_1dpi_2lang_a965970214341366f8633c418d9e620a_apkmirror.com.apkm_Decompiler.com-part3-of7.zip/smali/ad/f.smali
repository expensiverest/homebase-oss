###### Class ad.f (ad.f)
.class public final Lad/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La40/d;


# instance fields
.field public final synthetic d:Lad/g;


# direct methods
.method public constructor <init>(Lad/g;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lad/f;->d:Lad/g;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 1
    check-cast p1, Lcom/discord/primitives/MessageId;

    .line 2
    .line 3
    iget-object v3, p1, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 4
    .line 5
    check-cast p2, Lcom/discord/primitives/ChannelId;

    .line 6
    .line 7
    iget-wide p1, p2, Lcom/discord/primitives/ChannelId;->d:J

    .line 8
    .line 9
    check-cast p3, Ljava/lang/Integer;

    .line 10
    .line 11
    check-cast p4, Lq9/o;

    .line 12
    .line 13
    move-object v6, p5

    .line 14
    check-cast v6, Ljava/lang/String;

    .line 15
    .line 16
    move-object v2, p6

    .line 17
    check-cast v2, Ljava/lang/Integer;

    .line 18
    .line 19
    const-string p5, "$v$c$com-discord-primitives-MessageId$-messageId$0"

    .line 20
    .line 21
    invoke-static {v3, p5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object p5, p0, Lad/f;->d:Lad/g;

    .line 25
    .line 26
    iget-object p5, p5, Lad/g;->a:Lad/d;

    .line 27
    .line 28
    new-instance v0, Lad/a1;

    .line 29
    .line 30
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    if-eqz p3, :cond_29

    .line 35
    .line 36
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    :goto_27
    move v1, p1

    .line 41
    goto :goto_2b

    .line 42
    :cond_29
    const/4 p1, 0x0

    .line 43
    goto :goto_27

    .line 44
    :goto_2b
    if-eqz p4, :cond_31

    .line 45
    .line 46
    iget-object p1, p4, Lq9/o;->d:Ljava/lang/String;

    .line 47
    .line 48
    :goto_2f
    move-object v5, p1

    .line 49
    goto :goto_34

    .line 50
    :cond_31
    const-string p1, ""

    .line 51
    .line 52
    goto :goto_2f

    .line 53
    :goto_34
    invoke-direct/range {v0 .. v6}, Lad/a1;-><init>(ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p5, v0}, Lad/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 60
    .line 61
    return-object p1
.end method
