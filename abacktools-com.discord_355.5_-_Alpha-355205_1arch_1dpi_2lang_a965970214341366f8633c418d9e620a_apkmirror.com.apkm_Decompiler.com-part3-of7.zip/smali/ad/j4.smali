###### Class ad.j4 (ad.j4)
.class public final Lad/j4;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/i4;->a:Lad/i4;

    .line 2
    .line 3
    return-object v0
.end method
