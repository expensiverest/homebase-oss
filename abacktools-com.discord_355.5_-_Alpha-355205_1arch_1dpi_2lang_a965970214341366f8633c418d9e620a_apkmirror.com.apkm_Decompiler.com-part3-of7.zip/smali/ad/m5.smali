###### Class ad.m5 (ad.m5)
.class public final Lad/m5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ly9/x3;

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ly9/x3;Ljava/lang/String;)V
    .registers 6

    .line 1
    const-string v0, "content"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lad/m5;->a:Ljava/lang/String;

    .line 4
    iput-object p2, p0, Lad/m5;->b:Ljava/lang/String;

    .line 5
    iput-object p3, p0, Lad/m5;->c:Ly9/x3;

    .line 6
    iput-object p4, p0, Lad/m5;->d:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ly9/c1;)V
    .registers 5

    .line 7
    const-string v0, "node"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    iget-object v0, p2, Ly9/c1;->b:Ly9/x3;

    .line 9
    iget-object p2, p2, Ly9/c1;->a:Ljava/util/List;

    invoke-static {p2}, Ly9/x;->a(Ljava/util/List;)Ljava/lang/String;

    move-result-object v1

    .line 10
    invoke-static {p2}, Ly9/x;->a(Ljava/util/List;)Ljava/lang/String;

    move-result-object p2

    .line 11
    invoke-direct {p0, p1, p2, v0, v1}, Lad/m5;-><init>(Ljava/lang/String;Ljava/lang/String;Ly9/x3;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableMap;
    .registers 13

    .line 1
    iget-object v0, p0, Lad/m5;->d:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "content"

    .line 4
    .line 5
    const-string v2, "target"

    .line 6
    .line 7
    iget-object v3, p0, Lad/m5;->b:Ljava/lang/String;

    .line 8
    .line 9
    const-string v4, "title"

    .line 10
    .line 11
    const-string v5, "node"

    .line 12
    .line 13
    const-string v6, "url"

    .line 14
    .line 15
    const-string v7, "messageId"

    .line 16
    .line 17
    iget-object v8, p0, Lad/m5;->c:Ly9/x3;

    .line 18
    .line 19
    if-eqz v8, :cond_235

    .line 20
    .line 21
    const/4 v9, 0x0

    .line 22
    new-array v10, v9, [Ll30/j;

    .line 23
    .line 24
    invoke-static {v10}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 25
    .line 26
    .line 27
    move-result-object v10

    .line 28
    instance-of v11, v8, Ly9/w3;

    .line 29
    .line 30
    if-eqz v11, :cond_42

    .line 31
    .line 32
    check-cast v8, Ly9/w3;

    .line 33
    .line 34
    iget-object v7, v8, Ly9/w3;->a:Ljava/lang/String;

    .line 35
    .line 36
    invoke-static {v10, v6, v7}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    new-instance v6, Ll30/j;

    .line 40
    .line 41
    invoke-direct {v6, v4, v3}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    new-instance v3, Ll30/j;

    .line 45
    .line 46
    invoke-direct {v3, v2, v7}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    new-instance v2, Ll30/j;

    .line 50
    .line 51
    invoke-direct {v2, v1, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    filled-new-array {v6, v3, v2}, [Ll30/j;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-static {v10, v5, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    goto/16 :goto_269

    .line 66
    .line 67
    :cond_42
    instance-of v0, v8, Ly9/v2;

    .line 68
    .line 69
    const-string v1, "action"

    .line 70
    .line 71
    if-eqz v0, :cond_5c

    .line 72
    .line 73
    check-cast v8, Ly9/v2;

    .line 74
    .line 75
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 76
    .line 77
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    iget-wide v0, v8, Ly9/v2;->c:J

    .line 81
    .line 82
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    const-string v1, "threadId"

    .line 87
    .line 88
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    goto/16 :goto_269

    .line 92
    .line 93
    :cond_5c
    instance-of v0, v8, Ly9/k3;

    .line 94
    .line 95
    const-string v2, "userId"

    .line 96
    .line 97
    const-string v3, "messageChannelId"

    .line 98
    .line 99
    if-eqz v0, :cond_83

    .line 100
    .line 101
    check-cast v8, Ly9/k3;

    .line 102
    .line 103
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 104
    .line 105
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    iget-wide v0, v8, Ly9/k3;->c:J

    .line 109
    .line 110
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    invoke-static {v10, v2, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    iget-object v0, v8, Ly9/k3;->h:Lcom/discord/primitives/ChannelId;

    .line 118
    .line 119
    if-eqz v0, :cond_269

    .line 120
    .line 121
    iget-wide v0, v0, Lcom/discord/primitives/ChannelId;->d:J

    .line 122
    .line 123
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    invoke-static {v10, v3, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    goto/16 :goto_269

    .line 131
    .line 132
    :cond_83
    instance-of v0, v8, Ly9/e3;

    .line 133
    .line 134
    if-eqz v0, :cond_bf

    .line 135
    .line 136
    check-cast v8, Ly9/e3;

    .line 137
    .line 138
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 139
    .line 140
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    iget-wide v0, v8, Ly9/e3;->c:J

    .line 144
    .line 145
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-static {v10, v2, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    iget-object v0, v8, Ly9/e3;->f:Lq9/z;

    .line 153
    .line 154
    iget v0, v0, Lq9/z;->d:I

    .line 155
    .line 156
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    const-string v1, "messageType"

    .line 161
    .line 162
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    iget-object v0, v8, Ly9/e3;->d:Ljava/lang/String;

    .line 166
    .line 167
    invoke-static {v10, v7, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    iget-wide v0, v8, Ly9/e3;->e:J

    .line 171
    .line 172
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    const-string v1, "applicationUserId"

    .line 177
    .line 178
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 179
    .line 180
    .line 181
    iget-wide v0, v8, Ly9/e3;->g:J

    .line 182
    .line 183
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    invoke-static {v10, v3, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    goto/16 :goto_269

    .line 191
    .line 192
    :cond_bf
    instance-of v0, v8, Ly9/p2;

    .line 193
    .line 194
    if-eqz v0, :cond_d5

    .line 195
    .line 196
    check-cast v8, Ly9/p2;

    .line 197
    .line 198
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 199
    .line 200
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    iget-wide v0, v8, Ly9/p2;->c:J

    .line 204
    .line 205
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    invoke-static {v10, v3, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    goto/16 :goto_269

    .line 213
    .line 214
    :cond_d5
    instance-of v0, v8, Ly9/u1;

    .line 215
    .line 216
    const-string v2, "channel_id"

    .line 217
    .line 218
    if-eqz v0, :cond_109

    .line 219
    .line 220
    check-cast v8, Ly9/u1;

    .line 221
    .line 222
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 223
    .line 224
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    iget-object v0, v8, Ly9/u1;->c:Ly9/t1;

    .line 228
    .line 229
    if-eqz v0, :cond_269

    .line 230
    .line 231
    new-array v1, v9, [Ll30/j;

    .line 232
    .line 233
    invoke-static {v1}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    iget-wide v3, v0, Ly9/t1;->a:J

    .line 238
    .line 239
    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v3

    .line 243
    invoke-static {v1, v2, v3}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    iget-object v0, v0, Ly9/t1;->b:Lcom/discord/primitives/GuildId;

    .line 247
    .line 248
    if-eqz v0, :cond_102

    .line 249
    .line 250
    const-string v0, "guild_id"

    .line 251
    .line 252
    invoke-virtual {v8}, Ly9/u1;->toString()Ljava/lang/String;

    .line 253
    .line 254
    .line 255
    move-result-object v2

    .line 256
    invoke-static {v1, v0, v2}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    :cond_102
    const-string v0, "messageReference"

    .line 260
    .line 261
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 262
    .line 263
    .line 264
    goto/16 :goto_269

    .line 265
    .line 266
    :cond_109
    instance-of v0, v8, Ly9/l1;

    .line 267
    .line 268
    const-string v4, "loggingName"

    .line 269
    .line 270
    const-string v5, "id"

    .line 271
    .line 272
    const-string v9, "message"

    .line 273
    .line 274
    if-eqz v0, :cond_15c

    .line 275
    .line 276
    check-cast v8, Ly9/l1;

    .line 277
    .line 278
    iget-object v0, v8, Ly9/l1;->c:Ly9/h1;

    .line 279
    .line 280
    iget-object v3, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 281
    .line 282
    invoke-static {v10, v1, v3}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    iget-object v1, v0, Ly9/h1;->a:Ljava/lang/String;

    .line 286
    .line 287
    new-instance v3, Ll30/j;

    .line 288
    .line 289
    invoke-direct {v3, v5, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    iget-wide v5, v0, Ly9/h1;->b:J

    .line 293
    .line 294
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v1

    .line 298
    new-instance v5, Ll30/j;

    .line 299
    .line 300
    invoke-direct {v5, v2, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 301
    .line 302
    .line 303
    iget-object v1, v0, Ly9/h1;->c:Ljava/lang/String;

    .line 304
    .line 305
    new-instance v2, Ll30/j;

    .line 306
    .line 307
    invoke-direct {v2, v4, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 308
    .line 309
    .line 310
    iget-object v0, v0, Ly9/h1;->d:Ly9/k1;

    .line 311
    .line 312
    iget-object v0, v0, Ly9/k1;->a:Ljava/lang/String;

    .line 313
    .line 314
    new-instance v1, Ll30/j;

    .line 315
    .line 316
    const-string v4, "username"

    .line 317
    .line 318
    invoke-direct {v1, v4, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 319
    .line 320
    .line 321
    filled-new-array {v1}, [Ll30/j;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    new-instance v1, Ll30/j;

    .line 330
    .line 331
    const-string v4, "author"

    .line 332
    .line 333
    invoke-direct {v1, v4, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    filled-new-array {v3, v5, v2, v1}, [Ll30/j;

    .line 337
    .line 338
    .line 339
    move-result-object v0

    .line 340
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    invoke-static {v10, v9, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 345
    .line 346
    .line 347
    goto/16 :goto_269

    .line 348
    .line 349
    :cond_15c
    instance-of v0, v8, Ly9/s2;

    .line 350
    .line 351
    if-eqz v0, :cond_183

    .line 352
    .line 353
    check-cast v8, Ly9/s2;

    .line 354
    .line 355
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 356
    .line 357
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 358
    .line 359
    .line 360
    const-string v0, "guildId"

    .line 361
    .line 362
    iget-object v1, v8, Ly9/s2;->c:Ljava/lang/String;

    .line 363
    .line 364
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 365
    .line 366
    .line 367
    const-string v0, "channelId"

    .line 368
    .line 369
    iget-object v1, v8, Ly9/s2;->e:Ljava/lang/String;

    .line 370
    .line 371
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 372
    .line 373
    .line 374
    iget-object v0, v8, Ly9/s2;->d:Ljava/lang/String;

    .line 375
    .line 376
    invoke-static {v10, v7, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 377
    .line 378
    .line 379
    const-string v0, "roleSubscriptionListingId"

    .line 380
    .line 381
    iget-object v1, v8, Ly9/s2;->f:Ljava/lang/String;

    .line 382
    .line 383
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    goto/16 :goto_269

    .line 387
    .line 388
    :cond_183
    instance-of v0, v8, Ly9/q3;

    .line 389
    .line 390
    if-eqz v0, :cond_1bd

    .line 391
    .line 392
    check-cast v8, Ly9/q3;

    .line 393
    .line 394
    iget-object v0, v8, Ly9/q3;->c:Ly9/p3;

    .line 395
    .line 396
    iget-object v3, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 397
    .line 398
    invoke-static {v10, v1, v3}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 399
    .line 400
    .line 401
    iget-object v1, v0, Ly9/p3;->a:Ljava/lang/String;

    .line 402
    .line 403
    new-instance v3, Ll30/j;

    .line 404
    .line 405
    invoke-direct {v3, v5, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 406
    .line 407
    .line 408
    iget-wide v5, v0, Ly9/p3;->b:J

    .line 409
    .line 410
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 411
    .line 412
    .line 413
    move-result-object v1

    .line 414
    new-instance v5, Ll30/j;

    .line 415
    .line 416
    invoke-direct {v5, v2, v1}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 417
    .line 418
    .line 419
    iget-object v0, v0, Ly9/p3;->c:Ljava/lang/String;

    .line 420
    .line 421
    new-instance v1, Ll30/j;

    .line 422
    .line 423
    invoke-direct {v1, v4, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    filled-new-array {v3, v5, v1}, [Ll30/j;

    .line 427
    .line 428
    .line 429
    move-result-object v0

    .line 430
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 431
    .line 432
    .line 433
    move-result-object v0

    .line 434
    invoke-static {v10, v9, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 435
    .line 436
    .line 437
    const-string v0, "notificationType"

    .line 438
    .line 439
    iget-object v1, v8, Ly9/q3;->d:Ljava/lang/String;

    .line 440
    .line 441
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 442
    .line 443
    .line 444
    goto/16 :goto_269

    .line 445
    .line 446
    :cond_1bd
    instance-of v0, v8, Ly9/g2;

    .line 447
    .line 448
    if-eqz v0, :cond_1d8

    .line 449
    .line 450
    check-cast v8, Ly9/g2;

    .line 451
    .line 452
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 453
    .line 454
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 455
    .line 456
    .line 457
    const-string v0, "targetChannelId"

    .line 458
    .line 459
    iget-object v1, v8, Ly9/g2;->c:Ljava/lang/String;

    .line 460
    .line 461
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 462
    .line 463
    .line 464
    const-string v0, "targetMessageId"

    .line 465
    .line 466
    iget-object v1, v8, Ly9/g2;->d:Ljava/lang/String;

    .line 467
    .line 468
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 469
    .line 470
    .line 471
    goto/16 :goto_269

    .line 472
    .line 473
    :cond_1d8
    instance-of v0, v8, Ly9/y2;

    .line 474
    .line 475
    const-string v2, "linkColor"

    .line 476
    .line 477
    if-eqz v0, :cond_1ec

    .line 478
    .line 479
    check-cast v8, Ly9/y2;

    .line 480
    .line 481
    iget-object v0, v8, Ly9/y2;->c:Ljava/lang/String;

    .line 482
    .line 483
    invoke-static {v10, v6, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 484
    .line 485
    .line 486
    iget-object v0, v8, Ly9/y2;->d:Ljava/lang/Integer;

    .line 487
    .line 488
    invoke-static {v10, v2, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 489
    .line 490
    .line 491
    goto/16 :goto_269

    .line 492
    .line 493
    :cond_1ec
    instance-of v0, v8, Ly9/j2;

    .line 494
    .line 495
    if-eqz v0, :cond_202

    .line 496
    .line 497
    check-cast v8, Ly9/j2;

    .line 498
    .line 499
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 500
    .line 501
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 502
    .line 503
    .line 504
    iget-object v0, v8, Ly9/j2;->c:Ljava/lang/String;

    .line 505
    .line 506
    invoke-static {v10, v3, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 507
    .line 508
    .line 509
    iget-object v0, v8, Ly9/j2;->d:Ljava/lang/Integer;

    .line 510
    .line 511
    invoke-static {v10, v2, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 512
    .line 513
    .line 514
    goto :goto_269

    .line 515
    :cond_202
    instance-of v0, v8, Ly9/x1;

    .line 516
    .line 517
    if-eqz v0, :cond_21e

    .line 518
    .line 519
    check-cast v8, Ly9/x1;

    .line 520
    .line 521
    iget-object v0, v8, Ly9/u3;->a:Ljava/lang/String;

    .line 522
    .line 523
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 524
    .line 525
    .line 526
    const-string v0, "text"

    .line 527
    .line 528
    iget-object v1, v8, Ly9/x1;->c:Ljava/lang/String;

    .line 529
    .line 530
    invoke-static {v10, v0, v1}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 531
    .line 532
    .line 533
    iget-object v0, v8, Ly9/x1;->d:Ljava/lang/Boolean;

    .line 534
    .line 535
    if-eqz v0, :cond_269

    .line 536
    .line 537
    const-string v1, "addSpace"

    .line 538
    .line 539
    invoke-static {v10, v1, v0}, Lgi/f;->i(Lcom/facebook/react/bridge/WritableNativeMap;Ljava/lang/String;Ljava/lang/Object;)V

    .line 540
    .line 541
    .line 542
    goto :goto_269

    .line 543
    :cond_21e
    sget-object v0, Lnf/a;->a:Lnf/a;

    .line 544
    .line 545
    new-instance v0, Ljava/lang/StringBuilder;

    .line 546
    .line 547
    const-string v1, "Missing target type data: "

    .line 548
    .line 549
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 550
    .line 551
    .line 552
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 553
    .line 554
    .line 555
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 556
    .line 557
    .line 558
    move-result-object v0

    .line 559
    const-string v1, "TapLink"

    .line 560
    .line 561
    const/4 v2, 0x0

    .line 562
    invoke-static {v1, v0, v2}, Lnf/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 563
    .line 564
    .line 565
    goto :goto_269

    .line 566
    :cond_235
    iget-object v9, p0, Lad/m5;->a:Ljava/lang/String;

    .line 567
    .line 568
    if-nez v9, :cond_23b

    .line 569
    .line 570
    const-string v9, "null"

    .line 571
    .line 572
    :cond_23b
    new-instance v10, Ll30/j;

    .line 573
    .line 574
    invoke-direct {v10, v7, v9}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 575
    .line 576
    .line 577
    new-instance v7, Ll30/j;

    .line 578
    .line 579
    invoke-direct {v7, v6, v8}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 580
    .line 581
    .line 582
    new-instance v6, Ll30/j;

    .line 583
    .line 584
    invoke-direct {v6, v4, v3}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 585
    .line 586
    .line 587
    new-instance v3, Ll30/j;

    .line 588
    .line 589
    invoke-direct {v3, v2, v8}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 590
    .line 591
    .line 592
    new-instance v2, Ll30/j;

    .line 593
    .line 594
    invoke-direct {v2, v1, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 595
    .line 596
    .line 597
    filled-new-array {v6, v3, v2}, [Ll30/j;

    .line 598
    .line 599
    .line 600
    move-result-object v0

    .line 601
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 602
    .line 603
    .line 604
    move-result-object v0

    .line 605
    new-instance v1, Ll30/j;

    .line 606
    .line 607
    invoke-direct {v1, v5, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 608
    .line 609
    .line 610
    filled-new-array {v10, v7, v1}, [Ll30/j;

    .line 611
    .line 612
    .line 613
    move-result-object v0

    .line 614
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 615
    .line 616
    .line 617
    move-result-object v10

    .line 618
    :cond_269
    :goto_269
    new-instance v0, Ll30/j;

    .line 619
    .line 620
    const-string v1, "data"

    .line 621
    .line 622
    invoke-direct {v0, v1, v10}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 623
    .line 624
    .line 625
    filled-new-array {v0}, [Ll30/j;

    .line 626
    .line 627
    .line 628
    move-result-object v0

    .line 629
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 630
    .line 631
    .line 632
    move-result-object v0

    .line 633
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lad/m5;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lad/m5;

    .line 12
    .line 13
    iget-object v1, p1, Lad/m5;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p0, Lad/m5;->a:Ljava/lang/String;

    .line 16
    .line 17
    if-nez v3, :cond_18

    .line 18
    .line 19
    if-nez v1, :cond_16

    .line 20
    .line 21
    move v1, v0

    .line 22
    goto :goto_1f

    .line 23
    :cond_16
    :goto_16
    move v1, v2

    .line 24
    goto :goto_1f

    .line 25
    :cond_18
    if-nez v1, :cond_1b

    .line 26
    .line 27
    goto :goto_16

    .line 28
    :cond_1b
    invoke-static {v3, v1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    :goto_1f
    if-nez v1, :cond_22

    .line 33
    .line 34
    return v2

    .line 35
    :cond_22
    iget-object v1, p0, Lad/m5;->b:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v3, p1, Lad/m5;->b:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_2d

    .line 44
    .line 45
    return v2

    .line 46
    :cond_2d
    iget-object v1, p0, Lad/m5;->c:Ly9/x3;

    .line 47
    .line 48
    iget-object v3, p1, Lad/m5;->c:Ly9/x3;

    .line 49
    .line 50
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-nez v1, :cond_38

    .line 55
    .line 56
    return v2

    .line 57
    :cond_38
    iget-object v1, p0, Lad/m5;->d:Ljava/lang/String;

    .line 58
    .line 59
    iget-object p1, p1, Lad/m5;->d:Ljava/lang/String;

    .line 60
    .line 61
    invoke-static {v1, p1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    if-nez p1, :cond_43

    .line 66
    .line 67
    return v2

    .line 68
    :cond_43
    return v0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lad/m5;->a:Ljava/lang/String;

    .line 3
    .line 4
    if-nez v1, :cond_7

    .line 5
    .line 6
    move v1, v0

    .line 7
    goto :goto_b

    .line 8
    :cond_7
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    :goto_b
    mul-int/lit8 v1, v1, 0x1f

    .line 13
    .line 14
    iget-object v2, p0, Lad/m5;->b:Ljava/lang/String;

    .line 15
    .line 16
    if-nez v2, :cond_13

    .line 17
    .line 18
    move v2, v0

    .line 19
    goto :goto_17

    .line 20
    :cond_13
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    :goto_17
    add-int/2addr v1, v2

    .line 25
    mul-int/lit8 v1, v1, 0x1f

    .line 26
    .line 27
    iget-object v2, p0, Lad/m5;->c:Ly9/x3;

    .line 28
    .line 29
    if-nez v2, :cond_1f

    .line 30
    .line 31
    goto :goto_23

    .line 32
    :cond_1f
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    :goto_23
    add-int/2addr v1, v0

    .line 37
    mul-int/lit8 v1, v1, 0x1f

    .line 38
    .line 39
    iget-object v0, p0, Lad/m5;->d:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    add-int/2addr v0, v1

    .line 46
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    iget-object v0, p0, Lad/m5;->a:Ljava/lang/String;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const-string v0, "null"

    .line 6
    .line 7
    :cond_6
    const-string v1, ", title="

    .line 8
    .line 9
    const-string v2, ", target="

    .line 10
    .line 11
    const-string v3, "TapLinkData(messageId="

    .line 12
    .line 13
    iget-object v4, p0, Lad/m5;->b:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {v3, v0, v1, v4, v2}, Lp/x2;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iget-object v1, p0, Lad/m5;->c:Ly9/x3;

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const-string v1, ", content="

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    iget-object v1, p0, Lad/m5;->d:Ljava/lang/String;

    .line 30
    .line 31
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string v1, ")"

    .line 35
    .line 36
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    return-object v0
.end method
