###### Class ad.d (ad.d)
.class public final synthetic Lad/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 1
    iput p1, p0, Lad/d;->d:I

    iput-object p2, p0, Lad/d;->e:Ljava/lang/Object;

    iput-object p3, p0, Lad/d;->i:Ljava/lang/Object;

    iput-object p4, p0, Lad/d;->v:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 45

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Lad/d;->d:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x0

    .line 9
    packed-switch v0, :pswitch_data_520

    .line 10
    .line 11
    .line 12
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Lzd/j;

    .line 15
    .line 16
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v2, Lde/b;

    .line 19
    .line 20
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v3, Lde/b;

    .line 23
    .line 24
    move-object/from16 v4, p1

    .line 25
    .line 26
    check-cast v4, Ljava/lang/Boolean;

    .line 27
    .line 28
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    iget-object v5, v0, Lzd/j;->u1:Lk7/m;

    .line 33
    .line 34
    invoke-virtual {v5}, Lk7/m;->k()Lbe/b;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    if-eqz v5, :cond_30

    .line 39
    .line 40
    if-eqz v4, :cond_2d

    .line 41
    .line 42
    invoke-virtual {v2, v0, v5}, Lde/b;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    goto :goto_30

    .line 46
    :cond_2d
    invoke-virtual {v3, v0, v5}, Lde/b;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    :cond_30
    :goto_30
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_33
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 53
    .line 54
    move-object v6, v0

    .line 55
    check-cast v6, Lab/h;

    .line 56
    .line 57
    iget-object v0, v1, Lad/d;->i:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v0, Lcom/discord/chat/presentation/message/MessageViewReplyPreview;

    .line 60
    .line 61
    iget-object v2, v0, Lcom/discord/chat/presentation/message/MessageViewReplyPreview;->U:Lfb/c0;

    .line 62
    .line 63
    iget-object v7, v1, Lad/d;->v:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v7, Lcom/discord/chat/bridge/Message;

    .line 66
    .line 67
    move-object/from16 v8, p1

    .line 68
    .line 69
    check-cast v8, Ljava/lang/Integer;

    .line 70
    .line 71
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 72
    .line 73
    .line 74
    move-result v8

    .line 75
    const-string v9, "getPaint(...)"

    .line 76
    .line 77
    const-string v10, "getFontMetrics(...)"

    .line 78
    .line 79
    const-string v11, "getContext(...)"

    .line 80
    .line 81
    if-eqz v6, :cond_dd

    .line 82
    .line 83
    iget-object v5, v2, Lfb/c0;->M:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v5, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 86
    .line 87
    move-object v12, v7

    .line 88
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 89
    .line 90
    .line 91
    move-result-object v7

    .line 92
    invoke-static {v7, v11}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    move v0, v8

    .line 96
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getId-3Eiw7ao()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v8

    .line 100
    invoke-static {v12}, Le00/a;->H(Lcom/discord/chat/bridge/Message;)Z

    .line 101
    .line 102
    .line 103
    move-result v11

    .line 104
    invoke-static {v12}, Le00/a;->J(Lcom/discord/chat/bridge/Message;)Z

    .line 105
    .line 106
    .line 107
    move-result v13

    .line 108
    move v14, v11

    .line 109
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getShouldShowRoleDot()Z

    .line 110
    .line 111
    .line 112
    move-result v11

    .line 113
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getShouldShowRoleOnName()Z

    .line 114
    .line 115
    .line 116
    move-result v12

    .line 117
    iget-object v2, v2, Lfb/c0;->M:Ljava/lang/Object;

    .line 118
    .line 119
    check-cast v2, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 120
    .line 121
    invoke-virtual {v2}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 122
    .line 123
    .line 124
    move-result-object v15

    .line 125
    invoke-virtual {v15}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    .line 126
    .line 127
    .line 128
    move-result-object v15

    .line 129
    invoke-static {v15, v10}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    iget v10, v15, Landroid/graphics/Paint$FontMetrics;->descent:F

    .line 133
    .line 134
    iget v15, v15, Landroid/graphics/Paint$FontMetrics;->ascent:F

    .line 135
    .line 136
    sub-float v32, v10, v15

    .line 137
    .line 138
    move v10, v13

    .line 139
    invoke-virtual {v2}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 140
    .line 141
    .line 142
    move-result-object v13

    .line 143
    invoke-static {v13, v9}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    const/16 v34, 0x0

    .line 147
    .line 148
    const v35, 0x1affff80

    .line 149
    .line 150
    .line 151
    move v9, v14

    .line 152
    const/4 v14, 0x0

    .line 153
    const/4 v15, 0x0

    .line 154
    const/16 v16, 0x0

    .line 155
    .line 156
    const/16 v17, 0x0

    .line 157
    .line 158
    const/16 v18, 0x0

    .line 159
    .line 160
    const/16 v19, 0x0

    .line 161
    .line 162
    const/16 v20, 0x0

    .line 163
    .line 164
    const/16 v21, 0x0

    .line 165
    .line 166
    const/16 v22, 0x0

    .line 167
    .line 168
    const/16 v23, 0x0

    .line 169
    .line 170
    const/16 v24, 0x0

    .line 171
    .line 172
    const/16 v25, 0x0

    .line 173
    .line 174
    const/16 v26, 0x0

    .line 175
    .line 176
    const/16 v27, 0x0

    .line 177
    .line 178
    const/16 v28, 0x0

    .line 179
    .line 180
    const/16 v29, 0x0

    .line 181
    .line 182
    const/16 v30, 0x0

    .line 183
    .line 184
    const/16 v31, 0x0

    .line 185
    .line 186
    const/16 v33, 0x0

    .line 187
    .line 188
    invoke-static/range {v6 .. v35}, Lcom/facebook/imagepipeline/nativecode/b;->n0(Lab/h;Landroid/content/Context;Ljava/lang/String;ZZZZLandroid/text/TextPaint;ZLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;La40/b;La40/b;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;La40/d;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Ljk/i;FLjava/lang/Float;ZI)Ldm/d;

    .line 189
    .line 190
    .line 191
    move-result-object v6

    .line 192
    new-instance v7, Lxj/a;

    .line 193
    .line 194
    invoke-direct {v7, v2}, Lxj/a;-><init>(Landroid/widget/TextView;)V

    .line 195
    .line 196
    .line 197
    invoke-static {v6, v7}, Lz20/g;->i(Landroid/text/Editable;Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    new-instance v2, Landroid/text/style/StyleSpan;

    .line 201
    .line 202
    invoke-direct {v2, v4}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v6}, Landroid/text/SpannableStringBuilder;->length()I

    .line 206
    .line 207
    .line 208
    move-result v4

    .line 209
    const/16 v7, 0x21

    .line 210
    .line 211
    invoke-virtual {v6, v2, v3, v4, v7}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 212
    .line 213
    .line 214
    invoke-static {v0, v6}, Lg8/i0;->i(ILdm/d;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v5, v6}, Lcom/facebook/drawee/span/SimpleDraweeSpanTextView;->setDraweeSpanStringBuilder(Ldm/d;)V

    .line 218
    .line 219
    .line 220
    goto/16 :goto_16f

    .line 221
    .line 222
    :cond_dd
    move-object v12, v7

    .line 223
    move v3, v8

    .line 224
    sget v4, Lcom/discord/chat/presentation/message/MessageViewReplyPreview;->W:I

    .line 225
    .line 226
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getContent()Lab/h;

    .line 227
    .line 228
    .line 229
    move-result-object v4

    .line 230
    if-eqz v4, :cond_168

    .line 231
    .line 232
    iget-object v4, v2, Lfb/c0;->M:Ljava/lang/Object;

    .line 233
    .line 234
    check-cast v4, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 235
    .line 236
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getContent()Lab/h;

    .line 237
    .line 238
    .line 239
    move-result-object v13

    .line 240
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 241
    .line 242
    .line 243
    move-result-object v14

    .line 244
    invoke-static {v14, v11}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getId-3Eiw7ao()Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v15

    .line 251
    invoke-static {v12}, Le00/a;->H(Lcom/discord/chat/bridge/Message;)Z

    .line 252
    .line 253
    .line 254
    move-result v16

    .line 255
    invoke-static {v12}, Le00/a;->J(Lcom/discord/chat/bridge/Message;)Z

    .line 256
    .line 257
    .line 258
    move-result v17

    .line 259
    invoke-static {v12}, Le00/a;->I(Lcom/discord/chat/bridge/Message;)Z

    .line 260
    .line 261
    .line 262
    move-result v21

    .line 263
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getShouldShowRoleDot()Z

    .line 264
    .line 265
    .line 266
    move-result v18

    .line 267
    invoke-virtual {v12}, Lcom/discord/chat/bridge/Message;->getShouldShowRoleOnName()Z

    .line 268
    .line 269
    .line 270
    move-result v19

    .line 271
    iget-object v0, v2, Lfb/c0;->M:Ljava/lang/Object;

    .line 272
    .line 273
    check-cast v0, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 274
    .line 275
    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 276
    .line 277
    .line 278
    move-result-object v2

    .line 279
    invoke-virtual {v2}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    .line 280
    .line 281
    .line 282
    move-result-object v2

    .line 283
    invoke-static {v2, v10}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    iget v5, v2, Landroid/graphics/Paint$FontMetrics;->descent:F

    .line 287
    .line 288
    iget v2, v2, Landroid/graphics/Paint$FontMetrics;->ascent:F

    .line 289
    .line 290
    sub-float v39, v5, v2

    .line 291
    .line 292
    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 293
    .line 294
    .line 295
    move-result-object v2

    .line 296
    invoke-static {v2, v9}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    const/16 v41, 0x0

    .line 300
    .line 301
    const v42, 0x1affff00

    .line 302
    .line 303
    .line 304
    const/16 v22, 0x0

    .line 305
    .line 306
    const/16 v23, 0x0

    .line 307
    .line 308
    const/16 v24, 0x0

    .line 309
    .line 310
    const/16 v25, 0x0

    .line 311
    .line 312
    const/16 v26, 0x0

    .line 313
    .line 314
    const/16 v27, 0x0

    .line 315
    .line 316
    const/16 v28, 0x0

    .line 317
    .line 318
    const/16 v29, 0x0

    .line 319
    .line 320
    const/16 v30, 0x0

    .line 321
    .line 322
    const/16 v31, 0x0

    .line 323
    .line 324
    const/16 v32, 0x0

    .line 325
    .line 326
    const/16 v33, 0x0

    .line 327
    .line 328
    const/16 v34, 0x0

    .line 329
    .line 330
    const/16 v35, 0x0

    .line 331
    .line 332
    const/16 v36, 0x0

    .line 333
    .line 334
    const/16 v37, 0x0

    .line 335
    .line 336
    const/16 v38, 0x0

    .line 337
    .line 338
    const/16 v40, 0x0

    .line 339
    .line 340
    move-object/from16 v20, v2

    .line 341
    .line 342
    invoke-static/range {v13 .. v42}, Lcom/facebook/imagepipeline/nativecode/b;->n0(Lab/h;Landroid/content/Context;Ljava/lang/String;ZZZZLandroid/text/TextPaint;ZLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;La40/b;La40/b;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;La40/d;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Ljk/i;FLjava/lang/Float;ZI)Ldm/d;

    .line 343
    .line 344
    .line 345
    move-result-object v2

    .line 346
    new-instance v5, Lxj/a;

    .line 347
    .line 348
    invoke-direct {v5, v0}, Lxj/a;-><init>(Landroid/widget/TextView;)V

    .line 349
    .line 350
    .line 351
    invoke-static {v2, v5}, Lz20/g;->i(Landroid/text/Editable;Ljava/lang/Object;)V

    .line 352
    .line 353
    .line 354
    invoke-static {v3, v2}, Lg8/i0;->i(ILdm/d;)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {v4, v2}, Lcom/facebook/drawee/span/SimpleDraweeSpanTextView;->setDraweeSpanStringBuilder(Ldm/d;)V

    .line 358
    .line 359
    .line 360
    goto :goto_16f

    .line 361
    :cond_168
    iget-object v0, v2, Lfb/c0;->M:Ljava/lang/Object;

    .line 362
    .line 363
    check-cast v0, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 364
    .line 365
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 366
    .line 367
    .line 368
    :goto_16f
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 369
    .line 370
    return-object v0

    .line 371
    :pswitch_172
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 372
    .line 373
    check-cast v0, Lbh/m;

    .line 374
    .line 375
    iget-object v6, v1, Lad/d;->i:Ljava/lang/Object;

    .line 376
    .line 377
    check-cast v6, Landroid/view/MotionEvent;

    .line 378
    .line 379
    iget-object v7, v1, Lad/d;->v:Ljava/lang/Object;

    .line 380
    .line 381
    check-cast v7, Lyg/e;

    .line 382
    .line 383
    move-object/from16 v8, p1

    .line 384
    .line 385
    check-cast v8, Lbh/k;

    .line 386
    .line 387
    const-string v9, "trashWrap"

    .line 388
    .line 389
    invoke-static {v8, v9}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 390
    .line 391
    .line 392
    iget-object v9, v8, Lbh/k;->v:Lk7/i;

    .line 393
    .line 394
    const-string v10, "motionEvent"

    .line 395
    .line 396
    invoke-static {v6, v10}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 397
    .line 398
    .line 399
    iget-object v10, v8, Lbh/k;->y:Landroid/graphics/Rect;

    .line 400
    .line 401
    invoke-virtual {v6}, Landroid/view/MotionEvent;->getRawX()F

    .line 402
    .line 403
    .line 404
    move-result v11

    .line 405
    float-to-int v11, v11

    .line 406
    invoke-virtual {v6}, Landroid/view/MotionEvent;->getRawY()F

    .line 407
    .line 408
    .line 409
    move-result v12

    .line 410
    float-to-int v12, v12

    .line 411
    invoke-virtual {v10, v11, v12}, Landroid/graphics/Rect;->contains(II)Z

    .line 412
    .line 413
    .line 414
    move-result v10

    .line 415
    if-eqz v10, :cond_1a1

    .line 416
    .line 417
    move-object v5, v0

    .line 418
    :cond_1a1
    iget-object v0, v9, Lk7/i;->v:Ljava/lang/Object;

    .line 419
    .line 420
    check-cast v0, Landroid/widget/FrameLayout;

    .line 421
    .line 422
    invoke-virtual {v0}, Landroid/view/View;->isActivated()Z

    .line 423
    .line 424
    .line 425
    move-result v10

    .line 426
    const-wide/16 v11, 0xc8

    .line 427
    .line 428
    if-eqz v5, :cond_1fa

    .line 429
    .line 430
    if-nez v10, :cond_1fa

    .line 431
    .line 432
    invoke-virtual {v0, v2}, Landroid/view/View;->setActivated(Z)V

    .line 433
    .line 434
    .line 435
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    .line 436
    .line 437
    .line 438
    move-result v10

    .line 439
    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    .line 440
    .line 441
    .line 442
    move-result v13

    .line 443
    invoke-static {v10, v13}, Ljava/lang/Math;->max(II)I

    .line 444
    .line 445
    .line 446
    move-result v10

    .line 447
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 448
    .line 449
    .line 450
    move-result v13

    .line 451
    invoke-static {v10, v13}, Ljava/lang/Math;->max(II)I

    .line 452
    .line 453
    .line 454
    move-result v10

    .line 455
    int-to-float v10, v10

    .line 456
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 457
    .line 458
    .line 459
    move-result v13

    .line 460
    int-to-float v13, v13

    .line 461
    div-float/2addr v10, v13

    .line 462
    const/high16 v13, 0x3f000000    # 0.5f

    .line 463
    .line 464
    add-float v16, v10, v13

    .line 465
    .line 466
    new-instance v14, Landroid/view/animation/ScaleAnimation;

    .line 467
    .line 468
    invoke-virtual {v0}, Landroid/view/View;->getScaleX()F

    .line 469
    .line 470
    .line 471
    move-result v15

    .line 472
    invoke-virtual {v0}, Landroid/view/View;->getScaleY()F

    .line 473
    .line 474
    .line 475
    move-result v17

    .line 476
    invoke-virtual {v0}, Landroid/view/View;->getPivotX()F

    .line 477
    .line 478
    .line 479
    move-result v19

    .line 480
    invoke-virtual {v0}, Landroid/view/View;->getPivotY()F

    .line 481
    .line 482
    .line 483
    move-result v20

    .line 484
    move/from16 v18, v16

    .line 485
    .line 486
    invoke-direct/range {v14 .. v20}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFFF)V

    .line 487
    .line 488
    .line 489
    invoke-virtual {v14, v11, v12}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 490
    .line 491
    .line 492
    new-instance v10, Landroid/view/animation/OvershootInterpolator;

    .line 493
    .line 494
    invoke-direct {v10}, Landroid/view/animation/OvershootInterpolator;-><init>()V

    .line 495
    .line 496
    .line 497
    invoke-virtual {v14, v10}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 498
    .line 499
    .line 500
    invoke-virtual {v14, v2}, Landroid/view/animation/Animation;->setFillAfter(Z)V

    .line 501
    .line 502
    .line 503
    invoke-virtual {v0, v14}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 504
    .line 505
    .line 506
    goto :goto_226

    .line 507
    :cond_1fa
    if-nez v5, :cond_226

    .line 508
    .line 509
    if-eqz v10, :cond_226

    .line 510
    .line 511
    invoke-virtual {v0, v3}, Landroid/view/View;->setActivated(Z)V

    .line 512
    .line 513
    .line 514
    invoke-virtual {v8, v3}, Landroid/view/View;->setActivated(Z)V

    .line 515
    .line 516
    .line 517
    new-instance v10, Landroid/view/animation/ScaleAnimation;

    .line 518
    .line 519
    invoke-virtual {v0}, Landroid/view/View;->getScaleX()F

    .line 520
    .line 521
    .line 522
    move-result v13

    .line 523
    const/high16 v14, 0x3f800000    # 1.0f

    .line 524
    .line 525
    invoke-virtual {v0}, Landroid/view/View;->getScaleY()F

    .line 526
    .line 527
    .line 528
    move-result v15

    .line 529
    invoke-direct {v10, v13, v14, v15, v14}, Landroid/view/animation/ScaleAnimation;-><init>(FFFF)V

    .line 530
    .line 531
    .line 532
    invoke-virtual {v10, v11, v12}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 533
    .line 534
    .line 535
    invoke-virtual {v8}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 536
    .line 537
    .line 538
    move-result-object v11

    .line 539
    const v12, 0x10c0007

    .line 540
    .line 541
    .line 542
    invoke-virtual {v10, v11, v12}, Landroid/view/animation/Animation;->setInterpolator(Landroid/content/Context;I)V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v10, v2}, Landroid/view/animation/Animation;->setFillAfter(Z)V

    .line 546
    .line 547
    .line 548
    invoke-virtual {v0, v10}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 549
    .line 550
    .line 551
    :cond_226
    :goto_226
    iget-object v0, v8, Lbh/k;->K:Lbh/c;

    .line 552
    .line 553
    invoke-static {v5, v0}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 554
    .line 555
    .line 556
    move-result v0

    .line 557
    if-nez v0, :cond_246

    .line 558
    .line 559
    if-eqz v5, :cond_237

    .line 560
    .line 561
    iget-object v0, v9, Lk7/i;->i:Ljava/lang/Object;

    .line 562
    .line 563
    check-cast v0, Lcom/facebook/drawee/view/SimpleDraweeView;

    .line 564
    .line 565
    invoke-virtual {v5, v0}, Lbh/c;->b(Landroid/view/View;)V

    .line 566
    .line 567
    .line 568
    :cond_237
    const/4 v0, 0x6

    .line 569
    invoke-virtual {v8, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 570
    .line 571
    .line 572
    iget-object v0, v8, Lbh/k;->K:Lbh/c;

    .line 573
    .line 574
    if-eqz v0, :cond_244

    .line 575
    .line 576
    sget-object v9, Lbh/c;->R:[Lh40/t;

    .line 577
    .line 578
    invoke-virtual {v0, v3}, Lbh/c;->a(Z)V

    .line 579
    .line 580
    .line 581
    :cond_244
    iput-object v5, v8, Lbh/k;->K:Lbh/c;

    .line 582
    .line 583
    :cond_246
    if-eqz v5, :cond_291

    .line 584
    .line 585
    invoke-virtual {v6}, Landroid/view/MotionEvent;->getAction()I

    .line 586
    .line 587
    .line 588
    move-result v0

    .line 589
    if-ne v0, v2, :cond_291

    .line 590
    .line 591
    iget-object v0, v7, Lyg/e;->d:Lah/a;

    .line 592
    .line 593
    invoke-virtual {v0}, Lah/a;->a()Lbh/l;

    .line 594
    .line 595
    .line 596
    move-result-object v0

    .line 597
    check-cast v0, Lbh/m;

    .line 598
    .line 599
    iget-object v2, v0, Lbh/c;->Q:Landroid/graphics/Point;

    .line 600
    .line 601
    if-eqz v2, :cond_264

    .line 602
    .line 603
    iget-object v3, v0, Lbh/c;->P:Landroid/graphics/Point;

    .line 604
    .line 605
    iget v5, v2, Landroid/graphics/Point;->x:I

    .line 606
    .line 607
    iput v5, v3, Landroid/graphics/Point;->x:I

    .line 608
    .line 609
    iget v2, v2, Landroid/graphics/Point;->y:I

    .line 610
    .line 611
    iput v2, v3, Landroid/graphics/Point;->y:I

    .line 612
    .line 613
    :cond_264
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 614
    .line 615
    .line 616
    move-result-object v2

    .line 617
    const v3, 0x7f020006

    .line 618
    .line 619
    .line 620
    invoke-static {v2, v3}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;

    .line 621
    .line 622
    .line 623
    move-result-object v2

    .line 624
    invoke-virtual {v2, v0}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    .line 625
    .line 626
    .line 627
    new-instance v3, Lbh/d;

    .line 628
    .line 629
    const/4 v5, 0x4

    .line 630
    invoke-direct {v3, v5, v7}, Lbh/d;-><init>(ILjava/lang/Object;)V

    .line 631
    .line 632
    .line 633
    invoke-virtual {v2, v3}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 634
    .line 635
    .line 636
    invoke-virtual {v2}, Landroid/animation/Animator;->start()V

    .line 637
    .line 638
    .line 639
    invoke-virtual {v0}, Lbh/c;->getX()F

    .line 640
    .line 641
    .line 642
    move-result v2

    .line 643
    float-to-int v2, v2

    .line 644
    invoke-virtual {v0}, Lbh/c;->getY()F

    .line 645
    .line 646
    .line 647
    move-result v3

    .line 648
    float-to-int v3, v3

    .line 649
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 650
    .line 651
    .line 652
    move-result v5

    .line 653
    div-int/2addr v5, v4

    .line 654
    add-int/2addr v5, v3

    .line 655
    invoke-static {v0, v2, v5}, Lbh/c;->c(Lbh/c;II)V

    .line 656
    .line 657
    .line 658
    :cond_291
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 659
    .line 660
    return-object v0

    .line 661
    :pswitch_294
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 662
    .line 663
    check-cast v0, Lcom/discord/age_assurance/PlayAgeSignalsModule;

    .line 664
    .line 665
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 666
    .line 667
    check-cast v2, Lsw/b;

    .line 668
    .line 669
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 670
    .line 671
    check-cast v3, Lcom/facebook/react/bridge/Promise;

    .line 672
    .line 673
    move-object/from16 v4, p1

    .line 674
    .line 675
    check-cast v4, Lsw/a;

    .line 676
    .line 677
    invoke-static {v0, v2, v3, v4}, Lcom/discord/age_assurance/PlayAgeSignalsModule;->c(Lcom/discord/age_assurance/PlayAgeSignalsModule;Lsw/b;Lcom/facebook/react/bridge/Promise;Lsw/a;)Ll30/a0;

    .line 678
    .line 679
    .line 680
    move-result-object v0

    .line 681
    return-object v0

    .line 682
    :pswitch_2a9
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 683
    .line 684
    check-cast v0, Ljava/lang/String;

    .line 685
    .line 686
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 687
    .line 688
    check-cast v2, Ljava/lang/Throwable;

    .line 689
    .line 690
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 691
    .line 692
    check-cast v3, Lcom/facebook/react/bridge/WritableMap;

    .line 693
    .line 694
    move-object/from16 v4, p1

    .line 695
    .line 696
    check-cast v4, Lcom/facebook/react/bridge/Promise;

    .line 697
    .line 698
    const-string v5, "it"

    .line 699
    .line 700
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 701
    .line 702
    .line 703
    invoke-interface {v4, v0, v2, v3}, Lcom/facebook/react/bridge/Promise;->reject(Ljava/lang/String;Ljava/lang/Throwable;Lcom/facebook/react/bridge/WritableMap;)V

    .line 704
    .line 705
    .line 706
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 707
    .line 708
    return-object v0

    .line 709
    :pswitch_2c4
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 710
    .line 711
    check-cast v0, Ljava/lang/String;

    .line 712
    .line 713
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 714
    .line 715
    check-cast v2, Ljava/lang/String;

    .line 716
    .line 717
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 718
    .line 719
    check-cast v3, Ljava/lang/Throwable;

    .line 720
    .line 721
    move-object/from16 v4, p1

    .line 722
    .line 723
    check-cast v4, Lcom/facebook/react/bridge/Promise;

    .line 724
    .line 725
    const-string v5, "it"

    .line 726
    .line 727
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 728
    .line 729
    .line 730
    invoke-interface {v4, v0, v2, v3}, Lcom/facebook/react/bridge/Promise;->reject(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 731
    .line 732
    .line 733
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 734
    .line 735
    return-object v0

    .line 736
    :pswitch_2df
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 737
    .line 738
    check-cast v0, Ljava/lang/String;

    .line 739
    .line 740
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 741
    .line 742
    check-cast v2, Ljava/lang/String;

    .line 743
    .line 744
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 745
    .line 746
    check-cast v3, Lcom/facebook/react/bridge/WritableMap;

    .line 747
    .line 748
    move-object/from16 v4, p1

    .line 749
    .line 750
    check-cast v4, Lcom/facebook/react/bridge/Promise;

    .line 751
    .line 752
    const-string v5, "it"

    .line 753
    .line 754
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 755
    .line 756
    .line 757
    invoke-interface {v4, v0, v2, v3}, Lcom/facebook/react/bridge/Promise;->reject(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 758
    .line 759
    .line 760
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 761
    .line 762
    return-object v0

    .line 763
    :pswitch_2fa
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 764
    .line 765
    move-object v5, v0

    .line 766
    check-cast v5, Lo20/h;

    .line 767
    .line 768
    iget-object v0, v1, Lad/d;->i:Ljava/lang/Object;

    .line 769
    .line 770
    move-object v6, v0

    .line 771
    check-cast v6, Lo20/l;

    .line 772
    .line 773
    iget-object v0, v1, Lad/d;->v:Ljava/lang/Object;

    .line 774
    .line 775
    move-object v7, v0

    .line 776
    check-cast v7, Lo20/k;

    .line 777
    .line 778
    move-object/from16 v0, p1

    .line 779
    .line 780
    check-cast v0, Lo20/i;

    .line 781
    .line 782
    const-string v2, "observer"

    .line 783
    .line 784
    invoke-static {v0, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 785
    .line 786
    .line 787
    check-cast v0, Lp20/a;

    .line 788
    .line 789
    const-string v2, "currentNavState"

    .line 790
    .line 791
    invoke-static {v5, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 792
    .line 793
    .line 794
    invoke-virtual {v0}, Lp20/a;->getEventEmitter$react_native_screens_release()Lp20/c;

    .line 795
    .line 796
    .line 797
    move-result-object v0

    .line 798
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 799
    .line 800
    .line 801
    iget-object v2, v0, La20/a;->c:Ljava/lang/Object;

    .line 802
    .line 803
    move-object v8, v2

    .line 804
    check-cast v8, Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 805
    .line 806
    new-instance v2, Lq20/c;

    .line 807
    .line 808
    iget-object v3, v0, La20/a;->b:Ljava/lang/Object;

    .line 809
    .line 810
    check-cast v3, Lcom/facebook/react/bridge/ReactContext;

    .line 811
    .line 812
    invoke-static {v3}, Lcom/facebook/react/uimanager/t0;->i(Landroid/content/Context;)I

    .line 813
    .line 814
    .line 815
    move-result v3

    .line 816
    iget v4, v0, La20/a;->a:I

    .line 817
    .line 818
    invoke-direct/range {v2 .. v7}, Lq20/c;-><init>(IILo20/h;Lo20/l;Lo20/k;)V

    .line 819
    .line 820
    .line 821
    invoke-interface {v8, v2}, Lcom/facebook/react/uimanager/events/EventDispatcher;->b(Lqp/f;)V

    .line 822
    .line 823
    .line 824
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 825
    .line 826
    return-object v0

    .line 827
    :pswitch_33a
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 828
    .line 829
    move-object v2, v0

    .line 830
    check-cast v2, Lle/b;

    .line 831
    .line 832
    iget-object v0, v1, Lad/d;->i:Ljava/lang/Object;

    .line 833
    .line 834
    check-cast v0, Ljava/lang/String;

    .line 835
    .line 836
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 837
    .line 838
    check-cast v3, Lle/c;

    .line 839
    .line 840
    move-object/from16 v4, p1

    .line 841
    .line 842
    check-cast v4, Landroid/graphics/Bitmap;

    .line 843
    .line 844
    monitor-enter v2

    .line 845
    :try_start_34c
    iget-object v6, v2, Lle/b;->d:Ljava/lang/String;

    .line 846
    .line 847
    invoke-static {v6, v0}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 848
    .line 849
    .line 850
    move-result v6
    :try_end_352
    .catchall {:try_start_34c .. :try_end_352} :catchall_35d

    .line 851
    if-nez v6, :cond_356

    .line 852
    .line 853
    :goto_354
    monitor-exit v2

    .line 854
    goto :goto_36a

    .line 855
    :cond_356
    :try_start_356
    iput-object v5, v2, Lle/b;->d:Ljava/lang/String;

    .line 856
    .line 857
    if-nez v4, :cond_35f

    .line 858
    .line 859
    iput-object v0, v2, Lle/b;->e:Ljava/lang/String;

    .line 860
    .line 861
    goto :goto_354

    .line 862
    :catchall_35d
    move-exception v0

    .line 863
    goto :goto_36d

    .line 864
    :cond_35f
    new-instance v5, Ll30/j;

    .line 865
    .line 866
    invoke-direct {v5, v0, v4}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 867
    .line 868
    .line 869
    iput-object v5, v2, Lle/b;->b:Ll30/j;
    :try_end_366
    .catchall {:try_start_356 .. :try_end_366} :catchall_35d

    .line 870
    .line 871
    monitor-exit v2

    .line 872
    invoke-virtual {v3}, Lle/c;->invoke()Ljava/lang/Object;

    .line 873
    .line 874
    .line 875
    :goto_36a
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 876
    .line 877
    return-object v0

    .line 878
    :goto_36d
    monitor-exit v2

    .line 879
    throw v0

    .line 880
    :pswitch_36f
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 881
    .line 882
    check-cast v0, Ljava/lang/String;

    .line 883
    .line 884
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 885
    .line 886
    check-cast v2, Ljava/lang/String;

    .line 887
    .line 888
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 889
    .line 890
    check-cast v3, Lcom/facebook/react/bridge/NativeArray;

    .line 891
    .line 892
    move-object/from16 v4, p1

    .line 893
    .line 894
    check-cast v4, Lcom/facebook/react/runtime/ReactInstance;

    .line 895
    .line 896
    sget-object v5, Lcom/facebook/react/runtime/ReactHostImpl;->x:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 897
    .line 898
    const-string v5, "reactInstance"

    .line 899
    .line 900
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 901
    .line 902
    .line 903
    invoke-virtual {v4, v0, v2, v3}, Lcom/facebook/react/runtime/ReactInstance;->callFunctionOnModule(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/react/bridge/NativeArray;)V

    .line 904
    .line 905
    .line 906
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 907
    .line 908
    return-object v0

    .line 909
    :pswitch_38c
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 910
    .line 911
    check-cast v0, Landroid/content/ContextWrapper;

    .line 912
    .line 913
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 914
    .line 915
    check-cast v2, Ljava/lang/String;

    .line 916
    .line 917
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 918
    .line 919
    check-cast v3, Lc9/q;

    .line 920
    .line 921
    move-object/from16 v4, p1

    .line 922
    .line 923
    check-cast v4, Ljava/lang/Exception;

    .line 924
    .line 925
    const-string v5, "it"

    .line 926
    .line 927
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 928
    .line 929
    .line 930
    sget-object v4, Li9/a;->a:Li9/a;

    .line 931
    .line 932
    invoke-virtual {v4, v0, v2, v3}, Li9/a;->d(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 933
    .line 934
    .line 935
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 936
    .line 937
    return-object v0

    .line 938
    :pswitch_3a9
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 939
    .line 940
    check-cast v0, Lcom/discord/chat/presentation/message/view/SpoilerView;

    .line 941
    .line 942
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 943
    .line 944
    check-cast v2, Landroid/view/View;

    .line 945
    .line 946
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 947
    .line 948
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 949
    .line 950
    move-object/from16 v4, p1

    .line 951
    .line 952
    check-cast v4, Ljava/lang/Boolean;

    .line 953
    .line 954
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 955
    .line 956
    .line 957
    move-result v5

    .line 958
    sget v6, Lcom/discord/chat/presentation/message/view/SpoilerView;->w:I

    .line 959
    .line 960
    invoke-virtual {v0, v2, v5}, Lcom/discord/chat/presentation/message/view/SpoilerView;->d(Landroid/view/View;Z)V

    .line 961
    .line 962
    .line 963
    invoke-interface {v3, v4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 964
    .line 965
    .line 966
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 967
    .line 968
    return-object v0

    .line 969
    :pswitch_3c8
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 970
    .line 971
    check-cast v0, Lcom/discord/chat/presentation/message/view/MediaView;

    .line 972
    .line 973
    iget-object v3, v1, Lad/d;->i:Ljava/lang/Object;

    .line 974
    .line 975
    check-cast v3, Leg/h0;

    .line 976
    .line 977
    iget-object v4, v1, Lad/d;->v:Ljava/lang/Object;

    .line 978
    .line 979
    check-cast v4, Leg/e0;

    .line 980
    .line 981
    move-object/from16 v6, p1

    .line 982
    .line 983
    check-cast v6, Landroid/view/View;

    .line 984
    .line 985
    sget v7, Lcom/discord/chat/presentation/message/view/MediaView;->i0:I

    .line 986
    .line 987
    const-string v7, "it"

    .line 988
    .line 989
    invoke-static {v6, v7}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 990
    .line 991
    .line 992
    invoke-interface {v3}, Leg/h0;->Q()Z

    .line 993
    .line 994
    .line 995
    move-result v6

    .line 996
    xor-int/2addr v2, v6

    .line 997
    iput-boolean v2, v0, Lcom/discord/chat/presentation/message/view/MediaView;->K:Z

    .line 998
    .line 999
    iget-object v2, v0, Lcom/discord/chat/presentation/message/view/MediaView;->f0:Lcom/discord/media_player/MediaPlayerManagerModule;

    .line 1000
    .line 1001
    if-eqz v2, :cond_3ed

    .line 1002
    .line 1003
    invoke-virtual {v2, v4}, Lcom/discord/media_player/MediaPlayerManagerModule;->stopPlayerProgressInterval(Leg/e0;)V

    .line 1004
    .line 1005
    .line 1006
    :cond_3ed
    iget-object v2, v4, Leg/e0;->k:Ljava/lang/Double;

    .line 1007
    .line 1008
    iget-object v4, v0, Lcom/discord/chat/presentation/message/view/MediaView;->i:Leg/e0;

    .line 1009
    .line 1010
    if-eqz v4, :cond_3f5

    .line 1011
    .line 1012
    iget-object v5, v4, Leg/e0;->k:Ljava/lang/Double;

    .line 1013
    .line 1014
    :cond_3f5
    if-nez v2, :cond_3fa

    .line 1015
    .line 1016
    if-nez v5, :cond_414

    .line 1017
    .line 1018
    goto :goto_408

    .line 1019
    :cond_3fa
    if-eqz v5, :cond_414

    .line 1020
    .line 1021
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 1022
    .line 1023
    .line 1024
    move-result-wide v6

    .line 1025
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    .line 1026
    .line 1027
    .line 1028
    move-result-wide v4

    .line 1029
    cmpl-double v2, v6, v4

    .line 1030
    .line 1031
    if-nez v2, :cond_414

    .line 1032
    .line 1033
    :goto_408
    invoke-interface {v3}, Leg/h0;->V()Z

    .line 1034
    .line 1035
    .line 1036
    move-result v2

    .line 1037
    if-nez v2, :cond_414

    .line 1038
    .line 1039
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 1040
    .line 1041
    .line 1042
    move-result v2

    .line 1043
    if-nez v2, :cond_417

    .line 1044
    .line 1045
    :cond_414
    invoke-virtual {v0}, Lcom/discord/chat/presentation/message/view/MediaView;->e()V

    .line 1046
    .line 1047
    .line 1048
    :cond_417
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1049
    .line 1050
    return-object v0

    .line 1051
    :pswitch_41a
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 1052
    .line 1053
    check-cast v0, Ljava/util/ArrayList;

    .line 1054
    .line 1055
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 1056
    .line 1057
    check-cast v2, Ljava/util/ArrayList;

    .line 1058
    .line 1059
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 1060
    .line 1061
    check-cast v3, Lkotlin/jvm/internal/s;

    .line 1062
    .line 1063
    move-object/from16 v4, p1

    .line 1064
    .line 1065
    check-cast v4, Lzd/g;

    .line 1066
    .line 1067
    if-eqz v4, :cond_441

    .line 1068
    .line 1069
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1070
    .line 1071
    .line 1072
    iget v0, v3, Lkotlin/jvm/internal/s;->d:I

    .line 1073
    .line 1074
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1075
    .line 1076
    .line 1077
    move-result-object v0

    .line 1078
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1079
    .line 1080
    .line 1081
    iget v0, v3, Lkotlin/jvm/internal/s;->d:I

    .line 1082
    .line 1083
    invoke-virtual {v4}, Lzd/g;->c()I

    .line 1084
    .line 1085
    .line 1086
    move-result v2

    .line 1087
    add-int/2addr v2, v0

    .line 1088
    iput v2, v3, Lkotlin/jvm/internal/s;->d:I

    .line 1089
    .line 1090
    :cond_441
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1091
    .line 1092
    return-object v0

    .line 1093
    :pswitch_444
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 1094
    .line 1095
    check-cast v0, [Ljava/security/cert/X509Certificate;

    .line 1096
    .line 1097
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 1098
    .line 1099
    check-cast v2, Ljava/lang/String;

    .line 1100
    .line 1101
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 1102
    .line 1103
    check-cast v3, Ljavax/net/ssl/SSLEngine;

    .line 1104
    .line 1105
    move-object/from16 v4, p1

    .line 1106
    .line 1107
    check-cast v4, Ljava/lang/String;

    .line 1108
    .line 1109
    const-string v6, "it"

    .line 1110
    .line 1111
    invoke-static {v4, v6}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1112
    .line 1113
    .line 1114
    sget-object v6, Lcom/margelo/nitro/nitrofetch/h;->a:Lcom/margelo/nitro/nitrofetch/h;

    .line 1115
    .line 1116
    sget-object v6, Lcom/margelo/nitro/nitrofetch/h;->h:Ll30/o;

    .line 1117
    .line 1118
    invoke-virtual {v6}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 1119
    .line 1120
    .line 1121
    move-result-object v6

    .line 1122
    check-cast v6, Ljavax/net/ssl/X509TrustManager;

    .line 1123
    .line 1124
    instance-of v7, v6, Ljavax/net/ssl/X509ExtendedTrustManager;

    .line 1125
    .line 1126
    if-eqz v7, :cond_46a

    .line 1127
    .line 1128
    move-object v5, v6

    .line 1129
    check-cast v5, Ljavax/net/ssl/X509ExtendedTrustManager;

    .line 1130
    .line 1131
    :cond_46a
    if-eqz v5, :cond_470

    .line 1132
    .line 1133
    invoke-virtual {v5, v0, v2, v3}, Ljavax/net/ssl/X509ExtendedTrustManager;->checkServerTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;Ljavax/net/ssl/SSLEngine;)V

    .line 1134
    .line 1135
    .line 1136
    goto :goto_47b

    .line 1137
    :cond_470
    sget-object v3, Lcom/margelo/nitro/nitrofetch/h;->i:Ll30/o;

    .line 1138
    .line 1139
    invoke-virtual {v3}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 1140
    .line 1141
    .line 1142
    move-result-object v3

    .line 1143
    check-cast v3, Landroid/net/http/X509TrustManagerExtensions;

    .line 1144
    .line 1145
    invoke-virtual {v3, v0, v2, v4}, Landroid/net/http/X509TrustManagerExtensions;->checkServerTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 1146
    .line 1147
    .line 1148
    :goto_47b
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1149
    .line 1150
    return-object v0

    .line 1151
    :pswitch_47e
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 1152
    .line 1153
    check-cast v0, [Ljava/security/cert/X509Certificate;

    .line 1154
    .line 1155
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 1156
    .line 1157
    check-cast v2, Ljava/lang/String;

    .line 1158
    .line 1159
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 1160
    .line 1161
    check-cast v3, Ljava/net/Socket;

    .line 1162
    .line 1163
    move-object/from16 v4, p1

    .line 1164
    .line 1165
    check-cast v4, Ljava/lang/String;

    .line 1166
    .line 1167
    const-string v6, "it"

    .line 1168
    .line 1169
    invoke-static {v4, v6}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1170
    .line 1171
    .line 1172
    sget-object v6, Lcom/margelo/nitro/nitrofetch/h;->a:Lcom/margelo/nitro/nitrofetch/h;

    .line 1173
    .line 1174
    sget-object v6, Lcom/margelo/nitro/nitrofetch/h;->h:Ll30/o;

    .line 1175
    .line 1176
    invoke-virtual {v6}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 1177
    .line 1178
    .line 1179
    move-result-object v6

    .line 1180
    check-cast v6, Ljavax/net/ssl/X509TrustManager;

    .line 1181
    .line 1182
    instance-of v7, v6, Ljavax/net/ssl/X509ExtendedTrustManager;

    .line 1183
    .line 1184
    if-eqz v7, :cond_4a4

    .line 1185
    .line 1186
    move-object v5, v6

    .line 1187
    check-cast v5, Ljavax/net/ssl/X509ExtendedTrustManager;

    .line 1188
    .line 1189
    :cond_4a4
    if-eqz v5, :cond_4aa

    .line 1190
    .line 1191
    invoke-virtual {v5, v0, v2, v3}, Ljavax/net/ssl/X509ExtendedTrustManager;->checkServerTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;Ljava/net/Socket;)V

    .line 1192
    .line 1193
    .line 1194
    goto :goto_4b5

    .line 1195
    :cond_4aa
    sget-object v3, Lcom/margelo/nitro/nitrofetch/h;->i:Ll30/o;

    .line 1196
    .line 1197
    invoke-virtual {v3}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 1198
    .line 1199
    .line 1200
    move-result-object v3

    .line 1201
    check-cast v3, Landroid/net/http/X509TrustManagerExtensions;

    .line 1202
    .line 1203
    invoke-virtual {v3, v0, v2, v4}, Landroid/net/http/X509TrustManagerExtensions;->checkServerTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    .line 1204
    .line 1205
    .line 1206
    :goto_4b5
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1207
    .line 1208
    return-object v0

    .line 1209
    :pswitch_4b8
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 1210
    .line 1211
    check-cast v0, Lcom/discord/crash_reporting/CrashReportingModule;

    .line 1212
    .line 1213
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 1214
    .line 1215
    check-cast v2, Lcom/discord/crash_reporting/c;

    .line 1216
    .line 1217
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 1218
    .line 1219
    check-cast v3, Lcom/facebook/react/bridge/Callback;

    .line 1220
    .line 1221
    move-object/from16 v4, p1

    .line 1222
    .line 1223
    check-cast v4, Lld/e;

    .line 1224
    .line 1225
    invoke-static {v0, v2, v3, v4}, Lcom/discord/crash_reporting/CrashReportingModule;->a(Lcom/discord/crash_reporting/CrashReportingModule;Lcom/discord/crash_reporting/c;Lcom/facebook/react/bridge/Callback;Lld/e;)Ll30/a0;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v0

    .line 1229
    return-object v0

    .line 1230
    :pswitch_4cd
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 1231
    .line 1232
    check-cast v0, Ljava/lang/String;

    .line 1233
    .line 1234
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 1235
    .line 1236
    check-cast v2, Lb20/g;

    .line 1237
    .line 1238
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 1239
    .line 1240
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1241
    .line 1242
    move-object/from16 v4, p1

    .line 1243
    .line 1244
    check-cast v4, Landroid/graphics/drawable/Drawable;

    .line 1245
    .line 1246
    iget-object v5, v2, Lb20/g;->b:Ljava/lang/String;

    .line 1247
    .line 1248
    invoke-static {v0, v5}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1249
    .line 1250
    .line 1251
    move-result v0

    .line 1252
    if-eqz v0, :cond_4f1

    .line 1253
    .line 1254
    iget-object v0, v2, Lb20/g;->a:Ljava/lang/String;

    .line 1255
    .line 1256
    if-nez v0, :cond_4f1

    .line 1257
    .line 1258
    new-instance v0, Lb20/a;

    .line 1259
    .line 1260
    invoke-direct {v0, v4}, Lb20/a;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 1261
    .line 1262
    .line 1263
    invoke-interface {v3, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1264
    .line 1265
    .line 1266
    :cond_4f1
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1267
    .line 1268
    return-object v0

    .line 1269
    :pswitch_4f4
    iget-object v0, v1, Lad/d;->e:Ljava/lang/Object;

    .line 1270
    .line 1271
    check-cast v0, Lui/b;

    .line 1272
    .line 1273
    iget-object v2, v1, Lad/d;->i:Ljava/lang/Object;

    .line 1274
    .line 1275
    check-cast v2, Landroid/content/Context;

    .line 1276
    .line 1277
    iget-object v3, v1, Lad/d;->v:Ljava/lang/Object;

    .line 1278
    .line 1279
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 1280
    .line 1281
    move-object/from16 v4, p1

    .line 1282
    .line 1283
    check-cast v4, Lui/a;

    .line 1284
    .line 1285
    const-string v5, "event"

    .line 1286
    .line 1287
    invoke-static {v4, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1288
    .line 1289
    .line 1290
    const-string v5, "null cannot be cast to non-null type com.facebook.react.bridge.ReactContext"

    .line 1291
    .line 1292
    invoke-static {v2, v5}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1293
    .line 1294
    .line 1295
    check-cast v2, Lcom/facebook/react/bridge/ReactContext;

    .line 1296
    .line 1297
    invoke-interface {v3}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1298
    .line 1299
    .line 1300
    move-result-object v3

    .line 1301
    check-cast v3, Ljava/lang/Number;

    .line 1302
    .line 1303
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 1304
    .line 1305
    .line 1306
    move-result v3

    .line 1307
    invoke-virtual {v0, v2, v3, v4}, Lui/b;->b(Lcom/facebook/react/bridge/ReactContext;ILui/a;)V

    .line 1308
    .line 1309
    .line 1310
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1311
    .line 1312
    return-object v0

    .line 1313
    :pswitch_data_520
    .packed-switch 0x0
        :pswitch_4f4
        :pswitch_4cd
        :pswitch_4b8
        :pswitch_47e
        :pswitch_444
        :pswitch_41a
        :pswitch_3c8
        :pswitch_3a9
        :pswitch_38c
        :pswitch_36f
        :pswitch_33a
        :pswitch_2fa
        :pswitch_2df
        :pswitch_2c4
        :pswitch_2a9
        :pswitch_294
        :pswitch_172
        :pswitch_33
    .end packed-switch
.end method
