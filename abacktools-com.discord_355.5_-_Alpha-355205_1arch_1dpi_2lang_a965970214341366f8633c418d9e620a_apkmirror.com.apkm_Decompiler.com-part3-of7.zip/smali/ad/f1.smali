###### Class ad.f1 (ad.f1)
.class public final Lad/f1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final serializer()Lj70/b;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lj70/b;"
        }
    .end annotation

    .line 1
    sget-object v0, Lad/e1;->a:Lad/e1;

    .line 2
    .line 3
    return-object v0
.end method
