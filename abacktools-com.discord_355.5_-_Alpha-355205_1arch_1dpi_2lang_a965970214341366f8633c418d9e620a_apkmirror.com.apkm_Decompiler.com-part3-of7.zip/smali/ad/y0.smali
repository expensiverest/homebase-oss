###### Class ad.y0 (ad.y0)
.class public final synthetic Lad/y0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/y0;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/y0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/y0;->a:Lad/y0;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.LongPressMessageEvent"

    .line 11
    .line 12
    const/4 v3, 0x6

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "messageId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "channelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "mediaIndex"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "mediaType"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-string v0, "componentId"

    .line 38
    .line 39
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 40
    .line 41
    .line 42
    const-string v0, "componentMediaIndex"

    .line 43
    .line 44
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 45
    .line 46
    .line 47
    sput-object v1, Lad/y0;->descriptor:Ll70/g;

    .line 48
    .line 49
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 26

    .line 1
    sget-object v0, Lad/y0;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x5

    .line 14
    const/4 v4, 0x3

    .line 15
    const/4 v5, 0x4

    .line 16
    const/4 v6, 0x2

    .line 17
    const/4 v7, 0x1

    .line 18
    const/4 v8, 0x0

    .line 19
    const/4 v9, 0x0

    .line 20
    if-eqz v2, :cond_47

    .line 21
    .line 22
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v7

    .line 30
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 31
    .line 32
    .line 33
    move-result v6

    .line 34
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 39
    .line 40
    invoke-interface {v1, v0, v5, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    check-cast v5, Ljava/lang/String;

    .line 45
    .line 46
    sget-object v8, Ln70/e0;->a:Ln70/e0;

    .line 47
    .line 48
    invoke-interface {v1, v0, v3, v8, v9}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    check-cast v3, Ljava/lang/Integer;

    .line 53
    .line 54
    const/16 v8, 0x3f

    .line 55
    .line 56
    move-object/from16 v18, v2

    .line 57
    .line 58
    move-object/from16 v23, v3

    .line 59
    .line 60
    move-object/from16 v21, v4

    .line 61
    .line 62
    move-object/from16 v22, v5

    .line 63
    .line 64
    move/from16 v20, v6

    .line 65
    .line 66
    move-object/from16 v19, v7

    .line 67
    .line 68
    move/from16 v17, v8

    .line 69
    .line 70
    goto/16 :goto_a5

    .line 71
    .line 72
    :cond_47
    move v15, v7

    .line 73
    move v2, v8

    .line 74
    move-object v10, v9

    .line 75
    move-object v11, v10

    .line 76
    move-object v12, v11

    .line 77
    move-object v13, v12

    .line 78
    move-object v14, v13

    .line 79
    move v9, v2

    .line 80
    :goto_4f
    if-eqz v15, :cond_97

    .line 81
    .line 82
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 83
    .line 84
    .line 85
    move-result v8

    .line 86
    packed-switch v8, :pswitch_data_ae

    .line 87
    .line 88
    .line 89
    new-instance v0, Lj70/k;

    .line 90
    .line 91
    invoke-direct {v0, v8}, Lj70/k;-><init>(I)V

    .line 92
    .line 93
    .line 94
    throw v0

    .line 95
    :pswitch_5e
    sget-object v8, Ln70/e0;->a:Ln70/e0;

    .line 96
    .line 97
    invoke-interface {v1, v0, v3, v8, v14}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v8

    .line 101
    move-object v14, v8

    .line 102
    check-cast v14, Ljava/lang/Integer;

    .line 103
    .line 104
    or-int/lit8 v9, v9, 0x20

    .line 105
    .line 106
    :goto_69
    const/4 v8, 0x0

    .line 107
    goto :goto_4f

    .line 108
    :pswitch_6b
    sget-object v8, Ln70/h1;->a:Ln70/h1;

    .line 109
    .line 110
    invoke-interface {v1, v0, v5, v8, v13}, Lm70/a;->s(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v8

    .line 114
    move-object v13, v8

    .line 115
    check-cast v13, Ljava/lang/String;

    .line 116
    .line 117
    or-int/lit8 v9, v9, 0x10

    .line 118
    .line 119
    goto :goto_69

    .line 120
    :pswitch_77
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v12

    .line 124
    or-int/lit8 v9, v9, 0x8

    .line 125
    .line 126
    goto :goto_69

    .line 127
    :pswitch_7e
    invoke-interface {v1, v0, v6}, Lm70/a;->p(Ll70/g;I)I

    .line 128
    .line 129
    .line 130
    move-result v2

    .line 131
    or-int/lit8 v9, v9, 0x4

    .line 132
    .line 133
    goto :goto_69

    .line 134
    :pswitch_85
    invoke-interface {v1, v0, v7}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v11

    .line 138
    or-int/lit8 v9, v9, 0x2

    .line 139
    .line 140
    goto :goto_69

    .line 141
    :pswitch_8c
    const/4 v8, 0x0

    .line 142
    invoke-interface {v1, v0, v8}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v10

    .line 146
    or-int/lit8 v9, v9, 0x1

    .line 147
    .line 148
    goto :goto_4f

    .line 149
    :pswitch_94
    const/4 v8, 0x0

    .line 150
    move v15, v8

    .line 151
    goto :goto_4f

    .line 152
    :cond_97
    move/from16 v20, v2

    .line 153
    .line 154
    move/from16 v17, v9

    .line 155
    .line 156
    move-object/from16 v18, v10

    .line 157
    .line 158
    move-object/from16 v19, v11

    .line 159
    .line 160
    move-object/from16 v21, v12

    .line 161
    .line 162
    move-object/from16 v22, v13

    .line 163
    .line 164
    move-object/from16 v23, v14

    .line 165
    .line 166
    :goto_a5
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 167
    .line 168
    .line 169
    new-instance v16, Lad/a1;

    .line 170
    .line 171
    invoke-direct/range {v16 .. v23}, Lad/a1;-><init>(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)V

    .line 172
    .line 173
    .line 174
    return-object v16

    .line 175
    :pswitch_data_ae
    .packed-switch -0x1
        :pswitch_94
        :pswitch_8c
        :pswitch_85
        :pswitch_7e
        :pswitch_77
        :pswitch_6b
        :pswitch_5e
    .end packed-switch
.end method

.method public final b()[Lj70/b;
    .registers 7

    .line 1
    sget-object v0, Ln70/h1;->a:Ln70/h1;

    .line 2
    .line 3
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 4
    .line 5
    invoke-static {v0}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-static {v1}, Lmn/a;->A(Lj70/b;)Lj70/b;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    const/4 v4, 0x6

    .line 14
    new-array v4, v4, [Lj70/b;

    .line 15
    .line 16
    const/4 v5, 0x0

    .line 17
    aput-object v0, v4, v5

    .line 18
    .line 19
    const/4 v5, 0x1

    .line 20
    aput-object v0, v4, v5

    .line 21
    .line 22
    const/4 v5, 0x2

    .line 23
    aput-object v1, v4, v5

    .line 24
    .line 25
    const/4 v1, 0x3

    .line 26
    aput-object v0, v4, v1

    .line 27
    .line 28
    const/4 v0, 0x4

    .line 29
    aput-object v2, v4, v0

    .line 30
    .line 31
    const/4 v0, 0x5

    .line 32
    aput-object v3, v4, v0

    .line 33
    .line 34
    return-object v4
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p2, Lad/a1;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/y0;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lad/a1;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-object v2, p2, Lad/a1;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget v2, p2, Lad/a1;->c:I

    .line 28
    .line 29
    invoke-interface {p1, v1, v2, v0}, Lm70/b;->n(IILl70/g;)V

    .line 30
    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    iget-object v2, p2, Lad/a1;->d:Ljava/lang/String;

    .line 34
    .line 35
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 39
    .line 40
    iget-object v2, p2, Lad/a1;->e:Ljava/lang/String;

    .line 41
    .line 42
    const/4 v3, 0x4

    .line 43
    invoke-interface {p1, v0, v3, v1, v2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    sget-object v1, Ln70/e0;->a:Ln70/e0;

    .line 47
    .line 48
    iget-object p2, p2, Lad/a1;->f:Ljava/lang/Integer;

    .line 49
    .line 50
    const/4 v2, 0x5

    .line 51
    invoke-interface {p1, v0, v2, v1, p2}, Lm70/b;->A(Ll70/g;ILj70/j;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/y0;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
