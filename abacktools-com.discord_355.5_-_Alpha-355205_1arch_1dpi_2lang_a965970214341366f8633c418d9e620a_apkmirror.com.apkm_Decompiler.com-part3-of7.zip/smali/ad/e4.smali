###### Class ad.e4 (ad.e4)
.class public final Lad/e4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lad/d4;


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lad/d4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/e4;->Companion:Lad/d4;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .registers 5

    const-string v0, "channelId"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "messageId"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, Lad/e4;->a:I

    .line 3
    iput-object p2, p0, Lad/e4;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lad/e4;->c:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .registers 7

    and-int/lit8 v0, p2, 0x7

    const/4 v1, 0x7

    if-ne v1, v0, :cond_f

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p3, p0, Lad/e4;->a:I

    iput-object p1, p0, Lad/e4;->b:Ljava/lang/String;

    iput-object p4, p0, Lad/e4;->c:Ljava/lang/String;

    return-void

    :cond_f
    sget-object p1, Lad/c4;->a:Lad/c4;

    invoke-virtual {p1}, Lad/c4;->d()Ll70/g;

    move-result-object p1

    invoke-static {p2, v1, p1}, Ln70/t0;->j(IILl70/g;)V

    const/4 p1, 0x0

    throw p1
.end method


# virtual methods
.method public final bridge a()Lcom/facebook/react/bridge/WritableMap;
    .registers 2

    .line 1
    invoke-static {p0}, Ls1/e;->J(Lui/a;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method
