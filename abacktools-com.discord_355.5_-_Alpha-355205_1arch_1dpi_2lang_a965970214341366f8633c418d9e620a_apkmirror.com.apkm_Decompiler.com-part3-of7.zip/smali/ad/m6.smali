###### Class ad.m6 (ad.m6)
.class public final synthetic Lad/m6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln70/z;


# static fields
.field public static final a:Lad/m6;

.field private static final descriptor:Ll70/g;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lad/m6;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/m6;->a:Lad/m6;

    .line 7
    .line 8
    new-instance v1, Ln70/v0;

    .line 9
    .line 10
    const-string v2, "com.discord.chat.reactevents.TapPostPreviewEmbedData"

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-direct {v1, v2, v0, v3}, Ln70/v0;-><init>(Ljava/lang/String;Ln70/z;I)V

    .line 14
    .line 15
    .line 16
    const-string v0, "guildId"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v0, "parentChannelId"

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 25
    .line 26
    .line 27
    const-string v0, "threadId"

    .line 28
    .line 29
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    const-string v0, "messageId"

    .line 33
    .line 34
    invoke-virtual {v1, v0, v2}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    sput-object v1, Lad/m6;->descriptor:Ll70/g;

    .line 38
    .line 39
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 21

    .line 1
    sget-object v0, Lad/m6;->descriptor:Ll70/g;

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lm70/c;->b(Ll70/g;)Lm70/a;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Lm70/a;->z()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x3

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v2, :cond_37

    .line 19
    .line 20
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    sget-object v6, Lyh/h;->a:Lyh/h;

    .line 33
    .line 34
    invoke-interface {v1, v0, v3, v6, v7}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, Lcom/discord/primitives/MessageId;

    .line 39
    .line 40
    if-eqz v3, :cond_2b

    .line 41
    .line 42
    iget-object v7, v3, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 43
    .line 44
    :cond_2b
    const/16 v3, 0xf

    .line 45
    .line 46
    move v14, v3

    .line 47
    move-object/from16 v17, v4

    .line 48
    .line 49
    move-object/from16 v16, v5

    .line 50
    .line 51
    move-object/from16 v18, v7

    .line 52
    .line 53
    :goto_34
    move-object v15, v2

    .line 54
    goto/16 :goto_8d

    .line 55
    .line 56
    :cond_37
    move v12, v5

    .line 57
    move v8, v6

    .line 58
    move-object v2, v7

    .line 59
    move-object v9, v2

    .line 60
    move-object v10, v9

    .line 61
    move-object v11, v10

    .line 62
    :goto_3d
    if-eqz v12, :cond_85

    .line 63
    .line 64
    invoke-interface {v1, v0}, Lm70/a;->m(Ll70/g;)I

    .line 65
    .line 66
    .line 67
    move-result v13

    .line 68
    const/4 v14, -0x1

    .line 69
    if-eq v13, v14, :cond_83

    .line 70
    .line 71
    if-eqz v13, :cond_7c

    .line 72
    .line 73
    if-eq v13, v5, :cond_75

    .line 74
    .line 75
    if-eq v13, v4, :cond_6e

    .line 76
    .line 77
    if-ne v13, v3, :cond_68

    .line 78
    .line 79
    sget-object v13, Lyh/h;->a:Lyh/h;

    .line 80
    .line 81
    if-eqz v11, :cond_58

    .line 82
    .line 83
    new-instance v14, Lcom/discord/primitives/MessageId;

    .line 84
    .line 85
    invoke-direct {v14, v11}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    goto :goto_59

    .line 89
    :cond_58
    move-object v14, v7

    .line 90
    :goto_59
    invoke-interface {v1, v0, v3, v13, v14}, Lm70/a;->f(Ll70/g;ILj70/b;Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v11

    .line 94
    check-cast v11, Lcom/discord/primitives/MessageId;

    .line 95
    .line 96
    if-eqz v11, :cond_64

    .line 97
    .line 98
    iget-object v11, v11, Lcom/discord/primitives/MessageId;->d:Ljava/lang/String;

    .line 99
    .line 100
    goto :goto_65

    .line 101
    :cond_64
    move-object v11, v7

    .line 102
    :goto_65
    or-int/lit8 v8, v8, 0x8

    .line 103
    .line 104
    goto :goto_3d

    .line 105
    :cond_68
    new-instance v0, Lj70/k;

    .line 106
    .line 107
    invoke-direct {v0, v13}, Lj70/k;-><init>(I)V

    .line 108
    .line 109
    .line 110
    throw v0

    .line 111
    :cond_6e
    invoke-interface {v1, v0, v4}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    or-int/lit8 v8, v8, 0x4

    .line 116
    .line 117
    goto :goto_3d

    .line 118
    :cond_75
    invoke-interface {v1, v0, v5}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v10

    .line 122
    or-int/lit8 v8, v8, 0x2

    .line 123
    .line 124
    goto :goto_3d

    .line 125
    :cond_7c
    invoke-interface {v1, v0, v6}, Lm70/a;->x(Ll70/g;I)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    or-int/lit8 v8, v8, 0x1

    .line 130
    .line 131
    goto :goto_3d

    .line 132
    :cond_83
    move v12, v6

    .line 133
    goto :goto_3d

    .line 134
    :cond_85
    move v14, v8

    .line 135
    move-object/from16 v17, v9

    .line 136
    .line 137
    move-object/from16 v16, v10

    .line 138
    .line 139
    move-object/from16 v18, v11

    .line 140
    .line 141
    goto :goto_34

    .line 142
    :goto_8d
    invoke-interface {v1, v0}, Lm70/a;->c(Ll70/g;)V

    .line 143
    .line 144
    .line 145
    new-instance v13, Lad/o6;

    .line 146
    .line 147
    invoke-direct/range {v13 .. v18}, Lad/o6;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    return-object v13
.end method

.method public final b()[Lj70/b;
    .registers 4

    .line 1
    const/4 v0, 0x4

    .line 2
    new-array v0, v0, [Lj70/b;

    .line 3
    .line 4
    sget-object v1, Ln70/h1;->a:Ln70/h1;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    aput-object v1, v0, v2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    aput-object v1, v0, v2

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    aput-object v1, v0, v2

    .line 14
    .line 15
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 16
    .line 17
    const/4 v2, 0x3

    .line 18
    aput-object v1, v0, v2

    .line 19
    .line 20
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lad/o6;

    .line 2
    .line 3
    const-string v0, "value"

    .line 4
    .line 5
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Lad/m6;->descriptor:Ll70/g;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lm70/d;->b(Ll70/g;)Lm70/b;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v1, 0x0

    .line 15
    iget-object v2, p2, Lad/o6;->a:Ljava/lang/String;

    .line 16
    .line 17
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    iget-object v2, p2, Lad/o6;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x2

    .line 27
    iget-object v2, p2, Lad/o6;->c:Ljava/lang/String;

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2}, Lm70/b;->d(Ll70/g;ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    sget-object v1, Lyh/h;->a:Lyh/h;

    .line 33
    .line 34
    iget-object p2, p2, Lad/o6;->d:Ljava/lang/String;

    .line 35
    .line 36
    const/4 v2, 0x3

    .line 37
    invoke-static {p2, p1, v0, v2, v1}, Lp/x2;->q(Ljava/lang/String;Lm70/b;Ll70/g;ILyh/h;)V

    .line 38
    .line 39
    .line 40
    invoke-interface {p1, v0}, Lm70/b;->c(Ll70/g;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lad/m6;->descriptor:Ll70/g;

    .line 2
    .line 3
    return-object v0
.end method
