###### Class ad.r4 (ad.r4)
.class public final Lad/r4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:Lad/u8;


# direct methods
.method public constructor <init>(IIIILad/u8;)V
    .registers 7

    .line 1
    const-string v0, "resizeMode"

    .line 2
    .line 3
    invoke-static {p5, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput p1, p0, Lad/r4;->a:I

    .line 10
    .line 11
    iput p2, p0, Lad/r4;->b:I

    .line 12
    .line 13
    iput p3, p0, Lad/r4;->c:I

    .line 14
    .line 15
    iput p4, p0, Lad/r4;->d:I

    .line 16
    .line 17
    iput-object p5, p0, Lad/r4;->e:Lad/u8;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/react/bridge/WritableNativeMap;
    .registers 8

    .line 1
    iget v0, p0, Lad/r4;->a:I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Ll30/j;

    .line 8
    .line 9
    const-string v2, "width"

    .line 10
    .line 11
    invoke-direct {v1, v2, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    iget v0, p0, Lad/r4;->b:I

    .line 15
    .line 16
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    new-instance v2, Ll30/j;

    .line 21
    .line 22
    const-string v3, "height"

    .line 23
    .line 24
    invoke-direct {v2, v3, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget v0, p0, Lad/r4;->c:I

    .line 28
    .line 29
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    new-instance v3, Ll30/j;

    .line 34
    .line 35
    const-string v4, "x"

    .line 36
    .line 37
    invoke-direct {v3, v4, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iget v0, p0, Lad/r4;->d:I

    .line 41
    .line 42
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    new-instance v4, Ll30/j;

    .line 47
    .line 48
    const-string v5, "y"

    .line 49
    .line 50
    invoke-direct {v4, v5, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lad/r4;->e:Lad/u8;

    .line 54
    .line 55
    iget-object v0, v0, Lad/u8;->d:Ljava/lang/String;

    .line 56
    .line 57
    new-instance v5, Ll30/j;

    .line 58
    .line 59
    const-string v6, "resizeMode"

    .line 60
    .line 61
    invoke-direct {v5, v6, v0}, Ll30/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    filled-new-array {v1, v2, v3, v4, v5}, [Ll30/j;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v0}, Lgi/f;->h([Ll30/j;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lad/r4;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lad/r4;

    .line 12
    .line 13
    iget v1, p0, Lad/r4;->a:I

    .line 14
    .line 15
    iget v3, p1, Lad/r4;->a:I

    .line 16
    .line 17
    if-eq v1, v3, :cond_13

    .line 18
    .line 19
    return v2

    .line 20
    :cond_13
    iget v1, p0, Lad/r4;->b:I

    .line 21
    .line 22
    iget v3, p1, Lad/r4;->b:I

    .line 23
    .line 24
    if-eq v1, v3, :cond_1a

    .line 25
    .line 26
    return v2

    .line 27
    :cond_1a
    iget v1, p0, Lad/r4;->c:I

    .line 28
    .line 29
    iget v3, p1, Lad/r4;->c:I

    .line 30
    .line 31
    if-eq v1, v3, :cond_21

    .line 32
    .line 33
    return v2

    .line 34
    :cond_21
    iget v1, p0, Lad/r4;->d:I

    .line 35
    .line 36
    iget v3, p1, Lad/r4;->d:I

    .line 37
    .line 38
    if-eq v1, v3, :cond_28

    .line 39
    .line 40
    return v2

    .line 41
    :cond_28
    iget-object v1, p0, Lad/r4;->e:Lad/u8;

    .line 42
    .line 43
    iget-object p1, p1, Lad/r4;->e:Lad/u8;

    .line 44
    .line 45
    if-eq v1, p1, :cond_2f

    .line 46
    .line 47
    return v2

    .line 48
    :cond_2f
    return v0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Lad/r4;->a:I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lad/r4;->b:I

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget v2, p0, Lad/r4;->c:I

    .line 17
    .line 18
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget v2, p0, Lad/r4;->d:I

    .line 23
    .line 24
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-object v1, p0, Lad/r4;->e:Lad/u8;

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    add-int/2addr v1, v0

    .line 35
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    const-string v0, ", height="

    .line 2
    .line 3
    const-string v1, ", x="

    .line 4
    .line 5
    iget v2, p0, Lad/r4;->a:I

    .line 6
    .line 7
    const-string v3, "Layout(width="

    .line 8
    .line 9
    iget v4, p0, Lad/r4;->b:I

    .line 10
    .line 11
    invoke-static {v2, v3, v4, v0, v1}, La1/h;->m(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, ", y="

    .line 16
    .line 17
    const-string v2, ", resizeMode="

    .line 18
    .line 19
    iget v3, p0, Lad/r4;->c:I

    .line 20
    .line 21
    iget v4, p0, Lad/r4;->d:I

    .line 22
    .line 23
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->t(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, Lad/r4;->e:Lad/u8;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, ")"

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    return-object v0
.end method
