###### Class ad.c (ad.c)
.class public final Lad/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lui/a;


# annotations
.annotation runtime Lj70/h;
.end annotation


# static fields
.field public static final Companion:Lad/b;


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Z

.field public final d:Z

.field public final e:Z

.field public final f:Z

.field public final g:Z

.field public final h:I

.field public final i:Ljava/lang/Double;

.field public final j:I

.field public final k:Ljava/lang/Double;

.field public final l:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lad/b;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lad/c;->Companion:Lad/b;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(IZZZZZZZILjava/lang/Double;ILjava/lang/Double;I)V
    .registers 16

    and-int/lit16 v0, p1, 0xfff

    const/16 v1, 0xfff

    if-ne v1, v0, :cond_22

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, Lad/c;->a:Z

    iput-boolean p3, p0, Lad/c;->b:Z

    iput-boolean p4, p0, Lad/c;->c:Z

    iput-boolean p5, p0, Lad/c;->d:Z

    iput-boolean p6, p0, Lad/c;->e:Z

    iput-boolean p7, p0, Lad/c;->f:Z

    iput-boolean p8, p0, Lad/c;->g:Z

    iput p9, p0, Lad/c;->h:I

    iput-object p10, p0, Lad/c;->i:Ljava/lang/Double;

    iput p11, p0, Lad/c;->j:I

    iput-object p12, p0, Lad/c;->k:Ljava/lang/Double;

    iput p13, p0, Lad/c;->l:I

    return-void

    :cond_22
    sget-object p2, Lad/a;->a:Lad/a;

    invoke-virtual {p2}, Lad/a;->d()Ll70/g;

    move-result-object p2

    invoke-static {p1, v1, p2}, Ln70/t0;->j(IILl70/g;)V

    const/4 p1, 0x0

    throw p1
.end method

.method public constructor <init>(ZZZZZZZILjava/lang/Double;ILjava/lang/Double;I)V
    .registers 13

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-boolean p1, p0, Lad/c;->a:Z

    .line 4
    iput-boolean p2, p0, Lad/c;->b:Z

    .line 5
    iput-boolean p3, p0, Lad/c;->c:Z

    .line 6
    iput-boolean p4, p0, Lad/c;->d:Z

    .line 7
    iput-boolean p5, p0, Lad/c;->e:Z

    .line 8
    iput-boolean p6, p0, Lad/c;->f:Z

    .line 9
    iput-boolean p7, p0, Lad/c;->g:Z

    .line 10
    iput p8, p0, Lad/c;->h:I

    .line 11
    iput-object p9, p0, Lad/c;->i:Ljava/lang/Double;

    .line 12
    iput p10, p0, Lad/c;->j:I

    .line 13
    iput-object p11, p0, Lad/c;->k:Ljava/lang/Double;

    .line 14
    iput p12, p0, Lad/c;->l:I

    return-void
.end method


# virtual methods
.method public final bridge a()Lcom/facebook/react/bridge/WritableMap;
    .registers 2

    .line 1
    invoke-static {p0}, Ls1/e;->J(Lui/a;)Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lad/c;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lad/c;

    .line 12
    .line 13
    iget-boolean v1, p0, Lad/c;->a:Z

    .line 14
    .line 15
    iget-boolean v3, p1, Lad/c;->a:Z

    .line 16
    .line 17
    if-eq v1, v3, :cond_13

    .line 18
    .line 19
    return v2

    .line 20
    :cond_13
    iget-boolean v1, p0, Lad/c;->b:Z

    .line 21
    .line 22
    iget-boolean v3, p1, Lad/c;->b:Z

    .line 23
    .line 24
    if-eq v1, v3, :cond_1a

    .line 25
    .line 26
    return v2

    .line 27
    :cond_1a
    iget-boolean v1, p0, Lad/c;->c:Z

    .line 28
    .line 29
    iget-boolean v3, p1, Lad/c;->c:Z

    .line 30
    .line 31
    if-eq v1, v3, :cond_21

    .line 32
    .line 33
    return v2

    .line 34
    :cond_21
    iget-boolean v1, p0, Lad/c;->d:Z

    .line 35
    .line 36
    iget-boolean v3, p1, Lad/c;->d:Z

    .line 37
    .line 38
    if-eq v1, v3, :cond_28

    .line 39
    .line 40
    return v2

    .line 41
    :cond_28
    iget-boolean v1, p0, Lad/c;->e:Z

    .line 42
    .line 43
    iget-boolean v3, p1, Lad/c;->e:Z

    .line 44
    .line 45
    if-eq v1, v3, :cond_2f

    .line 46
    .line 47
    return v2

    .line 48
    :cond_2f
    iget-boolean v1, p0, Lad/c;->f:Z

    .line 49
    .line 50
    iget-boolean v3, p1, Lad/c;->f:Z

    .line 51
    .line 52
    if-eq v1, v3, :cond_36

    .line 53
    .line 54
    return v2

    .line 55
    :cond_36
    iget-boolean v1, p0, Lad/c;->g:Z

    .line 56
    .line 57
    iget-boolean v3, p1, Lad/c;->g:Z

    .line 58
    .line 59
    if-eq v1, v3, :cond_3d

    .line 60
    .line 61
    return v2

    .line 62
    :cond_3d
    iget v1, p0, Lad/c;->h:I

    .line 63
    .line 64
    iget v3, p1, Lad/c;->h:I

    .line 65
    .line 66
    if-eq v1, v3, :cond_44

    .line 67
    .line 68
    return v2

    .line 69
    :cond_44
    iget-object v1, p0, Lad/c;->i:Ljava/lang/Double;

    .line 70
    .line 71
    iget-object v3, p1, Lad/c;->i:Ljava/lang/Double;

    .line 72
    .line 73
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    if-nez v1, :cond_4f

    .line 78
    .line 79
    return v2

    .line 80
    :cond_4f
    iget v1, p0, Lad/c;->j:I

    .line 81
    .line 82
    iget v3, p1, Lad/c;->j:I

    .line 83
    .line 84
    if-eq v1, v3, :cond_56

    .line 85
    .line 86
    return v2

    .line 87
    :cond_56
    iget-object v1, p0, Lad/c;->k:Ljava/lang/Double;

    .line 88
    .line 89
    iget-object v3, p1, Lad/c;->k:Ljava/lang/Double;

    .line 90
    .line 91
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    if-nez v1, :cond_61

    .line 96
    .line 97
    return v2

    .line 98
    :cond_61
    iget v1, p0, Lad/c;->l:I

    .line 99
    .line 100
    iget p1, p1, Lad/c;->l:I

    .line 101
    .line 102
    if-eq v1, p1, :cond_68

    .line 103
    .line 104
    return v2

    .line 105
    :cond_68
    return v0
.end method

.method public final hashCode()I
    .registers 5

    .line 1
    iget-boolean v0, p0, Lad/c;->a:Z

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Boolean;->hashCode(Z)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-boolean v2, p0, Lad/c;->b:Z

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-boolean v2, p0, Lad/c;->c:Z

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-boolean v2, p0, Lad/c;->d:Z

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-boolean v2, p0, Lad/c;->e:Z

    .line 29
    .line 30
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget-boolean v2, p0, Lad/c;->f:Z

    .line 35
    .line 36
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    iget-boolean v2, p0, Lad/c;->g:Z

    .line 41
    .line 42
    invoke-static {v0, v1, v2}, Lhs/q;->d(IIZ)I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    iget v2, p0, Lad/c;->h:I

    .line 47
    .line 48
    invoke-static {v2, v0, v1}, Lhs/q;->a(III)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    const/4 v2, 0x0

    .line 53
    iget-object v3, p0, Lad/c;->i:Ljava/lang/Double;

    .line 54
    .line 55
    if-nez v3, :cond_3a

    .line 56
    .line 57
    move v3, v2

    .line 58
    goto :goto_3e

    .line 59
    :cond_3a
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    :goto_3e
    add-int/2addr v0, v3

    .line 64
    mul-int/2addr v0, v1

    .line 65
    iget v3, p0, Lad/c;->j:I

    .line 66
    .line 67
    invoke-static {v3, v0, v1}, Lhs/q;->a(III)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    iget-object v3, p0, Lad/c;->k:Ljava/lang/Double;

    .line 72
    .line 73
    if-nez v3, :cond_4b

    .line 74
    .line 75
    goto :goto_4f

    .line 76
    :cond_4b
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    :goto_4f
    add-int/2addr v0, v2

    .line 81
    mul-int/2addr v0, v1

    .line 82
    iget v1, p0, Lad/c;->l:I

    .line 83
    .line 84
    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    add-int/2addr v1, v0

    .line 89
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "ChatScrollPositionEvent(isAtBottom="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-boolean v1, p0, Lad/c;->a:Z

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", isNearBottom="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-boolean v1, p0, Lad/c;->b:Z

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", isNearTop="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    const-string v1, ", dragging="

    .line 29
    .line 30
    const-string v2, ", decelerating="

    .line 31
    .line 32
    iget-boolean v3, p0, Lad/c;->c:Z

    .line 33
    .line 34
    iget-boolean v4, p0, Lad/c;->d:Z

    .line 35
    .line 36
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->w(Ljava/lang/StringBuilder;ZLjava/lang/String;ZLjava/lang/String;)V

    .line 37
    .line 38
    .line 39
    const-string v1, ", shouldShowJumpToPresent="

    .line 40
    .line 41
    const-string v2, ", isFirstMessageVisible="

    .line 42
    .line 43
    iget-boolean v3, p0, Lad/c;->e:Z

    .line 44
    .line 45
    iget-boolean v4, p0, Lad/c;->f:Z

    .line 46
    .line 47
    invoke-static {v0, v3, v1, v4, v2}, La1/h;->w(Ljava/lang/StringBuilder;ZLjava/lang/String;ZLjava/lang/String;)V

    .line 48
    .line 49
    .line 50
    iget-boolean v1, p0, Lad/c;->g:Z

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    const-string v1, ", firstVisibleMessageIndex="

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    iget v1, p0, Lad/c;->h:I

    .line 61
    .line 62
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string v1, ", firstVisibleMessagePercentVisible="

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    iget-object v1, p0, Lad/c;->i:Ljava/lang/Double;

    .line 71
    .line 72
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    const-string v1, ", lastVisibleMessageIndex="

    .line 76
    .line 77
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    iget v1, p0, Lad/c;->j:I

    .line 81
    .line 82
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    const-string v1, ", lastVisibleMessagePercentVisible="

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    iget-object v1, p0, Lad/c;->k:Ljava/lang/Double;

    .line 91
    .line 92
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v1, ", changesetUpdateId="

    .line 96
    .line 97
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    iget v1, p0, Lad/c;->l:I

    .line 101
    .line 102
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    const-string v1, ")"

    .line 106
    .line 107
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    return-object v0
.end method
