###### Class a20.b (a20.b)
.class public interface abstract La20/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getEventName()Ljava/lang/String;
.end method

.method public abstract x()Ljava/lang/String;
.end method
