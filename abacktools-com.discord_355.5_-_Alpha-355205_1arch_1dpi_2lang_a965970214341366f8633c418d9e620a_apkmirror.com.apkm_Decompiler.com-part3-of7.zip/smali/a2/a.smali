###### Class a2.a (a2.a)
.class public final La2/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method public constructor <init>(I)V
    .registers 2

    packed-switch p1, :pswitch_data_b2

    .line 1
    const-string p1, "androidx.credentials.TYPE_ABORT_ERROR"

    .line 2
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 3
    :pswitch_9
    const-string p1, "androidx.credentials.TYPE_WRONG_DOCUMENT_ERROR"

    .line 4
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 5
    :pswitch_f
    const-string p1, "androidx.credentials.TYPE_VERSION_ERROR"

    .line 6
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 7
    :pswitch_15
    const-string p1, "androidx.credentials.TYPE_UNKNOWN_ERROR"

    .line 8
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 9
    :pswitch_1b
    const-string p1, "androidx.credentials.TYPE_TRANSACTION_INACTIVE_ERROR"

    .line 10
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 11
    :pswitch_21
    const-string p1, "androidx.credentials.TYPE_TIMEOUT_ERROR"

    .line 12
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 13
    :pswitch_27
    const-string p1, "androidx.credentials.TYPE_SYNTAX_ERROR"

    .line 14
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 15
    :pswitch_2d
    const-string p1, "androidx.credentials.TYPE_SECURITY_ERROR"

    .line 16
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 17
    :pswitch_33
    const-string p1, "androidx.credentials.TYPE_READ_ONLY_ERROR"

    .line 18
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 19
    :pswitch_39
    const-string p1, "androidx.credentials.TYPE_QUOTA_EXCEEDED_ERROR"

    .line 20
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 21
    :pswitch_3f
    const-string p1, "androidx.credentials.TYPE_OPT_OUT_ERROR"

    .line 22
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 23
    :pswitch_45
    const-string p1, "androidx.credentials.TYPE_OPERATION_ERROR"

    .line 24
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 25
    :pswitch_4b
    const-string p1, "androidx.credentials.TYPE_NOT_SUPPORTED_ERROR"

    .line 26
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 27
    :pswitch_51
    const-string p1, "androidx.credentials.TYPE_NOT_READABLE_ERROR"

    .line 28
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 29
    :pswitch_57
    const-string p1, "androidx.credentials.TYPE_NOT_FOUND_ERROR"

    .line 30
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 31
    :pswitch_5d
    const-string p1, "androidx.credentials.TYPE_NOT_ALLOWED_ERROR"

    .line 32
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 33
    :pswitch_63
    const-string p1, "androidx.credentials.TYPE_NO_MODIFICATION_ALLOWED_ERROR"

    .line 34
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 35
    :pswitch_69
    const-string p1, "androidx.credentials.TYPE_NETWORK_ERROR"

    .line 36
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 37
    :pswitch_6f
    const-string p1, "androidx.credentials.TYPE_NAMESPACE_ERROR"

    .line 38
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 39
    :pswitch_75
    const-string p1, "androidx.credentials.TYPE_INVALID_STATE_ERROR"

    .line 40
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 41
    :pswitch_7b
    const-string p1, "androidx.credentials.TYPE_INVALID_NODE_TYPE_ERROR"

    .line 42
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 43
    :pswitch_81
    const-string p1, "androidx.credentials.TYPE_INVALID_MODIFICATION_ERROR"

    .line 44
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 45
    :pswitch_87
    const-string p1, "androidx.credentials.TYPE_INVALID_CHARACTER_ERROR"

    .line 46
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 47
    :pswitch_8d
    const-string p1, "androidx.credentials.TYPE_IN_USE_ATTRIBUTE_ERROR"

    .line 48
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 49
    :pswitch_93
    const-string p1, "androidx.credentials.TYPE_HIERARCHY_REQUEST_ERROR"

    .line 50
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 51
    :pswitch_99
    const-string p1, "androidx.credentials.TYPE_ENCODING_ERROR"

    .line 52
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 53
    :pswitch_9f
    const-string p1, "androidx.credentials.TYPE_DATA_ERROR"

    .line 54
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 55
    :pswitch_a5
    const-string p1, "androidx.credentials.TYPE_DATA_CLONE_ERROR"

    .line 56
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    .line 57
    :pswitch_ab
    const-string p1, "androidx.credentials.TYPE_CONSTRAINT_ERROR"

    .line 58
    invoke-direct {p0, p1}, La2/a;-><init>(Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_b2
    .packed-switch 0x1
        :pswitch_ab
        :pswitch_a5
        :pswitch_9f
        :pswitch_99
        :pswitch_93
        :pswitch_8d
        :pswitch_87
        :pswitch_81
        :pswitch_7b
        :pswitch_75
        :pswitch_6f
        :pswitch_69
        :pswitch_63
        :pswitch_5d
        :pswitch_57
        :pswitch_51
        :pswitch_4b
        :pswitch_45
        :pswitch_3f
        :pswitch_39
        :pswitch_33
        :pswitch_2d
        :pswitch_27
        :pswitch_21
        :pswitch_1b
        :pswitch_15
        :pswitch_f
        :pswitch_9
    .end packed-switch
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 59
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 60
    iput-object p1, p0, La2/a;->a:Ljava/lang/String;

    return-void
.end method
