###### Class a80.a (a80.a)
.class public final La80/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnet/time4j/tz/o;
.implements Lz70/a;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/util/Map;

.field public final d:Ljava/util/Map;

.field public final e:Lnet/time4j/x0;

.field public final f:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .registers 19

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    const-string v0, "Classloader cannot access tz-repository: "

    .line 4
    .line 5
    const-string v2, "Path to tz-repository not found: "

    .line 6
    .line 7
    const-string v3, "tzrepo/"

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    const-string v4, ""

    .line 13
    .line 14
    sget-object v5, Lnet/time4j/x0;->b0:Lw70/p;

    .line 15
    .line 16
    iget-object v5, v5, Lw70/p;->y:Lw70/q;

    .line 17
    .line 18
    check-cast v5, Lnet/time4j/x0;

    .line 19
    .line 20
    new-instance v6, Ljava/util/HashMap;

    .line 21
    .line 22
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 23
    .line 24
    .line 25
    new-instance v7, Ljava/util/HashMap;

    .line 26
    .line 27
    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 28
    .line 29
    .line 30
    const-string v8, "net.time4j.scale.leapseconds.path"

    .line 31
    .line 32
    invoke-static {v8}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v8

    .line 36
    const/4 v9, 0x0

    .line 37
    if-eqz v8, :cond_28

    .line 38
    .line 39
    const/4 v8, 0x1

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move v8, v9

    .line 42
    :goto_29
    if-eqz v8, :cond_30

    .line 43
    .line 44
    sget-object v11, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 45
    .line 46
    iput-object v11, v1, La80/a;->f:Ljava/util/Map;

    .line 47
    .line 48
    goto :goto_39

    .line 49
    :cond_30
    new-instance v11, Ljava/util/LinkedHashMap;

    .line 50
    .line 51
    const/16 v12, 0x32

    .line 52
    .line 53
    invoke-direct {v11, v12}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 54
    .line 55
    .line 56
    iput-object v11, v1, La80/a;->f:Ljava/util/Map;

    .line 57
    .line 58
    :goto_39
    const-string v11, "net.time4j.tz.repository.path"

    .line 59
    .line 60
    invoke-static {v11}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v11

    .line 64
    const-string v12, "net.time4j.tz.repository.version"

    .line 65
    .line 66
    invoke-static {v12}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v12

    .line 70
    const-string v13, "tzdata"

    .line 71
    .line 72
    if-nez v12, :cond_4c

    .line 73
    .line 74
    const-string v12, "tzdata.repository"

    .line 75
    .line 76
    goto :goto_52

    .line 77
    :cond_4c
    const-string v14, ".repository"

    .line 78
    .line 79
    invoke-static {v13, v12, v14}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v12

    .line 83
    :goto_52
    :try_start_52
    new-instance v15, Ljava/lang/StringBuilder;

    .line 84
    .line 85
    invoke-direct {v15, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    if-eqz v11, :cond_a0

    .line 96
    .line 97
    new-instance v15, Ljava/io/File;

    .line 98
    .line 99
    invoke-direct {v15, v11, v12}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v15}, Ljava/io/File;->isAbsolute()Z

    .line 103
    .line 104
    .line 105
    move-result v11

    .line 106
    if-eqz v11, :cond_91

    .line 107
    .line 108
    invoke-virtual {v15}, Ljava/io/File;->exists()Z

    .line 109
    .line 110
    .line 111
    move-result v11

    .line 112
    if-eqz v11, :cond_7f

    .line 113
    .line 114
    invoke-virtual {v15}, Ljava/io/File;->toURI()Ljava/net/URI;

    .line 115
    .line 116
    .line 117
    move-result-object v2

    .line 118
    goto :goto_aa

    .line 119
    :catchall_76
    move-exception v0

    .line 120
    const/4 v14, 0x0

    .line 121
    goto/16 :goto_1f8

    .line 122
    .line 123
    :catch_7a
    move-exception v0

    .line 124
    move-object v2, v4

    .line 125
    const/4 v14, 0x0

    .line 126
    goto/16 :goto_1c1

    .line 127
    .line 128
    :cond_7f
    new-instance v0, Ljava/io/FileNotFoundException;

    .line 129
    .line 130
    new-instance v3, Ljava/lang/StringBuilder;

    .line 131
    .line 132
    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    invoke-direct {v0, v2}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    throw v0

    .line 146
    :cond_91
    sget-object v2, Lu70/c;->b:Lu70/c;

    .line 147
    .line 148
    invoke-static {}, La80/a;->e()Ljava/lang/Class;

    .line 149
    .line 150
    .line 151
    move-result-object v11

    .line 152
    invoke-virtual {v15}, Ljava/io/File;->toString()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v12

    .line 156
    invoke-virtual {v2, v13, v12, v11}, Lu70/c;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/net/URI;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    goto :goto_aa

    .line 161
    :cond_a0
    sget-object v2, Lu70/c;->b:Lu70/c;

    .line 162
    .line 163
    invoke-static {}, La80/a;->e()Ljava/lang/Class;

    .line 164
    .line 165
    .line 166
    move-result-object v11

    .line 167
    invoke-virtual {v2, v13, v3, v11}, Lu70/c;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/net/URI;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    :goto_aa
    if-eqz v2, :cond_c0

    .line 172
    .line 173
    sget-object v11, Lu70/c;->b:Lu70/c;

    .line 174
    .line 175
    invoke-virtual {v11, v2}, Lu70/c;->b(Ljava/net/URI;)Ljava/io/InputStream;

    .line 176
    .line 177
    .line 178
    move-result-object v11
    :try_end_b2
    .catch Ljava/io/IOException; {:try_start_52 .. :try_end_b2} :catch_7a
    .catchall {:try_start_52 .. :try_end_b2} :catchall_76

    .line 179
    :try_start_b2
    invoke-virtual {v2}, Ljava/net/URI;->toString()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v2
    :try_end_b6
    .catch Ljava/io/IOException; {:try_start_b2 .. :try_end_b6} :catch_bb
    .catchall {:try_start_b2 .. :try_end_b6} :catchall_b7

    .line 183
    goto :goto_c2

    .line 184
    :catchall_b7
    move-exception v0

    .line 185
    move-object v14, v11

    .line 186
    goto/16 :goto_1f8

    .line 187
    .line 188
    :catch_bb
    move-exception v0

    .line 189
    move-object v2, v4

    .line 190
    :goto_bd
    move-object v14, v11

    .line 191
    goto/16 :goto_1c1

    .line 192
    .line 193
    :cond_c0
    move-object v2, v4

    .line 194
    const/4 v11, 0x0

    .line 195
    :goto_c2
    if-nez v11, :cond_f9

    .line 196
    .line 197
    :try_start_c4
    invoke-static {}, La80/a;->e()Ljava/lang/Class;

    .line 198
    .line 199
    .line 200
    move-result-object v12

    .line 201
    invoke-virtual {v12}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 202
    .line 203
    .line 204
    move-result-object v12

    .line 205
    invoke-virtual {v12, v3}, Ljava/lang/ClassLoader;->getResource(Ljava/lang/String;)Ljava/net/URL;

    .line 206
    .line 207
    .line 208
    move-result-object v12

    .line 209
    if-eqz v12, :cond_e7

    .line 210
    .line 211
    invoke-virtual {v12}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    invoke-virtual {v0, v9}, Ljava/net/URLConnection;->setUseCaches(Z)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v0}, Ljava/net/URLConnection;->connect()V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 222
    .line 223
    .line 224
    move-result-object v11

    .line 225
    invoke-virtual {v12}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v2

    .line 229
    goto :goto_f9

    .line 230
    :catch_e5
    move-exception v0

    .line 231
    goto :goto_bd

    .line 232
    :cond_e7
    new-instance v8, Ljava/io/FileNotFoundException;

    .line 233
    .line 234
    new-instance v9, Ljava/lang/StringBuilder;

    .line 235
    .line 236
    invoke-direct {v9, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 240
    .line 241
    .line 242
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-direct {v8, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    throw v8
    :try_end_f9
    .catch Ljava/io/IOException; {:try_start_c4 .. :try_end_f9} :catch_e5
    .catchall {:try_start_c4 .. :try_end_f9} :catchall_b7

    .line 250
    :cond_f9
    :goto_f9
    :try_start_f9
    new-instance v0, Ljava/io/DataInputStream;

    .line 251
    .line 252
    invoke-direct {v0, v11}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 253
    .line 254
    .line 255
    invoke-static {v0, v2}, La80/a;->d(Ljava/io/DataInputStream;Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v3

    .line 262
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    .line 263
    .line 264
    .line 265
    move-result v12

    .line 266
    new-instance v13, Ljava/util/ArrayList;

    .line 267
    .line 268
    invoke-direct {v13, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 269
    .line 270
    .line 271
    move v15, v9

    .line 272
    :goto_10f
    if-ge v15, v12, :cond_15c

    .line 273
    .line 274
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v9

    .line 278
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    .line 279
    .line 280
    .line 281
    move-result v14

    .line 282
    new-array v10, v14, [B
    :try_end_11b
    .catch Ljava/io/IOException; {:try_start_f9 .. :try_end_11b} :catch_157
    .catchall {:try_start_f9 .. :try_end_11b} :catchall_b7

    .line 283
    .line 284
    move-object/from16 v16, v2

    .line 285
    .line 286
    move-object/from16 v17, v3

    .line 287
    .line 288
    const/4 v2, 0x0

    .line 289
    :cond_120
    sub-int v3, v14, v2

    .line 290
    .line 291
    :try_start_122
    invoke-virtual {v0, v10, v2, v3}, Ljava/io/DataInputStream;->read([BII)I

    .line 292
    .line 293
    .line 294
    move-result v3

    .line 295
    add-int/2addr v2, v3

    .line 296
    const/4 v3, -0x1

    .line 297
    if-eq v2, v3, :cond_140

    .line 298
    .line 299
    if-gt v14, v2, :cond_120

    .line 300
    .line 301
    invoke-virtual {v13, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    invoke-virtual {v6, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    add-int/lit8 v15, v15, 0x1

    .line 308
    .line 309
    move-object/from16 v2, v16

    .line 310
    .line 311
    move-object/from16 v3, v17

    .line 312
    .line 313
    const/4 v9, 0x0

    .line 314
    goto :goto_10f

    .line 315
    :catch_13a
    move-exception v0

    .line 316
    move-object v14, v11

    .line 317
    move-object/from16 v2, v16

    .line 318
    .line 319
    goto/16 :goto_1c1

    .line 320
    .line 321
    :cond_140
    new-instance v0, Ljava/io/EOFException;

    .line 322
    .line 323
    new-instance v2, Ljava/lang/StringBuilder;

    .line 324
    .line 325
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 326
    .line 327
    .line 328
    const-string v3, "Incomplete data: "

    .line 329
    .line 330
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 331
    .line 332
    .line 333
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 334
    .line 335
    .line 336
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    move-result-object v2

    .line 340
    invoke-direct {v0, v2}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    throw v0

    .line 344
    :catch_157
    move-exception v0

    .line 345
    move-object/from16 v16, v2

    .line 346
    .line 347
    goto/16 :goto_bd

    .line 348
    .line 349
    :cond_15c
    move-object/from16 v16, v2

    .line 350
    .line 351
    move-object/from16 v17, v3

    .line 352
    .line 353
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    .line 354
    .line 355
    .line 356
    move-result v2

    .line 357
    const/4 v3, 0x0

    .line 358
    :goto_165
    if-ge v3, v2, :cond_17b

    .line 359
    .line 360
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v9

    .line 364
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    .line 365
    .line 366
    .line 367
    move-result v10

    .line 368
    invoke-virtual {v13, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 369
    .line 370
    .line 371
    move-result-object v10

    .line 372
    check-cast v10, Ljava/lang/String;

    .line 373
    .line 374
    invoke-virtual {v7, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 375
    .line 376
    .line 377
    add-int/lit8 v3, v3, 0x1

    .line 378
    .line 379
    goto :goto_165

    .line 380
    :cond_17b
    if-nez v8, :cond_1b6

    .line 381
    .line 382
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    .line 383
    .line 384
    .line 385
    move-result v2

    .line 386
    const/4 v9, 0x0

    .line 387
    :goto_182
    if-ge v9, v2, :cond_1a5

    .line 388
    .line 389
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    .line 390
    .line 391
    .line 392
    move-result v3

    .line 393
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 394
    .line 395
    .line 396
    move-result v8

    .line 397
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 398
    .line 399
    .line 400
    move-result v10

    .line 401
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 402
    .line 403
    .line 404
    move-result v12

    .line 405
    iget-object v13, v1, La80/a;->f:Ljava/util/Map;

    .line 406
    .line 407
    const/4 v14, 0x1

    .line 408
    invoke-static {v3, v8, v10, v14}, Lnet/time4j/x0;->z(IIIZ)Lnet/time4j/x0;

    .line 409
    .line 410
    .line 411
    move-result-object v3

    .line 412
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 413
    .line 414
    .line 415
    move-result-object v8

    .line 416
    invoke-interface {v13, v3, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 417
    .line 418
    .line 419
    add-int/lit8 v9, v9, 0x1

    .line 420
    .line 421
    goto :goto_182

    .line 422
    :cond_1a5
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readShort()S

    .line 423
    .line 424
    .line 425
    move-result v2

    .line 426
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 427
    .line 428
    .line 429
    move-result v3

    .line 430
    invoke-virtual {v0}, Ljava/io/DataInputStream;->readByte()B

    .line 431
    .line 432
    .line 433
    move-result v0

    .line 434
    const/4 v14, 0x1

    .line 435
    invoke-static {v2, v3, v0, v14}, Lnet/time4j/x0;->z(IIIZ)Lnet/time4j/x0;

    .line 436
    .line 437
    .line 438
    move-result-object v5
    :try_end_1b6
    .catch Ljava/io/IOException; {:try_start_122 .. :try_end_1b6} :catch_13a
    .catchall {:try_start_122 .. :try_end_1b6} :catchall_b7

    .line 439
    :cond_1b6
    if-eqz v11, :cond_1bb

    .line 440
    .line 441
    :try_start_1b8
    invoke-virtual {v11}, Ljava/io/InputStream;->close()V
    :try_end_1bb
    .catch Ljava/io/IOException; {:try_start_1b8 .. :try_end_1bb} :catch_1bb

    .line 442
    .line 443
    .line 444
    :catch_1bb
    :cond_1bb
    move-object/from16 v2, v16

    .line 445
    .line 446
    move-object/from16 v4, v17

    .line 447
    .line 448
    const/4 v14, 0x0

    .line 449
    goto :goto_1e1

    .line 450
    :goto_1c1
    :try_start_1c1
    new-instance v3, Ljava/lang/IllegalStateException;

    .line 451
    .line 452
    new-instance v8, Ljava/lang/StringBuilder;

    .line 453
    .line 454
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 455
    .line 456
    .line 457
    const-string v9, "[ERROR] TZ-repository not available. => "

    .line 458
    .line 459
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 460
    .line 461
    .line 462
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    move-result-object v9

    .line 466
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 467
    .line 468
    .line 469
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 470
    .line 471
    .line 472
    move-result-object v8

    .line 473
    invoke-direct {v3, v8, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1db
    .catchall {:try_start_1c1 .. :try_end_1db} :catchall_1f7

    .line 474
    .line 475
    .line 476
    if-eqz v14, :cond_1e0

    .line 477
    .line 478
    :try_start_1dd
    invoke-virtual {v14}, Ljava/io/InputStream;->close()V
    :try_end_1e0
    .catch Ljava/io/IOException; {:try_start_1dd .. :try_end_1e0} :catch_1e0

    .line 479
    .line 480
    .line 481
    :catch_1e0
    :cond_1e0
    move-object v14, v3

    .line 482
    :goto_1e1
    if-nez v14, :cond_1f6

    .line 483
    .line 484
    iput-object v4, v1, La80/a;->a:Ljava/lang/String;

    .line 485
    .line 486
    iput-object v2, v1, La80/a;->b:Ljava/lang/String;

    .line 487
    .line 488
    invoke-static {v6}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    iput-object v0, v1, La80/a;->c:Ljava/util/Map;

    .line 493
    .line 494
    invoke-static {v7}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 495
    .line 496
    .line 497
    move-result-object v0

    .line 498
    iput-object v0, v1, La80/a;->d:Ljava/util/Map;

    .line 499
    .line 500
    iput-object v5, v1, La80/a;->e:Lnet/time4j/x0;

    .line 501
    .line 502
    return-void

    .line 503
    :cond_1f6
    throw v14

    .line 504
    :catchall_1f7
    move-exception v0

    .line 505
    :goto_1f8
    if-eqz v14, :cond_1fd

    .line 506
    .line 507
    :try_start_1fa
    invoke-virtual {v14}, Ljava/io/InputStream;->close()V
    :try_end_1fd
    .catch Ljava/io/IOException; {:try_start_1fa .. :try_end_1fd} :catch_1fd

    .line 508
    .line 509
    .line 510
    :catch_1fd
    :cond_1fd
    throw v0
.end method

.method public static d(Ljava/io/DataInputStream;Ljava/lang/String;)V
    .registers 8

    .line 1
    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    .line 18
    .line 19
    .line 20
    move-result v4

    .line 21
    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    const/16 v5, 0x74

    .line 26
    .line 27
    if-ne v0, v5, :cond_31

    .line 28
    .line 29
    const/16 v0, 0x7a

    .line 30
    .line 31
    if-ne v1, v0, :cond_31

    .line 32
    .line 33
    const/16 v0, 0x72

    .line 34
    .line 35
    if-ne v2, v0, :cond_31

    .line 36
    .line 37
    const/16 v0, 0x65

    .line 38
    .line 39
    if-ne v3, v0, :cond_31

    .line 40
    .line 41
    const/16 v0, 0x70

    .line 42
    .line 43
    if-ne v4, v0, :cond_31

    .line 44
    .line 45
    const/16 v0, 0x6f

    .line 46
    .line 47
    if-ne p0, v0, :cond_31

    .line 48
    .line 49
    return-void

    .line 50
    :cond_31
    new-instance p0, Ljava/io/IOException;

    .line 51
    .line 52
    const-string v0, "Invalid tz-repository: "

    .line 53
    .line 54
    invoke-static {v0, p1}, La1/h;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    throw p0
.end method

.method public static e()Ljava/lang/Class;
    .registers 2

    .line 1
    const-string v0, "test.environment"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Boolean;->getBoolean(Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_16

    .line 8
    .line 9
    :try_start_8
    const-string v0, "net.time4j.tz.spi.RepositoryTest"

    .line 10
    .line 11
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    move-result-object v0
    :try_end_e
    .catch Ljava/lang/ClassNotFoundException; {:try_start_8 .. :try_end_e} :catch_f

    .line 15
    return-object v0

    .line 16
    :catch_f
    move-exception v0

    .line 17
    new-instance v1, Ljava/lang/AssertionError;

    .line 18
    .line 19
    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    throw v1

    .line 23
    :cond_16
    const-class v0, La80/a;

    .line 24
    .line 25
    return-object v0
.end method


# virtual methods
.method public final a()Ljava/util/Set;
    .registers 2

    .line 1
    iget-object v0, p0, La80/a;->c:Ljava/util/Map;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final b()Ljava/util/Map;
    .registers 2

    .line 1
    iget-object v0, p0, La80/a;->d:Ljava/util/Map;

    .line 2
    .line 3
    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, La80/a;->b:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 2

    .line 1
    const-string v0, "TZDB"

    .line 2
    .line 3
    return-object v0
.end method

.method public final getVersion()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, La80/a;->a:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final load(Ljava/lang/String;)Lnet/time4j/tz/j;
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, La80/a;->c:Ljava/util/Map;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, [B

    .line 8
    .line 9
    if-eqz p1, :cond_26

    .line 10
    .line 11
    new-instance v0, Ljava/io/ObjectInputStream;

    .line 12
    .line 13
    new-instance v1, Ljava/io/ByteArrayInputStream;

    .line 14
    .line 15
    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 16
    .line 17
    .line 18
    invoke-direct {v0, v1}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Lnet/time4j/tz/j;
    :try_end_1a
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_1a} :catch_1d
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_1a} :catch_1b

    .line 26
    .line 27
    return-object p1

    .line 28
    :catch_1b
    move-exception p1

    .line 29
    goto :goto_1f

    .line 30
    :catch_1d
    move-exception p1

    .line 31
    goto :goto_23

    .line 32
    :goto_1f
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 33
    .line 34
    .line 35
    goto :goto_26

    .line 36
    :goto_23
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 37
    .line 38
    .line 39
    :cond_26
    :goto_26
    const/4 p1, 0x0

    .line 40
    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "TZ-REPOSITORY("

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, La80/a;->a:Ljava/lang/String;

    .line 9
    .line 10
    const-string v2, ")"

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, Lcom/google/android/gms/internal/fido/nb;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method
