###### Class a40.d (a40.d)
.class public interface abstract La40/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ll30/e;


# virtual methods
.method public abstract d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
