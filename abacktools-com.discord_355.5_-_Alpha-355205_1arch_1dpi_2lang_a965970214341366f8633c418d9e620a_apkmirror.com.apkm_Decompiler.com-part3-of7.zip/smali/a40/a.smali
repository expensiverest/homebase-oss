###### Class a40.a (a40.a)
.class public interface abstract La40/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ll30/e;


# virtual methods
.method public abstract invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
