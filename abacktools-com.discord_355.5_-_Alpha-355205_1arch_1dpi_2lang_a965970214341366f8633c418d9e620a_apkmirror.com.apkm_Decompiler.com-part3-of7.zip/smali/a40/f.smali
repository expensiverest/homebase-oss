###### Class a40.f (a40.f)
.class public interface abstract La40/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ll30/e;
