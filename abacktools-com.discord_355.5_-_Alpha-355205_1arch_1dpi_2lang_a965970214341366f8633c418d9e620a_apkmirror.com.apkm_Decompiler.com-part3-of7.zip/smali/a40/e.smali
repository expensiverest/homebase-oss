###### Class a40.e (a40.e)
.class public interface abstract La40/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ll30/e;


# virtual methods
.method public abstract invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
