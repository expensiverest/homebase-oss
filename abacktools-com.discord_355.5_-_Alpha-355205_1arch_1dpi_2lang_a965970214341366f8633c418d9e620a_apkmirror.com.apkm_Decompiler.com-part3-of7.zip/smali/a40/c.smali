###### Class a40.c (a40.c)
.class public interface abstract La40/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ll30/e;
