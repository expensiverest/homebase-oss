###### Class a40.b (a40.b)
.class public interface abstract La40/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ll30/e;


# virtual methods
.method public abstract b(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
