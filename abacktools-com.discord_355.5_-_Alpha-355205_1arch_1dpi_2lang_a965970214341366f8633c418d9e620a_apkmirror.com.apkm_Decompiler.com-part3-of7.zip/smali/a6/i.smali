###### Class a6.i (a6.i)
.class public final synthetic La6/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/i;->d:I

    iput-object p2, p0, La6/i;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .registers 3

    .line 2
    const/16 v0, 0x19

    iput v0, p0, La6/i;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    check-cast p1, Lkotlin/jvm/internal/i;

    iput-object p1, p0, La6/i;->e:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    .line 1
    iget v0, p0, La6/i;->d:I

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    iget-object v4, p0, La6/i;->e:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_1ba

    .line 10
    .line 11
    .line 12
    check-cast v4, Lzb/q;

    .line 13
    .line 14
    sget p1, Lcom/discord/chat/presentation/message/MessageViewReplyPreview;->W:I

    .line 15
    .line 16
    invoke-virtual {v4}, Lzb/q;->invoke()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_13
    check-cast v4, Lkotlin/jvm/internal/i;

    .line 21
    .line 22
    invoke-interface {v4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :pswitch_19
    check-cast v4, Lfb/c0;

    .line 27
    .line 28
    iget-object p1, v4, Lfb/c0;->y:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p1, Lcom/facebook/drawee/view/SimpleDraweeView;

    .line 31
    .line 32
    iget-object v0, v4, Lfb/c0;->L:Landroid/view/View;

    .line 33
    .line 34
    check-cast v0, Lcom/facebook/drawee/view/SimpleDraweeView;

    .line 35
    .line 36
    const-string v1, "jumpButton"

    .line 37
    .line 38
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    if-nez p1, :cond_36

    .line 46
    .line 47
    iget-object p1, v4, Lfb/c0;->y:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p1, Lcom/facebook/drawee/view/SimpleDraweeView;

    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/View;->performClick()Z

    .line 52
    .line 53
    .line 54
    goto :goto_44

    .line 55
    :cond_36
    const-string p1, "moreButton"

    .line 56
    .line 57
    invoke-static {v0, p1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    if-nez p1, :cond_44

    .line 65
    .line 66
    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    .line 67
    .line 68
    .line 69
    :cond_44
    :goto_44
    return-void

    .line 70
    :pswitch_45
    check-cast v4, Lr1/y;

    .line 71
    .line 72
    invoke-virtual {v4, p1}, Lr1/y;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :pswitch_4b
    check-cast v4, Lt10/p;

    .line 77
    .line 78
    invoke-virtual {v4}, Lt10/p;->getSheetClosesOnTouchOutside()Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    if-eqz p1, :cond_61

    .line 83
    .line 84
    invoke-virtual {v4}, Lt10/p;->getFragment()Lb3/a0;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    const-string v0, "null cannot be cast to non-null type com.swmansion.rnscreens.ScreenStackFragment"

    .line 89
    .line 90
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    check-cast p1, Lt10/h0;

    .line 94
    .line 95
    invoke-virtual {p1}, Lt10/h0;->g0()V

    .line 96
    .line 97
    .line 98
    :cond_61
    return-void

    .line 99
    :pswitch_62
    check-cast v4, Lt10/z0;

    .line 100
    .line 101
    invoke-static {v4}, Lt10/z0;->n(Lt10/z0;)V

    .line 102
    .line 103
    .line 104
    return-void

    .line 105
    :pswitch_68
    check-cast v4, Lt10/j0;

    .line 106
    .line 107
    invoke-static {v4}, Lt10/j0;->a(Lt10/j0;)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_6e
    check-cast v4, Lt10/a;

    .line 112
    .line 113
    iget-object v0, v4, Lt10/a;->N0:Landroid/view/View$OnClickListener;

    .line 114
    .line 115
    if-eqz v0, :cond_77

    .line 116
    .line 117
    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 118
    .line 119
    .line 120
    :cond_77
    iget-object p1, v4, Lt10/a;->O0:Lb80/o;

    .line 121
    .line 122
    invoke-virtual {p1}, Lb80/o;->e()V

    .line 123
    .line 124
    .line 125
    return-void

    .line 126
    :pswitch_7d
    check-cast v4, Llq/g;

    .line 127
    .line 128
    invoke-static {v4, p1}, Lcom/facebook/react/views/view/ReactViewManager;->a(Llq/g;Landroid/view/View;)V

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :pswitch_83
    check-cast v4, Lcom/discord/notifications/renderer/IncomingCallActivity;

    .line 133
    .line 134
    invoke-virtual {v4}, Lcom/discord/notifications/renderer/IncomingCallActivity;->t()V

    .line 135
    .line 136
    .line 137
    return-void

    .line 138
    :pswitch_89
    check-cast v4, Laj/a;

    .line 139
    .line 140
    sget p1, Lcom/discord/chat/presentation/message/view/SpoilerOverlayView;->e:I

    .line 141
    .line 142
    invoke-virtual {v4}, Laj/a;->invoke()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    return-void

    .line 146
    :pswitch_91
    check-cast v4, Lzb/i;

    .line 147
    .line 148
    invoke-virtual {v4, v3}, Lzb/i;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    return-void

    .line 152
    :pswitch_97
    check-cast v4, Lzb/i;

    .line 153
    .line 154
    invoke-virtual {v4, v3}, Lzb/i;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    return-void

    .line 158
    :pswitch_9d
    check-cast v4, Lcom/discord/chat/presentation/message/view/MediaView;

    .line 159
    .line 160
    sget p1, Lcom/discord/chat/presentation/message/view/MediaView;->i0:I

    .line 161
    .line 162
    invoke-virtual {v4}, Lcom/discord/chat/presentation/message/view/MediaView;->c()V

    .line 163
    .line 164
    .line 165
    return-void

    .line 166
    :pswitch_a5
    check-cast v4, Lqc/e;

    .line 167
    .line 168
    invoke-virtual {v4}, Lqc/e;->invoke()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    return-void

    .line 172
    :pswitch_ab
    check-cast v4, Le2/b;

    .line 173
    .line 174
    invoke-virtual {v4}, Le2/b;->invoke()Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    return-void

    .line 178
    :pswitch_b1
    check-cast v4, Lcg/e;

    .line 179
    .line 180
    invoke-virtual {v4, v3, v3, v3}, Lcg/e;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    return-void

    .line 184
    :pswitch_b7
    check-cast v4, Lfc/h2;

    .line 185
    .line 186
    sget p1, Lcom/discord/chat/presentation/message/view/AttachmentUploadOverlayView;->g0:I

    .line 187
    .line 188
    iget-object p1, v4, Lfc/h2;->d:Laj/a;

    .line 189
    .line 190
    invoke-virtual {p1}, Laj/a;->invoke()Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    return-void

    .line 194
    :pswitch_c1
    check-cast v4, Lk7/m;

    .line 195
    .line 196
    iget-object p1, v4, Lk7/m;->v:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast p1, Landroidx/lifecycle/t0;

    .line 199
    .line 200
    invoke-virtual {p1}, Landroidx/lifecycle/t0;->invoke()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    return-void

    .line 204
    :pswitch_cb
    check-cast v4, Lbh/r;

    .line 205
    .line 206
    iget-object p1, v4, Lbh/r;->w:Lyg/u;

    .line 207
    .line 208
    if-eqz p1, :cond_dd

    .line 209
    .line 210
    iget-object v0, v4, Lbh/r;->u:Lkotlin/jvm/functions/Function1;

    .line 211
    .line 212
    iget-wide v1, p1, Lyg/u;->b:J

    .line 213
    .line 214
    new-instance p1, Lcom/discord/primitives/ChannelId;

    .line 215
    .line 216
    invoke-direct {p1, v1, v2}, Lcom/discord/primitives/ChannelId;-><init>(J)V

    .line 217
    .line 218
    .line 219
    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    :cond_dd
    return-void

    .line 223
    :pswitch_de
    check-cast v4, Lbh/p;

    .line 224
    .line 225
    invoke-virtual {v4}, Lbh/e;->h()V

    .line 226
    .line 227
    .line 228
    return-void

    .line 229
    :pswitch_e4
    check-cast v4, Lbh/e;

    .line 230
    .line 231
    invoke-virtual {v4}, Lbh/e;->h()V

    .line 232
    .line 233
    .line 234
    return-void

    .line 235
    :pswitch_ea
    check-cast v4, La6/b0;

    .line 236
    .line 237
    invoke-virtual {v4}, La6/b0;->g()V

    .line 238
    .line 239
    .line 240
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 241
    .line 242
    .line 243
    move-result v0

    .line 244
    const v1, 0x7f0a01bd

    .line 245
    .line 246
    .line 247
    if-ne v0, v1, :cond_fe

    .line 248
    .line 249
    iget-object p1, v4, La6/b0;->r:Landroid/animation/ValueAnimator;

    .line 250
    .line 251
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    .line 252
    .line 253
    .line 254
    goto :goto_10c

    .line 255
    :cond_fe
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 256
    .line 257
    .line 258
    move-result p1

    .line 259
    const v0, 0x7f0a01bc

    .line 260
    .line 261
    .line 262
    if-ne p1, v0, :cond_10c

    .line 263
    .line 264
    iget-object p1, v4, La6/b0;->s:Landroid/animation/ValueAnimator;

    .line 265
    .line 266
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    .line 267
    .line 268
    .line 269
    :cond_10c
    :goto_10c
    return-void

    .line 270
    :pswitch_10d
    check-cast v4, La6/k;

    .line 271
    .line 272
    iget-object p1, v4, La6/k;->g:La6/w;

    .line 273
    .line 274
    iget-object v0, p1, La6/w;->S0:Lk3/e1;

    .line 275
    .line 276
    if-eqz v0, :cond_144

    .line 277
    .line 278
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 279
    .line 280
    .line 281
    move-result v0

    .line 282
    if-eqz v0, :cond_144

    .line 283
    .line 284
    iget-object v0, p1, La6/w;->S0:Lk3/e1;

    .line 285
    .line 286
    invoke-interface {v0}, Lk3/e1;->Z1()Lk3/t1;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    iget-object v1, p1, La6/w;->S0:Lk3/e1;

    .line 291
    .line 292
    invoke-virtual {v0}, Lk3/t1;->a()Lk3/s1;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    const/4 v2, 0x3

    .line 297
    invoke-virtual {v0, v2}, Lk3/s1;->d(I)Lk3/s1;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    invoke-virtual {v0}, Lk3/s1;->g()Lk3/s1;

    .line 302
    .line 303
    .line 304
    move-result-object v0

    .line 305
    invoke-virtual {v0}, Lk3/s1;->i()Lk3/s1;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    invoke-virtual {v0}, Lk3/s1;->k()Lk3/s1;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    invoke-virtual {v0}, Lk3/s1;->b()Lk3/t1;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    invoke-interface {v1, v0}, Lk3/e1;->N0(Lk3/t1;)V

    .line 318
    .line 319
    .line 320
    iget-object p1, p1, La6/w;->T:Landroid/widget/PopupWindow;

    .line 321
    .line 322
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    .line 323
    .line 324
    .line 325
    :cond_144
    return-void

    .line 326
    :pswitch_145
    check-cast v4, La6/q;

    .line 327
    .line 328
    iget-object p1, v4, La6/q;->x:La6/w;

    .line 329
    .line 330
    invoke-virtual {v4}, Le6/l1;->f()I

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    iget-object v1, p1, La6/w;->l0:Landroid/view/View;

    .line 335
    .line 336
    if-nez v0, :cond_15a

    .line 337
    .line 338
    iget-object v0, p1, La6/w;->P:La6/o;

    .line 339
    .line 340
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 341
    .line 342
    .line 343
    invoke-virtual {p1, v0, v1}, La6/w;->e(Le6/n0;Landroid/view/View;)V

    .line 344
    .line 345
    .line 346
    goto :goto_16a

    .line 347
    :cond_15a
    if-ne v0, v2, :cond_165

    .line 348
    .line 349
    iget-object v0, p1, La6/w;->R:La6/k;

    .line 350
    .line 351
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 352
    .line 353
    .line 354
    invoke-virtual {p1, v0, v1}, La6/w;->e(Le6/n0;Landroid/view/View;)V

    .line 355
    .line 356
    .line 357
    goto :goto_16a

    .line 358
    :cond_165
    iget-object p1, p1, La6/w;->T:Landroid/widget/PopupWindow;

    .line 359
    .line 360
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    .line 361
    .line 362
    .line 363
    :goto_16a
    return-void

    .line 364
    :pswitch_16b
    check-cast v4, La6/k;

    .line 365
    .line 366
    iget-object p1, v4, La6/k;->g:La6/w;

    .line 367
    .line 368
    iget-object v0, p1, La6/w;->S0:Lk3/e1;

    .line 369
    .line 370
    if-eqz v0, :cond_1b0

    .line 371
    .line 372
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 373
    .line 374
    .line 375
    move-result v0

    .line 376
    if-nez v0, :cond_17a

    .line 377
    .line 378
    goto :goto_1b0

    .line 379
    :cond_17a
    iget-object v0, p1, La6/w;->S0:Lk3/e1;

    .line 380
    .line 381
    invoke-interface {v0}, Lk3/e1;->Z1()Lk3/t1;

    .line 382
    .line 383
    .line 384
    move-result-object v0

    .line 385
    iget-object v1, p1, La6/w;->S0:Lk3/e1;

    .line 386
    .line 387
    sget-object v3, Ln3/l0;->a:Ljava/lang/String;

    .line 388
    .line 389
    invoke-virtual {v0}, Lk3/t1;->a()Lk3/s1;

    .line 390
    .line 391
    .line 392
    move-result-object v0

    .line 393
    invoke-virtual {v0, v2}, Lk3/s1;->d(I)Lk3/s1;

    .line 394
    .line 395
    .line 396
    move-result-object v0

    .line 397
    const/4 v3, 0x0

    .line 398
    invoke-virtual {v0, v2, v3}, Lk3/s1;->l(IZ)Lk3/s1;

    .line 399
    .line 400
    .line 401
    move-result-object v0

    .line 402
    invoke-virtual {v0}, Lk3/s1;->b()Lk3/t1;

    .line 403
    .line 404
    .line 405
    move-result-object v0

    .line 406
    invoke-interface {v1, v0}, Lk3/e1;->N0(Lk3/t1;)V

    .line 407
    .line 408
    .line 409
    iget-object v0, p1, La6/w;->O:La6/r;

    .line 410
    .line 411
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    const v3, 0x7f1300c1

    .line 416
    .line 417
    .line 418
    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v1

    .line 422
    iget-object v0, v0, La6/r;->f:Ljava/lang/Object;

    .line 423
    .line 424
    check-cast v0, [Ljava/lang/String;

    .line 425
    .line 426
    aput-object v1, v0, v2

    .line 427
    .line 428
    iget-object p1, p1, La6/w;->T:Landroid/widget/PopupWindow;

    .line 429
    .line 430
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    .line 431
    .line 432
    .line 433
    :cond_1b0
    :goto_1b0
    return-void

    .line 434
    :pswitch_1b1
    check-cast v4, La6/w;

    .line 435
    .line 436
    iget-boolean p1, v4, La6/w;->T0:Z

    .line 437
    .line 438
    xor-int/2addr p1, v2

    .line 439
    invoke-virtual {v4, p1}, La6/w;->o(Z)V

    .line 440
    .line 441
    .line 442
    return-void

    .line 443
    :pswitch_data_1ba
    .packed-switch 0x0
        :pswitch_1b1
        :pswitch_16b
        :pswitch_145
        :pswitch_10d
        :pswitch_ea
        :pswitch_e4
        :pswitch_de
        :pswitch_cb
        :pswitch_c1
        :pswitch_b7
        :pswitch_b1
        :pswitch_ab
        :pswitch_a5
        :pswitch_9d
        :pswitch_97
        :pswitch_91
        :pswitch_89
        :pswitch_83
        :pswitch_7d
        :pswitch_6e
        :pswitch_68
        :pswitch_62
        :pswitch_4b
        :pswitch_45
        :pswitch_19
        :pswitch_13
    .end packed-switch
.end method
