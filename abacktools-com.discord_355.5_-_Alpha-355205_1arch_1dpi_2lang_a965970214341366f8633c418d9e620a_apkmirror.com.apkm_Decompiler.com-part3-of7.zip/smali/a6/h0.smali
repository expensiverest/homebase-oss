###### Class a6.h0 (a6.h0)
.class public final synthetic La6/h0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/h0;->a:I

    iput-object p2, p0, La6/h0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, La6/h0;->a:I

    .line 2
    .line 3
    iget-object v1, p0, La6/h0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_30

    .line 6
    .line 7
    .line 8
    check-cast v1, Lcom/swmansion/reanimated/pseudoSelectors/ExtraWindowObserverBridge;

    .line 9
    .line 10
    invoke-static {v1, p1, p2, p3}, Lcom/swmansion/reanimated/pseudoSelectors/ExtraWindowObserverBridge;->a(Lcom/swmansion/reanimated/pseudoSelectors/ExtraWindowObserverBridge;Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_e
    check-cast v1, Landroidx/media3/ui/PlayerView;

    .line 16
    .line 17
    sget p1, Landroidx/media3/ui/PlayerView;->l0:I

    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    const-string p2, "onImageAvailable"

    .line 24
    .line 25
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_2d

    .line 30
    .line 31
    const/4 p1, 0x1

    .line 32
    aget-object p2, p3, p1

    .line 33
    .line 34
    check-cast p2, Landroid/graphics/Bitmap;

    .line 35
    .line 36
    iget-object p3, v1, Landroidx/media3/ui/PlayerView;->Q:Landroid/os/Handler;

    .line 37
    .line 38
    new-instance v0, La4/c;

    .line 39
    .line 40
    invoke-direct {v0, p1, v1, p2}, La4/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p3, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 44
    .line 45
    .line 46
    :cond_2d
    const/4 p1, 0x0

    .line 47
    return-object p1

    .line 48
    nop

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
