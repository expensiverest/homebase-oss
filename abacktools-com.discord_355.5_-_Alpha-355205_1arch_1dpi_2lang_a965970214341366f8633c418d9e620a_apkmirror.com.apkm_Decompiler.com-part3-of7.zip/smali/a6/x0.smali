###### Class a6.x0 (a6.x0)
.class public final La6/x0;
.super Landroid/webkit/WebView;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 1
    iput p3, p0, La6/x0;->d:I

    invoke-direct {p0, p1, p2}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 3

    .line 1
    iget v0, p0, La6/x0;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1}, Landroid/webkit/WebView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 7
    .line 8
    .line 9
    :goto_8
    const/4 p1, 0x0

    .line 10
    return p1

    .line 11
    :pswitch_a
    invoke-super {p0, p1}, Landroid/webkit/WebView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 12
    .line 13
    .line 14
    goto :goto_8

    .line 15
    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method

.method public final performClick()Z
    .registers 2

    .line 1
    iget v0, p0, La6/x0;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    .line 7
    .line 8
    .line 9
    :goto_8
    const/4 v0, 0x0

    .line 10
    return v0

    .line 11
    :pswitch_a
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    .line 12
    .line 13
    .line 14
    goto :goto_8

    .line 15
    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method
