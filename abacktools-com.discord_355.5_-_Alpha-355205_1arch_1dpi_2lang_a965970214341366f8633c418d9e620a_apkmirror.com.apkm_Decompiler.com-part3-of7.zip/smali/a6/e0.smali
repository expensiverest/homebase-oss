###### Class a6.e0 (a6.e0)
.class public final La6/e0;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    .line 1
    const/4 v0, 0x1

    iput v0, p0, La6/e0;->a:I

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 2
    iput p1, p0, La6/e0;->a:I

    iput-object p2, p0, La6/e0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .registers 3

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FirebaseMessaging"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    const-string v0, "Connectivity change received registered"

    .line 11
    .line 12
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 13
    .line 14
    .line 15
    :cond_e
    new-instance v0, Landroid/content/IntentFilter;

    .line 16
    .line 17
    const-string v1, "android.net.conn.CONNECTIVITY_CHANGE"

    .line 18
    .line 19
    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v1, Lcom/google/firebase/messaging/v;

    .line 25
    .line 26
    iget-object v1, v1, Lcom/google/firebase/messaging/v;->i:Lcom/google/firebase/messaging/FirebaseMessaging;

    .line 27
    .line 28
    iget-object v1, v1, Lcom/google/firebase/messaging/FirebaseMessaging;->b:Landroid/content/Context;

    .line 29
    .line 30
    invoke-virtual {v1, p0, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 15

    .line 1
    iget v0, p0, La6/e0;->a:I

    .line 2
    .line 3
    const/4 v1, 0x7

    .line 4
    const/16 v2, 0x9

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x3

    .line 8
    const-string v5, "intent"

    .line 9
    .line 10
    const-string v6, "context"

    .line 11
    .line 12
    const/4 v7, 0x0

    .line 13
    const/4 v8, 0x1

    .line 14
    const/4 v9, 0x2

    .line 15
    packed-switch v0, :pswitch_data_416

    .line 16
    .line 17
    .line 18
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Lz8/l;

    .line 21
    .line 22
    iget-object v0, p1, Lz8/l;->c:Landroid/media/AudioManager;

    .line 23
    .line 24
    if-eqz p2, :cond_1e

    .line 25
    .line 26
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move-object v1, v7

    .line 32
    :goto_1f
    if-eqz v1, :cond_b8

    .line 33
    .line 34
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    const v4, -0x64dbd1dc

    .line 39
    .line 40
    .line 41
    if-eq v2, v4, :cond_2c

    .line 42
    .line 43
    goto/16 :goto_b8

    .line 44
    .line 45
    :cond_2c
    const-string v2, "android.media.ACTION_SCO_AUDIO_STATE_UPDATED"

    .line 46
    .line 47
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_b8

    .line 52
    .line 53
    const-string v1, "android.media.extra.SCO_AUDIO_PREVIOUS_STATE"

    .line 54
    .line 55
    const/4 v2, -0x1

    .line 56
    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const-string v4, "android.media.extra.SCO_AUDIO_STATE"

    .line 61
    .line 62
    invoke-virtual {p2, v4, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 63
    .line 64
    .line 65
    move-result p2

    .line 66
    sget-object v4, Lnf/a;->a:Lnf/a;

    .line 67
    .line 68
    const-string v4, "SCO_AUDIO_STATE_ERROR"

    .line 69
    .line 70
    const-string v5, "SCO_AUDIO_STATE_DISCONNECTED"

    .line 71
    .line 72
    const-string v6, "SCO_AUDIO_STATE_CONNECTED"

    .line 73
    .line 74
    const-string v10, "SCO_AUDIO_STATE_CONNECTING"

    .line 75
    .line 76
    const-string v11, "UNKNOWN"

    .line 77
    .line 78
    if-eq v1, v2, :cond_5d

    .line 79
    .line 80
    if-eqz v1, :cond_5b

    .line 81
    .line 82
    if-eq v1, v8, :cond_59

    .line 83
    .line 84
    if-eq v1, v9, :cond_57

    .line 85
    .line 86
    move-object v1, v11

    .line 87
    goto :goto_5e

    .line 88
    :cond_57
    move-object v1, v10

    .line 89
    goto :goto_5e

    .line 90
    :cond_59
    move-object v1, v6

    .line 91
    goto :goto_5e

    .line 92
    :cond_5b
    move-object v1, v5

    .line 93
    goto :goto_5e

    .line 94
    :cond_5d
    move-object v1, v4

    .line 95
    :goto_5e
    if-eq p2, v2, :cond_6d

    .line 96
    .line 97
    if-eqz p2, :cond_6c

    .line 98
    .line 99
    if-eq p2, v8, :cond_6a

    .line 100
    .line 101
    if-eq p2, v9, :cond_68

    .line 102
    .line 103
    move-object v4, v11

    .line 104
    goto :goto_6d

    .line 105
    :cond_68
    move-object v4, v10

    .line 106
    goto :goto_6d

    .line 107
    :cond_6a
    move-object v4, v6

    .line 108
    goto :goto_6d

    .line 109
    :cond_6c
    move-object v4, v5

    .line 110
    :cond_6d
    :goto_6d
    const-string v5, "Bluetooth SCO State Change - previous: "

    .line 111
    .line 112
    const-string v6, " current: "

    .line 113
    .line 114
    invoke-static {v5, v1, v6, v4}, Lcom/google/android/gms/internal/fido/nb;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    const-string v4, "DiscordAudioManager"

    .line 119
    .line 120
    invoke-static {v4, v1, v7}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 121
    .line 122
    .line 123
    if-eq p2, v2, :cond_8d

    .line 124
    .line 125
    if-eqz p2, :cond_8d

    .line 126
    .line 127
    if-eq p2, v8, :cond_81

    .line 128
    .line 129
    goto :goto_b8

    .line 130
    :cond_81
    invoke-virtual {v0}, Landroid/media/AudioManager;->isBluetoothScoOn()Z

    .line 131
    .line 132
    .line 133
    move-result p2

    .line 134
    if-eqz p2, :cond_b8

    .line 135
    .line 136
    iput v3, p1, Lz8/l;->f:I

    .line 137
    .line 138
    invoke-virtual {p1}, Lz8/l;->i()V

    .line 139
    .line 140
    .line 141
    goto :goto_b8

    .line 142
    :cond_8d
    iget-object p2, p1, Lz8/l;->i:Lz8/o;

    .line 143
    .line 144
    sget-object v1, Lz8/o;->x:Lz8/o;

    .line 145
    .line 146
    if-ne p2, v1, :cond_b8

    .line 147
    .line 148
    iget p2, p1, Lz8/l;->f:I

    .line 149
    .line 150
    iget v1, p1, Lz8/l;->e:I

    .line 151
    .line 152
    if-ge p2, v1, :cond_b1

    .line 153
    .line 154
    add-int/2addr p2, v8

    .line 155
    iput p2, p1, Lz8/l;->f:I

    .line 156
    .line 157
    new-instance p1, Ljava/lang/StringBuilder;

    .line 158
    .line 159
    const-string v1, "Retry SCO # "

    .line 160
    .line 161
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 168
    .line 169
    .line 170
    move-result-object p1

    .line 171
    invoke-static {v4, p1, v7}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v0}, Landroid/media/AudioManager;->startBluetoothSco()V

    .line 175
    .line 176
    .line 177
    goto :goto_b8

    .line 178
    :cond_b1
    sget-object p2, Lz8/o;->d:Lz8/o;

    .line 179
    .line 180
    iput-object p2, p1, Lz8/l;->i:Lz8/o;

    .line 181
    .line 182
    invoke-virtual {p1}, Lz8/l;->i()V

    .line 183
    .line 184
    .line 185
    :cond_b8
    :goto_b8
    return-void

    .line 186
    :pswitch_b9
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    const-string v0, "android.intent.action.MEDIA_BUTTON"

    .line 191
    .line 192
    invoke-static {p1, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result p1

    .line 196
    if-nez p1, :cond_c6

    .line 197
    .line 198
    goto :goto_e0

    .line 199
    :cond_c6
    invoke-static {p2}, Le00/a;->o(Landroid/content/Intent;)Landroid/view/KeyEvent;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    if-nez p1, :cond_cd

    .line 204
    .line 205
    goto :goto_e0

    .line 206
    :cond_cd
    iget-object p2, p0, La6/e0;->b:Ljava/lang/Object;

    .line 207
    .line 208
    check-cast p2, Ly5/v0;

    .line 209
    .line 210
    iget-object p2, p2, Ly5/v0;->o:Lz5/u;

    .line 211
    .line 212
    iget-object p2, p2, Lz5/u;->e:Ljava/lang/Object;

    .line 213
    .line 214
    check-cast p2, Lz5/y;

    .line 215
    .line 216
    iget-object p2, p2, Lz5/y;->a:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast p2, Lz5/g;

    .line 219
    .line 220
    iget-object p2, p2, Lz5/g;->a:Landroid/media/session/MediaController;

    .line 221
    .line 222
    invoke-virtual {p2, p1}, Landroid/media/session/MediaController;->dispatchMediaButtonEvent(Landroid/view/KeyEvent;)Z

    .line 223
    .line 224
    .line 225
    :goto_e0
    return-void

    .line 226
    :pswitch_e1
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 227
    .line 228
    check-cast p1, Ly5/b;

    .line 229
    .line 230
    iget-object p2, p1, Ly5/b;->c:Ljava/util/concurrent/Executor;

    .line 231
    .line 232
    new-instance v0, Ly5/a;

    .line 233
    .line 234
    invoke-direct {v0, p1, v9}, Ly5/a;-><init>(Ly5/b;I)V

    .line 235
    .line 236
    .line 237
    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 238
    .line 239
    .line 240
    return-void

    .line 241
    :pswitch_f0
    iget-object v0, p0, La6/e0;->b:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast v0, Lx3/c;

    .line 244
    .line 245
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->isInitialStickyBroadcast()Z

    .line 246
    .line 247
    .line 248
    move-result v1

    .line 249
    if-nez v1, :cond_109

    .line 250
    .line 251
    invoke-virtual {v0}, Lx3/c;->a()Ljava/util/List;

    .line 252
    .line 253
    .line 254
    move-result-object v1

    .line 255
    iget-object v2, v0, Lx3/c;->j:Lk3/e;

    .line 256
    .line 257
    iget-object v3, v0, Lx3/c;->i:Landroid/media/AudioDeviceInfo;

    .line 258
    .line 259
    invoke-static {p1, p2, v2, v3, v1}, Lx3/b;->b(Landroid/content/Context;Landroid/content/Intent;Lk3/e;Landroid/media/AudioDeviceInfo;Ljava/util/List;)Lx3/b;

    .line 260
    .line 261
    .line 262
    move-result-object p1

    .line 263
    invoke-virtual {v0, p1}, Lx3/c;->b(Lx3/b;)V

    .line 264
    .line 265
    .line 266
    :cond_109
    return-void

    .line 267
    :pswitch_10a
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 268
    .line 269
    check-cast p1, Lww/o;

    .line 270
    .line 271
    invoke-virtual {p1, p2}, Lww/o;->b(Landroid/content/Intent;)V

    .line 272
    .line 273
    .line 274
    return-void

    .line 275
    :pswitch_112
    invoke-static {p1, v6}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 276
    .line 277
    .line 278
    invoke-static {p2, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    const-string p1, "newConfig"

    .line 282
    .line 283
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 284
    .line 285
    .line 286
    move-result-object p1

    .line 287
    invoke-static {p1}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 288
    .line 289
    .line 290
    check-cast p1, Landroid/content/res/Configuration;

    .line 291
    .line 292
    iget p1, p1, Landroid/content/res/Configuration;->orientation:I

    .line 293
    .line 294
    iget-object p2, p0, La6/e0;->b:Ljava/lang/Object;

    .line 295
    .line 296
    check-cast p2, Lwq/b;

    .line 297
    .line 298
    iget-object p2, p2, Lwq/b;->d:Lcom/facebook/react/bridge/ReactContext;

    .line 299
    .line 300
    const-string v0, "reactContext"

    .line 301
    .line 302
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {p2}, Lcom/facebook/react/bridge/ReactContext;->hasActiveReactInstance()Z

    .line 306
    .line 307
    .line 308
    move-result v0

    .line 309
    if-eqz v0, :cond_153

    .line 310
    .line 311
    if-ne p1, v8, :cond_13b

    .line 312
    .line 313
    const-string p1, "PORTRAIT"

    .line 314
    .line 315
    goto :goto_13d

    .line 316
    :cond_13b
    const-string p1, "LANDSCAPE"

    .line 317
    .line 318
    :goto_13d
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    const-string v1, "orientation"

    .line 323
    .line 324
    invoke-interface {v0, v1, p1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    const-class p1, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;

    .line 328
    .line 329
    invoke-virtual {p2, p1}, Lcom/facebook/react/bridge/ReactContext;->getJSModule(Ljava/lang/Class;)Lcom/facebook/react/bridge/JavaScriptModule;

    .line 330
    .line 331
    .line 332
    move-result-object p1

    .line 333
    check-cast p1, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;

    .line 334
    .line 335
    const-string p2, "orientationDidChange"

    .line 336
    .line 337
    invoke-interface {p1, p2, v0}, Lcom/facebook/react/modules/core/DeviceEventManagerModule$RCTDeviceEventEmitter;->emit(Ljava/lang/String;Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    :cond_153
    return-void

    .line 341
    :pswitch_154
    iget-object p2, p0, La6/e0;->b:Ljava/lang/Object;

    .line 342
    .line 343
    check-cast p2, Lqt/p;

    .line 344
    .line 345
    const-string v0, "connectivity"

    .line 346
    .line 347
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    check-cast v0, Landroid/net/ConnectivityManager;

    .line 352
    .line 353
    const/4 v5, 0x5

    .line 354
    if-nez v0, :cond_164

    .line 355
    .line 356
    goto :goto_197

    .line 357
    :cond_164
    :try_start_164
    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    .line 358
    .line 359
    .line 360
    move-result-object v0
    :try_end_168
    .catch Ljava/lang/SecurityException; {:try_start_164 .. :try_end_168} :catch_197

    .line 361
    if-eqz v0, :cond_1a1

    .line 362
    .line 363
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->isConnected()Z

    .line 364
    .line 365
    .line 366
    move-result v6

    .line 367
    if-nez v6, :cond_171

    .line 368
    .line 369
    goto :goto_1a1

    .line 370
    :cond_171
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getType()I

    .line 371
    .line 372
    .line 373
    move-result v6

    .line 374
    const/4 v7, 0x6

    .line 375
    const/4 v10, 0x4

    .line 376
    if-eqz v6, :cond_186

    .line 377
    .line 378
    if-eq v6, v8, :cond_199

    .line 379
    .line 380
    if-eq v6, v10, :cond_186

    .line 381
    .line 382
    if-eq v6, v5, :cond_186

    .line 383
    .line 384
    if-eq v6, v7, :cond_19b

    .line 385
    .line 386
    if-eq v6, v2, :cond_1a2

    .line 387
    .line 388
    const/16 v1, 0x8

    .line 389
    .line 390
    goto :goto_1a2

    .line 391
    :cond_186
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getSubtype()I

    .line 392
    .line 393
    .line 394
    move-result v0

    .line 395
    packed-switch v0, :pswitch_data_436

    .line 396
    .line 397
    .line 398
    :pswitch_18d
    move v1, v7

    .line 399
    goto :goto_1a2

    .line 400
    :pswitch_18f
    sget v0, Lqt/x;->a:I

    .line 401
    .line 402
    const/16 v1, 0x1d

    .line 403
    .line 404
    if-lt v0, v1, :cond_197

    .line 405
    .line 406
    move v1, v2

    .line 407
    goto :goto_1a2

    .line 408
    :catch_197
    :cond_197
    :goto_197
    move v1, v3

    .line 409
    goto :goto_1a2

    .line 410
    :cond_199
    :pswitch_199
    move v1, v9

    .line 411
    goto :goto_1a2

    .line 412
    :cond_19b
    :pswitch_19b
    move v1, v5

    .line 413
    goto :goto_1a2

    .line 414
    :pswitch_19d
    move v1, v10

    .line 415
    goto :goto_1a2

    .line 416
    :pswitch_19f
    move v1, v4

    .line 417
    goto :goto_1a2

    .line 418
    :cond_1a1
    :goto_1a1
    move v1, v8

    .line 419
    :cond_1a2
    :goto_1a2
    sget v0, Lqt/x;->a:I

    .line 420
    .line 421
    const/16 v2, 0x1f

    .line 422
    .line 423
    if-lt v0, v2, :cond_1ae

    .line 424
    .line 425
    if-ne v1, v5, :cond_1ae

    .line 426
    .line 427
    invoke-static {p1, p2}, Lqt/o;->a(Landroid/content/Context;Lqt/p;)V

    .line 428
    .line 429
    .line 430
    goto :goto_1b1

    .line 431
    :cond_1ae
    invoke-static {v1, p2}, Lqt/p;->a(ILqt/p;)V

    .line 432
    .line 433
    .line 434
    :goto_1b1
    return-void

    .line 435
    :pswitch_1b2
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->isInitialStickyBroadcast()Z

    .line 436
    .line 437
    .line 438
    move-result v0

    .line 439
    if-nez v0, :cond_1c3

    .line 440
    .line 441
    iget-object v0, p0, La6/e0;->b:Ljava/lang/Object;

    .line 442
    .line 443
    check-cast v0, Lc6/b;

    .line 444
    .line 445
    invoke-static {p1, p2}, Lor/g;->b(Landroid/content/Context;Landroid/content/Intent;)Lor/g;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    invoke-static {v0, p1}, Lc6/b;->a(Lc6/b;Lor/g;)V

    .line 450
    .line 451
    .line 452
    :cond_1c3
    return-void

    .line 453
    :pswitch_1c4
    iget-object p2, p0, La6/e0;->b:Ljava/lang/Object;

    .line 454
    .line 455
    check-cast p2, Ln3/v;

    .line 456
    .line 457
    iget-object p2, p2, Ln3/v;->i:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast p2, Ljava/util/concurrent/Executor;

    .line 460
    .line 461
    new-instance v0, Lio/sentry/react/c;

    .line 462
    .line 463
    const/16 v1, 0x11

    .line 464
    .line 465
    invoke-direct {v0, v1, p0, p1}, Lio/sentry/react/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 466
    .line 467
    .line 468
    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 469
    .line 470
    .line 471
    return-void

    .line 472
    :pswitch_1d7
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 473
    .line 474
    check-cast p1, Lcom/discord/time_zone_fix/TimezoneHermesFixModule;

    .line 475
    .line 476
    if-eqz p2, :cond_1e1

    .line 477
    .line 478
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 479
    .line 480
    .line 481
    move-result-object v7

    .line 482
    :cond_1e1
    const-string p2, "android.intent.action.TIMEZONE_CHANGED"

    .line 483
    .line 484
    invoke-static {v7, p2}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 485
    .line 486
    .line 487
    move-result p2

    .line 488
    if-eqz p2, :cond_204

    .line 489
    .line 490
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    .line 491
    .line 492
    .line 493
    move-result-object p2

    .line 494
    invoke-virtual {p2}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    .line 495
    .line 496
    .line 497
    move-result-object p2

    .line 498
    invoke-static {p1}, Lcom/discord/time_zone_fix/TimezoneHermesFixModule;->access$getCurrentTimezoneName$p(Lcom/discord/time_zone_fix/TimezoneHermesFixModule;)Ljava/lang/String;

    .line 499
    .line 500
    .line 501
    move-result-object v0

    .line 502
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 503
    .line 504
    .line 505
    move-result v0

    .line 506
    if-nez v0, :cond_204

    .line 507
    .line 508
    invoke-static {p2}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 509
    .line 510
    .line 511
    invoke-static {p1, p2}, Lcom/discord/time_zone_fix/TimezoneHermesFixModule;->access$setCurrentTimezoneName$p(Lcom/discord/time_zone_fix/TimezoneHermesFixModule;Ljava/lang/String;)V

    .line 512
    .line 513
    .line 514
    invoke-static {p1}, Lcom/discord/time_zone_fix/TimezoneHermesFixModule;->access$onTimezoneChanged(Lcom/discord/time_zone_fix/TimezoneHermesFixModule;)V

    .line 515
    .line 516
    .line 517
    :cond_204
    return-void

    .line 518
    :pswitch_205
    invoke-static {p1, v6}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 519
    .line 520
    .line 521
    invoke-static {p2, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 522
    .line 523
    .line 524
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 525
    .line 526
    check-cast p1, Lcom/discord/notifications/renderer/IncomingCallActivity;

    .line 527
    .line 528
    invoke-virtual {p1}, Landroid/app/Activity;->finishAndRemoveTask()V

    .line 529
    .line 530
    .line 531
    return-void

    .line 532
    :pswitch_213
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 533
    .line 534
    check-cast p1, Lcom/facebook/react/devsupport/g;

    .line 535
    .line 536
    invoke-virtual {p1}, Lcom/facebook/react/devsupport/g;->o()V

    .line 537
    .line 538
    .line 539
    return-void

    .line 540
    :pswitch_21b
    invoke-static {p1, v6}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 541
    .line 542
    .line 543
    invoke-static {p2, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 547
    .line 548
    check-cast p1, Li7/a;

    .line 549
    .line 550
    iget v0, p1, Li7/a;->g:I

    .line 551
    .line 552
    const-string v1, "Received "

    .line 553
    .line 554
    packed-switch v0, :pswitch_data_462

    .line 555
    .line 556
    .line 557
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 558
    .line 559
    .line 560
    move-result-object v0

    .line 561
    if-nez v0, :cond_234

    .line 562
    .line 563
    goto/16 :goto_333

    .line 564
    .line 565
    :cond_234
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 566
    .line 567
    .line 568
    move-result-object v0

    .line 569
    sget-object v2, Li7/j;->a:Ljava/lang/String;

    .line 570
    .line 571
    new-instance v3, Ljava/lang/StringBuilder;

    .line 572
    .line 573
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 574
    .line 575
    .line 576
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 577
    .line 578
    .line 579
    move-result-object v1

    .line 580
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 581
    .line 582
    .line 583
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 584
    .line 585
    .line 586
    move-result-object v1

    .line 587
    invoke-virtual {v0, v2, v1}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 588
    .line 589
    .line 590
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 591
    .line 592
    .line 593
    move-result-object p2

    .line 594
    if-eqz p2, :cond_333

    .line 595
    .line 596
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 597
    .line 598
    .line 599
    move-result v0

    .line 600
    const v1, -0x46671f94

    .line 601
    .line 602
    .line 603
    if-eq v0, v1, :cond_274

    .line 604
    .line 605
    const v1, -0x2b8fb65c

    .line 606
    .line 607
    .line 608
    if-eq v0, v1, :cond_263

    .line 609
    .line 610
    goto/16 :goto_333

    .line 611
    .line 612
    :cond_263
    const-string v0, "android.intent.action.DEVICE_STORAGE_OK"

    .line 613
    .line 614
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 615
    .line 616
    .line 617
    move-result p2

    .line 618
    if-nez p2, :cond_26d

    .line 619
    .line 620
    goto/16 :goto_333

    .line 621
    .line 622
    :cond_26d
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 623
    .line 624
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 625
    .line 626
    .line 627
    goto/16 :goto_333

    .line 628
    .line 629
    :cond_274
    const-string v0, "android.intent.action.DEVICE_STORAGE_LOW"

    .line 630
    .line 631
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 632
    .line 633
    .line 634
    move-result p2

    .line 635
    if-nez p2, :cond_27e

    .line 636
    .line 637
    goto/16 :goto_333

    .line 638
    .line 639
    :cond_27e
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 640
    .line 641
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 642
    .line 643
    .line 644
    goto/16 :goto_333

    .line 645
    .line 646
    :pswitch_285
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object v0

    .line 650
    if-nez v0, :cond_28d

    .line 651
    .line 652
    goto/16 :goto_333

    .line 653
    .line 654
    :cond_28d
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 655
    .line 656
    .line 657
    move-result-object v0

    .line 658
    sget-object v2, Li7/c;->a:Ljava/lang/String;

    .line 659
    .line 660
    new-instance v3, Ljava/lang/StringBuilder;

    .line 661
    .line 662
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 663
    .line 664
    .line 665
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 666
    .line 667
    .line 668
    move-result-object v1

    .line 669
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 670
    .line 671
    .line 672
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 673
    .line 674
    .line 675
    move-result-object v1

    .line 676
    invoke-virtual {v0, v2, v1}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 677
    .line 678
    .line 679
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 680
    .line 681
    .line 682
    move-result-object p2

    .line 683
    if-eqz p2, :cond_333

    .line 684
    .line 685
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 686
    .line 687
    .line 688
    move-result v0

    .line 689
    const v1, -0x7606c095    # -6.0004207E-33f

    .line 690
    .line 691
    .line 692
    if-eq v0, v1, :cond_2cd

    .line 693
    .line 694
    const v1, 0x1d398bfd

    .line 695
    .line 696
    .line 697
    if-eq v0, v1, :cond_2bc

    .line 698
    .line 699
    goto/16 :goto_333

    .line 700
    .line 701
    :cond_2bc
    const-string v0, "android.intent.action.BATTERY_LOW"

    .line 702
    .line 703
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 704
    .line 705
    .line 706
    move-result p2

    .line 707
    if-nez p2, :cond_2c6

    .line 708
    .line 709
    goto/16 :goto_333

    .line 710
    .line 711
    :cond_2c6
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 712
    .line 713
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 714
    .line 715
    .line 716
    goto/16 :goto_333

    .line 717
    .line 718
    :cond_2cd
    const-string v0, "android.intent.action.BATTERY_OKAY"

    .line 719
    .line 720
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 721
    .line 722
    .line 723
    move-result p2

    .line 724
    if-nez p2, :cond_2d6

    .line 725
    .line 726
    goto :goto_333

    .line 727
    :cond_2d6
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 728
    .line 729
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 730
    .line 731
    .line 732
    goto :goto_333

    .line 733
    :pswitch_2dc
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 734
    .line 735
    .line 736
    move-result-object p2

    .line 737
    if-nez p2, :cond_2e3

    .line 738
    .line 739
    goto :goto_333

    .line 740
    :cond_2e3
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 741
    .line 742
    .line 743
    move-result-object v0

    .line 744
    sget-object v2, Li7/b;->a:Ljava/lang/String;

    .line 745
    .line 746
    invoke-virtual {v1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 747
    .line 748
    .line 749
    move-result-object v1

    .line 750
    invoke-virtual {v0, v2, v1}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 751
    .line 752
    .line 753
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 754
    .line 755
    .line 756
    move-result v0

    .line 757
    sparse-switch v0, :sswitch_data_46a

    .line 758
    .line 759
    .line 760
    goto :goto_333

    .line 761
    :sswitch_2f8
    const-string v0, "android.intent.action.ACTION_POWER_CONNECTED"

    .line 762
    .line 763
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 764
    .line 765
    .line 766
    move-result p2

    .line 767
    if-nez p2, :cond_301

    .line 768
    .line 769
    goto :goto_333

    .line 770
    :cond_301
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 771
    .line 772
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 773
    .line 774
    .line 775
    goto :goto_333

    .line 776
    :sswitch_307
    const-string v0, "android.os.action.CHARGING"

    .line 777
    .line 778
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 779
    .line 780
    .line 781
    move-result p2

    .line 782
    if-nez p2, :cond_310

    .line 783
    .line 784
    goto :goto_333

    .line 785
    :cond_310
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 786
    .line 787
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 788
    .line 789
    .line 790
    goto :goto_333

    .line 791
    :sswitch_316
    const-string v0, "android.os.action.DISCHARGING"

    .line 792
    .line 793
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 794
    .line 795
    .line 796
    move-result p2

    .line 797
    if-nez p2, :cond_31f

    .line 798
    .line 799
    goto :goto_333

    .line 800
    :cond_31f
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 801
    .line 802
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 803
    .line 804
    .line 805
    goto :goto_333

    .line 806
    :sswitch_325
    const-string v0, "android.intent.action.ACTION_POWER_DISCONNECTED"

    .line 807
    .line 808
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 809
    .line 810
    .line 811
    move-result p2

    .line 812
    if-nez p2, :cond_32e

    .line 813
    .line 814
    goto :goto_333

    .line 815
    :cond_32e
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 816
    .line 817
    invoke-virtual {p1, p2}, Li7/e;->b(Ljava/lang/Object;)V

    .line 818
    .line 819
    .line 820
    :cond_333
    :goto_333
    return-void

    .line 821
    :pswitch_334
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 822
    .line 823
    check-cast p1, Lcom/google/firebase/messaging/v;

    .line 824
    .line 825
    if-nez p1, :cond_33b

    .line 826
    .line 827
    goto :goto_36a

    .line 828
    :cond_33b
    invoke-virtual {p1}, Lcom/google/firebase/messaging/v;->a()Z

    .line 829
    .line 830
    .line 831
    move-result p1

    .line 832
    if-nez p1, :cond_342

    .line 833
    .line 834
    goto :goto_36a

    .line 835
    :cond_342
    const-string p1, "FirebaseMessaging"

    .line 836
    .line 837
    invoke-static {p1, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 838
    .line 839
    .line 840
    move-result p2

    .line 841
    if-eqz p2, :cond_34f

    .line 842
    .line 843
    const-string p2, "Connectivity changed. Starting background sync."

    .line 844
    .line 845
    invoke-static {p1, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 846
    .line 847
    .line 848
    :cond_34f
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 849
    .line 850
    check-cast p1, Lcom/google/firebase/messaging/v;

    .line 851
    .line 852
    iget-object p2, p1, Lcom/google/firebase/messaging/v;->i:Lcom/google/firebase/messaging/FirebaseMessaging;

    .line 853
    .line 854
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 855
    .line 856
    .line 857
    const-wide/16 v0, 0x0

    .line 858
    .line 859
    invoke-static {p1, v0, v1}, Lcom/google/firebase/messaging/FirebaseMessaging;->b(Ljava/lang/Runnable;J)V

    .line 860
    .line 861
    .line 862
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 863
    .line 864
    check-cast p1, Lcom/google/firebase/messaging/v;

    .line 865
    .line 866
    iget-object p1, p1, Lcom/google/firebase/messaging/v;->i:Lcom/google/firebase/messaging/FirebaseMessaging;

    .line 867
    .line 868
    iget-object p1, p1, Lcom/google/firebase/messaging/FirebaseMessaging;->b:Landroid/content/Context;

    .line 869
    .line 870
    invoke-virtual {p1, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 871
    .line 872
    .line 873
    iput-object v7, p0, La6/e0;->b:Ljava/lang/Object;

    .line 874
    .line 875
    :goto_36a
    return-void

    .line 876
    :pswitch_36b
    iget-object p1, p0, La6/e0;->b:Ljava/lang/Object;

    .line 877
    .line 878
    check-cast p1, La6/g0;

    .line 879
    .line 880
    iget v0, p1, La6/g0;->m:I

    .line 881
    .line 882
    iget-object v3, p1, La6/g0;->p:Lk3/e1;

    .line 883
    .line 884
    if-eqz v3, :cond_415

    .line 885
    .line 886
    iget-boolean v5, p1, La6/g0;->q:Z

    .line 887
    .line 888
    if-eqz v5, :cond_415

    .line 889
    .line 890
    const-string v5, "INSTANCE_ID"

    .line 891
    .line 892
    invoke-virtual {p2, v5, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 893
    .line 894
    .line 895
    move-result v5

    .line 896
    if-eq v5, v0, :cond_383

    .line 897
    .line 898
    goto/16 :goto_415

    .line 899
    .line 900
    :cond_383
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 901
    .line 902
    .line 903
    move-result-object p2

    .line 904
    const-string v0, "androidx.media3.ui.notification.play"

    .line 905
    .line 906
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 907
    .line 908
    .line 909
    move-result v0

    .line 910
    if-eqz v0, :cond_394

    .line 911
    .line 912
    invoke-static {v3}, Ln3/l0;->K(Lk3/e1;)Z

    .line 913
    .line 914
    .line 915
    goto/16 :goto_415

    .line 916
    .line 917
    :cond_394
    const-string v0, "androidx.media3.ui.notification.pause"

    .line 918
    .line 919
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 920
    .line 921
    .line 922
    move-result v0

    .line 923
    if-eqz v0, :cond_3a1

    .line 924
    .line 925
    invoke-static {v3}, Ln3/l0;->J(Lk3/e1;)Z

    .line 926
    .line 927
    .line 928
    goto/16 :goto_415

    .line 929
    .line 930
    :cond_3a1
    const-string v0, "androidx.media3.ui.notification.prev"

    .line 931
    .line 932
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 933
    .line 934
    .line 935
    move-result v0

    .line 936
    if-eqz v0, :cond_3b3

    .line 937
    .line 938
    invoke-interface {v3, v1}, Lk3/e1;->D1(I)Z

    .line 939
    .line 940
    .line 941
    move-result p1

    .line 942
    if-eqz p1, :cond_415

    .line 943
    .line 944
    invoke-interface {v3}, Lk3/e1;->c1()V

    .line 945
    .line 946
    .line 947
    goto :goto_415

    .line 948
    :cond_3b3
    const-string v0, "androidx.media3.ui.notification.rewind"

    .line 949
    .line 950
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 951
    .line 952
    .line 953
    move-result v0

    .line 954
    if-eqz v0, :cond_3c7

    .line 955
    .line 956
    const/16 p1, 0xb

    .line 957
    .line 958
    invoke-interface {v3, p1}, Lk3/e1;->D1(I)Z

    .line 959
    .line 960
    .line 961
    move-result p1

    .line 962
    if-eqz p1, :cond_415

    .line 963
    .line 964
    invoke-interface {v3}, Lk3/e1;->h2()V

    .line 965
    .line 966
    .line 967
    goto :goto_415

    .line 968
    :cond_3c7
    const-string v0, "androidx.media3.ui.notification.ffwd"

    .line 969
    .line 970
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 971
    .line 972
    .line 973
    move-result v0

    .line 974
    if-eqz v0, :cond_3db

    .line 975
    .line 976
    const/16 p1, 0xc

    .line 977
    .line 978
    invoke-interface {v3, p1}, Lk3/e1;->D1(I)Z

    .line 979
    .line 980
    .line 981
    move-result p1

    .line 982
    if-eqz p1, :cond_415

    .line 983
    .line 984
    invoke-interface {v3}, Lk3/e1;->g2()V

    .line 985
    .line 986
    .line 987
    goto :goto_415

    .line 988
    :cond_3db
    const-string v0, "androidx.media3.ui.notification.next"

    .line 989
    .line 990
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 991
    .line 992
    .line 993
    move-result v0

    .line 994
    if-eqz v0, :cond_3ed

    .line 995
    .line 996
    invoke-interface {v3, v2}, Lk3/e1;->D1(I)Z

    .line 997
    .line 998
    .line 999
    move-result p1

    .line 1000
    if-eqz p1, :cond_415

    .line 1001
    .line 1002
    invoke-interface {v3}, Lk3/e1;->f2()V

    .line 1003
    .line 1004
    .line 1005
    goto :goto_415

    .line 1006
    :cond_3ed
    const-string v0, "androidx.media3.ui.notification.stop"

    .line 1007
    .line 1008
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1009
    .line 1010
    .line 1011
    move-result v0

    .line 1012
    if-eqz v0, :cond_40a

    .line 1013
    .line 1014
    invoke-interface {v3, v4}, Lk3/e1;->D1(I)Z

    .line 1015
    .line 1016
    .line 1017
    move-result p1

    .line 1018
    if-eqz p1, :cond_3fe

    .line 1019
    .line 1020
    invoke-interface {v3}, Lk3/e1;->stop()V

    .line 1021
    .line 1022
    .line 1023
    :cond_3fe
    const/16 p1, 0x14

    .line 1024
    .line 1025
    invoke-interface {v3, p1}, Lk3/e1;->D1(I)Z

    .line 1026
    .line 1027
    .line 1028
    move-result p1

    .line 1029
    if-eqz p1, :cond_415

    .line 1030
    .line 1031
    invoke-interface {v3}, Lk3/e1;->j0()V

    .line 1032
    .line 1033
    .line 1034
    goto :goto_415

    .line 1035
    :cond_40a
    const-string v0, "androidx.media3.ui.notification.dismiss"

    .line 1036
    .line 1037
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1038
    .line 1039
    .line 1040
    move-result p2

    .line 1041
    if-eqz p2, :cond_415

    .line 1042
    .line 1043
    invoke-virtual {p1}, La6/g0;->d()V

    .line 1044
    .line 1045
    .line 1046
    :cond_415
    :goto_415
    return-void

    .line 1047
    :pswitch_data_416
    .packed-switch 0x0
        :pswitch_36b
        :pswitch_334
        :pswitch_21b
        :pswitch_213
        :pswitch_205
        :pswitch_1d7
        :pswitch_1c4
        :pswitch_1b2
        :pswitch_154
        :pswitch_112
        :pswitch_10a
        :pswitch_f0
        :pswitch_e1
        :pswitch_b9
    .end packed-switch

    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    :pswitch_data_436
    .packed-switch 0x1
        :pswitch_19f
        :pswitch_19f
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19d
        :pswitch_19b
        :pswitch_19d
        :pswitch_19d
        :pswitch_18d
        :pswitch_19d
        :pswitch_199
        :pswitch_18d
        :pswitch_18f
    .end packed-switch

    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    :pswitch_data_462
    .packed-switch 0x0
        :pswitch_2dc
        :pswitch_285
    .end packed-switch

    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    :sswitch_data_46a
    .sparse-switch
        -0x7073f927 -> :sswitch_325
        -0x3465cce -> :sswitch_316
        0x388694fe -> :sswitch_307
        0x3cbf870b -> :sswitch_2f8
    .end sparse-switch
.end method
