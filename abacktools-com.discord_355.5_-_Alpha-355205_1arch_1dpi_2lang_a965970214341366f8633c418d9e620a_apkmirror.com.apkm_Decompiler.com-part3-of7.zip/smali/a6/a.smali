###### Class a6.a (a6.a)
.class public interface abstract La6/a;
.super Ljava/lang/Object;
.source "SourceFile"
