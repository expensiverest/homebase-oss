###### Class a6.m (a6.m)
.class public interface abstract La6/m;
.super Ljava/lang/Object;
.source "SourceFile"
