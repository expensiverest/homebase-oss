###### Class a6.n0 (a6.n0)
.class public final synthetic La6/n0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, La6/n0;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 2
    iput p1, p0, La6/n0;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .registers 1

    .line 1
    return-void
.end method

.method private final b()V
    .registers 1

    .line 1
    return-void
.end method

.method private final c()V
    .registers 1

    .line 1
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 12

    .line 1
    iget v0, p0, La6/n0;->d:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    packed-switch v0, :pswitch_data_24e

    .line 7
    .line 8
    .line 9
    invoke-static {}, Lcom/discord/chat/presentation/message/view/voicemessages/AudioPlayerModule;->b()V

    .line 10
    .line 11
    .line 12
    :pswitch_b
    return-void

    .line 13
    :pswitch_c
    invoke-static {}, Lorg/webrtc/EglBase14Impl$EglConnection;->b()V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_10
    invoke-static {}, Lorg/webrtc/EglBase10Impl$EglConnection;->a()V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_14
    invoke-static {}, Lcom/discord/device/DeviceAccessibilityModule;->b()V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_18
    sget-object v0, Lcom/facebook/react/runtime/ReactHostImpl;->x:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 26
    .line 27
    sget-object v0, Lcom/facebook/react/bridge/ReactMarkerConstants;->REACT_BRIDGELESS_LOADING_END:Lcom/facebook/react/bridge/ReactMarkerConstants;

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    invoke-static {v0, v1}, Lcom/facebook/react/bridge/ReactMarker;->logMarker(Lcom/facebook/react/bridge/ReactMarkerConstants;I)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_21
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 35
    .line 36
    .line 37
    move-result-wide v2

    .line 38
    const-wide/16 v4, 0x2710

    .line 39
    .line 40
    sub-long/2addr v2, v4

    .line 41
    sget-object v0, Lkm/e;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 42
    .line 43
    new-instance v0, Ljava/util/Date;

    .line 44
    .line 45
    invoke-direct {v0, v2, v3}, Ljava/util/Date;-><init>(J)V

    .line 46
    .line 47
    .line 48
    sget-object v2, Lkm/e;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 49
    .line 50
    monitor-enter v2

    .line 51
    :try_start_32
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 52
    .line 53
    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v2}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    :cond_3f
    :goto_3f
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v7

    .line 68
    if-eqz v7, :cond_67

    .line 69
    .line 70
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v7

    .line 74
    check-cast v7, Ljava/util/Map$Entry;

    .line 75
    .line 76
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v8

    .line 80
    check-cast v8, Lkm/g;

    .line 81
    .line 82
    iget-object v8, v8, Lkm/g;->b:Ljava/util/Date;

    .line 83
    .line 84
    invoke-virtual {v8, v0}, Ljava/util/Date;->compareTo(Ljava/util/Date;)I

    .line 85
    .line 86
    .line 87
    move-result v8

    .line 88
    if-gez v8, :cond_3f

    .line 89
    .line 90
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v8

    .line 94
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v7

    .line 98
    invoke-interface {v3, v8, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    goto :goto_3f

    .line 102
    :catchall_65
    move-exception v0

    .line 103
    goto :goto_c2

    .line 104
    :cond_67
    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    :goto_6f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 113
    .line 114
    .line 115
    move-result v3

    .line 116
    if-eqz v3, :cond_b3

    .line 117
    .line 118
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    check-cast v3, Ljava/util/Map$Entry;

    .line 123
    .line 124
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v6

    .line 128
    check-cast v6, Lkm/g;

    .line 129
    .line 130
    iget-object v6, v6, Lkm/g;->a:Lkm/d;

    .line 131
    .line 132
    iget-object v7, v6, Lkm/d;->f:Ljava/util/concurrent/ConcurrentHashMap;

    .line 133
    .line 134
    invoke-virtual {v7}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    .line 135
    .line 136
    .line 137
    move-result-object v8

    .line 138
    const-string v9, "<get-values>(...)"

    .line 139
    .line 140
    invoke-static {v8, v9}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 144
    .line 145
    .line 146
    move-result-object v8

    .line 147
    :goto_92
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 148
    .line 149
    .line 150
    move-result v9

    .line 151
    if-eqz v9, :cond_a4

    .line 152
    .line 153
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v9

    .line 157
    check-cast v9, Lkm/c;

    .line 158
    .line 159
    iget-object v9, v9, Lkm/c;->a:Ljl/c;

    .line 160
    .line 161
    invoke-virtual {v9}, Ljl/b;->close()V

    .line 162
    .line 163
    .line 164
    goto :goto_92

    .line 165
    :cond_a4
    invoke-virtual {v7}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    .line 166
    .line 167
    .line 168
    iput v1, v6, Lkm/d;->j:I

    .line 169
    .line 170
    sget-object v6, Lkm/e;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 171
    .line 172
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v3

    .line 176
    invoke-virtual {v6, v3}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_b2
    .catchall {:try_start_32 .. :try_end_b2} :catchall_65

    .line 177
    .line 178
    .line 179
    goto :goto_6f

    .line 180
    :cond_b3
    monitor-exit v2

    .line 181
    sget-object v0, Lkm/b;->e:Ll30/o;

    .line 182
    .line 183
    invoke-virtual {v0}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    check-cast v0, Landroid/os/Handler;

    .line 188
    .line 189
    sget-object v1, Lkm/b;->g:La6/n0;

    .line 190
    .line 191
    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 192
    .line 193
    .line 194
    return-void

    .line 195
    :goto_c2
    monitor-exit v2

    .line 196
    throw v0

    .line 197
    :pswitch_c4
    sget-object v0, Lkm/b;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 198
    .line 199
    sget-object v1, Lkm/b;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 200
    .line 201
    invoke-virtual {v1, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndSet(I)I

    .line 202
    .line 203
    .line 204
    move-result v1

    .line 205
    int-to-float v1, v1

    .line 206
    sget-object v2, Lkm/b;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 207
    .line 208
    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndSet(I)I

    .line 209
    .line 210
    .line 211
    move-result v2

    .line 212
    int-to-float v2, v2

    .line 213
    sget-object v4, Lkm/b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 214
    .line 215
    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndSet(I)I

    .line 216
    .line 217
    .line 218
    move-result v3

    .line 219
    int-to-float v3, v3

    .line 220
    add-float v4, v1, v2

    .line 221
    .line 222
    add-float/2addr v4, v3

    .line 223
    const/4 v5, 0x0

    .line 224
    cmpl-float v5, v4, v5

    .line 225
    .line 226
    if-lez v5, :cond_14f

    .line 227
    .line 228
    div-float/2addr v1, v4

    .line 229
    div-float/2addr v2, v4

    .line 230
    div-float/2addr v3, v4

    .line 231
    const/high16 v4, 0x3e800000    # 0.25f

    .line 232
    .line 233
    cmpl-float v2, v2, v4

    .line 234
    .line 235
    if-gtz v2, :cond_123

    .line 236
    .line 237
    const v2, 0x3dcccccd    # 0.1f

    .line 238
    .line 239
    .line 240
    cmpl-float v2, v3, v2

    .line 241
    .line 242
    if-lez v2, :cond_f4

    .line 243
    .line 244
    goto :goto_123

    .line 245
    :cond_f4
    const v2, 0x3f7ae148    # 0.98f

    .line 246
    .line 247
    .line 248
    cmpl-float v1, v1, v2

    .line 249
    .line 250
    if-lez v1, :cond_14c

    .line 251
    .line 252
    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    .line 253
    .line 254
    .line 255
    move-result-object v1

    .line 256
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 257
    .line 258
    .line 259
    move-result-object v1

    .line 260
    :goto_103
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 261
    .line 262
    .line 263
    move-result v2

    .line 264
    if-eqz v2, :cond_14c

    .line 265
    .line 266
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v2

    .line 270
    check-cast v2, Ljava/util/Map$Entry;

    .line 271
    .line 272
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v3

    .line 276
    check-cast v3, Lim/e;

    .line 277
    .line 278
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object v2

    .line 282
    check-cast v2, Ljava/lang/Number;

    .line 283
    .line 284
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 285
    .line 286
    .line 287
    move-result v2

    .line 288
    invoke-static {v3, v2}, Lkm/b;->a(Lim/e;I)V

    .line 289
    .line 290
    .line 291
    goto :goto_103

    .line 292
    :cond_123
    :goto_123
    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    .line 293
    .line 294
    .line 295
    move-result-object v1

    .line 296
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 297
    .line 298
    .line 299
    move-result-object v1

    .line 300
    :goto_12b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 301
    .line 302
    .line 303
    move-result v2

    .line 304
    if-eqz v2, :cond_14c

    .line 305
    .line 306
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v2

    .line 310
    check-cast v2, Ljava/util/Map$Entry;

    .line 311
    .line 312
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object v3

    .line 316
    check-cast v3, Lim/e;

    .line 317
    .line 318
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 319
    .line 320
    .line 321
    move-result-object v2

    .line 322
    check-cast v2, Ljava/lang/Number;

    .line 323
    .line 324
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 325
    .line 326
    .line 327
    move-result v2

    .line 328
    neg-int v2, v2

    .line 329
    invoke-static {v3, v2}, Lkm/b;->a(Lim/e;I)V

    .line 330
    .line 331
    .line 332
    goto :goto_12b

    .line 333
    :cond_14c
    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    .line 334
    .line 335
    .line 336
    :cond_14f
    sget-object v0, Lkm/b;->e:Ll30/o;

    .line 337
    .line 338
    invoke-virtual {v0}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    check-cast v0, Landroid/os/Handler;

    .line 343
    .line 344
    sget-object v1, Lkm/b;->f:La6/n0;

    .line 345
    .line 346
    const-wide/16 v2, 0x7d0

    .line 347
    .line 348
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 349
    .line 350
    .line 351
    return-void

    .line 352
    :pswitch_15f
    invoke-static {}, Lio/sentry/android/ndk/SentryNdk;->a()V

    .line 353
    .line 354
    .line 355
    return-void

    .line 356
    :pswitch_163
    invoke-static {}, Landroid/os/Process;->myTid()I

    .line 357
    .line 358
    .line 359
    move-result v0

    .line 360
    int-to-long v0, v0

    .line 361
    sput-wide v0, Lio/sentry/android/core/internal/util/e;->b:J

    .line 362
    .line 363
    return-void

    .line 364
    :pswitch_16b
    sget v0, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/AlarmManagerSchedulerBroadcastReceiver;->a:I

    .line 365
    .line 366
    return-void

    .line 367
    :pswitch_16e
    sget-object v0, Lff/h;->a:Ll30/o;

    .line 368
    .line 369
    sget-object v0, Lff/h;->b:Lim/c;

    .line 370
    .line 371
    if-nez v0, :cond_175

    .line 372
    .line 373
    goto :goto_186

    .line 374
    :cond_175
    invoke-static {v3}, Lff/h;->j(Z)Lff/i;

    .line 375
    .line 376
    .line 377
    move-result-object v1

    .line 378
    iget-object v2, v0, Lim/c;->i:Ljava/lang/Object;

    .line 379
    .line 380
    check-cast v2, Ljava/util/concurrent/locks/ReentrantLock;

    .line 381
    .line 382
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 383
    .line 384
    .line 385
    :try_start_180
    invoke-virtual {v0, v1}, Lim/c;->p(Lff/i;)Z
    :try_end_183
    .catchall {:try_start_180 .. :try_end_183} :catchall_187

    .line 386
    .line 387
    .line 388
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 389
    .line 390
    .line 391
    :goto_186
    return-void

    .line 392
    :catchall_187
    move-exception v0

    .line 393
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 394
    .line 395
    .line 396
    throw v0

    .line 397
    :pswitch_18c
    sget-object v0, Lff/h;->a:Ll30/o;

    .line 398
    .line 399
    sget-object v0, Lff/h;->b:Lim/c;

    .line 400
    .line 401
    if-nez v0, :cond_193

    .line 402
    .line 403
    goto :goto_1a4

    .line 404
    :cond_193
    invoke-static {v3}, Lff/h;->j(Z)Lff/i;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    iget-object v2, v0, Lim/c;->i:Ljava/lang/Object;

    .line 409
    .line 410
    check-cast v2, Ljava/util/concurrent/locks/ReentrantLock;

    .line 411
    .line 412
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 413
    .line 414
    .line 415
    :try_start_19e
    invoke-virtual {v0, v1}, Lim/c;->p(Lff/i;)Z
    :try_end_1a1
    .catchall {:try_start_19e .. :try_end_1a1} :catchall_1a5

    .line 416
    .line 417
    .line 418
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 419
    .line 420
    .line 421
    :goto_1a4
    return-void

    .line 422
    :catchall_1a5
    move-exception v0

    .line 423
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 424
    .line 425
    .line 426
    throw v0

    .line 427
    :pswitch_1aa
    return-void

    .line 428
    :pswitch_1ab
    :try_start_1ab
    sget-object v0, Lcom/margelo/nitro/nitrofetch/HybridNitroFetch;->a:Lcom/margelo/nitro/nitrofetch/r;

    .line 429
    .line 430
    invoke-virtual {v0}, Lcom/margelo/nitro/nitrofetch/r;->a()Lorg/chromium/net/CronetEngine;
    :try_end_1b0
    .catchall {:try_start_1ab .. :try_end_1b0} :catchall_1b0

    .line 431
    .line 432
    .line 433
    :catchall_1b0
    return-void

    .line 434
    :pswitch_1b1
    throw v2

    .line 435
    :pswitch_1b2
    sput-boolean v3, Lcom/discord/crash_reporting/s;->e:Z

    .line 436
    .line 437
    sget-object v0, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;

    .line 438
    .line 439
    if-eqz v0, :cond_1bb

    .line 440
    .line 441
    invoke-static {v0}, Lcom/discord/crash_reporting/s;->c(Lcom/discord/crash_reporting/x;)V

    .line 442
    .line 443
    .line 444
    :cond_1bb
    return-void

    .line 445
    :pswitch_1bc
    sget-object v0, Lcom/discord/crash_reporting/s;->b:Ljava/util/ArrayDeque;

    .line 446
    .line 447
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    .line 448
    .line 449
    .line 450
    sget-object v0, Lcom/discord/crash_reporting/s;->c:Ljava/util/ArrayDeque;

    .line 451
    .line 452
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    .line 453
    .line 454
    .line 455
    sput-boolean v3, Lcom/discord/crash_reporting/s;->e:Z

    .line 456
    .line 457
    sget-object v0, Lcom/discord/crash_reporting/s;->f:Ljava/util/concurrent/ScheduledFuture;

    .line 458
    .line 459
    if-eqz v0, :cond_1cf

    .line 460
    .line 461
    invoke-interface {v0, v3}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 462
    .line 463
    .line 464
    :cond_1cf
    sput-object v2, Lcom/discord/crash_reporting/s;->f:Ljava/util/concurrent/ScheduledFuture;

    .line 465
    .line 466
    sget-object v0, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;

    .line 467
    .line 468
    if-eqz v0, :cond_23d

    .line 469
    .line 470
    const-string v4, "TelemetryRingSqlite"

    .line 471
    .line 472
    sget-object v5, Ll30/a0;->a:Ll30/a0;

    .line 473
    .line 474
    iget-object v6, v0, Lcom/discord/crash_reporting/x;->c:Lcom/discord/crash_reporting/u;

    .line 475
    .line 476
    invoke-virtual {v6}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 477
    .line 478
    .line 479
    move-result-object v6

    .line 480
    :try_start_1df
    invoke-static {v6}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 481
    .line 482
    .line 483
    invoke-virtual {v6}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V
    :try_end_1e5
    .catchall {:try_start_1df .. :try_end_1e5} :catchall_20e

    .line 484
    .line 485
    .line 486
    :try_start_1e5
    const-string v7, "UPDATE telemetry_ring_slots SET seq=0, channel_mask=0, payload_json=NULL, payload_size=0"

    .line 487
    .line 488
    invoke-virtual {v6, v7}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 489
    .line 490
    .line 491
    iput v1, v0, Lcom/discord/crash_reporting/x;->f:I

    .line 492
    .line 493
    iput v3, v0, Lcom/discord/crash_reporting/x;->g:I

    .line 494
    .line 495
    iput v3, v0, Lcom/discord/crash_reporting/x;->h:I

    .line 496
    .line 497
    const-wide/16 v7, 0x0

    .line 498
    .line 499
    iput-wide v7, v0, Lcom/discord/crash_reporting/x;->i:J

    .line 500
    .line 501
    const-wide/16 v9, 0x1

    .line 502
    .line 503
    iput-wide v9, v0, Lcom/discord/crash_reporting/x;->j:J

    .line 504
    .line 505
    iget-object v1, v0, Lcom/discord/crash_reporting/x;->d:[J

    .line 506
    .line 507
    invoke-static {v1, v7, v8}, Lm30/k;->c0([JJ)V

    .line 508
    .line 509
    .line 510
    iget-object v1, v0, Lcom/discord/crash_reporting/x;->e:[I

    .line 511
    .line 512
    array-length v7, v1

    .line 513
    invoke-static {v1, v3, v7, v3}, Ljava/util/Arrays;->fill([IIII)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {v0, v6}, Lcom/discord/crash_reporting/x;->i(Landroid/database/sqlite/SQLiteDatabase;)V

    .line 517
    .line 518
    .line 519
    invoke-virtual {v6}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_209
    .catchall {:try_start_1e5 .. :try_end_209} :catchall_210

    .line 520
    .line 521
    .line 522
    :try_start_209
    invoke-virtual {v6}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 523
    .line 524
    .line 525
    move-object v1, v5

    .line 526
    goto :goto_219

    .line 527
    :catchall_20e
    move-exception v1

    .line 528
    goto :goto_215

    .line 529
    :catchall_210
    move-exception v1

    .line 530
    invoke-virtual {v6}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    .line 531
    .line 532
    .line 533
    throw v1
    :try_end_215
    .catchall {:try_start_209 .. :try_end_215} :catchall_20e

    .line 534
    :goto_215
    invoke-static {v1}, Landroid/support/v4/media/session/b;->q(Ljava/lang/Throwable;)Ll30/l;

    .line 535
    .line 536
    .line 537
    move-result-object v1

    .line 538
    :goto_219
    invoke-static {v1}, Ll30/m;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 539
    .line 540
    .line 541
    move-result-object v1

    .line 542
    if-eqz v1, :cond_23d

    .line 543
    .line 544
    sget-object v2, Lnf/a;->a:Lnf/a;

    .line 545
    .line 546
    const-string v2, "TelemetryRing clear failed; reloading in-memory state"

    .line 547
    .line 548
    invoke-static {v4, v2, v1}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 549
    .line 550
    .line 551
    :try_start_226
    invoke-virtual {v0}, Lcom/discord/crash_reporting/x;->g()V
    :try_end_229
    .catchall {:try_start_226 .. :try_end_229} :catchall_22a

    .line 552
    .line 553
    .line 554
    goto :goto_22f

    .line 555
    :catchall_22a
    move-exception v0

    .line 556
    invoke-static {v0}, Landroid/support/v4/media/session/b;->q(Ljava/lang/Throwable;)Ll30/l;

    .line 557
    .line 558
    .line 559
    move-result-object v5

    .line 560
    :goto_22f
    invoke-static {v5}, Ll30/m;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 561
    .line 562
    .line 563
    move-result-object v0

    .line 564
    if-eqz v0, :cond_23c

    .line 565
    .line 566
    sget-object v2, Lnf/a;->a:Lnf/a;

    .line 567
    .line 568
    const-string v2, "TelemetryRing state reload failed after clear error"

    .line 569
    .line 570
    invoke-static {v4, v2, v0}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 571
    .line 572
    .line 573
    :cond_23c
    throw v1

    .line 574
    :cond_23d
    sget-object v0, Lnf/a;->a:Lnf/a;

    .line 575
    .line 576
    const-string v0, "TelemetryRing"

    .line 577
    .line 578
    const-string v1, "TelemetryRing cleared"

    .line 579
    .line 580
    invoke-static {v0, v1, v2}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 581
    .line 582
    .line 583
    return-void

    .line 584
    :pswitch_247
    invoke-static {}, Lcom/appsflyer/internal/AFj1rSDK;->d()V

    .line 585
    .line 586
    .line 587
    return-void

    .line 588
    :pswitch_24b
    throw v2

    .line 589
    :pswitch_24c
    return-void

    .line 590
    nop

    .line 591
    :pswitch_data_24e
    .packed-switch 0x0
        :pswitch_24c
        :pswitch_24c
        :pswitch_24b
        :pswitch_247
        :pswitch_1bc
        :pswitch_1b2
        :pswitch_1b1
        :pswitch_1ab
        :pswitch_1aa
        :pswitch_18c
        :pswitch_16e
        :pswitch_16b
        :pswitch_163
        :pswitch_15f
        :pswitch_c4
        :pswitch_21
        :pswitch_18
        :pswitch_14
        :pswitch_10
        :pswitch_c
        :pswitch_b
    .end packed-switch
.end method
