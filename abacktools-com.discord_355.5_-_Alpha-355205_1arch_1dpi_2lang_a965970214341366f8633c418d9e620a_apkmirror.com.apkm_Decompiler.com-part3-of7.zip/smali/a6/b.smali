###### Class a6.b (a6.b)
.class public final La6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public e:Z

.field public final synthetic i:Landroid/view/ViewGroup;


# direct methods
.method public synthetic constructor <init>(Landroid/view/ViewGroup;I)V
    .registers 3

    .line 1
    iput p2, p0, La6/b;->d:I

    iput-object p1, p0, La6/b;->i:Landroid/view/ViewGroup;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    iget v0, p0, La6/b;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, La6/b;->i:Landroid/view/ViewGroup;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_2a

    .line 7
    .line 8
    .line 9
    iput-boolean v1, p0, La6/b;->e:Z

    .line 10
    .line 11
    check-cast v2, Lcom/google/android/exoplayer2/ui/AspectRatioFrameLayout;

    .line 12
    .line 13
    sget v0, Lcom/google/android/exoplayer2/ui/AspectRatioFrameLayout;->v:I

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_12
    check-cast v2, Lmz/j;

    .line 20
    .line 21
    iget-boolean v0, p0, La6/b;->e:Z

    .line 22
    .line 23
    invoke-virtual {v2, v0}, Lmz/j;->a(Z)V

    .line 24
    .line 25
    .line 26
    iget-wide v0, v2, Lmz/j;->T:J

    .line 27
    .line 28
    invoke-virtual {v2, p0, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :pswitch_1f
    iput-boolean v1, p0, La6/b;->e:Z

    .line 33
    .line 34
    check-cast v2, Landroidx/media3/ui/AspectRatioFrameLayout;

    .line 35
    .line 36
    sget v0, Landroidx/media3/ui/AspectRatioFrameLayout;->v:I

    .line 37
    .line 38
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    nop

    .line 43
    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_1f
        :pswitch_12
    .end packed-switch
.end method
