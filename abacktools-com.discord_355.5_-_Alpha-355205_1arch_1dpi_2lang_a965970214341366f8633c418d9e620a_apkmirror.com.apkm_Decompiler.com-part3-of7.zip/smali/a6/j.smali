###### Class a6.j (a6.j)
.class public final synthetic La6/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/j;->d:I

    iput-object p2, p0, La6/j;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .registers 20

    .line 1
    iget v0, p0, La6/j;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x2

    .line 6
    const/4 v4, 0x1

    .line 7
    iget-object v5, p0, La6/j;->e:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_1ca

    .line 10
    .line 11
    .line 12
    check-cast v5, Lcom/google/android/material/carousel/CarouselLayoutManager;

    .line 13
    .line 14
    sub-int p2, p4, p2

    .line 15
    .line 16
    sub-int v0, p8, p6

    .line 17
    .line 18
    if-ne p2, v0, :cond_19

    .line 19
    .line 20
    sub-int p2, p5, p3

    .line 21
    .line 22
    sub-int p3, p9, p7

    .line 23
    .line 24
    if-eq p2, p3, :cond_23

    .line 25
    .line 26
    :cond_19
    new-instance p2, Lw80/q0;

    .line 27
    .line 28
    const/16 p3, 0xf

    .line 29
    .line 30
    invoke-direct {p2, p3, v5}, Lw80/q0;-><init>(ILjava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 34
    .line 35
    .line 36
    :cond_23
    return-void

    .line 37
    :pswitch_24
    check-cast v5, Lxk/b;

    .line 38
    .line 39
    invoke-virtual {v5}, Lj00/o;->getEngine()Lj00/m;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 44
    .line 45
    .line 46
    move-result p3

    .line 47
    int-to-float p3, p3

    .line 48
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    int-to-float p1, p1

    .line 53
    invoke-virtual {p2, p3, p1, v4}, Lj00/m;->d(FFZ)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :pswitch_38
    check-cast v5, Lcom/discord/chat/presentation/message/view/voicemessages/AudioPlayerView;

    .line 58
    .line 59
    invoke-static {v5}, Lcom/discord/chat/presentation/message/view/voicemessages/AudioPlayerView;->c(Lcom/discord/chat/presentation/message/view/voicemessages/AudioPlayerView;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :pswitch_3e
    check-cast v5, Lcom/discord/channel_spine/ChannelSpineView;

    .line 64
    .line 65
    sget p1, Lcom/discord/channel_spine/ChannelSpineView;->K:I

    .line 66
    .line 67
    sub-int p1, p5, p3

    .line 68
    .line 69
    invoke-static {p1}, Lox/b;->n(I)F

    .line 70
    .line 71
    .line 72
    move-result p1

    .line 73
    invoke-virtual {v5, p1}, Lcom/discord/channel_spine/ChannelSpineView;->setRowHeight(F)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_4c
    check-cast v5, Lmb/g;

    .line 78
    .line 79
    iget-object p1, v5, Lmb/g;->P:Lc70/n0;

    .line 80
    .line 81
    invoke-virtual {p1}, Lc70/n0;->getValue()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object p2

    .line 85
    check-cast p2, Ljava/lang/Number;

    .line 86
    .line 87
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 88
    .line 89
    .line 90
    move-result p2

    .line 91
    add-int/2addr p2, v4

    .line 92
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 93
    .line 94
    .line 95
    move-result-object p2

    .line 96
    invoke-virtual {p1, v2, p2}, Lc70/n0;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :pswitch_63
    check-cast v5, Lvv/a;

    .line 101
    .line 102
    iget-object p1, v5, Lhw/e;->T:Landroid/view/View;

    .line 103
    .line 104
    iget-object v0, v5, Lhw/e;->V:Landroid/widget/ImageView;

    .line 105
    .line 106
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 107
    .line 108
    .line 109
    move-result v6

    .line 110
    if-nez v6, :cond_81

    .line 111
    .line 112
    iget-object v6, v5, Lhw/e;->C0:Lsv/a;

    .line 113
    .line 114
    if-eqz v6, :cond_81

    .line 115
    .line 116
    new-instance v7, Landroid/graphics/Rect;

    .line 117
    .line 118
    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0, v7}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v6, v7}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v6, v0, v2}, Lsv/a;->j(Landroid/view/View;Landroid/widget/FrameLayout;)V

    .line 128
    .line 129
    .line 130
    :cond_81
    iget-object v0, v5, Lhw/e;->S:Landroid/widget/LinearLayout;

    .line 131
    .line 132
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 137
    .line 138
    sub-int p2, p4, p2

    .line 139
    .line 140
    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 141
    .line 142
    add-int/2addr p2, v2

    .line 143
    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 144
    .line 145
    add-int/2addr p2, v2

    .line 146
    sub-int p3, p5, p3

    .line 147
    .line 148
    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 149
    .line 150
    add-int/2addr p3, v2

    .line 151
    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    .line 152
    .line 153
    add-int/2addr p3, v0

    .line 154
    iget v0, v5, Lhw/e;->D0:I

    .line 155
    .line 156
    if-ne v0, v4, :cond_d6

    .line 157
    .line 158
    iget v0, v5, Lhw/e;->x0:I

    .line 159
    .line 160
    const/4 v2, -0x2

    .line 161
    if-ne v0, v2, :cond_d6

    .line 162
    .line 163
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 168
    .line 169
    iget v6, v5, Lhw/e;->x0:I

    .line 170
    .line 171
    if-ne v6, v2, :cond_c7

    .line 172
    .line 173
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    if-eq v2, p2, :cond_c7

    .line 178
    .line 179
    iget v1, v5, Lhw/e;->v0:I

    .line 180
    .line 181
    invoke-virtual {v5}, Landroid/view/View;->getMeasuredWidth()I

    .line 182
    .line 183
    .line 184
    move-result v2

    .line 185
    iget v5, v5, Lhw/e;->A0:I

    .line 186
    .line 187
    mul-int/2addr v5, v3

    .line 188
    sub-int/2addr v2, v5

    .line 189
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 190
    .line 191
    .line 192
    move-result v1

    .line 193
    invoke-static {p2, v1}, Ljava/lang/Math;->max(II)I

    .line 194
    .line 195
    .line 196
    move-result p2

    .line 197
    iput p2, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    .line 198
    .line 199
    move v1, v4

    .line 200
    :cond_c7
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 201
    .line 202
    .line 203
    move-result p2

    .line 204
    if-ge p2, p3, :cond_d0

    .line 205
    .line 206
    iput p3, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    .line 207
    .line 208
    goto :goto_d1

    .line 209
    :cond_d0
    move v4, v1

    .line 210
    :goto_d1
    if-eqz v4, :cond_d6

    .line 211
    .line 212
    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 213
    .line 214
    .line 215
    :cond_d6
    return-void

    .line 216
    :pswitch_d7
    check-cast v5, Lf20/h;

    .line 217
    .line 218
    invoke-virtual {v5}, Lf20/h;->B()V

    .line 219
    .line 220
    .line 221
    return-void

    .line 222
    :pswitch_dd
    check-cast v5, La6/b0;

    .line 223
    .line 224
    iget-object p3, v5, La6/b0;->a:La6/w;

    .line 225
    .line 226
    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    .line 227
    .line 228
    .line 229
    move-result v0

    .line 230
    invoke-virtual {p3}, Landroid/view/View;->getPaddingLeft()I

    .line 231
    .line 232
    .line 233
    move-result v2

    .line 234
    sub-int/2addr v0, v2

    .line 235
    invoke-virtual {p3}, Landroid/view/View;->getPaddingRight()I

    .line 236
    .line 237
    .line 238
    move-result v2

    .line 239
    sub-int/2addr v0, v2

    .line 240
    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    .line 241
    .line 242
    .line 243
    move-result v2

    .line 244
    invoke-virtual {p3}, Landroid/view/View;->getPaddingBottom()I

    .line 245
    .line 246
    .line 247
    move-result v6

    .line 248
    sub-int/2addr v2, v6

    .line 249
    invoke-virtual {p3}, Landroid/view/View;->getPaddingTop()I

    .line 250
    .line 251
    .line 252
    move-result p3

    .line 253
    sub-int/2addr v2, p3

    .line 254
    iget-object p3, v5, La6/b0;->d:Landroid/view/ViewGroup;

    .line 255
    .line 256
    invoke-static {p3}, La6/b0;->c(Landroid/view/View;)I

    .line 257
    .line 258
    .line 259
    move-result v6

    .line 260
    if-eqz p3, :cond_10f

    .line 261
    .line 262
    invoke-virtual {p3}, Landroid/view/View;->getPaddingLeft()I

    .line 263
    .line 264
    .line 265
    move-result v7

    .line 266
    invoke-virtual {p3}, Landroid/view/View;->getPaddingRight()I

    .line 267
    .line 268
    .line 269
    move-result v8

    .line 270
    add-int/2addr v8, v7

    .line 271
    goto :goto_110

    .line 272
    :cond_10f
    move v8, v1

    .line 273
    :goto_110
    sub-int/2addr v6, v8

    .line 274
    if-nez p3, :cond_115

    .line 275
    .line 276
    move v7, v1

    .line 277
    goto :goto_129

    .line 278
    :cond_115
    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    .line 279
    .line 280
    .line 281
    move-result v7

    .line 282
    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 283
    .line 284
    .line 285
    move-result-object v8

    .line 286
    instance-of v9, v8, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 287
    .line 288
    if-eqz v9, :cond_129

    .line 289
    .line 290
    check-cast v8, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 291
    .line 292
    iget v9, v8, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 293
    .line 294
    iget v8, v8, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 295
    .line 296
    add-int/2addr v9, v8

    .line 297
    add-int/2addr v7, v9

    .line 298
    :cond_129
    :goto_129
    if-eqz p3, :cond_135

    .line 299
    .line 300
    invoke-virtual {p3}, Landroid/view/View;->getPaddingTop()I

    .line 301
    .line 302
    .line 303
    move-result v8

    .line 304
    invoke-virtual {p3}, Landroid/view/View;->getPaddingBottom()I

    .line 305
    .line 306
    .line 307
    move-result p3

    .line 308
    add-int/2addr p3, v8

    .line 309
    goto :goto_136

    .line 310
    :cond_135
    move p3, v1

    .line 311
    :goto_136
    sub-int/2addr v7, p3

    .line 312
    iget-object p3, v5, La6/b0;->j:Landroid/view/ViewGroup;

    .line 313
    .line 314
    invoke-static {p3}, La6/b0;->c(Landroid/view/View;)I

    .line 315
    .line 316
    .line 317
    move-result p3

    .line 318
    iget-object v8, v5, La6/b0;->l:Landroid/view/View;

    .line 319
    .line 320
    invoke-static {v8}, La6/b0;->c(Landroid/view/View;)I

    .line 321
    .line 322
    .line 323
    move-result v8

    .line 324
    add-int/2addr v8, p3

    .line 325
    invoke-static {v6, v8}, Ljava/lang/Math;->max(II)I

    .line 326
    .line 327
    .line 328
    move-result p3

    .line 329
    iget-object v6, v5, La6/b0;->e:Landroid/view/ViewGroup;

    .line 330
    .line 331
    if-nez v6, :cond_14e

    .line 332
    .line 333
    move v8, v1

    .line 334
    goto :goto_162

    .line 335
    :cond_14e
    invoke-virtual {v6}, Landroid/view/View;->getHeight()I

    .line 336
    .line 337
    .line 338
    move-result v8

    .line 339
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 340
    .line 341
    .line 342
    move-result-object v6

    .line 343
    instance-of v9, v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 344
    .line 345
    if-eqz v9, :cond_162

    .line 346
    .line 347
    check-cast v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 348
    .line 349
    iget v9, v6, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 350
    .line 351
    iget v6, v6, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 352
    .line 353
    add-int/2addr v9, v6

    .line 354
    add-int/2addr v8, v9

    .line 355
    :cond_162
    :goto_162
    mul-int/2addr v8, v3

    .line 356
    add-int/2addr v8, v7

    .line 357
    if-le v0, p3, :cond_16b

    .line 358
    .line 359
    if-gt v2, v8, :cond_169

    .line 360
    .line 361
    goto :goto_16b

    .line 362
    :cond_169
    move p3, v1

    .line 363
    goto :goto_16c

    .line 364
    :cond_16b
    :goto_16b
    move p3, v4

    .line 365
    :goto_16c
    iget-boolean v0, v5, La6/b0;->B:Z

    .line 366
    .line 367
    if-eq v0, p3, :cond_17a

    .line 368
    .line 369
    iput-boolean p3, v5, La6/b0;->B:Z

    .line 370
    .line 371
    new-instance p3, La6/x;

    .line 372
    .line 373
    invoke-direct {p3, v5, v4}, La6/x;-><init>(La6/b0;I)V

    .line 374
    .line 375
    .line 376
    invoke-virtual {p1, p3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 377
    .line 378
    .line 379
    :cond_17a
    sub-int p2, p4, p2

    .line 380
    .line 381
    sub-int p3, p8, p6

    .line 382
    .line 383
    if-eq p2, p3, :cond_181

    .line 384
    .line 385
    move v1, v4

    .line 386
    :cond_181
    iget-boolean p2, v5, La6/b0;->B:Z

    .line 387
    .line 388
    if-nez p2, :cond_18f

    .line 389
    .line 390
    if-eqz v1, :cond_18f

    .line 391
    .line 392
    new-instance p2, La6/x;

    .line 393
    .line 394
    invoke-direct {p2, v5, v3}, La6/x;-><init>(La6/b0;I)V

    .line 395
    .line 396
    .line 397
    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 398
    .line 399
    .line 400
    :cond_18f
    return-void

    .line 401
    :pswitch_190
    check-cast v5, La6/w;

    .line 402
    .line 403
    iget v0, v5, La6/w;->U:I

    .line 404
    .line 405
    iget-object v1, v5, La6/w;->T:Landroid/widget/PopupWindow;

    .line 406
    .line 407
    sub-int p2, p4, p2

    .line 408
    .line 409
    sub-int p3, p5, p3

    .line 410
    .line 411
    sub-int v2, p8, p6

    .line 412
    .line 413
    sub-int v3, p9, p7

    .line 414
    .line 415
    if-ne p2, v2, :cond_1a2

    .line 416
    .line 417
    if-eq p3, v3, :cond_1c8

    .line 418
    .line 419
    :cond_1a2
    invoke-virtual {v1}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 420
    .line 421
    .line 422
    move-result p2

    .line 423
    if-eqz p2, :cond_1c8

    .line 424
    .line 425
    invoke-virtual {v5}, La6/w;->u()V

    .line 426
    .line 427
    .line 428
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    .line 429
    .line 430
    .line 431
    move-result p2

    .line 432
    invoke-virtual {v1}, Landroid/widget/PopupWindow;->getWidth()I

    .line 433
    .line 434
    .line 435
    move-result p3

    .line 436
    sub-int/2addr p2, p3

    .line 437
    sub-int/2addr p2, v0

    .line 438
    invoke-virtual {v1}, Landroid/widget/PopupWindow;->getHeight()I

    .line 439
    .line 440
    .line 441
    move-result p3

    .line 442
    neg-int p3, p3

    .line 443
    sub-int/2addr p3, v0

    .line 444
    const/4 v0, -0x1

    .line 445
    const/4 v2, -0x1

    .line 446
    move p4, p2

    .line 447
    move p5, p3

    .line 448
    move/from16 p6, v0

    .line 449
    .line 450
    move-object p2, v1

    .line 451
    move/from16 p7, v2

    .line 452
    .line 453
    move-object p3, p1

    .line 454
    invoke-virtual/range {p2 .. p7}, Landroid/widget/PopupWindow;->update(Landroid/view/View;IIII)V

    .line 455
    .line 456
    .line 457
    :cond_1c8
    return-void

    .line 458
    nop

    .line 459
    :pswitch_data_1ca
    .packed-switch 0x0
        :pswitch_190
        :pswitch_dd
        :pswitch_d7
        :pswitch_63
        :pswitch_4c
        :pswitch_3e
        :pswitch_38
        :pswitch_24
    .end packed-switch
.end method
