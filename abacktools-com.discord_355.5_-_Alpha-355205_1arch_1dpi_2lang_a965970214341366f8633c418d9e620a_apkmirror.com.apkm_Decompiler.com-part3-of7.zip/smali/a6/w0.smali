###### Class a6.w0 (a6.w0)
.class public interface abstract La6/w0;
.super Ljava/lang/Object;
.source "SourceFile"
