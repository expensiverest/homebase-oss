###### Class a6.c (a6.c)
.class public abstract La6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/google/android/gms/internal/fido/f8;

.field public static final b:Lcom/google/android/gms/internal/fido/f8;

.field public static final c:Lgx/l;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const-string v0, "\n"

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/android/gms/internal/fido/f8;->L(Ljava/lang/String;)Lcom/google/android/gms/internal/fido/f8;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sput-object v1, La6/c;->a:Lcom/google/android/gms/internal/fido/f8;

    .line 8
    .line 9
    const-string v1, "\r\n"

    .line 10
    .line 11
    invoke-static {v1}, Lcom/google/android/gms/internal/fido/f8;->L(Ljava/lang/String;)Lcom/google/android/gms/internal/fido/f8;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sput-object v1, La6/c;->b:Lcom/google/android/gms/internal/fido/f8;

    .line 16
    .line 17
    new-instance v1, Lgx/l;

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    invoke-direct {v1, v0, v2}, Lgx/l;-><init>(Ljava/lang/String;I)V

    .line 21
    .line 22
    .line 23
    sput-object v1, La6/c;->c:Lgx/l;

    .line 24
    .line 25
    return-void
.end method
