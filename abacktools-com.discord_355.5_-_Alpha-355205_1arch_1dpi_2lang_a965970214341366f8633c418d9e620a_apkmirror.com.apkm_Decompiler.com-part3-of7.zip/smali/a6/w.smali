###### Class a6.w (a6.w)
.class public final La6/w;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# static fields
.field public static final j1:[F


# instance fields
.field public final A0:Landroid/graphics/drawable/Drawable;

.field public final B0:Ljava/lang/String;

.field public final C0:Ljava/lang/String;

.field public final D0:Ljava/lang/String;

.field public final E0:Landroid/graphics/drawable/Drawable;

.field public final F0:Landroid/graphics/drawable/Drawable;

.field public final G0:F

.field public final H0:F

.field public final I0:Ljava/lang/String;

.field public final J:Ljava/lang/Class;

.field public final J0:Ljava/lang/String;

.field public final K:Ljava/lang/reflect/Method;

.field public final K0:Landroid/graphics/drawable/Drawable;

.field public final L:Ljava/lang/reflect/Method;

.field public final L0:Landroid/graphics/drawable/Drawable;

.field public final M:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final M0:Ljava/lang/String;

.field public final N:Landroidx/recyclerview/widget/RecyclerView;

.field public final N0:Ljava/lang/String;

.field public final O:La6/r;

.field public final O0:Landroid/graphics/drawable/Drawable;

.field public final P:La6/o;

.field public final P0:Landroid/graphics/drawable/Drawable;

.field public final Q:La6/k;

.field public final Q0:Ljava/lang/String;

.field public final R:La6/k;

.field public final R0:Ljava/lang/String;

.field public final S:La8/d;

.field public S0:Lk3/e1;

.field public final T:Landroid/widget/PopupWindow;

.field public T0:Z

.field public final U:I

.field public U0:Z

.field public final V:Landroid/widget/ImageView;

.field public V0:Z

.field public final W:Landroid/widget/ImageView;

.field public W0:Z

.field public X0:Z

.field public Y0:Z

.field public Z0:I

.field public final a0:Landroid/widget/ImageView;

.field public a1:Z

.field public final b0:Landroid/view/View;

.field public b1:I

.field public final c0:Landroid/view/View;

.field public c1:I

.field public final d:La6/b0;

.field public final d0:Landroid/widget/TextView;

.field public d1:[J

.field public final e:Landroid/content/res/Resources;

.field public final e0:Landroid/widget/TextView;

.field public e1:[Z

.field public final f0:Landroid/widget/ImageView;

.field public final f1:[J

.field public final g0:Landroid/widget/ImageView;

.field public final g1:[Z

.field public final h0:Landroid/widget/ImageView;

.field public h1:J

.field public final i:Landroid/os/Handler;

.field public final i0:Landroid/widget/ImageView;

.field public i1:Z

.field public final j0:Landroid/widget/ImageView;

.field public final k0:Landroid/widget/ImageView;

.field public final l0:Landroid/view/View;

.field public final m0:Landroid/view/View;

.field public final n0:Landroid/view/View;

.field public final o0:Landroid/widget/TextView;

.field public final p0:Landroid/widget/TextView;

.field public final q0:La6/w0;

.field public final r0:Ljava/lang/StringBuilder;

.field public final s0:Ljava/util/Formatter;

.field public final t0:Lk3/k1;

.field public final u0:Lk3/m1;

.field public final v:La6/l;

.field public final v0:La6/f;

.field public final w:Ljava/lang/Class;

.field public final w0:Landroid/graphics/drawable/Drawable;

.field public final x:Ljava/lang/reflect/Method;

.field public final x0:Landroid/graphics/drawable/Drawable;

.field public final y:Ljava/lang/reflect/Method;

.field public final y0:Landroid/graphics/drawable/Drawable;

.field public final z0:Landroid/graphics/drawable/Drawable;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const-string v0, "media3.ui"

    .line 2
    .line 3
    invoke-static {v0}, Lk3/p0;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x7

    .line 7
    new-array v0, v0, [F

    .line 8
    .line 9
    fill-array-data v0, :array_e

    .line 10
    .line 11
    .line 12
    sput-object v0, La6/w;->j1:[F

    .line 13
    .line 14
    return-void

    .line 15
    :array_e
    .array-data 4
        0x3e800000    # 0.25f
        0x3f000000    # 0.5f
        0x3f400000    # 0.75f
        0x3f800000    # 1.0f
        0x3fa00000    # 1.25f
        0x3fc00000    # 1.5f
        0x40000000    # 2.0f
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 48

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v0, p2

    .line 6
    .line 7
    const-string v3, "isScrubbingModeEnabled"

    .line 8
    .line 9
    sget-object v4, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 10
    .line 11
    const-string v5, "setScrubbingModeEnabled"

    .line 12
    .line 13
    const/4 v9, 0x0

    .line 14
    const/4 v10, 0x0

    .line 15
    invoke-direct {v1, v2, v9, v10}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 16
    .line 17
    .line 18
    const/4 v11, 0x1

    .line 19
    iput-boolean v11, v1, La6/w;->W0:Z

    .line 20
    .line 21
    const/16 v6, 0x1388

    .line 22
    .line 23
    iput v6, v1, La6/w;->Z0:I

    .line 24
    .line 25
    iput v10, v1, La6/w;->c1:I

    .line 26
    .line 27
    const/16 v6, 0xc8

    .line 28
    .line 29
    iput v6, v1, La6/w;->b1:I

    .line 30
    .line 31
    const v7, 0x7f0d0054

    .line 32
    .line 33
    .line 34
    const v8, 0x7f0802ee

    .line 35
    .line 36
    .line 37
    const v12, 0x7f0802ed

    .line 38
    .line 39
    .line 40
    const v13, 0x7f0802ea

    .line 41
    .line 42
    .line 43
    const v14, 0x7f0802f7

    .line 44
    .line 45
    .line 46
    const v15, 0x7f0802ef

    .line 47
    .line 48
    .line 49
    const v9, 0x7f0802f8

    .line 50
    .line 51
    .line 52
    if-eqz v0, :cond_16b

    .line 53
    .line 54
    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    sget-object v11, La6/p0;->c:[I

    .line 59
    .line 60
    invoke-virtual {v6, v0, v11, v10, v10}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    const/4 v11, 0x6

    .line 65
    :try_start_40
    invoke-virtual {v6, v11, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 66
    .line 67
    .line 68
    move-result v7

    .line 69
    const/16 v11, 0xc

    .line 70
    .line 71
    invoke-virtual {v6, v11, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 72
    .line 73
    .line 74
    move-result v8

    .line 75
    const/16 v11, 0xb

    .line 76
    .line 77
    invoke-virtual {v6, v11, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 78
    .line 79
    .line 80
    move-result v12

    .line 81
    const/16 v11, 0xa

    .line 82
    .line 83
    invoke-virtual {v6, v11, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 84
    .line 85
    .line 86
    move-result v13

    .line 87
    const/4 v11, 0x7

    .line 88
    invoke-virtual {v6, v11, v14}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 89
    .line 90
    .line 91
    move-result v14

    .line 92
    const/16 v11, 0xf

    .line 93
    .line 94
    invoke-virtual {v6, v11, v15}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 95
    .line 96
    .line 97
    move-result v15

    .line 98
    const/16 v11, 0x14

    .line 99
    .line 100
    invoke-virtual {v6, v11, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 101
    .line 102
    .line 103
    move-result v9

    .line 104
    const/16 v11, 0x9

    .line 105
    .line 106
    const v10, 0x7f0802e9

    .line 107
    .line 108
    .line 109
    invoke-virtual {v6, v11, v10}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 110
    .line 111
    .line 112
    move-result v11

    .line 113
    move-object/from16 v17, v4

    .line 114
    .line 115
    const v4, 0x7f0802e8

    .line 116
    .line 117
    .line 118
    const/16 v10, 0x8

    .line 119
    .line 120
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    const/16 v10, 0x11

    .line 125
    .line 126
    move/from16 v26, v4

    .line 127
    .line 128
    const v4, 0x7f0802f1

    .line 129
    .line 130
    .line 131
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 132
    .line 133
    .line 134
    move-result v4

    .line 135
    const/16 v10, 0x12

    .line 136
    .line 137
    move/from16 v18, v4

    .line 138
    .line 139
    const v4, 0x7f0802f2

    .line 140
    .line 141
    .line 142
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    const/16 v10, 0x10

    .line 147
    .line 148
    move/from16 v19, v4

    .line 149
    .line 150
    const v4, 0x7f0802f0

    .line 151
    .line 152
    .line 153
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 154
    .line 155
    .line 156
    move-result v4

    .line 157
    const/16 v10, 0x23

    .line 158
    .line 159
    move/from16 v20, v4

    .line 160
    .line 161
    const v4, 0x7f0802f6

    .line 162
    .line 163
    .line 164
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 165
    .line 166
    .line 167
    move-result v4

    .line 168
    const/16 v10, 0x22

    .line 169
    .line 170
    move/from16 v21, v4

    .line 171
    .line 172
    const v4, 0x7f0802f5

    .line 173
    .line 174
    .line 175
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 176
    .line 177
    .line 178
    move-result v4

    .line 179
    const/16 v10, 0x25

    .line 180
    .line 181
    move/from16 v22, v4

    .line 182
    .line 183
    const v4, 0x7f0802fb

    .line 184
    .line 185
    .line 186
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 187
    .line 188
    .line 189
    move-result v4

    .line 190
    const/16 v10, 0x24

    .line 191
    .line 192
    move/from16 v23, v4

    .line 193
    .line 194
    const v4, 0x7f0802fa

    .line 195
    .line 196
    .line 197
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 198
    .line 199
    .line 200
    move-result v4

    .line 201
    const/16 v10, 0x2a

    .line 202
    .line 203
    move/from16 v24, v4

    .line 204
    .line 205
    const v4, 0x7f0802fc

    .line 206
    .line 207
    .line 208
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 209
    .line 210
    .line 211
    move-result v4

    .line 212
    iget v10, v1, La6/w;->Z0:I

    .line 213
    .line 214
    move/from16 v25, v4

    .line 215
    .line 216
    const/16 v4, 0x20

    .line 217
    .line 218
    invoke-virtual {v6, v4, v10}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 219
    .line 220
    .line 221
    move-result v4

    .line 222
    iput v4, v1, La6/w;->Z0:I

    .line 223
    .line 224
    iget v4, v1, La6/w;->c1:I

    .line 225
    .line 226
    const/16 v10, 0x13

    .line 227
    .line 228
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 229
    .line 230
    .line 231
    move-result v4

    .line 232
    iput v4, v1, La6/w;->c1:I

    .line 233
    .line 234
    const/16 v4, 0x1d

    .line 235
    .line 236
    const/4 v10, 0x1

    .line 237
    invoke-virtual {v6, v4, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 238
    .line 239
    .line 240
    move-result v4

    .line 241
    move/from16 v27, v4

    .line 242
    .line 243
    const/16 v4, 0x1a

    .line 244
    .line 245
    invoke-virtual {v6, v4, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 246
    .line 247
    .line 248
    move-result v4

    .line 249
    move/from16 v28, v4

    .line 250
    .line 251
    const/16 v4, 0x1c

    .line 252
    .line 253
    invoke-virtual {v6, v4, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 254
    .line 255
    .line 256
    move-result v4

    .line 257
    move/from16 v29, v4

    .line 258
    .line 259
    const/16 v4, 0x1b

    .line 260
    .line 261
    invoke-virtual {v6, v4, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 262
    .line 263
    .line 264
    move-result v4

    .line 265
    const/16 v10, 0x1e

    .line 266
    .line 267
    move/from16 v30, v4

    .line 268
    .line 269
    const/4 v4, 0x0

    .line 270
    invoke-virtual {v6, v10, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 271
    .line 272
    .line 273
    move-result v10

    .line 274
    move/from16 v31, v7

    .line 275
    .line 276
    const/16 v7, 0x1f

    .line 277
    .line 278
    invoke-virtual {v6, v7, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 279
    .line 280
    .line 281
    move-result v7

    .line 282
    move/from16 v32, v7

    .line 283
    .line 284
    const/16 v7, 0x21

    .line 285
    .line 286
    invoke-virtual {v6, v7, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 287
    .line 288
    .line 289
    move-result v7

    .line 290
    move/from16 v33, v7

    .line 291
    .line 292
    const/16 v7, 0x27

    .line 293
    .line 294
    invoke-virtual {v6, v7, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 295
    .line 296
    .line 297
    move-result v7

    .line 298
    iput-boolean v7, v1, La6/w;->a1:Z

    .line 299
    .line 300
    iget v4, v1, La6/w;->b1:I

    .line 301
    .line 302
    const/16 v7, 0x26

    .line 303
    .line 304
    invoke-virtual {v6, v7, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 305
    .line 306
    .line 307
    move-result v4

    .line 308
    invoke-virtual {v1, v4}, La6/w;->setTimeBarMinUpdateInterval(I)V

    .line 309
    .line 310
    .line 311
    const/4 v4, 0x2

    .line 312
    const/4 v7, 0x1

    .line 313
    invoke-virtual {v6, v4, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 314
    .line 315
    .line 316
    move-result v4
    :try_end_13c
    .catchall {:try_start_40 .. :try_end_13c} :catchall_166

    .line 317
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    .line 318
    .line 319
    .line 320
    move/from16 v41, v4

    .line 321
    .line 322
    move/from16 v38, v11

    .line 323
    .line 324
    move/from16 v39, v12

    .line 325
    .line 326
    move v4, v13

    .line 327
    move/from16 v40, v14

    .line 328
    .line 329
    move/from16 v14, v18

    .line 330
    .line 331
    move/from16 v12, v25

    .line 332
    .line 333
    move/from16 v13, v26

    .line 334
    .line 335
    move/from16 v34, v27

    .line 336
    .line 337
    move/from16 v35, v28

    .line 338
    .line 339
    move/from16 v36, v29

    .line 340
    .line 341
    move/from16 v37, v30

    .line 342
    .line 343
    move/from16 v7, v31

    .line 344
    .line 345
    move/from16 v11, v33

    .line 346
    .line 347
    move/from16 v18, v9

    .line 348
    .line 349
    move/from16 v9, v32

    .line 350
    .line 351
    :goto_15e
    move v6, v15

    .line 352
    move/from16 v15, v19

    .line 353
    .line 354
    move/from16 v19, v20

    .line 355
    .line 356
    move/from16 v20, v8

    .line 357
    .line 358
    goto :goto_1a6

    .line 359
    :catchall_166
    move-exception v0

    .line 360
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    .line 361
    .line 362
    .line 363
    throw v0

    .line 364
    :cond_16b
    move-object/from16 v17, v4

    .line 365
    .line 366
    const v4, 0x7f0802fc

    .line 367
    .line 368
    .line 369
    const v6, 0x7f0802e8

    .line 370
    .line 371
    .line 372
    const v10, 0x7f0802e9

    .line 373
    .line 374
    .line 375
    const v18, 0x7f0802f1

    .line 376
    .line 377
    .line 378
    const v19, 0x7f0802f2

    .line 379
    .line 380
    .line 381
    const v20, 0x7f0802f0

    .line 382
    .line 383
    .line 384
    const v21, 0x7f0802f6

    .line 385
    .line 386
    .line 387
    const v22, 0x7f0802f5

    .line 388
    .line 389
    .line 390
    const v23, 0x7f0802fb

    .line 391
    .line 392
    .line 393
    const v24, 0x7f0802fa

    .line 394
    .line 395
    .line 396
    move/from16 v38, v10

    .line 397
    .line 398
    move/from16 v39, v12

    .line 399
    .line 400
    move/from16 v40, v14

    .line 401
    .line 402
    move/from16 v14, v18

    .line 403
    .line 404
    const/4 v10, 0x0

    .line 405
    const/4 v11, 0x0

    .line 406
    const/16 v34, 0x1

    .line 407
    .line 408
    const/16 v35, 0x1

    .line 409
    .line 410
    const/16 v36, 0x1

    .line 411
    .line 412
    const/16 v37, 0x1

    .line 413
    .line 414
    const/16 v41, 0x1

    .line 415
    .line 416
    move v12, v4

    .line 417
    move/from16 v18, v9

    .line 418
    .line 419
    move v4, v13

    .line 420
    const/4 v9, 0x0

    .line 421
    move v13, v6

    .line 422
    goto :goto_15e

    .line 423
    :goto_1a6
    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 424
    .line 425
    .line 426
    move-result-object v8

    .line 427
    invoke-virtual {v8, v7, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 428
    .line 429
    .line 430
    const/high16 v7, 0x40000

    .line 431
    .line 432
    invoke-virtual {v1, v7}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    .line 433
    .line 434
    .line 435
    new-instance v7, La6/l;

    .line 436
    .line 437
    invoke-direct {v7, v1}, La6/l;-><init>(La6/w;)V

    .line 438
    .line 439
    .line 440
    iput-object v7, v1, La6/w;->v:La6/l;

    .line 441
    .line 442
    new-instance v7, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 443
    .line 444
    invoke-direct {v7}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 445
    .line 446
    .line 447
    iput-object v7, v1, La6/w;->M:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 448
    .line 449
    new-instance v7, Lk3/k1;

    .line 450
    .line 451
    invoke-direct {v7}, Lk3/k1;-><init>()V

    .line 452
    .line 453
    .line 454
    iput-object v7, v1, La6/w;->t0:Lk3/k1;

    .line 455
    .line 456
    new-instance v7, Lk3/m1;

    .line 457
    .line 458
    invoke-direct {v7}, Lk3/m1;-><init>()V

    .line 459
    .line 460
    .line 461
    iput-object v7, v1, La6/w;->u0:Lk3/m1;

    .line 462
    .line 463
    new-instance v7, Ljava/lang/StringBuilder;

    .line 464
    .line 465
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 466
    .line 467
    .line 468
    iput-object v7, v1, La6/w;->r0:Ljava/lang/StringBuilder;

    .line 469
    .line 470
    new-instance v8, Ljava/util/Formatter;

    .line 471
    .line 472
    move/from16 v25, v11

    .line 473
    .line 474
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 475
    .line 476
    .line 477
    move-result-object v11

    .line 478
    invoke-direct {v8, v7, v11}, Ljava/util/Formatter;-><init>(Ljava/lang/Appendable;Ljava/util/Locale;)V

    .line 479
    .line 480
    .line 481
    iput-object v8, v1, La6/w;->s0:Ljava/util/Formatter;

    .line 482
    .line 483
    const/4 v7, 0x0

    .line 484
    new-array v8, v7, [J

    .line 485
    .line 486
    iput-object v8, v1, La6/w;->d1:[J

    .line 487
    .line 488
    new-array v8, v7, [Z

    .line 489
    .line 490
    iput-object v8, v1, La6/w;->e1:[Z

    .line 491
    .line 492
    new-array v8, v7, [J

    .line 493
    .line 494
    iput-object v8, v1, La6/w;->f1:[J

    .line 495
    .line 496
    new-array v8, v7, [Z

    .line 497
    .line 498
    iput-object v8, v1, La6/w;->g1:[Z

    .line 499
    .line 500
    new-instance v7, La6/f;

    .line 501
    .line 502
    const/4 v8, 0x1

    .line 503
    invoke-direct {v7, v8, v1}, La6/f;-><init>(ILjava/lang/Object;)V

    .line 504
    .line 505
    .line 506
    iput-object v7, v1, La6/w;->v0:La6/f;

    .line 507
    .line 508
    :try_start_1fb
    const-class v7, Landroidx/media3/exoplayer/ExoPlayer;
    :try_end_1fd
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1fb .. :try_end_1fd} :catch_20f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1fb .. :try_end_1fd} :catch_20f

    .line 509
    .line 510
    :try_start_1fd
    filled-new-array/range {v17 .. v17}, [Ljava/lang/Class;

    .line 511
    .line 512
    .line 513
    move-result-object v8

    .line 514
    invoke-virtual {v7, v5, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 515
    .line 516
    .line 517
    move-result-object v8
    :try_end_205
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1fd .. :try_end_205} :catch_20d
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1fd .. :try_end_205} :catch_20d

    .line 518
    const/4 v11, 0x0

    .line 519
    :try_start_206
    invoke-virtual {v7, v3, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 520
    .line 521
    .line 522
    move-result-object v26
    :try_end_20a
    .catch Ljava/lang/ClassNotFoundException; {:try_start_206 .. :try_end_20a} :catch_211
    .catch Ljava/lang/NoSuchMethodException; {:try_start_206 .. :try_end_20a} :catch_211

    .line 523
    move-object/from16 v11, v26

    .line 524
    .line 525
    goto :goto_212

    .line 526
    :catch_20d
    :goto_20d
    const/4 v8, 0x0

    .line 527
    goto :goto_211

    .line 528
    :catch_20f
    const/4 v7, 0x0

    .line 529
    goto :goto_20d

    .line 530
    :catch_211
    :goto_211
    const/4 v11, 0x0

    .line 531
    :goto_212
    iput-object v7, v1, La6/w;->w:Ljava/lang/Class;

    .line 532
    .line 533
    iput-object v8, v1, La6/w;->x:Ljava/lang/reflect/Method;

    .line 534
    .line 535
    iput-object v11, v1, La6/w;->y:Ljava/lang/reflect/Method;

    .line 536
    .line 537
    :try_start_218
    const-string v7, "androidx.media3.transformer.CompositionPlayer"

    .line 538
    .line 539
    invoke-static {v7}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 540
    .line 541
    .line 542
    move-result-object v7
    :try_end_21e
    .catch Ljava/lang/ClassNotFoundException; {:try_start_218 .. :try_end_21e} :catch_22e
    .catch Ljava/lang/NoSuchMethodException; {:try_start_218 .. :try_end_21e} :catch_22e

    .line 543
    :try_start_21e
    filled-new-array/range {v17 .. v17}, [Ljava/lang/Class;

    .line 544
    .line 545
    .line 546
    move-result-object v8

    .line 547
    invoke-virtual {v7, v5, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 548
    .line 549
    .line 550
    move-result-object v5
    :try_end_226
    .catch Ljava/lang/ClassNotFoundException; {:try_start_21e .. :try_end_226} :catch_22c
    .catch Ljava/lang/NoSuchMethodException; {:try_start_21e .. :try_end_226} :catch_22c

    .line 551
    const/4 v11, 0x0

    .line 552
    :try_start_227
    invoke-virtual {v7, v3, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 553
    .line 554
    .line 555
    move-result-object v3
    :try_end_22b
    .catch Ljava/lang/ClassNotFoundException; {:try_start_227 .. :try_end_22b} :catch_230
    .catch Ljava/lang/NoSuchMethodException; {:try_start_227 .. :try_end_22b} :catch_230

    .line 556
    goto :goto_231

    .line 557
    :catch_22c
    const/4 v5, 0x0

    .line 558
    goto :goto_230

    .line 559
    :catch_22e
    const/4 v5, 0x0

    .line 560
    const/4 v7, 0x0

    .line 561
    :catch_230
    :goto_230
    const/4 v3, 0x0

    .line 562
    :goto_231
    iput-object v7, v1, La6/w;->J:Ljava/lang/Class;

    .line 563
    .line 564
    iput-object v5, v1, La6/w;->K:Ljava/lang/reflect/Method;

    .line 565
    .line 566
    iput-object v3, v1, La6/w;->L:Ljava/lang/reflect/Method;

    .line 567
    .line 568
    const v3, 0x7f0a01ae

    .line 569
    .line 570
    .line 571
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 572
    .line 573
    .line 574
    move-result-object v3

    .line 575
    check-cast v3, Landroid/widget/TextView;

    .line 576
    .line 577
    iput-object v3, v1, La6/w;->o0:Landroid/widget/TextView;

    .line 578
    .line 579
    const v3, 0x7f0a01c4

    .line 580
    .line 581
    .line 582
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 583
    .line 584
    .line 585
    move-result-object v3

    .line 586
    check-cast v3, Landroid/widget/TextView;

    .line 587
    .line 588
    iput-object v3, v1, La6/w;->p0:Landroid/widget/TextView;

    .line 589
    .line 590
    const v3, 0x7f0a01d0

    .line 591
    .line 592
    .line 593
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 594
    .line 595
    .line 596
    move-result-object v3

    .line 597
    check-cast v3, Landroid/widget/ImageView;

    .line 598
    .line 599
    iput-object v3, v1, La6/w;->i0:Landroid/widget/ImageView;

    .line 600
    .line 601
    if-eqz v3, :cond_25f

    .line 602
    .line 603
    iget-object v5, v1, La6/w;->v:La6/l;

    .line 604
    .line 605
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 606
    .line 607
    .line 608
    :cond_25f
    const v3, 0x7f0a01b4

    .line 609
    .line 610
    .line 611
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 612
    .line 613
    .line 614
    move-result-object v3

    .line 615
    check-cast v3, Landroid/widget/ImageView;

    .line 616
    .line 617
    iput-object v3, v1, La6/w;->j0:Landroid/widget/ImageView;

    .line 618
    .line 619
    new-instance v5, La6/i;

    .line 620
    .line 621
    const/4 v7, 0x0

    .line 622
    invoke-direct {v5, v7, v1}, La6/i;-><init>(ILjava/lang/Object;)V

    .line 623
    .line 624
    .line 625
    if-nez v3, :cond_275

    .line 626
    .line 627
    const/16 v8, 0x8

    .line 628
    .line 629
    goto :goto_27d

    .line 630
    :cond_275
    const/16 v8, 0x8

    .line 631
    .line 632
    invoke-virtual {v3, v8}, Landroid/view/View;->setVisibility(I)V

    .line 633
    .line 634
    .line 635
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 636
    .line 637
    .line 638
    :goto_27d
    const v3, 0x7f0a01ba

    .line 639
    .line 640
    .line 641
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 642
    .line 643
    .line 644
    move-result-object v3

    .line 645
    check-cast v3, Landroid/widget/ImageView;

    .line 646
    .line 647
    iput-object v3, v1, La6/w;->k0:Landroid/widget/ImageView;

    .line 648
    .line 649
    new-instance v5, La6/i;

    .line 650
    .line 651
    invoke-direct {v5, v7, v1}, La6/i;-><init>(ILjava/lang/Object;)V

    .line 652
    .line 653
    .line 654
    if-nez v3, :cond_290

    .line 655
    .line 656
    goto :goto_296

    .line 657
    :cond_290
    invoke-virtual {v3, v8}, Landroid/view/View;->setVisibility(I)V

    .line 658
    .line 659
    .line 660
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 661
    .line 662
    .line 663
    :goto_296
    const v3, 0x7f0a01cb

    .line 664
    .line 665
    .line 666
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 667
    .line 668
    .line 669
    move-result-object v3

    .line 670
    iput-object v3, v1, La6/w;->l0:Landroid/view/View;

    .line 671
    .line 672
    if-eqz v3, :cond_2a6

    .line 673
    .line 674
    iget-object v5, v1, La6/w;->v:La6/l;

    .line 675
    .line 676
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 677
    .line 678
    .line 679
    :cond_2a6
    const v3, 0x7f0a01c3

    .line 680
    .line 681
    .line 682
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 683
    .line 684
    .line 685
    move-result-object v3

    .line 686
    iput-object v3, v1, La6/w;->m0:Landroid/view/View;

    .line 687
    .line 688
    if-eqz v3, :cond_2b6

    .line 689
    .line 690
    iget-object v5, v1, La6/w;->v:La6/l;

    .line 691
    .line 692
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 693
    .line 694
    .line 695
    :cond_2b6
    const v3, 0x7f0a01a4

    .line 696
    .line 697
    .line 698
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 699
    .line 700
    .line 701
    move-result-object v3

    .line 702
    iput-object v3, v1, La6/w;->n0:Landroid/view/View;

    .line 703
    .line 704
    if-eqz v3, :cond_2c6

    .line 705
    .line 706
    iget-object v5, v1, La6/w;->v:La6/l;

    .line 707
    .line 708
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 709
    .line 710
    .line 711
    :cond_2c6
    const v3, 0x7f0a01c6

    .line 712
    .line 713
    .line 714
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 715
    .line 716
    .line 717
    move-result-object v5

    .line 718
    check-cast v5, La6/w0;

    .line 719
    .line 720
    const v7, 0x7f0a01c7

    .line 721
    .line 722
    .line 723
    invoke-virtual {v1, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 724
    .line 725
    .line 726
    move-result-object v7

    .line 727
    if-eqz v5, :cond_2dc

    .line 728
    .line 729
    iput-object v5, v1, La6/w;->q0:La6/w0;

    .line 730
    .line 731
    :goto_2da
    const/4 v11, 0x0

    .line 732
    goto :goto_303

    .line 733
    :cond_2dc
    if-eqz v7, :cond_300

    .line 734
    .line 735
    new-instance v5, La6/h;

    .line 736
    .line 737
    invoke-direct {v5, v2, v0}, La6/h;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 738
    .line 739
    .line 740
    invoke-virtual {v5, v3}, Landroid/view/View;->setId(I)V

    .line 741
    .line 742
    .line 743
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 744
    .line 745
    .line 746
    move-result-object v0

    .line 747
    invoke-virtual {v5, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 748
    .line 749
    .line 750
    invoke-virtual {v7}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 751
    .line 752
    .line 753
    move-result-object v0

    .line 754
    check-cast v0, Landroid/view/ViewGroup;

    .line 755
    .line 756
    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 757
    .line 758
    .line 759
    move-result v3

    .line 760
    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 761
    .line 762
    .line 763
    invoke-virtual {v0, v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 764
    .line 765
    .line 766
    iput-object v5, v1, La6/w;->q0:La6/w0;

    .line 767
    .line 768
    goto :goto_2da

    .line 769
    :cond_300
    const/4 v11, 0x0

    .line 770
    iput-object v11, v1, La6/w;->q0:La6/w0;

    .line 771
    .line 772
    :goto_303
    iget-object v0, v1, La6/w;->q0:La6/w0;

    .line 773
    .line 774
    if-eqz v0, :cond_313

    .line 775
    .line 776
    iget-object v3, v1, La6/w;->v:La6/l;

    .line 777
    .line 778
    check-cast v0, La6/h;

    .line 779
    .line 780
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 781
    .line 782
    .line 783
    iget-object v0, v0, La6/h;->c0:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 784
    .line 785
    invoke-virtual {v0, v3}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    .line 786
    .line 787
    .line 788
    :cond_313
    invoke-static {v11}, Ln3/l0;->r(Lm4/m;)Landroid/os/Handler;

    .line 789
    .line 790
    .line 791
    move-result-object v0

    .line 792
    iput-object v0, v1, La6/w;->i:Landroid/os/Handler;

    .line 793
    .line 794
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 795
    .line 796
    .line 797
    move-result-object v0

    .line 798
    iput-object v0, v1, La6/w;->e:Landroid/content/res/Resources;

    .line 799
    .line 800
    const v3, 0x7f0a01c1

    .line 801
    .line 802
    .line 803
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 804
    .line 805
    .line 806
    move-result-object v3

    .line 807
    check-cast v3, Landroid/widget/ImageView;

    .line 808
    .line 809
    iput-object v3, v1, La6/w;->a0:Landroid/widget/ImageView;

    .line 810
    .line 811
    if-eqz v3, :cond_331

    .line 812
    .line 813
    iget-object v5, v1, La6/w;->v:La6/l;

    .line 814
    .line 815
    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 816
    .line 817
    .line 818
    :cond_331
    const v3, 0x7f0a01c5

    .line 819
    .line 820
    .line 821
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 822
    .line 823
    .line 824
    move-result-object v3

    .line 825
    move-object v11, v3

    .line 826
    check-cast v11, Landroid/widget/ImageView;

    .line 827
    .line 828
    iput-object v11, v1, La6/w;->V:Landroid/widget/ImageView;

    .line 829
    .line 830
    if-eqz v11, :cond_34f

    .line 831
    .line 832
    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 833
    .line 834
    .line 835
    move-result-object v3

    .line 836
    invoke-virtual {v0, v6, v3}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 837
    .line 838
    .line 839
    move-result-object v3

    .line 840
    invoke-virtual {v11, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 841
    .line 842
    .line 843
    iget-object v3, v1, La6/w;->v:La6/l;

    .line 844
    .line 845
    invoke-virtual {v11, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 846
    .line 847
    .line 848
    :cond_34f
    const v3, 0x7f0a01bb

    .line 849
    .line 850
    .line 851
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 852
    .line 853
    .line 854
    move-result-object v3

    .line 855
    check-cast v3, Landroid/widget/ImageView;

    .line 856
    .line 857
    iput-object v3, v1, La6/w;->W:Landroid/widget/ImageView;

    .line 858
    .line 859
    if-eqz v3, :cond_36c

    .line 860
    .line 861
    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 862
    .line 863
    .line 864
    move-result-object v5

    .line 865
    invoke-virtual {v0, v4, v5}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 866
    .line 867
    .line 868
    move-result-object v4

    .line 869
    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 870
    .line 871
    .line 872
    iget-object v4, v1, La6/w;->v:La6/l;

    .line 873
    .line 874
    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 875
    .line 876
    .line 877
    :cond_36c
    sget-object v4, Lh1/k;->a:Ljava/lang/ThreadLocal;

    .line 878
    .line 879
    invoke-virtual {v2}, Landroid/content/Context;->isRestricted()Z

    .line 880
    .line 881
    .line 882
    move-result v4

    .line 883
    if-eqz v4, :cond_38e

    .line 884
    .line 885
    move-object/from16 v44, v3

    .line 886
    .line 887
    move/from16 v17, v9

    .line 888
    .line 889
    move/from16 v16, v10

    .line 890
    .line 891
    move-object/from16 p2, v11

    .line 892
    .line 893
    move/from16 v9, v18

    .line 894
    .line 895
    move/from16 v18, v19

    .line 896
    .line 897
    move/from16 v10, v20

    .line 898
    .line 899
    move/from16 v42, v21

    .line 900
    .line 901
    move/from16 v43, v22

    .line 902
    .line 903
    move/from16 v11, v23

    .line 904
    .line 905
    const/4 v3, 0x0

    .line 906
    move/from16 v19, v15

    .line 907
    .line 908
    move/from16 v15, v24

    .line 909
    .line 910
    goto :goto_3b9

    .line 911
    :cond_38e
    new-instance v4, Landroid/util/TypedValue;

    .line 912
    .line 913
    invoke-direct {v4}, Landroid/util/TypedValue;-><init>()V

    .line 914
    .line 915
    .line 916
    const/4 v7, 0x0

    .line 917
    const/4 v8, 0x0

    .line 918
    move-object v5, v3

    .line 919
    const/high16 v3, 0x7f090000

    .line 920
    .line 921
    move-object v6, v5

    .line 922
    const/4 v5, 0x0

    .line 923
    move-object/from16 v16, v6

    .line 924
    .line 925
    const/4 v6, 0x0

    .line 926
    move/from16 v17, v9

    .line 927
    .line 928
    move-object/from16 p2, v11

    .line 929
    .line 930
    move-object/from16 v44, v16

    .line 931
    .line 932
    move/from16 v9, v18

    .line 933
    .line 934
    move/from16 v18, v19

    .line 935
    .line 936
    move/from16 v42, v21

    .line 937
    .line 938
    move/from16 v43, v22

    .line 939
    .line 940
    move/from16 v11, v23

    .line 941
    .line 942
    move/from16 v16, v10

    .line 943
    .line 944
    move/from16 v19, v15

    .line 945
    .line 946
    move/from16 v10, v20

    .line 947
    .line 948
    move/from16 v15, v24

    .line 949
    .line 950
    invoke-static/range {v2 .. v8}, Lh1/k;->a(Landroid/content/Context;ILandroid/util/TypedValue;ILh1/b;ZZ)Landroid/graphics/Typeface;

    .line 951
    .line 952
    .line 953
    move-result-object v3

    .line 954
    :goto_3b9
    const v2, 0x7f0a01c9

    .line 955
    .line 956
    .line 957
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 958
    .line 959
    .line 960
    move-result-object v2

    .line 961
    check-cast v2, Landroid/widget/ImageView;

    .line 962
    .line 963
    const v4, 0x7f0a01ca

    .line 964
    .line 965
    .line 966
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 967
    .line 968
    .line 969
    move-result-object v4

    .line 970
    check-cast v4, Landroid/widget/TextView;

    .line 971
    .line 972
    if-eqz v2, :cond_3de

    .line 973
    .line 974
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 975
    .line 976
    .line 977
    move-result-object v4

    .line 978
    invoke-virtual {v0, v9, v4}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 979
    .line 980
    .line 981
    move-result-object v4

    .line 982
    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 983
    .line 984
    .line 985
    iput-object v2, v1, La6/w;->c0:Landroid/view/View;

    .line 986
    .line 987
    const/4 v2, 0x0

    .line 988
    iput-object v2, v1, La6/w;->e0:Landroid/widget/TextView;

    .line 989
    .line 990
    goto :goto_3ed

    .line 991
    :cond_3de
    const/4 v2, 0x0

    .line 992
    if-eqz v4, :cond_3e9

    .line 993
    .line 994
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 995
    .line 996
    .line 997
    iput-object v4, v1, La6/w;->e0:Landroid/widget/TextView;

    .line 998
    .line 999
    iput-object v4, v1, La6/w;->c0:Landroid/view/View;

    .line 1000
    .line 1001
    goto :goto_3ed

    .line 1002
    :cond_3e9
    iput-object v2, v1, La6/w;->e0:Landroid/widget/TextView;

    .line 1003
    .line 1004
    iput-object v2, v1, La6/w;->c0:Landroid/view/View;

    .line 1005
    .line 1006
    :goto_3ed
    iget-object v2, v1, La6/w;->c0:Landroid/view/View;

    .line 1007
    .line 1008
    if-eqz v2, :cond_3f6

    .line 1009
    .line 1010
    iget-object v4, v1, La6/w;->v:La6/l;

    .line 1011
    .line 1012
    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1013
    .line 1014
    .line 1015
    :cond_3f6
    const v2, 0x7f0a01b2

    .line 1016
    .line 1017
    .line 1018
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1019
    .line 1020
    .line 1021
    move-result-object v2

    .line 1022
    check-cast v2, Landroid/widget/ImageView;

    .line 1023
    .line 1024
    const v4, 0x7f0a01b3

    .line 1025
    .line 1026
    .line 1027
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v4

    .line 1031
    check-cast v4, Landroid/widget/TextView;

    .line 1032
    .line 1033
    if-eqz v2, :cond_41d

    .line 1034
    .line 1035
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1036
    .line 1037
    .line 1038
    move-result-object v3

    .line 1039
    move/from16 v4, v40

    .line 1040
    .line 1041
    invoke-virtual {v0, v4, v3}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v3

    .line 1045
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1046
    .line 1047
    .line 1048
    iput-object v2, v1, La6/w;->b0:Landroid/view/View;

    .line 1049
    .line 1050
    const/4 v2, 0x0

    .line 1051
    iput-object v2, v1, La6/w;->d0:Landroid/widget/TextView;

    .line 1052
    .line 1053
    goto :goto_42c

    .line 1054
    :cond_41d
    const/4 v2, 0x0

    .line 1055
    if-eqz v4, :cond_428

    .line 1056
    .line 1057
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1058
    .line 1059
    .line 1060
    iput-object v4, v1, La6/w;->d0:Landroid/widget/TextView;

    .line 1061
    .line 1062
    iput-object v4, v1, La6/w;->b0:Landroid/view/View;

    .line 1063
    .line 1064
    goto :goto_42c

    .line 1065
    :cond_428
    iput-object v2, v1, La6/w;->d0:Landroid/widget/TextView;

    .line 1066
    .line 1067
    iput-object v2, v1, La6/w;->b0:Landroid/view/View;

    .line 1068
    .line 1069
    :goto_42c
    iget-object v2, v1, La6/w;->b0:Landroid/view/View;

    .line 1070
    .line 1071
    if-eqz v2, :cond_435

    .line 1072
    .line 1073
    iget-object v3, v1, La6/w;->v:La6/l;

    .line 1074
    .line 1075
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1076
    .line 1077
    .line 1078
    :cond_435
    const v2, 0x7f0a01c8

    .line 1079
    .line 1080
    .line 1081
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1082
    .line 1083
    .line 1084
    move-result-object v2

    .line 1085
    check-cast v2, Landroid/widget/ImageView;

    .line 1086
    .line 1087
    iput-object v2, v1, La6/w;->f0:Landroid/widget/ImageView;

    .line 1088
    .line 1089
    if-eqz v2, :cond_447

    .line 1090
    .line 1091
    iget-object v3, v1, La6/w;->v:La6/l;

    .line 1092
    .line 1093
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1094
    .line 1095
    .line 1096
    :cond_447
    const v3, 0x7f0a01cd

    .line 1097
    .line 1098
    .line 1099
    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1100
    .line 1101
    .line 1102
    move-result-object v3

    .line 1103
    check-cast v3, Landroid/widget/ImageView;

    .line 1104
    .line 1105
    iput-object v3, v1, La6/w;->g0:Landroid/widget/ImageView;

    .line 1106
    .line 1107
    if-eqz v3, :cond_459

    .line 1108
    .line 1109
    iget-object v4, v1, La6/w;->v:La6/l;

    .line 1110
    .line 1111
    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1112
    .line 1113
    .line 1114
    :cond_459
    const v4, 0x7f0b0009

    .line 1115
    .line 1116
    .line 1117
    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getInteger(I)I

    .line 1118
    .line 1119
    .line 1120
    move-result v4

    .line 1121
    int-to-float v4, v4

    .line 1122
    const/high16 v5, 0x42c80000    # 100.0f

    .line 1123
    .line 1124
    div-float/2addr v4, v5

    .line 1125
    iput v4, v1, La6/w;->G0:F

    .line 1126
    .line 1127
    const v4, 0x7f0b0008

    .line 1128
    .line 1129
    .line 1130
    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getInteger(I)I

    .line 1131
    .line 1132
    .line 1133
    move-result v4

    .line 1134
    int-to-float v4, v4

    .line 1135
    div-float/2addr v4, v5

    .line 1136
    iput v4, v1, La6/w;->H0:F

    .line 1137
    .line 1138
    const v4, 0x7f0a01d6

    .line 1139
    .line 1140
    .line 1141
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1142
    .line 1143
    .line 1144
    move-result-object v4

    .line 1145
    check-cast v4, Landroid/widget/ImageView;

    .line 1146
    .line 1147
    iput-object v4, v1, La6/w;->h0:Landroid/widget/ImageView;

    .line 1148
    .line 1149
    if-eqz v4, :cond_48d

    .line 1150
    .line 1151
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1152
    .line 1153
    .line 1154
    move-result-object v5

    .line 1155
    invoke-virtual {v0, v12, v5}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1156
    .line 1157
    .line 1158
    move-result-object v5

    .line 1159
    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1160
    .line 1161
    .line 1162
    const/4 v7, 0x0

    .line 1163
    invoke-virtual {v1, v4, v7}, La6/w;->n(Landroid/view/View;Z)V

    .line 1164
    .line 1165
    .line 1166
    :cond_48d
    new-instance v5, La6/b0;

    .line 1167
    .line 1168
    invoke-direct {v5, v1}, La6/b0;-><init>(La6/w;)V

    .line 1169
    .line 1170
    .line 1171
    iput-object v5, v1, La6/w;->d:La6/b0;

    .line 1172
    .line 1173
    move/from16 v6, v41

    .line 1174
    .line 1175
    iput-boolean v6, v5, La6/b0;->D:Z

    .line 1176
    .line 1177
    const v6, 0x7f1300a2

    .line 1178
    .line 1179
    .line 1180
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1181
    .line 1182
    .line 1183
    move-result-object v6

    .line 1184
    const v7, 0x7f0802f9

    .line 1185
    .line 1186
    .line 1187
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1188
    .line 1189
    .line 1190
    move-result-object v8

    .line 1191
    invoke-virtual {v0, v7, v8}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1192
    .line 1193
    .line 1194
    move-result-object v7

    .line 1195
    const v8, 0x7f1300c3

    .line 1196
    .line 1197
    .line 1198
    invoke-virtual {v0, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1199
    .line 1200
    .line 1201
    move-result-object v8

    .line 1202
    filled-new-array {v6, v8}, [Ljava/lang/String;

    .line 1203
    .line 1204
    .line 1205
    move-result-object v6

    .line 1206
    const v8, 0x7f0802e5

    .line 1207
    .line 1208
    .line 1209
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1210
    .line 1211
    .line 1212
    move-result-object v9

    .line 1213
    invoke-virtual {v0, v8, v9}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1214
    .line 1215
    .line 1216
    move-result-object v8

    .line 1217
    filled-new-array {v7, v8}, [Landroid/graphics/drawable/Drawable;

    .line 1218
    .line 1219
    .line 1220
    move-result-object v7

    .line 1221
    new-instance v8, La6/r;

    .line 1222
    .line 1223
    invoke-direct {v8, v1, v6, v7}, La6/r;-><init>(La6/w;[Ljava/lang/String;[Landroid/graphics/drawable/Drawable;)V

    .line 1224
    .line 1225
    .line 1226
    iput-object v8, v1, La6/w;->O:La6/r;

    .line 1227
    .line 1228
    const v6, 0x7f0700a6

    .line 1229
    .line 1230
    .line 1231
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 1232
    .line 1233
    .line 1234
    move-result v6

    .line 1235
    iput v6, v1, La6/w;->U:I

    .line 1236
    .line 1237
    invoke-static/range {p1 .. p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 1238
    .line 1239
    .line 1240
    move-result-object v6

    .line 1241
    const v7, 0x7f0d005a

    .line 1242
    .line 1243
    .line 1244
    const/4 v9, 0x0

    .line 1245
    invoke-virtual {v6, v7, v9}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 1246
    .line 1247
    .line 1248
    move-result-object v6

    .line 1249
    check-cast v6, Landroidx/recyclerview/widget/RecyclerView;

    .line 1250
    .line 1251
    iput-object v6, v1, La6/w;->N:Landroidx/recyclerview/widget/RecyclerView;

    .line 1252
    .line 1253
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Le6/n0;)V

    .line 1254
    .line 1255
    .line 1256
    new-instance v7, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 1257
    .line 1258
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1259
    .line 1260
    .line 1261
    move-result-object v8

    .line 1262
    invoke-direct {v7, v8}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    .line 1263
    .line 1264
    .line 1265
    invoke-virtual {v6, v7}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/a;)V

    .line 1266
    .line 1267
    .line 1268
    new-instance v7, Landroid/widget/PopupWindow;

    .line 1269
    .line 1270
    const/4 v8, -0x2

    .line 1271
    const/4 v9, 0x1

    .line 1272
    invoke-direct {v7, v6, v8, v8, v9}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;IIZ)V

    .line 1273
    .line 1274
    .line 1275
    iput-object v7, v1, La6/w;->T:Landroid/widget/PopupWindow;

    .line 1276
    .line 1277
    iget-object v6, v1, La6/w;->v:La6/l;

    .line 1278
    .line 1279
    invoke-virtual {v7, v6}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 1280
    .line 1281
    .line 1282
    iput-boolean v9, v1, La6/w;->i1:Z

    .line 1283
    .line 1284
    new-instance v6, La8/d;

    .line 1285
    .line 1286
    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 1287
    .line 1288
    .line 1289
    move-result-object v7

    .line 1290
    invoke-direct {v6, v7}, La8/d;-><init>(Landroid/content/res/Resources;)V

    .line 1291
    .line 1292
    .line 1293
    iput-object v6, v1, La6/w;->S:La8/d;

    .line 1294
    .line 1295
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1296
    .line 1297
    .line 1298
    move-result-object v6

    .line 1299
    invoke-virtual {v0, v11, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1300
    .line 1301
    .line 1302
    move-result-object v6

    .line 1303
    iput-object v6, v1, La6/w;->K0:Landroid/graphics/drawable/Drawable;

    .line 1304
    .line 1305
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1306
    .line 1307
    .line 1308
    move-result-object v6

    .line 1309
    invoke-virtual {v0, v15, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1310
    .line 1311
    .line 1312
    move-result-object v6

    .line 1313
    iput-object v6, v1, La6/w;->L0:Landroid/graphics/drawable/Drawable;

    .line 1314
    .line 1315
    const v6, 0x7f130097

    .line 1316
    .line 1317
    .line 1318
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1319
    .line 1320
    .line 1321
    move-result-object v6

    .line 1322
    iput-object v6, v1, La6/w;->M0:Ljava/lang/String;

    .line 1323
    .line 1324
    const v6, 0x7f130096

    .line 1325
    .line 1326
    .line 1327
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1328
    .line 1329
    .line 1330
    move-result-object v6

    .line 1331
    iput-object v6, v1, La6/w;->N0:Ljava/lang/String;

    .line 1332
    .line 1333
    new-instance v6, La6/k;

    .line 1334
    .line 1335
    const/4 v7, 0x1

    .line 1336
    invoke-direct {v6, v1, v7}, La6/k;-><init>(La6/w;I)V

    .line 1337
    .line 1338
    .line 1339
    iput-object v6, v1, La6/w;->Q:La6/k;

    .line 1340
    .line 1341
    new-instance v6, La6/k;

    .line 1342
    .line 1343
    const/4 v7, 0x0

    .line 1344
    invoke-direct {v6, v1, v7}, La6/k;-><init>(La6/w;I)V

    .line 1345
    .line 1346
    .line 1347
    iput-object v6, v1, La6/w;->R:La6/k;

    .line 1348
    .line 1349
    new-instance v6, La6/o;

    .line 1350
    .line 1351
    const v7, 0x7f030004

    .line 1352
    .line 1353
    .line 1354
    invoke-virtual {v0, v7}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    .line 1355
    .line 1356
    .line 1357
    move-result-object v7

    .line 1358
    sget-object v8, La6/w;->j1:[F

    .line 1359
    .line 1360
    invoke-direct {v6, v1, v7, v8}, La6/o;-><init>(La6/w;[Ljava/lang/String;[F)V

    .line 1361
    .line 1362
    .line 1363
    iput-object v6, v1, La6/w;->P:La6/o;

    .line 1364
    .line 1365
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1366
    .line 1367
    .line 1368
    move-result-object v6

    .line 1369
    invoke-virtual {v0, v10, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1370
    .line 1371
    .line 1372
    move-result-object v6

    .line 1373
    iput-object v6, v1, La6/w;->w0:Landroid/graphics/drawable/Drawable;

    .line 1374
    .line 1375
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1376
    .line 1377
    .line 1378
    move-result-object v6

    .line 1379
    move/from16 v12, v39

    .line 1380
    .line 1381
    invoke-virtual {v0, v12, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1382
    .line 1383
    .line 1384
    move-result-object v6

    .line 1385
    iput-object v6, v1, La6/w;->x0:Landroid/graphics/drawable/Drawable;

    .line 1386
    .line 1387
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1388
    .line 1389
    .line 1390
    move-result-object v6

    .line 1391
    move/from16 v10, v38

    .line 1392
    .line 1393
    invoke-virtual {v0, v10, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1394
    .line 1395
    .line 1396
    move-result-object v6

    .line 1397
    iput-object v6, v1, La6/w;->O0:Landroid/graphics/drawable/Drawable;

    .line 1398
    .line 1399
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1400
    .line 1401
    .line 1402
    move-result-object v6

    .line 1403
    invoke-virtual {v0, v13, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1404
    .line 1405
    .line 1406
    move-result-object v6

    .line 1407
    iput-object v6, v1, La6/w;->P0:Landroid/graphics/drawable/Drawable;

    .line 1408
    .line 1409
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1410
    .line 1411
    .line 1412
    move-result-object v6

    .line 1413
    invoke-virtual {v0, v14, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1414
    .line 1415
    .line 1416
    move-result-object v6

    .line 1417
    iput-object v6, v1, La6/w;->y0:Landroid/graphics/drawable/Drawable;

    .line 1418
    .line 1419
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1420
    .line 1421
    .line 1422
    move-result-object v6

    .line 1423
    move/from16 v7, v19

    .line 1424
    .line 1425
    invoke-virtual {v0, v7, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1426
    .line 1427
    .line 1428
    move-result-object v6

    .line 1429
    iput-object v6, v1, La6/w;->z0:Landroid/graphics/drawable/Drawable;

    .line 1430
    .line 1431
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1432
    .line 1433
    .line 1434
    move-result-object v6

    .line 1435
    move/from16 v7, v18

    .line 1436
    .line 1437
    invoke-virtual {v0, v7, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1438
    .line 1439
    .line 1440
    move-result-object v6

    .line 1441
    iput-object v6, v1, La6/w;->A0:Landroid/graphics/drawable/Drawable;

    .line 1442
    .line 1443
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1444
    .line 1445
    .line 1446
    move-result-object v6

    .line 1447
    move/from16 v7, v42

    .line 1448
    .line 1449
    invoke-virtual {v0, v7, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1450
    .line 1451
    .line 1452
    move-result-object v6

    .line 1453
    iput-object v6, v1, La6/w;->E0:Landroid/graphics/drawable/Drawable;

    .line 1454
    .line 1455
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v6

    .line 1459
    move/from16 v7, v43

    .line 1460
    .line 1461
    invoke-virtual {v0, v7, v6}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 1462
    .line 1463
    .line 1464
    move-result-object v6

    .line 1465
    iput-object v6, v1, La6/w;->F0:Landroid/graphics/drawable/Drawable;

    .line 1466
    .line 1467
    const v6, 0x7f13009b

    .line 1468
    .line 1469
    .line 1470
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1471
    .line 1472
    .line 1473
    move-result-object v6

    .line 1474
    iput-object v6, v1, La6/w;->Q0:Ljava/lang/String;

    .line 1475
    .line 1476
    const v6, 0x7f13009a

    .line 1477
    .line 1478
    .line 1479
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1480
    .line 1481
    .line 1482
    move-result-object v6

    .line 1483
    iput-object v6, v1, La6/w;->R0:Ljava/lang/String;

    .line 1484
    .line 1485
    const v6, 0x7f1300a5

    .line 1486
    .line 1487
    .line 1488
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1489
    .line 1490
    .line 1491
    move-result-object v6

    .line 1492
    iput-object v6, v1, La6/w;->B0:Ljava/lang/String;

    .line 1493
    .line 1494
    const v6, 0x7f1300a6

    .line 1495
    .line 1496
    .line 1497
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1498
    .line 1499
    .line 1500
    move-result-object v6

    .line 1501
    iput-object v6, v1, La6/w;->C0:Ljava/lang/String;

    .line 1502
    .line 1503
    const v6, 0x7f1300a4

    .line 1504
    .line 1505
    .line 1506
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1507
    .line 1508
    .line 1509
    move-result-object v6

    .line 1510
    iput-object v6, v1, La6/w;->D0:Ljava/lang/String;

    .line 1511
    .line 1512
    const v6, 0x7f1300ac

    .line 1513
    .line 1514
    .line 1515
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1516
    .line 1517
    .line 1518
    move-result-object v6

    .line 1519
    iput-object v6, v1, La6/w;->I0:Ljava/lang/String;

    .line 1520
    .line 1521
    const v6, 0x7f1300ab

    .line 1522
    .line 1523
    .line 1524
    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 1525
    .line 1526
    .line 1527
    move-result-object v0

    .line 1528
    iput-object v0, v1, La6/w;->J0:Ljava/lang/String;

    .line 1529
    .line 1530
    const v0, 0x7f0a01a6

    .line 1531
    .line 1532
    .line 1533
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1534
    .line 1535
    .line 1536
    move-result-object v0

    .line 1537
    check-cast v0, Landroid/view/ViewGroup;

    .line 1538
    .line 1539
    const/4 v7, 0x1

    .line 1540
    invoke-virtual {v5, v0, v7}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1541
    .line 1542
    .line 1543
    iget-object v0, v1, La6/w;->b0:Landroid/view/View;

    .line 1544
    .line 1545
    move/from16 v6, v35

    .line 1546
    .line 1547
    invoke-virtual {v5, v0, v6}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1548
    .line 1549
    .line 1550
    iget-object v0, v1, La6/w;->c0:Landroid/view/View;

    .line 1551
    .line 1552
    move/from16 v6, v34

    .line 1553
    .line 1554
    invoke-virtual {v5, v0, v6}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1555
    .line 1556
    .line 1557
    move-object/from16 v6, p2

    .line 1558
    .line 1559
    move/from16 v0, v36

    .line 1560
    .line 1561
    invoke-virtual {v5, v6, v0}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1562
    .line 1563
    .line 1564
    move/from16 v0, v37

    .line 1565
    .line 1566
    move-object/from16 v6, v44

    .line 1567
    .line 1568
    invoke-virtual {v5, v6, v0}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1569
    .line 1570
    .line 1571
    move/from16 v10, v16

    .line 1572
    .line 1573
    invoke-virtual {v5, v3, v10}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1574
    .line 1575
    .line 1576
    iget-object v0, v1, La6/w;->i0:Landroid/widget/ImageView;

    .line 1577
    .line 1578
    move/from16 v3, v17

    .line 1579
    .line 1580
    invoke-virtual {v5, v0, v3}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1581
    .line 1582
    .line 1583
    move/from16 v0, v25

    .line 1584
    .line 1585
    invoke-virtual {v5, v4, v0}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1586
    .line 1587
    .line 1588
    iget v0, v1, La6/w;->c1:I

    .line 1589
    .line 1590
    if-eqz v0, :cond_639

    .line 1591
    .line 1592
    move v11, v7

    .line 1593
    goto :goto_63a

    .line 1594
    :cond_639
    const/4 v11, 0x0

    .line 1595
    :goto_63a
    invoke-virtual {v5, v2, v11}, La6/b0;->h(Landroid/view/View;Z)V

    .line 1596
    .line 1597
    .line 1598
    new-instance v0, La6/j;

    .line 1599
    .line 1600
    const/4 v7, 0x0

    .line 1601
    invoke-direct {v0, v7, v1}, La6/j;-><init>(ILjava/lang/Object;)V

    .line 1602
    .line 1603
    .line 1604
    invoke-virtual {v1, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 1605
    .line 1606
    .line 1607
    return-void
.end method

.method public static a(La6/w;Lk3/e1;J)V
    .registers 10

    .line 1
    iget-boolean v0, p0, La6/w;->X0:Z

    .line 2
    .line 3
    if-eqz v0, :cond_3d

    .line 4
    .line 5
    const/16 v0, 0x11

    .line 6
    .line 7
    invoke-interface {p1, v0}, Lk3/e1;->D1(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_47

    .line 12
    .line 13
    const/16 v0, 0xa

    .line 14
    .line 15
    invoke-interface {p1, v0}, Lk3/e1;->D1(I)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_47

    .line 20
    .line 21
    invoke-interface {p1}, Lk3/e1;->U()Lk3/n1;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Lk3/n1;->o()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    const/4 v2, 0x0

    .line 30
    :goto_1d
    iget-object v3, p0, La6/w;->u0:Lk3/m1;

    .line 31
    .line 32
    const-wide/16 v4, 0x0

    .line 33
    .line 34
    invoke-virtual {v0, v2, v3, v4, v5}, Lk3/n1;->m(ILk3/m1;J)Lk3/m1;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    iget-wide v3, v3, Lk3/m1;->m:J

    .line 39
    .line 40
    invoke-static {v3, v4}, Ln3/l0;->g0(J)J

    .line 41
    .line 42
    .line 43
    move-result-wide v3

    .line 44
    cmp-long v5, p2, v3

    .line 45
    .line 46
    if-gez v5, :cond_30

    .line 47
    .line 48
    goto :goto_35

    .line 49
    :cond_30
    add-int/lit8 v5, v1, -0x1

    .line 50
    .line 51
    if-ne v2, v5, :cond_39

    .line 52
    .line 53
    move-wide p2, v3

    .line 54
    :goto_35
    invoke-interface {p1, v2, p2, p3}, Lk3/e1;->h0(IJ)V

    .line 55
    .line 56
    .line 57
    goto :goto_47

    .line 58
    :cond_39
    sub-long/2addr p2, v3

    .line 59
    add-int/lit8 v2, v2, 0x1

    .line 60
    .line 61
    goto :goto_1d

    .line 62
    :cond_3d
    const/4 v0, 0x5

    .line 63
    invoke-interface {p1, v0}, Lk3/e1;->D1(I)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_47

    .line 68
    .line 69
    invoke-interface {p1, p2, p3}, Lk3/e1;->B(J)V

    .line 70
    .line 71
    .line 72
    :cond_47
    :goto_47
    invoke-virtual {p0}, La6/w;->s()V

    .line 73
    .line 74
    .line 75
    return-void
.end method

.method public static synthetic b(La6/w;F)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, La6/w;->setPlaybackSpeed(F)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static c(Lk3/e1;Lk3/m1;)Z
    .registers 10

    .line 1
    const/16 v0, 0x11

    .line 2
    .line 3
    invoke-interface {p0, v0}, Lk3/e1;->D1(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    goto :goto_33

    .line 11
    :cond_a
    invoke-interface {p0}, Lk3/e1;->U()Lk3/n1;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-virtual {p0}, Lk3/n1;->o()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/4 v2, 0x1

    .line 20
    if-le v0, v2, :cond_33

    .line 21
    .line 22
    const/16 v3, 0x64

    .line 23
    .line 24
    if-le v0, v3, :cond_1a

    .line 25
    .line 26
    goto :goto_33

    .line 27
    :cond_1a
    move v3, v1

    .line 28
    :goto_1b
    if-ge v3, v0, :cond_32

    .line 29
    .line 30
    const-wide/16 v4, 0x0

    .line 31
    .line 32
    invoke-virtual {p0, v3, p1, v4, v5}, Lk3/n1;->m(ILk3/m1;J)Lk3/m1;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    iget-wide v4, v4, Lk3/m1;->m:J

    .line 37
    .line 38
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    cmp-long v4, v4, v6

    .line 44
    .line 45
    if-nez v4, :cond_2f

    .line 46
    .line 47
    goto :goto_33

    .line 48
    :cond_2f
    add-int/lit8 v3, v3, 0x1

    .line 49
    .line 50
    goto :goto_1b

    .line 51
    :cond_32
    return v2

    .line 52
    :cond_33
    :goto_33
    return v1
.end method

.method private setPlaybackSpeed(F)V
    .registers 5

    .line 1
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 2
    .line 3
    if-eqz v0, :cond_1d

    .line 4
    .line 5
    const/16 v1, 0xd

    .line 6
    .line 7
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    goto :goto_1d

    .line 14
    :cond_d
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 15
    .line 16
    invoke-interface {v0}, Lk3/e1;->e()Lk3/y0;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    new-instance v2, Lk3/y0;

    .line 21
    .line 22
    iget v1, v1, Lk3/y0;->b:F

    .line 23
    .line 24
    invoke-direct {v2, p1, v1}, Lk3/y0;-><init>(FF)V

    .line 25
    .line 26
    .line 27
    invoke-interface {v0, v2}, Lk3/e1;->z(Lk3/y0;)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    :goto_1d
    return-void
.end method


# virtual methods
.method public final d(Landroid/view/KeyEvent;)Z
    .registers 13

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 6
    .line 7
    if-eqz v1, :cond_94

    .line 8
    .line 9
    const/16 v2, 0x58

    .line 10
    .line 11
    const/16 v3, 0x57

    .line 12
    .line 13
    const/16 v4, 0x7f

    .line 14
    .line 15
    const/16 v5, 0x7e

    .line 16
    .line 17
    const/16 v6, 0x4f

    .line 18
    .line 19
    const/16 v7, 0x55

    .line 20
    .line 21
    const/16 v8, 0x59

    .line 22
    .line 23
    const/16 v9, 0x5a

    .line 24
    .line 25
    if-eq v0, v9, :cond_28

    .line 26
    .line 27
    if-eq v0, v8, :cond_28

    .line 28
    .line 29
    if-eq v0, v7, :cond_28

    .line 30
    .line 31
    if-eq v0, v6, :cond_28

    .line 32
    .line 33
    if-eq v0, v5, :cond_28

    .line 34
    .line 35
    if-eq v0, v4, :cond_28

    .line 36
    .line 37
    if-eq v0, v3, :cond_28

    .line 38
    .line 39
    if-ne v0, v2, :cond_94

    .line 40
    .line 41
    :cond_28
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 42
    .line 43
    .line 44
    move-result v10

    .line 45
    if-nez v10, :cond_92

    .line 46
    .line 47
    if-ne v0, v9, :cond_43

    .line 48
    .line 49
    invoke-interface {v1}, Lk3/e1;->I()I

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    const/4 v0, 0x4

    .line 54
    if-eq p1, v0, :cond_92

    .line 55
    .line 56
    const/16 p1, 0xc

    .line 57
    .line 58
    invoke-interface {v1, p1}, Lk3/e1;->D1(I)Z

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    if-eqz p1, :cond_92

    .line 63
    .line 64
    invoke-interface {v1}, Lk3/e1;->g2()V

    .line 65
    .line 66
    .line 67
    goto :goto_92

    .line 68
    :cond_43
    if-ne v0, v8, :cond_51

    .line 69
    .line 70
    const/16 v8, 0xb

    .line 71
    .line 72
    invoke-interface {v1, v8}, Lk3/e1;->D1(I)Z

    .line 73
    .line 74
    .line 75
    move-result v8

    .line 76
    if-eqz v8, :cond_51

    .line 77
    .line 78
    invoke-interface {v1}, Lk3/e1;->h2()V

    .line 79
    .line 80
    .line 81
    goto :goto_92

    .line 82
    :cond_51
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    if-nez p1, :cond_92

    .line 87
    .line 88
    if-eq v0, v6, :cond_83

    .line 89
    .line 90
    if-eq v0, v7, :cond_83

    .line 91
    .line 92
    if-eq v0, v3, :cond_77

    .line 93
    .line 94
    if-eq v0, v2, :cond_6c

    .line 95
    .line 96
    if-eq v0, v5, :cond_68

    .line 97
    .line 98
    if-eq v0, v4, :cond_64

    .line 99
    .line 100
    goto :goto_92

    .line 101
    :cond_64
    invoke-static {v1}, Ln3/l0;->J(Lk3/e1;)Z

    .line 102
    .line 103
    .line 104
    goto :goto_92

    .line 105
    :cond_68
    invoke-static {v1}, Ln3/l0;->K(Lk3/e1;)Z

    .line 106
    .line 107
    .line 108
    goto :goto_92

    .line 109
    :cond_6c
    const/4 p1, 0x7

    .line 110
    invoke-interface {v1, p1}, Lk3/e1;->D1(I)Z

    .line 111
    .line 112
    .line 113
    move-result p1

    .line 114
    if-eqz p1, :cond_92

    .line 115
    .line 116
    invoke-interface {v1}, Lk3/e1;->c1()V

    .line 117
    .line 118
    .line 119
    goto :goto_92

    .line 120
    :cond_77
    const/16 p1, 0x9

    .line 121
    .line 122
    invoke-interface {v1, p1}, Lk3/e1;->D1(I)Z

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    if-eqz p1, :cond_92

    .line 127
    .line 128
    invoke-interface {v1}, Lk3/e1;->f2()V

    .line 129
    .line 130
    .line 131
    goto :goto_92

    .line 132
    :cond_83
    iget-boolean p1, p0, La6/w;->W0:Z

    .line 133
    .line 134
    invoke-static {v1, p1}, Ln3/l0;->c0(Lk3/e1;Z)Z

    .line 135
    .line 136
    .line 137
    move-result p1

    .line 138
    if-eqz p1, :cond_8f

    .line 139
    .line 140
    invoke-static {v1}, Ln3/l0;->K(Lk3/e1;)Z

    .line 141
    .line 142
    .line 143
    goto :goto_92

    .line 144
    :cond_8f
    invoke-static {v1}, Ln3/l0;->J(Lk3/e1;)Z

    .line 145
    .line 146
    .line 147
    :cond_92
    :goto_92
    const/4 p1, 0x1

    .line 148
    return p1

    .line 149
    :cond_94
    const/4 p1, 0x0

    .line 150
    return p1
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 3

    .line 1
    invoke-virtual {p0, p1}, La6/w;->d(Landroid/view/KeyEvent;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_f

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    if-eqz p1, :cond_d

    .line 12
    .line 13
    goto :goto_f

    .line 14
    :cond_d
    const/4 p1, 0x0

    .line 15
    return p1

    .line 16
    :cond_f
    :goto_f
    const/4 p1, 0x1

    .line 17
    return p1
.end method

.method public final e(Le6/n0;Landroid/view/View;)V
    .registers 6

    .line 1
    iget-object v0, p0, La6/w;->N:Landroidx/recyclerview/widget/RecyclerView;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Le6/n0;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, La6/w;->u()V

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    iput-boolean p1, p0, La6/w;->i1:Z

    .line 11
    .line 12
    iget-object p1, p0, La6/w;->T:Landroid/widget/PopupWindow;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    iput-boolean v0, p0, La6/w;->i1:Z

    .line 19
    .line 20
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->getWidth()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    sub-int/2addr v0, v1

    .line 29
    iget v1, p0, La6/w;->U:I

    .line 30
    .line 31
    sub-int/2addr v0, v1

    .line 32
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->getHeight()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    neg-int v2, v2

    .line 37
    sub-int/2addr v2, v1

    .line 38
    invoke-virtual {p1, p2, v0, v2}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;II)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final f(Lk3/v1;I)Lhx/w1;
    .registers 26

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const-string v1, "initialCapacity"

    .line 4
    .line 5
    const/4 v2, 0x4

    .line 6
    invoke-static {v2, v1}, Lhx/s;->g(ILjava/lang/String;)V

    .line 7
    .line 8
    .line 9
    new-array v1, v2, [Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v3, v0, Lk3/v1;->a:Lhx/m0;

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    const/4 v6, 0x0

    .line 15
    :goto_e
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 16
    .line 17
    .line 18
    move-result v7

    .line 19
    if-ge v5, v7, :cond_1d0

    .line 20
    .line 21
    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v7

    .line 25
    check-cast v7, Lk3/u1;

    .line 26
    .line 27
    iget-object v8, v7, Lk3/u1;->b:Lk3/o1;

    .line 28
    .line 29
    iget v8, v8, Lk3/o1;->c:I

    .line 30
    .line 31
    move/from16 v9, p2

    .line 32
    .line 33
    if-eq v8, v9, :cond_28

    .line 34
    .line 35
    :goto_22
    move-object/from16 v11, p0

    .line 36
    .line 37
    move-object/from16 v16, v3

    .line 38
    .line 39
    goto/16 :goto_1c9

    .line 40
    .line 41
    :cond_28
    const/4 v8, 0x0

    .line 42
    :goto_29
    iget v10, v7, Lk3/u1;->a:I

    .line 43
    .line 44
    if-ge v8, v10, :cond_1c5

    .line 45
    .line 46
    iget-object v10, v7, Lk3/u1;->d:[I

    .line 47
    .line 48
    aget v10, v10, v8

    .line 49
    .line 50
    if-eq v10, v2, :cond_3b

    .line 51
    .line 52
    :goto_33
    move-object/from16 v11, p0

    .line 53
    .line 54
    move-object/from16 v16, v3

    .line 55
    .line 56
    move-object/from16 v17, v7

    .line 57
    .line 58
    goto/16 :goto_1ba

    .line 59
    .line 60
    :cond_3b
    iget-object v10, v7, Lk3/u1;->b:Lk3/o1;

    .line 61
    .line 62
    iget-object v10, v10, Lk3/o1;->d:[Lk3/w;

    .line 63
    .line 64
    aget-object v10, v10, v8

    .line 65
    .line 66
    iget v11, v10, Lk3/w;->e:I

    .line 67
    .line 68
    iget v12, v10, Lk3/w;->k:I

    .line 69
    .line 70
    const/4 v13, 0x2

    .line 71
    and-int/2addr v11, v13

    .line 72
    if-eqz v11, :cond_4a

    .line 73
    .line 74
    goto :goto_33

    .line 75
    :cond_4a
    move-object/from16 v11, p0

    .line 76
    .line 77
    iget-object v14, v11, La6/w;->S:La8/d;

    .line 78
    .line 79
    iget-object v15, v14, La8/d;->e:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v15, Landroid/content/res/Resources;

    .line 82
    .line 83
    iget-object v2, v14, La8/d;->e:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v2, Landroid/content/res/Resources;

    .line 86
    .line 87
    iget-object v4, v10, Lk3/w;->p:Ljava/lang/String;

    .line 88
    .line 89
    iget v13, v10, Lk3/w;->J:I

    .line 90
    .line 91
    move-object/from16 v16, v3

    .line 92
    .line 93
    iget v3, v10, Lk3/w;->x:I

    .line 94
    .line 95
    move-object/from16 v17, v4

    .line 96
    .line 97
    iget v4, v10, Lk3/w;->w:I

    .line 98
    .line 99
    move/from16 v18, v6

    .line 100
    .line 101
    iget-object v6, v10, Lk3/w;->l:Ljava/lang/String;

    .line 102
    .line 103
    move-object/from16 v19, v6

    .line 104
    .line 105
    invoke-static/range {v17 .. v17}, Lk3/u0;->h(Ljava/lang/String;)I

    .line 106
    .line 107
    .line 108
    move-result v6

    .line 109
    move-object/from16 v17, v7

    .line 110
    .line 111
    const/4 v7, -0x1

    .line 112
    if-eq v6, v7, :cond_72

    .line 113
    .line 114
    goto :goto_c7

    .line 115
    :cond_72
    if-nez v19, :cond_77

    .line 116
    .line 117
    :cond_74
    const/16 v21, 0x0

    .line 118
    .line 119
    goto :goto_91

    .line 120
    :cond_77
    invoke-static/range {v19 .. v19}, Ln3/l0;->d0(Ljava/lang/String;)[Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v6

    .line 124
    array-length v9, v6

    .line 125
    const/4 v7, 0x0

    .line 126
    :goto_7d
    if-ge v7, v9, :cond_74

    .line 127
    .line 128
    aget-object v21, v6, v7

    .line 129
    .line 130
    invoke-static/range {v21 .. v21}, Lk3/u0;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v21

    .line 134
    if-eqz v21, :cond_8e

    .line 135
    .line 136
    invoke-static/range {v21 .. v21}, Lk3/u0;->m(Ljava/lang/String;)Z

    .line 137
    .line 138
    .line 139
    move-result v22

    .line 140
    if-eqz v22, :cond_8e

    .line 141
    .line 142
    goto :goto_91

    .line 143
    :cond_8e
    add-int/lit8 v7, v7, 0x1

    .line 144
    .line 145
    goto :goto_7d

    .line 146
    :goto_91
    if-eqz v21, :cond_95

    .line 147
    .line 148
    :cond_93
    :goto_93
    const/4 v6, 0x2

    .line 149
    goto :goto_c7

    .line 150
    :cond_95
    if-nez v19, :cond_99

    .line 151
    .line 152
    :cond_97
    const/4 v6, 0x0

    .line 153
    goto :goto_b5

    .line 154
    :cond_99
    invoke-static/range {v19 .. v19}, Ln3/l0;->d0(Ljava/lang/String;)[Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v6

    .line 158
    array-length v7, v6

    .line 159
    const/4 v9, 0x0

    .line 160
    :goto_9f
    if-ge v9, v7, :cond_97

    .line 161
    .line 162
    aget-object v19, v6, v9

    .line 163
    .line 164
    invoke-static/range {v19 .. v19}, Lk3/u0;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v19

    .line 168
    if-eqz v19, :cond_b2

    .line 169
    .line 170
    invoke-static/range {v19 .. v19}, Lk3/u0;->i(Ljava/lang/String;)Z

    .line 171
    .line 172
    .line 173
    move-result v21

    .line 174
    if-eqz v21, :cond_b2

    .line 175
    .line 176
    move-object/from16 v6, v19

    .line 177
    .line 178
    goto :goto_b5

    .line 179
    :cond_b2
    add-int/lit8 v9, v9, 0x1

    .line 180
    .line 181
    goto :goto_9f

    .line 182
    :goto_b5
    if-eqz v6, :cond_b9

    .line 183
    .line 184
    :cond_b7
    :goto_b7
    const/4 v6, 0x1

    .line 185
    goto :goto_c7

    .line 186
    :cond_b9
    const/4 v6, -0x1

    .line 187
    if-ne v4, v6, :cond_93

    .line 188
    .line 189
    if-eq v3, v6, :cond_bf

    .line 190
    .line 191
    goto :goto_93

    .line 192
    :cond_bf
    if-ne v13, v6, :cond_b7

    .line 193
    .line 194
    iget v7, v10, Lk3/w;->L:I

    .line 195
    .line 196
    if-eq v7, v6, :cond_c6

    .line 197
    .line 198
    goto :goto_b7

    .line 199
    :cond_c6
    const/4 v6, -0x1

    .line 200
    :goto_c7
    const v9, 0x7f1300ba

    .line 201
    .line 202
    .line 203
    const-string v19, ""

    .line 204
    .line 205
    const/4 v7, 0x2

    .line 206
    const v20, 0x49742400    # 1000000.0f

    .line 207
    .line 208
    .line 209
    if-ne v6, v7, :cond_111

    .line 210
    .line 211
    invoke-virtual {v14, v10}, La8/d;->p(Lk3/w;)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v6

    .line 215
    const/4 v7, -0x1

    .line 216
    if-eq v4, v7, :cond_f0

    .line 217
    .line 218
    if-ne v3, v7, :cond_dc

    .line 219
    .line 220
    goto :goto_f0

    .line 221
    :cond_dc
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 226
    .line 227
    .line 228
    move-result-object v3

    .line 229
    filled-new-array {v4, v3}, [Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v3

    .line 233
    const v4, 0x7f1300bc

    .line 234
    .line 235
    .line 236
    invoke-virtual {v15, v4, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v3

    .line 240
    goto :goto_f2

    .line 241
    :cond_f0
    :goto_f0
    move-object/from16 v3, v19

    .line 242
    .line 243
    :goto_f2
    if-ne v12, v7, :cond_f7

    .line 244
    .line 245
    :goto_f4
    move-object/from16 v2, v19

    .line 246
    .line 247
    goto :goto_107

    .line 248
    :cond_f7
    int-to-float v4, v12

    .line 249
    div-float v4, v4, v20

    .line 250
    .line 251
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 252
    .line 253
    .line 254
    move-result-object v4

    .line 255
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    move-result-object v4

    .line 259
    invoke-virtual {v2, v9, v4}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v19

    .line 263
    goto :goto_f4

    .line 264
    :goto_107
    filled-new-array {v6, v3, v2}, [Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    invoke-virtual {v14, v2}, La8/d;->x([Ljava/lang/String;)Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object v2

    .line 272
    goto/16 :goto_17b

    .line 273
    .line 274
    :cond_111
    const/4 v3, 0x1

    .line 275
    if-ne v6, v3, :cond_177

    .line 276
    .line 277
    invoke-virtual {v14, v10}, La8/d;->l(Lk3/w;)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    move-result-object v4

    .line 281
    const/4 v6, -0x1

    .line 282
    if-eq v13, v6, :cond_156

    .line 283
    .line 284
    if-ge v13, v3, :cond_11e

    .line 285
    .line 286
    goto :goto_156

    .line 287
    :cond_11e
    if-eq v13, v3, :cond_14e

    .line 288
    .line 289
    const/4 v7, 0x2

    .line 290
    if-eq v13, v7, :cond_146

    .line 291
    .line 292
    const/4 v3, 0x6

    .line 293
    if-eq v13, v3, :cond_13e

    .line 294
    .line 295
    const/4 v3, 0x7

    .line 296
    if-eq v13, v3, :cond_13e

    .line 297
    .line 298
    const/16 v3, 0x8

    .line 299
    .line 300
    if-eq v13, v3, :cond_136

    .line 301
    .line 302
    const v3, 0x7f1300c7

    .line 303
    .line 304
    .line 305
    invoke-virtual {v15, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v3

    .line 309
    :goto_134
    const/4 v6, -0x1

    .line 310
    goto :goto_159

    .line 311
    :cond_136
    const v3, 0x7f1300c9

    .line 312
    .line 313
    .line 314
    invoke-virtual {v15, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v3

    .line 318
    goto :goto_134

    .line 319
    :cond_13e
    const v3, 0x7f1300c8

    .line 320
    .line 321
    .line 322
    invoke-virtual {v15, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v3

    .line 326
    goto :goto_134

    .line 327
    :cond_146
    const v3, 0x7f1300c6

    .line 328
    .line 329
    .line 330
    invoke-virtual {v15, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v3

    .line 334
    goto :goto_134

    .line 335
    :cond_14e
    const v3, 0x7f1300bb

    .line 336
    .line 337
    .line 338
    invoke-virtual {v15, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v3

    .line 342
    goto :goto_134

    .line 343
    :cond_156
    :goto_156
    move-object/from16 v3, v19

    .line 344
    .line 345
    goto :goto_134

    .line 346
    :goto_159
    if-ne v12, v6, :cond_15e

    .line 347
    .line 348
    :goto_15b
    move-object/from16 v2, v19

    .line 349
    .line 350
    goto :goto_16e

    .line 351
    :cond_15e
    int-to-float v6, v12

    .line 352
    div-float v6, v6, v20

    .line 353
    .line 354
    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 355
    .line 356
    .line 357
    move-result-object v6

    .line 358
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 359
    .line 360
    .line 361
    move-result-object v6

    .line 362
    invoke-virtual {v2, v9, v6}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 363
    .line 364
    .line 365
    move-result-object v19

    .line 366
    goto :goto_15b

    .line 367
    :goto_16e
    filled-new-array {v4, v3, v2}, [Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object v2

    .line 371
    invoke-virtual {v14, v2}, La8/d;->x([Ljava/lang/String;)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v2

    .line 375
    goto :goto_17b

    .line 376
    :cond_177
    invoke-virtual {v14, v10}, La8/d;->l(Lk3/w;)Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object v2

    .line 380
    :goto_17b
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 381
    .line 382
    .line 383
    move-result v3

    .line 384
    if-nez v3, :cond_182

    .line 385
    .line 386
    goto :goto_1a4

    .line 387
    :cond_182
    iget-object v2, v10, Lk3/w;->d:Ljava/lang/String;

    .line 388
    .line 389
    if-eqz v2, :cond_19d

    .line 390
    .line 391
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 392
    .line 393
    .line 394
    move-result-object v3

    .line 395
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 396
    .line 397
    .line 398
    move-result v3

    .line 399
    if-eqz v3, :cond_191

    .line 400
    .line 401
    goto :goto_19d

    .line 402
    :cond_191
    const v3, 0x7f1300cb

    .line 403
    .line 404
    .line 405
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 406
    .line 407
    .line 408
    move-result-object v2

    .line 409
    invoke-virtual {v15, v3, v2}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object v2

    .line 413
    goto :goto_1a4

    .line 414
    :cond_19d
    :goto_19d
    const v2, 0x7f1300ca

    .line 415
    .line 416
    .line 417
    invoke-virtual {v15, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 418
    .line 419
    .line 420
    move-result-object v2

    .line 421
    :goto_1a4
    new-instance v3, La6/t;

    .line 422
    .line 423
    invoke-direct {v3, v0, v5, v8, v2}, La6/t;-><init>(Lk3/v1;IILjava/lang/String;)V

    .line 424
    .line 425
    .line 426
    array-length v2, v1

    .line 427
    add-int/lit8 v6, v18, 0x1

    .line 428
    .line 429
    invoke-static {v2, v6}, Lhx/g0;->b(II)I

    .line 430
    .line 431
    .line 432
    move-result v2

    .line 433
    array-length v4, v1

    .line 434
    if-gt v2, v4, :cond_1b4

    .line 435
    .line 436
    goto :goto_1b8

    .line 437
    :cond_1b4
    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v1

    .line 441
    :goto_1b8
    aput-object v3, v1, v18

    .line 442
    .line 443
    :goto_1ba
    add-int/lit8 v8, v8, 0x1

    .line 444
    .line 445
    move/from16 v9, p2

    .line 446
    .line 447
    move-object/from16 v3, v16

    .line 448
    .line 449
    move-object/from16 v7, v17

    .line 450
    .line 451
    const/4 v2, 0x4

    .line 452
    goto/16 :goto_29

    .line 453
    .line 454
    :cond_1c5
    move/from16 v18, v6

    .line 455
    .line 456
    goto/16 :goto_22

    .line 457
    .line 458
    :goto_1c9
    add-int/lit8 v5, v5, 0x1

    .line 459
    .line 460
    move-object/from16 v3, v16

    .line 461
    .line 462
    const/4 v2, 0x4

    .line 463
    goto/16 :goto_e

    .line 464
    .line 465
    :cond_1d0
    move-object/from16 v11, p0

    .line 466
    .line 467
    invoke-static {v6, v1}, Lhx/m0;->o(I[Ljava/lang/Object;)Lhx/w1;

    .line 468
    .line 469
    .line 470
    move-result-object v0

    .line 471
    return-object v0
.end method

.method public final g()V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget v1, v0, La6/b0;->A:I

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    if-eq v1, v2, :cond_26

    .line 7
    .line 8
    const/4 v2, 0x2

    .line 9
    if-ne v1, v2, :cond_b

    .line 10
    .line 11
    goto :goto_26

    .line 12
    :cond_b
    invoke-virtual {v0}, La6/b0;->f()V

    .line 13
    .line 14
    .line 15
    iget-boolean v1, v0, La6/b0;->D:Z

    .line 16
    .line 17
    if-nez v1, :cond_16

    .line 18
    .line 19
    invoke-virtual {v0, v2}, La6/b0;->i(I)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    iget v1, v0, La6/b0;->A:I

    .line 24
    .line 25
    const/4 v2, 0x1

    .line 26
    if-ne v1, v2, :cond_21

    .line 27
    .line 28
    iget-object v0, v0, La6/b0;->n:Landroid/animation/AnimatorSet;

    .line 29
    .line 30
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_21
    iget-object v0, v0, La6/b0;->o:Landroid/animation/AnimatorSet;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 37
    .line 38
    .line 39
    :cond_26
    :goto_26
    return-void
.end method

.method public getPlayer()Lk3/e1;
    .registers 2

    .line 1
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 2
    .line 3
    return-object v0
.end method

.method public getRepeatToggleModes()I
    .registers 2

    .line 1
    iget v0, p0, La6/w;->c1:I

    .line 2
    .line 3
    return v0
.end method

.method public getShowShuffleButton()Z
    .registers 3

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->g0:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, La6/b0;->b(Landroid/view/View;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getShowSubtitleButton()Z
    .registers 3

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->i0:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, La6/b0;->b(Landroid/view/View;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getShowTimeoutMs()I
    .registers 2

    .line 1
    iget v0, p0, La6/w;->Z0:I

    .line 2
    .line 3
    return v0
.end method

.method public getShowVrButton()Z
    .registers 3

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->h0:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, La6/b0;->b(Landroid/view/View;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public final h(Lk3/e1;)Z
    .registers 3

    .line 1
    if-eqz p1, :cond_12

    .line 2
    .line 3
    iget-object v0, p0, La6/w;->J:Ljava/lang/Class;

    .line 4
    .line 5
    if-eqz v0, :cond_12

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    if-eqz p1, :cond_12

    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    return p1

    .line 19
    :cond_12
    const/4 p1, 0x0

    .line 20
    return p1
.end method

.method public final hasOverlappingRendering()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final i(Lk3/e1;)Z
    .registers 3

    .line 1
    if-eqz p1, :cond_12

    .line 2
    .line 3
    iget-object v0, p0, La6/w;->w:Ljava/lang/Class;

    .line 4
    .line 5
    if-eqz v0, :cond_12

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    if-eqz p1, :cond_12

    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    return p1

    .line 19
    :cond_12
    const/4 p1, 0x0

    .line 20
    return p1
.end method

.method public final j()Z
    .registers 3

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget v1, v0, La6/b0;->A:I

    .line 4
    .line 5
    if-nez v1, :cond_10

    .line 6
    .line 7
    iget-object v0, v0, La6/b0;->a:La6/w;

    .line 8
    .line 9
    invoke-virtual {v0}, La6/w;->l()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_10

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    return v0

    .line 17
    :cond_10
    const/4 v0, 0x0

    .line 18
    return v0
.end method

.method public final k(Lk3/e1;)Z
    .registers 4

    .line 1
    :try_start_0
    invoke-virtual {p0, p1}, La6/w;->i(Lk3/e1;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_20

    .line 7
    .line 8
    iget-object v0, p0, La6/w;->y:Ljava/lang/reflect/Method;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    check-cast v0, Ljava/lang/Boolean;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-nez v0, :cond_3a

    .line 27
    .line 28
    goto :goto_20

    .line 29
    :catch_1c
    move-exception p1

    .line 30
    goto :goto_3e

    .line 31
    :catch_1e
    move-exception p1

    .line 32
    goto :goto_3e

    .line 33
    :cond_20
    :goto_20
    invoke-virtual {p0, p1}, La6/w;->h(Lk3/e1;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_3c

    .line 38
    .line 39
    iget-object v0, p0, La6/w;->L:Ljava/lang/reflect/Method;

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    check-cast p1, Ljava/lang/Boolean;

    .line 52
    .line 53
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 54
    .line 55
    .line 56
    move-result p1
    :try_end_38
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_38} :catch_1e
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_38} :catch_1c

    .line 57
    if-eqz p1, :cond_3c

    .line 58
    .line 59
    :cond_3a
    const/4 p1, 0x1

    .line 60
    return p1

    .line 61
    :cond_3c
    const/4 p1, 0x0

    .line 62
    return p1

    .line 63
    :goto_3e
    new-instance v0, Ljava/lang/RuntimeException;

    .line 64
    .line 65
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 66
    .line 67
    .line 68
    throw v0
.end method

.method public final l()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    return v0

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    return v0
.end method

.method public final m()V
    .registers 1

    .line 1
    invoke-virtual {p0}, La6/w;->q()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La6/w;->p()V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, La6/w;->t()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, La6/w;->v()V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, La6/w;->x()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, La6/w;->r()V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, La6/w;->w()V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final n(Landroid/view/View;Z)V
    .registers 3

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    .line 5
    .line 6
    .line 7
    if-eqz p2, :cond_b

    .line 8
    .line 9
    iget p2, p0, La6/w;->G0:F

    .line 10
    .line 11
    goto :goto_d

    .line 12
    :cond_b
    iget p2, p0, La6/w;->H0:F

    .line 13
    .line 14
    :goto_d
    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final o(Z)V
    .registers 7

    .line 1
    iget-boolean v0, p0, La6/w;->T0:Z

    .line 2
    .line 3
    if-ne v0, p1, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    iput-boolean p1, p0, La6/w;->T0:Z

    .line 7
    .line 8
    iget-object v0, p0, La6/w;->R0:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v1, p0, La6/w;->P0:Landroid/graphics/drawable/Drawable;

    .line 11
    .line 12
    iget-object v2, p0, La6/w;->Q0:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v3, p0, La6/w;->O0:Landroid/graphics/drawable/Drawable;

    .line 15
    .line 16
    iget-object v4, p0, La6/w;->j0:Landroid/widget/ImageView;

    .line 17
    .line 18
    if-nez v4, :cond_14

    .line 19
    .line 20
    goto :goto_23

    .line 21
    :cond_14
    if-eqz p1, :cond_1d

    .line 22
    .line 23
    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v4, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 27
    .line 28
    .line 29
    goto :goto_23

    .line 30
    :cond_1d
    invoke-virtual {v4, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v4, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 34
    .line 35
    .line 36
    :goto_23
    iget-object v4, p0, La6/w;->k0:Landroid/widget/ImageView;

    .line 37
    .line 38
    if-nez v4, :cond_28

    .line 39
    .line 40
    goto :goto_37

    .line 41
    :cond_28
    if-eqz p1, :cond_31

    .line 42
    .line 43
    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v4, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 47
    .line 48
    .line 49
    goto :goto_37

    .line 50
    :cond_31
    invoke-virtual {v4, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v4, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 54
    .line 55
    .line 56
    :goto_37
    return-void
.end method

.method public final onAttachedToWindow()V
    .registers 4

    .line 1
    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 5
    .line 6
    iget-object v1, v0, La6/b0;->a:La6/w;

    .line 7
    .line 8
    iget-object v2, v0, La6/b0;->y:La6/j;

    .line 9
    .line 10
    invoke-virtual {v1, v2}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 11
    .line 12
    .line 13
    const/4 v1, 0x1

    .line 14
    iput-boolean v1, p0, La6/w;->U0:Z

    .line 15
    .line 16
    invoke-virtual {p0}, La6/w;->j()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_18

    .line 21
    .line 22
    invoke-virtual {v0}, La6/b0;->g()V

    .line 23
    .line 24
    .line 25
    :cond_18
    invoke-virtual {p0}, La6/w;->m()V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public final onDetachedFromWindow()V
    .registers 4

    .line 1
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 5
    .line 6
    iget-object v1, v0, La6/b0;->a:La6/w;

    .line 7
    .line 8
    iget-object v2, v0, La6/b0;->y:La6/j;

    .line 9
    .line 10
    invoke-virtual {v1, v2}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 11
    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    iput-boolean v1, p0, La6/w;->U0:Z

    .line 15
    .line 16
    iget-object v1, p0, La6/w;->v0:La6/f;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, La6/b0;->f()V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final onLayout(ZIIII)V
    .registers 7

    .line 1
    invoke-super/range {p0 .. p5}, Landroid/widget/FrameLayout;->onLayout(ZIIII)V

    .line 2
    .line 3
    .line 4
    move-object p1, p0

    .line 5
    iget-object v0, p1, La6/w;->d:La6/b0;

    .line 6
    .line 7
    iget-object v0, v0, La6/b0;->b:Landroid/view/View;

    .line 8
    .line 9
    if-eqz v0, :cond_10

    .line 10
    .line 11
    sub-int/2addr p4, p2

    .line 12
    sub-int/2addr p5, p3

    .line 13
    const/4 p2, 0x0

    .line 14
    invoke-virtual {v0, p2, p2, p4, p5}, Landroid/view/View;->layout(IIII)V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public final p()V
    .registers 13

    .line 1
    invoke-virtual {p0}, La6/w;->l()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_c1

    .line 6
    .line 7
    iget-boolean v0, p0, La6/w;->U0:Z

    .line 8
    .line 9
    if-nez v0, :cond_c

    .line 10
    .line 11
    goto/16 :goto_c1

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 14
    .line 15
    if-eqz v0, :cond_40

    .line 16
    .line 17
    iget-boolean v1, p0, La6/w;->V0:Z

    .line 18
    .line 19
    if-eqz v1, :cond_23

    .line 20
    .line 21
    iget-object v1, p0, La6/w;->u0:Lk3/m1;

    .line 22
    .line 23
    invoke-static {v0, v1}, La6/w;->c(Lk3/e1;Lk3/m1;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_23

    .line 28
    .line 29
    const/16 v1, 0xa

    .line 30
    .line 31
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    goto :goto_28

    .line 36
    :cond_23
    const/4 v1, 0x5

    .line 37
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    :goto_28
    const/4 v2, 0x7

    .line 42
    invoke-interface {v0, v2}, Lk3/e1;->D1(I)Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    const/16 v3, 0xb

    .line 47
    .line 48
    invoke-interface {v0, v3}, Lk3/e1;->D1(I)Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    const/16 v4, 0xc

    .line 53
    .line 54
    invoke-interface {v0, v4}, Lk3/e1;->D1(I)Z

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    const/16 v5, 0x9

    .line 59
    .line 60
    invoke-interface {v0, v5}, Lk3/e1;->D1(I)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    goto :goto_45

    .line 65
    :cond_40
    const/4 v1, 0x0

    .line 66
    move v0, v1

    .line 67
    move v2, v0

    .line 68
    move v3, v2

    .line 69
    move v4, v3

    .line 70
    :goto_45
    iget-object v5, p0, La6/w;->e:Landroid/content/res/Resources;

    .line 71
    .line 72
    iget-object v6, p0, La6/w;->c0:Landroid/view/View;

    .line 73
    .line 74
    const-wide/16 v7, 0x3e8

    .line 75
    .line 76
    if-eqz v3, :cond_79

    .line 77
    .line 78
    iget-object v9, p0, La6/w;->S0:Lk3/e1;

    .line 79
    .line 80
    if-eqz v9, :cond_56

    .line 81
    .line 82
    invoke-interface {v9}, Lk3/e1;->c0()J

    .line 83
    .line 84
    .line 85
    move-result-wide v9

    .line 86
    goto :goto_58

    .line 87
    :cond_56
    const-wide/16 v9, 0x1388

    .line 88
    .line 89
    :goto_58
    div-long/2addr v9, v7

    .line 90
    long-to-int v9, v9

    .line 91
    iget-object v10, p0, La6/w;->e0:Landroid/widget/TextView;

    .line 92
    .line 93
    if-eqz v10, :cond_65

    .line 94
    .line 95
    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v11

    .line 99
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 100
    .line 101
    .line 102
    :cond_65
    if-eqz v6, :cond_79

    .line 103
    .line 104
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v10

    .line 108
    filled-new-array {v10}, [Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v10

    .line 112
    const v11, 0x7f110001

    .line 113
    .line 114
    .line 115
    invoke-virtual {v5, v11, v9, v10}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v9

    .line 119
    invoke-virtual {v6, v9}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 120
    .line 121
    .line 122
    :cond_79
    iget-object v9, p0, La6/w;->b0:Landroid/view/View;

    .line 123
    .line 124
    if-eqz v4, :cond_a8

    .line 125
    .line 126
    iget-object v10, p0, La6/w;->S0:Lk3/e1;

    .line 127
    .line 128
    if-eqz v10, :cond_86

    .line 129
    .line 130
    invoke-interface {v10}, Lk3/e1;->G()J

    .line 131
    .line 132
    .line 133
    move-result-wide v10

    .line 134
    goto :goto_88

    .line 135
    :cond_86
    const-wide/16 v10, 0x3a98

    .line 136
    .line 137
    :goto_88
    div-long/2addr v10, v7

    .line 138
    long-to-int v7, v10

    .line 139
    iget-object v8, p0, La6/w;->d0:Landroid/widget/TextView;

    .line 140
    .line 141
    if-eqz v8, :cond_95

    .line 142
    .line 143
    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v10

    .line 147
    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 148
    .line 149
    .line 150
    :cond_95
    if-eqz v9, :cond_a8

    .line 151
    .line 152
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 153
    .line 154
    .line 155
    move-result-object v8

    .line 156
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v8

    .line 160
    const/high16 v10, 0x7f110000

    .line 161
    .line 162
    invoke-virtual {v5, v10, v7, v8}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v5

    .line 166
    invoke-virtual {v9, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 167
    .line 168
    .line 169
    :cond_a8
    iget-object v5, p0, La6/w;->V:Landroid/widget/ImageView;

    .line 170
    .line 171
    invoke-virtual {p0, v5, v2}, La6/w;->n(Landroid/view/View;Z)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p0, v6, v3}, La6/w;->n(Landroid/view/View;Z)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {p0, v9, v4}, La6/w;->n(Landroid/view/View;Z)V

    .line 178
    .line 179
    .line 180
    iget-object v2, p0, La6/w;->W:Landroid/widget/ImageView;

    .line 181
    .line 182
    invoke-virtual {p0, v2, v0}, La6/w;->n(Landroid/view/View;Z)V

    .line 183
    .line 184
    .line 185
    iget-object v0, p0, La6/w;->q0:La6/w0;

    .line 186
    .line 187
    if-eqz v0, :cond_c1

    .line 188
    .line 189
    check-cast v0, La6/h;

    .line 190
    .line 191
    invoke-virtual {v0, v1}, La6/h;->setEnabled(Z)V

    .line 192
    .line 193
    .line 194
    :cond_c1
    :goto_c1
    return-void
.end method

.method public final q()V
    .registers 10

    .line 1
    invoke-virtual {p0}, La6/w;->l()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_79

    .line 6
    .line 7
    iget-boolean v0, p0, La6/w;->U0:Z

    .line 8
    .line 9
    if-nez v0, :cond_c

    .line 10
    .line 11
    goto/16 :goto_79

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, La6/w;->a0:Landroid/widget/ImageView;

    .line 14
    .line 15
    if-eqz v0, :cond_79

    .line 16
    .line 17
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 18
    .line 19
    iget-boolean v2, p0, La6/w;->W0:Z

    .line 20
    .line 21
    invoke-static {v1, v2}, Ln3/l0;->c0(Lk3/e1;Z)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_1d

    .line 26
    .line 27
    iget-object v2, p0, La6/w;->w0:Landroid/graphics/drawable/Drawable;

    .line 28
    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    iget-object v2, p0, La6/w;->x0:Landroid/graphics/drawable/Drawable;

    .line 31
    .line 32
    :goto_1f
    if-eqz v1, :cond_25

    .line 33
    .line 34
    const v1, 0x7f1300a1

    .line 35
    .line 36
    .line 37
    goto :goto_28

    .line 38
    :cond_25
    const v1, 0x7f1300a0

    .line 39
    .line 40
    .line 41
    :goto_28
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 42
    .line 43
    .line 44
    iget-object v2, p0, La6/w;->e:Landroid/content/res/Resources;

    .line 45
    .line 46
    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-virtual {v0, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 51
    .line 52
    .line 53
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 54
    .line 55
    const/4 v2, 0x0

    .line 56
    if-nez v1, :cond_3a

    .line 57
    .line 58
    goto :goto_76

    .line 59
    :cond_3a
    invoke-interface {v1}, Lk3/e1;->I()I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    const/16 v4, 0x10

    .line 64
    .line 65
    invoke-interface {v1, v4}, Lk3/e1;->D1(I)Z

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    const/4 v5, 0x1

    .line 70
    if-eqz v4, :cond_50

    .line 71
    .line 72
    invoke-interface {v1}, Lk3/e1;->k0()Lk3/o0;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    if-eqz v4, :cond_4e

    .line 77
    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    move v4, v2

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    :goto_50
    move v4, v5

    .line 82
    :goto_51
    invoke-interface {v1, v5}, Lk3/e1;->D1(I)Z

    .line 83
    .line 84
    .line 85
    move-result v6

    .line 86
    if-ne v3, v5, :cond_60

    .line 87
    .line 88
    const/4 v7, 0x2

    .line 89
    invoke-interface {v1, v7}, Lk3/e1;->D1(I)Z

    .line 90
    .line 91
    .line 92
    move-result v7

    .line 93
    if-eqz v7, :cond_60

    .line 94
    .line 95
    move v7, v5

    .line 96
    goto :goto_61

    .line 97
    :cond_60
    move v7, v2

    .line 98
    :goto_61
    const/4 v8, 0x4

    .line 99
    if-ne v3, v8, :cond_6c

    .line 100
    .line 101
    invoke-interface {v1, v8}, Lk3/e1;->D1(I)Z

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    if-eqz v1, :cond_6c

    .line 106
    .line 107
    move v1, v5

    .line 108
    goto :goto_6d

    .line 109
    :cond_6c
    move v1, v2

    .line 110
    :goto_6d
    if-eqz v4, :cond_76

    .line 111
    .line 112
    if-nez v6, :cond_75

    .line 113
    .line 114
    if-nez v7, :cond_75

    .line 115
    .line 116
    if-eqz v1, :cond_76

    .line 117
    .line 118
    :cond_75
    move v2, v5

    .line 119
    :cond_76
    :goto_76
    invoke-virtual {p0, v0, v2}, La6/w;->n(Landroid/view/View;Z)V

    .line 120
    .line 121
    .line 122
    :cond_79
    :goto_79
    return-void
.end method

.method public final r()V
    .registers 9

    .line 1
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    invoke-interface {v0}, Lk3/e1;->e()Lk3/y0;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget v0, v0, Lk3/y0;->a:F

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    const v2, 0x7f7fffff    # Float.MAX_VALUE

    .line 14
    .line 15
    .line 16
    move v3, v1

    .line 17
    move v4, v3

    .line 18
    :goto_11
    iget-object v5, p0, La6/w;->P:La6/o;

    .line 19
    .line 20
    iget-object v6, v5, La6/o;->e:[F

    .line 21
    .line 22
    array-length v7, v6

    .line 23
    if-ge v3, v7, :cond_29

    .line 24
    .line 25
    aget v5, v6, v3

    .line 26
    .line 27
    sub-float v5, v0, v5

    .line 28
    .line 29
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    cmpg-float v6, v5, v2

    .line 34
    .line 35
    if-gez v6, :cond_26

    .line 36
    .line 37
    move v4, v3

    .line 38
    move v2, v5

    .line 39
    :cond_26
    add-int/lit8 v3, v3, 0x1

    .line 40
    .line 41
    goto :goto_11

    .line 42
    :cond_29
    iput v4, v5, La6/o;->f:I

    .line 43
    .line 44
    iget-object v0, v5, La6/o;->d:[Ljava/lang/String;

    .line 45
    .line 46
    aget-object v0, v0, v4

    .line 47
    .line 48
    iget-object v2, p0, La6/w;->O:La6/r;

    .line 49
    .line 50
    iget-object v3, v2, La6/r;->f:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v3, [Ljava/lang/String;

    .line 53
    .line 54
    aput-object v0, v3, v1

    .line 55
    .line 56
    const/4 v0, 0x1

    .line 57
    invoke-virtual {v2, v0}, La6/r;->n(I)Z

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    if-nez v3, :cond_44

    .line 62
    .line 63
    invoke-virtual {v2, v1}, La6/r;->n(I)Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-eqz v2, :cond_45

    .line 68
    .line 69
    :cond_44
    move v1, v0

    .line 70
    :cond_45
    iget-object v0, p0, La6/w;->l0:Landroid/view/View;

    .line 71
    .line 72
    invoke-virtual {p0, v0, v1}, La6/w;->n(Landroid/view/View;Z)V

    .line 73
    .line 74
    .line 75
    return-void
.end method

.method public final s()V
    .registers 16

    .line 1
    invoke-virtual {p0}, La6/w;->l()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_9e

    .line 6
    .line 7
    iget-boolean v0, p0, La6/w;->U0:Z

    .line 8
    .line 9
    if-nez v0, :cond_c

    .line 10
    .line 11
    goto/16 :goto_9e

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 14
    .line 15
    if-eqz v0, :cond_27

    .line 16
    .line 17
    const/16 v1, 0x10

    .line 18
    .line 19
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-eqz v1, :cond_27

    .line 24
    .line 25
    iget-wide v1, p0, La6/w;->h1:J

    .line 26
    .line 27
    invoke-interface {v0}, Lk3/e1;->H()J

    .line 28
    .line 29
    .line 30
    move-result-wide v3

    .line 31
    add-long/2addr v3, v1

    .line 32
    iget-wide v1, p0, La6/w;->h1:J

    .line 33
    .line 34
    invoke-interface {v0}, Lk3/e1;->X()J

    .line 35
    .line 36
    .line 37
    move-result-wide v5

    .line 38
    add-long/2addr v5, v1

    .line 39
    goto :goto_2a

    .line 40
    :cond_27
    const-wide/16 v3, 0x0

    .line 41
    .line 42
    move-wide v5, v3

    .line 43
    :goto_2a
    iget-object v1, p0, La6/w;->p0:Landroid/widget/TextView;

    .line 44
    .line 45
    if-eqz v1, :cond_3d

    .line 46
    .line 47
    iget-boolean v2, p0, La6/w;->Y0:Z

    .line 48
    .line 49
    if-nez v2, :cond_3d

    .line 50
    .line 51
    iget-object v2, p0, La6/w;->r0:Ljava/lang/StringBuilder;

    .line 52
    .line 53
    iget-object v7, p0, La6/w;->s0:Ljava/util/Formatter;

    .line 54
    .line 55
    invoke-static {v2, v7, v3, v4}, Ln3/l0;->G(Ljava/lang/StringBuilder;Ljava/util/Formatter;J)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 60
    .line 61
    .line 62
    :cond_3d
    iget-object v1, p0, La6/w;->q0:La6/w0;

    .line 63
    .line 64
    if-eqz v1, :cond_51

    .line 65
    .line 66
    move-object v2, v1

    .line 67
    check-cast v2, La6/h;

    .line 68
    .line 69
    invoke-virtual {v2, v3, v4}, La6/h;->setPosition(J)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p0, v0}, La6/w;->k(Lk3/e1;)Z

    .line 73
    .line 74
    .line 75
    move-result v7

    .line 76
    if-eqz v7, :cond_4e

    .line 77
    .line 78
    move-wide v5, v3

    .line 79
    :cond_4e
    invoke-virtual {v2, v5, v6}, La6/h;->setBufferedPosition(J)V

    .line 80
    .line 81
    .line 82
    :cond_51
    iget-object v2, p0, La6/w;->v0:La6/f;

    .line 83
    .line 84
    invoke-virtual {p0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 85
    .line 86
    .line 87
    const/4 v5, 0x1

    .line 88
    if-nez v0, :cond_5b

    .line 89
    .line 90
    move v6, v5

    .line 91
    goto :goto_5f

    .line 92
    :cond_5b
    invoke-interface {v0}, Lk3/e1;->I()I

    .line 93
    .line 94
    .line 95
    move-result v6

    .line 96
    :goto_5f
    const-wide/16 v7, 0x3e8

    .line 97
    .line 98
    if-eqz v0, :cond_96

    .line 99
    .line 100
    invoke-interface {v0}, Lk3/e1;->K()Z

    .line 101
    .line 102
    .line 103
    move-result v9

    .line 104
    if-eqz v9, :cond_96

    .line 105
    .line 106
    if-eqz v1, :cond_72

    .line 107
    .line 108
    check-cast v1, La6/h;

    .line 109
    .line 110
    invoke-virtual {v1}, La6/h;->getPreferredUpdateDelay()J

    .line 111
    .line 112
    .line 113
    move-result-wide v5

    .line 114
    goto :goto_73

    .line 115
    :cond_72
    move-wide v5, v7

    .line 116
    :goto_73
    rem-long/2addr v3, v7

    .line 117
    sub-long v3, v7, v3

    .line 118
    .line 119
    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->min(JJ)J

    .line 120
    .line 121
    .line 122
    move-result-wide v3

    .line 123
    invoke-interface {v0}, Lk3/e1;->e()Lk3/y0;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    iget v0, v0, Lk3/y0;->a:F

    .line 128
    .line 129
    const/4 v1, 0x0

    .line 130
    cmpl-float v1, v0, v1

    .line 131
    .line 132
    if-lez v1, :cond_88

    .line 133
    .line 134
    long-to-float v1, v3

    .line 135
    div-float/2addr v1, v0

    .line 136
    float-to-long v7, v1

    .line 137
    :cond_88
    move-wide v9, v7

    .line 138
    iget v0, p0, La6/w;->b1:I

    .line 139
    .line 140
    int-to-long v11, v0

    .line 141
    const-wide/16 v13, 0x3e8

    .line 142
    .line 143
    invoke-static/range {v9 .. v14}, Ln3/l0;->k(JJJ)J

    .line 144
    .line 145
    .line 146
    move-result-wide v0

    .line 147
    invoke-virtual {p0, v2, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :cond_96
    const/4 v0, 0x4

    .line 152
    if-eq v6, v0, :cond_9e

    .line 153
    .line 154
    if-eq v6, v5, :cond_9e

    .line 155
    .line 156
    invoke-virtual {p0, v2, v7, v8}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 157
    .line 158
    .line 159
    :cond_9e
    :goto_9e
    return-void
.end method

.method public setAnimationEnabled(Z)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iput-boolean p1, v0, La6/b0;->D:Z

    .line 4
    .line 5
    return-void
.end method

.method public setMediaRouteButtonViewProvider(Lk3/a2;)V
    .registers 6

    .line 1
    const v0, 0x7f0a01b8

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_40

    .line 9
    .line 10
    if-nez p1, :cond_11

    .line 11
    .line 12
    const/16 p1, 0x8

    .line 13
    .line 14
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_11
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Landroid/view/ViewGroup;

    .line 23
    .line 24
    if-eqz v1, :cond_38

    .line 25
    .line 26
    invoke-interface {p1}, Lk3/a2;->getView()Lmx/y;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    new-instance v2, Lk7/m;

    .line 31
    .line 32
    const/4 v3, 0x2

    .line 33
    invoke-direct {v2, v3, p0, v0, v1}, Lk7/m;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iget-object v0, p0, La6/w;->i:Landroid/os/Handler;

    .line 37
    .line 38
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    new-instance v1, Lv3/u;

    .line 42
    .line 43
    const/4 v3, 0x1

    .line 44
    invoke-direct {v1, v3, v0}, Lv3/u;-><init>(ILjava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    new-instance v0, Lmx/u;

    .line 48
    .line 49
    const/4 v3, 0x0

    .line 50
    invoke-direct {v0, v3, p1, v2}, Lmx/u;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    invoke-interface {p1, v0, v1}, Lmx/y;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :cond_38
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 58
    .line 59
    const-string v0, "The media route button placeholder has no parent view."

    .line 60
    .line 61
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw p1

    .line 65
    :cond_40
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 66
    .line 67
    const-string v0, "The media route button placeholder is missing."

    .line 68
    .line 69
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw p1
.end method

.method public setOnFullScreenModeChangedListener(La6/m;)V
    .registers 7
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    if-eqz p1, :cond_6

    .line 4
    .line 5
    move v2, v1

    .line 6
    goto :goto_7

    .line 7
    :cond_6
    move v2, v0

    .line 8
    :goto_7
    const/16 v3, 0x8

    .line 9
    .line 10
    iget-object v4, p0, La6/w;->j0:Landroid/widget/ImageView;

    .line 11
    .line 12
    if-nez v4, :cond_e

    .line 13
    .line 14
    goto :goto_17

    .line 15
    :cond_e
    if-eqz v2, :cond_14

    .line 16
    .line 17
    invoke-virtual {v4, v0}, Landroid/view/View;->setVisibility(I)V

    .line 18
    .line 19
    .line 20
    goto :goto_17

    .line 21
    :cond_14
    invoke-virtual {v4, v3}, Landroid/view/View;->setVisibility(I)V

    .line 22
    .line 23
    .line 24
    :goto_17
    if-eqz p1, :cond_1a

    .line 25
    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    move v1, v0

    .line 28
    :goto_1b
    iget-object p1, p0, La6/w;->k0:Landroid/widget/ImageView;

    .line 29
    .line 30
    if-nez p1, :cond_20

    .line 31
    .line 32
    return-void

    .line 33
    :cond_20
    if-eqz v1, :cond_26

    .line 34
    .line 35
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_26
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public setPlayer(Lk3/e1;)V
    .registers 6

    .line 1
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne v0, v1, :cond_e

    .line 12
    .line 13
    move v0, v3

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    move v0, v2

    .line 16
    :goto_f
    invoke-static {v0}, Loq/a;->z(Z)V

    .line 17
    .line 18
    .line 19
    if-eqz p1, :cond_1e

    .line 20
    .line 21
    invoke-interface {p1}, Lk3/e1;->V()Landroid/os/Looper;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    if-ne v0, v1, :cond_1f

    .line 30
    .line 31
    :cond_1e
    move v2, v3

    .line 32
    :cond_1f
    invoke-static {v2}, Loq/a;->n(Z)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 36
    .line 37
    if-ne v0, p1, :cond_27

    .line 38
    .line 39
    return-void

    .line 40
    :cond_27
    iget-object v1, p0, La6/w;->v:La6/l;

    .line 41
    .line 42
    if-eqz v0, :cond_2e

    .line 43
    .line 44
    invoke-interface {v0, v1}, Lk3/e1;->E0(Lk3/c1;)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    iput-object p1, p0, La6/w;->S0:Lk3/e1;

    .line 48
    .line 49
    if-eqz p1, :cond_35

    .line 50
    .line 51
    invoke-interface {p1, v1}, Lk3/e1;->o1(Lk3/c1;)V

    .line 52
    .line 53
    .line 54
    :cond_35
    invoke-virtual {p0}, La6/w;->m()V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public setProgressUpdateListener(La6/p;)V
    .registers 2

    .line 1
    return-void
.end method

.method public setRepeatToggleModes(I)V
    .registers 6

    .line 1
    iput p1, p0, La6/w;->c1:I

    .line 2
    .line 3
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    if-eqz v0, :cond_34

    .line 8
    .line 9
    const/16 v3, 0xf

    .line 10
    .line 11
    invoke-interface {v0, v3}, Lk3/e1;->D1(I)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_34

    .line 16
    .line 17
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 18
    .line 19
    invoke-interface {v0}, Lk3/e1;->T()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez p1, :cond_20

    .line 24
    .line 25
    if-eqz v0, :cond_20

    .line 26
    .line 27
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 28
    .line 29
    invoke-interface {v0, v1}, Lk3/e1;->Q(I)V

    .line 30
    .line 31
    .line 32
    goto :goto_34

    .line 33
    :cond_20
    const/4 v3, 0x2

    .line 34
    if-ne p1, v2, :cond_2b

    .line 35
    .line 36
    if-ne v0, v3, :cond_2b

    .line 37
    .line 38
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 39
    .line 40
    invoke-interface {v0, v2}, Lk3/e1;->Q(I)V

    .line 41
    .line 42
    .line 43
    goto :goto_34

    .line 44
    :cond_2b
    if-ne p1, v3, :cond_34

    .line 45
    .line 46
    if-ne v0, v2, :cond_34

    .line 47
    .line 48
    iget-object v0, p0, La6/w;->S0:Lk3/e1;

    .line 49
    .line 50
    invoke-interface {v0, v3}, Lk3/e1;->Q(I)V

    .line 51
    .line 52
    .line 53
    :cond_34
    :goto_34
    if-eqz p1, :cond_37

    .line 54
    .line 55
    move v1, v2

    .line 56
    :cond_37
    iget-object p1, p0, La6/w;->d:La6/b0;

    .line 57
    .line 58
    iget-object v0, p0, La6/w;->f0:Landroid/widget/ImageView;

    .line 59
    .line 60
    invoke-virtual {p1, v0, v1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p0}, La6/w;->t()V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public setShowFastForwardButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->b0:Landroid/view/View;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La6/w;->p()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setShowMultiWindowTimeBar(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iput-boolean p1, p0, La6/w;->V0:Z

    .line 2
    .line 3
    invoke-virtual {p0}, La6/w;->w()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setShowNextButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->W:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La6/w;->p()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setShowPlayButtonIfPlaybackIsSuppressed(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, La6/w;->W0:Z

    .line 2
    .line 3
    invoke-virtual {p0}, La6/w;->q()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setShowPreviousButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->V:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La6/w;->p()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setShowRewindButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->c0:Landroid/view/View;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La6/w;->p()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setShowShuffleButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->g0:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La6/w;->v()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setShowSubtitleButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->i0:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public setShowTimeoutMs(I)V
    .registers 2

    .line 1
    iput p1, p0, La6/w;->Z0:I

    .line 2
    .line 3
    invoke-virtual {p0}, La6/w;->j()Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eqz p1, :cond_d

    .line 8
    .line 9
    iget-object p1, p0, La6/w;->d:La6/b0;

    .line 10
    .line 11
    invoke-virtual {p1}, La6/b0;->g()V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

.method public setShowVrButton(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, La6/w;->d:La6/b0;

    .line 2
    .line 3
    iget-object v1, p0, La6/w;->h0:Landroid/widget/ImageView;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, La6/b0;->h(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public setTimeBarMinUpdateInterval(I)V
    .registers 4

    .line 1
    const/16 v0, 0x10

    .line 2
    .line 3
    const/16 v1, 0x3e8

    .line 4
    .line 5
    invoke-static {p1, v0, v1}, Ln3/l0;->j(III)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    iput p1, p0, La6/w;->b1:I

    .line 10
    .line 11
    return-void
.end method

.method public setTimeBarScrubbingEnabled(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, La6/w;->a1:Z

    .line 2
    .line 3
    return-void
.end method

.method public setVrButtonListener(Landroid/view/View$OnClickListener;)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/w;->h0:Landroid/widget/ImageView;

    .line 2
    .line 3
    if-eqz v0, :cond_f

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 6
    .line 7
    .line 8
    if-eqz p1, :cond_b

    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 p1, 0x0

    .line 13
    :goto_c
    invoke-virtual {p0, v0, p1}, La6/w;->n(Landroid/view/View;Z)V

    .line 14
    .line 15
    .line 16
    :cond_f
    return-void
.end method

.method public final t()V
    .registers 7

    .line 1
    invoke-virtual {p0}, La6/w;->l()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_5f

    .line 6
    .line 7
    iget-boolean v0, p0, La6/w;->U0:Z

    .line 8
    .line 9
    if-eqz v0, :cond_5f

    .line 10
    .line 11
    iget-object v0, p0, La6/w;->f0:Landroid/widget/ImageView;

    .line 12
    .line 13
    if-nez v0, :cond_f

    .line 14
    .line 15
    goto :goto_5f

    .line 16
    :cond_f
    iget v1, p0, La6/w;->c1:I

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    if-nez v1, :cond_18

    .line 20
    .line 21
    invoke-virtual {p0, v0, v2}, La6/w;->n(Landroid/view/View;Z)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 26
    .line 27
    iget-object v3, p0, La6/w;->B0:Ljava/lang/String;

    .line 28
    .line 29
    iget-object v4, p0, La6/w;->y0:Landroid/graphics/drawable/Drawable;

    .line 30
    .line 31
    if-eqz v1, :cond_56

    .line 32
    .line 33
    const/16 v5, 0xf

    .line 34
    .line 35
    invoke-interface {v1, v5}, Lk3/e1;->D1(I)Z

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    if-nez v5, :cond_29

    .line 40
    .line 41
    goto :goto_56

    .line 42
    :cond_29
    const/4 v2, 0x1

    .line 43
    invoke-virtual {p0, v0, v2}, La6/w;->n(Landroid/view/View;Z)V

    .line 44
    .line 45
    .line 46
    invoke-interface {v1}, Lk3/e1;->T()I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_4f

    .line 51
    .line 52
    if-eq v1, v2, :cond_44

    .line 53
    .line 54
    const/4 v2, 0x2

    .line 55
    if-eq v1, v2, :cond_39

    .line 56
    .line 57
    goto :goto_5f

    .line 58
    :cond_39
    iget-object v1, p0, La6/w;->A0:Landroid/graphics/drawable/Drawable;

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 61
    .line 62
    .line 63
    iget-object v1, p0, La6/w;->D0:Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_44
    iget-object v1, p0, La6/w;->z0:Landroid/graphics/drawable/Drawable;

    .line 70
    .line 71
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 72
    .line 73
    .line 74
    iget-object v1, p0, La6/w;->C0:Ljava/lang/String;

    .line 75
    .line 76
    invoke-virtual {v0, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :cond_4f
    invoke-virtual {v0, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0, v3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_56
    :goto_56
    invoke-virtual {p0, v0, v2}, La6/w;->n(Landroid/view/View;Z)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0, v3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 94
    .line 95
    .line 96
    :cond_5f
    :goto_5f
    return-void
.end method

.method public final u()V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La6/w;->N:Landroidx/recyclerview/widget/RecyclerView;

    .line 3
    .line 4
    invoke-virtual {v1, v0, v0}, Landroid/view/View;->measure(II)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iget v2, p0, La6/w;->U:I

    .line 12
    .line 13
    mul-int/lit8 v3, v2, 0x2

    .line 14
    .line 15
    sub-int/2addr v0, v3

    .line 16
    invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iget-object v3, p0, La6/w;->T:Landroid/widget/PopupWindow;

    .line 25
    .line 26
    invoke-virtual {v3, v0}, Landroid/widget/PopupWindow;->setWidth(I)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    mul-int/lit8 v2, v2, 0x2

    .line 34
    .line 35
    sub-int/2addr v0, v2

    .line 36
    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-virtual {v3, v0}, Landroid/widget/PopupWindow;->setHeight(I)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final v()V
    .registers 7

    .line 1
    invoke-virtual {p0}, La6/w;->l()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_51

    .line 6
    .line 7
    iget-boolean v0, p0, La6/w;->U0:Z

    .line 8
    .line 9
    if-eqz v0, :cond_51

    .line 10
    .line 11
    iget-object v0, p0, La6/w;->g0:Landroid/widget/ImageView;

    .line 12
    .line 13
    if-nez v0, :cond_f

    .line 14
    .line 15
    goto :goto_51

    .line 16
    :cond_f
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 17
    .line 18
    iget-object v2, p0, La6/w;->d:La6/b0;

    .line 19
    .line 20
    invoke-virtual {v2, v0}, La6/b0;->b(Landroid/view/View;)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    const/4 v3, 0x0

    .line 25
    if-nez v2, :cond_1e

    .line 26
    .line 27
    invoke-virtual {p0, v0, v3}, La6/w;->n(Landroid/view/View;Z)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_1e
    iget-object v2, p0, La6/w;->J0:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v4, p0, La6/w;->F0:Landroid/graphics/drawable/Drawable;

    .line 34
    .line 35
    if-eqz v1, :cond_48

    .line 36
    .line 37
    const/16 v5, 0xe

    .line 38
    .line 39
    invoke-interface {v1, v5}, Lk3/e1;->D1(I)Z

    .line 40
    .line 41
    .line 42
    move-result v5

    .line 43
    if-nez v5, :cond_2d

    .line 44
    .line 45
    goto :goto_48

    .line 46
    :cond_2d
    const/4 v3, 0x1

    .line 47
    invoke-virtual {p0, v0, v3}, La6/w;->n(Landroid/view/View;Z)V

    .line 48
    .line 49
    .line 50
    invoke-interface {v1}, Lk3/e1;->W()Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eqz v3, :cond_39

    .line 55
    .line 56
    iget-object v4, p0, La6/w;->E0:Landroid/graphics/drawable/Drawable;

    .line 57
    .line 58
    :cond_39
    invoke-virtual {v0, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 59
    .line 60
    .line 61
    invoke-interface {v1}, Lk3/e1;->W()Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-eqz v1, :cond_44

    .line 66
    .line 67
    iget-object v2, p0, La6/w;->I0:Ljava/lang/String;

    .line 68
    .line 69
    :cond_44
    invoke-virtual {v0, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 70
    .line 71
    .line 72
    return-void

    .line 73
    :cond_48
    :goto_48
    invoke-virtual {p0, v0, v3}, La6/w;->n(Landroid/view/View;Z)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v0, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v0, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    :goto_51
    return-void
.end method

.method public final w()V
    .registers 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, La6/w;->S0:Lk3/e1;

    .line 4
    .line 5
    if-nez v1, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    iget-boolean v2, v0, La6/w;->V0:Z

    .line 9
    .line 10
    iget-object v3, v0, La6/w;->u0:Lk3/m1;

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    const/4 v5, 0x1

    .line 14
    if-eqz v2, :cond_17

    .line 15
    .line 16
    invoke-static {v1, v3}, La6/w;->c(Lk3/e1;Lk3/m1;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_17

    .line 21
    .line 22
    move v2, v5

    .line 23
    goto :goto_18

    .line 24
    :cond_17
    move v2, v4

    .line 25
    :goto_18
    iput-boolean v2, v0, La6/w;->X0:Z

    .line 26
    .line 27
    const-wide/16 v6, 0x0

    .line 28
    .line 29
    iput-wide v6, v0, La6/w;->h1:J

    .line 30
    .line 31
    const/16 v2, 0x11

    .line 32
    .line 33
    invoke-interface {v1, v2}, Lk3/e1;->D1(I)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_2b

    .line 38
    .line 39
    invoke-interface {v1}, Lk3/e1;->U()Lk3/n1;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    goto :goto_2d

    .line 44
    :cond_2b
    sget-object v2, Lk3/n1;->a:Lk3/j1;

    .line 45
    .line 46
    :goto_2d
    invoke-virtual {v2}, Lk3/n1;->p()Z

    .line 47
    .line 48
    .line 49
    move-result v8

    .line 50
    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    if-nez v8, :cond_125

    .line 56
    .line 57
    invoke-interface {v1}, Lk3/e1;->P()I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    iget-boolean v8, v0, La6/w;->X0:Z

    .line 62
    .line 63
    if-eqz v8, :cond_42

    .line 64
    .line 65
    move v11, v4

    .line 66
    goto :goto_43

    .line 67
    :cond_42
    move v11, v1

    .line 68
    :goto_43
    if-eqz v8, :cond_4b

    .line 69
    .line 70
    invoke-virtual {v2}, Lk3/n1;->o()I

    .line 71
    .line 72
    .line 73
    move-result v8

    .line 74
    sub-int/2addr v8, v5

    .line 75
    goto :goto_4c

    .line 76
    :cond_4b
    move v8, v1

    .line 77
    :goto_4c
    move v14, v4

    .line 78
    move-wide v12, v6

    .line 79
    :goto_4e
    if-gt v11, v8, :cond_68

    .line 80
    .line 81
    move-wide v15, v6

    .line 82
    if-ne v11, v1, :cond_59

    .line 83
    .line 84
    invoke-static {v12, v13}, Ln3/l0;->g0(J)J

    .line 85
    .line 86
    .line 87
    move-result-wide v6

    .line 88
    iput-wide v6, v0, La6/w;->h1:J

    .line 89
    .line 90
    :cond_59
    invoke-virtual {v2, v11, v3}, Lk3/n1;->n(ILk3/m1;)V

    .line 91
    .line 92
    .line 93
    iget-wide v6, v3, Lk3/m1;->m:J

    .line 94
    .line 95
    cmp-long v6, v6, v9

    .line 96
    .line 97
    if-nez v6, :cond_6b

    .line 98
    .line 99
    iget-boolean v1, v0, La6/w;->X0:Z

    .line 100
    .line 101
    xor-int/2addr v1, v5

    .line 102
    invoke-static {v1}, Loq/a;->z(Z)V

    .line 103
    .line 104
    .line 105
    :cond_68
    move v2, v5

    .line 106
    goto/16 :goto_123

    .line 107
    .line 108
    :cond_6b
    iget v6, v3, Lk3/m1;->n:I

    .line 109
    .line 110
    :goto_6d
    iget v7, v3, Lk3/m1;->o:I

    .line 111
    .line 112
    if-gt v6, v7, :cond_10f

    .line 113
    .line 114
    iget-object v7, v0, La6/w;->t0:Lk3/k1;

    .line 115
    .line 116
    invoke-virtual {v2, v6, v7, v4}, Lk3/n1;->f(ILk3/k1;Z)Lk3/k1;

    .line 117
    .line 118
    .line 119
    move-wide/from16 v17, v9

    .line 120
    .line 121
    iget-object v9, v7, Lk3/k1;->g:Lk3/c;

    .line 122
    .line 123
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 124
    .line 125
    .line 126
    iget v9, v9, Lk3/c;->a:I

    .line 127
    .line 128
    move v10, v4

    .line 129
    :goto_80
    if-ge v10, v9, :cond_ff

    .line 130
    .line 131
    invoke-virtual {v7, v10}, Lk3/k1;->d(I)J

    .line 132
    .line 133
    .line 134
    iget-wide v4, v7, Lk3/k1;->e:J

    .line 135
    .line 136
    cmp-long v20, v4, v15

    .line 137
    .line 138
    if-ltz v20, :cond_ef

    .line 139
    .line 140
    iget-object v15, v0, La6/w;->d1:[J

    .line 141
    .line 142
    move/from16 v16, v1

    .line 143
    .line 144
    array-length v1, v15

    .line 145
    if-ne v14, v1, :cond_a8

    .line 146
    .line 147
    array-length v1, v15

    .line 148
    if-nez v1, :cond_97

    .line 149
    .line 150
    const/4 v1, 0x1

    .line 151
    goto :goto_9a

    .line 152
    :cond_97
    array-length v1, v15

    .line 153
    mul-int/lit8 v1, v1, 0x2

    .line 154
    .line 155
    :goto_9a
    invoke-static {v15, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 156
    .line 157
    .line 158
    move-result-object v15

    .line 159
    iput-object v15, v0, La6/w;->d1:[J

    .line 160
    .line 161
    iget-object v15, v0, La6/w;->e1:[Z

    .line 162
    .line 163
    invoke-static {v15, v1}, Ljava/util/Arrays;->copyOf([ZI)[Z

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    iput-object v1, v0, La6/w;->e1:[Z

    .line 168
    .line 169
    :cond_a8
    iget-object v1, v0, La6/w;->d1:[J

    .line 170
    .line 171
    add-long/2addr v4, v12

    .line 172
    invoke-static {v4, v5}, Ln3/l0;->g0(J)J

    .line 173
    .line 174
    .line 175
    move-result-wide v4

    .line 176
    aput-wide v4, v1, v14

    .line 177
    .line 178
    iget-object v1, v0, La6/w;->e1:[Z

    .line 179
    .line 180
    iget-object v4, v7, Lk3/k1;->g:Lk3/c;

    .line 181
    .line 182
    invoke-virtual {v4, v10}, Lk3/c;->a(I)Lk3/a;

    .line 183
    .line 184
    .line 185
    move-result-object v4

    .line 186
    iget v5, v4, Lk3/a;->a:I

    .line 187
    .line 188
    const/4 v15, -0x1

    .line 189
    if-ne v5, v15, :cond_c6

    .line 190
    .line 191
    move-object/from16 v21, v1

    .line 192
    .line 193
    move-object/from16 v22, v2

    .line 194
    .line 195
    const/4 v2, 0x1

    .line 196
    const/16 v19, 0x1

    .line 197
    .line 198
    goto :goto_e8

    .line 199
    :cond_c6
    const/4 v15, 0x0

    .line 200
    :goto_c7
    if-ge v15, v5, :cond_e1

    .line 201
    .line 202
    move-object/from16 v21, v1

    .line 203
    .line 204
    iget-object v1, v4, Lk3/a;->e:[I

    .line 205
    .line 206
    aget v1, v1, v15

    .line 207
    .line 208
    move-object/from16 v22, v2

    .line 209
    .line 210
    const/4 v2, 0x1

    .line 211
    if-eqz v1, :cond_de

    .line 212
    .line 213
    if-ne v1, v2, :cond_d7

    .line 214
    .line 215
    goto :goto_de

    .line 216
    :cond_d7
    add-int/lit8 v15, v15, 0x1

    .line 217
    .line 218
    move-object/from16 v1, v21

    .line 219
    .line 220
    move-object/from16 v2, v22

    .line 221
    .line 222
    goto :goto_c7

    .line 223
    :cond_de
    :goto_de
    move/from16 v19, v2

    .line 224
    .line 225
    goto :goto_e8

    .line 226
    :cond_e1
    move-object/from16 v21, v1

    .line 227
    .line 228
    move-object/from16 v22, v2

    .line 229
    .line 230
    const/4 v2, 0x1

    .line 231
    const/16 v19, 0x0

    .line 232
    .line 233
    :goto_e8
    xor-int/lit8 v1, v19, 0x1

    .line 234
    .line 235
    aput-boolean v1, v21, v14

    .line 236
    .line 237
    add-int/lit8 v14, v14, 0x1

    .line 238
    .line 239
    goto :goto_f4

    .line 240
    :cond_ef
    move/from16 v16, v1

    .line 241
    .line 242
    move-object/from16 v22, v2

    .line 243
    .line 244
    const/4 v2, 0x1

    .line 245
    :goto_f4
    add-int/lit8 v10, v10, 0x1

    .line 246
    .line 247
    move v5, v2

    .line 248
    move/from16 v1, v16

    .line 249
    .line 250
    move-object/from16 v2, v22

    .line 251
    .line 252
    const/4 v4, 0x0

    .line 253
    const-wide/16 v15, 0x0

    .line 254
    .line 255
    goto :goto_80

    .line 256
    :cond_ff
    move/from16 v16, v1

    .line 257
    .line 258
    move-object/from16 v22, v2

    .line 259
    .line 260
    move v2, v5

    .line 261
    add-int/lit8 v6, v6, 0x1

    .line 262
    .line 263
    move-wide/from16 v9, v17

    .line 264
    .line 265
    move-object/from16 v2, v22

    .line 266
    .line 267
    const/4 v4, 0x0

    .line 268
    const-wide/16 v15, 0x0

    .line 269
    .line 270
    goto/16 :goto_6d

    .line 271
    .line 272
    :cond_10f
    move/from16 v16, v1

    .line 273
    .line 274
    move-object/from16 v22, v2

    .line 275
    .line 276
    move v2, v5

    .line 277
    move-wide/from16 v17, v9

    .line 278
    .line 279
    iget-wide v4, v3, Lk3/m1;->m:J

    .line 280
    .line 281
    add-long/2addr v12, v4

    .line 282
    add-int/lit8 v11, v11, 0x1

    .line 283
    .line 284
    move v5, v2

    .line 285
    move-object/from16 v2, v22

    .line 286
    .line 287
    const/4 v4, 0x0

    .line 288
    const-wide/16 v6, 0x0

    .line 289
    .line 290
    goto/16 :goto_4e

    .line 291
    .line 292
    :goto_123
    move-wide v6, v12

    .line 293
    goto :goto_141

    .line 294
    :cond_125
    move v2, v5

    .line 295
    move-wide/from16 v17, v9

    .line 296
    .line 297
    const/16 v3, 0x10

    .line 298
    .line 299
    invoke-interface {v1, v3}, Lk3/e1;->D1(I)Z

    .line 300
    .line 301
    .line 302
    move-result v3

    .line 303
    if-eqz v3, :cond_13e

    .line 304
    .line 305
    invoke-interface {v1}, Lk3/e1;->x0()J

    .line 306
    .line 307
    .line 308
    move-result-wide v3

    .line 309
    cmp-long v1, v3, v17

    .line 310
    .line 311
    if-eqz v1, :cond_13e

    .line 312
    .line 313
    invoke-static {v3, v4}, Ln3/l0;->S(J)J

    .line 314
    .line 315
    .line 316
    move-result-wide v6

    .line 317
    :goto_13c
    const/4 v14, 0x0

    .line 318
    goto :goto_141

    .line 319
    :cond_13e
    const-wide/16 v6, 0x0

    .line 320
    .line 321
    goto :goto_13c

    .line 322
    :goto_141
    invoke-static {v6, v7}, Ln3/l0;->g0(J)J

    .line 323
    .line 324
    .line 325
    move-result-wide v3

    .line 326
    iget-object v1, v0, La6/w;->o0:Landroid/widget/TextView;

    .line 327
    .line 328
    if-eqz v1, :cond_154

    .line 329
    .line 330
    iget-object v5, v0, La6/w;->r0:Ljava/lang/StringBuilder;

    .line 331
    .line 332
    iget-object v6, v0, La6/w;->s0:Ljava/util/Formatter;

    .line 333
    .line 334
    invoke-static {v5, v6, v3, v4}, Ln3/l0;->G(Ljava/lang/StringBuilder;Ljava/util/Formatter;J)Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v5

    .line 338
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 339
    .line 340
    .line 341
    :cond_154
    iget-object v1, v0, La6/w;->q0:La6/w0;

    .line 342
    .line 343
    if-eqz v1, :cond_19a

    .line 344
    .line 345
    check-cast v1, La6/h;

    .line 346
    .line 347
    invoke-virtual {v1, v3, v4}, La6/h;->setDuration(J)V

    .line 348
    .line 349
    .line 350
    iget-object v3, v0, La6/w;->f1:[J

    .line 351
    .line 352
    array-length v4, v3

    .line 353
    add-int v5, v14, v4

    .line 354
    .line 355
    iget-object v6, v0, La6/w;->d1:[J

    .line 356
    .line 357
    array-length v7, v6

    .line 358
    if-le v5, v7, :cond_175

    .line 359
    .line 360
    invoke-static {v6, v5}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 361
    .line 362
    .line 363
    move-result-object v6

    .line 364
    iput-object v6, v0, La6/w;->d1:[J

    .line 365
    .line 366
    iget-object v6, v0, La6/w;->e1:[Z

    .line 367
    .line 368
    invoke-static {v6, v5}, Ljava/util/Arrays;->copyOf([ZI)[Z

    .line 369
    .line 370
    .line 371
    move-result-object v6

    .line 372
    iput-object v6, v0, La6/w;->e1:[Z

    .line 373
    .line 374
    :cond_175
    iget-object v6, v0, La6/w;->d1:[J

    .line 375
    .line 376
    const/4 v7, 0x0

    .line 377
    invoke-static {v3, v7, v6, v14, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 378
    .line 379
    .line 380
    iget-object v3, v0, La6/w;->g1:[Z

    .line 381
    .line 382
    iget-object v6, v0, La6/w;->e1:[Z

    .line 383
    .line 384
    invoke-static {v3, v7, v6, v14, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 385
    .line 386
    .line 387
    iget-object v3, v0, La6/w;->d1:[J

    .line 388
    .line 389
    iget-object v4, v0, La6/w;->e1:[Z

    .line 390
    .line 391
    if-eqz v5, :cond_18e

    .line 392
    .line 393
    if-eqz v3, :cond_18d

    .line 394
    .line 395
    if-eqz v4, :cond_18d

    .line 396
    .line 397
    goto :goto_18e

    .line 398
    :cond_18d
    move v2, v7

    .line 399
    :cond_18e
    :goto_18e
    invoke-static {v2}, Loq/a;->n(Z)V

    .line 400
    .line 401
    .line 402
    iput v5, v1, La6/h;->r0:I

    .line 403
    .line 404
    iput-object v3, v1, La6/h;->s0:[J

    .line 405
    .line 406
    iput-object v4, v1, La6/h;->t0:[Z

    .line 407
    .line 408
    invoke-virtual {v1}, La6/h;->e()V

    .line 409
    .line 410
    .line 411
    :cond_19a
    invoke-virtual {v0}, La6/w;->s()V

    .line 412
    .line 413
    .line 414
    return-void
.end method

.method public final x()V
    .registers 12

    .line 1
    iget-object v0, p0, La6/w;->Q:La6/k;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 7
    .line 8
    iput-object v1, v0, La6/k;->d:Ljava/util/List;

    .line 9
    .line 10
    iget-object v2, p0, La6/w;->R:La6/k;

    .line 11
    .line 12
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    iput-object v1, v2, La6/k;->d:Ljava/util/List;

    .line 16
    .line 17
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 18
    .line 19
    iget-object v3, p0, La6/w;->i0:Landroid/widget/ImageView;

    .line 20
    .line 21
    const/4 v4, 0x0

    .line 22
    const/4 v5, 0x1

    .line 23
    if-eqz v1, :cond_ac

    .line 24
    .line 25
    const/16 v6, 0x1e

    .line 26
    .line 27
    invoke-interface {v1, v6}, Lk3/e1;->D1(I)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_ac

    .line 32
    .line 33
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 34
    .line 35
    const/16 v6, 0x1d

    .line 36
    .line 37
    invoke-interface {v1, v6}, Lk3/e1;->D1(I)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-nez v1, :cond_2c

    .line 42
    .line 43
    goto/16 :goto_ac

    .line 44
    .line 45
    :cond_2c
    iget-object v1, p0, La6/w;->S0:Lk3/e1;

    .line 46
    .line 47
    invoke-interface {v1}, Lk3/e1;->J()Lk3/v1;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-virtual {p0, v1, v5}, La6/w;->f(Lk3/v1;I)Lhx/w1;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    iput-object v6, v2, La6/k;->d:Ljava/util/List;

    .line 56
    .line 57
    iget-object v7, v2, La6/k;->g:La6/w;

    .line 58
    .line 59
    iget-object v8, v7, La6/w;->S0:Lk3/e1;

    .line 60
    .line 61
    iget-object v9, v7, La6/w;->O:La6/r;

    .line 62
    .line 63
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    invoke-interface {v8}, Lk3/e1;->Z1()Lk3/t1;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    invoke-virtual {v6}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 71
    .line 72
    .line 73
    move-result v10

    .line 74
    if-eqz v10, :cond_5d

    .line 75
    .line 76
    invoke-virtual {v7}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    const v6, 0x7f1300c2

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    iget-object v6, v9, La6/r;->f:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast v6, [Ljava/lang/String;

    .line 90
    .line 91
    aput-object v2, v6, v5

    .line 92
    .line 93
    goto :goto_96

    .line 94
    :cond_5d
    invoke-virtual {v2, v8}, La6/k;->n(Lk3/t1;)Z

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    if-nez v2, :cond_75

    .line 99
    .line 100
    invoke-virtual {v7}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    const v6, 0x7f1300c1

    .line 105
    .line 106
    .line 107
    invoke-virtual {v2, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    iget-object v6, v9, La6/r;->f:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v6, [Ljava/lang/String;

    .line 114
    .line 115
    aput-object v2, v6, v5

    .line 116
    .line 117
    goto :goto_96

    .line 118
    :cond_75
    move v2, v4

    .line 119
    :goto_76
    iget v7, v6, Lhx/w1;->v:I

    .line 120
    .line 121
    if-ge v2, v7, :cond_96

    .line 122
    .line 123
    invoke-virtual {v6, v2}, Lhx/w1;->get(I)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    check-cast v7, La6/t;

    .line 128
    .line 129
    iget-object v8, v7, La6/t;->a:Lk3/u1;

    .line 130
    .line 131
    iget v10, v7, La6/t;->b:I

    .line 132
    .line 133
    iget-object v8, v8, Lk3/u1;->e:[Z

    .line 134
    .line 135
    aget-boolean v8, v8, v10

    .line 136
    .line 137
    if-eqz v8, :cond_93

    .line 138
    .line 139
    iget-object v2, v7, La6/t;->c:Ljava/lang/String;

    .line 140
    .line 141
    iget-object v6, v9, La6/r;->f:Ljava/lang/Object;

    .line 142
    .line 143
    check-cast v6, [Ljava/lang/String;

    .line 144
    .line 145
    aput-object v2, v6, v5

    .line 146
    .line 147
    goto :goto_96

    .line 148
    :cond_93
    add-int/lit8 v2, v2, 0x1

    .line 149
    .line 150
    goto :goto_76

    .line 151
    :cond_96
    :goto_96
    iget-object v2, p0, La6/w;->d:La6/b0;

    .line 152
    .line 153
    invoke-virtual {v2, v3}, La6/b0;->b(Landroid/view/View;)Z

    .line 154
    .line 155
    .line 156
    move-result v2

    .line 157
    if-eqz v2, :cond_a7

    .line 158
    .line 159
    const/4 v2, 0x3

    .line 160
    invoke-virtual {p0, v1, v2}, La6/w;->f(Lk3/v1;I)Lhx/w1;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    invoke-virtual {v0, v1}, La6/k;->o(Ljava/util/List;)V

    .line 165
    .line 166
    .line 167
    goto :goto_ac

    .line 168
    :cond_a7
    sget-object v1, Lhx/w1;->w:Lhx/w1;

    .line 169
    .line 170
    invoke-virtual {v0, v1}, La6/k;->o(Ljava/util/List;)V

    .line 171
    .line 172
    .line 173
    :cond_ac
    :goto_ac
    invoke-virtual {v0}, La6/k;->b()I

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    if-lez v0, :cond_b4

    .line 178
    .line 179
    move v0, v5

    .line 180
    goto :goto_b5

    .line 181
    :cond_b4
    move v0, v4

    .line 182
    :goto_b5
    invoke-virtual {p0, v3, v0}, La6/w;->n(Landroid/view/View;Z)V

    .line 183
    .line 184
    .line 185
    iget-object v0, p0, La6/w;->O:La6/r;

    .line 186
    .line 187
    invoke-virtual {v0, v5}, La6/r;->n(I)Z

    .line 188
    .line 189
    .line 190
    move-result v1

    .line 191
    if-nez v1, :cond_c6

    .line 192
    .line 193
    invoke-virtual {v0, v4}, La6/r;->n(I)Z

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    if-eqz v0, :cond_c7

    .line 198
    .line 199
    :cond_c6
    move v4, v5

    .line 200
    :cond_c7
    iget-object v0, p0, La6/w;->l0:Landroid/view/View;

    .line 201
    .line 202
    invoke-virtual {p0, v0, v4}, La6/w;->n(Landroid/view/View;Z)V

    .line 203
    .line 204
    .line 205
    return-void
.end method
