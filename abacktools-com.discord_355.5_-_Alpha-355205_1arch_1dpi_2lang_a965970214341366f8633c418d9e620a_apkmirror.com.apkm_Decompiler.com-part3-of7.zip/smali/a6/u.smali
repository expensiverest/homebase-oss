###### Class a6.u (a6.u)
.class public final synthetic La6/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;

.field public final synthetic w:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 6

    .line 1
    iput p5, p0, La6/u;->d:I

    iput-object p1, p0, La6/u;->e:Ljava/lang/Object;

    iput-object p2, p0, La6/u;->i:Ljava/lang/Object;

    iput-object p3, p0, La6/u;->v:Ljava/lang/Object;

    iput-object p4, p0, La6/u;->w:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    .line 1
    iget p1, p0, La6/u;->d:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_ac

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/u;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Ljj/c;

    .line 9
    .line 10
    iget-object v0, p0, La6/u;->i:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Ljava/lang/String;

    .line 13
    .line 14
    iget-object v1, p0, La6/u;->v:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v1, Ljava/lang/String;

    .line 17
    .line 18
    iget-object v2, p0, La6/u;->w:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v2, Ldm/d;

    .line 21
    .line 22
    new-instance v3, Lcom/discord/primitives/MessageId;

    .line 23
    .line 24
    invoke-direct {v3, v0}, Lcom/discord/primitives/MessageId;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    if-eqz v2, :cond_21

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v0, 0x0

    .line 35
    :goto_22
    if-nez v0, :cond_26

    .line 36
    .line 37
    const-string v0, ""

    .line 38
    .line 39
    :cond_26
    invoke-virtual {p1, v3, v1, v0}, Ljj/c;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :pswitch_2a
    iget-object p1, p0, La6/u;->e:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast p1, Lfc/d;

    .line 46
    .line 47
    iget-object v0, p0, La6/u;->i:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v0, Lsb/b;

    .line 50
    .line 51
    iget-object v1, p0, La6/u;->v:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Lw9/h;

    .line 54
    .line 55
    iget-object v2, p0, La6/u;->w:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v2, Ljava/lang/String;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    iget-object p1, v1, Lw9/h;->D:Ljava/lang/String;

    .line 63
    .line 64
    iget-object v3, v1, Lw9/h;->C:Ljava/lang/String;

    .line 65
    .line 66
    iget-object v1, v1, Lw9/h;->L:Ljava/lang/String;

    .line 67
    .line 68
    if-nez v1, :cond_47

    .line 69
    .line 70
    const-string v1, ""

    .line 71
    .line 72
    :cond_47
    invoke-interface {v0, p1, v2, v3, v1}, Lsb/b;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :pswitch_4b
    iget-object p1, p0, La6/u;->e:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast p1, La6/k;

    .line 79
    .line 80
    iget-object v0, p0, La6/u;->i:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, Lk3/e1;

    .line 83
    .line 84
    iget-object v1, p0, La6/u;->v:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v1, Lk3/o1;

    .line 87
    .line 88
    iget-object v2, p0, La6/u;->w:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v2, La6/t;

    .line 91
    .line 92
    const/16 v3, 0x1d

    .line 93
    .line 94
    invoke-interface {v0, v3}, Lk3/e1;->D1(I)Z

    .line 95
    .line 96
    .line 97
    move-result v3

    .line 98
    if-nez v3, :cond_64

    .line 99
    .line 100
    goto :goto_ab

    .line 101
    :cond_64
    invoke-interface {v0}, Lk3/e1;->Z1()Lk3/t1;

    .line 102
    .line 103
    .line 104
    move-result-object v3

    .line 105
    invoke-virtual {v3}, Lk3/t1;->a()Lk3/s1;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    new-instance v4, Lk3/p1;

    .line 110
    .line 111
    iget v5, v2, La6/t;->b:I

    .line 112
    .line 113
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 114
    .line 115
    .line 116
    move-result-object v5

    .line 117
    invoke-static {v5}, Lhx/m0;->v(Ljava/lang/Object;)Lhx/w1;

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    invoke-direct {v4, v1, v5}, Lk3/p1;-><init>(Lk3/o1;Ljava/util/List;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v3, v4}, Lk3/s1;->h(Lk3/p1;)Lk3/s1;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    iget-object v3, v2, La6/t;->a:Lk3/u1;

    .line 129
    .line 130
    iget-object v3, v3, Lk3/u1;->b:Lk3/o1;

    .line 131
    .line 132
    iget v3, v3, Lk3/o1;->c:I

    .line 133
    .line 134
    const/4 v4, 0x0

    .line 135
    invoke-virtual {v1, v3, v4}, Lk3/s1;->l(IZ)Lk3/s1;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    invoke-virtual {v1}, Lk3/s1;->b()Lk3/t1;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    invoke-interface {v0, v1}, Lk3/e1;->N0(Lk3/t1;)V

    .line 144
    .line 145
    .line 146
    iget-object v0, v2, La6/t;->c:Ljava/lang/String;

    .line 147
    .line 148
    iget v1, p1, La6/k;->f:I

    .line 149
    .line 150
    packed-switch v1, :pswitch_data_b4

    .line 151
    .line 152
    .line 153
    goto :goto_a4

    .line 154
    :pswitch_99
    iget-object v1, p1, La6/k;->g:La6/w;

    .line 155
    .line 156
    iget-object v1, v1, La6/w;->O:La6/r;

    .line 157
    .line 158
    iget-object v1, v1, La6/r;->f:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v1, [Ljava/lang/String;

    .line 161
    .line 162
    const/4 v2, 0x1

    .line 163
    aput-object v0, v1, v2

    .line 164
    .line 165
    :goto_a4
    iget-object p1, p1, La6/k;->e:La6/w;

    .line 166
    .line 167
    iget-object p1, p1, La6/w;->T:Landroid/widget/PopupWindow;

    .line 168
    .line 169
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    .line 170
    .line 171
    .line 172
    :goto_ab
    return-void

    .line 173
    :pswitch_data_ac
    .packed-switch 0x0
        :pswitch_4b
        :pswitch_2a
    .end packed-switch

    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    :pswitch_data_b4
    .packed-switch 0x0
        :pswitch_99
    .end packed-switch
.end method
