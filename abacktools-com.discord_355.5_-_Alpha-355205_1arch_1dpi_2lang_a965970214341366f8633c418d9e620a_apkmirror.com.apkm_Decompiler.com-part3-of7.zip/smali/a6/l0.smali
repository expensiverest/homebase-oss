###### Class a6.l0 (a6.l0)
.class public interface abstract La6/l0;
.super Ljava/lang/Object;
.source "SourceFile"
