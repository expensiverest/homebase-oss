###### Class a6.f0 (a6.f0)
.class public final La6/f0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk3/c1;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/f0;->d:I

    iput-object p2, p0, La6/f0;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final L(Lk3/b1;)V
    .registers 4

    .line 1
    iget v0, p0, La6/f0;->d:I

    .line 2
    .line 3
    iget-object v1, p0, La6/f0;->e:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_44

    .line 6
    .line 7
    .line 8
    check-cast v1, Lcom/google/android/gms/internal/fido/f6;

    .line 9
    .line 10
    iget-object p1, v1, Lcom/google/android/gms/internal/fido/f6;->y:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p1, Ln3/z;

    .line 13
    .line 14
    invoke-virtual {p1}, Ln3/z;->a()V

    .line 15
    .line 16
    .line 17
    iget-object p1, v1, Lcom/google/android/gms/internal/fido/f6;->J:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p1, Ln3/a0;

    .line 20
    .line 21
    invoke-virtual {p1}, Ln3/a0;->a()V

    .line 22
    .line 23
    .line 24
    iget-object p1, v1, Lcom/google/android/gms/internal/fido/f6;->K:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Ln3/b0;

    .line 27
    .line 28
    invoke-virtual {p1}, Ln3/b0;->a()V

    .line 29
    .line 30
    .line 31
    iget-object p1, v1, Lcom/google/android/gms/internal/fido/f6;->L:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p1, Ln3/c0;

    .line 34
    .line 35
    invoke-virtual {p1}, Ln3/c0;->a()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_26
    const/16 v0, 0x9

    .line 40
    .line 41
    new-array v0, v0, [I

    .line 42
    .line 43
    fill-array-data v0, :array_4a

    .line 44
    .line 45
    .line 46
    iget-object p1, p1, Lk3/b1;->a:Lk3/u;

    .line 47
    .line 48
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    if-eqz p1, :cond_43

    .line 53
    .line 54
    check-cast v1, La6/g0;

    .line 55
    .line 56
    iget-object p1, v1, La6/g0;->e:Landroid/os/Handler;

    .line 57
    .line 58
    const/4 v0, 0x1

    .line 59
    invoke-virtual {p1, v0}, Landroid/os/Handler;->hasMessages(I)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-nez v1, :cond_43

    .line 64
    .line 65
    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 66
    .line 67
    .line 68
    :cond_43
    return-void

    .line 69
    :pswitch_data_44
    .packed-switch 0x0
        :pswitch_26
    .end packed-switch

    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    :array_4a
    .array-data 4
        0x4
        0x5
        0x7
        0x0
        0xc
        0xb
        0x8
        0x9
        0xe
    .end array-data
.end method
