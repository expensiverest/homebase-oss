###### Class a6.c0 (a6.c0)
.class public final synthetic La6/c0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/c0;->d:I

    iput-object p2, p0, La6/c0;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)Z
    .registers 9

    .line 1
    iget v0, p0, La6/c0;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_fc

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/c0;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Ln3/q;

    .line 9
    .line 10
    iget-object v0, p1, Ln3/q;->b:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :cond_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_49

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Lqt/i;

    .line 27
    .line 28
    iget-object v2, p1, Ln3/q;->j:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v2, Lqt/h;

    .line 31
    .line 32
    iget-boolean v3, v1, Lqt/i;->d:Z

    .line 33
    .line 34
    const/4 v4, 0x0

    .line 35
    if-nez v3, :cond_3d

    .line 36
    .line 37
    iget-boolean v3, v1, Lqt/i;->c:Z

    .line 38
    .line 39
    if-eqz v3, :cond_3d

    .line 40
    .line 41
    iget-object v3, v1, Lqt/i;->b:Lk3/t;

    .line 42
    .line 43
    invoke-virtual {v3}, Lk3/t;->e()Lqt/e;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    new-instance v5, Lk3/t;

    .line 48
    .line 49
    const/4 v6, 0x1

    .line 50
    invoke-direct {v5, v6}, Lk3/t;-><init>(I)V

    .line 51
    .line 52
    .line 53
    iput-object v5, v1, Lqt/i;->b:Lk3/t;

    .line 54
    .line 55
    iput-boolean v4, v1, Lqt/i;->c:Z

    .line 56
    .line 57
    iget-object v1, v1, Lqt/i;->a:Ljava/lang/Object;

    .line 58
    .line 59
    invoke-interface {v2, v1, v3}, Lqt/h;->a(Ljava/lang/Object;Lqt/e;)V

    .line 60
    .line 61
    .line 62
    :cond_3d
    iget-object v1, p1, Ln3/q;->i:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v1, Lqt/u;

    .line 65
    .line 66
    iget-object v1, v1, Lqt/u;->a:Landroid/os/Handler;

    .line 67
    .line 68
    invoke-virtual {v1, v4}, Landroid/os/Handler;->hasMessages(I)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-eqz v1, :cond_f

    .line 73
    .line 74
    :cond_49
    const/4 p1, 0x1

    .line 75
    return p1

    .line 76
    :pswitch_4b
    iget-object v0, p0, La6/c0;->e:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v0, Lcom/google/android/gms/internal/fido/f6;

    .line 79
    .line 80
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    iget p1, p1, Landroid/os/Message;->what:I

    .line 84
    .line 85
    const/4 v1, 0x1

    .line 86
    if-eq p1, v1, :cond_7a

    .line 87
    .line 88
    const/4 v2, 0x2

    .line 89
    if-eq p1, v2, :cond_72

    .line 90
    .line 91
    const/4 v2, 0x3

    .line 92
    if-eq p1, v2, :cond_6a

    .line 93
    .line 94
    const/4 v2, 0x4

    .line 95
    if-eq p1, v2, :cond_62

    .line 96
    .line 97
    const/4 v1, 0x0

    .line 98
    goto :goto_81

    .line 99
    :cond_62
    iget-object p1, v0, Lcom/google/android/gms/internal/fido/f6;->L:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast p1, Ln3/c0;

    .line 102
    .line 103
    invoke-virtual {p1}, Ln3/c0;->a()V

    .line 104
    .line 105
    .line 106
    goto :goto_81

    .line 107
    :cond_6a
    iget-object p1, v0, Lcom/google/android/gms/internal/fido/f6;->K:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast p1, Ln3/b0;

    .line 110
    .line 111
    invoke-virtual {p1}, Ln3/b0;->a()V

    .line 112
    .line 113
    .line 114
    goto :goto_81

    .line 115
    :cond_72
    iget-object p1, v0, Lcom/google/android/gms/internal/fido/f6;->J:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast p1, Ln3/a0;

    .line 118
    .line 119
    invoke-virtual {p1}, Ln3/a0;->a()V

    .line 120
    .line 121
    .line 122
    goto :goto_81

    .line 123
    :cond_7a
    iget-object p1, v0, Lcom/google/android/gms/internal/fido/f6;->y:Ljava/lang/Object;

    .line 124
    .line 125
    check-cast p1, Ln3/z;

    .line 126
    .line 127
    invoke-virtual {p1}, Ln3/z;->a()V

    .line 128
    .line 129
    .line 130
    :goto_81
    return v1

    .line 131
    :pswitch_82
    iget-object p1, p0, La6/c0;->e:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast p1, Ln3/q;

    .line 134
    .line 135
    iget-object v0, p1, Ln3/q;->j:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast v0, Ln3/o;

    .line 138
    .line 139
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 140
    .line 141
    .line 142
    iget-object v1, p1, Ln3/q;->b:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 143
    .line 144
    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    :cond_93
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    const/4 v3, 0x1

    .line 153
    if-eqz v2, :cond_cd

    .line 154
    .line 155
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    check-cast v2, Ln3/p;

    .line 160
    .line 161
    iget-boolean v4, v2, Ln3/p;->d:Z

    .line 162
    .line 163
    if-nez v4, :cond_be

    .line 164
    .line 165
    iget-boolean v4, v2, Ln3/p;->c:Z

    .line 166
    .line 167
    if-eqz v4, :cond_be

    .line 168
    .line 169
    iget-object v4, v2, Ln3/p;->b:Lk3/t;

    .line 170
    .line 171
    invoke-virtual {v4}, Lk3/t;->d()Lk3/u;

    .line 172
    .line 173
    .line 174
    move-result-object v4

    .line 175
    new-instance v5, Lk3/t;

    .line 176
    .line 177
    const/4 v6, 0x0

    .line 178
    invoke-direct {v5, v6}, Lk3/t;-><init>(I)V

    .line 179
    .line 180
    .line 181
    iput-object v5, v2, Ln3/p;->b:Lk3/t;

    .line 182
    .line 183
    const/4 v5, 0x0

    .line 184
    iput-boolean v5, v2, Ln3/p;->c:Z

    .line 185
    .line 186
    iget-object v2, v2, Ln3/p;->a:Ljava/lang/Object;

    .line 187
    .line 188
    invoke-interface {v0, v2, v4}, Ln3/o;->c(Ljava/lang/Object;Lk3/u;)V

    .line 189
    .line 190
    .line 191
    :cond_be
    iget-object v2, p1, Ln3/q;->i:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v2, Ln3/g0;

    .line 194
    .line 195
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 196
    .line 197
    .line 198
    iget-object v2, v2, Ln3/g0;->a:Landroid/os/Handler;

    .line 199
    .line 200
    invoke-virtual {v2, v3}, Landroid/os/Handler;->hasMessages(I)Z

    .line 201
    .line 202
    .line 203
    move-result v2

    .line 204
    if-eqz v2, :cond_93

    .line 205
    .line 206
    :cond_cd
    return v3

    .line 207
    :pswitch_ce
    iget-object v0, p0, La6/c0;->e:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v0, La6/g0;

    .line 210
    .line 211
    iget v1, p1, Landroid/os/Message;->what:I

    .line 212
    .line 213
    const/4 v2, 0x1

    .line 214
    if-eq v1, v2, :cond_f2

    .line 215
    .line 216
    const/4 v3, 0x2

    .line 217
    if-eq v1, v3, :cond_dc

    .line 218
    .line 219
    const/4 v2, 0x0

    .line 220
    goto :goto_fa

    .line 221
    :cond_dc
    iget-object v1, v0, La6/g0;->p:Lk3/e1;

    .line 222
    .line 223
    if-eqz v1, :cond_fa

    .line 224
    .line 225
    iget-boolean v3, v0, La6/g0;->q:Z

    .line 226
    .line 227
    if-eqz v3, :cond_fa

    .line 228
    .line 229
    iget v3, v0, La6/g0;->r:I

    .line 230
    .line 231
    iget v4, p1, Landroid/os/Message;->arg1:I

    .line 232
    .line 233
    if-ne v3, v4, :cond_fa

    .line 234
    .line 235
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 236
    .line 237
    check-cast p1, Landroid/graphics/Bitmap;

    .line 238
    .line 239
    invoke-virtual {v0, v1, p1}, La6/g0;->c(Lk3/e1;Landroid/graphics/Bitmap;)V

    .line 240
    .line 241
    .line 242
    goto :goto_fa

    .line 243
    :cond_f2
    iget-object p1, v0, La6/g0;->p:Lk3/e1;

    .line 244
    .line 245
    if-eqz p1, :cond_fa

    .line 246
    .line 247
    const/4 v1, 0x0

    .line 248
    invoke-virtual {v0, p1, v1}, La6/g0;->c(Lk3/e1;Landroid/graphics/Bitmap;)V

    .line 249
    .line 250
    .line 251
    :cond_fa
    :goto_fa
    return v2

    .line 252
    nop

    .line 253
    :pswitch_data_fc
    .packed-switch 0x0
        :pswitch_ce
        :pswitch_82
        :pswitch_4b
    .end packed-switch
.end method
