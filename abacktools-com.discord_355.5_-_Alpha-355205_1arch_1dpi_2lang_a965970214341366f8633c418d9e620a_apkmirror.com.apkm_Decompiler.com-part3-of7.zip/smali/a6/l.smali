###### Class a6.l (a6.l)
.class public final La6/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk3/c1;
.implements Landroid/view/View$OnClickListener;
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field public final synthetic d:La6/w;


# direct methods
.method public constructor <init>(La6/w;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La6/l;->d:La6/w;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final L(Lk3/b1;)V
    .registers 7

    .line 1
    const/4 v0, 0x4

    .line 2
    const/4 v1, 0x5

    .line 3
    const/16 v2, 0xd

    .line 4
    .line 5
    filled-new-array {v0, v1, v2}, [I

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    iget-object p1, p1, Lk3/b1;->a:Lk3/u;

    .line 10
    .line 11
    invoke-virtual {p1, v3}, Lk3/u;->a([I)Z

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    iget-object v4, p0, La6/l;->d:La6/w;

    .line 16
    .line 17
    if-eqz v3, :cond_15

    .line 18
    .line 19
    invoke-virtual {v4}, La6/w;->q()V

    .line 20
    .line 21
    .line 22
    :cond_15
    const/4 v3, 0x7

    .line 23
    filled-new-array {v0, v1, v3, v2}, [I

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_23

    .line 32
    .line 33
    invoke-virtual {v4}, La6/w;->s()V

    .line 34
    .line 35
    .line 36
    :cond_23
    const/16 v0, 0x8

    .line 37
    .line 38
    filled-new-array {v0, v2}, [I

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_32

    .line 47
    .line 48
    invoke-virtual {v4}, La6/w;->t()V

    .line 49
    .line 50
    .line 51
    :cond_32
    const/16 v0, 0x9

    .line 52
    .line 53
    filled-new-array {v0, v2}, [I

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_41

    .line 62
    .line 63
    invoke-virtual {v4}, La6/w;->v()V

    .line 64
    .line 65
    .line 66
    :cond_41
    new-array v0, v3, [I

    .line 67
    .line 68
    fill-array-data v0, :array_7e

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_4f

    .line 76
    .line 77
    invoke-virtual {v4}, La6/w;->p()V

    .line 78
    .line 79
    .line 80
    :cond_4f
    const/16 v0, 0xb

    .line 81
    .line 82
    const/4 v1, 0x0

    .line 83
    filled-new-array {v0, v1, v2}, [I

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_5f

    .line 92
    .line 93
    invoke-virtual {v4}, La6/w;->w()V

    .line 94
    .line 95
    .line 96
    :cond_5f
    const/16 v0, 0xc

    .line 97
    .line 98
    filled-new-array {v0, v2}, [I

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-eqz v0, :cond_6e

    .line 107
    .line 108
    invoke-virtual {v4}, La6/w;->r()V

    .line 109
    .line 110
    .line 111
    :cond_6e
    const/4 v0, 0x2

    .line 112
    filled-new-array {v0, v2}, [I

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    invoke-virtual {p1, v0}, Lk3/u;->a([I)Z

    .line 117
    .line 118
    .line 119
    move-result p1

    .line 120
    if-eqz p1, :cond_7c

    .line 121
    .line 122
    invoke-virtual {v4}, La6/w;->x()V

    .line 123
    .line 124
    .line 125
    :cond_7c
    return-void

    .line 126
    nop

    .line 127
    :array_7e
    .array-data 4
        0x8
        0x9
        0xb
        0x0
        0x10
        0x11
        0xd
    .end array-data
.end method

.method public final onClick(Landroid/view/View;)V
    .registers 11

    .line 1
    iget-object v0, p0, La6/l;->d:La6/w;

    .line 2
    .line 3
    iget-object v1, v0, La6/w;->i0:Landroid/widget/ImageView;

    .line 4
    .line 5
    iget-object v2, v0, La6/w;->n0:Landroid/view/View;

    .line 6
    .line 7
    iget-object v3, v0, La6/w;->m0:Landroid/view/View;

    .line 8
    .line 9
    iget-object v4, v0, La6/w;->l0:Landroid/view/View;

    .line 10
    .line 11
    iget-object v5, v0, La6/w;->d:La6/b0;

    .line 12
    .line 13
    iget-object v6, v0, La6/w;->S0:Lk3/e1;

    .line 14
    .line 15
    if-nez v6, :cond_12

    .line 16
    .line 17
    goto/16 :goto_e3

    .line 18
    .line 19
    :cond_12
    invoke-virtual {v5}, La6/b0;->g()V

    .line 20
    .line 21
    .line 22
    iget-object v7, v0, La6/w;->W:Landroid/widget/ImageView;

    .line 23
    .line 24
    if-ne v7, p1, :cond_25

    .line 25
    .line 26
    const/16 p1, 0x9

    .line 27
    .line 28
    invoke-interface {v6, p1}, Lk3/e1;->D1(I)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_e3

    .line 33
    .line 34
    invoke-interface {v6}, Lk3/e1;->f2()V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_25
    iget-object v7, v0, La6/w;->V:Landroid/widget/ImageView;

    .line 39
    .line 40
    if-ne v7, p1, :cond_34

    .line 41
    .line 42
    const/4 p1, 0x7

    .line 43
    invoke-interface {v6, p1}, Lk3/e1;->D1(I)Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    if-eqz p1, :cond_e3

    .line 48
    .line 49
    invoke-interface {v6}, Lk3/e1;->c1()V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_34
    iget-object v7, v0, La6/w;->b0:Landroid/view/View;

    .line 54
    .line 55
    if-ne v7, p1, :cond_4b

    .line 56
    .line 57
    invoke-interface {v6}, Lk3/e1;->I()I

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    const/4 v0, 0x4

    .line 62
    if-eq p1, v0, :cond_e3

    .line 63
    .line 64
    const/16 p1, 0xc

    .line 65
    .line 66
    invoke-interface {v6, p1}, Lk3/e1;->D1(I)Z

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-eqz p1, :cond_e3

    .line 71
    .line 72
    invoke-interface {v6}, Lk3/e1;->g2()V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :cond_4b
    iget-object v7, v0, La6/w;->c0:Landroid/view/View;

    .line 77
    .line 78
    if-ne v7, p1, :cond_5b

    .line 79
    .line 80
    const/16 p1, 0xb

    .line 81
    .line 82
    invoke-interface {v6, p1}, Lk3/e1;->D1(I)Z

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    if-eqz p1, :cond_e3

    .line 87
    .line 88
    invoke-interface {v6}, Lk3/e1;->h2()V

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :cond_5b
    iget-object v7, v0, La6/w;->a0:Landroid/widget/ImageView;

    .line 93
    .line 94
    if-ne v7, p1, :cond_6f

    .line 95
    .line 96
    iget-boolean p1, v0, La6/w;->W0:Z

    .line 97
    .line 98
    invoke-static {v6, p1}, Ln3/l0;->c0(Lk3/e1;Z)Z

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    if-eqz p1, :cond_6b

    .line 103
    .line 104
    invoke-static {v6}, Ln3/l0;->K(Lk3/e1;)Z

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :cond_6b
    invoke-static {v6}, Ln3/l0;->J(Lk3/e1;)Z

    .line 109
    .line 110
    .line 111
    return-void

    .line 112
    :cond_6f
    iget-object v7, v0, La6/w;->f0:Landroid/widget/ImageView;

    .line 113
    .line 114
    const/4 v8, 0x1

    .line 115
    if-ne v7, p1, :cond_a3

    .line 116
    .line 117
    const/16 p1, 0xf

    .line 118
    .line 119
    invoke-interface {v6, p1}, Lk3/e1;->D1(I)Z

    .line 120
    .line 121
    .line 122
    move-result p1

    .line 123
    if-eqz p1, :cond_e3

    .line 124
    .line 125
    invoke-interface {v6}, Lk3/e1;->T()I

    .line 126
    .line 127
    .line 128
    move-result p1

    .line 129
    iget v0, v0, La6/w;->c1:I

    .line 130
    .line 131
    move v1, v8

    .line 132
    :goto_83
    const/4 v2, 0x2

    .line 133
    if-gt v1, v2, :cond_9f

    .line 134
    .line 135
    add-int v3, p1, v1

    .line 136
    .line 137
    rem-int/lit8 v3, v3, 0x3

    .line 138
    .line 139
    if-eqz v3, :cond_9e

    .line 140
    .line 141
    if-eq v3, v8, :cond_96

    .line 142
    .line 143
    if-eq v3, v2, :cond_91

    .line 144
    .line 145
    goto :goto_9b

    .line 146
    :cond_91
    and-int/lit8 v2, v0, 0x2

    .line 147
    .line 148
    if-eqz v2, :cond_9b

    .line 149
    .line 150
    goto :goto_9e

    .line 151
    :cond_96
    and-int/lit8 v2, v0, 0x1

    .line 152
    .line 153
    if-eqz v2, :cond_9b

    .line 154
    .line 155
    goto :goto_9e

    .line 156
    :cond_9b
    :goto_9b
    add-int/lit8 v1, v1, 0x1

    .line 157
    .line 158
    goto :goto_83

    .line 159
    :cond_9e
    :goto_9e
    move p1, v3

    .line 160
    :cond_9f
    invoke-interface {v6, p1}, Lk3/e1;->Q(I)V

    .line 161
    .line 162
    .line 163
    return-void

    .line 164
    :cond_a3
    iget-object v7, v0, La6/w;->g0:Landroid/widget/ImageView;

    .line 165
    .line 166
    if-ne v7, p1, :cond_b8

    .line 167
    .line 168
    const/16 p1, 0xe

    .line 169
    .line 170
    invoke-interface {v6, p1}, Lk3/e1;->D1(I)Z

    .line 171
    .line 172
    .line 173
    move-result p1

    .line 174
    if-eqz p1, :cond_e3

    .line 175
    .line 176
    invoke-interface {v6}, Lk3/e1;->W()Z

    .line 177
    .line 178
    .line 179
    move-result p1

    .line 180
    xor-int/2addr p1, v8

    .line 181
    invoke-interface {v6, p1}, Lk3/e1;->q(Z)V

    .line 182
    .line 183
    .line 184
    return-void

    .line 185
    :cond_b8
    if-ne v4, p1, :cond_c3

    .line 186
    .line 187
    invoke-virtual {v5}, La6/b0;->f()V

    .line 188
    .line 189
    .line 190
    iget-object p1, v0, La6/w;->O:La6/r;

    .line 191
    .line 192
    invoke-virtual {v0, p1, v4}, La6/w;->e(Le6/n0;Landroid/view/View;)V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    :cond_c3
    if-ne v3, p1, :cond_ce

    .line 197
    .line 198
    invoke-virtual {v5}, La6/b0;->f()V

    .line 199
    .line 200
    .line 201
    iget-object p1, v0, La6/w;->P:La6/o;

    .line 202
    .line 203
    invoke-virtual {v0, p1, v3}, La6/w;->e(Le6/n0;Landroid/view/View;)V

    .line 204
    .line 205
    .line 206
    return-void

    .line 207
    :cond_ce
    if-ne v2, p1, :cond_d9

    .line 208
    .line 209
    invoke-virtual {v5}, La6/b0;->f()V

    .line 210
    .line 211
    .line 212
    iget-object p1, v0, La6/w;->R:La6/k;

    .line 213
    .line 214
    invoke-virtual {v0, p1, v2}, La6/w;->e(Le6/n0;Landroid/view/View;)V

    .line 215
    .line 216
    .line 217
    return-void

    .line 218
    :cond_d9
    if-ne v1, p1, :cond_e3

    .line 219
    .line 220
    invoke-virtual {v5}, La6/b0;->f()V

    .line 221
    .line 222
    .line 223
    iget-object p1, v0, La6/w;->Q:La6/k;

    .line 224
    .line 225
    invoke-virtual {v0, p1, v1}, La6/w;->e(Le6/n0;Landroid/view/View;)V

    .line 226
    .line 227
    .line 228
    :cond_e3
    :goto_e3
    return-void
.end method

.method public final onDismiss()V
    .registers 3

    .line 1
    iget-object v0, p0, La6/l;->d:La6/w;

    .line 2
    .line 3
    iget-boolean v1, v0, La6/w;->i1:Z

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    iget-object v0, v0, La6/w;->d:La6/b0;

    .line 8
    .line 9
    invoke-virtual {v0}, La6/b0;->g()V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method
