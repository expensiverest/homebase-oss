###### Class a6.o (a6.o)
.class public final La6/o;
.super Le6/n0;
.source "SourceFile"


# instance fields
.field public final d:[Ljava/lang/String;

.field public final e:[F

.field public f:I

.field public final synthetic g:La6/w;


# direct methods
.method public constructor <init>(La6/w;[Ljava/lang/String;[F)V
    .registers 4

    .line 1
    iput-object p1, p0, La6/o;->g:La6/w;

    .line 2
    .line 3
    invoke-direct {p0}, Le6/n0;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, La6/o;->d:[Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, La6/o;->e:[F

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final b()I
    .registers 2

    .line 1
    iget-object v0, p0, La6/o;->d:[Ljava/lang/String;

    .line 2
    .line 3
    array-length v0, v0

    .line 4
    return v0
.end method

.method public final f(Le6/l1;I)V
    .registers 7

    .line 1
    check-cast p1, La6/s;

    .line 2
    .line 3
    iget-object v0, p1, La6/s;->v:Landroid/view/View;

    .line 4
    .line 5
    iget-object v1, p1, Le6/l1;->a:Landroid/view/View;

    .line 6
    .line 7
    iget-object v2, p0, La6/o;->d:[Ljava/lang/String;

    .line 8
    .line 9
    array-length v3, v2

    .line 10
    if-ge p2, v3, :cond_12

    .line 11
    .line 12
    iget-object p1, p1, La6/s;->u:Landroid/widget/TextView;

    .line 13
    .line 14
    aget-object v2, v2, p2

    .line 15
    .line 16
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 17
    .line 18
    .line 19
    :cond_12
    iget p1, p0, La6/o;->f:I

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    if-ne p2, p1, :cond_1f

    .line 23
    .line 24
    const/4 p1, 0x1

    .line 25
    invoke-virtual {v1, p1}, Landroid/view/View;->setSelected(Z)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    goto :goto_26

    .line 32
    :cond_1f
    invoke-virtual {v1, v2}, Landroid/view/View;->setSelected(Z)V

    .line 33
    .line 34
    .line 35
    const/4 p1, 0x4

    .line 36
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 37
    .line 38
    .line 39
    :goto_26
    new-instance p1, La6/n;

    .line 40
    .line 41
    invoke-direct {p1, p0, p2}, La6/n;-><init>(La6/o;I)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final h(Landroid/view/ViewGroup;I)Le6/l1;
    .registers 5

    .line 1
    iget-object p2, p0, La6/o;->g:La6/w;

    .line 2
    .line 3
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    const v0, 0x7f0d005c

    .line 12
    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-virtual {p2, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    new-instance p2, La6/s;

    .line 20
    .line 21
    invoke-direct {p2, p1}, La6/s;-><init>(Landroid/view/View;)V

    .line 22
    .line 23
    .line 24
    return-object p2
.end method

###### Class a6.n (a6.n)
.class public final synthetic La6/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic d:La6/o;

.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(La6/o;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La6/n;->d:La6/o;

    iput p2, p0, La6/n;->e:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 1
    iget-object p1, p0, La6/n;->d:La6/o;

    .line 2
    .line 3
    iget-object v0, p1, La6/o;->g:La6/w;

    .line 4
    .line 5
    iget v1, p1, La6/o;->f:I

    .line 6
    .line 7
    iget v2, p0, La6/n;->e:I

    .line 8
    .line 9
    if-eq v2, v1, :cond_11

    .line 10
    .line 11
    iget-object p1, p1, La6/o;->e:[F

    .line 12
    .line 13
    aget p1, p1, v2

    .line 14
    .line 15
    invoke-static {v0, p1}, La6/w;->b(La6/w;F)V

    .line 16
    .line 17
    .line 18
    :cond_11
    iget-object p1, v0, La6/w;->T:Landroid/widget/PopupWindow;

    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    .line 21
    .line 22
    .line 23
    return-void
.end method
