###### Class a6.d (a6.d)
.class public final La6/d;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements La6/v0;


# instance fields
.field public final d:Ljava/util/ArrayList;

.field public e:Ljava/util/List;

.field public i:F

.field public v:La6/e;

.field public w:F


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .registers 3

    .line 1
    const/4 p2, 0x0

    .line 2
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 3
    .line 4
    .line 5
    new-instance p1, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, La6/d;->d:Ljava/util/ArrayList;

    .line 11
    .line 12
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 13
    .line 14
    iput-object p1, p0, La6/d;->e:Ljava/util/List;

    .line 15
    .line 16
    const p1, 0x3d5a511a    # 0.0533f

    .line 17
    .line 18
    .line 19
    iput p1, p0, La6/d;->i:F

    .line 20
    .line 21
    sget-object p1, La6/e;->g:La6/e;

    .line 22
    .line 23
    iput-object p1, p0, La6/d;->v:La6/e;

    .line 24
    .line 25
    const p1, 0x3da3d70a    # 0.08f

    .line 26
    .line 27
    .line 28
    iput p1, p0, La6/d;->w:F

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;La6/e;FF)V
    .registers 5

    .line 1
    iput-object p1, p0, La6/d;->e:Ljava/util/List;

    .line 2
    .line 3
    iput-object p2, p0, La6/d;->v:La6/e;

    .line 4
    .line 5
    iput p3, p0, La6/d;->i:F

    .line 6
    .line 7
    iput p4, p0, La6/d;->w:F

    .line 8
    .line 9
    :goto_8
    iget-object p2, p0, La6/d;->d:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    .line 12
    .line 13
    .line 14
    move-result p3

    .line 15
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 16
    .line 17
    .line 18
    move-result p4

    .line 19
    if-ge p3, p4, :cond_21

    .line 20
    .line 21
    new-instance p3, La6/u0;

    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object p4

    .line 27
    invoke-direct {p3, p4}, La6/u0;-><init>(Landroid/content/Context;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    goto :goto_8

    .line 34
    :cond_21
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 49

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, La6/d;->e:Ljava/util/List;

    .line 6
    .line 7
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-eqz v3, :cond_e

    .line 12
    .line 13
    goto/16 :goto_63a

    .line 14
    .line 15
    :cond_e
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    sub-int/2addr v6, v7

    .line 36
    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    .line 37
    .line 38
    .line 39
    move-result v7

    .line 40
    sub-int v7, v3, v7

    .line 41
    .line 42
    if-le v7, v5, :cond_63a

    .line 43
    .line 44
    if-gt v6, v4, :cond_2f

    .line 45
    .line 46
    goto/16 :goto_63a

    .line 47
    .line 48
    :cond_2f
    sub-int v8, v7, v5

    .line 49
    .line 50
    iget v9, v0, La6/d;->i:F

    .line 51
    .line 52
    const/4 v10, 0x0

    .line 53
    invoke-static {v9, v10, v3, v8}, Lcom/facebook/imagepipeline/nativecode/c;->t0(FIII)F

    .line 54
    .line 55
    .line 56
    move-result v9

    .line 57
    const/4 v11, 0x0

    .line 58
    cmpg-float v12, v9, v11

    .line 59
    .line 60
    if-gtz v12, :cond_3f

    .line 61
    .line 62
    goto/16 :goto_63a

    .line 63
    .line 64
    :cond_3f
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 65
    .line 66
    .line 67
    move-result v12

    .line 68
    move v13, v10

    .line 69
    :goto_44
    if-ge v13, v12, :cond_63a

    .line 70
    .line 71
    invoke-interface {v2, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v14

    .line 75
    check-cast v14, Lm3/b;

    .line 76
    .line 77
    iget v15, v14, Lm3/b;->p:I

    .line 78
    .line 79
    move/from16 v16, v11

    .line 80
    .line 81
    const/high16 v17, 0x3f800000    # 1.0f

    .line 82
    .line 83
    const/high16 v11, -0x80000000

    .line 84
    .line 85
    if-eq v15, v11, :cond_90

    .line 86
    .line 87
    invoke-virtual {v14}, Lm3/b;->a()Lm3/a;

    .line 88
    .line 89
    .line 90
    move-result-object v15

    .line 91
    iget v10, v14, Lm3/b;->e:F

    .line 92
    .line 93
    move-object/from16 v21, v2

    .line 94
    .line 95
    const v2, -0x800001

    .line 96
    .line 97
    .line 98
    iput v2, v15, Lm3/a;->h:F

    .line 99
    .line 100
    iput v11, v15, Lm3/a;->i:I

    .line 101
    .line 102
    const/4 v2, 0x0

    .line 103
    iput-object v2, v15, Lm3/a;->c:Landroid/text/Layout$Alignment;

    .line 104
    .line 105
    iget v11, v14, Lm3/b;->f:I

    .line 106
    .line 107
    if-nez v11, :cond_74

    .line 108
    .line 109
    sub-float v10, v17, v10

    .line 110
    .line 111
    iput v10, v15, Lm3/a;->e:F

    .line 112
    .line 113
    const/4 v11, 0x0

    .line 114
    iput v11, v15, Lm3/a;->f:I

    .line 115
    .line 116
    goto :goto_7d

    .line 117
    :cond_74
    const/4 v11, 0x0

    .line 118
    neg-float v10, v10

    .line 119
    sub-float v10, v10, v17

    .line 120
    .line 121
    iput v10, v15, Lm3/a;->e:F

    .line 122
    .line 123
    const/4 v10, 0x1

    .line 124
    iput v10, v15, Lm3/a;->f:I

    .line 125
    .line 126
    :goto_7d
    iget v10, v14, Lm3/b;->g:I

    .line 127
    .line 128
    if-eqz v10, :cond_88

    .line 129
    .line 130
    const/4 v14, 0x2

    .line 131
    if-eq v10, v14, :cond_85

    .line 132
    .line 133
    goto :goto_8b

    .line 134
    :cond_85
    iput v11, v15, Lm3/a;->g:I

    .line 135
    .line 136
    goto :goto_8b

    .line 137
    :cond_88
    const/4 v14, 0x2

    .line 138
    iput v14, v15, Lm3/a;->g:I

    .line 139
    .line 140
    :goto_8b
    invoke-virtual {v15}, Lm3/a;->a()Lm3/b;

    .line 141
    .line 142
    .line 143
    move-result-object v14

    .line 144
    goto :goto_93

    .line 145
    :cond_90
    move-object/from16 v21, v2

    .line 146
    .line 147
    const/4 v2, 0x0

    .line 148
    :goto_93
    iget v10, v14, Lm3/b;->n:I

    .line 149
    .line 150
    iget v11, v14, Lm3/b;->o:F

    .line 151
    .line 152
    invoke-static {v11, v10, v3, v8}, Lcom/facebook/imagepipeline/nativecode/c;->t0(FIII)F

    .line 153
    .line 154
    .line 155
    move-result v10

    .line 156
    iget-object v11, v0, La6/d;->d:Ljava/util/ArrayList;

    .line 157
    .line 158
    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v11

    .line 162
    check-cast v11, La6/u0;

    .line 163
    .line 164
    iget-object v15, v0, La6/d;->v:La6/e;

    .line 165
    .line 166
    iget v2, v0, La6/d;->w:F

    .line 167
    .line 168
    iget-object v0, v11, La6/u0;->f:Landroid/text/TextPaint;

    .line 169
    .line 170
    move/from16 v30, v3

    .line 171
    .line 172
    iget-object v3, v14, Lm3/b;->d:Landroid/graphics/Bitmap;

    .line 173
    .line 174
    move/from16 v31, v8

    .line 175
    .line 176
    iget v8, v14, Lm3/b;->k:F

    .line 177
    .line 178
    move/from16 v32, v12

    .line 179
    .line 180
    iget v12, v14, Lm3/b;->j:F

    .line 181
    .line 182
    move/from16 v33, v13

    .line 183
    .line 184
    iget v13, v14, Lm3/b;->i:I

    .line 185
    .line 186
    move/from16 v22, v2

    .line 187
    .line 188
    iget v2, v14, Lm3/b;->h:F

    .line 189
    .line 190
    move/from16 v23, v10

    .line 191
    .line 192
    iget v10, v14, Lm3/b;->g:I

    .line 193
    .line 194
    move/from16 v34, v9

    .line 195
    .line 196
    iget v9, v14, Lm3/b;->f:I

    .line 197
    .line 198
    move-object/from16 v24, v0

    .line 199
    .line 200
    iget v0, v14, Lm3/b;->e:F

    .line 201
    .line 202
    move/from16 v25, v8

    .line 203
    .line 204
    iget-object v8, v14, Lm3/b;->b:Landroid/text/Layout$Alignment;

    .line 205
    .line 206
    move/from16 v26, v12

    .line 207
    .line 208
    iget-object v12, v14, Lm3/b;->a:Ljava/lang/CharSequence;

    .line 209
    .line 210
    move/from16 v27, v13

    .line 211
    .line 212
    if-nez v3, :cond_d7

    .line 213
    .line 214
    const/4 v13, 0x1

    .line 215
    goto :goto_d8

    .line 216
    :cond_d7
    const/4 v13, 0x0

    .line 217
    :goto_d8
    if-eqz v13, :cond_f0

    .line 218
    .line 219
    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 220
    .line 221
    .line 222
    move-result v28

    .line 223
    if-eqz v28, :cond_e4

    .line 224
    .line 225
    :goto_e0
    move v3, v7

    .line 226
    const/4 v15, 0x0

    .line 227
    goto/16 :goto_626

    .line 228
    .line 229
    :cond_e4
    move/from16 v28, v2

    .line 230
    .line 231
    iget-boolean v2, v14, Lm3/b;->l:Z

    .line 232
    .line 233
    if-eqz v2, :cond_ed

    .line 234
    .line 235
    iget v2, v14, Lm3/b;->m:I

    .line 236
    .line 237
    goto :goto_f4

    .line 238
    :cond_ed
    iget v2, v15, La6/e;->c:I

    .line 239
    .line 240
    goto :goto_f4

    .line 241
    :cond_f0
    move/from16 v28, v2

    .line 242
    .line 243
    const/high16 v2, -0x1000000

    .line 244
    .line 245
    :goto_f4
    iget-object v14, v11, La6/u0;->i:Ljava/lang/CharSequence;

    .line 246
    .line 247
    if-eq v14, v12, :cond_105

    .line 248
    .line 249
    if-eqz v14, :cond_101

    .line 250
    .line 251
    invoke-virtual {v14, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 252
    .line 253
    .line 254
    move-result v14

    .line 255
    if-eqz v14, :cond_101

    .line 256
    .line 257
    goto :goto_105

    .line 258
    :cond_101
    move/from16 v29, v10

    .line 259
    .line 260
    goto/16 :goto_19e

    .line 261
    .line 262
    :cond_105
    :goto_105
    iget-object v14, v11, La6/u0;->j:Landroid/text/Layout$Alignment;

    .line 263
    .line 264
    invoke-static {v14, v8}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 265
    .line 266
    .line 267
    move-result v14

    .line 268
    if-eqz v14, :cond_101

    .line 269
    .line 270
    iget-object v14, v11, La6/u0;->k:Landroid/graphics/Bitmap;

    .line 271
    .line 272
    if-ne v14, v3, :cond_101

    .line 273
    .line 274
    iget v14, v11, La6/u0;->l:F

    .line 275
    .line 276
    cmpl-float v14, v14, v0

    .line 277
    .line 278
    if-nez v14, :cond_101

    .line 279
    .line 280
    iget v14, v11, La6/u0;->m:I

    .line 281
    .line 282
    if-ne v14, v9, :cond_101

    .line 283
    .line 284
    iget v14, v11, La6/u0;->n:I

    .line 285
    .line 286
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 287
    .line 288
    .line 289
    move-result-object v14

    .line 290
    move/from16 v29, v10

    .line 291
    .line 292
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 293
    .line 294
    .line 295
    move-result-object v10

    .line 296
    invoke-virtual {v14, v10}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 297
    .line 298
    .line 299
    move-result v10

    .line 300
    if-eqz v10, :cond_19e

    .line 301
    .line 302
    iget v10, v11, La6/u0;->o:F

    .line 303
    .line 304
    cmpl-float v10, v10, v28

    .line 305
    .line 306
    if-nez v10, :cond_19e

    .line 307
    .line 308
    iget v10, v11, La6/u0;->p:I

    .line 309
    .line 310
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 311
    .line 312
    .line 313
    move-result-object v10

    .line 314
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 315
    .line 316
    .line 317
    move-result-object v14

    .line 318
    invoke-virtual {v10, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v10

    .line 322
    if-eqz v10, :cond_19e

    .line 323
    .line 324
    iget v10, v11, La6/u0;->q:F

    .line 325
    .line 326
    cmpl-float v10, v10, v26

    .line 327
    .line 328
    if-nez v10, :cond_19e

    .line 329
    .line 330
    iget v10, v11, La6/u0;->r:F

    .line 331
    .line 332
    cmpl-float v10, v10, v25

    .line 333
    .line 334
    if-nez v10, :cond_19e

    .line 335
    .line 336
    iget v10, v11, La6/u0;->s:I

    .line 337
    .line 338
    iget v14, v15, La6/e;->a:I

    .line 339
    .line 340
    if-ne v10, v14, :cond_19e

    .line 341
    .line 342
    iget v10, v11, La6/u0;->t:I

    .line 343
    .line 344
    iget v14, v15, La6/e;->b:I

    .line 345
    .line 346
    if-ne v10, v14, :cond_19e

    .line 347
    .line 348
    iget v10, v11, La6/u0;->u:I

    .line 349
    .line 350
    if-ne v10, v2, :cond_19e

    .line 351
    .line 352
    iget v10, v11, La6/u0;->w:I

    .line 353
    .line 354
    iget v14, v15, La6/e;->d:I

    .line 355
    .line 356
    if-ne v10, v14, :cond_19e

    .line 357
    .line 358
    iget v10, v11, La6/u0;->v:I

    .line 359
    .line 360
    iget v14, v15, La6/e;->e:I

    .line 361
    .line 362
    if-ne v10, v14, :cond_19e

    .line 363
    .line 364
    invoke-virtual/range {v24 .. v24}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    .line 365
    .line 366
    .line 367
    move-result-object v10

    .line 368
    iget-object v14, v15, La6/e;->f:Landroid/graphics/Typeface;

    .line 369
    .line 370
    invoke-static {v10, v14}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 371
    .line 372
    .line 373
    move-result v10

    .line 374
    if-eqz v10, :cond_19e

    .line 375
    .line 376
    iget v10, v11, La6/u0;->x:F

    .line 377
    .line 378
    cmpl-float v10, v10, v34

    .line 379
    .line 380
    if-nez v10, :cond_19e

    .line 381
    .line 382
    iget v10, v11, La6/u0;->y:F

    .line 383
    .line 384
    cmpl-float v10, v10, v23

    .line 385
    .line 386
    if-nez v10, :cond_19e

    .line 387
    .line 388
    iget v10, v11, La6/u0;->z:F

    .line 389
    .line 390
    cmpl-float v10, v10, v22

    .line 391
    .line 392
    if-nez v10, :cond_19e

    .line 393
    .line 394
    iget v10, v11, La6/u0;->A:I

    .line 395
    .line 396
    if-ne v10, v4, :cond_19e

    .line 397
    .line 398
    iget v10, v11, La6/u0;->B:I

    .line 399
    .line 400
    if-ne v10, v5, :cond_19e

    .line 401
    .line 402
    iget v10, v11, La6/u0;->C:I

    .line 403
    .line 404
    if-ne v10, v6, :cond_19e

    .line 405
    .line 406
    iget v10, v11, La6/u0;->D:I

    .line 407
    .line 408
    if-ne v10, v7, :cond_19e

    .line 409
    .line 410
    invoke-virtual {v11, v1, v13}, La6/u0;->a(Landroid/graphics/Canvas;Z)V

    .line 411
    .line 412
    .line 413
    goto/16 :goto_e0

    .line 414
    .line 415
    :cond_19e
    :goto_19e
    sget-object v10, La6/c;->a:Lcom/google/android/gms/internal/fido/f8;

    .line 416
    .line 417
    if-nez v12, :cond_1aa

    .line 418
    .line 419
    :cond_1a2
    move/from16 v40, v6

    .line 420
    .line 421
    move/from16 v36, v7

    .line 422
    .line 423
    move/from16 v35, v13

    .line 424
    .line 425
    goto/16 :goto_353

    .line 426
    .line 427
    :cond_1aa
    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    .line 428
    .line 429
    .line 430
    move-result v10

    .line 431
    const/4 v14, 0x0

    .line 432
    :goto_1af
    if-ge v14, v10, :cond_1a2

    .line 433
    .line 434
    invoke-static {v12, v14}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 435
    .line 436
    .line 437
    move-result v35

    .line 438
    move/from16 v36, v10

    .line 439
    .line 440
    invoke-static/range {v35 .. v35}, Ljava/lang/Character;->getDirectionality(I)B

    .line 441
    .line 442
    .line 443
    move-result v10

    .line 444
    move/from16 v37, v14

    .line 445
    .line 446
    const/4 v14, 0x1

    .line 447
    if-eq v10, v14, :cond_1d5

    .line 448
    .line 449
    const/4 v14, 0x2

    .line 450
    if-eq v10, v14, :cond_1d5

    .line 451
    .line 452
    const/16 v14, 0x10

    .line 453
    .line 454
    if-eq v10, v14, :cond_1d5

    .line 455
    .line 456
    const/16 v14, 0x11

    .line 457
    .line 458
    if-ne v10, v14, :cond_1cc

    .line 459
    .line 460
    goto :goto_1d5

    .line 461
    :cond_1cc
    invoke-static/range {v35 .. v35}, Ljava/lang/Character;->charCount(I)I

    .line 462
    .line 463
    .line 464
    move-result v10

    .line 465
    add-int v14, v10, v37

    .line 466
    .line 467
    move/from16 v10, v36

    .line 468
    .line 469
    goto :goto_1af

    .line 470
    :cond_1d5
    :goto_1d5
    invoke-static {}, Landroid/text/BidiFormatter;->getInstance()Landroid/text/BidiFormatter;

    .line 471
    .line 472
    .line 473
    move-result-object v10

    .line 474
    instance-of v14, v12, Landroid/text/Spanned;

    .line 475
    .line 476
    if-eqz v14, :cond_203

    .line 477
    .line 478
    move-object v14, v12

    .line 479
    check-cast v14, Landroid/text/Spanned;

    .line 480
    .line 481
    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    .line 482
    .line 483
    .line 484
    move-result v1

    .line 485
    move/from16 v35, v13

    .line 486
    .line 487
    const-class v13, Ljava/lang/Object;

    .line 488
    .line 489
    move/from16 v36, v7

    .line 490
    .line 491
    const/4 v7, 0x0

    .line 492
    invoke-interface {v14, v7, v1, v13}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 493
    .line 494
    .line 495
    move-result-object v1

    .line 496
    array-length v7, v1

    .line 497
    new-array v7, v7, [I

    .line 498
    .line 499
    array-length v13, v1

    .line 500
    new-array v13, v13, [I

    .line 501
    .line 502
    move-object/from16 v18, v1

    .line 503
    .line 504
    const/4 v1, -0x1

    .line 505
    invoke-static {v7, v1}, Ljava/util/Arrays;->fill([II)V

    .line 506
    .line 507
    .line 508
    invoke-static {v13, v1}, Ljava/util/Arrays;->fill([II)V

    .line 509
    .line 510
    .line 511
    move-object/from16 v1, v18

    .line 512
    .line 513
    move-object/from16 v18, v7

    .line 514
    .line 515
    goto :goto_20c

    .line 516
    :cond_203
    move/from16 v36, v7

    .line 517
    .line 518
    move/from16 v35, v13

    .line 519
    .line 520
    const/4 v1, 0x0

    .line 521
    const/4 v13, 0x0

    .line 522
    const/4 v14, 0x0

    .line 523
    const/16 v18, 0x0

    .line 524
    .line 525
    :goto_20c
    invoke-interface {v12}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 526
    .line 527
    .line 528
    move-result-object v7

    .line 529
    move-object/from16 v37, v13

    .line 530
    .line 531
    const-string v13, "\r\n"

    .line 532
    .line 533
    invoke-virtual {v7, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 534
    .line 535
    .line 536
    move-result v7

    .line 537
    if-eqz v7, :cond_222

    .line 538
    .line 539
    sget-object v7, La6/c;->b:Lcom/google/android/gms/internal/fido/f8;

    .line 540
    .line 541
    invoke-virtual {v7, v12}, Lcom/google/android/gms/internal/fido/f8;->V(Ljava/lang/CharSequence;)Ljava/util/List;

    .line 542
    .line 543
    .line 544
    move-result-object v7

    .line 545
    const/4 v12, 0x2

    .line 546
    goto :goto_229

    .line 547
    :cond_222
    sget-object v7, La6/c;->a:Lcom/google/android/gms/internal/fido/f8;

    .line 548
    .line 549
    invoke-virtual {v7, v12}, Lcom/google/android/gms/internal/fido/f8;->V(Ljava/lang/CharSequence;)Ljava/util/List;

    .line 550
    .line 551
    .line 552
    move-result-object v7

    .line 553
    const/4 v12, 0x1

    .line 554
    :goto_229
    new-instance v13, Ljava/util/ArrayList;

    .line 555
    .line 556
    move-object/from16 v38, v7

    .line 557
    .line 558
    invoke-interface/range {v38 .. v38}, Ljava/util/List;->size()I

    .line 559
    .line 560
    .line 561
    move-result v7

    .line 562
    invoke-direct {v13, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 563
    .line 564
    .line 565
    invoke-interface/range {v38 .. v38}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 566
    .line 567
    .line 568
    move-result-object v7

    .line 569
    move-object/from16 v39, v7

    .line 570
    .line 571
    const/4 v7, 0x0

    .line 572
    const/16 v38, 0x0

    .line 573
    .line 574
    :goto_23d
    invoke-interface/range {v39 .. v39}, Ljava/util/Iterator;->hasNext()Z

    .line 575
    .line 576
    .line 577
    move-result v40

    .line 578
    if-eqz v40, :cond_2d5

    .line 579
    .line 580
    invoke-interface/range {v39 .. v39}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 581
    .line 582
    .line 583
    move-result-object v40

    .line 584
    move/from16 v41, v12

    .line 585
    .line 586
    move-object/from16 v12, v40

    .line 587
    .line 588
    check-cast v12, Ljava/lang/String;

    .line 589
    .line 590
    move/from16 v40, v6

    .line 591
    .line 592
    sget-object v6, Landroid/text/TextDirectionHeuristics;->LTR:Landroid/text/TextDirectionHeuristic;

    .line 593
    .line 594
    invoke-virtual {v10, v12, v6}, Landroid/text/BidiFormatter;->unicodeWrap(Ljava/lang/String;Landroid/text/TextDirectionHeuristic;)Ljava/lang/String;

    .line 595
    .line 596
    .line 597
    move-result-object v6

    .line 598
    if-eqz v1, :cond_2c8

    .line 599
    .line 600
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 601
    .line 602
    .line 603
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 604
    .line 605
    .line 606
    invoke-virtual/range {v37 .. v37}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 607
    .line 608
    .line 609
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 610
    .line 611
    .line 612
    move-result v42

    .line 613
    invoke-virtual {v12}, Ljava/lang/String;->length()I

    .line 614
    .line 615
    .line 616
    move-result v43

    .line 617
    sub-int v42, v42, v43

    .line 618
    .line 619
    if-lez v42, :cond_26e

    .line 620
    .line 621
    add-int/lit8 v38, v38, 0x1

    .line 622
    .line 623
    :cond_26e
    move-object/from16 v43, v10

    .line 624
    .line 625
    move-object/from16 v44, v12

    .line 626
    .line 627
    const/4 v10, 0x0

    .line 628
    :goto_273
    array-length v12, v1

    .line 629
    if-ge v10, v12, :cond_2bb

    .line 630
    .line 631
    aget v12, v18, v10

    .line 632
    .line 633
    if-gez v12, :cond_295

    .line 634
    .line 635
    aget-object v12, v1, v10

    .line 636
    .line 637
    invoke-interface {v14, v12}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 638
    .line 639
    .line 640
    move-result v12

    .line 641
    if-lt v12, v7, :cond_295

    .line 642
    .line 643
    aget-object v12, v1, v10

    .line 644
    .line 645
    invoke-interface {v14, v12}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 646
    .line 647
    .line 648
    move-result v12

    .line 649
    invoke-virtual/range {v44 .. v44}, Ljava/lang/String;->length()I

    .line 650
    .line 651
    .line 652
    move-result v45

    .line 653
    move/from16 v46, v10

    .line 654
    .line 655
    add-int v10, v45, v7

    .line 656
    .line 657
    if-ge v12, v10, :cond_297

    .line 658
    .line 659
    aput v38, v18, v46

    .line 660
    .line 661
    goto :goto_297

    .line 662
    :cond_295
    move/from16 v46, v10

    .line 663
    .line 664
    :cond_297
    :goto_297
    aget v10, v37, v46

    .line 665
    .line 666
    if-gez v10, :cond_2b8

    .line 667
    .line 668
    aget-object v10, v1, v46

    .line 669
    .line 670
    invoke-interface {v14, v10}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 671
    .line 672
    .line 673
    move-result v10

    .line 674
    const/16 v20, 0x1

    .line 675
    .line 676
    add-int/lit8 v10, v10, -0x1

    .line 677
    .line 678
    if-lt v10, v7, :cond_2b8

    .line 679
    .line 680
    aget-object v10, v1, v46

    .line 681
    .line 682
    invoke-interface {v14, v10}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 683
    .line 684
    .line 685
    move-result v10

    .line 686
    add-int/lit8 v10, v10, -0x1

    .line 687
    .line 688
    invoke-virtual/range {v44 .. v44}, Ljava/lang/String;->length()I

    .line 689
    .line 690
    .line 691
    move-result v12

    .line 692
    add-int/2addr v12, v7

    .line 693
    if-ge v10, v12, :cond_2b8

    .line 694
    .line 695
    aput v38, v37, v46

    .line 696
    .line 697
    :cond_2b8
    add-int/lit8 v10, v46, 0x1

    .line 698
    .line 699
    goto :goto_273

    .line 700
    :cond_2bb
    invoke-virtual/range {v44 .. v44}, Ljava/lang/String;->length()I

    .line 701
    .line 702
    .line 703
    move-result v10

    .line 704
    add-int v10, v10, v41

    .line 705
    .line 706
    add-int/2addr v10, v7

    .line 707
    if-lez v42, :cond_2c6

    .line 708
    .line 709
    add-int/lit8 v38, v38, 0x1

    .line 710
    .line 711
    :cond_2c6
    move v7, v10

    .line 712
    goto :goto_2ca

    .line 713
    :cond_2c8
    move-object/from16 v43, v10

    .line 714
    .line 715
    :goto_2ca
    invoke-virtual {v13, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 716
    .line 717
    .line 718
    move/from16 v6, v40

    .line 719
    .line 720
    move/from16 v12, v41

    .line 721
    .line 722
    move-object/from16 v10, v43

    .line 723
    .line 724
    goto/16 :goto_23d

    .line 725
    .line 726
    :cond_2d5
    move/from16 v40, v6

    .line 727
    .line 728
    new-instance v12, Landroid/text/SpannableStringBuilder;

    .line 729
    .line 730
    sget-object v6, La6/c;->c:Lgx/l;

    .line 731
    .line 732
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 733
    .line 734
    .line 735
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 736
    .line 737
    .line 738
    move-result-object v7

    .line 739
    new-instance v10, Ljava/lang/StringBuilder;

    .line 740
    .line 741
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 742
    .line 743
    .line 744
    invoke-virtual {v6, v10, v7}, Lgx/l;->a(Ljava/lang/StringBuilder;Ljava/util/Iterator;)V

    .line 745
    .line 746
    .line 747
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 748
    .line 749
    .line 750
    move-result-object v6

    .line 751
    invoke-direct {v12, v6}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 752
    .line 753
    .line 754
    if-eqz v1, :cond_353

    .line 755
    .line 756
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 757
    .line 758
    .line 759
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 760
    .line 761
    .line 762
    invoke-virtual/range {v37 .. v37}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 763
    .line 764
    .line 765
    const/4 v6, 0x0

    .line 766
    :goto_2fd
    array-length v7, v1

    .line 767
    if-ge v6, v7, :cond_353

    .line 768
    .line 769
    aget-object v7, v1, v6

    .line 770
    .line 771
    invoke-interface {v14, v7}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 772
    .line 773
    .line 774
    move-result v7

    .line 775
    aget v10, v18, v6

    .line 776
    .line 777
    add-int/2addr v7, v10

    .line 778
    aget-object v10, v1, v6

    .line 779
    .line 780
    invoke-interface {v14, v10}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 781
    .line 782
    .line 783
    move-result v10

    .line 784
    aget v13, v37, v6

    .line 785
    .line 786
    add-int/2addr v10, v13

    .line 787
    aget-object v13, v1, v6

    .line 788
    .line 789
    invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I

    .line 790
    .line 791
    .line 792
    move-result v13

    .line 793
    move-object/from16 v38, v1

    .line 794
    .line 795
    if-ltz v7, :cond_332

    .line 796
    .line 797
    invoke-virtual {v12}, Landroid/text/SpannableStringBuilder;->length()I

    .line 798
    .line 799
    .line 800
    move-result v1

    .line 801
    if-ge v7, v1, :cond_332

    .line 802
    .line 803
    if-ltz v10, :cond_332

    .line 804
    .line 805
    invoke-virtual {v12}, Landroid/text/SpannableStringBuilder;->length()I

    .line 806
    .line 807
    .line 808
    move-result v1

    .line 809
    if-gt v10, v1, :cond_332

    .line 810
    .line 811
    aget-object v1, v38, v6

    .line 812
    .line 813
    invoke-virtual {v12, v1, v7, v10, v13}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 814
    .line 815
    .line 816
    move/from16 v39, v6

    .line 817
    .line 818
    goto :goto_34e

    .line 819
    :cond_332
    const-string v1, ",end="

    .line 820
    .line 821
    const-string v13, ",len="

    .line 822
    .line 823
    move/from16 v39, v6

    .line 824
    .line 825
    const-string v6, "Span out of bounds: start="

    .line 826
    .line 827
    invoke-static {v7, v6, v10, v1, v13}, La1/h;->m(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 828
    .line 829
    .line 830
    move-result-object v1

    .line 831
    invoke-virtual {v12}, Landroid/text/SpannableStringBuilder;->length()I

    .line 832
    .line 833
    .line 834
    move-result v6

    .line 835
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 836
    .line 837
    .line 838
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 839
    .line 840
    .line 841
    move-result-object v1

    .line 842
    const-string v6, "BidiUtils"

    .line 843
    .line 844
    invoke-static {v6, v1}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 845
    .line 846
    .line 847
    :goto_34e
    add-int/lit8 v6, v39, 0x1

    .line 848
    .line 849
    move-object/from16 v1, v38

    .line 850
    .line 851
    goto :goto_2fd

    .line 852
    :cond_353
    :goto_353
    iput-object v12, v11, La6/u0;->i:Ljava/lang/CharSequence;

    .line 853
    .line 854
    iput-object v8, v11, La6/u0;->j:Landroid/text/Layout$Alignment;

    .line 855
    .line 856
    iput-object v3, v11, La6/u0;->k:Landroid/graphics/Bitmap;

    .line 857
    .line 858
    iput v0, v11, La6/u0;->l:F

    .line 859
    .line 860
    iput v9, v11, La6/u0;->m:I

    .line 861
    .line 862
    move/from16 v0, v29

    .line 863
    .line 864
    iput v0, v11, La6/u0;->n:I

    .line 865
    .line 866
    move/from16 v0, v28

    .line 867
    .line 868
    iput v0, v11, La6/u0;->o:F

    .line 869
    .line 870
    move/from16 v0, v27

    .line 871
    .line 872
    iput v0, v11, La6/u0;->p:I

    .line 873
    .line 874
    move/from16 v0, v26

    .line 875
    .line 876
    iput v0, v11, La6/u0;->q:F

    .line 877
    .line 878
    move/from16 v0, v25

    .line 879
    .line 880
    iput v0, v11, La6/u0;->r:F

    .line 881
    .line 882
    iget v0, v15, La6/e;->a:I

    .line 883
    .line 884
    iput v0, v11, La6/u0;->s:I

    .line 885
    .line 886
    iget v0, v15, La6/e;->b:I

    .line 887
    .line 888
    iput v0, v11, La6/u0;->t:I

    .line 889
    .line 890
    iput v2, v11, La6/u0;->u:I

    .line 891
    .line 892
    iget v0, v15, La6/e;->d:I

    .line 893
    .line 894
    iput v0, v11, La6/u0;->w:I

    .line 895
    .line 896
    iget v0, v15, La6/e;->e:I

    .line 897
    .line 898
    iput v0, v11, La6/u0;->v:I

    .line 899
    .line 900
    iget-object v0, v15, La6/e;->f:Landroid/graphics/Typeface;

    .line 901
    .line 902
    move-object/from16 v1, v24

    .line 903
    .line 904
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 905
    .line 906
    .line 907
    move/from16 v0, v34

    .line 908
    .line 909
    iput v0, v11, La6/u0;->x:F

    .line 910
    .line 911
    move/from16 v2, v23

    .line 912
    .line 913
    iput v2, v11, La6/u0;->y:F

    .line 914
    .line 915
    move/from16 v2, v22

    .line 916
    .line 917
    iput v2, v11, La6/u0;->z:F

    .line 918
    .line 919
    iput v4, v11, La6/u0;->A:I

    .line 920
    .line 921
    iput v5, v11, La6/u0;->B:I

    .line 922
    .line 923
    move/from16 v6, v40

    .line 924
    .line 925
    iput v6, v11, La6/u0;->C:I

    .line 926
    .line 927
    move/from16 v3, v36

    .line 928
    .line 929
    iput v3, v11, La6/u0;->D:I

    .line 930
    .line 931
    if-eqz v35, :cond_5ac

    .line 932
    .line 933
    iget-object v2, v11, La6/u0;->i:Ljava/lang/CharSequence;

    .line 934
    .line 935
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 936
    .line 937
    .line 938
    iget-object v2, v11, La6/u0;->i:Ljava/lang/CharSequence;

    .line 939
    .line 940
    instance-of v7, v2, Landroid/text/SpannableStringBuilder;

    .line 941
    .line 942
    if-eqz v7, :cond_3b2

    .line 943
    .line 944
    check-cast v2, Landroid/text/SpannableStringBuilder;

    .line 945
    .line 946
    goto :goto_3b9

    .line 947
    :cond_3b2
    new-instance v2, Landroid/text/SpannableStringBuilder;

    .line 948
    .line 949
    iget-object v7, v11, La6/u0;->i:Ljava/lang/CharSequence;

    .line 950
    .line 951
    invoke-direct {v2, v7}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 952
    .line 953
    .line 954
    :goto_3b9
    iget v7, v11, La6/u0;->C:I

    .line 955
    .line 956
    iget v8, v11, La6/u0;->A:I

    .line 957
    .line 958
    sub-int/2addr v7, v8

    .line 959
    iget v8, v11, La6/u0;->D:I

    .line 960
    .line 961
    iget v9, v11, La6/u0;->B:I

    .line 962
    .line 963
    sub-int/2addr v8, v9

    .line 964
    iget v9, v11, La6/u0;->x:F

    .line 965
    .line 966
    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 967
    .line 968
    .line 969
    iget v9, v11, La6/u0;->x:F

    .line 970
    .line 971
    const/high16 v10, 0x3e000000    # 0.125f

    .line 972
    .line 973
    mul-float/2addr v9, v10

    .line 974
    const/high16 v10, 0x3f000000    # 0.5f

    .line 975
    .line 976
    add-float/2addr v9, v10

    .line 977
    float-to-int v9, v9

    .line 978
    mul-int/lit8 v10, v9, 0x2

    .line 979
    .line 980
    sub-int v12, v7, v10

    .line 981
    .line 982
    iget v13, v11, La6/u0;->q:F

    .line 983
    .line 984
    const v19, -0x800001

    .line 985
    .line 986
    .line 987
    cmpl-float v14, v13, v19

    .line 988
    .line 989
    if-eqz v14, :cond_3e1

    .line 990
    .line 991
    int-to-float v12, v12

    .line 992
    mul-float/2addr v12, v13

    .line 993
    float-to-int v12, v12

    .line 994
    :cond_3e1
    move/from16 v25, v12

    .line 995
    .line 996
    const-string v12, "SubtitlePainter"

    .line 997
    .line 998
    if-gtz v25, :cond_3f1

    .line 999
    .line 1000
    const-string v1, "Skipped drawing subtitle cue (insufficient space)"

    .line 1001
    .line 1002
    invoke-static {v12, v1}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 1003
    .line 1004
    .line 1005
    move/from16 v34, v0

    .line 1006
    .line 1007
    :goto_3ee
    const/4 v15, 0x0

    .line 1008
    goto/16 :goto_5a6

    .line 1009
    .line 1010
    :cond_3f1
    iget v13, v11, La6/u0;->y:F

    .line 1011
    .line 1012
    cmpl-float v13, v13, v16

    .line 1013
    .line 1014
    const/high16 v14, 0xff0000

    .line 1015
    .line 1016
    if-lez v13, :cond_40c

    .line 1017
    .line 1018
    new-instance v13, Landroid/text/style/AbsoluteSizeSpan;

    .line 1019
    .line 1020
    iget v15, v11, La6/u0;->y:F

    .line 1021
    .line 1022
    float-to-int v15, v15

    .line 1023
    invoke-direct {v13, v15}, Landroid/text/style/AbsoluteSizeSpan;-><init>(I)V

    .line 1024
    .line 1025
    .line 1026
    invoke-virtual {v2}, Landroid/text/SpannableStringBuilder;->length()I

    .line 1027
    .line 1028
    .line 1029
    move-result v15

    .line 1030
    move/from16 v34, v0

    .line 1031
    .line 1032
    const/4 v0, 0x0

    .line 1033
    invoke-virtual {v2, v13, v0, v15, v14}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 1034
    .line 1035
    .line 1036
    goto :goto_40f

    .line 1037
    :cond_40c
    move/from16 v34, v0

    .line 1038
    .line 1039
    const/4 v0, 0x0

    .line 1040
    :goto_40f
    new-instance v13, Landroid/text/SpannableStringBuilder;

    .line 1041
    .line 1042
    invoke-direct {v13, v2}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 1043
    .line 1044
    .line 1045
    iget v15, v11, La6/u0;->w:I

    .line 1046
    .line 1047
    const/4 v14, 0x1

    .line 1048
    if-ne v15, v14, :cond_435

    .line 1049
    .line 1050
    invoke-virtual {v13}, Landroid/text/SpannableStringBuilder;->length()I

    .line 1051
    .line 1052
    .line 1053
    move-result v14

    .line 1054
    const-class v15, Landroid/text/style/ForegroundColorSpan;

    .line 1055
    .line 1056
    invoke-virtual {v13, v0, v14, v15}, Landroid/text/SpannableStringBuilder;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 1057
    .line 1058
    .line 1059
    move-result-object v14

    .line 1060
    check-cast v14, [Landroid/text/style/ForegroundColorSpan;

    .line 1061
    .line 1062
    array-length v0, v14

    .line 1063
    const/4 v15, 0x0

    .line 1064
    :goto_427
    if-ge v15, v0, :cond_435

    .line 1065
    .line 1066
    move/from16 v22, v0

    .line 1067
    .line 1068
    aget-object v0, v14, v15

    .line 1069
    .line 1070
    invoke-virtual {v13, v0}, Landroid/text/SpannableStringBuilder;->removeSpan(Ljava/lang/Object;)V

    .line 1071
    .line 1072
    .line 1073
    add-int/lit8 v15, v15, 0x1

    .line 1074
    .line 1075
    move/from16 v0, v22

    .line 1076
    .line 1077
    goto :goto_427

    .line 1078
    :cond_435
    iget v0, v11, La6/u0;->t:I

    .line 1079
    .line 1080
    invoke-static {v0}, Landroid/graphics/Color;->alpha(I)I

    .line 1081
    .line 1082
    .line 1083
    move-result v0

    .line 1084
    if-lez v0, :cond_46d

    .line 1085
    .line 1086
    iget v0, v11, La6/u0;->w:I

    .line 1087
    .line 1088
    if-eqz v0, :cond_444

    .line 1089
    .line 1090
    const/4 v14, 0x2

    .line 1091
    if-ne v0, v14, :cond_44a

    .line 1092
    .line 1093
    :cond_444
    move-object/from16 v24, v1

    .line 1094
    .line 1095
    const/high16 v1, 0xff0000

    .line 1096
    .line 1097
    const/4 v15, 0x0

    .line 1098
    goto :goto_45e

    .line 1099
    :cond_44a
    new-instance v0, Landroid/text/style/BackgroundColorSpan;

    .line 1100
    .line 1101
    iget v14, v11, La6/u0;->t:I

    .line 1102
    .line 1103
    invoke-direct {v0, v14}, Landroid/text/style/BackgroundColorSpan;-><init>(I)V

    .line 1104
    .line 1105
    .line 1106
    invoke-virtual {v13}, Landroid/text/SpannableStringBuilder;->length()I

    .line 1107
    .line 1108
    .line 1109
    move-result v14

    .line 1110
    move-object/from16 v24, v1

    .line 1111
    .line 1112
    const/high16 v1, 0xff0000

    .line 1113
    .line 1114
    const/4 v15, 0x0

    .line 1115
    invoke-virtual {v13, v0, v15, v14, v1}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 1116
    .line 1117
    .line 1118
    goto :goto_46f

    .line 1119
    :goto_45e
    new-instance v0, Landroid/text/style/BackgroundColorSpan;

    .line 1120
    .line 1121
    iget v14, v11, La6/u0;->t:I

    .line 1122
    .line 1123
    invoke-direct {v0, v14}, Landroid/text/style/BackgroundColorSpan;-><init>(I)V

    .line 1124
    .line 1125
    .line 1126
    invoke-virtual {v2}, Landroid/text/SpannableStringBuilder;->length()I

    .line 1127
    .line 1128
    .line 1129
    move-result v14

    .line 1130
    invoke-virtual {v2, v0, v15, v14, v1}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 1131
    .line 1132
    .line 1133
    goto :goto_46f

    .line 1134
    :cond_46d
    move-object/from16 v24, v1

    .line 1135
    .line 1136
    :goto_46f
    iget-object v0, v11, La6/u0;->j:Landroid/text/Layout$Alignment;

    .line 1137
    .line 1138
    if-nez v0, :cond_475

    .line 1139
    .line 1140
    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    .line 1141
    .line 1142
    :cond_475
    move-object/from16 v26, v0

    .line 1143
    .line 1144
    new-instance v22, Landroid/text/StaticLayout;

    .line 1145
    .line 1146
    iget v0, v11, La6/u0;->d:F

    .line 1147
    .line 1148
    iget v1, v11, La6/u0;->e:F

    .line 1149
    .line 1150
    const/16 v29, 0x1

    .line 1151
    .line 1152
    move/from16 v27, v0

    .line 1153
    .line 1154
    move/from16 v28, v1

    .line 1155
    .line 1156
    move-object/from16 v23, v2

    .line 1157
    .line 1158
    invoke-direct/range {v22 .. v29}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    .line 1159
    .line 1160
    .line 1161
    move-object/from16 v1, v22

    .line 1162
    .line 1163
    move/from16 v0, v25

    .line 1164
    .line 1165
    iput-object v1, v11, La6/u0;->E:Landroid/text/StaticLayout;

    .line 1166
    .line 1167
    invoke-virtual {v1}, Landroid/text/Layout;->getHeight()I

    .line 1168
    .line 1169
    .line 1170
    move-result v1

    .line 1171
    iget-object v2, v11, La6/u0;->E:Landroid/text/StaticLayout;

    .line 1172
    .line 1173
    invoke-virtual {v2}, Landroid/text/StaticLayout;->getLineCount()I

    .line 1174
    .line 1175
    .line 1176
    move-result v2

    .line 1177
    const/4 v14, 0x0

    .line 1178
    const/4 v15, 0x0

    .line 1179
    :goto_49a
    if-ge v14, v2, :cond_4b7

    .line 1180
    .line 1181
    move/from16 v18, v1

    .line 1182
    .line 1183
    iget-object v1, v11, La6/u0;->E:Landroid/text/StaticLayout;

    .line 1184
    .line 1185
    invoke-virtual {v1, v14}, Landroid/text/Layout;->getLineWidth(I)F

    .line 1186
    .line 1187
    .line 1188
    move-result v1

    .line 1189
    move/from16 v22, v2

    .line 1190
    .line 1191
    float-to-double v1, v1

    .line 1192
    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    .line 1193
    .line 1194
    .line 1195
    move-result-wide v1

    .line 1196
    double-to-int v1, v1

    .line 1197
    invoke-static {v1, v15}, Ljava/lang/Math;->max(II)I

    .line 1198
    .line 1199
    .line 1200
    move-result v15

    .line 1201
    add-int/lit8 v14, v14, 0x1

    .line 1202
    .line 1203
    move/from16 v1, v18

    .line 1204
    .line 1205
    move/from16 v2, v22

    .line 1206
    .line 1207
    goto :goto_49a

    .line 1208
    :cond_4b7
    move/from16 v18, v1

    .line 1209
    .line 1210
    iget v1, v11, La6/u0;->q:F

    .line 1211
    .line 1212
    const v19, -0x800001

    .line 1213
    .line 1214
    .line 1215
    cmpl-float v1, v1, v19

    .line 1216
    .line 1217
    if-eqz v1, :cond_4c7

    .line 1218
    .line 1219
    if-ge v15, v0, :cond_4c7

    .line 1220
    .line 1221
    move/from16 v25, v0

    .line 1222
    .line 1223
    goto :goto_4c9

    .line 1224
    :cond_4c7
    move/from16 v25, v15

    .line 1225
    .line 1226
    :goto_4c9
    add-int v25, v25, v10

    .line 1227
    .line 1228
    iget v0, v11, La6/u0;->o:F

    .line 1229
    .line 1230
    cmpl-float v1, v0, v19

    .line 1231
    .line 1232
    if-eqz v1, :cond_4f9

    .line 1233
    .line 1234
    int-to-float v1, v7

    .line 1235
    mul-float/2addr v1, v0

    .line 1236
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 1237
    .line 1238
    .line 1239
    move-result v0

    .line 1240
    iget v1, v11, La6/u0;->A:I

    .line 1241
    .line 1242
    add-int/2addr v0, v1

    .line 1243
    iget v2, v11, La6/u0;->p:I

    .line 1244
    .line 1245
    const/4 v14, 0x1

    .line 1246
    if-eq v2, v14, :cond_4e6

    .line 1247
    .line 1248
    const/4 v14, 0x2

    .line 1249
    if-eq v2, v14, :cond_4e3

    .line 1250
    .line 1251
    goto :goto_4ec

    .line 1252
    :cond_4e3
    sub-int v0, v0, v25

    .line 1253
    .line 1254
    goto :goto_4ec

    .line 1255
    :cond_4e6
    const/4 v14, 0x2

    .line 1256
    mul-int/lit8 v0, v0, 0x2

    .line 1257
    .line 1258
    sub-int v0, v0, v25

    .line 1259
    .line 1260
    div-int/2addr v0, v14

    .line 1261
    :goto_4ec
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 1262
    .line 1263
    .line 1264
    move-result v0

    .line 1265
    add-int v1, v0, v25

    .line 1266
    .line 1267
    iget v2, v11, La6/u0;->C:I

    .line 1268
    .line 1269
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 1270
    .line 1271
    .line 1272
    move-result v1

    .line 1273
    goto :goto_502

    .line 1274
    :cond_4f9
    const/4 v14, 0x2

    .line 1275
    sub-int v7, v7, v25

    .line 1276
    .line 1277
    div-int/2addr v7, v14

    .line 1278
    iget v0, v11, La6/u0;->A:I

    .line 1279
    .line 1280
    add-int/2addr v0, v7

    .line 1281
    add-int v1, v0, v25

    .line 1282
    .line 1283
    :goto_502
    sub-int v25, v1, v0

    .line 1284
    .line 1285
    if-gtz v25, :cond_50d

    .line 1286
    .line 1287
    const-string v0, "Skipped drawing subtitle cue (invalid horizontal positioning)"

    .line 1288
    .line 1289
    invoke-static {v12, v0}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 1290
    .line 1291
    .line 1292
    goto/16 :goto_3ee

    .line 1293
    .line 1294
    :cond_50d
    iget v1, v11, La6/u0;->l:F

    .line 1295
    .line 1296
    const v19, -0x800001

    .line 1297
    .line 1298
    .line 1299
    cmpl-float v2, v1, v19

    .line 1300
    .line 1301
    if-eqz v2, :cond_56f

    .line 1302
    .line 1303
    iget v2, v11, La6/u0;->m:I

    .line 1304
    .line 1305
    if-nez v2, :cond_535

    .line 1306
    .line 1307
    int-to-float v2, v8

    .line 1308
    mul-float/2addr v2, v1

    .line 1309
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 1310
    .line 1311
    .line 1312
    move-result v1

    .line 1313
    iget v2, v11, La6/u0;->B:I

    .line 1314
    .line 1315
    add-int/2addr v1, v2

    .line 1316
    iget v2, v11, La6/u0;->n:I

    .line 1317
    .line 1318
    const/4 v14, 0x2

    .line 1319
    if-ne v2, v14, :cond_52b

    .line 1320
    .line 1321
    sub-int v1, v1, v18

    .line 1322
    .line 1323
    goto :goto_533

    .line 1324
    :cond_52b
    const/4 v10, 0x1

    .line 1325
    if-ne v2, v10, :cond_533

    .line 1326
    .line 1327
    mul-int/lit8 v1, v1, 0x2

    .line 1328
    .line 1329
    sub-int v1, v1, v18

    .line 1330
    .line 1331
    div-int/2addr v1, v14

    .line 1332
    :cond_533
    :goto_533
    const/4 v15, 0x0

    .line 1333
    goto :goto_560

    .line 1334
    :cond_535
    iget-object v1, v11, La6/u0;->E:Landroid/text/StaticLayout;

    .line 1335
    .line 1336
    const/4 v15, 0x0

    .line 1337
    invoke-virtual {v1, v15}, Landroid/text/Layout;->getLineBottom(I)I

    .line 1338
    .line 1339
    .line 1340
    move-result v1

    .line 1341
    iget-object v2, v11, La6/u0;->E:Landroid/text/StaticLayout;

    .line 1342
    .line 1343
    invoke-virtual {v2, v15}, Landroid/text/StaticLayout;->getLineTop(I)I

    .line 1344
    .line 1345
    .line 1346
    move-result v2

    .line 1347
    sub-int/2addr v1, v2

    .line 1348
    iget v2, v11, La6/u0;->l:F

    .line 1349
    .line 1350
    cmpl-float v7, v2, v16

    .line 1351
    .line 1352
    if-ltz v7, :cond_553

    .line 1353
    .line 1354
    int-to-float v1, v1

    .line 1355
    mul-float/2addr v2, v1

    .line 1356
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 1357
    .line 1358
    .line 1359
    move-result v1

    .line 1360
    iget v2, v11, La6/u0;->B:I

    .line 1361
    .line 1362
    add-int/2addr v1, v2

    .line 1363
    goto :goto_560

    .line 1364
    :cond_553
    add-float v2, v2, v17

    .line 1365
    .line 1366
    int-to-float v1, v1

    .line 1367
    mul-float/2addr v2, v1

    .line 1368
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 1369
    .line 1370
    .line 1371
    move-result v1

    .line 1372
    iget v2, v11, La6/u0;->D:I

    .line 1373
    .line 1374
    add-int/2addr v1, v2

    .line 1375
    sub-int v1, v1, v18

    .line 1376
    .line 1377
    :goto_560
    add-int v2, v1, v18

    .line 1378
    .line 1379
    iget v7, v11, La6/u0;->D:I

    .line 1380
    .line 1381
    if-le v2, v7, :cond_569

    .line 1382
    .line 1383
    sub-int v1, v7, v18

    .line 1384
    .line 1385
    goto :goto_57a

    .line 1386
    :cond_569
    iget v2, v11, La6/u0;->B:I

    .line 1387
    .line 1388
    if-ge v1, v2, :cond_57a

    .line 1389
    .line 1390
    move v1, v2

    .line 1391
    goto :goto_57a

    .line 1392
    :cond_56f
    const/4 v15, 0x0

    .line 1393
    iget v1, v11, La6/u0;->D:I

    .line 1394
    .line 1395
    sub-int v1, v1, v18

    .line 1396
    .line 1397
    int-to-float v2, v8

    .line 1398
    iget v7, v11, La6/u0;->z:F

    .line 1399
    .line 1400
    mul-float/2addr v2, v7

    .line 1401
    float-to-int v2, v2

    .line 1402
    sub-int/2addr v1, v2

    .line 1403
    :cond_57a
    :goto_57a
    new-instance v22, Landroid/text/StaticLayout;

    .line 1404
    .line 1405
    iget v2, v11, La6/u0;->d:F

    .line 1406
    .line 1407
    iget v7, v11, La6/u0;->e:F

    .line 1408
    .line 1409
    const/16 v29, 0x1

    .line 1410
    .line 1411
    move/from16 v27, v2

    .line 1412
    .line 1413
    move/from16 v28, v7

    .line 1414
    .line 1415
    invoke-direct/range {v22 .. v29}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    .line 1416
    .line 1417
    .line 1418
    move-object/from16 v2, v22

    .line 1419
    .line 1420
    iput-object v2, v11, La6/u0;->E:Landroid/text/StaticLayout;

    .line 1421
    .line 1422
    new-instance v22, Landroid/text/StaticLayout;

    .line 1423
    .line 1424
    iget v2, v11, La6/u0;->d:F

    .line 1425
    .line 1426
    iget v7, v11, La6/u0;->e:F

    .line 1427
    .line 1428
    move/from16 v27, v2

    .line 1429
    .line 1430
    move/from16 v28, v7

    .line 1431
    .line 1432
    move-object/from16 v23, v13

    .line 1433
    .line 1434
    invoke-direct/range {v22 .. v29}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    .line 1435
    .line 1436
    .line 1437
    move-object/from16 v2, v22

    .line 1438
    .line 1439
    iput-object v2, v11, La6/u0;->F:Landroid/text/StaticLayout;

    .line 1440
    .line 1441
    iput v0, v11, La6/u0;->G:I

    .line 1442
    .line 1443
    iput v1, v11, La6/u0;->H:I

    .line 1444
    .line 1445
    iput v9, v11, La6/u0;->I:I

    .line 1446
    .line 1447
    :goto_5a6
    move-object/from16 v1, p1

    .line 1448
    .line 1449
    move/from16 v0, v35

    .line 1450
    .line 1451
    goto/16 :goto_623

    .line 1452
    .line 1453
    :cond_5ac
    move/from16 v34, v0

    .line 1454
    .line 1455
    const/4 v15, 0x0

    .line 1456
    iget-object v0, v11, La6/u0;->k:Landroid/graphics/Bitmap;

    .line 1457
    .line 1458
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1459
    .line 1460
    .line 1461
    iget-object v0, v11, La6/u0;->k:Landroid/graphics/Bitmap;

    .line 1462
    .line 1463
    iget v1, v11, La6/u0;->C:I

    .line 1464
    .line 1465
    iget v2, v11, La6/u0;->A:I

    .line 1466
    .line 1467
    sub-int/2addr v1, v2

    .line 1468
    iget v7, v11, La6/u0;->D:I

    .line 1469
    .line 1470
    iget v8, v11, La6/u0;->B:I

    .line 1471
    .line 1472
    sub-int/2addr v7, v8

    .line 1473
    int-to-float v2, v2

    .line 1474
    int-to-float v1, v1

    .line 1475
    iget v9, v11, La6/u0;->o:F

    .line 1476
    .line 1477
    mul-float/2addr v9, v1

    .line 1478
    add-float/2addr v9, v2

    .line 1479
    int-to-float v2, v8

    .line 1480
    int-to-float v7, v7

    .line 1481
    iget v8, v11, La6/u0;->l:F

    .line 1482
    .line 1483
    mul-float/2addr v8, v7

    .line 1484
    add-float/2addr v8, v2

    .line 1485
    iget v2, v11, La6/u0;->q:F

    .line 1486
    .line 1487
    mul-float/2addr v1, v2

    .line 1488
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 1489
    .line 1490
    .line 1491
    move-result v1

    .line 1492
    iget v2, v11, La6/u0;->r:F

    .line 1493
    .line 1494
    const v19, -0x800001

    .line 1495
    .line 1496
    .line 1497
    cmpl-float v10, v2, v19

    .line 1498
    .line 1499
    if-eqz v10, :cond_5e2

    .line 1500
    .line 1501
    mul-float/2addr v7, v2

    .line 1502
    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    .line 1503
    .line 1504
    .line 1505
    move-result v0

    .line 1506
    goto :goto_5f3

    .line 1507
    :cond_5e2
    int-to-float v2, v1

    .line 1508
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    .line 1509
    .line 1510
    .line 1511
    move-result v7

    .line 1512
    int-to-float v7, v7

    .line 1513
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    .line 1514
    .line 1515
    .line 1516
    move-result v0

    .line 1517
    int-to-float v0, v0

    .line 1518
    div-float/2addr v7, v0

    .line 1519
    mul-float/2addr v7, v2

    .line 1520
    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    .line 1521
    .line 1522
    .line 1523
    move-result v0

    .line 1524
    :goto_5f3
    iget v2, v11, La6/u0;->p:I

    .line 1525
    .line 1526
    const/4 v14, 0x2

    .line 1527
    if-ne v2, v14, :cond_5fb

    .line 1528
    .line 1529
    int-to-float v2, v1

    .line 1530
    :goto_5f9
    sub-float/2addr v9, v2

    .line 1531
    goto :goto_602

    .line 1532
    :cond_5fb
    const/4 v14, 0x1

    .line 1533
    if-ne v2, v14, :cond_602

    .line 1534
    .line 1535
    div-int/lit8 v2, v1, 0x2

    .line 1536
    .line 1537
    int-to-float v2, v2

    .line 1538
    goto :goto_5f9

    .line 1539
    :cond_602
    :goto_602
    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    .line 1540
    .line 1541
    .line 1542
    move-result v2

    .line 1543
    iget v7, v11, La6/u0;->n:I

    .line 1544
    .line 1545
    const/4 v14, 0x2

    .line 1546
    if-ne v7, v14, :cond_60e

    .line 1547
    .line 1548
    int-to-float v7, v0

    .line 1549
    :goto_60c
    sub-float/2addr v8, v7

    .line 1550
    goto :goto_615

    .line 1551
    :cond_60e
    const/4 v14, 0x1

    .line 1552
    if-ne v7, v14, :cond_615

    .line 1553
    .line 1554
    div-int/lit8 v7, v0, 0x2

    .line 1555
    .line 1556
    int-to-float v7, v7

    .line 1557
    goto :goto_60c

    .line 1558
    :cond_615
    :goto_615
    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    .line 1559
    .line 1560
    .line 1561
    move-result v7

    .line 1562
    new-instance v8, Landroid/graphics/Rect;

    .line 1563
    .line 1564
    add-int/2addr v1, v2

    .line 1565
    add-int/2addr v0, v7

    .line 1566
    invoke-direct {v8, v2, v7, v1, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 1567
    .line 1568
    .line 1569
    iput-object v8, v11, La6/u0;->J:Landroid/graphics/Rect;

    .line 1570
    .line 1571
    goto :goto_5a6

    .line 1572
    :goto_623
    invoke-virtual {v11, v1, v0}, La6/u0;->a(Landroid/graphics/Canvas;Z)V

    .line 1573
    .line 1574
    .line 1575
    :goto_626
    add-int/lit8 v13, v33, 0x1

    .line 1576
    .line 1577
    move-object/from16 v0, p0

    .line 1578
    .line 1579
    move v7, v3

    .line 1580
    move v10, v15

    .line 1581
    move/from16 v11, v16

    .line 1582
    .line 1583
    move-object/from16 v2, v21

    .line 1584
    .line 1585
    move/from16 v3, v30

    .line 1586
    .line 1587
    move/from16 v8, v31

    .line 1588
    .line 1589
    move/from16 v12, v32

    .line 1590
    .line 1591
    move/from16 v9, v34

    .line 1592
    .line 1593
    goto/16 :goto_44

    .line 1594
    .line 1595
    :cond_63a
    :goto_63a
    return-void
.end method
