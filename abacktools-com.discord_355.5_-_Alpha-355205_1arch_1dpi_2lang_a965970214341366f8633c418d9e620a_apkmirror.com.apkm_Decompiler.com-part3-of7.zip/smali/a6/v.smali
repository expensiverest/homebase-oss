###### Class a6.v (a6.v)
.class public interface abstract La6/v;
.super Ljava/lang/Object;
.source "SourceFile"
