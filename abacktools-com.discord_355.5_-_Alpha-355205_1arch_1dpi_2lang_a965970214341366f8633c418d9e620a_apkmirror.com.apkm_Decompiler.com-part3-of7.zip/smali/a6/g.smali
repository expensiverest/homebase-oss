###### Class a6.g (a6.g)
.class public final synthetic La6/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/g;->a:I

    iput-object p2, p0, La6/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 8

    .line 1
    iget v0, p0, La6/g;->a:I

    .line 2
    .line 3
    const-string v1, "null cannot be cast to non-null type kotlin.Float"

    .line 4
    .line 5
    const-string v2, "it"

    .line 6
    .line 7
    const-string v3, "animator"

    .line 8
    .line 9
    const-string v4, "null cannot be cast to non-null type kotlin.Int"

    .line 10
    .line 11
    iget-object v5, p0, La6/g;->b:Ljava/lang/Object;

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_12a

    .line 14
    .line 15
    .line 16
    check-cast v5, Lyv/c;

    .line 17
    .line 18
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Ljava/lang/Float;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    const/high16 v0, 0x437f0000    # 255.0f

    .line 32
    .line 33
    mul-float/2addr v0, p1

    .line 34
    float-to-int v0, v0

    .line 35
    iget-object v1, v5, Lyv/c;->j:Landroid/graphics/drawable/Drawable;

    .line 36
    .line 37
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 38
    .line 39
    .line 40
    iput p1, v5, Lyv/c;->x:F

    .line 41
    .line 42
    return-void

    .line 43
    :pswitch_2a
    check-cast v5, Lwc/b;

    .line 44
    .line 45
    invoke-static {p1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object v0, v5, Lwc/b;->x:Landroid/graphics/Paint;

    .line 49
    .line 50
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    check-cast p1, Ljava/lang/Integer;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v5}, Landroid/view/View;->invalidate()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :pswitch_45
    check-cast v5, Lu10/d;

    .line 71
    .line 72
    invoke-static {p1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    instance-of v0, p1, Ljava/lang/Float;

    .line 80
    .line 81
    if-eqz v0, :cond_55

    .line 82
    .line 83
    check-cast p1, Ljava/lang/Float;

    .line 84
    .line 85
    goto :goto_56

    .line 86
    :cond_55
    const/4 p1, 0x0

    .line 87
    :goto_56
    if-eqz p1, :cond_61

    .line 88
    .line 89
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    iget-object v0, v5, Lu10/d;->a:Lu10/b;

    .line 94
    .line 95
    invoke-virtual {v0, p1}, Landroid/view/View;->setAlpha(F)V

    .line 96
    .line 97
    .line 98
    :cond_61
    return-void

    .line 99
    :pswitch_62
    check-cast v5, Lu10/c;

    .line 100
    .line 101
    invoke-static {p1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    iget-object v0, v5, Lu10/c;->b:Landroid/view/View;

    .line 105
    .line 106
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    check-cast p1, Ljava/lang/Float;

    .line 114
    .line 115
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 116
    .line 117
    .line 118
    move-result p1

    .line 119
    invoke-virtual {v0, p1}, Landroid/view/View;->setAlpha(F)V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :pswitch_7a
    check-cast v5, Lcom/discord/chat/presentation/message/view/voicemessages/AudioProgressBar;

    .line 124
    .line 125
    sget v0, Lcom/discord/chat/presentation/message/view/voicemessages/AudioProgressBar;->N:I

    .line 126
    .line 127
    const-string v0, "animation"

    .line 128
    .line 129
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    check-cast p1, Ljava/lang/Float;

    .line 140
    .line 141
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 142
    .line 143
    .line 144
    move-result p1

    .line 145
    iput p1, v5, Lcom/discord/chat/presentation/message/view/voicemessages/AudioProgressBar;->w:F

    .line 146
    .line 147
    invoke-virtual {v5}, Landroid/view/View;->invalidate()V

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :pswitch_96
    check-cast v5, Lr7/v;

    .line 152
    .line 153
    iget-object p1, v5, Lr7/v;->n0:Lr7/a;

    .line 154
    .line 155
    if-eqz p1, :cond_9d

    .line 156
    .line 157
    goto :goto_9f

    .line 158
    :cond_9d
    sget-object p1, Lr7/a;->d:Lr7/a;

    .line 159
    .line 160
    :goto_9f
    sget-object v0, Lr7/a;->e:Lr7/a;

    .line 161
    .line 162
    if-ne p1, v0, :cond_a7

    .line 163
    .line 164
    invoke-virtual {v5}, Lr7/v;->invalidateSelf()V

    .line 165
    .line 166
    .line 167
    goto :goto_b4

    .line 168
    :cond_a7
    iget-object p1, v5, Lr7/v;->S:Lz7/c;

    .line 169
    .line 170
    if-eqz p1, :cond_b4

    .line 171
    .line 172
    iget-object v0, v5, Lr7/v;->e:Ld8/e;

    .line 173
    .line 174
    invoke-virtual {v0}, Ld8/e;->d()F

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    invoke-virtual {p1, v0}, Lz7/c;->s(F)V

    .line 179
    .line 180
    .line 181
    :cond_b4
    :goto_b4
    return-void

    .line 182
    :pswitch_b5
    check-cast v5, Lcom/google/android/exoplayer2/ui/DefaultTimeBar;

    .line 183
    .line 184
    sget v0, Lcom/google/android/exoplayer2/ui/DefaultTimeBar;->s0:I

    .line 185
    .line 186
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 187
    .line 188
    .line 189
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    check-cast p1, Ljava/lang/Float;

    .line 194
    .line 195
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 196
    .line 197
    .line 198
    move-result p1

    .line 199
    iput p1, v5, Lcom/google/android/exoplayer2/ui/DefaultTimeBar;->j0:F

    .line 200
    .line 201
    iget-object p1, v5, Lcom/google/android/exoplayer2/ui/DefaultTimeBar;->d:Landroid/graphics/Rect;

    .line 202
    .line 203
    invoke-virtual {v5, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 204
    .line 205
    .line 206
    return-void

    .line 207
    :pswitch_ce
    check-cast v5, Liw/m;

    .line 208
    .line 209
    iget-object p1, v5, Liw/m;->S:Liw/p;

    .line 210
    .line 211
    iget-object v0, v5, Liw/m;->X:Landroid/animation/TimeInterpolator;

    .line 212
    .line 213
    iget-object v1, v5, Liw/m;->W:Landroid/animation/ValueAnimator;

    .line 214
    .line 215
    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    .line 216
    .line 217
    .line 218
    move-result v1

    .line 219
    invoke-interface {v0, v1}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    iput v0, p1, Liw/p;->d:F

    .line 224
    .line 225
    return-void

    .line 226
    :pswitch_e1
    check-cast v5, Landroid/app/Activity;

    .line 227
    .line 228
    invoke-static {p1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v5}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    if-eqz v0, :cond_fc

    .line 236
    .line 237
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object p1

    .line 241
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    check-cast p1, Ljava/lang/Integer;

    .line 245
    .line 246
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 247
    .line 248
    .line 249
    move-result p1

    .line 250
    invoke-virtual {v0, p1}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 251
    .line 252
    .line 253
    :cond_fc
    return-void

    .line 254
    :pswitch_fd
    check-cast v5, Landroid/view/Window;

    .line 255
    .line 256
    invoke-static {p1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object p1

    .line 263
    invoke-static {p1, v4}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    check-cast p1, Ljava/lang/Integer;

    .line 267
    .line 268
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 269
    .line 270
    .line 271
    move-result p1

    .line 272
    invoke-virtual {v5, p1}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 273
    .line 274
    .line 275
    return-void

    .line 276
    :pswitch_113
    check-cast v5, La6/h;

    .line 277
    .line 278
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 279
    .line 280
    .line 281
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object p1

    .line 285
    check-cast p1, Ljava/lang/Float;

    .line 286
    .line 287
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 288
    .line 289
    .line 290
    move-result p1

    .line 291
    iput p1, v5, La6/h;->k0:F

    .line 292
    .line 293
    iget-object p1, v5, La6/h;->d:Landroid/graphics/Rect;

    .line 294
    .line 295
    invoke-virtual {v5, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 296
    .line 297
    .line 298
    return-void

    .line 299
    :pswitch_data_12a
    .packed-switch 0x0
        :pswitch_113
        :pswitch_fd
        :pswitch_e1
        :pswitch_ce
        :pswitch_b5
        :pswitch_96
        :pswitch_7a
        :pswitch_62
        :pswitch_45
        :pswitch_2a
    .end packed-switch
.end method
