###### Class a6.f (a6.f)
.class public final synthetic La6/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La6/f;->d:I

    iput-object p2, p0, La6/f;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcom/google/firebase/messaging/k;Landroid/content/Intent;)V
    .registers 3

    .line 2
    const/16 p1, 0x11

    iput p1, p0, La6/f;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La6/f;->e:Ljava/lang/Object;

    return-void
.end method

.method private final a()V
    .registers 5

    .line 1
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->m:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v1

    .line 8
    const/4 v2, 0x0

    .line 9
    :try_start_8
    iput-boolean v2, v0, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->s:Z

    .line 10
    .line 11
    iget-boolean v2, v0, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->t:Z
    :try_end_c
    .catchall {:try_start_8 .. :try_end_c} :catchall_1a

    .line 12
    .line 13
    if-eqz v2, :cond_10

    .line 14
    .line 15
    monitor-exit v1

    .line 16
    return-void

    .line 17
    :cond_10
    :try_start_10
    invoke-virtual {v0}, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->c()Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_1c

    .line 22
    .line 23
    invoke-virtual {v0}, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->f()V

    .line 24
    .line 25
    .line 26
    goto :goto_1c

    .line 27
    :catchall_1a
    move-exception v0

    .line 28
    goto :goto_2a

    .line 29
    :cond_1c
    :goto_1c
    iget-object v2, v0, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->r:Lorg/chromium/net/UrlRequest;
    :try_end_1e
    .catchall {:try_start_10 .. :try_end_1e} :catchall_1a

    .line 30
    .line 31
    if-nez v2, :cond_22

    .line 32
    .line 33
    monitor-exit v1

    .line 34
    return-void

    .line 35
    :cond_22
    const/4 v3, 0x0

    .line 36
    :try_start_23
    iput-object v3, v0, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->r:Lorg/chromium/net/UrlRequest;

    .line 37
    .line 38
    invoke-virtual {v0, v2}, Lcom/margelo/nitro/nitrofetch/HybridUrlRequestBuilder;->d(Lorg/chromium/net/UrlRequest;)V
    :try_end_28
    .catchall {:try_start_23 .. :try_end_28} :catchall_1a

    .line 39
    .line 40
    .line 41
    monitor-exit v1

    .line 42
    return-void

    .line 43
    :goto_2a
    monitor-exit v1

    .line 44
    throw v0
.end method


# virtual methods
.method public final run()V
    .registers 9

    .line 1
    iget v0, p0, La6/f;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    packed-switch v0, :pswitch_data_268

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Le/g;

    .line 11
    .line 12
    iget-object v1, v0, Le/g;->e:Ljava/lang/Runnable;

    .line 13
    .line 14
    if-eqz v1, :cond_14

    .line 15
    .line 16
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 17
    .line 18
    .line 19
    iput-object v2, v0, Le/g;->e:Ljava/lang/Runnable;

    .line 20
    .line 21
    :cond_14
    return-void

    .line 22
    :pswitch_15
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Ldg/c;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    const/high16 v2, 0x40000000    # 2.0f

    .line 31
    .line 32
    invoke-static {v1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    invoke-static {v3, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    invoke-virtual {v0, v1, v2}, Landroid/view/View;->measure(II)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    .line 60
    .line 61
    .line 62
    move-result v4

    .line 63
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/view/View;->layout(IIII)V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :pswitch_42
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast v0, Lcom/swmansion/worklets/AndroidUIScheduler;

    .line 70
    .line 71
    invoke-static {v0}, Lcom/swmansion/worklets/AndroidUIScheduler;->a(Lcom/swmansion/worklets/AndroidUIScheduler;)V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :pswitch_4a
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v0, Lcom/swmansion/reanimated/css/MainThreadCommandQueue;

    .line 78
    .line 79
    invoke-static {v0}, Lcom/swmansion/reanimated/css/MainThreadCommandQueue;->a(Lcom/swmansion/reanimated/css/MainThreadCommandQueue;)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :pswitch_52
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v0, Lcom/swmansion/reanimated/css/CSSPlatformTransitionsManager;

    .line 86
    .line 87
    invoke-static {v0}, Lcom/swmansion/reanimated/css/CSSPlatformTransitionsManager;->b(Lcom/swmansion/reanimated/css/CSSPlatformTransitionsManager;)V

    .line 88
    .line 89
    .line 90
    return-void

    .line 91
    :pswitch_5a
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v0, [Ljava/lang/Runnable;

    .line 94
    .line 95
    invoke-static {v0}, Lcom/swmansion/reanimated/Utils;->a([Ljava/lang/Runnable;)V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :pswitch_62
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast v0, Lcom/reactnativecommunity/webview/i;

    .line 102
    .line 103
    invoke-static {v0}, Lcom/reactnativecommunity/webview/RNCWebViewManager;->b(Lcom/reactnativecommunity/webview/i;)V

    .line 104
    .line 105
    .line 106
    return-void

    .line 107
    :pswitch_6a
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast v0, Lapp/rive/runtime/kotlin/core/File;

    .line 110
    .line 111
    invoke-static {v0}, Lcom/margelo/nitro/rive/HybridRiveFile;->b(Lapp/rive/runtime/kotlin/core/File;)V

    .line 112
    .line 113
    .line 114
    return-void

    .line 115
    :pswitch_72
    invoke-direct {p0}, La6/f;->a()V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :pswitch_76
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 120
    .line 121
    check-cast v0, Lcom/margelo/nitro/nitrofetch/f0;

    .line 122
    .line 123
    iget-object v1, v0, Lcom/margelo/nitro/nitrofetch/f0;->d:Ljava/lang/Object;

    .line 124
    .line 125
    monitor-enter v1

    .line 126
    :try_start_7d
    invoke-virtual {v0}, Lcom/margelo/nitro/nitrofetch/f0;->g()V
    :try_end_80
    .catchall {:try_start_7d .. :try_end_80} :catchall_82

    .line 127
    .line 128
    .line 129
    monitor-exit v1

    .line 130
    return-void

    .line 131
    :catchall_82
    move-exception v0

    .line 132
    monitor-exit v1

    .line 133
    throw v0

    .line 134
    :pswitch_85
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v0, Lcom/google/firebase/messaging/e0;

    .line 137
    .line 138
    const-string v1, "FirebaseMessaging"

    .line 139
    .line 140
    new-instance v3, Ljava/lang/StringBuilder;

    .line 141
    .line 142
    const-string v4, "Service took too long to process intent: "

    .line 143
    .line 144
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    iget-object v4, v0, Lcom/google/firebase/messaging/e0;->a:Landroid/content/Intent;

    .line 148
    .line 149
    invoke-virtual {v4}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v4

    .line 153
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    const-string v4, " finishing."

    .line 157
    .line 158
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 159
    .line 160
    .line 161
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v3

    .line 165
    invoke-static {v1, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 166
    .line 167
    .line 168
    iget-object v0, v0, Lcom/google/firebase/messaging/e0;->b:Lnv/h;

    .line 169
    .line 170
    invoke-virtual {v0, v2}, Lnv/h;->d(Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    return-void

    .line 174
    :pswitch_ad
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 175
    .line 176
    check-cast v0, Lim/c;

    .line 177
    .line 178
    iget-object v1, v0, Lim/c;->v:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast v1, Ljava/util/ArrayDeque;

    .line 181
    .line 182
    monitor-enter v1

    .line 183
    :try_start_b6
    iget-object v2, v0, Lim/c;->d:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast v2, Landroid/content/SharedPreferences;

    .line 186
    .line 187
    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    iget-object v3, v0, Lim/c;->e:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v3, Ljava/lang/String;

    .line 194
    .line 195
    new-instance v4, Ljava/lang/StringBuilder;

    .line 196
    .line 197
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 198
    .line 199
    .line 200
    iget-object v5, v0, Lim/c;->v:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast v5, Ljava/util/ArrayDeque;

    .line 203
    .line 204
    invoke-virtual {v5}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 205
    .line 206
    .line 207
    move-result-object v5

    .line 208
    :goto_cf
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 209
    .line 210
    .line 211
    move-result v6

    .line 212
    if-eqz v6, :cond_e6

    .line 213
    .line 214
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v6

    .line 218
    check-cast v6, Ljava/lang/String;

    .line 219
    .line 220
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 221
    .line 222
    .line 223
    iget-object v6, v0, Lim/c;->i:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v6, Ljava/lang/String;

    .line 226
    .line 227
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 228
    .line 229
    .line 230
    goto :goto_cf

    .line 231
    :cond_e6
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    invoke-interface {v2, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 240
    .line 241
    .line 242
    monitor-exit v1

    .line 243
    return-void

    .line 244
    :catchall_f3
    move-exception v0

    .line 245
    monitor-exit v1
    :try_end_f5
    .catchall {:try_start_b6 .. :try_end_f5} :catchall_f3

    .line 246
    throw v0

    .line 247
    :pswitch_f6
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v0, Landroid/content/Intent;

    .line 250
    .line 251
    invoke-static {v0}, Lcom/google/firebase/messaging/k;->a(Landroid/content/Intent;)V

    .line 252
    .line 253
    .line 254
    return-void

    .line 255
    :pswitch_fe
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 256
    .line 257
    check-cast v0, Lcom/facebook/react/uimanager/d1;

    .line 258
    .line 259
    invoke-virtual {v0}, Lcom/facebook/react/uimanager/d1;->invoke()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    return-void

    .line 263
    :pswitch_106
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast v0, Lcom/facebook/react/uimanager/c1;

    .line 266
    .line 267
    invoke-virtual {v0}, Lcom/facebook/react/uimanager/c1;->invoke()Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    return-void

    .line 271
    :pswitch_10e
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 272
    .line 273
    check-cast v0, Lcom/facebook/react/uimanager/c1;

    .line 274
    .line 275
    invoke-virtual {v0}, Lcom/facebook/react/uimanager/c1;->invoke()Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    return-void

    .line 279
    :pswitch_116
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 280
    .line 281
    check-cast v0, Lcom/facebook/react/fabric/mounting/SurfaceMountingManager;

    .line 282
    .line 283
    invoke-static {v0}, Lcom/facebook/react/fabric/mounting/SurfaceMountingManager;->e(Lcom/facebook/react/fabric/mounting/SurfaceMountingManager;)V

    .line 284
    .line 285
    .line 286
    return-void

    .line 287
    :pswitch_11e
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 288
    .line 289
    check-cast v0, Lcom/discord/crash_reporting/v;

    .line 290
    .line 291
    sget-object v2, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;

    .line 292
    .line 293
    sget-object v2, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;

    .line 294
    .line 295
    if-nez v2, :cond_12e

    .line 296
    .line 297
    sget-object v1, Lcom/discord/crash_reporting/s;->b:Ljava/util/ArrayDeque;

    .line 298
    .line 299
    invoke-virtual {v1, v0}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 300
    .line 301
    .line 302
    goto :goto_168

    .line 303
    :cond_12e
    sget-object v3, Lcom/discord/crash_reporting/s;->c:Ljava/util/ArrayDeque;

    .line 304
    .line 305
    invoke-virtual {v3, v0}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 306
    .line 307
    .line 308
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 309
    .line 310
    .line 311
    move-result-wide v4

    .line 312
    invoke-virtual {v3}, Ljava/util/ArrayDeque;->size()I

    .line 313
    .line 314
    .line 315
    move-result v0

    .line 316
    const/16 v3, 0xc8

    .line 317
    .line 318
    if-ge v0, v3, :cond_165

    .line 319
    .line 320
    sget-wide v6, Lcom/discord/crash_reporting/s;->d:J

    .line 321
    .line 322
    sub-long/2addr v4, v6

    .line 323
    const-wide/16 v6, 0xc8

    .line 324
    .line 325
    cmp-long v0, v4, v6

    .line 326
    .line 327
    if-ltz v0, :cond_149

    .line 328
    .line 329
    goto :goto_165

    .line 330
    :cond_149
    sget-boolean v0, Lcom/discord/crash_reporting/s;->e:Z

    .line 331
    .line 332
    if-nez v0, :cond_168

    .line 333
    .line 334
    if-eqz v0, :cond_150

    .line 335
    .line 336
    goto :goto_168

    .line 337
    :cond_150
    sput-boolean v1, Lcom/discord/crash_reporting/s;->e:Z

    .line 338
    .line 339
    invoke-static {}, Lcom/discord/crash_reporting/s;->d()Ljava/util/concurrent/ScheduledExecutorService;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    new-instance v1, La6/n0;

    .line 344
    .line 345
    const/4 v2, 0x5

    .line 346
    invoke-direct {v1, v2}, La6/n0;-><init>(I)V

    .line 347
    .line 348
    .line 349
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 350
    .line 351
    invoke-interface {v0, v1, v6, v7, v2}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    sput-object v0, Lcom/discord/crash_reporting/s;->f:Ljava/util/concurrent/ScheduledFuture;

    .line 356
    .line 357
    goto :goto_168

    .line 358
    :cond_165
    :goto_165
    invoke-static {v2}, Lcom/discord/crash_reporting/s;->c(Lcom/discord/crash_reporting/x;)V

    .line 359
    .line 360
    .line 361
    :cond_168
    :goto_168
    return-void

    .line 362
    :pswitch_169
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v0, Lci/a;

    .line 365
    .line 366
    invoke-static {v0}, Lsg/a;->N(Landroid/view/View;)V

    .line 367
    .line 368
    .line 369
    return-void

    .line 370
    :pswitch_171
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 371
    .line 372
    check-cast v0, Lc4/g;

    .line 373
    .line 374
    iget-object v1, v0, Lc4/g;->a:Ljava/lang/Object;

    .line 375
    .line 376
    monitor-enter v1

    .line 377
    :try_start_178
    iget-boolean v2, v0, Lc4/g;->m:Z

    .line 378
    .line 379
    if-eqz v2, :cond_180

    .line 380
    .line 381
    monitor-exit v1

    .line 382
    goto :goto_1a5

    .line 383
    :catchall_17e
    move-exception v0

    .line 384
    goto :goto_1a6

    .line 385
    :cond_180
    iget-wide v2, v0, Lc4/g;->l:J

    .line 386
    .line 387
    const-wide/16 v4, 0x1

    .line 388
    .line 389
    sub-long/2addr v2, v4

    .line 390
    iput-wide v2, v0, Lc4/g;->l:J

    .line 391
    .line 392
    const-wide/16 v4, 0x0

    .line 393
    .line 394
    cmp-long v2, v2, v4

    .line 395
    .line 396
    if-lez v2, :cond_18f

    .line 397
    .line 398
    monitor-exit v1

    .line 399
    goto :goto_1a5

    .line 400
    :cond_18f
    if-gez v2, :cond_1a1

    .line 401
    .line 402
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 403
    .line 404
    invoke-direct {v2}, Ljava/lang/IllegalStateException;-><init>()V

    .line 405
    .line 406
    .line 407
    iget-object v3, v0, Lc4/g;->a:Ljava/lang/Object;

    .line 408
    .line 409
    monitor-enter v3
    :try_end_199
    .catchall {:try_start_178 .. :try_end_199} :catchall_17e

    .line 410
    :try_start_199
    iput-object v2, v0, Lc4/g;->n:Ljava/lang/IllegalStateException;

    .line 411
    .line 412
    monitor-exit v3
    :try_end_19c
    .catchall {:try_start_199 .. :try_end_19c} :catchall_19e

    .line 413
    :try_start_19c
    monitor-exit v1
    :try_end_19d
    .catchall {:try_start_19c .. :try_end_19d} :catchall_17e

    .line 414
    goto :goto_1a5

    .line 415
    :catchall_19e
    move-exception v0

    .line 416
    :try_start_19f
    monitor-exit v3
    :try_end_1a0
    .catchall {:try_start_19f .. :try_end_1a0} :catchall_19e

    .line 417
    :try_start_1a0
    throw v0

    .line 418
    :cond_1a1
    invoke-virtual {v0}, Lc4/g;->a()V

    .line 419
    .line 420
    .line 421
    monitor-exit v1

    .line 422
    :goto_1a5
    return-void

    .line 423
    :goto_1a6
    monitor-exit v1
    :try_end_1a7
    .catchall {:try_start_1a0 .. :try_end_1a7} :catchall_17e

    .line 424
    throw v0

    .line 425
    :pswitch_1a8
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 426
    .line 427
    check-cast v0, Landroidx/work/CoroutineWorker;

    .line 428
    .line 429
    iget-object v1, v0, Landroidx/work/CoroutineWorker;->x:Lm7/j;

    .line 430
    .line 431
    iget-object v1, v1, Lm7/h;->d:Ljava/lang/Object;

    .line 432
    .line 433
    instance-of v1, v1, Lm7/a;

    .line 434
    .line 435
    if-eqz v1, :cond_1b9

    .line 436
    .line 437
    iget-object v0, v0, Landroidx/work/CoroutineWorker;->w:Lz60/e1;

    .line 438
    .line 439
    invoke-virtual {v0, v2}, Lz60/k1;->d(Ljava/util/concurrent/CancellationException;)V

    .line 440
    .line 441
    .line 442
    :cond_1b9
    return-void

    .line 443
    :pswitch_1ba
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 444
    .line 445
    check-cast v0, Lb3/x0;

    .line 446
    .line 447
    iget-object v0, v0, Lb3/x0;->n:Ljava/util/ArrayList;

    .line 448
    .line 449
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 450
    .line 451
    .line 452
    move-result-object v0

    .line 453
    :goto_1c4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 454
    .line 455
    .line 456
    move-result v1

    .line 457
    if-eqz v1, :cond_1d4

    .line 458
    .line 459
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    check-cast v1, Lb3/t0;

    .line 464
    .line 465
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 466
    .line 467
    .line 468
    goto :goto_1c4

    .line 469
    :cond_1d4
    return-void

    .line 470
    :pswitch_1d5
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 471
    .line 472
    check-cast v0, Lb3/a0;

    .line 473
    .line 474
    iget-object v1, v0, Lb3/a0;->s0:Lb3/n1;

    .line 475
    .line 476
    iget-object v3, v0, Lb3/a0;->v:Landroid/os/Bundle;

    .line 477
    .line 478
    iget-object v1, v1, Lb3/n1;->w:Lio/sentry/internal/debugmeta/c;

    .line 479
    .line 480
    invoke-virtual {v1, v3}, Lio/sentry/internal/debugmeta/c;->w(Landroid/os/Bundle;)V

    .line 481
    .line 482
    .line 483
    iput-object v2, v0, Lb3/a0;->v:Landroid/os/Bundle;

    .line 484
    .line 485
    return-void

    .line 486
    :pswitch_1e5
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 487
    .line 488
    check-cast v0, Lb3/p;

    .line 489
    .line 490
    const/4 v1, 0x2

    .line 491
    invoke-static {v1}, Lb3/x0;->M(I)Z

    .line 492
    .line 493
    .line 494
    move-result v1

    .line 495
    if-eqz v1, :cond_1f7

    .line 496
    .line 497
    const-string v1, "FragmentManager"

    .line 498
    .line 499
    const-string v2, "Transition for all operations has completed"

    .line 500
    .line 501
    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 502
    .line 503
    .line 504
    :cond_1f7
    iget-object v1, v0, Lb3/p;->c:Ljava/util/ArrayList;

    .line 505
    .line 506
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 507
    .line 508
    .line 509
    move-result-object v1

    .line 510
    :goto_1fd
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 511
    .line 512
    .line 513
    move-result v2

    .line 514
    if-eqz v2, :cond_211

    .line 515
    .line 516
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    move-result-object v2

    .line 520
    check-cast v2, Lb3/q;

    .line 521
    .line 522
    iget-object v2, v2, Lb3/l;->e:Ljava/lang/Object;

    .line 523
    .line 524
    check-cast v2, Lb3/q1;

    .line 525
    .line 526
    invoke-virtual {v2, v0}, Lb3/q1;->c(Lb3/p1;)V

    .line 527
    .line 528
    .line 529
    goto :goto_1fd

    .line 530
    :cond_211
    return-void

    .line 531
    :pswitch_212
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 532
    .line 533
    check-cast v0, Ljava/util/ArrayList;

    .line 534
    .line 535
    const/4 v1, 0x4

    .line 536
    invoke-static {v1, v0}, Lb3/g1;->a(ILjava/util/ArrayList;)V

    .line 537
    .line 538
    .line 539
    return-void

    .line 540
    :pswitch_21b
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 541
    .line 542
    check-cast v0, Lkotlin/jvm/internal/u;

    .line 543
    .line 544
    const-string v1, "$seekCancelLambda"

    .line 545
    .line 546
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 547
    .line 548
    .line 549
    iget-object v0, v0, Lkotlin/jvm/internal/u;->d:Ljava/lang/Object;

    .line 550
    .line 551
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 552
    .line 553
    if-eqz v0, :cond_22d

    .line 554
    .line 555
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 556
    .line 557
    .line 558
    :cond_22d
    return-void

    .line 559
    :pswitch_22e
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 560
    .line 561
    check-cast v0, Landroidx/lifecycle/ProcessLifecycleOwner;

    .line 562
    .line 563
    iget-object v2, v0, Landroidx/lifecycle/ProcessLifecycleOwner;->x:Landroidx/lifecycle/x;

    .line 564
    .line 565
    iget v3, v0, Landroidx/lifecycle/ProcessLifecycleOwner;->e:I

    .line 566
    .line 567
    if-nez v3, :cond_23f

    .line 568
    .line 569
    iput-boolean v1, v0, Landroidx/lifecycle/ProcessLifecycleOwner;->i:Z

    .line 570
    .line 571
    sget-object v3, Landroidx/lifecycle/m;->ON_PAUSE:Landroidx/lifecycle/m;

    .line 572
    .line 573
    invoke-virtual {v2, v3}, Landroidx/lifecycle/x;->e(Landroidx/lifecycle/m;)V

    .line 574
    .line 575
    .line 576
    :cond_23f
    iget v3, v0, Landroidx/lifecycle/ProcessLifecycleOwner;->d:I

    .line 577
    .line 578
    if-nez v3, :cond_24e

    .line 579
    .line 580
    iget-boolean v3, v0, Landroidx/lifecycle/ProcessLifecycleOwner;->i:Z

    .line 581
    .line 582
    if-eqz v3, :cond_24e

    .line 583
    .line 584
    sget-object v3, Landroidx/lifecycle/m;->ON_STOP:Landroidx/lifecycle/m;

    .line 585
    .line 586
    invoke-virtual {v2, v3}, Landroidx/lifecycle/x;->e(Landroidx/lifecycle/m;)V

    .line 587
    .line 588
    .line 589
    iput-boolean v1, v0, Landroidx/lifecycle/ProcessLifecycleOwner;->v:Z

    .line 590
    .line 591
    :cond_24e
    return-void

    .line 592
    :pswitch_24f
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 593
    .line 594
    check-cast v0, Landroidx/media3/ui/PlayerView;

    .line 595
    .line 596
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 597
    .line 598
    .line 599
    return-void

    .line 600
    :pswitch_257
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 601
    .line 602
    check-cast v0, La6/w;

    .line 603
    .line 604
    invoke-virtual {v0}, La6/w;->s()V

    .line 605
    .line 606
    .line 607
    return-void

    .line 608
    :pswitch_25f
    iget-object v0, p0, La6/f;->e:Ljava/lang/Object;

    .line 609
    .line 610
    check-cast v0, La6/h;

    .line 611
    .line 612
    const/4 v1, 0x0

    .line 613
    invoke-virtual {v0, v1}, La6/h;->d(Z)V

    .line 614
    .line 615
    .line 616
    return-void

    .line 617
    :pswitch_data_268
    .packed-switch 0x0
        :pswitch_25f
        :pswitch_257
        :pswitch_24f
        :pswitch_22e
        :pswitch_21b
        :pswitch_212
        :pswitch_1e5
        :pswitch_1d5
        :pswitch_1ba
        :pswitch_1a8
        :pswitch_171
        :pswitch_169
        :pswitch_11e
        :pswitch_116
        :pswitch_10e
        :pswitch_106
        :pswitch_fe
        :pswitch_f6
        :pswitch_ad
        :pswitch_85
        :pswitch_76
        :pswitch_72
        :pswitch_6a
        :pswitch_62
        :pswitch_5a
        :pswitch_52
        :pswitch_4a
        :pswitch_42
        :pswitch_15
    .end packed-switch
.end method
