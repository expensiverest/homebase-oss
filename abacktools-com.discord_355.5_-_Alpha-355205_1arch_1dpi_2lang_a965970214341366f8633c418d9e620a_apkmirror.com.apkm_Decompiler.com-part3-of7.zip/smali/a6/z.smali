###### Class a6.z (a6.z)
.class public final La6/z;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:La6/b0;


# direct methods
.method public synthetic constructor <init>(La6/b0;I)V
    .registers 3

    .line 1
    iput p2, p0, La6/z;->a:I

    iput-object p1, p0, La6/z;->b:La6/b0;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .registers 4

    .line 1
    iget v0, p0, La6/z;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_4e

    .line 4
    .line 5
    .line 6
    :pswitch_5
    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationEnd(Landroid/animation/Animator;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_9
    iget-object p1, p0, La6/z;->b:La6/b0;

    .line 11
    .line 12
    iget-object p1, p1, La6/b0;->i:Landroid/view/ViewGroup;

    .line 13
    .line 14
    if-eqz p1, :cond_13

    .line 15
    .line 16
    const/4 v0, 0x4

    .line 17
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 18
    .line 19
    .line 20
    :cond_13
    return-void

    .line 21
    :pswitch_14
    iget-object p1, p0, La6/z;->b:La6/b0;

    .line 22
    .line 23
    iget-object p1, p1, La6/b0;->g:Landroid/view/ViewGroup;

    .line 24
    .line 25
    if-eqz p1, :cond_1e

    .line 26
    .line 27
    const/4 v0, 0x4

    .line 28
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    :cond_1e
    return-void

    .line 32
    :pswitch_1f
    iget-object p1, p0, La6/z;->b:La6/b0;

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    invoke-virtual {p1, v0}, La6/b0;->i(I)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_26
    iget-object p1, p0, La6/z;->b:La6/b0;

    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    invoke-virtual {p1, v0}, La6/b0;->i(I)V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :pswitch_2d
    iget-object p1, p0, La6/z;->b:La6/b0;

    .line 47
    .line 48
    iget-object v0, p1, La6/b0;->b:Landroid/view/View;

    .line 49
    .line 50
    const/4 v1, 0x4

    .line 51
    if-eqz v0, :cond_37

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 54
    .line 55
    .line 56
    :cond_37
    iget-object v0, p1, La6/b0;->c:Landroid/view/ViewGroup;

    .line 57
    .line 58
    if-eqz v0, :cond_3e

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 61
    .line 62
    .line 63
    :cond_3e
    iget-object v0, p1, La6/b0;->d:Landroid/view/ViewGroup;

    .line 64
    .line 65
    if-eqz v0, :cond_45

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 68
    .line 69
    .line 70
    :cond_45
    iget-object p1, p1, La6/b0;->f:Landroid/view/ViewGroup;

    .line 71
    .line 72
    if-eqz p1, :cond_4c

    .line 73
    .line 74
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 75
    .line 76
    .line 77
    :cond_4c
    return-void

    .line 78
    nop

    .line 79
    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_2d
        :pswitch_5
        :pswitch_26
        :pswitch_1f
        :pswitch_14
        :pswitch_9
    .end packed-switch
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .registers 10

    .line 1
    iget p1, p0, La6/z;->a:I

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    const/4 v1, 0x2

    .line 5
    const-wide/16 v2, 0xfa

    .line 6
    .line 7
    const/4 v4, 0x4

    .line 8
    const/4 v5, 0x0

    .line 9
    iget-object v6, p0, La6/z;->b:La6/b0;

    .line 10
    .line 11
    packed-switch p1, :pswitch_data_b0

    .line 12
    .line 13
    .line 14
    iget-object p1, v6, La6/b0;->g:Landroid/view/ViewGroup;

    .line 15
    .line 16
    if-eqz p1, :cond_14

    .line 17
    .line 18
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void

    .line 22
    :pswitch_15
    iget-object p1, v6, La6/b0;->i:Landroid/view/ViewGroup;

    .line 23
    .line 24
    if-eqz p1, :cond_2f

    .line 25
    .line 26
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 27
    .line 28
    .line 29
    iget-object p1, v6, La6/b0;->i:Landroid/view/ViewGroup;

    .line 30
    .line 31
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    int-to-float v0, v0

    .line 36
    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationX(F)V

    .line 37
    .line 38
    .line 39
    iget-object p1, v6, La6/b0;->i:Landroid/view/ViewGroup;

    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    invoke-virtual {p1, v0, v5}, Landroid/view/View;->scrollTo(II)V

    .line 46
    .line 47
    .line 48
    :cond_2f
    return-void

    .line 49
    :pswitch_30
    invoke-virtual {v6, v4}, La6/b0;->i(I)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :pswitch_34
    invoke-virtual {v6, v4}, La6/b0;->i(I)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :pswitch_38
    iget-object p1, v6, La6/b0;->b:Landroid/view/View;

    .line 58
    .line 59
    if-eqz p1, :cond_3f

    .line 60
    .line 61
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 62
    .line 63
    .line 64
    :cond_3f
    iget-object p1, v6, La6/b0;->c:Landroid/view/ViewGroup;

    .line 65
    .line 66
    if-eqz p1, :cond_46

    .line 67
    .line 68
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 69
    .line 70
    .line 71
    :cond_46
    iget-object p1, v6, La6/b0;->d:Landroid/view/ViewGroup;

    .line 72
    .line 73
    if-eqz p1, :cond_4d

    .line 74
    .line 75
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 76
    .line 77
    .line 78
    :cond_4d
    iget-object p1, v6, La6/b0;->f:Landroid/view/ViewGroup;

    .line 79
    .line 80
    if-eqz p1, :cond_59

    .line 81
    .line 82
    iget-boolean v7, v6, La6/b0;->B:Z

    .line 83
    .line 84
    if-eqz v7, :cond_56

    .line 85
    .line 86
    move v4, v5

    .line 87
    :cond_56
    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 88
    .line 89
    .line 90
    :cond_59
    iget-object p1, v6, La6/b0;->k:Landroid/view/View;

    .line 91
    .line 92
    instance-of v4, p1, La6/h;

    .line 93
    .line 94
    if-eqz v4, :cond_85

    .line 95
    .line 96
    iget-boolean v4, v6, La6/b0;->B:Z

    .line 97
    .line 98
    if-nez v4, :cond_85

    .line 99
    .line 100
    check-cast p1, La6/h;

    .line 101
    .line 102
    iget-object v4, p1, La6/h;->j0:Landroid/animation/ValueAnimator;

    .line 103
    .line 104
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->isStarted()Z

    .line 105
    .line 106
    .line 107
    move-result v6

    .line 108
    if-eqz v6, :cond_70

    .line 109
    .line 110
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->cancel()V

    .line 111
    .line 112
    .line 113
    :cond_70
    iput-boolean v5, p1, La6/h;->l0:Z

    .line 114
    .line 115
    iget p1, p1, La6/h;->k0:F

    .line 116
    .line 117
    new-array v1, v1, [F

    .line 118
    .line 119
    aput p1, v1, v5

    .line 120
    .line 121
    const/high16 p1, 0x3f800000    # 1.0f

    .line 122
    .line 123
    aput p1, v1, v0

    .line 124
    .line 125
    invoke-virtual {v4, v1}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v4, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->start()V

    .line 132
    .line 133
    .line 134
    :cond_85
    return-void

    .line 135
    :pswitch_86
    iget-object p1, v6, La6/b0;->k:Landroid/view/View;

    .line 136
    .line 137
    instance-of v4, p1, La6/h;

    .line 138
    .line 139
    if-eqz v4, :cond_af

    .line 140
    .line 141
    iget-boolean v4, v6, La6/b0;->B:Z

    .line 142
    .line 143
    if-nez v4, :cond_af

    .line 144
    .line 145
    check-cast p1, La6/h;

    .line 146
    .line 147
    iget-object v4, p1, La6/h;->j0:Landroid/animation/ValueAnimator;

    .line 148
    .line 149
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->isStarted()Z

    .line 150
    .line 151
    .line 152
    move-result v6

    .line 153
    if-eqz v6, :cond_9d

    .line 154
    .line 155
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->cancel()V

    .line 156
    .line 157
    .line 158
    :cond_9d
    iget p1, p1, La6/h;->k0:F

    .line 159
    .line 160
    new-array v1, v1, [F

    .line 161
    .line 162
    aput p1, v1, v5

    .line 163
    .line 164
    const/4 p1, 0x0

    .line 165
    aput p1, v1, v0

    .line 166
    .line 167
    invoke-virtual {v4, v1}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v4, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 171
    .line 172
    .line 173
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->start()V

    .line 174
    .line 175
    .line 176
    :cond_af
    return-void

    .line 177
    :pswitch_data_b0
    .packed-switch 0x0
        :pswitch_86
        :pswitch_38
        :pswitch_34
        :pswitch_30
        :pswitch_15
    .end packed-switch
.end method
