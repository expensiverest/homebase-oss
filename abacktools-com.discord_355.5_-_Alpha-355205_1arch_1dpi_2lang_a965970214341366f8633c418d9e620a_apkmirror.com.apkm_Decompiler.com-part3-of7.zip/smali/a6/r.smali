###### Class a6.r (a6.r)
.class public final La6/r;
.super Le6/n0;
.source "SourceFile"


# instance fields
.field public final synthetic d:I

.field public final e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public final g:Ljava/lang/Object;

.field public final h:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La6/w;[Ljava/lang/String;[Landroid/graphics/drawable/Drawable;)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, La6/r;->d:I

    .line 7
    iput-object p1, p0, La6/r;->h:Ljava/lang/Object;

    invoke-direct {p0}, Le6/n0;-><init>()V

    .line 8
    iput-object p2, p0, La6/r;->e:Ljava/lang/Object;

    .line 9
    array-length p1, p2

    new-array p1, p1, [Ljava/lang/String;

    iput-object p1, p0, La6/r;->f:Ljava/lang/Object;

    .line 10
    iput-object p3, p0, La6/r;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/discord/fastest_list/android/FastestListLayoutManager;Lae/d;Lg8/y;Lcom/margelo/nitro/nitrofetch/k;)V
    .registers 6

    const/4 v0, 0x1

    iput v0, p0, La6/r;->d:I

    .line 1
    invoke-direct {p0}, Le6/n0;-><init>()V

    .line 2
    iput-object p1, p0, La6/r;->e:Ljava/lang/Object;

    .line 3
    iput-object p2, p0, La6/r;->f:Ljava/lang/Object;

    .line 4
    iput-object p3, p0, La6/r;->g:Ljava/lang/Object;

    .line 5
    iput-object p4, p0, La6/r;->h:Ljava/lang/Object;

    .line 6
    invoke-virtual {p0}, Le6/n0;->m()V

    return-void
.end method


# virtual methods
.method public final b()I
    .registers 2

    .line 1
    iget v0, p0, La6/r;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La6/r;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lg8/y;

    .line 9
    .line 10
    iget-object v0, v0, Lg8/y;->b:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    return v0

    .line 17
    :pswitch_10
    iget-object v0, p0, La6/r;->e:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, [Ljava/lang/String;

    .line 20
    .line 21
    array-length v0, v0

    .line 22
    return v0

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_10
    .end packed-switch
.end method

.method public final c(I)J
    .registers 4

    .line 1
    iget v0, p0, La6/r;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1c

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La6/r;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lg8/y;

    .line 9
    .line 10
    iget-object v0, v0, Lg8/y;->b:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, Lzd/g;

    .line 17
    .line 18
    invoke-virtual {p1}, Lzd/g;->a()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-static {p1}, Lw70/m;->i(Ljava/lang/CharSequence;)J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    return-wide v0

    .line 27
    :pswitch_1a
    int-to-long v0, p1

    .line 28
    return-wide v0

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_1a
    .end packed-switch
.end method

.method public d(I)I
    .registers 3

    .line 1
    iget v0, p0, La6/r;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_3c

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1}, Le6/n0;->d(I)I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    return p1

    .line 11
    :pswitch_a
    iget-object v0, p0, La6/r;->g:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lg8/y;

    .line 14
    .line 15
    iget-object v0, v0, Lg8/y;->b:Ljava/util/ArrayList;

    .line 16
    .line 17
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    check-cast p1, Lzd/g;

    .line 22
    .line 23
    instance-of v0, p1, Lzd/e;

    .line 24
    .line 25
    if-eqz v0, :cond_1c

    .line 26
    .line 27
    const/4 p1, 0x1

    .line 28
    goto :goto_33

    .line 29
    :cond_1c
    instance-of v0, p1, Lzd/d;

    .line 30
    .line 31
    if-eqz v0, :cond_22

    .line 32
    .line 33
    const/4 p1, 0x2

    .line 34
    goto :goto_33

    .line 35
    :cond_22
    instance-of v0, p1, Lzd/f;

    .line 36
    .line 37
    if-eqz v0, :cond_28

    .line 38
    .line 39
    const/4 p1, 0x0

    .line 40
    goto :goto_33

    .line 41
    :cond_28
    instance-of v0, p1, Lzd/b;

    .line 42
    .line 43
    if-eqz v0, :cond_2e

    .line 44
    .line 45
    const/4 p1, 0x4

    .line 46
    goto :goto_33

    .line 47
    :cond_2e
    instance-of p1, p1, Lzd/c;

    .line 48
    .line 49
    if-eqz p1, :cond_34

    .line 50
    .line 51
    const/4 p1, 0x3

    .line 52
    :goto_33
    return p1

    .line 53
    :cond_34
    new-instance p1, Lan/g;

    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    invoke-direct {p1, v0}, Lan/g;-><init>(Z)V

    .line 57
    .line 58
    .line 59
    throw p1

    .line 60
    nop

    .line 61
    :pswitch_data_3c
    .packed-switch 0x1
        :pswitch_a
    .end packed-switch
.end method

.method public final f(Le6/l1;I)V
    .registers 11

    .line 1
    iget v0, p0, La6/r;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, -0x1

    .line 5
    iget-object v3, p0, La6/r;->e:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v4, p0, La6/r;->g:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_10c

    .line 10
    .line 11
    .line 12
    check-cast p1, Lce/b;

    .line 13
    .line 14
    check-cast v4, Lg8/y;

    .line 15
    .line 16
    iget-object v0, v4, Lg8/y;->b:Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    check-cast p2, Lzd/g;

    .line 23
    .line 24
    check-cast v3, Lcom/discord/fastest_list/android/FastestListLayoutManager;

    .line 25
    .line 26
    iget-boolean v0, v3, Lcom/discord/fastest_list/android/FastestListLayoutManager;->j0:Z

    .line 27
    .line 28
    iget-object v3, p0, La6/r;->f:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v3, Lae/d;

    .line 31
    .line 32
    iget-object v4, p1, Lce/b;->u:Lce/c;

    .line 33
    .line 34
    const-string v5, "item"

    .line 35
    .line 36
    invoke-static {p2, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    const-string v5, "placeholderConfig"

    .line 40
    .line 41
    invoke-static {v3, v5}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v5, p1, Lce/b;->x:Ljava/lang/String;

    .line 45
    .line 46
    if-eqz v5, :cond_3c

    .line 47
    .line 48
    invoke-virtual {p2}, Lzd/g;->a()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    invoke-virtual {v5, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v6

    .line 56
    if-nez v6, :cond_3c

    .line 57
    .line 58
    invoke-static {v5, p1}, Lvh/b;->c(Ljava/lang/String;Lce/b;)V

    .line 59
    .line 60
    .line 61
    :cond_3c
    iput-object p2, p1, Lce/b;->A:Lzd/g;

    .line 62
    .line 63
    iput-boolean v0, p1, Lce/b;->B:Z

    .line 64
    .line 65
    invoke-virtual {p2}, Lzd/g;->a()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    iput-object v5, p1, Lce/b;->x:Ljava/lang/String;

    .line 70
    .line 71
    invoke-virtual {p2}, Lzd/g;->c()I

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    if-eqz v6, :cond_bc

    .line 80
    .line 81
    check-cast v6, Le6/v0;

    .line 82
    .line 83
    if-eqz v0, :cond_56

    .line 84
    .line 85
    move v7, v5

    .line 86
    goto :goto_57

    .line 87
    :cond_56
    move v7, v2

    .line 88
    :goto_57
    iput v7, v6, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 89
    .line 90
    if-eqz v0, :cond_5c

    .line 91
    .line 92
    goto :goto_5d

    .line 93
    :cond_5c
    move v2, v5

    .line 94
    :goto_5d
    iput v2, v6, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 95
    .line 96
    invoke-virtual {v4, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 97
    .line 98
    .line 99
    iget-object v0, v3, Lae/d;->e:Lae/i;

    .line 100
    .line 101
    instance-of v2, p2, Lzd/f;

    .line 102
    .line 103
    if-eqz v2, :cond_8e

    .line 104
    .line 105
    move-object v1, p2

    .line 106
    check-cast v1, Lzd/f;

    .line 107
    .line 108
    iget-boolean v2, v1, Lzd/f;->f:Z

    .line 109
    .line 110
    iget-boolean v1, v1, Lzd/f;->e:Z

    .line 111
    .line 112
    if-eqz v1, :cond_7c

    .line 113
    .line 114
    if-eqz v2, :cond_7c

    .line 115
    .line 116
    iget-object v1, v3, Lae/d;->h:Lae/i;

    .line 117
    .line 118
    instance-of v2, v1, Lae/f;

    .line 119
    .line 120
    if-eqz v2, :cond_7a

    .line 121
    .line 122
    goto :goto_a9

    .line 123
    :cond_7a
    move-object v0, v1

    .line 124
    goto :goto_a9

    .line 125
    :cond_7c
    if-eqz v1, :cond_85

    .line 126
    .line 127
    iget-object v1, v3, Lae/d;->f:Lae/i;

    .line 128
    .line 129
    instance-of v2, v1, Lae/f;

    .line 130
    .line 131
    if-eqz v2, :cond_7a

    .line 132
    .line 133
    goto :goto_a9

    .line 134
    :cond_85
    if-eqz v2, :cond_a9

    .line 135
    .line 136
    iget-object v1, v3, Lae/d;->g:Lae/i;

    .line 137
    .line 138
    instance-of v2, v1, Lae/f;

    .line 139
    .line 140
    if-eqz v2, :cond_7a

    .line 141
    .line 142
    goto :goto_a9

    .line 143
    :cond_8e
    instance-of v0, p2, Lzd/b;

    .line 144
    .line 145
    if-eqz v0, :cond_95

    .line 146
    .line 147
    iget-object v0, v3, Lae/d;->a:Lae/i;

    .line 148
    .line 149
    goto :goto_a9

    .line 150
    :cond_95
    instance-of v0, p2, Lzd/c;

    .line 151
    .line 152
    if-eqz v0, :cond_9c

    .line 153
    .line 154
    iget-object v0, v3, Lae/d;->b:Lae/i;

    .line 155
    .line 156
    goto :goto_a9

    .line 157
    :cond_9c
    instance-of v0, p2, Lzd/d;

    .line 158
    .line 159
    if-eqz v0, :cond_a3

    .line 160
    .line 161
    iget-object v0, v3, Lae/d;->c:Lae/i;

    .line 162
    .line 163
    goto :goto_a9

    .line 164
    :cond_a3
    instance-of v0, p2, Lzd/e;

    .line 165
    .line 166
    if-eqz v0, :cond_b6

    .line 167
    .line 168
    iget-object v0, v3, Lae/d;->d:Lae/i;

    .line 169
    .line 170
    :cond_a9
    :goto_a9
    invoke-virtual {p1, v4, v0}, Lce/b;->v(Landroid/view/ViewGroup;Lae/i;)V

    .line 171
    .line 172
    .line 173
    sget-object v0, Lvh/b;->a:Ljava/util/HashMap;

    .line 174
    .line 175
    invoke-virtual {p2}, Lzd/g;->a()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object p2

    .line 179
    invoke-static {p2, p1}, Lvh/b;->a(Ljava/lang/String;Lvh/a;)V

    .line 180
    .line 181
    .line 182
    return-void

    .line 183
    :cond_b6
    new-instance p1, Lan/g;

    .line 184
    .line 185
    invoke-direct {p1, v1}, Lan/g;-><init>(Z)V

    .line 186
    .line 187
    .line 188
    throw p1

    .line 189
    :cond_bc
    new-instance p1, Ljava/lang/NullPointerException;

    .line 190
    .line 191
    const-string p2, "null cannot be cast to non-null type androidx.recyclerview.widget.RecyclerView.LayoutParams"

    .line 192
    .line 193
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    throw p1

    .line 197
    :pswitch_c4
    check-cast p1, La6/q;

    .line 198
    .line 199
    iget-object v0, p1, Le6/l1;->a:Landroid/view/View;

    .line 200
    .line 201
    invoke-virtual {p0, p2}, La6/r;->n(I)Z

    .line 202
    .line 203
    .line 204
    move-result v5

    .line 205
    if-eqz v5, :cond_d8

    .line 206
    .line 207
    new-instance v1, Le6/v0;

    .line 208
    .line 209
    const/4 v5, -0x2

    .line 210
    invoke-direct {v1, v2, v5}, Le6/v0;-><init>(II)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 214
    .line 215
    .line 216
    goto :goto_e0

    .line 217
    :cond_d8
    new-instance v2, Le6/v0;

    .line 218
    .line 219
    invoke-direct {v2, v1, v1}, Le6/v0;-><init>(II)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 223
    .line 224
    .line 225
    :goto_e0
    iget-object v0, p1, La6/q;->u:Landroid/widget/TextView;

    .line 226
    .line 227
    iget-object v1, p1, La6/q;->w:Landroid/widget/ImageView;

    .line 228
    .line 229
    iget-object p1, p1, La6/q;->v:Landroid/widget/TextView;

    .line 230
    .line 231
    check-cast v3, [Ljava/lang/String;

    .line 232
    .line 233
    aget-object v2, v3, p2

    .line 234
    .line 235
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 236
    .line 237
    .line 238
    iget-object v0, p0, La6/r;->f:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v0, [Ljava/lang/String;

    .line 241
    .line 242
    aget-object v0, v0, p2

    .line 243
    .line 244
    const/16 v2, 0x8

    .line 245
    .line 246
    if-nez v0, :cond_fb

    .line 247
    .line 248
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 249
    .line 250
    .line 251
    goto :goto_fe

    .line 252
    :cond_fb
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 253
    .line 254
    .line 255
    :goto_fe
    check-cast v4, [Landroid/graphics/drawable/Drawable;

    .line 256
    .line 257
    aget-object p1, v4, p2

    .line 258
    .line 259
    if-nez p1, :cond_108

    .line 260
    .line 261
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 262
    .line 263
    .line 264
    goto :goto_10b

    .line 265
    :cond_108
    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 266
    .line 267
    .line 268
    :goto_10b
    return-void

    .line 269
    :pswitch_data_10c
    .packed-switch 0x0
        :pswitch_c4
    .end packed-switch
.end method

.method public final h(Landroid/view/ViewGroup;I)Le6/l1;
    .registers 6

    .line 1
    iget v0, p0, La6/r;->d:I

    .line 2
    .line 3
    iget-object v1, p0, La6/r;->h:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_70

    .line 6
    .line 7
    .line 8
    check-cast v1, Lcom/margelo/nitro/nitrofetch/k;

    .line 9
    .line 10
    const-string v0, "parent"

    .line 11
    .line 12
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v0, "onUnexpectedItemSize"

    .line 16
    .line 17
    if-eqz p2, :cond_4e

    .line 18
    .line 19
    const/4 v2, 0x1

    .line 20
    if-eq p2, v2, :cond_45

    .line 21
    .line 22
    const/4 v2, 0x2

    .line 23
    if-eq p2, v2, :cond_3c

    .line 24
    .line 25
    const/4 v2, 0x3

    .line 26
    if-eq p2, v2, :cond_33

    .line 27
    .line 28
    const/4 v2, 0x4

    .line 29
    if-ne p2, v2, :cond_27

    .line 30
    .line 31
    new-instance p2, Lce/b;

    .line 32
    .line 33
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-direct {p2, p1, v1}, Lce/b;-><init>(Landroid/view/ViewGroup;Lkotlin/jvm/functions/Function2;)V

    .line 37
    .line 38
    .line 39
    goto :goto_56

    .line 40
    :cond_27
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 41
    .line 42
    const-string v0, "Unknown view type "

    .line 43
    .line 44
    invoke-static {p2, v0}, Lhs/q;->j(ILjava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p1

    .line 52
    :cond_33
    new-instance p2, Lce/b;

    .line 53
    .line 54
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-direct {p2, p1, v1}, Lce/b;-><init>(Landroid/view/ViewGroup;Lkotlin/jvm/functions/Function2;)V

    .line 58
    .line 59
    .line 60
    goto :goto_56

    .line 61
    :cond_3c
    new-instance p2, Lce/b;

    .line 62
    .line 63
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    invoke-direct {p2, p1, v1}, Lce/b;-><init>(Landroid/view/ViewGroup;Lkotlin/jvm/functions/Function2;)V

    .line 67
    .line 68
    .line 69
    goto :goto_56

    .line 70
    :cond_45
    new-instance p2, Lce/b;

    .line 71
    .line 72
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-direct {p2, p1, v1}, Lce/b;-><init>(Landroid/view/ViewGroup;Lkotlin/jvm/functions/Function2;)V

    .line 76
    .line 77
    .line 78
    goto :goto_56

    .line 79
    :cond_4e
    new-instance p2, Lce/b;

    .line 80
    .line 81
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-direct {p2, p1, v1}, Lce/b;-><init>(Landroid/view/ViewGroup;Lkotlin/jvm/functions/Function2;)V

    .line 85
    .line 86
    .line 87
    :goto_56
    return-object p2

    .line 88
    :pswitch_57
    check-cast v1, La6/w;

    .line 89
    .line 90
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 95
    .line 96
    .line 97
    move-result-object p2

    .line 98
    const v0, 0x7f0d005b

    .line 99
    .line 100
    .line 101
    const/4 v2, 0x0

    .line 102
    invoke-virtual {p2, v0, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    new-instance p2, La6/q;

    .line 107
    .line 108
    invoke-direct {p2, v1, p1}, La6/q;-><init>(La6/w;Landroid/view/View;)V

    .line 109
    .line 110
    .line 111
    return-object p2

    .line 112
    nop

    .line 113
    :pswitch_data_70
    .packed-switch 0x0
        :pswitch_57
    .end packed-switch
.end method

.method public l(Le6/l1;)V
    .registers 3

    .line 1
    iget v0, p0, La6/r;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_18

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_6
    check-cast p1, Lce/b;

    .line 8
    .line 9
    const-string v0, "holder"

    .line 10
    .line 11
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p1, Lce/b;->x:Ljava/lang/String;

    .line 15
    .line 16
    if-eqz v0, :cond_14

    .line 17
    .line 18
    invoke-static {v0, p1}, Lvh/b;->c(Ljava/lang/String;Lce/b;)V

    .line 19
    .line 20
    .line 21
    :cond_14
    const/4 v0, 0x0

    .line 22
    iput-object v0, p1, Lce/b;->x:Ljava/lang/String;

    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_data_18
    .packed-switch 0x1
        :pswitch_6
    .end packed-switch
.end method

.method public n(I)Z
    .registers 6

    .line 1
    iget-object v0, p0, La6/r;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, La6/w;

    .line 4
    .line 5
    iget-object v1, v0, La6/w;->S0:Lk3/e1;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    if-eqz p1, :cond_24

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    if-eq p1, v3, :cond_10

    .line 15
    .line 16
    return v3

    .line 17
    :cond_10
    const/16 p1, 0x1e

    .line 18
    .line 19
    invoke-interface {v1, p1}, Lk3/e1;->D1(I)Z

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    if-eqz p1, :cond_23

    .line 24
    .line 25
    iget-object p1, v0, La6/w;->S0:Lk3/e1;

    .line 26
    .line 27
    const/16 v0, 0x1d

    .line 28
    .line 29
    invoke-interface {p1, v0}, Lk3/e1;->D1(I)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_23

    .line 34
    .line 35
    return v3

    .line 36
    :cond_23
    return v2

    .line 37
    :cond_24
    const/16 p1, 0xd

    .line 38
    .line 39
    invoke-interface {v1, p1}, Lk3/e1;->D1(I)Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    return p1
.end method
