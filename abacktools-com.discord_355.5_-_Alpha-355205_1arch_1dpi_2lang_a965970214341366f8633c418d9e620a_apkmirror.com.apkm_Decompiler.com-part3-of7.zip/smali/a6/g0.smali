###### Class a6.g0 (a6.g0)
.class public final La6/g0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static F:I


# instance fields
.field public final A:Z

.field public final B:I

.field public final C:I

.field public final D:I

.field public final E:Z

.field public final a:Landroid/content/Context;

.field public final b:Ljava/lang/String;

.field public final c:I

.field public final d:La8/d;

.field public final e:Landroid/os/Handler;

.field public final f:Le1/a1;

.field public final g:Landroid/content/IntentFilter;

.field public final h:La6/f0;

.field public final i:La6/e0;

.field public final j:Ljava/util/HashMap;

.field public final k:Ljava/util/Map;

.field public final l:Landroid/app/PendingIntent;

.field public final m:I

.field public n:Le1/b0;

.field public o:Ljava/util/ArrayList;

.field public p:Lk3/e1;

.field public q:Z

.field public r:I

.field public s:Landroid/media/session/MediaSession$Token;

.field public t:Z

.field public u:Z

.field public v:Z

.field public w:Z

.field public final x:Z

.field public final y:Z

.field public final z:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;ILa8/d;IIIIIIII)V
    .registers 15

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, La6/g0;->a:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p2, p0, La6/g0;->b:Ljava/lang/String;

    .line 11
    .line 12
    iput p3, p0, La6/g0;->c:I

    .line 13
    .line 14
    iput-object p4, p0, La6/g0;->d:La8/d;

    .line 15
    .line 16
    iput p5, p0, La6/g0;->B:I

    .line 17
    .line 18
    sget p2, La6/g0;->F:I

    .line 19
    .line 20
    add-int/lit8 p3, p2, 0x1

    .line 21
    .line 22
    sput p3, La6/g0;->F:I

    .line 23
    .line 24
    iput p2, p0, La6/g0;->m:I

    .line 25
    .line 26
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 27
    .line 28
    .line 29
    move-result-object p3

    .line 30
    new-instance p4, La6/c0;

    .line 31
    .line 32
    const/4 p5, 0x0

    .line 33
    invoke-direct {p4, p5, p0}, La6/c0;-><init>(ILjava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    sget-object v0, Ln3/l0;->a:Ljava/lang/String;

    .line 37
    .line 38
    new-instance v0, Landroid/os/Handler;

    .line 39
    .line 40
    invoke-direct {v0, p3, p4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    .line 41
    .line 42
    .line 43
    iput-object v0, p0, La6/g0;->e:Landroid/os/Handler;

    .line 44
    .line 45
    new-instance p3, Le1/a1;

    .line 46
    .line 47
    invoke-direct {p3, p1}, Le1/a1;-><init>(Landroid/content/Context;)V

    .line 48
    .line 49
    .line 50
    iput-object p3, p0, La6/g0;->f:Le1/a1;

    .line 51
    .line 52
    new-instance p3, La6/f0;

    .line 53
    .line 54
    invoke-direct {p3, p5, p0}, La6/f0;-><init>(ILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iput-object p3, p0, La6/g0;->h:La6/f0;

    .line 58
    .line 59
    new-instance p3, La6/e0;

    .line 60
    .line 61
    invoke-direct {p3, p5, p0}, La6/e0;-><init>(ILjava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    iput-object p3, p0, La6/g0;->i:La6/e0;

    .line 65
    .line 66
    new-instance p3, Landroid/content/IntentFilter;

    .line 67
    .line 68
    invoke-direct {p3}, Landroid/content/IntentFilter;-><init>()V

    .line 69
    .line 70
    .line 71
    iput-object p3, p0, La6/g0;->g:Landroid/content/IntentFilter;

    .line 72
    .line 73
    const/4 p3, 0x1

    .line 74
    iput-boolean p3, p0, La6/g0;->t:Z

    .line 75
    .line 76
    iput-boolean p3, p0, La6/g0;->u:Z

    .line 77
    .line 78
    iput-boolean p3, p0, La6/g0;->x:Z

    .line 79
    .line 80
    iput-boolean p3, p0, La6/g0;->y:Z

    .line 81
    .line 82
    iput-boolean p3, p0, La6/g0;->v:Z

    .line 83
    .line 84
    iput-boolean p3, p0, La6/g0;->w:Z

    .line 85
    .line 86
    iput-boolean p3, p0, La6/g0;->A:Z

    .line 87
    .line 88
    iput-boolean p3, p0, La6/g0;->E:Z

    .line 89
    .line 90
    const/4 p4, -0x1

    .line 91
    iput p4, p0, La6/g0;->D:I

    .line 92
    .line 93
    iput p3, p0, La6/g0;->z:I

    .line 94
    .line 95
    iput p3, p0, La6/g0;->C:I

    .line 96
    .line 97
    new-instance p3, Ljava/util/HashMap;

    .line 98
    .line 99
    invoke-direct {p3}, Ljava/util/HashMap;-><init>()V

    .line 100
    .line 101
    .line 102
    new-instance p4, Le1/u;

    .line 103
    .line 104
    const p5, 0x7f1300a1

    .line 105
    .line 106
    .line 107
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object p5

    .line 111
    const-string v0, "androidx.media3.ui.notification.play"

    .line 112
    .line 113
    invoke-static {p2, p1, v0}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    invoke-direct {p4, p6, p5, v1}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {p3, v0, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    new-instance p4, Le1/u;

    .line 124
    .line 125
    const p5, 0x7f1300a0

    .line 126
    .line 127
    .line 128
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object p5

    .line 132
    const-string p6, "androidx.media3.ui.notification.pause"

    .line 133
    .line 134
    invoke-static {p2, p1, p6}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-direct {p4, p7, p5, v0}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {p3, p6, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    new-instance p4, Le1/u;

    .line 145
    .line 146
    const p5, 0x7f1300ad

    .line 147
    .line 148
    .line 149
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object p5

    .line 153
    const-string p6, "androidx.media3.ui.notification.stop"

    .line 154
    .line 155
    invoke-static {p2, p1, p6}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 156
    .line 157
    .line 158
    move-result-object p7

    .line 159
    invoke-direct {p4, p8, p5, p7}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {p3, p6, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    new-instance p4, Le1/u;

    .line 166
    .line 167
    const p5, 0x7f1300a7

    .line 168
    .line 169
    .line 170
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object p5

    .line 174
    const-string p6, "androidx.media3.ui.notification.rewind"

    .line 175
    .line 176
    invoke-static {p2, p1, p6}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 177
    .line 178
    .line 179
    move-result-object p7

    .line 180
    invoke-direct {p4, p9, p5, p7}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {p3, p6, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    new-instance p4, Le1/u;

    .line 187
    .line 188
    const p5, 0x7f130099

    .line 189
    .line 190
    .line 191
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object p5

    .line 195
    const-string p6, "androidx.media3.ui.notification.ffwd"

    .line 196
    .line 197
    invoke-static {p2, p1, p6}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 198
    .line 199
    .line 200
    move-result-object p7

    .line 201
    invoke-direct {p4, p10, p5, p7}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p3, p6, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    new-instance p4, Le1/u;

    .line 208
    .line 209
    const p5, 0x7f1300a3

    .line 210
    .line 211
    .line 212
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object p5

    .line 216
    const-string p6, "androidx.media3.ui.notification.prev"

    .line 217
    .line 218
    invoke-static {p2, p1, p6}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 219
    .line 220
    .line 221
    move-result-object p7

    .line 222
    invoke-direct {p4, p11, p5, p7}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {p3, p6, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    new-instance p4, Le1/u;

    .line 229
    .line 230
    const p5, 0x7f13009d

    .line 231
    .line 232
    .line 233
    invoke-virtual {p1, p5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    move-result-object p5

    .line 237
    const-string p6, "androidx.media3.ui.notification.next"

    .line 238
    .line 239
    invoke-static {p2, p1, p6}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 240
    .line 241
    .line 242
    move-result-object p2

    .line 243
    invoke-direct {p4, p12, p5, p2}, Le1/u;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {p3, p6, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    iput-object p3, p0, La6/g0;->j:Ljava/util/HashMap;

    .line 250
    .line 251
    invoke-virtual {p3}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 252
    .line 253
    .line 254
    move-result-object p2

    .line 255
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 256
    .line 257
    .line 258
    move-result-object p2

    .line 259
    :goto_102
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 260
    .line 261
    .line 262
    move-result p3

    .line 263
    if-eqz p3, :cond_114

    .line 264
    .line 265
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object p3

    .line 269
    check-cast p3, Ljava/lang/String;

    .line 270
    .line 271
    iget-object p4, p0, La6/g0;->g:Landroid/content/IntentFilter;

    .line 272
    .line 273
    invoke-virtual {p4, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    goto :goto_102

    .line 277
    :cond_114
    sget-object p2, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 278
    .line 279
    iput-object p2, p0, La6/g0;->k:Ljava/util/Map;

    .line 280
    .line 281
    invoke-interface {p2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 282
    .line 283
    .line 284
    move-result-object p2

    .line 285
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 286
    .line 287
    .line 288
    move-result-object p2

    .line 289
    :goto_120
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 290
    .line 291
    .line 292
    move-result p3

    .line 293
    if-eqz p3, :cond_132

    .line 294
    .line 295
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object p3

    .line 299
    check-cast p3, Ljava/lang/String;

    .line 300
    .line 301
    iget-object p4, p0, La6/g0;->g:Landroid/content/IntentFilter;

    .line 302
    .line 303
    invoke-virtual {p4, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    goto :goto_120

    .line 307
    :cond_132
    iget p2, p0, La6/g0;->m:I

    .line 308
    .line 309
    const-string p3, "androidx.media3.ui.notification.dismiss"

    .line 310
    .line 311
    invoke-static {p2, p1, p3}, La6/g0;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;

    .line 312
    .line 313
    .line 314
    move-result-object p1

    .line 315
    iput-object p1, p0, La6/g0;->l:Landroid/app/PendingIntent;

    .line 316
    .line 317
    iget-object p1, p0, La6/g0;->g:Landroid/content/IntentFilter;

    .line 318
    .line 319
    invoke-virtual {p1, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    return-void
.end method

.method public static a(ILandroid/content/Context;Ljava/lang/String;)Landroid/app/PendingIntent;
    .registers 4

    .line 1
    new-instance v0, Landroid/content/Intent;

    .line 2
    .line 3
    invoke-direct {v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    const-string v0, "INSTANCE_ID"

    .line 15
    .line 16
    invoke-virtual {p2, v0, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 17
    .line 18
    .line 19
    const/high16 v0, 0xc000000

    .line 20
    .line 21
    invoke-static {p1, p0, p2, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0
.end method


# virtual methods
.method public final b(Lv3/w;)V
    .registers 6

    .line 1
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x1

    .line 10
    const/4 v3, 0x0

    .line 11
    if-ne v0, v1, :cond_e

    .line 12
    .line 13
    move v0, v2

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    move v0, v3

    .line 16
    :goto_f
    invoke-static {v0}, Loq/a;->z(Z)V

    .line 17
    .line 18
    .line 19
    if-eqz p1, :cond_1c

    .line 20
    .line 21
    iget-object v0, p1, Lv3/w;->W:Landroid/os/Looper;

    .line 22
    .line 23
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    if-ne v0, v1, :cond_1d

    .line 28
    .line 29
    :cond_1c
    move v3, v2

    .line 30
    :cond_1d
    invoke-static {v3}, Loq/a;->n(Z)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, La6/g0;->p:Lk3/e1;

    .line 34
    .line 35
    if-ne v0, p1, :cond_25

    .line 36
    .line 37
    goto :goto_43

    .line 38
    :cond_25
    iget-object v1, p0, La6/g0;->h:La6/f0;

    .line 39
    .line 40
    if-eqz v0, :cond_31

    .line 41
    .line 42
    invoke-interface {v0, v1}, Lk3/e1;->E0(Lk3/c1;)V

    .line 43
    .line 44
    .line 45
    if-nez p1, :cond_31

    .line 46
    .line 47
    invoke-virtual {p0}, La6/g0;->d()V

    .line 48
    .line 49
    .line 50
    :cond_31
    iput-object p1, p0, La6/g0;->p:Lk3/e1;

    .line 51
    .line 52
    if-eqz p1, :cond_43

    .line 53
    .line 54
    invoke-virtual {p1, v1}, Lv3/w;->o1(Lk3/c1;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, La6/g0;->e:Landroid/os/Handler;

    .line 58
    .line 59
    invoke-virtual {p1, v2}, Landroid/os/Handler;->hasMessages(I)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_43

    .line 64
    .line 65
    invoke-virtual {p1, v2}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    .line 66
    .line 67
    .line 68
    :cond_43
    :goto_43
    return-void
.end method

.method public final c(Lk3/e1;Landroid/graphics/Bitmap;)V
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-interface {v1}, Lk3/e1;->I()I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x3

    .line 10
    const/4 v4, 0x0

    .line 11
    const/4 v5, 0x1

    .line 12
    const/4 v6, 0x2

    .line 13
    if-eq v2, v6, :cond_10

    .line 14
    .line 15
    if-ne v2, v3, :cond_18

    .line 16
    .line 17
    :cond_10
    invoke-interface {v1}, Lk3/e1;->o()Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_18

    .line 22
    .line 23
    move v2, v5

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    move v2, v4

    .line 26
    :goto_19
    iget-object v7, v0, La6/g0;->n:Le1/b0;

    .line 27
    .line 28
    invoke-interface {v1}, Lk3/e1;->I()I

    .line 29
    .line 30
    .line 31
    move-result v8

    .line 32
    iget-object v9, v0, La6/g0;->a:Landroid/content/Context;

    .line 33
    .line 34
    const/4 v10, 0x0

    .line 35
    if-ne v8, v5, :cond_3d

    .line 36
    .line 37
    const/16 v8, 0x11

    .line 38
    .line 39
    invoke-interface {v1, v8}, Lk3/e1;->D1(I)Z

    .line 40
    .line 41
    .line 42
    move-result v8

    .line 43
    if-eqz v8, :cond_3d

    .line 44
    .line 45
    invoke-interface {v1}, Lk3/e1;->U()Lk3/n1;

    .line 46
    .line 47
    .line 48
    move-result-object v8

    .line 49
    invoke-virtual {v8}, Lk3/n1;->p()Z

    .line 50
    .line 51
    .line 52
    move-result v8

    .line 53
    if-eqz v8, :cond_3d

    .line 54
    .line 55
    iput-object v10, v0, La6/g0;->o:Ljava/util/ArrayList;

    .line 56
    .line 57
    move-object v7, v10

    .line 58
    move-object/from16 v16, v7

    .line 59
    .line 60
    goto/16 :goto_219

    .line 61
    .line 62
    :cond_3d
    const/4 v8, 0x7

    .line 63
    invoke-interface {v1, v8}, Lk3/e1;->D1(I)Z

    .line 64
    .line 65
    .line 66
    move-result v8

    .line 67
    const/16 v11, 0xb

    .line 68
    .line 69
    invoke-interface {v1, v11}, Lk3/e1;->D1(I)Z

    .line 70
    .line 71
    .line 72
    move-result v11

    .line 73
    const/16 v12, 0xc

    .line 74
    .line 75
    invoke-interface {v1, v12}, Lk3/e1;->D1(I)Z

    .line 76
    .line 77
    .line 78
    move-result v12

    .line 79
    const/16 v13, 0x9

    .line 80
    .line 81
    invoke-interface {v1, v13}, Lk3/e1;->D1(I)Z

    .line 82
    .line 83
    .line 84
    move-result v13

    .line 85
    new-instance v14, Ljava/util/ArrayList;

    .line 86
    .line 87
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 88
    .line 89
    .line 90
    iget-boolean v15, v0, La6/g0;->t:Z

    .line 91
    .line 92
    if-eqz v15, :cond_64

    .line 93
    .line 94
    if-eqz v8, :cond_64

    .line 95
    .line 96
    const-string v8, "androidx.media3.ui.notification.prev"

    .line 97
    .line 98
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    :cond_64
    iget-boolean v8, v0, La6/g0;->v:Z

    .line 102
    .line 103
    if-eqz v8, :cond_6f

    .line 104
    .line 105
    if-eqz v11, :cond_6f

    .line 106
    .line 107
    const-string v8, "androidx.media3.ui.notification.rewind"

    .line 108
    .line 109
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    :cond_6f
    iget-boolean v8, v0, La6/g0;->x:Z

    .line 113
    .line 114
    const-string v11, "androidx.media3.ui.notification.pause"

    .line 115
    .line 116
    const-string v15, "androidx.media3.ui.notification.play"

    .line 117
    .line 118
    move-object/from16 v16, v10

    .line 119
    .line 120
    iget-boolean v10, v0, La6/g0;->y:Z

    .line 121
    .line 122
    if-eqz v8, :cond_88

    .line 123
    .line 124
    invoke-static {v1, v10}, Ln3/l0;->c0(Lk3/e1;Z)Z

    .line 125
    .line 126
    .line 127
    move-result v8

    .line 128
    if-eqz v8, :cond_85

    .line 129
    .line 130
    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    goto :goto_88

    .line 134
    :cond_85
    invoke-virtual {v14, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    :cond_88
    :goto_88
    iget-boolean v8, v0, La6/g0;->w:Z

    .line 138
    .line 139
    if-eqz v8, :cond_93

    .line 140
    .line 141
    if-eqz v12, :cond_93

    .line 142
    .line 143
    const-string v8, "androidx.media3.ui.notification.ffwd"

    .line 144
    .line 145
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    :cond_93
    iget-boolean v8, v0, La6/g0;->u:Z

    .line 149
    .line 150
    if-eqz v8, :cond_9e

    .line 151
    .line 152
    if-eqz v13, :cond_9e

    .line 153
    .line 154
    const-string v8, "androidx.media3.ui.notification.next"

    .line 155
    .line 156
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    :cond_9e
    new-instance v8, Ljava/util/ArrayList;

    .line 160
    .line 161
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    .line 162
    .line 163
    .line 164
    move-result v12

    .line 165
    invoke-direct {v8, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 166
    .line 167
    .line 168
    move v12, v4

    .line 169
    :goto_a8
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    .line 170
    .line 171
    .line 172
    move-result v13

    .line 173
    if-ge v12, v13, :cond_d4

    .line 174
    .line 175
    invoke-virtual {v14, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v13

    .line 179
    check-cast v13, Ljava/lang/String;

    .line 180
    .line 181
    iget-object v5, v0, La6/g0;->j:Ljava/util/HashMap;

    .line 182
    .line 183
    invoke-virtual {v5, v13}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    move-result v18

    .line 187
    if-eqz v18, :cond_c3

    .line 188
    .line 189
    invoke-virtual {v5, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v5

    .line 193
    check-cast v5, Le1/u;

    .line 194
    .line 195
    goto :goto_cb

    .line 196
    :cond_c3
    iget-object v5, v0, La6/g0;->k:Ljava/util/Map;

    .line 197
    .line 198
    invoke-interface {v5, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v5

    .line 202
    check-cast v5, Le1/u;

    .line 203
    .line 204
    :goto_cb
    if-eqz v5, :cond_d0

    .line 205
    .line 206
    invoke-virtual {v8, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 207
    .line 208
    .line 209
    :cond_d0
    add-int/lit8 v12, v12, 0x1

    .line 210
    .line 211
    const/4 v5, 0x1

    .line 212
    goto :goto_a8

    .line 213
    :cond_d4
    if-eqz v7, :cond_de

    .line 214
    .line 215
    iget-object v5, v0, La6/g0;->o:Ljava/util/ArrayList;

    .line 216
    .line 217
    invoke-virtual {v8, v5}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    .line 218
    .line 219
    .line 220
    move-result v5

    .line 221
    if-nez v5, :cond_fe

    .line 222
    .line 223
    :cond_de
    new-instance v7, Le1/b0;

    .line 224
    .line 225
    iget-object v5, v0, La6/g0;->b:Ljava/lang/String;

    .line 226
    .line 227
    invoke-direct {v7, v9, v5}, Le1/b0;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    iput-object v8, v0, La6/g0;->o:Ljava/util/ArrayList;

    .line 231
    .line 232
    move v5, v4

    .line 233
    :goto_e8
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 234
    .line 235
    .line 236
    move-result v12

    .line 237
    if-ge v5, v12, :cond_fe

    .line 238
    .line 239
    invoke-virtual {v8, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object v12

    .line 243
    check-cast v12, Le1/u;

    .line 244
    .line 245
    if-eqz v12, :cond_fb

    .line 246
    .line 247
    iget-object v13, v7, Le1/b0;->b:Ljava/util/ArrayList;

    .line 248
    .line 249
    invoke-virtual {v13, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 250
    .line 251
    .line 252
    :cond_fb
    add-int/lit8 v5, v5, 0x1

    .line 253
    .line 254
    goto :goto_e8

    .line 255
    :cond_fe
    iget-object v5, v7, Le1/b0;->N:Landroid/app/Notification;

    .line 256
    .line 257
    invoke-virtual {v14, v11}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    .line 258
    .line 259
    .line 260
    move-result v8

    .line 261
    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    .line 262
    .line 263
    .line 264
    move-result v11

    .line 265
    new-array v3, v3, [I

    .line 266
    .line 267
    invoke-static {v1, v10}, Ln3/l0;->c0(Lk3/e1;Z)Z

    .line 268
    .line 269
    .line 270
    move-result v10

    .line 271
    const/4 v12, -0x1

    .line 272
    if-eq v8, v12, :cond_117

    .line 273
    .line 274
    if-nez v10, :cond_117

    .line 275
    .line 276
    aput v8, v3, v4

    .line 277
    .line 278
    :goto_115
    const/4 v8, 0x1

    .line 279
    goto :goto_11f

    .line 280
    :cond_117
    if-eq v11, v12, :cond_11e

    .line 281
    .line 282
    if-eqz v10, :cond_11e

    .line 283
    .line 284
    aput v11, v3, v4

    .line 285
    .line 286
    goto :goto_115

    .line 287
    :cond_11e
    move v8, v4

    .line 288
    :goto_11f
    invoke-static {v3, v8}, Ljava/util/Arrays;->copyOf([II)[I

    .line 289
    .line 290
    .line 291
    move-result-object v3

    .line 292
    new-instance v8, La6/d0;

    .line 293
    .line 294
    iget-object v10, v0, La6/g0;->s:Landroid/media/session/MediaSession$Token;

    .line 295
    .line 296
    invoke-direct {v8, v10, v3}, La6/d0;-><init>(Landroid/media/session/MediaSession$Token;[I)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v7, v8}, Le1/b0;->i(Le1/s0;)V

    .line 300
    .line 301
    .line 302
    iget-object v3, v0, La6/g0;->l:Landroid/app/PendingIntent;

    .line 303
    .line 304
    iput-object v3, v5, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    .line 305
    .line 306
    iget v3, v0, La6/g0;->z:I

    .line 307
    .line 308
    iput v3, v7, Le1/b0;->H:I

    .line 309
    .line 310
    invoke-virtual {v7, v6, v2}, Le1/b0;->f(IZ)V

    .line 311
    .line 312
    .line 313
    iput v4, v7, Le1/b0;->D:I

    .line 314
    .line 315
    iget-boolean v2, v0, La6/g0;->A:Z

    .line 316
    .line 317
    iput-boolean v2, v7, Le1/b0;->z:Z

    .line 318
    .line 319
    const/4 v2, 0x1

    .line 320
    iput-boolean v2, v7, Le1/b0;->A:Z

    .line 321
    .line 322
    iget v2, v0, La6/g0;->B:I

    .line 323
    .line 324
    iput v2, v5, Landroid/app/Notification;->icon:I

    .line 325
    .line 326
    iget v2, v0, La6/g0;->C:I

    .line 327
    .line 328
    iput v2, v7, Le1/b0;->E:I

    .line 329
    .line 330
    iget v2, v0, La6/g0;->D:I

    .line 331
    .line 332
    iput v2, v7, Le1/b0;->m:I

    .line 333
    .line 334
    invoke-virtual {v7, v4}, Le1/b0;->e(I)V

    .line 335
    .line 336
    .line 337
    iget-boolean v2, v0, La6/g0;->E:Z

    .line 338
    .line 339
    if-eqz v2, :cond_18b

    .line 340
    .line 341
    const/16 v2, 0x10

    .line 342
    .line 343
    invoke-interface {v1, v2}, Lk3/e1;->D1(I)Z

    .line 344
    .line 345
    .line 346
    move-result v2

    .line 347
    if-eqz v2, :cond_18b

    .line 348
    .line 349
    invoke-interface {v1}, Lk3/e1;->K()Z

    .line 350
    .line 351
    .line 352
    move-result v2

    .line 353
    if-eqz v2, :cond_18b

    .line 354
    .line 355
    invoke-interface {v1}, Lk3/e1;->l()Z

    .line 356
    .line 357
    .line 358
    move-result v2

    .line 359
    if-nez v2, :cond_18b

    .line 360
    .line 361
    invoke-interface {v1}, Lk3/e1;->N1()Z

    .line 362
    .line 363
    .line 364
    move-result v2

    .line 365
    if-nez v2, :cond_18b

    .line 366
    .line 367
    invoke-interface {v1}, Lk3/e1;->e()Lk3/y0;

    .line 368
    .line 369
    .line 370
    move-result-object v2

    .line 371
    iget v2, v2, Lk3/y0;->a:F

    .line 372
    .line 373
    const/high16 v3, 0x3f800000    # 1.0f

    .line 374
    .line 375
    cmpl-float v2, v2, v3

    .line 376
    .line 377
    if-nez v2, :cond_18b

    .line 378
    .line 379
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 380
    .line 381
    .line 382
    move-result-wide v2

    .line 383
    invoke-interface {v1}, Lk3/e1;->H()J

    .line 384
    .line 385
    .line 386
    move-result-wide v10

    .line 387
    sub-long/2addr v2, v10

    .line 388
    iput-wide v2, v5, Landroid/app/Notification;->when:J

    .line 389
    .line 390
    const/4 v2, 0x1

    .line 391
    iput-boolean v2, v7, Le1/b0;->n:Z

    .line 392
    .line 393
    iput-boolean v2, v7, Le1/b0;->o:Z

    .line 394
    .line 395
    goto :goto_18f

    .line 396
    :cond_18b
    iput-boolean v4, v7, Le1/b0;->n:Z

    .line 397
    .line 398
    iput-boolean v4, v7, Le1/b0;->o:Z

    .line 399
    .line 400
    :goto_18f
    iget-object v2, v0, La6/g0;->d:La8/d;

    .line 401
    .line 402
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 403
    .line 404
    .line 405
    const-string v3, "player"

    .line 406
    .line 407
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 408
    .line 409
    .line 410
    invoke-interface {v1}, Lk3/e1;->Z()Lk3/r0;

    .line 411
    .line 412
    .line 413
    move-result-object v3

    .line 414
    iget-object v3, v3, Lk3/r0;->a:Ljava/lang/CharSequence;

    .line 415
    .line 416
    if-nez v3, :cond_1a3

    .line 417
    .line 418
    const-string v3, ""

    .line 419
    .line 420
    :cond_1a3
    invoke-static {v3}, Le1/b0;->d(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 421
    .line 422
    .line 423
    move-result-object v3

    .line 424
    iput-object v3, v7, Le1/b0;->e:Ljava/lang/CharSequence;

    .line 425
    .line 426
    const-string v3, "player"

    .line 427
    .line 428
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 429
    .line 430
    .line 431
    iget-object v3, v2, La8/d;->e:Ljava/lang/Object;

    .line 432
    .line 433
    check-cast v3, Lcg/l0;

    .line 434
    .line 435
    iget-object v4, v3, Lcg/l0;->a:Landroid/content/Context;

    .line 436
    .line 437
    invoke-virtual {v4}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 438
    .line 439
    .line 440
    move-result-object v4

    .line 441
    iget-object v3, v3, Lcg/l0;->a:Landroid/content/Context;

    .line 442
    .line 443
    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 444
    .line 445
    .line 446
    move-result-object v3

    .line 447
    invoke-virtual {v4, v3}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    .line 448
    .line 449
    .line 450
    move-result-object v3

    .line 451
    const-string v4, "loadLabel(...)"

    .line 452
    .line 453
    invoke-static {v3, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 454
    .line 455
    .line 456
    invoke-static {v3}, Le1/b0;->d(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 457
    .line 458
    .line 459
    move-result-object v3

    .line 460
    iput-object v3, v7, Le1/b0;->f:Ljava/lang/CharSequence;

    .line 461
    .line 462
    invoke-static/range {v16 .. v16}, Le1/b0;->d(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 463
    .line 464
    .line 465
    move-result-object v3

    .line 466
    iput-object v3, v7, Le1/b0;->q:Ljava/lang/CharSequence;

    .line 467
    .line 468
    if-nez p2, :cond_1ea

    .line 469
    .line 470
    new-instance v3, Lay/f;

    .line 471
    .line 472
    iget v4, v0, La6/g0;->r:I

    .line 473
    .line 474
    const/16 v17, 0x1

    .line 475
    .line 476
    add-int/lit8 v4, v4, 0x1

    .line 477
    .line 478
    iput v4, v0, La6/g0;->r:I

    .line 479
    .line 480
    const/4 v4, 0x1

    .line 481
    invoke-direct {v3, v4}, Lay/f;-><init>(I)V

    .line 482
    .line 483
    .line 484
    const-string v3, "player"

    .line 485
    .line 486
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 487
    .line 488
    .line 489
    const/4 v3, 0x0

    .line 490
    goto :goto_1ec

    .line 491
    :cond_1ea
    move-object/from16 v3, p2

    .line 492
    .line 493
    :goto_1ec
    invoke-virtual {v7, v3}, Le1/b0;->g(Landroid/graphics/Bitmap;)V

    .line 494
    .line 495
    .line 496
    const-string v3, "player"

    .line 497
    .line 498
    invoke-static {v1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 499
    .line 500
    .line 501
    iget-object v1, v2, La8/d;->e:Ljava/lang/Object;

    .line 502
    .line 503
    check-cast v1, Lcg/l0;

    .line 504
    .line 505
    iget-object v1, v1, Lcg/l0;->a:Landroid/content/Context;

    .line 506
    .line 507
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 508
    .line 509
    .line 510
    move-result-object v2

    .line 511
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object v3

    .line 515
    invoke-virtual {v2, v3}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 516
    .line 517
    .line 518
    move-result-object v2

    .line 519
    if-eqz v2, :cond_210

    .line 520
    .line 521
    const/4 v3, 0x0

    .line 522
    const/high16 v4, 0xc000000

    .line 523
    .line 524
    invoke-static {v1, v3, v2, v4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 525
    .line 526
    .line 527
    move-result-object v1

    .line 528
    goto :goto_211

    .line 529
    :cond_210
    const/4 v1, 0x0

    .line 530
    :goto_211
    iput-object v1, v7, Le1/b0;->h:Landroid/app/PendingIntent;

    .line 531
    .line 532
    const/16 v1, 0x8

    .line 533
    .line 534
    const/4 v2, 0x1

    .line 535
    invoke-virtual {v7, v1, v2}, Le1/b0;->f(IZ)V

    .line 536
    .line 537
    .line 538
    :goto_219
    iput-object v7, v0, La6/g0;->n:Le1/b0;

    .line 539
    .line 540
    if-nez v7, :cond_221

    .line 541
    .line 542
    invoke-virtual {v0}, La6/g0;->d()V

    .line 543
    .line 544
    .line 545
    return-void

    .line 546
    :cond_221
    invoke-virtual {v7}, Le1/b0;->b()Landroid/app/Notification;

    .line 547
    .line 548
    .line 549
    move-result-object v1

    .line 550
    iget-object v2, v0, La6/g0;->f:Le1/a1;

    .line 551
    .line 552
    iget v3, v0, La6/g0;->c:I

    .line 553
    .line 554
    move-object/from16 v4, v16

    .line 555
    .line 556
    invoke-virtual {v2, v4, v3, v1}, Le1/a1;->g(Ljava/lang/String;ILandroid/app/Notification;)V

    .line 557
    .line 558
    .line 559
    iget-boolean v1, v0, La6/g0;->q:Z

    .line 560
    .line 561
    if-nez v1, :cond_239

    .line 562
    .line 563
    iget-object v1, v0, La6/g0;->i:La6/e0;

    .line 564
    .line 565
    iget-object v2, v0, La6/g0;->g:Landroid/content/IntentFilter;

    .line 566
    .line 567
    invoke-static {v9, v1, v2}, Ln3/l0;->X(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    .line 568
    .line 569
    .line 570
    :cond_239
    const/4 v2, 0x1

    .line 571
    iput-boolean v2, v0, La6/g0;->q:Z

    .line 572
    .line 573
    return-void
.end method

.method public final d()V
    .registers 4

    .line 1
    iget-boolean v0, p0, La6/g0;->q:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1e

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, La6/g0;->q:Z

    .line 7
    .line 8
    iget-object v0, p0, La6/g0;->e:Landroid/os/Handler;

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    .line 12
    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    iget-object v1, p0, La6/g0;->f:Le1/a1;

    .line 16
    .line 17
    iget-object v1, v1, Le1/a1;->b:Landroid/app/NotificationManager;

    .line 18
    .line 19
    iget v2, p0, La6/g0;->c:I

    .line 20
    .line 21
    invoke-virtual {v1, v0, v2}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, La6/g0;->a:Landroid/content/Context;

    .line 25
    .line 26
    iget-object v1, p0, La6/g0;->i:La6/e0;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 29
    .line 30
    .line 31
    :cond_1e
    return-void
.end method
