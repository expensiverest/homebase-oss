###### Class a6.h (a6.h)
.class public final La6/h;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements La6/w0;


# instance fields
.field public final J:Landroid/graphics/Paint;

.field public final K:Landroid/graphics/Paint;

.field public final L:Landroid/graphics/Paint;

.field public final M:Landroid/graphics/drawable/Drawable;

.field public final N:I

.field public final O:I

.field public final P:I

.field public final Q:I

.field public final R:I

.field public final S:I

.field public final T:I

.field public final U:I

.field public final V:I

.field public final W:Ljava/lang/StringBuilder;

.field public final a0:Ljava/util/Formatter;

.field public final b0:La6/f;

.field public final c0:Ljava/util/concurrent/CopyOnWriteArraySet;

.field public final d:Landroid/graphics/Rect;

.field public final d0:Landroid/graphics/Point;

.field public final e:Landroid/graphics/Rect;

.field public final e0:F

.field public f0:I

.field public g0:J

.field public h0:I

.field public final i:Landroid/graphics/Rect;

.field public i0:Landroid/graphics/Rect;

.field public final j0:Landroid/animation/ValueAnimator;

.field public k0:F

.field public l0:Z

.field public m0:Z

.field public n0:J

.field public o0:J

.field public p0:J

.field public q0:J

.field public r0:I

.field public s0:[J

.field public t0:[Z

.field public final v:Landroid/graphics/Rect;

.field public final w:Landroid/graphics/Paint;

.field public final x:Landroid/graphics/Paint;

.field public final y:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 23

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x0

    .line 7
    move-object/from16 v4, p1

    .line 8
    .line 9
    invoke-direct {v1, v4, v2, v3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 10
    .line 11
    .line 12
    new-instance v5, Landroid/graphics/Rect;

    .line 13
    .line 14
    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v5, v1, La6/h;->d:Landroid/graphics/Rect;

    .line 18
    .line 19
    new-instance v5, Landroid/graphics/Rect;

    .line 20
    .line 21
    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v5, v1, La6/h;->e:Landroid/graphics/Rect;

    .line 25
    .line 26
    new-instance v5, Landroid/graphics/Rect;

    .line 27
    .line 28
    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object v5, v1, La6/h;->i:Landroid/graphics/Rect;

    .line 32
    .line 33
    new-instance v5, Landroid/graphics/Rect;

    .line 34
    .line 35
    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object v5, v1, La6/h;->v:Landroid/graphics/Rect;

    .line 39
    .line 40
    new-instance v5, Landroid/graphics/Paint;

    .line 41
    .line 42
    invoke-direct {v5}, Landroid/graphics/Paint;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object v5, v1, La6/h;->w:Landroid/graphics/Paint;

    .line 46
    .line 47
    new-instance v6, Landroid/graphics/Paint;

    .line 48
    .line 49
    invoke-direct {v6}, Landroid/graphics/Paint;-><init>()V

    .line 50
    .line 51
    .line 52
    iput-object v6, v1, La6/h;->x:Landroid/graphics/Paint;

    .line 53
    .line 54
    new-instance v7, Landroid/graphics/Paint;

    .line 55
    .line 56
    invoke-direct {v7}, Landroid/graphics/Paint;-><init>()V

    .line 57
    .line 58
    .line 59
    iput-object v7, v1, La6/h;->y:Landroid/graphics/Paint;

    .line 60
    .line 61
    new-instance v8, Landroid/graphics/Paint;

    .line 62
    .line 63
    invoke-direct {v8}, Landroid/graphics/Paint;-><init>()V

    .line 64
    .line 65
    .line 66
    iput-object v8, v1, La6/h;->J:Landroid/graphics/Paint;

    .line 67
    .line 68
    new-instance v9, Landroid/graphics/Paint;

    .line 69
    .line 70
    invoke-direct {v9}, Landroid/graphics/Paint;-><init>()V

    .line 71
    .line 72
    .line 73
    iput-object v9, v1, La6/h;->K:Landroid/graphics/Paint;

    .line 74
    .line 75
    new-instance v10, Landroid/graphics/Paint;

    .line 76
    .line 77
    invoke-direct {v10}, Landroid/graphics/Paint;-><init>()V

    .line 78
    .line 79
    .line 80
    iput-object v10, v1, La6/h;->L:Landroid/graphics/Paint;

    .line 81
    .line 82
    const/4 v11, 0x1

    .line 83
    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 84
    .line 85
    .line 86
    new-instance v12, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 87
    .line 88
    invoke-direct {v12}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    .line 89
    .line 90
    .line 91
    iput-object v12, v1, La6/h;->c0:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 92
    .line 93
    new-instance v12, Landroid/graphics/Point;

    .line 94
    .line 95
    invoke-direct {v12}, Landroid/graphics/Point;-><init>()V

    .line 96
    .line 97
    .line 98
    iput-object v12, v1, La6/h;->d0:Landroid/graphics/Point;

    .line 99
    .line 100
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 101
    .line 102
    .line 103
    move-result-object v12

    .line 104
    invoke-virtual {v12}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 105
    .line 106
    .line 107
    move-result-object v12

    .line 108
    iget v12, v12, Landroid/util/DisplayMetrics;->density:F

    .line 109
    .line 110
    iput v12, v1, La6/h;->e0:F

    .line 111
    .line 112
    const/16 v13, -0x32

    .line 113
    .line 114
    invoke-static {v12, v13}, La6/h;->a(FI)I

    .line 115
    .line 116
    .line 117
    move-result v13

    .line 118
    iput v13, v1, La6/h;->V:I

    .line 119
    .line 120
    const/4 v13, 0x4

    .line 121
    invoke-static {v12, v13}, La6/h;->a(FI)I

    .line 122
    .line 123
    .line 124
    move-result v14

    .line 125
    const/16 v15, 0x1a

    .line 126
    .line 127
    invoke-static {v12, v15}, La6/h;->a(FI)I

    .line 128
    .line 129
    .line 130
    move-result v15

    .line 131
    invoke-static {v12, v13}, La6/h;->a(FI)I

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    const/16 v13, 0xc

    .line 136
    .line 137
    invoke-static {v12, v13}, La6/h;->a(FI)I

    .line 138
    .line 139
    .line 140
    move-result v11

    .line 141
    invoke-static {v12, v3}, La6/h;->a(FI)I

    .line 142
    .line 143
    .line 144
    move-result v13

    .line 145
    const/16 v3, 0x10

    .line 146
    .line 147
    invoke-static {v12, v3}, La6/h;->a(FI)I

    .line 148
    .line 149
    .line 150
    move-result v3

    .line 151
    if-eqz v0, :cond_147

    .line 152
    .line 153
    invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    sget-object v12, La6/p0;->b:[I

    .line 158
    .line 159
    move-object/from16 v18, v9

    .line 160
    .line 161
    const v9, 0x7f14014c

    .line 162
    .line 163
    .line 164
    move-object/from16 v19, v8

    .line 165
    .line 166
    const/4 v8, 0x0

    .line 167
    invoke-virtual {v4, v0, v12, v8, v9}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 168
    .line 169
    .line 170
    move-result-object v4

    .line 171
    const/16 v0, 0xa

    .line 172
    .line 173
    :try_start_ac
    invoke-virtual {v4, v0}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    iput-object v0, v1, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 178
    .line 179
    if-eqz v0, :cond_c7

    .line 180
    .line 181
    invoke-virtual {v1}, Landroid/view/View;->getLayoutDirection()I

    .line 182
    .line 183
    .line 184
    move-result v8

    .line 185
    invoke-virtual {v0, v8}, Landroid/graphics/drawable/Drawable;->setLayoutDirection(I)Z

    .line 186
    .line 187
    .line 188
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    .line 189
    .line 190
    .line 191
    move-result v0

    .line 192
    invoke-static {v0, v15}, Ljava/lang/Math;->max(II)I

    .line 193
    .line 194
    .line 195
    move-result v15

    .line 196
    goto :goto_c7

    .line 197
    :catchall_c4
    move-exception v0

    .line 198
    goto/16 :goto_143

    .line 199
    .line 200
    :cond_c7
    :goto_c7
    const/4 v0, 0x3

    .line 201
    invoke-virtual {v4, v0, v14}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 202
    .line 203
    .line 204
    move-result v0

    .line 205
    iput v0, v1, La6/h;->N:I

    .line 206
    .line 207
    const/16 v0, 0xc

    .line 208
    .line 209
    invoke-virtual {v4, v0, v15}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    iput v0, v1, La6/h;->O:I

    .line 214
    .line 215
    const/4 v0, 0x2

    .line 216
    const/4 v8, 0x0

    .line 217
    invoke-virtual {v4, v0, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 218
    .line 219
    .line 220
    move-result v9

    .line 221
    iput v9, v1, La6/h;->P:I

    .line 222
    .line 223
    const/4 v0, 0x1

    .line 224
    invoke-virtual {v4, v0, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 225
    .line 226
    .line 227
    move-result v2

    .line 228
    iput v2, v1, La6/h;->Q:I

    .line 229
    .line 230
    const/16 v0, 0xb

    .line 231
    .line 232
    invoke-virtual {v4, v0, v11}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 233
    .line 234
    .line 235
    move-result v0

    .line 236
    iput v0, v1, La6/h;->R:I

    .line 237
    .line 238
    const/16 v0, 0x8

    .line 239
    .line 240
    invoke-virtual {v4, v0, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 241
    .line 242
    .line 243
    move-result v0

    .line 244
    iput v0, v1, La6/h;->S:I

    .line 245
    .line 246
    const/16 v0, 0x9

    .line 247
    .line 248
    invoke-virtual {v4, v0, v3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 249
    .line 250
    .line 251
    move-result v0

    .line 252
    iput v0, v1, La6/h;->T:I

    .line 253
    .line 254
    const/4 v0, 0x6

    .line 255
    const/4 v2, -0x1

    .line 256
    invoke-virtual {v4, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 257
    .line 258
    .line 259
    move-result v0

    .line 260
    const/4 v3, 0x7

    .line 261
    invoke-virtual {v4, v3, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 262
    .line 263
    .line 264
    move-result v2

    .line 265
    const v3, -0x33000001    # -1.3421772E8f

    .line 266
    .line 267
    .line 268
    const/4 v8, 0x4

    .line 269
    invoke-virtual {v4, v8, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 270
    .line 271
    .line 272
    move-result v3

    .line 273
    const/16 v8, 0xd

    .line 274
    .line 275
    const v9, 0x33ffffff

    .line 276
    .line 277
    .line 278
    invoke-virtual {v4, v8, v9}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 279
    .line 280
    .line 281
    move-result v8

    .line 282
    const/4 v9, 0x0

    .line 283
    const v11, -0x4d000100

    .line 284
    .line 285
    .line 286
    invoke-virtual {v4, v9, v11}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 287
    .line 288
    .line 289
    move-result v11

    .line 290
    const/4 v9, 0x5

    .line 291
    const v12, 0x33ffff00

    .line 292
    .line 293
    .line 294
    invoke-virtual {v4, v9, v12}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 295
    .line 296
    .line 297
    move-result v9

    .line 298
    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v10, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v6, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 305
    .line 306
    .line 307
    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 308
    .line 309
    .line 310
    move-object/from16 v0, v19

    .line 311
    .line 312
    invoke-virtual {v0, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 313
    .line 314
    .line 315
    move-object/from16 v8, v18

    .line 316
    .line 317
    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V
    :try_end_13f
    .catchall {:try_start_ac .. :try_end_13f} :catchall_c4

    .line 318
    .line 319
    .line 320
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 321
    .line 322
    .line 323
    goto :goto_17a

    .line 324
    :goto_143
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 325
    .line 326
    .line 327
    throw v0

    .line 328
    :cond_147
    move-object v0, v8

    .line 329
    move-object v8, v9

    .line 330
    iput v14, v1, La6/h;->N:I

    .line 331
    .line 332
    iput v15, v1, La6/h;->O:I

    .line 333
    .line 334
    const/4 v9, 0x0

    .line 335
    iput v9, v1, La6/h;->P:I

    .line 336
    .line 337
    iput v2, v1, La6/h;->Q:I

    .line 338
    .line 339
    iput v11, v1, La6/h;->R:I

    .line 340
    .line 341
    iput v13, v1, La6/h;->S:I

    .line 342
    .line 343
    iput v3, v1, La6/h;->T:I

    .line 344
    .line 345
    const/4 v2, -0x1

    .line 346
    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 347
    .line 348
    .line 349
    invoke-virtual {v10, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 350
    .line 351
    .line 352
    const v3, -0x33000001    # -1.3421772E8f

    .line 353
    .line 354
    .line 355
    invoke-virtual {v6, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 356
    .line 357
    .line 358
    const v9, 0x33ffffff

    .line 359
    .line 360
    .line 361
    invoke-virtual {v7, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 362
    .line 363
    .line 364
    const v11, -0x4d000100

    .line 365
    .line 366
    .line 367
    invoke-virtual {v0, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 368
    .line 369
    .line 370
    const v12, 0x33ffff00

    .line 371
    .line 372
    .line 373
    invoke-virtual {v8, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 374
    .line 375
    .line 376
    const/4 v0, 0x0

    .line 377
    iput-object v0, v1, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 378
    .line 379
    :goto_17a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 380
    .line 381
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 382
    .line 383
    .line 384
    iput-object v0, v1, La6/h;->W:Ljava/lang/StringBuilder;

    .line 385
    .line 386
    new-instance v2, Ljava/util/Formatter;

    .line 387
    .line 388
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 389
    .line 390
    .line 391
    move-result-object v3

    .line 392
    invoke-direct {v2, v0, v3}, Ljava/util/Formatter;-><init>(Ljava/lang/Appendable;Ljava/util/Locale;)V

    .line 393
    .line 394
    .line 395
    iput-object v2, v1, La6/h;->a0:Ljava/util/Formatter;

    .line 396
    .line 397
    new-instance v0, La6/f;

    .line 398
    .line 399
    const/4 v8, 0x0

    .line 400
    invoke-direct {v0, v8, v1}, La6/f;-><init>(ILjava/lang/Object;)V

    .line 401
    .line 402
    .line 403
    iput-object v0, v1, La6/h;->b0:La6/f;

    .line 404
    .line 405
    iget-object v0, v1, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 406
    .line 407
    if-eqz v0, :cond_1a7

    .line 408
    .line 409
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    .line 410
    .line 411
    .line 412
    move-result v0

    .line 413
    const/16 v16, 0x1

    .line 414
    .line 415
    add-int/lit8 v0, v0, 0x1

    .line 416
    .line 417
    const/16 v17, 0x2

    .line 418
    .line 419
    div-int/lit8 v0, v0, 0x2

    .line 420
    .line 421
    iput v0, v1, La6/h;->U:I

    .line 422
    .line 423
    goto :goto_1bf

    .line 424
    :cond_1a7
    const/16 v16, 0x1

    .line 425
    .line 426
    const/16 v17, 0x2

    .line 427
    .line 428
    iget v0, v1, La6/h;->S:I

    .line 429
    .line 430
    iget v2, v1, La6/h;->R:I

    .line 431
    .line 432
    iget v3, v1, La6/h;->T:I

    .line 433
    .line 434
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 435
    .line 436
    .line 437
    move-result v2

    .line 438
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    .line 439
    .line 440
    .line 441
    move-result v0

    .line 442
    add-int/lit8 v0, v0, 0x1

    .line 443
    .line 444
    div-int/lit8 v0, v0, 0x2

    .line 445
    .line 446
    iput v0, v1, La6/h;->U:I

    .line 447
    .line 448
    :goto_1bf
    const/high16 v0, 0x3f800000    # 1.0f

    .line 449
    .line 450
    iput v0, v1, La6/h;->k0:F

    .line 451
    .line 452
    new-instance v0, Landroid/animation/ValueAnimator;

    .line 453
    .line 454
    invoke-direct {v0}, Landroid/animation/ValueAnimator;-><init>()V

    .line 455
    .line 456
    .line 457
    iput-object v0, v1, La6/h;->j0:Landroid/animation/ValueAnimator;

    .line 458
    .line 459
    new-instance v2, La6/g;

    .line 460
    .line 461
    const/4 v8, 0x0

    .line 462
    invoke-direct {v2, v8, v1}, La6/g;-><init>(ILjava/lang/Object;)V

    .line 463
    .line 464
    .line 465
    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 466
    .line 467
    .line 468
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    iput-wide v2, v1, La6/h;->o0:J

    .line 474
    .line 475
    iput-wide v2, v1, La6/h;->g0:J

    .line 476
    .line 477
    const/16 v0, 0x14

    .line 478
    .line 479
    iput v0, v1, La6/h;->f0:I

    .line 480
    .line 481
    const/4 v0, 0x1

    .line 482
    invoke-virtual {v1, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 483
    .line 484
    .line 485
    invoke-virtual {v1}, Landroid/view/View;->getImportantForAccessibility()I

    .line 486
    .line 487
    .line 488
    move-result v2

    .line 489
    if-nez v2, :cond_1ed

    .line 490
    .line 491
    invoke-virtual {v1, v0}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 492
    .line 493
    .line 494
    :cond_1ed
    return-void
.end method

.method public static a(FI)I
    .registers 2

    .line 1
    int-to-float p1, p1

    .line 2
    mul-float/2addr p1, p0

    .line 3
    const/high16 p0, 0x3f000000    # 0.5f

    .line 4
    .line 5
    add-float/2addr p1, p0

    .line 6
    float-to-int p0, p1

    .line 7
    return p0
.end method

.method private getPositionIncrement()J
    .registers 6

    .line 1
    iget-wide v0, p0, La6/h;->g0:J

    .line 2
    .line 3
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    cmp-long v4, v0, v2

    .line 9
    .line 10
    if-nez v4, :cond_18

    .line 11
    .line 12
    iget-wide v0, p0, La6/h;->o0:J

    .line 13
    .line 14
    cmp-long v2, v0, v2

    .line 15
    .line 16
    if-nez v2, :cond_14

    .line 17
    .line 18
    const-wide/16 v0, 0x0

    .line 19
    .line 20
    return-wide v0

    .line 21
    :cond_14
    iget v2, p0, La6/h;->f0:I

    .line 22
    .line 23
    int-to-long v2, v2

    .line 24
    div-long/2addr v0, v2

    .line 25
    :cond_18
    return-wide v0
.end method

.method private getProgressText()Ljava/lang/String;
    .registers 5

    .line 1
    iget-object v0, p0, La6/h;->a0:Ljava/util/Formatter;

    .line 2
    .line 3
    iget-wide v1, p0, La6/h;->p0:J

    .line 4
    .line 5
    iget-object v3, p0, La6/h;->W:Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-static {v3, v0, v1, v2}, Ln3/l0;->G(Ljava/lang/StringBuilder;Ljava/util/Formatter;J)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method private getScrubberPosition()J
    .registers 6

    .line 1
    iget-object v0, p0, La6/h;->e:Landroid/graphics/Rect;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-lez v1, :cond_25

    .line 8
    .line 9
    iget-wide v1, p0, La6/h;->o0:J

    .line 10
    .line 11
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    cmp-long v1, v1, v3

    .line 17
    .line 18
    if-nez v1, :cond_14

    .line 19
    .line 20
    goto :goto_25

    .line 21
    :cond_14
    iget-object v1, p0, La6/h;->v:Landroid/graphics/Rect;

    .line 22
    .line 23
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    int-to-long v1, v1

    .line 28
    iget-wide v3, p0, La6/h;->o0:J

    .line 29
    .line 30
    mul-long/2addr v1, v3

    .line 31
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    int-to-long v3, v0

    .line 36
    div-long/2addr v1, v3

    .line 37
    return-wide v1

    .line 38
    :cond_25
    :goto_25
    const-wide/16 v0, 0x0

    .line 39
    .line 40
    return-wide v0
.end method


# virtual methods
.method public final b(J)Z
    .registers 11

    .line 1
    iget-wide v4, p0, La6/h;->o0:J

    .line 2
    .line 3
    const-wide/16 v0, 0x0

    .line 4
    .line 5
    cmp-long v0, v4, v0

    .line 6
    .line 7
    if-gtz v0, :cond_9

    .line 8
    .line 9
    goto :goto_20

    .line 10
    :cond_9
    iget-boolean v0, p0, La6/h;->m0:Z

    .line 11
    .line 12
    if-eqz v0, :cond_11

    .line 13
    .line 14
    iget-wide v0, p0, La6/h;->n0:J

    .line 15
    .line 16
    :goto_f
    move-wide v6, v0

    .line 17
    goto :goto_14

    .line 18
    :cond_11
    iget-wide v0, p0, La6/h;->p0:J

    .line 19
    .line 20
    goto :goto_f

    .line 21
    :goto_14
    add-long v0, v6, p1

    .line 22
    .line 23
    const-wide/16 v2, 0x0

    .line 24
    .line 25
    invoke-static/range {v0 .. v5}, Ln3/l0;->k(JJJ)J

    .line 26
    .line 27
    .line 28
    move-result-wide p1

    .line 29
    cmp-long v0, p1, v6

    .line 30
    .line 31
    if-nez v0, :cond_22

    .line 32
    .line 33
    :goto_20
    const/4 p1, 0x0

    .line 34
    return p1

    .line 35
    :cond_22
    iget-boolean v0, p0, La6/h;->m0:Z

    .line 36
    .line 37
    if-nez v0, :cond_2a

    .line 38
    .line 39
    invoke-virtual {p0, p1, p2}, La6/h;->c(J)V

    .line 40
    .line 41
    .line 42
    goto :goto_2d

    .line 43
    :cond_2a
    invoke-virtual {p0, p1, p2}, La6/h;->f(J)V

    .line 44
    .line 45
    .line 46
    :goto_2d
    invoke-virtual {p0}, La6/h;->e()V

    .line 47
    .line 48
    .line 49
    const/4 p1, 0x1

    .line 50
    return p1
.end method

.method public final c(J)V
    .registers 9

    .line 1
    iput-wide p1, p0, La6/h;->n0:J

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    iput-boolean v0, p0, La6/h;->m0:Z

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Landroid/view/View;->setPressed(Z)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-eqz v1, :cond_11

    .line 14
    .line 15
    invoke-interface {v1, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 16
    .line 17
    .line 18
    :cond_11
    iget-object v1, p0, La6/h;->c0:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    :cond_17
    :goto_17
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_b0

    .line 29
    .line 30
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    check-cast v2, La6/l;

    .line 35
    .line 36
    iget-object v2, v2, La6/l;->d:La6/w;

    .line 37
    .line 38
    iput-boolean v0, v2, La6/w;->Y0:Z

    .line 39
    .line 40
    iget-object v3, v2, La6/w;->p0:Landroid/widget/TextView;

    .line 41
    .line 42
    if-eqz v3, :cond_36

    .line 43
    .line 44
    iget-object v4, v2, La6/w;->r0:Ljava/lang/StringBuilder;

    .line 45
    .line 46
    iget-object v5, v2, La6/w;->s0:Ljava/util/Formatter;

    .line 47
    .line 48
    invoke-static {v4, v5, p1, p2}, Ln3/l0;->G(Ljava/lang/StringBuilder;Ljava/util/Formatter;J)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    iget-object v3, v2, La6/w;->d:La6/b0;

    .line 56
    .line 57
    invoke-virtual {v3}, La6/b0;->f()V

    .line 58
    .line 59
    .line 60
    iget-object v3, v2, La6/w;->S0:Lk3/e1;

    .line 61
    .line 62
    if-eqz v3, :cond_a1

    .line 63
    .line 64
    iget-boolean v4, v2, La6/w;->a1:Z

    .line 65
    .line 66
    if-eqz v4, :cond_a1

    .line 67
    .line 68
    invoke-virtual {v2, v3}, La6/w;->i(Lk3/e1;)Z

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-eqz v3, :cond_63

    .line 73
    .line 74
    :try_start_49
    iget-object v3, v2, La6/w;->x:Ljava/lang/reflect/Method;

    .line 75
    .line 76
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    iget-object v4, v2, La6/w;->S0:Lk3/e1;

    .line 80
    .line 81
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 82
    .line 83
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    invoke-virtual {v3, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_59
    .catch Ljava/lang/IllegalAccessException; {:try_start_49 .. :try_end_59} :catch_5c
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_49 .. :try_end_59} :catch_5a

    .line 88
    .line 89
    .line 90
    goto :goto_a1

    .line 91
    :catch_5a
    move-exception p1

    .line 92
    goto :goto_5d

    .line 93
    :catch_5c
    move-exception p1

    .line 94
    :goto_5d
    new-instance p2, Ljava/lang/RuntimeException;

    .line 95
    .line 96
    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 97
    .line 98
    .line 99
    throw p2

    .line 100
    :cond_63
    iget-object v3, v2, La6/w;->S0:Lk3/e1;

    .line 101
    .line 102
    invoke-virtual {v2, v3}, La6/w;->h(Lk3/e1;)Z

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    if-eqz v3, :cond_85

    .line 107
    .line 108
    :try_start_6b
    iget-object v3, v2, La6/w;->K:Ljava/lang/reflect/Method;

    .line 109
    .line 110
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    .line 112
    .line 113
    iget-object v4, v2, La6/w;->S0:Lk3/e1;

    .line 114
    .line 115
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 116
    .line 117
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    invoke-virtual {v3, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_7b
    .catch Ljava/lang/IllegalAccessException; {:try_start_6b .. :try_end_7b} :catch_7e
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_6b .. :try_end_7b} :catch_7c

    .line 122
    .line 123
    .line 124
    goto :goto_a1

    .line 125
    :catch_7c
    move-exception p1

    .line 126
    goto :goto_7f

    .line 127
    :catch_7e
    move-exception p1

    .line 128
    :goto_7f
    new-instance p2, Ljava/lang/RuntimeException;

    .line 129
    .line 130
    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 131
    .line 132
    .line 133
    throw p2

    .line 134
    :cond_85
    new-instance v3, Ljava/lang/StringBuilder;

    .line 135
    .line 136
    const-string v4, "Time bar scrubbing is enabled, but player is not an ExoPlayer or CompositionPlayer instance, so ignoring (because we can\'t enable scrubbing mode). player.class="

    .line 137
    .line 138
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    iget-object v4, v2, La6/w;->S0:Lk3/e1;

    .line 142
    .line 143
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    move-result-object v4

    .line 150
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 151
    .line 152
    .line 153
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    const-string v4, "PlayerControlView"

    .line 158
    .line 159
    invoke-static {v4, v3}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    :cond_a1
    :goto_a1
    iget-object v3, v2, La6/w;->S0:Lk3/e1;

    .line 163
    .line 164
    invoke-virtual {v2, v3}, La6/w;->k(Lk3/e1;)Z

    .line 165
    .line 166
    .line 167
    move-result v3

    .line 168
    if-eqz v3, :cond_17

    .line 169
    .line 170
    iget-object v3, v2, La6/w;->S0:Lk3/e1;

    .line 171
    .line 172
    invoke-static {v2, v3, p1, p2}, La6/w;->a(La6/w;Lk3/e1;J)V

    .line 173
    .line 174
    .line 175
    goto/16 :goto_17

    .line 176
    .line 177
    :cond_b0
    return-void
.end method

.method public final d(Z)V
    .registers 8

    .line 1
    iget-object v0, p0, La6/h;->b0:La6/f;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput-boolean v0, p0, La6/h;->m0:Z

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Landroid/view/View;->setPressed(Z)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    if-eqz v1, :cond_14

    .line 17
    .line 18
    invoke-interface {v1, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 19
    .line 20
    .line 21
    :cond_14
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, La6/h;->c0:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    :goto_1d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_82

    .line 35
    .line 36
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    check-cast v2, La6/l;

    .line 41
    .line 42
    iget-wide v3, p0, La6/h;->n0:J

    .line 43
    .line 44
    iget-object v2, v2, La6/l;->d:La6/w;

    .line 45
    .line 46
    iput-boolean v0, v2, La6/w;->Y0:Z

    .line 47
    .line 48
    iget-object v5, v2, La6/w;->S0:Lk3/e1;

    .line 49
    .line 50
    if-eqz v5, :cond_7c

    .line 51
    .line 52
    if-nez p1, :cond_38

    .line 53
    .line 54
    invoke-static {v2, v5, v3, v4}, La6/w;->a(La6/w;Lk3/e1;J)V

    .line 55
    .line 56
    .line 57
    :cond_38
    iget-object v3, v2, La6/w;->S0:Lk3/e1;

    .line 58
    .line 59
    invoke-virtual {v2, v3}, La6/w;->i(Lk3/e1;)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    if-eqz v3, :cond_5a

    .line 64
    .line 65
    :try_start_40
    iget-object v3, v2, La6/w;->x:Ljava/lang/reflect/Method;

    .line 66
    .line 67
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget-object v4, v2, La6/w;->S0:Lk3/e1;

    .line 71
    .line 72
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 73
    .line 74
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    invoke-virtual {v3, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_50
    .catch Ljava/lang/IllegalAccessException; {:try_start_40 .. :try_end_50} :catch_53
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_40 .. :try_end_50} :catch_51

    .line 79
    .line 80
    .line 81
    goto :goto_7c

    .line 82
    :catch_51
    move-exception p1

    .line 83
    goto :goto_54

    .line 84
    :catch_53
    move-exception p1

    .line 85
    :goto_54
    new-instance v0, Ljava/lang/RuntimeException;

    .line 86
    .line 87
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 88
    .line 89
    .line 90
    throw v0

    .line 91
    :cond_5a
    iget-object v3, v2, La6/w;->S0:Lk3/e1;

    .line 92
    .line 93
    invoke-virtual {v2, v3}, La6/w;->h(Lk3/e1;)Z

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    if-eqz v3, :cond_7c

    .line 98
    .line 99
    :try_start_62
    iget-object v3, v2, La6/w;->K:Ljava/lang/reflect/Method;

    .line 100
    .line 101
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 102
    .line 103
    .line 104
    iget-object v4, v2, La6/w;->S0:Lk3/e1;

    .line 105
    .line 106
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 107
    .line 108
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v5

    .line 112
    invoke-virtual {v3, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_72
    .catch Ljava/lang/IllegalAccessException; {:try_start_62 .. :try_end_72} :catch_75
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_62 .. :try_end_72} :catch_73

    .line 113
    .line 114
    .line 115
    goto :goto_7c

    .line 116
    :catch_73
    move-exception p1

    .line 117
    goto :goto_76

    .line 118
    :catch_75
    move-exception p1

    .line 119
    :goto_76
    new-instance v0, Ljava/lang/RuntimeException;

    .line 120
    .line 121
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 122
    .line 123
    .line 124
    throw v0

    .line 125
    :cond_7c
    :goto_7c
    iget-object v2, v2, La6/w;->d:La6/b0;

    .line 126
    .line 127
    invoke-virtual {v2}, La6/b0;->g()V

    .line 128
    .line 129
    .line 130
    goto :goto_1d

    .line 131
    :cond_82
    return-void
.end method

.method public final drawableStateChanged()V
    .registers 3

    .line 1
    invoke-super {p0}, Landroid/view/View;->drawableStateChanged()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 5
    .line 6
    if-eqz v0, :cond_1a

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_1a

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_1a

    .line 23
    .line 24
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 25
    .line 26
    .line 27
    :cond_1a
    return-void
.end method

.method public final e()V
    .registers 10

    .line 1
    iget-object v0, p0, La6/h;->i:Landroid/graphics/Rect;

    .line 2
    .line 3
    iget-object v1, p0, La6/h;->e:Landroid/graphics/Rect;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 6
    .line 7
    .line 8
    iget-object v2, p0, La6/h;->v:Landroid/graphics/Rect;

    .line 9
    .line 10
    invoke-virtual {v2, v1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 11
    .line 12
    .line 13
    iget-boolean v3, p0, La6/h;->m0:Z

    .line 14
    .line 15
    if-eqz v3, :cond_13

    .line 16
    .line 17
    iget-wide v3, p0, La6/h;->n0:J

    .line 18
    .line 19
    goto :goto_15

    .line 20
    :cond_13
    iget-wide v3, p0, La6/h;->p0:J

    .line 21
    .line 22
    :goto_15
    iget-wide v5, p0, La6/h;->o0:J

    .line 23
    .line 24
    const-wide/16 v7, 0x0

    .line 25
    .line 26
    cmp-long v5, v5, v7

    .line 27
    .line 28
    if-lez v5, :cond_4a

    .line 29
    .line 30
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    int-to-long v5, v5

    .line 35
    iget-wide v7, p0, La6/h;->q0:J

    .line 36
    .line 37
    mul-long/2addr v5, v7

    .line 38
    iget-wide v7, p0, La6/h;->o0:J

    .line 39
    .line 40
    div-long/2addr v5, v7

    .line 41
    long-to-int v5, v5

    .line 42
    iget v6, v1, Landroid/graphics/Rect;->left:I

    .line 43
    .line 44
    add-int/2addr v6, v5

    .line 45
    iget v5, v1, Landroid/graphics/Rect;->right:I

    .line 46
    .line 47
    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    .line 48
    .line 49
    .line 50
    move-result v5

    .line 51
    iput v5, v0, Landroid/graphics/Rect;->right:I

    .line 52
    .line 53
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    int-to-long v5, v0

    .line 58
    mul-long/2addr v5, v3

    .line 59
    iget-wide v3, p0, La6/h;->o0:J

    .line 60
    .line 61
    div-long/2addr v5, v3

    .line 62
    long-to-int v0, v5

    .line 63
    iget v3, v1, Landroid/graphics/Rect;->left:I

    .line 64
    .line 65
    add-int/2addr v3, v0

    .line 66
    iget v0, v1, Landroid/graphics/Rect;->right:I

    .line 67
    .line 68
    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    iput v0, v2, Landroid/graphics/Rect;->right:I

    .line 73
    .line 74
    goto :goto_50

    .line 75
    :cond_4a
    iget v1, v1, Landroid/graphics/Rect;->left:I

    .line 76
    .line 77
    iput v1, v0, Landroid/graphics/Rect;->right:I

    .line 78
    .line 79
    iput v1, v2, Landroid/graphics/Rect;->right:I

    .line 80
    .line 81
    :goto_50
    iget-object v0, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 82
    .line 83
    invoke-virtual {p0, v0}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 84
    .line 85
    .line 86
    return-void
.end method

.method public final f(J)V
    .registers 8

    .line 1
    iget-wide v0, p0, La6/h;->n0:J

    .line 2
    .line 3
    cmp-long v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    goto :goto_3a

    .line 8
    :cond_7
    iput-wide p1, p0, La6/h;->n0:J

    .line 9
    .line 10
    iget-object v0, p0, La6/h;->c0:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :cond_f
    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_3a

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, La6/l;

    .line 27
    .line 28
    iget-object v1, v1, La6/l;->d:La6/w;

    .line 29
    .line 30
    iget-object v2, v1, La6/w;->p0:Landroid/widget/TextView;

    .line 31
    .line 32
    if-eqz v2, :cond_2c

    .line 33
    .line 34
    iget-object v3, v1, La6/w;->r0:Ljava/lang/StringBuilder;

    .line 35
    .line 36
    iget-object v4, v1, La6/w;->s0:Ljava/util/Formatter;

    .line 37
    .line 38
    invoke-static {v3, v4, p1, p2}, Ln3/l0;->G(Ljava/lang/StringBuilder;Ljava/util/Formatter;J)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    .line 44
    .line 45
    :cond_2c
    iget-object v2, v1, La6/w;->S0:Lk3/e1;

    .line 46
    .line 47
    invoke-virtual {v1, v2}, La6/w;->k(Lk3/e1;)Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_f

    .line 52
    .line 53
    iget-object v2, v1, La6/w;->S0:Lk3/e1;

    .line 54
    .line 55
    invoke-static {v1, v2, p1, p2}, La6/w;->a(La6/w;Lk3/e1;J)V

    .line 56
    .line 57
    .line 58
    goto :goto_f

    .line 59
    :cond_3a
    :goto_3a
    return-void
.end method

.method public getPreferredUpdateDelay()J
    .registers 6

    .line 1
    iget-object v0, p0, La6/h;->e:Landroid/graphics/Rect;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    int-to-float v0, v0

    .line 8
    iget v1, p0, La6/h;->e0:F

    .line 9
    .line 10
    div-float/2addr v0, v1

    .line 11
    float-to-int v0, v0

    .line 12
    if-eqz v0, :cond_22

    .line 13
    .line 14
    iget-wide v1, p0, La6/h;->o0:J

    .line 15
    .line 16
    const-wide/16 v3, 0x0

    .line 17
    .line 18
    cmp-long v3, v1, v3

    .line 19
    .line 20
    if-eqz v3, :cond_22

    .line 21
    .line 22
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    cmp-long v3, v1, v3

    .line 28
    .line 29
    if-nez v3, :cond_1f

    .line 30
    .line 31
    goto :goto_22

    .line 32
    :cond_1f
    int-to-long v3, v0

    .line 33
    div-long/2addr v1, v3

    .line 34
    return-wide v1

    .line 35
    :cond_22
    :goto_22
    const-wide v0, 0x7fffffffffffffffL

    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    return-wide v0
.end method

.method public final jumpDrawablesToCurrentState()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 5
    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    .line 9
    .line 10
    .line 11
    :cond_a
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    .line 4
    .line 5
    .line 6
    iget-object v7, v0, La6/h;->e:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {v7}, Landroid/graphics/Rect;->height()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    invoke-virtual {v7}, Landroid/graphics/Rect;->centerY()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    div-int/lit8 v3, v1, 0x2

    .line 17
    .line 18
    sub-int v8, v2, v3

    .line 19
    .line 20
    add-int v9, v8, v1

    .line 21
    .line 22
    iget-wide v1, v0, La6/h;->o0:J

    .line 23
    .line 24
    const-wide/16 v10, 0x0

    .line 25
    .line 26
    cmp-long v1, v1, v10

    .line 27
    .line 28
    iget-object v6, v0, La6/h;->y:Landroid/graphics/Paint;

    .line 29
    .line 30
    iget-object v12, v0, La6/h;->v:Landroid/graphics/Rect;

    .line 31
    .line 32
    if-gtz v1, :cond_30

    .line 33
    .line 34
    iget v1, v7, Landroid/graphics/Rect;->left:I

    .line 35
    .line 36
    int-to-float v2, v1

    .line 37
    int-to-float v3, v8

    .line 38
    iget v1, v7, Landroid/graphics/Rect;->right:I

    .line 39
    .line 40
    int-to-float v4, v1

    .line 41
    int-to-float v5, v9

    .line 42
    move-object/from16 v1, p1

    .line 43
    .line 44
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 45
    .line 46
    .line 47
    goto/16 :goto_dc

    .line 48
    .line 49
    :cond_30
    iget-object v1, v0, La6/h;->i:Landroid/graphics/Rect;

    .line 50
    .line 51
    iget v13, v1, Landroid/graphics/Rect;->left:I

    .line 52
    .line 53
    iget v14, v1, Landroid/graphics/Rect;->right:I

    .line 54
    .line 55
    iget v1, v7, Landroid/graphics/Rect;->left:I

    .line 56
    .line 57
    invoke-static {v1, v14}, Ljava/lang/Math;->max(II)I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    iget v2, v12, Landroid/graphics/Rect;->right:I

    .line 62
    .line 63
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    iget v2, v7, Landroid/graphics/Rect;->right:I

    .line 68
    .line 69
    if-ge v1, v2, :cond_50

    .line 70
    .line 71
    int-to-float v1, v1

    .line 72
    int-to-float v3, v8

    .line 73
    int-to-float v4, v2

    .line 74
    int-to-float v5, v9

    .line 75
    move v2, v1

    .line 76
    move-object/from16 v1, p1

    .line 77
    .line 78
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 79
    .line 80
    .line 81
    :cond_50
    iget v1, v12, Landroid/graphics/Rect;->right:I

    .line 82
    .line 83
    invoke-static {v13, v1}, Ljava/lang/Math;->max(II)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    if-le v14, v1, :cond_63

    .line 88
    .line 89
    int-to-float v2, v1

    .line 90
    int-to-float v3, v8

    .line 91
    int-to-float v4, v14

    .line 92
    int-to-float v5, v9

    .line 93
    iget-object v6, v0, La6/h;->x:Landroid/graphics/Paint;

    .line 94
    .line 95
    move-object/from16 v1, p1

    .line 96
    .line 97
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 98
    .line 99
    .line 100
    :cond_63
    invoke-virtual {v12}, Landroid/graphics/Rect;->width()I

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-lez v1, :cond_78

    .line 105
    .line 106
    iget v1, v12, Landroid/graphics/Rect;->left:I

    .line 107
    .line 108
    int-to-float v2, v1

    .line 109
    int-to-float v3, v8

    .line 110
    iget v1, v12, Landroid/graphics/Rect;->right:I

    .line 111
    .line 112
    int-to-float v4, v1

    .line 113
    int-to-float v5, v9

    .line 114
    iget-object v6, v0, La6/h;->w:Landroid/graphics/Paint;

    .line 115
    .line 116
    move-object/from16 v1, p1

    .line 117
    .line 118
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 119
    .line 120
    .line 121
    :cond_78
    iget v1, v0, La6/h;->r0:I

    .line 122
    .line 123
    if-nez v1, :cond_7f

    .line 124
    .line 125
    :cond_7c
    move-object/from16 v1, p1

    .line 126
    .line 127
    goto :goto_dc

    .line 128
    :cond_7f
    iget-object v13, v0, La6/h;->s0:[J

    .line 129
    .line 130
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    .line 132
    .line 133
    iget-object v14, v0, La6/h;->t0:[Z

    .line 134
    .line 135
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 136
    .line 137
    .line 138
    iget v15, v0, La6/h;->Q:I

    .line 139
    .line 140
    div-int/lit8 v16, v15, 0x2

    .line 141
    .line 142
    const/4 v1, 0x0

    .line 143
    move v2, v1

    .line 144
    :goto_8f
    iget v3, v0, La6/h;->r0:I

    .line 145
    .line 146
    if-ge v2, v3, :cond_7c

    .line 147
    .line 148
    aget-wide v17, v13, v2

    .line 149
    .line 150
    const-wide/16 v19, 0x0

    .line 151
    .line 152
    iget-wide v3, v0, La6/h;->o0:J

    .line 153
    .line 154
    move-wide/from16 v21, v3

    .line 155
    .line 156
    invoke-static/range {v17 .. v22}, Ln3/l0;->k(JJJ)J

    .line 157
    .line 158
    .line 159
    move-result-wide v3

    .line 160
    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    .line 161
    .line 162
    .line 163
    move-result v5

    .line 164
    int-to-long v5, v5

    .line 165
    mul-long/2addr v5, v3

    .line 166
    iget-wide v3, v0, La6/h;->o0:J

    .line 167
    .line 168
    div-long/2addr v5, v3

    .line 169
    long-to-int v3, v5

    .line 170
    sub-int v3, v3, v16

    .line 171
    .line 172
    iget v4, v7, Landroid/graphics/Rect;->left:I

    .line 173
    .line 174
    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    .line 175
    .line 176
    .line 177
    move-result v5

    .line 178
    sub-int/2addr v5, v15

    .line 179
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 180
    .line 181
    .line 182
    move-result v3

    .line 183
    invoke-static {v5, v3}, Ljava/lang/Math;->min(II)I

    .line 184
    .line 185
    .line 186
    move-result v3

    .line 187
    add-int/2addr v3, v4

    .line 188
    aget-boolean v4, v14, v2

    .line 189
    .line 190
    if-eqz v4, :cond_c4

    .line 191
    .line 192
    iget-object v4, v0, La6/h;->K:Landroid/graphics/Paint;

    .line 193
    .line 194
    :goto_c1
    move-object v6, v4

    .line 195
    move v4, v2

    .line 196
    goto :goto_c7

    .line 197
    :cond_c4
    iget-object v4, v0, La6/h;->J:Landroid/graphics/Paint;

    .line 198
    .line 199
    goto :goto_c1

    .line 200
    :goto_c7
    int-to-float v2, v3

    .line 201
    move v5, v3

    .line 202
    int-to-float v3, v8

    .line 203
    add-int/2addr v5, v15

    .line 204
    int-to-float v5, v5

    .line 205
    move/from16 v17, v4

    .line 206
    .line 207
    move v4, v5

    .line 208
    int-to-float v5, v9

    .line 209
    move/from16 v18, v1

    .line 210
    .line 211
    move-object/from16 v1, p1

    .line 212
    .line 213
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 214
    .line 215
    .line 216
    add-int/lit8 v2, v17, 0x1

    .line 217
    .line 218
    move/from16 v1, v18

    .line 219
    .line 220
    goto :goto_8f

    .line 221
    :goto_dc
    iget-wide v2, v0, La6/h;->o0:J

    .line 222
    .line 223
    cmp-long v2, v2, v10

    .line 224
    .line 225
    if-gtz v2, :cond_e3

    .line 226
    .line 227
    goto :goto_141

    .line 228
    :cond_e3
    iget v2, v12, Landroid/graphics/Rect;->right:I

    .line 229
    .line 230
    iget v3, v12, Landroid/graphics/Rect;->left:I

    .line 231
    .line 232
    iget v4, v7, Landroid/graphics/Rect;->right:I

    .line 233
    .line 234
    invoke-static {v2, v3, v4}, Ln3/l0;->j(III)I

    .line 235
    .line 236
    .line 237
    move-result v2

    .line 238
    invoke-virtual {v12}, Landroid/graphics/Rect;->centerY()I

    .line 239
    .line 240
    .line 241
    move-result v3

    .line 242
    iget-object v4, v0, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 243
    .line 244
    if-nez v4, :cond_11f

    .line 245
    .line 246
    iget-boolean v4, v0, La6/h;->m0:Z

    .line 247
    .line 248
    if-nez v4, :cond_10c

    .line 249
    .line 250
    invoke-virtual {v0}, Landroid/view/View;->isFocused()Z

    .line 251
    .line 252
    .line 253
    move-result v4

    .line 254
    if-eqz v4, :cond_100

    .line 255
    .line 256
    goto :goto_10c

    .line 257
    :cond_100
    invoke-virtual {v0}, Landroid/view/View;->isEnabled()Z

    .line 258
    .line 259
    .line 260
    move-result v4

    .line 261
    if-eqz v4, :cond_109

    .line 262
    .line 263
    iget v4, v0, La6/h;->R:I

    .line 264
    .line 265
    goto :goto_10e

    .line 266
    :cond_109
    iget v4, v0, La6/h;->S:I

    .line 267
    .line 268
    goto :goto_10e

    .line 269
    :cond_10c
    :goto_10c
    iget v4, v0, La6/h;->T:I

    .line 270
    .line 271
    :goto_10e
    int-to-float v4, v4

    .line 272
    iget v5, v0, La6/h;->k0:F

    .line 273
    .line 274
    mul-float/2addr v4, v5

    .line 275
    const/high16 v5, 0x40000000    # 2.0f

    .line 276
    .line 277
    div-float/2addr v4, v5

    .line 278
    float-to-int v4, v4

    .line 279
    int-to-float v2, v2

    .line 280
    int-to-float v3, v3

    .line 281
    int-to-float v4, v4

    .line 282
    iget-object v5, v0, La6/h;->L:Landroid/graphics/Paint;

    .line 283
    .line 284
    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 285
    .line 286
    .line 287
    goto :goto_141

    .line 288
    :cond_11f
    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 289
    .line 290
    .line 291
    move-result v5

    .line 292
    int-to-float v5, v5

    .line 293
    iget v6, v0, La6/h;->k0:F

    .line 294
    .line 295
    mul-float/2addr v5, v6

    .line 296
    float-to-int v5, v5

    .line 297
    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 298
    .line 299
    .line 300
    move-result v6

    .line 301
    int-to-float v6, v6

    .line 302
    iget v7, v0, La6/h;->k0:F

    .line 303
    .line 304
    mul-float/2addr v6, v7

    .line 305
    float-to-int v6, v6

    .line 306
    div-int/lit8 v5, v5, 0x2

    .line 307
    .line 308
    sub-int v7, v2, v5

    .line 309
    .line 310
    div-int/lit8 v6, v6, 0x2

    .line 311
    .line 312
    sub-int v8, v3, v6

    .line 313
    .line 314
    add-int/2addr v2, v5

    .line 315
    add-int/2addr v3, v6

    .line 316
    invoke-virtual {v4, v7, v8, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {v4, v1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 320
    .line 321
    .line 322
    :goto_141
    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 323
    .line 324
    .line 325
    return-void
.end method

.method public final onFocusChanged(ZILandroid/graphics/Rect;)V
    .registers 4

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroid/view/View;->onFocusChanged(ZILandroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    iget-boolean p2, p0, La6/h;->m0:Z

    .line 5
    .line 6
    if-eqz p2, :cond_d

    .line 7
    .line 8
    if-nez p1, :cond_d

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    invoke-virtual {p0, p1}, La6/h;->d(Z)V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x4

    .line 9
    if-ne v0, v1, :cond_15

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-direct {p0}, La6/h;->getProgressText()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    :cond_15
    const-string v0, "android.widget.SeekBar"

    .line 23
    .line 24
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 6

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 2
    .line 3
    .line 4
    const-string v0, "android.widget.SeekBar"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0}, La6/h;->getProgressText()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 14
    .line 15
    .line 16
    iget-wide v0, p0, La6/h;->o0:J

    .line 17
    .line 18
    const-wide/16 v2, 0x0

    .line 19
    .line 20
    cmp-long v0, v0, v2

    .line 21
    .line 22
    if-gtz v0, :cond_18

    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_FORWARD:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    .line 28
    .line 29
    .line 30
    sget-object v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_BACKWARD:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 31
    .line 32
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final onKeyDown(ILandroid/view/KeyEvent;)Z
    .registers 7

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_2e

    .line 6
    .line 7
    invoke-direct {p0}, La6/h;->getPositionIncrement()J

    .line 8
    .line 9
    .line 10
    move-result-wide v0

    .line 11
    const/16 v2, 0x42

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    if-eq p1, v2, :cond_25

    .line 15
    .line 16
    packed-switch p1, :pswitch_data_34

    .line 17
    .line 18
    .line 19
    goto :goto_2e

    .line 20
    :pswitch_13
    neg-long v0, v0

    .line 21
    :pswitch_14
    invoke-virtual {p0, v0, v1}, La6/h;->b(J)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_2e

    .line 26
    .line 27
    iget-object p1, p0, La6/h;->b0:La6/f;

    .line 28
    .line 29
    invoke-virtual {p0, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 30
    .line 31
    .line 32
    const-wide/16 v0, 0x3e8

    .line 33
    .line 34
    invoke-virtual {p0, p1, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 35
    .line 36
    .line 37
    return v3

    .line 38
    :cond_25
    :pswitch_25
    iget-boolean v0, p0, La6/h;->m0:Z

    .line 39
    .line 40
    if-eqz v0, :cond_2e

    .line 41
    .line 42
    const/4 p1, 0x0

    .line 43
    invoke-virtual {p0, p1}, La6/h;->d(Z)V

    .line 44
    .line 45
    .line 46
    return v3

    .line 47
    :cond_2e
    :goto_2e
    invoke-super {p0, p1, p2}, Landroid/view/View;->onKeyDown(ILandroid/view/KeyEvent;)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    return p1

    .line 52
    nop

    .line 53
    :pswitch_data_34
    .packed-switch 0x15
        :pswitch_13
        :pswitch_14
        :pswitch_25
    .end packed-switch
.end method

.method public final onLayout(ZIIII)V
    .registers 12

    .line 1
    sub-int/2addr p4, p2

    .line 2
    sub-int/2addr p5, p3

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    sub-int p2, p4, p2

    .line 12
    .line 13
    iget-boolean p3, p0, La6/h;->l0:Z

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    if-eqz p3, :cond_13

    .line 17
    .line 18
    move p3, v0

    .line 19
    goto :goto_15

    .line 20
    :cond_13
    iget p3, p0, La6/h;->U:I

    .line 21
    .line 22
    :goto_15
    iget v1, p0, La6/h;->P:I

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    iget v3, p0, La6/h;->N:I

    .line 26
    .line 27
    iget v4, p0, La6/h;->O:I

    .line 28
    .line 29
    if-ne v1, v2, :cond_36

    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    sub-int v1, p5, v1

    .line 36
    .line 37
    sub-int/2addr v1, v4

    .line 38
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    sub-int v2, p5, v2

    .line 43
    .line 44
    sub-int/2addr v2, v3

    .line 45
    div-int/lit8 v5, v3, 0x2

    .line 46
    .line 47
    sub-int v5, p3, v5

    .line 48
    .line 49
    invoke-static {v5, v0}, Ljava/lang/Math;->max(II)I

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    sub-int/2addr v2, v5

    .line 54
    goto :goto_3e

    .line 55
    :cond_36
    sub-int v1, p5, v4

    .line 56
    .line 57
    div-int/lit8 v1, v1, 0x2

    .line 58
    .line 59
    sub-int v2, p5, v3

    .line 60
    .line 61
    div-int/lit8 v2, v2, 0x2

    .line 62
    .line 63
    :goto_3e
    add-int/2addr v4, v1

    .line 64
    iget-object v5, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 65
    .line 66
    invoke-virtual {v5, p1, v1, p2, v4}, Landroid/graphics/Rect;->set(IIII)V

    .line 67
    .line 68
    .line 69
    iget p1, v5, Landroid/graphics/Rect;->left:I

    .line 70
    .line 71
    add-int/2addr p1, p3

    .line 72
    iget p2, v5, Landroid/graphics/Rect;->right:I

    .line 73
    .line 74
    sub-int/2addr p2, p3

    .line 75
    add-int/2addr v3, v2

    .line 76
    iget-object p3, p0, La6/h;->e:Landroid/graphics/Rect;

    .line 77
    .line 78
    invoke-virtual {p3, p1, v2, p2, v3}, Landroid/graphics/Rect;->set(IIII)V

    .line 79
    .line 80
    .line 81
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 82
    .line 83
    const/16 p2, 0x1d

    .line 84
    .line 85
    if-lt p1, p2, :cond_77

    .line 86
    .line 87
    iget-object p1, p0, La6/h;->i0:Landroid/graphics/Rect;

    .line 88
    .line 89
    if-eqz p1, :cond_69

    .line 90
    .line 91
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    .line 92
    .line 93
    .line 94
    move-result p1

    .line 95
    if-ne p1, p4, :cond_69

    .line 96
    .line 97
    iget-object p1, p0, La6/h;->i0:Landroid/graphics/Rect;

    .line 98
    .line 99
    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    .line 100
    .line 101
    .line 102
    move-result p1

    .line 103
    if-ne p1, p5, :cond_69

    .line 104
    .line 105
    goto :goto_77

    .line 106
    :cond_69
    new-instance p1, Landroid/graphics/Rect;

    .line 107
    .line 108
    invoke-direct {p1, v0, v0, p4, p5}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 109
    .line 110
    .line 111
    iput-object p1, p0, La6/h;->i0:Landroid/graphics/Rect;

    .line 112
    .line 113
    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemGestureExclusionRects(Ljava/util/List;)V

    .line 118
    .line 119
    .line 120
    :cond_77
    :goto_77
    invoke-virtual {p0}, La6/h;->e()V

    .line 121
    .line 122
    .line 123
    return-void
.end method

.method public final onMeasure(II)V
    .registers 6

    .line 1
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    iget v1, p0, La6/h;->O:I

    .line 10
    .line 11
    if-nez v0, :cond_e

    .line 12
    .line 13
    move p2, v1

    .line 14
    goto :goto_17

    .line 15
    :cond_e
    const/high16 v2, 0x40000000    # 2.0f

    .line 16
    .line 17
    if-ne v0, v2, :cond_13

    .line 18
    .line 19
    goto :goto_17

    .line 20
    :cond_13
    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    .line 21
    .line 22
    .line 23
    move-result p2

    .line 24
    :goto_17
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 32
    .line 33
    if-eqz p1, :cond_35

    .line 34
    .line 35
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    if-eqz p2, :cond_35

    .line 40
    .line 41
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    if-eqz p1, :cond_35

    .line 50
    .line 51
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 52
    .line 53
    .line 54
    :cond_35
    return-void
.end method

.method public final onRtlPropertiesChanged(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->M:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_d

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLayoutDirection(I)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_d

    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 11

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_a2

    .line 7
    .line 8
    iget-wide v2, p0, La6/h;->o0:J

    .line 9
    .line 10
    const-wide/16 v4, 0x0

    .line 11
    .line 12
    cmp-long v0, v2, v4

    .line 13
    .line 14
    if-gtz v0, :cond_11

    .line 15
    .line 16
    goto/16 :goto_a2

    .line 17
    .line 18
    :cond_11
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    float-to-int v0, v0

    .line 23
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    float-to-int v2, v2

    .line 28
    iget-object v3, p0, La6/h;->d0:Landroid/graphics/Point;

    .line 29
    .line 30
    invoke-virtual {v3, v0, v2}, Landroid/graphics/Point;->set(II)V

    .line 31
    .line 32
    .line 33
    iget v0, v3, Landroid/graphics/Point;->x:I

    .line 34
    .line 35
    iget v2, v3, Landroid/graphics/Point;->y:I

    .line 36
    .line 37
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    iget-object v4, p0, La6/h;->e:Landroid/graphics/Rect;

    .line 42
    .line 43
    iget-object v5, p0, La6/h;->v:Landroid/graphics/Rect;

    .line 44
    .line 45
    const/4 v6, 0x1

    .line 46
    if-eqz v3, :cond_7e

    .line 47
    .line 48
    const/4 v7, 0x3

    .line 49
    if-eq v3, v6, :cond_6f

    .line 50
    .line 51
    const/4 v8, 0x2

    .line 52
    if-eq v3, v8, :cond_38

    .line 53
    .line 54
    if-eq v3, v7, :cond_6f

    .line 55
    .line 56
    goto :goto_a2

    .line 57
    :cond_38
    iget-boolean p1, p0, La6/h;->m0:Z

    .line 58
    .line 59
    if-eqz p1, :cond_a2

    .line 60
    .line 61
    iget p1, p0, La6/h;->V:I

    .line 62
    .line 63
    if-ge v2, p1, :cond_53

    .line 64
    .line 65
    iget p1, p0, La6/h;->h0:I

    .line 66
    .line 67
    invoke-static {v0, p1, v7, p1}, Lhs/q;->b(IIII)I

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    int-to-float p1, p1

    .line 72
    float-to-int p1, p1

    .line 73
    iget v0, v4, Landroid/graphics/Rect;->left:I

    .line 74
    .line 75
    iget v1, v4, Landroid/graphics/Rect;->right:I

    .line 76
    .line 77
    invoke-static {p1, v0, v1}, Ln3/l0;->j(III)I

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    iput p1, v5, Landroid/graphics/Rect;->right:I

    .line 82
    .line 83
    goto :goto_61

    .line 84
    :cond_53
    iput v0, p0, La6/h;->h0:I

    .line 85
    .line 86
    int-to-float p1, v0

    .line 87
    float-to-int p1, p1

    .line 88
    iget v0, v4, Landroid/graphics/Rect;->left:I

    .line 89
    .line 90
    iget v1, v4, Landroid/graphics/Rect;->right:I

    .line 91
    .line 92
    invoke-static {p1, v0, v1}, Ln3/l0;->j(III)I

    .line 93
    .line 94
    .line 95
    move-result p1

    .line 96
    iput p1, v5, Landroid/graphics/Rect;->right:I

    .line 97
    .line 98
    :goto_61
    invoke-direct {p0}, La6/h;->getScrubberPosition()J

    .line 99
    .line 100
    .line 101
    move-result-wide v0

    .line 102
    invoke-virtual {p0, v0, v1}, La6/h;->f(J)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0}, La6/h;->e()V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 109
    .line 110
    .line 111
    return v6

    .line 112
    :cond_6f
    iget-boolean v0, p0, La6/h;->m0:Z

    .line 113
    .line 114
    if-eqz v0, :cond_a2

    .line 115
    .line 116
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 117
    .line 118
    .line 119
    move-result p1

    .line 120
    if-ne p1, v7, :cond_7a

    .line 121
    .line 122
    move v1, v6

    .line 123
    :cond_7a
    invoke-virtual {p0, v1}, La6/h;->d(Z)V

    .line 124
    .line 125
    .line 126
    return v6

    .line 127
    :cond_7e
    int-to-float p1, v0

    .line 128
    int-to-float v0, v2

    .line 129
    float-to-int p1, p1

    .line 130
    float-to-int v0, v0

    .line 131
    iget-object v2, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 132
    .line 133
    invoke-virtual {v2, p1, v0}, Landroid/graphics/Rect;->contains(II)Z

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    if-eqz v0, :cond_a2

    .line 138
    .line 139
    iget v0, v4, Landroid/graphics/Rect;->left:I

    .line 140
    .line 141
    iget v1, v4, Landroid/graphics/Rect;->right:I

    .line 142
    .line 143
    invoke-static {p1, v0, v1}, Ln3/l0;->j(III)I

    .line 144
    .line 145
    .line 146
    move-result p1

    .line 147
    iput p1, v5, Landroid/graphics/Rect;->right:I

    .line 148
    .line 149
    invoke-direct {p0}, La6/h;->getScrubberPosition()J

    .line 150
    .line 151
    .line 152
    move-result-wide v0

    .line 153
    invoke-virtual {p0, v0, v1}, La6/h;->c(J)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {p0}, La6/h;->e()V

    .line 157
    .line 158
    .line 159
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 160
    .line 161
    .line 162
    return v6

    .line 163
    :cond_a2
    :goto_a2
    return v1
.end method

.method public final performAccessibilityAction(ILandroid/os/Bundle;)Z
    .registers 8

    .line 1
    invoke-super {p0, p1, p2}, Landroid/view/View;->performAccessibilityAction(ILandroid/os/Bundle;)Z

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    const/4 v0, 0x1

    .line 6
    if-eqz p2, :cond_8

    .line 7
    .line 8
    return v0

    .line 9
    :cond_8
    iget-wide v1, p0, La6/h;->o0:J

    .line 10
    .line 11
    const-wide/16 v3, 0x0

    .line 12
    .line 13
    cmp-long p2, v1, v3

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    if-gtz p2, :cond_12

    .line 17
    .line 18
    return v1

    .line 19
    :cond_12
    const/16 p2, 0x2000

    .line 20
    .line 21
    if-ne p1, p2, :cond_25

    .line 22
    .line 23
    invoke-direct {p0}, La6/h;->getPositionIncrement()J

    .line 24
    .line 25
    .line 26
    move-result-wide p1

    .line 27
    neg-long p1, p1

    .line 28
    invoke-virtual {p0, p1, p2}, La6/h;->b(J)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_36

    .line 33
    .line 34
    invoke-virtual {p0, v1}, La6/h;->d(Z)V

    .line 35
    .line 36
    .line 37
    goto :goto_36

    .line 38
    :cond_25
    const/16 p2, 0x1000

    .line 39
    .line 40
    if-ne p1, p2, :cond_3b

    .line 41
    .line 42
    invoke-direct {p0}, La6/h;->getPositionIncrement()J

    .line 43
    .line 44
    .line 45
    move-result-wide p1

    .line 46
    invoke-virtual {p0, p1, p2}, La6/h;->b(J)Z

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    if-eqz p1, :cond_36

    .line 51
    .line 52
    invoke-virtual {p0, v1}, La6/h;->d(Z)V

    .line 53
    .line 54
    .line 55
    :cond_36
    :goto_36
    const/4 p1, 0x4

    .line 56
    invoke-virtual {p0, p1}, Landroid/view/View;->sendAccessibilityEvent(I)V

    .line 57
    .line 58
    .line 59
    return v0

    .line 60
    :cond_3b
    return v1
.end method

.method public setAdMarkerColor(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->J:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setBufferedColor(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->x:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setBufferedPosition(J)V
    .registers 5

    .line 1
    iget-wide v0, p0, La6/h;->q0:J

    .line 2
    .line 3
    cmp-long v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    iput-wide p1, p0, La6/h;->q0:J

    .line 9
    .line 10
    invoke-virtual {p0}, La6/h;->e()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public setDuration(J)V
    .registers 5

    .line 1
    iget-wide v0, p0, La6/h;->o0:J

    .line 2
    .line 3
    cmp-long v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    iput-wide p1, p0, La6/h;->o0:J

    .line 9
    .line 10
    iget-boolean v0, p0, La6/h;->m0:Z

    .line 11
    .line 12
    if-eqz v0, :cond_1a

    .line 13
    .line 14
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    cmp-long p1, p1, v0

    .line 20
    .line 21
    if-nez p1, :cond_1a

    .line 22
    .line 23
    const/4 p1, 0x1

    .line 24
    invoke-virtual {p0, p1}, La6/h;->d(Z)V

    .line 25
    .line 26
    .line 27
    :cond_1a
    invoke-virtual {p0}, La6/h;->e()V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public setEnabled(Z)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->setEnabled(Z)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, La6/h;->m0:Z

    .line 5
    .line 6
    if-eqz v0, :cond_d

    .line 7
    .line 8
    if-nez p1, :cond_d

    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    invoke-virtual {p0, p1}, La6/h;->d(Z)V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

.method public setKeyCountIncrement(I)V
    .registers 4

    .line 1
    if-lez p1, :cond_4

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    goto :goto_5

    .line 5
    :cond_4
    const/4 v0, 0x0

    .line 6
    :goto_5
    invoke-static {v0}, Loq/a;->n(Z)V

    .line 7
    .line 8
    .line 9
    iput p1, p0, La6/h;->f0:I

    .line 10
    .line 11
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    iput-wide v0, p0, La6/h;->g0:J

    .line 17
    .line 18
    return-void
.end method

.method public setKeyTimeIncrement(J)V
    .registers 5

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v0, p1, v0

    .line 4
    .line 5
    if-lez v0, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    invoke-static {v0}, Loq/a;->n(Z)V

    .line 11
    .line 12
    .line 13
    const/4 v0, -0x1

    .line 14
    iput v0, p0, La6/h;->f0:I

    .line 15
    .line 16
    iput-wide p1, p0, La6/h;->g0:J

    .line 17
    .line 18
    return-void
.end method

.method public setPlayedAdMarkerColor(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->K:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setPlayedColor(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->w:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setPosition(J)V
    .registers 5

    .line 1
    iget-wide v0, p0, La6/h;->p0:J

    .line 2
    .line 3
    cmp-long v0, v0, p1

    .line 4
    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    iput-wide p1, p0, La6/h;->p0:J

    .line 9
    .line 10
    invoke-direct {p0}, La6/h;->getProgressText()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, La6/h;->e()V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public setScrubberColor(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->L:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setUnplayedColor(I)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/h;->y:Landroid/graphics/Paint;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La6/h;->d:Landroid/graphics/Rect;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
