###### Class a6.t (a6.t)
.class public final La6/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lk3/u1;

.field public final b:I

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lk3/v1;IILjava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object p1, p1, Lk3/v1;->a:Lhx/m0;

    .line 5
    .line 6
    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    check-cast p1, Lk3/u1;

    .line 11
    .line 12
    iput-object p1, p0, La6/t;->a:Lk3/u1;

    .line 13
    .line 14
    iput p3, p0, La6/t;->b:I

    .line 15
    .line 16
    iput-object p4, p0, La6/t;->c:Ljava/lang/String;

    .line 17
    .line 18
    return-void
.end method
