###### Class a6.k0 (a6.k0)
.class public interface abstract La6/k0;
.super Ljava/lang/Object;
.source "SourceFile"
