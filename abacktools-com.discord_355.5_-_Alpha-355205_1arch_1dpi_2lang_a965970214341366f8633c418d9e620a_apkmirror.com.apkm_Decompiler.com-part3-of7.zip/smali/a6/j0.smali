###### Class a6.j0 (a6.j0)
.class public final La6/j0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk3/c1;
.implements Landroid/view/View$OnClickListener;
.implements La6/v;
.implements La6/m;


# instance fields
.field public final d:Lk3/k1;

.field public e:Ljava/lang/Object;

.field public final synthetic i:Landroidx/media3/ui/PlayerView;


# direct methods
.method public constructor <init>(Landroidx/media3/ui/PlayerView;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 5
    .line 6
    new-instance p1, Lk3/k1;

    .line 7
    .line 8
    invoke-direct {p1}, Lk3/k1;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, La6/j0;->d:Lk3/k1;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final G(Lk3/d1;Lk3/d1;I)V
    .registers 4

    .line 1
    sget p1, Landroidx/media3/ui/PlayerView;->l0:I

    .line 2
    .line 3
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 4
    .line 5
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->d()Z

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    if-eqz p2, :cond_15

    .line 10
    .line 11
    iget-boolean p2, p1, Landroidx/media3/ui/PlayerView;->i0:Z

    .line 12
    .line 13
    if-eqz p2, :cond_15

    .line 14
    .line 15
    iget-object p1, p1, Landroidx/media3/ui/PlayerView;->N:La6/w;

    .line 16
    .line 17
    if-eqz p1, :cond_15

    .line 18
    .line 19
    invoke-virtual {p1}, La6/w;->g()V

    .line 20
    .line 21
    .line 22
    :cond_15
    return-void
.end method

.method public final I(Lm3/c;)V
    .registers 3

    .line 1
    iget-object v0, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/media3/ui/PlayerView;->K:Landroidx/media3/ui/SubtitleView;

    .line 4
    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    iget-object p1, p1, Lm3/c;->a:Lhx/w1;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Landroidx/media3/ui/SubtitleView;->setCues(Ljava/util/List;)V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method public final b(Lk3/z1;)V
    .registers 4

    .line 1
    sget-object v0, Lk3/z1;->d:Lk3/z1;

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Lk3/z1;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-nez p1, :cond_19

    .line 8
    .line 9
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 10
    .line 11
    iget-object v0, p1, Landroidx/media3/ui/PlayerView;->U:Lk3/e1;

    .line 12
    .line 13
    if-eqz v0, :cond_19

    .line 14
    .line 15
    invoke-interface {v0}, Lk3/e1;->I()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/4 v1, 0x1

    .line 20
    if-ne v0, v1, :cond_16

    .line 21
    .line 22
    goto :goto_19

    .line 23
    :cond_16
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->j()V

    .line 24
    .line 25
    .line 26
    :cond_19
    :goto_19
    return-void
.end method

.method public final e(IZ)V
    .registers 3

    .line 1
    sget p1, Landroidx/media3/ui/PlayerView;->l0:I

    .line 2
    .line 3
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 4
    .line 5
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->k()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->d()Z

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    if-eqz p2, :cond_19

    .line 13
    .line 14
    iget-boolean p2, p1, Landroidx/media3/ui/PlayerView;->i0:Z

    .line 15
    .line 16
    if-eqz p2, :cond_19

    .line 17
    .line 18
    iget-object p1, p1, Landroidx/media3/ui/PlayerView;->N:La6/w;

    .line 19
    .line 20
    if-eqz p1, :cond_18

    .line 21
    .line 22
    invoke-virtual {p1}, La6/w;->g()V

    .line 23
    .line 24
    .line 25
    :cond_18
    return-void

    .line 26
    :cond_19
    const/4 p2, 0x0

    .line 27
    invoke-virtual {p1, p2}, Landroidx/media3/ui/PlayerView;->e(Z)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final g(I)V
    .registers 3

    .line 1
    sget p1, Landroidx/media3/ui/PlayerView;->l0:I

    .line 2
    .line 3
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 4
    .line 5
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->k()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->m()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->d()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1c

    .line 16
    .line 17
    iget-boolean v0, p1, Landroidx/media3/ui/PlayerView;->i0:Z

    .line 18
    .line 19
    if-eqz v0, :cond_1c

    .line 20
    .line 21
    iget-object p1, p1, Landroidx/media3/ui/PlayerView;->N:La6/w;

    .line 22
    .line 23
    if-eqz p1, :cond_1b

    .line 24
    .line 25
    invoke-virtual {p1}, La6/w;->g()V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void

    .line 29
    :cond_1c
    const/4 v0, 0x0

    .line 30
    invoke-virtual {p1, v0}, Landroidx/media3/ui/PlayerView;->e(Z)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final i()V
    .registers 4

    .line 1
    iget-object v0, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    iget-object v1, v0, Landroidx/media3/ui/PlayerView;->i:Landroid/view/View;

    .line 4
    .line 5
    if-eqz v1, :cond_1b

    .line 6
    .line 7
    const/4 v2, 0x4

    .line 8
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->b()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_18

    .line 16
    .line 17
    iget-object v0, v0, Landroidx/media3/ui/PlayerView;->y:Landroid/widget/ImageView;

    .line 18
    .line 19
    if-eqz v0, :cond_1b

    .line 20
    .line 21
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->c()V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void
.end method

.method public final n(II)V
    .registers 7

    .line 1
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    iget-object p2, p1, Landroidx/media3/ui/PlayerView;->v:Landroid/view/View;

    .line 4
    .line 5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    .line 7
    const/16 v1, 0x22

    .line 8
    .line 9
    if-ne v0, v1, :cond_2a

    .line 10
    .line 11
    instance-of v0, p2, Landroid/view/SurfaceView;

    .line 12
    .line 13
    if-eqz v0, :cond_2a

    .line 14
    .line 15
    iget-boolean v0, p1, Landroidx/media3/ui/PlayerView;->k0:Z

    .line 16
    .line 17
    if-eqz v0, :cond_2a

    .line 18
    .line 19
    iget-object v0, p1, Landroidx/media3/ui/PlayerView;->x:La6/o0;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    iget-object v1, p1, Landroidx/media3/ui/PlayerView;->Q:Landroid/os/Handler;

    .line 25
    .line 26
    check-cast p2, Landroid/view/SurfaceView;

    .line 27
    .line 28
    new-instance v2, La6/f;

    .line 29
    .line 30
    const/4 v3, 0x2

    .line 31
    invoke-direct {v2, v3, p1}, La6/f;-><init>(ILjava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    new-instance p1, La6/m0;

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-direct {p1, v3, v0, p2, v2}, La6/m0;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void
.end method

.method public final onClick(Landroid/view/View;)V
    .registers 2

    .line 1
    sget p1, Landroidx/media3/ui/PlayerView;->l0:I

    .line 2
    .line 3
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 4
    .line 5
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->i()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final t(Lk3/v1;)V
    .registers 9

    .line 1
    iget-object p1, p0, La6/j0;->i:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    iget-object v0, p1, Landroidx/media3/ui/PlayerView;->U:Lk3/e1;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const/16 v1, 0x11

    .line 9
    .line 10
    invoke-interface {v0, v1}, Lk3/e1;->D1(I)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_14

    .line 15
    .line 16
    invoke-interface {v0}, Lk3/e1;->U()Lk3/n1;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    goto :goto_16

    .line 21
    :cond_14
    sget-object v1, Lk3/n1;->a:Lk3/j1;

    .line 22
    .line 23
    :goto_16
    invoke-virtual {v1}, Lk3/n1;->p()Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    const/4 v3, 0x0

    .line 28
    const/4 v4, 0x0

    .line 29
    if-eqz v2, :cond_21

    .line 30
    .line 31
    iput-object v4, p0, La6/j0;->e:Ljava/lang/Object;

    .line 32
    .line 33
    goto :goto_5f

    .line 34
    :cond_21
    const/16 v2, 0x1e

    .line 35
    .line 36
    invoke-interface {v0, v2}, Lk3/e1;->D1(I)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    iget-object v5, p0, La6/j0;->d:Lk3/k1;

    .line 41
    .line 42
    if-eqz v2, :cond_45

    .line 43
    .line 44
    invoke-interface {v0}, Lk3/e1;->J()Lk3/v1;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    iget-object v2, v2, Lk3/v1;->a:Lhx/m0;

    .line 49
    .line 50
    invoke-virtual {v2}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-nez v2, :cond_45

    .line 55
    .line 56
    invoke-interface {v0}, Lk3/e1;->t()I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    const/4 v2, 0x1

    .line 61
    invoke-virtual {v1, v0, v5, v2}, Lk3/n1;->f(ILk3/k1;Z)Lk3/k1;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iget-object v0, v0, Lk3/k1;->b:Ljava/lang/Object;

    .line 66
    .line 67
    iput-object v0, p0, La6/j0;->e:Ljava/lang/Object;

    .line 68
    .line 69
    goto :goto_5f

    .line 70
    :cond_45
    iget-object v2, p0, La6/j0;->e:Ljava/lang/Object;

    .line 71
    .line 72
    if-eqz v2, :cond_5f

    .line 73
    .line 74
    invoke-virtual {v1, v2}, Lk3/n1;->b(Ljava/lang/Object;)I

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    const/4 v6, -0x1

    .line 79
    if-eq v2, v6, :cond_5d

    .line 80
    .line 81
    invoke-virtual {v1, v2, v5, v3}, Lk3/n1;->f(ILk3/k1;Z)Lk3/k1;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    iget v1, v1, Lk3/k1;->c:I

    .line 86
    .line 87
    invoke-interface {v0}, Lk3/e1;->P()I

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-ne v0, v1, :cond_5d

    .line 92
    .line 93
    return-void

    .line 94
    :cond_5d
    iput-object v4, p0, La6/j0;->e:Ljava/lang/Object;

    .line 95
    .line 96
    :cond_5f
    :goto_5f
    invoke-virtual {p1, v3}, Landroidx/media3/ui/PlayerView;->n(Z)V

    .line 97
    .line 98
    .line 99
    return-void
.end method
