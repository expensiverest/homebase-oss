###### Class a6.v0 (a6.v0)
.class public interface abstract La6/v0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/util/List;La6/e;FF)V
.end method
