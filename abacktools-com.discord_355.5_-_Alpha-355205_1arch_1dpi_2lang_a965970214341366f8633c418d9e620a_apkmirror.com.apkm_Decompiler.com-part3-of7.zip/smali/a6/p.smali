###### Class a6.p (a6.p)
.class public interface abstract La6/p;
.super Ljava/lang/Object;
.source "SourceFile"
