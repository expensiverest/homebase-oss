###### Class a6.m0 (a6.m0)
.class public final synthetic La6/m0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 1
    iput p1, p0, La6/m0;->d:I

    iput-object p2, p0, La6/m0;->e:Ljava/lang/Object;

    iput-object p3, p0, La6/m0;->i:Ljava/lang/Object;

    iput-object p4, p0, La6/m0;->v:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lgr/a;Lbr/i;Lj10/a;Lbr/h;)V
    .registers 5

    .line 2
    const/16 p3, 0xb

    iput p3, p0, La6/m0;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La6/m0;->e:Ljava/lang/Object;

    iput-object p2, p0, La6/m0;->i:Ljava/lang/Object;

    iput-object p4, p0, La6/m0;->v:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lo00/g;Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 3
    const/16 p2, 0x15

    iput p2, p0, La6/m0;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La6/m0;->e:Ljava/lang/Object;

    iput-object p3, p0, La6/m0;->i:Ljava/lang/Object;

    iput-object p5, p0, La6/m0;->v:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    .line 1
    iget v0, p0, La6/m0;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    packed-switch v0, :pswitch_data_49c

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lv3/n0;

    .line 12
    .line 13
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lhx/j0;

    .line 16
    .line 17
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Lf4/d0;

    .line 20
    .line 21
    iget-object v0, v0, Lv3/n0;->c:Lw3/e;

    .line 22
    .line 23
    invoke-virtual {v1}, Lhx/j0;->g()Lhx/w1;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    iget-object v4, v0, Lw3/e;->v:Lb80/i0;

    .line 28
    .line 29
    iget-object v0, v0, Lw3/e;->y:Lk3/e1;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    invoke-static {v1}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    iput-object v5, v4, Lb80/i0;->e:Ljava/lang/Object;

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    if-nez v5, :cond_3d

    .line 48
    .line 49
    invoke-virtual {v1, v3}, Lhx/w1;->get(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lf4/d0;

    .line 54
    .line 55
    iput-object v1, v4, Lb80/i0;->x:Ljava/lang/Object;

    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    iput-object v2, v4, Lb80/i0;->y:Ljava/lang/Object;

    .line 61
    .line 62
    :cond_3d
    iget-object v1, v4, Lb80/i0;->w:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v1, Lf4/d0;

    .line 65
    .line 66
    if-nez v1, :cond_55

    .line 67
    .line 68
    iget-object v1, v4, Lb80/i0;->e:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v1, Lhx/m0;

    .line 71
    .line 72
    iget-object v2, v4, Lb80/i0;->x:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v2, Lf4/d0;

    .line 75
    .line 76
    iget-object v3, v4, Lb80/i0;->i:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v3, Lk3/k1;

    .line 79
    .line 80
    invoke-static {v0, v1, v2, v3}, Lb80/i0;->B(Lk3/e1;Lhx/m0;Lf4/d0;Lk3/k1;)Lf4/d0;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    iput-object v1, v4, Lb80/i0;->w:Ljava/lang/Object;

    .line 85
    .line 86
    :cond_55
    invoke-interface {v0}, Lk3/e1;->U()Lk3/n1;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {v4, v0}, Lb80/i0;->Z(Lk3/n1;)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    :pswitch_5d
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v0, Lcom/google/android/gms/internal/fido/f8;

    .line 97
    .line 98
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 99
    .line 100
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v2, Lf4/z;

    .line 103
    .line 104
    iget v3, v0, Lcom/google/android/gms/internal/fido/f8;->i:I

    .line 105
    .line 106
    iget-object v0, v0, Lcom/google/android/gms/internal/fido/f8;->e:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v0, Lss/s;

    .line 109
    .line 110
    invoke-interface {v1, v3, v0, v2}, Lss/w;->t(ILss/s;Lf4/z;)V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :pswitch_71
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v0, Lsr/m;

    .line 117
    .line 118
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 119
    .line 120
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v2, Ljava/lang/Exception;

    .line 123
    .line 124
    iget v3, v0, Lsr/m;->a:I

    .line 125
    .line 126
    iget-object v0, v0, Lsr/m;->b:Lss/s;

    .line 127
    .line 128
    invoke-interface {v1, v3, v0, v2}, Lsr/n;->A(ILss/s;Ljava/lang/Exception;)V

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :pswitch_83
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v0, Lcom/facebook/react/defaults/DefaultTurboModuleManagerDelegate;

    .line 135
    .line 136
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v1, Lcom/facebook/react/bridge/ReactApplicationContext;

    .line 139
    .line 140
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v2, Ljava/util/List;

    .line 143
    .line 144
    invoke-static {v0, v1, v2}, Lsn/t;->a(Lcom/facebook/react/defaults/DefaultTurboModuleManagerDelegate;Lcom/facebook/react/bridge/ReactApplicationContext;Ljava/util/List;)V

    .line 145
    .line 146
    .line 147
    return-void

    .line 148
    :pswitch_93
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v0, Lho/c;

    .line 151
    .line 152
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 153
    .line 154
    check-cast v1, Lho/a;

    .line 155
    .line 156
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 157
    .line 158
    check-cast v2, Lsn/e;

    .line 159
    .line 160
    monitor-enter v0

    .line 161
    :try_start_a0
    iget-object v3, v0, Lho/c;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 162
    .line 163
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 164
    .line 165
    .line 166
    move-result v3

    .line 167
    invoke-virtual {v0, v1, v3}, Lho/c;->c(Lho/a;I)V
    :try_end_a9
    .catchall {:try_start_a0 .. :try_end_a9} :catchall_b4

    .line 168
    .line 169
    .line 170
    monitor-exit v0

    .line 171
    iget-object v0, v2, Lsn/e;->d:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 172
    .line 173
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    return-void

    .line 181
    :catchall_b4
    move-exception v1

    .line 182
    :try_start_b5
    monitor-exit v0
    :try_end_b6
    .catchall {:try_start_b5 .. :try_end_b6} :catchall_b4

    .line 183
    throw v1

    .line 184
    :pswitch_b7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v0, Lorg/webrtc/VideoFileRenderer;

    .line 187
    .line 188
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 189
    .line 190
    check-cast v1, Lorg/webrtc/VideoFrame$I420Buffer;

    .line 191
    .line 192
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 193
    .line 194
    check-cast v2, Lorg/webrtc/VideoFrame;

    .line 195
    .line 196
    invoke-static {v0, v1, v2}, Lorg/webrtc/VideoFileRenderer;->d(Lorg/webrtc/VideoFileRenderer;Lorg/webrtc/VideoFrame$I420Buffer;Lorg/webrtc/VideoFrame;)V

    .line 197
    .line 198
    .line 199
    return-void

    .line 200
    :pswitch_c7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast v0, Lorg/webrtc/EglRenderer;

    .line 203
    .line 204
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 205
    .line 206
    check-cast v1, Ljava/util/concurrent/CountDownLatch;

    .line 207
    .line 208
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v2, Lorg/webrtc/EglRenderer$RenderListener;

    .line 211
    .line 212
    invoke-static {v0, v1, v2}, Lorg/webrtc/EglRenderer;->b(Lorg/webrtc/EglRenderer;Ljava/util/concurrent/CountDownLatch;Lorg/webrtc/EglRenderer$RenderListener;)V

    .line 213
    .line 214
    .line 215
    return-void

    .line 216
    :pswitch_d7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast v0, Lorg/webrtc/EglRenderer;

    .line 219
    .line 220
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast v1, Ljava/util/concurrent/CountDownLatch;

    .line 223
    .line 224
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 225
    .line 226
    check-cast v2, Lorg/webrtc/EglRenderer$FrameListener;

    .line 227
    .line 228
    invoke-static {v0, v1, v2}, Lorg/webrtc/EglRenderer;->f(Lorg/webrtc/EglRenderer;Ljava/util/concurrent/CountDownLatch;Lorg/webrtc/EglRenderer$FrameListener;)V

    .line 229
    .line 230
    .line 231
    return-void

    .line 232
    :pswitch_e7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 233
    .line 234
    check-cast v0, Lo00/g;

    .line 235
    .line 236
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 237
    .line 238
    check-cast v1, Ljava/lang/String;

    .line 239
    .line 240
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 241
    .line 242
    check-cast v2, Ljava/lang/String;

    .line 243
    .line 244
    iget-object v4, v0, Lo00/g;->i0:Lin/s;

    .line 245
    .line 246
    new-instance v5, Lcom/facebook/react/bridge/PromiseImpl;

    .line 247
    .line 248
    new-instance v6, Lo00/a;

    .line 249
    .line 250
    invoke-direct {v6, v3, v0, v2}, Lo00/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    new-instance v2, Lo00/b;

    .line 254
    .line 255
    invoke-direct {v2, v3, v0}, Lo00/b;-><init>(ILjava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    invoke-direct {v5, v6, v2}, Lcom/facebook/react/bridge/PromiseImpl;-><init>(Lcom/facebook/react/bridge/Callback;Lcom/facebook/react/bridge/Callback;)V

    .line 259
    .line 260
    .line 261
    monitor-enter v4

    .line 262
    :try_start_105
    invoke-interface {v5, v1}, Lcom/facebook/react/bridge/Promise;->resolve(Ljava/lang/Object;)V
    :try_end_108
    .catchall {:try_start_105 .. :try_end_108} :catchall_10a

    .line 263
    .line 264
    .line 265
    monitor-exit v4

    .line 266
    return-void

    .line 267
    :catchall_10a
    move-exception v0

    .line 268
    :try_start_10b
    monitor-exit v4
    :try_end_10c
    .catchall {:try_start_10b .. :try_end_10c} :catchall_10a

    .line 269
    throw v0

    .line 270
    :pswitch_10d
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 271
    .line 272
    check-cast v0, Lmx/e0;

    .line 273
    .line 274
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 275
    .line 276
    check-cast v1, Lw3/h;

    .line 277
    .line 278
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 279
    .line 280
    check-cast v2, Ly5/c2;

    .line 281
    .line 282
    :try_start_119
    iget-object v3, v0, Lmx/o;->d:Ljava/lang/Object;

    .line 283
    .line 284
    instance-of v3, v3, Lmx/a;

    .line 285
    .line 286
    if-eqz v3, :cond_120

    .line 287
    .line 288
    goto :goto_12b

    .line 289
    :cond_120
    invoke-virtual {v1}, Lw3/h;->run()V

    .line 290
    .line 291
    .line 292
    invoke-virtual {v0, v2}, Lmx/o;->m(Ljava/lang/Object;)Z
    :try_end_126
    .catchall {:try_start_119 .. :try_end_126} :catchall_127

    .line 293
    .line 294
    .line 295
    goto :goto_12b

    .line 296
    :catchall_127
    move-exception v1

    .line 297
    invoke-virtual {v0, v1}, Lmx/o;->n(Ljava/lang/Throwable;)Z

    .line 298
    .line 299
    .line 300
    :goto_12b
    return-void

    .line 301
    :pswitch_12c
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 302
    .line 303
    check-cast v0, Lmx/y;

    .line 304
    .line 305
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast v1, Lmx/e0;

    .line 308
    .line 309
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 310
    .line 311
    check-cast v2, Lmx/q;

    .line 312
    .line 313
    :try_start_138
    invoke-static {v0}, Lk7/f;->q(Ljava/util/concurrent/Future;)Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v0
    :try_end_13c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_138 .. :try_end_13c} :catch_15d
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_138 .. :try_end_13c} :catch_150
    .catch Ljava/lang/RuntimeException; {:try_start_138 .. :try_end_13c} :catch_14b
    .catch Ljava/lang/Error; {:try_start_138 .. :try_end_13c} :catch_149

    .line 317
    :try_start_13c
    invoke-interface {v2, v0}, Lmx/q;->apply(Ljava/lang/Object;)Lmx/y;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    invoke-virtual {v1, v0}, Lmx/o;->o(Lmx/y;)Z
    :try_end_143
    .catchall {:try_start_13c .. :try_end_143} :catchall_144

    .line 322
    .line 323
    .line 324
    goto :goto_160

    .line 325
    :catchall_144
    move-exception v0

    .line 326
    invoke-virtual {v1, v0}, Lmx/o;->n(Ljava/lang/Throwable;)Z

    .line 327
    .line 328
    .line 329
    goto :goto_160

    .line 330
    :catch_149
    move-exception v0

    .line 331
    goto :goto_14c

    .line 332
    :catch_14b
    move-exception v0

    .line 333
    :goto_14c
    invoke-virtual {v1, v0}, Lmx/o;->n(Ljava/lang/Throwable;)Z

    .line 334
    .line 335
    .line 336
    goto :goto_160

    .line 337
    :catch_150
    move-exception v0

    .line 338
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 339
    .line 340
    .line 341
    move-result-object v2

    .line 342
    if-nez v2, :cond_158

    .line 343
    .line 344
    goto :goto_159

    .line 345
    :cond_158
    move-object v0, v2

    .line 346
    :goto_159
    invoke-virtual {v1, v0}, Lmx/o;->n(Ljava/lang/Throwable;)Z

    .line 347
    .line 348
    .line 349
    goto :goto_160

    .line 350
    :catch_15d
    invoke-virtual {v1, v3}, Lmx/o;->cancel(Z)Z

    .line 351
    .line 352
    .line 353
    :goto_160
    return-void

    .line 354
    :pswitch_161
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v0, Lk7/l;

    .line 357
    .line 358
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 359
    .line 360
    check-cast v1, Landroid/util/Pair;

    .line 361
    .line 362
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v2, Ljava/lang/Exception;

    .line 365
    .line 366
    iget-object v0, v0, Lk7/l;->e:Ljava/lang/Object;

    .line 367
    .line 368
    check-cast v0, Lmr/j1;

    .line 369
    .line 370
    iget-object v0, v0, Lmr/j1;->j:Ljava/lang/Object;

    .line 371
    .line 372
    check-cast v0, Lnr/g;

    .line 373
    .line 374
    iget-object v3, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 375
    .line 376
    check-cast v3, Ljava/lang/Integer;

    .line 377
    .line 378
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 379
    .line 380
    .line 381
    move-result v3

    .line 382
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 383
    .line 384
    check-cast v1, Lss/s;

    .line 385
    .line 386
    invoke-virtual {v0, v3, v1, v2}, Lnr/g;->A(ILss/s;Ljava/lang/Exception;)V

    .line 387
    .line 388
    .line 389
    return-void

    .line 390
    :pswitch_185
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 391
    .line 392
    check-cast v0, Lmr/a1;

    .line 393
    .line 394
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 395
    .line 396
    check-cast v1, Lhx/j0;

    .line 397
    .line 398
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast v2, Lss/s;

    .line 401
    .line 402
    iget-object v0, v0, Lmr/a1;->c:Lnr/g;

    .line 403
    .line 404
    invoke-virtual {v1}, Lhx/j0;->g()Lhx/w1;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    iget-object v4, v0, Lnr/g;->v:Lb80/i0;

    .line 409
    .line 410
    iget-object v0, v0, Lnr/g;->y:Lmr/u1;

    .line 411
    .line 412
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 413
    .line 414
    .line 415
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 416
    .line 417
    .line 418
    invoke-static {v1}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    .line 419
    .line 420
    .line 421
    move-result-object v5

    .line 422
    iput-object v5, v4, Lb80/i0;->e:Ljava/lang/Object;

    .line 423
    .line 424
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 425
    .line 426
    .line 427
    move-result v5

    .line 428
    if-nez v5, :cond_1ba

    .line 429
    .line 430
    invoke-virtual {v1, v3}, Lhx/w1;->get(I)Ljava/lang/Object;

    .line 431
    .line 432
    .line 433
    move-result-object v1

    .line 434
    check-cast v1, Lss/s;

    .line 435
    .line 436
    iput-object v1, v4, Lb80/i0;->x:Ljava/lang/Object;

    .line 437
    .line 438
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 439
    .line 440
    .line 441
    iput-object v2, v4, Lb80/i0;->y:Ljava/lang/Object;

    .line 442
    .line 443
    :cond_1ba
    iget-object v1, v4, Lb80/i0;->w:Ljava/lang/Object;

    .line 444
    .line 445
    check-cast v1, Lss/s;

    .line 446
    .line 447
    if-nez v1, :cond_1d2

    .line 448
    .line 449
    iget-object v1, v4, Lb80/i0;->e:Ljava/lang/Object;

    .line 450
    .line 451
    check-cast v1, Lhx/m0;

    .line 452
    .line 453
    iget-object v2, v4, Lb80/i0;->x:Ljava/lang/Object;

    .line 454
    .line 455
    check-cast v2, Lss/s;

    .line 456
    .line 457
    iget-object v3, v4, Lb80/i0;->i:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast v3, Lmr/h2;

    .line 460
    .line 461
    invoke-static {v0, v1, v2, v3}, Lb80/i0;->C(Lmr/u1;Lhx/m0;Lss/s;Lmr/h2;)Lss/s;

    .line 462
    .line 463
    .line 464
    move-result-object v1

    .line 465
    iput-object v1, v4, Lb80/i0;->w:Ljava/lang/Object;

    .line 466
    .line 467
    :cond_1d2
    invoke-interface {v0}, Lmr/u1;->U()Lmr/j2;

    .line 468
    .line 469
    .line 470
    move-result-object v0

    .line 471
    invoke-virtual {v4, v0}, Lb80/i0;->a0(Lmr/j2;)V

    .line 472
    .line 473
    .line 474
    return-void

    .line 475
    :pswitch_1da
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 476
    .line 477
    check-cast v0, Lk7/l;

    .line 478
    .line 479
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 480
    .line 481
    check-cast v1, Lk3/w;

    .line 482
    .line 483
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 484
    .line 485
    check-cast v2, Lv3/d;

    .line 486
    .line 487
    iget-object v0, v0, Lk7/l;->e:Ljava/lang/Object;

    .line 488
    .line 489
    check-cast v0, Lv3/q;

    .line 490
    .line 491
    sget-object v3, Ln3/l0;->a:Ljava/lang/String;

    .line 492
    .line 493
    iget-object v0, v0, Lv3/q;->d:Lv3/w;

    .line 494
    .line 495
    iput-object v1, v0, Lv3/w;->x0:Lk3/w;

    .line 496
    .line 497
    iget-object v0, v0, Lv3/w;->V:Lw3/e;

    .line 498
    .line 499
    invoke-virtual {v0}, Lw3/e;->V()Lw3/a;

    .line 500
    .line 501
    .line 502
    move-result-object v3

    .line 503
    new-instance v4, Ll5/g;

    .line 504
    .line 505
    invoke-direct {v4, v3, v1, v2}, Ll5/g;-><init>(Lw3/a;Lk3/w;Lv3/d;)V

    .line 506
    .line 507
    .line 508
    const/16 v1, 0x3f9

    .line 509
    .line 510
    invoke-virtual {v0, v3, v1, v4}, Lw3/e;->W(Lw3/a;ILn3/n;)V

    .line 511
    .line 512
    .line 513
    return-void

    .line 514
    :pswitch_201
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 515
    .line 516
    check-cast v0, [[B

    .line 517
    .line 518
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 519
    .line 520
    check-cast v1, Landroid/app/Activity;

    .line 521
    .line 522
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 523
    .line 524
    check-cast v2, Ljava/util/concurrent/CountDownLatch;

    .line 525
    .line 526
    invoke-static {v0, v1, v2}, Lio/sentry/react/RNSentryModuleImpl;->h([[BLandroid/app/Activity;Ljava/util/concurrent/CountDownLatch;)V

    .line 527
    .line 528
    .line 529
    return-void

    .line 530
    :pswitch_211
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 531
    .line 532
    check-cast v0, Lio/sentry/cache/g;

    .line 533
    .line 534
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 535
    .line 536
    check-cast v1, Lio/sentry/m6;

    .line 537
    .line 538
    iget-object v3, p0, La6/m0;->v:Ljava/lang/Object;

    .line 539
    .line 540
    check-cast v3, Lio/sentry/t3;

    .line 541
    .line 542
    const-string v4, "trace.json"

    .line 543
    .line 544
    if-nez v1, :cond_23a

    .line 545
    .line 546
    iget-object v1, v3, Lio/sentry/t3;->r:Lfb/l;

    .line 547
    .line 548
    new-instance v3, Lio/sentry/m6;

    .line 549
    .line 550
    iget-object v5, v1, Lfb/l;->e:Ljava/lang/Object;

    .line 551
    .line 552
    check-cast v5, Lio/sentry/protocol/v;

    .line 553
    .line 554
    iget-object v1, v1, Lfb/l;->i:Ljava/lang/Object;

    .line 555
    .line 556
    check-cast v1, Lio/sentry/o6;

    .line 557
    .line 558
    const-string v6, "default"

    .line 559
    .line 560
    invoke-direct {v3, v5, v1, v6, v2}, Lio/sentry/m6;-><init>(Lio/sentry/protocol/v;Lio/sentry/o6;Ljava/lang/String;Lio/sentry/o6;)V

    .line 561
    .line 562
    .line 563
    const-string v1, "auto"

    .line 564
    .line 565
    iput-object v1, v3, Lio/sentry/m6;->K:Ljava/lang/String;

    .line 566
    .line 567
    invoke-virtual {v0, v3, v4}, Lio/sentry/cache/g;->r(Ljava/lang/Object;Ljava/lang/String;)V

    .line 568
    .line 569
    .line 570
    goto :goto_23d

    .line 571
    :cond_23a
    invoke-virtual {v0, v1, v4}, Lio/sentry/cache/g;->r(Ljava/lang/Object;Ljava/lang/String;)V

    .line 572
    .line 573
    .line 574
    :goto_23d
    return-void

    .line 575
    :pswitch_23e
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 576
    .line 577
    check-cast v0, Lio/sentry/android/replay/screenshot/f;

    .line 578
    .line 579
    iget-object v2, p0, La6/m0;->i:Ljava/lang/Object;

    .line 580
    .line 581
    check-cast v2, Lio/sentry/android/replay/viewhierarchy/f;

    .line 582
    .line 583
    iget-object v4, v0, Lio/sentry/android/replay/screenshot/f;->m:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 584
    .line 585
    iget-object v5, v0, Lio/sentry/android/replay/screenshot/f;->b:Lio/sentry/a6;

    .line 586
    .line 587
    iget-object v6, v0, Lio/sentry/android/replay/screenshot/f;->g:Landroid/graphics/Bitmap;

    .line 588
    .line 589
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 590
    .line 591
    .line 592
    move-result v4

    .line 593
    if-nez v4, :cond_28d

    .line 594
    .line 595
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->isRecycled()Z

    .line 596
    .line 597
    .line 598
    move-result v4

    .line 599
    if-eqz v4, :cond_259

    .line 600
    .line 601
    goto :goto_28d

    .line 602
    :cond_259
    new-instance v4, Ljava/util/ArrayList;

    .line 603
    .line 604
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 605
    .line 606
    .line 607
    new-instance v7, Landroid/graphics/Canvas;

    .line 608
    .line 609
    invoke-direct {v7, v6}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 610
    .line 611
    .line 612
    iget-object v8, v0, Lio/sentry/android/replay/screenshot/f;->i:Ljava/lang/Object;

    .line 613
    .line 614
    invoke-interface {v8}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 615
    .line 616
    .line 617
    move-result-object v8

    .line 618
    check-cast v8, Landroid/graphics/Matrix;

    .line 619
    .line 620
    invoke-virtual {v7, v8}, Landroid/graphics/Canvas;->setMatrix(Landroid/graphics/Matrix;)V

    .line 621
    .line 622
    .line 623
    new-instance v8, Ld80/c;

    .line 624
    .line 625
    invoke-direct {v8, v0, v4, v7}, Ld80/c;-><init>(Lio/sentry/android/replay/screenshot/f;Ljava/util/ArrayList;Landroid/graphics/Canvas;)V

    .line 626
    .line 627
    .line 628
    invoke-virtual {v2, v8}, Lio/sentry/android/replay/viewhierarchy/f;->a(Ld80/c;)V

    .line 629
    .line 630
    .line 631
    invoke-virtual {v5}, Lio/sentry/a6;->getReplayController()Lio/sentry/n3;

    .line 632
    .line 633
    .line 634
    move-result-object v2

    .line 635
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 636
    .line 637
    .line 638
    iget-object v2, v0, Lio/sentry/android/replay/screenshot/f;->a:Lio/sentry/android/replay/ReplayIntegration;

    .line 639
    .line 640
    invoke-virtual {v2, v6}, Lio/sentry/android/replay/ReplayIntegration;->L(Landroid/graphics/Bitmap;)V

    .line 641
    .line 642
    .line 643
    iget-object v2, v0, Lio/sentry/android/replay/screenshot/f;->j:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 644
    .line 645
    invoke-virtual {v2, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 646
    .line 647
    .line 648
    iget-object v0, v0, Lio/sentry/android/replay/screenshot/f;->l:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 649
    .line 650
    invoke-virtual {v0, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 651
    .line 652
    .line 653
    goto :goto_29a

    .line 654
    :cond_28d
    :goto_28d
    invoke-virtual {v5}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 655
    .line 656
    .line 657
    move-result-object v0

    .line 658
    sget-object v1, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 659
    .line 660
    const-string v2, "PixelCopyStrategy is closed, skipping masking"

    .line 661
    .line 662
    new-array v3, v3, [Ljava/lang/Object;

    .line 663
    .line 664
    invoke-interface {v0, v1, v2, v3}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 665
    .line 666
    .line 667
    :goto_29a
    return-void

    .line 668
    :pswitch_29b
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 669
    .line 670
    check-cast v0, Landroid/text/Layout;

    .line 671
    .line 672
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 673
    .line 674
    check-cast v1, Landroid/graphics/Canvas;

    .line 675
    .line 676
    iget-object v4, p0, La6/m0;->v:Ljava/lang/Object;

    .line 677
    .line 678
    check-cast v4, Lcom/facebook/react/views/text/PreparedLayoutTextView;

    .line 679
    .line 680
    sget-object v5, Lcom/facebook/react/views/text/PreparedLayoutTextView;->x:Landroid/graphics/Paint;

    .line 681
    .line 682
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 683
    .line 684
    const/16 v7, 0x22

    .line 685
    .line 686
    if-lt v6, v7, :cond_2bd

    .line 687
    .line 688
    sget-object v3, Lhq/a;->a:Lhq/a;

    .line 689
    .line 690
    iget-object v4, v4, Lcom/facebook/react/views/text/PreparedLayoutTextView;->e:Lds/f;

    .line 691
    .line 692
    if-eqz v4, :cond_2b9

    .line 693
    .line 694
    iget-object v2, v4, Lds/f;->v:Ljava/lang/Object;

    .line 695
    .line 696
    check-cast v2, Landroid/graphics/Path;

    .line 697
    .line 698
    :cond_2b9
    invoke-virtual {v3, v0, v1, v2, v5}, Lhq/a;->a(Landroid/text/Layout;Landroid/graphics/Canvas;Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 699
    .line 700
    .line 701
    goto :goto_2c8

    .line 702
    :cond_2bd
    iget-object v4, v4, Lcom/facebook/react/views/text/PreparedLayoutTextView;->e:Lds/f;

    .line 703
    .line 704
    if-eqz v4, :cond_2c5

    .line 705
    .line 706
    iget-object v2, v4, Lds/f;->v:Ljava/lang/Object;

    .line 707
    .line 708
    check-cast v2, Landroid/graphics/Path;

    .line 709
    .line 710
    :cond_2c5
    invoke-virtual {v0, v1, v2, v5, v3}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;Landroid/graphics/Path;Landroid/graphics/Paint;I)V

    .line 711
    .line 712
    .line 713
    :goto_2c8
    return-void

    .line 714
    :pswitch_2c9
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 715
    .line 716
    check-cast v0, Lgr/a;

    .line 717
    .line 718
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 719
    .line 720
    check-cast v1, Lbr/i;

    .line 721
    .line 722
    iget-object v2, v1, Lbr/i;->a:Ljava/lang/String;

    .line 723
    .line 724
    iget-object v3, p0, La6/m0;->v:Ljava/lang/Object;

    .line 725
    .line 726
    check-cast v3, Lbr/h;

    .line 727
    .line 728
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 729
    .line 730
    .line 731
    sget-object v4, Lgr/a;->f:Ljava/util/logging/Logger;

    .line 732
    .line 733
    const-string v5, "Transport backend \'"

    .line 734
    .line 735
    :try_start_2de
    iget-object v6, v0, Lgr/a;->c:Lcr/d;

    .line 736
    .line 737
    invoke-virtual {v6, v2}, Lcr/d;->a(Ljava/lang/String;)Lcr/e;

    .line 738
    .line 739
    .line 740
    move-result-object v6

    .line 741
    if-nez v6, :cond_302

    .line 742
    .line 743
    new-instance v0, Ljava/lang/StringBuilder;

    .line 744
    .line 745
    invoke-direct {v0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 746
    .line 747
    .line 748
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 749
    .line 750
    .line 751
    const-string v1, "\' is not registered"

    .line 752
    .line 753
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 754
    .line 755
    .line 756
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 757
    .line 758
    .line 759
    move-result-object v0

    .line 760
    invoke-virtual {v4, v0}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    .line 761
    .line 762
    .line 763
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 764
    .line 765
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 766
    .line 767
    .line 768
    goto :goto_32b

    .line 769
    :catch_300
    move-exception v0

    .line 770
    goto :goto_316

    .line 771
    :cond_302
    check-cast v6, Lzq/b;

    .line 772
    .line 773
    invoke-virtual {v6, v3}, Lzq/b;->a(Lbr/h;)Lbr/h;

    .line 774
    .line 775
    .line 776
    move-result-object v2

    .line 777
    iget-object v3, v0, Lgr/a;->e:Ljr/c;

    .line 778
    .line 779
    new-instance v5, Lbq/a;

    .line 780
    .line 781
    const/4 v6, 0x5

    .line 782
    invoke-direct {v5, v6, v0, v1, v2}, Lbq/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 783
    .line 784
    .line 785
    check-cast v3, Lir/h;

    .line 786
    .line 787
    invoke-virtual {v3, v5}, Lir/h;->l(Ljr/b;)Ljava/lang/Object;
    :try_end_315
    .catch Ljava/lang/Exception; {:try_start_2de .. :try_end_315} :catch_300

    .line 788
    .line 789
    .line 790
    goto :goto_32b

    .line 791
    :goto_316
    new-instance v1, Ljava/lang/StringBuilder;

    .line 792
    .line 793
    const-string v2, "Error scheduling event "

    .line 794
    .line 795
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 796
    .line 797
    .line 798
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 799
    .line 800
    .line 801
    move-result-object v0

    .line 802
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 803
    .line 804
    .line 805
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 806
    .line 807
    .line 808
    move-result-object v0

    .line 809
    invoke-virtual {v4, v0}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    .line 810
    .line 811
    .line 812
    :goto_32b
    return-void

    .line 813
    :pswitch_32c
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 814
    .line 815
    check-cast v0, Lcom/discord/chat/presentation/message/view/MediaView;

    .line 816
    .line 817
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 818
    .line 819
    check-cast v1, Leg/h0;

    .line 820
    .line 821
    iget-object v4, p0, La6/m0;->v:Ljava/lang/Object;

    .line 822
    .line 823
    check-cast v4, Leg/d0;

    .line 824
    .line 825
    iget-boolean v5, v0, Lcom/discord/chat/presentation/message/view/MediaView;->y:Z

    .line 826
    .line 827
    if-nez v5, :cond_370

    .line 828
    .line 829
    iget-boolean v5, v0, Lcom/discord/chat/presentation/message/view/MediaView;->w:Z

    .line 830
    .line 831
    if-nez v5, :cond_370

    .line 832
    .line 833
    iget-boolean v5, v0, Lcom/discord/chat/presentation/message/view/MediaView;->x:Z

    .line 834
    .line 835
    if-eqz v5, :cond_370

    .line 836
    .line 837
    sget-object v5, Lwh/c;->a:Ljava/util/LinkedHashMap;

    .line 838
    .line 839
    iget-object v5, v0, Lcom/discord/chat/presentation/message/view/MediaView;->i:Leg/e0;

    .line 840
    .line 841
    if-eqz v5, :cond_34c

    .line 842
    .line 843
    iget-object v2, v5, Leg/e0;->k:Ljava/lang/Double;

    .line 844
    .line 845
    :cond_34c
    invoke-static {v2}, Lwh/c;->a(Ljava/lang/Double;)Ljava/lang/Boolean;

    .line 846
    .line 847
    .line 848
    move-result-object v2

    .line 849
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 850
    .line 851
    invoke-static {v2, v5}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 852
    .line 853
    .line 854
    move-result v2

    .line 855
    if-nez v2, :cond_370

    .line 856
    .line 857
    invoke-virtual {v0}, Lcom/discord/chat/presentation/message/view/MediaView;->a()Z

    .line 858
    .line 859
    .line 860
    move-result v2

    .line 861
    if-eqz v2, :cond_370

    .line 862
    .line 863
    iget-object v2, v0, Lcom/discord/chat/presentation/message/view/MediaView;->v:Leg/h0;

    .line 864
    .line 865
    if-ne v2, v1, :cond_370

    .line 866
    .line 867
    iget-object v2, v0, Lcom/discord/chat/presentation/message/view/MediaView;->e:Leg/d0;

    .line 868
    .line 869
    if-ne v2, v4, :cond_370

    .line 870
    .line 871
    iput-boolean v3, v0, Lcom/discord/chat/presentation/message/view/MediaView;->L:Z

    .line 872
    .line 873
    iput-boolean v3, v0, Lcom/discord/chat/presentation/message/view/MediaView;->P:Z

    .line 874
    .line 875
    invoke-interface {v1, v4}, Leg/h0;->e0(Leg/d0;)V

    .line 876
    .line 877
    .line 878
    invoke-virtual {v0}, Lcom/discord/chat/presentation/message/view/MediaView;->b()V

    .line 879
    .line 880
    .line 881
    :cond_370
    return-void

    .line 882
    :pswitch_371
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 883
    .line 884
    check-cast v0, Lcom/swmansion/reanimated/pseudoSelectors/PseudoSelectorManager;

    .line 885
    .line 886
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 887
    .line 888
    check-cast v1, Landroid/view/View;

    .line 889
    .line 890
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 891
    .line 892
    check-cast v2, Landroid/view/View;

    .line 893
    .line 894
    invoke-static {v0, v1, v2}, Lcom/swmansion/reanimated/pseudoSelectors/PseudoSelectorManager;->a(Lcom/swmansion/reanimated/pseudoSelectors/PseudoSelectorManager;Landroid/view/View;Landroid/view/View;)V

    .line 895
    .line 896
    .line 897
    return-void

    .line 898
    :pswitch_381
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 899
    .line 900
    check-cast v0, Ljava/lang/String;

    .line 901
    .line 902
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 903
    .line 904
    check-cast v1, Ljava/lang/String;

    .line 905
    .line 906
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 907
    .line 908
    check-cast v2, Lcom/facebook/react/bridge/Promise;

    .line 909
    .line 910
    invoke-static {v0, v1, v2}, Lcom/reactnativecommunity/webview/RNCWebViewModule;->a(Ljava/lang/String;Ljava/lang/String;Lcom/facebook/react/bridge/Promise;)V

    .line 911
    .line 912
    .line 913
    return-void

    .line 914
    :pswitch_391
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 915
    .line 916
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 917
    .line 918
    iget-object v2, p0, La6/m0;->i:Ljava/lang/Object;

    .line 919
    .line 920
    check-cast v2, Lorg/chromium/net/UrlRequest;

    .line 921
    .line 922
    iget-object v4, p0, La6/m0;->v:Ljava/lang/Object;

    .line 923
    .line 924
    check-cast v4, Ljava/nio/ByteBuffer;

    .line 925
    .line 926
    invoke-virtual {v0, v3, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 927
    .line 928
    .line 929
    move-result v0

    .line 930
    if-eqz v0, :cond_3ab

    .line 931
    .line 932
    sget-object v0, Lcom/margelo/nitro/nitrofetch/HybridNitroFetchClient;->e:Ljava/util/concurrent/ConcurrentHashMap;

    .line 933
    .line 934
    invoke-virtual {v0, v2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 935
    .line 936
    .line 937
    :try_start_3a8
    invoke-virtual {v2, v4}, Lorg/chromium/net/UrlRequest;->read(Ljava/nio/ByteBuffer;)V
    :try_end_3ab
    .catch Ljava/lang/IllegalStateException; {:try_start_3a8 .. :try_end_3ab} :catch_3ab

    .line 938
    .line 939
    .line 940
    :catch_3ab
    :cond_3ab
    return-void

    .line 941
    :pswitch_3ac
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 942
    .line 943
    check-cast v0, Lcom/google/firebase/messaging/g;

    .line 944
    .line 945
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 946
    .line 947
    check-cast v1, Landroid/content/Intent;

    .line 948
    .line 949
    iget-object v3, p0, La6/m0;->v:Ljava/lang/Object;

    .line 950
    .line 951
    check-cast v3, Lnv/h;

    .line 952
    .line 953
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 954
    .line 955
    .line 956
    :try_start_3bb
    invoke-virtual {v0, v1}, Lcom/google/firebase/messaging/g;->handleIntent(Landroid/content/Intent;)V
    :try_end_3be
    .catchall {:try_start_3bb .. :try_end_3be} :catchall_3c2

    .line 957
    .line 958
    .line 959
    invoke-virtual {v3, v2}, Lnv/h;->b(Ljava/lang/Object;)V

    .line 960
    .line 961
    .line 962
    return-void

    .line 963
    :catchall_3c2
    move-exception v0

    .line 964
    invoke-virtual {v3, v2}, Lnv/h;->b(Ljava/lang/Object;)V

    .line 965
    .line 966
    .line 967
    throw v0

    .line 968
    :pswitch_3c7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 969
    .line 970
    check-cast v0, Lcom/appsflyer/internal/AFj1rSDK;

    .line 971
    .line 972
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 973
    .line 974
    check-cast v1, Lcom/appsflyer/internal/AFi1bSDK;

    .line 975
    .line 976
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 977
    .line 978
    check-cast v2, Ljava/lang/Runnable;

    .line 979
    .line 980
    invoke-static {v0, v1, v2}, Lcom/appsflyer/internal/AFj1rSDK;->e(Lcom/appsflyer/internal/AFj1rSDK;Lcom/appsflyer/internal/AFi1bSDK;Ljava/lang/Runnable;)V

    .line 981
    .line 982
    .line 983
    return-void

    .line 984
    :pswitch_3d7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 985
    .line 986
    check-cast v0, Lcom/appsflyer/internal/AFd1ySDK;

    .line 987
    .line 988
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 989
    .line 990
    check-cast v1, Ljava/lang/Throwable;

    .line 991
    .line 992
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 993
    .line 994
    check-cast v2, Ljava/lang/String;

    .line 995
    .line 996
    invoke-static {v0, v1, v2}, Lcom/appsflyer/internal/AFd1ySDK;->a(Lcom/appsflyer/internal/AFd1ySDK;Ljava/lang/Throwable;Ljava/lang/String;)V

    .line 997
    .line 998
    .line 999
    return-void

    .line 1000
    :pswitch_3e7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 1001
    .line 1002
    check-cast v0, Lcom/appsflyer/internal/AFa1uSDK;

    .line 1003
    .line 1004
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 1005
    .line 1006
    check-cast v1, Landroid/content/Context;

    .line 1007
    .line 1008
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 1009
    .line 1010
    check-cast v2, Landroid/content/Intent;

    .line 1011
    .line 1012
    invoke-static {v0, v1, v2}, Lcom/appsflyer/internal/AFa1uSDK;->b(Lcom/appsflyer/internal/AFa1uSDK;Landroid/content/Context;Landroid/content/Intent;)V

    .line 1013
    .line 1014
    .line 1015
    return-void

    .line 1016
    :pswitch_3f7
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 1017
    .line 1018
    check-cast v0, Lc7/f;

    .line 1019
    .line 1020
    iget-object v2, p0, La6/m0;->i:Ljava/lang/Object;

    .line 1021
    .line 1022
    check-cast v2, Lmx/y;

    .line 1023
    .line 1024
    iget-object v3, p0, La6/m0;->v:Ljava/lang/Object;

    .line 1025
    .line 1026
    check-cast v3, Lc7/u;

    .line 1027
    .line 1028
    :try_start_403
    invoke-interface {v2}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 1029
    .line 1030
    .line 1031
    move-result-object v2

    .line 1032
    check-cast v2, Ljava/lang/Boolean;

    .line 1033
    .line 1034
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1035
    .line 1036
    .line 1037
    move-result v1
    :try_end_40d
    .catch Ljava/lang/InterruptedException; {:try_start_403 .. :try_end_40d} :catch_40d
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_403 .. :try_end_40d} :catch_40d

    .line 1038
    :catch_40d
    iget-object v2, v0, Lc7/f;->k:Ljava/lang/Object;

    .line 1039
    .line 1040
    monitor-enter v2

    .line 1041
    :try_start_410
    iget-object v4, v3, Lc7/u;->i:Lk7/o;

    .line 1042
    .line 1043
    invoke-static {v4}, Lk80/d;->w(Lk7/o;)Lk7/j;

    .line 1044
    .line 1045
    .line 1046
    move-result-object v4

    .line 1047
    iget-object v5, v4, Lk7/j;->a:Ljava/lang/String;

    .line 1048
    .line 1049
    invoke-virtual {v0, v5}, Lc7/f;->c(Ljava/lang/String;)Lc7/u;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v6

    .line 1053
    if-ne v6, v3, :cond_424

    .line 1054
    .line 1055
    invoke-virtual {v0, v5}, Lc7/f;->b(Ljava/lang/String;)Lc7/u;

    .line 1056
    .line 1057
    .line 1058
    goto :goto_424

    .line 1059
    :catchall_422
    move-exception v0

    .line 1060
    goto :goto_467

    .line 1061
    :cond_424
    :goto_424
    invoke-static {}, Lb7/s;->d()Lb7/s;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v3

    .line 1065
    sget-object v6, Lc7/f;->l:Ljava/lang/String;

    .line 1066
    .line 1067
    new-instance v7, Ljava/lang/StringBuilder;

    .line 1068
    .line 1069
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 1070
    .line 1071
    .line 1072
    const-class v8, Lc7/f;

    .line 1073
    .line 1074
    invoke-virtual {v8}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 1075
    .line 1076
    .line 1077
    move-result-object v8

    .line 1078
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1079
    .line 1080
    .line 1081
    const-string v8, " "

    .line 1082
    .line 1083
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1084
    .line 1085
    .line 1086
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1087
    .line 1088
    .line 1089
    const-string v5, " executed; reschedule = "

    .line 1090
    .line 1091
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1092
    .line 1093
    .line 1094
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 1095
    .line 1096
    .line 1097
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1098
    .line 1099
    .line 1100
    move-result-object v5

    .line 1101
    invoke-virtual {v3, v6, v5}, Lb7/s;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 1102
    .line 1103
    .line 1104
    iget-object v0, v0, Lc7/f;->j:Ljava/util/ArrayList;

    .line 1105
    .line 1106
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1107
    .line 1108
    .line 1109
    move-result-object v0

    .line 1110
    :goto_455
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1111
    .line 1112
    .line 1113
    move-result v3

    .line 1114
    if-eqz v3, :cond_465

    .line 1115
    .line 1116
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v3

    .line 1120
    check-cast v3, Lc7/c;

    .line 1121
    .line 1122
    invoke-interface {v3, v4, v1}, Lc7/c;->b(Lk7/j;Z)V

    .line 1123
    .line 1124
    .line 1125
    goto :goto_455

    .line 1126
    :cond_465
    monitor-exit v2

    .line 1127
    return-void

    .line 1128
    :goto_467
    monitor-exit v2
    :try_end_468
    .catchall {:try_start_410 .. :try_end_468} :catchall_422

    .line 1129
    throw v0

    .line 1130
    :pswitch_469
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 1131
    .line 1132
    check-cast v0, Landroid/view/ViewGroup;

    .line 1133
    .line 1134
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 1135
    .line 1136
    check-cast v1, Landroid/view/View;

    .line 1137
    .line 1138
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 1139
    .line 1140
    check-cast v2, Lb3/f;

    .line 1141
    .line 1142
    const-string v3, "$container"

    .line 1143
    .line 1144
    invoke-static {v0, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1145
    .line 1146
    .line 1147
    const-string v3, "this$0"

    .line 1148
    .line 1149
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1150
    .line 1151
    .line 1152
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    .line 1153
    .line 1154
    .line 1155
    iget-object v0, v2, Lb3/f;->c:Lb3/g;

    .line 1156
    .line 1157
    iget-object v0, v0, Lb3/l;->e:Ljava/lang/Object;

    .line 1158
    .line 1159
    check-cast v0, Lb3/q1;

    .line 1160
    .line 1161
    invoke-virtual {v0, v2}, Lb3/q1;->c(Lb3/p1;)V

    .line 1162
    .line 1163
    .line 1164
    return-void

    .line 1165
    :pswitch_48c
    iget-object v0, p0, La6/m0;->e:Ljava/lang/Object;

    .line 1166
    .line 1167
    check-cast v0, La6/o0;

    .line 1168
    .line 1169
    iget-object v1, p0, La6/m0;->i:Ljava/lang/Object;

    .line 1170
    .line 1171
    check-cast v1, Landroid/view/SurfaceView;

    .line 1172
    .line 1173
    iget-object v2, p0, La6/m0;->v:Ljava/lang/Object;

    .line 1174
    .line 1175
    check-cast v2, La6/f;

    .line 1176
    .line 1177
    invoke-static {v0, v1, v2}, La6/o0;->a(La6/o0;Landroid/view/SurfaceView;La6/f;)V

    .line 1178
    .line 1179
    .line 1180
    return-void

    .line 1181
    :pswitch_data_49c
    .packed-switch 0x0
        :pswitch_48c
        :pswitch_469
        :pswitch_3f7
        :pswitch_3e7
        :pswitch_3d7
        :pswitch_3c7
        :pswitch_3ac
        :pswitch_391
        :pswitch_381
        :pswitch_371
        :pswitch_32c
        :pswitch_2c9
        :pswitch_29b
        :pswitch_23e
        :pswitch_211
        :pswitch_201
        :pswitch_1da
        :pswitch_185
        :pswitch_161
        :pswitch_12c
        :pswitch_10d
        :pswitch_e7
        :pswitch_d7
        :pswitch_c7
        :pswitch_b7
        :pswitch_93
        :pswitch_83
        :pswitch_71
        :pswitch_5d
    .end packed-switch
.end method
