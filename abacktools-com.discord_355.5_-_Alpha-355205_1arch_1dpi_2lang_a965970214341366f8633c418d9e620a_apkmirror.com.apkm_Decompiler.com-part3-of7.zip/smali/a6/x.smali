###### Class a6.x (a6.x)
.class public final synthetic La6/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:La6/b0;


# direct methods
.method public synthetic constructor <init>(La6/b0;I)V
    .registers 3

    .line 1
    iput p2, p0, La6/x;->d:I

    iput-object p1, p0, La6/x;->e:La6/b0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 13

    .line 1
    iget v0, p0, La6/x;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x2

    .line 6
    iget-object v4, p0, La6/x;->e:La6/b0;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_184

    .line 9
    .line 10
    .line 11
    invoke-virtual {v4, v3}, La6/b0;->i(I)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :pswitch_e
    iget-object v0, v4, La6/b0;->m:Landroid/animation/AnimatorSet;

    .line 16
    .line 17
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 18
    .line 19
    .line 20
    iget-object v0, v4, La6/b0;->v:La6/x;

    .line 21
    .line 22
    const-wide/16 v1, 0x7d0

    .line 23
    .line 24
    invoke-virtual {v4, v0, v1, v2}, La6/b0;->e(Ljava/lang/Runnable;J)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_1b
    iget-object v0, v4, La6/b0;->n:Landroid/animation/AnimatorSet;

    .line 29
    .line 30
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_21
    iget-object v0, v4, La6/b0;->o:Landroid/animation/AnimatorSet;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :pswitch_27
    iget-object v0, v4, La6/b0;->s:Landroid/animation/ValueAnimator;

    .line 41
    .line 42
    iget-object v5, v4, La6/b0;->l:Landroid/view/View;

    .line 43
    .line 44
    iget-object v6, v4, La6/b0;->a:La6/w;

    .line 45
    .line 46
    iget-object v7, v4, La6/b0;->h:Landroid/view/ViewGroup;

    .line 47
    .line 48
    iget-object v8, v4, La6/b0;->g:Landroid/view/ViewGroup;

    .line 49
    .line 50
    if-eqz v8, :cond_de

    .line 51
    .line 52
    if-nez v7, :cond_37

    .line 53
    .line 54
    goto/16 :goto_de

    .line 55
    .line 56
    :cond_37
    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    .line 57
    .line 58
    .line 59
    move-result v9

    .line 60
    invoke-virtual {v6}, Landroid/view/View;->getPaddingLeft()I

    .line 61
    .line 62
    .line 63
    move-result v10

    .line 64
    sub-int/2addr v9, v10

    .line 65
    invoke-virtual {v6}, Landroid/view/View;->getPaddingRight()I

    .line 66
    .line 67
    .line 68
    move-result v6

    .line 69
    sub-int/2addr v9, v6

    .line 70
    :goto_45
    invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I

    .line 71
    .line 72
    .line 73
    move-result v6

    .line 74
    if-le v6, v1, :cond_5b

    .line 75
    .line 76
    invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    sub-int/2addr v6, v3

    .line 81
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 82
    .line 83
    .line 84
    move-result-object v10

    .line 85
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->removeViewAt(I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v8, v10, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 89
    .line 90
    .line 91
    goto :goto_45

    .line 92
    :cond_5b
    if-eqz v5, :cond_62

    .line 93
    .line 94
    const/16 v3, 0x8

    .line 95
    .line 96
    invoke-virtual {v5, v3}, Landroid/view/View;->setVisibility(I)V

    .line 97
    .line 98
    .line 99
    :cond_62
    iget-object v3, v4, La6/b0;->j:Landroid/view/ViewGroup;

    .line 100
    .line 101
    invoke-static {v3}, La6/b0;->c(Landroid/view/View;)I

    .line 102
    .line 103
    .line 104
    move-result v3

    .line 105
    invoke-virtual {v8}, Landroid/view/ViewGroup;->getChildCount()I

    .line 106
    .line 107
    .line 108
    move-result v6

    .line 109
    sub-int/2addr v6, v1

    .line 110
    move v10, v2

    .line 111
    :goto_6e
    if-ge v10, v6, :cond_7c

    .line 112
    .line 113
    invoke-virtual {v8, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 114
    .line 115
    .line 116
    move-result-object v11

    .line 117
    invoke-static {v11}, La6/b0;->c(Landroid/view/View;)I

    .line 118
    .line 119
    .line 120
    move-result v11

    .line 121
    add-int/2addr v3, v11

    .line 122
    add-int/lit8 v10, v10, 0x1

    .line 123
    .line 124
    goto :goto_6e

    .line 125
    :cond_7c
    if-le v3, v9, :cond_c6

    .line 126
    .line 127
    if-eqz v5, :cond_88

    .line 128
    .line 129
    invoke-virtual {v5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 130
    .line 131
    .line 132
    invoke-static {v5}, La6/b0;->c(Landroid/view/View;)I

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    add-int/2addr v3, v0

    .line 137
    :cond_88
    new-instance v0, Ljava/util/ArrayList;

    .line 138
    .line 139
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 140
    .line 141
    .line 142
    move v4, v2

    .line 143
    :goto_8e
    if-ge v4, v6, :cond_a2

    .line 144
    .line 145
    invoke-virtual {v8, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 146
    .line 147
    .line 148
    move-result-object v5

    .line 149
    invoke-static {v5}, La6/b0;->c(Landroid/view/View;)I

    .line 150
    .line 151
    .line 152
    move-result v10

    .line 153
    sub-int/2addr v3, v10

    .line 154
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    if-gt v3, v9, :cond_9f

    .line 158
    .line 159
    goto :goto_a2

    .line 160
    :cond_9f
    add-int/lit8 v4, v4, 0x1

    .line 161
    .line 162
    goto :goto_8e

    .line 163
    :cond_a2
    :goto_a2
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 164
    .line 165
    .line 166
    move-result v3

    .line 167
    if-nez v3, :cond_de

    .line 168
    .line 169
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 170
    .line 171
    .line 172
    move-result v3

    .line 173
    invoke-virtual {v8, v2, v3}, Landroid/view/ViewGroup;->removeViews(II)V

    .line 174
    .line 175
    .line 176
    :goto_af
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    if-ge v2, v3, :cond_de

    .line 181
    .line 182
    invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I

    .line 183
    .line 184
    .line 185
    move-result v3

    .line 186
    sub-int/2addr v3, v1

    .line 187
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v4

    .line 191
    check-cast v4, Landroid/view/View;

    .line 192
    .line 193
    invoke-virtual {v7, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 194
    .line 195
    .line 196
    add-int/lit8 v2, v2, 0x1

    .line 197
    .line 198
    goto :goto_af

    .line 199
    :cond_c6
    iget-object v1, v4, La6/b0;->i:Landroid/view/ViewGroup;

    .line 200
    .line 201
    if-eqz v1, :cond_de

    .line 202
    .line 203
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 204
    .line 205
    .line 206
    move-result v1

    .line 207
    if-nez v1, :cond_de

    .line 208
    .line 209
    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isStarted()Z

    .line 210
    .line 211
    .line 212
    move-result v1

    .line 213
    if-nez v1, :cond_de

    .line 214
    .line 215
    iget-object v1, v4, La6/b0;->r:Landroid/animation/ValueAnimator;

    .line 216
    .line 217
    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    .line 221
    .line 222
    .line 223
    :cond_de
    :goto_de
    return-void

    .line 224
    :pswitch_df
    iget-object v0, v4, La6/b0;->k:Landroid/view/View;

    .line 225
    .line 226
    iget-object v3, v4, La6/b0;->f:Landroid/view/ViewGroup;

    .line 227
    .line 228
    const/4 v5, 0x4

    .line 229
    if-eqz v3, :cond_f0

    .line 230
    .line 231
    iget-boolean v6, v4, La6/b0;->B:Z

    .line 232
    .line 233
    if-eqz v6, :cond_ec

    .line 234
    .line 235
    move v6, v2

    .line 236
    goto :goto_ed

    .line 237
    :cond_ec
    move v6, v5

    .line 238
    :goto_ed
    invoke-virtual {v3, v6}, Landroid/view/View;->setVisibility(I)V

    .line 239
    .line 240
    .line 241
    :cond_f0
    if-eqz v0, :cond_15b

    .line 242
    .line 243
    iget-object v3, v4, La6/b0;->a:La6/w;

    .line 244
    .line 245
    invoke-virtual {v3}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 246
    .line 247
    .line 248
    move-result-object v3

    .line 249
    const v6, 0x7f0700b7

    .line 250
    .line 251
    .line 252
    invoke-virtual {v3, v6}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 253
    .line 254
    .line 255
    move-result v3

    .line 256
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 257
    .line 258
    .line 259
    move-result-object v6

    .line 260
    check-cast v6, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 261
    .line 262
    if-eqz v6, :cond_111

    .line 263
    .line 264
    iget-boolean v7, v4, La6/b0;->B:Z

    .line 265
    .line 266
    if-eqz v7, :cond_10c

    .line 267
    .line 268
    move v3, v2

    .line 269
    :cond_10c
    iput v3, v6, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 270
    .line 271
    invoke-virtual {v0, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 272
    .line 273
    .line 274
    :cond_111
    instance-of v3, v0, La6/h;

    .line 275
    .line 276
    if-eqz v3, :cond_15b

    .line 277
    .line 278
    check-cast v0, La6/h;

    .line 279
    .line 280
    iget-object v3, v0, La6/h;->d:Landroid/graphics/Rect;

    .line 281
    .line 282
    iget-object v6, v0, La6/h;->j0:Landroid/animation/ValueAnimator;

    .line 283
    .line 284
    iget-boolean v7, v4, La6/b0;->B:Z

    .line 285
    .line 286
    const/4 v8, 0x0

    .line 287
    if-eqz v7, :cond_131

    .line 288
    .line 289
    invoke-virtual {v6}, Landroid/animation/ValueAnimator;->isStarted()Z

    .line 290
    .line 291
    .line 292
    move-result v7

    .line 293
    if-eqz v7, :cond_129

    .line 294
    .line 295
    invoke-virtual {v6}, Landroid/animation/ValueAnimator;->cancel()V

    .line 296
    .line 297
    .line 298
    :cond_129
    iput-boolean v1, v0, La6/h;->l0:Z

    .line 299
    .line 300
    iput v8, v0, La6/h;->k0:F

    .line 301
    .line 302
    invoke-virtual {v0, v3}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 303
    .line 304
    .line 305
    goto :goto_15b

    .line 306
    :cond_131
    iget v7, v4, La6/b0;->A:I

    .line 307
    .line 308
    if-ne v7, v1, :cond_146

    .line 309
    .line 310
    invoke-virtual {v6}, Landroid/animation/ValueAnimator;->isStarted()Z

    .line 311
    .line 312
    .line 313
    move-result v1

    .line 314
    if-eqz v1, :cond_13e

    .line 315
    .line 316
    invoke-virtual {v6}, Landroid/animation/ValueAnimator;->cancel()V

    .line 317
    .line 318
    .line 319
    :cond_13e
    iput-boolean v2, v0, La6/h;->l0:Z

    .line 320
    .line 321
    iput v8, v0, La6/h;->k0:F

    .line 322
    .line 323
    invoke-virtual {v0, v3}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 324
    .line 325
    .line 326
    goto :goto_15b

    .line 327
    :cond_146
    const/4 v1, 0x3

    .line 328
    if-eq v7, v1, :cond_15b

    .line 329
    .line 330
    invoke-virtual {v6}, Landroid/animation/ValueAnimator;->isStarted()Z

    .line 331
    .line 332
    .line 333
    move-result v1

    .line 334
    if-eqz v1, :cond_152

    .line 335
    .line 336
    invoke-virtual {v6}, Landroid/animation/ValueAnimator;->cancel()V

    .line 337
    .line 338
    .line 339
    :cond_152
    iput-boolean v2, v0, La6/h;->l0:Z

    .line 340
    .line 341
    const/high16 v1, 0x3f800000    # 1.0f

    .line 342
    .line 343
    iput v1, v0, La6/h;->k0:F

    .line 344
    .line 345
    invoke-virtual {v0, v3}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    .line 346
    .line 347
    .line 348
    :cond_15b
    :goto_15b
    iget-object v0, v4, La6/b0;->z:Ljava/util/ArrayList;

    .line 349
    .line 350
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    :goto_161
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 355
    .line 356
    .line 357
    move-result v1

    .line 358
    if-eqz v1, :cond_17e

    .line 359
    .line 360
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    check-cast v1, Landroid/view/View;

    .line 365
    .line 366
    iget-boolean v3, v4, La6/b0;->B:Z

    .line 367
    .line 368
    if-eqz v3, :cond_179

    .line 369
    .line 370
    invoke-static {v1}, La6/b0;->j(Landroid/view/View;)Z

    .line 371
    .line 372
    .line 373
    move-result v3

    .line 374
    if-eqz v3, :cond_179

    .line 375
    .line 376
    move v3, v5

    .line 377
    goto :goto_17a

    .line 378
    :cond_179
    move v3, v2

    .line 379
    :goto_17a
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 380
    .line 381
    .line 382
    goto :goto_161

    .line 383
    :cond_17e
    return-void

    .line 384
    :pswitch_17f
    invoke-virtual {v4}, La6/b0;->k()V

    .line 385
    .line 386
    .line 387
    return-void

    .line 388
    nop

    .line 389
    :pswitch_data_184
    .packed-switch 0x0
        :pswitch_17f
        :pswitch_df
        :pswitch_27
        :pswitch_21
        :pswitch_1b
        :pswitch_e
    .end packed-switch
.end method
