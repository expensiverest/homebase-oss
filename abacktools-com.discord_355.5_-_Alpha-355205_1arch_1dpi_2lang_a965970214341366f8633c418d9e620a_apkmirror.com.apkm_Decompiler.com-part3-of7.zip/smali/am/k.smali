###### Class am.k (am.k)
.class public final Lam/k;
.super Lam/f;
.source "SourceFile"

# interfaces
.implements Lam/h;


# instance fields
.field public final J:Landroid/graphics/Paint;

.field public K:Z

.field public L:F

.field public M:I

.field public N:I

.field public O:F

.field public P:Z

.field public final Q:Landroid/graphics/Path;

.field public final R:Landroid/graphics/Path;

.field public final S:Landroid/graphics/RectF;

.field public final v:I

.field public final w:Landroid/graphics/RectF;

.field public final x:[F

.field public final y:[F


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1}, Lam/f;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 5
    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    iput p1, p0, Lam/k;->v:I

    .line 9
    .line 10
    new-instance v0, Landroid/graphics/RectF;

    .line 11
    .line 12
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lam/k;->w:Landroid/graphics/RectF;

    .line 16
    .line 17
    const/16 v0, 0x8

    .line 18
    .line 19
    new-array v1, v0, [F

    .line 20
    .line 21
    iput-object v1, p0, Lam/k;->x:[F

    .line 22
    .line 23
    new-array v0, v0, [F

    .line 24
    .line 25
    iput-object v0, p0, Lam/k;->y:[F

    .line 26
    .line 27
    new-instance v0, Landroid/graphics/Paint;

    .line 28
    .line 29
    invoke-direct {v0, p1}, Landroid/graphics/Paint;-><init>(I)V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Lam/k;->J:Landroid/graphics/Paint;

    .line 33
    .line 34
    const/4 p1, 0x0

    .line 35
    iput-boolean p1, p0, Lam/k;->K:Z

    .line 36
    .line 37
    const/4 v0, 0x0

    .line 38
    iput v0, p0, Lam/k;->L:F

    .line 39
    .line 40
    iput p1, p0, Lam/k;->M:I

    .line 41
    .line 42
    iput p1, p0, Lam/k;->N:I

    .line 43
    .line 44
    iput v0, p0, Lam/k;->O:F

    .line 45
    .line 46
    iput-boolean p1, p0, Lam/k;->P:Z

    .line 47
    .line 48
    new-instance p1, Landroid/graphics/Path;

    .line 49
    .line 50
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 51
    .line 52
    .line 53
    iput-object p1, p0, Lam/k;->Q:Landroid/graphics/Path;

    .line 54
    .line 55
    new-instance p1, Landroid/graphics/Path;

    .line 56
    .line 57
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 58
    .line 59
    .line 60
    iput-object p1, p0, Lam/k;->R:Landroid/graphics/Path;

    .line 61
    .line 62
    new-instance p1, Landroid/graphics/RectF;

    .line 63
    .line 64
    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    .line 65
    .line 66
    .line 67
    iput-object p1, p0, Lam/k;->S:Landroid/graphics/RectF;

    .line 68
    .line 69
    return-void
.end method


# virtual methods
.method public final b(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lam/k;->K:Z

    .line 2
    .line 3
    invoke-virtual {p0}, Lam/k;->v()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final c()V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lam/k;->x:[F

    .line 3
    .line 4
    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([FF)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lam/k;->v()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .registers 13

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lam/k;->w:Landroid/graphics/RectF;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 8
    .line 9
    .line 10
    iget v0, p0, Lam/k;->v:I

    .line 11
    .line 12
    invoke-static {v0}, Lv0/d;->d(I)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lam/k;->Q:Landroid/graphics/Path;

    .line 17
    .line 18
    iget-object v8, p0, Lam/k;->J:Landroid/graphics/Paint;

    .line 19
    .line 20
    if-eqz v0, :cond_29

    .line 21
    .line 22
    const/4 v1, 0x1

    .line 23
    if-eq v0, v1, :cond_1b

    .line 24
    .line 25
    :cond_18
    :goto_18
    move-object v3, p1

    .line 26
    goto/16 :goto_a0

    .line 27
    .line 28
    :cond_1b
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    .line 33
    .line 34
    .line 35
    invoke-super {p0, p1}, Lam/f;->draw(Landroid/graphics/Canvas;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 39
    .line 40
    .line 41
    goto :goto_18

    .line 42
    :cond_29
    invoke-super {p0, p1}, Lam/f;->draw(Landroid/graphics/Canvas;)V

    .line 43
    .line 44
    .line 45
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 46
    .line 47
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 48
    .line 49
    .line 50
    iget v0, p0, Lam/k;->N:I

    .line 51
    .line 52
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 53
    .line 54
    .line 55
    const/4 v0, 0x0

    .line 56
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 57
    .line 58
    .line 59
    iget-boolean v3, p0, Lam/k;->P:Z

    .line 60
    .line 61
    invoke-virtual {v8, v3}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    .line 62
    .line 63
    .line 64
    sget-object v3, Landroid/graphics/Path$FillType;->EVEN_ODD:Landroid/graphics/Path$FillType;

    .line 65
    .line 66
    invoke-virtual {v2, v3}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1, v2, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 70
    .line 71
    .line 72
    iget-boolean v3, p0, Lam/k;->K:Z

    .line 73
    .line 74
    if-eqz v3, :cond_18

    .line 75
    .line 76
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    .line 81
    .line 82
    .line 83
    move-result v4

    .line 84
    sub-float/2addr v3, v4

    .line 85
    iget v4, p0, Lam/k;->L:F

    .line 86
    .line 87
    add-float/2addr v3, v4

    .line 88
    const/high16 v4, 0x40000000    # 2.0f

    .line 89
    .line 90
    div-float v9, v3, v4

    .line 91
    .line 92
    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    sub-float/2addr v3, v5

    .line 101
    iget v5, p0, Lam/k;->L:F

    .line 102
    .line 103
    add-float/2addr v3, v5

    .line 104
    div-float v10, v3, v4

    .line 105
    .line 106
    cmpl-float v3, v9, v0

    .line 107
    .line 108
    if-lez v3, :cond_85

    .line 109
    .line 110
    iget v4, v1, Landroid/graphics/RectF;->left:F

    .line 111
    .line 112
    iget v5, v1, Landroid/graphics/RectF;->top:F

    .line 113
    .line 114
    add-float v6, v4, v9

    .line 115
    .line 116
    iget v7, v1, Landroid/graphics/RectF;->bottom:F

    .line 117
    .line 118
    move-object v3, p1

    .line 119
    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 120
    .line 121
    .line 122
    iget v6, v1, Landroid/graphics/RectF;->right:F

    .line 123
    .line 124
    sub-float v4, v6, v9

    .line 125
    .line 126
    iget v5, v1, Landroid/graphics/RectF;->top:F

    .line 127
    .line 128
    iget v7, v1, Landroid/graphics/RectF;->bottom:F

    .line 129
    .line 130
    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 131
    .line 132
    .line 133
    goto :goto_86

    .line 134
    :cond_85
    move-object v3, p1

    .line 135
    :goto_86
    cmpl-float p1, v10, v0

    .line 136
    .line 137
    if-lez p1, :cond_a0

    .line 138
    .line 139
    iget v4, v1, Landroid/graphics/RectF;->left:F

    .line 140
    .line 141
    iget v5, v1, Landroid/graphics/RectF;->top:F

    .line 142
    .line 143
    iget v6, v1, Landroid/graphics/RectF;->right:F

    .line 144
    .line 145
    add-float v7, v5, v10

    .line 146
    .line 147
    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 148
    .line 149
    .line 150
    iget v4, v1, Landroid/graphics/RectF;->left:F

    .line 151
    .line 152
    iget v7, v1, Landroid/graphics/RectF;->bottom:F

    .line 153
    .line 154
    sub-float v5, v7, v10

    .line 155
    .line 156
    iget v6, v1, Landroid/graphics/RectF;->right:F

    .line 157
    .line 158
    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 159
    .line 160
    .line 161
    :cond_a0
    :goto_a0
    iget p1, p0, Lam/k;->M:I

    .line 162
    .line 163
    if-eqz p1, :cond_bd

    .line 164
    .line 165
    sget-object p1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 166
    .line 167
    invoke-virtual {v8, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 168
    .line 169
    .line 170
    iget p1, p0, Lam/k;->M:I

    .line 171
    .line 172
    invoke-virtual {v8, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 173
    .line 174
    .line 175
    iget p1, p0, Lam/k;->L:F

    .line 176
    .line 177
    invoke-virtual {v8, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 178
    .line 179
    .line 180
    sget-object p1, Landroid/graphics/Path$FillType;->EVEN_ODD:Landroid/graphics/Path$FillType;

    .line 181
    .line 182
    invoke-virtual {v2, p1}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 183
    .line 184
    .line 185
    iget-object p1, p0, Lam/k;->R:Landroid/graphics/Path;

    .line 186
    .line 187
    invoke-virtual {v3, p1, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 188
    .line 189
    .line 190
    :cond_bd
    return-void
.end method

.method public final e(FI)V
    .registers 3

    .line 1
    iput p2, p0, Lam/k;->M:I

    .line 2
    .line 3
    iput p1, p0, Lam/k;->L:F

    .line 4
    .line 5
    invoke-virtual {p0}, Lam/k;->v()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final g(Z)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lam/k;->P:Z

    .line 2
    .line 3
    if-eq v0, p1, :cond_9

    .line 4
    .line 5
    iput-boolean p1, p0, Lam/k;->P:Z

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public final m()V
    .registers 1

    .line 1
    return-void
.end method

.method public final o(F)V
    .registers 2

    .line 1
    iput p1, p0, Lam/k;->O:F

    .line 2
    .line 3
    invoke-virtual {p0}, Lam/k;->v()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lam/f;->onBoundsChange(Landroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lam/k;->v()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final r()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lam/k;->v()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final s([F)V
    .registers 7

    .line 1
    iget-object v0, p0, Lam/k;->x:[F

    .line 2
    .line 3
    if-nez p1, :cond_9

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    invoke-static {v0, p1}, Ljava/util/Arrays;->fill([FF)V

    .line 7
    .line 8
    .line 9
    goto :goto_1a

    .line 10
    :cond_9
    array-length v1, p1

    .line 11
    const/16 v2, 0x8

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    if-ne v1, v2, :cond_11

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    goto :goto_12

    .line 18
    :cond_11
    move v1, v3

    .line 19
    :goto_12
    const-string v4, "radii should have exactly 8 values"

    .line 20
    .line 21
    invoke-static {v4, v1}, Lfl/j;->b(Ljava/lang/String;Z)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1, v3, v0, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 25
    .line 26
    .line 27
    :goto_1a
    invoke-virtual {p0}, Lam/k;->v()V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final v()V
    .registers 10

    .line 1
    iget-object v0, p0, Lam/k;->Q:Landroid/graphics/Path;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lam/k;->R:Landroid/graphics/Path;

    .line 7
    .line 8
    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    iget-object v3, p0, Lam/k;->S:Landroid/graphics/RectF;

    .line 16
    .line 17
    invoke-virtual {v3, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 18
    .line 19
    .line 20
    iget v2, p0, Lam/k;->O:F

    .line 21
    .line 22
    invoke-virtual {v3, v2, v2}, Landroid/graphics/RectF;->inset(FF)V

    .line 23
    .line 24
    .line 25
    iget v2, p0, Lam/k;->v:I

    .line 26
    .line 27
    const/4 v4, 0x1

    .line 28
    if-ne v2, v4, :cond_22

    .line 29
    .line 30
    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 31
    .line 32
    invoke-virtual {v0, v3, v2}, Landroid/graphics/Path;->addRect(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V

    .line 33
    .line 34
    .line 35
    :cond_22
    iget-boolean v2, p0, Lam/k;->K:Z

    .line 36
    .line 37
    iget-object v4, p0, Lam/k;->x:[F

    .line 38
    .line 39
    const/high16 v5, 0x40000000    # 2.0f

    .line 40
    .line 41
    if-eqz v2, :cond_45

    .line 42
    .line 43
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    .line 48
    .line 49
    .line 50
    move-result v6

    .line 51
    invoke-virtual {v3}, Landroid/graphics/RectF;->width()F

    .line 52
    .line 53
    .line 54
    move-result v7

    .line 55
    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    .line 56
    .line 57
    .line 58
    move-result v8

    .line 59
    invoke-static {v7, v8}, Ljava/lang/Math;->min(FF)F

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    div-float/2addr v7, v5

    .line 64
    sget-object v8, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 65
    .line 66
    invoke-virtual {v0, v2, v6, v7, v8}, Landroid/graphics/Path;->addCircle(FFFLandroid/graphics/Path$Direction;)V

    .line 67
    .line 68
    .line 69
    goto :goto_4a

    .line 70
    :cond_45
    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 71
    .line 72
    invoke-virtual {v0, v3, v4, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    .line 73
    .line 74
    .line 75
    :goto_4a
    iget v0, p0, Lam/k;->O:F

    .line 76
    .line 77
    neg-float v0, v0

    .line 78
    invoke-virtual {v3, v0, v0}, Landroid/graphics/RectF;->inset(FF)V

    .line 79
    .line 80
    .line 81
    iget v0, p0, Lam/k;->L:F

    .line 82
    .line 83
    div-float/2addr v0, v5

    .line 84
    invoke-virtual {v3, v0, v0}, Landroid/graphics/RectF;->inset(FF)V

    .line 85
    .line 86
    .line 87
    iget-boolean v0, p0, Lam/k;->K:Z

    .line 88
    .line 89
    if-eqz v0, :cond_75

    .line 90
    .line 91
    invoke-virtual {v3}, Landroid/graphics/RectF;->width()F

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    div-float/2addr v0, v5

    .line 104
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    .line 109
    .line 110
    .line 111
    move-result v4

    .line 112
    sget-object v6, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 113
    .line 114
    invoke-virtual {v1, v2, v4, v0, v6}, Landroid/graphics/Path;->addCircle(FFFLandroid/graphics/Path$Direction;)V

    .line 115
    .line 116
    .line 117
    goto :goto_8e

    .line 118
    :cond_75
    const/4 v0, 0x0

    .line 119
    :goto_76
    iget-object v2, p0, Lam/k;->y:[F

    .line 120
    .line 121
    array-length v6, v2

    .line 122
    if-ge v0, v6, :cond_89

    .line 123
    .line 124
    aget v6, v4, v0

    .line 125
    .line 126
    iget v7, p0, Lam/k;->O:F

    .line 127
    .line 128
    add-float/2addr v6, v7

    .line 129
    iget v7, p0, Lam/k;->L:F

    .line 130
    .line 131
    div-float/2addr v7, v5

    .line 132
    sub-float/2addr v6, v7

    .line 133
    aput v6, v2, v0

    .line 134
    .line 135
    add-int/lit8 v0, v0, 0x1

    .line 136
    .line 137
    goto :goto_76

    .line 138
    :cond_89
    sget-object v0, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 139
    .line 140
    invoke-virtual {v1, v3, v2, v0}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    .line 141
    .line 142
    .line 143
    :goto_8e
    iget v0, p0, Lam/k;->L:F

    .line 144
    .line 145
    neg-float v0, v0

    .line 146
    div-float/2addr v0, v5

    .line 147
    invoke-virtual {v3, v0, v0}, Landroid/graphics/RectF;->inset(FF)V

    .line 148
    .line 149
    .line 150
    return-void
.end method
