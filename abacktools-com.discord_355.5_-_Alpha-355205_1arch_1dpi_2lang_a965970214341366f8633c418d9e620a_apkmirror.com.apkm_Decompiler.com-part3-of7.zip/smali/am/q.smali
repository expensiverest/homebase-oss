###### Class am.q (am.q)
.class public interface abstract Lam/q;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract l(Lam/r;)V
.end method
