###### Class am.r (am.r)
.class public interface abstract Lam/r;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(Landroid/graphics/Matrix;)V
.end method

.method public abstract n(Landroid/graphics/RectF;)V
.end method
