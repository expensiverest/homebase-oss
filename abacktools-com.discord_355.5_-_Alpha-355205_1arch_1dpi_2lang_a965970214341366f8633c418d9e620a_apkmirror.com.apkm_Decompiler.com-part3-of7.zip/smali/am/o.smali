###### Class am.o (am.o)
.class public interface abstract Lam/o;
.super Ljava/lang/Object;
.source "SourceFile"
