###### Class am.c (am.c)
.class public interface abstract Lam/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract k(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
.end method

.method public abstract q()Landroid/graphics/drawable/Drawable;
.end method
