###### Class am.i (am.i)
.class public final Lam/i;
.super Lam/l;
.source "SourceFile"


# static fields
.field public static final synthetic f0:I


# instance fields
.field public final a0:Landroid/graphics/Paint;

.field public final b0:Landroid/graphics/Paint;

.field public final c0:Landroid/graphics/Bitmap;

.field public d0:Ljava/lang/ref/WeakReference;

.field public e0:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;Landroid/graphics/Paint;)V
    .registers 7

    .line 1
    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, v0}, Lam/l;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 7
    .line 8
    .line 9
    new-instance p1, Landroid/graphics/Paint;

    .line 10
    .line 11
    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lam/i;->a0:Landroid/graphics/Paint;

    .line 15
    .line 16
    new-instance v0, Landroid/graphics/Paint;

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Lam/i;->b0:Landroid/graphics/Paint;

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    iput-object v2, p0, Lam/i;->e0:Landroid/graphics/RectF;

    .line 26
    .line 27
    iput-object p2, p0, Lam/i;->c0:Landroid/graphics/Bitmap;

    .line 28
    .line 29
    if-eqz p3, :cond_21

    .line 30
    .line 31
    invoke-virtual {p1, p3}, Landroid/graphics/Paint;->set(Landroid/graphics/Paint;)V

    .line 32
    .line 33
    .line 34
    :cond_21
    invoke-virtual {p1, v1}, Landroid/graphics/Paint;->setFlags(I)V

    .line 35
    .line 36
    .line 37
    sget-object p1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 38
    .line 39
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method


# virtual methods
.method public final d()V
    .registers 4

    .line 1
    invoke-super {p0}, Lam/l;->d()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lam/i;->e0:Landroid/graphics/RectF;

    .line 5
    .line 6
    if-nez v0, :cond_e

    .line 7
    .line 8
    new-instance v0, Landroid/graphics/RectF;

    .line 9
    .line 10
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lam/i;->e0:Landroid/graphics/RectF;

    .line 14
    .line 15
    :cond_e
    iget-object v0, p0, Lam/i;->e0:Landroid/graphics/RectF;

    .line 16
    .line 17
    iget-object v1, p0, Lam/l;->O:Landroid/graphics/RectF;

    .line 18
    .line 19
    iget-object v2, p0, Lam/l;->V:Landroid/graphics/Matrix;

    .line 20
    .line 21
    invoke-virtual {v2, v0, v1}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .registers 7

    .line 1
    invoke-static {}, Lmn/a;->H()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lam/l;->e:Z

    .line 5
    .line 6
    if-nez v0, :cond_12

    .line 7
    .line 8
    iget-boolean v0, p0, Lam/l;->i:Z

    .line 9
    .line 10
    if-nez v0, :cond_12

    .line 11
    .line 12
    iget v0, p0, Lam/l;->v:F

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    cmpl-float v0, v0, v1

    .line 16
    .line 17
    if-lez v0, :cond_18

    .line 18
    .line 19
    :cond_12
    iget-object v0, p0, Lam/i;->c0:Landroid/graphics/Bitmap;

    .line 20
    .line 21
    if-eqz v0, :cond_18

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    const/4 v0, 0x0

    .line 26
    :goto_19
    if-nez v0, :cond_22

    .line 27
    .line 28
    invoke-super {p0, p1}, Lam/l;->draw(Landroid/graphics/Canvas;)V

    .line 29
    .line 30
    .line 31
    invoke-static {}, Lmn/a;->H()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_22
    invoke-virtual {p0}, Lam/i;->d()V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p0}, Lam/l;->a()V

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Lam/i;->d0:Ljava/lang/ref/WeakReference;

    .line 42
    .line 43
    iget-object v1, p0, Lam/i;->a0:Landroid/graphics/Paint;

    .line 44
    .line 45
    iget-object v2, p0, Lam/i;->c0:Landroid/graphics/Bitmap;

    .line 46
    .line 47
    if-eqz v0, :cond_36

    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    if-eq v0, v2, :cond_4c

    .line 54
    .line 55
    :cond_36
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 56
    .line 57
    invoke-direct {v0, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iput-object v0, p0, Lam/i;->d0:Ljava/lang/ref/WeakReference;

    .line 61
    .line 62
    if-eqz v2, :cond_4c

    .line 63
    .line 64
    new-instance v0, Landroid/graphics/BitmapShader;

    .line 65
    .line 66
    sget-object v3, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 67
    .line 68
    invoke-direct {v0, v2, v3, v3}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 72
    .line 73
    .line 74
    const/4 v0, 0x1

    .line 75
    iput-boolean v0, p0, Lam/l;->x:Z

    .line 76
    .line 77
    :cond_4c
    iget-boolean v0, p0, Lam/l;->x:Z

    .line 78
    .line 79
    if-eqz v0, :cond_5e

    .line 80
    .line 81
    invoke-virtual {v1}, Landroid/graphics/Paint;->getShader()Landroid/graphics/Shader;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    if-eqz v0, :cond_5e

    .line 86
    .line 87
    iget-object v2, p0, Lam/l;->V:Landroid/graphics/Matrix;

    .line 88
    .line 89
    invoke-virtual {v0, v2}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 90
    .line 91
    .line 92
    const/4 v0, 0x0

    .line 93
    iput-boolean v0, p0, Lam/l;->x:Z

    .line 94
    .line 95
    :cond_5e
    iget-boolean v0, p0, Lam/l;->X:Z

    .line 96
    .line 97
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    iget-object v2, p0, Lam/l;->U:Landroid/graphics/Matrix;

    .line 105
    .line 106
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    .line 107
    .line 108
    .line 109
    iget-object v2, p0, Lam/i;->e0:Landroid/graphics/RectF;

    .line 110
    .line 111
    iget-object v3, p0, Lam/l;->w:Landroid/graphics/Path;

    .line 112
    .line 113
    if-eqz v2, :cond_82

    .line 114
    .line 115
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    iget-object v4, p0, Lam/i;->e0:Landroid/graphics/RectF;

    .line 120
    .line 121
    invoke-virtual {p1, v4}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    .line 122
    .line 123
    .line 124
    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 128
    .line 129
    .line 130
    goto :goto_85

    .line 131
    :cond_82
    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 132
    .line 133
    .line 134
    :goto_85
    iget v2, p0, Lam/l;->v:F

    .line 135
    .line 136
    const/4 v3, 0x0

    .line 137
    cmpl-float v3, v2, v3

    .line 138
    .line 139
    if-lez v3, :cond_a3

    .line 140
    .line 141
    iget-object v3, p0, Lam/i;->b0:Landroid/graphics/Paint;

    .line 142
    .line 143
    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 144
    .line 145
    .line 146
    iget v2, p0, Lam/l;->y:I

    .line 147
    .line 148
    invoke-virtual {v1}, Landroid/graphics/Paint;->getAlpha()I

    .line 149
    .line 150
    .line 151
    move-result v1

    .line 152
    invoke-static {v2, v1}, Lio/sentry/config/a;->K(II)I

    .line 153
    .line 154
    .line 155
    move-result v1

    .line 156
    invoke-virtual {v3, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 157
    .line 158
    .line 159
    iget-object v1, p0, Lam/l;->J:Landroid/graphics/Path;

    .line 160
    .line 161
    invoke-virtual {p1, v1, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 162
    .line 163
    .line 164
    :cond_a3
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 165
    .line 166
    .line 167
    invoke-static {}, Lmn/a;->H()V

    .line 168
    .line 169
    .line 170
    return-void
.end method

.method public final m()V
    .registers 1

    .line 1
    return-void
.end method

.method public final setAlpha(I)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, Lam/l;->setAlpha(I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lam/i;->a0:Landroid/graphics/Paint;

    .line 5
    .line 6
    invoke-virtual {v0}, Landroid/graphics/Paint;->getAlpha()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eq p1, v1, :cond_14

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    invoke-super {p0, p1}, Lam/l;->setAlpha(I)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Lam/l;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lam/i;->a0:Landroid/graphics/Paint;

    .line 5
    .line 6
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 7
    .line 8
    .line 9
    return-void
.end method
