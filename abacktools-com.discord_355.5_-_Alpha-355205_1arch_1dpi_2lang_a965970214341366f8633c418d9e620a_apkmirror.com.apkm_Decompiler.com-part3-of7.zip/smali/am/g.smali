###### Class am.g (am.g)
.class public final Lam/g;
.super Lam/f;
.source "SourceFile"


# instance fields
.field public final J:Landroid/graphics/RectF;

.field public final v:Landroid/graphics/Matrix;

.field public final w:I

.field public final x:I

.field public final y:Landroid/graphics/Matrix;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/BitmapDrawable;II)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Lam/f;-><init>(Landroid/graphics/drawable/Drawable;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, Landroid/graphics/Matrix;

    .line 5
    .line 6
    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lam/g;->v:Landroid/graphics/Matrix;

    .line 10
    .line 11
    rem-int/lit8 p1, p2, 0x5a

    .line 12
    .line 13
    sub-int/2addr p2, p1

    .line 14
    iput p2, p0, Lam/g;->w:I

    .line 15
    .line 16
    if-ltz p3, :cond_16

    .line 17
    .line 18
    const/16 p1, 0x8

    .line 19
    .line 20
    if-gt p3, p1, :cond_16

    .line 21
    .line 22
    goto :goto_17

    .line 23
    :cond_16
    const/4 p3, 0x0

    .line 24
    :goto_17
    iput p3, p0, Lam/g;->x:I

    .line 25
    .line 26
    new-instance p1, Landroid/graphics/Matrix;

    .line 27
    .line 28
    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, Lam/g;->y:Landroid/graphics/Matrix;

    .line 32
    .line 33
    new-instance p1, Landroid/graphics/RectF;

    .line 34
    .line 35
    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object p1, p0, Lam/g;->J:Landroid/graphics/RectF;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .registers 4

    .line 1
    const-string v0, "canvas"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lam/g;->w:I

    .line 7
    .line 8
    if-gtz v0, :cond_14

    .line 9
    .line 10
    iget v0, p0, Lam/g;->x:I

    .line 11
    .line 12
    if-eqz v0, :cond_10

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    if-ne v0, v1, :cond_14

    .line 16
    .line 17
    :cond_10
    invoke-super {p0, p1}, Lam/f;->draw(Landroid/graphics/Canvas;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    iget-object v1, p0, Lam/g;->v:Landroid/graphics/Matrix;

    .line 26
    .line 27
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    .line 28
    .line 29
    .line 30
    invoke-super {p0, p1}, Lam/f;->draw(Landroid/graphics/Canvas;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final f(Landroid/graphics/Matrix;)V
    .registers 4

    .line 1
    const-string v0, "transform"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lam/f;->t(Landroid/graphics/Matrix;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lam/g;->v:Landroid/graphics/Matrix;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/graphics/Matrix;->isIdentity()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_13

    .line 16
    .line 17
    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->preConcat(Landroid/graphics/Matrix;)Z

    .line 18
    .line 19
    .line 20
    :cond_13
    return-void
.end method

.method public final getIntrinsicHeight()I
    .registers 3

    .line 1
    const/4 v0, 0x5

    .line 2
    iget v1, p0, Lam/g;->x:I

    .line 3
    .line 4
    if-eq v1, v0, :cond_14

    .line 5
    .line 6
    const/4 v0, 0x7

    .line 7
    if-eq v1, v0, :cond_14

    .line 8
    .line 9
    iget v0, p0, Lam/g;->w:I

    .line 10
    .line 11
    rem-int/lit16 v0, v0, 0xb4

    .line 12
    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    goto :goto_14

    .line 16
    :cond_f
    invoke-super {p0}, Lam/f;->getIntrinsicHeight()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0

    .line 21
    :cond_14
    :goto_14
    invoke-super {p0}, Lam/f;->getIntrinsicWidth()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    return v0
.end method

.method public final getIntrinsicWidth()I
    .registers 3

    .line 1
    const/4 v0, 0x5

    .line 2
    iget v1, p0, Lam/g;->x:I

    .line 3
    .line 4
    if-eq v1, v0, :cond_14

    .line 5
    .line 6
    const/4 v0, 0x7

    .line 7
    if-eq v1, v0, :cond_14

    .line 8
    .line 9
    iget v0, p0, Lam/g;->w:I

    .line 10
    .line 11
    rem-int/lit16 v0, v0, 0xb4

    .line 12
    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    goto :goto_14

    .line 16
    :cond_f
    invoke-super {p0}, Lam/f;->getIntrinsicWidth()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0

    .line 21
    :cond_14
    :goto_14
    invoke-super {p0}, Lam/f;->getIntrinsicHeight()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    return v0
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .registers 10

    .line 1
    const-string v0, "bounds"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lam/f;->d:Landroid/graphics/drawable/Drawable;

    .line 7
    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    iget v1, p0, Lam/g;->x:I

    .line 12
    .line 13
    iget v2, p0, Lam/g;->w:I

    .line 14
    .line 15
    if-gtz v2, :cond_1a

    .line 16
    .line 17
    if-eqz v1, :cond_16

    .line 18
    .line 19
    const/4 v3, 0x1

    .line 20
    if-eq v1, v3, :cond_16

    .line 21
    .line 22
    goto :goto_1a

    .line 23
    :cond_16
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_1a
    :goto_1a
    const/4 v3, 0x2

    .line 28
    const/high16 v4, 0x3f800000    # 1.0f

    .line 29
    .line 30
    const/high16 v5, -0x40800000    # -1.0f

    .line 31
    .line 32
    iget-object v6, p0, Lam/g;->v:Landroid/graphics/Matrix;

    .line 33
    .line 34
    if-eq v1, v3, :cond_63

    .line 35
    .line 36
    const/4 v3, 0x7

    .line 37
    const/high16 v7, 0x43870000    # 270.0f

    .line 38
    .line 39
    if-eq v1, v3, :cond_52

    .line 40
    .line 41
    const/4 v3, 0x4

    .line 42
    if-eq v1, v3, :cond_4e

    .line 43
    .line 44
    const/4 v3, 0x5

    .line 45
    if-eq v1, v3, :cond_3d

    .line 46
    .line 47
    int-to-float v1, v2

    .line 48
    invoke-virtual {p1}, Landroid/graphics/Rect;->centerX()I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    int-to-float v2, v2

    .line 53
    invoke-virtual {p1}, Landroid/graphics/Rect;->centerY()I

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    int-to-float v3, v3

    .line 58
    invoke-virtual {v6, v1, v2, v3}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 59
    .line 60
    .line 61
    goto :goto_66

    .line 62
    :cond_3d
    invoke-virtual {p1}, Landroid/graphics/Rect;->centerX()I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    int-to-float v1, v1

    .line 67
    invoke-virtual {p1}, Landroid/graphics/Rect;->centerY()I

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    int-to-float v2, v2

    .line 72
    invoke-virtual {v6, v7, v1, v2}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v6, v4, v5}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 76
    .line 77
    .line 78
    goto :goto_66

    .line 79
    :cond_4e
    invoke-virtual {v6, v4, v5}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 80
    .line 81
    .line 82
    goto :goto_66

    .line 83
    :cond_52
    invoke-virtual {p1}, Landroid/graphics/Rect;->centerX()I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    int-to-float v1, v1

    .line 88
    invoke-virtual {p1}, Landroid/graphics/Rect;->centerY()I

    .line 89
    .line 90
    .line 91
    move-result v2

    .line 92
    int-to-float v2, v2

    .line 93
    invoke-virtual {v6, v7, v1, v2}, Landroid/graphics/Matrix;->setRotate(FFF)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v6, v5, v4}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 97
    .line 98
    .line 99
    goto :goto_66

    .line 100
    :cond_63
    invoke-virtual {v6, v5, v4}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 101
    .line 102
    .line 103
    :goto_66
    iget-object v1, p0, Lam/g;->y:Landroid/graphics/Matrix;

    .line 104
    .line 105
    invoke-virtual {v1}, Landroid/graphics/Matrix;->reset()V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v6, v1}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    .line 109
    .line 110
    .line 111
    iget-object v2, p0, Lam/g;->J:Landroid/graphics/RectF;

    .line 112
    .line 113
    invoke-virtual {v2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v1, v2}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    .line 117
    .line 118
    .line 119
    iget p1, v2, Landroid/graphics/RectF;->left:F

    .line 120
    .line 121
    float-to-int p1, p1

    .line 122
    iget v1, v2, Landroid/graphics/RectF;->top:F

    .line 123
    .line 124
    float-to-int v1, v1

    .line 125
    iget v3, v2, Landroid/graphics/RectF;->right:F

    .line 126
    .line 127
    float-to-int v3, v3

    .line 128
    iget v2, v2, Landroid/graphics/RectF;->bottom:F

    .line 129
    .line 130
    float-to-int v2, v2

    .line 131
    invoke-virtual {v0, p1, v1, v3, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 132
    .line 133
    .line 134
    return-void
.end method
