###### Class am.a (am.a)
.class public final Lam/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lam/c;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lam/e;


# direct methods
.method public constructor <init>(Lam/e;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lam/a;->e:Lam/e;

    .line 5
    .line 6
    iput p2, p0, Lam/a;->d:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final k(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .registers 4

    .line 1
    iget-object v0, p0, Lam/a;->e:Lam/e;

    .line 2
    .line 3
    iget v1, p0, Lam/a;->d:I

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, Lam/e;->d(ILandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public final q()Landroid/graphics/drawable/Drawable;
    .registers 3

    .line 1
    iget-object v0, p0, Lam/a;->e:Lam/e;

    .line 2
    .line 3
    iget v1, p0, Lam/a;->d:I

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Lam/e;->c(I)Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method
