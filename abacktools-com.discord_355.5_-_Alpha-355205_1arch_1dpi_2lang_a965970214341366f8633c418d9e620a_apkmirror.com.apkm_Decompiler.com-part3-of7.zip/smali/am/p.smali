###### Class am.p (am.p)
.class public final Lam/p;
.super Lk7/f;
.source "SourceFile"


# static fields
.field public static final c:Lam/p;

.field public static final d:Lam/p;

.field public static final e:Lam/p;

.field public static final f:Lam/p;

.field public static final g:Lam/p;

.field public static final h:Lam/p;

.field public static final i:Lam/p;

.field public static final j:Lam/p;

.field public static final k:Lam/p;


# instance fields
.field public final synthetic b:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lam/p;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lam/p;->c:Lam/p;

    .line 8
    .line 9
    new-instance v0, Lam/p;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lam/p;->d:Lam/p;

    .line 16
    .line 17
    new-instance v0, Lam/p;

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 21
    .line 22
    .line 23
    sput-object v0, Lam/p;->e:Lam/p;

    .line 24
    .line 25
    new-instance v0, Lam/p;

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 29
    .line 30
    .line 31
    sput-object v0, Lam/p;->f:Lam/p;

    .line 32
    .line 33
    new-instance v0, Lam/p;

    .line 34
    .line 35
    const/4 v1, 0x4

    .line 36
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lam/p;->g:Lam/p;

    .line 40
    .line 41
    new-instance v0, Lam/p;

    .line 42
    .line 43
    const/4 v1, 0x5

    .line 44
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Lam/p;->h:Lam/p;

    .line 48
    .line 49
    new-instance v0, Lam/p;

    .line 50
    .line 51
    const/4 v1, 0x6

    .line 52
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 53
    .line 54
    .line 55
    sput-object v0, Lam/p;->i:Lam/p;

    .line 56
    .line 57
    new-instance v0, Lam/p;

    .line 58
    .line 59
    const/4 v1, 0x7

    .line 60
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 61
    .line 62
    .line 63
    sput-object v0, Lam/p;->j:Lam/p;

    .line 64
    .line 65
    new-instance v0, Lam/p;

    .line 66
    .line 67
    const/16 v1, 0x8

    .line 68
    .line 69
    invoke-direct {v0, v1}, Lam/p;-><init>(I)V

    .line 70
    .line 71
    .line 72
    sput-object v0, Lam/p;->k:Lam/p;

    .line 73
    .line 74
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lam/p;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Lam/p;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_20

    .line 4
    .line 5
    .line 6
    const-string v0, "focus_crop"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_8
    const-string v0, "fit_xy"

    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_b
    const-string v0, "fit_start"

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_e
    const-string v0, "fit_end"

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_11
    const-string v0, "fit_center"

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_14
    const-string v0, "fit_bottom_start"

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_17
    const-string v0, "center_inside"

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_1a
    const-string v0, "center_crop"

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1d
    const-string v0, "center"

    .line 31
    .line 32
    return-object v0

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_1d
        :pswitch_1a
        :pswitch_17
        :pswitch_14
        :pswitch_11
        :pswitch_e
        :pswitch_b
        :pswitch_8
    .end packed-switch
.end method

.method public final w(Landroid/graphics/Matrix;Landroid/graphics/Rect;IIFFFF)V
    .registers 12

    .line 1
    iget v0, p0, Lam/p;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_18c

    .line 4
    .line 5
    .line 6
    cmpl-float v0, p8, p7

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/high16 v2, 0x3f000000    # 0.5f

    .line 10
    .line 11
    if-lez v0, :cond_2d

    .line 12
    .line 13
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 14
    .line 15
    .line 16
    move-result p4

    .line 17
    int-to-float p4, p4

    .line 18
    mul-float/2addr p4, v2

    .line 19
    int-to-float p3, p3

    .line 20
    mul-float/2addr p3, p8

    .line 21
    mul-float/2addr p5, p3

    .line 22
    sub-float/2addr p4, p5

    .line 23
    iget p5, p2, Landroid/graphics/Rect;->left:I

    .line 24
    .line 25
    int-to-float p5, p5

    .line 26
    invoke-static {p4, v1}, Ljava/lang/Math;->min(FF)F

    .line 27
    .line 28
    .line 29
    move-result p4

    .line 30
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 31
    .line 32
    .line 33
    move-result p6

    .line 34
    int-to-float p6, p6

    .line 35
    sub-float/2addr p6, p3

    .line 36
    invoke-static {p4, p6}, Ljava/lang/Math;->max(FF)F

    .line 37
    .line 38
    .line 39
    move-result p3

    .line 40
    add-float/2addr p3, p5

    .line 41
    iget p2, p2, Landroid/graphics/Rect;->top:I

    .line 42
    .line 43
    int-to-float p2, p2

    .line 44
    move p7, p8

    .line 45
    goto :goto_4c

    .line 46
    :cond_2d
    iget p3, p2, Landroid/graphics/Rect;->left:I

    .line 47
    .line 48
    int-to-float p3, p3

    .line 49
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 50
    .line 51
    .line 52
    move-result p5

    .line 53
    int-to-float p5, p5

    .line 54
    mul-float/2addr p5, v2

    .line 55
    int-to-float p4, p4

    .line 56
    mul-float/2addr p4, p7

    .line 57
    mul-float/2addr p6, p4

    .line 58
    sub-float/2addr p5, p6

    .line 59
    iget p6, p2, Landroid/graphics/Rect;->top:I

    .line 60
    .line 61
    int-to-float p6, p6

    .line 62
    invoke-static {p5, v1}, Ljava/lang/Math;->min(FF)F

    .line 63
    .line 64
    .line 65
    move-result p5

    .line 66
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 67
    .line 68
    .line 69
    move-result p2

    .line 70
    int-to-float p2, p2

    .line 71
    sub-float/2addr p2, p4

    .line 72
    invoke-static {p5, p2}, Ljava/lang/Math;->max(FF)F

    .line 73
    .line 74
    .line 75
    move-result p2

    .line 76
    add-float/2addr p2, p6

    .line 77
    :goto_4c
    invoke-virtual {p1, p7, p7}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 78
    .line 79
    .line 80
    add-float/2addr p3, v2

    .line 81
    float-to-int p3, p3

    .line 82
    int-to-float p3, p3

    .line 83
    add-float/2addr p2, v2

    .line 84
    float-to-int p2, p2

    .line 85
    int-to-float p2, p2

    .line 86
    invoke-virtual {p1, p3, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    :pswitch_59
    iget p3, p2, Landroid/graphics/Rect;->left:I

    .line 91
    .line 92
    int-to-float p3, p3

    .line 93
    iget p2, p2, Landroid/graphics/Rect;->top:I

    .line 94
    .line 95
    int-to-float p2, p2

    .line 96
    invoke-virtual {p1, p7, p8}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 97
    .line 98
    .line 99
    const/high16 p4, 0x3f000000    # 0.5f

    .line 100
    .line 101
    add-float/2addr p3, p4

    .line 102
    float-to-int p3, p3

    .line 103
    int-to-float p3, p3

    .line 104
    add-float/2addr p2, p4

    .line 105
    float-to-int p2, p2

    .line 106
    int-to-float p2, p2

    .line 107
    invoke-virtual {p1, p3, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_6e
    invoke-static {p7, p8}, Ljava/lang/Math;->min(FF)F

    .line 112
    .line 113
    .line 114
    move-result p3

    .line 115
    iget p4, p2, Landroid/graphics/Rect;->left:I

    .line 116
    .line 117
    int-to-float p4, p4

    .line 118
    iget p2, p2, Landroid/graphics/Rect;->top:I

    .line 119
    .line 120
    int-to-float p2, p2

    .line 121
    invoke-virtual {p1, p3, p3}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 122
    .line 123
    .line 124
    const/high16 p3, 0x3f000000    # 0.5f

    .line 125
    .line 126
    add-float/2addr p4, p3

    .line 127
    float-to-int p4, p4

    .line 128
    int-to-float p4, p4

    .line 129
    add-float/2addr p2, p3

    .line 130
    float-to-int p2, p2

    .line 131
    int-to-float p2, p2

    .line 132
    invoke-virtual {p1, p4, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 133
    .line 134
    .line 135
    return-void

    .line 136
    :pswitch_87
    invoke-static {p7, p8}, Ljava/lang/Math;->min(FF)F

    .line 137
    .line 138
    .line 139
    move-result p5

    .line 140
    iget p6, p2, Landroid/graphics/Rect;->left:I

    .line 141
    .line 142
    int-to-float p6, p6

    .line 143
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 144
    .line 145
    .line 146
    move-result p7

    .line 147
    int-to-float p7, p7

    .line 148
    int-to-float p3, p3

    .line 149
    mul-float/2addr p3, p5

    .line 150
    sub-float/2addr p7, p3

    .line 151
    add-float/2addr p7, p6

    .line 152
    iget p3, p2, Landroid/graphics/Rect;->top:I

    .line 153
    .line 154
    int-to-float p3, p3

    .line 155
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 156
    .line 157
    .line 158
    move-result p2

    .line 159
    int-to-float p2, p2

    .line 160
    int-to-float p4, p4

    .line 161
    mul-float/2addr p4, p5

    .line 162
    sub-float/2addr p2, p4

    .line 163
    add-float/2addr p2, p3

    .line 164
    invoke-virtual {p1, p5, p5}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 165
    .line 166
    .line 167
    const/high16 p3, 0x3f000000    # 0.5f

    .line 168
    .line 169
    add-float/2addr p7, p3

    .line 170
    float-to-int p4, p7

    .line 171
    int-to-float p4, p4

    .line 172
    add-float/2addr p2, p3

    .line 173
    float-to-int p2, p2

    .line 174
    int-to-float p2, p2

    .line 175
    invoke-virtual {p1, p4, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :pswitch_b2
    invoke-static {p7, p8}, Ljava/lang/Math;->min(FF)F

    .line 180
    .line 181
    .line 182
    move-result p5

    .line 183
    iget p6, p2, Landroid/graphics/Rect;->left:I

    .line 184
    .line 185
    int-to-float p6, p6

    .line 186
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 187
    .line 188
    .line 189
    move-result p7

    .line 190
    int-to-float p7, p7

    .line 191
    int-to-float p3, p3

    .line 192
    mul-float/2addr p3, p5

    .line 193
    sub-float/2addr p7, p3

    .line 194
    const/high16 p3, 0x3f000000    # 0.5f

    .line 195
    .line 196
    mul-float/2addr p7, p3

    .line 197
    add-float/2addr p7, p6

    .line 198
    iget p6, p2, Landroid/graphics/Rect;->top:I

    .line 199
    .line 200
    int-to-float p6, p6

    .line 201
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 202
    .line 203
    .line 204
    move-result p2

    .line 205
    int-to-float p2, p2

    .line 206
    int-to-float p4, p4

    .line 207
    mul-float/2addr p4, p5

    .line 208
    sub-float/2addr p2, p4

    .line 209
    mul-float/2addr p2, p3

    .line 210
    add-float/2addr p2, p6

    .line 211
    invoke-virtual {p1, p5, p5}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 212
    .line 213
    .line 214
    add-float/2addr p7, p3

    .line 215
    float-to-int p4, p7

    .line 216
    int-to-float p4, p4

    .line 217
    add-float/2addr p2, p3

    .line 218
    float-to-int p2, p2

    .line 219
    int-to-float p2, p2

    .line 220
    invoke-virtual {p1, p4, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 221
    .line 222
    .line 223
    return-void

    .line 224
    :pswitch_df
    invoke-static {p7, p8}, Ljava/lang/Math;->min(FF)F

    .line 225
    .line 226
    .line 227
    move-result p3

    .line 228
    iget p5, p2, Landroid/graphics/Rect;->left:I

    .line 229
    .line 230
    int-to-float p5, p5

    .line 231
    iget p6, p2, Landroid/graphics/Rect;->top:I

    .line 232
    .line 233
    int-to-float p6, p6

    .line 234
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 235
    .line 236
    .line 237
    move-result p2

    .line 238
    int-to-float p2, p2

    .line 239
    int-to-float p4, p4

    .line 240
    mul-float/2addr p4, p3

    .line 241
    sub-float/2addr p2, p4

    .line 242
    add-float/2addr p2, p6

    .line 243
    invoke-virtual {p1, p3, p3}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 244
    .line 245
    .line 246
    const/high16 p3, 0x3f000000    # 0.5f

    .line 247
    .line 248
    add-float/2addr p5, p3

    .line 249
    float-to-int p4, p5

    .line 250
    int-to-float p4, p4

    .line 251
    add-float/2addr p2, p3

    .line 252
    float-to-int p2, p2

    .line 253
    int-to-float p2, p2

    .line 254
    invoke-virtual {p1, p4, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 255
    .line 256
    .line 257
    return-void

    .line 258
    :pswitch_101
    invoke-static {p7, p8}, Ljava/lang/Math;->min(FF)F

    .line 259
    .line 260
    .line 261
    move-result p5

    .line 262
    const/high16 p6, 0x3f800000    # 1.0f

    .line 263
    .line 264
    invoke-static {p5, p6}, Ljava/lang/Math;->min(FF)F

    .line 265
    .line 266
    .line 267
    move-result p5

    .line 268
    iget p6, p2, Landroid/graphics/Rect;->left:I

    .line 269
    .line 270
    int-to-float p6, p6

    .line 271
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 272
    .line 273
    .line 274
    move-result p7

    .line 275
    int-to-float p7, p7

    .line 276
    int-to-float p3, p3

    .line 277
    mul-float/2addr p3, p5

    .line 278
    sub-float/2addr p7, p3

    .line 279
    const/high16 p3, 0x3f000000    # 0.5f

    .line 280
    .line 281
    mul-float/2addr p7, p3

    .line 282
    add-float/2addr p7, p6

    .line 283
    iget p6, p2, Landroid/graphics/Rect;->top:I

    .line 284
    .line 285
    int-to-float p6, p6

    .line 286
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 287
    .line 288
    .line 289
    move-result p2

    .line 290
    int-to-float p2, p2

    .line 291
    int-to-float p4, p4

    .line 292
    mul-float/2addr p4, p5

    .line 293
    sub-float/2addr p2, p4

    .line 294
    mul-float/2addr p2, p3

    .line 295
    add-float/2addr p2, p6

    .line 296
    invoke-virtual {p1, p5, p5}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 297
    .line 298
    .line 299
    add-float/2addr p7, p3

    .line 300
    float-to-int p4, p7

    .line 301
    int-to-float p4, p4

    .line 302
    add-float/2addr p2, p3

    .line 303
    float-to-int p2, p2

    .line 304
    int-to-float p2, p2

    .line 305
    invoke-virtual {p1, p4, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 306
    .line 307
    .line 308
    return-void

    .line 309
    :pswitch_134
    cmpl-float p5, p8, p7

    .line 310
    .line 311
    const/high16 p6, 0x3f000000    # 0.5f

    .line 312
    .line 313
    if-lez p5, :cond_14c

    .line 314
    .line 315
    iget p4, p2, Landroid/graphics/Rect;->left:I

    .line 316
    .line 317
    int-to-float p4, p4

    .line 318
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 319
    .line 320
    .line 321
    move-result p5

    .line 322
    int-to-float p5, p5

    .line 323
    int-to-float p3, p3

    .line 324
    mul-float/2addr p3, p8

    .line 325
    sub-float/2addr p5, p3

    .line 326
    mul-float/2addr p5, p6

    .line 327
    add-float/2addr p5, p4

    .line 328
    iget p2, p2, Landroid/graphics/Rect;->top:I

    .line 329
    .line 330
    int-to-float p2, p2

    .line 331
    move p7, p8

    .line 332
    goto :goto_15c

    .line 333
    :cond_14c
    iget p3, p2, Landroid/graphics/Rect;->left:I

    .line 334
    .line 335
    int-to-float p5, p3

    .line 336
    iget p3, p2, Landroid/graphics/Rect;->top:I

    .line 337
    .line 338
    int-to-float p3, p3

    .line 339
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 340
    .line 341
    .line 342
    move-result p2

    .line 343
    int-to-float p2, p2

    .line 344
    int-to-float p4, p4

    .line 345
    mul-float/2addr p4, p7

    .line 346
    sub-float/2addr p2, p4

    .line 347
    mul-float/2addr p2, p6

    .line 348
    add-float/2addr p2, p3

    .line 349
    :goto_15c
    invoke-virtual {p1, p7, p7}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 350
    .line 351
    .line 352
    add-float/2addr p5, p6

    .line 353
    float-to-int p3, p5

    .line 354
    int-to-float p3, p3

    .line 355
    add-float/2addr p2, p6

    .line 356
    float-to-int p2, p2

    .line 357
    int-to-float p2, p2

    .line 358
    invoke-virtual {p1, p3, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 359
    .line 360
    .line 361
    return-void

    .line 362
    :pswitch_169
    iget p5, p2, Landroid/graphics/Rect;->left:I

    .line 363
    .line 364
    int-to-float p5, p5

    .line 365
    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    .line 366
    .line 367
    .line 368
    move-result p6

    .line 369
    sub-int/2addr p6, p3

    .line 370
    int-to-float p3, p6

    .line 371
    const/high16 p6, 0x3f000000    # 0.5f

    .line 372
    .line 373
    mul-float/2addr p3, p6

    .line 374
    add-float/2addr p3, p5

    .line 375
    iget p5, p2, Landroid/graphics/Rect;->top:I

    .line 376
    .line 377
    int-to-float p5, p5

    .line 378
    invoke-virtual {p2}, Landroid/graphics/Rect;->height()I

    .line 379
    .line 380
    .line 381
    move-result p2

    .line 382
    sub-int/2addr p2, p4

    .line 383
    int-to-float p2, p2

    .line 384
    mul-float/2addr p2, p6

    .line 385
    add-float/2addr p2, p5

    .line 386
    add-float/2addr p3, p6

    .line 387
    float-to-int p3, p3

    .line 388
    int-to-float p3, p3

    .line 389
    add-float/2addr p2, p6

    .line 390
    float-to-int p2, p2

    .line 391
    int-to-float p2, p2

    .line 392
    invoke-virtual {p1, p3, p2}, Landroid/graphics/Matrix;->setTranslate(FF)V

    .line 393
    .line 394
    .line 395
    return-void

    .line 396
    nop

    .line 397
    :pswitch_data_18c
    .packed-switch 0x0
        :pswitch_169
        :pswitch_134
        :pswitch_101
        :pswitch_df
        :pswitch_b2
        :pswitch_87
        :pswitch_6e
        :pswitch_59
    .end packed-switch
.end method
