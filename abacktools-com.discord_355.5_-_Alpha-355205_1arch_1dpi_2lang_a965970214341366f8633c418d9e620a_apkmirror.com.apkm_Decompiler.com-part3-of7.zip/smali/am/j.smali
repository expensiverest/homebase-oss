###### Class am.j (am.j)
.class public final Lam/j;
.super Landroid/graphics/drawable/Drawable;
.source "SourceFile"

# interfaces
.implements Lam/h;


# instance fields
.field public J:Z

.field public final K:Landroid/graphics/Path;

.field public final L:Landroid/graphics/Path;

.field public final M:I

.field public final N:Landroid/graphics/RectF;

.field public O:I

.field public final d:[F

.field public final e:[F

.field public final i:Landroid/graphics/Paint;

.field public v:Z

.field public w:F

.field public x:F

.field public y:I


# direct methods
.method public constructor <init>(I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x8

    .line 5
    .line 6
    new-array v1, v0, [F

    .line 7
    .line 8
    iput-object v1, p0, Lam/j;->d:[F

    .line 9
    .line 10
    new-array v0, v0, [F

    .line 11
    .line 12
    iput-object v0, p0, Lam/j;->e:[F

    .line 13
    .line 14
    new-instance v0, Landroid/graphics/Paint;

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 18
    .line 19
    .line 20
    iput-object v0, p0, Lam/j;->i:Landroid/graphics/Paint;

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    iput-boolean v0, p0, Lam/j;->v:Z

    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    iput v1, p0, Lam/j;->w:F

    .line 27
    .line 28
    iput v1, p0, Lam/j;->x:F

    .line 29
    .line 30
    iput v0, p0, Lam/j;->y:I

    .line 31
    .line 32
    iput-boolean v0, p0, Lam/j;->J:Z

    .line 33
    .line 34
    new-instance v1, Landroid/graphics/Path;

    .line 35
    .line 36
    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    .line 37
    .line 38
    .line 39
    iput-object v1, p0, Lam/j;->K:Landroid/graphics/Path;

    .line 40
    .line 41
    new-instance v1, Landroid/graphics/Path;

    .line 42
    .line 43
    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    .line 44
    .line 45
    .line 46
    iput-object v1, p0, Lam/j;->L:Landroid/graphics/Path;

    .line 47
    .line 48
    iput v0, p0, Lam/j;->M:I

    .line 49
    .line 50
    new-instance v0, Landroid/graphics/RectF;

    .line 51
    .line 52
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 53
    .line 54
    .line 55
    iput-object v0, p0, Lam/j;->N:Landroid/graphics/RectF;

    .line 56
    .line 57
    const/16 v0, 0xff

    .line 58
    .line 59
    iput v0, p0, Lam/j;->O:I

    .line 60
    .line 61
    iget v0, p0, Lam/j;->M:I

    .line 62
    .line 63
    if-eq v0, p1, :cond_45

    .line 64
    .line 65
    iput p1, p0, Lam/j;->M:I

    .line 66
    .line 67
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 68
    .line 69
    .line 70
    :cond_45
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 10

    .line 1
    iget-object v0, p0, Lam/j;->K:Landroid/graphics/Path;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lam/j;->L:Landroid/graphics/Path;

    .line 7
    .line 8
    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    iget-object v3, p0, Lam/j;->N:Landroid/graphics/RectF;

    .line 16
    .line 17
    invoke-virtual {v3, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 18
    .line 19
    .line 20
    iget v2, p0, Lam/j;->w:F

    .line 21
    .line 22
    const/high16 v4, 0x40000000    # 2.0f

    .line 23
    .line 24
    div-float/2addr v2, v4

    .line 25
    invoke-virtual {v3, v2, v2}, Landroid/graphics/RectF;->inset(FF)V

    .line 26
    .line 27
    .line 28
    iget-boolean v2, p0, Lam/j;->v:Z

    .line 29
    .line 30
    iget-object v5, p0, Lam/j;->d:[F

    .line 31
    .line 32
    if-eqz v2, :cond_3c

    .line 33
    .line 34
    invoke-virtual {v3}, Landroid/graphics/RectF;->width()F

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    div-float/2addr v2, v4

    .line 47
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    .line 48
    .line 49
    .line 50
    move-result v6

    .line 51
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    .line 52
    .line 53
    .line 54
    move-result v7

    .line 55
    sget-object v8, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 56
    .line 57
    invoke-virtual {v1, v6, v7, v2, v8}, Landroid/graphics/Path;->addCircle(FFFLandroid/graphics/Path$Direction;)V

    .line 58
    .line 59
    .line 60
    goto :goto_55

    .line 61
    :cond_3c
    const/4 v2, 0x0

    .line 62
    :goto_3d
    iget-object v6, p0, Lam/j;->e:[F

    .line 63
    .line 64
    array-length v7, v6

    .line 65
    if-ge v2, v7, :cond_50

    .line 66
    .line 67
    aget v7, v5, v2

    .line 68
    .line 69
    iget v8, p0, Lam/j;->x:F

    .line 70
    .line 71
    add-float/2addr v7, v8

    .line 72
    iget v8, p0, Lam/j;->w:F

    .line 73
    .line 74
    div-float/2addr v8, v4

    .line 75
    sub-float/2addr v7, v8

    .line 76
    aput v7, v6, v2

    .line 77
    .line 78
    add-int/lit8 v2, v2, 0x1

    .line 79
    .line 80
    goto :goto_3d

    .line 81
    :cond_50
    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 82
    .line 83
    invoke-virtual {v1, v3, v6, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    .line 84
    .line 85
    .line 86
    :goto_55
    iget v1, p0, Lam/j;->w:F

    .line 87
    .line 88
    neg-float v1, v1

    .line 89
    div-float/2addr v1, v4

    .line 90
    invoke-virtual {v3, v1, v1}, Landroid/graphics/RectF;->inset(FF)V

    .line 91
    .line 92
    .line 93
    iget v1, p0, Lam/j;->x:F

    .line 94
    .line 95
    const/4 v2, 0x0

    .line 96
    add-float/2addr v1, v2

    .line 97
    invoke-virtual {v3, v1, v1}, Landroid/graphics/RectF;->inset(FF)V

    .line 98
    .line 99
    .line 100
    iget-boolean v2, p0, Lam/j;->v:Z

    .line 101
    .line 102
    if-eqz v2, :cond_82

    .line 103
    .line 104
    invoke-virtual {v3}, Landroid/graphics/RectF;->width()F

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    .line 109
    .line 110
    .line 111
    move-result v5

    .line 112
    invoke-static {v2, v5}, Ljava/lang/Math;->min(FF)F

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    div-float/2addr v2, v4

    .line 117
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    .line 118
    .line 119
    .line 120
    move-result v4

    .line 121
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    .line 122
    .line 123
    .line 124
    move-result v5

    .line 125
    sget-object v6, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 126
    .line 127
    invoke-virtual {v0, v4, v5, v2, v6}, Landroid/graphics/Path;->addCircle(FFFLandroid/graphics/Path$Direction;)V

    .line 128
    .line 129
    .line 130
    goto :goto_87

    .line 131
    :cond_82
    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    .line 132
    .line 133
    invoke-virtual {v0, v3, v5, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    .line 134
    .line 135
    .line 136
    :goto_87
    neg-float v0, v1

    .line 137
    invoke-virtual {v3, v0, v0}, Landroid/graphics/RectF;->inset(FF)V

    .line 138
    .line 139
    .line 140
    return-void
.end method

.method public final b(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lam/j;->v:Z

    .line 2
    .line 3
    invoke-virtual {p0}, Lam/j;->a()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final c()V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lam/j;->d:[F

    .line 3
    .line 4
    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([FF)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lam/j;->a()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .registers 5

    .line 1
    iget v0, p0, Lam/j;->M:I

    .line 2
    .line 3
    iget v1, p0, Lam/j;->O:I

    .line 4
    .line 5
    invoke-static {v0, v1}, Lio/sentry/config/a;->K(II)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iget-object v1, p0, Lam/j;->i:Landroid/graphics/Paint;

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 12
    .line 13
    .line 14
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 17
    .line 18
    .line 19
    iget-boolean v0, p0, Lam/j;->J:Z

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lam/j;->K:Landroid/graphics/Path;

    .line 25
    .line 26
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 27
    .line 28
    .line 29
    iget v0, p0, Lam/j;->w:F

    .line 30
    .line 31
    const/4 v2, 0x0

    .line 32
    cmpl-float v0, v0, v2

    .line 33
    .line 34
    if-eqz v0, :cond_3d

    .line 35
    .line 36
    iget v0, p0, Lam/j;->y:I

    .line 37
    .line 38
    iget v2, p0, Lam/j;->O:I

    .line 39
    .line 40
    invoke-static {v0, v2}, Lio/sentry/config/a;->K(II)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 45
    .line 46
    .line 47
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 48
    .line 49
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 50
    .line 51
    .line 52
    iget v0, p0, Lam/j;->w:F

    .line 53
    .line 54
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 55
    .line 56
    .line 57
    iget-object v0, p0, Lam/j;->L:Landroid/graphics/Path;

    .line 58
    .line 59
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 60
    .line 61
    .line 62
    :cond_3d
    return-void
.end method

.method public final e(FI)V
    .registers 4

    .line 1
    iget v0, p0, Lam/j;->y:I

    .line 2
    .line 3
    if-eq v0, p2, :cond_9

    .line 4
    .line 5
    iput p2, p0, Lam/j;->y:I

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget p2, p0, Lam/j;->w:F

    .line 11
    .line 12
    cmpl-float p2, p2, p1

    .line 13
    .line 14
    if-eqz p2, :cond_17

    .line 15
    .line 16
    iput p1, p0, Lam/j;->w:F

    .line 17
    .line 18
    invoke-virtual {p0}, Lam/j;->a()V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 22
    .line 23
    .line 24
    :cond_17
    return-void
.end method

.method public final g(Z)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lam/j;->J:Z

    .line 2
    .line 3
    if-eq v0, p1, :cond_9

    .line 4
    .line 5
    iput-boolean p1, p0, Lam/j;->J:Z

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public final getAlpha()I
    .registers 2

    .line 1
    iget v0, p0, Lam/j;->O:I

    .line 2
    .line 3
    return v0
.end method

.method public final getOpacity()I
    .registers 3

    .line 1
    iget v0, p0, Lam/j;->M:I

    .line 2
    .line 3
    iget v1, p0, Lam/j;->O:I

    .line 4
    .line 5
    invoke-static {v0, v1}, Lio/sentry/config/a;->K(II)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    ushr-int/lit8 v0, v0, 0x18

    .line 10
    .line 11
    if-eqz v0, :cond_14

    .line 12
    .line 13
    const/16 v1, 0xff

    .line 14
    .line 15
    if-eq v0, v1, :cond_12

    .line 16
    .line 17
    const/4 v0, -0x3

    .line 18
    return v0

    .line 19
    :cond_12
    const/4 v0, -0x1

    .line 20
    return v0

    .line 21
    :cond_14
    const/4 v0, -0x2

    .line 22
    return v0
.end method

.method public final m()V
    .registers 1

    .line 1
    return-void
.end method

.method public final o(F)V
    .registers 3

    .line 1
    iget v0, p0, Lam/j;->x:F

    .line 2
    .line 3
    cmpl-float v0, v0, p1

    .line 4
    .line 5
    if-eqz v0, :cond_e

    .line 6
    .line 7
    iput p1, p0, Lam/j;->x:F

    .line 8
    .line 9
    invoke-virtual {p0}, Lam/j;->a()V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onBoundsChange(Landroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lam/j;->a()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final r()V
    .registers 1

    .line 1
    return-void
.end method

.method public final s([F)V
    .registers 7

    .line 1
    iget-object v0, p0, Lam/j;->d:[F

    .line 2
    .line 3
    if-nez p1, :cond_9

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    invoke-static {v0, p1}, Ljava/util/Arrays;->fill([FF)V

    .line 7
    .line 8
    .line 9
    goto :goto_1a

    .line 10
    :cond_9
    array-length v1, p1

    .line 11
    const/16 v2, 0x8

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    if-ne v1, v2, :cond_11

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    goto :goto_12

    .line 18
    :cond_11
    move v1, v3

    .line 19
    :goto_12
    const-string v4, "radii should have exactly 8 values"

    .line 20
    .line 21
    invoke-static {v4, v1}, Lfl/j;->b(Ljava/lang/String;Z)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1, v3, v0, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 25
    .line 26
    .line 27
    :goto_1a
    invoke-virtual {p0}, Lam/j;->a()V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final setAlpha(I)V
    .registers 3

    .line 1
    iget v0, p0, Lam/j;->O:I

    .line 2
    .line 3
    if-eq p1, v0, :cond_9

    .line 4
    .line 5
    iput p1, p0, Lam/j;->O:I

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2

    .line 1
    return-void
.end method
