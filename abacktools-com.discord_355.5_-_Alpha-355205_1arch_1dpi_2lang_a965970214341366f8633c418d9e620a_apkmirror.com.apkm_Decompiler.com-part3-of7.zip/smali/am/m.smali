###### Class am.m (am.m)
.class public final Lam/m;
.super Lam/l;
.source "SourceFile"


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .registers 4

    .line 1
    const-string v0, "canvas"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lmn/a;->H()V

    .line 7
    .line 8
    .line 9
    iget-boolean v0, p0, Lam/l;->e:Z

    .line 10
    .line 11
    if-nez v0, :cond_1f

    .line 12
    .line 13
    iget-boolean v0, p0, Lam/l;->i:Z

    .line 14
    .line 15
    if-nez v0, :cond_1f

    .line 16
    .line 17
    iget v0, p0, Lam/l;->v:F

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    cmpl-float v0, v0, v1

    .line 21
    .line 22
    if-lez v0, :cond_18

    .line 23
    .line 24
    goto :goto_1f

    .line 25
    :cond_18
    invoke-super {p0, p1}, Lam/l;->draw(Landroid/graphics/Canvas;)V

    .line 26
    .line 27
    .line 28
    invoke-static {}, Lmn/a;->H()V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_1f
    :goto_1f
    invoke-virtual {p0}, Lam/l;->d()V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Lam/l;->a()V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lam/l;->w:Landroid/graphics/Path;

    .line 39
    .line 40
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    .line 41
    .line 42
    .line 43
    invoke-super {p0, p1}, Lam/l;->draw(Landroid/graphics/Canvas;)V

    .line 44
    .line 45
    .line 46
    invoke-static {}, Lmn/a;->H()V

    .line 47
    .line 48
    .line 49
    return-void
.end method
