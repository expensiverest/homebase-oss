###### Class a30.a (a30.a)
.class public abstract La30/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:[I

.field public static final b:[I


# direct methods
.method public static constructor <clinit>()V
    .registers 3

    .line 1
    const v0, 0x7f04063e

    .line 2
    .line 3
    .line 4
    const v1, 0x7f04063f

    .line 5
    .line 6
    .line 7
    const v2, 0x7f04063d

    .line 8
    .line 9
    .line 10
    filled-new-array {v2, v0, v1}, [I

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, La30/a;->a:[I

    .line 15
    .line 16
    const/16 v0, 0xd

    .line 17
    .line 18
    new-array v0, v0, [I

    .line 19
    .line 20
    fill-array-data v0, :array_1a

    .line 21
    .line 22
    .line 23
    sput-object v0, La30/a;->b:[I

    .line 24
    .line 25
    return-void

    .line 26
    nop

    .line 27
    :array_1a
    .array-data 4
        0x7f040640
        0x7f040641
        0x7f040642
        0x7f040643
        0x7f040644
        0x7f040645
        0x7f040646
        0x7f040647
        0x7f040648
        0x7f040649
        0x7f04064a
        0x7f04064b
        0x7f04064c
    .end array-data
.end method
