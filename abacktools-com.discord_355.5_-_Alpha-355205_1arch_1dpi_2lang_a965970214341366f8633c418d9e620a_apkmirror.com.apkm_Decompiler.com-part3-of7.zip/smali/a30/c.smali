###### Class a30.c (a30.c)
.class public final synthetic La30/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/core/view/u;


# virtual methods
.method public final f(Landroid/view/View;Landroidx/core/view/q2;)Landroidx/core/view/q2;
    .registers 7

    .line 1
    sget-object v0, Lcom/yalantis/ucrop/UCropActivity;->E0:Landroid/graphics/Bitmap$CompressFormat;

    .line 2
    .line 3
    const/16 v0, 0x207

    .line 4
    .line 5
    iget-object v1, p2, Landroidx/core/view/q2;->a:Landroidx/core/view/n2;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Landroidx/core/view/n2;->i(I)Li1/b;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget v1, v0, Li1/b;->a:I

    .line 12
    .line 13
    iget v2, v0, Li1/b;->b:I

    .line 14
    .line 15
    iget v0, v0, Li1/b;->c:I

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    invoke-virtual {p1, v1, v2, v0, v3}, Landroid/view/View;->setPaddingRelative(IIII)V

    .line 19
    .line 20
    .line 21
    return-object p2
.end method
