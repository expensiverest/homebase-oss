###### Class ac.c (ac.c)
.class public final Lac/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:I

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public final g:Ljava/lang/Object;

.field public h:Ljava/io/Serializable;

.field public i:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lac/c;->a:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    const-string v0, ""

    iput-object v0, p0, Lac/c;->d:Ljava/lang/Object;

    .line 15
    iput-object v0, p0, Lac/c;->e:Ljava/lang/Object;

    const/4 v1, -0x1

    .line 16
    iput v1, p0, Lac/c;->b:I

    .line 17
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lac/c;->g:Ljava/lang/Object;

    .line 18
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Lac/c;->a:I

    const-string v1, "context"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    new-instance v1, Lac/b;

    invoke-direct {v1, v0}, Lac/b;-><init>(I)V

    new-instance v0, Lac/b;

    const/4 v2, 0x1

    invoke-direct {v0, v2}, Lac/b;-><init>(I)V

    new-instance v2, Lac/b;

    const/4 v3, 0x2

    invoke-direct {v2, v3}, Lac/b;-><init>(I)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object v1, p0, Lac/c;->c:Ljava/lang/Object;

    .line 4
    iput-object v0, p0, Lac/c;->d:Ljava/lang/Object;

    .line 5
    iput-object v2, p0, Lac/c;->e:Ljava/lang/Object;

    .line 6
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const v0, 0x7f070377

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    iput p1, p0, Lac/c;->b:I

    .line 7
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 8
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 9
    iput-object p1, p0, Lac/c;->f:Ljava/lang/Object;

    .line 10
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    .line 11
    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 12
    iput-object p1, p0, Lac/c;->g:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()Lb80/z;
    .registers 14

    .line 1
    iget-object v0, p0, Lac/c;->c:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v2, v0

    .line 4
    check-cast v2, Ljava/lang/String;

    .line 5
    .line 6
    if-eqz v2, :cond_99

    .line 7
    .line 8
    iget-object v0, p0, Lac/c;->d:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Ljava/lang/String;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    const/4 v3, 0x7

    .line 14
    invoke-static {v1, v0, v1, v3}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v4, p0, Lac/c;->e:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v4, Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {v1, v4, v1, v3}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    iget-object v5, p0, Lac/c;->f:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v5, Ljava/lang/String;

    .line 29
    .line 30
    if-eqz v5, :cond_91

    .line 31
    .line 32
    invoke-virtual {p0}, Lac/c;->c()I

    .line 33
    .line 34
    .line 35
    move-result v6

    .line 36
    iget-object v7, p0, Lac/c;->g:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v7, Ljava/util/ArrayList;

    .line 39
    .line 40
    move-object v8, v7

    .line 41
    new-instance v7, Ljava/util/ArrayList;

    .line 42
    .line 43
    const/16 v9, 0xa

    .line 44
    .line 45
    invoke-static {v8, v9}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 46
    .line 47
    .line 48
    move-result v10

    .line 49
    invoke-direct {v7, v10}, Ljava/util/ArrayList;-><init>(I)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 53
    .line 54
    .line 55
    move-result-object v8

    .line 56
    :goto_37
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 57
    .line 58
    .line 59
    move-result v10

    .line 60
    if-eqz v10, :cond_4b

    .line 61
    .line 62
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v10

    .line 66
    check-cast v10, Ljava/lang/String;

    .line 67
    .line 68
    invoke-static {v1, v10, v1, v3}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v10

    .line 72
    invoke-virtual {v7, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    goto :goto_37

    .line 76
    :cond_4b
    iget-object v8, p0, Lac/c;->h:Ljava/io/Serializable;

    .line 77
    .line 78
    check-cast v8, Ljava/util/ArrayList;

    .line 79
    .line 80
    const/4 v10, 0x0

    .line 81
    if-eqz v8, :cond_7a

    .line 82
    .line 83
    new-instance v11, Ljava/util/ArrayList;

    .line 84
    .line 85
    invoke-static {v8, v9}, Lm30/l;->W(Ljava/lang/Iterable;I)I

    .line 86
    .line 87
    .line 88
    move-result v9

    .line 89
    invoke-direct {v11, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 90
    .line 91
    .line 92
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 93
    .line 94
    .line 95
    move-result-object v8

    .line 96
    :goto_5f
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 97
    .line 98
    .line 99
    move-result v9

    .line 100
    if-eqz v9, :cond_78

    .line 101
    .line 102
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v9

    .line 106
    check-cast v9, Ljava/lang/String;

    .line 107
    .line 108
    if-eqz v9, :cond_73

    .line 109
    .line 110
    const/4 v12, 0x3

    .line 111
    invoke-static {v1, v9, v1, v12}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    goto :goto_74

    .line 116
    :cond_73
    move-object v9, v10

    .line 117
    :goto_74
    invoke-virtual {v11, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    goto :goto_5f

    .line 121
    :cond_78
    move-object v8, v11

    .line 122
    goto :goto_7b

    .line 123
    :cond_7a
    move-object v8, v10

    .line 124
    :goto_7b
    iget-object v9, p0, Lac/c;->i:Ljava/lang/Object;

    .line 125
    .line 126
    check-cast v9, Ljava/lang/String;

    .line 127
    .line 128
    if-eqz v9, :cond_85

    .line 129
    .line 130
    invoke-static {v1, v9, v1, v3}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v10

    .line 134
    :cond_85
    move-object v9, v10

    .line 135
    invoke-virtual {p0}, Lac/c;->toString()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v10

    .line 139
    new-instance v1, Lb80/z;

    .line 140
    .line 141
    move-object v3, v0

    .line 142
    invoke-direct/range {v1 .. v10}, Lb80/z;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    return-object v1

    .line 146
    :cond_91
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 147
    .line 148
    const-string v1, "host == null"

    .line 149
    .line 150
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    throw v0

    .line 154
    :cond_99
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 155
    .line 156
    const-string v1, "scheme == null"

    .line 157
    .line 158
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    throw v0
.end method

.method public b(Landroid/graphics/Canvas;Landroid/view/View;)V
    .registers 16

    .line 1
    iget-object v0, p0, Lac/c;->g:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v6, v0

    .line 4
    check-cast v6, Landroid/graphics/Paint;

    .line 5
    .line 6
    iget-object v0, p0, Lac/c;->f:Ljava/lang/Object;

    .line 7
    .line 8
    move-object v12, v0

    .line 9
    check-cast v12, Landroid/graphics/Paint;

    .line 10
    .line 11
    const-string v0, "canvas"

    .line 12
    .line 13
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    int-to-float v0, v0

    .line 21
    invoke-virtual {p2}, Landroid/view/View;->getTranslationX()F

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    add-float v2, v1, v0

    .line 26
    .line 27
    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    int-to-float v10, v0

    .line 32
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    int-to-float v0, v0

    .line 37
    invoke-virtual {p2}, Landroid/view/View;->getTranslationY()F

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    add-float/2addr v1, v0

    .line 42
    const/4 v0, 0x0

    .line 43
    int-to-float v0, v0

    .line 44
    sub-float v3, v1, v0

    .line 45
    .line 46
    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    int-to-float v1, v1

    .line 51
    invoke-virtual {p2}, Landroid/view/View;->getTranslationY()F

    .line 52
    .line 53
    .line 54
    move-result p2

    .line 55
    add-float/2addr p2, v1

    .line 56
    add-float v5, p2, v0

    .line 57
    .line 58
    iget-object p2, p0, Lac/c;->h:Ljava/io/Serializable;

    .line 59
    .line 60
    check-cast p2, Ljava/lang/Integer;

    .line 61
    .line 62
    if-eqz p2, :cond_4f

    .line 63
    .line 64
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 65
    .line 66
    .line 67
    move-result p2

    .line 68
    invoke-virtual {v12, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 69
    .line 70
    .line 71
    move-object v7, p1

    .line 72
    move v8, v2

    .line 73
    move v9, v3

    .line 74
    move v11, v5

    .line 75
    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 76
    .line 77
    .line 78
    move-object v1, v7

    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    move-object v1, p1

    .line 81
    :goto_50
    iget-object p1, p0, Lac/c;->i:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast p1, Ljava/lang/Integer;

    .line 84
    .line 85
    if-eqz p1, :cond_65

    .line 86
    .line 87
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 88
    .line 89
    .line 90
    move-result p1

    .line 91
    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 92
    .line 93
    .line 94
    iget p1, p0, Lac/c;->b:I

    .line 95
    .line 96
    int-to-float p1, p1

    .line 97
    add-float v4, v2, p1

    .line 98
    .line 99
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 100
    .line 101
    .line 102
    :cond_65
    return-void
.end method

.method public c()I
    .registers 4

    .line 1
    iget v0, p0, Lac/c;->b:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_6

    .line 5
    .line 6
    return v0

    .line 7
    :cond_6
    iget-object v0, p0, Lac/c;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    const-string v2, "http"

    .line 15
    .line 16
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_18

    .line 21
    .line 22
    const/16 v1, 0x50

    .line 23
    .line 24
    goto :goto_22

    .line 25
    :cond_18
    const-string v2, "https"

    .line 26
    .line 27
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_22

    .line 32
    .line 33
    const/16 v1, 0x1bb

    .line 34
    .line 35
    :cond_22
    :goto_22
    return v1
.end method

.method public d(Ljava/lang/String;)V
    .registers 4

    .line 1
    const-string v0, "host"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    const/4 v1, 0x7

    .line 8
    invoke-static {v0, p1, v0, v1}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, Lsu/e;->O(Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_14

    .line 17
    .line 18
    iput-object v0, p0, Lac/c;->f:Ljava/lang/Object;

    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 22
    .line 23
    const-string v1, "unexpected host: "

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    throw v0
.end method

.method public e(Lb80/z;Ljava/lang/String;)V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Lac/c;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v3, Ljava/util/ArrayList;

    .line 10
    .line 11
    sget-object v4, Lc80/b;->a:[B

    .line 12
    .line 13
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    const/4 v5, 0x0

    .line 18
    invoke-static {v5, v4, v2}, Lc80/b;->m(IILjava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    invoke-static {v4, v6, v2}, Lc80/b;->n(IILjava/lang/String;)I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    sub-int v7, v6, v4

    .line 31
    .line 32
    const/16 v8, 0x5b

    .line 33
    .line 34
    const/16 v9, 0x3a

    .line 35
    .line 36
    const/4 v10, -0x1

    .line 37
    const/4 v11, 0x2

    .line 38
    if-ge v7, v11, :cond_28

    .line 39
    .line 40
    goto :goto_7c

    .line 41
    :cond_28
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    const/16 v12, 0x61

    .line 46
    .line 47
    invoke-static {v7, v12}, Lkotlin/jvm/internal/k;->i(II)I

    .line 48
    .line 49
    .line 50
    move-result v13

    .line 51
    const/16 v14, 0x41

    .line 52
    .line 53
    if-ltz v13, :cond_3e

    .line 54
    .line 55
    const/16 v13, 0x7a

    .line 56
    .line 57
    invoke-static {v7, v13}, Lkotlin/jvm/internal/k;->i(II)I

    .line 58
    .line 59
    .line 60
    move-result v13

    .line 61
    if-lez v13, :cond_4d

    .line 62
    .line 63
    :cond_3e
    invoke-static {v7, v14}, Lkotlin/jvm/internal/k;->i(II)I

    .line 64
    .line 65
    .line 66
    move-result v13

    .line 67
    if-ltz v13, :cond_7c

    .line 68
    .line 69
    const/16 v13, 0x5a

    .line 70
    .line 71
    invoke-static {v7, v13}, Lkotlin/jvm/internal/k;->i(II)I

    .line 72
    .line 73
    .line 74
    move-result v7

    .line 75
    if-lez v7, :cond_4d

    .line 76
    .line 77
    goto :goto_7c

    .line 78
    :cond_4d
    add-int/lit8 v7, v4, 0x1

    .line 79
    .line 80
    :goto_4f
    if-ge v7, v6, :cond_7c

    .line 81
    .line 82
    invoke-virtual {v2, v7}, Ljava/lang/String;->charAt(I)C

    .line 83
    .line 84
    .line 85
    move-result v13

    .line 86
    if-gt v12, v13, :cond_5c

    .line 87
    .line 88
    const/16 v15, 0x7b

    .line 89
    .line 90
    if-ge v13, v15, :cond_5c

    .line 91
    .line 92
    goto :goto_76

    .line 93
    :cond_5c
    if-gt v14, v13, :cond_61

    .line 94
    .line 95
    if-ge v13, v8, :cond_61

    .line 96
    .line 97
    goto :goto_76

    .line 98
    :cond_61
    const/16 v15, 0x30

    .line 99
    .line 100
    if-gt v15, v13, :cond_68

    .line 101
    .line 102
    if-ge v13, v9, :cond_68

    .line 103
    .line 104
    goto :goto_76

    .line 105
    :cond_68
    const/16 v15, 0x2b

    .line 106
    .line 107
    if-ne v13, v15, :cond_6d

    .line 108
    .line 109
    goto :goto_76

    .line 110
    :cond_6d
    const/16 v15, 0x2d

    .line 111
    .line 112
    if-ne v13, v15, :cond_72

    .line 113
    .line 114
    goto :goto_76

    .line 115
    :cond_72
    const/16 v15, 0x2e

    .line 116
    .line 117
    if-ne v13, v15, :cond_79

    .line 118
    .line 119
    :goto_76
    add-int/lit8 v7, v7, 0x1

    .line 120
    .line 121
    goto :goto_4f

    .line 122
    :cond_79
    if-ne v13, v9, :cond_7c

    .line 123
    .line 124
    goto :goto_7d

    .line 125
    :cond_7c
    :goto_7c
    move v7, v10

    .line 126
    :goto_7d
    const-string v12, "http"

    .line 127
    .line 128
    const-string v13, "https"

    .line 129
    .line 130
    const-string v14, "this as java.lang.String\u2026ing(startIndex, endIndex)"

    .line 131
    .line 132
    const/4 v15, 0x1

    .line 133
    if-eq v7, v10, :cond_c0

    .line 134
    .line 135
    const-string v8, "https:"

    .line 136
    .line 137
    invoke-static {v2, v8, v4, v15}, Lw60/v;->h0(Ljava/lang/String;Ljava/lang/String;IZ)Z

    .line 138
    .line 139
    .line 140
    move-result v8

    .line 141
    if-eqz v8, :cond_93

    .line 142
    .line 143
    iput-object v13, v0, Lac/c;->c:Ljava/lang/Object;

    .line 144
    .line 145
    add-int/lit8 v4, v4, 0x6

    .line 146
    .line 147
    goto :goto_c6

    .line 148
    :cond_93
    const-string v8, "http:"

    .line 149
    .line 150
    invoke-static {v2, v8, v4, v15}, Lw60/v;->h0(Ljava/lang/String;Ljava/lang/String;IZ)Z

    .line 151
    .line 152
    .line 153
    move-result v8

    .line 154
    if-eqz v8, :cond_a0

    .line 155
    .line 156
    iput-object v12, v0, Lac/c;->c:Ljava/lang/Object;

    .line 157
    .line 158
    add-int/lit8 v4, v4, 0x5

    .line 159
    .line 160
    goto :goto_c6

    .line 161
    :cond_a0
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 162
    .line 163
    new-instance v3, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    const-string v4, "Expected URL scheme \'http\' or \'https\' but was \'"

    .line 166
    .line 167
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v2, v5, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    invoke-static {v2, v14}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    const/16 v2, 0x27

    .line 181
    .line 182
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    throw v1

    .line 193
    :cond_c0
    if-eqz v1, :cond_379

    .line 194
    .line 195
    iget-object v7, v1, Lb80/z;->a:Ljava/lang/String;

    .line 196
    .line 197
    iput-object v7, v0, Lac/c;->c:Ljava/lang/Object;

    .line 198
    .line 199
    :goto_c6
    move v7, v4

    .line 200
    move v8, v5

    .line 201
    move/from16 v16, v15

    .line 202
    .line 203
    :goto_ca
    const/16 v15, 0x2f

    .line 204
    .line 205
    const/16 v9, 0x5c

    .line 206
    .line 207
    if-ge v7, v6, :cond_e0

    .line 208
    .line 209
    invoke-virtual {v2, v7}, Ljava/lang/String;->charAt(I)C

    .line 210
    .line 211
    .line 212
    move-result v10

    .line 213
    if-eq v10, v9, :cond_d8

    .line 214
    .line 215
    if-ne v10, v15, :cond_e0

    .line 216
    .line 217
    :cond_d8
    add-int/lit8 v8, v8, 0x1

    .line 218
    .line 219
    add-int/lit8 v7, v7, 0x1

    .line 220
    .line 221
    const/16 v9, 0x3a

    .line 222
    .line 223
    const/4 v10, -0x1

    .line 224
    goto :goto_ca

    .line 225
    :cond_e0
    const-string v7, " \"\'<>#"

    .line 226
    .line 227
    const-string v10, ""

    .line 228
    .line 229
    const/16 v9, 0x23

    .line 230
    .line 231
    if-ge v8, v11, :cond_133

    .line 232
    .line 233
    if-eqz v1, :cond_133

    .line 234
    .line 235
    iget-object v11, v1, Lb80/z;->a:Ljava/lang/String;

    .line 236
    .line 237
    iget-object v15, v0, Lac/c;->c:Ljava/lang/Object;

    .line 238
    .line 239
    check-cast v15, Ljava/lang/String;

    .line 240
    .line 241
    invoke-static {v11, v15}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 242
    .line 243
    .line 244
    move-result v11

    .line 245
    if-nez v11, :cond_f7

    .line 246
    .line 247
    goto :goto_133

    .line 248
    :cond_f7
    invoke-virtual {v1}, Lb80/z;->e()Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v8

    .line 252
    iput-object v8, v0, Lac/c;->d:Ljava/lang/Object;

    .line 253
    .line 254
    invoke-virtual {v1}, Lb80/z;->a()Ljava/lang/String;

    .line 255
    .line 256
    .line 257
    move-result-object v8

    .line 258
    iput-object v8, v0, Lac/c;->e:Ljava/lang/Object;

    .line 259
    .line 260
    iget-object v8, v1, Lb80/z;->d:Ljava/lang/String;

    .line 261
    .line 262
    iput-object v8, v0, Lac/c;->f:Ljava/lang/Object;

    .line 263
    .line 264
    iget v8, v1, Lb80/z;->e:I

    .line 265
    .line 266
    iput v8, v0, Lac/c;->b:I

    .line 267
    .line 268
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 269
    .line 270
    .line 271
    invoke-virtual {v1}, Lb80/z;->c()Ljava/util/ArrayList;

    .line 272
    .line 273
    .line 274
    move-result-object v8

    .line 275
    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 276
    .line 277
    .line 278
    if-eq v4, v6, :cond_11d

    .line 279
    .line 280
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 281
    .line 282
    .line 283
    move-result v8

    .line 284
    if-ne v8, v9, :cond_260

    .line 285
    .line 286
    :cond_11d
    invoke-virtual {v1}, Lb80/z;->d()Ljava/lang/String;

    .line 287
    .line 288
    .line 289
    move-result-object v1

    .line 290
    if-eqz v1, :cond_12e

    .line 291
    .line 292
    const/16 v8, 0xd3

    .line 293
    .line 294
    invoke-static {v5, v5, v8, v1, v7}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v1

    .line 298
    invoke-static {v1}, Lb80/b;->i(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 299
    .line 300
    .line 301
    move-result-object v1

    .line 302
    goto :goto_12f

    .line 303
    :cond_12e
    const/4 v1, 0x0

    .line 304
    :goto_12f
    iput-object v1, v0, Lac/c;->h:Ljava/io/Serializable;

    .line 305
    .line 306
    goto/16 :goto_260

    .line 307
    .line 308
    :cond_133
    :goto_133
    add-int/2addr v4, v8

    .line 309
    move v1, v5

    .line 310
    move v8, v1

    .line 311
    :goto_136
    const-string v11, "@/\\?#"

    .line 312
    .line 313
    invoke-static {v2, v4, v6, v11}, Lc80/b;->f(Ljava/lang/String;IILjava/lang/String;)I

    .line 314
    .line 315
    .line 316
    move-result v11

    .line 317
    if-eq v11, v6, :cond_144

    .line 318
    .line 319
    invoke-virtual {v2, v11}, Ljava/lang/String;->charAt(I)C

    .line 320
    .line 321
    .line 322
    move-result v15

    .line 323
    :goto_142
    const/4 v5, -0x1

    .line 324
    goto :goto_146

    .line 325
    :cond_144
    const/4 v15, -0x1

    .line 326
    goto :goto_142

    .line 327
    :goto_146
    if-eq v15, v5, :cond_1c2

    .line 328
    .line 329
    if-eq v15, v9, :cond_1c2

    .line 330
    .line 331
    const/16 v5, 0x2f

    .line 332
    .line 333
    if-eq v15, v5, :cond_1c2

    .line 334
    .line 335
    const/16 v5, 0x5c

    .line 336
    .line 337
    if-eq v15, v5, :cond_1c2

    .line 338
    .line 339
    const/16 v5, 0x3f

    .line 340
    .line 341
    if-eq v15, v5, :cond_1c2

    .line 342
    .line 343
    const/16 v5, 0x40

    .line 344
    .line 345
    if-eq v15, v5, :cond_15c

    .line 346
    .line 347
    const/4 v5, 0x0

    .line 348
    goto :goto_136

    .line 349
    :cond_15c
    const-string v5, " \"\':;<=>@[]^`{}|/\\?#"

    .line 350
    .line 351
    const-string v15, "%40"

    .line 352
    .line 353
    if-nez v1, :cond_197

    .line 354
    .line 355
    move/from16 p1, v1

    .line 356
    .line 357
    const/16 v9, 0x3a

    .line 358
    .line 359
    invoke-static {v9, v4, v11, v2}, Lc80/b;->e(CIILjava/lang/String;)I

    .line 360
    .line 361
    .line 362
    move-result v1

    .line 363
    const/16 v9, 0xf0

    .line 364
    .line 365
    invoke-static {v4, v1, v9, v2, v5}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 366
    .line 367
    .line 368
    move-result-object v4

    .line 369
    if-eqz v8, :cond_17f

    .line 370
    .line 371
    new-instance v8, Ljava/lang/StringBuilder;

    .line 372
    .line 373
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 374
    .line 375
    .line 376
    iget-object v9, v0, Lac/c;->d:Ljava/lang/Object;

    .line 377
    .line 378
    check-cast v9, Ljava/lang/String;

    .line 379
    .line 380
    invoke-static {v8, v9, v15, v4}, La1/h;->l(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 381
    .line 382
    .line 383
    move-result-object v4

    .line 384
    :cond_17f
    iput-object v4, v0, Lac/c;->d:Ljava/lang/Object;

    .line 385
    .line 386
    if-eq v1, v11, :cond_190

    .line 387
    .line 388
    add-int/lit8 v1, v1, 0x1

    .line 389
    .line 390
    const/16 v9, 0xf0

    .line 391
    .line 392
    invoke-static {v1, v11, v9, v2, v5}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 393
    .line 394
    .line 395
    move-result-object v1

    .line 396
    iput-object v1, v0, Lac/c;->e:Ljava/lang/Object;

    .line 397
    .line 398
    move/from16 v1, v16

    .line 399
    .line 400
    goto :goto_194

    .line 401
    :cond_190
    const/16 v9, 0xf0

    .line 402
    .line 403
    move/from16 v1, p1

    .line 404
    .line 405
    :goto_194
    move/from16 v8, v16

    .line 406
    .line 407
    goto :goto_1bb

    .line 408
    :cond_197
    move/from16 p1, v1

    .line 409
    .line 410
    const/16 v9, 0xf0

    .line 411
    .line 412
    new-instance v1, Ljava/lang/StringBuilder;

    .line 413
    .line 414
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 415
    .line 416
    .line 417
    iget-object v9, v0, Lac/c;->e:Ljava/lang/Object;

    .line 418
    .line 419
    check-cast v9, Ljava/lang/String;

    .line 420
    .line 421
    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 422
    .line 423
    .line 424
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 425
    .line 426
    .line 427
    const/16 v9, 0xf0

    .line 428
    .line 429
    invoke-static {v4, v11, v9, v2, v5}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 430
    .line 431
    .line 432
    move-result-object v4

    .line 433
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 434
    .line 435
    .line 436
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 437
    .line 438
    .line 439
    move-result-object v1

    .line 440
    iput-object v1, v0, Lac/c;->e:Ljava/lang/Object;

    .line 441
    .line 442
    move/from16 v1, p1

    .line 443
    .line 444
    :goto_1bb
    add-int/lit8 v4, v11, 0x1

    .line 445
    .line 446
    const/4 v5, 0x0

    .line 447
    const/16 v9, 0x23

    .line 448
    .line 449
    goto/16 :goto_136

    .line 450
    .line 451
    :cond_1c2
    move v1, v4

    .line 452
    :goto_1c3
    if-ge v1, v11, :cond_1e4

    .line 453
    .line 454
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 455
    .line 456
    .line 457
    move-result v5

    .line 458
    const/16 v8, 0x5b

    .line 459
    .line 460
    if-ne v5, v8, :cond_1dc

    .line 461
    .line 462
    :cond_1cd
    add-int/lit8 v1, v1, 0x1

    .line 463
    .line 464
    if-ge v1, v11, :cond_1d9

    .line 465
    .line 466
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 467
    .line 468
    .line 469
    move-result v5

    .line 470
    const/16 v9, 0x5d

    .line 471
    .line 472
    if-ne v5, v9, :cond_1cd

    .line 473
    .line 474
    :cond_1d9
    const/16 v9, 0x3a

    .line 475
    .line 476
    goto :goto_1e1

    .line 477
    :cond_1dc
    const/16 v9, 0x3a

    .line 478
    .line 479
    if-ne v5, v9, :cond_1e1

    .line 480
    .line 481
    goto :goto_1e5

    .line 482
    :cond_1e1
    :goto_1e1
    add-int/lit8 v1, v1, 0x1

    .line 483
    .line 484
    goto :goto_1c3

    .line 485
    :cond_1e4
    move v1, v11

    .line 486
    :goto_1e5
    add-int/lit8 v5, v1, 0x1

    .line 487
    .line 488
    const/4 v8, 0x4

    .line 489
    const/16 v9, 0x22

    .line 490
    .line 491
    if-ge v5, v11, :cond_232

    .line 492
    .line 493
    invoke-static {v4, v2, v1, v8}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 494
    .line 495
    .line 496
    move-result-object v8

    .line 497
    invoke-static {v8}, Lsu/e;->O(Ljava/lang/String;)Ljava/lang/String;

    .line 498
    .line 499
    .line 500
    move-result-object v8

    .line 501
    iput-object v8, v0, Lac/c;->f:Ljava/lang/Object;

    .line 502
    .line 503
    const/16 v8, 0xf8

    .line 504
    .line 505
    :try_start_1f8
    invoke-static {v5, v11, v8, v2, v10}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 506
    .line 507
    .line 508
    move-result-object v8

    .line 509
    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 510
    .line 511
    .line 512
    move-result v8
    :try_end_200
    .catch Ljava/lang/NumberFormatException; {:try_start_1f8 .. :try_end_200} :catch_209

    .line 513
    move/from16 v12, v16

    .line 514
    .line 515
    if-gt v12, v8, :cond_209

    .line 516
    .line 517
    const/high16 v12, 0x10000

    .line 518
    .line 519
    if-ge v8, v12, :cond_209

    .line 520
    .line 521
    goto :goto_20a

    .line 522
    :catch_209
    :cond_209
    const/4 v8, -0x1

    .line 523
    :goto_20a
    iput v8, v0, Lac/c;->b:I

    .line 524
    .line 525
    const/4 v15, -0x1

    .line 526
    if-eq v8, v15, :cond_210

    .line 527
    .line 528
    goto :goto_259

    .line 529
    :cond_210
    new-instance v1, Ljava/lang/StringBuilder;

    .line 530
    .line 531
    const-string v3, "Invalid URL port: \""

    .line 532
    .line 533
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 534
    .line 535
    .line 536
    invoke-virtual {v2, v5, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    move-result-object v2

    .line 540
    invoke-static {v2, v14}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 541
    .line 542
    .line 543
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 544
    .line 545
    .line 546
    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 547
    .line 548
    .line 549
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 550
    .line 551
    .line 552
    move-result-object v1

    .line 553
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 554
    .line 555
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 556
    .line 557
    .line 558
    move-result-object v1

    .line 559
    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 560
    .line 561
    .line 562
    throw v2

    .line 563
    :cond_232
    const/4 v15, -0x1

    .line 564
    invoke-static {v4, v2, v1, v8}, Lb80/b;->h(ILjava/lang/String;II)Ljava/lang/String;

    .line 565
    .line 566
    .line 567
    move-result-object v5

    .line 568
    invoke-static {v5}, Lsu/e;->O(Ljava/lang/String;)Ljava/lang/String;

    .line 569
    .line 570
    .line 571
    move-result-object v5

    .line 572
    iput-object v5, v0, Lac/c;->f:Ljava/lang/Object;

    .line 573
    .line 574
    iget-object v5, v0, Lac/c;->c:Ljava/lang/Object;

    .line 575
    .line 576
    check-cast v5, Ljava/lang/String;

    .line 577
    .line 578
    invoke-static {v5}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 579
    .line 580
    .line 581
    invoke-virtual {v5, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 582
    .line 583
    .line 584
    move-result v8

    .line 585
    if-eqz v8, :cond_24d

    .line 586
    .line 587
    const/16 v5, 0x50

    .line 588
    .line 589
    goto :goto_257

    .line 590
    :cond_24d
    invoke-virtual {v5, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 591
    .line 592
    .line 593
    move-result v5

    .line 594
    if-eqz v5, :cond_256

    .line 595
    .line 596
    const/16 v5, 0x1bb

    .line 597
    .line 598
    goto :goto_257

    .line 599
    :cond_256
    move v5, v15

    .line 600
    :goto_257
    iput v5, v0, Lac/c;->b:I

    .line 601
    .line 602
    :goto_259
    iget-object v5, v0, Lac/c;->f:Ljava/lang/Object;

    .line 603
    .line 604
    check-cast v5, Ljava/lang/String;

    .line 605
    .line 606
    if-eqz v5, :cond_357

    .line 607
    .line 608
    move v4, v11

    .line 609
    :cond_260
    :goto_260
    const-string v1, "?#"

    .line 610
    .line 611
    invoke-static {v2, v4, v6, v1}, Lc80/b;->f(Ljava/lang/String;IILjava/lang/String;)I

    .line 612
    .line 613
    .line 614
    move-result v1

    .line 615
    if-ne v4, v1, :cond_26a

    .line 616
    .line 617
    goto/16 :goto_321

    .line 618
    .line 619
    :cond_26a
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 620
    .line 621
    .line 622
    move-result v5

    .line 623
    const/16 v8, 0x2f

    .line 624
    .line 625
    if-eq v5, v8, :cond_283

    .line 626
    .line 627
    const/16 v8, 0x5c

    .line 628
    .line 629
    if-ne v5, v8, :cond_277

    .line 630
    .line 631
    goto :goto_283

    .line 632
    :cond_277
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 633
    .line 634
    .line 635
    move-result v5

    .line 636
    const/16 v16, 0x1

    .line 637
    .line 638
    add-int/lit8 v5, v5, -0x1

    .line 639
    .line 640
    invoke-virtual {v3, v5, v10}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 641
    .line 642
    .line 643
    goto :goto_28b

    .line 644
    :cond_283
    :goto_283
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 645
    .line 646
    .line 647
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 648
    .line 649
    .line 650
    add-int/lit8 v4, v4, 0x1

    .line 651
    .line 652
    :goto_28b
    if-ge v4, v1, :cond_321

    .line 653
    .line 654
    const-string v5, "/\\"

    .line 655
    .line 656
    invoke-static {v2, v4, v1, v5}, Lc80/b;->f(Ljava/lang/String;IILjava/lang/String;)I

    .line 657
    .line 658
    .line 659
    move-result v5

    .line 660
    if-ge v5, v1, :cond_297

    .line 661
    .line 662
    const/4 v12, 0x1

    .line 663
    goto :goto_298

    .line 664
    :cond_297
    const/4 v12, 0x0

    .line 665
    :goto_298
    const-string v8, " \"<>^`{}|/\\?#"

    .line 666
    .line 667
    const/16 v9, 0xf0

    .line 668
    .line 669
    invoke-static {v4, v5, v9, v2, v8}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 670
    .line 671
    .line 672
    move-result-object v4

    .line 673
    const-string v8, "."

    .line 674
    .line 675
    invoke-virtual {v4, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 676
    .line 677
    .line 678
    move-result v8

    .line 679
    if-nez v8, :cond_318

    .line 680
    .line 681
    const-string v8, "%2e"

    .line 682
    .line 683
    invoke-virtual {v4, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 684
    .line 685
    .line 686
    move-result v8

    .line 687
    if-eqz v8, :cond_2b1

    .line 688
    .line 689
    goto :goto_318

    .line 690
    :cond_2b1
    const-string v8, ".."

    .line 691
    .line 692
    invoke-virtual {v4, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 693
    .line 694
    .line 695
    move-result v8

    .line 696
    if-nez v8, :cond_2f1

    .line 697
    .line 698
    const-string v8, "%2e."

    .line 699
    .line 700
    invoke-virtual {v4, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 701
    .line 702
    .line 703
    move-result v8

    .line 704
    if-nez v8, :cond_2f1

    .line 705
    .line 706
    const-string v8, ".%2e"

    .line 707
    .line 708
    invoke-virtual {v4, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 709
    .line 710
    .line 711
    move-result v8

    .line 712
    if-nez v8, :cond_2f1

    .line 713
    .line 714
    const-string v8, "%2e%2e"

    .line 715
    .line 716
    invoke-virtual {v4, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 717
    .line 718
    .line 719
    move-result v8

    .line 720
    if-eqz v8, :cond_2d2

    .line 721
    .line 722
    goto :goto_2f1

    .line 723
    :cond_2d2
    const/4 v8, 0x1

    .line 724
    invoke-static {v8, v3}, Lhs/q;->h(ILjava/util/ArrayList;)Ljava/lang/Object;

    .line 725
    .line 726
    .line 727
    move-result-object v11

    .line 728
    check-cast v11, Ljava/lang/CharSequence;

    .line 729
    .line 730
    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    .line 731
    .line 732
    .line 733
    move-result v11

    .line 734
    if-nez v11, :cond_2e8

    .line 735
    .line 736
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 737
    .line 738
    .line 739
    move-result v11

    .line 740
    sub-int/2addr v11, v8

    .line 741
    invoke-virtual {v3, v11, v4}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 742
    .line 743
    .line 744
    goto :goto_2eb

    .line 745
    :cond_2e8
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 746
    .line 747
    .line 748
    :goto_2eb
    if-eqz v12, :cond_318

    .line 749
    .line 750
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 751
    .line 752
    .line 753
    goto :goto_318

    .line 754
    :cond_2f1
    :goto_2f1
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 755
    .line 756
    .line 757
    move-result v4

    .line 758
    const/16 v16, 0x1

    .line 759
    .line 760
    add-int/lit8 v4, v4, -0x1

    .line 761
    .line 762
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 763
    .line 764
    .line 765
    move-result-object v4

    .line 766
    check-cast v4, Ljava/lang/String;

    .line 767
    .line 768
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 769
    .line 770
    .line 771
    move-result v4

    .line 772
    if-nez v4, :cond_315

    .line 773
    .line 774
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 775
    .line 776
    .line 777
    move-result v4

    .line 778
    if-nez v4, :cond_315

    .line 779
    .line 780
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 781
    .line 782
    .line 783
    move-result v4

    .line 784
    add-int/lit8 v4, v4, -0x1

    .line 785
    .line 786
    invoke-virtual {v3, v4, v10}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    goto :goto_318

    .line 790
    :cond_315
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 791
    .line 792
    .line 793
    :cond_318
    :goto_318
    if-eqz v12, :cond_31e

    .line 794
    .line 795
    add-int/lit8 v4, v5, 0x1

    .line 796
    .line 797
    goto/16 :goto_28b

    .line 798
    .line 799
    :cond_31e
    move v4, v5

    .line 800
    goto/16 :goto_28b

    .line 801
    .line 802
    :cond_321
    :goto_321
    if-ge v1, v6, :cond_340

    .line 803
    .line 804
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 805
    .line 806
    .line 807
    move-result v3

    .line 808
    const/16 v5, 0x3f

    .line 809
    .line 810
    if-ne v3, v5, :cond_340

    .line 811
    .line 812
    const/16 v3, 0x23

    .line 813
    .line 814
    invoke-static {v3, v1, v6, v2}, Lc80/b;->e(CIILjava/lang/String;)I

    .line 815
    .line 816
    .line 817
    move-result v4

    .line 818
    add-int/lit8 v1, v1, 0x1

    .line 819
    .line 820
    const/16 v3, 0xd0

    .line 821
    .line 822
    invoke-static {v1, v4, v3, v2, v7}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 823
    .line 824
    .line 825
    move-result-object v1

    .line 826
    invoke-static {v1}, Lb80/b;->i(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 827
    .line 828
    .line 829
    move-result-object v1

    .line 830
    iput-object v1, v0, Lac/c;->h:Ljava/io/Serializable;

    .line 831
    .line 832
    move v1, v4

    .line 833
    :cond_340
    if-ge v1, v6, :cond_356

    .line 834
    .line 835
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 836
    .line 837
    .line 838
    move-result v3

    .line 839
    const/16 v4, 0x23

    .line 840
    .line 841
    if-ne v3, v4, :cond_356

    .line 842
    .line 843
    const/16 v16, 0x1

    .line 844
    .line 845
    add-int/lit8 v1, v1, 0x1

    .line 846
    .line 847
    const/16 v3, 0xb0

    .line 848
    .line 849
    invoke-static {v1, v6, v3, v2, v10}, Lb80/b;->d(IIILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 850
    .line 851
    .line 852
    move-result-object v1

    .line 853
    iput-object v1, v0, Lac/c;->i:Ljava/lang/Object;

    .line 854
    .line 855
    :cond_356
    return-void

    .line 856
    :cond_357
    new-instance v3, Ljava/lang/StringBuilder;

    .line 857
    .line 858
    const-string v5, "Invalid URL host: \""

    .line 859
    .line 860
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 861
    .line 862
    .line 863
    invoke-virtual {v2, v4, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 864
    .line 865
    .line 866
    move-result-object v1

    .line 867
    invoke-static {v1, v14}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 868
    .line 869
    .line 870
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 871
    .line 872
    .line 873
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 874
    .line 875
    .line 876
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 877
    .line 878
    .line 879
    move-result-object v1

    .line 880
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 881
    .line 882
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 883
    .line 884
    .line 885
    move-result-object v1

    .line 886
    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 887
    .line 888
    .line 889
    throw v2

    .line 890
    :cond_379
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 891
    .line 892
    .line 893
    move-result v1

    .line 894
    const/4 v3, 0x6

    .line 895
    if-le v1, v3, :cond_38b

    .line 896
    .line 897
    invoke-static {v3, v2}, Lw60/o;->U0(ILjava/lang/String;)Ljava/lang/String;

    .line 898
    .line 899
    .line 900
    move-result-object v1

    .line 901
    const-string v2, "..."

    .line 902
    .line 903
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 904
    .line 905
    .line 906
    move-result-object v1

    .line 907
    goto :goto_38c

    .line 908
    :cond_38b
    move-object v1, v2

    .line 909
    :goto_38c
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 910
    .line 911
    const-string v3, "Expected URL scheme \'http\' or \'https\' but no scheme was found for "

    .line 912
    .line 913
    invoke-static {v3, v1}, La1/h;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 914
    .line 915
    .line 916
    move-result-object v1

    .line 917
    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 918
    .line 919
    .line 920
    throw v2
.end method

.method public f(Ljava/lang/String;)V
    .registers 4

    .line 1
    const-string v0, "http"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_b

    .line 8
    .line 9
    iput-object v0, p0, Lac/c;->c:Ljava/lang/Object;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    const-string v0, "https"

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_16

    .line 19
    .line 20
    iput-object v0, p0, Lac/c;->c:Ljava/lang/Object;

    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 24
    .line 25
    const-string v1, "unexpected scheme: "

    .line 26
    .line 27
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw v0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    .line 1
    iget v0, p0, Lac/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_104

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Lac/c;->c:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v1, Ljava/lang/String;

    .line 19
    .line 20
    if-eqz v1, :cond_1e

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, "://"

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    goto :goto_23

    .line 31
    :cond_1e
    const-string v1, "//"

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    :goto_23
    iget-object v1, p0, Lac/c;->d:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v1, Ljava/lang/String;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    const/16 v2, 0x3a

    .line 45
    .line 46
    if-lez v1, :cond_30

    .line 47
    .line 48
    goto :goto_3a

    .line 49
    :cond_30
    iget-object v1, p0, Lac/c;->e:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v1, Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-lez v1, :cond_5a

    .line 58
    .line 59
    :goto_3a
    iget-object v1, p0, Lac/c;->d:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v1, Ljava/lang/String;

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    iget-object v1, p0, Lac/c;->e:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v1, Ljava/lang/String;

    .line 69
    .line 70
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    if-lez v1, :cond_55

    .line 75
    .line 76
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    iget-object v1, p0, Lac/c;->e:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v1, Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    :cond_55
    const/16 v1, 0x40

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    :cond_5a
    iget-object v1, p0, Lac/c;->f:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v1, Ljava/lang/String;

    .line 94
    .line 95
    if-eqz v1, :cond_7f

    .line 96
    .line 97
    invoke-static {v1, v2}, Lw60/o;->n0(Ljava/lang/CharSequence;C)Z

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    if-eqz v1, :cond_78

    .line 102
    .line 103
    const/16 v1, 0x5b

    .line 104
    .line 105
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    iget-object v1, p0, Lac/c;->f:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, Ljava/lang/String;

    .line 111
    .line 112
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 113
    .line 114
    .line 115
    const/16 v1, 0x5d

    .line 116
    .line 117
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    goto :goto_7f

    .line 121
    :cond_78
    iget-object v1, p0, Lac/c;->f:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast v1, Ljava/lang/String;

    .line 124
    .line 125
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    :cond_7f
    :goto_7f
    iget v1, p0, Lac/c;->b:I

    .line 129
    .line 130
    const/4 v3, -0x1

    .line 131
    if-ne v1, v3, :cond_8a

    .line 132
    .line 133
    iget-object v1, p0, Lac/c;->c:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v1, Ljava/lang/String;

    .line 136
    .line 137
    if-eqz v1, :cond_b1

    .line 138
    .line 139
    :cond_8a
    invoke-virtual {p0}, Lac/c;->c()I

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    iget-object v4, p0, Lac/c;->c:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v4, Ljava/lang/String;

    .line 146
    .line 147
    if-eqz v4, :cond_ab

    .line 148
    .line 149
    const-string v5, "http"

    .line 150
    .line 151
    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result v5

    .line 155
    if-eqz v5, :cond_9f

    .line 156
    .line 157
    const/16 v3, 0x50

    .line 158
    .line 159
    goto :goto_a9

    .line 160
    :cond_9f
    const-string v5, "https"

    .line 161
    .line 162
    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result v4

    .line 166
    if-eqz v4, :cond_a9

    .line 167
    .line 168
    const/16 v3, 0x1bb

    .line 169
    .line 170
    :cond_a9
    :goto_a9
    if-eq v1, v3, :cond_b1

    .line 171
    .line 172
    :cond_ab
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    :cond_b1
    iget-object v1, p0, Lac/c;->g:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast v1, Ljava/util/ArrayList;

    .line 181
    .line 182
    const-string v2, "<this>"

    .line 183
    .line 184
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 188
    .line 189
    .line 190
    move-result v2

    .line 191
    const/4 v3, 0x0

    .line 192
    :goto_bf
    if-ge v3, v2, :cond_d2

    .line 193
    .line 194
    const/16 v4, 0x2f

    .line 195
    .line 196
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v4

    .line 203
    check-cast v4, Ljava/lang/String;

    .line 204
    .line 205
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 206
    .line 207
    .line 208
    add-int/lit8 v3, v3, 0x1

    .line 209
    .line 210
    goto :goto_bf

    .line 211
    :cond_d2
    iget-object v1, p0, Lac/c;->h:Ljava/io/Serializable;

    .line 212
    .line 213
    check-cast v1, Ljava/util/ArrayList;

    .line 214
    .line 215
    if-eqz v1, :cond_e7

    .line 216
    .line 217
    const/16 v1, 0x3f

    .line 218
    .line 219
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 220
    .line 221
    .line 222
    iget-object v1, p0, Lac/c;->h:Ljava/io/Serializable;

    .line 223
    .line 224
    check-cast v1, Ljava/util/ArrayList;

    .line 225
    .line 226
    invoke-static {v1}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    invoke-static {v0, v1}, Lb80/b;->j(Ljava/lang/StringBuilder;Ljava/util/List;)V

    .line 230
    .line 231
    .line 232
    :cond_e7
    iget-object v1, p0, Lac/c;->i:Ljava/lang/Object;

    .line 233
    .line 234
    check-cast v1, Ljava/lang/String;

    .line 235
    .line 236
    if-eqz v1, :cond_f9

    .line 237
    .line 238
    const/16 v1, 0x23

    .line 239
    .line 240
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    iget-object v1, p0, Lac/c;->i:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast v1, Ljava/lang/String;

    .line 246
    .line 247
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    :cond_f9
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    const-string v1, "StringBuilder().apply(builderAction).toString()"

    .line 255
    .line 256
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    return-object v0

    .line 260
    nop

    .line 261
    :pswitch_data_104
    .packed-switch 0x1
        :pswitch_a
    .end packed-switch
.end method
