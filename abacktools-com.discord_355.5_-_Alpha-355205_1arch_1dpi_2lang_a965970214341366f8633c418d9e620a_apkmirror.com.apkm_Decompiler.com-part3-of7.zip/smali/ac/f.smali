###### Class ac.f (ac.f)
.class public final Lac/f;
.super Le6/t0;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:I

.field public final c:Ll30/o;

.field public final d:Ll30/o;

.field public final e:I

.field public final f:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lac/f;->a:Landroid/content/Context;

    .line 5
    .line 6
    iput p2, p0, Lac/f;->b:I

    .line 7
    .line 8
    new-instance p2, Lac/e;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p2, p0, v0}, Lac/e;-><init>(Lac/f;I)V

    .line 12
    .line 13
    .line 14
    invoke-static {p2}, La/a;->K(Lkotlin/jvm/functions/Function0;)Ll30/o;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    iput-object p2, p0, Lac/f;->c:Ll30/o;

    .line 19
    .line 20
    new-instance p2, Lac/e;

    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    invoke-direct {p2, p0, v0}, Lac/e;-><init>(Lac/f;I)V

    .line 24
    .line 25
    .line 26
    invoke-static {p2}, La/a;->K(Lkotlin/jvm/functions/Function0;)Ll30/o;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    iput-object p2, p0, Lac/f;->d:Ll30/o;

    .line 31
    .line 32
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    const p2, 0x7f070370

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    iput p1, p0, Lac/f;->e:I

    .line 44
    .line 45
    new-instance p1, Landroid/graphics/Rect;

    .line 46
    .line 47
    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    .line 48
    .line 49
    .line 50
    iput-object p1, p0, Lac/f;->f:Landroid/graphics/Rect;

    .line 51
    .line 52
    return-void
.end method


# virtual methods
.method public final g(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;II)V
    .registers 14

    .line 1
    iget-object p2, p0, Lac/f;->f:Landroid/graphics/Rect;

    .line 2
    .line 3
    const-string v0, "canvas"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    :try_start_b
    invoke-static {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->O(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 13
    .line 14
    .line 15
    iget-object p3, p0, Lac/f;->c:Ll30/o;

    .line 16
    .line 17
    invoke-virtual {p3}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p3

    .line 21
    check-cast p3, Landroid/graphics/drawable/PaintDrawable;

    .line 22
    .line 23
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    const/4 v2, 0x2

    .line 28
    div-int/2addr v1, v2

    .line 29
    sub-int v1, p4, v1

    .line 30
    .line 31
    iget v3, p2, Landroid/graphics/Rect;->top:I

    .line 32
    .line 33
    add-int/2addr v3, p5

    .line 34
    int-to-double p4, p4

    .line 35
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    int-to-double v4, v4

    .line 40
    int-to-double v6, v2

    .line 41
    div-double/2addr v4, v6

    .line 42
    add-double/2addr v4, p4

    .line 43
    invoke-static {v4, v5}, Ljava/lang/Math;->ceil(D)D

    .line 44
    .line 45
    .line 46
    move-result-wide p4

    .line 47
    double-to-int p4, p4

    .line 48
    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    .line 49
    .line 50
    invoke-virtual {p3, v1, v3, p4, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V
    :try_end_37
    .catchall {:try_start_b .. :try_end_37} :catchall_3b

    .line 54
    .line 55
    .line 56
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :catchall_3b
    move-exception p2

    .line 61
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 62
    .line 63
    .line 64
    throw p2
.end method

###### Class ac.e (ac.e)
.class public final synthetic Lac/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Lac/f;


# direct methods
.method public synthetic constructor <init>(Lac/f;I)V
    .registers 3

    .line 1
    iput p2, p0, Lac/e;->d:I

    iput-object p1, p0, Lac/e;->e:Lac/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lac/e;->d:I

    .line 2
    .line 3
    iget-object v1, p0, Lac/e;->e:Lac/f;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_4a

    .line 6
    .line 7
    .line 8
    new-instance v0, Lcom/discord/channel_spine/ChannelSpineView;

    .line 9
    .line 10
    iget-object v1, v1, Lac/f;->a:Landroid/content/Context;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x2

    .line 14
    invoke-direct {v0, v1, v2, v3, v2}, Lcom/discord/channel_spine/ChannelSpineView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 15
    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    invoke-virtual {v0, v1}, Lcom/discord/channel_spine/ChannelSpineView;->setVerticalPadding(I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const v2, 0x7f07046d

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-virtual {v0, v1}, Lcom/discord/channel_spine/ChannelSpineView;->setHorizontalPadding(I)V

    .line 37
    .line 38
    .line 39
    const/4 v1, 0x1

    .line 40
    invoke-virtual {v0, v1}, Lcom/discord/channel_spine/ChannelSpineView;->setNumRows(I)V

    .line 41
    .line 42
    .line 43
    return-object v0

    .line 44
    :pswitch_2b
    new-instance v0, Landroid/graphics/drawable/PaintDrawable;

    .line 45
    .line 46
    invoke-static {}, Ljk/l0;->a()Ljk/i;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {v2}, Ljk/i;->I()I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    invoke-direct {v0, v2}, Landroid/graphics/drawable/PaintDrawable;-><init>(I)V

    .line 55
    .line 56
    .line 57
    iget-object v1, v1, Lac/f;->a:Landroid/content/Context;

    .line 58
    .line 59
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    const v2, 0x7f07046b

    .line 64
    .line 65
    .line 66
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/ShapeDrawable;->setIntrinsicWidth(I)V

    .line 71
    .line 72
    .line 73
    return-object v0

    .line 74
    nop

    .line 75
    :pswitch_data_4a
    .packed-switch 0x0
        :pswitch_2b
    .end packed-switch
.end method
