###### Class ac.b (ac.b)
.class public final synthetic Lac/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lac/b;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Lac/b;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    packed-switch v0, :pswitch_data_1c0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lfg/c;

    .line 9
    .line 10
    const-string v0, "it"

    .line 11
    .line 12
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_11
    check-cast p1, Leg/n;

    .line 19
    .line 20
    const-string v0, "it"

    .line 21
    .line 22
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 26
    .line 27
    return-object p1

    .line 28
    :pswitch_1b
    check-cast p1, Lfg/c;

    .line 29
    .line 30
    const-string v0, "it"

    .line 31
    .line 32
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 36
    .line 37
    return-object p1

    .line 38
    :pswitch_25
    check-cast p1, Ljava/lang/Float;

    .line 39
    .line 40
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 44
    .line 45
    return-object p1

    .line 46
    :pswitch_2d
    check-cast p1, Leg/n;

    .line 47
    .line 48
    const-string v0, "it"

    .line 49
    .line 50
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 54
    .line 55
    return-object p1

    .line 56
    :pswitch_37
    check-cast p1, Lcom/facebook/react/bridge/WritableMap;

    .line 57
    .line 58
    const-string v0, "<this>"

    .line 59
    .line 60
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 64
    .line 65
    return-object p1

    .line 66
    :pswitch_41
    check-cast p1, Lcom/margelo/nitro/rive/RiveError;

    .line 67
    .line 68
    invoke-static {p1}, Lcom/margelo/nitro/rive/HybridRiveView;->m(Lcom/margelo/nitro/rive/RiveError;)Ll30/a0;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    return-object p1

    .line 73
    :pswitch_48
    check-cast p1, Ljava/lang/ref/WeakReference;

    .line 74
    .line 75
    invoke-static {p1}, Lcom/margelo/nitro/rive/HybridRiveFile;->a(Ljava/lang/ref/WeakReference;)Z

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    return-object p1

    .line 84
    :pswitch_53
    check-cast p1, Lorg/chromium/net/UrlRequest$Builder;

    .line 85
    .line 86
    const-string v0, "it"

    .line 87
    .line 88
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p1}, Lorg/chromium/net/UrlRequest$Builder;->disableCache()Lorg/chromium/net/UrlRequest$Builder;

    .line 92
    .line 93
    .line 94
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 95
    .line 96
    return-object p1

    .line 97
    :pswitch_60
    check-cast p1, Ljava/lang/String;

    .line 98
    .line 99
    const-string v0, "it"

    .line 100
    .line 101
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 105
    .line 106
    return-object p1

    .line 107
    :pswitch_6a
    check-cast p1, Lcom/margelo/nitro/nitrofetch/NitroResponse;

    .line 108
    .line 109
    return-object p1

    .line 110
    :pswitch_6d
    check-cast p1, Lio/sentry/protocol/z;

    .line 111
    .line 112
    sget-object v0, Lcom/discord/crash_reporting/CrashReporting;->INSTANCE:Lcom/discord/crash_reporting/CrashReporting;

    .line 113
    .line 114
    const/4 v0, -0x1

    .line 115
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    const-string v1, "frame"

    .line 120
    .line 121
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    new-instance v1, Ljava/lang/StringBuilder;

    .line 125
    .line 126
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 127
    .line 128
    .line 129
    iget-object v3, p1, Lio/sentry/protocol/z;->v:Ljava/lang/String;

    .line 130
    .line 131
    if-eqz v3, :cond_87

    .line 132
    .line 133
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    :cond_87
    iget-object v3, p1, Lio/sentry/protocol/z;->y:Ljava/lang/Integer;

    .line 137
    .line 138
    if-eqz v3, :cond_8c

    .line 139
    .line 140
    goto :goto_93

    .line 141
    :cond_8c
    iget-object v3, p1, Lio/sentry/protocol/z;->J:Ljava/lang/Integer;

    .line 142
    .line 143
    if-eqz v3, :cond_92

    .line 144
    .line 145
    move-object v3, v0

    .line 146
    goto :goto_93

    .line 147
    :cond_92
    move-object v3, v2

    .line 148
    :goto_93
    iget-object v4, p1, Lio/sentry/protocol/z;->J:Ljava/lang/Integer;

    .line 149
    .line 150
    if-eqz v4, :cond_99

    .line 151
    .line 152
    move-object v2, v4

    .line 153
    goto :goto_9c

    .line 154
    :cond_99
    if-eqz v3, :cond_9c

    .line 155
    .line 156
    move-object v2, v0

    .line 157
    :cond_9c
    :goto_9c
    if-eqz v3, :cond_bc

    .line 158
    .line 159
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    .line 164
    .line 165
    .line 166
    move-result v3

    .line 167
    const/16 v4, 0x3a

    .line 168
    .line 169
    if-lez v3, :cond_ad

    .line 170
    .line 171
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    :cond_ad
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    if-eqz v2, :cond_bc

    .line 178
    .line 179
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 187
    .line 188
    .line 189
    :cond_bc
    iget-object p1, p1, Lio/sentry/protocol/z;->w:Ljava/lang/String;

    .line 190
    .line 191
    if-eqz p1, :cond_cd

    .line 192
    .line 193
    const-string v0, " ("

    .line 194
    .line 195
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 199
    .line 200
    .line 201
    const/16 p1, 0x29

    .line 202
    .line 203
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    :cond_cd
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    return-object p1

    .line 211
    :pswitch_d2
    check-cast p1, Lo70/f;

    .line 212
    .line 213
    const-string v0, "$this$Json"

    .line 214
    .line 215
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 216
    .line 217
    .line 218
    iput-boolean v1, p1, Lo70/f;->c:Z

    .line 219
    .line 220
    iput-boolean v1, p1, Lo70/f;->d:Z

    .line 221
    .line 222
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 223
    .line 224
    return-object p1

    .line 225
    :pswitch_e0
    check-cast p1, Ljava/lang/String;

    .line 226
    .line 227
    const-string v0, "it"

    .line 228
    .line 229
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 233
    .line 234
    return-object p1

    .line 235
    :pswitch_ea
    check-cast p1, Ljava/lang/String;

    .line 236
    .line 237
    const-string v0, "it"

    .line 238
    .line 239
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 243
    .line 244
    return-object p1

    .line 245
    :pswitch_f4
    check-cast p1, Ljava/lang/String;

    .line 246
    .line 247
    const-string v0, "it"

    .line 248
    .line 249
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 253
    .line 254
    return-object p1

    .line 255
    :pswitch_fe
    check-cast p1, Ljava/lang/Boolean;

    .line 256
    .line 257
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 258
    .line 259
    .line 260
    sget p1, Lce/c;->e:I

    .line 261
    .line 262
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 263
    .line 264
    return-object p1

    .line 265
    :pswitch_108
    check-cast p1, Ljava/lang/Exception;

    .line 266
    .line 267
    const-string v0, "it"

    .line 268
    .line 269
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 273
    .line 274
    return-object p1

    .line 275
    :pswitch_112
    check-cast p1, Ljava/lang/Exception;

    .line 276
    .line 277
    const-string v0, "e"

    .line 278
    .line 279
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    return-object p1

    .line 283
    :pswitch_11a
    check-cast p1, Ljava/lang/Exception;

    .line 284
    .line 285
    sget v0, Lcom/discord/recycler_view/utils/TransitionResilientGridLayoutManager;->t0:I

    .line 286
    .line 287
    const-string v0, "e"

    .line 288
    .line 289
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 290
    .line 291
    .line 292
    return-object p1

    .line 293
    :pswitch_124
    check-cast p1, Lcom/discord/primitives/ChannelId;

    .line 294
    .line 295
    sget p1, Lbh/p;->b0:I

    .line 296
    .line 297
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 298
    .line 299
    return-object p1

    .line 300
    :pswitch_12b
    check-cast p1, Ljava/lang/String;

    .line 301
    .line 302
    const-string v0, "it"

    .line 303
    .line 304
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 305
    .line 306
    .line 307
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 308
    .line 309
    return-object p1

    .line 310
    :pswitch_135
    check-cast p1, Lbh/e;

    .line 311
    .line 312
    const-string v0, "it"

    .line 313
    .line 314
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 318
    .line 319
    return-object p1

    .line 320
    :pswitch_13f
    check-cast p1, Landroid/view/MotionEvent;

    .line 321
    .line 322
    const-string v0, "it"

    .line 323
    .line 324
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 328
    .line 329
    return-object p1

    .line 330
    :pswitch_149
    check-cast p1, Ljava/lang/String;

    .line 331
    .line 332
    const-string v0, "mimeType"

    .line 333
    .line 334
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 335
    .line 336
    .line 337
    new-instance v0, Ljava/lang/StringBuilder;

    .line 338
    .line 339
    const-string v1, "\'"

    .line 340
    .line 341
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 345
    .line 346
    .line 347
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 348
    .line 349
    .line 350
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 351
    .line 352
    .line 353
    move-result-object p1

    .line 354
    return-object p1

    .line 355
    :pswitch_162
    check-cast p1, Ljava/lang/String;

    .line 356
    .line 357
    const-string v0, "ext"

    .line 358
    .line 359
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 360
    .line 361
    .line 362
    new-instance v0, Ljava/lang/StringBuilder;

    .line 363
    .line 364
    const-string v1, "_display_name LIKE \'%."

    .line 365
    .line 366
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 370
    .line 371
    .line 372
    const-string p1, "\'"

    .line 373
    .line 374
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 375
    .line 376
    .line 377
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object p1

    .line 381
    return-object p1

    .line 382
    :pswitch_17d
    sget-object p1, Lb0/e;->b:Ljava/lang/Object;

    .line 383
    .line 384
    monitor-enter p1

    .line 385
    :try_start_180
    sget-object v0, Lb0/e;->f:Lm30/s;

    .line 386
    .line 387
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_185
    .catchall {:try_start_180 .. :try_end_185} :catchall_189

    .line 388
    .line 389
    .line 390
    monitor-exit p1

    .line 391
    sget-object p1, Ll30/a0;->a:Ll30/a0;

    .line 392
    .line 393
    return-object p1

    .line 394
    :catchall_189
    move-exception v0

    .line 395
    monitor-exit p1

    .line 396
    throw v0

    .line 397
    :pswitch_18c
    check-cast p1, Lwb/d;

    .line 398
    .line 399
    const-string v0, "it"

    .line 400
    .line 401
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 402
    .line 403
    .line 404
    invoke-static {p1}, Lcom/facebook/react/uimanager/b0;->k(Lwb/d;)Lq9/c;

    .line 405
    .line 406
    .line 407
    move-result-object p1

    .line 408
    if-eqz p1, :cond_19a

    .line 409
    .line 410
    goto :goto_19b

    .line 411
    :cond_19a
    const/4 v1, 0x0

    .line 412
    :goto_19b
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 413
    .line 414
    .line 415
    move-result-object p1

    .line 416
    return-object p1

    .line 417
    :pswitch_1a0
    check-cast p1, Lwb/d;

    .line 418
    .line 419
    const-string v0, "it"

    .line 420
    .line 421
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    invoke-static {p1}, Lcom/facebook/react/uimanager/b0;->k(Lwb/d;)Lq9/c;

    .line 425
    .line 426
    .line 427
    move-result-object p1

    .line 428
    if-eqz p1, :cond_1af

    .line 429
    .line 430
    iget-object v2, p1, Lq9/c;->b:Ljava/lang/Integer;

    .line 431
    .line 432
    :cond_1af
    return-object v2

    .line 433
    :pswitch_1b0
    check-cast p1, Lwb/d;

    .line 434
    .line 435
    const-string v0, "it"

    .line 436
    .line 437
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 438
    .line 439
    .line 440
    invoke-static {p1}, Lcom/facebook/react/uimanager/b0;->k(Lwb/d;)Lq9/c;

    .line 441
    .line 442
    .line 443
    move-result-object p1

    .line 444
    if-eqz p1, :cond_1bf

    .line 445
    .line 446
    iget-object v2, p1, Lq9/c;->a:Ljava/lang/Integer;

    .line 447
    .line 448
    :cond_1bf
    return-object v2

    .line 449
    :pswitch_data_1c0
    .packed-switch 0x0
        :pswitch_1b0
        :pswitch_1a0
        :pswitch_18c
        :pswitch_17d
        :pswitch_162
        :pswitch_149
        :pswitch_13f
        :pswitch_135
        :pswitch_12b
        :pswitch_124
        :pswitch_11a
        :pswitch_112
        :pswitch_108
        :pswitch_fe
        :pswitch_f4
        :pswitch_ea
        :pswitch_e0
        :pswitch_d2
        :pswitch_6d
        :pswitch_6a
        :pswitch_60
        :pswitch_53
        :pswitch_48
        :pswitch_41
        :pswitch_37
        :pswitch_2d
        :pswitch_25
        :pswitch_1b
        :pswitch_11
    .end packed-switch
.end method
