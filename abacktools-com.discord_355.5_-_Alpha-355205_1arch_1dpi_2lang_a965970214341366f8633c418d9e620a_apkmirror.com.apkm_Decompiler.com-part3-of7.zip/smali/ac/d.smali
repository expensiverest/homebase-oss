###### Class ac.d (ac.d)
.class public final Lac/d;
.super Le6/t0;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:Z

.field public final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, Lac/d;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lac/f;

    invoke-direct {v0, p1, p2}, Lac/f;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Lac/d;->c:Ljava/lang/Object;

    const/4 p1, 0x1

    .line 3
    iput-boolean p1, p0, Lac/d;->b:Z

    return-void
.end method

.method public constructor <init>(Lbc/h0;Z)V
    .registers 4

    const/4 v0, 0x0

    iput v0, p0, Lac/d;->a:I

    const-string v0, "margins"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, Lac/d;->c:Ljava/lang/Object;

    .line 6
    iput-boolean p2, p0, Lac/d;->b:Z

    return-void
.end method


# virtual methods
.method public d(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Le6/h1;)V
    .registers 6

    .line 1
    iget v0, p0, Lac/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_3c

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2, p3, p4}, Le6/t0;->d(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Le6/h1;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_9
    iget-object p3, p0, Lac/d;->c:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p3, Lbc/h0;

    .line 13
    .line 14
    const-string v0, "outRect"

    .line 15
    .line 16
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const-string v0, "view"

    .line 20
    .line 21
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const-string v0, "state"

    .line 25
    .line 26
    invoke-static {p4, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    instance-of p4, p2, Lfc/e0;

    .line 30
    .line 31
    if-eqz p4, :cond_21

    .line 32
    .line 33
    goto :goto_3b

    .line 34
    :cond_21
    iget-boolean p4, p0, Lac/d;->b:Z

    .line 35
    .line 36
    iget v0, p3, Lbc/h0;->a:I

    .line 37
    .line 38
    if-nez p4, :cond_28

    .line 39
    .line 40
    goto :goto_35

    .line 41
    :cond_28
    instance-of p4, p2, Lcom/discord/reactions/ShortcutsFlexbox;

    .line 42
    .line 43
    if-eqz p4, :cond_2d

    .line 44
    .line 45
    goto :goto_35

    .line 46
    :cond_2d
    instance-of p2, p2, Lfc/f2;

    .line 47
    .line 48
    if-eqz p2, :cond_32

    .line 49
    .line 50
    goto :goto_35

    .line 51
    :cond_32
    sget p2, Lbc/h0;->e:I

    .line 52
    .line 53
    add-int/2addr v0, p2

    .line 54
    :goto_35
    iput v0, p1, Landroid/graphics/Rect;->left:I

    .line 55
    .line 56
    iget p2, p3, Lbc/h0;->b:I

    .line 57
    .line 58
    iput p2, p1, Landroid/graphics/Rect;->right:I

    .line 59
    .line 60
    :goto_3b
    return-void

    .line 61
    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_9
    .end packed-switch
.end method

.method public e(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Le6/h1;)V
    .registers 15

    .line 1
    iget v0, p0, Lac/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_102

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_6
    const-string v0, "canvas"

    .line 8
    .line 9
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v0, "state"

    .line 13
    .line 14
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-boolean p3, p0, Lac/d;->b:Z

    .line 18
    .line 19
    if-nez p3, :cond_16

    .line 20
    .line 21
    goto/16 :goto_101

    .line 22
    .line 23
    :cond_16
    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 24
    .line 25
    .line 26
    move-result-object p3

    .line 27
    instance-of v0, p3, Lxc/a;

    .line 28
    .line 29
    if-eqz v0, :cond_21

    .line 30
    .line 31
    check-cast p3, Lxc/a;

    .line 32
    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 p3, 0x0

    .line 35
    :goto_22
    if-eqz p3, :cond_101

    .line 36
    .line 37
    invoke-interface {p3}, Lxc/a;->getSpineOriginView()Landroid/view/View;

    .line 38
    .line 39
    .line 40
    move-result-object p3

    .line 41
    if-nez p3, :cond_2c

    .line 42
    .line 43
    goto/16 :goto_101

    .line 44
    .line 45
    :cond_2c
    invoke-virtual {p3}, Landroid/view/View;->getLeft()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-virtual {p3}, Landroid/view/View;->getMeasuredWidth()I

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    const/4 v1, 0x2

    .line 54
    div-int/2addr p3, v1

    .line 55
    add-int v6, p3, v0

    .line 56
    .line 57
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 58
    .line 59
    .line 60
    move-result p3

    .line 61
    const/4 v0, 0x0

    .line 62
    move v8, v0

    .line 63
    :goto_3e
    if-ge v8, p3, :cond_101

    .line 64
    .line 65
    invoke-virtual {p2, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    if-eqz v5, :cond_f9

    .line 70
    .line 71
    instance-of v2, v5, Lfc/f2;

    .line 72
    .line 73
    if-eqz v2, :cond_cd

    .line 74
    .line 75
    iget-object v2, p0, Lac/d;->c:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v2, Lac/f;

    .line 78
    .line 79
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    :try_start_55
    iget-object v4, v2, Lac/f;->f:Landroid/graphics/Rect;

    .line 87
    .line 88
    invoke-static {v5, v4}, Landroidx/recyclerview/widget/RecyclerView;->O(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 92
    .line 93
    .line 94
    move-result v4

    .line 95
    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 96
    .line 97
    .line 98
    move-result v7

    .line 99
    invoke-virtual {v5}, Landroid/view/View;->getBottom()I

    .line 100
    .line 101
    .line 102
    move-result v9

    .line 103
    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 104
    .line 105
    .line 106
    move-result v5

    .line 107
    sub-int/2addr v9, v5

    .line 108
    div-int/2addr v9, v1

    .line 109
    add-int/2addr v7, v9

    .line 110
    iget v5, v2, Lac/f;->e:I

    .line 111
    .line 112
    add-int/2addr v7, v5

    .line 113
    new-instance v5, Landroid/graphics/Rect;

    .line 114
    .line 115
    iget-object v9, v2, Lac/f;->c:Ll30/o;

    .line 116
    .line 117
    invoke-virtual {v9}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v9

    .line 121
    check-cast v9, Landroid/graphics/drawable/PaintDrawable;

    .line 122
    .line 123
    invoke-virtual {v9}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    div-int/2addr v9, v1

    .line 128
    sub-int v9, v6, v9

    .line 129
    .line 130
    iget v10, v2, Lac/f;->b:I

    .line 131
    .line 132
    invoke-direct {v5, v9, v4, v10, v7}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 133
    .line 134
    .line 135
    iget-object v2, v2, Lac/f;->d:Ll30/o;

    .line 136
    .line 137
    invoke-virtual {v2}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    check-cast v2, Lcom/discord/channel_spine/ChannelSpineView;

    .line 142
    .line 143
    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    .line 144
    .line 145
    .line 146
    move-result v4

    .line 147
    div-int/2addr v4, v1

    .line 148
    int-to-float v4, v4

    .line 149
    invoke-virtual {v2, v4}, Lcom/discord/channel_spine/ChannelSpineView;->setRowHeight(F)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    .line 153
    .line 154
    .line 155
    move-result v4

    .line 156
    const/high16 v7, 0x40000000    # 2.0f

    .line 157
    .line 158
    invoke-static {v4, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 159
    .line 160
    .line 161
    move-result v4

    .line 162
    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    .line 163
    .line 164
    .line 165
    move-result v9

    .line 166
    invoke-static {v9, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 167
    .line 168
    .line 169
    move-result v7

    .line 170
    invoke-virtual {v2, v4, v7}, Landroid/view/View;->measure(II)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    .line 174
    .line 175
    .line 176
    move-result v4

    .line 177
    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    .line 178
    .line 179
    .line 180
    move-result v7

    .line 181
    invoke-virtual {v2, v0, v0, v4, v7}, Landroid/view/View;->layout(IIII)V

    .line 182
    .line 183
    .line 184
    iget v4, v5, Landroid/graphics/Rect;->left:I

    .line 185
    .line 186
    int-to-float v4, v4

    .line 187
    iget v5, v5, Landroid/graphics/Rect;->top:I

    .line 188
    .line 189
    int-to-float v5, v5

    .line 190
    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v2, p1}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_c3
    .catchall {:try_start_55 .. :try_end_c3} :catchall_c7

    .line 194
    .line 195
    .line 196
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 197
    .line 198
    .line 199
    goto :goto_f9

    .line 200
    :catchall_c7
    move-exception v0

    .line 201
    move-object p2, v0

    .line 202
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 203
    .line 204
    .line 205
    throw p2

    .line 206
    :cond_cd
    instance-of v2, v5, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 207
    .line 208
    if-eqz v2, :cond_ed

    .line 209
    .line 210
    if-nez v8, :cond_e2

    .line 211
    .line 212
    move-object v2, v5

    .line 213
    check-cast v2, Lcom/discord/chat/presentation/message/view/MessageContentView;

    .line 214
    .line 215
    invoke-virtual {v2}, Landroid/widget/TextView;->getLineHeight()I

    .line 216
    .line 217
    .line 218
    move-result v2

    .line 219
    int-to-float v3, v1

    .line 220
    invoke-static {v3}, Lox/b;->k(F)I

    .line 221
    .line 222
    .line 223
    move-result v3

    .line 224
    add-int/2addr v3, v2

    .line 225
    move v7, v3

    .line 226
    goto :goto_e3

    .line 227
    :cond_e2
    move v7, v0

    .line 228
    :goto_e3
    iget-object v2, p0, Lac/d;->c:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast v2, Lac/f;

    .line 231
    .line 232
    move-object v3, p1

    .line 233
    move-object v4, p2

    .line 234
    invoke-virtual/range {v2 .. v7}, Lac/f;->g(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;II)V

    .line 235
    .line 236
    .line 237
    goto :goto_fb

    .line 238
    :cond_ed
    move-object v3, p1

    .line 239
    move-object v4, p2

    .line 240
    iget-object p1, p0, Lac/d;->c:Ljava/lang/Object;

    .line 241
    .line 242
    move-object v2, p1

    .line 243
    check-cast v2, Lac/f;

    .line 244
    .line 245
    const/4 v7, 0x0

    .line 246
    invoke-virtual/range {v2 .. v7}, Lac/f;->g(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;II)V

    .line 247
    .line 248
    .line 249
    goto :goto_fb

    .line 250
    :cond_f9
    :goto_f9
    move-object v3, p1

    .line 251
    move-object v4, p2

    .line 252
    :goto_fb
    add-int/lit8 v8, v8, 0x1

    .line 253
    .line 254
    move-object p1, v3

    .line 255
    move-object p2, v4

    .line 256
    goto/16 :goto_3e

    .line 257
    .line 258
    :cond_101
    :goto_101
    return-void

    .line 259
    :pswitch_data_102
    .packed-switch 0x1
        :pswitch_6
    .end packed-switch
.end method
