###### Class ac.a (ac.a)
.class public final Lac/a;
.super Le6/t0;
.source "SourceFile"


# instance fields
.field public final a:Lac/c;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Lac/c;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Lac/c;-><init>(Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lac/a;->a:Lac/c;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final e(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Le6/h1;)V
    .registers 12

    .line 1
    iget-object v0, p0, Lac/a;->a:Lac/c;

    .line 2
    .line 3
    const-string v1, "canvas"

    .line 4
    .line 5
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v1, "state"

    .line 9
    .line 10
    invoke-static {p3, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 14
    .line 15
    .line 16
    move-result p3

    .line 17
    :try_start_10
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Le6/n0;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v2, "null cannot be cast to non-null type com.discord.chat.presentation.list.ChatListAdapter"

    .line 22
    .line 23
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    check-cast v1, Lub/b;

    .line 27
    .line 28
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    const/4 v3, 0x0

    .line 33
    :goto_20
    if-ge v3, v2, :cond_a5

    .line 34
    .line 35
    invoke-virtual {p2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    invoke-static {v4}, Landroidx/recyclerview/widget/RecyclerView;->N(Landroid/view/View;)Le6/l1;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    if-eqz v5, :cond_31

    .line 44
    .line 45
    invoke-virtual {v5}, Le6/l1;->e()I

    .line 46
    .line 47
    .line 48
    move-result v5

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    const/4 v5, -0x1

    .line 51
    :goto_32
    if-ltz v5, :cond_a1

    .line 52
    .line 53
    iget-object v6, v1, Lub/b;->e:Ljava/lang/Object;

    .line 54
    .line 55
    const-string v7, "items"

    .line 56
    .line 57
    invoke-static {v6, v7}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    check-cast v6, Ljava/util/List;

    .line 61
    .line 62
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 63
    .line 64
    .line 65
    move-result v6

    .line 66
    if-lt v5, v6, :cond_44

    .line 67
    .line 68
    goto :goto_a1

    .line 69
    :cond_44
    iget-object v6, v1, Lub/b;->f:Ljava/util/List;

    .line 70
    .line 71
    invoke-static {v5, v6}, Lm30/q;->q0(ILjava/util/List;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    check-cast v6, Lwb/d;

    .line 76
    .line 77
    if-nez v6, :cond_73

    .line 78
    .line 79
    sget-object p2, Lnf/a;->a:Lnf/a;

    .line 80
    .line 81
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    .line 83
    .line 84
    move-result-object p2

    .line 85
    invoke-virtual {p2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object p2

    .line 89
    new-instance v0, Ljava/lang/StringBuilder;

    .line 90
    .line 91
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 92
    .line 93
    .line 94
    const-string v1, "Missing item in position "

    .line 95
    .line 96
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    const/4 v1, 0x0

    .line 107
    invoke-static {p2, v0, v1}, Lnf/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_6d
    .catchall {:try_start_10 .. :try_end_6d} :catchall_71

    .line 108
    .line 109
    .line 110
    invoke-virtual {p1, p3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :catchall_71
    move-exception p2

    .line 115
    goto :goto_a9

    .line 116
    :cond_73
    :try_start_73
    iget-object v5, v0, Lac/c;->e:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast v5, Lac/b;

    .line 119
    .line 120
    invoke-virtual {v5, v6}, Lac/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v5

    .line 124
    check-cast v5, Ljava/lang/Boolean;

    .line 125
    .line 126
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 127
    .line 128
    .line 129
    move-result v5

    .line 130
    if-eqz v5, :cond_a1

    .line 131
    .line 132
    iget-object v5, v0, Lac/c;->c:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v5, Lac/b;

    .line 135
    .line 136
    invoke-virtual {v5, v6}, Lac/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v5

    .line 140
    check-cast v5, Ljava/lang/Integer;

    .line 141
    .line 142
    iput-object v5, v0, Lac/c;->h:Ljava/io/Serializable;

    .line 143
    .line 144
    iget-object v5, v0, Lac/c;->d:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v5, Lac/b;

    .line 147
    .line 148
    invoke-virtual {v5, v6}, Lac/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v5

    .line 152
    check-cast v5, Ljava/lang/Integer;

    .line 153
    .line 154
    iput-object v5, v0, Lac/c;->i:Ljava/lang/Object;

    .line 155
    .line 156
    invoke-static {v4}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v0, p1, v4}, Lac/c;->b(Landroid/graphics/Canvas;Landroid/view/View;)V
    :try_end_a1
    .catchall {:try_start_73 .. :try_end_a1} :catchall_71

    .line 160
    .line 161
    .line 162
    :cond_a1
    :goto_a1
    add-int/lit8 v3, v3, 0x1

    .line 163
    .line 164
    goto/16 :goto_20

    .line 165
    .line 166
    :cond_a5
    invoke-virtual {p1, p3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 167
    .line 168
    .line 169
    return-void

    .line 170
    :goto_a9
    invoke-virtual {p1, p3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 171
    .line 172
    .line 173
    throw p2
.end method
