###### Class a50.f (a50.f)
.class public abstract synthetic La50/f;
.super Lkotlin/jvm/internal/m;
.source "SourceFile"


# static fields
.field public static final synthetic e:I

.field public static final synthetic i:I

.field public static final synthetic v:I

.field public static final synthetic w:I
