###### Class a50.i (a50.i)
.class public final La50/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:I

.field public c:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput p1, p0, La50/i;->a:I

    return-void
.end method

.method public synthetic constructor <init>(III)V
    .registers 4

    .line 1
    iput p1, p0, La50/i;->a:I

    iput p2, p0, La50/i;->b:I

    iput p3, p0, La50/i;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lny/f;I)V
    .registers 4

    const-string v0, "field"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    iget v0, p1, Lny/f;->b:I

    iget p1, p1, Lny/f;->c:I

    invoke-direct {p0, v0, p1, p2}, La50/i;-><init>(III)V

    return-void
.end method

.method public constructor <init>(Lq50/b;)V
    .registers 3

    const-string v0, "field"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 3
    invoke-direct {p0, p1, v0}, La50/i;-><init>(Lny/f;I)V

    return-void
.end method


# virtual methods
.method public a()Lmr/i;
    .registers 3

    .line 1
    iget v0, p0, La50/i;->b:I

    .line 2
    .line 3
    iget v1, p0, La50/i;->c:I

    .line 4
    .line 5
    if-gt v0, v1, :cond_8

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 v0, 0x0

    .line 10
    :goto_9
    invoke-static {v0}, Lqt/a;->g(Z)V

    .line 11
    .line 12
    .line 13
    new-instance v0, Lmr/i;

    .line 14
    .line 15
    invoke-direct {v0, p0}, Lmr/i;-><init>(La50/i;)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method
