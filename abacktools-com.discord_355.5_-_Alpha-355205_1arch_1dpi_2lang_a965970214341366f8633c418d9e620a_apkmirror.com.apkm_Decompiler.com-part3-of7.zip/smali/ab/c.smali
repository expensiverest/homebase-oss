###### Class ab.c (ab.c)
.class public final Lab/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lj70/b;


# static fields
.field public static final a:Lab/c;

.field public static final b:Ln70/z0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lab/c;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lab/c;->a:Lab/c;

    .line 7
    .line 8
    const-string v0, "AnnotatedStructurableText"

    .line 9
    .line 10
    sget-object v1, Ll70/e;->M:Ll70/e;

    .line 11
    .line 12
    invoke-static {v0, v1}, Lk80/d;->a(Ljava/lang/String;Ll70/f;)Ln70/z0;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lab/c;->b:Ln70/z0;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 5

    .line 1
    new-instance v0, Ln70/d;

    .line 2
    .line 3
    sget-object v1, Ly9/w;->Companion:Ly9/v;

    .line 4
    .line 5
    invoke-virtual {v1}, Ly9/v;->serializer()Lj70/b;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v0, v1, v2}, Ln70/d;-><init>(Lj70/b;I)V

    .line 11
    .line 12
    .line 13
    invoke-interface {p1, v0}, Lm70/c;->A(Lj70/b;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    check-cast p1, Ljava/util/List;

    .line 18
    .line 19
    new-instance v0, Lab/b;

    .line 20
    .line 21
    invoke-direct {v0, p1}, Lab/b;-><init>(Ljava/util/List;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p2, Lab/b;

    .line 2
    .line 3
    const-string p1, "value"

    .line 4
    .line 5
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lab/c;->b:Ln70/z0;

    .line 2
    .line 3
    return-object v0
.end method
