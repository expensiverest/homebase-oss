###### Class ab.f (ab.f)
.class public final Lab/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lj70/b;


# static fields
.field public static final a:Lab/f;

.field public static final b:Ln70/z0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lab/f;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lab/f;->a:Lab/f;

    .line 7
    .line 8
    const-string v0, "PrimitiveStructurableText"

    .line 9
    .line 10
    sget-object v1, Ll70/e;->M:Ll70/e;

    .line 11
    .line 12
    invoke-static {v0, v1}, Lk80/d;->a(Ljava/lang/String;Ll70/f;)Ln70/z0;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    sput-object v0, Lab/f;->b:Ln70/z0;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a(Lm70/c;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p1}, Lm70/c;->r()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    new-instance v0, Lab/e;

    .line 6
    .line 7
    invoke-direct {v0, p1}, Lab/e;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method

.method public final c(Lm70/d;Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p2, Lab/e;

    .line 2
    .line 3
    const-string p1, "value"

    .line 4
    .line 5
    invoke-static {p2, p1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 11
    .line 12
    .line 13
    throw p1
.end method

.method public final d()Ll70/g;
    .registers 2

    .line 1
    sget-object v0, Lab/f;->b:Ln70/z0;

    .line 2
    .line 3
    return-object v0
.end method
