###### Class ab.i (ab.i)
.class public final Lab/i;
.super Ln70/f0;
.source "SourceFile"


# static fields
.field public static final d:Lab/i;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lab/i;

    .line 2
    .line 3
    const-class v1, Lab/h;

    .line 4
    .line 5
    sget-object v2, Lkotlin/jvm/internal/v;->a:Lkotlin/jvm/internal/w;

    .line 6
    .line 7
    invoke-virtual {v2, v1}, Lkotlin/jvm/internal/w;->b(Ljava/lang/Class;)Lh40/d;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Ln70/f0;-><init>(Lh40/d;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lab/i;->d:Lab/i;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final g(Lkotlinx/serialization/json/b;)Lj70/b;
    .registers 5

    .line 1
    const-string v0, "element"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    instance-of v0, p1, Lkotlinx/serialization/json/d;

    .line 7
    .line 8
    if-eqz v0, :cond_c

    .line 9
    .line 10
    sget-object p1, Lab/f;->a:Lab/f;

    .line 11
    .line 12
    return-object p1

    .line 13
    :cond_c
    instance-of v0, p1, Lkotlinx/serialization/json/a;

    .line 14
    .line 15
    if-eqz v0, :cond_13

    .line 16
    .line 17
    sget-object p1, Lab/c;->a:Lab/c;

    .line 18
    .line 19
    return-object p1

    .line 20
    :cond_13
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 21
    .line 22
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    const-string v2, "unable to find serializer for json: "

    .line 25
    .line 26
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw v0
.end method
