###### Class ab.h (ab.h)
.class public abstract Lab/h;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lj70/h;
    with = Lab/i;
.end annotation


# static fields
.field public static final Companion:Lab/g;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lab/g;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lab/h;->Companion:Lab/g;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public abstract a()Z
.end method
