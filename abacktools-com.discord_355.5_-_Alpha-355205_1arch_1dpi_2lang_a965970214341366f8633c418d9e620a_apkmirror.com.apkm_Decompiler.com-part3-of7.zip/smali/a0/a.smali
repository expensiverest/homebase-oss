###### Class a0.a (a0.a)
.class public interface abstract La0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/Object;)Ljava/lang/Object;
.end method
