###### Class an.b (an.b)
.class public Lan/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final d:Lan/b;


# instance fields
.field public final a:Z

.field public final b:Landroid/graphics/Bitmap$Config;

.field public final c:Landroid/graphics/Bitmap$Config;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lan/c;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lan/c;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 8
    .line 9
    iput-object v1, v0, Lan/c;->i:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object v1, v0, Lan/c;->v:Ljava/lang/Object;

    .line 12
    .line 13
    new-instance v1, Lan/b;

    .line 14
    .line 15
    invoke-direct {v1, v0}, Lan/b;-><init>(Lan/c;)V

    .line 16
    .line 17
    .line 18
    sput-object v1, Lan/b;->d:Lan/b;

    .line 19
    .line 20
    return-void
.end method

.method public constructor <init>(Lan/c;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p1, Lan/c;->e:Z

    .line 5
    .line 6
    iput-boolean v0, p0, Lan/b;->a:Z

    .line 7
    .line 8
    iget-object v0, p1, Lan/c;->i:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Landroid/graphics/Bitmap$Config;

    .line 11
    .line 12
    iput-object v0, p0, Lan/b;->b:Landroid/graphics/Bitmap$Config;

    .line 13
    .line 14
    iget-object p1, p1, Lan/c;->v:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p1, Landroid/graphics/Bitmap$Config;

    .line 17
    .line 18
    iput-object p1, p0, Lan/b;->c:Landroid/graphics/Bitmap$Config;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    if-eqz p1, :cond_29

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    if-eq v1, v2, :cond_11

    .line 16
    .line 17
    goto :goto_29

    .line 18
    :cond_11
    check-cast p1, Lan/b;

    .line 19
    .line 20
    iget-boolean v1, p0, Lan/b;->a:Z

    .line 21
    .line 22
    iget-boolean v2, p1, Lan/b;->a:Z

    .line 23
    .line 24
    if-eq v1, v2, :cond_1a

    .line 25
    .line 26
    goto :goto_29

    .line 27
    :cond_1a
    iget-object v1, p0, Lan/b;->b:Landroid/graphics/Bitmap$Config;

    .line 28
    .line 29
    iget-object v2, p1, Lan/b;->b:Landroid/graphics/Bitmap$Config;

    .line 30
    .line 31
    if-eq v1, v2, :cond_21

    .line 32
    .line 33
    goto :goto_29

    .line 34
    :cond_21
    iget-object v1, p0, Lan/b;->c:Landroid/graphics/Bitmap$Config;

    .line 35
    .line 36
    iget-object p1, p1, Lan/b;->c:Landroid/graphics/Bitmap$Config;

    .line 37
    .line 38
    if-eq v1, p1, :cond_28

    .line 39
    .line 40
    goto :goto_29

    .line 41
    :cond_28
    return v0

    .line 42
    :cond_29
    :goto_29
    const/4 p1, 0x0

    .line 43
    return p1
.end method

.method public final hashCode()I
    .registers 3

    .line 1
    const v0, 0x283a4cc5

    .line 2
    .line 3
    .line 4
    iget-boolean v1, p0, Lan/b;->a:Z

    .line 5
    .line 6
    add-int/2addr v0, v1

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Lan/b;->b:Landroid/graphics/Bitmap$Config;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lan/b;->c:Landroid/graphics/Bitmap$Config;

    .line 19
    .line 20
    if-eqz v0, :cond_1a

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v0, 0x0

    .line 28
    :goto_1b
    add-int/2addr v1, v0

    .line 29
    mul-int/lit16 v1, v1, 0x745f

    .line 30
    .line 31
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "ImageDecodeOptions{"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p0}, Lfl/j;->j(Ljava/lang/Object;)Lfb/l;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/16 v2, 0x64

    .line 13
    .line 14
    const-string v3, "minDecodeIntervalMs"

    .line 15
    .line 16
    invoke-virtual {v1, v2, v3}, Lfb/l;->j(ILjava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const v2, 0x7fffffff

    .line 20
    .line 21
    .line 22
    const-string v3, "maxDimensionPx"

    .line 23
    .line 24
    invoke-virtual {v1, v2, v3}, Lfb/l;->j(ILjava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const-string v2, "decodePreviewFrame"

    .line 28
    .line 29
    const/4 v3, 0x0

    .line 30
    invoke-virtual {v1, v2, v3}, Lfb/l;->k(Ljava/lang/String;Z)V

    .line 31
    .line 32
    .line 33
    const-string v2, "useLastFrameForPreview"

    .line 34
    .line 35
    invoke-virtual {v1, v2, v3}, Lfb/l;->k(Ljava/lang/String;Z)V

    .line 36
    .line 37
    .line 38
    const-string v2, "useEncodedImageForPreview"

    .line 39
    .line 40
    invoke-virtual {v1, v2, v3}, Lfb/l;->k(Ljava/lang/String;Z)V

    .line 41
    .line 42
    .line 43
    const-string v2, "decodeAllFrames"

    .line 44
    .line 45
    invoke-virtual {v1, v2, v3}, Lfb/l;->k(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    iget-boolean v2, p0, Lan/b;->a:Z

    .line 49
    .line 50
    const-string v3, "forceStaticImage"

    .line 51
    .line 52
    invoke-virtual {v1, v3, v2}, Lfb/l;->k(Ljava/lang/String;Z)V

    .line 53
    .line 54
    .line 55
    iget-object v2, p0, Lan/b;->b:Landroid/graphics/Bitmap$Config;

    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    const-string v3, "bitmapConfigName"

    .line 62
    .line 63
    invoke-virtual {v1, v2, v3}, Lfb/l;->l(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    iget-object v2, p0, Lan/b;->c:Landroid/graphics/Bitmap$Config;

    .line 67
    .line 68
    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    const-string v3, "animatedBitmapConfigName"

    .line 73
    .line 74
    invoke-virtual {v1, v2, v3}, Lfb/l;->l(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const-string v2, "customImageDecoder"

    .line 78
    .line 79
    const/4 v3, 0x0

    .line 80
    invoke-virtual {v1, v3, v2}, Lfb/l;->l(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    const-string v2, "bitmapTransformation"

    .line 84
    .line 85
    invoke-virtual {v1, v3, v2}, Lfb/l;->l(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    const-string v2, "colorSpace"

    .line 89
    .line 90
    invoke-virtual {v1, v3, v2}, Lfb/l;->l(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v1}, Lfb/l;->toString()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    const-string v2, "}"

    .line 98
    .line 99
    invoke-static {v0, v1, v2}, Lcom/google/android/gms/internal/fido/nb;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    return-object v0
.end method
