###### Class an.c (an.c)
.class public final Lan/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc4/m;
.implements Ll60/c;


# instance fields
.field public final synthetic d:I

.field public e:Z

.field public i:Ljava/lang/Object;

.field public v:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    const/16 v0, 0x9

    iput v0, p0, Lan/c;->d:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lan/c;->i:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 2
    iput p1, p0, Lan/c;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/16 v0, 0x8

    iput v0, p0, Lan/c;->d:I

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 37
    new-instance p1, Lim/d;

    const/4 v0, 0x4

    .line 38
    invoke-direct {p1, v0}, Lim/d;-><init>(I)V

    const/4 v0, 0x0

    .line 39
    iput v0, p1, Lim/d;->e:I

    .line 40
    iput-object p1, p0, Lan/c;->v:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;Lmr/w;)V
    .registers 5

    const/4 v0, 0x7

    iput v0, p0, Lan/c;->d:I

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 22
    new-instance p1, Lmr/a;

    invoke-direct {p1, p0, p2, p3}, Lmr/a;-><init>(Lan/c;Landroid/os/Handler;Lmr/w;)V

    iput-object p1, p0, Lan/c;->v:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ld20/o;)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, Lan/c;->d:I

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p2, p0, Lan/c;->i:Ljava/lang/Object;

    .line 12
    new-instance p2, Lc20/a;

    invoke-direct {p2, p1}, Lc20/a;-><init>(Landroid/content/Context;)V

    .line 13
    new-instance p1, Lc1/f;

    const/4 v0, -0x1

    invoke-direct {p1, v0, v0}, Lc1/f;-><init>(II)V

    .line 14
    invoke-virtual {p2, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 15
    iput-object p2, p0, Lan/c;->v:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lc4/b;Lc4/b;)V
    .registers 4

    const/4 v0, 0x2

    iput v0, p0, Lan/c;->d:I

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 33
    iput-object p2, p0, Lan/c;->v:Ljava/lang/Object;

    const/4 p1, 0x1

    .line 34
    iput-boolean p1, p0, Lan/c;->e:Z

    return-void
.end method

.method public constructor <init>(Ld50/u;Lb70/u;)V
    .registers 4

    const/4 v0, 0x3

    iput v0, p0, Lan/c;->d:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 6
    iput-object p2, p0, Lan/c;->v:Ljava/lang/Object;

    .line 7
    iget-boolean p1, p1, Ld50/u;->d:Z

    if-nez p1, :cond_1b

    .line 8
    sget-object p1, Ld50/r;->a:Lt50/c;

    .line 9
    invoke-virtual {p2, p1}, Lb70/u;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, Ld50/a0;->e:Ld50/a0;

    if-ne p1, p2, :cond_19

    goto :goto_1b

    :cond_19
    const/4 p1, 0x0

    goto :goto_1c

    :cond_1b
    :goto_1b
    const/4 p1, 0x1

    :goto_1c
    iput-boolean p1, p0, Lan/c;->e:Z

    return-void
.end method

.method public constructor <init>(Lf4/a;)V
    .registers 3

    const/4 v0, 0x4

    iput v0, p0, Lan/c;->d:I

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 28
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 30
    new-instance p1, Lk3/b0;

    invoke-direct {p1}, Lk3/b0;-><init>()V

    iput-object p1, p0, Lan/c;->v:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lio/sentry/android/core/SentryAndroidOptions;)V
    .registers 3

    const/4 v0, 0x5

    iput v0, p0, Lan/c;->d:I

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lan/c;->v:Ljava/lang/Object;

    const/4 v0, 0x0

    .line 25
    iput-boolean v0, p0, Lan/c;->e:Z

    .line 26
    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lio/sentry/j2;Z)V
    .registers 5

    const/4 v0, 0x6

    iput v0, p0, Lan/c;->d:I

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 18
    iput-object p2, p0, Lan/c;->v:Ljava/lang/Object;

    .line 19
    iput-boolean p3, p0, Lan/c;->e:Z

    return-void
.end method

.method public constructor <init>(Lq40/b;Lq40/b;Z)V
    .registers 5

    const/16 v0, 0xa

    iput v0, p0, Lan/c;->d:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p3, p0, Lan/c;->e:Z

    iput-object p1, p0, Lan/c;->i:Ljava/lang/Object;

    iput-object p2, p0, Lan/c;->v:Ljava/lang/Object;

    return-void
.end method

.method public static i(Ljava/io/BufferedInputStream;J)V
    .registers 7

    .line 1
    :goto_0
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v2, p1, v0

    .line 4
    .line 5
    if-lez v2, :cond_23

    .line 6
    .line 7
    invoke-virtual {p0, p1, p2}, Ljava/io/InputStream;->skip(J)J

    .line 8
    .line 9
    .line 10
    move-result-wide v2

    .line 11
    cmp-long v0, v2, v0

    .line 12
    .line 13
    if-nez v0, :cond_21

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/4 v1, -0x1

    .line 20
    if-eq v0, v1, :cond_19

    .line 21
    .line 22
    const-wide/16 v0, 0x1

    .line 23
    .line 24
    sub-long/2addr p1, v0

    .line 25
    goto :goto_0

    .line 26
    :cond_19
    new-instance p0, Ljava/io/EOFException;

    .line 27
    .line 28
    const-string p1, "Unexpected end of stream while skipping bytes"

    .line 29
    .line 30
    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    throw p0

    .line 34
    :cond_21
    sub-long/2addr p1, v2

    .line 35
    goto :goto_0

    .line 36
    :cond_23
    return-void
.end method


# virtual methods
.method public a(Lk60/l0;Lk60/l0;)Z
    .registers 7

    .line 1
    iget-boolean v0, p0, Lan/c;->e:Z

    .line 2
    .line 3
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lq40/b;

    .line 6
    .line 7
    iget-object v2, p0, Lan/c;->v:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Lq40/b;

    .line 10
    .line 11
    const-string v3, "c1"

    .line 12
    .line 13
    invoke-static {p1, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v3, "c2"

    .line 17
    .line 18
    invoke-static {p2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    if-eqz v3, :cond_1c

    .line 26
    .line 27
    const/4 p1, 0x1

    .line 28
    return p1

    .line 29
    :cond_1c
    invoke-interface {p1}, Lk60/l0;->h()Lq40/h;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-interface {p2}, Lk60/l0;->h()Lq40/h;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    instance-of v3, p1, Lq40/q0;

    .line 38
    .line 39
    if-eqz v3, :cond_3d

    .line 40
    .line 41
    instance-of v3, p2, Lq40/q0;

    .line 42
    .line 43
    if-nez v3, :cond_2d

    .line 44
    .line 45
    goto :goto_3d

    .line 46
    :cond_2d
    check-cast p1, Lq40/q0;

    .line 47
    .line 48
    check-cast p2, Lq40/q0;

    .line 49
    .line 50
    new-instance v3, Lw50/b;

    .line 51
    .line 52
    invoke-direct {v3, v1, v2}, Lw50/b;-><init>(Lq40/b;Lq40/b;)V

    .line 53
    .line 54
    .line 55
    sget-object v1, Lw50/c;->d:Lw50/c;

    .line 56
    .line 57
    invoke-virtual {v1, p1, p2, v0, v3}, Lw50/c;->d(Lq40/q0;Lq40/q0;ZLkotlin/jvm/functions/Function2;)Z

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    return p1

    .line 62
    :cond_3d
    :goto_3d
    const/4 p1, 0x0

    .line 63
    return p1
.end method

.method public b(Lb80/i0;)Lc4/c;
    .registers 9

    .line 1
    const-string v0, "createCodec:"

    .line 2
    .line 3
    iget-object v1, p1, Lb80/i0;->i:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lc4/r;

    .line 6
    .line 7
    iget-object v1, v1, Lc4/r;->a:Ljava/lang/String;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    :try_start_9
    new-instance v3, Ljava/lang/StringBuilder;

    .line 11
    .line 12
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-static {v1}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    .line 26
    .line 27
    .line 28
    move-result-object v0
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_1c} :catch_7b

    .line 29
    :try_start_1c
    iget-boolean v1, p0, Lan/c;->e:Z

    .line 30
    .line 31
    if-eqz v1, :cond_2f

    .line 32
    .line 33
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 34
    .line 35
    const/16 v3, 0x24

    .line 36
    .line 37
    if-lt v1, v3, :cond_2f

    .line 38
    .line 39
    new-instance v1, La8/c;

    .line 40
    .line 41
    invoke-direct {v1, v0}, La8/c;-><init>(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    const/4 v3, 0x4

    .line 45
    goto :goto_3f

    .line 46
    :catch_2d
    move-exception p1

    .line 47
    goto :goto_7d

    .line 48
    :cond_2f
    new-instance v1, Lc4/f;

    .line 49
    .line 50
    iget-object v3, p0, Lan/c;->v:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v3, Lc4/b;

    .line 53
    .line 54
    invoke-virtual {v3}, Lc4/b;->get()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    check-cast v3, Landroid/os/HandlerThread;

    .line 59
    .line 60
    invoke-direct {v1, v0, v3}, Lc4/f;-><init>(Landroid/media/MediaCodec;Landroid/os/HandlerThread;)V

    .line 61
    .line 62
    .line 63
    const/4 v3, 0x0

    .line 64
    :goto_3f
    new-instance v4, Lc4/c;

    .line 65
    .line 66
    iget-object v5, p0, Lan/c;->i:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v5, Lc4/b;

    .line 69
    .line 70
    invoke-virtual {v5}, Lc4/b;->get()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    check-cast v5, Landroid/os/HandlerThread;

    .line 75
    .line 76
    iget-object v6, p1, Lb80/i0;->y:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v6, Lc4/l;

    .line 79
    .line 80
    invoke-direct {v4, v0, v5, v1, v6}, Lc4/c;-><init>(Landroid/media/MediaCodec;Landroid/os/HandlerThread;Lc4/o;Lc4/l;)V
    :try_end_52
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_52} :catch_2d

    .line 81
    .line 82
    .line 83
    :try_start_52
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 84
    .line 85
    .line 86
    iget-object v1, p1, Lb80/i0;->w:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v1, Landroid/view/Surface;

    .line 89
    .line 90
    if-nez v1, :cond_6f

    .line 91
    .line 92
    iget-object v2, p1, Lb80/i0;->i:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v2, Lc4/r;

    .line 95
    .line 96
    iget-boolean v2, v2, Lc4/r;->h:Z

    .line 97
    .line 98
    if-eqz v2, :cond_6f

    .line 99
    .line 100
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 101
    .line 102
    const/16 v5, 0x23

    .line 103
    .line 104
    if-lt v2, v5, :cond_6f

    .line 105
    .line 106
    or-int/lit8 v3, v3, 0x8

    .line 107
    .line 108
    goto :goto_6f

    .line 109
    :catch_6c
    move-exception p1

    .line 110
    move-object v2, v4

    .line 111
    goto :goto_7d

    .line 112
    :cond_6f
    :goto_6f
    iget-object v2, p1, Lb80/i0;->e:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v2, Landroid/media/MediaFormat;

    .line 115
    .line 116
    iget-object p1, p1, Lb80/i0;->x:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast p1, Landroid/media/MediaCrypto;

    .line 119
    .line 120
    invoke-static {v4, v2, v1, p1, v3}, Lc4/c;->b(Lc4/c;Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_52 .. :try_end_7a} :catch_6c

    .line 121
    .line 122
    .line 123
    return-object v4

    .line 124
    :catch_7b
    move-exception p1

    .line 125
    move-object v0, v2

    .line 126
    :goto_7d
    if-nez v2, :cond_85

    .line 127
    .line 128
    if-eqz v0, :cond_88

    .line 129
    .line 130
    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    .line 131
    .line 132
    .line 133
    goto :goto_88

    .line 134
    :cond_85
    invoke-virtual {v2}, Lc4/c;->release()V

    .line 135
    .line 136
    .line 137
    :cond_88
    :goto_88
    throw p1
.end method

.method public c(Landroid/os/Handler;Lmr/w;Lmr/w;Lmr/w;Lmr/w;)[Lmr/c;
    .registers 19

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 7
    .line 8
    move-object v3, v1

    .line 9
    check-cast v3, Landroid/content/Context;

    .line 10
    .line 11
    iget-boolean v5, p0, Lan/c;->e:Z

    .line 12
    .line 13
    new-instance v2, Lrt/g;

    .line 14
    .line 15
    iget-object v1, p0, Lan/c;->v:Ljava/lang/Object;

    .line 16
    .line 17
    move-object v4, v1

    .line 18
    check-cast v4, Lim/d;

    .line 19
    .line 20
    move-object v6, p1

    .line 21
    move-object v7, p2

    .line 22
    invoke-direct/range {v2 .. v7}, Lrt/g;-><init>(Landroid/content/Context;Lhs/g;ZLandroid/os/Handler;Lmr/w;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    iget-object p2, p0, Lan/c;->i:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p2, Landroid/content/Context;

    .line 31
    .line 32
    new-instance v1, Lld/d;

    .line 33
    .line 34
    invoke-direct {v1, p2}, Lld/d;-><init>(Landroid/content/Context;)V

    .line 35
    .line 36
    .line 37
    iget-object p2, v1, Lld/d;->v:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p2, Lk3/j0;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    if-nez p2, :cond_34

    .line 43
    .line 44
    new-instance p2, Lk3/j0;

    .line 45
    .line 46
    new-array v3, v2, [Lor/m;

    .line 47
    .line 48
    invoke-direct {p2, v3}, Lk3/j0;-><init>([Lor/m;)V

    .line 49
    .line 50
    .line 51
    iput-object p2, v1, Lld/d;->v:Ljava/lang/Object;

    .line 52
    .line 53
    :cond_34
    new-instance v12, Lor/f0;

    .line 54
    .line 55
    invoke-direct {v12, v1}, Lor/f0;-><init>(Lld/d;)V

    .line 56
    .line 57
    .line 58
    iget-object p2, p0, Lan/c;->i:Ljava/lang/Object;

    .line 59
    .line 60
    move-object v7, p2

    .line 61
    check-cast v7, Landroid/content/Context;

    .line 62
    .line 63
    iget-boolean v9, p0, Lan/c;->e:Z

    .line 64
    .line 65
    new-instance v6, Lor/i0;

    .line 66
    .line 67
    move-object v10, p1

    .line 68
    move-object/from16 v11, p3

    .line 69
    .line 70
    move-object v8, v4

    .line 71
    invoke-direct/range {v6 .. v12}, Lor/i0;-><init>(Landroid/content/Context;Lhs/g;ZLandroid/os/Handler;Lmr/w;Lor/f0;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 78
    .line 79
    .line 80
    move-result-object p2

    .line 81
    new-instance v1, Lbt/l;

    .line 82
    .line 83
    move-object/from16 v3, p4

    .line 84
    .line 85
    invoke-direct {v1, v3, p2}, Lbt/l;-><init>(Lmr/w;Landroid/os/Looper;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    new-instance p2, Lis/f;

    .line 96
    .line 97
    move-object/from16 v1, p5

    .line 98
    .line 99
    invoke-direct {p2, v1, p1}, Lis/f;-><init>(Lmr/w;Landroid/os/Looper;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    new-instance p1, Lst/b;

    .line 106
    .line 107
    invoke-direct {p1}, Lst/b;-><init>()V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    new-array p1, v2, [Lmr/c;

    .line 114
    .line 115
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    check-cast p1, [Lmr/c;

    .line 120
    .line 121
    return-object p1
.end method

.method public d(Ljava/io/BufferedInputStream;ILjava/io/File;)Lio/sentry/android/core/y0;
    .registers 13

    .line 1
    iget-object v0, p0, Lan/c;->i:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/sentry/android/core/SentryAndroidOptions;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    :try_start_5
    new-instance v2, Lio/sentry/android/core/x0;

    .line 7
    .line 8
    invoke-direct {v2, p1, p2}, Lio/sentry/android/core/x0;-><init>(Ljava/io/BufferedInputStream;I)V
    :try_end_a
    .catchall {:try_start_5 .. :try_end_a} :catchall_7c

    .line 9
    .line 10
    .line 11
    :try_start_a
    new-instance p1, Ljava/io/InputStreamReader;

    .line 12
    .line 13
    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 14
    .line 15
    invoke-direct {p1, v2, p2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
    :try_end_11
    .catchall {:try_start_a .. :try_end_11} :catchall_7e

    .line 16
    .line 17
    .line 18
    :try_start_11
    new-instance p2, Lio/sentry/a2;

    .line 19
    .line 20
    invoke-direct {p2, p1}, Lio/sentry/a2;-><init>(Ljava/io/Reader;)V

    .line 21
    .line 22
    .line 23
    iget-object v3, p2, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v3, Lio/sentry/vendor/gson/stream/a;

    .line 26
    .line 27
    invoke-virtual {p2}, Lio/sentry/a2;->d()V

    .line 28
    .line 29
    .line 30
    move-object v4, v1

    .line 31
    move-object v5, v4

    .line 32
    :cond_1f
    invoke-virtual {v3}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 33
    .line 34
    .line 35
    move-result-object v6

    .line 36
    sget-object v7, Lio/sentry/vendor/gson/stream/b;->NAME:Lio/sentry/vendor/gson/stream/b;

    .line 37
    .line 38
    if-ne v6, v7, :cond_61

    .line 39
    .line 40
    invoke-virtual {v3}, Lio/sentry/vendor/gson/stream/a;->Z()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v6

    .line 44
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    const v8, 0x3492916

    .line 49
    .line 50
    .line 51
    if-eq v7, v8, :cond_49

    .line 52
    .line 53
    const v8, 0x6fbd6873

    .line 54
    .line 55
    .line 56
    if-eq v7, v8, :cond_3a

    .line 57
    .line 58
    goto :goto_5a

    .line 59
    :cond_3a
    const-string v7, "platform"

    .line 60
    .line 61
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v6

    .line 65
    if-eqz v6, :cond_5a

    .line 66
    .line 67
    invoke-virtual {p2}, Lio/sentry/a2;->p0()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    goto :goto_5d

    .line 72
    :catchall_47
    move-exception p2

    .line 73
    goto :goto_80

    .line 74
    :cond_49
    const-string v7, "timestamp"

    .line 75
    .line 76
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    if-eqz v6, :cond_5a

    .line 81
    .line 82
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    invoke-virtual {p2, v5}, Lio/sentry/a2;->n(Lio/sentry/ILogger;)Ljava/util/Date;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    goto :goto_5d

    .line 91
    :cond_5a
    :goto_5a
    invoke-virtual {p2}, Lio/sentry/a2;->v0()V

    .line 92
    .line 93
    .line 94
    :goto_5d
    if-eqz v4, :cond_1f

    .line 95
    .line 96
    if-eqz v5, :cond_1f

    .line 97
    .line 98
    :cond_61
    const-string p2, "native"

    .line 99
    .line 100
    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result p2

    .line 104
    if-eqz p2, :cond_75

    .line 105
    .line 106
    if-eqz v5, :cond_75

    .line 107
    .line 108
    new-instance p2, Lio/sentry/android/core/y0;

    .line 109
    .line 110
    invoke-virtual {v5}, Ljava/util/Date;->getTime()J

    .line 111
    .line 112
    .line 113
    move-result-wide v3

    .line 114
    invoke-direct {p2, p3, v3, v4}, Lio/sentry/android/core/y0;-><init>(Ljava/io/File;J)V
    :try_end_74
    .catchall {:try_start_11 .. :try_end_74} :catchall_47

    .line 115
    .line 116
    .line 117
    move-object v1, p2

    .line 118
    :cond_75
    :try_start_75
    invoke-virtual {p1}, Ljava/io/Reader;->close()V
    :try_end_78
    .catchall {:try_start_75 .. :try_end_78} :catchall_7e

    .line 119
    .line 120
    .line 121
    :try_start_78
    invoke-virtual {v2}, Lio/sentry/android/core/x0;->close()V
    :try_end_7b
    .catchall {:try_start_78 .. :try_end_7b} :catchall_7c

    .line 122
    .line 123
    .line 124
    return-object v1

    .line 125
    :catchall_7c
    move-exception p1

    .line 126
    goto :goto_92

    .line 127
    :catchall_7e
    move-exception p1

    .line 128
    goto :goto_89

    .line 129
    :goto_80
    :try_start_80
    invoke-virtual {p1}, Ljava/io/Reader;->close()V
    :try_end_83
    .catchall {:try_start_80 .. :try_end_83} :catchall_84

    .line 130
    .line 131
    .line 132
    goto :goto_88

    .line 133
    :catchall_84
    move-exception p1

    .line 134
    :try_start_85
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 135
    .line 136
    .line 137
    :goto_88
    throw p2
    :try_end_89
    .catchall {:try_start_85 .. :try_end_89} :catchall_7e

    .line 138
    :goto_89
    :try_start_89
    invoke-virtual {v2}, Lio/sentry/android/core/x0;->close()V
    :try_end_8c
    .catchall {:try_start_89 .. :try_end_8c} :catchall_8d

    .line 139
    .line 140
    .line 141
    goto :goto_91

    .line 142
    :catchall_8d
    move-exception p2

    .line 143
    :try_start_8e
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 144
    .line 145
    .line 146
    :goto_91
    throw p1
    :try_end_92
    .catchall {:try_start_8e .. :try_end_92} :catchall_7c

    .line 147
    :goto_92
    invoke-virtual {v0}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 148
    .line 149
    .line 150
    move-result-object p2

    .line 151
    sget-object v0, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 152
    .line 153
    invoke-virtual {p3}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object p3

    .line 157
    filled-new-array {p3}, [Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object p3

    .line 161
    const-string v2, "Error parsing event JSON from: %s"

    .line 162
    .line 163
    invoke-interface {p2, v0, p1, v2, p3}, Lio/sentry/ILogger;->b(Lio/sentry/a5;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    return-object v1
.end method

.method public e()Ljava/util/Properties;
    .registers 7

    .line 1
    iget-object v0, p0, Lan/c;->v:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/sentry/j2;

    .line 4
    .line 5
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    :try_start_9
    new-instance v3, Ljava/io/File;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    invoke-direct {v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    if-eqz v4, :cond_40

    .line 24
    .line 25
    invoke-virtual {v3}, Ljava/io/File;->canRead()Z

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    if-eqz v4, :cond_40

    .line 30
    .line 31
    new-instance v4, Ljava/io/BufferedInputStream;

    .line 32
    .line 33
    new-instance v5, Ljava/io/FileInputStream;

    .line 34
    .line 35
    invoke-direct {v5, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 36
    .line 37
    .line 38
    invoke-direct {v4, v5}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_28
    .catchall {:try_start_9 .. :try_end_28} :catchall_34

    .line 39
    .line 40
    .line 41
    :try_start_28
    new-instance v3, Ljava/util/Properties;

    .line 42
    .line 43
    invoke-direct {v3}, Ljava/util/Properties;-><init>()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v3, v4}, Ljava/util/Properties;->load(Ljava/io/InputStream;)V
    :try_end_30
    .catchall {:try_start_28 .. :try_end_30} :catchall_36

    .line 47
    .line 48
    .line 49
    :try_start_30
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_33
    .catchall {:try_start_30 .. :try_end_33} :catchall_34

    .line 50
    .line 51
    .line 52
    return-object v3

    .line 53
    :catchall_34
    move-exception v3

    .line 54
    goto :goto_68

    .line 55
    :catchall_36
    move-exception v3

    .line 56
    :try_start_37
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_3a
    .catchall {:try_start_37 .. :try_end_3a} :catchall_3b

    .line 57
    .line 58
    .line 59
    goto :goto_3f

    .line 60
    :catchall_3b
    move-exception v4

    .line 61
    :try_start_3c
    invoke-virtual {v3, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 62
    .line 63
    .line 64
    :goto_3f
    throw v3

    .line 65
    :cond_40
    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    if-nez v4, :cond_56

    .line 70
    .line 71
    iget-boolean v3, p0, Lan/c;->e:Z

    .line 72
    .line 73
    if-eqz v3, :cond_67

    .line 74
    .line 75
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 76
    .line 77
    const-string v4, "Failed to load Sentry configuration since it is not a file or does not exist: %s"

    .line 78
    .line 79
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    invoke-virtual {v0, v3, v4, v5}, Lio/sentry/j2;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-object v2

    .line 87
    :cond_56
    invoke-virtual {v3}, Ljava/io/File;->canRead()Z

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    if-nez v3, :cond_67

    .line 92
    .line 93
    sget-object v3, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 94
    .line 95
    const-string v4, "Failed to load Sentry configuration since it is not readable: %s"

    .line 96
    .line 97
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v5

    .line 101
    invoke-virtual {v0, v3, v4, v5}, Lio/sentry/j2;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_67
    .catchall {:try_start_3c .. :try_end_67} :catchall_34

    .line 102
    .line 103
    .line 104
    :cond_67
    return-object v2

    .line 105
    :goto_68
    sget-object v4, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 106
    .line 107
    const-string v5, "Failed to load Sentry configuration from file: %s"

    .line 108
    .line 109
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-virtual {v0, v4, v3, v5, v1}, Lio/sentry/j2;->b(Lio/sentry/a5;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    return-object v2
.end method

.method public f(Ljava/lang/String;)Lg8/e;
    .registers 10

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_1
    new-instance v1, Ljava/io/InputStreamReader;

    .line 3
    .line 4
    new-instance v2, Ljava/io/ByteArrayInputStream;

    .line 5
    .line 6
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 7
    .line 8
    invoke-virtual {p1, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-direct {v2, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 13
    .line 14
    .line 15
    invoke-direct {v1, v2, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
    :try_end_11
    .catchall {:try_start_1 .. :try_end_11} :catchall_6c

    .line 16
    .line 17
    .line 18
    :try_start_11
    new-instance p1, Lio/sentry/a2;

    .line 19
    .line 20
    invoke-direct {p1, v1}, Lio/sentry/a2;-><init>(Ljava/io/Reader;)V

    .line 21
    .line 22
    .line 23
    iget-object v2, p1, Lio/sentry/a2;->e:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v2, Lio/sentry/vendor/gson/stream/a;

    .line 26
    .line 27
    invoke-virtual {p1}, Lio/sentry/a2;->d()V

    .line 28
    .line 29
    .line 30
    const/4 v3, -0x1

    .line 31
    move-object v4, v0

    .line 32
    :cond_1f
    invoke-virtual {v2}, Lio/sentry/vendor/gson/stream/a;->o0()Lio/sentry/vendor/gson/stream/b;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    sget-object v6, Lio/sentry/vendor/gson/stream/b;->NAME:Lio/sentry/vendor/gson/stream/b;

    .line 37
    .line 38
    if-ne v5, v6, :cond_5d

    .line 39
    .line 40
    invoke-virtual {v2}, Lio/sentry/vendor/gson/stream/a;->Z()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 45
    .line 46
    .line 47
    move-result v6

    .line 48
    const v7, -0x41f1c51a

    .line 49
    .line 50
    .line 51
    if-eq v6, v7, :cond_49

    .line 52
    .line 53
    const v7, 0x368f3a

    .line 54
    .line 55
    .line 56
    if-eq v6, v7, :cond_3a

    .line 57
    .line 58
    goto :goto_56

    .line 59
    :cond_3a
    const-string v6, "type"

    .line 60
    .line 61
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v5

    .line 65
    if-eqz v5, :cond_56

    .line 66
    .line 67
    invoke-virtual {p1}, Lio/sentry/a2;->p0()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    goto :goto_59

    .line 72
    :catchall_47
    move-exception p1

    .line 73
    goto :goto_72

    .line 74
    :cond_49
    const-string v6, "length"

    .line 75
    .line 76
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    if-eqz v5, :cond_56

    .line 81
    .line 82
    invoke-virtual {v2}, Lio/sentry/vendor/gson/stream/a;->X()I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    goto :goto_59

    .line 87
    :cond_56
    :goto_56
    invoke-virtual {p1}, Lio/sentry/a2;->v0()V

    .line 88
    .line 89
    .line 90
    :goto_59
    if-eqz v4, :cond_1f

    .line 91
    .line 92
    if-ltz v3, :cond_1f

    .line 93
    .line 94
    :cond_5d
    if-ltz v3, :cond_6e

    .line 95
    .line 96
    new-instance p1, Lg8/e;

    .line 97
    .line 98
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 99
    .line 100
    .line 101
    iput-object v4, p1, Lg8/e;->a:Ljava/lang/String;

    .line 102
    .line 103
    iput v3, p1, Lg8/e;->b:I
    :try_end_68
    .catchall {:try_start_11 .. :try_end_68} :catchall_47

    .line 104
    .line 105
    :try_start_68
    invoke-virtual {v1}, Ljava/io/Reader;->close()V

    .line 106
    .line 107
    .line 108
    return-object p1

    .line 109
    :catchall_6c
    move-exception p1

    .line 110
    goto :goto_7b

    .line 111
    :cond_6e
    invoke-virtual {v1}, Ljava/io/Reader;->close()V
    :try_end_71
    .catchall {:try_start_68 .. :try_end_71} :catchall_6c

    .line 112
    .line 113
    .line 114
    return-object v0

    .line 115
    :goto_72
    :try_start_72
    invoke-virtual {v1}, Ljava/io/Reader;->close()V
    :try_end_75
    .catchall {:try_start_72 .. :try_end_75} :catchall_76

    .line 116
    .line 117
    .line 118
    goto :goto_7a

    .line 119
    :catchall_76
    move-exception v1

    .line 120
    :try_start_77
    invoke-virtual {p1, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 121
    .line 122
    .line 123
    :goto_7a
    throw p1
    :try_end_7b
    .catchall {:try_start_77 .. :try_end_7b} :catchall_6c

    .line 124
    :goto_7b
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 125
    .line 126
    check-cast v1, Lio/sentry/android/core/SentryAndroidOptions;

    .line 127
    .line 128
    invoke-virtual {v1}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    sget-object v2, Lio/sentry/a5;->DEBUG:Lio/sentry/a5;

    .line 133
    .line 134
    const/4 v3, 0x0

    .line 135
    new-array v3, v3, [Ljava/lang/Object;

    .line 136
    .line 137
    const-string v4, "Error parsing item header"

    .line 138
    .line 139
    invoke-interface {v1, v2, p1, v4, v3}, Lio/sentry/ILogger;->b(Lio/sentry/a5;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    return-object v0
.end method

.method public g()V
    .registers 4

    .line 1
    iget-object v0, p0, Lan/c;->v:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lmr/a;

    .line 4
    .line 5
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroid/content/Context;

    .line 8
    .line 9
    iget-boolean v2, p0, Lan/c;->e:Z

    .line 10
    .line 11
    if-eqz v2, :cond_12

    .line 12
    .line 13
    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput-boolean v0, p0, Lan/c;->e:Z

    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public bridge synthetic h(Lb80/i0;)Lc4/n;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lan/c;->b(Lb80/i0;)Lc4/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public j(Lnv/l;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lan/c;->i:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lan/c;->v:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, Ljava/util/ArrayDeque;

    .line 7
    .line 8
    if-nez v1, :cond_13

    .line 9
    .line 10
    new-instance v1, Ljava/util/ArrayDeque;

    .line 11
    .line 12
    invoke-direct {v1}, Ljava/util/ArrayDeque;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v1, p0, Lan/c;->v:Ljava/lang/Object;

    .line 16
    .line 17
    goto :goto_13

    .line 18
    :catchall_11
    move-exception p1

    .line 19
    goto :goto_1c

    .line 20
    :cond_13
    :goto_13
    iget-object v1, p0, Lan/c;->v:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Ljava/util/ArrayDeque;

    .line 23
    .line 24
    invoke-virtual {v1, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    monitor-exit v0

    .line 28
    return-void

    .line 29
    :goto_1c
    monitor-exit v0
    :try_end_1d
    .catchall {:try_start_3 .. :try_end_1d} :catchall_11

    .line 30
    throw p1
.end method

.method public k(Lcom/google/android/gms/tasks/Task;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lan/c;->i:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lan/c;->v:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, Ljava/util/ArrayDeque;

    .line 7
    .line 8
    if-eqz v1, :cond_31

    .line 9
    .line 10
    iget-boolean v1, p0, Lan/c;->e:Z

    .line 11
    .line 12
    if-eqz v1, :cond_e

    .line 13
    .line 14
    goto :goto_31

    .line 15
    :cond_e
    const/4 v1, 0x1

    .line 16
    iput-boolean v1, p0, Lan/c;->e:Z

    .line 17
    .line 18
    monitor-exit v0
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_2f

    .line 19
    :goto_12
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 20
    .line 21
    monitor-enter v1

    .line 22
    :try_start_15
    iget-object v0, p0, Lan/c;->v:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Ljava/util/ArrayDeque;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, Lnv/l;

    .line 31
    .line 32
    if-nez v0, :cond_28

    .line 33
    .line 34
    const/4 p1, 0x0

    .line 35
    iput-boolean p1, p0, Lan/c;->e:Z

    .line 36
    .line 37
    monitor-exit v1

    .line 38
    return-void

    .line 39
    :catchall_26
    move-exception p1

    .line 40
    goto :goto_2d

    .line 41
    :cond_28
    monitor-exit v1
    :try_end_29
    .catchall {:try_start_15 .. :try_end_29} :catchall_26

    .line 42
    invoke-interface {v0, p1}, Lnv/l;->a(Lcom/google/android/gms/tasks/Task;)V

    .line 43
    .line 44
    .line 45
    goto :goto_12

    .line 46
    :goto_2d
    :try_start_2d
    monitor-exit v1
    :try_end_2e
    .catchall {:try_start_2d .. :try_end_2e} :catchall_26

    .line 47
    throw p1

    .line 48
    :catchall_2f
    move-exception p1

    .line 49
    goto :goto_33

    .line 50
    :cond_31
    :goto_31
    :try_start_31
    monitor-exit v0

    .line 51
    return-void

    .line 52
    :goto_33
    monitor-exit v0
    :try_end_34
    .catchall {:try_start_31 .. :try_end_34} :catchall_2f

    .line 53
    throw p1
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    iget v0, p0, Lan/c;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_2e

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "JavaTypeEnhancementState(jsr305="

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lan/c;->i:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v1, Ld50/u;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, ", getReportLevelForAnnotation="

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, Lan/c;->v:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v1, Lb70/u;

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const/16 v1, 0x29

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0

    .line 47
    :pswitch_data_2e
    .packed-switch 0x3
        :pswitch_a
    .end packed-switch
.end method
