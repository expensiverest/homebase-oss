###### Class al.a (al.a)
.class public interface abstract Lal/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/net/Uri;)Z
.end method

.method public abstract b()Z
.end method

.method public abstract c()Ljava/lang/String;
.end method
