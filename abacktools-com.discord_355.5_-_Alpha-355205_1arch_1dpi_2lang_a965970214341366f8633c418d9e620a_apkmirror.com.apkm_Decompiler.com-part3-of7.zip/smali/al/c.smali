###### Class al.c (al.c)
.class public Lal/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/b1;
.implements Loq/b;
.implements La20/b;
.implements Ldr/b;
.implements Lj00/b;
.implements Ljl/a;
.implements Lw70/g;
.implements Lo4/p;
.implements Lvm/d;
.implements Lew/m;


# static fields
.field public static e:Lal/c;

.field public static i:Lal/c;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lal/c;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/facebook/react/runtime/ReactHostImpl;)V
    .registers 2

    const/16 p1, 0xd

    iput p1, p0, Lal/c;->d:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final g(Landroid/net/Uri;)Ljava/lang/String;
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const-string v0, "toString(...)"

    .line 6
    .line 7
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/16 v1, 0x1e

    .line 15
    .line 16
    if-le v0, v1, :cond_21

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    const-string v0, "substring(...)"

    .line 24
    .line 25
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    const-string v0, "..."

    .line 29
    .line 30
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    :cond_21
    return-object p0
.end method

.method public static i(Ljava/lang/String;)Lzd/k;
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, 0x30228f

    .line 6
    .line 7
    .line 8
    if-eq v0, v1, :cond_29

    .line 9
    .line 10
    const v1, 0x30c033

    .line 11
    .line 12
    .line 13
    if-eq v0, v1, :cond_1e

    .line 14
    .line 15
    const v1, 0x7e88c8dc

    .line 16
    .line 17
    .line 18
    if-ne v0, v1, :cond_34

    .line 19
    .line 20
    const-string v0, "nominal"

    .line 21
    .line 22
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_34

    .line 27
    .line 28
    sget-object p0, Lzd/k;->i:Lzd/k;

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1e
    const-string v0, "half"

    .line 32
    .line 33
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_34

    .line 38
    .line 39
    sget-object p0, Lzd/k;->v:Lzd/k;

    .line 40
    .line 41
    return-object p0

    .line 42
    :cond_29
    const-string v0, "full"

    .line 43
    .line 44
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_34

    .line 49
    .line 50
    sget-object p0, Lzd/k;->w:Lzd/k;

    .line 51
    .line 52
    return-object p0

    .line 53
    :cond_34
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 54
    .line 55
    const-string v1, "Unknown item type: "

    .line 56
    .line 57
    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw v0
.end method

.method public static j(Ljava/lang/String;)Lrp/j;
    .registers 3

    .line 1
    const-string v0, "borderStyle"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    const-string v0, "toLowerCase(...)"

    .line 13
    .line 14
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    const v1, -0x4fcea04f

    .line 22
    .line 23
    .line 24
    if-eq v0, v1, :cond_3c

    .line 25
    .line 26
    const v1, -0x4f08b5d6

    .line 27
    .line 28
    .line 29
    if-eq v0, v1, :cond_30

    .line 30
    .line 31
    const v1, 0x688a6ab

    .line 32
    .line 33
    .line 34
    if-eq v0, v1, :cond_24

    .line 35
    .line 36
    goto :goto_44

    .line 37
    :cond_24
    const-string v0, "solid"

    .line 38
    .line 39
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    if-nez p0, :cond_2d

    .line 44
    .line 45
    goto :goto_44

    .line 46
    :cond_2d
    sget-object p0, Lrp/j;->e:Lrp/j;

    .line 47
    .line 48
    return-object p0

    .line 49
    :cond_30
    const-string v0, "dotted"

    .line 50
    .line 51
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result p0

    .line 55
    if-nez p0, :cond_39

    .line 56
    .line 57
    goto :goto_44

    .line 58
    :cond_39
    sget-object p0, Lrp/j;->v:Lrp/j;

    .line 59
    .line 60
    return-object p0

    .line 61
    :cond_3c
    const-string v0, "dashed"

    .line 62
    .line 63
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-nez p0, :cond_46

    .line 68
    .line 69
    :goto_44
    const/4 p0, 0x0

    .line 70
    return-object p0

    .line 71
    :cond_46
    sget-object p0, Lrp/j;->i:Lrp/j;

    .line 72
    .line 73
    return-object p0
.end method

.method public static l(Leq/i0;)Ljava/lang/String;
    .registers 2

    .line 1
    const-string v0, "type"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    if-eqz p0, :cond_2a

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    if-eq p0, v0, :cond_27

    .line 14
    .line 15
    const/4 v0, 0x2

    .line 16
    if-eq p0, v0, :cond_24

    .line 17
    .line 18
    const/4 v0, 0x3

    .line 19
    if-eq p0, v0, :cond_21

    .line 20
    .line 21
    const/4 v0, 0x4

    .line 22
    if-ne p0, v0, :cond_1a

    .line 23
    .line 24
    const-string p0, "topMomentumScrollEnd"

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_1a
    new-instance p0, Lan/g;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-direct {p0, v0}, Lan/g;-><init>(Z)V

    .line 31
    .line 32
    .line 33
    throw p0

    .line 34
    :cond_21
    const-string p0, "topMomentumScrollBegin"

    .line 35
    .line 36
    return-object p0

    .line 37
    :cond_24
    const-string p0, "topScroll"

    .line 38
    .line 39
    return-object p0

    .line 40
    :cond_27
    const-string p0, "topScrollEndDrag"

    .line 41
    .line 42
    return-object p0

    .line 43
    :cond_2a
    const-string p0, "topScrollBeginDrag"

    .line 44
    .line 45
    return-object p0
.end method

.method public static q()F
    .registers 2

    .line 1
    sget v0, Lae/k;->d:I

    .line 2
    .line 3
    sget-object v0, Le40/d;->d:Le40/a;

    .line 4
    .line 5
    sget-object v0, Le40/d;->d:Le40/a;

    .line 6
    .line 7
    invoke-virtual {v0}, Le40/a;->d()Ljava/util/Random;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const v1, 0x3effffff    # 0.49999997f

    .line 16
    .line 17
    .line 18
    mul-float/2addr v0, v1

    .line 19
    const v1, 0x3ecccccd    # 0.4f

    .line 20
    .line 21
    .line 22
    add-float/2addr v0, v1

    .line 23
    return v0
.end method


# virtual methods
.method public E(Lo4/b0;)V
    .registers 2

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public a(Ljava/lang/Class;)Landroidx/lifecycle/z0;
    .registers 2

    .line 1
    invoke-static {p1}, Lsu/e;->q(Ljava/lang/Class;)Landroidx/lifecycle/z0;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public b(Landroid/view/View;Landroidx/core/view/q2;Lew/n;)Landroidx/core/view/q2;
    .registers 9

    .line 1
    iget v0, p3, Lew/n;->e:I

    .line 2
    .line 3
    invoke-virtual {p2}, Landroidx/core/view/q2;->a()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    add-int/2addr v1, v0

    .line 8
    iput v1, p3, Lew/n;->e:I

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getLayoutDirection()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x1

    .line 15
    if-ne v0, v1, :cond_11

    .line 16
    .line 17
    goto :goto_12

    .line 18
    :cond_11
    const/4 v1, 0x0

    .line 19
    :goto_12
    invoke-virtual {p2}, Landroidx/core/view/q2;->b()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-virtual {p2}, Landroidx/core/view/q2;->c()I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    iget v3, p3, Lew/n;->b:I

    .line 28
    .line 29
    if-eqz v1, :cond_20

    .line 30
    .line 31
    move v4, v2

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move v4, v0

    .line 34
    :goto_21
    add-int/2addr v3, v4

    .line 35
    iput v3, p3, Lew/n;->b:I

    .line 36
    .line 37
    iget v4, p3, Lew/n;->d:I

    .line 38
    .line 39
    if-eqz v1, :cond_29

    .line 40
    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    move v0, v2

    .line 43
    :goto_2a
    add-int/2addr v4, v0

    .line 44
    iput v4, p3, Lew/n;->d:I

    .line 45
    .line 46
    iget v0, p3, Lew/n;->c:I

    .line 47
    .line 48
    iget p3, p3, Lew/n;->e:I

    .line 49
    .line 50
    invoke-virtual {p1, v3, v0, v4, p3}, Landroid/view/View;->setPaddingRelative(IIII)V

    .line 51
    .line 52
    .line 53
    return-object p2
.end method

.method public c(Ljava/lang/Class;Lg3/c;)Landroidx/lifecycle/z0;
    .registers 3

    .line 1
    invoke-virtual {p0, p1}, Lal/c;->a(Ljava/lang/Class;)Landroidx/lifecycle/z0;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public d(Lh40/d;Lg3/c;)Landroidx/lifecycle/z0;
    .registers 3

    .line 1
    invoke-static {p1}, Lz20/g;->y(Lh40/d;)Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p0, p1, p2}, Lal/c;->c(Ljava/lang/Class;Lg3/c;)Landroidx/lifecycle/z0;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public e(Ljava/lang/String;)Z
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0, p1}, Lcom/facebook/soloader/SoLoader;->n(ILjava/lang/String;)Z

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    return p1
.end method

.method public f(I)Ljl/b;
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public get()Ljava/lang/Object;
    .registers 16

    .line 1
    new-instance v0, Lcl/a;

    .line 2
    .line 3
    const/16 v1, 0xd

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lcl/a;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Ljava/util/HashMap;

    .line 9
    .line 10
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 11
    .line 12
    .line 13
    sget-object v7, Ljava/util/Collections;->EMPTY_SET:Ljava/util/Set;

    .line 14
    .line 15
    const-string v8, "Null flags"

    .line 16
    .line 17
    if-eqz v7, :cond_8d

    .line 18
    .line 19
    new-instance v2, Lhr/b;

    .line 20
    .line 21
    const-wide/16 v3, 0x7530

    .line 22
    .line 23
    const-wide/32 v5, 0x5265c00

    .line 24
    .line 25
    .line 26
    invoke-direct/range {v2 .. v7}, Lhr/b;-><init>(JJLjava/util/Set;)V

    .line 27
    .line 28
    .line 29
    sget-object v3, Lyq/d;->d:Lyq/d;

    .line 30
    .line 31
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    if-eqz v7, :cond_87

    .line 35
    .line 36
    new-instance v2, Lhr/b;

    .line 37
    .line 38
    const-wide/16 v3, 0x3e8

    .line 39
    .line 40
    const-wide/32 v5, 0x5265c00

    .line 41
    .line 42
    .line 43
    invoke-direct/range {v2 .. v7}, Lhr/b;-><init>(JJLjava/util/Set;)V

    .line 44
    .line 45
    .line 46
    sget-object v3, Lyq/d;->i:Lyq/d;

    .line 47
    .line 48
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    if-eqz v7, :cond_81

    .line 52
    .line 53
    sget-object v2, Lhr/c;->e:Lhr/c;

    .line 54
    .line 55
    filled-new-array {v2}, [Lhr/c;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    new-instance v3, Ljava/util/HashSet;

    .line 60
    .line 61
    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-direct {v3, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 66
    .line 67
    .line 68
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 69
    .line 70
    .line 71
    move-result-object v14

    .line 72
    if-eqz v14, :cond_7b

    .line 73
    .line 74
    new-instance v9, Lhr/b;

    .line 75
    .line 76
    const-wide/32 v10, 0x5265c00

    .line 77
    .line 78
    .line 79
    const-wide/32 v12, 0x5265c00

    .line 80
    .line 81
    .line 82
    invoke-direct/range {v9 .. v14}, Lhr/b;-><init>(JJLjava/util/Set;)V

    .line 83
    .line 84
    .line 85
    sget-object v2, Lyq/d;->e:Lyq/d;

    .line 86
    .line 87
    invoke-virtual {v1, v2, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    invoke-interface {v2}, Ljava/util/Set;->size()I

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    invoke-static {}, Lyq/d;->values()[Lyq/d;

    .line 99
    .line 100
    .line 101
    move-result-object v3

    .line 102
    array-length v3, v3

    .line 103
    if-lt v2, v3, :cond_73

    .line 104
    .line 105
    new-instance v2, Ljava/util/HashMap;

    .line 106
    .line 107
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 108
    .line 109
    .line 110
    new-instance v2, Lhr/a;

    .line 111
    .line 112
    invoke-direct {v2, v0, v1}, Lhr/a;-><init>(Lkr/a;Ljava/util/HashMap;)V

    .line 113
    .line 114
    .line 115
    return-object v2

    .line 116
    :cond_73
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 117
    .line 118
    const-string v1, "Not all priorities have been configured"

    .line 119
    .line 120
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw v0

    .line 124
    :cond_7b
    new-instance v0, Ljava/lang/NullPointerException;

    .line 125
    .line 126
    invoke-direct {v0, v8}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    throw v0

    .line 130
    :cond_81
    new-instance v0, Ljava/lang/NullPointerException;

    .line 131
    .line 132
    invoke-direct {v0, v8}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw v0

    .line 136
    :cond_87
    new-instance v0, Ljava/lang/NullPointerException;

    .line 137
    .line 138
    invoke-direct {v0, v8}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    throw v0

    .line 142
    :cond_8d
    new-instance v0, Ljava/lang/NullPointerException;

    .line 143
    .line 144
    invoke-direct {v0, v8}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    throw v0
.end method

.method public getEventName()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Lal/c;->d:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_e

    .line 4
    .line 5
    .line 6
    const-string v0, "topDidDisappear"

    .line 7
    .line 8
    return-object v0

    .line 9
    :sswitch_8
    const-string v0, "topTabSelectionPrevented"

    .line 10
    .line 11
    return-object v0

    .line 12
    :sswitch_b
    const-string v0, "topWillAppear"

    .line 13
    .line 14
    return-object v0

    .line 15
    :sswitch_data_e
    .sparse-switch
        0x7 -> :sswitch_b
        0x12 -> :sswitch_8
    .end sparse-switch
.end method

.method public h(F)F
    .registers 2

    .line 1
    const/high16 p1, 0x3f800000    # 1.0f

    .line 2
    .line 3
    return p1
.end method

.method public k()V
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public m(Lj00/m;Z)F
    .registers 5

    .line 1
    const-string v0, "engine"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, Lj00/m;->i:Lm00/a;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    const v1, 0x3dcccccd    # 0.1f

    .line 10
    .line 11
    .line 12
    if-ne p2, v0, :cond_11

    .line 13
    .line 14
    iget p1, p1, Lm00/a;->j:F

    .line 15
    .line 16
    :goto_f
    mul-float/2addr p1, v1

    .line 17
    return p1

    .line 18
    :cond_11
    if-nez p2, :cond_16

    .line 19
    .line 20
    iget p1, p1, Lm00/a;->k:F

    .line 21
    .line 22
    goto :goto_f

    .line 23
    :cond_16
    new-instance p1, Lan/g;

    .line 24
    .line 25
    const/4 p2, 0x0

    .line 26
    invoke-direct {p1, p2}, Lan/g;-><init>(Z)V

    .line 27
    .line 28
    .line 29
    throw p1
.end method

.method public n()V
    .registers 1

    .line 1
    return-void
.end method

.method public o(II)Lo4/i0;
    .registers 3

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public p(Landroid/graphics/Bitmap;)V
    .registers 2

    .line 1
    return-void
.end method

.method public r(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
    .registers 4

    .line 1
    const/16 v0, 0x40

    .line 2
    .line 3
    invoke-virtual {p1, p2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 8
    .line 9
    return-object p1
.end method

.method public t(Ljl/e;Ljava/lang/Throwable;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljl/e;->a()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    if-nez p2, :cond_18

    .line 22
    .line 23
    const/4 p2, 0x0

    .line 24
    goto :goto_20

    .line 25
    :cond_18
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    :goto_20
    filled-new-array {v0, p1, p2}, [Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    const-class p2, Ljl/b;

    .line 38
    .line 39
    const-string v0, "Finalized without closing: %x %x (type = %s)"

    .line 40
    .line 41
    invoke-static {p2, v0, p1}, Lgl/a;->o(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public x()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Lal/c;->d:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_e

    .line 4
    .line 5
    .line 6
    const-string v0, "onDidDisappear"

    .line 7
    .line 8
    return-object v0

    .line 9
    :sswitch_8
    const-string v0, "onTabSelectionPrevented"

    .line 10
    .line 11
    return-object v0

    .line 12
    :sswitch_b
    const-string v0, "onWillAppear"

    .line 13
    .line 14
    return-object v0

    .line 15
    :sswitch_data_e
    .sparse-switch
        0x7 -> :sswitch_b
        0x12 -> :sswitch_8
    .end sparse-switch
.end method
