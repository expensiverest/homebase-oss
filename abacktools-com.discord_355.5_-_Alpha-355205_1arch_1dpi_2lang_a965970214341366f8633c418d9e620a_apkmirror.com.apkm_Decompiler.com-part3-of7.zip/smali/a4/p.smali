###### Class a4.p (a4.p)
.class public final La4/p;
.super La4/t;
.source "SourceFile"


# instance fields
.field public final d:I

.field public final e:J

.field public final f:Z

.field public final g:Z

.field public final h:J

.field public final i:Z

.field public final j:I

.field public final k:J

.field public final l:I

.field public final m:J

.field public final n:J

.field public final o:Z

.field public final p:Z

.field public final q:Lk3/r;

.field public final r:Lhx/m0;

.field public final s:Lhx/m0;

.field public final t:Lhx/p0;

.field public final u:J

.field public final v:La4/o;

.field public final w:Lhx/m0;

.field public final x:La4/m;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/util/List;JZJZIJIJJZZZLk3/r;Ljava/util/List;Ljava/util/List;La4/o;Ljava/util/Map;Ljava/util/List;La4/m;)V
    .registers 32

    move/from16 v0, p18

    .line 1
    invoke-direct {p0, p2, p3, v0}, La4/t;-><init>(Ljava/lang/String;Ljava/util/List;Z)V

    .line 2
    iput p1, p0, La4/p;->d:I

    .line 3
    iput-wide p7, p0, La4/p;->h:J

    .line 4
    iput-boolean p6, p0, La4/p;->g:Z

    .line 5
    iput-boolean p9, p0, La4/p;->i:Z

    .line 6
    iput p10, p0, La4/p;->j:I

    move-wide p1, p11

    .line 7
    iput-wide p1, p0, La4/p;->k:J

    move/from16 p1, p13

    .line 8
    iput p1, p0, La4/p;->l:I

    move-wide/from16 p1, p14

    .line 9
    iput-wide p1, p0, La4/p;->m:J

    move-wide/from16 p1, p16

    .line 10
    iput-wide p1, p0, La4/p;->n:J

    move/from16 p1, p19

    .line 11
    iput-boolean p1, p0, La4/p;->o:Z

    move/from16 p1, p20

    .line 12
    iput-boolean p1, p0, La4/p;->p:Z

    move-object/from16 p1, p21

    .line 13
    iput-object p1, p0, La4/p;->q:Lk3/r;

    .line 14
    invoke-static/range {p22 .. p22}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    move-result-object p1

    iput-object p1, p0, La4/p;->r:Lhx/m0;

    .line 15
    invoke-static/range {p23 .. p23}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    move-result-object p1

    iput-object p1, p0, La4/p;->s:Lhx/m0;

    .line 16
    invoke-static/range {p25 .. p25}, Lhx/p0;->a(Ljava/util/Map;)Lhx/p0;

    move-result-object p1

    iput-object p1, p0, La4/p;->t:Lhx/p0;

    .line 17
    invoke-static/range {p26 .. p26}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    move-result-object p1

    iput-object p1, p0, La4/p;->w:Lhx/m0;

    move-object/from16 p1, p27

    .line 18
    iput-object p1, p0, La4/p;->x:La4/m;

    .line 19
    invoke-interface/range {p23 .. p23}, Ljava/util/List;->isEmpty()Z

    move-result p1

    const-wide/16 p2, 0x0

    if-nez p1, :cond_5c

    .line 20
    invoke-static/range {p23 .. p23}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La4/k;

    .line 21
    iget-wide v0, p1, La4/n;->w:J

    iget-wide v2, p1, La4/n;->i:J

    add-long/2addr v0, v2

    iput-wide v0, p0, La4/p;->u:J

    goto :goto_72

    .line 22
    :cond_5c
    invoke-interface/range {p22 .. p22}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_70

    .line 23
    invoke-static/range {p22 .. p22}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La4/m;

    .line 24
    iget-wide v0, p1, La4/n;->w:J

    iget-wide v2, p1, La4/n;->i:J

    add-long/2addr v0, v2

    iput-wide v0, p0, La4/p;->u:J

    goto :goto_72

    .line 25
    :cond_70
    iput-wide p2, p0, La4/p;->u:J

    :goto_72
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long p1, p4, v0

    if-nez p1, :cond_7c

    goto :goto_8e

    :cond_7c
    cmp-long p1, p4, p2

    if-ltz p1, :cond_87

    .line 26
    iget-wide v0, p0, La4/p;->u:J

    invoke-static {v0, v1, p4, p5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    goto :goto_8e

    .line 27
    :cond_87
    iget-wide v0, p0, La4/p;->u:J

    add-long/2addr v0, p4

    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    :goto_8e
    iput-wide v0, p0, La4/p;->e:J

    cmp-long p1, p4, p2

    if-ltz p1, :cond_96

    const/4 p1, 0x1

    goto :goto_97

    :cond_96
    const/4 p1, 0x0

    .line 28
    :goto_97
    iput-boolean p1, p0, La4/p;->f:Z

    move-object/from16 p1, p24

    .line 29
    iput-object p1, p0, La4/p;->v:La4/o;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;)Ljava/lang/Object;
    .registers 2

    .line 1
    return-object p0
.end method
