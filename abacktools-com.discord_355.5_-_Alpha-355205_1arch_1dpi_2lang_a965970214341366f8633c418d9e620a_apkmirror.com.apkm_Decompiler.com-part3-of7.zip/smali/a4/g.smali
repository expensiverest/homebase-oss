###### Class a4.g (a4.g)
.class public final La4/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:D

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    if-ne p1, v0, :cond_18

    .line 7
    const-string v1, "0x"

    invoke-virtual {p3, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_18

    const-string v1, "0X"

    invoke-virtual {p3, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_17

    goto :goto_18

    :cond_17
    const/4 v0, 0x0

    :cond_18
    :goto_18
    invoke-static {v0}, Loq/a;->z(Z)V

    .line 8
    iput-object p2, p0, La4/g;->a:Ljava/lang/String;

    .line 9
    iput p1, p0, La4/g;->b:I

    .line 10
    iput-object p3, p0, La4/g;->d:Ljava/lang/String;

    const-wide/16 p1, 0x0

    .line 11
    iput-wide p1, p0, La4/g;->c:D

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;D)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, La4/g;->a:Ljava/lang/String;

    const/4 p1, 0x2

    .line 3
    iput p1, p0, La4/g;->b:I

    .line 4
    iput-wide p2, p0, La4/g;->c:D

    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, La4/g;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    if-ne p0, p1, :cond_3

    .line 2
    .line 3
    goto :goto_2e

    .line 4
    :cond_3
    instance-of v0, p1, La4/g;

    .line 5
    .line 6
    if-nez v0, :cond_8

    .line 7
    .line 8
    goto :goto_30

    .line 9
    :cond_8
    check-cast p1, La4/g;

    .line 10
    .line 11
    iget v0, p0, La4/g;->b:I

    .line 12
    .line 13
    iget v1, p1, La4/g;->b:I

    .line 14
    .line 15
    if-ne v0, v1, :cond_30

    .line 16
    .line 17
    iget-wide v0, p0, La4/g;->c:D

    .line 18
    .line 19
    iget-wide v2, p1, La4/g;->c:D

    .line 20
    .line 21
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Double;->compare(DD)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_30

    .line 26
    .line 27
    iget-object v0, p0, La4/g;->a:Ljava/lang/String;

    .line 28
    .line 29
    iget-object v1, p1, La4/g;->a:Ljava/lang/String;

    .line 30
    .line 31
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_30

    .line 36
    .line 37
    iget-object v0, p0, La4/g;->d:Ljava/lang/String;

    .line 38
    .line 39
    iget-object p1, p1, La4/g;->d:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    if-eqz p1, :cond_30

    .line 46
    .line 47
    :goto_2e
    const/4 p1, 0x1

    .line 48
    return p1

    .line 49
    :cond_30
    :goto_30
    const/4 p1, 0x0

    .line 50
    return p1
.end method

.method public final hashCode()I
    .registers 5

    .line 1
    iget v0, p0, La4/g;->b:I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-wide v1, p0, La4/g;->c:D

    .line 8
    .line 9
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v2, p0, La4/g;->d:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p0, La4/g;->a:Ljava/lang/String;

    .line 16
    .line 17
    filled-new-array {v3, v0, v1, v2}, [Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    return v0
.end method
