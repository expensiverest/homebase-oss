###### Class a4.m (a4.m)
.class public final La4/m;
.super La4/n;
.source "SourceFile"


# instance fields
.field public final N:Ljava/lang/String;

.field public final O:Lhx/m0;


# direct methods
.method public constructor <init>(Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)V
    .registers 27

    .line 1
    sget-object v0, Lhx/m0;->e:Lhx/k0;

    .line 2
    sget-object v18, Lhx/w1;->w:Lhx/w1;

    const/4 v3, 0x0

    .line 3
    const-string v4, ""

    const-wide/16 v5, 0x0

    const/4 v7, -0x1

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v10, 0x0

    const/16 v17, 0x0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-wide/from16 v13, p2

    move-wide/from16 v15, p4

    move-object/from16 v11, p6

    move-object/from16 v12, p7

    invoke-direct/range {v1 .. v18}, La4/m;-><init>(Ljava/lang/String;La4/m;Ljava/lang/String;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZLjava/util/List;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;La4/m;Ljava/lang/String;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZLjava/util/List;)V
    .registers 34

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-wide/from16 v3, p4

    move/from16 v5, p6

    move-wide/from16 v6, p7

    move-object/from16 v8, p9

    move-object/from16 v9, p10

    move-object/from16 v10, p11

    move-wide/from16 v11, p12

    move-wide/from16 v13, p14

    move/from16 v15, p16

    .line 4
    invoke-direct/range {v0 .. v15}, La4/n;-><init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZ)V

    move-object/from16 v1, p3

    .line 5
    iput-object v1, v0, La4/m;->N:Ljava/lang/String;

    .line 6
    invoke-static/range {p17 .. p17}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    move-result-object v1

    iput-object v1, v0, La4/m;->O:Lhx/m0;

    return-void
.end method
