###### Class a4.b0 (a4.b0)
.class public final La4/b0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:La4/s;

.field public final b:Z

.field public final c:Ljava/util/HashMap;

.field public final d:Ljava/util/HashMap;

.field public final e:Ljava/util/HashMap;

.field public f:Lhx/m0;

.field public g:Lhx/m0;

.field public h:Lhx/m0;

.field public i:Lhx/m0;


# direct methods
.method public constructor <init>(La4/s;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/b0;->a:La4/s;

    .line 5
    .line 6
    iget-object p1, p1, La4/s;->n:Lk7/l;

    .line 7
    .line 8
    if-eqz p1, :cond_b

    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 p1, 0x0

    .line 13
    :goto_c
    iput-boolean p1, p0, La4/b0;->b:Z

    .line 14
    .line 15
    new-instance p1, Ljava/util/HashMap;

    .line 16
    .line 17
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, La4/b0;->c:Ljava/util/HashMap;

    .line 21
    .line 22
    new-instance p1, Ljava/util/HashMap;

    .line 23
    .line 24
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, La4/b0;->d:Ljava/util/HashMap;

    .line 28
    .line 29
    new-instance p1, Ljava/util/HashMap;

    .line 30
    .line 31
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 32
    .line 33
    .line 34
    iput-object p1, p0, La4/b0;->e:Ljava/util/HashMap;

    .line 35
    .line 36
    return-void
.end method

.method public static e(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;)V
    .registers 4

    .line 1
    invoke-virtual {p2, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_29

    .line 6
    .line 7
    invoke-virtual {p2, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_11

    .line 16
    .line 17
    goto :goto_29

    .line 18
    :cond_11
    new-instance p1, Ljava/lang/StringBuilder;

    .line 19
    .line 20
    const-string p2, "The group ID "

    .line 21
    .line 22
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    const-string p0, " is associated with more than one pathway from variants"

    .line 29
    .line 30
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-static {p0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    throw p0

    .line 42
    :cond_29
    :goto_29
    invoke-virtual {p2, p0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;Ljava/util/HashMap;)Lhx/m0;
    .registers 14

    .line 1
    new-instance v4, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v6, Ljava/util/HashMap;

    .line 7
    .line 8
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 9
    .line 10
    .line 11
    new-instance v7, Ljava/util/HashMap;

    .line 12
    .line 13
    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 v8, 0x0

    .line 17
    move v3, v8

    .line 18
    :goto_11
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-boolean v1, p0, La4/b0;->b:Z

    .line 23
    .line 24
    if-ge v3, v0, :cond_47

    .line 25
    .line 26
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, La4/q;

    .line 31
    .line 32
    iget-object v2, v0, La4/q;->a:Landroid/net/Uri;

    .line 33
    .line 34
    new-instance v5, La4/c0;

    .line 35
    .line 36
    iget-object v2, v0, La4/q;->b:Lk3/w;

    .line 37
    .line 38
    iget-object v9, v0, La4/q;->e:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v10, v0, La4/q;->d:Ljava/lang/String;

    .line 41
    .line 42
    invoke-direct {v5, v2, v9, v10}, La4/c0;-><init>(Lk3/w;Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    if-eqz v1, :cond_3c

    .line 46
    .line 47
    iget-object v1, v0, La4/q;->c:Ljava/lang/String;

    .line 48
    .line 49
    invoke-virtual {p2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Ljava/lang/String;

    .line 54
    .line 55
    if-nez v1, :cond_3a

    .line 56
    .line 57
    move-object v0, p0

    .line 58
    goto :goto_44

    .line 59
    :cond_3a
    :goto_3a
    move-object v2, v1

    .line 60
    goto :goto_3e

    .line 61
    :cond_3c
    const/4 v1, 0x0

    .line 62
    goto :goto_3a

    .line 63
    :goto_3e
    iget-object v1, v0, La4/q;->a:Landroid/net/Uri;

    .line 64
    .line 65
    move-object v0, p0

    .line 66
    invoke-virtual/range {v0 .. v7}, La4/b0;->d(Landroid/net/Uri;Ljava/lang/String;ILjava/util/ArrayList;La4/c0;Ljava/util/HashMap;Ljava/util/HashMap;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    :goto_44
    add-int/lit8 v3, v3, 0x1

    .line 70
    .line 71
    goto :goto_11

    .line 72
    :cond_47
    move-object v0, p0

    .line 73
    if-nez v1, :cond_4b

    .line 74
    .line 75
    goto :goto_7a

    .line 76
    :cond_4b
    iget-object p1, v0, La4/b0;->f:Lhx/m0;

    .line 77
    .line 78
    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    check-cast p1, La4/d0;

    .line 83
    .line 84
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    invoke-virtual {p1}, La4/d0;->a()Lhx/x0;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    :goto_5a
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 92
    .line 93
    .line 94
    move-result p2

    .line 95
    if-ge v8, p2, :cond_7a

    .line 96
    .line 97
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p2

    .line 101
    check-cast p2, La4/d0;

    .line 102
    .line 103
    invoke-virtual {p2}, La4/d0;->a()Lhx/x0;

    .line 104
    .line 105
    .line 106
    move-result-object p2

    .line 107
    invoke-virtual {p2, p1}, Lhx/x0;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result p2

    .line 111
    if-eqz p2, :cond_73

    .line 112
    .line 113
    add-int/lit8 v8, v8, 0x1

    .line 114
    .line 115
    goto :goto_5a

    .line 116
    :cond_73
    const-string p1, "The set of available pathway IDs of a rendition redundant group is inconsistent with variant redundant groups"

    .line 117
    .line 118
    invoke-static {p1}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    throw p1

    .line 123
    :cond_7a
    :goto_7a
    invoke-static {v4}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    return-object p1
.end method

.method public final b(I)Lhx/m0;
    .registers 4

    .line 1
    invoke-virtual {p0}, La4/b0;->c()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iget-object v1, p0, La4/b0;->a:La4/s;

    .line 6
    .line 7
    if-eq p1, v0, :cond_38

    .line 8
    .line 9
    const/4 v0, 0x2

    .line 10
    if-eq p1, v0, :cond_27

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    if-ne p1, v0, :cond_1f

    .line 14
    .line 15
    iget-object p1, p0, La4/b0;->i:Lhx/m0;

    .line 16
    .line 17
    if-nez p1, :cond_1c

    .line 18
    .line 19
    iget-object p1, v1, La4/s;->h:Ljava/util/List;

    .line 20
    .line 21
    iget-object v0, p0, La4/b0;->e:Ljava/util/HashMap;

    .line 22
    .line 23
    invoke-virtual {p0, p1, v0}, La4/b0;->a(Ljava/util/List;Ljava/util/HashMap;)Lhx/m0;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    iput-object p1, p0, La4/b0;->i:Lhx/m0;

    .line 28
    .line 29
    :cond_1c
    iget-object p1, p0, La4/b0;->i:Lhx/m0;

    .line 30
    .line 31
    return-object p1

    .line 32
    :cond_1f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 33
    .line 34
    const-string v0, "Invalid type for creating rendition redundant group list"

    .line 35
    .line 36
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw p1

    .line 40
    :cond_27
    iget-object p1, p0, La4/b0;->h:Lhx/m0;

    .line 41
    .line 42
    if-nez p1, :cond_35

    .line 43
    .line 44
    iget-object p1, v1, La4/s;->g:Ljava/util/List;

    .line 45
    .line 46
    iget-object v0, p0, La4/b0;->d:Ljava/util/HashMap;

    .line 47
    .line 48
    invoke-virtual {p0, p1, v0}, La4/b0;->a(Ljava/util/List;Ljava/util/HashMap;)Lhx/m0;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    iput-object p1, p0, La4/b0;->h:Lhx/m0;

    .line 53
    .line 54
    :cond_35
    iget-object p1, p0, La4/b0;->h:Lhx/m0;

    .line 55
    .line 56
    return-object p1

    .line 57
    :cond_38
    iget-object p1, p0, La4/b0;->g:Lhx/m0;

    .line 58
    .line 59
    if-nez p1, :cond_46

    .line 60
    .line 61
    iget-object p1, v1, La4/s;->f:Ljava/util/List;

    .line 62
    .line 63
    iget-object v0, p0, La4/b0;->c:Ljava/util/HashMap;

    .line 64
    .line 65
    invoke-virtual {p0, p1, v0}, La4/b0;->a(Ljava/util/List;Ljava/util/HashMap;)Lhx/m0;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, La4/b0;->g:Lhx/m0;

    .line 70
    .line 71
    :cond_46
    iget-object p1, p0, La4/b0;->g:Lhx/m0;

    .line 72
    .line 73
    return-object p1
.end method

.method public final c()V
    .registers 12

    .line 1
    iget-object v0, p0, La4/b0;->f:Lhx/m0;

    .line 2
    .line 3
    if-nez v0, :cond_99

    .line 4
    .line 5
    new-instance v5, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v7, Ljava/util/HashMap;

    .line 11
    .line 12
    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 13
    .line 14
    .line 15
    new-instance v8, Ljava/util/HashMap;

    .line 16
    .line 17
    invoke-direct {v8}, Ljava/util/HashMap;-><init>()V

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    move v4, v0

    .line 22
    :goto_15
    iget-object v1, p0, La4/b0;->a:La4/s;

    .line 23
    .line 24
    iget-object v2, v1, La4/s;->e:Ljava/util/List;

    .line 25
    .line 26
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    iget-boolean v9, p0, La4/b0;->b:Z

    .line 31
    .line 32
    if-ge v4, v2, :cond_5d

    .line 33
    .line 34
    iget-object v1, v1, La4/s;->e:Ljava/util/List;

    .line 35
    .line 36
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    move-object v10, v1

    .line 41
    check-cast v10, La4/r;

    .line 42
    .line 43
    new-instance v6, La4/c0;

    .line 44
    .line 45
    iget-object v1, v10, La4/r;->b:Lk3/w;

    .line 46
    .line 47
    iget-object v2, v10, La4/r;->h:Ljava/lang/String;

    .line 48
    .line 49
    const/4 v3, 0x0

    .line 50
    invoke-direct {v6, v1, v2, v3}, La4/c0;-><init>(Lk3/w;Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    iget-object v2, v10, La4/r;->a:Landroid/net/Uri;

    .line 54
    .line 55
    iget-object v3, v10, La4/r;->g:Ljava/lang/String;

    .line 56
    .line 57
    move-object v1, p0

    .line 58
    invoke-virtual/range {v1 .. v8}, La4/b0;->d(Landroid/net/Uri;Ljava/lang/String;ILjava/util/ArrayList;La4/c0;Ljava/util/HashMap;Ljava/util/HashMap;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    if-eqz v9, :cond_5a

    .line 63
    .line 64
    iget-object v3, v10, La4/r;->c:Ljava/lang/String;

    .line 65
    .line 66
    if-eqz v3, :cond_48

    .line 67
    .line 68
    iget-object v6, v1, La4/b0;->c:Ljava/util/HashMap;

    .line 69
    .line 70
    invoke-static {v3, v2, v6}, La4/b0;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;)V

    .line 71
    .line 72
    .line 73
    :cond_48
    iget-object v3, v10, La4/r;->d:Ljava/lang/String;

    .line 74
    .line 75
    if-eqz v3, :cond_51

    .line 76
    .line 77
    iget-object v6, v1, La4/b0;->d:Ljava/util/HashMap;

    .line 78
    .line 79
    invoke-static {v3, v2, v6}, La4/b0;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    iget-object v3, v10, La4/r;->e:Ljava/lang/String;

    .line 83
    .line 84
    if-eqz v3, :cond_5a

    .line 85
    .line 86
    iget-object v6, v1, La4/b0;->e:Ljava/util/HashMap;

    .line 87
    .line 88
    invoke-static {v3, v2, v6}, La4/b0;->e(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;)V

    .line 89
    .line 90
    .line 91
    :cond_5a
    add-int/lit8 v4, v4, 0x1

    .line 92
    .line 93
    goto :goto_15

    .line 94
    :cond_5d
    move-object v1, p0

    .line 95
    invoke-static {v5}, Lhx/m0;->q(Ljava/util/Collection;)Lhx/m0;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    iput-object v2, v1, La4/b0;->f:Lhx/m0;

    .line 100
    .line 101
    if-nez v9, :cond_67

    .line 102
    .line 103
    goto :goto_9a

    .line 104
    :cond_67
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    check-cast v0, La4/d0;

    .line 109
    .line 110
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v0}, La4/d0;->a()Lhx/x0;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    const/4 v2, 0x1

    .line 118
    :goto_75
    iget-object v3, v1, La4/b0;->f:Lhx/m0;

    .line 119
    .line 120
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    if-ge v2, v3, :cond_9a

    .line 125
    .line 126
    iget-object v3, v1, La4/b0;->f:Lhx/m0;

    .line 127
    .line 128
    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    check-cast v3, La4/d0;

    .line 133
    .line 134
    invoke-virtual {v3}, La4/d0;->a()Lhx/x0;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    invoke-virtual {v3, v0}, Lhx/x0;->equals(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v3

    .line 142
    if-eqz v3, :cond_92

    .line 143
    .line 144
    add-int/lit8 v2, v2, 0x1

    .line 145
    .line 146
    goto :goto_75

    .line 147
    :cond_92
    const-string v0, "The set of available pathway IDs is inconsistent among variant redundant groups"

    .line 148
    .line 149
    invoke-static {v0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    throw v0

    .line 154
    :cond_99
    move-object v1, p0

    .line 155
    :cond_9a
    :goto_9a
    return-void
.end method

.method public final d(Landroid/net/Uri;Ljava/lang/String;ILjava/util/ArrayList;La4/c0;Ljava/util/HashMap;Ljava/util/HashMap;)Ljava/lang/String;
    .registers 16

    .line 1
    invoke-virtual {p6, p5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Ljava/lang/Integer;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const-string v2, "."

    .line 9
    .line 10
    const/4 v3, 0x1

    .line 11
    if-nez v0, :cond_32

    .line 12
    .line 13
    if-nez p2, :cond_17

    .line 14
    .line 15
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    invoke-virtual {p7, p5, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-object p2, v2

    .line 23
    goto :goto_1e

    .line 24
    :cond_17
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {p7, p5, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    :goto_1e
    new-instance p7, La4/d0;

    .line 32
    .line 33
    invoke-direct {p7, p5, p2, p1, p3}, La4/d0;-><init>(La4/c0;Ljava/lang/String;Landroid/net/Uri;I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-virtual {p6, p5, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    invoke-virtual {p4, p7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    return-object p2

    .line 51
    :cond_32
    if-nez p2, :cond_96

    .line 52
    .line 53
    invoke-virtual {p7, p5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    check-cast p2, Ljava/lang/Integer;

    .line 58
    .line 59
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 63
    .line 64
    .line 65
    move-result p2

    .line 66
    iget-boolean p6, p0, La4/b0;->b:Z

    .line 67
    .line 68
    if-eqz p6, :cond_4f

    .line 69
    .line 70
    if-ge p2, v3, :cond_48

    .line 71
    .line 72
    goto :goto_4f

    .line 73
    :cond_48
    const-string p1, "At most one playlist URL within an HlsRedundantGroup can have an undefined pathway when Content Steering is enabled"

    .line 74
    .line 75
    invoke-static {p1}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    throw p1

    .line 80
    :cond_4f
    :goto_4f
    add-int/2addr p2, v3

    .line 81
    if-gt p2, v3, :cond_61

    .line 82
    .line 83
    if-ltz p2, :cond_55

    .line 84
    .line 85
    move v1, v3

    .line 86
    :cond_55
    const-string p6, "invalid count: %s"

    .line 87
    .line 88
    invoke-static {p6, p2, v1}, Loq/a;->l(Ljava/lang/String;IZ)V

    .line 89
    .line 90
    .line 91
    if-nez p2, :cond_5f

    .line 92
    .line 93
    const-string p6, ""

    .line 94
    .line 95
    goto :goto_81

    .line 96
    :cond_5f
    move-object p6, v2

    .line 97
    goto :goto_81

    .line 98
    :cond_61
    int-to-long v4, v3

    .line 99
    int-to-long v6, p2

    .line 100
    mul-long/2addr v4, v6

    .line 101
    long-to-int p6, v4

    .line 102
    int-to-long v6, p6

    .line 103
    cmp-long v6, v6, v4

    .line 104
    .line 105
    if-nez v6, :cond_8a

    .line 106
    .line 107
    new-array v4, p6, [C

    .line 108
    .line 109
    invoke-virtual {v2, v1, v3, v4, v1}, Ljava/lang/String;->getChars(II[CI)V

    .line 110
    .line 111
    .line 112
    :goto_6f
    sub-int v2, p6, v3

    .line 113
    .line 114
    if-ge v3, v2, :cond_79

    .line 115
    .line 116
    invoke-static {v4, v1, v4, v3, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 117
    .line 118
    .line 119
    shl-int/lit8 v3, v3, 0x1

    .line 120
    .line 121
    goto :goto_6f

    .line 122
    :cond_79
    invoke-static {v4, v1, v4, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 123
    .line 124
    .line 125
    new-instance p6, Ljava/lang/String;

    .line 126
    .line 127
    invoke-direct {p6, v4}, Ljava/lang/String;-><init>([C)V

    .line 128
    .line 129
    .line 130
    :goto_81
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 131
    .line 132
    .line 133
    move-result-object p2

    .line 134
    invoke-virtual {p7, p5, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-object p2, p6

    .line 138
    goto :goto_96

    .line 139
    :cond_8a
    new-instance p1, Ljava/lang/ArrayIndexOutOfBoundsException;

    .line 140
    .line 141
    const-string p2, "Required array size too large: "

    .line 142
    .line 143
    invoke-static {v4, v5, p2}, Lxw/a;->e(JLjava/lang/String;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object p2

    .line 147
    invoke-direct {p1, p2}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    throw p1

    .line 151
    :cond_96
    :goto_96
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 152
    .line 153
    .line 154
    move-result p5

    .line 155
    invoke-virtual {p4, p5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p4

    .line 159
    check-cast p4, La4/d0;

    .line 160
    .line 161
    iget-object p5, p4, La4/d0;->b:Ljava/util/HashMap;

    .line 162
    .line 163
    invoke-virtual {p5, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object p5

    .line 167
    check-cast p5, Landroid/net/Uri;

    .line 168
    .line 169
    if-eqz p5, :cond_c9

    .line 170
    .line 171
    invoke-virtual {p1, p5}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result p5

    .line 175
    if-eqz p5, :cond_b1

    .line 176
    .line 177
    goto :goto_c9

    .line 178
    :cond_b1
    new-instance p1, Ljava/lang/StringBuilder;

    .line 179
    .line 180
    const-string p3, "Different playlist URLs are found for pathway ID "

    .line 181
    .line 182
    invoke-direct {p1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    const-string p2, " within the HlsRedundantGroup"

    .line 189
    .line 190
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    invoke-static {p1}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    throw p1

    .line 202
    :cond_c9
    :goto_c9
    iget-object p5, p4, La4/d0;->b:Ljava/util/HashMap;

    .line 203
    .line 204
    invoke-virtual {p5, p2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    const/4 p1, -0x1

    .line 208
    if-eq p3, p1, :cond_da

    .line 209
    .line 210
    iget-object p1, p4, La4/d0;->c:Ljava/util/ArrayList;

    .line 211
    .line 212
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 213
    .line 214
    .line 215
    move-result-object p3

    .line 216
    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    :cond_da
    return-object p2
.end method
