###### Class a4.z (a4.z)
.class public interface abstract La4/z;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract b(Landroid/net/Uri;Lj4/h;Z)Z
.end method
