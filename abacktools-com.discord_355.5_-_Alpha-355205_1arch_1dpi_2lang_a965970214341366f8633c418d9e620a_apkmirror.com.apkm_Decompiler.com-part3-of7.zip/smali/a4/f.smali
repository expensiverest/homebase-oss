###### Class a4.f (a4.f)
.class public final La4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lj4/i;


# static fields
.field public static final Y:La4/a;


# instance fields
.field public J:Landroid/os/Handler;

.field public K:Lz3/j;

.field public L:Lj4/d;

.field public M:La4/s;

.field public N:Lk3/v0;

.field public O:Lw70/n;

.field public P:Lhx/m0;

.field public Q:Lhx/m0;

.field public R:Lhx/m0;

.field public S:Lhx/m0;

.field public T:Landroid/net/Uri;

.field public U:La4/p;

.field public V:Landroid/net/Uri;

.field public W:Z

.field public X:J

.field public final d:Lmr/k0;

.field public final e:La4/y;

.field public final i:Lcl/a;

.field public final v:Ljava/util/HashMap;

.field public final w:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public x:Lcom/google/android/gms/internal/fido/f8;

.field public y:Lj4/n;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, La4/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, La4/a;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, La4/f;->Y:La4/a;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Lmr/k0;Lcl/a;La4/y;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/f;->d:Lmr/k0;

    .line 5
    .line 6
    iput-object p3, p0, La4/f;->e:La4/y;

    .line 7
    .line 8
    iput-object p2, p0, La4/f;->i:Lcl/a;

    .line 9
    .line 10
    new-instance p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 11
    .line 12
    invoke-direct {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, La4/f;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 16
    .line 17
    new-instance p1, Ljava/util/HashMap;

    .line 18
    .line 19
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, La4/f;->v:Ljava/util/HashMap;

    .line 23
    .line 24
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    iput-wide p1, p0, La4/f;->X:J

    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;Z)V
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    if-ge v0, v1, :cond_35

    .line 7
    .line 8
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, La4/d0;

    .line 13
    .line 14
    new-instance v2, La4/e;

    .line 15
    .line 16
    invoke-direct {v2, p0, v1, p2}, La4/e;-><init>(La4/f;La4/d0;Z)V

    .line 17
    .line 18
    .line 19
    iget-object v1, v1, La4/d0;->b:Ljava/util/HashMap;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {v1}, Lhx/x0;->q(Ljava/util/Collection;)Lhx/x0;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {v1}, Lhx/h0;->m()Lhx/l2;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    :goto_20
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_32

    .line 38
    .line 39
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    check-cast v3, Landroid/net/Uri;

    .line 44
    .line 45
    iget-object v4, p0, La4/f;->v:Ljava/util/HashMap;

    .line 46
    .line 47
    invoke-virtual {v4, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    goto :goto_20

    .line 51
    :cond_32
    add-int/lit8 v0, v0, 0x1

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_35
    return-void
.end method

.method public final b(ZLandroid/net/Uri;)La4/p;
    .registers 6

    .line 1
    iget-object v0, p0, La4/f;->v:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, La4/e;

    .line 8
    .line 9
    if-nez v1, :cond_c

    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    return-object p1

    .line 13
    :cond_c
    invoke-static {v1, p2}, La4/e;->a(La4/e;Landroid/net/Uri;)La4/p;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    if-eqz v1, :cond_58

    .line 18
    .line 19
    if-eqz p1, :cond_58

    .line 20
    .line 21
    const/4 p1, 0x0

    .line 22
    invoke-virtual {p0, p1, p2}, La4/f;->j(ZLandroid/net/Uri;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    check-cast p1, La4/e;

    .line 30
    .line 31
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    iget-object v0, p1, La4/e;->b:Ljava/util/HashMap;

    .line 35
    .line 36
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-static {v2}, Loq/a;->z(Z)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    check-cast v2, La4/d;

    .line 48
    .line 49
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    iget-boolean v2, v2, La4/d;->N:Z

    .line 53
    .line 54
    if-eqz v2, :cond_38

    .line 55
    .line 56
    goto :goto_58

    .line 57
    :cond_38
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    invoke-static {v2}, Loq/a;->z(Z)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    check-cast v0, La4/d;

    .line 69
    .line 70
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    const/4 v2, 0x1

    .line 74
    iput-boolean v2, v0, La4/d;->N:Z

    .line 75
    .line 76
    invoke-static {p1, p2}, La4/e;->a(La4/e;Landroid/net/Uri;)La4/p;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    if-eqz v0, :cond_58

    .line 81
    .line 82
    iget-boolean v0, v0, La4/p;->o:Z

    .line 83
    .line 84
    if-nez v0, :cond_58

    .line 85
    .line 86
    invoke-static {p1, p2, v2}, La4/e;->b(La4/e;Landroid/net/Uri;Z)V

    .line 87
    .line 88
    .line 89
    :cond_58
    :goto_58
    return-object v1
.end method

.method public final c(Lj4/k;JJ)V
    .registers 27

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    check-cast v0, Lj4/p;

    .line 6
    .line 7
    iget-object v2, v0, Lj4/p;->f:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, La4/t;

    .line 10
    .line 11
    instance-of v3, v2, La4/p;

    .line 12
    .line 13
    if-eqz v3, :cond_54

    .line 14
    .line 15
    iget-object v4, v2, La4/t;->a:Ljava/lang/String;

    .line 16
    .line 17
    sget-object v5, La4/s;->o:La4/s;

    .line 18
    .line 19
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 20
    .line 21
    .line 22
    move-result-object v7

    .line 23
    new-instance v4, Lk3/v;

    .line 24
    .line 25
    invoke-direct {v4}, Lk3/v;-><init>()V

    .line 26
    .line 27
    .line 28
    const-string v5, "0"

    .line 29
    .line 30
    iput-object v5, v4, Lk3/v;->a:Ljava/lang/String;

    .line 31
    .line 32
    const-string v5, "application/x-mpegURL"

    .line 33
    .line 34
    invoke-static {v5}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    iput-object v5, v4, Lk3/v;->n:Ljava/lang/String;

    .line 39
    .line 40
    new-instance v8, Lk3/w;

    .line 41
    .line 42
    invoke-direct {v8, v4}, Lk3/w;-><init>(Lk3/v;)V

    .line 43
    .line 44
    .line 45
    new-instance v6, La4/r;

    .line 46
    .line 47
    const/4 v13, 0x0

    .line 48
    const/4 v14, 0x0

    .line 49
    const/4 v9, 0x0

    .line 50
    const/4 v10, 0x0

    .line 51
    const/4 v11, 0x0

    .line 52
    const/4 v12, 0x0

    .line 53
    invoke-direct/range {v6 .. v14}, La4/r;-><init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-static {v6}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object v10

    .line 60
    new-instance v7, La4/s;

    .line 61
    .line 62
    sget-object v9, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 63
    .line 64
    sget-object v18, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 65
    .line 66
    const/16 v20, 0x0

    .line 67
    .line 68
    const-string v8, ""

    .line 69
    .line 70
    const/4 v15, 0x0

    .line 71
    const/16 v16, 0x0

    .line 72
    .line 73
    const/16 v17, 0x0

    .line 74
    .line 75
    move-object v11, v9

    .line 76
    move-object v12, v9

    .line 77
    move-object v13, v9

    .line 78
    move-object v14, v9

    .line 79
    move-object/from16 v19, v9

    .line 80
    .line 81
    invoke-direct/range {v7 .. v20}, La4/s;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lk3/w;Ljava/util/List;ZLjava/util/Map;Ljava/util/List;Lk7/l;)V

    .line 82
    .line 83
    .line 84
    goto :goto_57

    .line 85
    :cond_54
    move-object v7, v2

    .line 86
    check-cast v7, La4/s;

    .line 87
    .line 88
    :goto_57
    iput-object v7, v1, La4/f;->M:La4/s;

    .line 89
    .line 90
    new-instance v4, La4/b0;

    .line 91
    .line 92
    invoke-direct {v4, v7}, La4/b0;-><init>(La4/s;)V

    .line 93
    .line 94
    .line 95
    :try_start_5e
    invoke-virtual {v4}, La4/b0;->c()V

    .line 96
    .line 97
    .line 98
    iget-object v5, v4, La4/b0;->f:Lhx/m0;

    .line 99
    .line 100
    iput-object v5, v1, La4/f;->P:Lhx/m0;

    .line 101
    .line 102
    const/4 v5, 0x1

    .line 103
    invoke-virtual {v4, v5}, La4/b0;->b(I)Lhx/m0;

    .line 104
    .line 105
    .line 106
    move-result-object v6

    .line 107
    iput-object v6, v1, La4/f;->Q:Lhx/m0;

    .line 108
    .line 109
    const/4 v6, 0x2

    .line 110
    invoke-virtual {v4, v6}, La4/b0;->b(I)Lhx/m0;

    .line 111
    .line 112
    .line 113
    move-result-object v6

    .line 114
    iput-object v6, v1, La4/f;->R:Lhx/m0;

    .line 115
    .line 116
    const/4 v6, 0x3

    .line 117
    invoke-virtual {v4, v6}, La4/b0;->b(I)Lhx/m0;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    iput-object v4, v1, La4/f;->S:Lhx/m0;
    :try_end_7a
    .catch Lk3/v0; {:try_start_5e .. :try_end_7a} :catch_17f

    .line 122
    .line 123
    iget-object v4, v1, La4/f;->M:La4/s;

    .line 124
    .line 125
    iget-object v4, v4, La4/s;->n:Lk7/l;

    .line 126
    .line 127
    if-eqz v4, :cond_e6

    .line 128
    .line 129
    new-instance v6, Lw70/n;

    .line 130
    .line 131
    iget-object v7, v1, La4/f;->d:Lmr/k0;

    .line 132
    .line 133
    new-instance v8, La8/c;

    .line 134
    .line 135
    invoke-direct {v8, v1}, La8/c;-><init>(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    iget-object v9, v1, La4/f;->L:Lj4/d;

    .line 139
    .line 140
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    invoke-direct {v6, v7, v1, v8, v9}, Lw70/n;-><init>(Lmr/k0;La4/f;La8/c;Lj4/d;)V

    .line 144
    .line 145
    .line 146
    iput-object v6, v1, La4/f;->O:Lw70/n;

    .line 147
    .line 148
    iget-object v7, v4, Lk7/l;->d:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v7, Landroid/net/Uri;

    .line 151
    .line 152
    iget-object v4, v4, Lk7/l;->e:Ljava/lang/Object;

    .line 153
    .line 154
    check-cast v4, Ljava/lang/String;

    .line 155
    .line 156
    iget-object v8, v1, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 157
    .line 158
    if-eqz v4, :cond_ac

    .line 159
    .line 160
    iget-object v9, v6, Lw70/n;->i:Ljava/util/AbstractCollection;

    .line 161
    .line 162
    check-cast v9, Ljava/util/HashSet;

    .line 163
    .line 164
    invoke-virtual {v9, v4}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v9

    .line 168
    invoke-static {v9}, Loq/a;->z(Z)V

    .line 169
    .line 170
    .line 171
    iput-object v4, v6, Lw70/n;->l:Ljava/lang/Object;

    .line 172
    .line 173
    :cond_ac
    iput-boolean v5, v6, Lw70/n;->a:Z

    .line 174
    .line 175
    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    invoke-virtual {v6, v9, v10}, Lw70/n;->h(J)V

    .line 181
    .line 182
    .line 183
    iget-object v4, v6, Lw70/n;->b:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast v4, Ld20/z;

    .line 186
    .line 187
    new-instance v9, Lkp/z;

    .line 188
    .line 189
    const/16 v10, 0x1d

    .line 190
    .line 191
    invoke-direct {v9, v10, v6}, Lkp/z;-><init>(ILjava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    iput-object v7, v4, Ld20/z;->e:Ljava/lang/Object;

    .line 195
    .line 196
    iput-object v9, v4, Ld20/z;->f:Ljava/lang/Object;

    .line 197
    .line 198
    iput-object v8, v4, Ld20/z;->g:Ljava/lang/Object;

    .line 199
    .line 200
    invoke-static {}, Ln3/l0;->y()Landroid/os/Looper;

    .line 201
    .line 202
    .line 203
    move-result-object v6

    .line 204
    new-instance v7, Ln3/g0;

    .line 205
    .line 206
    new-instance v8, Landroid/os/Handler;

    .line 207
    .line 208
    const/4 v9, 0x0

    .line 209
    invoke-direct {v8, v6, v9}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    .line 210
    .line 211
    .line 212
    invoke-direct {v7, v8}, Ln3/g0;-><init>(Landroid/os/Handler;)V

    .line 213
    .line 214
    .line 215
    iput-object v7, v4, Ld20/z;->i:Ljava/lang/Object;

    .line 216
    .line 217
    new-instance v6, Lj4/n;

    .line 218
    .line 219
    const-string v7, "SteeringManifestTracker"

    .line 220
    .line 221
    invoke-direct {v6, v7}, Lj4/n;-><init>(Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    iput-object v6, v4, Ld20/z;->j:Ljava/lang/Object;

    .line 225
    .line 226
    iput-boolean v5, v4, Ld20/z;->a:Z

    .line 227
    .line 228
    invoke-virtual {v4}, Ld20/z;->b()V

    .line 229
    .line 230
    .line 231
    :cond_e6
    iget-object v4, v1, La4/f;->P:Lhx/m0;

    .line 232
    .line 233
    const/4 v6, 0x0

    .line 234
    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v4

    .line 238
    check-cast v4, La4/d0;

    .line 239
    .line 240
    invoke-virtual {v4}, La4/d0;->b()Landroid/net/Uri;

    .line 241
    .line 242
    .line 243
    move-result-object v4

    .line 244
    iput-object v4, v1, La4/f;->T:Landroid/net/Uri;

    .line 245
    .line 246
    iget-object v4, v1, La4/f;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 247
    .line 248
    new-instance v7, La4/b;

    .line 249
    .line 250
    invoke-direct {v7, v1}, La4/b;-><init>(La4/f;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v4, v7}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 254
    .line 255
    .line 256
    iget-object v4, v1, La4/f;->P:Lhx/m0;

    .line 257
    .line 258
    invoke-virtual {v1, v4, v5}, La4/f;->a(Ljava/util/List;Z)V

    .line 259
    .line 260
    .line 261
    iget-object v4, v1, La4/f;->Q:Lhx/m0;

    .line 262
    .line 263
    invoke-virtual {v1, v4, v6}, La4/f;->a(Ljava/util/List;Z)V

    .line 264
    .line 265
    .line 266
    iget-object v4, v1, La4/f;->R:Lhx/m0;

    .line 267
    .line 268
    invoke-virtual {v1, v4, v6}, La4/f;->a(Ljava/util/List;Z)V

    .line 269
    .line 270
    .line 271
    iget-object v4, v1, La4/f;->S:Lhx/m0;

    .line 272
    .line 273
    invoke-virtual {v1, v4, v6}, La4/f;->a(Ljava/util/List;Z)V

    .line 274
    .line 275
    .line 276
    new-instance v7, Lf4/t;

    .line 277
    .line 278
    iget-wide v8, v0, Lj4/p;->a:J

    .line 279
    .line 280
    iget-object v10, v0, Lj4/p;->b:Lq3/k;

    .line 281
    .line 282
    move-wide/from16 v11, p2

    .line 283
    .line 284
    invoke-direct/range {v7 .. v12}, Lf4/t;-><init>(JLq3/k;J)V

    .line 285
    .line 286
    .line 287
    iget-object v4, v0, Lj4/p;->d:Lq3/y;

    .line 288
    .line 289
    iget-object v5, v4, Lq3/y;->i:Landroid/net/Uri;

    .line 290
    .line 291
    iput-object v5, v7, Lf4/t;->d:Landroid/net/Uri;

    .line 292
    .line 293
    iget-object v5, v4, Lq3/y;->v:Ljava/util/Map;

    .line 294
    .line 295
    iput-object v5, v7, Lf4/t;->e:Ljava/util/Map;

    .line 296
    .line 297
    move-wide/from16 v8, p4

    .line 298
    .line 299
    iput-wide v8, v7, Lf4/t;->f:J

    .line 300
    .line 301
    iget-wide v4, v4, Lq3/y;->e:J

    .line 302
    .line 303
    iput-wide v4, v7, Lf4/t;->g:J

    .line 304
    .line 305
    new-instance v9, Lf4/u;

    .line 306
    .line 307
    invoke-direct {v9, v7}, Lf4/u;-><init>(Lf4/t;)V

    .line 308
    .line 309
    .line 310
    iget-object v4, v1, La4/f;->v:Ljava/util/HashMap;

    .line 311
    .line 312
    iget-object v5, v1, La4/f;->T:Landroid/net/Uri;

    .line 313
    .line 314
    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object v4

    .line 318
    check-cast v4, La4/e;

    .line 319
    .line 320
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 321
    .line 322
    .line 323
    if-eqz v3, :cond_160

    .line 324
    .line 325
    iget-object v0, v0, Lj4/p;->d:Lq3/y;

    .line 326
    .line 327
    iget-object v0, v0, Lq3/y;->i:Landroid/net/Uri;

    .line 328
    .line 329
    check-cast v2, La4/p;

    .line 330
    .line 331
    iget-object v3, v4, La4/e;->b:Ljava/util/HashMap;

    .line 332
    .line 333
    invoke-virtual {v3, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 334
    .line 335
    .line 336
    move-result v4

    .line 337
    invoke-static {v4}, Loq/a;->z(Z)V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    check-cast v0, La4/d;

    .line 345
    .line 346
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 347
    .line 348
    .line 349
    invoke-virtual {v0, v2, v9}, La4/d;->e(La4/p;Lf4/u;)V

    .line 350
    .line 351
    .line 352
    goto :goto_165

    .line 353
    :cond_160
    iget-object v0, v1, La4/f;->T:Landroid/net/Uri;

    .line 354
    .line 355
    invoke-static {v4, v0, v6}, La4/e;->b(La4/e;Landroid/net/Uri;Z)V

    .line 356
    .line 357
    .line 358
    :goto_165
    iget-object v0, v1, La4/f;->i:Lcl/a;

    .line 359
    .line 360
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 361
    .line 362
    .line 363
    iget-object v8, v1, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 364
    .line 365
    const-wide v15, -0x7fffffffffffffffL    # -4.9E-324

    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    const-wide v17, -0x7fffffffffffffffL    # -4.9E-324

    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    const/4 v10, 0x4

    .line 376
    const/4 v11, -0x1

    .line 377
    const/4 v12, 0x0

    .line 378
    const/4 v13, 0x0

    .line 379
    const/4 v14, 0x0

    .line 380
    invoke-virtual/range {v8 .. v18}, Lcom/google/android/gms/internal/fido/f8;->x(Lf4/u;IILk3/w;ILjava/lang/Object;JJ)V

    .line 381
    .line 382
    .line 383
    return-void

    .line 384
    :catch_17f
    move-exception v0

    .line 385
    iput-object v0, v1, La4/f;->N:Lk3/v0;

    .line 386
    .line 387
    return-void
.end method

.method public final d(I)Lhx/m0;
    .registers 3

    .line 1
    if-eqz p1, :cond_16

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p1, v0, :cond_13

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    if-eq p1, v0, :cond_10

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    if-eq p1, v0, :cond_d

    .line 11
    .line 12
    const/4 p1, 0x0

    .line 13
    return-object p1

    .line 14
    :cond_d
    iget-object p1, p0, La4/f;->S:Lhx/m0;

    .line 15
    .line 16
    return-object p1

    .line 17
    :cond_10
    iget-object p1, p0, La4/f;->R:Lhx/m0;

    .line 18
    .line 19
    return-object p1

    .line 20
    :cond_13
    iget-object p1, p0, La4/f;->Q:Lhx/m0;

    .line 21
    .line 22
    return-object p1

    .line 23
    :cond_16
    iget-object p1, p0, La4/f;->P:Lhx/m0;

    .line 24
    .line 25
    return-object p1
.end method

.method public final e(Landroid/net/Uri;)Landroid/net/Uri;
    .registers 5

    .line 1
    iget-object v0, p0, La4/f;->U:La4/p;

    .line 2
    .line 3
    if-eqz v0, :cond_35

    .line 4
    .line 5
    iget-object v1, v0, La4/p;->v:La4/o;

    .line 6
    .line 7
    iget-boolean v1, v1, La4/o;->e:Z

    .line 8
    .line 9
    if-eqz v1, :cond_35

    .line 10
    .line 11
    iget-object v0, v0, La4/p;->t:Lhx/p0;

    .line 12
    .line 13
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, La4/l;

    .line 18
    .line 19
    if-eqz v0, :cond_35

    .line 20
    .line 21
    invoke-virtual {p1}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iget-wide v1, v0, La4/l;->b:J

    .line 26
    .line 27
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v2, "_HLS_msn"

    .line 32
    .line 33
    invoke-virtual {p1, v2, v1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 34
    .line 35
    .line 36
    iget v0, v0, La4/l;->c:I

    .line 37
    .line 38
    const/4 v1, -0x1

    .line 39
    if-eq v0, v1, :cond_31

    .line 40
    .line 41
    const-string v1, "_HLS_part"

    .line 42
    .line 43
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {p1, v1, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 48
    .line 49
    .line 50
    :cond_31
    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    :cond_35
    return-object p1
.end method

.method public final f(La4/d0;J)Z
    .registers 9

    .line 1
    iget-object v0, p0, La4/f;->v:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {p1}, La4/d0;->b()Landroid/net/Uri;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    check-cast p1, La4/e;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    if-eqz p1, :cond_33

    .line 15
    .line 16
    iget-object p1, p1, La4/e;->b:Ljava/util/HashMap;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const/4 v1, 0x1

    .line 27
    move v2, v1

    .line 28
    :goto_1b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-eqz v3, :cond_32

    .line 33
    .line 34
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, La4/d;

    .line 39
    .line 40
    iget-wide v3, v3, La4/d;->K:J

    .line 41
    .line 42
    cmp-long v3, p2, v3

    .line 43
    .line 44
    if-gtz v3, :cond_2f

    .line 45
    .line 46
    move v3, v1

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move v3, v0

    .line 49
    :goto_30
    and-int/2addr v2, v3

    .line 50
    goto :goto_1b

    .line 51
    :cond_32
    return v2

    .line 52
    :cond_33
    return v0
.end method

.method public final g(Landroid/net/Uri;J)Z
    .registers 5

    .line 1
    iget-object v0, p0, La4/f;->v:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La4/e;

    .line 8
    .line 9
    if-eqz v0, :cond_f

    .line 10
    .line 11
    invoke-virtual {v0, p1, p2, p3}, La4/e;->d(Landroid/net/Uri;J)Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    return p1

    .line 16
    :cond_f
    const/4 p1, 0x0

    .line 17
    return p1
.end method

.method public final h(Lj4/k;JJI)V
    .registers 22

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    check-cast v0, Lj4/p;

    .line 4
    .line 5
    new-instance v1, Lf4/t;

    .line 6
    .line 7
    iget-wide v2, v0, Lj4/p;->a:J

    .line 8
    .line 9
    iget-object v4, v0, Lj4/p;->b:Lq3/k;

    .line 10
    .line 11
    move-wide/from16 v5, p2

    .line 12
    .line 13
    invoke-direct/range {v1 .. v6}, Lf4/t;-><init>(JLq3/k;J)V

    .line 14
    .line 15
    .line 16
    if-eqz p6, :cond_23

    .line 17
    .line 18
    iget-object v2, v0, Lj4/p;->d:Lq3/y;

    .line 19
    .line 20
    iget-object v3, v2, Lq3/y;->i:Landroid/net/Uri;

    .line 21
    .line 22
    iput-object v3, v1, Lf4/t;->d:Landroid/net/Uri;

    .line 23
    .line 24
    iget-object v3, v2, Lq3/y;->v:Ljava/util/Map;

    .line 25
    .line 26
    iput-object v3, v1, Lf4/t;->e:Ljava/util/Map;

    .line 27
    .line 28
    move-wide/from16 v3, p4

    .line 29
    .line 30
    iput-wide v3, v1, Lf4/t;->f:J

    .line 31
    .line 32
    iget-wide v2, v2, Lq3/y;->e:J

    .line 33
    .line 34
    iput-wide v2, v1, Lf4/t;->g:J

    .line 35
    .line 36
    :cond_23
    iget-object v3, p0, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 37
    .line 38
    new-instance v4, Lf4/u;

    .line 39
    .line 40
    invoke-direct {v4, v1}, Lf4/u;-><init>(Lf4/t;)V

    .line 41
    .line 42
    .line 43
    iget v5, v0, Lj4/p;->c:I

    .line 44
    .line 45
    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    const/4 v6, -0x1

    .line 56
    const/4 v7, 0x0

    .line 57
    const/4 v8, 0x0

    .line 58
    const/4 v9, 0x0

    .line 59
    move/from16 v14, p6

    .line 60
    .line 61
    invoke-virtual/range {v3 .. v14}, Lcom/google/android/gms/internal/fido/f8;->H(Lf4/u;IILk3/w;ILjava/lang/Object;JJI)V

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public final i(Landroid/net/Uri;)Z
    .registers 9

    .line 1
    iget-object v0, p0, La4/f;->v:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La4/e;

    .line 8
    .line 9
    if-nez v0, :cond_b

    .line 10
    .line 11
    goto :goto_4a

    .line 12
    :cond_b
    iget-object v0, v0, La4/e;->b:Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    invoke-static {v1}, Loq/a;->z(Z)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, La4/d;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iget-object v0, p1, La4/d;->w:La4/p;

    .line 31
    .line 32
    if-nez v0, :cond_22

    .line 33
    .line 34
    goto :goto_4a

    .line 35
    :cond_22
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 36
    .line 37
    .line 38
    move-result-wide v0

    .line 39
    iget-object v2, p1, La4/d;->w:La4/p;

    .line 40
    .line 41
    iget-wide v2, v2, La4/p;->u:J

    .line 42
    .line 43
    invoke-static {v2, v3}, Ln3/l0;->g0(J)J

    .line 44
    .line 45
    .line 46
    move-result-wide v2

    .line 47
    const-wide/16 v4, 0x7530

    .line 48
    .line 49
    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->max(JJ)J

    .line 50
    .line 51
    .line 52
    move-result-wide v2

    .line 53
    iget-object v4, p1, La4/d;->w:La4/p;

    .line 54
    .line 55
    iget-boolean v5, v4, La4/p;->o:Z

    .line 56
    .line 57
    const/4 v6, 0x1

    .line 58
    if-nez v5, :cond_4c

    .line 59
    .line 60
    iget v4, v4, La4/p;->d:I

    .line 61
    .line 62
    const/4 v5, 0x2

    .line 63
    if-eq v4, v5, :cond_4c

    .line 64
    .line 65
    if-eq v4, v6, :cond_4c

    .line 66
    .line 67
    iget-wide v4, p1, La4/d;->x:J

    .line 68
    .line 69
    add-long/2addr v4, v2

    .line 70
    cmp-long p1, v4, v0

    .line 71
    .line 72
    if-lez p1, :cond_4a

    .line 73
    .line 74
    goto :goto_4c

    .line 75
    :cond_4a
    :goto_4a
    const/4 p1, 0x0

    .line 76
    return p1

    .line 77
    :cond_4c
    :goto_4c
    return v6
.end method

.method public final j(ZLandroid/net/Uri;)V
    .registers 7

    .line 1
    iget-object v0, p0, La4/f;->T:Landroid/net/Uri;

    .line 2
    .line 3
    invoke-virtual {p2, v0}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_57

    .line 8
    .line 9
    iget-object v0, p0, La4/f;->v:Ljava/util/HashMap;

    .line 10
    .line 11
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, La4/e;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    if-eqz v1, :cond_16

    .line 19
    .line 20
    iget-boolean v1, v1, La4/e;->c:Z

    .line 21
    .line 22
    goto :goto_17

    .line 23
    :cond_16
    move v1, v2

    .line 24
    :goto_17
    if-eqz v1, :cond_57

    .line 25
    .line 26
    iget-object v1, p0, La4/f;->U:La4/p;

    .line 27
    .line 28
    if-eqz v1, :cond_22

    .line 29
    .line 30
    iget-boolean v1, v1, La4/p;->o:Z

    .line 31
    .line 32
    if-eqz v1, :cond_22

    .line 33
    .line 34
    goto :goto_57

    .line 35
    :cond_22
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    check-cast v0, La4/e;

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    invoke-static {v0, p2}, La4/e;->a(La4/e;Landroid/net/Uri;)La4/p;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    if-eqz v1, :cond_36

    .line 49
    .line 50
    iget-boolean v3, v1, La4/p;->o:Z

    .line 51
    .line 52
    if-eqz v3, :cond_36

    .line 53
    .line 54
    const/4 v2, 0x1

    .line 55
    :cond_36
    if-nez v2, :cond_44

    .line 56
    .line 57
    if-eqz p1, :cond_44

    .line 58
    .line 59
    invoke-virtual {p0, p2}, La4/f;->e(Landroid/net/Uri;)Landroid/net/Uri;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {v0, p2, p1}, La4/e;->e(Landroid/net/Uri;Landroid/net/Uri;)V

    .line 64
    .line 65
    .line 66
    iput-object p2, p0, La4/f;->V:Landroid/net/Uri;

    .line 67
    .line 68
    return-void

    .line 69
    :cond_44
    iput-object p2, p0, La4/f;->T:Landroid/net/Uri;

    .line 70
    .line 71
    if-eqz v2, :cond_50

    .line 72
    .line 73
    iput-object v1, p0, La4/f;->U:La4/p;

    .line 74
    .line 75
    iget-object p1, p0, La4/f;->K:Lz3/j;

    .line 76
    .line 77
    invoke-virtual {p1, v1}, Lz3/j;->u(La4/p;)V

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :cond_50
    invoke-virtual {p0, p2}, La4/f;->e(Landroid/net/Uri;)Landroid/net/Uri;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    invoke-virtual {v0, p2, p1}, La4/e;->e(Landroid/net/Uri;Landroid/net/Uri;)V

    .line 86
    .line 87
    .line 88
    :cond_57
    :goto_57
    return-void
.end method

.method public final k(Landroid/net/Uri;)V
    .registers 5

    .line 1
    iget-object v0, p0, La4/f;->v:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La4/e;

    .line 8
    .line 9
    if-eqz v0, :cond_39

    .line 10
    .line 11
    iget-object v0, v0, La4/e;->b:Ljava/util/HashMap;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    invoke-static {v1}, Loq/a;->z(Z)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    check-cast p1, La4/d;

    .line 25
    .line 26
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    iget-object v0, p1, La4/d;->i:Lj4/n;

    .line 30
    .line 31
    iget-object v1, v0, Lj4/n;->c:Ljava/io/IOException;

    .line 32
    .line 33
    if-nez v1, :cond_38

    .line 34
    .line 35
    iget-object v0, v0, Lj4/n;->b:Lj4/j;

    .line 36
    .line 37
    if-eqz v0, :cond_32

    .line 38
    .line 39
    iget v1, v0, Lj4/j;->e:I

    .line 40
    .line 41
    iget-object v2, v0, Lj4/j;->v:Ljava/io/IOException;

    .line 42
    .line 43
    if-eqz v2, :cond_32

    .line 44
    .line 45
    iget v0, v0, Lj4/j;->w:I

    .line 46
    .line 47
    if-gt v0, v1, :cond_31

    .line 48
    .line 49
    goto :goto_32

    .line 50
    :cond_31
    throw v2

    .line 51
    :cond_32
    :goto_32
    iget-object p1, p1, La4/d;->M:Ljava/io/IOException;

    .line 52
    .line 53
    if-nez p1, :cond_37

    .line 54
    .line 55
    goto :goto_39

    .line 56
    :cond_37
    throw p1

    .line 57
    :cond_38
    throw v1

    .line 58
    :cond_39
    :goto_39
    return-void
.end method

.method public final t(Lj4/k;JJZ)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lj4/p;

    .line 6
    .line 7
    new-instance v2, Lf4/t;

    .line 8
    .line 9
    iget-wide v3, v1, Lj4/p;->a:J

    .line 10
    .line 11
    iget-object v5, v1, Lj4/p;->b:Lq3/k;

    .line 12
    .line 13
    move-wide/from16 v6, p2

    .line 14
    .line 15
    invoke-direct/range {v2 .. v7}, Lf4/t;-><init>(JLq3/k;J)V

    .line 16
    .line 17
    .line 18
    iget-object v1, v1, Lj4/p;->d:Lq3/y;

    .line 19
    .line 20
    iget-object v3, v1, Lq3/y;->i:Landroid/net/Uri;

    .line 21
    .line 22
    iput-object v3, v2, Lf4/t;->d:Landroid/net/Uri;

    .line 23
    .line 24
    iget-object v3, v1, Lq3/y;->v:Ljava/util/Map;

    .line 25
    .line 26
    iput-object v3, v2, Lf4/t;->e:Ljava/util/Map;

    .line 27
    .line 28
    move-wide/from16 v3, p4

    .line 29
    .line 30
    iput-wide v3, v2, Lf4/t;->f:J

    .line 31
    .line 32
    iget-wide v3, v1, Lq3/y;->e:J

    .line 33
    .line 34
    iput-wide v3, v2, Lf4/t;->g:J

    .line 35
    .line 36
    new-instance v6, Lf4/u;

    .line 37
    .line 38
    invoke-direct {v6, v2}, Lf4/u;-><init>(Lf4/t;)V

    .line 39
    .line 40
    .line 41
    iget-object v1, v0, La4/f;->i:Lcl/a;

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    iget-object v5, v0, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 47
    .line 48
    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    const-wide v14, -0x7fffffffffffffffL    # -4.9E-324

    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    const/4 v7, 0x4

    .line 59
    const/4 v8, -0x1

    .line 60
    const/4 v9, 0x0

    .line 61
    const/4 v10, 0x0

    .line 62
    const/4 v11, 0x0

    .line 63
    invoke-virtual/range {v5 .. v15}, Lcom/google/android/gms/internal/fido/f8;->u(Lf4/u;IILk3/w;ILjava/lang/Object;JJ)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public final v(Lj4/k;JJLjava/io/IOException;I)Lgs/f;
    .registers 14

    .line 1
    check-cast p1, Lj4/p;

    .line 2
    .line 3
    new-instance v0, Lf4/t;

    .line 4
    .line 5
    iget-wide v1, p1, Lj4/p;->a:J

    .line 6
    .line 7
    iget-object v3, p1, Lj4/p;->b:Lq3/k;

    .line 8
    .line 9
    move-wide v4, p2

    .line 10
    invoke-direct/range {v0 .. v5}, Lf4/t;-><init>(JLq3/k;J)V

    .line 11
    .line 12
    .line 13
    iget-object p2, p1, Lj4/p;->d:Lq3/y;

    .line 14
    .line 15
    iget-object p3, p2, Lq3/y;->i:Landroid/net/Uri;

    .line 16
    .line 17
    iput-object p3, v0, Lf4/t;->d:Landroid/net/Uri;

    .line 18
    .line 19
    iget-object p3, p2, Lq3/y;->v:Ljava/util/Map;

    .line 20
    .line 21
    iput-object p3, v0, Lf4/t;->e:Ljava/util/Map;

    .line 22
    .line 23
    iput-wide p4, v0, Lf4/t;->f:J

    .line 24
    .line 25
    iget-wide p2, p2, Lq3/y;->e:J

    .line 26
    .line 27
    iput-wide p2, v0, Lf4/t;->g:J

    .line 28
    .line 29
    new-instance p2, Lf4/u;

    .line 30
    .line 31
    invoke-direct {p2, v0}, Lf4/u;-><init>(Lf4/t;)V

    .line 32
    .line 33
    .line 34
    iget p1, p1, Lj4/p;->c:I

    .line 35
    .line 36
    iget-object p3, p0, La4/f;->i:Lcl/a;

    .line 37
    .line 38
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    move-object p3, p6

    .line 42
    :goto_29
    const/4 p4, 0x1

    .line 43
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    if-eqz p3, :cond_56

    .line 49
    .line 50
    instance-of p5, p3, Lk3/v0;

    .line 51
    .line 52
    if-nez p5, :cond_54

    .line 53
    .line 54
    instance-of p5, p3, Ljava/io/FileNotFoundException;

    .line 55
    .line 56
    if-nez p5, :cond_54

    .line 57
    .line 58
    instance-of p5, p3, Lq3/p;

    .line 59
    .line 60
    if-nez p5, :cond_54

    .line 61
    .line 62
    instance-of p5, p3, Lj4/m;

    .line 63
    .line 64
    if-nez p5, :cond_54

    .line 65
    .line 66
    instance-of p5, p3, Lq3/j;

    .line 67
    .line 68
    if-eqz p5, :cond_4f

    .line 69
    .line 70
    move-object p5, p3

    .line 71
    check-cast p5, Lq3/j;

    .line 72
    .line 73
    iget p5, p5, Lq3/j;->d:I

    .line 74
    .line 75
    const/16 v2, 0x7d8

    .line 76
    .line 77
    if-ne p5, v2, :cond_4f

    .line 78
    .line 79
    goto :goto_54

    .line 80
    :cond_4f
    invoke-virtual {p3}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 81
    .line 82
    .line 83
    move-result-object p3

    .line 84
    goto :goto_29

    .line 85
    :cond_54
    :goto_54
    move-wide v2, v0

    .line 86
    goto :goto_60

    .line 87
    :cond_56
    sub-int/2addr p7, p4

    .line 88
    mul-int/lit16 p7, p7, 0x3e8

    .line 89
    .line 90
    const/16 p3, 0x1388

    .line 91
    .line 92
    invoke-static {p7, p3}, Ljava/lang/Math;->min(II)I

    .line 93
    .line 94
    .line 95
    move-result p3

    .line 96
    int-to-long v2, p3

    .line 97
    :goto_60
    cmp-long p3, v2, v0

    .line 98
    .line 99
    const/4 p5, 0x0

    .line 100
    if-nez p3, :cond_66

    .line 101
    .line 102
    goto :goto_67

    .line 103
    :cond_66
    move p4, p5

    .line 104
    :goto_67
    iget-object p3, p0, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 105
    .line 106
    invoke-virtual {p3, p2, p1, p6, p4}, Lcom/google/android/gms/internal/fido/f8;->C(Lf4/u;ILjava/io/IOException;Z)V

    .line 107
    .line 108
    .line 109
    if-eqz p4, :cond_71

    .line 110
    .line 111
    sget-object p1, Lj4/n;->f:Lgs/f;

    .line 112
    .line 113
    return-object p1

    .line 114
    :cond_71
    new-instance p1, Lgs/f;

    .line 115
    .line 116
    const/4 p2, 0x0

    .line 117
    invoke-direct {p1, p5, v2, v3, p2}, Lgs/f;-><init>(IJB)V

    .line 118
    .line 119
    .line 120
    return-object p1
.end method
