###### Class a4.k (a4.k)
.class public final La4/k;
.super La4/n;
.source "SourceFile"


# instance fields
.field public final N:Z

.field public final O:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZZZ)V
    .registers 18

    .line 1
    invoke-direct/range {p0 .. p15}, La4/n;-><init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZ)V

    .line 2
    .line 3
    .line 4
    move/from16 p1, p16

    .line 5
    .line 6
    iput-boolean p1, p0, La4/k;->N:Z

    .line 7
    .line 8
    move/from16 p1, p17

    .line 9
    .line 10
    iput-boolean p1, p0, La4/k;->O:Z

    .line 11
    .line 12
    return-void
.end method
