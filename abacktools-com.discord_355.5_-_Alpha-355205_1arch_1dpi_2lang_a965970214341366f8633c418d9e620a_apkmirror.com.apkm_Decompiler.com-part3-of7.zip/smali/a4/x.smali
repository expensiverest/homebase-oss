###### Class a4.x (a4.x)
.class public final La4/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lj4/o;


# static fields
.field public static final A0:Ljava/util/regex/Pattern;

.field public static final B0:Ljava/util/regex/Pattern;

.field public static final C0:Ljava/util/regex/Pattern;

.field public static final D0:Ljava/util/regex/Pattern;

.field public static final E0:Ljava/util/regex/Pattern;

.field public static final F0:Ljava/util/regex/Pattern;

.field public static final G0:Ljava/util/regex/Pattern;

.field public static final H0:Ljava/util/regex/Pattern;

.field public static final I0:Ljava/util/regex/Pattern;

.field public static final J:Ljava/util/regex/Pattern;

.field public static final J0:Ljava/util/regex/Pattern;

.field public static final K:Ljava/util/regex/Pattern;

.field public static final K0:Ljava/util/regex/Pattern;

.field public static final L:Ljava/util/regex/Pattern;

.field public static final L0:Ljava/util/regex/Pattern;

.field public static final M:Ljava/util/regex/Pattern;

.field public static final M0:Ljava/util/regex/Pattern;

.field public static final N:Ljava/util/regex/Pattern;

.field public static final N0:Ljava/util/regex/Pattern;

.field public static final O:Ljava/util/regex/Pattern;

.field public static final O0:Ljava/util/regex/Pattern;

.field public static final P:Ljava/util/regex/Pattern;

.field public static final P0:Ljava/util/regex/Pattern;

.field public static final Q:Ljava/util/regex/Pattern;

.field public static final Q0:Ljava/util/regex/Pattern;

.field public static final R:Ljava/util/regex/Pattern;

.field public static final R0:Ljava/util/regex/Pattern;

.field public static final S:Ljava/util/regex/Pattern;

.field public static final S0:Ljava/util/regex/Pattern;

.field public static final T:Ljava/util/regex/Pattern;

.field public static final T0:Ljava/util/regex/Pattern;

.field public static final U:Ljava/util/regex/Pattern;

.field public static final U0:Ljava/util/regex/Pattern;

.field public static final V:Ljava/util/regex/Pattern;

.field public static final V0:Ljava/util/regex/Pattern;

.field public static final W:Ljava/util/regex/Pattern;

.field public static final W0:Ljava/util/regex/Pattern;

.field public static final X:Ljava/util/regex/Pattern;

.field public static final X0:Ljava/util/regex/Pattern;

.field public static final Y:Ljava/util/regex/Pattern;

.field public static final Y0:Ljava/util/regex/Pattern;

.field public static final Z:Ljava/util/regex/Pattern;

.field public static final Z0:Ljava/util/regex/Pattern;

.field public static final a0:Ljava/util/regex/Pattern;

.field public static final a1:Ljava/util/regex/Pattern;

.field public static final b0:Ljava/util/regex/Pattern;

.field public static final b1:Ljava/util/regex/Pattern;

.field public static final c0:Ljava/util/regex/Pattern;

.field public static final c1:Ljava/util/regex/Pattern;

.field public static final d0:Ljava/util/regex/Pattern;

.field public static final d1:Ljava/util/regex/Pattern;

.field public static final e0:Ljava/util/regex/Pattern;

.field public static final e1:Ljava/util/regex/Pattern;

.field public static final f0:Ljava/util/regex/Pattern;

.field public static final f1:Ljava/util/regex/Pattern;

.field public static final g0:Ljava/util/regex/Pattern;

.field public static final g1:Ljava/util/regex/Pattern;

.field public static final h0:Ljava/util/regex/Pattern;

.field public static final h1:Ljava/util/regex/Pattern;

.field public static final i:Ljava/util/regex/Pattern;

.field public static final i0:Ljava/util/regex/Pattern;

.field public static final j0:Ljava/util/regex/Pattern;

.field public static final k0:Ljava/util/regex/Pattern;

.field public static final l0:Ljava/util/regex/Pattern;

.field public static final m0:Ljava/util/regex/Pattern;

.field public static final n0:Ljava/util/regex/Pattern;

.field public static final o0:Ljava/util/regex/Pattern;

.field public static final p0:Ljava/util/regex/Pattern;

.field public static final q0:Ljava/util/regex/Pattern;

.field public static final r0:Ljava/util/regex/Pattern;

.field public static final s0:Ljava/util/regex/Pattern;

.field public static final t0:Ljava/util/regex/Pattern;

.field public static final u0:Ljava/util/regex/Pattern;

.field public static final v:Ljava/util/regex/Pattern;

.field public static final v0:Ljava/util/regex/Pattern;

.field public static final w:Ljava/util/regex/Pattern;

.field public static final w0:Ljava/util/regex/Pattern;

.field public static final x:Ljava/util/regex/Pattern;

.field public static final x0:Ljava/util/regex/Pattern;

.field public static final y:Ljava/util/regex/Pattern;

.field public static final y0:Ljava/util/regex/Pattern;

.field public static final z0:Ljava/util/regex/Pattern;


# instance fields
.field public final d:La4/s;

.field public final e:La4/p;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const-string v0, "AVERAGE-BANDWIDTH=(\\d+)\\b"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, La4/x;->i:Ljava/util/regex/Pattern;

    .line 8
    .line 9
    const-string v0, "VIDEO=\"((?:.|\u000c)+?)\""

    .line 10
    .line 11
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, La4/x;->v:Ljava/util/regex/Pattern;

    .line 16
    .line 17
    const-string v0, "AUDIO=\"((?:.|\u000c)+?)\""

    .line 18
    .line 19
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sput-object v0, La4/x;->w:Ljava/util/regex/Pattern;

    .line 24
    .line 25
    const-string v0, "SUBTITLES=\"((?:.|\u000c)+?)\""

    .line 26
    .line 27
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, La4/x;->x:Ljava/util/regex/Pattern;

    .line 32
    .line 33
    const-string v0, "CLOSED-CAPTIONS=\"((?:.|\u000c)+?)\""

    .line 34
    .line 35
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sput-object v0, La4/x;->y:Ljava/util/regex/Pattern;

    .line 40
    .line 41
    const-string v0, "[^-]BANDWIDTH=(\\d+)\\b"

    .line 42
    .line 43
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sput-object v0, La4/x;->J:Ljava/util/regex/Pattern;

    .line 48
    .line 49
    const-string v0, "CHANNELS=\"((?:.|\u000c)+?)\""

    .line 50
    .line 51
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sput-object v0, La4/x;->K:Ljava/util/regex/Pattern;

    .line 56
    .line 57
    const-string v0, "SAMPLE-RATE=(\\d+)\\b"

    .line 58
    .line 59
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    sput-object v0, La4/x;->L:Ljava/util/regex/Pattern;

    .line 64
    .line 65
    const-string v0, "VIDEO-RANGE=(SDR|PQ|HLG)"

    .line 66
    .line 67
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    sput-object v0, La4/x;->M:Ljava/util/regex/Pattern;

    .line 72
    .line 73
    const-string v0, "CODECS=\"((?:.|\u000c)+?)\""

    .line 74
    .line 75
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    sput-object v0, La4/x;->N:Ljava/util/regex/Pattern;

    .line 80
    .line 81
    const-string v0, "SUPPLEMENTAL-CODECS=\"((?:.|\u000c)+?)\""

    .line 82
    .line 83
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    sput-object v0, La4/x;->O:Ljava/util/regex/Pattern;

    .line 88
    .line 89
    const-string v0, "RESOLUTION=(\\d+x\\d+)"

    .line 90
    .line 91
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    sput-object v0, La4/x;->P:Ljava/util/regex/Pattern;

    .line 96
    .line 97
    const-string v0, "FRAME-RATE=([\\d\\.]+)\\b"

    .line 98
    .line 99
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    sput-object v0, La4/x;->Q:Ljava/util/regex/Pattern;

    .line 104
    .line 105
    const-string v0, "SCORE=([\\d\\.]+)\\b"

    .line 106
    .line 107
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    sput-object v0, La4/x;->R:Ljava/util/regex/Pattern;

    .line 112
    .line 113
    const-string v0, "SERVER-URI=\"((?:.|\u000c)+?)\""

    .line 114
    .line 115
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    sput-object v0, La4/x;->S:Ljava/util/regex/Pattern;

    .line 120
    .line 121
    const-string v0, "PATHWAY-ID=\"((?:.|\u000c)+?)\""

    .line 122
    .line 123
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    sput-object v0, La4/x;->T:Ljava/util/regex/Pattern;

    .line 128
    .line 129
    const-string v0, "STABLE-VARIANT-ID=\"((?:.|\u000c)+?)\""

    .line 130
    .line 131
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    sput-object v0, La4/x;->U:Ljava/util/regex/Pattern;

    .line 136
    .line 137
    const-string v0, "STABLE-RENDITION-ID=\"((?:.|\u000c)+?)\""

    .line 138
    .line 139
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    sput-object v0, La4/x;->V:Ljava/util/regex/Pattern;

    .line 144
    .line 145
    const-string v0, "#EXT-X-TARGETDURATION:(\\d+)\\b"

    .line 146
    .line 147
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    sput-object v0, La4/x;->W:Ljava/util/regex/Pattern;

    .line 152
    .line 153
    const-string v0, "DURATION=([\\d\\.]+)\\b"

    .line 154
    .line 155
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    sput-object v0, La4/x;->X:Ljava/util/regex/Pattern;

    .line 160
    .line 161
    const-string v0, "[:,]DURATION=([\\d\\.]+)\\b"

    .line 162
    .line 163
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    sput-object v0, La4/x;->Y:Ljava/util/regex/Pattern;

    .line 168
    .line 169
    const-string v0, "PART-TARGET=([\\d\\.]+)\\b"

    .line 170
    .line 171
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    sput-object v0, La4/x;->Z:Ljava/util/regex/Pattern;

    .line 176
    .line 177
    const-string v0, "#EXT-X-VERSION:(\\d+)\\b"

    .line 178
    .line 179
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    sput-object v0, La4/x;->a0:Ljava/util/regex/Pattern;

    .line 184
    .line 185
    const-string v0, "#EXT-X-PLAYLIST-TYPE:(.+)\\b"

    .line 186
    .line 187
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    sput-object v0, La4/x;->b0:Ljava/util/regex/Pattern;

    .line 192
    .line 193
    const-string v0, "CAN-SKIP-UNTIL=([\\d\\.]+)\\b"

    .line 194
    .line 195
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    sput-object v0, La4/x;->c0:Ljava/util/regex/Pattern;

    .line 200
    .line 201
    const-string v0, "CAN-SKIP-DATERANGES"

    .line 202
    .line 203
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 204
    .line 205
    .line 206
    move-result-object v0

    .line 207
    sput-object v0, La4/x;->d0:Ljava/util/regex/Pattern;

    .line 208
    .line 209
    const-string v0, "SKIPPED-SEGMENTS=(\\d+)\\b"

    .line 210
    .line 211
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    sput-object v0, La4/x;->e0:Ljava/util/regex/Pattern;

    .line 216
    .line 217
    const-string v0, "[:|,]HOLD-BACK=([\\d\\.]+)\\b"

    .line 218
    .line 219
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 220
    .line 221
    .line 222
    move-result-object v0

    .line 223
    sput-object v0, La4/x;->f0:Ljava/util/regex/Pattern;

    .line 224
    .line 225
    const-string v0, "PART-HOLD-BACK=([\\d\\.]+)\\b"

    .line 226
    .line 227
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    sput-object v0, La4/x;->g0:Ljava/util/regex/Pattern;

    .line 232
    .line 233
    const-string v0, "CAN-BLOCK-RELOAD"

    .line 234
    .line 235
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    sput-object v0, La4/x;->h0:Ljava/util/regex/Pattern;

    .line 240
    .line 241
    const-string v0, "#EXT-X-MEDIA-SEQUENCE:(\\d+)\\b"

    .line 242
    .line 243
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    sput-object v0, La4/x;->i0:Ljava/util/regex/Pattern;

    .line 248
    .line 249
    const-string v0, "#EXTINF:([\\d\\.]+)\\b"

    .line 250
    .line 251
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    sput-object v0, La4/x;->j0:Ljava/util/regex/Pattern;

    .line 256
    .line 257
    const-string v0, "#EXTINF:[\\d\\.]+\\b,(.+)"

    .line 258
    .line 259
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    sput-object v0, La4/x;->k0:Ljava/util/regex/Pattern;

    .line 264
    .line 265
    const-string v0, "LAST-MSN=(\\d+)\\b"

    .line 266
    .line 267
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    sput-object v0, La4/x;->l0:Ljava/util/regex/Pattern;

    .line 272
    .line 273
    const-string v0, "LAST-PART=(\\d+)\\b"

    .line 274
    .line 275
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    sput-object v0, La4/x;->m0:Ljava/util/regex/Pattern;

    .line 280
    .line 281
    const-string v0, "TIME-OFFSET=(-?[\\d\\.]+)\\b"

    .line 282
    .line 283
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    sput-object v0, La4/x;->n0:Ljava/util/regex/Pattern;

    .line 288
    .line 289
    const-string v0, "#EXT-X-BYTERANGE:(\\d+(?:@\\d+)?)\\b"

    .line 290
    .line 291
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 292
    .line 293
    .line 294
    move-result-object v0

    .line 295
    sput-object v0, La4/x;->o0:Ljava/util/regex/Pattern;

    .line 296
    .line 297
    const-string v0, "BYTERANGE=\"(\\d+(?:@\\d+)?)\\b\""

    .line 298
    .line 299
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 300
    .line 301
    .line 302
    move-result-object v0

    .line 303
    sput-object v0, La4/x;->p0:Ljava/util/regex/Pattern;

    .line 304
    .line 305
    const-string v0, "BYTERANGE-START=(\\d+)\\b"

    .line 306
    .line 307
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    sput-object v0, La4/x;->q0:Ljava/util/regex/Pattern;

    .line 312
    .line 313
    const-string v0, "BYTERANGE-LENGTH=(\\d+)\\b"

    .line 314
    .line 315
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 316
    .line 317
    .line 318
    move-result-object v0

    .line 319
    sput-object v0, La4/x;->r0:Ljava/util/regex/Pattern;

    .line 320
    .line 321
    const-string v0, "METHOD=(NONE|AES-128|SAMPLE-AES|SAMPLE-AES-CENC|SAMPLE-AES-CTR)\\s*(?:,|$)"

    .line 322
    .line 323
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 324
    .line 325
    .line 326
    move-result-object v0

    .line 327
    sput-object v0, La4/x;->s0:Ljava/util/regex/Pattern;

    .line 328
    .line 329
    const-string v0, "KEYFORMAT=\"((?:.|\u000c)+?)\""

    .line 330
    .line 331
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    sput-object v0, La4/x;->t0:Ljava/util/regex/Pattern;

    .line 336
    .line 337
    const-string v0, "KEYFORMATVERSIONS=\"((?:.|\u000c)+?)\""

    .line 338
    .line 339
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    sput-object v0, La4/x;->u0:Ljava/util/regex/Pattern;

    .line 344
    .line 345
    const-string v0, "URI=\"((?:.|\u000c)+?)\""

    .line 346
    .line 347
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    sput-object v0, La4/x;->v0:Ljava/util/regex/Pattern;

    .line 352
    .line 353
    const-string v0, "IV=([^,.*]+)"

    .line 354
    .line 355
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 356
    .line 357
    .line 358
    move-result-object v0

    .line 359
    sput-object v0, La4/x;->w0:Ljava/util/regex/Pattern;

    .line 360
    .line 361
    const-string v0, "TYPE=(AUDIO|VIDEO|SUBTITLES|CLOSED-CAPTIONS)"

    .line 362
    .line 363
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 364
    .line 365
    .line 366
    move-result-object v0

    .line 367
    sput-object v0, La4/x;->x0:Ljava/util/regex/Pattern;

    .line 368
    .line 369
    const-string v0, "TYPE=(PART|MAP)"

    .line 370
    .line 371
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    sput-object v0, La4/x;->y0:Ljava/util/regex/Pattern;

    .line 376
    .line 377
    const-string v0, "LANGUAGE=\"((?:.|\u000c)+?)\""

    .line 378
    .line 379
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 380
    .line 381
    .line 382
    move-result-object v0

    .line 383
    sput-object v0, La4/x;->z0:Ljava/util/regex/Pattern;

    .line 384
    .line 385
    const-string v0, "NAME=\"((?:.|\u000c)+?)\""

    .line 386
    .line 387
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    sput-object v0, La4/x;->A0:Ljava/util/regex/Pattern;

    .line 392
    .line 393
    const-string v0, "QUERYPARAM=\"((?:.|\u000c)+?)\""

    .line 394
    .line 395
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 396
    .line 397
    .line 398
    move-result-object v0

    .line 399
    sput-object v0, La4/x;->B0:Ljava/util/regex/Pattern;

    .line 400
    .line 401
    const-string v0, "GROUP-ID=\"((?:.|\u000c)+?)\""

    .line 402
    .line 403
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 404
    .line 405
    .line 406
    move-result-object v0

    .line 407
    sput-object v0, La4/x;->C0:Ljava/util/regex/Pattern;

    .line 408
    .line 409
    const-string v0, "CHARACTERISTICS=\"((?:.|\u000c)+?)\""

    .line 410
    .line 411
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 412
    .line 413
    .line 414
    move-result-object v0

    .line 415
    sput-object v0, La4/x;->D0:Ljava/util/regex/Pattern;

    .line 416
    .line 417
    const-string v0, "INSTREAM-ID=\"((?:CC|SERVICE)\\d+)\""

    .line 418
    .line 419
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 420
    .line 421
    .line 422
    move-result-object v0

    .line 423
    sput-object v0, La4/x;->E0:Ljava/util/regex/Pattern;

    .line 424
    .line 425
    const-string v0, "AUTOSELECT"

    .line 426
    .line 427
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 428
    .line 429
    .line 430
    move-result-object v0

    .line 431
    sput-object v0, La4/x;->F0:Ljava/util/regex/Pattern;

    .line 432
    .line 433
    const-string v0, "DEFAULT"

    .line 434
    .line 435
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 436
    .line 437
    .line 438
    move-result-object v0

    .line 439
    sput-object v0, La4/x;->G0:Ljava/util/regex/Pattern;

    .line 440
    .line 441
    const-string v0, "FORCED"

    .line 442
    .line 443
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 444
    .line 445
    .line 446
    move-result-object v0

    .line 447
    sput-object v0, La4/x;->H0:Ljava/util/regex/Pattern;

    .line 448
    .line 449
    const-string v0, "INDEPENDENT"

    .line 450
    .line 451
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 452
    .line 453
    .line 454
    move-result-object v0

    .line 455
    sput-object v0, La4/x;->I0:Ljava/util/regex/Pattern;

    .line 456
    .line 457
    const-string v0, "GAP"

    .line 458
    .line 459
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 460
    .line 461
    .line 462
    move-result-object v0

    .line 463
    sput-object v0, La4/x;->J0:Ljava/util/regex/Pattern;

    .line 464
    .line 465
    const-string v0, "PRECISE"

    .line 466
    .line 467
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 468
    .line 469
    .line 470
    move-result-object v0

    .line 471
    sput-object v0, La4/x;->K0:Ljava/util/regex/Pattern;

    .line 472
    .line 473
    const-string v0, "VALUE=\"((?:.|\u000c)+?)\""

    .line 474
    .line 475
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 476
    .line 477
    .line 478
    move-result-object v0

    .line 479
    sput-object v0, La4/x;->L0:Ljava/util/regex/Pattern;

    .line 480
    .line 481
    const-string v0, "IMPORT=\"((?:.|\u000c)+?)\""

    .line 482
    .line 483
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 484
    .line 485
    .line 486
    move-result-object v0

    .line 487
    sput-object v0, La4/x;->M0:Ljava/util/regex/Pattern;

    .line 488
    .line 489
    const-string v0, "[:,]ID=\"((?:.|\u000c)+?)\""

    .line 490
    .line 491
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 492
    .line 493
    .line 494
    move-result-object v0

    .line 495
    sput-object v0, La4/x;->N0:Ljava/util/regex/Pattern;

    .line 496
    .line 497
    const-string v0, "CLASS=\"((?:.|\u000c)+?)\""

    .line 498
    .line 499
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    sput-object v0, La4/x;->O0:Ljava/util/regex/Pattern;

    .line 504
    .line 505
    const-string v0, "START-DATE=\"((?:.|\u000c)+?)\""

    .line 506
    .line 507
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 508
    .line 509
    .line 510
    move-result-object v0

    .line 511
    sput-object v0, La4/x;->P0:Ljava/util/regex/Pattern;

    .line 512
    .line 513
    const-string v0, "CUE=\"((?:.|\u000c)+?)\""

    .line 514
    .line 515
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 516
    .line 517
    .line 518
    move-result-object v0

    .line 519
    sput-object v0, La4/x;->Q0:Ljava/util/regex/Pattern;

    .line 520
    .line 521
    const-string v0, "END-DATE=\"((?:.|\u000c)+?)\""

    .line 522
    .line 523
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    sput-object v0, La4/x;->R0:Ljava/util/regex/Pattern;

    .line 528
    .line 529
    const-string v0, "PLANNED-DURATION=([\\d\\.]+)\\b"

    .line 530
    .line 531
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 532
    .line 533
    .line 534
    move-result-object v0

    .line 535
    sput-object v0, La4/x;->S0:Ljava/util/regex/Pattern;

    .line 536
    .line 537
    const-string v0, "END-ON-NEXT"

    .line 538
    .line 539
    invoke-static {v0}, La4/x;->a(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 540
    .line 541
    .line 542
    move-result-object v0

    .line 543
    sput-object v0, La4/x;->T0:Ljava/util/regex/Pattern;

    .line 544
    .line 545
    const-string v0, "X-ASSET-URI=\"((?:.|\u000c)+?)\""

    .line 546
    .line 547
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 548
    .line 549
    .line 550
    move-result-object v0

    .line 551
    sput-object v0, La4/x;->U0:Ljava/util/regex/Pattern;

    .line 552
    .line 553
    const-string v0, "X-ASSET-LIST=\"((?:.|\u000c)+?)\""

    .line 554
    .line 555
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 556
    .line 557
    .line 558
    move-result-object v0

    .line 559
    sput-object v0, La4/x;->V0:Ljava/util/regex/Pattern;

    .line 560
    .line 561
    const-string v0, "X-RESUME-OFFSET=(-?[\\d\\.]+)\\b"

    .line 562
    .line 563
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    sput-object v0, La4/x;->W0:Ljava/util/regex/Pattern;

    .line 568
    .line 569
    const-string v0, "X-PLAYOUT-LIMIT=([\\d\\.]+)\\b"

    .line 570
    .line 571
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 572
    .line 573
    .line 574
    move-result-object v0

    .line 575
    sput-object v0, La4/x;->X0:Ljava/util/regex/Pattern;

    .line 576
    .line 577
    const-string v0, "X-SNAP=\"((?:.|\u000c)+?)\""

    .line 578
    .line 579
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 580
    .line 581
    .line 582
    move-result-object v0

    .line 583
    sput-object v0, La4/x;->Y0:Ljava/util/regex/Pattern;

    .line 584
    .line 585
    const-string v0, "X-RESTRICT=\"((?:.|\u000c)+?)\""

    .line 586
    .line 587
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 588
    .line 589
    .line 590
    move-result-object v0

    .line 591
    sput-object v0, La4/x;->Z0:Ljava/util/regex/Pattern;

    .line 592
    .line 593
    const-string v0, "X-CONTENT-MAY-VARY=\"((?:.|\u000c)+?)\""

    .line 594
    .line 595
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 596
    .line 597
    .line 598
    move-result-object v0

    .line 599
    sput-object v0, La4/x;->a1:Ljava/util/regex/Pattern;

    .line 600
    .line 601
    const-string v0, "X-TIMELINE-OCCUPIES=\"((?:.|\u000c)+?)\""

    .line 602
    .line 603
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 604
    .line 605
    .line 606
    move-result-object v0

    .line 607
    sput-object v0, La4/x;->b1:Ljava/util/regex/Pattern;

    .line 608
    .line 609
    const-string v0, "X-TIMELINE-STYLE=\"((?:.|\u000c)+?)\""

    .line 610
    .line 611
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 612
    .line 613
    .line 614
    move-result-object v0

    .line 615
    sput-object v0, La4/x;->c1:Ljava/util/regex/Pattern;

    .line 616
    .line 617
    const-string v0, "X-SKIP-CONTROL-OFFSET=([\\d\\.]+)\\b"

    .line 618
    .line 619
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 620
    .line 621
    .line 622
    move-result-object v0

    .line 623
    sput-object v0, La4/x;->d1:Ljava/util/regex/Pattern;

    .line 624
    .line 625
    const-string v0, "X-SKIP-CONTROL-DURATION=([\\d\\.]+)\\b"

    .line 626
    .line 627
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 628
    .line 629
    .line 630
    move-result-object v0

    .line 631
    sput-object v0, La4/x;->e1:Ljava/util/regex/Pattern;

    .line 632
    .line 633
    const-string v0, "X-SKIP-CONTROL-LABEL-ID=\"((?:.|\u000c)+?)\""

    .line 634
    .line 635
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 636
    .line 637
    .line 638
    move-result-object v0

    .line 639
    sput-object v0, La4/x;->f1:Ljava/util/regex/Pattern;

    .line 640
    .line 641
    const-string v0, "\\{\\$([a-zA-Z0-9\\-_]+)\\}"

    .line 642
    .line 643
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 644
    .line 645
    .line 646
    move-result-object v0

    .line 647
    sput-object v0, La4/x;->g1:Ljava/util/regex/Pattern;

    .line 648
    .line 649
    const-string v0, "\\b(X-[A-Z0-9-]+)="

    .line 650
    .line 651
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 652
    .line 653
    .line 654
    move-result-object v0

    .line 655
    sput-object v0, La4/x;->h1:Ljava/util/regex/Pattern;

    .line 656
    .line 657
    return-void
.end method

.method public constructor <init>(La4/s;La4/p;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/x;->d:La4/s;

    .line 5
    .line 6
    iput-object p2, p0, La4/x;->e:La4/p;

    .line 7
    .line 8
    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/util/regex/Pattern;
    .registers 2

    .line 1
    const-string v0, "=(NO|YES)"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {p0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public static b(Ljava/lang/String;[Lk3/q;)Lk3/r;
    .registers 9

    .line 1
    array-length v0, p1

    .line 2
    new-array v0, v0, [Lk3/q;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    :goto_4
    array-length v2, p1

    .line 6
    if-ge v1, v2, :cond_1a

    .line 7
    .line 8
    aget-object v2, p1, v1

    .line 9
    .line 10
    new-instance v3, Lk3/q;

    .line 11
    .line 12
    iget-object v4, v2, Lk3/q;->e:Ljava/util/UUID;

    .line 13
    .line 14
    iget-object v5, v2, Lk3/q;->i:Ljava/lang/String;

    .line 15
    .line 16
    iget-object v2, v2, Lk3/q;->v:Ljava/lang/String;

    .line 17
    .line 18
    const/4 v6, 0x0

    .line 19
    invoke-direct {v3, v4, v5, v2, v6}, Lk3/q;-><init>(Ljava/util/UUID;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 20
    .line 21
    .line 22
    aput-object v3, v0, v1

    .line 23
    .line 24
    add-int/lit8 v1, v1, 0x1

    .line 25
    .line 26
    goto :goto_4

    .line 27
    :cond_1a
    new-instance p1, Lk3/r;

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    invoke-direct {p1, p0, v1, v0}, Lk3/r;-><init>(Ljava/lang/String;Z[Lk3/q;)V

    .line 31
    .line 32
    .line 33
    return-object p1
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;La4/w;)Lk3/q;
    .registers 12

    .line 1
    sget-object v0, La4/x;->u0:Ljava/util/regex/Pattern;

    .line 2
    .line 3
    const-string v1, "1"

    .line 4
    .line 5
    invoke-static {p0, v0, v1, p2, p3}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const-string v2, "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"

    .line 10
    .line 11
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    .line 16
    const/16 v4, 0x2c

    .line 17
    .line 18
    const-string v5, "video/mp4"

    .line 19
    .line 20
    sget-object v6, La4/x;->v0:Ljava/util/regex/Pattern;

    .line 21
    .line 22
    const/4 v7, 0x0

    .line 23
    if-eqz v2, :cond_30

    .line 24
    .line 25
    invoke-static {p0, v6, p2, p3}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    new-instance p1, Lk3/q;

    .line 30
    .line 31
    sget-object p2, Lk3/l;->e:Ljava/util/UUID;

    .line 32
    .line 33
    invoke-virtual {p0, v4}, Ljava/lang/String;->indexOf(I)I

    .line 34
    .line 35
    .line 36
    move-result p3

    .line 37
    invoke-virtual {p0, p3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    invoke-static {p0, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-direct {p1, p2, v7, v5, p0}, Lk3/q;-><init>(Ljava/util/UUID;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 46
    .line 47
    .line 48
    return-object p1

    .line 49
    :cond_30
    const-string v2, "com.widevine"

    .line 50
    .line 51
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    if-eqz v2, :cond_4a

    .line 56
    .line 57
    new-instance p1, Lk3/q;

    .line 58
    .line 59
    sget-object p2, Lk3/l;->e:Ljava/util/UUID;

    .line 60
    .line 61
    sget-object p3, Ln3/l0;->a:Ljava/lang/String;

    .line 62
    .line 63
    sget-object p3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 64
    .line 65
    invoke-virtual {p0, p3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    const-string p3, "hls"

    .line 70
    .line 71
    invoke-direct {p1, p2, v7, p3, p0}, Lk3/q;-><init>(Ljava/util/UUID;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 72
    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_4a
    const-string v2, "com.microsoft.playready"

    .line 76
    .line 77
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    if-eqz p1, :cond_74

    .line 82
    .line 83
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    if-eqz p1, :cond_74

    .line 88
    .line 89
    invoke-static {p0, v6, p2, p3}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    invoke-virtual {p0, v4}, Ljava/lang/String;->indexOf(I)I

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    invoke-static {p0, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    sget-object p1, Lk3/l;->f:Ljava/util/UUID;

    .line 106
    .line 107
    invoke-static {p1, v7, p0}, Li5/s;->a(Ljava/util/UUID;[Ljava/util/UUID;[B)[B

    .line 108
    .line 109
    .line 110
    move-result-object p0

    .line 111
    new-instance p2, Lk3/q;

    .line 112
    .line 113
    invoke-direct {p2, p1, v7, v5, p0}, Lk3/q;-><init>(Ljava/util/UUID;Ljava/lang/String;Ljava/lang/String;[B)V

    .line 114
    .line 115
    .line 116
    return-object p2

    .line 117
    :cond_74
    return-object v7
.end method

.method public static d(La4/s;La4/p;La4/v;Landroid/net/Uri;La4/w;)La4/p;
    .registers 131

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    invoke-virtual/range {p3 .. p3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    iget-boolean v4, v0, La4/t;->c:Z

    .line 12
    .line 13
    if-eqz v1, :cond_11

    .line 14
    .line 15
    iget-object v6, v1, La4/p;->x:La4/m;

    .line 16
    .line 17
    goto :goto_12

    .line 18
    :cond_11
    const/4 v6, 0x0

    .line 19
    :goto_12
    new-instance v7, Ljava/util/HashMap;

    .line 20
    .line 21
    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 22
    .line 23
    .line 24
    new-instance v8, Ljava/util/HashMap;

    .line 25
    .line 26
    invoke-direct {v8}, Ljava/util/HashMap;-><init>()V

    .line 27
    .line 28
    .line 29
    new-instance v9, Ljava/util/ArrayList;

    .line 30
    .line 31
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 32
    .line 33
    .line 34
    new-instance v10, Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 37
    .line 38
    .line 39
    new-instance v11, Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    new-instance v12, Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 47
    .line 48
    .line 49
    new-instance v13, Ljava/util/LinkedHashMap;

    .line 50
    .line 51
    invoke-direct {v13}, Ljava/util/LinkedHashMap;-><init>()V

    .line 52
    .line 53
    .line 54
    new-instance v14, La4/o;

    .line 55
    .line 56
    const-wide v20, -0x7fffffffffffffffL    # -4.9E-324

    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    const/16 v22, 0x0

    .line 62
    .line 63
    const-wide v15, -0x7fffffffffffffffL    # -4.9E-324

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    const/16 v17, 0x0

    .line 69
    .line 70
    const-wide v18, -0x7fffffffffffffffL    # -4.9E-324

    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    invoke-direct/range {v14 .. v22}, La4/o;-><init>(JZJJZ)V

    .line 76
    .line 77
    .line 78
    new-instance v15, Ljava/util/TreeMap;

    .line 79
    .line 80
    invoke-direct {v15}, Ljava/util/TreeMap;-><init>()V

    .line 81
    .line 82
    .line 83
    const-string v5, ""

    .line 84
    .line 85
    const-wide/16 v17, -0x1

    .line 86
    .line 87
    move/from16 v19, v4

    .line 88
    .line 89
    const-wide/16 v22, 0x0

    .line 90
    .line 91
    const/16 v24, 0x0

    .line 92
    .line 93
    move-object/from16 v71, v5

    .line 94
    .line 95
    move-object/from16 v30, v6

    .line 96
    .line 97
    move-wide/from16 v46, v17

    .line 98
    .line 99
    move-wide/from16 v74, v46

    .line 100
    .line 101
    move/from16 v27, v19

    .line 102
    .line 103
    move-wide/from16 v25, v20

    .line 104
    .line 105
    move-wide/from16 v53, v25

    .line 106
    .line 107
    move-wide/from16 v55, v53

    .line 108
    .line 109
    move-wide/from16 v76, v55

    .line 110
    .line 111
    move-wide/from16 v20, v22

    .line 112
    .line 113
    move-wide/from16 v39, v20

    .line 114
    .line 115
    move-wide/from16 v50, v39

    .line 116
    .line 117
    move-wide/from16 v57, v50

    .line 118
    .line 119
    move-wide/from16 v61, v57

    .line 120
    .line 121
    move-wide/from16 v66, v61

    .line 122
    .line 123
    move-wide/from16 v69, v66

    .line 124
    .line 125
    move-wide/from16 v72, v69

    .line 126
    .line 127
    move-wide/from16 v78, v72

    .line 128
    .line 129
    move/from16 v6, v24

    .line 130
    .line 131
    move/from16 v17, v6

    .line 132
    .line 133
    move/from16 v18, v17

    .line 134
    .line 135
    move/from16 v19, v18

    .line 136
    .line 137
    move/from16 v23, v19

    .line 138
    .line 139
    move/from16 v48, v23

    .line 140
    .line 141
    move/from16 v52, v48

    .line 142
    .line 143
    move/from16 v68, v52

    .line 144
    .line 145
    const/16 v22, 0x1

    .line 146
    .line 147
    const/16 v28, 0x0

    .line 148
    .line 149
    const/16 v29, 0x0

    .line 150
    .line 151
    const/16 v37, 0x0

    .line 152
    .line 153
    const/16 v38, 0x0

    .line 154
    .line 155
    const/16 v49, 0x0

    .line 156
    .line 157
    const/16 v65, 0x0

    .line 158
    .line 159
    :goto_9e
    invoke-virtual/range {p2 .. p2}, La4/v;->a()Z

    .line 160
    .line 161
    .line 162
    move-result v31

    .line 163
    const-string v4, "HIGHLIGHT"

    .line 164
    .line 165
    move/from16 v41, v6

    .line 166
    .line 167
    const-string v6, "POINT"

    .line 168
    .line 169
    move-object/from16 v81, v14

    .line 170
    .line 171
    if-eqz v31, :cond_10e1

    .line 172
    .line 173
    invoke-virtual/range {p2 .. p2}, La4/v;->b()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v14

    .line 177
    move-object/from16 v82, v8

    .line 178
    .line 179
    const-string v8, "#EXT"

    .line 180
    .line 181
    invoke-virtual {v14, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 182
    .line 183
    .line 184
    move-result v8

    .line 185
    if-eqz v8, :cond_bd

    .line 186
    .line 187
    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    :cond_bd
    const-string v8, "#EXT-X-PLAYLIST-TYPE"

    .line 191
    .line 192
    invoke-virtual {v14, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 193
    .line 194
    .line 195
    move-result v8

    .line 196
    const/16 v32, 0x2

    .line 197
    .line 198
    if-eqz v8, :cond_e9

    .line 199
    .line 200
    sget-object v4, La4/x;->b0:Ljava/util/regex/Pattern;

    .line 201
    .line 202
    invoke-static {v14, v4, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v4

    .line 206
    const-string v6, "VOD"

    .line 207
    .line 208
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    move-result v6

    .line 212
    if-eqz v6, :cond_d8

    .line 213
    .line 214
    const/16 v52, 0x1

    .line 215
    .line 216
    goto :goto_e2

    .line 217
    :cond_d8
    const-string v6, "EVENT"

    .line 218
    .line 219
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v4

    .line 223
    if-eqz v4, :cond_e2

    .line 224
    .line 225
    move/from16 v52, v32

    .line 226
    .line 227
    :cond_e2
    :goto_e2
    move/from16 v6, v41

    .line 228
    .line 229
    move-object/from16 v14, v81

    .line 230
    .line 231
    :goto_e6
    move-object/from16 v8, v82

    .line 232
    .line 233
    goto :goto_9e

    .line 234
    :cond_e9
    const-string v8, "#EXT-X-I-FRAMES-ONLY"

    .line 235
    .line 236
    invoke-virtual {v14, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 237
    .line 238
    .line 239
    move-result v8

    .line 240
    if-eqz v8, :cond_fa

    .line 241
    .line 242
    move/from16 v6, v41

    .line 243
    .line 244
    move-object/from16 v14, v81

    .line 245
    .line 246
    move-object/from16 v8, v82

    .line 247
    .line 248
    const/16 v68, 0x1

    .line 249
    .line 250
    goto :goto_9e

    .line 251
    :cond_fa
    const-string v8, "#EXT-X-START"

    .line 252
    .line 253
    invoke-virtual {v14, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 254
    .line 255
    .line 256
    move-result v8

    .line 257
    const-wide v33, 0x412e848000000000L    # 1000000.0

    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    if-eqz v8, :cond_129

    .line 263
    .line 264
    sget-object v4, La4/x;->n0:Ljava/util/regex/Pattern;

    .line 265
    .line 266
    sget-object v6, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 267
    .line 268
    invoke-static {v14, v4, v6, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object v4

    .line 272
    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 273
    .line 274
    .line 275
    move-result-wide v31

    .line 276
    move-object v8, v12

    .line 277
    move-object/from16 v83, v13

    .line 278
    .line 279
    mul-double v12, v31, v33

    .line 280
    .line 281
    double-to-long v12, v12

    .line 282
    sget-object v4, La4/x;->K0:Ljava/util/regex/Pattern;

    .line 283
    .line 284
    invoke-static {v2, v14, v4}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 285
    .line 286
    .line 287
    move-result v19

    .line 288
    move-wide/from16 v53, v12

    .line 289
    .line 290
    :goto_121
    move/from16 v6, v41

    .line 291
    .line 292
    move-object/from16 v14, v81

    .line 293
    .line 294
    move-object/from16 v13, v83

    .line 295
    .line 296
    move-object v12, v8

    .line 297
    goto :goto_e6

    .line 298
    :cond_129
    move-object v8, v12

    .line 299
    move-object/from16 v83, v13

    .line 300
    .line 301
    const-string v12, "#EXT-X-SERVER-CONTROL"

    .line 302
    .line 303
    invoke-virtual {v14, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 304
    .line 305
    .line 306
    move-result v12

    .line 307
    if-eqz v12, :cond_18c

    .line 308
    .line 309
    sget-object v4, La4/x;->c0:Ljava/util/regex/Pattern;

    .line 310
    .line 311
    const-wide/high16 v12, -0x3c20000000000000L    # -9.223372036854776E18

    .line 312
    .line 313
    invoke-static {v14, v4, v12, v13, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 314
    .line 315
    .line 316
    move-result-wide v31

    .line 317
    cmpl-double v4, v31, v12

    .line 318
    .line 319
    if-nez v4, :cond_143

    .line 320
    .line 321
    move-wide/from16 v85, v76

    .line 322
    .line 323
    goto :goto_148

    .line 324
    :cond_143
    mul-double v12, v31, v33

    .line 325
    .line 326
    double-to-long v12, v12

    .line 327
    move-wide/from16 v85, v12

    .line 328
    .line 329
    :goto_148
    sget-object v4, La4/x;->d0:Ljava/util/regex/Pattern;

    .line 330
    .line 331
    invoke-static {v2, v14, v4}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 332
    .line 333
    .line 334
    move-result v87

    .line 335
    sget-object v4, La4/x;->f0:Ljava/util/regex/Pattern;

    .line 336
    .line 337
    const-wide/high16 v12, -0x3c20000000000000L    # -9.223372036854776E18

    .line 338
    .line 339
    invoke-static {v14, v4, v12, v13, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 340
    .line 341
    .line 342
    move-result-wide v31

    .line 343
    cmpl-double v4, v31, v12

    .line 344
    .line 345
    if-nez v4, :cond_15d

    .line 346
    .line 347
    move-wide/from16 v88, v76

    .line 348
    .line 349
    goto :goto_162

    .line 350
    :cond_15d
    mul-double v12, v31, v33

    .line 351
    .line 352
    double-to-long v12, v12

    .line 353
    move-wide/from16 v88, v12

    .line 354
    .line 355
    :goto_162
    sget-object v4, La4/x;->g0:Ljava/util/regex/Pattern;

    .line 356
    .line 357
    const-wide/high16 v12, -0x3c20000000000000L    # -9.223372036854776E18

    .line 358
    .line 359
    invoke-static {v14, v4, v12, v13, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 360
    .line 361
    .line 362
    move-result-wide v31

    .line 363
    cmpl-double v4, v31, v12

    .line 364
    .line 365
    if-nez v4, :cond_171

    .line 366
    .line 367
    move-wide/from16 v90, v76

    .line 368
    .line 369
    goto :goto_176

    .line 370
    :cond_171
    mul-double v12, v31, v33

    .line 371
    .line 372
    double-to-long v12, v12

    .line 373
    move-wide/from16 v90, v12

    .line 374
    .line 375
    :goto_176
    sget-object v4, La4/x;->h0:Ljava/util/regex/Pattern;

    .line 376
    .line 377
    invoke-static {v2, v14, v4}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 378
    .line 379
    .line 380
    move-result v92

    .line 381
    new-instance v84, La4/o;

    .line 382
    .line 383
    invoke-direct/range {v84 .. v92}, La4/o;-><init>(JZJJZ)V

    .line 384
    .line 385
    .line 386
    move-object v12, v8

    .line 387
    move/from16 v6, v41

    .line 388
    .line 389
    move-object/from16 v8, v82

    .line 390
    .line 391
    move-object/from16 v13, v83

    .line 392
    .line 393
    move-object/from16 v14, v84

    .line 394
    .line 395
    goto/16 :goto_9e

    .line 396
    .line 397
    :cond_18c
    const-string v12, "#EXT-X-PART-INF"

    .line 398
    .line 399
    invoke-virtual {v14, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 400
    .line 401
    .line 402
    move-result v12

    .line 403
    if-eqz v12, :cond_1a7

    .line 404
    .line 405
    sget-object v4, La4/x;->Z:Ljava/util/regex/Pattern;

    .line 406
    .line 407
    sget-object v6, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 408
    .line 409
    invoke-static {v14, v4, v6, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object v4

    .line 413
    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 414
    .line 415
    .line 416
    move-result-wide v12

    .line 417
    mul-double v12, v12, v33

    .line 418
    .line 419
    double-to-long v12, v12

    .line 420
    move-wide/from16 v25, v12

    .line 421
    .line 422
    goto/16 :goto_121

    .line 423
    .line 424
    :cond_1a7
    const-string v12, "#EXT-X-MAP"

    .line 425
    .line 426
    invoke-virtual {v14, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 427
    .line 428
    .line 429
    move-result v12

    .line 430
    sget-object v13, La4/x;->p0:Ljava/util/regex/Pattern;

    .line 431
    .line 432
    move-object/from16 v84, v8

    .line 433
    .line 434
    const-string v8, "@"

    .line 435
    .line 436
    move/from16 v35, v12

    .line 437
    .line 438
    sget-object v12, La4/x;->v0:Ljava/util/regex/Pattern;

    .line 439
    .line 440
    if-eqz v35, :cond_211

    .line 441
    .line 442
    invoke-static {v14, v12, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object v32

    .line 446
    const/4 v4, 0x0

    .line 447
    invoke-static {v14, v13, v4, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v6

    .line 451
    if-eqz v6, :cond_1db

    .line 452
    .line 453
    sget-object v4, Ln3/l0;->a:Ljava/lang/String;

    .line 454
    .line 455
    const/4 v4, -0x1

    .line 456
    invoke-virtual {v6, v8, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 457
    .line 458
    .line 459
    move-result-object v4

    .line 460
    aget-object v6, v4, v24

    .line 461
    .line 462
    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 463
    .line 464
    .line 465
    move-result-wide v46

    .line 466
    array-length v6, v4

    .line 467
    const/4 v8, 0x1

    .line 468
    if-le v6, v8, :cond_1db

    .line 469
    .line 470
    aget-object v4, v4, v8

    .line 471
    .line 472
    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 473
    .line 474
    .line 475
    move-result-wide v61

    .line 476
    :cond_1db
    move-wide/from16 v35, v46

    .line 477
    .line 478
    cmp-long v4, v35, v74

    .line 479
    .line 480
    if-nez v4, :cond_1e4

    .line 481
    .line 482
    move-wide/from16 v33, v78

    .line 483
    .line 484
    goto :goto_1e6

    .line 485
    :cond_1e4
    move-wide/from16 v33, v61

    .line 486
    .line 487
    :goto_1e6
    if-eqz v37, :cond_1f2

    .line 488
    .line 489
    if-eqz v38, :cond_1eb

    .line 490
    .line 491
    goto :goto_1f2

    .line 492
    :cond_1eb
    const-string v0, "The encryption IV attribute must be present when an initialization segment is encrypted with METHOD=AES-128."

    .line 493
    .line 494
    invoke-static {v0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 495
    .line 496
    .line 497
    move-result-object v0

    .line 498
    throw v0

    .line 499
    :cond_1f2
    :goto_1f2
    new-instance v31, La4/m;

    .line 500
    .line 501
    invoke-direct/range {v31 .. v38}, La4/m;-><init>(Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)V

    .line 502
    .line 503
    .line 504
    move-object/from16 v85, v38

    .line 505
    .line 506
    if-eqz v4, :cond_1fd

    .line 507
    .line 508
    add-long v33, v33, v35

    .line 509
    .line 510
    :cond_1fd
    move-wide/from16 v61, v33

    .line 511
    .line 512
    move-object/from16 v30, v31

    .line 513
    .line 514
    move/from16 v6, v41

    .line 515
    .line 516
    move-wide/from16 v46, v74

    .line 517
    .line 518
    move-object/from16 v14, v81

    .line 519
    .line 520
    move-object/from16 v8, v82

    .line 521
    .line 522
    move-object/from16 v13, v83

    .line 523
    .line 524
    move-object/from16 v12, v84

    .line 525
    .line 526
    move-object/from16 v38, v85

    .line 527
    .line 528
    goto/16 :goto_9e

    .line 529
    .line 530
    :cond_211
    move-object/from16 v35, v4

    .line 531
    .line 532
    move-object/from16 v85, v38

    .line 533
    .line 534
    const-string v4, "#EXT-X-TARGETDURATION"

    .line 535
    .line 536
    invoke-virtual {v14, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 537
    .line 538
    .line 539
    move-result v4

    .line 540
    move-object/from16 v87, v10

    .line 541
    .line 542
    move-object/from16 v86, v11

    .line 543
    .line 544
    const-wide/32 v10, 0xf4240

    .line 545
    .line 546
    .line 547
    if-eqz v4, :cond_245

    .line 548
    .line 549
    sget-object v4, La4/x;->W:Ljava/util/regex/Pattern;

    .line 550
    .line 551
    sget-object v6, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 552
    .line 553
    invoke-static {v14, v4, v6, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 554
    .line 555
    .line 556
    move-result-object v4

    .line 557
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 558
    .line 559
    .line 560
    move-result v4

    .line 561
    int-to-long v12, v4

    .line 562
    mul-long v55, v12, v10

    .line 563
    .line 564
    :goto_233
    move/from16 v6, v41

    .line 565
    .line 566
    :goto_235
    move-object/from16 v14, v81

    .line 567
    .line 568
    move-object/from16 v8, v82

    .line 569
    .line 570
    move-object/from16 v13, v83

    .line 571
    .line 572
    move-object/from16 v12, v84

    .line 573
    .line 574
    move-object/from16 v38, v85

    .line 575
    .line 576
    move-object/from16 v11, v86

    .line 577
    .line 578
    move-object/from16 v10, v87

    .line 579
    .line 580
    goto/16 :goto_9e

    .line 581
    .line 582
    :cond_245
    const-string v4, "#EXT-X-MEDIA-SEQUENCE"

    .line 583
    .line 584
    invoke-virtual {v14, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 585
    .line 586
    .line 587
    move-result v4

    .line 588
    if-eqz v4, :cond_25e

    .line 589
    .line 590
    sget-object v4, La4/x;->i0:Ljava/util/regex/Pattern;

    .line 591
    .line 592
    sget-object v6, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 593
    .line 594
    invoke-static {v14, v4, v6, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 595
    .line 596
    .line 597
    move-result-object v4

    .line 598
    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 599
    .line 600
    .line 601
    move-result-wide v57

    .line 602
    move/from16 v6, v41

    .line 603
    .line 604
    move-wide/from16 v20, v57

    .line 605
    .line 606
    goto :goto_235

    .line 607
    :cond_25e
    const-string v4, "#EXT-X-VERSION"

    .line 608
    .line 609
    invoke-virtual {v14, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 610
    .line 611
    .line 612
    move-result v4

    .line 613
    if-eqz v4, :cond_273

    .line 614
    .line 615
    sget-object v4, La4/x;->a0:Ljava/util/regex/Pattern;

    .line 616
    .line 617
    sget-object v6, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 618
    .line 619
    invoke-static {v14, v4, v6, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 620
    .line 621
    .line 622
    move-result-object v4

    .line 623
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 624
    .line 625
    .line 626
    move-result v22

    .line 627
    goto :goto_233

    .line 628
    :cond_273
    const-string v4, "#EXT-X-DEFINE"

    .line 629
    .line 630
    invoke-virtual {v14, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 631
    .line 632
    .line 633
    move-result v4

    .line 634
    if-eqz v4, :cond_2fe

    .line 635
    .line 636
    sget-object v4, La4/x;->A0:Ljava/util/regex/Pattern;

    .line 637
    .line 638
    const/4 v6, 0x0

    .line 639
    invoke-static {v14, v4, v6, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 640
    .line 641
    .line 642
    move-result-object v4

    .line 643
    sget-object v8, La4/x;->B0:Ljava/util/regex/Pattern;

    .line 644
    .line 645
    invoke-static {v14, v8, v6, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 646
    .line 647
    .line 648
    move-result-object v8

    .line 649
    if-eqz v4, :cond_299

    .line 650
    .line 651
    invoke-static {v4, v7}, La4/x;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 652
    .line 653
    .line 654
    sget-object v6, La4/x;->L0:Ljava/util/regex/Pattern;

    .line 655
    .line 656
    invoke-static {v14, v6, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 657
    .line 658
    .line 659
    move-result-object v6

    .line 660
    invoke-virtual {v7, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 661
    .line 662
    .line 663
    move-object/from16 v4, p3

    .line 664
    .line 665
    goto :goto_2da

    .line 666
    :cond_299
    if-eqz v8, :cond_2c2

    .line 667
    .line 668
    invoke-static {v8, v7}, La4/x;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 669
    .line 670
    .line 671
    move-object/from16 v4, p3

    .line 672
    .line 673
    invoke-virtual {v4, v8}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 674
    .line 675
    .line 676
    move-result-object v6

    .line 677
    if-eqz v6, :cond_2aa

    .line 678
    .line 679
    invoke-virtual {v7, v8, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    goto :goto_2da

    .line 683
    :cond_2aa
    new-instance v0, Ljava/lang/StringBuilder;

    .line 684
    .line 685
    const-string v1, "QUERYPARAM \""

    .line 686
    .line 687
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 688
    .line 689
    .line 690
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 691
    .line 692
    .line 693
    const-string v1, "\" not found in playlist URI"

    .line 694
    .line 695
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 696
    .line 697
    .line 698
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 699
    .line 700
    .line 701
    move-result-object v0

    .line 702
    invoke-static {v0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 703
    .line 704
    .line 705
    move-result-object v0

    .line 706
    throw v0

    .line 707
    :cond_2c2
    move-object/from16 v4, p3

    .line 708
    .line 709
    sget-object v6, La4/x;->M0:Ljava/util/regex/Pattern;

    .line 710
    .line 711
    invoke-static {v14, v6, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 712
    .line 713
    .line 714
    move-result-object v6

    .line 715
    invoke-static {v6, v7}, La4/x;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 716
    .line 717
    .line 718
    iget-object v8, v0, La4/s;->l:Ljava/util/Map;

    .line 719
    .line 720
    invoke-interface {v8, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 721
    .line 722
    .line 723
    move-result-object v8

    .line 724
    check-cast v8, Ljava/lang/String;

    .line 725
    .line 726
    if-eqz v8, :cond_2da

    .line 727
    .line 728
    invoke-virtual {v7, v6, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 729
    .line 730
    .line 731
    :cond_2da
    :goto_2da
    move/from16 v8, v41

    .line 732
    .line 733
    move-object/from16 v41, v37

    .line 734
    .line 735
    move/from16 v37, v8

    .line 736
    .line 737
    move-object/from16 v115, v5

    .line 738
    .line 739
    move/from16 v14, v24

    .line 740
    .line 741
    move-wide/from16 v45, v46

    .line 742
    .line 743
    move/from16 v47, v48

    .line 744
    .line 745
    move-object/from16 v114, v49

    .line 746
    .line 747
    move-object/from16 v10, v65

    .line 748
    .line 749
    move-wide/from16 v35, v69

    .line 750
    .line 751
    move-object/from16 v34, v71

    .line 752
    .line 753
    move-object/from16 v5, v82

    .line 754
    .line 755
    move-object/from16 v12, v83

    .line 756
    .line 757
    move-object/from16 v8, v87

    .line 758
    .line 759
    move-object/from16 v49, v3

    .line 760
    .line 761
    move-object v3, v7

    .line 762
    move-object/from16 v65, v15

    .line 763
    .line 764
    :goto_2fb
    move-object v15, v9

    .line 765
    goto/16 :goto_10b8

    .line 766
    .line 767
    :cond_2fe
    move-object/from16 v4, p3

    .line 768
    .line 769
    const-string v10, "#EXTINF"

    .line 770
    .line 771
    invoke-virtual {v14, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 772
    .line 773
    .line 774
    move-result v10

    .line 775
    if-eqz v10, :cond_32d

    .line 776
    .line 777
    sget-object v6, La4/x;->j0:Ljava/util/regex/Pattern;

    .line 778
    .line 779
    sget-object v8, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 780
    .line 781
    invoke-static {v14, v6, v8, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 782
    .line 783
    .line 784
    move-result-object v6

    .line 785
    new-instance v8, Ljava/math/BigDecimal;

    .line 786
    .line 787
    invoke-direct {v8, v6}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    .line 788
    .line 789
    .line 790
    new-instance v6, Ljava/math/BigDecimal;

    .line 791
    .line 792
    const-wide/32 v10, 0xf4240

    .line 793
    .line 794
    .line 795
    invoke-direct {v6, v10, v11}, Ljava/math/BigDecimal;-><init>(J)V

    .line 796
    .line 797
    .line 798
    invoke-virtual {v8, v6}, Ljava/math/BigDecimal;->multiply(Ljava/math/BigDecimal;)Ljava/math/BigDecimal;

    .line 799
    .line 800
    .line 801
    move-result-object v6

    .line 802
    invoke-virtual {v6}, Ljava/math/BigDecimal;->longValue()J

    .line 803
    .line 804
    .line 805
    move-result-wide v69

    .line 806
    sget-object v6, La4/x;->k0:Ljava/util/regex/Pattern;

    .line 807
    .line 808
    invoke-static {v14, v6, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 809
    .line 810
    .line 811
    move-result-object v71

    .line 812
    goto/16 :goto_233

    .line 813
    .line 814
    :cond_32d
    const-string v10, "#EXT-X-SKIP"

    .line 815
    .line 816
    invoke-virtual {v14, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 817
    .line 818
    .line 819
    move-result v10

    .line 820
    const-wide/16 v42, 0x1

    .line 821
    .line 822
    if-eqz v10, :cond_469

    .line 823
    .line 824
    sget-object v6, La4/x;->e0:Ljava/util/regex/Pattern;

    .line 825
    .line 826
    sget-object v8, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 827
    .line 828
    invoke-static {v14, v6, v8, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 829
    .line 830
    .line 831
    move-result-object v6

    .line 832
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 833
    .line 834
    .line 835
    move-result v6

    .line 836
    if-eqz v1, :cond_34d

    .line 837
    .line 838
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    .line 839
    .line 840
    .line 841
    move-result v8

    .line 842
    if-eqz v8, :cond_34d

    .line 843
    .line 844
    const/4 v8, 0x1

    .line 845
    goto :goto_34f

    .line 846
    :cond_34d
    move/from16 v8, v24

    .line 847
    .line 848
    :goto_34f
    invoke-static {v8}, Loq/a;->z(Z)V

    .line 849
    .line 850
    .line 851
    sget-object v8, Ln3/l0;->a:Ljava/lang/String;

    .line 852
    .line 853
    iget-wide v10, v1, La4/p;->k:J

    .line 854
    .line 855
    iget-object v8, v1, La4/p;->r:Lhx/m0;

    .line 856
    .line 857
    sub-long v10, v20, v10

    .line 858
    .line 859
    long-to-int v10, v10

    .line 860
    add-int/2addr v6, v10

    .line 861
    if-ltz v10, :cond_463

    .line 862
    .line 863
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 864
    .line 865
    .line 866
    move-result v11

    .line 867
    if-gt v6, v11, :cond_463

    .line 868
    .line 869
    move-wide/from16 v95, v66

    .line 870
    .line 871
    move-object/from16 v38, v85

    .line 872
    .line 873
    :goto_368
    if-ge v10, v6, :cond_44f

    .line 874
    .line 875
    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 876
    .line 877
    .line 878
    move-result-object v11

    .line 879
    check-cast v11, La4/m;

    .line 880
    .line 881
    iget-wide v12, v1, La4/p;->k:J

    .line 882
    .line 883
    cmp-long v12, v20, v12

    .line 884
    .line 885
    if-eqz v12, :cond_40e

    .line 886
    .line 887
    iget v12, v1, La4/p;->j:I

    .line 888
    .line 889
    sub-int v12, v12, v17

    .line 890
    .line 891
    iget v13, v11, La4/n;->v:I

    .line 892
    .line 893
    add-int v94, v12, v13

    .line 894
    .line 895
    iget-object v12, v11, La4/m;->O:Lhx/m0;

    .line 896
    .line 897
    new-instance v13, Ljava/util/ArrayList;

    .line 898
    .line 899
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 900
    .line 901
    .line 902
    move/from16 v14, v24

    .line 903
    .line 904
    move-wide/from16 v103, v95

    .line 905
    .line 906
    :goto_389
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 907
    .line 908
    .line 909
    move-result v0

    .line 910
    if-ge v14, v0, :cond_3da

    .line 911
    .line 912
    invoke-interface {v12, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 913
    .line 914
    .line 915
    move-result-object v0

    .line 916
    check-cast v0, La4/k;

    .line 917
    .line 918
    new-instance v97, La4/k;

    .line 919
    .line 920
    iget-object v4, v0, La4/n;->d:Ljava/lang/String;

    .line 921
    .line 922
    move-object/from16 v98, v4

    .line 923
    .line 924
    iget-object v4, v0, La4/n;->e:La4/m;

    .line 925
    .line 926
    move-object/from16 v99, v4

    .line 927
    .line 928
    move-object/from16 v115, v5

    .line 929
    .line 930
    iget-wide v4, v0, La4/n;->i:J

    .line 931
    .line 932
    move-wide/from16 v100, v4

    .line 933
    .line 934
    iget-object v4, v0, La4/n;->x:Lk3/r;

    .line 935
    .line 936
    iget-object v5, v0, La4/n;->y:Ljava/lang/String;

    .line 937
    .line 938
    move-object/from16 v105, v4

    .line 939
    .line 940
    iget-object v4, v0, La4/n;->J:Ljava/lang/String;

    .line 941
    .line 942
    move-object/from16 v107, v4

    .line 943
    .line 944
    move-object/from16 v106, v5

    .line 945
    .line 946
    iget-wide v4, v0, La4/n;->K:J

    .line 947
    .line 948
    move-wide/from16 v108, v4

    .line 949
    .line 950
    iget-wide v4, v0, La4/n;->L:J

    .line 951
    .line 952
    move-wide/from16 v110, v4

    .line 953
    .line 954
    iget-boolean v4, v0, La4/n;->M:Z

    .line 955
    .line 956
    iget-boolean v5, v0, La4/k;->N:Z

    .line 957
    .line 958
    move/from16 v112, v4

    .line 959
    .line 960
    iget-boolean v4, v0, La4/k;->O:Z

    .line 961
    .line 962
    move/from16 v114, v4

    .line 963
    .line 964
    move/from16 v113, v5

    .line 965
    .line 966
    move/from16 v102, v94

    .line 967
    .line 968
    invoke-direct/range {v97 .. v114}, La4/k;-><init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZZZ)V

    .line 969
    .line 970
    .line 971
    move-object/from16 v4, v97

    .line 972
    .line 973
    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 974
    .line 975
    .line 976
    iget-wide v4, v0, La4/n;->i:J

    .line 977
    .line 978
    add-long v103, v103, v4

    .line 979
    .line 980
    add-int/lit8 v14, v14, 0x1

    .line 981
    .line 982
    move-object/from16 v4, p3

    .line 983
    .line 984
    move-object/from16 v5, v115

    .line 985
    .line 986
    goto :goto_389

    .line 987
    :cond_3da
    move-object/from16 v115, v5

    .line 988
    .line 989
    new-instance v88, La4/m;

    .line 990
    .line 991
    iget-object v0, v11, La4/n;->d:Ljava/lang/String;

    .line 992
    .line 993
    iget-object v4, v11, La4/n;->e:La4/m;

    .line 994
    .line 995
    iget-object v5, v11, La4/m;->N:Ljava/lang/String;

    .line 996
    .line 997
    move-object/from16 v90, v4

    .line 998
    .line 999
    move-object/from16 v91, v5

    .line 1000
    .line 1001
    iget-wide v4, v11, La4/n;->i:J

    .line 1002
    .line 1003
    iget-object v12, v11, La4/n;->x:Lk3/r;

    .line 1004
    .line 1005
    iget-object v14, v11, La4/n;->y:Ljava/lang/String;

    .line 1006
    .line 1007
    move-object/from16 v89, v0

    .line 1008
    .line 1009
    iget-object v0, v11, La4/n;->J:Ljava/lang/String;

    .line 1010
    .line 1011
    move-wide/from16 v92, v4

    .line 1012
    .line 1013
    iget-wide v4, v11, La4/n;->K:J

    .line 1014
    .line 1015
    move-wide/from16 v100, v4

    .line 1016
    .line 1017
    iget-wide v4, v11, La4/n;->L:J

    .line 1018
    .line 1019
    iget-boolean v11, v11, La4/n;->M:Z

    .line 1020
    .line 1021
    move-object/from16 v99, v0

    .line 1022
    .line 1023
    move-wide/from16 v102, v4

    .line 1024
    .line 1025
    move/from16 v104, v11

    .line 1026
    .line 1027
    move-object/from16 v97, v12

    .line 1028
    .line 1029
    move-object/from16 v105, v13

    .line 1030
    .line 1031
    move-object/from16 v98, v14

    .line 1032
    .line 1033
    invoke-direct/range {v88 .. v105}, La4/m;-><init>(Ljava/lang/String;La4/m;Ljava/lang/String;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZLjava/util/List;)V

    .line 1034
    .line 1035
    .line 1036
    move-object/from16 v11, v88

    .line 1037
    .line 1038
    goto :goto_410

    .line 1039
    :cond_40e
    move-object/from16 v115, v5

    .line 1040
    .line 1041
    :goto_410
    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1042
    .line 1043
    .line 1044
    iget-wide v4, v11, La4/n;->i:J

    .line 1045
    .line 1046
    iget-object v0, v11, La4/n;->J:Ljava/lang/String;

    .line 1047
    .line 1048
    add-long v95, v95, v4

    .line 1049
    .line 1050
    iget-wide v4, v11, La4/n;->L:J

    .line 1051
    .line 1052
    cmp-long v12, v4, v74

    .line 1053
    .line 1054
    if-eqz v12, :cond_423

    .line 1055
    .line 1056
    iget-wide v12, v11, La4/n;->K:J

    .line 1057
    .line 1058
    add-long v61, v12, v4

    .line 1059
    .line 1060
    :cond_423
    iget v4, v11, La4/n;->v:I

    .line 1061
    .line 1062
    iget-object v5, v11, La4/n;->e:La4/m;

    .line 1063
    .line 1064
    iget-object v12, v11, La4/n;->x:Lk3/r;

    .line 1065
    .line 1066
    iget-object v11, v11, La4/n;->y:Ljava/lang/String;

    .line 1067
    .line 1068
    if-eqz v0, :cond_437

    .line 1069
    .line 1070
    invoke-static/range {v57 .. v58}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    .line 1071
    .line 1072
    .line 1073
    move-result-object v13

    .line 1074
    invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1075
    .line 1076
    .line 1077
    move-result v13

    .line 1078
    if-nez v13, :cond_439

    .line 1079
    .line 1080
    :cond_437
    move-object/from16 v38, v0

    .line 1081
    .line 1082
    :cond_439
    add-long v57, v57, v42

    .line 1083
    .line 1084
    add-int/lit8 v10, v10, 0x1

    .line 1085
    .line 1086
    move-object/from16 v0, p0

    .line 1087
    .line 1088
    move/from16 v41, v4

    .line 1089
    .line 1090
    move-object/from16 v30, v5

    .line 1091
    .line 1092
    move-object/from16 v37, v11

    .line 1093
    .line 1094
    move-object/from16 v29, v12

    .line 1095
    .line 1096
    move-wide/from16 v39, v95

    .line 1097
    .line 1098
    move-object/from16 v5, v115

    .line 1099
    .line 1100
    move-object/from16 v4, p3

    .line 1101
    .line 1102
    goto/16 :goto_368

    .line 1103
    .line 1104
    :cond_44f
    move-object/from16 v0, p0

    .line 1105
    .line 1106
    move/from16 v6, v41

    .line 1107
    .line 1108
    move-object/from16 v14, v81

    .line 1109
    .line 1110
    move-object/from16 v8, v82

    .line 1111
    .line 1112
    move-object/from16 v13, v83

    .line 1113
    .line 1114
    move-object/from16 v12, v84

    .line 1115
    .line 1116
    move-object/from16 v11, v86

    .line 1117
    .line 1118
    move-object/from16 v10, v87

    .line 1119
    .line 1120
    move-wide/from16 v66, v95

    .line 1121
    .line 1122
    goto/16 :goto_9e

    .line 1123
    .line 1124
    :cond_463
    new-instance v0, La4/u;

    .line 1125
    .line 1126
    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    .line 1127
    .line 1128
    .line 1129
    throw v0

    .line 1130
    :cond_469
    move-object/from16 v115, v5

    .line 1131
    .line 1132
    const-string v0, "#EXT-X-KEY"

    .line 1133
    .line 1134
    invoke-virtual {v14, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1135
    .line 1136
    .line 1137
    move-result v0

    .line 1138
    if-eqz v0, :cond_4f7

    .line 1139
    .line 1140
    sget-object v0, La4/x;->s0:Ljava/util/regex/Pattern;

    .line 1141
    .line 1142
    invoke-static {v14, v0, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1143
    .line 1144
    .line 1145
    move-result-object v0

    .line 1146
    sget-object v4, La4/x;->t0:Ljava/util/regex/Pattern;

    .line 1147
    .line 1148
    const-string v5, "identity"

    .line 1149
    .line 1150
    invoke-static {v14, v4, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v4

    .line 1154
    const-string v6, "NONE"

    .line 1155
    .line 1156
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1157
    .line 1158
    .line 1159
    move-result v6

    .line 1160
    if-eqz v6, :cond_493

    .line 1161
    .line 1162
    invoke-virtual {v15}, Ljava/util/TreeMap;->clear()V

    .line 1163
    .line 1164
    .line 1165
    const/16 v29, 0x0

    .line 1166
    .line 1167
    const/16 v37, 0x0

    .line 1168
    .line 1169
    const/16 v38, 0x0

    .line 1170
    .line 1171
    goto :goto_4e3

    .line 1172
    :cond_493
    sget-object v6, La4/x;->w0:Ljava/util/regex/Pattern;

    .line 1173
    .line 1174
    const/4 v8, 0x0

    .line 1175
    invoke-static {v14, v6, v8, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1176
    .line 1177
    .line 1178
    move-result-object v6

    .line 1179
    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1180
    .line 1181
    .line 1182
    move-result v5

    .line 1183
    if-eqz v5, :cond_4b6

    .line 1184
    .line 1185
    const-string v4, "AES-128"

    .line 1186
    .line 1187
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1188
    .line 1189
    .line 1190
    move-result v0

    .line 1191
    if-eqz v0, :cond_4b1

    .line 1192
    .line 1193
    invoke-static {v14, v12, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1194
    .line 1195
    .line 1196
    move-result-object v0

    .line 1197
    move-object/from16 v37, v0

    .line 1198
    .line 1199
    move-object/from16 v38, v6

    .line 1200
    .line 1201
    goto :goto_4e3

    .line 1202
    :cond_4b1
    move-object/from16 v38, v6

    .line 1203
    .line 1204
    :goto_4b3
    const/16 v37, 0x0

    .line 1205
    .line 1206
    goto :goto_4e3

    .line 1207
    :cond_4b6
    move-object/from16 v5, v65

    .line 1208
    .line 1209
    if-nez v5, :cond_4d3

    .line 1210
    .line 1211
    const-string v5, "SAMPLE-AES-CENC"

    .line 1212
    .line 1213
    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1214
    .line 1215
    .line 1216
    move-result v5

    .line 1217
    if-nez v5, :cond_4d0

    .line 1218
    .line 1219
    const-string v5, "SAMPLE-AES-CTR"

    .line 1220
    .line 1221
    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1222
    .line 1223
    .line 1224
    move-result v0

    .line 1225
    if-eqz v0, :cond_4cb

    .line 1226
    .line 1227
    goto :goto_4d0

    .line 1228
    :cond_4cb
    const-string v0, "cbcs"

    .line 1229
    .line 1230
    :goto_4cd
    move-object/from16 v65, v0

    .line 1231
    .line 1232
    goto :goto_4d5

    .line 1233
    :cond_4d0
    :goto_4d0
    const-string v0, "cenc"

    .line 1234
    .line 1235
    goto :goto_4cd

    .line 1236
    :cond_4d3
    move-object/from16 v65, v5

    .line 1237
    .line 1238
    :goto_4d5
    invoke-static {v14, v4, v7, v2}, La4/x;->c(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;La4/w;)Lk3/q;

    .line 1239
    .line 1240
    .line 1241
    move-result-object v0

    .line 1242
    if-eqz v0, :cond_4b1

    .line 1243
    .line 1244
    invoke-virtual {v15, v4, v0}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1245
    .line 1246
    .line 1247
    move-object/from16 v38, v6

    .line 1248
    .line 1249
    const/16 v29, 0x0

    .line 1250
    .line 1251
    goto :goto_4b3

    .line 1252
    :goto_4e3
    move-object/from16 v0, p0

    .line 1253
    .line 1254
    move/from16 v6, v41

    .line 1255
    .line 1256
    move-object/from16 v14, v81

    .line 1257
    .line 1258
    move-object/from16 v8, v82

    .line 1259
    .line 1260
    move-object/from16 v13, v83

    .line 1261
    .line 1262
    move-object/from16 v12, v84

    .line 1263
    .line 1264
    :goto_4ef
    move-object/from16 v11, v86

    .line 1265
    .line 1266
    move-object/from16 v10, v87

    .line 1267
    .line 1268
    :goto_4f3
    move-object/from16 v5, v115

    .line 1269
    .line 1270
    goto/16 :goto_9e

    .line 1271
    .line 1272
    :cond_4f7
    move-object/from16 v5, v65

    .line 1273
    .line 1274
    const-string v0, "#EXT-X-BYTERANGE"

    .line 1275
    .line 1276
    invoke-virtual {v14, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1277
    .line 1278
    .line 1279
    move-result v0

    .line 1280
    if-eqz v0, :cond_531

    .line 1281
    .line 1282
    sget-object v0, La4/x;->o0:Ljava/util/regex/Pattern;

    .line 1283
    .line 1284
    invoke-static {v14, v0, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1285
    .line 1286
    .line 1287
    move-result-object v0

    .line 1288
    sget-object v4, Ln3/l0;->a:Ljava/lang/String;

    .line 1289
    .line 1290
    const/4 v4, -0x1

    .line 1291
    invoke-virtual {v0, v8, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 1292
    .line 1293
    .line 1294
    move-result-object v0

    .line 1295
    aget-object v4, v0, v24

    .line 1296
    .line 1297
    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 1298
    .line 1299
    .line 1300
    move-result-wide v46

    .line 1301
    array-length v4, v0

    .line 1302
    const/4 v10, 0x1

    .line 1303
    if-le v4, v10, :cond_520

    .line 1304
    .line 1305
    aget-object v0, v0, v10

    .line 1306
    .line 1307
    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 1308
    .line 1309
    .line 1310
    move-result-wide v11

    .line 1311
    move-wide/from16 v61, v11

    .line 1312
    .line 1313
    :cond_520
    :goto_520
    move-object/from16 v0, p0

    .line 1314
    .line 1315
    move-object/from16 v65, v5

    .line 1316
    .line 1317
    move/from16 v6, v41

    .line 1318
    .line 1319
    :goto_526
    move-object/from16 v14, v81

    .line 1320
    .line 1321
    move-object/from16 v8, v82

    .line 1322
    .line 1323
    move-object/from16 v13, v83

    .line 1324
    .line 1325
    move-object/from16 v12, v84

    .line 1326
    .line 1327
    move-object/from16 v38, v85

    .line 1328
    .line 1329
    goto :goto_4ef

    .line 1330
    :cond_531
    const/4 v10, 0x1

    .line 1331
    const-string v0, "#EXT-X-DISCONTINUITY-SEQUENCE"

    .line 1332
    .line 1333
    invoke-virtual {v14, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1334
    .line 1335
    .line 1336
    move-result v0

    .line 1337
    const/16 v4, 0x3a

    .line 1338
    .line 1339
    if-eqz v0, :cond_563

    .line 1340
    .line 1341
    invoke-virtual {v14, v4}, Ljava/lang/String;->indexOf(I)I

    .line 1342
    .line 1343
    .line 1344
    move-result v0

    .line 1345
    add-int/2addr v0, v10

    .line 1346
    invoke-virtual {v14, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1347
    .line 1348
    .line 1349
    move-result-object v0

    .line 1350
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 1351
    .line 1352
    .line 1353
    move-result v17

    .line 1354
    move-object/from16 v0, p0

    .line 1355
    .line 1356
    move-object/from16 v65, v5

    .line 1357
    .line 1358
    move/from16 v6, v41

    .line 1359
    .line 1360
    move-object/from16 v14, v81

    .line 1361
    .line 1362
    move-object/from16 v8, v82

    .line 1363
    .line 1364
    move-object/from16 v13, v83

    .line 1365
    .line 1366
    move-object/from16 v12, v84

    .line 1367
    .line 1368
    move-object/from16 v38, v85

    .line 1369
    .line 1370
    move-object/from16 v11, v86

    .line 1371
    .line 1372
    move-object/from16 v10, v87

    .line 1373
    .line 1374
    move-object/from16 v5, v115

    .line 1375
    .line 1376
    const/16 v18, 0x1

    .line 1377
    .line 1378
    goto/16 :goto_9e

    .line 1379
    .line 1380
    :cond_563
    const-string v0, "#EXT-X-DISCONTINUITY"

    .line 1381
    .line 1382
    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1383
    .line 1384
    .line 1385
    move-result v0

    .line 1386
    if-eqz v0, :cond_572

    .line 1387
    .line 1388
    add-int/lit8 v6, v41, 0x1

    .line 1389
    .line 1390
    move-object/from16 v0, p0

    .line 1391
    .line 1392
    move-object/from16 v65, v5

    .line 1393
    .line 1394
    goto :goto_526

    .line 1395
    :cond_572
    const-string v0, "#EXT-X-PROGRAM-DATE-TIME"

    .line 1396
    .line 1397
    invoke-virtual {v14, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1398
    .line 1399
    .line 1400
    move-result v0

    .line 1401
    if-eqz v0, :cond_5b5

    .line 1402
    .line 1403
    cmp-long v0, v50, v78

    .line 1404
    .line 1405
    if-nez v0, :cond_595

    .line 1406
    .line 1407
    invoke-virtual {v14, v4}, Ljava/lang/String;->indexOf(I)I

    .line 1408
    .line 1409
    .line 1410
    move-result v0

    .line 1411
    const/16 v80, 0x1

    .line 1412
    .line 1413
    add-int/lit8 v0, v0, 0x1

    .line 1414
    .line 1415
    invoke-virtual {v14, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1416
    .line 1417
    .line 1418
    move-result-object v0

    .line 1419
    invoke-static {v0}, Ln3/l0;->V(Ljava/lang/String;)J

    .line 1420
    .line 1421
    .line 1422
    move-result-wide v10

    .line 1423
    invoke-static {v10, v11}, Ln3/l0;->S(J)J

    .line 1424
    .line 1425
    .line 1426
    move-result-wide v10

    .line 1427
    sub-long v50, v10, v66

    .line 1428
    .line 1429
    goto :goto_520

    .line 1430
    :cond_595
    :goto_595
    move/from16 v8, v41

    .line 1431
    .line 1432
    move-object/from16 v41, v37

    .line 1433
    .line 1434
    move/from16 v37, v8

    .line 1435
    .line 1436
    move-object v10, v5

    .line 1437
    move-object/from16 v65, v15

    .line 1438
    .line 1439
    move/from16 v14, v24

    .line 1440
    .line 1441
    move-wide/from16 v45, v46

    .line 1442
    .line 1443
    move/from16 v47, v48

    .line 1444
    .line 1445
    move-object/from16 v114, v49

    .line 1446
    .line 1447
    move-wide/from16 v35, v69

    .line 1448
    .line 1449
    move-object/from16 v34, v71

    .line 1450
    .line 1451
    move-object/from16 v5, v82

    .line 1452
    .line 1453
    move-object/from16 v12, v83

    .line 1454
    .line 1455
    move-object/from16 v8, v87

    .line 1456
    .line 1457
    move-object/from16 v49, v3

    .line 1458
    .line 1459
    move-object v3, v7

    .line 1460
    goto/16 :goto_2fb

    .line 1461
    .line 1462
    :cond_5b5
    const-string v0, "#EXT-X-GAP"

    .line 1463
    .line 1464
    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1465
    .line 1466
    .line 1467
    move-result v0

    .line 1468
    if-eqz v0, :cond_5d7

    .line 1469
    .line 1470
    move-object/from16 v0, p0

    .line 1471
    .line 1472
    move-object/from16 v65, v5

    .line 1473
    .line 1474
    move/from16 v6, v41

    .line 1475
    .line 1476
    move-object/from16 v14, v81

    .line 1477
    .line 1478
    move-object/from16 v8, v82

    .line 1479
    .line 1480
    move-object/from16 v13, v83

    .line 1481
    .line 1482
    move-object/from16 v12, v84

    .line 1483
    .line 1484
    move-object/from16 v38, v85

    .line 1485
    .line 1486
    move-object/from16 v11, v86

    .line 1487
    .line 1488
    move-object/from16 v10, v87

    .line 1489
    .line 1490
    move-object/from16 v5, v115

    .line 1491
    .line 1492
    const/16 v48, 0x1

    .line 1493
    .line 1494
    goto/16 :goto_9e

    .line 1495
    .line 1496
    :cond_5d7
    const-string v0, "#EXT-X-INDEPENDENT-SEGMENTS"

    .line 1497
    .line 1498
    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1499
    .line 1500
    .line 1501
    move-result v0

    .line 1502
    if-eqz v0, :cond_5f9

    .line 1503
    .line 1504
    move-object/from16 v0, p0

    .line 1505
    .line 1506
    move-object/from16 v65, v5

    .line 1507
    .line 1508
    move/from16 v6, v41

    .line 1509
    .line 1510
    move-object/from16 v14, v81

    .line 1511
    .line 1512
    move-object/from16 v8, v82

    .line 1513
    .line 1514
    move-object/from16 v13, v83

    .line 1515
    .line 1516
    move-object/from16 v12, v84

    .line 1517
    .line 1518
    move-object/from16 v38, v85

    .line 1519
    .line 1520
    move-object/from16 v11, v86

    .line 1521
    .line 1522
    move-object/from16 v10, v87

    .line 1523
    .line 1524
    move-object/from16 v5, v115

    .line 1525
    .line 1526
    const/16 v27, 0x1

    .line 1527
    .line 1528
    goto/16 :goto_9e

    .line 1529
    .line 1530
    :cond_5f9
    const-string v0, "#EXT-X-ENDLIST"

    .line 1531
    .line 1532
    invoke-virtual {v14, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1533
    .line 1534
    .line 1535
    move-result v0

    .line 1536
    if-eqz v0, :cond_61b

    .line 1537
    .line 1538
    move-object/from16 v0, p0

    .line 1539
    .line 1540
    move-object/from16 v65, v5

    .line 1541
    .line 1542
    move/from16 v6, v41

    .line 1543
    .line 1544
    move-object/from16 v14, v81

    .line 1545
    .line 1546
    move-object/from16 v8, v82

    .line 1547
    .line 1548
    move-object/from16 v13, v83

    .line 1549
    .line 1550
    move-object/from16 v12, v84

    .line 1551
    .line 1552
    move-object/from16 v38, v85

    .line 1553
    .line 1554
    move-object/from16 v11, v86

    .line 1555
    .line 1556
    move-object/from16 v10, v87

    .line 1557
    .line 1558
    move-object/from16 v5, v115

    .line 1559
    .line 1560
    const/16 v23, 0x1

    .line 1561
    .line 1562
    goto/16 :goto_9e

    .line 1563
    .line 1564
    :cond_61b
    const-string v0, "#EXT-X-RENDITION-REPORT"

    .line 1565
    .line 1566
    invoke-virtual {v14, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1567
    .line 1568
    .line 1569
    move-result v0

    .line 1570
    if-eqz v0, :cond_647

    .line 1571
    .line 1572
    sget-object v0, La4/x;->l0:Ljava/util/regex/Pattern;

    .line 1573
    .line 1574
    invoke-static {v2, v14, v0}, La4/x;->j(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)J

    .line 1575
    .line 1576
    .line 1577
    move-result-wide v10

    .line 1578
    sget-object v0, La4/x;->m0:Ljava/util/regex/Pattern;

    .line 1579
    .line 1580
    invoke-static {v2, v14, v0}, La4/x;->i(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)I

    .line 1581
    .line 1582
    .line 1583
    move-result v0

    .line 1584
    invoke-static {v14, v12, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1585
    .line 1586
    .line 1587
    move-result-object v4

    .line 1588
    invoke-static {v3, v4}, Ln3/e;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1589
    .line 1590
    .line 1591
    move-result-object v4

    .line 1592
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 1593
    .line 1594
    .line 1595
    move-result-object v4

    .line 1596
    new-instance v6, La4/l;

    .line 1597
    .line 1598
    invoke-direct {v6, v4, v10, v11, v0}, La4/l;-><init>(Landroid/net/Uri;JI)V

    .line 1599
    .line 1600
    .line 1601
    move-object/from16 v0, v86

    .line 1602
    .line 1603
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1604
    .line 1605
    .line 1606
    goto/16 :goto_595

    .line 1607
    .line 1608
    :cond_647
    move-object/from16 v0, v86

    .line 1609
    .line 1610
    const-string v4, "#EXT-X-PRELOAD-HINT"

    .line 1611
    .line 1612
    invoke-virtual {v14, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1613
    .line 1614
    .line 1615
    move-result v4

    .line 1616
    if-eqz v4, :cond_728

    .line 1617
    .line 1618
    move-object/from16 v4, v49

    .line 1619
    .line 1620
    if-eqz v4, :cond_677

    .line 1621
    .line 1622
    :goto_655
    move/from16 v8, v41

    .line 1623
    .line 1624
    move-object/from16 v41, v37

    .line 1625
    .line 1626
    move/from16 v37, v8

    .line 1627
    .line 1628
    move-object/from16 v86, v0

    .line 1629
    .line 1630
    move-object/from16 v49, v3

    .line 1631
    .line 1632
    move-object/from16 v114, v4

    .line 1633
    .line 1634
    move-object v10, v5

    .line 1635
    move-object v3, v7

    .line 1636
    move-object/from16 v65, v15

    .line 1637
    .line 1638
    move/from16 v14, v24

    .line 1639
    .line 1640
    move-wide/from16 v45, v46

    .line 1641
    .line 1642
    move/from16 v47, v48

    .line 1643
    .line 1644
    move-wide/from16 v35, v69

    .line 1645
    .line 1646
    move-object/from16 v34, v71

    .line 1647
    .line 1648
    move-object/from16 v5, v82

    .line 1649
    .line 1650
    move-object/from16 v12, v83

    .line 1651
    .line 1652
    move-object/from16 v8, v87

    .line 1653
    .line 1654
    goto/16 :goto_2fb

    .line 1655
    .line 1656
    :cond_677
    sget-object v6, La4/x;->y0:Ljava/util/regex/Pattern;

    .line 1657
    .line 1658
    invoke-static {v14, v6, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1659
    .line 1660
    .line 1661
    move-result-object v6

    .line 1662
    const-string v8, "PART"

    .line 1663
    .line 1664
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1665
    .line 1666
    .line 1667
    move-result v6

    .line 1668
    if-nez v6, :cond_686

    .line 1669
    .line 1670
    goto :goto_655

    .line 1671
    :cond_686
    move-object/from16 v10, v29

    .line 1672
    .line 1673
    invoke-static {v14, v12, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1674
    .line 1675
    .line 1676
    move-result-object v29

    .line 1677
    sget-object v6, La4/x;->q0:Ljava/util/regex/Pattern;

    .line 1678
    .line 1679
    invoke-static {v2, v14, v6}, La4/x;->j(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)J

    .line 1680
    .line 1681
    .line 1682
    move-result-wide v11

    .line 1683
    sget-object v6, La4/x;->r0:Ljava/util/regex/Pattern;

    .line 1684
    .line 1685
    invoke-static {v2, v14, v6}, La4/x;->j(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)J

    .line 1686
    .line 1687
    .line 1688
    move-result-wide v13

    .line 1689
    if-nez v37, :cond_69d

    .line 1690
    .line 1691
    const/16 v38, 0x0

    .line 1692
    .line 1693
    goto :goto_6a8

    .line 1694
    :cond_69d
    if-eqz v85, :cond_6a2

    .line 1695
    .line 1696
    move-object/from16 v38, v85

    .line 1697
    .line 1698
    goto :goto_6a8

    .line 1699
    :cond_6a2
    invoke-static/range {v57 .. v58}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    .line 1700
    .line 1701
    .line 1702
    move-result-object v6

    .line 1703
    move-object/from16 v38, v6

    .line 1704
    .line 1705
    :goto_6a8
    if-nez v10, :cond_6d2

    .line 1706
    .line 1707
    invoke-virtual {v15}, Ljava/util/AbstractMap;->isEmpty()Z

    .line 1708
    .line 1709
    .line 1710
    move-result v6

    .line 1711
    if-nez v6, :cond_6d2

    .line 1712
    .line 1713
    invoke-virtual {v15}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 1714
    .line 1715
    .line 1716
    move-result-object v6

    .line 1717
    move/from16 v8, v24

    .line 1718
    .line 1719
    new-array v10, v8, [Lk3/q;

    .line 1720
    .line 1721
    invoke-interface {v6, v10}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 1722
    .line 1723
    .line 1724
    move-result-object v6

    .line 1725
    check-cast v6, [Lk3/q;

    .line 1726
    .line 1727
    new-instance v8, Lk3/r;

    .line 1728
    .line 1729
    const/4 v10, 0x1

    .line 1730
    invoke-direct {v8, v5, v10, v6}, Lk3/r;-><init>(Ljava/lang/String;Z[Lk3/q;)V

    .line 1731
    .line 1732
    .line 1733
    if-nez v28, :cond_6cd

    .line 1734
    .line 1735
    invoke-static {v5, v6}, La4/x;->b(Ljava/lang/String;[Lk3/q;)Lk3/r;

    .line 1736
    .line 1737
    .line 1738
    move-result-object v6

    .line 1739
    move-object/from16 v36, v8

    .line 1740
    .line 1741
    goto :goto_6d5

    .line 1742
    :cond_6cd
    move-object/from16 v36, v8

    .line 1743
    .line 1744
    :goto_6cf
    move-object/from16 v6, v28

    .line 1745
    .line 1746
    goto :goto_6d5

    .line 1747
    :cond_6d2
    move-object/from16 v36, v10

    .line 1748
    .line 1749
    goto :goto_6cf

    .line 1750
    :goto_6d5
    cmp-long v8, v11, v74

    .line 1751
    .line 1752
    if-eqz v8, :cond_6e7

    .line 1753
    .line 1754
    cmp-long v10, v13, v74

    .line 1755
    .line 1756
    if-eqz v10, :cond_6de

    .line 1757
    .line 1758
    goto :goto_6e7

    .line 1759
    :cond_6de
    move/from16 v49, v41

    .line 1760
    .line 1761
    move-object/from16 v41, v37

    .line 1762
    .line 1763
    move/from16 v37, v49

    .line 1764
    .line 1765
    move-object/from16 v49, v4

    .line 1766
    .line 1767
    goto :goto_709

    .line 1768
    :cond_6e7
    :goto_6e7
    new-instance v28, La4/k;

    .line 1769
    .line 1770
    if-eqz v8, :cond_6ec

    .line 1771
    .line 1772
    goto :goto_6ee

    .line 1773
    :cond_6ec
    move-wide/from16 v11, v78

    .line 1774
    .line 1775
    :goto_6ee
    const/16 v44, 0x0

    .line 1776
    .line 1777
    const/16 v45, 0x1

    .line 1778
    .line 1779
    const-wide/16 v31, 0x0

    .line 1780
    .line 1781
    const/16 v43, 0x0

    .line 1782
    .line 1783
    move-wide/from16 v34, v39

    .line 1784
    .line 1785
    move/from16 v33, v41

    .line 1786
    .line 1787
    move-wide/from16 v39, v11

    .line 1788
    .line 1789
    move-wide/from16 v41, v13

    .line 1790
    .line 1791
    invoke-direct/range {v28 .. v45}, La4/k;-><init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZZZ)V

    .line 1792
    .line 1793
    .line 1794
    move-wide/from16 v39, v34

    .line 1795
    .line 1796
    move-object/from16 v41, v37

    .line 1797
    .line 1798
    move/from16 v37, v33

    .line 1799
    .line 1800
    move-object/from16 v49, v28

    .line 1801
    .line 1802
    :goto_709
    move-object v11, v0

    .line 1803
    move-object/from16 v65, v5

    .line 1804
    .line 1805
    move-object/from16 v28, v6

    .line 1806
    .line 1807
    move-object/from16 v29, v36

    .line 1808
    .line 1809
    move/from16 v6, v37

    .line 1810
    .line 1811
    move-object/from16 v37, v41

    .line 1812
    .line 1813
    move-object/from16 v14, v81

    .line 1814
    .line 1815
    move-object/from16 v8, v82

    .line 1816
    .line 1817
    move-object/from16 v13, v83

    .line 1818
    .line 1819
    move-object/from16 v12, v84

    .line 1820
    .line 1821
    move-object/from16 v38, v85

    .line 1822
    .line 1823
    move-object/from16 v10, v87

    .line 1824
    .line 1825
    move-object/from16 v5, v115

    .line 1826
    .line 1827
    const/16 v24, 0x0

    .line 1828
    .line 1829
    move-object/from16 v0, p0

    .line 1830
    .line 1831
    goto/16 :goto_9e

    .line 1832
    .line 1833
    :cond_728
    move/from16 v4, v41

    .line 1834
    .line 1835
    move-object/from16 v41, v37

    .line 1836
    .line 1837
    move/from16 v37, v4

    .line 1838
    .line 1839
    move-object/from16 v10, v29

    .line 1840
    .line 1841
    move-object/from16 v4, v49

    .line 1842
    .line 1843
    const-string v11, "#EXT-X-PART"

    .line 1844
    .line 1845
    invoke-virtual {v14, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1846
    .line 1847
    .line 1848
    move-result v11

    .line 1849
    if-eqz v11, :cond_819

    .line 1850
    .line 1851
    if-nez v41, :cond_73f

    .line 1852
    .line 1853
    const/16 v38, 0x0

    .line 1854
    .line 1855
    goto :goto_74a

    .line 1856
    :cond_73f
    if-eqz v85, :cond_744

    .line 1857
    .line 1858
    move-object/from16 v38, v85

    .line 1859
    .line 1860
    goto :goto_74a

    .line 1861
    :cond_744
    invoke-static/range {v57 .. v58}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    .line 1862
    .line 1863
    .line 1864
    move-result-object v6

    .line 1865
    move-object/from16 v38, v6

    .line 1866
    .line 1867
    :goto_74a
    invoke-static {v14, v12, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1868
    .line 1869
    .line 1870
    move-result-object v29

    .line 1871
    sget-object v6, La4/x;->X:Ljava/util/regex/Pattern;

    .line 1872
    .line 1873
    sget-object v11, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 1874
    .line 1875
    invoke-static {v14, v6, v11, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1876
    .line 1877
    .line 1878
    move-result-object v6

    .line 1879
    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 1880
    .line 1881
    .line 1882
    move-result-wide v11

    .line 1883
    mul-double v11, v11, v33

    .line 1884
    .line 1885
    double-to-long v11, v11

    .line 1886
    sget-object v6, La4/x;->I0:Ljava/util/regex/Pattern;

    .line 1887
    .line 1888
    invoke-static {v2, v14, v6}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 1889
    .line 1890
    .line 1891
    move-result v6

    .line 1892
    if-eqz v27, :cond_76e

    .line 1893
    .line 1894
    invoke-interface/range {v87 .. v87}, Ljava/util/List;->isEmpty()Z

    .line 1895
    .line 1896
    .line 1897
    move-result v32

    .line 1898
    if-eqz v32, :cond_76e

    .line 1899
    .line 1900
    const/16 v32, 0x1

    .line 1901
    .line 1902
    goto :goto_770

    .line 1903
    :cond_76e
    const/16 v32, 0x0

    .line 1904
    .line 1905
    :goto_770
    or-int v44, v6, v32

    .line 1906
    .line 1907
    sget-object v6, La4/x;->J0:Ljava/util/regex/Pattern;

    .line 1908
    .line 1909
    invoke-static {v2, v14, v6}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 1910
    .line 1911
    .line 1912
    move-result v43

    .line 1913
    const/4 v6, 0x0

    .line 1914
    invoke-static {v14, v13, v6, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1915
    .line 1916
    .line 1917
    move-result-object v13

    .line 1918
    if-eqz v13, :cond_79b

    .line 1919
    .line 1920
    sget-object v6, Ln3/l0;->a:Ljava/lang/String;

    .line 1921
    .line 1922
    const/4 v6, -0x1

    .line 1923
    invoke-virtual {v13, v8, v6}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 1924
    .line 1925
    .line 1926
    move-result-object v6

    .line 1927
    const/16 v24, 0x0

    .line 1928
    .line 1929
    aget-object v8, v6, v24

    .line 1930
    .line 1931
    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 1932
    .line 1933
    .line 1934
    move-result-wide v13

    .line 1935
    array-length v8, v6

    .line 1936
    move-object/from16 v49, v3

    .line 1937
    .line 1938
    const/4 v3, 0x1

    .line 1939
    if-le v8, v3, :cond_79f

    .line 1940
    .line 1941
    aget-object v6, v6, v3

    .line 1942
    .line 1943
    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 1944
    .line 1945
    .line 1946
    move-result-wide v72

    .line 1947
    goto :goto_79f

    .line 1948
    :cond_79b
    move-object/from16 v49, v3

    .line 1949
    .line 1950
    move-wide/from16 v13, v74

    .line 1951
    .line 1952
    :cond_79f
    :goto_79f
    cmp-long v3, v13, v74

    .line 1953
    .line 1954
    if-nez v3, :cond_7a5

    .line 1955
    .line 1956
    move-wide/from16 v72, v78

    .line 1957
    .line 1958
    :cond_7a5
    if-nez v10, :cond_7ce

    .line 1959
    .line 1960
    invoke-virtual {v15}, Ljava/util/AbstractMap;->isEmpty()Z

    .line 1961
    .line 1962
    .line 1963
    move-result v6

    .line 1964
    if-nez v6, :cond_7ce

    .line 1965
    .line 1966
    invoke-virtual {v15}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 1967
    .line 1968
    .line 1969
    move-result-object v6

    .line 1970
    const/4 v8, 0x0

    .line 1971
    new-array v10, v8, [Lk3/q;

    .line 1972
    .line 1973
    invoke-interface {v6, v10}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 1974
    .line 1975
    .line 1976
    move-result-object v6

    .line 1977
    check-cast v6, [Lk3/q;

    .line 1978
    .line 1979
    new-instance v8, Lk3/r;

    .line 1980
    .line 1981
    const/4 v10, 0x1

    .line 1982
    invoke-direct {v8, v5, v10, v6}, Lk3/r;-><init>(Ljava/lang/String;Z[Lk3/q;)V

    .line 1983
    .line 1984
    .line 1985
    if-nez v28, :cond_7c9

    .line 1986
    .line 1987
    invoke-static {v5, v6}, La4/x;->b(Ljava/lang/String;[Lk3/q;)Lk3/r;

    .line 1988
    .line 1989
    .line 1990
    move-result-object v6

    .line 1991
    move-object/from16 v36, v8

    .line 1992
    .line 1993
    goto :goto_7d1

    .line 1994
    :cond_7c9
    move-object/from16 v36, v8

    .line 1995
    .line 1996
    :goto_7cb
    move-object/from16 v6, v28

    .line 1997
    .line 1998
    goto :goto_7d1

    .line 1999
    :cond_7ce
    move-object/from16 v36, v10

    .line 2000
    .line 2001
    goto :goto_7cb

    .line 2002
    :goto_7d1
    new-instance v28, La4/k;

    .line 2003
    .line 2004
    const/16 v45, 0x0

    .line 2005
    .line 2006
    move-wide/from16 v31, v11

    .line 2007
    .line 2008
    move/from16 v33, v37

    .line 2009
    .line 2010
    move-wide/from16 v34, v39

    .line 2011
    .line 2012
    move-object/from16 v37, v41

    .line 2013
    .line 2014
    move-wide/from16 v39, v72

    .line 2015
    .line 2016
    move-wide/from16 v41, v13

    .line 2017
    .line 2018
    invoke-direct/range {v28 .. v45}, La4/k;-><init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZZZ)V

    .line 2019
    .line 2020
    .line 2021
    move-object/from16 v10, v28

    .line 2022
    .line 2023
    move-object/from16 v8, v87

    .line 2024
    .line 2025
    move-wide/from16 v39, v34

    .line 2026
    .line 2027
    move-object/from16 v41, v37

    .line 2028
    .line 2029
    move/from16 v37, v33

    .line 2030
    .line 2031
    invoke-interface {v8, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2032
    .line 2033
    .line 2034
    add-long v39, v39, v31

    .line 2035
    .line 2036
    if-eqz v3, :cond_7f7

    .line 2037
    .line 2038
    add-long v72, v72, v13

    .line 2039
    .line 2040
    :cond_7f7
    move-object v11, v0

    .line 2041
    move-object/from16 v65, v5

    .line 2042
    .line 2043
    move-object/from16 v28, v6

    .line 2044
    .line 2045
    move-object v10, v8

    .line 2046
    move-object/from16 v29, v36

    .line 2047
    .line 2048
    move/from16 v6, v37

    .line 2049
    .line 2050
    move-object/from16 v37, v41

    .line 2051
    .line 2052
    move-object/from16 v3, v49

    .line 2053
    .line 2054
    move-object/from16 v14, v81

    .line 2055
    .line 2056
    move-object/from16 v8, v82

    .line 2057
    .line 2058
    move-object/from16 v13, v83

    .line 2059
    .line 2060
    move-object/from16 v12, v84

    .line 2061
    .line 2062
    move-object/from16 v38, v85

    .line 2063
    .line 2064
    move-object/from16 v5, v115

    .line 2065
    .line 2066
    const/16 v24, 0x0

    .line 2067
    .line 2068
    move-object/from16 v0, p0

    .line 2069
    .line 2070
    move-object/from16 v49, v4

    .line 2071
    .line 2072
    goto/16 :goto_9e

    .line 2073
    .line 2074
    :cond_819
    move-object/from16 v49, v3

    .line 2075
    .line 2076
    move-object/from16 v8, v87

    .line 2077
    .line 2078
    const-string v3, "#EXT-X-DATERANGE"

    .line 2079
    .line 2080
    invoke-virtual {v14, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2081
    .line 2082
    .line 2083
    move-result v3

    .line 2084
    if-eqz v3, :cond_fca

    .line 2085
    .line 2086
    sget-object v3, La4/x;->O0:Ljava/util/regex/Pattern;

    .line 2087
    .line 2088
    move-object/from16 v11, v115

    .line 2089
    .line 2090
    invoke-static {v14, v3, v11, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2091
    .line 2092
    .line 2093
    move-result-object v3

    .line 2094
    const-string v12, "com.apple.hls.interstitial"

    .line 2095
    .line 2096
    invoke-virtual {v3, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2097
    .line 2098
    .line 2099
    move-result v3

    .line 2100
    if-eqz v3, :cond_fc8

    .line 2101
    .line 2102
    sget-object v3, La4/x;->N0:Ljava/util/regex/Pattern;

    .line 2103
    .line 2104
    invoke-static {v14, v3, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2105
    .line 2106
    .line 2107
    move-result-object v3

    .line 2108
    sget-object v12, La4/x;->U0:Ljava/util/regex/Pattern;

    .line 2109
    .line 2110
    const/4 v13, 0x0

    .line 2111
    invoke-static {v14, v12, v13, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2112
    .line 2113
    .line 2114
    move-result-object v12

    .line 2115
    if-eqz v12, :cond_84d

    .line 2116
    .line 2117
    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 2118
    .line 2119
    .line 2120
    move-result-object v16

    .line 2121
    move-object/from16 v12, v16

    .line 2122
    .line 2123
    :goto_84a
    move-object/from16 v87, v8

    .line 2124
    .line 2125
    goto :goto_84f

    .line 2126
    :cond_84d
    move-object v12, v13

    .line 2127
    goto :goto_84a

    .line 2128
    :goto_84f
    sget-object v8, La4/x;->V0:Ljava/util/regex/Pattern;

    .line 2129
    .line 2130
    invoke-static {v14, v8, v13, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2131
    .line 2132
    .line 2133
    move-result-object v8

    .line 2134
    if-eqz v8, :cond_860

    .line 2135
    .line 2136
    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 2137
    .line 2138
    .line 2139
    move-result-object v16

    .line 2140
    move-object/from16 v8, v16

    .line 2141
    .line 2142
    :goto_85d
    move-object/from16 v29, v10

    .line 2143
    .line 2144
    goto :goto_862

    .line 2145
    :cond_860
    move-object v8, v13

    .line 2146
    goto :goto_85d

    .line 2147
    :goto_862
    sget-object v10, La4/x;->P0:Ljava/util/regex/Pattern;

    .line 2148
    .line 2149
    invoke-static {v14, v10, v13, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2150
    .line 2151
    .line 2152
    move-result-object v10

    .line 2153
    if-eqz v10, :cond_875

    .line 2154
    .line 2155
    invoke-static {v10}, Ln3/l0;->V(Ljava/lang/String;)J

    .line 2156
    .line 2157
    .line 2158
    move-result-wide v42

    .line 2159
    invoke-static/range {v42 .. v43}, Ln3/l0;->S(J)J

    .line 2160
    .line 2161
    .line 2162
    move-result-wide v42

    .line 2163
    move-wide/from16 v90, v42

    .line 2164
    .line 2165
    goto :goto_877

    .line 2166
    :cond_875
    move-wide/from16 v90, v76

    .line 2167
    .line 2168
    :goto_877
    sget-object v10, La4/x;->R0:Ljava/util/regex/Pattern;

    .line 2169
    .line 2170
    invoke-static {v14, v10, v13, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2171
    .line 2172
    .line 2173
    move-result-object v10

    .line 2174
    if-eqz v10, :cond_88a

    .line 2175
    .line 2176
    invoke-static {v10}, Ln3/l0;->V(Ljava/lang/String;)J

    .line 2177
    .line 2178
    .line 2179
    move-result-wide v42

    .line 2180
    invoke-static/range {v42 .. v43}, Ln3/l0;->S(J)J

    .line 2181
    .line 2182
    .line 2183
    move-result-wide v42

    .line 2184
    move-wide/from16 v94, v42

    .line 2185
    .line 2186
    goto :goto_88c

    .line 2187
    :cond_88a
    move-wide/from16 v94, v76

    .line 2188
    .line 2189
    :goto_88c
    new-instance v10, Ljava/util/ArrayList;

    .line 2190
    .line 2191
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 2192
    .line 2193
    .line 2194
    move-object/from16 v115, v11

    .line 2195
    .line 2196
    sget-object v11, La4/x;->Q0:Ljava/util/regex/Pattern;

    .line 2197
    .line 2198
    invoke-static {v14, v11, v13, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2199
    .line 2200
    .line 2201
    move-result-object v11

    .line 2202
    const-string v13, ","

    .line 2203
    .line 2204
    if-eqz v11, :cond_8f5

    .line 2205
    .line 2206
    sget-object v36, Ln3/l0;->a:Ljava/lang/String;

    .line 2207
    .line 2208
    move-object/from16 v65, v15

    .line 2209
    .line 2210
    const/4 v15, -0x1

    .line 2211
    invoke-virtual {v11, v13, v15}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 2212
    .line 2213
    .line 2214
    move-result-object v11

    .line 2215
    array-length v15, v11

    .line 2216
    move-object/from16 v36, v11

    .line 2217
    .line 2218
    const/4 v11, 0x0

    .line 2219
    :goto_8aa
    if-ge v11, v15, :cond_8f7

    .line 2220
    .line 2221
    aget-object v38, v36, v11

    .line 2222
    .line 2223
    move/from16 v42, v11

    .line 2224
    .line 2225
    invoke-virtual/range {v38 .. v38}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 2226
    .line 2227
    .line 2228
    move-result-object v11

    .line 2229
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2230
    .line 2231
    .line 2232
    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    .line 2233
    .line 2234
    .line 2235
    move-result v38

    .line 2236
    sparse-switch v38, :sswitch_data_124e

    .line 2237
    .line 2238
    .line 2239
    move/from16 v38, v15

    .line 2240
    .line 2241
    :goto_8c0
    const/4 v15, -0x1

    .line 2242
    goto :goto_8e9

    .line 2243
    :sswitch_8c2
    move/from16 v38, v15

    .line 2244
    .line 2245
    const-string v15, "POST"

    .line 2246
    .line 2247
    invoke-virtual {v11, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2248
    .line 2249
    .line 2250
    move-result v15

    .line 2251
    if-nez v15, :cond_8cd

    .line 2252
    .line 2253
    goto :goto_8e7

    .line 2254
    :cond_8cd
    move/from16 v15, v32

    .line 2255
    .line 2256
    goto :goto_8e9

    .line 2257
    :sswitch_8d0
    move/from16 v38, v15

    .line 2258
    .line 2259
    const-string v15, "ONCE"

    .line 2260
    .line 2261
    invoke-virtual {v11, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2262
    .line 2263
    .line 2264
    move-result v15

    .line 2265
    if-nez v15, :cond_8db

    .line 2266
    .line 2267
    goto :goto_8e7

    .line 2268
    :cond_8db
    const/4 v15, 0x1

    .line 2269
    goto :goto_8e9

    .line 2270
    :sswitch_8dd
    move/from16 v38, v15

    .line 2271
    .line 2272
    const-string v15, "PRE"

    .line 2273
    .line 2274
    invoke-virtual {v11, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2275
    .line 2276
    .line 2277
    move-result v15

    .line 2278
    if-nez v15, :cond_8e8

    .line 2279
    .line 2280
    :goto_8e7
    goto :goto_8c0

    .line 2281
    :cond_8e8
    const/4 v15, 0x0

    .line 2282
    :goto_8e9
    packed-switch v15, :pswitch_data_125c

    .line 2283
    .line 2284
    .line 2285
    goto :goto_8f0

    .line 2286
    :pswitch_8ed
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2287
    .line 2288
    .line 2289
    :goto_8f0
    add-int/lit8 v11, v42, 0x1

    .line 2290
    .line 2291
    move/from16 v15, v38

    .line 2292
    .line 2293
    goto :goto_8aa

    .line 2294
    :cond_8f5
    move-object/from16 v65, v15

    .line 2295
    .line 2296
    :cond_8f7
    sget-object v11, La4/x;->Y:Ljava/util/regex/Pattern;

    .line 2297
    .line 2298
    move-object/from16 v86, v0

    .line 2299
    .line 2300
    const-wide/high16 v0, -0x4010000000000000L    # -1.0

    .line 2301
    .line 2302
    invoke-static {v14, v11, v0, v1, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 2303
    .line 2304
    .line 2305
    move-result-wide v42

    .line 2306
    const-wide/16 v44, 0x0

    .line 2307
    .line 2308
    cmpl-double v11, v42, v44

    .line 2309
    .line 2310
    if-ltz v11, :cond_90d

    .line 2311
    .line 2312
    mul-double v0, v42, v33

    .line 2313
    .line 2314
    double-to-long v0, v0

    .line 2315
    move-wide/from16 v98, v0

    .line 2316
    .line 2317
    goto :goto_90f

    .line 2318
    :cond_90d
    move-wide/from16 v98, v76

    .line 2319
    .line 2320
    :goto_90f
    sget-object v0, La4/x;->S0:Ljava/util/regex/Pattern;

    .line 2321
    .line 2322
    move-object v11, v4

    .line 2323
    move-object v1, v5

    .line 2324
    const-wide/high16 v4, -0x4010000000000000L    # -1.0

    .line 2325
    .line 2326
    invoke-static {v14, v0, v4, v5, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 2327
    .line 2328
    .line 2329
    move-result-wide v42

    .line 2330
    cmpl-double v0, v42, v44

    .line 2331
    .line 2332
    if-ltz v0, :cond_923

    .line 2333
    .line 2334
    mul-double v4, v42, v33

    .line 2335
    .line 2336
    double-to-long v4, v4

    .line 2337
    move-wide/from16 v102, v4

    .line 2338
    .line 2339
    goto :goto_925

    .line 2340
    :cond_923
    move-wide/from16 v102, v76

    .line 2341
    .line 2342
    :goto_925
    sget-object v0, La4/x;->T0:Ljava/util/regex/Pattern;

    .line 2343
    .line 2344
    invoke-static {v2, v14, v0}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 2345
    .line 2346
    .line 2347
    move-result v0

    .line 2348
    sget-object v4, La4/x;->W0:Ljava/util/regex/Pattern;

    .line 2349
    .line 2350
    move v15, v0

    .line 2351
    move-object v5, v1

    .line 2352
    const-wide/16 v0, 0x1

    .line 2353
    .line 2354
    invoke-static {v14, v4, v0, v1, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 2355
    .line 2356
    .line 2357
    move-result-wide v42

    .line 2358
    cmpl-double v0, v42, v0

    .line 2359
    .line 2360
    if-eqz v0, :cond_93f

    .line 2361
    .line 2362
    mul-double v0, v42, v33

    .line 2363
    .line 2364
    double-to-long v0, v0

    .line 2365
    move-wide/from16 v106, v0

    .line 2366
    .line 2367
    goto :goto_941

    .line 2368
    :cond_93f
    move-wide/from16 v106, v76

    .line 2369
    .line 2370
    :goto_941
    sget-object v0, La4/x;->X0:Ljava/util/regex/Pattern;

    .line 2371
    .line 2372
    move-object v1, v5

    .line 2373
    const-wide/high16 v4, -0x4010000000000000L    # -1.0

    .line 2374
    .line 2375
    invoke-static {v14, v0, v4, v5, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 2376
    .line 2377
    .line 2378
    move-result-wide v42

    .line 2379
    cmpl-double v0, v42, v44

    .line 2380
    .line 2381
    if-ltz v0, :cond_954

    .line 2382
    .line 2383
    mul-double v4, v42, v33

    .line 2384
    .line 2385
    double-to-long v4, v4

    .line 2386
    move-wide/from16 v110, v4

    .line 2387
    .line 2388
    goto :goto_956

    .line 2389
    :cond_954
    move-wide/from16 v110, v76

    .line 2390
    .line 2391
    :goto_956
    new-instance v0, Ljava/util/ArrayList;

    .line 2392
    .line 2393
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2394
    .line 2395
    .line 2396
    sget-object v4, La4/x;->Y0:Ljava/util/regex/Pattern;

    .line 2397
    .line 2398
    const/4 v5, 0x0

    .line 2399
    invoke-static {v14, v4, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2400
    .line 2401
    .line 2402
    move-result-object v4

    .line 2403
    if-eqz v4, :cond_997

    .line 2404
    .line 2405
    sget-object v5, Ln3/l0;->a:Ljava/lang/String;

    .line 2406
    .line 2407
    const/4 v5, -0x1

    .line 2408
    invoke-virtual {v4, v13, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 2409
    .line 2410
    .line 2411
    move-result-object v4

    .line 2412
    array-length v5, v4

    .line 2413
    move-object/from16 v36, v1

    .line 2414
    .line 2415
    const/4 v1, 0x0

    .line 2416
    :goto_96f
    if-ge v1, v5, :cond_999

    .line 2417
    .line 2418
    aget-object v38, v4, v1

    .line 2419
    .line 2420
    move/from16 v42, v1

    .line 2421
    .line 2422
    invoke-virtual/range {v38 .. v38}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 2423
    .line 2424
    .line 2425
    move-result-object v1

    .line 2426
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2427
    .line 2428
    .line 2429
    move-object/from16 v38, v4

    .line 2430
    .line 2431
    const-string v4, "IN"

    .line 2432
    .line 2433
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2434
    .line 2435
    .line 2436
    move-result v4

    .line 2437
    if-nez v4, :cond_98f

    .line 2438
    .line 2439
    const-string v4, "OUT"

    .line 2440
    .line 2441
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2442
    .line 2443
    .line 2444
    move-result v4

    .line 2445
    if-nez v4, :cond_98f

    .line 2446
    .line 2447
    goto :goto_992

    .line 2448
    :cond_98f
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2449
    .line 2450
    .line 2451
    :goto_992
    add-int/lit8 v1, v42, 0x1

    .line 2452
    .line 2453
    move-object/from16 v4, v38

    .line 2454
    .line 2455
    goto :goto_96f

    .line 2456
    :cond_997
    move-object/from16 v36, v1

    .line 2457
    .line 2458
    :cond_999
    new-instance v1, Ljava/util/ArrayList;

    .line 2459
    .line 2460
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 2461
    .line 2462
    .line 2463
    sget-object v4, La4/x;->Z0:Ljava/util/regex/Pattern;

    .line 2464
    .line 2465
    const/4 v5, 0x0

    .line 2466
    invoke-static {v14, v4, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2467
    .line 2468
    .line 2469
    move-result-object v4

    .line 2470
    if-eqz v4, :cond_9da

    .line 2471
    .line 2472
    sget-object v5, Ln3/l0;->a:Ljava/lang/String;

    .line 2473
    .line 2474
    const/4 v5, -0x1

    .line 2475
    invoke-virtual {v4, v13, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 2476
    .line 2477
    .line 2478
    move-result-object v4

    .line 2479
    array-length v5, v4

    .line 2480
    const/4 v13, 0x0

    .line 2481
    :goto_9b0
    if-ge v13, v5, :cond_9da

    .line 2482
    .line 2483
    aget-object v38, v4, v13

    .line 2484
    .line 2485
    move-object/from16 v42, v4

    .line 2486
    .line 2487
    invoke-virtual/range {v38 .. v38}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 2488
    .line 2489
    .line 2490
    move-result-object v4

    .line 2491
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2492
    .line 2493
    .line 2494
    move/from16 v38, v5

    .line 2495
    .line 2496
    const-string v5, "JUMP"

    .line 2497
    .line 2498
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2499
    .line 2500
    .line 2501
    move-result v5

    .line 2502
    if-nez v5, :cond_9d0

    .line 2503
    .line 2504
    const-string v5, "SKIP"

    .line 2505
    .line 2506
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2507
    .line 2508
    .line 2509
    move-result v5

    .line 2510
    if-nez v5, :cond_9d0

    .line 2511
    .line 2512
    goto :goto_9d3

    .line 2513
    :cond_9d0
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2514
    .line 2515
    .line 2516
    :goto_9d3
    add-int/lit8 v13, v13, 0x1

    .line 2517
    .line 2518
    move/from16 v5, v38

    .line 2519
    .line 2520
    move-object/from16 v4, v42

    .line 2521
    .line 2522
    goto :goto_9b0

    .line 2523
    :cond_9da
    sget-object v4, La4/x;->a1:Ljava/util/regex/Pattern;

    .line 2524
    .line 2525
    const/4 v5, 0x0

    .line 2526
    invoke-static {v14, v4, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2527
    .line 2528
    .line 2529
    move-result-object v4

    .line 2530
    if-eqz v4, :cond_9f4

    .line 2531
    .line 2532
    const-string v13, "NO"

    .line 2533
    .line 2534
    invoke-virtual {v4, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2535
    .line 2536
    .line 2537
    move-result v4

    .line 2538
    const/16 v80, 0x1

    .line 2539
    .line 2540
    xor-int/lit8 v4, v4, 0x1

    .line 2541
    .line 2542
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 2543
    .line 2544
    .line 2545
    move-result-object v16

    .line 2546
    move-object/from16 v4, v16

    .line 2547
    .line 2548
    goto :goto_9f5

    .line 2549
    :cond_9f4
    move-object v4, v5

    .line 2550
    :goto_9f5
    sget-object v13, La4/x;->b1:Ljava/util/regex/Pattern;

    .line 2551
    .line 2552
    invoke-static {v14, v13, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2553
    .line 2554
    .line 2555
    move-result-object v13

    .line 2556
    if-eqz v13, :cond_a0e

    .line 2557
    .line 2558
    const-string v5, "RANGE"

    .line 2559
    .line 2560
    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2561
    .line 2562
    .line 2563
    move-result v38

    .line 2564
    if-eqz v38, :cond_a07

    .line 2565
    .line 2566
    move-object v6, v5

    .line 2567
    goto :goto_a0f

    .line 2568
    :cond_a07
    invoke-virtual {v13, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2569
    .line 2570
    .line 2571
    move-result v5

    .line 2572
    if-eqz v5, :cond_a0e

    .line 2573
    .line 2574
    goto :goto_a0f

    .line 2575
    :cond_a0e
    const/4 v6, 0x0

    .line 2576
    :goto_a0f
    sget-object v5, La4/x;->c1:Ljava/util/regex/Pattern;

    .line 2577
    .line 2578
    const/4 v13, 0x0

    .line 2579
    invoke-static {v14, v5, v13, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2580
    .line 2581
    .line 2582
    move-result-object v5

    .line 2583
    if-eqz v5, :cond_a2a

    .line 2584
    .line 2585
    const-string v13, "PRIMARY"

    .line 2586
    .line 2587
    invoke-virtual {v5, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2588
    .line 2589
    .line 2590
    move-result v38

    .line 2591
    if-eqz v38, :cond_a21

    .line 2592
    .line 2593
    goto :goto_a2b

    .line 2594
    :cond_a21
    move-object/from16 v13, v35

    .line 2595
    .line 2596
    invoke-virtual {v5, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2597
    .line 2598
    .line 2599
    move-result v5

    .line 2600
    if-eqz v5, :cond_a2a

    .line 2601
    .line 2602
    goto :goto_a2b

    .line 2603
    :cond_a2a
    const/4 v13, 0x0

    .line 2604
    :goto_a2b
    sget-object v5, La4/x;->d1:Ljava/util/regex/Pattern;

    .line 2605
    .line 2606
    move-object/from16 v35, v0

    .line 2607
    .line 2608
    move-object/from16 v38, v1

    .line 2609
    .line 2610
    const-wide/high16 v0, -0x4010000000000000L    # -1.0

    .line 2611
    .line 2612
    invoke-static {v14, v5, v0, v1, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 2613
    .line 2614
    .line 2615
    move-result-wide v42

    .line 2616
    cmpl-double v5, v42, v44

    .line 2617
    .line 2618
    if-ltz v5, :cond_a41

    .line 2619
    .line 2620
    mul-double v0, v42, v33

    .line 2621
    .line 2622
    double-to-long v0, v0

    .line 2623
    move-wide/from16 v118, v0

    .line 2624
    .line 2625
    goto :goto_a43

    .line 2626
    :cond_a41
    move-wide/from16 v118, v76

    .line 2627
    .line 2628
    :goto_a43
    sget-object v0, La4/x;->e1:Ljava/util/regex/Pattern;

    .line 2629
    .line 2630
    move-object v1, v6

    .line 2631
    const-wide/high16 v5, -0x4010000000000000L    # -1.0

    .line 2632
    .line 2633
    invoke-static {v14, v0, v5, v6, v2}, La4/x;->h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D

    .line 2634
    .line 2635
    .line 2636
    move-result-wide v5

    .line 2637
    cmpl-double v0, v5, v44

    .line 2638
    .line 2639
    if-ltz v0, :cond_a56

    .line 2640
    .line 2641
    mul-double v5, v5, v33

    .line 2642
    .line 2643
    double-to-long v5, v5

    .line 2644
    move-wide/from16 v122, v5

    .line 2645
    .line 2646
    goto :goto_a58

    .line 2647
    :cond_a56
    move-wide/from16 v122, v76

    .line 2648
    .line 2649
    :goto_a58
    sget-object v0, La4/x;->f1:Ljava/util/regex/Pattern;

    .line 2650
    .line 2651
    const/4 v5, 0x0

    .line 2652
    invoke-static {v14, v0, v5, v7, v2}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2653
    .line 2654
    .line 2655
    move-result-object v0

    .line 2656
    new-instance v6, Ljava/util/ArrayList;

    .line 2657
    .line 2658
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 2659
    .line 2660
    .line 2661
    const/16 v5, 0x11

    .line 2662
    .line 2663
    invoke-virtual {v14, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 2664
    .line 2665
    .line 2666
    move-result-object v5

    .line 2667
    sget-object v14, La4/x;->h1:Ljava/util/regex/Pattern;

    .line 2668
    .line 2669
    invoke-static {v2, v5, v14}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 2670
    .line 2671
    .line 2672
    move-result-object v14

    .line 2673
    :goto_a70
    invoke-virtual {v14}, Ljava/util/regex/Matcher;->find()Z

    .line 2674
    .line 2675
    .line 2676
    move-result v33

    .line 2677
    if-eqz v33, :cond_bee

    .line 2678
    .line 2679
    move-object/from16 v33, v1

    .line 2680
    .line 2681
    invoke-virtual {v14}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    .line 2682
    .line 2683
    .line 2684
    move-result-object v1

    .line 2685
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2686
    .line 2687
    .line 2688
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 2689
    .line 2690
    .line 2691
    move-result v34

    .line 2692
    move-object/from16 v114, v11

    .line 2693
    .line 2694
    sparse-switch v34, :sswitch_data_1266

    .line 2695
    .line 2696
    .line 2697
    :goto_a88
    const/4 v11, -0x1

    .line 2698
    goto/16 :goto_b1c

    .line 2699
    .line 2700
    :sswitch_a8b
    const-string v11, "X-SKIP-CONTROL-LABEL-ID="

    .line 2701
    .line 2702
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2703
    .line 2704
    .line 2705
    move-result v11

    .line 2706
    if-nez v11, :cond_a95

    .line 2707
    .line 2708
    goto/16 :goto_b19

    .line 2709
    .line 2710
    :cond_a95
    const/16 v11, 0xb

    .line 2711
    .line 2712
    goto/16 :goto_b1c

    .line 2713
    .line 2714
    :sswitch_a99
    const-string v11, "X-ASSET-URI="

    .line 2715
    .line 2716
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2717
    .line 2718
    .line 2719
    move-result v11

    .line 2720
    if-nez v11, :cond_aa3

    .line 2721
    .line 2722
    goto/16 :goto_b19

    .line 2723
    .line 2724
    :cond_aa3
    const/16 v11, 0xa

    .line 2725
    .line 2726
    goto/16 :goto_b1c

    .line 2727
    .line 2728
    :sswitch_aa7
    const-string v11, "X-RESUME-OFFSET="

    .line 2729
    .line 2730
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2731
    .line 2732
    .line 2733
    move-result v11

    .line 2734
    if-nez v11, :cond_ab1

    .line 2735
    .line 2736
    goto/16 :goto_b19

    .line 2737
    .line 2738
    :cond_ab1
    const/16 v11, 0x9

    .line 2739
    .line 2740
    goto/16 :goto_b1c

    .line 2741
    .line 2742
    :sswitch_ab5
    const-string v11, "X-RESTRICT="

    .line 2743
    .line 2744
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2745
    .line 2746
    .line 2747
    move-result v11

    .line 2748
    if-nez v11, :cond_abf

    .line 2749
    .line 2750
    goto/16 :goto_b19

    .line 2751
    .line 2752
    :cond_abf
    const/16 v11, 0x8

    .line 2753
    .line 2754
    goto/16 :goto_b1c

    .line 2755
    .line 2756
    :sswitch_ac3
    const-string v11, "X-SKIP-CONTROL-OFFSET="

    .line 2757
    .line 2758
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2759
    .line 2760
    .line 2761
    move-result v11

    .line 2762
    if-nez v11, :cond_acc

    .line 2763
    .line 2764
    goto :goto_b19

    .line 2765
    :cond_acc
    const/4 v11, 0x7

    .line 2766
    goto :goto_b1c

    .line 2767
    :sswitch_ace
    const-string v11, "X-SKIP-CONTROL-DURATION="

    .line 2768
    .line 2769
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2770
    .line 2771
    .line 2772
    move-result v11

    .line 2773
    if-nez v11, :cond_ad7

    .line 2774
    .line 2775
    goto :goto_b19

    .line 2776
    :cond_ad7
    const/4 v11, 0x6

    .line 2777
    goto :goto_b1c

    .line 2778
    :sswitch_ad9
    const-string v11, "X-TIMELINE-OCCUPIES="

    .line 2779
    .line 2780
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2781
    .line 2782
    .line 2783
    move-result v11

    .line 2784
    if-nez v11, :cond_ae2

    .line 2785
    .line 2786
    goto :goto_b19

    .line 2787
    :cond_ae2
    const/4 v11, 0x5

    .line 2788
    goto :goto_b1c

    .line 2789
    :sswitch_ae4
    const-string v11, "X-ASSET-LIST="

    .line 2790
    .line 2791
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2792
    .line 2793
    .line 2794
    move-result v11

    .line 2795
    if-nez v11, :cond_aed

    .line 2796
    .line 2797
    goto :goto_b19

    .line 2798
    :cond_aed
    const/4 v11, 0x4

    .line 2799
    goto :goto_b1c

    .line 2800
    :sswitch_aef
    const-string v11, "X-TIMELINE-STYLE="

    .line 2801
    .line 2802
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2803
    .line 2804
    .line 2805
    move-result v11

    .line 2806
    if-nez v11, :cond_af8

    .line 2807
    .line 2808
    goto :goto_b19

    .line 2809
    :cond_af8
    const/4 v11, 0x3

    .line 2810
    goto :goto_b1c

    .line 2811
    :sswitch_afa
    const-string v11, "X-PLAYOUT-LIMIT="

    .line 2812
    .line 2813
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2814
    .line 2815
    .line 2816
    move-result v11

    .line 2817
    if-nez v11, :cond_b03

    .line 2818
    .line 2819
    goto :goto_b19

    .line 2820
    :cond_b03
    move/from16 v11, v32

    .line 2821
    .line 2822
    goto :goto_b1c

    .line 2823
    :sswitch_b06
    const-string v11, "X-CONTENT-MAY-VARY="

    .line 2824
    .line 2825
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2826
    .line 2827
    .line 2828
    move-result v11

    .line 2829
    if-nez v11, :cond_b0f

    .line 2830
    .line 2831
    goto :goto_b19

    .line 2832
    :cond_b0f
    const/4 v11, 0x1

    .line 2833
    goto :goto_b1c

    .line 2834
    :sswitch_b11
    const-string v11, "X-SNAP="

    .line 2835
    .line 2836
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2837
    .line 2838
    .line 2839
    move-result v11

    .line 2840
    if-nez v11, :cond_b1b

    .line 2841
    .line 2842
    :goto_b19
    goto/16 :goto_a88

    .line 2843
    .line 2844
    :cond_b1b
    const/4 v11, 0x0

    .line 2845
    :goto_b1c
    packed-switch v11, :pswitch_data_1298

    .line 2846
    .line 2847
    .line 2848
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 2849
    .line 2850
    .line 2851
    move-result v11

    .line 2852
    const/16 v80, 0x1

    .line 2853
    .line 2854
    add-int/lit8 v11, v11, -0x1

    .line 2855
    .line 2856
    move-object/from16 v34, v14

    .line 2857
    .line 2858
    const/4 v14, 0x0

    .line 2859
    invoke-virtual {v1, v14, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 2860
    .line 2861
    .line 2862
    move-result-object v1

    .line 2863
    const-string v11, "="

    .line 2864
    .line 2865
    invoke-static {v1, v11}, Lp/x2;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 2866
    .line 2867
    .line 2868
    move-result-object v11

    .line 2869
    invoke-virtual {v5, v11}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 2870
    .line 2871
    .line 2872
    move-result v14

    .line 2873
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 2874
    .line 2875
    .line 2876
    move-result v11

    .line 2877
    add-int/2addr v11, v14

    .line 2878
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 2879
    .line 2880
    .line 2881
    move-result v14

    .line 2882
    move/from16 v42, v15

    .line 2883
    .line 2884
    add-int/lit8 v15, v11, 0x1

    .line 2885
    .line 2886
    if-ne v14, v15, :cond_b49

    .line 2887
    .line 2888
    const/4 v14, 0x1

    .line 2889
    goto :goto_b4b

    .line 2890
    :cond_b49
    move/from16 v14, v32

    .line 2891
    .line 2892
    :goto_b4b
    add-int/2addr v14, v11

    .line 2893
    invoke-virtual {v5, v11, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 2894
    .line 2895
    .line 2896
    move-result-object v11

    .line 2897
    const-string v14, "\""

    .line 2898
    .line 2899
    invoke-virtual {v11, v14}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2900
    .line 2901
    .line 2902
    move-result v14

    .line 2903
    if-eqz v14, :cond_b7b

    .line 2904
    .line 2905
    new-instance v11, Ljava/lang/StringBuilder;

    .line 2906
    .line 2907
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 2908
    .line 2909
    .line 2910
    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2911
    .line 2912
    .line 2913
    const-string v14, "=\"((?:.|\u000c)+?)\""

    .line 2914
    .line 2915
    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2916
    .line 2917
    .line 2918
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2919
    .line 2920
    .line 2921
    move-result-object v11

    .line 2922
    invoke-static {v11}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 2923
    .line 2924
    .line 2925
    move-result-object v11

    .line 2926
    invoke-static {v5, v11, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2927
    .line 2928
    .line 2929
    move-result-object v11

    .line 2930
    new-instance v14, La4/g;

    .line 2931
    .line 2932
    const/4 v15, 0x0

    .line 2933
    invoke-direct {v14, v15, v1, v11}, La4/g;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 2934
    .line 2935
    .line 2936
    move-object v15, v9

    .line 2937
    move-object/from16 v43, v10

    .line 2938
    .line 2939
    goto :goto_bd6

    .line 2940
    :cond_b7b
    const-string v14, "0x"

    .line 2941
    .line 2942
    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2943
    .line 2944
    .line 2945
    move-result v14

    .line 2946
    if-nez v14, :cond_b8b

    .line 2947
    .line 2948
    const-string v14, "0X"

    .line 2949
    .line 2950
    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 2951
    .line 2952
    .line 2953
    move-result v11

    .line 2954
    if-eqz v11, :cond_b8f

    .line 2955
    .line 2956
    :cond_b8b
    move-object v15, v9

    .line 2957
    move-object/from16 v43, v10

    .line 2958
    .line 2959
    goto :goto_bb7

    .line 2960
    :cond_b8f
    new-instance v11, Ljava/lang/StringBuilder;

    .line 2961
    .line 2962
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 2963
    .line 2964
    .line 2965
    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2966
    .line 2967
    .line 2968
    const-string v14, "=([\\d\\.]+)\\b"

    .line 2969
    .line 2970
    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2971
    .line 2972
    .line 2973
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2974
    .line 2975
    .line 2976
    move-result-object v11

    .line 2977
    invoke-static {v11}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 2978
    .line 2979
    .line 2980
    move-result-object v11

    .line 2981
    new-instance v14, La4/g;

    .line 2982
    .line 2983
    sget-object v15, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 2984
    .line 2985
    invoke-static {v5, v11, v15, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 2986
    .line 2987
    .line 2988
    move-result-object v11

    .line 2989
    move-object v15, v9

    .line 2990
    move-object/from16 v43, v10

    .line 2991
    .line 2992
    invoke-static {v11}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 2993
    .line 2994
    .line 2995
    move-result-wide v9

    .line 2996
    invoke-direct {v14, v1, v9, v10}, La4/g;-><init>(Ljava/lang/String;D)V

    .line 2997
    .line 2998
    .line 2999
    goto :goto_bd6

    .line 3000
    :goto_bb7
    new-instance v9, Ljava/lang/StringBuilder;

    .line 3001
    .line 3002
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 3003
    .line 3004
    .line 3005
    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3006
    .line 3007
    .line 3008
    const-string v10, "=(0[xX][A-F0-9]+)"

    .line 3009
    .line 3010
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3011
    .line 3012
    .line 3013
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3014
    .line 3015
    .line 3016
    move-result-object v9

    .line 3017
    invoke-static {v9}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 3018
    .line 3019
    .line 3020
    move-result-object v9

    .line 3021
    invoke-static {v5, v9, v7, v2}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 3022
    .line 3023
    .line 3024
    move-result-object v9

    .line 3025
    new-instance v14, La4/g;

    .line 3026
    .line 3027
    const/4 v10, 0x1

    .line 3028
    invoke-direct {v14, v10, v1, v9}, La4/g;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 3029
    .line 3030
    .line 3031
    :goto_bd6
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 3032
    .line 3033
    .line 3034
    goto :goto_be1

    .line 3035
    :pswitch_bda
    move-object/from16 v43, v10

    .line 3036
    .line 3037
    move-object/from16 v34, v14

    .line 3038
    .line 3039
    move/from16 v42, v15

    .line 3040
    .line 3041
    move-object v15, v9

    .line 3042
    :goto_be1
    move-object v9, v15

    .line 3043
    move-object/from16 v1, v33

    .line 3044
    .line 3045
    move-object/from16 v14, v34

    .line 3046
    .line 3047
    move/from16 v15, v42

    .line 3048
    .line 3049
    move-object/from16 v10, v43

    .line 3050
    .line 3051
    move-object/from16 v11, v114

    .line 3052
    .line 3053
    goto/16 :goto_a70

    .line 3054
    .line 3055
    :cond_bee
    move-object/from16 v33, v1

    .line 3056
    .line 3057
    move-object/from16 v43, v10

    .line 3058
    .line 3059
    move-object/from16 v114, v11

    .line 3060
    .line 3061
    move/from16 v42, v15

    .line 3062
    .line 3063
    move-object/from16 v1, v83

    .line 3064
    .line 3065
    move-object v15, v9

    .line 3066
    invoke-virtual {v1, v3}, Ljava/util/AbstractMap;->containsKey(Ljava/lang/Object;)Z

    .line 3067
    .line 3068
    .line 3069
    move-result v5

    .line 3070
    if-eqz v5, :cond_c06

    .line 3071
    .line 3072
    invoke-virtual {v1, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3073
    .line 3074
    .line 3075
    move-result-object v5

    .line 3076
    check-cast v5, La4/i;

    .line 3077
    .line 3078
    goto :goto_c0b

    .line 3079
    :cond_c06
    new-instance v5, La4/i;

    .line 3080
    .line 3081
    invoke-direct {v5, v3}, La4/i;-><init>(Ljava/lang/String;)V

    .line 3082
    .line 3083
    .line 3084
    :goto_c0b
    if-nez v12, :cond_c11

    .line 3085
    .line 3086
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3087
    .line 3088
    .line 3089
    goto :goto_c22

    .line 3090
    :cond_c11
    iget-object v9, v5, La4/i;->c:Landroid/net/Uri;

    .line 3091
    .line 3092
    if-eqz v9, :cond_c20

    .line 3093
    .line 3094
    invoke-virtual {v9, v12}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 3095
    .line 3096
    .line 3097
    move-result v9

    .line 3098
    const-string v10, "Can\'t change assetUri from %s to %s"

    .line 3099
    .line 3100
    iget-object v11, v5, La4/i;->c:Landroid/net/Uri;

    .line 3101
    .line 3102
    invoke-static {v9, v10, v11, v12}, Loq/a;->p(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V

    .line 3103
    .line 3104
    .line 3105
    :cond_c20
    iput-object v12, v5, La4/i;->c:Landroid/net/Uri;

    .line 3106
    .line 3107
    :goto_c22
    if-nez v8, :cond_c25

    .line 3108
    .line 3109
    goto :goto_c36

    .line 3110
    :cond_c25
    iget-object v9, v5, La4/i;->d:Landroid/net/Uri;

    .line 3111
    .line 3112
    if-eqz v9, :cond_c34

    .line 3113
    .line 3114
    invoke-virtual {v9, v8}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 3115
    .line 3116
    .line 3117
    move-result v9

    .line 3118
    const-string v10, "Can\'t change assetListUri from %s to %s"

    .line 3119
    .line 3120
    iget-object v11, v5, La4/i;->d:Landroid/net/Uri;

    .line 3121
    .line 3122
    invoke-static {v9, v10, v11, v8}, Loq/a;->p(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V

    .line 3123
    .line 3124
    .line 3125
    :cond_c34
    iput-object v8, v5, La4/i;->d:Landroid/net/Uri;

    .line 3126
    .line 3127
    :goto_c36
    cmp-long v8, v90, v76

    .line 3128
    .line 3129
    if-nez v8, :cond_c3b

    .line 3130
    .line 3131
    goto :goto_c55

    .line 3132
    :cond_c3b
    iget-wide v8, v5, La4/i;->e:J

    .line 3133
    .line 3134
    cmp-long v10, v8, v76

    .line 3135
    .line 3136
    if-eqz v10, :cond_c51

    .line 3137
    .line 3138
    cmp-long v10, v8, v90

    .line 3139
    .line 3140
    if-nez v10, :cond_c48

    .line 3141
    .line 3142
    const/16 v93, 0x1

    .line 3143
    .line 3144
    goto :goto_c4a

    .line 3145
    :cond_c48
    const/16 v93, 0x0

    .line 3146
    .line 3147
    :goto_c4a
    const-string v92, "Can\'t change startDateUnixUs from %s to %s"

    .line 3148
    .line 3149
    move-wide/from16 v88, v8

    .line 3150
    .line 3151
    invoke-static/range {v88 .. v93}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3152
    .line 3153
    .line 3154
    :cond_c51
    move-wide/from16 v8, v90

    .line 3155
    .line 3156
    iput-wide v8, v5, La4/i;->e:J

    .line 3157
    .line 3158
    :goto_c55
    cmp-long v8, v94, v76

    .line 3159
    .line 3160
    if-nez v8, :cond_c5a

    .line 3161
    .line 3162
    goto :goto_c74

    .line 3163
    :cond_c5a
    iget-wide v8, v5, La4/i;->f:J

    .line 3164
    .line 3165
    cmp-long v10, v8, v76

    .line 3166
    .line 3167
    if-eqz v10, :cond_c70

    .line 3168
    .line 3169
    cmp-long v10, v8, v94

    .line 3170
    .line 3171
    if-nez v10, :cond_c67

    .line 3172
    .line 3173
    const/16 v97, 0x1

    .line 3174
    .line 3175
    goto :goto_c69

    .line 3176
    :cond_c67
    const/16 v97, 0x0

    .line 3177
    .line 3178
    :goto_c69
    const-string v96, "Can\'t change endDateUnixUs from %s to %s"

    .line 3179
    .line 3180
    move-wide/from16 v92, v8

    .line 3181
    .line 3182
    invoke-static/range {v92 .. v97}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3183
    .line 3184
    .line 3185
    :cond_c70
    move-wide/from16 v8, v94

    .line 3186
    .line 3187
    iput-wide v8, v5, La4/i;->f:J

    .line 3188
    .line 3189
    :goto_c74
    cmp-long v8, v98, v76

    .line 3190
    .line 3191
    if-nez v8, :cond_c79

    .line 3192
    .line 3193
    goto :goto_c93

    .line 3194
    :cond_c79
    iget-wide v8, v5, La4/i;->g:J

    .line 3195
    .line 3196
    cmp-long v10, v8, v76

    .line 3197
    .line 3198
    if-eqz v10, :cond_c8f

    .line 3199
    .line 3200
    cmp-long v10, v8, v98

    .line 3201
    .line 3202
    if-nez v10, :cond_c86

    .line 3203
    .line 3204
    const/16 v101, 0x1

    .line 3205
    .line 3206
    goto :goto_c88

    .line 3207
    :cond_c86
    const/16 v101, 0x0

    .line 3208
    .line 3209
    :goto_c88
    const-string v100, "Can\'t change durationUs from %s to %s"

    .line 3210
    .line 3211
    move-wide/from16 v96, v8

    .line 3212
    .line 3213
    invoke-static/range {v96 .. v101}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3214
    .line 3215
    .line 3216
    :cond_c8f
    move-wide/from16 v8, v98

    .line 3217
    .line 3218
    iput-wide v8, v5, La4/i;->g:J

    .line 3219
    .line 3220
    :goto_c93
    cmp-long v8, v102, v76

    .line 3221
    .line 3222
    if-nez v8, :cond_c98

    .line 3223
    .line 3224
    goto :goto_cb2

    .line 3225
    :cond_c98
    iget-wide v8, v5, La4/i;->h:J

    .line 3226
    .line 3227
    cmp-long v10, v8, v76

    .line 3228
    .line 3229
    if-eqz v10, :cond_cae

    .line 3230
    .line 3231
    cmp-long v10, v8, v102

    .line 3232
    .line 3233
    if-nez v10, :cond_ca5

    .line 3234
    .line 3235
    const/16 v105, 0x1

    .line 3236
    .line 3237
    goto :goto_ca7

    .line 3238
    :cond_ca5
    const/16 v105, 0x0

    .line 3239
    .line 3240
    :goto_ca7
    const-string v104, "Can\'t change plannedDurationUs from %s to %s"

    .line 3241
    .line 3242
    move-wide/from16 v100, v8

    .line 3243
    .line 3244
    invoke-static/range {v100 .. v105}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3245
    .line 3246
    .line 3247
    :cond_cae
    move-wide/from16 v8, v102

    .line 3248
    .line 3249
    iput-wide v8, v5, La4/i;->h:J

    .line 3250
    .line 3251
    :goto_cb2
    invoke-virtual/range {v43 .. v43}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3252
    .line 3253
    .line 3254
    move-result v8

    .line 3255
    const-string v9, " to "

    .line 3256
    .line 3257
    const-string v10, ", "

    .line 3258
    .line 3259
    if-eqz v8, :cond_cc0

    .line 3260
    .line 3261
    move-object/from16 v83, v15

    .line 3262
    .line 3263
    goto/16 :goto_d54

    .line 3264
    .line 3265
    :cond_cc0
    iget-object v8, v5, La4/i;->i:Ljava/util/ArrayList;

    .line 3266
    .line 3267
    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3268
    .line 3269
    .line 3270
    move-result v8

    .line 3271
    if-nez v8, :cond_d4e

    .line 3272
    .line 3273
    iget-object v8, v5, La4/i;->i:Ljava/util/ArrayList;

    .line 3274
    .line 3275
    move-object/from16 v11, v43

    .line 3276
    .line 3277
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    .line 3278
    .line 3279
    .line 3280
    move-result v8

    .line 3281
    new-instance v12, Ljava/lang/StringBuilder;

    .line 3282
    .line 3283
    const-string v14, "Can\'t change cue from "

    .line 3284
    .line 3285
    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3286
    .line 3287
    .line 3288
    iget-object v14, v5, La4/i;->i:Ljava/util/ArrayList;

    .line 3289
    .line 3290
    move-object/from16 v31, v14

    .line 3291
    .line 3292
    new-instance v14, Ljava/lang/StringBuilder;

    .line 3293
    .line 3294
    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    .line 3295
    .line 3296
    .line 3297
    invoke-virtual/range {v31 .. v31}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 3298
    .line 3299
    .line 3300
    move-result-object v31

    .line 3301
    invoke-interface/range {v31 .. v31}, Ljava/util/Iterator;->hasNext()Z

    .line 3302
    .line 3303
    .line 3304
    move-result v32

    .line 3305
    if-eqz v32, :cond_d07

    .line 3306
    .line 3307
    invoke-interface/range {v31 .. v31}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3308
    .line 3309
    .line 3310
    move-result-object v32

    .line 3311
    move-object/from16 v83, v15

    .line 3312
    .line 3313
    move-object/from16 v15, v32

    .line 3314
    .line 3315
    check-cast v15, Ljava/lang/CharSequence;

    .line 3316
    .line 3317
    :goto_cf4
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3318
    .line 3319
    .line 3320
    invoke-interface/range {v31 .. v31}, Ljava/util/Iterator;->hasNext()Z

    .line 3321
    .line 3322
    .line 3323
    move-result v15

    .line 3324
    if-eqz v15, :cond_d09

    .line 3325
    .line 3326
    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3327
    .line 3328
    .line 3329
    invoke-interface/range {v31 .. v31}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3330
    .line 3331
    .line 3332
    move-result-object v15

    .line 3333
    check-cast v15, Ljava/lang/CharSequence;

    .line 3334
    .line 3335
    goto :goto_cf4

    .line 3336
    :cond_d07
    move-object/from16 v83, v15

    .line 3337
    .line 3338
    :cond_d09
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3339
    .line 3340
    .line 3341
    move-result-object v14

    .line 3342
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3343
    .line 3344
    .line 3345
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3346
    .line 3347
    .line 3348
    new-instance v14, Ljava/lang/StringBuilder;

    .line 3349
    .line 3350
    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    .line 3351
    .line 3352
    .line 3353
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 3354
    .line 3355
    .line 3356
    move-result-object v15

    .line 3357
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 3358
    .line 3359
    .line 3360
    move-result v31

    .line 3361
    if-eqz v31, :cond_d3f

    .line 3362
    .line 3363
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3364
    .line 3365
    .line 3366
    move-result-object v31

    .line 3367
    move-object/from16 v32, v15

    .line 3368
    .line 3369
    move-object/from16 v15, v31

    .line 3370
    .line 3371
    check-cast v15, Ljava/lang/CharSequence;

    .line 3372
    .line 3373
    :goto_d2c
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3374
    .line 3375
    .line 3376
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    .line 3377
    .line 3378
    .line 3379
    move-result v15

    .line 3380
    if-eqz v15, :cond_d3f

    .line 3381
    .line 3382
    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3383
    .line 3384
    .line 3385
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3386
    .line 3387
    .line 3388
    move-result-object v15

    .line 3389
    check-cast v15, Ljava/lang/CharSequence;

    .line 3390
    .line 3391
    goto :goto_d2c

    .line 3392
    :cond_d3f
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3393
    .line 3394
    .line 3395
    move-result-object v14

    .line 3396
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3397
    .line 3398
    .line 3399
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3400
    .line 3401
    .line 3402
    move-result-object v12

    .line 3403
    invoke-static {v12, v8}, Loq/a;->m(Ljava/lang/String;Z)V

    .line 3404
    .line 3405
    .line 3406
    goto :goto_d52

    .line 3407
    :cond_d4e
    move-object/from16 v83, v15

    .line 3408
    .line 3409
    move-object/from16 v11, v43

    .line 3410
    .line 3411
    :goto_d52
    iput-object v11, v5, La4/i;->i:Ljava/util/ArrayList;

    .line 3412
    .line 3413
    :goto_d54
    if-nez v42, :cond_d57

    .line 3414
    .line 3415
    goto :goto_d5a

    .line 3416
    :cond_d57
    const/4 v8, 0x1

    .line 3417
    iput-boolean v8, v5, La4/i;->j:Z

    .line 3418
    .line 3419
    :goto_d5a
    cmp-long v8, v106, v76

    .line 3420
    .line 3421
    if-nez v8, :cond_d5f

    .line 3422
    .line 3423
    goto :goto_d79

    .line 3424
    :cond_d5f
    iget-wide v11, v5, La4/i;->k:J

    .line 3425
    .line 3426
    cmp-long v8, v11, v76

    .line 3427
    .line 3428
    if-eqz v8, :cond_d75

    .line 3429
    .line 3430
    cmp-long v8, v11, v106

    .line 3431
    .line 3432
    if-nez v8, :cond_d6c

    .line 3433
    .line 3434
    const/16 v109, 0x1

    .line 3435
    .line 3436
    goto :goto_d6e

    .line 3437
    :cond_d6c
    const/16 v109, 0x0

    .line 3438
    .line 3439
    :goto_d6e
    const-string v108, "Can\'t change resumeOffsetUs from %s to %s"

    .line 3440
    .line 3441
    move-wide/from16 v104, v11

    .line 3442
    .line 3443
    invoke-static/range {v104 .. v109}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3444
    .line 3445
    .line 3446
    :cond_d75
    move-wide/from16 v11, v106

    .line 3447
    .line 3448
    iput-wide v11, v5, La4/i;->k:J

    .line 3449
    .line 3450
    :goto_d79
    cmp-long v8, v110, v76

    .line 3451
    .line 3452
    if-nez v8, :cond_d7e

    .line 3453
    .line 3454
    goto :goto_d98

    .line 3455
    :cond_d7e
    iget-wide v11, v5, La4/i;->l:J

    .line 3456
    .line 3457
    cmp-long v8, v11, v76

    .line 3458
    .line 3459
    if-eqz v8, :cond_d94

    .line 3460
    .line 3461
    cmp-long v8, v11, v110

    .line 3462
    .line 3463
    if-nez v8, :cond_d8b

    .line 3464
    .line 3465
    const/16 v113, 0x1

    .line 3466
    .line 3467
    goto :goto_d8d

    .line 3468
    :cond_d8b
    const/16 v113, 0x0

    .line 3469
    .line 3470
    :goto_d8d
    const-string v112, "Can\'t change playoutLimitUs from %s to %s"

    .line 3471
    .line 3472
    move-wide/from16 v108, v11

    .line 3473
    .line 3474
    invoke-static/range {v108 .. v113}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3475
    .line 3476
    .line 3477
    :cond_d94
    move-wide/from16 v11, v110

    .line 3478
    .line 3479
    iput-wide v11, v5, La4/i;->l:J

    .line 3480
    .line 3481
    :goto_d98
    invoke-virtual/range {v35 .. v35}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3482
    .line 3483
    .line 3484
    move-result v8

    .line 3485
    if-eqz v8, :cond_da0

    .line 3486
    .line 3487
    goto/16 :goto_e2e

    .line 3488
    .line 3489
    :cond_da0
    iget-object v8, v5, La4/i;->m:Ljava/util/ArrayList;

    .line 3490
    .line 3491
    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3492
    .line 3493
    .line 3494
    move-result v8

    .line 3495
    if-nez v8, :cond_e2a

    .line 3496
    .line 3497
    iget-object v8, v5, La4/i;->m:Ljava/util/ArrayList;

    .line 3498
    .line 3499
    move-object/from16 v11, v35

    .line 3500
    .line 3501
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    .line 3502
    .line 3503
    .line 3504
    move-result v8

    .line 3505
    new-instance v12, Ljava/lang/StringBuilder;

    .line 3506
    .line 3507
    const-string v14, "Can\'t change snapTypes from "

    .line 3508
    .line 3509
    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3510
    .line 3511
    .line 3512
    iget-object v14, v5, La4/i;->m:Ljava/util/ArrayList;

    .line 3513
    .line 3514
    new-instance v15, Ljava/lang/StringBuilder;

    .line 3515
    .line 3516
    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    .line 3517
    .line 3518
    .line 3519
    invoke-virtual {v14}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 3520
    .line 3521
    .line 3522
    move-result-object v14

    .line 3523
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    .line 3524
    .line 3525
    .line 3526
    move-result v31

    .line 3527
    if-eqz v31, :cond_de5

    .line 3528
    .line 3529
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3530
    .line 3531
    .line 3532
    move-result-object v31

    .line 3533
    move-object/from16 v32, v14

    .line 3534
    .line 3535
    move-object/from16 v14, v31

    .line 3536
    .line 3537
    check-cast v14, Ljava/lang/CharSequence;

    .line 3538
    .line 3539
    :goto_dd2
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3540
    .line 3541
    .line 3542
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    .line 3543
    .line 3544
    .line 3545
    move-result v14

    .line 3546
    if-eqz v14, :cond_de5

    .line 3547
    .line 3548
    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3549
    .line 3550
    .line 3551
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3552
    .line 3553
    .line 3554
    move-result-object v14

    .line 3555
    check-cast v14, Ljava/lang/CharSequence;

    .line 3556
    .line 3557
    goto :goto_dd2

    .line 3558
    :cond_de5
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3559
    .line 3560
    .line 3561
    move-result-object v14

    .line 3562
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3563
    .line 3564
    .line 3565
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3566
    .line 3567
    .line 3568
    new-instance v14, Ljava/lang/StringBuilder;

    .line 3569
    .line 3570
    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    .line 3571
    .line 3572
    .line 3573
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 3574
    .line 3575
    .line 3576
    move-result-object v15

    .line 3577
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 3578
    .line 3579
    .line 3580
    move-result v31

    .line 3581
    if-eqz v31, :cond_e1b

    .line 3582
    .line 3583
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3584
    .line 3585
    .line 3586
    move-result-object v31

    .line 3587
    move-object/from16 v32, v15

    .line 3588
    .line 3589
    move-object/from16 v15, v31

    .line 3590
    .line 3591
    check-cast v15, Ljava/lang/CharSequence;

    .line 3592
    .line 3593
    :goto_e08
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3594
    .line 3595
    .line 3596
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    .line 3597
    .line 3598
    .line 3599
    move-result v15

    .line 3600
    if-eqz v15, :cond_e1b

    .line 3601
    .line 3602
    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3603
    .line 3604
    .line 3605
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3606
    .line 3607
    .line 3608
    move-result-object v15

    .line 3609
    check-cast v15, Ljava/lang/CharSequence;

    .line 3610
    .line 3611
    goto :goto_e08

    .line 3612
    :cond_e1b
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3613
    .line 3614
    .line 3615
    move-result-object v14

    .line 3616
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3617
    .line 3618
    .line 3619
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3620
    .line 3621
    .line 3622
    move-result-object v12

    .line 3623
    invoke-static {v12, v8}, Loq/a;->m(Ljava/lang/String;Z)V

    .line 3624
    .line 3625
    .line 3626
    goto :goto_e2c

    .line 3627
    :cond_e2a
    move-object/from16 v11, v35

    .line 3628
    .line 3629
    :goto_e2c
    iput-object v11, v5, La4/i;->m:Ljava/util/ArrayList;

    .line 3630
    .line 3631
    :goto_e2e
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3632
    .line 3633
    .line 3634
    invoke-virtual/range {v38 .. v38}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3635
    .line 3636
    .line 3637
    move-result v8

    .line 3638
    if-eqz v8, :cond_e39

    .line 3639
    .line 3640
    goto/16 :goto_ebd

    .line 3641
    .line 3642
    :cond_e39
    iget-object v8, v5, La4/i;->n:Ljava/util/ArrayList;

    .line 3643
    .line 3644
    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3645
    .line 3646
    .line 3647
    move-result v8

    .line 3648
    if-nez v8, :cond_eb9

    .line 3649
    .line 3650
    iget-object v8, v5, La4/i;->n:Ljava/util/ArrayList;

    .line 3651
    .line 3652
    move-object/from16 v11, v38

    .line 3653
    .line 3654
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    .line 3655
    .line 3656
    .line 3657
    move-result v8

    .line 3658
    new-instance v12, Ljava/lang/StringBuilder;

    .line 3659
    .line 3660
    const-string v14, "Can\'t change restrictions from "

    .line 3661
    .line 3662
    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3663
    .line 3664
    .line 3665
    iget-object v14, v5, La4/i;->n:Ljava/util/ArrayList;

    .line 3666
    .line 3667
    new-instance v15, Ljava/lang/StringBuilder;

    .line 3668
    .line 3669
    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    .line 3670
    .line 3671
    .line 3672
    invoke-virtual {v14}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 3673
    .line 3674
    .line 3675
    move-result-object v14

    .line 3676
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    .line 3677
    .line 3678
    .line 3679
    move-result v31

    .line 3680
    if-eqz v31, :cond_e7e

    .line 3681
    .line 3682
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3683
    .line 3684
    .line 3685
    move-result-object v31

    .line 3686
    move-object/from16 v32, v14

    .line 3687
    .line 3688
    move-object/from16 v14, v31

    .line 3689
    .line 3690
    check-cast v14, Ljava/lang/CharSequence;

    .line 3691
    .line 3692
    :goto_e6b
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3693
    .line 3694
    .line 3695
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    .line 3696
    .line 3697
    .line 3698
    move-result v14

    .line 3699
    if-eqz v14, :cond_e7e

    .line 3700
    .line 3701
    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3702
    .line 3703
    .line 3704
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3705
    .line 3706
    .line 3707
    move-result-object v14

    .line 3708
    check-cast v14, Ljava/lang/CharSequence;

    .line 3709
    .line 3710
    goto :goto_e6b

    .line 3711
    :cond_e7e
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3712
    .line 3713
    .line 3714
    move-result-object v14

    .line 3715
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3716
    .line 3717
    .line 3718
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3719
    .line 3720
    .line 3721
    new-instance v9, Ljava/lang/StringBuilder;

    .line 3722
    .line 3723
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 3724
    .line 3725
    .line 3726
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 3727
    .line 3728
    .line 3729
    move-result-object v14

    .line 3730
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    .line 3731
    .line 3732
    .line 3733
    move-result v15

    .line 3734
    if-eqz v15, :cond_eaa

    .line 3735
    .line 3736
    :goto_e97
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 3737
    .line 3738
    .line 3739
    move-result-object v15

    .line 3740
    check-cast v15, Ljava/lang/CharSequence;

    .line 3741
    .line 3742
    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3743
    .line 3744
    .line 3745
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    .line 3746
    .line 3747
    .line 3748
    move-result v15

    .line 3749
    if-eqz v15, :cond_eaa

    .line 3750
    .line 3751
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 3752
    .line 3753
    .line 3754
    goto :goto_e97

    .line 3755
    :cond_eaa
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3756
    .line 3757
    .line 3758
    move-result-object v9

    .line 3759
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3760
    .line 3761
    .line 3762
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 3763
    .line 3764
    .line 3765
    move-result-object v9

    .line 3766
    invoke-static {v9, v8}, Loq/a;->m(Ljava/lang/String;Z)V

    .line 3767
    .line 3768
    .line 3769
    goto :goto_ebb

    .line 3770
    :cond_eb9
    move-object/from16 v11, v38

    .line 3771
    .line 3772
    :goto_ebb
    iput-object v11, v5, La4/i;->n:Ljava/util/ArrayList;

    .line 3773
    .line 3774
    :goto_ebd
    iget-object v8, v5, La4/i;->b:Ljava/util/HashMap;

    .line 3775
    .line 3776
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3777
    .line 3778
    .line 3779
    move-result v9

    .line 3780
    if-eqz v9, :cond_ec9

    .line 3781
    .line 3782
    :cond_ec5
    move-object v12, v1

    .line 3783
    move-object/from16 v88, v7

    .line 3784
    .line 3785
    goto :goto_f1e

    .line 3786
    :cond_ec9
    const/4 v9, 0x0

    .line 3787
    :goto_eca
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 3788
    .line 3789
    .line 3790
    move-result v10

    .line 3791
    if-ge v9, v10, :cond_ec5

    .line 3792
    .line 3793
    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 3794
    .line 3795
    .line 3796
    move-result-object v10

    .line 3797
    check-cast v10, La4/g;

    .line 3798
    .line 3799
    iget-object v11, v10, La4/g;->a:Ljava/lang/String;

    .line 3800
    .line 3801
    invoke-virtual {v8, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3802
    .line 3803
    .line 3804
    move-result-object v12

    .line 3805
    check-cast v12, La4/g;

    .line 3806
    .line 3807
    if-eqz v12, :cond_f0c

    .line 3808
    .line 3809
    invoke-virtual {v12, v10}, La4/g;->equals(Ljava/lang/Object;)Z

    .line 3810
    .line 3811
    .line 3812
    move-result v14

    .line 3813
    iget-object v15, v12, La4/g;->d:Ljava/lang/String;

    .line 3814
    .line 3815
    move-object/from16 v32, v6

    .line 3816
    .line 3817
    move-object/from16 v88, v7

    .line 3818
    .line 3819
    iget-wide v6, v12, La4/g;->c:D

    .line 3820
    .line 3821
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 3822
    .line 3823
    .line 3824
    move-result-object v6

    .line 3825
    iget-object v7, v10, La4/g;->d:Ljava/lang/String;

    .line 3826
    .line 3827
    move-object v12, v1

    .line 3828
    iget-wide v1, v10, La4/g;->c:D

    .line 3829
    .line 3830
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 3831
    .line 3832
    .line 3833
    move-result-object v1

    .line 3834
    filled-new-array {v11, v15, v6, v7, v1}, [Ljava/lang/Object;

    .line 3835
    .line 3836
    .line 3837
    move-result-object v1

    .line 3838
    if-eqz v14, :cond_f00

    .line 3839
    .line 3840
    goto :goto_f11

    .line 3841
    :cond_f00
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 3842
    .line 3843
    const-string v2, "Can\'t change %s from %s %s to %s %s"

    .line 3844
    .line 3845
    invoke-static {v2, v1}, Lox/b;->z(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 3846
    .line 3847
    .line 3848
    move-result-object v1

    .line 3849
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 3850
    .line 3851
    .line 3852
    throw v0

    .line 3853
    :cond_f0c
    move-object v12, v1

    .line 3854
    move-object/from16 v32, v6

    .line 3855
    .line 3856
    move-object/from16 v88, v7

    .line 3857
    .line 3858
    :goto_f11
    invoke-virtual {v8, v11, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3859
    .line 3860
    .line 3861
    add-int/lit8 v9, v9, 0x1

    .line 3862
    .line 3863
    move-object/from16 v2, p4

    .line 3864
    .line 3865
    move-object v1, v12

    .line 3866
    move-object/from16 v6, v32

    .line 3867
    .line 3868
    move-object/from16 v7, v88

    .line 3869
    .line 3870
    goto :goto_eca

    .line 3871
    :goto_f1e
    if-nez v4, :cond_f21

    .line 3872
    .line 3873
    goto :goto_f32

    .line 3874
    :cond_f21
    iget-object v1, v5, La4/i;->o:Ljava/lang/Boolean;

    .line 3875
    .line 3876
    if-eqz v1, :cond_f30

    .line 3877
    .line 3878
    invoke-virtual {v1, v4}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 3879
    .line 3880
    .line 3881
    move-result v1

    .line 3882
    const-string v2, "Can\'t change contentMayVary from %s to %s"

    .line 3883
    .line 3884
    iget-object v6, v5, La4/i;->o:Ljava/lang/Boolean;

    .line 3885
    .line 3886
    invoke-static {v1, v2, v6, v4}, Loq/a;->p(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V

    .line 3887
    .line 3888
    .line 3889
    :cond_f30
    iput-object v4, v5, La4/i;->o:Ljava/lang/Boolean;

    .line 3890
    .line 3891
    :goto_f32
    if-nez v33, :cond_f35

    .line 3892
    .line 3893
    goto :goto_f48

    .line 3894
    :cond_f35
    iget-object v1, v5, La4/i;->p:Ljava/lang/String;

    .line 3895
    .line 3896
    move-object/from16 v6, v33

    .line 3897
    .line 3898
    if-eqz v1, :cond_f46

    .line 3899
    .line 3900
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 3901
    .line 3902
    .line 3903
    move-result v1

    .line 3904
    const-string v2, "Can\'t change timelineOccupies from %s to %s"

    .line 3905
    .line 3906
    iget-object v4, v5, La4/i;->p:Ljava/lang/String;

    .line 3907
    .line 3908
    invoke-static {v1, v2, v4, v6}, Loq/a;->p(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V

    .line 3909
    .line 3910
    .line 3911
    :cond_f46
    iput-object v6, v5, La4/i;->p:Ljava/lang/String;

    .line 3912
    .line 3913
    :goto_f48
    if-nez v13, :cond_f4b

    .line 3914
    .line 3915
    goto :goto_f5c

    .line 3916
    :cond_f4b
    iget-object v1, v5, La4/i;->q:Ljava/lang/String;

    .line 3917
    .line 3918
    if-eqz v1, :cond_f5a

    .line 3919
    .line 3920
    invoke-virtual {v1, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 3921
    .line 3922
    .line 3923
    move-result v1

    .line 3924
    const-string v2, "Can\'t change timelineStyle from %s to %s"

    .line 3925
    .line 3926
    iget-object v4, v5, La4/i;->q:Ljava/lang/String;

    .line 3927
    .line 3928
    invoke-static {v1, v2, v4, v13}, Loq/a;->p(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V

    .line 3929
    .line 3930
    .line 3931
    :cond_f5a
    iput-object v13, v5, La4/i;->q:Ljava/lang/String;

    .line 3932
    .line 3933
    :goto_f5c
    cmp-long v1, v118, v76

    .line 3934
    .line 3935
    if-nez v1, :cond_f61

    .line 3936
    .line 3937
    goto :goto_f7b

    .line 3938
    :cond_f61
    iget-wide v1, v5, La4/i;->r:J

    .line 3939
    .line 3940
    cmp-long v4, v1, v76

    .line 3941
    .line 3942
    if-eqz v4, :cond_f77

    .line 3943
    .line 3944
    cmp-long v4, v1, v118

    .line 3945
    .line 3946
    if-nez v4, :cond_f6e

    .line 3947
    .line 3948
    const/16 v121, 0x1

    .line 3949
    .line 3950
    goto :goto_f70

    .line 3951
    :cond_f6e
    const/16 v121, 0x0

    .line 3952
    .line 3953
    :goto_f70
    const-string v120, "Can\'t change skipControlOffsetUs from %s to %s"

    .line 3954
    .line 3955
    move-wide/from16 v116, v1

    .line 3956
    .line 3957
    invoke-static/range {v116 .. v121}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3958
    .line 3959
    .line 3960
    :cond_f77
    move-wide/from16 v1, v118

    .line 3961
    .line 3962
    iput-wide v1, v5, La4/i;->r:J

    .line 3963
    .line 3964
    :goto_f7b
    cmp-long v1, v122, v76

    .line 3965
    .line 3966
    if-nez v1, :cond_f80

    .line 3967
    .line 3968
    goto :goto_f9a

    .line 3969
    :cond_f80
    iget-wide v1, v5, La4/i;->s:J

    .line 3970
    .line 3971
    cmp-long v4, v1, v76

    .line 3972
    .line 3973
    if-eqz v4, :cond_f96

    .line 3974
    .line 3975
    cmp-long v4, v1, v122

    .line 3976
    .line 3977
    if-nez v4, :cond_f8d

    .line 3978
    .line 3979
    const/16 v125, 0x1

    .line 3980
    .line 3981
    goto :goto_f8f

    .line 3982
    :cond_f8d
    const/16 v125, 0x0

    .line 3983
    .line 3984
    :goto_f8f
    const-string v124, "Can\'t change skipControlDurationUs from %s to %s"

    .line 3985
    .line 3986
    move-wide/from16 v120, v1

    .line 3987
    .line 3988
    invoke-static/range {v120 .. v125}, Loq/a;->j(JJLjava/lang/String;Z)V

    .line 3989
    .line 3990
    .line 3991
    :cond_f96
    move-wide/from16 v1, v122

    .line 3992
    .line 3993
    iput-wide v1, v5, La4/i;->s:J

    .line 3994
    .line 3995
    :goto_f9a
    if-nez v0, :cond_f9d

    .line 3996
    .line 3997
    goto :goto_fae

    .line 3998
    :cond_f9d
    iget-object v1, v5, La4/i;->t:Ljava/lang/String;

    .line 3999
    .line 4000
    if-eqz v1, :cond_fac

    .line 4001
    .line 4002
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4003
    .line 4004
    .line 4005
    move-result v1

    .line 4006
    const-string v2, "Can\'t change skipControlLabelId from %s to %s"

    .line 4007
    .line 4008
    iget-object v4, v5, La4/i;->t:Ljava/lang/String;

    .line 4009
    .line 4010
    invoke-static {v1, v2, v4, v0}, Loq/a;->p(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V

    .line 4011
    .line 4012
    .line 4013
    :cond_fac
    iput-object v0, v5, La4/i;->t:Ljava/lang/String;

    .line 4014
    .line 4015
    :goto_fae
    invoke-virtual {v12, v3, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4016
    .line 4017
    .line 4018
    :cond_fb1
    move-object/from16 v2, p4

    .line 4019
    .line 4020
    move-object/from16 v10, v36

    .line 4021
    .line 4022
    move-wide/from16 v45, v46

    .line 4023
    .line 4024
    move/from16 v47, v48

    .line 4025
    .line 4026
    move-wide/from16 v35, v69

    .line 4027
    .line 4028
    move-object/from16 v34, v71

    .line 4029
    .line 4030
    move-object/from16 v5, v82

    .line 4031
    .line 4032
    move-object/from16 v15, v83

    .line 4033
    .line 4034
    move-object/from16 v8, v87

    .line 4035
    .line 4036
    move-object/from16 v3, v88

    .line 4037
    .line 4038
    const/4 v14, 0x0

    .line 4039
    goto/16 :goto_10b8

    .line 4040
    .line 4041
    :cond_fc8
    move-object/from16 v115, v11

    .line 4042
    .line 4043
    :cond_fca
    move-object/from16 v86, v0

    .line 4044
    .line 4045
    move-object/from16 v114, v4

    .line 4046
    .line 4047
    move-object/from16 v36, v5

    .line 4048
    .line 4049
    move-object/from16 v88, v7

    .line 4050
    .line 4051
    move-object/from16 v87, v8

    .line 4052
    .line 4053
    move-object/from16 v29, v10

    .line 4054
    .line 4055
    move-object/from16 v65, v15

    .line 4056
    .line 4057
    move-object/from16 v12, v83

    .line 4058
    .line 4059
    move-object/from16 v83, v9

    .line 4060
    .line 4061
    const-string v0, "#"

    .line 4062
    .line 4063
    invoke-virtual {v14, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 4064
    .line 4065
    .line 4066
    move-result v0

    .line 4067
    if-nez v0, :cond_fb1

    .line 4068
    .line 4069
    if-nez v41, :cond_fe9

    .line 4070
    .line 4071
    const/16 v38, 0x0

    .line 4072
    .line 4073
    goto :goto_ff2

    .line 4074
    :cond_fe9
    if-eqz v85, :cond_fee

    .line 4075
    .line 4076
    move-object/from16 v38, v85

    .line 4077
    .line 4078
    goto :goto_ff2

    .line 4079
    :cond_fee
    invoke-static/range {v57 .. v58}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    .line 4080
    .line 4081
    .line 4082
    move-result-object v38

    .line 4083
    :goto_ff2
    add-long v0, v57, v42

    .line 4084
    .line 4085
    move-object/from16 v2, p4

    .line 4086
    .line 4087
    move-object/from16 v3, v88

    .line 4088
    .line 4089
    invoke-static {v14, v3, v2}, La4/x;->m(Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 4090
    .line 4091
    .line 4092
    move-result-object v4

    .line 4093
    move-object/from16 v5, v82

    .line 4094
    .line 4095
    invoke-virtual {v5, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4096
    .line 4097
    .line 4098
    move-result-object v6

    .line 4099
    check-cast v6, La4/m;

    .line 4100
    .line 4101
    cmp-long v7, v46, v74

    .line 4102
    .line 4103
    if-nez v7, :cond_100b

    .line 4104
    .line 4105
    move-wide/from16 v43, v78

    .line 4106
    .line 4107
    goto :goto_1025

    .line 4108
    :cond_100b
    if-eqz v68, :cond_1023

    .line 4109
    .line 4110
    if-nez v30, :cond_1023

    .line 4111
    .line 4112
    if-nez v6, :cond_1023

    .line 4113
    .line 4114
    new-instance v57, La4/m;

    .line 4115
    .line 4116
    const/16 v63, 0x0

    .line 4117
    .line 4118
    const/16 v64, 0x0

    .line 4119
    .line 4120
    const-wide/16 v59, 0x0

    .line 4121
    .line 4122
    move-object/from16 v58, v4

    .line 4123
    .line 4124
    invoke-direct/range {v57 .. v64}, La4/m;-><init>(Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)V

    .line 4125
    .line 4126
    .line 4127
    move-object/from16 v6, v57

    .line 4128
    .line 4129
    invoke-virtual {v5, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4130
    .line 4131
    .line 4132
    :cond_1023
    move-wide/from16 v43, v61

    .line 4133
    .line 4134
    :goto_1025
    if-nez v29, :cond_104d

    .line 4135
    .line 4136
    invoke-virtual/range {v65 .. v65}, Ljava/util/AbstractMap;->isEmpty()Z

    .line 4137
    .line 4138
    .line 4139
    move-result v8

    .line 4140
    if-nez v8, :cond_104d

    .line 4141
    .line 4142
    invoke-virtual/range {v65 .. v65}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 4143
    .line 4144
    .line 4145
    move-result-object v8

    .line 4146
    const/4 v14, 0x0

    .line 4147
    new-array v9, v14, [Lk3/q;

    .line 4148
    .line 4149
    invoke-interface {v8, v9}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 4150
    .line 4151
    .line 4152
    move-result-object v8

    .line 4153
    check-cast v8, [Lk3/q;

    .line 4154
    .line 4155
    new-instance v9, Lk3/r;

    .line 4156
    .line 4157
    move-object/from16 v10, v36

    .line 4158
    .line 4159
    const/4 v11, 0x1

    .line 4160
    invoke-direct {v9, v10, v11, v8}, Lk3/r;-><init>(Ljava/lang/String;Z[Lk3/q;)V

    .line 4161
    .line 4162
    .line 4163
    if-nez v28, :cond_104a

    .line 4164
    .line 4165
    invoke-static {v10, v8}, La4/x;->b(Ljava/lang/String;[Lk3/q;)Lk3/r;

    .line 4166
    .line 4167
    .line 4168
    move-result-object v8

    .line 4169
    move-object/from16 v28, v8

    .line 4170
    .line 4171
    :cond_104a
    move-object/from16 v40, v9

    .line 4172
    .line 4173
    goto :goto_1052

    .line 4174
    :cond_104d
    move-object/from16 v10, v36

    .line 4175
    .line 4176
    const/4 v14, 0x0

    .line 4177
    move-object/from16 v40, v29

    .line 4178
    .line 4179
    :goto_1052
    new-instance v31, La4/m;

    .line 4180
    .line 4181
    if-eqz v30, :cond_1069

    .line 4182
    .line 4183
    move-object/from16 v33, v30

    .line 4184
    .line 4185
    :goto_1058
    move-object/from16 v32, v4

    .line 4186
    .line 4187
    move-object/from16 v42, v38

    .line 4188
    .line 4189
    move-wide/from16 v45, v46

    .line 4190
    .line 4191
    move/from16 v47, v48

    .line 4192
    .line 4193
    move-wide/from16 v38, v66

    .line 4194
    .line 4195
    move-wide/from16 v35, v69

    .line 4196
    .line 4197
    move-object/from16 v34, v71

    .line 4198
    .line 4199
    move-object/from16 v48, v87

    .line 4200
    .line 4201
    goto :goto_106c

    .line 4202
    :cond_1069
    move-object/from16 v33, v6

    .line 4203
    .line 4204
    goto :goto_1058

    .line 4205
    :goto_106c
    invoke-direct/range {v31 .. v48}, La4/m;-><init>(Ljava/lang/String;La4/m;Ljava/lang/String;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZLjava/util/List;)V

    .line 4206
    .line 4207
    .line 4208
    move-object/from16 v4, v31

    .line 4209
    .line 4210
    move-wide/from16 v66, v38

    .line 4211
    .line 4212
    move-object/from16 v15, v83

    .line 4213
    .line 4214
    invoke-virtual {v15, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4215
    .line 4216
    .line 4217
    add-long v8, v66, v35

    .line 4218
    .line 4219
    new-instance v4, Ljava/util/ArrayList;

    .line 4220
    .line 4221
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 4222
    .line 4223
    .line 4224
    if-eqz v7, :cond_1083

    .line 4225
    .line 4226
    add-long v43, v43, v45

    .line 4227
    .line 4228
    :cond_1083
    move-wide/from16 v61, v43

    .line 4229
    .line 4230
    move-wide/from16 v57, v0

    .line 4231
    .line 4232
    move-object v7, v3

    .line 4233
    move-wide/from16 v66, v8

    .line 4234
    .line 4235
    move-object v13, v12

    .line 4236
    move/from16 v24, v14

    .line 4237
    .line 4238
    move/from16 v48, v24

    .line 4239
    .line 4240
    move/from16 v6, v37

    .line 4241
    .line 4242
    move-object/from16 v29, v40

    .line 4243
    .line 4244
    move-object/from16 v37, v41

    .line 4245
    .line 4246
    move-object/from16 v3, v49

    .line 4247
    .line 4248
    move-wide/from16 v46, v74

    .line 4249
    .line 4250
    move-wide/from16 v69, v78

    .line 4251
    .line 4252
    move-object/from16 v14, v81

    .line 4253
    .line 4254
    move-object/from16 v12, v84

    .line 4255
    .line 4256
    move-object/from16 v38, v85

    .line 4257
    .line 4258
    move-object/from16 v11, v86

    .line 4259
    .line 4260
    move-object/from16 v49, v114

    .line 4261
    .line 4262
    move-object/from16 v71, v115

    .line 4263
    .line 4264
    move-object/from16 v0, p0

    .line 4265
    .line 4266
    move-object/from16 v1, p1

    .line 4267
    .line 4268
    move-object v8, v5

    .line 4269
    move-wide/from16 v39, v66

    .line 4270
    .line 4271
    move-object v9, v15

    .line 4272
    move-object/from16 v15, v65

    .line 4273
    .line 4274
    move-object/from16 v5, v71

    .line 4275
    .line 4276
    move-object/from16 v65, v10

    .line 4277
    .line 4278
    move-object v10, v4

    .line 4279
    goto/16 :goto_9e

    .line 4280
    .line 4281
    :goto_10b8
    move-object/from16 v0, p0

    .line 4282
    .line 4283
    move-object/from16 v1, p1

    .line 4284
    .line 4285
    move-object v7, v3

    .line 4286
    move-object v13, v12

    .line 4287
    move/from16 v24, v14

    .line 4288
    .line 4289
    move-object v9, v15

    .line 4290
    move-object/from16 v71, v34

    .line 4291
    .line 4292
    move-wide/from16 v69, v35

    .line 4293
    .line 4294
    move/from16 v6, v37

    .line 4295
    .line 4296
    move-object/from16 v37, v41

    .line 4297
    .line 4298
    move/from16 v48, v47

    .line 4299
    .line 4300
    move-object/from16 v3, v49

    .line 4301
    .line 4302
    move-object/from16 v15, v65

    .line 4303
    .line 4304
    move-object/from16 v14, v81

    .line 4305
    .line 4306
    move-object/from16 v12, v84

    .line 4307
    .line 4308
    move-object/from16 v38, v85

    .line 4309
    .line 4310
    move-object/from16 v11, v86

    .line 4311
    .line 4312
    move-object/from16 v49, v114

    .line 4313
    .line 4314
    move-object/from16 v65, v10

    .line 4315
    .line 4316
    move-wide/from16 v46, v45

    .line 4317
    .line 4318
    move-object v10, v8

    .line 4319
    move-object v8, v5

    .line 4320
    goto/16 :goto_4f3

    .line 4321
    .line 4322
    :cond_10e1
    move-object v15, v9

    .line 4323
    move-object v8, v10

    .line 4324
    move-object/from16 v86, v11

    .line 4325
    .line 4326
    move-object/from16 v84, v12

    .line 4327
    .line 4328
    move-object v12, v13

    .line 4329
    move/from16 v14, v24

    .line 4330
    .line 4331
    move-object/from16 v114, v49

    .line 4332
    .line 4333
    move-object v13, v4

    .line 4334
    new-instance v0, Ljava/util/HashMap;

    .line 4335
    .line 4336
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4337
    .line 4338
    .line 4339
    move v1, v14

    .line 4340
    :goto_10f3
    invoke-virtual/range {v86 .. v86}, Ljava/util/ArrayList;->size()I

    .line 4341
    .line 4342
    .line 4343
    move-result v2

    .line 4344
    if-ge v1, v2, :cond_1147

    .line 4345
    .line 4346
    move-object/from16 v2, v86

    .line 4347
    .line 4348
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 4349
    .line 4350
    .line 4351
    move-result-object v3

    .line 4352
    check-cast v3, La4/l;

    .line 4353
    .line 4354
    iget-wide v4, v3, La4/l;->b:J

    .line 4355
    .line 4356
    cmp-long v7, v4, v74

    .line 4357
    .line 4358
    if-nez v7, :cond_1114

    .line 4359
    .line 4360
    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    .line 4361
    .line 4362
    .line 4363
    move-result v4

    .line 4364
    int-to-long v4, v4

    .line 4365
    add-long v4, v20, v4

    .line 4366
    .line 4367
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    .line 4368
    .line 4369
    .line 4370
    move-result v7

    .line 4371
    int-to-long v9, v7

    .line 4372
    sub-long/2addr v4, v9

    .line 4373
    :cond_1114
    iget v7, v3, La4/l;->c:I

    .line 4374
    .line 4375
    const/4 v9, -0x1

    .line 4376
    if-ne v7, v9, :cond_1136

    .line 4377
    .line 4378
    cmp-long v10, v25, v76

    .line 4379
    .line 4380
    if-eqz v10, :cond_1136

    .line 4381
    .line 4382
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    .line 4383
    .line 4384
    .line 4385
    move-result v7

    .line 4386
    if-eqz v7, :cond_112c

    .line 4387
    .line 4388
    invoke-static {v15}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 4389
    .line 4390
    .line 4391
    move-result-object v7

    .line 4392
    check-cast v7, La4/m;

    .line 4393
    .line 4394
    iget-object v10, v7, La4/m;->O:Lhx/m0;

    .line 4395
    .line 4396
    goto :goto_112d

    .line 4397
    :cond_112c
    move-object v10, v8

    .line 4398
    :goto_112d
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 4399
    .line 4400
    .line 4401
    move-result v7

    .line 4402
    const/16 v80, 0x1

    .line 4403
    .line 4404
    add-int/lit8 v7, v7, -0x1

    .line 4405
    .line 4406
    goto :goto_1138

    .line 4407
    :cond_1136
    const/16 v80, 0x1

    .line 4408
    .line 4409
    :goto_1138
    iget-object v3, v3, La4/l;->a:Landroid/net/Uri;

    .line 4410
    .line 4411
    new-instance v10, La4/l;

    .line 4412
    .line 4413
    invoke-direct {v10, v3, v4, v5, v7}, La4/l;-><init>(Landroid/net/Uri;JI)V

    .line 4414
    .line 4415
    .line 4416
    invoke-virtual {v0, v3, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4417
    .line 4418
    .line 4419
    add-int/lit8 v1, v1, 0x1

    .line 4420
    .line 4421
    move-object/from16 v86, v2

    .line 4422
    .line 4423
    goto :goto_10f3

    .line 4424
    :cond_1147
    const/16 v80, 0x1

    .line 4425
    .line 4426
    if-eqz v114, :cond_1150

    .line 4427
    .line 4428
    move-object/from16 v11, v114

    .line 4429
    .line 4430
    invoke-interface {v8, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4431
    .line 4432
    .line 4433
    :cond_1150
    new-instance v1, Ljava/util/ArrayList;

    .line 4434
    .line 4435
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 4436
    .line 4437
    .line 4438
    invoke-virtual {v12}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 4439
    .line 4440
    .line 4441
    move-result-object v2

    .line 4442
    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 4443
    .line 4444
    .line 4445
    move-result-object v2

    .line 4446
    :goto_115d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 4447
    .line 4448
    .line 4449
    move-result v3

    .line 4450
    if-eqz v3, :cond_120c

    .line 4451
    .line 4452
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 4453
    .line 4454
    .line 4455
    move-result-object v3

    .line 4456
    check-cast v3, La4/i;

    .line 4457
    .line 4458
    iget-object v4, v3, La4/i;->d:Landroid/net/Uri;

    .line 4459
    .line 4460
    if-nez v4, :cond_1171

    .line 4461
    .line 4462
    iget-object v5, v3, La4/i;->c:Landroid/net/Uri;

    .line 4463
    .line 4464
    if-nez v5, :cond_1177

    .line 4465
    .line 4466
    :cond_1171
    if-eqz v4, :cond_11f7

    .line 4467
    .line 4468
    iget-object v5, v3, La4/i;->c:Landroid/net/Uri;

    .line 4469
    .line 4470
    if-nez v5, :cond_11f7

    .line 4471
    .line 4472
    :cond_1177
    iget-wide v9, v3, La4/i;->e:J

    .line 4473
    .line 4474
    cmp-long v5, v9, v76

    .line 4475
    .line 4476
    if-eqz v5, :cond_11f7

    .line 4477
    .line 4478
    new-instance v85, La4/j;

    .line 4479
    .line 4480
    iget-object v5, v3, La4/i;->a:Ljava/lang/String;

    .line 4481
    .line 4482
    iget-object v7, v3, La4/i;->c:Landroid/net/Uri;

    .line 4483
    .line 4484
    iget-wide v11, v3, La4/i;->f:J

    .line 4485
    .line 4486
    move-object/from16 v31, v15

    .line 4487
    .line 4488
    iget-wide v14, v3, La4/i;->g:J

    .line 4489
    .line 4490
    move-object/from16 v88, v4

    .line 4491
    .line 4492
    move-object/from16 v86, v5

    .line 4493
    .line 4494
    iget-wide v4, v3, La4/i;->h:J

    .line 4495
    .line 4496
    move-object/from16 v34, v0

    .line 4497
    .line 4498
    iget-object v0, v3, La4/i;->i:Ljava/util/ArrayList;

    .line 4499
    .line 4500
    move-object/from16 v97, v0

    .line 4501
    .line 4502
    iget-boolean v0, v3, La4/i;->j:Z

    .line 4503
    .line 4504
    move-wide/from16 v95, v4

    .line 4505
    .line 4506
    iget-wide v4, v3, La4/i;->k:J

    .line 4507
    .line 4508
    move-wide/from16 v99, v4

    .line 4509
    .line 4510
    iget-wide v4, v3, La4/i;->l:J

    .line 4511
    .line 4512
    move/from16 v98, v0

    .line 4513
    .line 4514
    iget-object v0, v3, La4/i;->m:Ljava/util/ArrayList;

    .line 4515
    .line 4516
    move-object/from16 v103, v0

    .line 4517
    .line 4518
    iget-object v0, v3, La4/i;->n:Ljava/util/ArrayList;

    .line 4519
    .line 4520
    move-object/from16 v104, v0

    .line 4521
    .line 4522
    new-instance v0, Ljava/util/ArrayList;

    .line 4523
    .line 4524
    move-object/from16 p0, v2

    .line 4525
    .line 4526
    iget-object v2, v3, La4/i;->b:Ljava/util/HashMap;

    .line 4527
    .line 4528
    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 4529
    .line 4530
    .line 4531
    move-result-object v2

    .line 4532
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 4533
    .line 4534
    .line 4535
    iget-object v2, v3, La4/i;->o:Ljava/lang/Boolean;

    .line 4536
    .line 4537
    if-eqz v2, :cond_11c4

    .line 4538
    .line 4539
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4540
    .line 4541
    .line 4542
    move-result v2

    .line 4543
    if-eqz v2, :cond_11c1

    .line 4544
    .line 4545
    goto :goto_11c4

    .line 4546
    :cond_11c1
    const/16 v106, 0x0

    .line 4547
    .line 4548
    goto :goto_11c6

    .line 4549
    :cond_11c4
    :goto_11c4
    move/from16 v106, v80

    .line 4550
    .line 4551
    :goto_11c6
    iget-object v2, v3, La4/i;->p:Ljava/lang/String;

    .line 4552
    .line 4553
    if-eqz v2, :cond_11cd

    .line 4554
    .line 4555
    move-object/from16 v107, v2

    .line 4556
    .line 4557
    goto :goto_11cf

    .line 4558
    :cond_11cd
    move-object/from16 v107, v6

    .line 4559
    .line 4560
    :goto_11cf
    iget-object v2, v3, La4/i;->q:Ljava/lang/String;

    .line 4561
    .line 4562
    if-eqz v2, :cond_11d8

    .line 4563
    .line 4564
    move-object/from16 v108, v2

    .line 4565
    .line 4566
    :goto_11d5
    move-wide/from16 v101, v4

    .line 4567
    .line 4568
    goto :goto_11db

    .line 4569
    :cond_11d8
    move-object/from16 v108, v13

    .line 4570
    .line 4571
    goto :goto_11d5

    .line 4572
    :goto_11db
    iget-wide v4, v3, La4/i;->r:J

    .line 4573
    .line 4574
    move-wide/from16 v109, v4

    .line 4575
    .line 4576
    iget-wide v4, v3, La4/i;->s:J

    .line 4577
    .line 4578
    iget-object v2, v3, La4/i;->t:Ljava/lang/String;

    .line 4579
    .line 4580
    move-object/from16 v105, v0

    .line 4581
    .line 4582
    move-object/from16 v113, v2

    .line 4583
    .line 4584
    move-wide/from16 v111, v4

    .line 4585
    .line 4586
    move-object/from16 v87, v7

    .line 4587
    .line 4588
    move-wide/from16 v89, v9

    .line 4589
    .line 4590
    move-wide/from16 v91, v11

    .line 4591
    .line 4592
    move-wide/from16 v93, v14

    .line 4593
    .line 4594
    invoke-direct/range {v85 .. v113}, La4/j;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;JJJJLjava/util/ArrayList;ZJJLjava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;ZLjava/lang/String;Ljava/lang/String;JJLjava/lang/String;)V

    .line 4595
    .line 4596
    .line 4597
    move-object/from16 v4, v85

    .line 4598
    .line 4599
    goto :goto_11fe

    .line 4600
    :cond_11f7
    move-object/from16 v34, v0

    .line 4601
    .line 4602
    move-object/from16 p0, v2

    .line 4603
    .line 4604
    move-object/from16 v31, v15

    .line 4605
    .line 4606
    const/4 v4, 0x0

    .line 4607
    :goto_11fe
    if-eqz v4, :cond_1203

    .line 4608
    .line 4609
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4610
    .line 4611
    .line 4612
    :cond_1203
    move-object/from16 v2, p0

    .line 4613
    .line 4614
    move-object/from16 v15, v31

    .line 4615
    .line 4616
    move-object/from16 v0, v34

    .line 4617
    .line 4618
    const/4 v14, 0x0

    .line 4619
    goto/16 :goto_115d

    .line 4620
    .line 4621
    :cond_120c
    move-object/from16 v34, v0

    .line 4622
    .line 4623
    move-object/from16 v31, v15

    .line 4624
    .line 4625
    cmp-long v0, v50, v78

    .line 4626
    .line 4627
    if-nez v0, :cond_1220

    .line 4628
    .line 4629
    if-eqz p1, :cond_1220

    .line 4630
    .line 4631
    move-object/from16 v0, p1

    .line 4632
    .line 4633
    iget-boolean v2, v0, La4/p;->p:Z

    .line 4634
    .line 4635
    if-eqz v2, :cond_1220

    .line 4636
    .line 4637
    iget-wide v2, v0, La4/p;->h:J

    .line 4638
    .line 4639
    move-wide/from16 v50, v2

    .line 4640
    .line 4641
    :cond_1220
    new-instance v9, La4/p;

    .line 4642
    .line 4643
    invoke-virtual/range {p3 .. p3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 4644
    .line 4645
    .line 4646
    move-result-object v11

    .line 4647
    cmp-long v0, v50, v78

    .line 4648
    .line 4649
    if-eqz v0, :cond_1247

    .line 4650
    .line 4651
    move/from16 v29, v80

    .line 4652
    .line 4653
    :goto_122c
    move-object/from16 v35, v1

    .line 4654
    .line 4655
    move-object/from16 v32, v8

    .line 4656
    .line 4657
    move/from16 v15, v19

    .line 4658
    .line 4659
    move-object/from16 v36, v30

    .line 4660
    .line 4661
    move/from16 v10, v52

    .line 4662
    .line 4663
    move-wide/from16 v13, v53

    .line 4664
    .line 4665
    move-object/from16 v33, v81

    .line 4666
    .line 4667
    move-object/from16 v12, v84

    .line 4668
    .line 4669
    move/from16 v19, v17

    .line 4670
    .line 4671
    move-object/from16 v30, v28

    .line 4672
    .line 4673
    move-wide/from16 v16, v50

    .line 4674
    .line 4675
    move/from16 v28, v23

    .line 4676
    .line 4677
    move-wide/from16 v23, v55

    .line 4678
    .line 4679
    goto :goto_124a

    .line 4680
    :cond_1247
    const/16 v29, 0x0

    .line 4681
    .line 4682
    goto :goto_122c

    .line 4683
    :goto_124a
    invoke-direct/range {v9 .. v36}, La4/p;-><init>(ILjava/lang/String;Ljava/util/List;JZJZIJIJJZZZLk3/r;Ljava/util/List;Ljava/util/List;La4/o;Ljava/util/Map;Ljava/util/List;La4/m;)V

    .line 4684
    .line 4685
    .line 4686
    return-object v9

    :sswitch_data_124e
    .sparse-switch
        0x13683 -> :sswitch_8dd
        0x251681 -> :sswitch_8d0
        0x2590a0 -> :sswitch_8c2
    .end sparse-switch

    :pswitch_data_125c
    .packed-switch 0x0
        :pswitch_8ed
        :pswitch_8ed
        :pswitch_8ed
    .end packed-switch

    :sswitch_data_1266
    .sparse-switch
        -0x7f5b7c02 -> :sswitch_b11
        -0x6ddab8e6 -> :sswitch_b06
        -0x8e0f436 -> :sswitch_afa
        -0x22a979d -> :sswitch_aef
        0x17ad642d -> :sswitch_ae4
        0x32acec39 -> :sswitch_ad9
        0x3f8488e0 -> :sswitch_ace
        0x4bf74f81 -> :sswitch_ac3
        0x57c501cc -> :sswitch_ab5
        0x6837ce7f -> :sswitch_aa7
        0x6c2295e3 -> :sswitch_a99
        0x7c029fc0 -> :sswitch_a8b
    .end sparse-switch

    :pswitch_data_1298
    .packed-switch 0x0
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
        :pswitch_bda
    .end packed-switch
.end method

.method public static e(La4/v;Landroid/net/Uri;La4/w;)La4/s;
    .registers 54

    .line 1
    move-object/from16 v0, p2

    .line 2
    .line 3
    invoke-virtual/range {p1 .. p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    new-instance v2, Ljava/util/HashMap;

    .line 8
    .line 9
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 10
    .line 11
    .line 12
    new-instance v14, Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-direct {v14}, Ljava/util/HashMap;-><init>()V

    .line 15
    .line 16
    .line 17
    new-instance v3, Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 20
    .line 21
    .line 22
    new-instance v7, Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 25
    .line 26
    .line 27
    new-instance v8, Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 30
    .line 31
    .line 32
    new-instance v9, Ljava/util/ArrayList;

    .line 33
    .line 34
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 35
    .line 36
    .line 37
    new-instance v10, Ljava/util/ArrayList;

    .line 38
    .line 39
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 40
    .line 41
    .line 42
    new-instance v4, Ljava/util/ArrayList;

    .line 43
    .line 44
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 45
    .line 46
    .line 47
    new-instance v15, Ljava/util/ArrayList;

    .line 48
    .line 49
    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    .line 50
    .line 51
    .line 52
    new-instance v5, Ljava/util/ArrayList;

    .line 53
    .line 54
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 55
    .line 56
    .line 57
    const/4 v12, 0x0

    .line 58
    const/4 v13, 0x0

    .line 59
    const/16 v16, 0x0

    .line 60
    .line 61
    :goto_3c
    invoke-virtual/range {p0 .. p0}, La4/v;->a()Z

    .line 62
    .line 63
    .line 64
    move-result v17

    .line 65
    const-string v18, "application/x-mpegURL"

    .line 66
    .line 67
    const/16 v19, 0x0

    .line 68
    .line 69
    sget-object v11, La4/x;->v0:Ljava/util/regex/Pattern;

    .line 70
    .line 71
    const-string v6, "/"

    .line 72
    .line 73
    move-object/from16 v22, v10

    .line 74
    .line 75
    sget-object v10, La4/x;->A0:Ljava/util/regex/Pattern;

    .line 76
    .line 77
    move/from16 v23, v12

    .line 78
    .line 79
    const-string v12, ","

    .line 80
    .line 81
    move/from16 v24, v13

    .line 82
    .line 83
    if-eqz v17, :cond_3e1

    .line 84
    .line 85
    invoke-virtual/range {p0 .. p0}, La4/v;->b()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v13

    .line 89
    move-object/from16 v25, v9

    .line 90
    .line 91
    const-string v9, "#EXT"

    .line 92
    .line 93
    invoke-virtual {v13, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 94
    .line 95
    .line 96
    move-result v9

    .line 97
    if-eqz v9, :cond_65

    .line 98
    .line 99
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    :cond_65
    const-string v9, "#EXT-X-I-FRAME-STREAM-INF"

    .line 103
    .line 104
    invoke-virtual {v13, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 105
    .line 106
    .line 107
    move-result v9

    .line 108
    move-object/from16 v26, v5

    .line 109
    .line 110
    const-string v5, "#EXT-X-DEFINE"

    .line 111
    .line 112
    invoke-virtual {v13, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    if-eqz v5, :cond_ba

    .line 117
    .line 118
    const/4 v5, 0x0

    .line 119
    invoke-static {v13, v10, v5, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v6

    .line 123
    if-eqz v6, :cond_8c

    .line 124
    .line 125
    invoke-static {v6, v14}, La4/x;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 126
    .line 127
    .line 128
    sget-object v5, La4/x;->L0:Ljava/util/regex/Pattern;

    .line 129
    .line 130
    invoke-static {v13, v5, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v5

    .line 134
    invoke-virtual {v14, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-object/from16 v10, p1

    .line 138
    .line 139
    goto/16 :goto_16a

    .line 140
    .line 141
    :cond_8c
    sget-object v5, La4/x;->B0:Ljava/util/regex/Pattern;

    .line 142
    .line 143
    invoke-static {v13, v5, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v5

    .line 147
    invoke-static {v5, v14}, La4/x;->n(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 148
    .line 149
    .line 150
    move-object/from16 v10, p1

    .line 151
    .line 152
    invoke-virtual {v10, v5}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v6

    .line 156
    if-eqz v6, :cond_a2

    .line 157
    .line 158
    invoke-virtual {v14, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    goto/16 :goto_16a

    .line 162
    .line 163
    :cond_a2
    new-instance v0, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    const-string v1, "QUERYPARAM \""

    .line 166
    .line 167
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    const-string v1, "\" not found in playlist URI"

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    invoke-static {v0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    throw v0

    .line 187
    :cond_ba
    move-object/from16 v10, p1

    .line 188
    .line 189
    const-string v5, "#EXT-X-INDEPENDENT-SEGMENTS"

    .line 190
    .line 191
    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v5

    .line 195
    if-eqz v5, :cond_d4

    .line 196
    .line 197
    move-object v12, v3

    .line 198
    move-object v3, v2

    .line 199
    move-object v2, v12

    .line 200
    move-object/from16 v38, v4

    .line 201
    .line 202
    move-object/from16 v37, v7

    .line 203
    .line 204
    move-object/from16 v36, v8

    .line 205
    .line 206
    move-object/from16 v28, v15

    .line 207
    .line 208
    move/from16 v12, v23

    .line 209
    .line 210
    const/4 v13, 0x1

    .line 211
    goto/16 :goto_3c7

    .line 212
    .line 213
    :cond_d4
    const-string v5, "#EXT-X-MEDIA"

    .line 214
    .line 215
    invoke-virtual {v13, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 216
    .line 217
    .line 218
    move-result v5

    .line 219
    if-eqz v5, :cond_e1

    .line 220
    .line 221
    invoke-virtual {v4, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    goto/16 :goto_16a

    .line 225
    .line 226
    :cond_e1
    const-string v5, "#EXT-X-SESSION-KEY"

    .line 227
    .line 228
    invoke-virtual {v13, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 229
    .line 230
    .line 231
    move-result v5

    .line 232
    if-eqz v5, :cond_121

    .line 233
    .line 234
    sget-object v5, La4/x;->t0:Ljava/util/regex/Pattern;

    .line 235
    .line 236
    const-string v6, "identity"

    .line 237
    .line 238
    invoke-static {v13, v5, v6, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v5

    .line 242
    invoke-static {v13, v5, v14, v0}, La4/x;->c(Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;La4/w;)Lk3/q;

    .line 243
    .line 244
    .line 245
    move-result-object v5

    .line 246
    if-eqz v5, :cond_16a

    .line 247
    .line 248
    sget-object v6, La4/x;->s0:Ljava/util/regex/Pattern;

    .line 249
    .line 250
    invoke-static {v13, v6, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v6

    .line 254
    const-string v9, "SAMPLE-AES-CENC"

    .line 255
    .line 256
    invoke-virtual {v9, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-result v9

    .line 260
    if-nez v9, :cond_111

    .line 261
    .line 262
    const-string v9, "SAMPLE-AES-CTR"

    .line 263
    .line 264
    invoke-virtual {v9, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 265
    .line 266
    .line 267
    move-result v6

    .line 268
    if-eqz v6, :cond_10e

    .line 269
    .line 270
    goto :goto_111

    .line 271
    :cond_10e
    const-string v6, "cbcs"

    .line 272
    .line 273
    goto :goto_113

    .line 274
    :cond_111
    :goto_111
    const-string v6, "cenc"

    .line 275
    .line 276
    :goto_113
    new-instance v9, Lk3/r;

    .line 277
    .line 278
    filled-new-array {v5}, [Lk3/q;

    .line 279
    .line 280
    .line 281
    move-result-object v5

    .line 282
    const/4 v11, 0x1

    .line 283
    invoke-direct {v9, v6, v11, v5}, Lk3/r;-><init>(Ljava/lang/String;Z[Lk3/q;)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v15, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    goto :goto_16a

    .line 290
    :cond_121
    const-string v5, "#EXT-X-CONTENT-STEERING"

    .line 291
    .line 292
    invoke-virtual {v13, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 293
    .line 294
    .line 295
    move-result v5

    .line 296
    move/from16 v27, v5

    .line 297
    .line 298
    sget-object v5, La4/x;->T:Ljava/util/regex/Pattern;

    .line 299
    .line 300
    if-eqz v27, :cond_15d

    .line 301
    .line 302
    if-nez v16, :cond_156

    .line 303
    .line 304
    sget-object v6, La4/x;->S:Ljava/util/regex/Pattern;

    .line 305
    .line 306
    invoke-static {v13, v6, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 307
    .line 308
    .line 309
    move-result-object v6

    .line 310
    invoke-static {v1, v6}, Ln3/e;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 311
    .line 312
    .line 313
    move-result-object v6

    .line 314
    const/4 v9, 0x0

    .line 315
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object v5

    .line 319
    new-instance v9, Lk7/l;

    .line 320
    .line 321
    invoke-direct {v9, v6, v5}, Lk7/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 322
    .line 323
    .line 324
    move-object v12, v3

    .line 325
    move-object v3, v2

    .line 326
    move-object v2, v12

    .line 327
    move-object/from16 v38, v4

    .line 328
    .line 329
    move-object/from16 v37, v7

    .line 330
    .line 331
    move-object/from16 v36, v8

    .line 332
    .line 333
    move-object/from16 v16, v9

    .line 334
    .line 335
    :goto_14e
    move-object/from16 v28, v15

    .line 336
    .line 337
    :goto_150
    move/from16 v12, v23

    .line 338
    .line 339
    move/from16 v13, v24

    .line 340
    .line 341
    goto/16 :goto_3c7

    .line 342
    .line 343
    :cond_156
    const-string v0, "The #EXT-X-CONTENT-STEERING tag must not appear more than once in a multivariant playlist"

    .line 344
    .line 345
    invoke-static {v0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    throw v0

    .line 350
    :cond_15d
    move/from16 v27, v9

    .line 351
    .line 352
    const-string v9, "#EXT-X-STREAM-INF"

    .line 353
    .line 354
    invoke-virtual {v13, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 355
    .line 356
    .line 357
    move-result v9

    .line 358
    if-nez v9, :cond_174

    .line 359
    .line 360
    if-eqz v27, :cond_16a

    .line 361
    .line 362
    goto :goto_174

    .line 363
    :cond_16a
    :goto_16a
    move-object v12, v3

    .line 364
    move-object v3, v2

    .line 365
    move-object v2, v12

    .line 366
    move-object/from16 v38, v4

    .line 367
    .line 368
    move-object/from16 v37, v7

    .line 369
    .line 370
    move-object/from16 v36, v8

    .line 371
    .line 372
    goto :goto_14e

    .line 373
    :cond_174
    :goto_174
    const-string v9, "CLOSED-CAPTIONS=NONE"

    .line 374
    .line 375
    invoke-virtual {v13, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 376
    .line 377
    .line 378
    move-result v9

    .line 379
    or-int v9, v23, v9

    .line 380
    .line 381
    if-eqz v27, :cond_187

    .line 382
    .line 383
    const/16 v23, 0x4000

    .line 384
    .line 385
    move/from16 v50, v23

    .line 386
    .line 387
    move/from16 v23, v9

    .line 388
    .line 389
    move/from16 v9, v50

    .line 390
    .line 391
    goto :goto_18b

    .line 392
    :cond_187
    move/from16 v23, v9

    .line 393
    .line 394
    move/from16 v9, v19

    .line 395
    .line 396
    :goto_18b
    sget-object v10, La4/x;->J:Ljava/util/regex/Pattern;

    .line 397
    .line 398
    move-object/from16 v28, v15

    .line 399
    .line 400
    sget-object v15, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 401
    .line 402
    invoke-static {v13, v10, v15, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 403
    .line 404
    .line 405
    move-result-object v10

    .line 406
    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 407
    .line 408
    .line 409
    move-result v10

    .line 410
    sget-object v15, La4/x;->i:Ljava/util/regex/Pattern;

    .line 411
    .line 412
    invoke-static {v0, v13, v15}, La4/x;->i(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)I

    .line 413
    .line 414
    .line 415
    move-result v15

    .line 416
    move-object/from16 v36, v8

    .line 417
    .line 418
    sget-object v8, La4/x;->M:Ljava/util/regex/Pattern;

    .line 419
    .line 420
    move-object/from16 v37, v7

    .line 421
    .line 422
    const/4 v7, 0x0

    .line 423
    invoke-static {v13, v8, v7, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 424
    .line 425
    .line 426
    move-result-object v8

    .line 427
    move-object/from16 v38, v4

    .line 428
    .line 429
    sget-object v4, La4/x;->N:Ljava/util/regex/Pattern;

    .line 430
    .line 431
    invoke-static {v13, v4, v7, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 432
    .line 433
    .line 434
    move-result-object v4

    .line 435
    move-object/from16 v39, v2

    .line 436
    .line 437
    sget-object v2, La4/x;->O:Ljava/util/regex/Pattern;

    .line 438
    .line 439
    invoke-static {v13, v2, v7, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 440
    .line 441
    .line 442
    move-result-object v2

    .line 443
    if-eqz v2, :cond_1dd

    .line 444
    .line 445
    sget-object v7, Ln3/l0;->a:Ljava/lang/String;

    .line 446
    .line 447
    const/4 v7, 0x2

    .line 448
    invoke-virtual {v2, v12, v7}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object v2

    .line 452
    aget-object v2, v2, v19

    .line 453
    .line 454
    const/4 v7, -0x1

    .line 455
    invoke-virtual {v2, v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    move-result-object v2

    .line 459
    aget-object v6, v2, v19

    .line 460
    .line 461
    array-length v7, v2

    .line 462
    move-object/from16 v29, v2

    .line 463
    .line 464
    const/4 v2, 0x1

    .line 465
    if-le v7, v2, :cond_1d8

    .line 466
    .line 467
    aget-object v7, v29, v2

    .line 468
    .line 469
    move-object/from16 v40, v3

    .line 470
    .line 471
    const/4 v2, 0x2

    .line 472
    goto :goto_1e2

    .line 473
    :cond_1d8
    move-object/from16 v40, v3

    .line 474
    .line 475
    const/4 v2, 0x2

    .line 476
    :goto_1db
    const/4 v7, 0x0

    .line 477
    goto :goto_1e2

    .line 478
    :cond_1dd
    move-object/from16 v40, v3

    .line 479
    .line 480
    const/4 v2, 0x2

    .line 481
    const/4 v6, 0x0

    .line 482
    goto :goto_1db

    .line 483
    :goto_1e2
    invoke-static {v2, v4}, Ln3/l0;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 484
    .line 485
    .line 486
    move-result-object v3

    .line 487
    invoke-static {v3, v6}, Lk3/u0;->j(Ljava/lang/String;Ljava/lang/String;)Z

    .line 488
    .line 489
    .line 490
    move-result v2

    .line 491
    if-nez v2, :cond_1f0

    .line 492
    .line 493
    :cond_1ec
    :goto_1ec
    move/from16 v30, v9

    .line 494
    .line 495
    goto/16 :goto_2da

    .line 496
    .line 497
    :cond_1f0
    const-string v2, "db4"

    .line 498
    .line 499
    move-object/from16 v29, v3

    .line 500
    .line 501
    const-string v3, "db1p"

    .line 502
    .line 503
    if-nez v6, :cond_1fb

    .line 504
    .line 505
    move/from16 v30, v9

    .line 506
    .line 507
    goto :goto_230

    .line 508
    :cond_1fb
    if-eqz v8, :cond_1ec

    .line 509
    .line 510
    if-nez v7, :cond_200

    .line 511
    .line 512
    goto :goto_1ec

    .line 513
    :cond_200
    move/from16 v30, v9

    .line 514
    .line 515
    const-string v9, "PQ"

    .line 516
    .line 517
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 518
    .line 519
    .line 520
    move-result v9

    .line 521
    if-eqz v9, :cond_210

    .line 522
    .line 523
    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 524
    .line 525
    .line 526
    move-result v9

    .line 527
    if-eqz v9, :cond_2da

    .line 528
    .line 529
    :cond_210
    const-string v9, "SDR"

    .line 530
    .line 531
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 532
    .line 533
    .line 534
    move-result v9

    .line 535
    if-eqz v9, :cond_220

    .line 536
    .line 537
    const-string v9, "db2g"

    .line 538
    .line 539
    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 540
    .line 541
    .line 542
    move-result v9

    .line 543
    if-eqz v9, :cond_2da

    .line 544
    .line 545
    :cond_220
    const-string v9, "HLG"

    .line 546
    .line 547
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 548
    .line 549
    .line 550
    move-result v8

    .line 551
    if-eqz v8, :cond_230

    .line 552
    .line 553
    invoke-virtual {v7, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 554
    .line 555
    .line 556
    move-result v8

    .line 557
    if-nez v8, :cond_230

    .line 558
    .line 559
    goto/16 :goto_2da

    .line 560
    .line 561
    :cond_230
    :goto_230
    if-nez v4, :cond_235

    .line 562
    .line 563
    :goto_232
    const/16 v41, 0x0

    .line 564
    .line 565
    goto :goto_28c

    .line 566
    :cond_235
    invoke-static {v4, v6}, Lk3/u0;->j(Ljava/lang/String;Ljava/lang/String;)Z

    .line 567
    .line 568
    .line 569
    move-result v8

    .line 570
    if-nez v8, :cond_23c

    .line 571
    .line 572
    goto :goto_232

    .line 573
    :cond_23c
    const-string v8, "dvhe"

    .line 574
    .line 575
    invoke-virtual {v4, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 576
    .line 577
    .line 578
    move-result v8

    .line 579
    const/4 v9, 0x6

    .line 580
    if-nez v8, :cond_277

    .line 581
    .line 582
    const-string v8, "dvh1"

    .line 583
    .line 584
    invoke-virtual {v4, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 585
    .line 586
    .line 587
    move-result v8

    .line 588
    if-nez v8, :cond_277

    .line 589
    .line 590
    const-string v8, "dav1"

    .line 591
    .line 592
    invoke-virtual {v4, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 593
    .line 594
    .line 595
    move-result v8

    .line 596
    if-eqz v8, :cond_256

    .line 597
    .line 598
    goto :goto_277

    .line 599
    :cond_256
    if-eqz v7, :cond_270

    .line 600
    .line 601
    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 602
    .line 603
    .line 604
    move-result v3

    .line 605
    if-eqz v3, :cond_264

    .line 606
    .line 607
    move/from16 v44, v9

    .line 608
    .line 609
    const/4 v7, -0x1

    .line 610
    const/16 v43, 0x2

    .line 611
    .line 612
    goto :goto_27c

    .line 613
    :cond_264
    invoke-virtual {v7, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 614
    .line 615
    .line 616
    move-result v2

    .line 617
    if-eqz v2, :cond_270

    .line 618
    .line 619
    const/4 v7, -0x1

    .line 620
    const/16 v43, 0x2

    .line 621
    .line 622
    const/16 v44, 0x7

    .line 623
    .line 624
    goto :goto_27c

    .line 625
    :cond_270
    const/4 v7, -0x1

    .line 626
    const/4 v9, -0x1

    .line 627
    const/16 v43, -0x1

    .line 628
    .line 629
    const/16 v44, -0x1

    .line 630
    .line 631
    goto :goto_27c

    .line 632
    :cond_277
    :goto_277
    move/from16 v44, v9

    .line 633
    .line 634
    const/4 v7, -0x1

    .line 635
    const/16 v43, 0x1

    .line 636
    .line 637
    :goto_27c
    if-ne v9, v7, :cond_27f

    .line 638
    .line 639
    goto :goto_232

    .line 640
    :cond_27f
    new-instance v41, Lk3/m;

    .line 641
    .line 642
    const/16 v45, 0x0

    .line 643
    .line 644
    const/16 v46, -0x1

    .line 645
    .line 646
    move/from16 v47, v46

    .line 647
    .line 648
    move/from16 v42, v9

    .line 649
    .line 650
    invoke-direct/range {v41 .. v47}, Lk3/m;-><init>(III[BII)V

    .line 651
    .line 652
    .line 653
    :goto_28c
    if-eqz v6, :cond_28f

    .line 654
    .line 655
    goto :goto_291

    .line 656
    :cond_28f
    move-object/from16 v6, v29

    .line 657
    .line 658
    :goto_291
    invoke-static {v4}, Ln3/l0;->d0(Ljava/lang/String;)[Ljava/lang/String;

    .line 659
    .line 660
    .line 661
    move-result-object v2

    .line 662
    array-length v3, v2

    .line 663
    if-nez v3, :cond_29a

    .line 664
    .line 665
    :cond_298
    const/4 v2, 0x0

    .line 666
    goto :goto_2ce

    .line 667
    :cond_29a
    new-instance v3, Ljava/lang/StringBuilder;

    .line 668
    .line 669
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 670
    .line 671
    .line 672
    array-length v4, v2

    .line 673
    move/from16 v7, v19

    .line 674
    .line 675
    :goto_2a2
    if-ge v7, v4, :cond_2c4

    .line 676
    .line 677
    aget-object v8, v2, v7

    .line 678
    .line 679
    invoke-static {v8}, Lk3/u0;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 680
    .line 681
    .line 682
    move-result-object v9

    .line 683
    invoke-static {v9}, Lk3/u0;->h(Ljava/lang/String;)I

    .line 684
    .line 685
    .line 686
    move-result v9

    .line 687
    move-object/from16 v21, v2

    .line 688
    .line 689
    const/4 v2, 0x2

    .line 690
    if-eq v2, v9, :cond_2bf

    .line 691
    .line 692
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    .line 693
    .line 694
    .line 695
    move-result v2

    .line 696
    if-lez v2, :cond_2bc

    .line 697
    .line 698
    invoke-virtual {v3, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 699
    .line 700
    .line 701
    :cond_2bc
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 702
    .line 703
    .line 704
    :cond_2bf
    add-int/lit8 v7, v7, 0x1

    .line 705
    .line 706
    move-object/from16 v2, v21

    .line 707
    .line 708
    goto :goto_2a2

    .line 709
    :cond_2c4
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    .line 710
    .line 711
    .line 712
    move-result v2

    .line 713
    if-lez v2, :cond_298

    .line 714
    .line 715
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 716
    .line 717
    .line 718
    move-result-object v2

    .line 719
    :goto_2ce
    if-eqz v2, :cond_2d6

    .line 720
    .line 721
    invoke-static {v6, v12, v2}, Lp/x2;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 722
    .line 723
    .line 724
    move-result-object v2

    .line 725
    move-object v4, v2

    .line 726
    goto :goto_2d7

    .line 727
    :cond_2d6
    move-object v4, v6

    .line 728
    :goto_2d7
    move-object/from16 v2, v41

    .line 729
    .line 730
    goto :goto_2db

    .line 731
    :cond_2da
    :goto_2da
    const/4 v2, 0x0

    .line 732
    :goto_2db
    sget-object v3, La4/x;->P:Ljava/util/regex/Pattern;

    .line 733
    .line 734
    const/4 v7, 0x0

    .line 735
    invoke-static {v13, v3, v7, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 736
    .line 737
    .line 738
    move-result-object v3

    .line 739
    if-eqz v3, :cond_2fd

    .line 740
    .line 741
    const-string v6, "x"

    .line 742
    .line 743
    const/4 v7, -0x1

    .line 744
    invoke-virtual {v3, v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 745
    .line 746
    .line 747
    move-result-object v3

    .line 748
    aget-object v6, v3, v19

    .line 749
    .line 750
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 751
    .line 752
    .line 753
    move-result v6

    .line 754
    const/16 v17, 0x1

    .line 755
    .line 756
    aget-object v3, v3, v17

    .line 757
    .line 758
    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 759
    .line 760
    .line 761
    move-result v3

    .line 762
    if-lez v6, :cond_2fd

    .line 763
    .line 764
    if-gtz v3, :cond_2ff

    .line 765
    .line 766
    :cond_2fd
    const/4 v3, -0x1

    .line 767
    const/4 v6, -0x1

    .line 768
    :cond_2ff
    sget-object v7, La4/x;->Q:Ljava/util/regex/Pattern;

    .line 769
    .line 770
    const/4 v9, 0x0

    .line 771
    invoke-static {v13, v7, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 772
    .line 773
    .line 774
    move-result-object v7

    .line 775
    const/high16 v8, -0x40800000    # -1.0f

    .line 776
    .line 777
    if-eqz v7, :cond_30f

    .line 778
    .line 779
    invoke-static {v7}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 780
    .line 781
    .line 782
    move-result v7

    .line 783
    goto :goto_310

    .line 784
    :cond_30f
    move v7, v8

    .line 785
    :goto_310
    sget-object v12, La4/x;->R:Ljava/util/regex/Pattern;

    .line 786
    .line 787
    invoke-static {v13, v12, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 788
    .line 789
    .line 790
    move-result-object v12

    .line 791
    if-eqz v12, :cond_31c

    .line 792
    .line 793
    invoke-static {v12}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 794
    .line 795
    .line 796
    move-result v8

    .line 797
    :cond_31c
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 798
    .line 799
    .line 800
    move-result-object v48

    .line 801
    sget-object v5, La4/x;->v:Ljava/util/regex/Pattern;

    .line 802
    .line 803
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 804
    .line 805
    .line 806
    move-result-object v44

    .line 807
    sget-object v5, La4/x;->w:Ljava/util/regex/Pattern;

    .line 808
    .line 809
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 810
    .line 811
    .line 812
    move-result-object v45

    .line 813
    sget-object v5, La4/x;->x:Ljava/util/regex/Pattern;

    .line 814
    .line 815
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 816
    .line 817
    .line 818
    move-result-object v46

    .line 819
    sget-object v5, La4/x;->y:Ljava/util/regex/Pattern;

    .line 820
    .line 821
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 822
    .line 823
    .line 824
    move-result-object v47

    .line 825
    sget-object v5, La4/x;->U:Ljava/util/regex/Pattern;

    .line 826
    .line 827
    invoke-static {v13, v5, v9, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 828
    .line 829
    .line 830
    move-result-object v49

    .line 831
    if-eqz v27, :cond_34b

    .line 832
    .line 833
    invoke-static {v13, v11, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 834
    .line 835
    .line 836
    move-result-object v5

    .line 837
    invoke-static {v1, v5}, Ln3/e;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 838
    .line 839
    .line 840
    move-result-object v5

    .line 841
    :goto_348
    move-object/from16 v42, v5

    .line 842
    .line 843
    goto :goto_35e

    .line 844
    :cond_34b
    invoke-virtual/range {p0 .. p0}, La4/v;->a()Z

    .line 845
    .line 846
    .line 847
    move-result v5

    .line 848
    if-eqz v5, :cond_3da

    .line 849
    .line 850
    invoke-virtual/range {p0 .. p0}, La4/v;->b()Ljava/lang/String;

    .line 851
    .line 852
    .line 853
    move-result-object v5

    .line 854
    invoke-static {v5, v14, v0}, La4/x;->m(Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 855
    .line 856
    .line 857
    move-result-object v5

    .line 858
    invoke-static {v1, v5}, Ln3/e;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 859
    .line 860
    .line 861
    move-result-object v5

    .line 862
    goto :goto_348

    .line 863
    :goto_35e
    new-instance v5, Lk3/v;

    .line 864
    .line 865
    invoke-direct {v5}, Lk3/v;-><init>()V

    .line 866
    .line 867
    .line 868
    invoke-virtual/range {v40 .. v40}, Ljava/util/ArrayList;->size()I

    .line 869
    .line 870
    .line 871
    move-result v9

    .line 872
    invoke-static {v9}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 873
    .line 874
    .line 875
    move-result-object v9

    .line 876
    iput-object v9, v5, Lk3/v;->a:Ljava/lang/String;

    .line 877
    .line 878
    invoke-static/range {v18 .. v18}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 879
    .line 880
    .line 881
    move-result-object v9

    .line 882
    iput-object v9, v5, Lk3/v;->n:Ljava/lang/String;

    .line 883
    .line 884
    iput-object v4, v5, Lk3/v;->k:Ljava/lang/String;

    .line 885
    .line 886
    iput v15, v5, Lk3/v;->i:I

    .line 887
    .line 888
    iput v10, v5, Lk3/v;->j:I

    .line 889
    .line 890
    iput v6, v5, Lk3/v;->v:I

    .line 891
    .line 892
    iput v3, v5, Lk3/v;->w:I

    .line 893
    .line 894
    invoke-virtual {v5, v7}, Lk3/v;->b(F)V

    .line 895
    .line 896
    .line 897
    iput v8, v5, Lk3/v;->g:F

    .line 898
    .line 899
    move/from16 v3, v30

    .line 900
    .line 901
    iput v3, v5, Lk3/v;->f:I

    .line 902
    .line 903
    iput-object v2, v5, Lk3/v;->G:Lk3/m;

    .line 904
    .line 905
    new-instance v2, Lk3/w;

    .line 906
    .line 907
    invoke-direct {v2, v5}, Lk3/w;-><init>(Lk3/v;)V

    .line 908
    .line 909
    .line 910
    new-instance v41, La4/r;

    .line 911
    .line 912
    move-object/from16 v43, v2

    .line 913
    .line 914
    invoke-direct/range {v41 .. v49}, La4/r;-><init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 915
    .line 916
    .line 917
    move-object/from16 v2, v40

    .line 918
    .line 919
    move-object/from16 v3, v41

    .line 920
    .line 921
    move-object/from16 v5, v42

    .line 922
    .line 923
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 924
    .line 925
    .line 926
    move-object/from16 v3, v39

    .line 927
    .line 928
    invoke-virtual {v3, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 929
    .line 930
    .line 931
    move-result-object v4

    .line 932
    check-cast v4, Ljava/util/ArrayList;

    .line 933
    .line 934
    if-nez v4, :cond_3af

    .line 935
    .line 936
    new-instance v4, Ljava/util/ArrayList;

    .line 937
    .line 938
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 939
    .line 940
    .line 941
    invoke-virtual {v3, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 942
    .line 943
    .line 944
    :cond_3af
    new-instance v29, Lz3/p;

    .line 945
    .line 946
    move/from16 v31, v10

    .line 947
    .line 948
    move/from16 v30, v15

    .line 949
    .line 950
    move-object/from16 v32, v44

    .line 951
    .line 952
    move-object/from16 v33, v45

    .line 953
    .line 954
    move-object/from16 v34, v46

    .line 955
    .line 956
    move-object/from16 v35, v47

    .line 957
    .line 958
    invoke-direct/range {v29 .. v35}, Lz3/p;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 959
    .line 960
    .line 961
    move-object/from16 v5, v29

    .line 962
    .line 963
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 964
    .line 965
    .line 966
    goto/16 :goto_150

    .line 967
    .line 968
    :goto_3c7
    move-object v4, v3

    .line 969
    move-object v3, v2

    .line 970
    move-object v2, v4

    .line 971
    move-object/from16 v10, v22

    .line 972
    .line 973
    move-object/from16 v9, v25

    .line 974
    .line 975
    move-object/from16 v5, v26

    .line 976
    .line 977
    move-object/from16 v15, v28

    .line 978
    .line 979
    move-object/from16 v8, v36

    .line 980
    .line 981
    move-object/from16 v7, v37

    .line 982
    .line 983
    move-object/from16 v4, v38

    .line 984
    .line 985
    goto/16 :goto_3c

    .line 986
    .line 987
    :cond_3da
    const-string v0, "#EXT-X-STREAM-INF must be followed by another line"

    .line 988
    .line 989
    invoke-static {v0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 990
    .line 991
    .line 992
    move-result-object v0

    .line 993
    throw v0

    .line 994
    :cond_3e1
    move-object/from16 v25, v3

    .line 995
    .line 996
    move-object v3, v2

    .line 997
    move-object/from16 v2, v25

    .line 998
    .line 999
    move-object/from16 v38, v4

    .line 1000
    .line 1001
    move-object/from16 v26, v5

    .line 1002
    .line 1003
    move-object/from16 v37, v7

    .line 1004
    .line 1005
    move-object/from16 v36, v8

    .line 1006
    .line 1007
    move-object/from16 v25, v9

    .line 1008
    .line 1009
    move-object/from16 v28, v15

    .line 1010
    .line 1011
    new-instance v4, Ljava/util/ArrayList;

    .line 1012
    .line 1013
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 1014
    .line 1015
    .line 1016
    new-instance v5, Ljava/util/HashSet;

    .line 1017
    .line 1018
    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    .line 1019
    .line 1020
    .line 1021
    move/from16 v7, v19

    .line 1022
    .line 1023
    :goto_3fe
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1024
    .line 1025
    .line 1026
    move-result v8

    .line 1027
    if-ge v7, v8, :cond_47d

    .line 1028
    .line 1029
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1030
    .line 1031
    .line 1032
    move-result-object v8

    .line 1033
    check-cast v8, La4/r;

    .line 1034
    .line 1035
    iget-object v9, v8, La4/r;->a:Landroid/net/Uri;

    .line 1036
    .line 1037
    iget-object v13, v8, La4/r;->b:Lk3/w;

    .line 1038
    .line 1039
    invoke-virtual {v5, v9}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1040
    .line 1041
    .line 1042
    move-result v9

    .line 1043
    if-eqz v9, :cond_472

    .line 1044
    .line 1045
    iget-object v9, v13, Lk3/w;->m:Lk3/t0;

    .line 1046
    .line 1047
    if-nez v9, :cond_41a

    .line 1048
    .line 1049
    const/4 v9, 0x1

    .line 1050
    goto :goto_41c

    .line 1051
    :cond_41a
    move/from16 v9, v19

    .line 1052
    .line 1053
    :goto_41c
    invoke-static {v9}, Loq/a;->z(Z)V

    .line 1054
    .line 1055
    .line 1056
    new-instance v9, Lz3/q;

    .line 1057
    .line 1058
    iget-object v15, v8, La4/r;->a:Landroid/net/Uri;

    .line 1059
    .line 1060
    invoke-virtual {v3, v15}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1061
    .line 1062
    .line 1063
    move-result-object v15

    .line 1064
    check-cast v15, Ljava/util/ArrayList;

    .line 1065
    .line 1066
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1067
    .line 1068
    .line 1069
    move-object/from16 v39, v3

    .line 1070
    .line 1071
    const/4 v3, 0x0

    .line 1072
    invoke-direct {v9, v3, v3, v15}, Lz3/q;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 1073
    .line 1074
    .line 1075
    new-instance v3, Lk3/t0;

    .line 1076
    .line 1077
    move-object/from16 p0, v5

    .line 1078
    .line 1079
    const/4 v15, 0x1

    .line 1080
    new-array v5, v15, [Lk3/s0;

    .line 1081
    .line 1082
    aput-object v9, v5, v19

    .line 1083
    .line 1084
    invoke-direct {v3, v5}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 1085
    .line 1086
    .line 1087
    invoke-virtual {v13}, Lk3/w;->a()Lk3/v;

    .line 1088
    .line 1089
    .line 1090
    move-result-object v5

    .line 1091
    iput-object v3, v5, Lk3/v;->l:Lk3/t0;

    .line 1092
    .line 1093
    new-instance v3, Lk3/w;

    .line 1094
    .line 1095
    invoke-direct {v3, v5}, Lk3/w;-><init>(Lk3/v;)V

    .line 1096
    .line 1097
    .line 1098
    new-instance v40, La4/r;

    .line 1099
    .line 1100
    iget-object v5, v8, La4/r;->a:Landroid/net/Uri;

    .line 1101
    .line 1102
    iget-object v9, v8, La4/r;->c:Ljava/lang/String;

    .line 1103
    .line 1104
    iget-object v13, v8, La4/r;->d:Ljava/lang/String;

    .line 1105
    .line 1106
    iget-object v15, v8, La4/r;->e:Ljava/lang/String;

    .line 1107
    .line 1108
    move-object/from16 v42, v3

    .line 1109
    .line 1110
    iget-object v3, v8, La4/r;->f:Ljava/lang/String;

    .line 1111
    .line 1112
    move-object/from16 v46, v3

    .line 1113
    .line 1114
    iget-object v3, v8, La4/r;->g:Ljava/lang/String;

    .line 1115
    .line 1116
    iget-object v8, v8, La4/r;->h:Ljava/lang/String;

    .line 1117
    .line 1118
    move-object/from16 v47, v3

    .line 1119
    .line 1120
    move-object/from16 v41, v5

    .line 1121
    .line 1122
    move-object/from16 v48, v8

    .line 1123
    .line 1124
    move-object/from16 v43, v9

    .line 1125
    .line 1126
    move-object/from16 v44, v13

    .line 1127
    .line 1128
    move-object/from16 v45, v15

    .line 1129
    .line 1130
    invoke-direct/range {v40 .. v48}, La4/r;-><init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1131
    .line 1132
    .line 1133
    move-object/from16 v3, v40

    .line 1134
    .line 1135
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1136
    .line 1137
    .line 1138
    goto :goto_476

    .line 1139
    :cond_472
    move-object/from16 v39, v3

    .line 1140
    .line 1141
    move-object/from16 p0, v5

    .line 1142
    .line 1143
    :goto_476
    add-int/lit8 v7, v7, 0x1

    .line 1144
    .line 1145
    move-object/from16 v5, p0

    .line 1146
    .line 1147
    move-object/from16 v3, v39

    .line 1148
    .line 1149
    goto :goto_3fe

    .line 1150
    :cond_47d
    move/from16 v7, v19

    .line 1151
    .line 1152
    const/4 v3, 0x0

    .line 1153
    const/4 v5, 0x0

    .line 1154
    :goto_481
    invoke-virtual/range {v38 .. v38}, Ljava/util/ArrayList;->size()I

    .line 1155
    .line 1156
    .line 1157
    move-result v8

    .line 1158
    if-ge v7, v8, :cond_750

    .line 1159
    .line 1160
    move-object/from16 v8, v38

    .line 1161
    .line 1162
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1163
    .line 1164
    .line 1165
    move-result-object v9

    .line 1166
    check-cast v9, Ljava/lang/String;

    .line 1167
    .line 1168
    sget-object v13, La4/x;->C0:Ljava/util/regex/Pattern;

    .line 1169
    .line 1170
    invoke-static {v9, v13, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1171
    .line 1172
    .line 1173
    move-result-object v13

    .line 1174
    invoke-static {v9, v10, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1175
    .line 1176
    .line 1177
    move-result-object v15

    .line 1178
    move-object/from16 p0, v3

    .line 1179
    .line 1180
    sget-object v3, La4/x;->V:Ljava/util/regex/Pattern;

    .line 1181
    .line 1182
    move-object/from16 v27, v4

    .line 1183
    .line 1184
    const/4 v4, 0x0

    .line 1185
    invoke-static {v9, v3, v4, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1186
    .line 1187
    .line 1188
    move-result-object v34

    .line 1189
    new-instance v3, Lk3/v;

    .line 1190
    .line 1191
    invoke-direct {v3}, Lk3/v;-><init>()V

    .line 1192
    .line 1193
    .line 1194
    const-string v4, ":"

    .line 1195
    .line 1196
    invoke-static {v13, v4, v15}, Lp/x2;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1197
    .line 1198
    .line 1199
    move-result-object v4

    .line 1200
    iput-object v4, v3, Lk3/v;->a:Ljava/lang/String;

    .line 1201
    .line 1202
    iput-object v15, v3, Lk3/v;->b:Ljava/lang/String;

    .line 1203
    .line 1204
    invoke-static/range {v18 .. v18}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 1205
    .line 1206
    .line 1207
    move-result-object v4

    .line 1208
    iput-object v4, v3, Lk3/v;->n:Ljava/lang/String;

    .line 1209
    .line 1210
    sget-object v4, La4/x;->G0:Ljava/util/regex/Pattern;

    .line 1211
    .line 1212
    invoke-static {v0, v9, v4}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 1213
    .line 1214
    .line 1215
    move-result v4

    .line 1216
    move/from16 v29, v4

    .line 1217
    .line 1218
    sget-object v4, La4/x;->H0:Ljava/util/regex/Pattern;

    .line 1219
    .line 1220
    invoke-static {v0, v9, v4}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 1221
    .line 1222
    .line 1223
    move-result v4

    .line 1224
    if-eqz v4, :cond_4cd

    .line 1225
    .line 1226
    or-int/lit8 v4, v29, 0x2

    .line 1227
    .line 1228
    move/from16 v29, v4

    .line 1229
    .line 1230
    :cond_4cd
    sget-object v4, La4/x;->F0:Ljava/util/regex/Pattern;

    .line 1231
    .line 1232
    invoke-static {v0, v9, v4}, La4/x;->g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z

    .line 1233
    .line 1234
    .line 1235
    move-result v4

    .line 1236
    if-eqz v4, :cond_4d8

    .line 1237
    .line 1238
    or-int/lit8 v4, v29, 0x4

    .line 1239
    .line 1240
    goto :goto_4da

    .line 1241
    :cond_4d8
    move/from16 v4, v29

    .line 1242
    .line 1243
    :goto_4da
    iput v4, v3, Lk3/v;->e:I

    .line 1244
    .line 1245
    sget-object v4, La4/x;->D0:Ljava/util/regex/Pattern;

    .line 1246
    .line 1247
    move-object/from16 v35, v5

    .line 1248
    .line 1249
    const/4 v5, 0x0

    .line 1250
    invoke-static {v9, v4, v5, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1251
    .line 1252
    .line 1253
    move-result-object v4

    .line 1254
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1255
    .line 1256
    .line 1257
    move-result v5

    .line 1258
    if-eqz v5, :cond_4f0

    .line 1259
    .line 1260
    move/from16 v38, v7

    .line 1261
    .line 1262
    move/from16 v5, v19

    .line 1263
    .line 1264
    goto :goto_525

    .line 1265
    :cond_4f0
    sget-object v5, Ln3/l0;->a:Ljava/lang/String;

    .line 1266
    .line 1267
    const/4 v5, -0x1

    .line 1268
    invoke-virtual {v4, v12, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 1269
    .line 1270
    .line 1271
    move-result-object v4

    .line 1272
    const-string v5, "public.accessibility.describes-video"

    .line 1273
    .line 1274
    invoke-static {v5, v4}, Ln3/l0;->m(Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 1275
    .line 1276
    .line 1277
    move-result v5

    .line 1278
    if-eqz v5, :cond_504

    .line 1279
    .line 1280
    const/16 v5, 0x200

    .line 1281
    .line 1282
    :goto_501
    move/from16 v38, v7

    .line 1283
    .line 1284
    goto :goto_507

    .line 1285
    :cond_504
    move/from16 v5, v19

    .line 1286
    .line 1287
    goto :goto_501

    .line 1288
    :goto_507
    const-string v7, "public.accessibility.transcribes-spoken-dialog"

    .line 1289
    .line 1290
    invoke-static {v7, v4}, Ln3/l0;->m(Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 1291
    .line 1292
    .line 1293
    move-result v7

    .line 1294
    if-eqz v7, :cond_511

    .line 1295
    .line 1296
    or-int/lit16 v5, v5, 0x1000

    .line 1297
    .line 1298
    :cond_511
    const-string v7, "public.accessibility.describes-music-and-sound"

    .line 1299
    .line 1300
    invoke-static {v7, v4}, Ln3/l0;->m(Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 1301
    .line 1302
    .line 1303
    move-result v7

    .line 1304
    if-eqz v7, :cond_51b

    .line 1305
    .line 1306
    or-int/lit16 v5, v5, 0x400

    .line 1307
    .line 1308
    :cond_51b
    const-string v7, "public.easy-to-read"

    .line 1309
    .line 1310
    invoke-static {v7, v4}, Ln3/l0;->m(Ljava/lang/Object;[Ljava/lang/Object;)Z

    .line 1311
    .line 1312
    .line 1313
    move-result v4

    .line 1314
    if-eqz v4, :cond_525

    .line 1315
    .line 1316
    or-int/lit16 v5, v5, 0x2000

    .line 1317
    .line 1318
    :cond_525
    :goto_525
    iput v5, v3, Lk3/v;->f:I

    .line 1319
    .line 1320
    sget-object v4, La4/x;->z0:Ljava/util/regex/Pattern;

    .line 1321
    .line 1322
    const/4 v5, 0x0

    .line 1323
    invoke-static {v9, v4, v5, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1324
    .line 1325
    .line 1326
    move-result-object v4

    .line 1327
    iput-object v4, v3, Lk3/v;->d:Ljava/lang/String;

    .line 1328
    .line 1329
    invoke-static {v9, v11, v5, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1330
    .line 1331
    .line 1332
    move-result-object v4

    .line 1333
    if-nez v4, :cond_539

    .line 1334
    .line 1335
    const/16 v30, 0x0

    .line 1336
    .line 1337
    goto :goto_53f

    .line 1338
    :cond_539
    invoke-static {v1, v4}, Ln3/e;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 1339
    .line 1340
    .line 1341
    move-result-object v5

    .line 1342
    move-object/from16 v30, v5

    .line 1343
    .line 1344
    :goto_53f
    new-instance v4, Lk3/t0;

    .line 1345
    .line 1346
    new-instance v5, Lz3/q;

    .line 1347
    .line 1348
    sget-object v7, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 1349
    .line 1350
    invoke-direct {v5, v13, v15, v7}, Lz3/q;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    .line 1351
    .line 1352
    .line 1353
    move-object/from16 v39, v1

    .line 1354
    .line 1355
    const/4 v7, 0x1

    .line 1356
    new-array v1, v7, [Lk3/s0;

    .line 1357
    .line 1358
    aput-object v5, v1, v19

    .line 1359
    .line 1360
    invoke-direct {v4, v1}, Lk3/t0;-><init>([Lk3/s0;)V

    .line 1361
    .line 1362
    .line 1363
    sget-object v1, La4/x;->x0:Ljava/util/regex/Pattern;

    .line 1364
    .line 1365
    invoke-static {v9, v1, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1366
    .line 1367
    .line 1368
    move-result-object v1

    .line 1369
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 1370
    .line 1371
    .line 1372
    move-result v5

    .line 1373
    const/4 v7, 0x3

    .line 1374
    sparse-switch v5, :sswitch_data_77c

    .line 1375
    .line 1376
    .line 1377
    :goto_560
    const/4 v1, -0x1

    .line 1378
    goto :goto_58e

    .line 1379
    :sswitch_562
    const-string v5, "VIDEO"

    .line 1380
    .line 1381
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1382
    .line 1383
    .line 1384
    move-result v1

    .line 1385
    if-nez v1, :cond_56b

    .line 1386
    .line 1387
    goto :goto_560

    .line 1388
    :cond_56b
    move v1, v7

    .line 1389
    goto :goto_58e

    .line 1390
    :sswitch_56d
    const-string v5, "AUDIO"

    .line 1391
    .line 1392
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1393
    .line 1394
    .line 1395
    move-result v1

    .line 1396
    if-nez v1, :cond_576

    .line 1397
    .line 1398
    goto :goto_560

    .line 1399
    :cond_576
    const/4 v1, 0x2

    .line 1400
    goto :goto_58e

    .line 1401
    :sswitch_578
    const-string v5, "CLOSED-CAPTIONS"

    .line 1402
    .line 1403
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1404
    .line 1405
    .line 1406
    move-result v1

    .line 1407
    if-nez v1, :cond_581

    .line 1408
    .line 1409
    goto :goto_560

    .line 1410
    :cond_581
    const/4 v1, 0x1

    .line 1411
    goto :goto_58e

    .line 1412
    :sswitch_583
    const-string v5, "SUBTITLES"

    .line 1413
    .line 1414
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1415
    .line 1416
    .line 1417
    move-result v1

    .line 1418
    if-nez v1, :cond_58c

    .line 1419
    .line 1420
    goto :goto_560

    .line 1421
    :cond_58c
    move/from16 v1, v19

    .line 1422
    .line 1423
    :goto_58e
    packed-switch v1, :pswitch_data_78e

    .line 1424
    .line 1425
    .line 1426
    :goto_591
    move-object/from16 v9, v25

    .line 1427
    .line 1428
    move-object/from16 v1, v36

    .line 1429
    .line 1430
    goto/16 :goto_73f

    .line 1431
    .line 1432
    :pswitch_597
    move/from16 v1, v19

    .line 1433
    .line 1434
    :goto_599
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1435
    .line 1436
    .line 1437
    move-result v5

    .line 1438
    if-ge v1, v5, :cond_5b1

    .line 1439
    .line 1440
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1441
    .line 1442
    .line 1443
    move-result-object v5

    .line 1444
    check-cast v5, La4/r;

    .line 1445
    .line 1446
    iget-object v7, v5, La4/r;->c:Ljava/lang/String;

    .line 1447
    .line 1448
    invoke-virtual {v13, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1449
    .line 1450
    .line 1451
    move-result v7

    .line 1452
    if-eqz v7, :cond_5ae

    .line 1453
    .line 1454
    goto :goto_5b2

    .line 1455
    :cond_5ae
    add-int/lit8 v1, v1, 0x1

    .line 1456
    .line 1457
    goto :goto_599

    .line 1458
    :cond_5b1
    const/4 v5, 0x0

    .line 1459
    :goto_5b2
    if-eqz v5, :cond_5d6

    .line 1460
    .line 1461
    iget-object v1, v5, La4/r;->b:Lk3/w;

    .line 1462
    .line 1463
    iget-object v5, v1, Lk3/w;->l:Ljava/lang/String;

    .line 1464
    .line 1465
    const/4 v7, 0x2

    .line 1466
    invoke-static {v7, v5}, Ln3/l0;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 1467
    .line 1468
    .line 1469
    move-result-object v5

    .line 1470
    iput-object v5, v3, Lk3/v;->k:Ljava/lang/String;

    .line 1471
    .line 1472
    invoke-static {v5}, Lk3/u0;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 1473
    .line 1474
    .line 1475
    move-result-object v5

    .line 1476
    invoke-static {v5}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 1477
    .line 1478
    .line 1479
    move-result-object v5

    .line 1480
    iput-object v5, v3, Lk3/v;->o:Ljava/lang/String;

    .line 1481
    .line 1482
    iget v5, v1, Lk3/w;->w:I

    .line 1483
    .line 1484
    iput v5, v3, Lk3/v;->v:I

    .line 1485
    .line 1486
    iget v5, v1, Lk3/w;->x:I

    .line 1487
    .line 1488
    iput v5, v3, Lk3/v;->w:I

    .line 1489
    .line 1490
    iget v1, v1, Lk3/w;->B:F

    .line 1491
    .line 1492
    invoke-virtual {v3, v1}, Lk3/v;->b(F)V

    .line 1493
    .line 1494
    .line 1495
    :cond_5d6
    if-nez v30, :cond_5d9

    .line 1496
    .line 1497
    goto :goto_591

    .line 1498
    :cond_5d9
    iput-object v4, v3, Lk3/v;->l:Lk3/t0;

    .line 1499
    .line 1500
    new-instance v29, La4/q;

    .line 1501
    .line 1502
    new-instance v1, Lk3/w;

    .line 1503
    .line 1504
    invoke-direct {v1, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 1505
    .line 1506
    .line 1507
    move-object/from16 v31, v1

    .line 1508
    .line 1509
    move-object/from16 v32, v13

    .line 1510
    .line 1511
    move-object/from16 v33, v15

    .line 1512
    .line 1513
    invoke-direct/range {v29 .. v34}, La4/q;-><init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1514
    .line 1515
    .line 1516
    move-object/from16 v3, v29

    .line 1517
    .line 1518
    move-object/from16 v1, v37

    .line 1519
    .line 1520
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1521
    .line 1522
    .line 1523
    goto :goto_591

    .line 1524
    :pswitch_5f3
    move-object v5, v13

    .line 1525
    move-object/from16 v33, v15

    .line 1526
    .line 1527
    move-object/from16 v1, v37

    .line 1528
    .line 1529
    move/from16 v7, v19

    .line 1530
    .line 1531
    :goto_5fa
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1532
    .line 1533
    .line 1534
    move-result v13

    .line 1535
    if-ge v7, v13, :cond_612

    .line 1536
    .line 1537
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1538
    .line 1539
    .line 1540
    move-result-object v13

    .line 1541
    check-cast v13, La4/r;

    .line 1542
    .line 1543
    iget-object v15, v13, La4/r;->d:Ljava/lang/String;

    .line 1544
    .line 1545
    invoke-virtual {v5, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1546
    .line 1547
    .line 1548
    move-result v15

    .line 1549
    if-eqz v15, :cond_60f

    .line 1550
    .line 1551
    goto :goto_613

    .line 1552
    :cond_60f
    add-int/lit8 v7, v7, 0x1

    .line 1553
    .line 1554
    goto :goto_5fa

    .line 1555
    :cond_612
    const/4 v13, 0x0

    .line 1556
    :goto_613
    if-eqz v13, :cond_625

    .line 1557
    .line 1558
    iget-object v7, v13, La4/r;->b:Lk3/w;

    .line 1559
    .line 1560
    iget-object v7, v7, Lk3/w;->l:Ljava/lang/String;

    .line 1561
    .line 1562
    const/4 v15, 0x1

    .line 1563
    invoke-static {v15, v7}, Ln3/l0;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 1564
    .line 1565
    .line 1566
    move-result-object v7

    .line 1567
    iput-object v7, v3, Lk3/v;->k:Ljava/lang/String;

    .line 1568
    .line 1569
    invoke-static {v7}, Lk3/u0;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 1570
    .line 1571
    .line 1572
    move-result-object v7

    .line 1573
    goto :goto_626

    .line 1574
    :cond_625
    const/4 v7, 0x0

    .line 1575
    :goto_626
    sget-object v15, La4/x;->K:Ljava/util/regex/Pattern;

    .line 1576
    .line 1577
    move-object/from16 v37, v1

    .line 1578
    .line 1579
    const/4 v1, 0x0

    .line 1580
    invoke-static {v9, v15, v1, v14, v0}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1581
    .line 1582
    .line 1583
    move-result-object v15

    .line 1584
    if-eqz v15, :cond_656

    .line 1585
    .line 1586
    sget-object v20, Ln3/l0;->a:Ljava/lang/String;

    .line 1587
    .line 1588
    const/4 v1, 0x2

    .line 1589
    invoke-virtual {v15, v6, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 1590
    .line 1591
    .line 1592
    move-result-object v20

    .line 1593
    aget-object v1, v20, v19

    .line 1594
    .line 1595
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 1596
    .line 1597
    .line 1598
    move-result v1

    .line 1599
    iput v1, v3, Lk3/v;->I:I

    .line 1600
    .line 1601
    const-string v1, "audio/eac3"

    .line 1602
    .line 1603
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1604
    .line 1605
    .line 1606
    move-result v1

    .line 1607
    if-eqz v1, :cond_656

    .line 1608
    .line 1609
    const-string v1, "/JOC"

    .line 1610
    .line 1611
    invoke-virtual {v15, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 1612
    .line 1613
    .line 1614
    move-result v1

    .line 1615
    if-eqz v1, :cond_656

    .line 1616
    .line 1617
    const-string v1, "ec+3"

    .line 1618
    .line 1619
    iput-object v1, v3, Lk3/v;->k:Ljava/lang/String;

    .line 1620
    .line 1621
    const-string v7, "audio/eac3-joc"

    .line 1622
    .line 1623
    :cond_656
    sget-object v1, La4/x;->L:Ljava/util/regex/Pattern;

    .line 1624
    .line 1625
    invoke-static {v0, v9, v1}, La4/x;->i(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)I

    .line 1626
    .line 1627
    .line 1628
    move-result v1

    .line 1629
    const/4 v15, -0x1

    .line 1630
    if-eq v1, v15, :cond_661

    .line 1631
    .line 1632
    iput v1, v3, Lk3/v;->K:I

    .line 1633
    .line 1634
    :cond_661
    invoke-static {v7}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 1635
    .line 1636
    .line 1637
    move-result-object v1

    .line 1638
    iput-object v1, v3, Lk3/v;->o:Ljava/lang/String;

    .line 1639
    .line 1640
    if-eqz v30, :cond_684

    .line 1641
    .line 1642
    iput-object v4, v3, Lk3/v;->l:Lk3/t0;

    .line 1643
    .line 1644
    new-instance v29, La4/q;

    .line 1645
    .line 1646
    new-instance v1, Lk3/w;

    .line 1647
    .line 1648
    invoke-direct {v1, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 1649
    .line 1650
    .line 1651
    move-object/from16 v31, v1

    .line 1652
    .line 1653
    move-object/from16 v32, v5

    .line 1654
    .line 1655
    invoke-direct/range {v29 .. v34}, La4/q;-><init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1656
    .line 1657
    .line 1658
    move-object/from16 v3, v29

    .line 1659
    .line 1660
    move-object/from16 v1, v36

    .line 1661
    .line 1662
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1663
    .line 1664
    .line 1665
    :cond_680
    move-object/from16 v9, v25

    .line 1666
    .line 1667
    goto/16 :goto_73f

    .line 1668
    .line 1669
    :cond_684
    move-object/from16 v1, v36

    .line 1670
    .line 1671
    if-eqz v13, :cond_680

    .line 1672
    .line 1673
    new-instance v4, Lk3/w;

    .line 1674
    .line 1675
    invoke-direct {v4, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 1676
    .line 1677
    .line 1678
    move-object/from16 v3, p0

    .line 1679
    .line 1680
    move-object v5, v4

    .line 1681
    move-object/from16 v9, v25

    .line 1682
    .line 1683
    goto/16 :goto_742

    .line 1684
    .line 1685
    :pswitch_694
    move-object/from16 v1, v36

    .line 1686
    .line 1687
    const/4 v15, -0x1

    .line 1688
    sget-object v4, La4/x;->E0:Ljava/util/regex/Pattern;

    .line 1689
    .line 1690
    invoke-static {v9, v4, v14, v0}, La4/x;->l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 1691
    .line 1692
    .line 1693
    move-result-object v4

    .line 1694
    const-string v5, "CC"

    .line 1695
    .line 1696
    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1697
    .line 1698
    .line 1699
    move-result v5

    .line 1700
    if-eqz v5, :cond_6b2

    .line 1701
    .line 1702
    const/4 v5, 0x2

    .line 1703
    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1704
    .line 1705
    .line 1706
    move-result-object v4

    .line 1707
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 1708
    .line 1709
    .line 1710
    move-result v4

    .line 1711
    const-string v7, "application/cea-608"

    .line 1712
    .line 1713
    const/4 v9, 0x7

    .line 1714
    goto :goto_6be

    .line 1715
    :cond_6b2
    const/4 v5, 0x2

    .line 1716
    const/4 v9, 0x7

    .line 1717
    invoke-virtual {v4, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1718
    .line 1719
    .line 1720
    move-result-object v4

    .line 1721
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 1722
    .line 1723
    .line 1724
    move-result v4

    .line 1725
    const-string v7, "application/cea-708"

    .line 1726
    .line 1727
    :goto_6be
    if-nez p0, :cond_6c6

    .line 1728
    .line 1729
    new-instance v13, Ljava/util/ArrayList;

    .line 1730
    .line 1731
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 1732
    .line 1733
    .line 1734
    goto :goto_6c8

    .line 1735
    :cond_6c6
    move-object/from16 v13, p0

    .line 1736
    .line 1737
    :goto_6c8
    invoke-static {v7}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 1738
    .line 1739
    .line 1740
    move-result-object v7

    .line 1741
    iput-object v7, v3, Lk3/v;->o:Ljava/lang/String;

    .line 1742
    .line 1743
    iput v4, v3, Lk3/v;->O:I

    .line 1744
    .line 1745
    new-instance v4, Lk3/w;

    .line 1746
    .line 1747
    invoke-direct {v4, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 1748
    .line 1749
    .line 1750
    invoke-interface {v13, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1751
    .line 1752
    .line 1753
    move-object v3, v13

    .line 1754
    move-object/from16 v9, v25

    .line 1755
    .line 1756
    :goto_6db
    move-object/from16 v5, v35

    .line 1757
    .line 1758
    goto/16 :goto_742

    .line 1759
    .line 1760
    :pswitch_6df
    move-object/from16 v33, v15

    .line 1761
    .line 1762
    move-object/from16 v1, v36

    .line 1763
    .line 1764
    move/from16 v5, v19

    .line 1765
    .line 1766
    :goto_6e5
    const/4 v15, -0x1

    .line 1767
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 1768
    .line 1769
    .line 1770
    move-result v9

    .line 1771
    if-ge v5, v9, :cond_6ff

    .line 1772
    .line 1773
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1774
    .line 1775
    .line 1776
    move-result-object v9

    .line 1777
    check-cast v9, La4/r;

    .line 1778
    .line 1779
    iget-object v15, v9, La4/r;->e:Ljava/lang/String;

    .line 1780
    .line 1781
    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1782
    .line 1783
    .line 1784
    move-result v15

    .line 1785
    if-eqz v15, :cond_6fc

    .line 1786
    .line 1787
    move-object v5, v9

    .line 1788
    goto :goto_700

    .line 1789
    :cond_6fc
    add-int/lit8 v5, v5, 0x1

    .line 1790
    .line 1791
    goto :goto_6e5

    .line 1792
    :cond_6ff
    const/4 v5, 0x0

    .line 1793
    :goto_700
    if-eqz v5, :cond_711

    .line 1794
    .line 1795
    iget-object v5, v5, La4/r;->b:Lk3/w;

    .line 1796
    .line 1797
    iget-object v5, v5, Lk3/w;->l:Ljava/lang/String;

    .line 1798
    .line 1799
    invoke-static {v7, v5}, Ln3/l0;->w(ILjava/lang/String;)Ljava/lang/String;

    .line 1800
    .line 1801
    .line 1802
    move-result-object v5

    .line 1803
    iput-object v5, v3, Lk3/v;->k:Ljava/lang/String;

    .line 1804
    .line 1805
    invoke-static {v5}, Lk3/u0;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 1806
    .line 1807
    .line 1808
    move-result-object v5

    .line 1809
    goto :goto_712

    .line 1810
    :cond_711
    const/4 v5, 0x0

    .line 1811
    :goto_712
    if-nez v5, :cond_716

    .line 1812
    .line 1813
    const-string v5, "text/vtt"

    .line 1814
    .line 1815
    :cond_716
    invoke-static {v5}, Lk3/u0;->n(Ljava/lang/String;)Ljava/lang/String;

    .line 1816
    .line 1817
    .line 1818
    move-result-object v5

    .line 1819
    iput-object v5, v3, Lk3/v;->o:Ljava/lang/String;

    .line 1820
    .line 1821
    iput-object v4, v3, Lk3/v;->l:Lk3/t0;

    .line 1822
    .line 1823
    if-eqz v30, :cond_736

    .line 1824
    .line 1825
    new-instance v29, La4/q;

    .line 1826
    .line 1827
    new-instance v4, Lk3/w;

    .line 1828
    .line 1829
    invoke-direct {v4, v3}, Lk3/w;-><init>(Lk3/v;)V

    .line 1830
    .line 1831
    .line 1832
    move-object/from16 v31, v4

    .line 1833
    .line 1834
    move-object/from16 v32, v13

    .line 1835
    .line 1836
    invoke-direct/range {v29 .. v34}, La4/q;-><init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1837
    .line 1838
    .line 1839
    move-object/from16 v9, v25

    .line 1840
    .line 1841
    move-object/from16 v3, v29

    .line 1842
    .line 1843
    invoke-virtual {v9, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1844
    .line 1845
    .line 1846
    goto :goto_73f

    .line 1847
    :cond_736
    move-object/from16 v9, v25

    .line 1848
    .line 1849
    const-string v3, "HlsPlaylistParser"

    .line 1850
    .line 1851
    const-string v4, "EXT-X-MEDIA tag with missing mandatory URI attribute: skipping"

    .line 1852
    .line 1853
    invoke-static {v3, v4}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 1854
    .line 1855
    .line 1856
    :goto_73f
    move-object/from16 v3, p0

    .line 1857
    .line 1858
    goto :goto_6db

    .line 1859
    :goto_742
    add-int/lit8 v7, v38, 0x1

    .line 1860
    .line 1861
    move-object/from16 v36, v1

    .line 1862
    .line 1863
    move-object/from16 v38, v8

    .line 1864
    .line 1865
    move-object/from16 v25, v9

    .line 1866
    .line 1867
    move-object/from16 v4, v27

    .line 1868
    .line 1869
    move-object/from16 v1, v39

    .line 1870
    .line 1871
    goto/16 :goto_481

    .line 1872
    .line 1873
    :cond_750
    move-object/from16 p0, v3

    .line 1874
    .line 1875
    move-object/from16 v27, v4

    .line 1876
    .line 1877
    move-object/from16 v35, v5

    .line 1878
    .line 1879
    move-object/from16 v9, v25

    .line 1880
    .line 1881
    move-object/from16 v1, v36

    .line 1882
    .line 1883
    if-eqz v23, :cond_760

    .line 1884
    .line 1885
    sget-object v3, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 1886
    .line 1887
    move-object v12, v3

    .line 1888
    goto :goto_762

    .line 1889
    :cond_760
    move-object/from16 v12, p0

    .line 1890
    .line 1891
    :goto_762
    new-instance v3, La4/s;

    .line 1892
    .line 1893
    invoke-virtual/range {p1 .. p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 1894
    .line 1895
    .line 1896
    move-result-object v4

    .line 1897
    move-object v8, v1

    .line 1898
    move-object/from16 v10, v22

    .line 1899
    .line 1900
    move/from16 v13, v24

    .line 1901
    .line 1902
    move-object/from16 v5, v26

    .line 1903
    .line 1904
    move-object/from16 v6, v27

    .line 1905
    .line 1906
    move-object/from16 v15, v28

    .line 1907
    .line 1908
    move-object/from16 v11, v35

    .line 1909
    .line 1910
    move-object/from16 v7, v37

    .line 1911
    .line 1912
    invoke-direct/range {v3 .. v16}, La4/s;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lk3/w;Ljava/util/List;ZLjava/util/Map;Ljava/util/List;Lk7/l;)V

    .line 1913
    .line 1914
    .line 1915
    return-object v3

    .line 1916
    nop

    .line 1917
    :sswitch_data_77c
    .sparse-switch
        -0x392db8c5 -> :sswitch_583
        -0x13dc6572 -> :sswitch_578
        0x3bba3b6 -> :sswitch_56d
        0x4de1c5b -> :sswitch_562
    .end sparse-switch

    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    :pswitch_data_78e
    .packed-switch 0x0
        :pswitch_6df
        :pswitch_694
        :pswitch_5f3
        :pswitch_597
    .end packed-switch
.end method

.method public static g(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Z
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_16

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    const-string p1, "YES"

    .line 17
    .line 18
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    return p0

    .line 23
    :cond_16
    const/4 p0, 0x0

    .line 24
    return p0
.end method

.method public static h(Ljava/lang/String;Ljava/util/regex/Pattern;DLa4/w;)D
    .registers 5

    .line 1
    invoke-static {p4, p0, p1}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_17

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 20
    .line 21
    .line 22
    move-result-wide p0

    .line 23
    return-wide p0

    .line 24
    :cond_17
    return-wide p2
.end method

.method public static i(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)I
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_17

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    return p0

    .line 24
    :cond_17
    const/4 p0, -0x1

    .line 25
    return p0
.end method

.method public static j(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)J
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_17

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 20
    .line 21
    .line 22
    move-result-wide p0

    .line 23
    return-wide p0

    .line 24
    :cond_17
    const-wide/16 p0, -0x1

    .line 25
    .line 26
    return-wide p0
.end method

.method public static k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;
    .registers 5

    .line 1
    invoke-static {p4, p0, p1}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_12

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-virtual {p0, p1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    :cond_12
    invoke-interface {p3}, Ljava/util/Map;->isEmpty()Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    if-nez p0, :cond_20

    .line 24
    .line 25
    if-nez p2, :cond_1b

    .line 26
    .line 27
    goto :goto_20

    .line 28
    :cond_1b
    invoke-static {p2, p3, p4}, La4/x;->m(Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0

    .line 33
    :cond_20
    :goto_20
    return-object p2
.end method

.method public static l(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/util/Map;La4/w;)Ljava/lang/String;
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p0, p1, v0, p2, p3}, La4/x;->k(Ljava/lang/String;Ljava/util/regex/Pattern;Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p2

    .line 6
    if-eqz p2, :cond_8

    .line 7
    .line 8
    return-object p2

    .line 9
    :cond_8
    new-instance p2, Ljava/lang/StringBuilder;

    .line 10
    .line 11
    const-string p3, "Couldn\'t match "

    .line 12
    .line 13
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/util/regex/Pattern;->pattern()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " in "

    .line 24
    .line 25
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    invoke-static {p0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    throw p0
.end method

.method public static m(Ljava/lang/String;Ljava/util/Map;La4/w;)Ljava/lang/String;
    .registers 5

    .line 1
    sget-object v0, La4/x;->g1:Ljava/util/regex/Pattern;

    .line 2
    .line 3
    invoke-static {p2, p0, v0}, La4/w;->a(La4/w;Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/regex/Matcher;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    new-instance p2, Ljava/lang/StringBuffer;

    .line 8
    .line 9
    invoke-direct {p2}, Ljava/lang/StringBuffer;-><init>()V

    .line 10
    .line 11
    .line 12
    :cond_b
    :goto_b
    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2a

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    invoke-virtual {p0, v0}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_b

    .line 28
    .line 29
    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, Ljava/util/regex/Matcher;->quoteReplacement(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {p0, p2, v0}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    .line 40
    .line 41
    .line 42
    goto :goto_b

    .line 43
    :cond_2a
    invoke-virtual {p0, p2}, Ljava/util/regex/Matcher;->appendTail(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;

    .line 44
    .line 45
    .line 46
    invoke-virtual {p2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0
.end method

.method public static n(Ljava/lang/String;Ljava/util/HashMap;)V
    .registers 3

    .line 1
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    new-instance p1, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    const-string v0, "duplicate variable name \""

    .line 11
    .line 12
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    const-string p0, "\""

    .line 19
    .line 20
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-static {p0}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    throw p0
.end method


# virtual methods
.method public final f(Landroid/net/Uri;Lot/o;)Ljava/lang/Object;
    .registers 10

    .line 1
    new-instance v0, Ljava/io/BufferedReader;

    .line 2
    .line 3
    new-instance v1, Ljava/io/InputStreamReader;

    .line 4
    .line 5
    invoke-direct {v1, p2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 9
    .line 10
    .line 11
    new-instance p2, Ljava/util/ArrayDeque;

    .line 12
    .line 13
    invoke-direct {p2}, Ljava/util/ArrayDeque;-><init>()V

    .line 14
    .line 15
    .line 16
    new-instance v1, La4/w;

    .line 17
    .line 18
    const/4 v2, 0x1

    .line 19
    const/4 v3, 0x0

    .line 20
    const/16 v4, 0x10

    .line 21
    .line 22
    const/high16 v5, 0x3f400000    # 0.75f

    .line 23
    .line 24
    invoke-direct {v1, v4, v5, v2, v3}, La4/w;-><init>(IFZI)V

    .line 25
    .line 26
    .line 27
    :try_start_1a
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    const/16 v3, 0xef

    .line 32
    .line 33
    const/4 v4, 0x0

    .line 34
    if-ne v2, v3, :cond_38

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    const/16 v3, 0xbb

    .line 41
    .line 42
    if-ne v2, v3, :cond_71

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    const/16 v3, 0xbf

    .line 49
    .line 50
    if-eq v2, v3, :cond_34

    .line 51
    .line 52
    goto :goto_71

    .line 53
    :cond_34
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    :cond_38
    :goto_38
    const/4 v3, -0x1

    .line 58
    if-eq v2, v3, :cond_46

    .line 59
    .line 60
    invoke-static {v2}, Ljava/lang/Character;->isWhitespace(I)Z

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    if-eqz v5, :cond_46

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    goto :goto_38

    .line 71
    :cond_46
    move v5, v4

    .line 72
    :goto_47
    const/4 v6, 0x7

    .line 73
    if-ge v5, v6, :cond_5a

    .line 74
    .line 75
    const-string v6, "#EXTM3U"

    .line 76
    .line 77
    invoke-virtual {v6, v5}, Ljava/lang/String;->charAt(I)C

    .line 78
    .line 79
    .line 80
    move-result v6

    .line 81
    if-eq v2, v6, :cond_53

    .line 82
    .line 83
    goto :goto_71

    .line 84
    :cond_53
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 85
    .line 86
    .line 87
    move-result v2

    .line 88
    add-int/lit8 v5, v5, 0x1

    .line 89
    .line 90
    goto :goto_47

    .line 91
    :cond_5a
    :goto_5a
    if-eq v2, v3, :cond_6d

    .line 92
    .line 93
    invoke-static {v2}, Ljava/lang/Character;->isWhitespace(I)Z

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    if-eqz v4, :cond_6d

    .line 98
    .line 99
    invoke-static {v2}, Ln3/l0;->P(I)Z

    .line 100
    .line 101
    .line 102
    move-result v4

    .line 103
    if-nez v4, :cond_6d

    .line 104
    .line 105
    invoke-virtual {v0}, Ljava/io/BufferedReader;->read()I

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    goto :goto_5a

    .line 110
    :cond_6d
    invoke-static {v2}, Ln3/l0;->P(I)Z

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    :cond_71
    :goto_71
    if-eqz v4, :cond_103

    .line 115
    .line 116
    :goto_73
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v2

    .line 120
    if-eqz v2, :cond_f9

    .line 121
    .line 122
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 127
    .line 128
    .line 129
    move-result v3

    .line 130
    if-eqz v3, :cond_84

    .line 131
    .line 132
    goto :goto_73

    .line 133
    :cond_84
    const-string v3, "#EXT-X-STREAM-INF"

    .line 134
    .line 135
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    if-eqz v3, :cond_9f

    .line 140
    .line 141
    invoke-virtual {p2, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    new-instance v2, La4/v;

    .line 145
    .line 146
    const/4 v3, 0x0

    .line 147
    invoke-direct {v2, p2, v0, v3}, La4/v;-><init>(Ljava/util/ArrayDeque;Ljava/io/BufferedReader;I)V

    .line 148
    .line 149
    .line 150
    invoke-static {v2, p1, v1}, La4/x;->e(La4/v;Landroid/net/Uri;La4/w;)La4/s;

    .line 151
    .line 152
    .line 153
    move-result-object p1
    :try_end_99
    .catchall {:try_start_1a .. :try_end_99} :catchall_9d

    .line 154
    invoke-static {v0}, Ln3/l0;->h(Ljava/io/Closeable;)V

    .line 155
    .line 156
    .line 157
    return-object p1

    .line 158
    :catchall_9d
    move-exception p1

    .line 159
    goto :goto_10a

    .line 160
    :cond_9f
    :try_start_9f
    const-string v3, "#EXT-X-TARGETDURATION"

    .line 161
    .line 162
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 163
    .line 164
    .line 165
    move-result v3

    .line 166
    if-nez v3, :cond_e4

    .line 167
    .line 168
    const-string v3, "#EXT-X-MEDIA-SEQUENCE"

    .line 169
    .line 170
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 171
    .line 172
    .line 173
    move-result v3

    .line 174
    if-nez v3, :cond_e4

    .line 175
    .line 176
    const-string v3, "#EXTINF"

    .line 177
    .line 178
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 179
    .line 180
    .line 181
    move-result v3

    .line 182
    if-nez v3, :cond_e4

    .line 183
    .line 184
    const-string v3, "#EXT-X-KEY"

    .line 185
    .line 186
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 187
    .line 188
    .line 189
    move-result v3

    .line 190
    if-nez v3, :cond_e4

    .line 191
    .line 192
    const-string v3, "#EXT-X-BYTERANGE"

    .line 193
    .line 194
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 195
    .line 196
    .line 197
    move-result v3

    .line 198
    if-nez v3, :cond_e4

    .line 199
    .line 200
    const-string v3, "#EXT-X-DISCONTINUITY"

    .line 201
    .line 202
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v3

    .line 206
    if-nez v3, :cond_e4

    .line 207
    .line 208
    const-string v3, "#EXT-X-DISCONTINUITY-SEQUENCE"

    .line 209
    .line 210
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 211
    .line 212
    .line 213
    move-result v3

    .line 214
    if-nez v3, :cond_e4

    .line 215
    .line 216
    const-string v3, "#EXT-X-ENDLIST"

    .line 217
    .line 218
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    move-result v3

    .line 222
    if-eqz v3, :cond_e0

    .line 223
    .line 224
    goto :goto_e4

    .line 225
    :cond_e0
    invoke-virtual {p2, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 226
    .line 227
    .line 228
    goto :goto_73

    .line 229
    :cond_e4
    :goto_e4
    invoke-virtual {p2, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 230
    .line 231
    .line 232
    iget-object v2, p0, La4/x;->d:La4/s;

    .line 233
    .line 234
    iget-object v3, p0, La4/x;->e:La4/p;

    .line 235
    .line 236
    new-instance v4, La4/v;

    .line 237
    .line 238
    const/4 v5, 0x0

    .line 239
    invoke-direct {v4, p2, v0, v5}, La4/v;-><init>(Ljava/util/ArrayDeque;Ljava/io/BufferedReader;I)V

    .line 240
    .line 241
    .line 242
    invoke-static {v2, v3, v4, p1, v1}, La4/x;->d(La4/s;La4/p;La4/v;Landroid/net/Uri;La4/w;)La4/p;

    .line 243
    .line 244
    .line 245
    move-result-object p1
    :try_end_f5
    .catchall {:try_start_9f .. :try_end_f5} :catchall_9d

    .line 246
    invoke-static {v0}, Ln3/l0;->h(Ljava/io/Closeable;)V

    .line 247
    .line 248
    .line 249
    return-object p1

    .line 250
    :cond_f9
    invoke-static {v0}, Ln3/l0;->h(Ljava/io/Closeable;)V

    .line 251
    .line 252
    .line 253
    const-string p1, "Failed to parse the playlist, could not identify any tags."

    .line 254
    .line 255
    invoke-static {p1}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    throw p1

    .line 260
    :cond_103
    :try_start_103
    const-string p1, "Input does not start with the #EXTM3U header."

    .line 261
    .line 262
    invoke-static {p1}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    throw p1
    :try_end_10a
    .catchall {:try_start_103 .. :try_end_10a} :catchall_9d

    .line 267
    :goto_10a
    invoke-static {v0}, Ln3/l0;->h(Ljava/io/Closeable;)V

    .line 268
    .line 269
    .line 270
    throw p1
.end method
