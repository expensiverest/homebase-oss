###### Class a4.d (a4.d)
.class public final La4/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lj4/i;


# instance fields
.field public J:J

.field public K:J

.field public L:Z

.field public M:Ljava/io/IOException;

.field public N:Z

.field public final synthetic O:La4/f;

.field public final d:Landroid/net/Uri;

.field public final e:Ljava/util/HashSet;

.field public final i:Lj4/n;

.field public final v:Lq3/h;

.field public w:La4/p;

.field public x:J

.field public y:J


# direct methods
.method public constructor <init>(La4/f;Landroid/net/Uri;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/d;->O:La4/f;

    .line 5
    .line 6
    iput-object p2, p0, La4/d;->d:Landroid/net/Uri;

    .line 7
    .line 8
    new-instance p2, Ljava/util/HashSet;

    .line 9
    .line 10
    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p2, p0, La4/d;->e:Ljava/util/HashSet;

    .line 14
    .line 15
    invoke-virtual {p2, p3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    new-instance p2, Lj4/n;

    .line 19
    .line 20
    const-string p3, "DefaultHlsPlaylistTracker:MediaPlaylist"

    .line 21
    .line 22
    invoke-direct {p2, p3}, Lj4/n;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    iput-object p2, p0, La4/d;->i:Lj4/n;

    .line 26
    .line 27
    iget-object p1, p1, La4/f;->d:Lmr/k0;

    .line 28
    .line 29
    iget-object p1, p1, Lmr/k0;->d:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lq3/g;

    .line 32
    .line 33
    invoke-interface {p1}, Lq3/g;->h()Lq3/h;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    iput-object p1, p0, La4/d;->v:Lq3/h;

    .line 38
    .line 39
    return-void
.end method


# virtual methods
.method public final a()Landroid/net/Uri;
    .registers 9

    .line 1
    iget-object v0, p0, La4/d;->w:La4/p;

    .line 2
    .line 3
    iget-object v1, p0, La4/d;->d:Landroid/net/Uri;

    .line 4
    .line 5
    if-eqz v0, :cond_7d

    .line 6
    .line 7
    iget-object v0, v0, La4/p;->v:La4/o;

    .line 8
    .line 9
    iget-wide v2, v0, La4/o;->a:J

    .line 10
    .line 11
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    cmp-long v2, v2, v4

    .line 17
    .line 18
    if-nez v2, :cond_18

    .line 19
    .line 20
    iget-boolean v0, v0, La4/o;->e:Z

    .line 21
    .line 22
    if-nez v0, :cond_18

    .line 23
    .line 24
    goto :goto_7d

    .line 25
    :cond_18
    invoke-virtual {v1}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iget-object v1, p0, La4/d;->w:La4/p;

    .line 30
    .line 31
    iget-object v2, v1, La4/p;->v:La4/o;

    .line 32
    .line 33
    iget-boolean v2, v2, La4/o;->e:Z

    .line 34
    .line 35
    if-eqz v2, :cond_60

    .line 36
    .line 37
    iget-wide v2, v1, La4/p;->k:J

    .line 38
    .line 39
    iget-object v1, v1, La4/p;->r:Lhx/m0;

    .line 40
    .line 41
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    int-to-long v6, v1

    .line 46
    add-long/2addr v2, v6

    .line 47
    const-string v1, "_HLS_msn"

    .line 48
    .line 49
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v0, v1, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 54
    .line 55
    .line 56
    iget-object v1, p0, La4/d;->w:La4/p;

    .line 57
    .line 58
    iget-wide v2, v1, La4/p;->n:J

    .line 59
    .line 60
    cmp-long v2, v2, v4

    .line 61
    .line 62
    if-eqz v2, :cond_60

    .line 63
    .line 64
    iget-object v1, v1, La4/p;->s:Lhx/m0;

    .line 65
    .line 66
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 71
    .line 72
    .line 73
    move-result v3

    .line 74
    if-nez v3, :cond_57

    .line 75
    .line 76
    invoke-static {v1}, Lhx/s;->n(Ljava/lang/Iterable;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    check-cast v1, La4/k;

    .line 81
    .line 82
    iget-boolean v1, v1, La4/k;->O:Z

    .line 83
    .line 84
    if-eqz v1, :cond_57

    .line 85
    .line 86
    add-int/lit8 v2, v2, -0x1

    .line 87
    .line 88
    :cond_57
    const-string v1, "_HLS_part"

    .line 89
    .line 90
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    invoke-virtual {v0, v1, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 95
    .line 96
    .line 97
    :cond_60
    iget-object v1, p0, La4/d;->w:La4/p;

    .line 98
    .line 99
    iget-object v1, v1, La4/p;->v:La4/o;

    .line 100
    .line 101
    iget-wide v2, v1, La4/o;->a:J

    .line 102
    .line 103
    cmp-long v2, v2, v4

    .line 104
    .line 105
    if-eqz v2, :cond_78

    .line 106
    .line 107
    iget-boolean v1, v1, La4/o;->b:Z

    .line 108
    .line 109
    if-eqz v1, :cond_71

    .line 110
    .line 111
    const-string v1, "v2"

    .line 112
    .line 113
    goto :goto_73

    .line 114
    :cond_71
    const-string v1, "YES"

    .line 115
    .line 116
    :goto_73
    const-string v2, "_HLS_skip"

    .line 117
    .line 118
    invoke-virtual {v0, v2, v1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 119
    .line 120
    .line 121
    :cond_78
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    return-object v0

    .line 126
    :cond_7d
    :goto_7d
    return-object v1
.end method

.method public final b(Landroid/net/Uri;)V
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, La4/d;->O:La4/f;

    .line 4
    .line 5
    iget-object v2, v1, La4/f;->e:La4/y;

    .line 6
    .line 7
    iget-object v3, v1, La4/f;->M:La4/s;

    .line 8
    .line 9
    iget-object v4, v0, La4/d;->w:La4/p;

    .line 10
    .line 11
    invoke-interface {v2, v3, v4}, La4/y;->e(La4/s;La4/p;)Lj4/o;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    sget-object v9, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 16
    .line 17
    const-string v3, "The uri must be set."

    .line 18
    .line 19
    move-object/from16 v4, p1

    .line 20
    .line 21
    invoke-static {v4, v3}, Loq/a;->t(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    new-instance v3, Lq3/k;

    .line 25
    .line 26
    const-wide/16 v5, 0x0

    .line 27
    .line 28
    const/4 v7, 0x1

    .line 29
    const/4 v8, 0x0

    .line 30
    const-wide/16 v10, 0x0

    .line 31
    .line 32
    const-wide/16 v12, -0x1

    .line 33
    .line 34
    const/4 v14, 0x0

    .line 35
    const/4 v15, 0x1

    .line 36
    invoke-direct/range {v3 .. v15}, Lq3/k;-><init>(Landroid/net/Uri;JI[BLjava/util/Map;JJLjava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    new-instance v4, Lk7/i;

    .line 40
    .line 41
    iget-object v5, v0, La4/d;->v:Lq3/h;

    .line 42
    .line 43
    invoke-direct {v4, v5, v3, v2}, Lk7/i;-><init>(Lq3/h;Lq3/k;Lj4/o;)V

    .line 44
    .line 45
    .line 46
    iget-object v2, v1, La4/f;->O:Lw70/n;

    .line 47
    .line 48
    const/4 v3, 0x0

    .line 49
    if-eqz v2, :cond_58

    .line 50
    .line 51
    iget-boolean v2, v2, Lw70/n;->a:Z

    .line 52
    .line 53
    if-nez v2, :cond_37

    .line 54
    .line 55
    goto :goto_58

    .line 56
    :cond_37
    iget-object v2, v1, La4/f;->v:Ljava/util/HashMap;

    .line 57
    .line 58
    iget-object v5, v0, La4/d;->d:Landroid/net/Uri;

    .line 59
    .line 60
    invoke-virtual {v2, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    check-cast v2, La4/e;

    .line 65
    .line 66
    iget-object v5, v0, La4/d;->e:Ljava/util/HashSet;

    .line 67
    .line 68
    if-eqz v2, :cond_51

    .line 69
    .line 70
    iget-object v2, v2, La4/e;->a:La4/d0;

    .line 71
    .line 72
    iget-object v2, v2, La4/d0;->d:Ljava/lang/String;

    .line 73
    .line 74
    invoke-virtual {v5, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v6

    .line 78
    if-eqz v6, :cond_51

    .line 79
    .line 80
    move-object v3, v2

    .line 81
    goto :goto_58

    .line 82
    :cond_51
    invoke-static {v3, v5}, Lhx/s;->m(Ljava/lang/String;Ljava/util/AbstractCollection;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    move-object v3, v2

    .line 87
    check-cast v3, Ljava/lang/String;

    .line 88
    .line 89
    :cond_58
    :goto_58
    iput-object v3, v4, Lk7/i;->w:Ljava/lang/Object;

    .line 90
    .line 91
    new-instance v2, Lj4/p;

    .line 92
    .line 93
    invoke-direct {v2, v4}, Lj4/p;-><init>(Lk7/i;)V

    .line 94
    .line 95
    .line 96
    iget-object v1, v1, La4/f;->i:Lcl/a;

    .line 97
    .line 98
    iget v3, v2, Lj4/p;->c:I

    .line 99
    .line 100
    invoke-virtual {v1, v3}, Lcl/a;->V(I)I

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    iget-object v3, v0, La4/d;->i:Lj4/n;

    .line 105
    .line 106
    invoke-virtual {v3, v2, v0, v1}, Lj4/n;->d(Lj4/k;Lj4/i;I)V

    .line 107
    .line 108
    .line 109
    return-void
.end method

.method public final c(Lj4/k;JJ)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lj4/p;

    .line 6
    .line 7
    iget-object v2, v1, Lj4/p;->f:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, La4/t;

    .line 10
    .line 11
    new-instance v3, Lf4/t;

    .line 12
    .line 13
    iget-wide v4, v1, Lj4/p;->a:J

    .line 14
    .line 15
    iget-object v6, v1, Lj4/p;->b:Lq3/k;

    .line 16
    .line 17
    move-wide/from16 v7, p2

    .line 18
    .line 19
    invoke-direct/range {v3 .. v8}, Lf4/t;-><init>(JLq3/k;J)V

    .line 20
    .line 21
    .line 22
    iget-object v1, v1, Lj4/p;->d:Lq3/y;

    .line 23
    .line 24
    iget-object v4, v1, Lq3/y;->i:Landroid/net/Uri;

    .line 25
    .line 26
    iput-object v4, v3, Lf4/t;->d:Landroid/net/Uri;

    .line 27
    .line 28
    iget-object v4, v1, Lq3/y;->v:Ljava/util/Map;

    .line 29
    .line 30
    iput-object v4, v3, Lf4/t;->e:Ljava/util/Map;

    .line 31
    .line 32
    move-wide/from16 v4, p4

    .line 33
    .line 34
    iput-wide v4, v3, Lf4/t;->f:J

    .line 35
    .line 36
    iget-wide v4, v1, Lq3/y;->e:J

    .line 37
    .line 38
    iput-wide v4, v3, Lf4/t;->g:J

    .line 39
    .line 40
    new-instance v7, Lf4/u;

    .line 41
    .line 42
    invoke-direct {v7, v3}, Lf4/u;-><init>(Lf4/t;)V

    .line 43
    .line 44
    .line 45
    instance-of v1, v2, La4/p;

    .line 46
    .line 47
    const/4 v8, 0x4

    .line 48
    if-eqz v1, :cond_4c

    .line 49
    .line 50
    check-cast v2, La4/p;

    .line 51
    .line 52
    invoke-virtual {v0, v2, v7}, La4/d;->e(La4/p;Lf4/u;)V

    .line 53
    .line 54
    .line 55
    iget-object v1, v0, La4/d;->O:La4/f;

    .line 56
    .line 57
    iget-object v6, v1, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 58
    .line 59
    const-wide v13, -0x7fffffffffffffffL    # -4.9E-324

    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    const-wide v15, -0x7fffffffffffffffL    # -4.9E-324

    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    const/4 v9, -0x1

    .line 70
    const/4 v10, 0x0

    .line 71
    const/4 v11, 0x0

    .line 72
    const/4 v12, 0x0

    .line 73
    invoke-virtual/range {v6 .. v16}, Lcom/google/android/gms/internal/fido/f8;->x(Lf4/u;IILk3/w;ILjava/lang/Object;JJ)V

    .line 74
    .line 75
    .line 76
    goto :goto_5c

    .line 77
    :cond_4c
    const-string v1, "Loaded playlist has unexpected type."

    .line 78
    .line 79
    invoke-static {v1}, Lk3/v0;->b(Ljava/lang/String;)Lk3/v0;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    iput-object v1, v0, La4/d;->M:Ljava/io/IOException;

    .line 84
    .line 85
    iget-object v2, v0, La4/d;->O:La4/f;

    .line 86
    .line 87
    iget-object v2, v2, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 88
    .line 89
    const/4 v3, 0x1

    .line 90
    invoke-virtual {v2, v7, v8, v1, v3}, Lcom/google/android/gms/internal/fido/f8;->C(Lf4/u;ILjava/io/IOException;Z)V

    .line 91
    .line 92
    .line 93
    :goto_5c
    iget-object v1, v0, La4/d;->O:La4/f;

    .line 94
    .line 95
    iget-object v1, v1, La4/f;->i:Lcl/a;

    .line 96
    .line 97
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    return-void
.end method

.method public final d(Landroid/net/Uri;)V
    .registers 9

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, La4/d;->K:J

    .line 4
    .line 5
    iget-boolean v0, p0, La4/d;->L:Z

    .line 6
    .line 7
    if-nez v0, :cond_34

    .line 8
    .line 9
    iget-object v0, p0, La4/d;->i:Lj4/n;

    .line 10
    .line 11
    invoke-virtual {v0}, Lj4/n;->b()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_34

    .line 16
    .line 17
    iget-object v0, v0, Lj4/n;->c:Ljava/io/IOException;

    .line 18
    .line 19
    if-eqz v0, :cond_15

    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    iget-wide v2, p0, La4/d;->J:J

    .line 27
    .line 28
    cmp-long v4, v0, v2

    .line 29
    .line 30
    if-gez v4, :cond_31

    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    iput-boolean v4, p0, La4/d;->L:Z

    .line 34
    .line 35
    iget-object v4, p0, La4/d;->O:La4/f;

    .line 36
    .line 37
    iget-object v4, v4, La4/f;->J:Landroid/os/Handler;

    .line 38
    .line 39
    new-instance v5, La4/c;

    .line 40
    .line 41
    const/4 v6, 0x0

    .line 42
    invoke-direct {v5, v6, p0, p1}, La4/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    sub-long/2addr v2, v0

    .line 46
    invoke-virtual {v4, v5, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_31
    invoke-virtual {p0, p1}, La4/d;->b(Landroid/net/Uri;)V

    .line 51
    .line 52
    .line 53
    :cond_34
    return-void
.end method

.method public final e(La4/p;Lf4/u;)V
    .registers 77

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, La4/d;->w:La4/p;

    .line 6
    .line 7
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 8
    .line 9
    .line 10
    move-result-wide v3

    .line 11
    iput-wide v3, v0, La4/d;->x:J

    .line 12
    .line 13
    iget-object v5, v0, La4/d;->O:La4/f;

    .line 14
    .line 15
    iget-object v6, v5, La4/f;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 16
    .line 17
    if-eqz v2, :cond_4b

    .line 18
    .line 19
    iget-wide v9, v1, La4/p;->k:J

    .line 20
    .line 21
    iget-wide v11, v2, La4/p;->k:J

    .line 22
    .line 23
    cmp-long v9, v9, v11

    .line 24
    .line 25
    if-lez v9, :cond_1b

    .line 26
    .line 27
    goto :goto_30

    .line 28
    :cond_1b
    if-gez v9, :cond_1f

    .line 29
    .line 30
    :cond_1d
    const/4 v9, 0x0

    .line 31
    goto :goto_4f

    .line 32
    :cond_1f
    iget-object v9, v1, La4/p;->r:Lhx/m0;

    .line 33
    .line 34
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 35
    .line 36
    .line 37
    move-result v9

    .line 38
    iget-object v10, v2, La4/p;->r:Lhx/m0;

    .line 39
    .line 40
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 41
    .line 42
    .line 43
    move-result v10

    .line 44
    sub-int/2addr v9, v10

    .line 45
    if-eqz v9, :cond_32

    .line 46
    .line 47
    if-lez v9, :cond_1d

    .line 48
    .line 49
    :cond_30
    :goto_30
    const/4 v9, 0x1

    .line 50
    goto :goto_4f

    .line 51
    :cond_32
    iget-object v9, v1, La4/p;->s:Lhx/m0;

    .line 52
    .line 53
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 54
    .line 55
    .line 56
    move-result v9

    .line 57
    iget-object v10, v2, La4/p;->s:Lhx/m0;

    .line 58
    .line 59
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 60
    .line 61
    .line 62
    move-result v10

    .line 63
    if-gt v9, v10, :cond_30

    .line 64
    .line 65
    if-ne v9, v10, :cond_1d

    .line 66
    .line 67
    iget-boolean v9, v1, La4/p;->o:Z

    .line 68
    .line 69
    if-eqz v9, :cond_1d

    .line 70
    .line 71
    iget-boolean v9, v2, La4/p;->o:Z

    .line 72
    .line 73
    if-nez v9, :cond_1d

    .line 74
    .line 75
    goto :goto_30

    .line 76
    :cond_4b
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    goto :goto_30

    .line 80
    :goto_4f
    iget-object v10, v1, La4/p;->r:Lhx/m0;

    .line 81
    .line 82
    iget-wide v11, v1, La4/p;->k:J

    .line 83
    .line 84
    const-wide/16 v38, 0x0

    .line 85
    .line 86
    if-nez v9, :cond_d4

    .line 87
    .line 88
    iget-boolean v9, v1, La4/p;->o:Z

    .line 89
    .line 90
    if-eqz v9, :cond_cd

    .line 91
    .line 92
    iget-boolean v9, v2, La4/p;->o:Z

    .line 93
    .line 94
    if-eqz v9, :cond_68

    .line 95
    .line 96
    move-object v10, v2

    .line 97
    move-object/from16 v69, v6

    .line 98
    .line 99
    move-wide v8, v11

    .line 100
    const/4 v6, 0x0

    .line 101
    const/16 v68, 0x1

    .line 102
    .line 103
    goto/16 :goto_1bb

    .line 104
    .line 105
    :cond_68
    new-instance v40, La4/p;

    .line 106
    .line 107
    iget v9, v2, La4/p;->d:I

    .line 108
    .line 109
    iget-object v10, v2, La4/t;->a:Ljava/lang/String;

    .line 110
    .line 111
    iget-object v14, v2, La4/t;->b:Ljava/util/List;

    .line 112
    .line 113
    move-object/from16 v43, v14

    .line 114
    .line 115
    iget-wide v13, v2, La4/p;->e:J

    .line 116
    .line 117
    iget-boolean v15, v2, La4/p;->g:Z

    .line 118
    .line 119
    const/16 v68, 0x1

    .line 120
    .line 121
    iget-wide v7, v2, La4/p;->h:J

    .line 122
    .line 123
    move-object/from16 v69, v6

    .line 124
    .line 125
    iget-boolean v6, v2, La4/p;->i:Z

    .line 126
    .line 127
    move/from16 v49, v6

    .line 128
    .line 129
    iget v6, v2, La4/p;->j:I

    .line 130
    .line 131
    move/from16 v50, v6

    .line 132
    .line 133
    move-wide/from16 v47, v7

    .line 134
    .line 135
    iget-wide v6, v2, La4/p;->k:J

    .line 136
    .line 137
    iget v8, v2, La4/p;->l:I

    .line 138
    .line 139
    move-wide/from16 v51, v6

    .line 140
    .line 141
    iget-wide v6, v2, La4/p;->m:J

    .line 142
    .line 143
    move-wide/from16 v54, v6

    .line 144
    .line 145
    iget-wide v6, v2, La4/p;->n:J

    .line 146
    .line 147
    move-wide/from16 v56, v6

    .line 148
    .line 149
    iget-boolean v6, v2, La4/t;->c:Z

    .line 150
    .line 151
    iget-boolean v7, v2, La4/p;->p:Z

    .line 152
    .line 153
    move/from16 v58, v6

    .line 154
    .line 155
    iget-object v6, v2, La4/p;->q:Lk3/r;

    .line 156
    .line 157
    move-object/from16 v61, v6

    .line 158
    .line 159
    iget-object v6, v2, La4/p;->r:Lhx/m0;

    .line 160
    .line 161
    move-object/from16 v62, v6

    .line 162
    .line 163
    iget-object v6, v2, La4/p;->s:Lhx/m0;

    .line 164
    .line 165
    move-object/from16 v63, v6

    .line 166
    .line 167
    iget-object v6, v2, La4/p;->v:La4/o;

    .line 168
    .line 169
    move-object/from16 v64, v6

    .line 170
    .line 171
    iget-object v6, v2, La4/p;->t:Lhx/p0;

    .line 172
    .line 173
    move-object/from16 v65, v6

    .line 174
    .line 175
    iget-object v6, v2, La4/p;->w:Lhx/m0;

    .line 176
    .line 177
    move-object/from16 v66, v6

    .line 178
    .line 179
    iget-object v6, v2, La4/p;->x:La4/m;

    .line 180
    .line 181
    const/16 v59, 0x1

    .line 182
    .line 183
    move-object/from16 v67, v6

    .line 184
    .line 185
    move/from16 v60, v7

    .line 186
    .line 187
    move/from16 v53, v8

    .line 188
    .line 189
    move/from16 v41, v9

    .line 190
    .line 191
    move-object/from16 v42, v10

    .line 192
    .line 193
    move-wide/from16 v44, v13

    .line 194
    .line 195
    move/from16 v46, v15

    .line 196
    .line 197
    invoke-direct/range {v40 .. v67}, La4/p;-><init>(ILjava/lang/String;Ljava/util/List;JZJZIJIJJZZZLk3/r;Ljava/util/List;Ljava/util/List;La4/o;Ljava/util/Map;Ljava/util/List;La4/m;)V

    .line 198
    .line 199
    .line 200
    move-wide v8, v11

    .line 201
    move-object/from16 v10, v40

    .line 202
    .line 203
    :goto_ca
    const/4 v6, 0x0

    .line 204
    goto/16 :goto_1bb

    .line 205
    .line 206
    :cond_cd
    move-object/from16 v69, v6

    .line 207
    .line 208
    const/16 v68, 0x1

    .line 209
    .line 210
    move-object v10, v2

    .line 211
    move-wide v8, v11

    .line 212
    goto :goto_ca

    .line 213
    :cond_d4
    move-object/from16 v69, v6

    .line 214
    .line 215
    const/16 v68, 0x1

    .line 216
    .line 217
    iget-boolean v6, v1, La4/p;->p:Z

    .line 218
    .line 219
    if-eqz v6, :cond_e1

    .line 220
    .line 221
    iget-wide v6, v1, La4/p;->h:J

    .line 222
    .line 223
    :goto_de
    move-wide/from16 v17, v6

    .line 224
    .line 225
    goto :goto_11d

    .line 226
    :cond_e1
    iget-object v6, v5, La4/f;->U:La4/p;

    .line 227
    .line 228
    if-eqz v6, :cond_e8

    .line 229
    .line 230
    iget-wide v6, v6, La4/p;->h:J

    .line 231
    .line 232
    goto :goto_ea

    .line 233
    :cond_e8
    move-wide/from16 v6, v38

    .line 234
    .line 235
    :goto_ea
    if-nez v2, :cond_ed

    .line 236
    .line 237
    goto :goto_de

    .line 238
    :cond_ed
    iget-wide v8, v2, La4/p;->h:J

    .line 239
    .line 240
    iget-wide v13, v2, La4/p;->k:J

    .line 241
    .line 242
    iget-object v15, v2, La4/p;->r:Lhx/m0;

    .line 243
    .line 244
    move-wide/from16 v17, v6

    .line 245
    .line 246
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 247
    .line 248
    .line 249
    move-result v6

    .line 250
    move-wide/from16 v19, v8

    .line 251
    .line 252
    sub-long v7, v11, v13

    .line 253
    .line 254
    long-to-int v7, v7

    .line 255
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 256
    .line 257
    .line 258
    move-result v8

    .line 259
    if-ge v7, v8, :cond_10b

    .line 260
    .line 261
    invoke-interface {v15, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v7

    .line 265
    check-cast v7, La4/m;

    .line 266
    .line 267
    goto :goto_10c

    .line 268
    :cond_10b
    const/4 v7, 0x0

    .line 269
    :goto_10c
    if-eqz v7, :cond_113

    .line 270
    .line 271
    iget-wide v6, v7, La4/n;->w:J

    .line 272
    .line 273
    :goto_110
    add-long v6, v19, v6

    .line 274
    .line 275
    goto :goto_de

    .line 276
    :cond_113
    int-to-long v6, v6

    .line 277
    sub-long v8, v11, v13

    .line 278
    .line 279
    cmp-long v6, v6, v8

    .line 280
    .line 281
    if-nez v6, :cond_11d

    .line 282
    .line 283
    iget-wide v6, v2, La4/p;->u:J

    .line 284
    .line 285
    goto :goto_110

    .line 286
    :cond_11d
    :goto_11d
    iget-boolean v6, v1, La4/p;->i:Z

    .line 287
    .line 288
    if-eqz v6, :cond_129

    .line 289
    .line 290
    iget v6, v1, La4/p;->j:I

    .line 291
    .line 292
    move/from16 v20, v6

    .line 293
    .line 294
    move-object/from16 v32, v10

    .line 295
    .line 296
    const/4 v7, 0x0

    .line 297
    goto :goto_15f

    .line 298
    :cond_129
    iget-object v6, v5, La4/f;->U:La4/p;

    .line 299
    .line 300
    if-eqz v6, :cond_130

    .line 301
    .line 302
    iget v6, v6, La4/p;->j:I

    .line 303
    .line 304
    goto :goto_131

    .line 305
    :cond_130
    const/4 v6, 0x0

    .line 306
    :goto_131
    if-nez v2, :cond_135

    .line 307
    .line 308
    :cond_133
    const/4 v7, 0x0

    .line 309
    goto :goto_15b

    .line 310
    :cond_135
    iget-wide v7, v2, La4/p;->k:J

    .line 311
    .line 312
    sub-long v7, v11, v7

    .line 313
    .line 314
    long-to-int v7, v7

    .line 315
    iget-object v8, v2, La4/p;->r:Lhx/m0;

    .line 316
    .line 317
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 318
    .line 319
    .line 320
    move-result v9

    .line 321
    if-ge v7, v9, :cond_149

    .line 322
    .line 323
    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object v7

    .line 327
    check-cast v7, La4/m;

    .line 328
    .line 329
    goto :goto_14a

    .line 330
    :cond_149
    const/4 v7, 0x0

    .line 331
    :goto_14a
    if-eqz v7, :cond_133

    .line 332
    .line 333
    iget v6, v2, La4/p;->j:I

    .line 334
    .line 335
    iget v7, v7, La4/n;->v:I

    .line 336
    .line 337
    add-int/2addr v6, v7

    .line 338
    const/4 v7, 0x0

    .line 339
    invoke-interface {v10, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 340
    .line 341
    .line 342
    move-result-object v8

    .line 343
    check-cast v8, La4/m;

    .line 344
    .line 345
    iget v8, v8, La4/n;->v:I

    .line 346
    .line 347
    sub-int/2addr v6, v8

    .line 348
    :goto_15b
    move/from16 v20, v6

    .line 349
    .line 350
    move-object/from16 v32, v10

    .line 351
    .line 352
    :goto_15f
    new-instance v10, La4/p;

    .line 353
    .line 354
    move-wide v8, v11

    .line 355
    iget v11, v1, La4/p;->d:I

    .line 356
    .line 357
    iget-object v12, v1, La4/t;->a:Ljava/lang/String;

    .line 358
    .line 359
    iget-object v13, v1, La4/t;->b:Ljava/util/List;

    .line 360
    .line 361
    iget-wide v14, v1, La4/p;->e:J

    .line 362
    .line 363
    iget-boolean v6, v1, La4/p;->g:Z

    .line 364
    .line 365
    move-wide/from16 v21, v8

    .line 366
    .line 367
    iget-wide v7, v1, La4/p;->k:J

    .line 368
    .line 369
    iget v9, v1, La4/p;->l:I

    .line 370
    .line 371
    move/from16 v19, v6

    .line 372
    .line 373
    move-wide/from16 v23, v7

    .line 374
    .line 375
    iget-wide v6, v1, La4/p;->m:J

    .line 376
    .line 377
    move-wide/from16 v25, v6

    .line 378
    .line 379
    iget-wide v6, v1, La4/p;->n:J

    .line 380
    .line 381
    iget-boolean v8, v1, La4/t;->c:Z

    .line 382
    .line 383
    move-wide/from16 v27, v6

    .line 384
    .line 385
    iget-boolean v6, v1, La4/p;->o:Z

    .line 386
    .line 387
    iget-boolean v7, v1, La4/p;->p:Z

    .line 388
    .line 389
    move/from16 v29, v6

    .line 390
    .line 391
    iget-object v6, v1, La4/p;->q:Lk3/r;

    .line 392
    .line 393
    move-object/from16 v31, v6

    .line 394
    .line 395
    iget-object v6, v1, La4/p;->s:Lhx/m0;

    .line 396
    .line 397
    move-object/from16 v33, v6

    .line 398
    .line 399
    iget-object v6, v1, La4/p;->v:La4/o;

    .line 400
    .line 401
    move-object/from16 v34, v6

    .line 402
    .line 403
    iget-object v6, v1, La4/p;->t:Lhx/p0;

    .line 404
    .line 405
    move-object/from16 v35, v6

    .line 406
    .line 407
    iget-object v6, v1, La4/p;->w:Lhx/m0;

    .line 408
    .line 409
    move-object/from16 v36, v6

    .line 410
    .line 411
    iget-object v6, v1, La4/p;->x:La4/m;

    .line 412
    .line 413
    move/from16 v16, v19

    .line 414
    .line 415
    const/16 v30, 0x0

    .line 416
    .line 417
    const/16 v19, 0x1

    .line 418
    .line 419
    move-object/from16 v37, v6

    .line 420
    .line 421
    move-object/from16 v6, v30

    .line 422
    .line 423
    move/from16 v30, v7

    .line 424
    .line 425
    move-wide/from16 v70, v27

    .line 426
    .line 427
    move/from16 v28, v8

    .line 428
    .line 429
    move-wide/from16 v72, v23

    .line 430
    .line 431
    move/from16 v23, v9

    .line 432
    .line 433
    move-wide/from16 v8, v21

    .line 434
    .line 435
    move-wide/from16 v21, v72

    .line 436
    .line 437
    move-wide/from16 v24, v25

    .line 438
    .line 439
    move-wide/from16 v26, v70

    .line 440
    .line 441
    invoke-direct/range {v10 .. v37}, La4/p;-><init>(ILjava/lang/String;Ljava/util/List;JZJZIJIJJZZZLk3/r;Ljava/util/List;Ljava/util/List;La4/o;Ljava/util/Map;Ljava/util/List;La4/m;)V

    .line 442
    .line 443
    .line 444
    :goto_1bb
    iput-object v10, v0, La4/d;->w:La4/p;

    .line 445
    .line 446
    iget-object v7, v0, La4/d;->d:Landroid/net/Uri;

    .line 447
    .line 448
    if-eq v10, v2, :cond_202

    .line 449
    .line 450
    iput-object v6, v0, La4/d;->M:Ljava/io/IOException;

    .line 451
    .line 452
    iput-wide v3, v0, La4/d;->y:J

    .line 453
    .line 454
    iget-object v1, v5, La4/f;->V:Landroid/net/Uri;

    .line 455
    .line 456
    invoke-virtual {v7, v1}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 457
    .line 458
    .line 459
    move-result v1

    .line 460
    if-eqz v1, :cond_1d1

    .line 461
    .line 462
    iput-object v7, v5, La4/f;->T:Landroid/net/Uri;

    .line 463
    .line 464
    iput-object v6, v5, La4/f;->V:Landroid/net/Uri;

    .line 465
    .line 466
    :cond_1d1
    iget-object v1, v5, La4/f;->T:Landroid/net/Uri;

    .line 467
    .line 468
    invoke-virtual {v7, v1}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 469
    .line 470
    .line 471
    move-result v1

    .line 472
    if-eqz v1, :cond_1ee

    .line 473
    .line 474
    iget-object v1, v5, La4/f;->U:La4/p;

    .line 475
    .line 476
    if-nez v1, :cond_1e7

    .line 477
    .line 478
    iget-boolean v1, v10, La4/p;->o:Z

    .line 479
    .line 480
    xor-int/lit8 v1, v1, 0x1

    .line 481
    .line 482
    iput-boolean v1, v5, La4/f;->W:Z

    .line 483
    .line 484
    iget-wide v8, v10, La4/p;->h:J

    .line 485
    .line 486
    iput-wide v8, v5, La4/f;->X:J

    .line 487
    .line 488
    :cond_1e7
    iput-object v10, v5, La4/f;->U:La4/p;

    .line 489
    .line 490
    iget-object v1, v5, La4/f;->K:Lz3/j;

    .line 491
    .line 492
    invoke-virtual {v1, v10}, Lz3/j;->u(La4/p;)V

    .line 493
    .line 494
    .line 495
    :cond_1ee
    invoke-virtual/range {v69 .. v69}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 496
    .line 497
    .line 498
    move-result-object v1

    .line 499
    :goto_1f2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 500
    .line 501
    .line 502
    move-result v6

    .line 503
    if-eqz v6, :cond_25a

    .line 504
    .line 505
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 506
    .line 507
    .line 508
    move-result-object v6

    .line 509
    check-cast v6, La4/z;

    .line 510
    .line 511
    invoke-interface {v6}, La4/z;->a()V

    .line 512
    .line 513
    .line 514
    goto :goto_1f2

    .line 515
    :cond_202
    iget-boolean v10, v10, La4/p;->o:Z

    .line 516
    .line 517
    if-nez v10, :cond_25a

    .line 518
    .line 519
    iget-object v1, v1, La4/p;->r:Lhx/m0;

    .line 520
    .line 521
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 522
    .line 523
    .line 524
    move-result v1

    .line 525
    int-to-long v10, v1

    .line 526
    add-long v11, v8, v10

    .line 527
    .line 528
    iget-object v1, v0, La4/d;->w:La4/p;

    .line 529
    .line 530
    iget-wide v8, v1, La4/p;->k:J

    .line 531
    .line 532
    cmp-long v8, v11, v8

    .line 533
    .line 534
    if-gez v8, :cond_21f

    .line 535
    .line 536
    new-instance v13, La4/a0;

    .line 537
    .line 538
    invoke-direct {v13}, Ljava/io/IOException;-><init>()V

    .line 539
    .line 540
    .line 541
    move/from16 v8, v68

    .line 542
    .line 543
    goto :goto_23b

    .line 544
    :cond_21f
    iget-wide v8, v0, La4/d;->y:J

    .line 545
    .line 546
    sub-long v8, v3, v8

    .line 547
    .line 548
    long-to-double v8, v8

    .line 549
    iget-wide v10, v1, La4/p;->m:J

    .line 550
    .line 551
    invoke-static {v10, v11}, Ln3/l0;->g0(J)J

    .line 552
    .line 553
    .line 554
    move-result-wide v10

    .line 555
    long-to-double v10, v10

    .line 556
    const-wide/high16 v12, 0x400c000000000000L    # 3.5

    .line 557
    .line 558
    mul-double/2addr v10, v12

    .line 559
    cmpl-double v1, v8, v10

    .line 560
    .line 561
    if-lez v1, :cond_239

    .line 562
    .line 563
    new-instance v13, La4/a0;

    .line 564
    .line 565
    invoke-direct {v13}, Ljava/io/IOException;-><init>()V

    .line 566
    .line 567
    .line 568
    :goto_237
    const/4 v8, 0x0

    .line 569
    goto :goto_23b

    .line 570
    :cond_239
    move-object v13, v6

    .line 571
    goto :goto_237

    .line 572
    :goto_23b
    if-eqz v13, :cond_25a

    .line 573
    .line 574
    iput-object v13, v0, La4/d;->M:Ljava/io/IOException;

    .line 575
    .line 576
    new-instance v1, Lj4/h;

    .line 577
    .line 578
    move/from16 v6, v68

    .line 579
    .line 580
    invoke-direct {v1, v6, v13}, Lj4/h;-><init>(ILjava/io/IOException;)V

    .line 581
    .line 582
    .line 583
    invoke-virtual/range {v69 .. v69}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 584
    .line 585
    .line 586
    move-result-object v6

    .line 587
    :goto_24a
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 588
    .line 589
    .line 590
    move-result v9

    .line 591
    if-eqz v9, :cond_25a

    .line 592
    .line 593
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 594
    .line 595
    .line 596
    move-result-object v9

    .line 597
    check-cast v9, La4/z;

    .line 598
    .line 599
    invoke-interface {v9, v7, v1, v8}, La4/z;->b(Landroid/net/Uri;Lj4/h;Z)Z

    .line 600
    .line 601
    .line 602
    goto :goto_24a

    .line 603
    :cond_25a
    iget-object v1, v0, La4/d;->w:La4/p;

    .line 604
    .line 605
    iget-object v6, v1, La4/p;->v:La4/o;

    .line 606
    .line 607
    iget-wide v8, v1, La4/p;->m:J

    .line 608
    .line 609
    iget-boolean v6, v6, La4/o;->e:Z

    .line 610
    .line 611
    const-wide/16 v10, 0x2

    .line 612
    .line 613
    if-nez v6, :cond_26d

    .line 614
    .line 615
    if-eq v1, v2, :cond_26b

    .line 616
    .line 617
    :goto_268
    move-wide/from16 v38, v8

    .line 618
    .line 619
    goto :goto_280

    .line 620
    :cond_26b
    div-long/2addr v8, v10

    .line 621
    goto :goto_268

    .line 622
    :cond_26d
    if-ne v1, v2, :cond_280

    .line 623
    .line 624
    iget-wide v1, v1, La4/p;->n:J

    .line 625
    .line 626
    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    cmp-long v6, v1, v12

    .line 632
    .line 633
    if-eqz v6, :cond_27e

    .line 634
    .line 635
    div-long/2addr v1, v10

    .line 636
    move-wide/from16 v38, v1

    .line 637
    .line 638
    goto :goto_280

    .line 639
    :cond_27e
    div-long/2addr v8, v10

    .line 640
    goto :goto_268

    .line 641
    :cond_280
    :goto_280
    invoke-static/range {v38 .. v39}, Ln3/l0;->g0(J)J

    .line 642
    .line 643
    .line 644
    move-result-wide v1

    .line 645
    add-long/2addr v1, v3

    .line 646
    move-object/from16 v3, p2

    .line 647
    .line 648
    iget-wide v3, v3, Lf4/u;->f:J

    .line 649
    .line 650
    sub-long/2addr v1, v3

    .line 651
    iput-wide v1, v0, La4/d;->J:J

    .line 652
    .line 653
    iget-object v1, v0, La4/d;->w:La4/p;

    .line 654
    .line 655
    iget-boolean v1, v1, La4/p;->o:Z

    .line 656
    .line 657
    if-nez v1, :cond_2a5

    .line 658
    .line 659
    iget-object v1, v5, La4/f;->T:Landroid/net/Uri;

    .line 660
    .line 661
    invoke-virtual {v7, v1}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 662
    .line 663
    .line 664
    move-result v1

    .line 665
    if-nez v1, :cond_29e

    .line 666
    .line 667
    iget-boolean v1, v0, La4/d;->N:Z

    .line 668
    .line 669
    if-eqz v1, :cond_2a5

    .line 670
    .line 671
    :cond_29e
    invoke-virtual {v0}, La4/d;->a()Landroid/net/Uri;

    .line 672
    .line 673
    .line 674
    move-result-object v1

    .line 675
    invoke-virtual {v0, v1}, La4/d;->d(Landroid/net/Uri;)V

    .line 676
    .line 677
    .line 678
    :cond_2a5
    return-void
.end method

.method public final h(Lj4/k;JJI)V
    .registers 23

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    check-cast v0, Lj4/p;

    .line 4
    .line 5
    new-instance v1, Lf4/t;

    .line 6
    .line 7
    iget-wide v2, v0, Lj4/p;->a:J

    .line 8
    .line 9
    iget-object v4, v0, Lj4/p;->b:Lq3/k;

    .line 10
    .line 11
    move-wide/from16 v5, p2

    .line 12
    .line 13
    invoke-direct/range {v1 .. v6}, Lf4/t;-><init>(JLq3/k;J)V

    .line 14
    .line 15
    .line 16
    if-eqz p6, :cond_23

    .line 17
    .line 18
    iget-object v2, v0, Lj4/p;->d:Lq3/y;

    .line 19
    .line 20
    iget-object v3, v2, Lq3/y;->i:Landroid/net/Uri;

    .line 21
    .line 22
    iput-object v3, v1, Lf4/t;->d:Landroid/net/Uri;

    .line 23
    .line 24
    iget-object v3, v2, Lq3/y;->v:Ljava/util/Map;

    .line 25
    .line 26
    iput-object v3, v1, Lf4/t;->e:Ljava/util/Map;

    .line 27
    .line 28
    move-wide/from16 v3, p4

    .line 29
    .line 30
    iput-wide v3, v1, Lf4/t;->f:J

    .line 31
    .line 32
    iget-wide v2, v2, Lq3/y;->e:J

    .line 33
    .line 34
    iput-wide v2, v1, Lf4/t;->g:J

    .line 35
    .line 36
    :cond_23
    move-object/from16 v2, p0

    .line 37
    .line 38
    iget-object v3, v2, La4/d;->O:La4/f;

    .line 39
    .line 40
    iget-object v4, v3, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 41
    .line 42
    new-instance v5, Lf4/u;

    .line 43
    .line 44
    invoke-direct {v5, v1}, Lf4/u;-><init>(Lf4/t;)V

    .line 45
    .line 46
    .line 47
    iget v6, v0, Lj4/p;->c:I

    .line 48
    .line 49
    const-wide v11, -0x7fffffffffffffffL    # -4.9E-324

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    const-wide v13, -0x7fffffffffffffffL    # -4.9E-324

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    const/4 v7, -0x1

    .line 60
    const/4 v8, 0x0

    .line 61
    const/4 v9, 0x0

    .line 62
    const/4 v10, 0x0

    .line 63
    move/from16 v15, p6

    .line 64
    .line 65
    invoke-virtual/range {v4 .. v15}, Lcom/google/android/gms/internal/fido/f8;->H(Lf4/u;IILk3/w;ILjava/lang/Object;JJI)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final t(Lj4/k;JJZ)V
    .registers 22

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    check-cast v0, Lj4/p;

    .line 4
    .line 5
    new-instance v1, Lf4/t;

    .line 6
    .line 7
    iget-wide v2, v0, Lj4/p;->a:J

    .line 8
    .line 9
    iget-object v4, v0, Lj4/p;->b:Lq3/k;

    .line 10
    .line 11
    move-wide/from16 v5, p2

    .line 12
    .line 13
    invoke-direct/range {v1 .. v6}, Lf4/t;-><init>(JLq3/k;J)V

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, Lj4/p;->d:Lq3/y;

    .line 17
    .line 18
    iget-object v2, v0, Lq3/y;->i:Landroid/net/Uri;

    .line 19
    .line 20
    iput-object v2, v1, Lf4/t;->d:Landroid/net/Uri;

    .line 21
    .line 22
    iget-object v2, v0, Lq3/y;->v:Ljava/util/Map;

    .line 23
    .line 24
    iput-object v2, v1, Lf4/t;->e:Ljava/util/Map;

    .line 25
    .line 26
    move-wide/from16 v2, p4

    .line 27
    .line 28
    iput-wide v2, v1, Lf4/t;->f:J

    .line 29
    .line 30
    iget-wide v2, v0, Lq3/y;->e:J

    .line 31
    .line 32
    iput-wide v2, v1, Lf4/t;->g:J

    .line 33
    .line 34
    new-instance v5, Lf4/u;

    .line 35
    .line 36
    invoke-direct {v5, v1}, Lf4/u;-><init>(Lf4/t;)V

    .line 37
    .line 38
    .line 39
    iget-object v0, p0, La4/d;->O:La4/f;

    .line 40
    .line 41
    iget-object v1, v0, La4/f;->i:Lcl/a;

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    iget-object v4, v0, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 47
    .line 48
    const-wide v11, -0x7fffffffffffffffL    # -4.9E-324

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    const-wide v13, -0x7fffffffffffffffL    # -4.9E-324

    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    const/4 v6, 0x4

    .line 59
    const/4 v7, -0x1

    .line 60
    const/4 v8, 0x0

    .line 61
    const/4 v9, 0x0

    .line 62
    const/4 v10, 0x0

    .line 63
    invoke-virtual/range {v4 .. v14}, Lcom/google/android/gms/internal/fido/f8;->u(Lf4/u;IILk3/w;ILjava/lang/Object;JJ)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public final v(Lj4/k;JJLjava/io/IOException;I)Lgs/f;
    .registers 15

    .line 1
    check-cast p1, Lj4/p;

    .line 2
    .line 3
    new-instance v0, Lf4/t;

    .line 4
    .line 5
    iget-wide v1, p1, Lj4/p;->a:J

    .line 6
    .line 7
    iget v6, p1, Lj4/p;->c:I

    .line 8
    .line 9
    iget-object v3, p1, Lj4/p;->b:Lq3/k;

    .line 10
    .line 11
    move-wide v4, p2

    .line 12
    invoke-direct/range {v0 .. v5}, Lf4/t;-><init>(JLq3/k;J)V

    .line 13
    .line 14
    .line 15
    iget-object p1, p1, Lj4/p;->d:Lq3/y;

    .line 16
    .line 17
    iget-object p2, p1, Lq3/y;->i:Landroid/net/Uri;

    .line 18
    .line 19
    iput-object p2, v0, Lf4/t;->d:Landroid/net/Uri;

    .line 20
    .line 21
    iget-object p2, p1, Lq3/y;->v:Ljava/util/Map;

    .line 22
    .line 23
    iput-object p2, v0, Lf4/t;->e:Ljava/util/Map;

    .line 24
    .line 25
    iput-wide p4, v0, Lf4/t;->f:J

    .line 26
    .line 27
    iget-wide p2, p1, Lq3/y;->e:J

    .line 28
    .line 29
    iput-wide p2, v0, Lf4/t;->g:J

    .line 30
    .line 31
    new-instance p2, Lf4/u;

    .line 32
    .line 33
    invoke-direct {p2, v0}, Lf4/u;-><init>(Lf4/t;)V

    .line 34
    .line 35
    .line 36
    iget-object p1, p1, Lq3/y;->i:Landroid/net/Uri;

    .line 37
    .line 38
    const-string p3, "_HLS_msn"

    .line 39
    .line 40
    invoke-virtual {p1, p3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    const/4 p3, 0x1

    .line 45
    const/4 p4, 0x0

    .line 46
    if-eqz p1, :cond_31

    .line 47
    .line 48
    move p1, p3

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move p1, p4

    .line 51
    :goto_32
    instance-of p5, p6, La4/u;

    .line 52
    .line 53
    sget-object v0, Lj4/n;->e:Lgs/f;

    .line 54
    .line 55
    iget-object v1, p0, La4/d;->d:Landroid/net/Uri;

    .line 56
    .line 57
    iget-object v2, p0, La4/d;->O:La4/f;

    .line 58
    .line 59
    if-nez p1, :cond_3e

    .line 60
    .line 61
    if-eqz p5, :cond_56

    .line 62
    .line 63
    :cond_3e
    instance-of p1, p6, Lq3/t;

    .line 64
    .line 65
    if-eqz p1, :cond_48

    .line 66
    .line 67
    move-object p1, p6

    .line 68
    check-cast p1, Lq3/t;

    .line 69
    .line 70
    iget p1, p1, Lq3/t;->i:I

    .line 71
    .line 72
    goto :goto_4b

    .line 73
    :cond_48
    const p1, 0x7fffffff

    .line 74
    .line 75
    .line 76
    :goto_4b
    if-nez p5, :cond_a8

    .line 77
    .line 78
    const/16 p5, 0x190

    .line 79
    .line 80
    if-eq p1, p5, :cond_a8

    .line 81
    .line 82
    const/16 p5, 0x1f7

    .line 83
    .line 84
    if-ne p1, p5, :cond_56

    .line 85
    .line 86
    goto :goto_a8

    .line 87
    :cond_56
    new-instance p1, Lj4/h;

    .line 88
    .line 89
    invoke-direct {p1, p7, p6}, Lj4/h;-><init>(ILjava/io/IOException;)V

    .line 90
    .line 91
    .line 92
    iget-object p5, v2, La4/f;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 93
    .line 94
    invoke-virtual {p5}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 95
    .line 96
    .line 97
    move-result-object p5

    .line 98
    move p7, p4

    .line 99
    :goto_62
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 100
    .line 101
    .line 102
    move-result v3

    .line 103
    if-eqz v3, :cond_75

    .line 104
    .line 105
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    check-cast v3, La4/z;

    .line 110
    .line 111
    invoke-interface {v3, v1, p1, p4}, La4/z;->b(Landroid/net/Uri;Lj4/h;Z)Z

    .line 112
    .line 113
    .line 114
    move-result v3

    .line 115
    xor-int/2addr v3, p3

    .line 116
    or-int/2addr p7, v3

    .line 117
    goto :goto_62

    .line 118
    :cond_75
    iget-object p5, v2, La4/f;->i:Lcl/a;

    .line 119
    .line 120
    if-eqz p7, :cond_93

    .line 121
    .line 122
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    .line 124
    .line 125
    invoke-static {p1}, Lcl/a;->X(Lj4/h;)J

    .line 126
    .line 127
    .line 128
    move-result-wide v0

    .line 129
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    cmp-long p1, v0, v3

    .line 135
    .line 136
    if-eqz p1, :cond_90

    .line 137
    .line 138
    new-instance p1, Lgs/f;

    .line 139
    .line 140
    invoke-direct {p1, p4, v0, v1, p4}, Lgs/f;-><init>(IJB)V

    .line 141
    .line 142
    .line 143
    :goto_8e
    move-object v0, p1

    .line 144
    goto :goto_93

    .line 145
    :cond_90
    sget-object p1, Lj4/n;->f:Lgs/f;

    .line 146
    .line 147
    goto :goto_8e

    .line 148
    :cond_93
    :goto_93
    iget p1, v0, Lgs/f;->a:I

    .line 149
    .line 150
    if-eqz p1, :cond_9b

    .line 151
    .line 152
    if-ne p1, p3, :cond_9a

    .line 153
    .line 154
    goto :goto_9b

    .line 155
    :cond_9a
    move p3, p4

    .line 156
    :cond_9b
    :goto_9b
    xor-int/lit8 p1, p3, 0x1

    .line 157
    .line 158
    iget-object p4, v2, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 159
    .line 160
    invoke-virtual {p4, p2, v6, p6, p1}, Lcom/google/android/gms/internal/fido/f8;->C(Lf4/u;ILjava/io/IOException;Z)V

    .line 161
    .line 162
    .line 163
    if-nez p3, :cond_a7

    .line 164
    .line 165
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    :cond_a7
    return-object v0

    .line 169
    :cond_a8
    :goto_a8
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 170
    .line 171
    .line 172
    move-result-wide p4

    .line 173
    iput-wide p4, p0, La4/d;->J:J

    .line 174
    .line 175
    invoke-virtual {p0, v1}, La4/d;->d(Landroid/net/Uri;)V

    .line 176
    .line 177
    .line 178
    iget-object p1, v2, La4/f;->x:Lcom/google/android/gms/internal/fido/f8;

    .line 179
    .line 180
    sget-object p4, Ln3/l0;->a:Ljava/lang/String;

    .line 181
    .line 182
    invoke-virtual {p1, p2, v6, p6, p3}, Lcom/google/android/gms/internal/fido/f8;->C(Lf4/u;ILjava/io/IOException;Z)V

    .line 183
    .line 184
    .line 185
    return-object v0
.end method
