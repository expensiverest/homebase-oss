###### Class a4.o (a4.o)
.class public final La4/o;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:Z

.field public final c:J

.field public final d:J

.field public final e:Z


# direct methods
.method public synthetic constructor <init>(JZJJZ)V
    .registers 9

    .line 1
    iput-wide p1, p0, La4/o;->a:J

    iput-boolean p3, p0, La4/o;->b:Z

    iput-wide p4, p0, La4/o;->c:J

    iput-wide p6, p0, La4/o;->d:J

    iput-boolean p8, p0, La4/o;->e:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
