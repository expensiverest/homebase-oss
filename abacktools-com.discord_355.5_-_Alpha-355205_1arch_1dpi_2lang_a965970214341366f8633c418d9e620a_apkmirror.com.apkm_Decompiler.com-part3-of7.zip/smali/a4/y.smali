###### Class a4.y (a4.y)
.class public interface abstract La4/y;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c()Lj4/o;
.end method

.method public abstract e(La4/s;La4/p;)Lj4/o;
.end method
