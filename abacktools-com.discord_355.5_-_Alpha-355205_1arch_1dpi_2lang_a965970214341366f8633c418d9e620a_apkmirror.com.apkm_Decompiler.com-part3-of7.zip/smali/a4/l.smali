###### Class a4.l (a4.l)
.class public final La4/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:J

.field public final c:I


# direct methods
.method public constructor <init>(Landroid/net/Uri;JI)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/l;->a:Landroid/net/Uri;

    .line 5
    .line 6
    iput-wide p2, p0, La4/l;->b:J

    .line 7
    .line 8
    iput p4, p0, La4/l;->c:I

    .line 9
    .line 10
    return-void
.end method
