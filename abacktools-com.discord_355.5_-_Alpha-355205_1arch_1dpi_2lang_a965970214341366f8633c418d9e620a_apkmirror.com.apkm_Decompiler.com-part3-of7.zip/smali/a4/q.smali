###### Class a4.q (a4.q)
.class public final La4/q;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/net/Uri;

.field public final b:Lk3/w;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/net/Uri;Lk3/w;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/q;->a:Landroid/net/Uri;

    .line 5
    .line 6
    iput-object p2, p0, La4/q;->b:Lk3/w;

    .line 7
    .line 8
    iput-object p3, p0, La4/q;->c:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, La4/q;->d:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p5, p0, La4/q;->e:Ljava/lang/String;

    .line 13
    .line 14
    return-void
.end method
