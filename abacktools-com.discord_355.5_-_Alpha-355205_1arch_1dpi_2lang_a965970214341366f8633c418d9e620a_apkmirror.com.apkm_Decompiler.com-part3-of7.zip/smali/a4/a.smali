###### Class a4.a (a4.a)
.class public final synthetic La4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lfl/f;
.implements Lmr/d;
.implements Lc5/g;
.implements Lorg/webrtc/Predicate;
.implements Lio/sentry/l5;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, La4/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static bridge synthetic c(Ljava/lang/Object;)Landroid/adservices/measurement/MeasurementManager;
    .registers 1

    .line 1
    check-cast p0, Landroid/adservices/measurement/MeasurementManager;

    return-object p0
.end method

.method public static bridge synthetic d()Landroid/graphics/Bitmap$CompressFormat;
    .registers 1

    .line 1
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->WEBP_LOSSY:Landroid/graphics/Bitmap$CompressFormat;

    return-object v0
.end method

.method public static bridge synthetic f()Landroid/graphics/Bitmap$Config;
    .registers 1

    .line 1
    sget-object v0, Landroid/graphics/Bitmap$Config;->HARDWARE:Landroid/graphics/Bitmap$Config;

    return-object v0
.end method

.method public static bridge synthetic g()Landroid/graphics/BlendMode;
    .registers 1

    .line 1
    sget-object v0, Landroid/graphics/BlendMode;->SRC_IN:Landroid/graphics/BlendMode;

    return-object v0
.end method

.method public static bridge synthetic h()Landroid/graphics/ColorSpace$Named;
    .registers 1

    .line 1
    sget-object v0, Landroid/graphics/ColorSpace$Named;->SRGB:Landroid/graphics/ColorSpace$Named;

    return-object v0
.end method

.method public static bridge synthetic i()Landroid/view/WindowInsets;
    .registers 1

    .line 1
    sget-object v0, Landroid/view/WindowInsets;->CONSUMED:Landroid/view/WindowInsets;

    return-object v0
.end method

.method public static bridge synthetic j()Ljava/lang/Class;
    .registers 1

    .line 1
    const-class v0, Landroid/adservices/measurement/MeasurementManager;

    return-object v0
.end method


# virtual methods
.method public a(IIIII)Z
    .registers 10

    .line 1
    iget v0, p0, La4/a;->d:I

    packed-switch v0, :pswitch_data_26

    const/4 v0, 0x2

    const/16 v1, 0x43

    const/16 v2, 0x49

    const/16 v3, 0x50

    if-ne p1, v0, :cond_15

    if-ne p2, v3, :cond_22

    if-ne p3, v2, :cond_22

    if-eq p4, v1, :cond_20

    goto :goto_22

    :cond_15
    const/16 p1, 0x41

    if-ne p2, p1, :cond_22

    if-ne p3, v3, :cond_22

    if-ne p4, v2, :cond_22

    if-eq p5, v1, :cond_20

    goto :goto_22

    :cond_20
    const/4 p1, 0x0

    goto :goto_23

    :cond_22
    :goto_22
    const/4 p1, 0x1

    :goto_23
    return p1

    :pswitch_24
    const/4 p1, 0x0

    return p1

    :pswitch_data_26
    .packed-switch 0xf
        :pswitch_24
    .end packed-switch
.end method

.method public apply(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    check-cast p1, Lal/a;

    .line 2
    .line 3
    const-string v0, "it"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    return p1
.end method

.method public b(Lio/sentry/e;Lio/sentry/h0;)Lio/sentry/e;
    .registers 12

    .line 1
    sget-object p2, Lcom/discord/crash_reporting/CrashReporting;->INSTANCE:Lcom/discord/crash_reporting/CrashReporting;

    .line 2
    .line 3
    const-string p2, "breadcrumb"

    .line 4
    .line 5
    invoke-static {p1, p2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sget-object p2, Lcom/discord/crash_reporting/CrashReporting;->INSTANCE:Lcom/discord/crash_reporting/CrashReporting;

    .line 9
    .line 10
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iget-object p2, p1, Lio/sentry/e;->y:Ljava/lang/String;

    .line 14
    .line 15
    if-eqz p2, :cond_f5

    .line 16
    .line 17
    const-string v0, "analytics"

    .line 18
    .line 19
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_1a

    .line 24
    .line 25
    goto/16 :goto_f5

    .line 26
    .line 27
    :cond_1a
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    const/4 v1, 0x0

    .line 32
    const-string v2, "app_lifecycle"

    .line 33
    .line 34
    sparse-switch v0, :sswitch_data_f6

    .line 35
    .line 36
    .line 37
    goto :goto_70

    .line 38
    :sswitch_25
    const-string v0, "ui.lifecycle"

    .line 39
    .line 40
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result p2

    .line 44
    if-nez p2, :cond_2e

    .line 45
    .line 46
    goto :goto_70

    .line 47
    :cond_2e
    const-string v2, "ui_lifecycle"

    .line 48
    .line 49
    :cond_30
    :goto_30
    move-object v3, v2

    .line 50
    goto :goto_75

    .line 51
    :sswitch_32
    const-string v0, "react.softexception"

    .line 52
    .line 53
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result p2

    .line 57
    if-nez p2, :cond_3b

    .line 58
    .line 59
    goto :goto_70

    .line 60
    :cond_3b
    const-string v2, "react_soft_exception"

    .line 61
    .line 62
    goto :goto_30

    .line 63
    :sswitch_3e
    const-string v0, "lifecycle"

    .line 64
    .line 65
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result p2

    .line 69
    if-nez p2, :cond_30

    .line 70
    .line 71
    goto :goto_70

    .line 72
    :sswitch_47
    const-string v0, "ForegroundService"

    .line 73
    .line 74
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result p2

    .line 78
    if-nez p2, :cond_50

    .line 79
    .line 80
    goto :goto_70

    .line 81
    :cond_50
    const-string v2, "foreground_service"

    .line 82
    .line 83
    goto :goto_30

    .line 84
    :sswitch_53
    const-string v0, "app.lifecycle"

    .line 85
    .line 86
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    if-nez p2, :cond_30

    .line 91
    .line 92
    goto :goto_70

    .line 93
    :sswitch_5c
    const-string v0, "device.event"

    .line 94
    .line 95
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result p2

    .line 99
    if-nez p2, :cond_65

    .line 100
    .line 101
    goto :goto_70

    .line 102
    :cond_65
    const-string v2, "device_event"

    .line 103
    .line 104
    goto :goto_30

    .line 105
    :sswitch_68
    const-string v0, "network.event"

    .line 106
    .line 107
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result p2

    .line 111
    if-nez p2, :cond_72

    .line 112
    .line 113
    :goto_70
    move-object v3, v1

    .line 114
    goto :goto_75

    .line 115
    :cond_72
    const-string v2, "network_capabilities_changed"

    .line 116
    .line 117
    goto :goto_30

    .line 118
    :goto_75
    if-eqz v3, :cond_f5

    .line 119
    .line 120
    new-instance v7, Ljava/util/LinkedHashMap;

    .line 121
    .line 122
    invoke-direct {v7}, Ljava/util/LinkedHashMap;-><init>()V

    .line 123
    .line 124
    .line 125
    const-string p2, "type"

    .line 126
    .line 127
    iget-object v0, p1, Lio/sentry/e;->w:Ljava/lang/String;

    .line 128
    .line 129
    invoke-interface {v7, p2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    iget-object p2, p1, Lio/sentry/e;->K:Lio/sentry/a5;

    .line 133
    .line 134
    if-eqz p2, :cond_98

    .line 135
    .line 136
    invoke-virtual {p2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p2

    .line 140
    if-eqz p2, :cond_98

    .line 141
    .line 142
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 143
    .line 144
    invoke-virtual {p2, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    const-string p2, "toLowerCase(...)"

    .line 149
    .line 150
    invoke-static {v1, p2}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    :cond_98
    const-string p2, "level"

    .line 154
    .line 155
    invoke-interface {v7, p2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    const-string p2, "message"

    .line 159
    .line 160
    iget-object v0, p1, Lio/sentry/e;->v:Ljava/lang/String;

    .line 161
    .line 162
    invoke-interface {v7, p2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    iget-object p2, p1, Lio/sentry/e;->x:Ljava/util/concurrent/ConcurrentHashMap;

    .line 166
    .line 167
    const-string v0, "getData(...)"

    .line 168
    .line 169
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 173
    .line 174
    .line 175
    move-result-object p2

    .line 176
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 177
    .line 178
    .line 179
    move-result-object p2

    .line 180
    :goto_b3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 181
    .line 182
    .line 183
    move-result v0

    .line 184
    if-eqz v0, :cond_cd

    .line 185
    .line 186
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    check-cast v0, Ljava/util/Map$Entry;

    .line 191
    .line 192
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v1

    .line 196
    check-cast v1, Ljava/lang/String;

    .line 197
    .line 198
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    invoke-interface {v7, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    goto :goto_b3

    .line 206
    :cond_cd
    iget-object v6, p1, Lio/sentry/e;->v:Ljava/lang/String;

    .line 207
    .line 208
    invoke-virtual {p1}, Lio/sentry/e;->b()Ljava/util/Date;

    .line 209
    .line 210
    .line 211
    move-result-object p2

    .line 212
    if-eqz p2, :cond_db

    .line 213
    .line 214
    invoke-virtual {p2}, Ljava/util/Date;->getTime()J

    .line 215
    .line 216
    .line 217
    move-result-wide v0

    .line 218
    :goto_d9
    move-wide v4, v0

    .line 219
    goto :goto_e0

    .line 220
    :cond_db
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 221
    .line 222
    .line 223
    move-result-wide v0

    .line 224
    goto :goto_d9

    .line 225
    :goto_e0
    const-string p2, "ZOOMED"

    .line 226
    .line 227
    invoke-static {p2}, Ls1/e;->t(Ljava/lang/Object;)Ljava/util/List;

    .line 228
    .line 229
    .line 230
    move-result-object v8

    .line 231
    :try_start_e6
    invoke-static/range {v3 .. v8}, Lcom/discord/crash_reporting/s;->a(Ljava/lang/String;JLjava/lang/String;Ljava/util/Map;Ljava/util/List;)V
    :try_end_e9
    .catchall {:try_start_e6 .. :try_end_e9} :catchall_ea

    .line 232
    .line 233
    .line 234
    return-object p1

    .line 235
    :catchall_ea
    move-exception v0

    .line 236
    move-object p2, v0

    .line 237
    sget-object v0, Lnf/a;->a:Lnf/a;

    .line 238
    .line 239
    const-string v0, "SentryBreadcrumb"

    .line 240
    .line 241
    const-string v1, "Failed to append breadcrumb to TelemetryRing"

    .line 242
    .line 243
    invoke-static {v0, v1, p2}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 244
    .line 245
    .line 246
    :cond_f5
    :goto_f5
    return-object p1

    .line 247
    :sswitch_data_f6
    .sparse-switch
        -0x78662126 -> :sswitch_68
        -0x77461afe -> :sswitch_5c
        -0x4b66c023 -> :sswitch_53
        -0x47b12c2e -> :sswitch_47
        -0x12051896 -> :sswitch_3e
        0x1412f536 -> :sswitch_32
        0x692b2090 -> :sswitch_25
    .end sparse-switch
.end method

.method public e(Landroid/os/Bundle;)Lmr/e;
    .registers 23

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    sget-object v1, Lbt/b;->U:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_d

    .line 11
    .line 12
    move-object v4, v1

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    move-object v4, v2

    .line 15
    :goto_e
    sget-object v1, Lbt/b;->V:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getSerializable(Ljava/lang/String;)Ljava/io/Serializable;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Landroid/text/Layout$Alignment;

    .line 22
    .line 23
    if-eqz v1, :cond_1a

    .line 24
    .line 25
    move-object v5, v1

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    move-object v5, v2

    .line 28
    :goto_1b
    sget-object v1, Lbt/b;->W:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getSerializable(Ljava/lang/String;)Ljava/io/Serializable;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    check-cast v1, Landroid/text/Layout$Alignment;

    .line 35
    .line 36
    if-eqz v1, :cond_27

    .line 37
    .line 38
    move-object v6, v1

    .line 39
    goto :goto_28

    .line 40
    :cond_27
    move-object v6, v2

    .line 41
    :goto_28
    sget-object v1, Lbt/b;->X:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    check-cast v1, Landroid/graphics/Bitmap;

    .line 48
    .line 49
    if-eqz v1, :cond_34

    .line 50
    .line 51
    move-object v7, v1

    .line 52
    goto :goto_35

    .line 53
    :cond_34
    move-object v7, v2

    .line 54
    :goto_35
    sget-object v1, Lbt/b;->Y:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    const v3, -0x800001

    .line 61
    .line 62
    .line 63
    if-eqz v2, :cond_52

    .line 64
    .line 65
    sget-object v2, Lbt/b;->Z:Ljava/lang/String;

    .line 66
    .line 67
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 68
    .line 69
    .line 70
    move-result v9

    .line 71
    if-eqz v9, :cond_52

    .line 72
    .line 73
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    move v9, v2

    .line 82
    goto :goto_55

    .line 83
    :cond_52
    move v1, v3

    .line 84
    const/high16 v9, -0x80000000

    .line 85
    .line 86
    :goto_55
    sget-object v2, Lbt/b;->a0:Ljava/lang/String;

    .line 87
    .line 88
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 89
    .line 90
    .line 91
    move-result v10

    .line 92
    if-eqz v10, :cond_63

    .line 93
    .line 94
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    move v10, v2

    .line 99
    goto :goto_65

    .line 100
    :cond_63
    const/high16 v10, -0x80000000

    .line 101
    .line 102
    :goto_65
    sget-object v2, Lbt/b;->b0:Ljava/lang/String;

    .line 103
    .line 104
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 105
    .line 106
    .line 107
    move-result v11

    .line 108
    if-eqz v11, :cond_73

    .line 109
    .line 110
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    move v11, v2

    .line 115
    goto :goto_74

    .line 116
    :cond_73
    move v11, v3

    .line 117
    :goto_74
    sget-object v2, Lbt/b;->c0:Ljava/lang/String;

    .line 118
    .line 119
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 120
    .line 121
    .line 122
    move-result v12

    .line 123
    if-eqz v12, :cond_82

    .line 124
    .line 125
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 126
    .line 127
    .line 128
    move-result v2

    .line 129
    move v12, v2

    .line 130
    goto :goto_84

    .line 131
    :cond_82
    const/high16 v12, -0x80000000

    .line 132
    .line 133
    :goto_84
    sget-object v2, Lbt/b;->e0:Ljava/lang/String;

    .line 134
    .line 135
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 136
    .line 137
    .line 138
    move-result v13

    .line 139
    if-eqz v13, :cond_9e

    .line 140
    .line 141
    sget-object v13, Lbt/b;->d0:Ljava/lang/String;

    .line 142
    .line 143
    invoke-virtual {v0, v13}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 144
    .line 145
    .line 146
    move-result v14

    .line 147
    if-eqz v14, :cond_9e

    .line 148
    .line 149
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    invoke-virtual {v0, v13}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 154
    .line 155
    .line 156
    move-result v13

    .line 157
    move v14, v2

    .line 158
    goto :goto_a1

    .line 159
    :cond_9e
    move v14, v3

    .line 160
    const/high16 v13, -0x80000000

    .line 161
    .line 162
    :goto_a1
    sget-object v2, Lbt/b;->f0:Ljava/lang/String;

    .line 163
    .line 164
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 165
    .line 166
    .line 167
    move-result v15

    .line 168
    if-eqz v15, :cond_af

    .line 169
    .line 170
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 171
    .line 172
    .line 173
    move-result v2

    .line 174
    move v15, v2

    .line 175
    goto :goto_b0

    .line 176
    :cond_af
    move v15, v3

    .line 177
    :goto_b0
    sget-object v2, Lbt/b;->g0:Ljava/lang/String;

    .line 178
    .line 179
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 180
    .line 181
    .line 182
    move-result v16

    .line 183
    if-eqz v16, :cond_bc

    .line 184
    .line 185
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    :cond_bc
    move/from16 v16, v3

    .line 190
    .line 191
    sget-object v2, Lbt/b;->h0:Ljava/lang/String;

    .line 192
    .line 193
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 194
    .line 195
    .line 196
    move-result v3

    .line 197
    const/4 v8, 0x0

    .line 198
    if-eqz v3, :cond_cf

    .line 199
    .line 200
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 201
    .line 202
    .line 203
    move-result v2

    .line 204
    const/4 v3, 0x1

    .line 205
    :goto_cc
    move/from16 v18, v2

    .line 206
    .line 207
    goto :goto_d3

    .line 208
    :cond_cf
    const/high16 v2, -0x1000000

    .line 209
    .line 210
    move v3, v8

    .line 211
    goto :goto_cc

    .line 212
    :goto_d3
    sget-object v2, Lbt/b;->i0:Ljava/lang/String;

    .line 213
    .line 214
    invoke-virtual {v0, v2, v8}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 215
    .line 216
    .line 217
    move-result v2

    .line 218
    if-nez v2, :cond_dc

    .line 219
    .line 220
    goto :goto_dd

    .line 221
    :cond_dc
    move v8, v3

    .line 222
    :goto_dd
    sget-object v2, Lbt/b;->j0:Ljava/lang/String;

    .line 223
    .line 224
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 225
    .line 226
    .line 227
    move-result v3

    .line 228
    if-eqz v3, :cond_ec

    .line 229
    .line 230
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 231
    .line 232
    .line 233
    move-result v2

    .line 234
    move/from16 v19, v2

    .line 235
    .line 236
    goto :goto_ee

    .line 237
    :cond_ec
    const/high16 v19, -0x80000000

    .line 238
    .line 239
    :goto_ee
    sget-object v2, Lbt/b;->k0:Ljava/lang/String;

    .line 240
    .line 241
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 242
    .line 243
    .line 244
    move-result v3

    .line 245
    if-eqz v3, :cond_fd

    .line 246
    .line 247
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 248
    .line 249
    .line 250
    move-result v0

    .line 251
    :goto_fa
    move/from16 v20, v0

    .line 252
    .line 253
    goto :goto_ff

    .line 254
    :cond_fd
    const/4 v0, 0x0

    .line 255
    goto :goto_fa

    .line 256
    :goto_ff
    new-instance v3, Lbt/b;

    .line 257
    .line 258
    move/from16 v17, v8

    .line 259
    .line 260
    move v8, v1

    .line 261
    invoke-direct/range {v3 .. v20}, Lbt/b;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFZIIF)V

    .line 262
    .line 263
    .line 264
    return-object v3
.end method

.method public test(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    check-cast p1, Landroid/media/MediaCodecInfo;

    invoke-static {p1}, Lco/discord/media_engine/DiscordVideoEncoderFactory;->a(Landroid/media/MediaCodecInfo;)Z

    move-result p1

    return p1
.end method
