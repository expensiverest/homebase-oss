###### Class a4.h (a4.h)
.class public final synthetic La4/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, La4/h;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 9

    .line 1
    iget v0, p0, La4/h;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, -0x1

    .line 5
    sget-object v3, Lhx/a0;->a:Lhx/y;

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    packed-switch v0, :pswitch_data_3b6

    .line 9
    .line 10
    .line 11
    check-cast p1, Lnt/m;

    .line 12
    .line 13
    check-cast p2, Lnt/m;

    .line 14
    .line 15
    iget v0, p2, Lnt/m;->a:I

    .line 16
    .line 17
    iget v1, p1, Lnt/m;->a:I

    .line 18
    .line 19
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_19

    .line 24
    .line 25
    goto :goto_2c

    .line 26
    :cond_19
    iget-object v0, p2, Lnt/m;->c:Ljava/lang/String;

    .line 27
    .line 28
    iget-object v1, p1, Lnt/m;->c:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_24

    .line 35
    .line 36
    goto :goto_2c

    .line 37
    :cond_24
    iget-object p2, p2, Lnt/m;->d:Ljava/lang/String;

    .line 38
    .line 39
    iget-object p1, p1, Lnt/m;->d:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {p2, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    :goto_2c
    return v0

    .line 46
    :pswitch_2d
    check-cast p1, Lnt/m;

    .line 47
    .line 48
    check-cast p2, Lnt/m;

    .line 49
    .line 50
    iget v0, p2, Lnt/m;->b:I

    .line 51
    .line 52
    iget v1, p1, Lnt/m;->b:I

    .line 53
    .line 54
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_3c

    .line 59
    .line 60
    goto :goto_4f

    .line 61
    :cond_3c
    iget-object v0, p1, Lnt/m;->c:Ljava/lang/String;

    .line 62
    .line 63
    iget-object v1, p2, Lnt/m;->c:Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_47

    .line 70
    .line 71
    goto :goto_4f

    .line 72
    :cond_47
    iget-object p1, p1, Lnt/m;->d:Ljava/lang/String;

    .line 73
    .line 74
    iget-object p2, p2, Lnt/m;->d:Ljava/lang/String;

    .line 75
    .line 76
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    :goto_4f
    return v0

    .line 81
    :pswitch_50
    check-cast p1, Lmt/n;

    .line 82
    .line 83
    check-cast p2, Lmt/n;

    .line 84
    .line 85
    iget-boolean v0, p1, Lmt/n;->w:Z

    .line 86
    .line 87
    iget v1, p1, Lmt/n;->K:I

    .line 88
    .line 89
    if-eqz v0, :cond_61

    .line 90
    .line 91
    iget-boolean v0, p1, Lmt/n;->J:Z

    .line 92
    .line 93
    if-eqz v0, :cond_61

    .line 94
    .line 95
    sget-object v0, Lmt/o;->k:Lhx/u1;

    .line 96
    .line 97
    goto :goto_67

    .line 98
    :cond_61
    sget-object v0, Lmt/o;->k:Lhx/u1;

    .line 99
    .line 100
    invoke-virtual {v0}, Lhx/u1;->c()Lhx/u1;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    :goto_67
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    iget v4, p2, Lmt/n;->K:I

    .line 109
    .line 110
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    iget-object v5, p1, Lmt/n;->x:Lmt/h;

    .line 115
    .line 116
    iget-boolean v5, v5, Lmt/w;->Y:Z

    .line 117
    .line 118
    if-eqz v5, :cond_7e

    .line 119
    .line 120
    sget-object v5, Lmt/o;->k:Lhx/u1;

    .line 121
    .line 122
    invoke-virtual {v5}, Lhx/u1;->c()Lhx/u1;

    .line 123
    .line 124
    .line 125
    move-result-object v5

    .line 126
    goto :goto_80

    .line 127
    :cond_7e
    sget-object v5, Lmt/o;->l:Lhx/u1;

    .line 128
    .line 129
    :goto_80
    invoke-virtual {v3, v2, v4, v5}, Lhx/y;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    iget p1, p1, Lmt/n;->L:I

    .line 134
    .line 135
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    iget v3, p2, Lmt/n;->L:I

    .line 140
    .line 141
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    invoke-virtual {v2, p1, v3, v0}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    iget p2, p2, Lmt/n;->K:I

    .line 154
    .line 155
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 156
    .line 157
    .line 158
    move-result-object p2

    .line 159
    invoke-virtual {p1, v1, p2, v0}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    invoke-virtual {p1}, Lhx/a0;->e()I

    .line 164
    .line 165
    .line 166
    move-result p1

    .line 167
    return p1

    .line 168
    :pswitch_a7
    check-cast p1, Lmt/n;

    .line 169
    .line 170
    check-cast p2, Lmt/n;

    .line 171
    .line 172
    invoke-static {p1, p2}, Lmt/n;->c(Lmt/n;Lmt/n;)I

    .line 173
    .line 174
    .line 175
    move-result p1

    .line 176
    return p1

    .line 177
    :pswitch_b0
    check-cast p1, Ljava/util/List;

    .line 178
    .line 179
    check-cast p2, Ljava/util/List;

    .line 180
    .line 181
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    check-cast p1, Lmt/k;

    .line 186
    .line 187
    invoke-interface {p2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object p2

    .line 191
    check-cast p2, Lmt/k;

    .line 192
    .line 193
    invoke-virtual {p1, p2}, Lmt/k;->c(Lmt/k;)I

    .line 194
    .line 195
    .line 196
    move-result p1

    .line 197
    return p1

    .line 198
    :pswitch_c5
    check-cast p1, Ljava/util/List;

    .line 199
    .line 200
    check-cast p2, Ljava/util/List;

    .line 201
    .line 202
    invoke-static {p1}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    check-cast p1, Lmt/e;

    .line 207
    .line 208
    invoke-static {p2}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object p2

    .line 212
    check-cast p2, Lmt/e;

    .line 213
    .line 214
    invoke-virtual {p1, p2}, Lmt/e;->c(Lmt/e;)I

    .line 215
    .line 216
    .line 217
    move-result p1

    .line 218
    return p1

    .line 219
    :pswitch_da
    check-cast p1, Ljava/util/List;

    .line 220
    .line 221
    check-cast p2, Ljava/util/List;

    .line 222
    .line 223
    new-instance v0, La4/h;

    .line 224
    .line 225
    const/16 v1, 0x1a

    .line 226
    .line 227
    invoke-direct {v0, v1}, La4/h;-><init>(I)V

    .line 228
    .line 229
    .line 230
    invoke-static {p1, v0}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    check-cast v0, Lmt/n;

    .line 235
    .line 236
    new-instance v2, La4/h;

    .line 237
    .line 238
    invoke-direct {v2, v1}, La4/h;-><init>(I)V

    .line 239
    .line 240
    .line 241
    invoke-static {p2, v2}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    check-cast v1, Lmt/n;

    .line 246
    .line 247
    invoke-static {v0, v1}, Lmt/n;->c(Lmt/n;Lmt/n;)I

    .line 248
    .line 249
    .line 250
    move-result v0

    .line 251
    invoke-static {v0}, Lhx/y;->f(I)Lhx/a0;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 256
    .line 257
    .line 258
    move-result v1

    .line 259
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 260
    .line 261
    .line 262
    move-result v2

    .line 263
    invoke-virtual {v0, v1, v2}, Lhx/a0;->a(II)Lhx/a0;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    new-instance v1, La4/h;

    .line 268
    .line 269
    const/16 v2, 0x1b

    .line 270
    .line 271
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 272
    .line 273
    .line 274
    invoke-static {p1, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    check-cast p1, Lmt/n;

    .line 279
    .line 280
    new-instance v1, La4/h;

    .line 281
    .line 282
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 283
    .line 284
    .line 285
    invoke-static {p2, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    move-result-object p2

    .line 289
    check-cast p2, Lmt/n;

    .line 290
    .line 291
    new-instance v1, La4/h;

    .line 292
    .line 293
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v0, p1, p2, v1}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 297
    .line 298
    .line 299
    move-result-object p1

    .line 300
    invoke-virtual {p1}, Lhx/a0;->e()I

    .line 301
    .line 302
    .line 303
    move-result p1

    .line 304
    return p1

    .line 305
    :pswitch_130
    check-cast p1, Ljava/lang/Integer;

    .line 306
    .line 307
    check-cast p2, Ljava/lang/Integer;

    .line 308
    .line 309
    sget-object p1, Lmt/o;->k:Lhx/u1;

    .line 310
    .line 311
    return v4

    .line 312
    :pswitch_137
    check-cast p1, Ljava/lang/Integer;

    .line 313
    .line 314
    check-cast p2, Ljava/lang/Integer;

    .line 315
    .line 316
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 317
    .line 318
    .line 319
    move-result v0

    .line 320
    if-ne v0, v2, :cond_14b

    .line 321
    .line 322
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 323
    .line 324
    .line 325
    move-result p1

    .line 326
    if-ne p1, v2, :cond_149

    .line 327
    .line 328
    move v1, v4

    .line 329
    goto :goto_15c

    .line 330
    :cond_149
    move v1, v2

    .line 331
    goto :goto_15c

    .line 332
    :cond_14b
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 333
    .line 334
    .line 335
    move-result v0

    .line 336
    if-ne v0, v2, :cond_152

    .line 337
    .line 338
    goto :goto_15c

    .line 339
    :cond_152
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 340
    .line 341
    .line 342
    move-result p1

    .line 343
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 344
    .line 345
    .line 346
    move-result p2

    .line 347
    sub-int v1, p1, p2

    .line 348
    .line 349
    :goto_15c
    return v1

    .line 350
    :pswitch_15d
    check-cast p1, Lmr/i0;

    .line 351
    .line 352
    check-cast p2, Lmr/i0;

    .line 353
    .line 354
    iget p2, p2, Lmr/i0;->J:I

    .line 355
    .line 356
    iget p1, p1, Lmr/i0;->J:I

    .line 357
    .line 358
    sub-int/2addr p2, p1

    .line 359
    return p2

    .line 360
    :pswitch_167
    check-cast p1, Lm5/d;

    .line 361
    .line 362
    check-cast p2, Lm5/d;

    .line 363
    .line 364
    iget p2, p2, Lm5/d;->b:I

    .line 365
    .line 366
    iget p1, p1, Lm5/d;->b:I

    .line 367
    .line 368
    invoke-static {p2, p1}, Ljava/lang/Integer;->compare(II)I

    .line 369
    .line 370
    .line 371
    move-result p1

    .line 372
    return p1

    .line 373
    :pswitch_174
    check-cast p1, Llt/c;

    .line 374
    .line 375
    check-cast p2, Llt/c;

    .line 376
    .line 377
    iget-wide v0, p1, Llt/c;->b:J

    .line 378
    .line 379
    iget-wide p1, p2, Llt/c;->b:J

    .line 380
    .line 381
    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->compare(JJ)I

    .line 382
    .line 383
    .line 384
    move-result p1

    .line 385
    return p1

    .line 386
    :pswitch_181
    check-cast p1, Llt/d;

    .line 387
    .line 388
    check-cast p2, Llt/d;

    .line 389
    .line 390
    iget-object p1, p1, Llt/d;->a:Llt/e;

    .line 391
    .line 392
    iget p1, p1, Llt/e;->b:I

    .line 393
    .line 394
    iget-object p2, p2, Llt/d;->a:Llt/e;

    .line 395
    .line 396
    iget p2, p2, Llt/e;->b:I

    .line 397
    .line 398
    invoke-static {p1, p2}, Ljava/lang/Integer;->compare(II)I

    .line 399
    .line 400
    .line 401
    move-result p1

    .line 402
    return p1

    .line 403
    :pswitch_192
    check-cast p1, Lj4/q;

    .line 404
    .line 405
    check-cast p2, Lj4/q;

    .line 406
    .line 407
    iget p1, p1, Lj4/q;->c:F

    .line 408
    .line 409
    iget p2, p2, Lj4/q;->c:F

    .line 410
    .line 411
    invoke-static {p1, p2}, Ljava/lang/Float;->compare(FF)I

    .line 412
    .line 413
    .line 414
    move-result p1

    .line 415
    return p1

    .line 416
    :pswitch_19f
    check-cast p1, Lj4/q;

    .line 417
    .line 418
    check-cast p2, Lj4/q;

    .line 419
    .line 420
    iget p1, p1, Lj4/q;->a:I

    .line 421
    .line 422
    iget p2, p2, Lj4/q;->a:I

    .line 423
    .line 424
    sub-int/2addr p1, p2

    .line 425
    return p1

    .line 426
    :pswitch_1a9
    check-cast p1, Ljava/io/File;

    .line 427
    .line 428
    check-cast p2, Ljava/io/File;

    .line 429
    .line 430
    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    .line 431
    .line 432
    .line 433
    move-result-wide v0

    .line 434
    invoke-virtual {p2}, Ljava/io/File;->lastModified()J

    .line 435
    .line 436
    .line 437
    move-result-wide p1

    .line 438
    invoke-static {v0, v1, p1, p2}, Ljava/lang/Long;->compare(JJ)I

    .line 439
    .line 440
    .line 441
    move-result p1

    .line 442
    return p1

    .line 443
    :pswitch_1ba
    check-cast p1, Lio/sentry/h1;

    .line 444
    .line 445
    check-cast p2, Lio/sentry/h1;

    .line 446
    .line 447
    if-ne p1, p2, :cond_1c1

    .line 448
    .line 449
    goto :goto_1e8

    .line 450
    :cond_1c1
    invoke-interface {p1}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 451
    .line 452
    .line 453
    move-result-object v0

    .line 454
    invoke-interface {p2}, Lio/sentry/h1;->s()Lio/sentry/l4;

    .line 455
    .line 456
    .line 457
    move-result-object v1

    .line 458
    invoke-virtual {v0, v1}, Lio/sentry/l4;->a(Lio/sentry/l4;)I

    .line 459
    .line 460
    .line 461
    move-result v4

    .line 462
    if-eqz v4, :cond_1d0

    .line 463
    .line 464
    goto :goto_1e8

    .line 465
    :cond_1d0
    invoke-interface {p1}, Lio/sentry/h1;->o()Lio/sentry/m6;

    .line 466
    .line 467
    .line 468
    move-result-object p1

    .line 469
    iget-object p1, p1, Lio/sentry/m6;->e:Lio/sentry/o6;

    .line 470
    .line 471
    invoke-virtual {p1}, Lio/sentry/o6;->toString()Ljava/lang/String;

    .line 472
    .line 473
    .line 474
    move-result-object p1

    .line 475
    invoke-interface {p2}, Lio/sentry/h1;->o()Lio/sentry/m6;

    .line 476
    .line 477
    .line 478
    move-result-object p2

    .line 479
    iget-object p2, p2, Lio/sentry/m6;->e:Lio/sentry/o6;

    .line 480
    .line 481
    invoke-virtual {p2}, Lio/sentry/o6;->toString()Ljava/lang/String;

    .line 482
    .line 483
    .line 484
    move-result-object p2

    .line 485
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 486
    .line 487
    .line 488
    move-result v4

    .line 489
    :goto_1e8
    return v4

    .line 490
    :pswitch_1e9
    check-cast p1, Li4/n;

    .line 491
    .line 492
    check-cast p2, Li4/n;

    .line 493
    .line 494
    iget-boolean v0, p1, Li4/n;->w:Z

    .line 495
    .line 496
    iget v1, p1, Li4/n;->L:I

    .line 497
    .line 498
    if-eqz v0, :cond_1fa

    .line 499
    .line 500
    iget-boolean v0, p1, Li4/n;->J:Z

    .line 501
    .line 502
    if-eqz v0, :cond_1fa

    .line 503
    .line 504
    sget-object v0, Li4/o;->k:Lhx/u1;

    .line 505
    .line 506
    goto :goto_200

    .line 507
    :cond_1fa
    sget-object v0, Li4/o;->k:Lhx/u1;

    .line 508
    .line 509
    invoke-virtual {v0}, Lhx/u1;->c()Lhx/u1;

    .line 510
    .line 511
    .line 512
    move-result-object v0

    .line 513
    :goto_200
    iget-object v2, p1, Li4/n;->x:Li4/j;

    .line 514
    .line 515
    iget-boolean v2, v2, Lk3/t1;->F:Z

    .line 516
    .line 517
    if-eqz v2, :cond_21a

    .line 518
    .line 519
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 520
    .line 521
    .line 522
    move-result-object v2

    .line 523
    iget v4, p2, Li4/n;->L:I

    .line 524
    .line 525
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 526
    .line 527
    .line 528
    move-result-object v4

    .line 529
    sget-object v5, Li4/o;->k:Lhx/u1;

    .line 530
    .line 531
    invoke-virtual {v5}, Lhx/u1;->c()Lhx/u1;

    .line 532
    .line 533
    .line 534
    move-result-object v5

    .line 535
    invoke-virtual {v3, v2, v4, v5}, Lhx/y;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 536
    .line 537
    .line 538
    move-result-object v3

    .line 539
    :cond_21a
    iget-boolean v2, p1, Li4/n;->a0:Z

    .line 540
    .line 541
    iget-boolean v4, p2, Li4/n;->a0:Z

    .line 542
    .line 543
    invoke-virtual {v3, v2, v4}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 544
    .line 545
    .line 546
    move-result-object v2

    .line 547
    iget v3, p1, Li4/n;->M:I

    .line 548
    .line 549
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 550
    .line 551
    .line 552
    move-result-object v3

    .line 553
    iget v4, p2, Li4/n;->M:I

    .line 554
    .line 555
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 556
    .line 557
    .line 558
    move-result-object v4

    .line 559
    invoke-virtual {v2, v3, v4, v0}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 560
    .line 561
    .line 562
    move-result-object v2

    .line 563
    iget-boolean v3, p1, Li4/n;->W:Z

    .line 564
    .line 565
    if-eqz v3, :cond_242

    .line 566
    .line 567
    iget-boolean v3, p1, Li4/n;->Y:Z

    .line 568
    .line 569
    if-eqz v3, :cond_242

    .line 570
    .line 571
    iget v3, p1, Li4/n;->Z:I

    .line 572
    .line 573
    iget v4, p2, Li4/n;->Z:I

    .line 574
    .line 575
    invoke-virtual {v2, v3, v4}, Lhx/a0;->a(II)Lhx/a0;

    .line 576
    .line 577
    .line 578
    move-result-object v2

    .line 579
    :cond_242
    iget-boolean p1, p1, Li4/n;->X:Z

    .line 580
    .line 581
    iget-boolean v3, p2, Li4/n;->X:Z

    .line 582
    .line 583
    invoke-virtual {v2, p1, v3}, Lhx/a0;->c(ZZ)Lhx/a0;

    .line 584
    .line 585
    .line 586
    move-result-object p1

    .line 587
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 588
    .line 589
    .line 590
    move-result-object v1

    .line 591
    iget p2, p2, Li4/n;->L:I

    .line 592
    .line 593
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 594
    .line 595
    .line 596
    move-result-object p2

    .line 597
    invoke-virtual {p1, v1, p2, v0}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 598
    .line 599
    .line 600
    move-result-object p1

    .line 601
    invoke-virtual {p1}, Lhx/a0;->e()I

    .line 602
    .line 603
    .line 604
    move-result p1

    .line 605
    return p1

    .line 606
    :pswitch_25d
    check-cast p1, Li4/n;

    .line 607
    .line 608
    check-cast p2, Li4/n;

    .line 609
    .line 610
    invoke-static {p1, p2}, Li4/n;->c(Li4/n;Li4/n;)I

    .line 611
    .line 612
    .line 613
    move-result p1

    .line 614
    return p1

    .line 615
    :pswitch_266
    check-cast p1, Ljava/util/List;

    .line 616
    .line 617
    check-cast p2, Ljava/util/List;

    .line 618
    .line 619
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    move-result-object p1

    .line 623
    check-cast p1, Li4/k;

    .line 624
    .line 625
    invoke-interface {p2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 626
    .line 627
    .line 628
    move-result-object p2

    .line 629
    check-cast p2, Li4/k;

    .line 630
    .line 631
    invoke-virtual {p1, p2}, Li4/k;->c(Li4/k;)I

    .line 632
    .line 633
    .line 634
    move-result p1

    .line 635
    return p1

    .line 636
    :pswitch_27b
    check-cast p1, Ljava/util/List;

    .line 637
    .line 638
    check-cast p2, Ljava/util/List;

    .line 639
    .line 640
    invoke-static {p1}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 641
    .line 642
    .line 643
    move-result-object p1

    .line 644
    check-cast p1, Li4/f;

    .line 645
    .line 646
    invoke-static {p2}, Ljava/util/Collections;->max(Ljava/util/Collection;)Ljava/lang/Object;

    .line 647
    .line 648
    .line 649
    move-result-object p2

    .line 650
    check-cast p2, Li4/f;

    .line 651
    .line 652
    invoke-virtual {p1, p2}, Li4/f;->c(Li4/f;)I

    .line 653
    .line 654
    .line 655
    move-result p1

    .line 656
    return p1

    .line 657
    :pswitch_290
    check-cast p1, Ljava/util/List;

    .line 658
    .line 659
    check-cast p2, Ljava/util/List;

    .line 660
    .line 661
    new-instance v0, La4/h;

    .line 662
    .line 663
    const/16 v1, 0xb

    .line 664
    .line 665
    invoke-direct {v0, v1}, La4/h;-><init>(I)V

    .line 666
    .line 667
    .line 668
    invoke-static {p1, v0}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 669
    .line 670
    .line 671
    move-result-object v0

    .line 672
    check-cast v0, Li4/n;

    .line 673
    .line 674
    new-instance v2, La4/h;

    .line 675
    .line 676
    invoke-direct {v2, v1}, La4/h;-><init>(I)V

    .line 677
    .line 678
    .line 679
    invoke-static {p2, v2}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    move-result-object v1

    .line 683
    check-cast v1, Li4/n;

    .line 684
    .line 685
    invoke-static {v0, v1}, Li4/n;->c(Li4/n;Li4/n;)I

    .line 686
    .line 687
    .line 688
    move-result v0

    .line 689
    invoke-static {v0}, Lhx/y;->f(I)Lhx/a0;

    .line 690
    .line 691
    .line 692
    move-result-object v0

    .line 693
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 694
    .line 695
    .line 696
    move-result v1

    .line 697
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 698
    .line 699
    .line 700
    move-result v2

    .line 701
    invoke-virtual {v0, v1, v2}, Lhx/a0;->a(II)Lhx/a0;

    .line 702
    .line 703
    .line 704
    move-result-object v0

    .line 705
    new-instance v1, La4/h;

    .line 706
    .line 707
    const/16 v2, 0xc

    .line 708
    .line 709
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 710
    .line 711
    .line 712
    invoke-static {p1, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 713
    .line 714
    .line 715
    move-result-object p1

    .line 716
    check-cast p1, Li4/n;

    .line 717
    .line 718
    new-instance v1, La4/h;

    .line 719
    .line 720
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 721
    .line 722
    .line 723
    invoke-static {p2, v1}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 724
    .line 725
    .line 726
    move-result-object p2

    .line 727
    check-cast p2, Li4/n;

    .line 728
    .line 729
    new-instance v1, La4/h;

    .line 730
    .line 731
    invoke-direct {v1, v2}, La4/h;-><init>(I)V

    .line 732
    .line 733
    .line 734
    invoke-virtual {v0, p1, p2, v1}, Lhx/a0;->b(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lhx/a0;

    .line 735
    .line 736
    .line 737
    move-result-object p1

    .line 738
    invoke-virtual {p1}, Lhx/a0;->e()I

    .line 739
    .line 740
    .line 741
    move-result p1

    .line 742
    return p1

    .line 743
    :pswitch_2e6
    check-cast p1, Ljava/util/List;

    .line 744
    .line 745
    check-cast p2, Ljava/util/List;

    .line 746
    .line 747
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 748
    .line 749
    .line 750
    move-result-object p1

    .line 751
    check-cast p1, Li4/g;

    .line 752
    .line 753
    invoke-interface {p2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 754
    .line 755
    .line 756
    move-result-object p2

    .line 757
    check-cast p2, Li4/g;

    .line 758
    .line 759
    iget p1, p1, Li4/g;->x:I

    .line 760
    .line 761
    iget p2, p2, Li4/g;->x:I

    .line 762
    .line 763
    invoke-static {p1, p2}, Ljava/lang/Integer;->compare(II)I

    .line 764
    .line 765
    .line 766
    move-result p1

    .line 767
    return p1

    .line 768
    :pswitch_2ff
    check-cast p1, Ljava/lang/Integer;

    .line 769
    .line 770
    check-cast p2, Ljava/lang/Integer;

    .line 771
    .line 772
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 773
    .line 774
    .line 775
    move-result v0

    .line 776
    if-ne v0, v2, :cond_313

    .line 777
    .line 778
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 779
    .line 780
    .line 781
    move-result p1

    .line 782
    if-ne p1, v2, :cond_311

    .line 783
    .line 784
    move v1, v4

    .line 785
    goto :goto_324

    .line 786
    :cond_311
    move v1, v2

    .line 787
    goto :goto_324

    .line 788
    :cond_313
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 789
    .line 790
    .line 791
    move-result v0

    .line 792
    if-ne v0, v2, :cond_31a

    .line 793
    .line 794
    goto :goto_324

    .line 795
    :cond_31a
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 796
    .line 797
    .line 798
    move-result p1

    .line 799
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 800
    .line 801
    .line 802
    move-result p2

    .line 803
    sub-int v1, p1, p2

    .line 804
    .line 805
    :goto_324
    return v1

    .line 806
    :pswitch_325
    check-cast p1, Lk3/w;

    .line 807
    .line 808
    check-cast p2, Lk3/w;

    .line 809
    .line 810
    iget p2, p2, Lk3/w;->k:I

    .line 811
    .line 812
    iget p1, p1, Lk3/w;->k:I

    .line 813
    .line 814
    invoke-static {p2, p1}, Ljava/lang/Integer;->compare(II)I

    .line 815
    .line 816
    .line 817
    move-result p1

    .line 818
    return p1

    .line 819
    :pswitch_332
    check-cast p1, Lcom/facebook/react/bridge/ReadableMap;

    .line 820
    .line 821
    check-cast p2, Lcom/facebook/react/bridge/ReadableMap;

    .line 822
    .line 823
    const-string v0, "time"

    .line 824
    .line 825
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 826
    .line 827
    .line 828
    move-result v1

    .line 829
    const-wide/16 v2, 0x0

    .line 830
    .line 831
    if-eqz v1, :cond_345

    .line 832
    .line 833
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 834
    .line 835
    .line 836
    move-result-wide v4

    .line 837
    goto :goto_346

    .line 838
    :cond_345
    move-wide v4, v2

    .line 839
    :goto_346
    invoke-interface {p2, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 840
    .line 841
    .line 842
    move-result p1

    .line 843
    if-eqz p1, :cond_350

    .line 844
    .line 845
    invoke-interface {p2, v0}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 846
    .line 847
    .line 848
    move-result-wide v2

    .line 849
    :cond_350
    invoke-static {v4, v5, v2, v3}, Ljava/lang/Double;->compare(DD)I

    .line 850
    .line 851
    .line 852
    move-result p1

    .line 853
    return p1

    .line 854
    :pswitch_355
    check-cast p1, Lct/d;

    .line 855
    .line 856
    check-cast p2, Lct/d;

    .line 857
    .line 858
    iget p2, p2, Lct/d;->b:I

    .line 859
    .line 860
    iget p1, p1, Lct/d;->b:I

    .line 861
    .line 862
    invoke-static {p2, p1}, Ljava/lang/Integer;->compare(II)I

    .line 863
    .line 864
    .line 865
    move-result p1

    .line 866
    return p1

    .line 867
    :pswitch_362
    check-cast p1, La6/r0;

    .line 868
    .line 869
    check-cast p2, La6/r0;

    .line 870
    .line 871
    iget v0, p2, La6/r0;->a:I

    .line 872
    .line 873
    iget v1, p1, La6/r0;->a:I

    .line 874
    .line 875
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 876
    .line 877
    .line 878
    move-result v0

    .line 879
    if-eqz v0, :cond_371

    .line 880
    .line 881
    goto :goto_384

    .line 882
    :cond_371
    iget-object v0, p2, La6/r0;->c:Ljava/lang/String;

    .line 883
    .line 884
    iget-object v1, p1, La6/r0;->c:Ljava/lang/String;

    .line 885
    .line 886
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 887
    .line 888
    .line 889
    move-result v0

    .line 890
    if-eqz v0, :cond_37c

    .line 891
    .line 892
    goto :goto_384

    .line 893
    :cond_37c
    iget-object p2, p2, La6/r0;->d:Ljava/lang/String;

    .line 894
    .line 895
    iget-object p1, p1, La6/r0;->d:Ljava/lang/String;

    .line 896
    .line 897
    invoke-virtual {p2, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 898
    .line 899
    .line 900
    move-result v0

    .line 901
    :goto_384
    return v0

    .line 902
    :pswitch_385
    check-cast p1, La6/r0;

    .line 903
    .line 904
    check-cast p2, La6/r0;

    .line 905
    .line 906
    iget v0, p2, La6/r0;->b:I

    .line 907
    .line 908
    iget v1, p1, La6/r0;->b:I

    .line 909
    .line 910
    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    .line 911
    .line 912
    .line 913
    move-result v0

    .line 914
    if-eqz v0, :cond_394

    .line 915
    .line 916
    goto :goto_3a7

    .line 917
    :cond_394
    iget-object v0, p1, La6/r0;->c:Ljava/lang/String;

    .line 918
    .line 919
    iget-object v1, p2, La6/r0;->c:Ljava/lang/String;

    .line 920
    .line 921
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 922
    .line 923
    .line 924
    move-result v0

    .line 925
    if-eqz v0, :cond_39f

    .line 926
    .line 927
    goto :goto_3a7

    .line 928
    :cond_39f
    iget-object p1, p1, La6/r0;->d:Ljava/lang/String;

    .line 929
    .line 930
    iget-object p2, p2, La6/r0;->d:Ljava/lang/String;

    .line 931
    .line 932
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 933
    .line 934
    .line 935
    move-result v0

    .line 936
    :goto_3a7
    return v0

    .line 937
    :pswitch_3a8
    check-cast p1, La4/g;

    .line 938
    .line 939
    check-cast p2, La4/g;

    .line 940
    .line 941
    iget-object p1, p1, La4/g;->a:Ljava/lang/String;

    .line 942
    .line 943
    iget-object p2, p2, La4/g;->a:Ljava/lang/String;

    .line 944
    .line 945
    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    .line 946
    .line 947
    .line 948
    move-result p1

    .line 949
    return p1

    .line 950
    nop

    .line 951
    :pswitch_data_3b6
    .packed-switch 0x0
        :pswitch_3a8
        :pswitch_385
        :pswitch_362
        :pswitch_355
        :pswitch_332
        :pswitch_325
        :pswitch_2ff
        :pswitch_2e6
        :pswitch_290
        :pswitch_27b
        :pswitch_266
        :pswitch_25d
        :pswitch_1e9
        :pswitch_1ba
        :pswitch_1a9
        :pswitch_19f
        :pswitch_192
        :pswitch_181
        :pswitch_174
        :pswitch_167
        :pswitch_15d
        :pswitch_137
        :pswitch_130
        :pswitch_da
        :pswitch_c5
        :pswitch_b0
        :pswitch_a7
        :pswitch_50
        :pswitch_2d
    .end packed-switch
.end method
