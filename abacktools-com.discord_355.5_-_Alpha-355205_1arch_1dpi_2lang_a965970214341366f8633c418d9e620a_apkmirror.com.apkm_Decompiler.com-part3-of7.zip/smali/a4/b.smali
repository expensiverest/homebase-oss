###### Class a4.b (a4.b)
.class public final La4/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La4/z;


# instance fields
.field public final synthetic d:La4/f;


# direct methods
.method public constructor <init>(La4/f;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/b;->d:La4/f;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 2

    .line 1
    iget-object v0, p0, La4/b;->d:La4/f;

    .line 2
    .line 3
    iget-object v0, v0, La4/f;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 4
    .line 5
    invoke-virtual {v0, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final b(Landroid/net/Uri;Lj4/h;Z)Z
    .registers 16

    .line 1
    iget-object p3, p0, La4/b;->d:La4/f;

    .line 2
    .line 3
    iget-object v0, p3, La4/f;->v:Ljava/util/HashMap;

    .line 4
    .line 5
    iget-object v1, p3, La4/f;->U:La4/p;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_b1

    .line 9
    .line 10
    iget-object v1, p3, La4/f;->O:Lw70/n;

    .line 11
    .line 12
    const/4 v3, 0x1

    .line 13
    if-eqz v1, :cond_14

    .line 14
    .line 15
    iget-boolean v1, v1, Lw70/n;->a:Z

    .line 16
    .line 17
    if-eqz v1, :cond_14

    .line 18
    .line 19
    move v5, v3

    .line 20
    goto :goto_15

    .line 21
    :cond_14
    move v5, v2

    .line 22
    :goto_15
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 23
    .line 24
    .line 25
    move-result-wide v6

    .line 26
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, La4/e;

    .line 31
    .line 32
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    iget-object v1, v1, La4/e;->a:La4/d0;

    .line 36
    .line 37
    iget-object v4, v1, La4/d0;->b:Ljava/util/HashMap;

    .line 38
    .line 39
    invoke-virtual {v4}, Ljava/util/HashMap;->size()I

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    iget-object v1, v1, La4/d0;->b:Ljava/util/HashMap;

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v1}, Lhx/x0;->q(Ljava/util/Collection;)Lhx/x0;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-virtual {v1}, Lhx/h0;->m()Lhx/l2;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    move-wide v8, v6

    .line 58
    move v7, v2

    .line 59
    :cond_3a
    :goto_3a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v6

    .line 63
    if-eqz v6, :cond_4f

    .line 64
    .line 65
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    check-cast v6, Landroid/net/Uri;

    .line 70
    .line 71
    invoke-virtual {p3, v6, v8, v9}, La4/f;->g(Landroid/net/Uri;J)Z

    .line 72
    .line 73
    .line 74
    move-result v6

    .line 75
    if-eqz v6, :cond_3a

    .line 76
    .line 77
    add-int/lit8 v7, v7, 0x1

    .line 78
    .line 79
    goto :goto_3a

    .line 80
    :cond_4f
    iget-object v1, p3, La4/f;->P:Lhx/m0;

    .line 81
    .line 82
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    iget-object v6, p3, La4/f;->P:Lhx/m0;

    .line 87
    .line 88
    invoke-virtual {v6, v2}, Lhx/m0;->s(I)Lhx/k0;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    move-wide v10, v8

    .line 93
    move v9, v2

    .line 94
    :cond_5d
    :goto_5d
    invoke-virtual {v6}, Lhx/a;->hasNext()Z

    .line 95
    .line 96
    .line 97
    move-result v8

    .line 98
    if-eqz v8, :cond_7d

    .line 99
    .line 100
    invoke-virtual {v6}, Lhx/a;->next()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v8

    .line 104
    check-cast v8, La4/d0;

    .line 105
    .line 106
    if-eqz v5, :cond_74

    .line 107
    .line 108
    invoke-virtual {v8}, La4/d0;->b()Landroid/net/Uri;

    .line 109
    .line 110
    .line 111
    move-result-object v8

    .line 112
    invoke-virtual {p3, v8, v10, v11}, La4/f;->g(Landroid/net/Uri;J)Z

    .line 113
    .line 114
    .line 115
    move-result v8

    .line 116
    goto :goto_78

    .line 117
    :cond_74
    invoke-virtual {p3, v8, v10, v11}, La4/f;->f(La4/d0;J)Z

    .line 118
    .line 119
    .line 120
    move-result v8

    .line 121
    :goto_78
    if-eqz v8, :cond_5d

    .line 122
    .line 123
    add-int/lit8 v9, v9, 0x1

    .line 124
    .line 125
    goto :goto_5d

    .line 126
    :cond_7d
    new-instance v6, Le6/s;

    .line 127
    .line 128
    move-object v8, v6

    .line 129
    move v6, v4

    .line 130
    move-object v4, v8

    .line 131
    move v8, v1

    .line 132
    invoke-direct/range {v4 .. v9}, Le6/s;-><init>(ZIIII)V

    .line 133
    .line 134
    .line 135
    iget-object v1, p3, La4/f;->i:Lcl/a;

    .line 136
    .line 137
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    invoke-static {v4, p2}, Lcl/a;->U(Le6/s;Lj4/h;)Lgs/f;

    .line 141
    .line 142
    .line 143
    move-result-object p2

    .line 144
    if-eqz p2, :cond_b1

    .line 145
    .line 146
    iget-wide v6, p2, Lgs/f;->b:J

    .line 147
    .line 148
    if-eqz v5, :cond_a3

    .line 149
    .line 150
    iget p2, p2, Lgs/f;->a:I

    .line 151
    .line 152
    if-ne p2, v3, :cond_a3

    .line 153
    .line 154
    iget-object p1, p3, La4/f;->O:Lw70/n;

    .line 155
    .line 156
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    invoke-virtual {p1, v6, v7}, Lw70/n;->f(J)Z

    .line 160
    .line 161
    .line 162
    move-result p1

    .line 163
    return p1

    .line 164
    :cond_a3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object p2

    .line 168
    check-cast p2, La4/e;

    .line 169
    .line 170
    if-eqz p2, :cond_b1

    .line 171
    .line 172
    const/4 p3, 0x0

    .line 173
    invoke-static {p2, p1, v6, v7, p3}, La4/e;->c(La4/e;Landroid/net/Uri;JLjava/lang/String;)Z

    .line 174
    .line 175
    .line 176
    move-result p1

    .line 177
    return p1

    .line 178
    :cond_b1
    return v2
.end method
