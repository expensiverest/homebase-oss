###### Class a4.n (a4.n)
.class public abstract La4/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public final J:Ljava/lang/String;

.field public final K:J

.field public final L:J

.field public final M:Z

.field public final d:Ljava/lang/String;

.field public final e:La4/m;

.field public final i:J

.field public final v:I

.field public final w:J

.field public final x:Lk3/r;

.field public final y:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;La4/m;JIJLk3/r;Ljava/lang/String;Ljava/lang/String;JJZ)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La4/n;->d:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, La4/n;->e:La4/m;

    .line 7
    .line 8
    iput-wide p3, p0, La4/n;->i:J

    .line 9
    .line 10
    iput p5, p0, La4/n;->v:I

    .line 11
    .line 12
    iput-wide p6, p0, La4/n;->w:J

    .line 13
    .line 14
    iput-object p8, p0, La4/n;->x:Lk3/r;

    .line 15
    .line 16
    iput-object p9, p0, La4/n;->y:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p10, p0, La4/n;->J:Ljava/lang/String;

    .line 19
    .line 20
    iput-wide p11, p0, La4/n;->K:J

    .line 21
    .line 22
    iput-wide p13, p0, La4/n;->L:J

    .line 23
    .line 24
    iput-boolean p15, p0, La4/n;->M:Z

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .registers 6

    .line 1
    check-cast p1, Ljava/lang/Long;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    iget-wide v2, p0, La4/n;->w:J

    .line 8
    .line 9
    cmp-long v0, v2, v0

    .line 10
    .line 11
    if-lez v0, :cond_e

    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    return p1

    .line 15
    :cond_e
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 16
    .line 17
    .line 18
    move-result-wide v0

    .line 19
    cmp-long p1, v2, v0

    .line 20
    .line 21
    if-gez p1, :cond_18

    .line 22
    .line 23
    const/4 p1, -0x1

    .line 24
    return p1

    .line 25
    :cond_18
    const/4 p1, 0x0

    .line 26
    return p1
.end method
