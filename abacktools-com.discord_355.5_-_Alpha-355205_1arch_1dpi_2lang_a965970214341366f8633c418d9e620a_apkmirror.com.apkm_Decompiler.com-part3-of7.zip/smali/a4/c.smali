###### Class a4.c (a4.c)
.class public final synthetic La4/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, La4/c;->d:I

    iput-object p2, p0, La4/c;->e:Ljava/lang/Object;

    iput-object p3, p0, La4/c;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, La4/c;->d:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x0

    .line 8
    packed-switch v0, :pswitch_data_416

    .line 9
    .line 10
    .line 11
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Ln3/j;

    .line 14
    .line 15
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-interface {v0, v2}, Ln3/j;->accept(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_14
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lf2/d;

    .line 24
    .line 25
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v2, Lkotlin/jvm/internal/u;

    .line 28
    .line 29
    invoke-virtual {v0}, Lf2/d;->f()Ly1/i;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object v2, v2, Lkotlin/jvm/internal/u;->d:Ljava/lang/Object;

    .line 34
    .line 35
    invoke-interface {v0, v2}, Ly1/i;->u(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_26
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v0, Lf2/d;

    .line 42
    .line 43
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v2, Ly1/p;

    .line 46
    .line 47
    invoke-virtual {v0}, Lf2/d;->f()Ly1/i;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-interface {v0, v2}, Ly1/i;->onResult(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :pswitch_36
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Lf2/d;

    .line 58
    .line 59
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v2, Lz1/o;

    .line 62
    .line 63
    invoke-virtual {v0}, Lf2/d;->f()Ly1/i;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-interface {v0, v2}, Ly1/i;->u(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :pswitch_46
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, Lf10/c;

    .line 74
    .line 75
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v2, Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {v0}, Lf10/c;->a()Landroidx/core/view/w2;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-eqz v0, :cond_5f

    .line 84
    .line 85
    const-string v3, "dark-content"

    .line 86
    .line 87
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    iget-object v0, v0, Landroidx/core/view/w2;->a:Ls1/e;

    .line 92
    .line 93
    invoke-virtual {v0, v2}, Ls1/e;->L(Z)V

    .line 94
    .line 95
    .line 96
    :cond_5f
    return-void

    .line 97
    :pswitch_60
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v0, Ly1/i;

    .line 100
    .line 101
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v2, Ly1/p;

    .line 104
    .line 105
    invoke-interface {v0, v2}, Ly1/i;->onResult(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    return-void

    .line 109
    :pswitch_6c
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast v0, Ly1/i;

    .line 112
    .line 113
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 114
    .line 115
    invoke-interface {v0, v2}, Ly1/i;->u(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :pswitch_76
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 120
    .line 121
    check-cast v0, Le/j;

    .line 122
    .line 123
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 124
    .line 125
    check-cast v2, Le/a0;

    .line 126
    .line 127
    sget v3, Le/j;->U:I

    .line 128
    .line 129
    iget-object v3, v0, Le1/h;->d:Landroidx/lifecycle/x;

    .line 130
    .line 131
    new-instance v4, Le/e;

    .line 132
    .line 133
    invoke-direct {v4, v2, v0}, Le/e;-><init>(Le/a0;Le/j;)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {v3, v4}, Landroidx/lifecycle/x;->a(Landroidx/lifecycle/u;)V

    .line 137
    .line 138
    .line 139
    return-void

    .line 140
    :pswitch_8b
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v0, Lbl/d;

    .line 143
    .line 144
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v2, Lc7/l;

    .line 147
    .line 148
    const-string v3, "this$0"

    .line 149
    .line 150
    invoke-static {v0, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    const-string v3, "$token"

    .line 154
    .line 155
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    iget-object v0, v0, Lbl/d;->i:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v0, Lz5/u;

    .line 161
    .line 162
    const/4 v3, 0x3

    .line 163
    invoke-virtual {v0, v2, v3}, Lz5/u;->Z(Lc7/l;I)V

    .line 164
    .line 165
    .line 166
    return-void

    .line 167
    :pswitch_a6
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 168
    .line 169
    check-cast v0, Ly1/i;

    .line 170
    .line 171
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast v2, Ljava/lang/Exception;

    .line 174
    .line 175
    invoke-static {v0, v2}, Landroidx/credentials/playservices/CredentialProviderPlayServicesImpl;->$r8$lambda$AS0yfz0pVQO1Ewzm5zGeHqWtm6I(Ly1/i;Ljava/lang/Exception;)V

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :pswitch_b2
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast v0, Landroid/view/View;

    .line 182
    .line 183
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast v2, Lcom/swmansion/reanimated/pseudoSelectors/d;

    .line 186
    .line 187
    invoke-static {v0, v2}, Lcom/swmansion/reanimated/pseudoSelectors/PseudoSelectorManager;->e(Landroid/view/View;Lcom/swmansion/reanimated/pseudoSelectors/d;)V

    .line 188
    .line 189
    .line 190
    return-void

    .line 191
    :pswitch_be
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v0, Landroid/view/View;

    .line 194
    .line 195
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v2, Ljava/lang/Integer;

    .line 198
    .line 199
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 200
    .line 201
    .line 202
    move-result v2

    .line 203
    invoke-virtual {v0, v2}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 204
    .line 205
    .line 206
    return-void

    .line 207
    :pswitch_ce
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v0, Lcom/margelo/nitro/nitrofetch/r0;

    .line 210
    .line 211
    iget-object v3, v1, La4/c;->i:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast v3, Lorg/chromium/net/UrlRequest;

    .line 214
    .line 215
    iput-boolean v2, v0, Lcom/margelo/nitro/nitrofetch/r0;->c:Z

    .line 216
    .line 217
    invoke-virtual {v3}, Lorg/chromium/net/UrlRequest;->cancel()V

    .line 218
    .line 219
    .line 220
    return-void

    .line 221
    :pswitch_dc
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 222
    .line 223
    check-cast v0, Lcom/margelo/nitro/nitrofetch/f0;

    .line 224
    .line 225
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v2, Ljava/nio/ByteBuffer;

    .line 228
    .line 229
    invoke-virtual {v0, v2, v4}, Lcom/margelo/nitro/nitrofetch/f0;->b(Ljava/nio/ByteBuffer;Z)V

    .line 230
    .line 231
    .line 232
    return-void

    .line 233
    :pswitch_e8
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 234
    .line 235
    check-cast v0, Lcom/google/firebase/messaging/p;

    .line 236
    .line 237
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 238
    .line 239
    check-cast v2, Lnv/h;

    .line 240
    .line 241
    :try_start_f0
    invoke-virtual {v0}, Lcom/google/firebase/messaging/p;->c()Landroid/graphics/Bitmap;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    invoke-virtual {v2, v0}, Lnv/h;->b(Ljava/lang/Object;)V
    :try_end_f7
    .catch Ljava/lang/Exception; {:try_start_f0 .. :try_end_f7} :catch_f8

    .line 246
    .line 247
    .line 248
    goto :goto_fc

    .line 249
    :catch_f8
    move-exception v0

    .line 250
    invoke-virtual {v2, v0}, Lnv/h;->a(Ljava/lang/Exception;)V

    .line 251
    .line 252
    .line 253
    :goto_fc
    return-void

    .line 254
    :pswitch_fd
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast v0, Lcom/google/firebase/messaging/FirebaseMessaging;

    .line 257
    .line 258
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 259
    .line 260
    check-cast v2, Lnv/h;

    .line 261
    .line 262
    sget-object v3, Lcom/google/firebase/messaging/FirebaseMessaging;->k:Landroidx/core/view/d0;

    .line 263
    .line 264
    :try_start_107
    invoke-virtual {v0}, Lcom/google/firebase/messaging/FirebaseMessaging;->a()Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    invoke-virtual {v2, v0}, Lnv/h;->b(Ljava/lang/Object;)V
    :try_end_10e
    .catch Ljava/lang/Exception; {:try_start_107 .. :try_end_10e} :catch_10f

    .line 269
    .line 270
    .line 271
    goto :goto_113

    .line 272
    :catch_10f
    move-exception v0

    .line 273
    invoke-virtual {v2, v0}, Lnv/h;->a(Ljava/lang/Exception;)V

    .line 274
    .line 275
    .line 276
    :goto_113
    return-void

    .line 277
    :pswitch_114
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 278
    .line 279
    move-object v2, v0

    .line 280
    check-cast v2, Lcom/facebook/react/uimanager/s0;

    .line 281
    .line 282
    iget-object v0, v1, La4/c;->i:Ljava/lang/Object;

    .line 283
    .line 284
    check-cast v0, Ljava/lang/String;

    .line 285
    .line 286
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 287
    .line 288
    .line 289
    const-string v4, "Background-loaded full UIManager constants (size="

    .line 290
    .line 291
    const-string v5, "UIManagerConstantsCache version mismatch! Expected: "

    .line 292
    .line 293
    const-string v6, "UIManagerConstantsCache version matches: "

    .line 294
    .line 295
    :try_start_126
    invoke-static {}, Lcom/tencent/mmkv/MMKV;->b()Lcom/tencent/mmkv/MMKV;

    .line 296
    .line 297
    .line 298
    move-result-object v7

    .line 299
    const-string v8, "UIManagerConstantsCacheVersion"

    .line 300
    .line 301
    invoke-virtual {v7, v8}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object v8

    .line 305
    if-eqz v8, :cond_14e

    .line 306
    .line 307
    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 308
    .line 309
    .line 310
    move-result v9

    .line 311
    if-nez v9, :cond_139

    .line 312
    .line 313
    goto :goto_14e

    .line 314
    :cond_139
    const-string v5, "UIManagerConstantsCache"

    .line 315
    .line 316
    new-instance v8, Ljava/lang/StringBuilder;

    .line 317
    .line 318
    invoke-direct {v8, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 322
    .line 323
    .line 324
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    invoke-static {v5, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 329
    .line 330
    .line 331
    goto :goto_176

    .line 332
    :catchall_14b
    move-exception v0

    .line 333
    goto/16 :goto_243

    .line 334
    .line 335
    :cond_14e
    :goto_14e
    const-string v6, "UIManagerConstantsCache"

    .line 336
    .line 337
    new-instance v9, Ljava/lang/StringBuilder;

    .line 338
    .line 339
    invoke-direct {v9, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    const-string v0, ", found: "

    .line 346
    .line 347
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 348
    .line 349
    .line 350
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 351
    .line 352
    .line 353
    const-string v0, ". Will regenerate constants and bubblingEventTypes."

    .line 354
    .line 355
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 356
    .line 357
    .line 358
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v0

    .line 362
    invoke-static {v6, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 363
    .line 364
    .line 365
    const-string v0, "UIManagerModuleConstants_v1"

    .line 366
    .line 367
    invoke-virtual {v7, v0}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;)V

    .line 368
    .line 369
    .line 370
    const-string v0, "UIManagerModuleBubbling_v1"

    .line 371
    .line 372
    invoke-virtual {v7, v0}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    :goto_176
    const-string v0, "UIManagerModuleConstants_v1"

    .line 376
    .line 377
    invoke-virtual {v7, v0}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object v5
    :try_end_17c
    .catchall {:try_start_126 .. :try_end_17c} :catchall_14b

    .line 381
    if-eqz v5, :cond_1c9

    .line 382
    .line 383
    :try_start_17e
    new-instance v0, Lorg/json/JSONObject;

    .line 384
    .line 385
    invoke-direct {v0, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 386
    .line 387
    .line 388
    invoke-static {v0}, Lcom/facebook/react/uimanager/s0;->c(Lorg/json/JSONObject;)Ljava/util/HashMap;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    monitor-enter v2
    :try_end_188
    .catch Lorg/json/JSONException; {:try_start_17e .. :try_end_188} :catch_1a6
    .catchall {:try_start_17e .. :try_end_188} :catchall_14b

    .line 393
    :try_start_188
    iput-object v0, v2, Lcom/facebook/react/uimanager/s0;->a:Ljava/util/HashMap;

    .line 394
    .line 395
    monitor-exit v2
    :try_end_18b
    .catchall {:try_start_188 .. :try_end_18b} :catchall_1a8

    .line 396
    :try_start_18b
    const-string v6, "UIManagerConstantsCache"

    .line 397
    .line 398
    new-instance v8, Ljava/lang/StringBuilder;

    .line 399
    .line 400
    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 401
    .line 402
    .line 403
    invoke-virtual {v0}, Ljava/util/HashMap;->size()I

    .line 404
    .line 405
    .line 406
    move-result v0

    .line 407
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 408
    .line 409
    .line 410
    const-string v0, ")"

    .line 411
    .line 412
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 413
    .line 414
    .line 415
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    invoke-static {v6, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1a5
    .catch Lorg/json/JSONException; {:try_start_18b .. :try_end_1a5} :catch_1a6
    .catchall {:try_start_18b .. :try_end_1a5} :catchall_14b

    .line 420
    .line 421
    .line 422
    goto :goto_1d4

    .line 423
    :catch_1a6
    move-exception v0

    .line 424
    goto :goto_1ab

    .line 425
    :catchall_1a8
    move-exception v0

    .line 426
    :try_start_1a9
    monitor-exit v2
    :try_end_1aa
    .catchall {:try_start_1a9 .. :try_end_1aa} :catchall_1a8

    .line 427
    :try_start_1aa
    throw v0
    :try_end_1ab
    .catch Lorg/json/JSONException; {:try_start_1aa .. :try_end_1ab} :catch_1a6
    .catchall {:try_start_1aa .. :try_end_1ab} :catchall_14b

    .line 428
    :goto_1ab
    :try_start_1ab
    const-string v4, "UIManagerConstantsCache"

    .line 429
    .line 430
    new-instance v6, Ljava/lang/StringBuilder;

    .line 431
    .line 432
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 433
    .line 434
    .line 435
    const-string v8, "Invalid JSON in MMKV (constants). Will regenerate.\n"

    .line 436
    .line 437
    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 438
    .line 439
    .line 440
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 441
    .line 442
    .line 443
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 444
    .line 445
    .line 446
    move-result-object v5

    .line 447
    invoke-static {v4, v5, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 448
    .line 449
    .line 450
    monitor-enter v2
    :try_end_1c2
    .catchall {:try_start_1ab .. :try_end_1c2} :catchall_14b

    .line 451
    :try_start_1c2
    iput-object v3, v2, Lcom/facebook/react/uimanager/s0;->a:Ljava/util/HashMap;

    .line 452
    .line 453
    monitor-exit v2

    .line 454
    goto :goto_1d4

    .line 455
    :catchall_1c6
    move-exception v0

    .line 456
    monitor-exit v2
    :try_end_1c8
    .catchall {:try_start_1c2 .. :try_end_1c8} :catchall_1c6

    .line 457
    :try_start_1c8
    throw v0

    .line 458
    :cond_1c9
    monitor-enter v2
    :try_end_1ca
    .catchall {:try_start_1c8 .. :try_end_1ca} :catchall_14b

    .line 459
    :try_start_1ca
    iput-object v3, v2, Lcom/facebook/react/uimanager/s0;->a:Ljava/util/HashMap;

    .line 460
    .line 461
    monitor-exit v2
    :try_end_1cd
    .catchall {:try_start_1ca .. :try_end_1cd} :catchall_240

    .line 462
    :try_start_1cd
    const-string v0, "UIManagerConstantsCache"

    .line 463
    .line 464
    const-string v4, "No UIManager constants found in MMKV."

    .line 465
    .line 466
    invoke-static {v0, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 467
    .line 468
    .line 469
    :goto_1d4
    const-string v0, "UIManagerModuleBubbling_v1"

    .line 470
    .line 471
    invoke-virtual {v7, v0}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 472
    .line 473
    .line 474
    move-result-object v4
    :try_end_1da
    .catchall {:try_start_1cd .. :try_end_1da} :catchall_14b

    .line 475
    if-eqz v4, :cond_22c

    .line 476
    .line 477
    :try_start_1dc
    new-instance v0, Lorg/json/JSONObject;

    .line 478
    .line 479
    invoke-direct {v0, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 480
    .line 481
    .line 482
    invoke-static {v0}, Lcom/facebook/react/uimanager/s0;->c(Lorg/json/JSONObject;)Ljava/util/HashMap;

    .line 483
    .line 484
    .line 485
    move-result-object v0

    .line 486
    monitor-enter v2
    :try_end_1e6
    .catch Lorg/json/JSONException; {:try_start_1dc .. :try_end_1e6} :catch_209
    .catchall {:try_start_1dc .. :try_end_1e6} :catchall_14b

    .line 487
    :try_start_1e6
    iput-object v0, v2, Lcom/facebook/react/uimanager/s0;->b:Ljava/util/HashMap;

    .line 488
    .line 489
    monitor-exit v2
    :try_end_1e9
    .catchall {:try_start_1e6 .. :try_end_1e9} :catchall_20b

    .line 490
    :try_start_1e9
    const-string v5, "UIManagerConstantsCache"

    .line 491
    .line 492
    new-instance v6, Ljava/lang/StringBuilder;

    .line 493
    .line 494
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 495
    .line 496
    .line 497
    const-string v7, "Background-loaded bubblingEventTypes (size="

    .line 498
    .line 499
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 500
    .line 501
    .line 502
    invoke-virtual {v0}, Ljava/util/HashMap;->size()I

    .line 503
    .line 504
    .line 505
    move-result v0

    .line 506
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 507
    .line 508
    .line 509
    const-string v0, ")"

    .line 510
    .line 511
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 512
    .line 513
    .line 514
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 515
    .line 516
    .line 517
    move-result-object v0

    .line 518
    invoke-static {v5, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_208
    .catch Lorg/json/JSONException; {:try_start_1e9 .. :try_end_208} :catch_209
    .catchall {:try_start_1e9 .. :try_end_208} :catchall_14b

    .line 519
    .line 520
    .line 521
    goto :goto_237

    .line 522
    :catch_209
    move-exception v0

    .line 523
    goto :goto_20e

    .line 524
    :catchall_20b
    move-exception v0

    .line 525
    :try_start_20c
    monitor-exit v2
    :try_end_20d
    .catchall {:try_start_20c .. :try_end_20d} :catchall_20b

    .line 526
    :try_start_20d
    throw v0
    :try_end_20e
    .catch Lorg/json/JSONException; {:try_start_20d .. :try_end_20e} :catch_209
    .catchall {:try_start_20d .. :try_end_20e} :catchall_14b

    .line 527
    :goto_20e
    :try_start_20e
    const-string v5, "UIManagerConstantsCache"

    .line 528
    .line 529
    new-instance v6, Ljava/lang/StringBuilder;

    .line 530
    .line 531
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 532
    .line 533
    .line 534
    const-string v7, "Invalid JSON in MMKV (bubblingEventTypes). Will regenerate.\n"

    .line 535
    .line 536
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 537
    .line 538
    .line 539
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 540
    .line 541
    .line 542
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 543
    .line 544
    .line 545
    move-result-object v4

    .line 546
    invoke-static {v5, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 547
    .line 548
    .line 549
    monitor-enter v2
    :try_end_225
    .catchall {:try_start_20e .. :try_end_225} :catchall_14b

    .line 550
    :try_start_225
    iput-object v3, v2, Lcom/facebook/react/uimanager/s0;->b:Ljava/util/HashMap;

    .line 551
    .line 552
    monitor-exit v2

    .line 553
    goto :goto_237

    .line 554
    :catchall_229
    move-exception v0

    .line 555
    monitor-exit v2
    :try_end_22b
    .catchall {:try_start_225 .. :try_end_22b} :catchall_229

    .line 556
    :try_start_22b
    throw v0

    .line 557
    :cond_22c
    monitor-enter v2
    :try_end_22d
    .catchall {:try_start_22b .. :try_end_22d} :catchall_14b

    .line 558
    :try_start_22d
    iput-object v3, v2, Lcom/facebook/react/uimanager/s0;->b:Ljava/util/HashMap;

    .line 559
    .line 560
    monitor-exit v2
    :try_end_230
    .catchall {:try_start_22d .. :try_end_230} :catchall_23d

    .line 561
    :try_start_230
    const-string v0, "UIManagerConstantsCache"

    .line 562
    .line 563
    const-string v3, "No bubblingEventTypes found in MMKV."

    .line 564
    .line 565
    invoke-static {v0, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_237
    .catchall {:try_start_230 .. :try_end_237} :catchall_14b

    .line 566
    .line 567
    .line 568
    :goto_237
    iget-object v0, v2, Lcom/facebook/react/uimanager/s0;->d:Ljava/util/concurrent/CountDownLatch;

    .line 569
    .line 570
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 571
    .line 572
    .line 573
    return-void

    .line 574
    :catchall_23d
    move-exception v0

    .line 575
    :try_start_23e
    monitor-exit v2
    :try_end_23f
    .catchall {:try_start_23e .. :try_end_23f} :catchall_23d

    .line 576
    :try_start_23f
    throw v0
    :try_end_240
    .catchall {:try_start_23f .. :try_end_240} :catchall_14b

    .line 577
    :catchall_240
    move-exception v0

    .line 578
    :try_start_241
    monitor-exit v2
    :try_end_242
    .catchall {:try_start_241 .. :try_end_242} :catchall_240

    .line 579
    :try_start_242
    throw v0
    :try_end_243
    .catchall {:try_start_242 .. :try_end_243} :catchall_14b

    .line 580
    :goto_243
    iget-object v2, v2, Lcom/facebook/react/uimanager/s0;->d:Ljava/util/concurrent/CountDownLatch;

    .line 581
    .line 582
    invoke-virtual {v2}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 583
    .line 584
    .line 585
    throw v0

    .line 586
    :pswitch_249
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 587
    .line 588
    check-cast v0, Landroid/content/Context;

    .line 589
    .line 590
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 591
    .line 592
    check-cast v2, Lcom/discord/crash_reporting/y;

    .line 593
    .line 594
    const-string v5, "TelemetryRing"

    .line 595
    .line 596
    :try_start_253
    sget-object v6, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;
    :try_end_255
    .catchall {:try_start_253 .. :try_end_255} :catchall_297

    .line 597
    .line 598
    if-eqz v6, :cond_25a

    .line 599
    .line 600
    :cond_257
    :goto_257
    sput-boolean v4, Lcom/discord/crash_reporting/s;->j:Z

    .line 601
    .line 602
    goto :goto_2a0

    .line 603
    :cond_25a
    :try_start_25a
    new-instance v6, Lcom/discord/crash_reporting/x;

    .line 604
    .line 605
    invoke-static {v0}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 606
    .line 607
    .line 608
    invoke-direct {v6, v0, v2}, Lcom/discord/crash_reporting/x;-><init>(Landroid/content/Context;Lcom/discord/crash_reporting/y;)V

    .line 609
    .line 610
    .line 611
    sput-object v6, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;

    .line 612
    .line 613
    sget-object v0, Lnf/a;->a:Lnf/a;

    .line 614
    .line 615
    const-string v0, "TelemetryRing initialized"

    .line 616
    .line 617
    invoke-static {v5, v0, v3}, Lnf/a;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 618
    .line 619
    .line 620
    sget-object v0, Lcom/discord/crash_reporting/s;->b:Ljava/util/ArrayDeque;

    .line 621
    .line 622
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 623
    .line 624
    .line 625
    move-result v2

    .line 626
    if-eqz v2, :cond_274

    .line 627
    .line 628
    goto :goto_257

    .line 629
    :cond_274
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 630
    .line 631
    .line 632
    move-result-object v0

    .line 633
    :goto_278
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 634
    .line 635
    .line 636
    move-result v2

    .line 637
    if-eqz v2, :cond_28a

    .line 638
    .line 639
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 640
    .line 641
    .line 642
    move-result-object v2

    .line 643
    check-cast v2, Lcom/discord/crash_reporting/v;

    .line 644
    .line 645
    sget-object v3, Lcom/discord/crash_reporting/s;->c:Ljava/util/ArrayDeque;

    .line 646
    .line 647
    invoke-virtual {v3, v2}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 648
    .line 649
    .line 650
    goto :goto_278

    .line 651
    :cond_28a
    sget-object v0, Lcom/discord/crash_reporting/s;->b:Ljava/util/ArrayDeque;

    .line 652
    .line 653
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    .line 654
    .line 655
    .line 656
    sget-object v0, Lcom/discord/crash_reporting/s;->a:Lcom/discord/crash_reporting/x;

    .line 657
    .line 658
    if-eqz v0, :cond_257

    .line 659
    .line 660
    invoke-static {v0}, Lcom/discord/crash_reporting/s;->c(Lcom/discord/crash_reporting/x;)V
    :try_end_296
    .catchall {:try_start_25a .. :try_end_296} :catchall_297

    .line 661
    .line 662
    .line 663
    goto :goto_257

    .line 664
    :catchall_297
    move-exception v0

    .line 665
    :try_start_298
    sget-object v2, Lnf/a;->a:Lnf/a;

    .line 666
    .line 667
    const-string v2, "TelemetryRing initialization failed"

    .line 668
    .line 669
    invoke-static {v5, v2, v0}, Lnf/a;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_29f
    .catchall {:try_start_298 .. :try_end_29f} :catchall_2a1

    .line 670
    .line 671
    .line 672
    goto :goto_257

    .line 673
    :goto_2a0
    return-void

    .line 674
    :catchall_2a1
    move-exception v0

    .line 675
    sput-boolean v4, Lcom/discord/crash_reporting/s;->j:Z

    .line 676
    .line 677
    throw v0

    .line 678
    :pswitch_2a5
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 679
    .line 680
    check-cast v0, Lc7/u;

    .line 681
    .line 682
    iget-object v3, v1, La4/c;->i:Ljava/lang/Object;

    .line 683
    .line 684
    check-cast v3, Lmx/y;

    .line 685
    .line 686
    iget-object v0, v0, Lc7/u;->R:Lm7/j;

    .line 687
    .line 688
    iget-object v0, v0, Lm7/h;->d:Ljava/lang/Object;

    .line 689
    .line 690
    instance-of v0, v0, Lm7/a;

    .line 691
    .line 692
    if-eqz v0, :cond_2b8

    .line 693
    .line 694
    invoke-interface {v3, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 695
    .line 696
    .line 697
    :cond_2b8
    return-void

    .line 698
    :pswitch_2b9
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 699
    .line 700
    check-cast v0, Lc7/f;

    .line 701
    .line 702
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 703
    .line 704
    check-cast v2, Lk7/j;

    .line 705
    .line 706
    iget-object v3, v0, Lc7/f;->k:Ljava/lang/Object;

    .line 707
    .line 708
    monitor-enter v3

    .line 709
    :try_start_2c4
    iget-object v0, v0, Lc7/f;->j:Ljava/util/ArrayList;

    .line 710
    .line 711
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 712
    .line 713
    .line 714
    move-result-object v0

    .line 715
    :goto_2ca
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 716
    .line 717
    .line 718
    move-result v5

    .line 719
    if-eqz v5, :cond_2dc

    .line 720
    .line 721
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 722
    .line 723
    .line 724
    move-result-object v5

    .line 725
    check-cast v5, Lc7/c;

    .line 726
    .line 727
    invoke-interface {v5, v2, v4}, Lc7/c;->b(Lk7/j;Z)V

    .line 728
    .line 729
    .line 730
    goto :goto_2ca

    .line 731
    :catchall_2da
    move-exception v0

    .line 732
    goto :goto_2de

    .line 733
    :cond_2dc
    monitor-exit v3

    .line 734
    return-void

    .line 735
    :goto_2de
    monitor-exit v3
    :try_end_2df
    .catchall {:try_start_2c4 .. :try_end_2df} :catchall_2da

    .line 736
    throw v0

    .line 737
    :pswitch_2e0
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 738
    .line 739
    check-cast v0, Lbn/l;

    .line 740
    .line 741
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 742
    .line 743
    check-cast v2, Ljava/lang/Runnable;

    .line 744
    .line 745
    const-string v3, "this$0"

    .line 746
    .line 747
    invoke-static {v0, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 748
    .line 749
    .line 750
    const-string v0, "$runnable"

    .line 751
    .line 752
    invoke-static {v2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 753
    .line 754
    .line 755
    const/16 v0, 0xa

    .line 756
    .line 757
    :try_start_2f4
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    :try_end_2f7
    .catchall {:try_start_2f4 .. :try_end_2f7} :catchall_2f7

    .line 758
    .line 759
    .line 760
    :catchall_2f7
    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    .line 761
    .line 762
    .line 763
    return-void

    .line 764
    :pswitch_2fb
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 765
    .line 766
    check-cast v0, Lb3/p;

    .line 767
    .line 768
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 769
    .line 770
    check-cast v2, Landroid/view/ViewGroup;

    .line 771
    .line 772
    const-string v3, "$container"

    .line 773
    .line 774
    invoke-static {v2, v3}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 775
    .line 776
    .line 777
    iget-object v0, v0, Lb3/p;->c:Ljava/util/ArrayList;

    .line 778
    .line 779
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 780
    .line 781
    .line 782
    move-result-object v0

    .line 783
    :cond_30e
    :goto_30e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 784
    .line 785
    .line 786
    move-result v3

    .line 787
    if-eqz v3, :cond_32a

    .line 788
    .line 789
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 790
    .line 791
    .line 792
    move-result-object v3

    .line 793
    check-cast v3, Lb3/q;

    .line 794
    .line 795
    iget-object v3, v3, Lb3/l;->e:Ljava/lang/Object;

    .line 796
    .line 797
    check-cast v3, Lb3/q1;

    .line 798
    .line 799
    iget-object v4, v3, Lb3/q1;->c:Lb3/a0;

    .line 800
    .line 801
    iget-object v4, v4, Lb3/a0;->j0:Landroid/view/View;

    .line 802
    .line 803
    if-eqz v4, :cond_30e

    .line 804
    .line 805
    iget v3, v3, Lb3/q1;->a:I

    .line 806
    .line 807
    invoke-static {v3, v4, v2}, La1/h;->a(ILandroid/view/View;Landroid/view/ViewGroup;)V

    .line 808
    .line 809
    .line 810
    goto :goto_30e

    .line 811
    :cond_32a
    return-void

    .line 812
    :pswitch_32b
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 813
    .line 814
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 815
    .line 816
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 817
    .line 818
    check-cast v2, Landroid/graphics/drawable/Drawable;

    .line 819
    .line 820
    invoke-interface {v0, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 821
    .line 822
    .line 823
    return-void

    .line 824
    :pswitch_337
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 825
    .line 826
    check-cast v0, Lb10/g;

    .line 827
    .line 828
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 829
    .line 830
    check-cast v2, Landroidx/core/view/u1;

    .line 831
    .line 832
    invoke-virtual {v0}, Lb10/g;->b()D

    .line 833
    .line 834
    .line 835
    move-result-wide v9

    .line 836
    iget-object v15, v0, Lb10/g;->d:Lg10/b;

    .line 837
    .line 838
    iget-object v5, v0, Lb10/g;->i:Lcom/facebook/react/uimanager/k0;

    .line 839
    .line 840
    invoke-virtual {v0}, Lb10/g;->d()Z

    .line 841
    .line 842
    .line 843
    move-result v6

    .line 844
    iput-boolean v6, v0, Lb10/g;->J:Z

    .line 845
    .line 846
    iput-wide v9, v0, Lb10/g;->y:D

    .line 847
    .line 848
    iget-object v6, v0, Lb10/g;->P:Ljava/util/HashSet;

    .line 849
    .line 850
    invoke-virtual {v6, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 851
    .line 852
    .line 853
    move-result v7

    .line 854
    if-eqz v7, :cond_35f

    .line 855
    .line 856
    iput v4, v0, Lb10/g;->M:I

    .line 857
    .line 858
    iput-object v3, v0, Lb10/g;->O:Lb10/j;

    .line 859
    .line 860
    invoke-virtual {v6, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 861
    .line 862
    .line 863
    goto :goto_3ba

    .line 864
    :cond_35f
    invoke-virtual {v0}, Lb10/g;->a()V

    .line 865
    .line 866
    .line 867
    iget-boolean v2, v0, Lb10/g;->J:Z

    .line 868
    .line 869
    if-nez v2, :cond_369

    .line 870
    .line 871
    const-string v2, "keyboardDidHide"

    .line 872
    .line 873
    goto :goto_36b

    .line 874
    :cond_369
    const-string v2, "keyboardDidShow"

    .line 875
    .line 876
    :goto_36b
    const-string v3, "KeyboardController::"

    .line 877
    .line 878
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 879
    .line 880
    .line 881
    move-result-object v2

    .line 882
    invoke-virtual {v0, v9, v10}, Lb10/g;->c(D)Lcom/facebook/react/bridge/WritableMap;

    .line 883
    .line 884
    .line 885
    move-result-object v3

    .line 886
    invoke-static {v5, v2, v3}, Ly00/b;->b(Lcom/facebook/react/uimanager/k0;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 887
    .line 888
    .line 889
    invoke-virtual {v15}, Landroid/view/View;->getId()I

    .line 890
    .line 891
    .line 892
    move-object v2, v5

    .line 893
    new-instance v5, Lx00/c;

    .line 894
    .line 895
    iget v6, v0, Lb10/g;->w:I

    .line 896
    .line 897
    invoke-virtual {v15}, Landroid/view/View;->getId()I

    .line 898
    .line 899
    .line 900
    move-result v7

    .line 901
    sget-object v8, Lx00/c;->L:Lx00/b;

    .line 902
    .line 903
    iget-boolean v3, v0, Lb10/g;->J:Z

    .line 904
    .line 905
    if-nez v3, :cond_38d

    .line 906
    .line 907
    const-wide/16 v11, 0x0

    .line 908
    .line 909
    goto :goto_38f

    .line 910
    :cond_38d
    const-wide/high16 v11, 0x3ff0000000000000L    # 1.0

    .line 911
    .line 912
    :goto_38f
    iget v13, v0, Lb10/g;->M:I

    .line 913
    .line 914
    iget v14, v0, Lb10/g;->N:I

    .line 915
    .line 916
    invoke-direct/range {v5 .. v14}, Lx00/c;-><init>(IILx00/b;DDII)V

    .line 917
    .line 918
    .line 919
    invoke-static {v2, v5}, Ly00/b;->a(Lcom/facebook/react/uimanager/k0;Lqp/f;)V

    .line 920
    .line 921
    .line 922
    iput v4, v0, Lb10/g;->M:I

    .line 923
    .line 924
    invoke-virtual {v15}, Landroid/view/View;->getId()I

    .line 925
    .line 926
    .line 927
    move-result v0

    .line 928
    filled-new-array {v0}, [I

    .line 929
    .line 930
    .line 931
    move-result-object v0

    .line 932
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createArray()Lcom/facebook/react/bridge/WritableArray;

    .line 933
    .line 934
    .line 935
    move-result-object v3

    .line 936
    aget v0, v0, v4

    .line 937
    .line 938
    invoke-interface {v3, v0}, Lcom/facebook/react/bridge/WritableArray;->pushInt(I)V

    .line 939
    .line 940
    .line 941
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 942
    .line 943
    .line 944
    move-result-object v0

    .line 945
    const-string v4, "tags"

    .line 946
    .line 947
    invoke-interface {v0, v4, v3}, Lcom/facebook/react/bridge/WritableMap;->putArray(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V

    .line 948
    .line 949
    .line 950
    const-string v3, "onUserDrivenAnimationEnded"

    .line 951
    .line 952
    invoke-static {v2, v3, v0}, Ly00/b;->b(Lcom/facebook/react/uimanager/k0;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 953
    .line 954
    .line 955
    :goto_3ba
    return-void

    .line 956
    :pswitch_3bb
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 957
    .line 958
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 959
    .line 960
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 961
    .line 962
    check-cast v2, Lapp/rive/runtime/kotlin/renderers/RenderContextEvent;

    .line 963
    .line 964
    invoke-static {v0, v2}, Lapp/rive/runtime/kotlin/renderers/Renderer;->c(Lkotlin/jvm/functions/Function1;Lapp/rive/runtime/kotlin/renderers/RenderContextEvent;)V

    .line 965
    .line 966
    .line 967
    return-void

    .line 968
    :pswitch_3c7
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 969
    .line 970
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 971
    .line 972
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 973
    .line 974
    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 975
    .line 976
    invoke-static {v0, v2}, Lapp/rive/core/CommandQueue;->d(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V

    .line 977
    .line 978
    .line 979
    return-void

    .line 980
    :pswitch_3d3
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 981
    .line 982
    check-cast v0, Lx/t;

    .line 983
    .line 984
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 985
    .line 986
    check-cast v2, Lapp/rive/RiveTextureView;

    .line 987
    .line 988
    invoke-static {v0, v2}, Lapp/rive/RiveKt$RiveSurfaceHost$3$1$1$1;->a(Lx/t;Lapp/rive/RiveTextureView;)V

    .line 989
    .line 990
    .line 991
    return-void

    .line 992
    :pswitch_3df
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 993
    .line 994
    check-cast v0, Lz60/k;

    .line 995
    .line 996
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 997
    .line 998
    check-cast v2, La70/e;

    .line 999
    .line 1000
    invoke-virtual {v0, v2}, Lz60/k;->D(Lz60/u;)V

    .line 1001
    .line 1002
    .line 1003
    return-void

    .line 1004
    :pswitch_3eb
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 1005
    .line 1006
    check-cast v0, Landroidx/media3/ui/PlayerView;

    .line 1007
    .line 1008
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 1009
    .line 1010
    check-cast v2, Landroid/graphics/Bitmap;

    .line 1011
    .line 1012
    invoke-static {v0, v2}, Landroidx/media3/ui/PlayerView;->a(Landroidx/media3/ui/PlayerView;Landroid/graphics/Bitmap;)V

    .line 1013
    .line 1014
    .line 1015
    return-void

    .line 1016
    :pswitch_3f7
    iget-object v0, v1, La4/c;->e:Ljava/lang/Object;

    .line 1017
    .line 1018
    check-cast v0, La4/d;

    .line 1019
    .line 1020
    iget-object v2, v1, La4/c;->i:Ljava/lang/Object;

    .line 1021
    .line 1022
    check-cast v2, Landroid/net/Uri;

    .line 1023
    .line 1024
    iput-boolean v4, v0, La4/d;->L:Z

    .line 1025
    .line 1026
    iget-object v3, v0, La4/d;->d:Landroid/net/Uri;

    .line 1027
    .line 1028
    iget-object v4, v0, La4/d;->O:La4/f;

    .line 1029
    .line 1030
    iget-object v4, v4, La4/f;->T:Landroid/net/Uri;

    .line 1031
    .line 1032
    invoke-virtual {v3, v4}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 1033
    .line 1034
    .line 1035
    move-result v3

    .line 1036
    if-nez v3, :cond_411

    .line 1037
    .line 1038
    iget-boolean v3, v0, La4/d;->N:Z

    .line 1039
    .line 1040
    if-eqz v3, :cond_414

    .line 1041
    .line 1042
    :cond_411
    invoke-virtual {v0, v2}, La4/d;->b(Landroid/net/Uri;)V

    .line 1043
    .line 1044
    .line 1045
    :cond_414
    return-void

    .line 1046
    nop

    .line 1047
    :pswitch_data_416
    .packed-switch 0x0
        :pswitch_3f7
        :pswitch_3eb
        :pswitch_3df
        :pswitch_3d3
        :pswitch_3c7
        :pswitch_3bb
        :pswitch_337
        :pswitch_32b
        :pswitch_2fb
        :pswitch_2e0
        :pswitch_2b9
        :pswitch_2a5
        :pswitch_249
        :pswitch_114
        :pswitch_fd
        :pswitch_e8
        :pswitch_dc
        :pswitch_ce
        :pswitch_be
        :pswitch_b2
        :pswitch_a6
        :pswitch_8b
        :pswitch_76
        :pswitch_6c
        :pswitch_60
        :pswitch_46
        :pswitch_36
        :pswitch_26
        :pswitch_14
    .end packed-switch
.end method
