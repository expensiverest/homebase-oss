###### Class a8.c (a8.c)
.class public final La8/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lgu/h;
.implements Lg/b;
.implements Lc4/o;
.implements Lnv/d;
.implements Le6/t1;
.implements Lkw/a;
.implements Lb30/a;
.implements Lh4/e;
.implements Lo/i;
.implements Lio/sentry/b4;
.implements Ldr/b;
.implements Lo/v;
.implements Lcom/facebook/react/uimanager/ComponentNameResolver;
.implements Lvm/d;


# instance fields
.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    packed-switch p1, :pswitch_data_1c

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    new-instance p1, Lnw/f;

    const/16 v0, 0xd

    .line 4
    invoke-direct {p1, v0}, Lnw/f;-><init>(I)V

    .line 5
    iput-object p1, p0, La8/c;->d:Ljava/lang/Object;

    return-void

    .line 6
    :pswitch_10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    new-instance p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object p1, p0, La8/c;->d:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0x18
        :pswitch_10
    .end packed-switch
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .registers 2

    .line 1
    iput-object p1, p0, La8/c;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static q(Ljava/lang/String;La8/b;Z)Ljava/lang/String;
    .registers 6

    .line 1
    iget-object p1, p1, La8/b;->d:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz p2, :cond_a

    .line 4
    .line 5
    const-string p2, ".temp"

    .line 6
    .line 7
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    :cond_a
    const-string p2, "\\W+"

    .line 12
    .line 13
    const-string v0, ""

    .line 14
    .line 15
    invoke-virtual {p0, p2, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    rsub-int p2, p2, 0xf2

    .line 24
    .line 25
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-le v0, p2, :cond_54

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    :try_start_1f
    const-string v1, "MD5"

    .line 33
    .line 34
    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 35
    .line 36
    .line 37
    move-result-object p2
    :try_end_25
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_1f .. :try_end_25} :catch_50

    .line 38
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    invoke-virtual {p2, p0}, Ljava/security/MessageDigest;->digest([B)[B

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    new-instance p2, Ljava/lang/StringBuilder;

    .line 47
    .line 48
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 49
    .line 50
    .line 51
    :goto_32
    array-length v1, p0

    .line 52
    if-ge v0, v1, :cond_4b

    .line 53
    .line 54
    aget-byte v1, p0, v0

    .line 55
    .line 56
    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    const-string v2, "%02x"

    .line 65
    .line 66
    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    add-int/lit8 v0, v0, 0x1

    .line 74
    .line 75
    goto :goto_32

    .line 76
    :cond_4b
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    goto :goto_54

    .line 81
    :catch_50
    invoke-virtual {p0, v0, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    :cond_54
    :goto_54
    const-string p2, "lottie_cache_"

    .line 86
    .line 87
    invoke-static {p2, p0, p1}, Lp/x2;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    return-object p0
.end method


# virtual methods
.method public D(Lo/k;)Z
    .registers 4

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lj/x;

    .line 4
    .line 5
    invoke-virtual {p1}, Lo/k;->k()Lo/k;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-ne p1, v1, :cond_1f

    .line 10
    .line 11
    iget-boolean v1, v0, Lj/x;->h0:Z

    .line 12
    .line 13
    if-eqz v1, :cond_1f

    .line 14
    .line 15
    iget-object v1, v0, Lj/x;->N:Landroid/view/Window;

    .line 16
    .line 17
    invoke-virtual {v1}, Landroid/view/Window;->getCallback()Landroid/view/Window$Callback;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-eqz v1, :cond_1f

    .line 22
    .line 23
    iget-boolean v0, v0, Lj/x;->s0:Z

    .line 24
    .line 25
    if-nez v0, :cond_1f

    .line 26
    .line 27
    const/16 v0, 0x6c

    .line 28
    .line 29
    invoke-interface {v1, v0, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    .line 30
    .line 31
    .line 32
    :cond_1f
    const/4 p1, 0x1

    .line 33
    return p1
.end method

.method public G(Lo/k;)V
    .registers 2

    .line 1
    return-void
.end method

.method public a(JIII)V
    .registers 14

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Landroid/media/MediaCodec;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    move-wide v5, p1

    .line 8
    move v2, p3

    .line 9
    move v4, p4

    .line 10
    move v7, p5

    .line 11
    invoke-virtual/range {v1 .. v7}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lav/e;

    .line 4
    .line 5
    check-cast p1, Lav/f;

    .line 6
    .line 7
    check-cast p2, Lnv/h;

    .line 8
    .line 9
    new-instance v1, Lav/d;

    .line 10
    .line 11
    invoke-direct {v1, p2}, Lav/d;-><init>(Lnv/h;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p1}, Lhu/c;->i()Landroid/os/IInterface;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    check-cast p1, Lav/m;

    .line 19
    .line 20
    iget-object p2, v0, Lav/e;->l:Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {p1}, Lav/a;->r()Landroid/os/Parcel;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sget v2, Lav/j;->a:I

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    const/4 p2, 0x2

    .line 35
    invoke-virtual {p1, p2, v0}, Lav/a;->v(ILandroid/os/Parcel;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public b(Landroid/view/View;)I
    .registers 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Le6/v0;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/a;->M(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 12
    .line 13
    sub-int/2addr p1, v0

    .line 14
    return p1
.end method

.method public c()V
    .registers 1

    .line 1
    return-void
.end method

.method public d(Ljava/lang/Object;)V
    .registers 7

    .line 1
    check-cast p1, Ljava/util/Map;

    .line 2
    .line 3
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lb3/x0;

    .line 6
    .line 7
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const/4 v2, 0x0

    .line 12
    new-array v3, v2, [Ljava/lang/String;

    .line 13
    .line 14
    invoke-interface {v1, v3}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    check-cast v1, [Ljava/lang/String;

    .line 19
    .line 20
    new-instance v1, Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-direct {v1, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    new-array p1, p1, [I

    .line 34
    .line 35
    move v3, v2

    .line 36
    :goto_23
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-ge v3, v4, :cond_3d

    .line 41
    .line 42
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    check-cast v4, Ljava/lang/Boolean;

    .line 47
    .line 48
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    if-eqz v4, :cond_37

    .line 53
    .line 54
    move v4, v2

    .line 55
    goto :goto_38

    .line 56
    :cond_37
    const/4 v4, -0x1

    .line 57
    :goto_38
    aput v4, p1, v3

    .line 58
    .line 59
    add-int/lit8 v3, v3, 0x1

    .line 60
    .line 61
    goto :goto_23

    .line 62
    :cond_3d
    iget-object p1, v0, Lb3/x0;->F:Ljava/util/ArrayDeque;

    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    check-cast p1, Lb3/s0;

    .line 69
    .line 70
    const-string v1, "FragmentManager"

    .line 71
    .line 72
    if-nez p1, :cond_5b

    .line 73
    .line 74
    new-instance p1, Ljava/lang/StringBuilder;

    .line 75
    .line 76
    const-string v0, "No permissions were requested for "

    .line 77
    .line 78
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :cond_5b
    iget-object p1, p1, Lb3/s0;->d:Ljava/lang/String;

    .line 93
    .line 94
    iget-object v0, v0, Lb3/x0;->c:Lcom/google/firebase/messaging/t;

    .line 95
    .line 96
    invoke-virtual {v0, p1}, Lcom/google/firebase/messaging/t;->g(Ljava/lang/String;)Lb3/a0;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-nez v0, :cond_76

    .line 101
    .line 102
    new-instance v0, Ljava/lang/StringBuilder;

    .line 103
    .line 104
    const-string v2, "Permission request result delivered for unknown Fragment "

    .line 105
    .line 106
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 117
    .line 118
    .line 119
    :cond_76
    return-void
.end method

.method public e(Lya/c;Landroid/view/ViewGroup;Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/view/View;Landroid/view/View;ZZZIZZ)V
    .registers 19

    .line 1
    const-string v0, "parentView"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    if-nez p1, :cond_f

    .line 7
    .line 8
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lcom/discord/chat/presentation/message/view/SpoilerView;

    .line 11
    .line 12
    if-nez v0, :cond_f

    .line 13
    .line 14
    goto/16 :goto_ad

    .line 15
    .line 16
    :cond_f
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Lcom/discord/chat/presentation/message/view/SpoilerView;

    .line 19
    .line 20
    const/4 v1, 0x4

    .line 21
    const/4 v2, 0x0

    .line 22
    if-nez v0, :cond_70

    .line 23
    .line 24
    new-instance v0, Lcom/discord/chat/presentation/message/view/SpoilerView;

    .line 25
    .line 26
    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    const-string v4, "getContext(...)"

    .line 31
    .line 32
    invoke-static {v3, v4}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const/4 v4, 0x2

    .line 36
    const/4 v5, 0x0

    .line 37
    invoke-direct {v0, v3, v5, v4, v5}, Lcom/discord/chat/presentation/message/view/SpoilerView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 38
    .line 39
    .line 40
    invoke-static {}, Landroid/view/View;->generateViewId()I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    invoke-virtual {v0, v3}, Landroid/view/View;->setId(I)V

    .line 45
    .line 46
    .line 47
    move/from16 v3, p9

    .line 48
    .line 49
    invoke-static {v0, v3}, Lxg/c;->b(Landroid/view/View;I)V

    .line 50
    .line 51
    .line 52
    new-instance v3, La1/d;

    .line 53
    .line 54
    invoke-direct {v3, v2, v2}, La1/d;-><init>(II)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 61
    .line 62
    .line 63
    new-instance v3, La1/o;

    .line 64
    .line 65
    invoke-direct {v3}, La1/o;-><init>()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v3, p3}, La1/o;->b(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    const/4 v6, 0x6

    .line 76
    invoke-virtual {v3, v4, v6, v6}, La1/o;->c(III)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    const/4 v6, 0x7

    .line 84
    invoke-virtual {v3, v4, v6, v6}, La1/o;->c(III)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 88
    .line 89
    .line 90
    move-result v4

    .line 91
    const/4 v6, 0x3

    .line 92
    invoke-virtual {v3, v4, v6, v6}, La1/o;->c(III)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 96
    .line 97
    .line 98
    move-result v4

    .line 99
    invoke-virtual {v3, v4, v1, v1}, La1/o;->c(III)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v3, p3}, La1/o;->a(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {p3, v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->setConstraintSet(La1/o;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p3}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    .line 109
    .line 110
    .line 111
    iput-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 112
    .line 113
    :cond_70
    iget-object p3, p0, La8/c;->d:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast p3, Lcom/discord/chat/presentation/message/view/SpoilerView;

    .line 116
    .line 117
    if-eqz p3, :cond_ad

    .line 118
    .line 119
    invoke-virtual {p3, p1, p2}, Lcom/discord/chat/presentation/message/view/SpoilerView;->a(Lya/c;Landroid/view/ViewGroup;)V

    .line 120
    .line 121
    .line 122
    if-eqz p8, :cond_9b

    .line 123
    .line 124
    iget-boolean p1, p3, Lcom/discord/chat/presentation/message/view/SpoilerView;->e:Z

    .line 125
    .line 126
    if-eqz p1, :cond_9b

    .line 127
    .line 128
    if-eqz p5, :cond_84

    .line 129
    .line 130
    invoke-virtual {p5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 131
    .line 132
    .line 133
    :cond_84
    invoke-virtual {p3, p6}, Lcom/discord/chat/presentation/message/view/SpoilerView;->setObscureLabelVisible(Z)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {p3, p7}, Lcom/discord/chat/presentation/message/view/SpoilerView;->b(Z)V

    .line 137
    .line 138
    .line 139
    xor-int/lit8 p1, p10, 0x1

    .line 140
    .line 141
    invoke-virtual {p3, p1}, Lcom/discord/chat/presentation/message/view/SpoilerView;->setRevealButtonVisible(Z)V

    .line 142
    .line 143
    .line 144
    move/from16 p1, p11

    .line 145
    .line 146
    invoke-virtual {p3, p1}, Lcom/discord/chat/presentation/message/view/SpoilerView;->setOpaqueBackgroundVisible(Z)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p4, v1}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {p4}, Landroid/view/View;->clearFocus()V

    .line 153
    .line 154
    .line 155
    return-void

    .line 156
    :cond_9b
    if-eqz p5, :cond_a2

    .line 157
    .line 158
    const/16 p1, 0x8

    .line 159
    .line 160
    invoke-virtual {p5, p1}, Landroid/view/View;->setVisibility(I)V

    .line 161
    .line 162
    .line 163
    :cond_a2
    invoke-virtual {p4, v2}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 164
    .line 165
    .line 166
    if-eqz p8, :cond_ad

    .line 167
    .line 168
    invoke-virtual {p3}, Landroid/view/View;->clearFocus()V

    .line 169
    .line 170
    .line 171
    invoke-virtual {p4}, Landroid/view/View;->requestFocus()Z

    .line 172
    .line 173
    .line 174
    :cond_ad
    :goto_ad
    return-void
.end method

.method public f(I)Ljl/b;
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Llm/a;

    .line 4
    .line 5
    iget-object v0, v0, Llm/a;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lgm/b;

    .line 8
    .line 9
    invoke-interface {v0, p1}, Lgm/b;->C(I)Ljl/b;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    return-object p1
.end method

.method public flush()V
    .registers 1

    .line 1
    return-void
.end method

.method public g()I
    .registers 2

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a;->getPaddingLeft()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public get()Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljavax/inject/Provider;

    .line 4
    .line 5
    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/content/Context;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_11

    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_11
    new-instance v0, Ljava/lang/NullPointerException;

    .line 19
    .line 20
    const-string v1, "Cannot return null from a non-@Nullable @Provides method"

    .line 21
    .line 22
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw v0
.end method

.method public getComponentNames()[Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/facebook/react/runtime/ReactInstance;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/facebook/react/runtime/ReactInstance;->d:Lk7/i;

    .line 6
    .line 7
    invoke-virtual {v0}, Lk7/i;->w()Ljava/util/Collection;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/util/HashSet;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const/4 v2, 0x0

    .line 18
    if-eqz v1, :cond_1f

    .line 19
    .line 20
    sget v0, Lcom/facebook/react/runtime/ReactInstance;->h:I

    .line 21
    .line 22
    const-string v0, "ReactInstance"

    .line 23
    .line 24
    const-string v1, "No ViewManager names found"

    .line 25
    .line 26
    invoke-static {v0, v1}, Lgl/a;->g(Ljava/lang/String;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    new-array v0, v2, [Ljava/lang/String;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_1f
    new-array v1, v2, [Ljava/lang/String;

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, [Ljava/lang/String;

    .line 39
    .line 40
    return-object v0
.end method

.method public h(Lo/k;Z)V
    .registers 12

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lj/x;

    .line 4
    .line 5
    invoke-virtual {p1}, Lo/k;->k()Lo/k;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    if-eq v1, p1, :cond_e

    .line 12
    .line 13
    move v4, v3

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    move v4, v2

    .line 16
    :goto_f
    if-eqz v4, :cond_12

    .line 17
    .line 18
    move-object p1, v1

    .line 19
    :cond_12
    iget-object v5, v0, Lj/x;->n0:[Lj/w;

    .line 20
    .line 21
    if-eqz v5, :cond_18

    .line 22
    .line 23
    array-length v6, v5

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    move v6, v2

    .line 26
    :goto_19
    if-ge v2, v6, :cond_27

    .line 27
    .line 28
    aget-object v7, v5, v2

    .line 29
    .line 30
    if-eqz v7, :cond_24

    .line 31
    .line 32
    iget-object v8, v7, Lj/w;->h:Lo/k;

    .line 33
    .line 34
    if-ne v8, p1, :cond_24

    .line 35
    .line 36
    goto :goto_28

    .line 37
    :cond_24
    add-int/lit8 v2, v2, 0x1

    .line 38
    .line 39
    goto :goto_19

    .line 40
    :cond_27
    const/4 v7, 0x0

    .line 41
    :goto_28
    if-eqz v7, :cond_38

    .line 42
    .line 43
    if-eqz v4, :cond_35

    .line 44
    .line 45
    iget p1, v7, Lj/w;->a:I

    .line 46
    .line 47
    invoke-virtual {v0, p1, v7, v1}, Lj/x;->q(ILj/w;Lo/k;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0, v7, v3}, Lj/x;->s(Lj/w;Z)V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :cond_35
    invoke-virtual {v0, v7, p2}, Lj/x;->s(Lj/w;Z)V

    .line 55
    .line 56
    .line 57
    :cond_38
    return-void
.end method

.method public i(ILrr/b;JI)V
    .registers 14

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Landroid/media/MediaCodec;

    .line 5
    .line 6
    iget-object v4, p2, Lrr/b;->i:Landroid/media/MediaCodec$CryptoInfo;

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    move v2, p1

    .line 10
    move-wide v5, p3

    .line 11
    move v7, p5

    .line 12
    invoke-virtual/range {v1 .. v7}, Landroid/media/MediaCodec;->queueSecureInputBuffer(IILandroid/media/MediaCodec$CryptoInfo;JI)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public j(Lio/sentry/a1;Lio/sentry/a6;)Lcg/q;
    .registers 14

    .line 1
    const-string v0, "Scopes are required"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "SentryOptions is required"

    .line 7
    .line 8
    invoke-static {p2, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/discord/crash_reporting/f;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/discord/crash_reporting/f;->d:Lio/sentry/android/core/SentryAndroidOptions;

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/sentry/a6;->getCacheDirPath()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    if-eqz v3, :cond_47

    .line 22
    .line 23
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v3, v0}, Lio/sentry/b4;->o(Ljava/lang/String;Lio/sentry/ILogger;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_21

    .line 32
    .line 33
    goto :goto_47

    .line 34
    :cond_21
    new-instance v4, Lio/sentry/b0;

    .line 35
    .line 36
    invoke-virtual {p2}, Lio/sentry/a6;->getSerializer()Lio/sentry/f1;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    invoke-virtual {p2}, Lio/sentry/a6;->getFlushTimeoutMillis()J

    .line 45
    .line 46
    .line 47
    move-result-wide v8

    .line 48
    invoke-virtual {p2}, Lio/sentry/a6;->getMaxQueueSize()I

    .line 49
    .line 50
    .line 51
    move-result v10

    .line 52
    move-object v5, p1

    .line 53
    invoke-direct/range {v4 .. v10}, Lio/sentry/b0;-><init>(Lio/sentry/a1;Lio/sentry/f1;Lio/sentry/ILogger;JI)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    new-instance v5, Ljava/io/File;

    .line 61
    .line 62
    invoke-direct {v5, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    new-instance v1, Lcg/q;

    .line 66
    .line 67
    const/4 v6, 0x3

    .line 68
    invoke-direct/range {v1 .. v6}, Lcg/q;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 69
    .line 70
    .line 71
    return-object v1

    .line 72
    :cond_47
    :goto_47
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    sget-object p2, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 77
    .line 78
    const/4 v0, 0x0

    .line 79
    new-array v0, v0, [Ljava/lang/Object;

    .line 80
    .line 81
    const-string v1, "No cache dir path is defined in options."

    .line 82
    .line 83
    invoke-interface {p1, p2, v1, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    const/4 p1, 0x0

    .line 87
    return-object p1
.end method

.method public k(Landroid/graphics/Typeface;)V
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lew/a;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lew/a;->m(Landroid/graphics/Typeface;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public l(Lo/k;Landroid/view/MenuItem;)Z
    .registers 3

    .line 1
    iget-object p1, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, Lvv/e;

    .line 4
    .line 5
    iget-object p1, p1, Lhw/q;->w:Lhw/o;

    .line 6
    .line 7
    if-eqz p1, :cond_16

    .line 8
    .line 9
    check-cast p1, Lio/sentry/android/core/n0;

    .line 10
    .line 11
    iget-object p1, p1, Lio/sentry/android/core/n0;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lo20/f;

    .line 14
    .line 15
    invoke-static {p1, p2}, Lo20/f;->d(Lo20/f;Landroid/view/MenuItem;)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    if-nez p1, :cond_16

    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    return p1

    .line 23
    :cond_16
    const/4 p1, 0x0

    .line 24
    return p1
.end method

.method public m()I
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    iget v1, v0, Landroidx/recyclerview/widget/a;->P:I

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a;->getPaddingRight()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    sub-int/2addr v1, v0

    .line 12
    return v1
.end method

.method public n(I)Landroid/view/View;
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/a;->G(I)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public p(Landroid/graphics/Bitmap;)V
    .registers 2

    .line 1
    return-void
.end method

.method public r(Landroid/view/View;)I
    .registers 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Le6/v0;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/a;->P(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 12
    .line 13
    add-int/2addr p1, v0

    .line 14
    return p1
.end method

.method public s(Ljava/lang/Exception;)V
    .registers 4

    .line 1
    instance-of v0, p1, Lfu/e;

    .line 2
    .line 3
    if-eqz v0, :cond_1f

    .line 4
    .line 5
    check-cast p1, Lfu/e;

    .line 6
    .line 7
    iget-object p1, p1, Lfu/e;->d:Lcom/google/android/gms/common/api/Status;

    .line 8
    .line 9
    iget-object p1, p1, Lcom/google/android/gms/common/api/Status;->v:Leu/b;

    .line 10
    .line 11
    if-eqz p1, :cond_1f

    .line 12
    .line 13
    iget p1, p1, Leu/b;->e:I

    .line 14
    .line 15
    const/16 v0, 0x18

    .line 16
    .line 17
    if-ne p1, v0, :cond_1f

    .line 18
    .line 19
    iget-object p1, p0, La8/c;->d:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p1, Lcom/google/android/gms/net/c;

    .line 22
    .line 23
    iget-object p1, p1, Lcom/google/android/gms/net/c;->b:Ljava/util/concurrent/atomic/AtomicLong;

    .line 24
    .line 25
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 26
    .line 27
    .line 28
    move-result-wide v0

    .line 29
    invoke-virtual {p1, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    .line 30
    .line 31
    .line 32
    :cond_1f
    return-void
.end method

.method public setParameters(Landroid/os/Bundle;)V
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/media/MediaCodec;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/media/MediaCodec;->setParameters(Landroid/os/Bundle;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public shutdown()V
    .registers 1

    .line 1
    return-void
.end method

.method public start()V
    .registers 1

    .line 1
    return-void
.end method

.method public t(Z)V
    .registers 3

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/core/view/v1;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroidx/core/view/v1;->s0(Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public u(Ljava/lang/String;)Ljava/io/File;
    .registers 6

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    .line 3
    invoke-virtual {p0}, La8/c;->w()Ljava/io/File;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, La8/b;->e:La8/b;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    invoke-static {p1, v2, v3}, La8/c;->q(Ljava/lang/String;La8/b;Z)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_17

    .line 22
    .line 23
    return-object v0

    .line 24
    :cond_17
    new-instance v0, Ljava/io/File;

    .line 25
    .line 26
    invoke-virtual {p0}, La8/c;->w()Ljava/io/File;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    sget-object v2, La8/b;->i:La8/b;

    .line 31
    .line 32
    invoke-static {p1, v2, v3}, La8/c;->q(Ljava/lang/String;La8/b;Z)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_2d

    .line 44
    .line 45
    return-object v0

    .line 46
    :cond_2d
    new-instance v0, Ljava/io/File;

    .line 47
    .line 48
    invoke-virtual {p0}, La8/c;->w()Ljava/io/File;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sget-object v2, La8/b;->v:La8/b;

    .line 53
    .line 54
    invoke-static {p1, v2, v3}, La8/c;->q(Ljava/lang/String;La8/b;Z)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-direct {v0, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    if-eqz p1, :cond_43

    .line 66
    .line 67
    return-object v0

    .line 68
    :cond_43
    const/4 p1, 0x0

    .line 69
    return-object p1
.end method

.method public v(Lg8/g;Ldx/e;)V
    .registers 5

    .line 1
    const-string v0, "billingResult"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lz60/q;

    .line 9
    .line 10
    new-instance v1, Lc9/d;

    .line 11
    .line 12
    invoke-direct {v1, p1, p2}, Lc9/d;-><init>(Lg8/g;Ldx/e;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0, v1}, Lz60/k1;->P(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public w()Ljava/io/File;
    .registers 4

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lc7/n;

    .line 4
    .line 5
    iget-object v0, v0, Lc7/n;->e:Landroid/content/Context;

    .line 6
    .line 7
    new-instance v1, Ljava/io/File;

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const-string v2, "lottie_network_cache"

    .line 14
    .line 15
    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_1a

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 25
    .line 26
    .line 27
    :cond_1a
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_23

    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 34
    .line 35
    .line 36
    :cond_23
    return-object v1
.end method

.method public x(Le6/l1;Landroidx/core/view/t;Landroidx/core/view/t;)V
    .registers 12

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {p1, v1}, Le6/l1;->s(Z)V

    .line 7
    .line 8
    .line 9
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->r0:Le6/s0;

    .line 10
    .line 11
    move-object v2, v1

    .line 12
    check-cast v2, Le6/n;

    .line 13
    .line 14
    if-eqz p2, :cond_1f

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    iget v4, p2, Landroidx/core/view/t;->b:I

    .line 20
    .line 21
    iget v6, p3, Landroidx/core/view/t;->b:I

    .line 22
    .line 23
    if-ne v4, v6, :cond_21

    .line 24
    .line 25
    iget v1, p2, Landroidx/core/view/t;->c:I

    .line 26
    .line 27
    iget v3, p3, Landroidx/core/view/t;->c:I

    .line 28
    .line 29
    if-eq v1, v3, :cond_1f

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    move-object v3, p1

    .line 33
    goto :goto_2b

    .line 34
    :cond_21
    :goto_21
    iget v5, p2, Landroidx/core/view/t;->c:I

    .line 35
    .line 36
    iget v7, p3, Landroidx/core/view/t;->c:I

    .line 37
    .line 38
    move-object v3, p1

    .line 39
    invoke-virtual/range {v2 .. v7}, Le6/n;->i(Le6/l1;IIII)Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    goto :goto_2f

    .line 44
    :goto_2b
    invoke-virtual {v2, v3}, Le6/n;->g(Le6/l1;)V

    .line 45
    .line 46
    .line 47
    const/4 p1, 0x1

    .line 48
    :goto_2f
    if-eqz p1, :cond_34

    .line 49
    .line 50
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->a0()V

    .line 51
    .line 52
    .line 53
    :cond_34
    return-void
.end method

.method public y(Le6/l1;Landroidx/core/view/t;Landroidx/core/view/t;)V
    .registers 12

    .line 1
    iget-object v0, p0, La8/c;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->i:Le6/b1;

    .line 6
    .line 7
    invoke-virtual {v1, p1}, Le6/b1;->o(Le6/l1;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;->g(Le6/l1;)V

    .line 11
    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-virtual {p1, v1}, Le6/l1;->s(Z)V

    .line 15
    .line 16
    .line 17
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->r0:Le6/s0;

    .line 18
    .line 19
    move-object v2, v1

    .line 20
    check-cast v2, Le6/n;

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    iget v4, p2, Landroidx/core/view/t;->b:I

    .line 26
    .line 27
    iget v5, p2, Landroidx/core/view/t;->c:I

    .line 28
    .line 29
    iget-object p2, p1, Le6/l1;->a:Landroid/view/View;

    .line 30
    .line 31
    if-nez p3, :cond_26

    .line 32
    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    :goto_24
    move v6, v1

    .line 38
    goto :goto_29

    .line 39
    :cond_26
    iget v1, p3, Landroidx/core/view/t;->b:I

    .line 40
    .line 41
    goto :goto_24

    .line 42
    :goto_29
    if-nez p3, :cond_31

    .line 43
    .line 44
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    .line 45
    .line 46
    .line 47
    move-result p3

    .line 48
    :goto_2f
    move v7, p3

    .line 49
    goto :goto_34

    .line 50
    :cond_31
    iget p3, p3, Landroidx/core/view/t;->c:I

    .line 51
    .line 52
    goto :goto_2f

    .line 53
    :goto_34
    invoke-virtual {p1}, Le6/l1;->m()Z

    .line 54
    .line 55
    .line 56
    move-result p3

    .line 57
    if-nez p3, :cond_3f

    .line 58
    .line 59
    if-ne v4, v6, :cond_41

    .line 60
    .line 61
    if-eq v5, v7, :cond_3f

    .line 62
    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    move-object v3, p1

    .line 65
    goto :goto_54

    .line 66
    :cond_41
    :goto_41
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    .line 67
    .line 68
    .line 69
    move-result p3

    .line 70
    add-int/2addr p3, v6

    .line 71
    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    add-int/2addr v1, v7

    .line 76
    invoke-virtual {p2, v6, v7, p3, v1}, Landroid/view/View;->layout(IIII)V

    .line 77
    .line 78
    .line 79
    move-object v3, p1

    .line 80
    invoke-virtual/range {v2 .. v7}, Le6/n;->i(Le6/l1;IIII)Z

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    goto :goto_58

    .line 85
    :goto_54
    invoke-virtual {v2, v3}, Le6/n;->j(Le6/l1;)V

    .line 86
    .line 87
    .line 88
    const/4 p1, 0x1

    .line 89
    :goto_58
    if-eqz p1, :cond_5d

    .line 90
    .line 91
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->a0()V

    .line 92
    .line 93
    .line 94
    :cond_5d
    return-void
.end method

.method public z(Ljava/lang/String;Ljava/io/InputStream;La8/b;)Ljava/io/File;
    .registers 7

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p1, p3, v0}, La8/c;->q(Ljava/lang/String;La8/b;Z)Ljava/lang/String;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    new-instance p3, Ljava/io/File;

    .line 7
    .line 8
    invoke-virtual {p0}, La8/c;->w()Ljava/io/File;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-direct {p3, v0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    :try_start_e
    new-instance p1, Ljava/io/FileOutputStream;

    .line 16
    .line 17
    invoke-direct {p1, p3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_13
    .catchall {:try_start_e .. :try_end_13} :catchall_2f

    .line 18
    .line 19
    .line 20
    const/16 v0, 0x400

    .line 21
    .line 22
    :try_start_15
    new-array v0, v0, [B

    .line 23
    .line 24
    :goto_17
    invoke-virtual {p2, v0}, Ljava/io/InputStream;->read([B)I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    const/4 v2, -0x1

    .line 29
    if-eq v1, v2, :cond_25

    .line 30
    .line 31
    const/4 v2, 0x0

    .line 32
    invoke-virtual {p1, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    .line 33
    .line 34
    .line 35
    goto :goto_17

    .line 36
    :catchall_23
    move-exception p3

    .line 37
    goto :goto_31

    .line 38
    :cond_25
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V
    :try_end_28
    .catchall {:try_start_15 .. :try_end_28} :catchall_23

    .line 39
    .line 40
    .line 41
    :try_start_28
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V
    :try_end_2b
    .catchall {:try_start_28 .. :try_end_2b} :catchall_2f

    .line 42
    .line 43
    .line 44
    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    .line 45
    .line 46
    .line 47
    return-object p3

    .line 48
    :catchall_2f
    move-exception p1

    .line 49
    goto :goto_35

    .line 50
    :goto_31
    :try_start_31
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V

    .line 51
    .line 52
    .line 53
    throw p3
    :try_end_35
    .catchall {:try_start_31 .. :try_end_35} :catchall_2f

    .line 54
    :goto_35
    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    .line 55
    .line 56
    .line 57
    throw p1
.end method
