###### Class a8.d (a8.d)
.class public La8/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lgu/h;
.implements Lg/b;
.implements Lc6/d;
.implements Landroidx/core/view/j;
.implements Le6/t1;
.implements Lkw/a;
.implements Lb30/b;
.implements Lg60/e;
.implements Lgx/u;
.implements Lgx/k;
.implements Lio/sentry/m1;
.implements Lio/sentry/b4;
.implements Ldr/b;
.implements Lp/k3;
.implements Lj60/n;
.implements Lj4/i;


# instance fields
.field public final synthetic d:I

.field public e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 4

    iput p1, p0, La8/d;->d:I

    sparse-switch p1, :sswitch_data_60

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void

    .line 7
    :sswitch_11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance p1, Lio/sentry/util/e;

    new-instance v0, Lio/sentry/p2;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lio/sentry/p2;-><init>(I)V

    invoke-direct {p1, v0}, Lio/sentry/util/e;-><init>(Lio/sentry/util/d;)V

    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void

    .line 9
    :sswitch_23
    new-instance p1, Lio/sentry/android/core/j0;

    sget-object v0, Lio/sentry/m2;->d:Lio/sentry/m2;

    invoke-direct {p1, v0}, Lio/sentry/android/core/j0;-><init>(Lio/sentry/ILogger;)V

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void

    .line 12
    :sswitch_30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void

    .line 13
    :sswitch_34
    new-instance p1, Lzm/n;

    const/4 v0, 0x7

    .line 14
    invoke-direct {p1, v0}, Lzm/n;-><init>(I)V

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void

    .line 17
    :sswitch_40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    new-instance p1, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {p1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void

    .line 19
    :sswitch_4b
    sget-object p1, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    .line 20
    const-string v0, "timeUnit"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    new-instance p1, Lf80/n;

    .line 22
    sget-object v0, Le80/c;->h:Le80/c;

    .line 23
    invoke-direct {p1, v0}, Lf80/n;-><init>(Le80/c;)V

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void

    nop

    :sswitch_data_60
    .sparse-switch
        0x5 -> :sswitch_4b
        0x9 -> :sswitch_40
        0xc -> :sswitch_34
        0x10 -> :sswitch_30
        0x18 -> :sswitch_23
        0x19 -> :sswitch_11
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, La8/d;->d:I

    iput-object p2, p0, La8/d;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(La8/c;Lil/c;)V
    .registers 3

    const/4 p2, 0x0

    iput p2, p0, La8/d;->d:I

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/res/Resources;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, La8/d;->d:I

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    iput-object p1, p0, La8/d;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lav/e;Lyt/e;)V
    .registers 3

    const/4 p1, 0x3

    iput p1, p0, La8/d;->d:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La8/d;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lh9/x1;Lo8/c;Lcom/discord/MainApplication;)V
    .registers 4

    const/16 p1, 0x13

    iput p1, p0, La8/d;->d:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p3, p0, La8/d;->e:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public C(F)Z
    .registers 6

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->P:Landroidx/recyclerview/widget/a;

    .line 6
    .line 7
    invoke-virtual {v1}, Landroidx/recyclerview/widget/a;->q()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v1, :cond_11

    .line 13
    .line 14
    float-to-int p1, p1

    .line 15
    move v1, p1

    .line 16
    move p1, v2

    .line 17
    goto :goto_1e

    .line 18
    :cond_11
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->P:Landroidx/recyclerview/widget/a;

    .line 19
    .line 20
    invoke-virtual {v1}, Landroidx/recyclerview/widget/a;->p()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_1c

    .line 25
    .line 26
    float-to-int p1, p1

    .line 27
    move v1, v2

    .line 28
    goto :goto_1e

    .line 29
    :cond_1c
    move p1, v2

    .line 30
    move v1, p1

    .line 31
    :goto_1e
    if-nez p1, :cond_23

    .line 32
    .line 33
    if-nez v1, :cond_23

    .line 34
    .line 35
    return v2

    .line 36
    :cond_23
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->t0()V

    .line 37
    .line 38
    .line 39
    const v3, 0x7fffffff

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0, p1, v1, v2, v3}, Landroidx/recyclerview/widget/RecyclerView;->J(IIII)Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    return p1
.end method

.method public L()F
    .registers 3

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->P:Landroidx/recyclerview/widget/a;

    .line 6
    .line 7
    invoke-virtual {v1}, Landroidx/recyclerview/widget/a;->q()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_10

    .line 12
    .line 13
    iget v0, v0, Landroidx/recyclerview/widget/RecyclerView;->E0:F

    .line 14
    .line 15
    :goto_e
    neg-float v0, v0

    .line 16
    return v0

    .line 17
    :cond_10
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->P:Landroidx/recyclerview/widget/a;

    .line 18
    .line 19
    invoke-virtual {v1}, Landroidx/recyclerview/widget/a;->p()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-eqz v1, :cond_1b

    .line 24
    .line 25
    iget v0, v0, Landroidx/recyclerview/widget/RecyclerView;->D0:F

    .line 26
    .line 27
    goto :goto_e

    .line 28
    :cond_1b
    const/4 v0, 0x0

    .line 29
    return v0
.end method

.method public N()V
    .registers 2

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->t0()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public a(Lcom/google/android/gms/internal/fido/f8;Ljava/lang/CharSequence;)Ljava/util/Iterator;
    .registers 5

    .line 1
    new-instance v0, Lgx/t;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, p1, p2, v1}, Lgx/t;-><init>(Lgx/u;Lcom/google/android/gms/internal/fido/f8;Ljava/lang/CharSequence;I)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p1, Lav/f;

    .line 2
    .line 3
    check-cast p2, Lnv/h;

    .line 4
    .line 5
    new-instance v0, Lav/c;

    .line 6
    .line 7
    invoke-direct {v0, p2}, Lav/c;-><init>(Lnv/h;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Lhu/c;->i()Landroid/os/IInterface;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lav/m;

    .line 15
    .line 16
    iget-object p2, p0, La8/d;->e:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p2, Lyt/e;

    .line 19
    .line 20
    invoke-virtual {p1}, Lav/a;->r()Landroid/os/Parcel;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    sget v2, Lav/j;->a:I

    .line 25
    .line 26
    invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    .line 27
    .line 28
    .line 29
    invoke-static {v1, p2}, Lav/j;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    .line 30
    .line 31
    .line 32
    const/4 p2, 0x1

    .line 33
    invoke-virtual {p1, p2, v1}, Lav/a;->v(ILandroid/os/Parcel;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, Ljava/util/Map$Entry;

    .line 2
    .line 3
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lhx/k1;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v1, Lhx/i1;

    .line 14
    .line 15
    invoke-direct {v1, p1, v0}, Lhx/i1;-><init>(Ljava/util/Map$Entry;Lhx/k1;)V

    .line 16
    .line 17
    .line 18
    return-object v1
.end method

.method public b(Landroid/view/View;)I
    .registers 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Le6/v0;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/a;->Q(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 12
    .line 13
    sub-int/2addr p1, v0

    .line 14
    return p1
.end method

.method public c(Lj4/k;JJ)V
    .registers 17

    .line 1
    check-cast p1, Lj4/p;

    .line 2
    .line 3
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ld20/z;

    .line 6
    .line 7
    iget-boolean v0, v0, Ld20/z;->a:Z

    .line 8
    .line 9
    if-nez v0, :cond_b

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    iget-object v0, p1, Lj4/p;->f:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Lk4/c;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, La8/d;->e:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v1, Ld20/z;

    .line 22
    .line 23
    iput-object v0, v1, Ld20/z;->h:Ljava/lang/Object;

    .line 24
    .line 25
    iget-object v1, v1, Ld20/z;->d:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v1, Ln3/g0;

    .line 28
    .line 29
    new-instance v2, Lio/sentry/react/c;

    .line 30
    .line 31
    const/4 v3, 0x3

    .line 32
    invoke-direct {v2, v3, p0, v0}, Lio/sentry/react/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1, v2}, Ln3/g0;->e(Ljava/lang/Runnable;)Z

    .line 36
    .line 37
    .line 38
    iget-object v1, p0, La8/d;->e:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v1, Ld20/z;

    .line 41
    .line 42
    iget-object v2, v1, Ld20/z;->e:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v2, Landroid/net/Uri;

    .line 45
    .line 46
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    iget-object v3, v0, Lk4/c;->c:Landroid/net/Uri;

    .line 50
    .line 51
    if-nez v3, :cond_35

    .line 52
    .line 53
    goto :goto_53

    .line 54
    :cond_35
    invoke-virtual {v3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    if-eqz v4, :cond_47

    .line 59
    .line 60
    invoke-static {v4}, Ln3/e;->f(Ljava/lang/String;)[I

    .line 61
    .line 62
    .line 63
    move-result-object v4

    .line 64
    const/4 v5, 0x0

    .line 65
    aget v4, v4, v5

    .line 66
    .line 67
    const/4 v5, -0x1

    .line 68
    if-eq v4, v5, :cond_47

    .line 69
    .line 70
    move-object v2, v3

    .line 71
    goto :goto_53

    .line 72
    :cond_47
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    invoke-virtual {v3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    invoke-static {v2, v3}, Ln3/e;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    :goto_53
    iput-object v2, v1, Ld20/z;->e:Ljava/lang/Object;

    .line 85
    .line 86
    iget-wide v0, v0, Lk4/c;->b:J

    .line 87
    .line 88
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    cmp-long v2, v0, v2

    .line 94
    .line 95
    if-eqz v2, :cond_61

    .line 96
    .line 97
    goto :goto_64

    .line 98
    :cond_61
    const-wide/32 v0, 0x493e0

    .line 99
    .line 100
    .line 101
    :goto_64
    iget-object v2, p0, La8/d;->e:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v2, Ld20/z;

    .line 104
    .line 105
    iget-object v2, v2, Ld20/z;->i:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v2, Ln3/g0;

    .line 108
    .line 109
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    iget-object v3, p0, La8/d;->e:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v3, Ld20/z;

    .line 115
    .line 116
    new-instance v4, Lk4/d;

    .line 117
    .line 118
    const/4 v5, 0x0

    .line 119
    invoke-direct {v4, v3, v5}, Lk4/d;-><init>(Ld20/z;I)V

    .line 120
    .line 121
    .line 122
    iget-object v2, v2, Ln3/g0;->a:Landroid/os/Handler;

    .line 123
    .line 124
    invoke-virtual {v2, v4, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 125
    .line 126
    .line 127
    move-wide v0, p4

    .line 128
    invoke-static {p1, p2, p3, v0, v1}, Ld20/z;->a(Lj4/p;JJ)Lf4/u;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    iget-object p1, p0, La8/d;->e:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast p1, Ld20/z;

    .line 135
    .line 136
    iget-object p1, p1, Ld20/z;->g:Ljava/lang/Object;

    .line 137
    .line 138
    move-object v0, p1

    .line 139
    check-cast v0, Lcom/google/android/gms/internal/fido/f8;

    .line 140
    .line 141
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 142
    .line 143
    .line 144
    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    const/16 v2, 0x8

    .line 155
    .line 156
    const/4 v3, -0x1

    .line 157
    const/4 v4, 0x0

    .line 158
    const/4 v6, 0x0

    .line 159
    invoke-virtual/range {v0 .. v10}, Lcom/google/android/gms/internal/fido/f8;->x(Lf4/u;IILk3/w;ILjava/lang/Object;JJ)V

    .line 160
    .line 161
    .line 162
    return-void
.end method

.method public d(Ljava/lang/Object;)V
    .registers 7

    .line 1
    iget v0, p0, La8/d;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_96

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;

    .line 9
    .line 10
    check-cast p1, Lg/a;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    iget-object v1, p1, Lg/a;->e:Landroid/content/Intent;

    .line 16
    .line 17
    const-string v2, "ProxyBillingActivityV2"

    .line 18
    .line 19
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/play_billing/r;->e(Landroid/content/Intent;Ljava/lang/String;)Lg8/g;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    iget v3, v3, Lg8/g;->a:I

    .line 24
    .line 25
    iget-object v4, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->c0:Landroid/os/ResultReceiver;

    .line 26
    .line 27
    if-eqz v4, :cond_27

    .line 28
    .line 29
    if-nez v1, :cond_20

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    goto :goto_24

    .line 33
    :cond_20
    invoke-virtual {v1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    :goto_24
    invoke-virtual {v4, v3, v1}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    .line 38
    .line 39
    .line 40
    :cond_27
    iget p1, p1, Lg/a;->d:I

    .line 41
    .line 42
    const/4 v1, -0x1

    .line 43
    if-ne p1, v1, :cond_2e

    .line 44
    .line 45
    if-eqz v3, :cond_47

    .line 46
    .line 47
    :cond_2e
    new-instance v1, Ljava/lang/StringBuilder;

    .line 48
    .line 49
    const-string v4, "External offer dialog finished with resultCode: "

    .line 50
    .line 51
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string p1, " and billing\'s responseCode: "

    .line 58
    .line 59
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-static {v2, p1}, Lcom/google/android/gms/internal/play_billing/r;->h(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    :cond_47
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :pswitch_4b
    check-cast p1, Lg/a;

    .line 77
    .line 78
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Lb3/x0;

    .line 81
    .line 82
    iget-object v1, v0, Lb3/x0;->F:Ljava/util/ArrayDeque;

    .line 83
    .line 84
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->pollLast()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    check-cast v1, Lb3/s0;

    .line 89
    .line 90
    const-string v2, "FragmentManager"

    .line 91
    .line 92
    if-nez v1, :cond_6f

    .line 93
    .line 94
    new-instance p1, Ljava/lang/StringBuilder;

    .line 95
    .line 96
    const-string v0, "No Activities were started for result for "

    .line 97
    .line 98
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 109
    .line 110
    .line 111
    goto :goto_94

    .line 112
    :cond_6f
    iget-object v3, v1, Lb3/s0;->d:Ljava/lang/String;

    .line 113
    .line 114
    iget v1, v1, Lb3/s0;->e:I

    .line 115
    .line 116
    iget-object v0, v0, Lb3/x0;->c:Lcom/google/firebase/messaging/t;

    .line 117
    .line 118
    invoke-virtual {v0, v3}, Lcom/google/firebase/messaging/t;->g(Ljava/lang/String;)Lb3/a0;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    if-nez v0, :cond_8d

    .line 123
    .line 124
    new-instance p1, Ljava/lang/StringBuilder;

    .line 125
    .line 126
    const-string v0, "Activity result delivered for unknown Fragment "

    .line 127
    .line 128
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 139
    .line 140
    .line 141
    goto :goto_94

    .line 142
    :cond_8d
    iget v2, p1, Lg/a;->d:I

    .line 143
    .line 144
    iget-object p1, p1, Lg/a;->e:Landroid/content/Intent;

    .line 145
    .line 146
    invoke-virtual {v0, v1, v2, p1}, Lb3/a0;->z(IILandroid/content/Intent;)V

    .line 147
    .line 148
    .line 149
    :goto_94
    return-void

    .line 150
    nop

    .line 151
    :pswitch_data_96
    .packed-switch 0x4
        :pswitch_4b
    .end packed-switch
.end method

.method public e()Z
    .registers 3

    .line 1
    invoke-static {}, Lio/sentry/y4;->d()Lio/sentry/y4;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, La8/d;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lio/sentry/a6;

    .line 8
    .line 9
    invoke-virtual {v1}, Lio/sentry/a6;->getFatalLogger()Lio/sentry/ILogger;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v0, v1}, Lio/sentry/y4;->c(Lio/sentry/ILogger;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    return v0
.end method

.method public f(Lt50/b;)Lg60/d;
    .registers 5

    .line 1
    const-string v0, "classId"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lq40/g0;

    .line 9
    .line 10
    iget-object v1, p1, Lt50/b;->a:Lt50/c;

    .line 11
    .line 12
    invoke-static {v0, v1}, Lq40/v;->i(Lq40/g0;Lt50/c;)Ljava/util/ArrayList;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    :cond_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_2e

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Lq40/d0;

    .line 31
    .line 32
    instance-of v2, v1, Lh60/c;

    .line 33
    .line 34
    if-eqz v2, :cond_13

    .line 35
    .line 36
    check-cast v1, Lh60/c;

    .line 37
    .line 38
    iget-object v1, v1, Lh60/c;->L:Lcom/google/firebase/messaging/t;

    .line 39
    .line 40
    invoke-virtual {v1, p1}, Lcom/google/firebase/messaging/t;->f(Lt50/b;)Lg60/d;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    if-eqz v1, :cond_13

    .line 45
    .line 46
    return-object v1

    .line 47
    :cond_2e
    const/4 p1, 0x0

    .line 48
    return-object p1
.end method

.method public g()I
    .registers 2

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a;->getPaddingTop()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public get()Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljavax/inject/Provider;

    .line 4
    .line 5
    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/content/Context;

    .line 10
    .line 11
    sget v1, Lir/j;->v:I

    .line 12
    .line 13
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    new-instance v2, Lir/j;

    .line 22
    .line 23
    const-string v3, "com.google.android.datatransport.events"

    .line 24
    .line 25
    invoke-direct {v2, v1, v0, v3}, Lir/j;-><init>(ILandroid/content/Context;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    return-object v2
.end method

.method public h(Lj4/k;JJI)V
    .registers 20

    .line 1
    check-cast p1, Lj4/p;

    .line 2
    .line 3
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ld20/z;

    .line 6
    .line 7
    iget-boolean v1, v0, Ld20/z;->a:Z

    .line 8
    .line 9
    if-nez v1, :cond_b

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    move-wide v1, p2

    .line 13
    move-wide/from16 v3, p4

    .line 14
    .line 15
    invoke-static {p1, v1, v2, v3, v4}, Ld20/z;->a(Lj4/p;JJ)Lf4/u;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    iget-object p1, v0, Ld20/z;->g:Ljava/lang/Object;

    .line 20
    .line 21
    move-object v1, p1

    .line 22
    check-cast v1, Lcom/google/android/gms/internal/fido/f8;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    const/16 v3, 0x8

    .line 38
    .line 39
    const/4 v4, -0x1

    .line 40
    const/4 v5, 0x0

    .line 41
    const/4 v6, 0x0

    .line 42
    const/4 v7, 0x0

    .line 43
    move/from16 v12, p6

    .line 44
    .line 45
    invoke-virtual/range {v1 .. v12}, Lcom/google/android/gms/internal/fido/f8;->H(Lf4/u;IILk3/w;ILjava/lang/Object;JJI)V

    .line 46
    .line 47
    .line 48
    return-void
.end method

.method public i(I)Ljava/nio/ByteBuffer;
    .registers 3

    .line 1
    invoke-static {p1}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 6
    .line 7
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    const-string v0, "{\n            ByteBuffer\u2026.LITTLE_ENDIAN)\n        }"

    .line 12
    .line 13
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object p1
.end method

.method public j(Lio/sentry/a1;Lio/sentry/a6;)Lcg/q;
    .registers 15

    .line 1
    const-string v0, "Scopes are required"

    .line 2
    .line 3
    invoke-static {p1, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "SentryOptions is required"

    .line 7
    .line 8
    invoke-static {p2, v0}, Ls1/e;->E(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/discord/crash_reporting/f;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/discord/crash_reporting/f;->d:Lio/sentry/android/core/SentryAndroidOptions;

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/sentry/a6;->getOutboxPath()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    if-eqz v3, :cond_4b

    .line 22
    .line 23
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v3, v0}, Lio/sentry/b4;->o(Ljava/lang/String;Lio/sentry/ILogger;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_21

    .line 32
    .line 33
    goto :goto_4b

    .line 34
    :cond_21
    new-instance v4, Lio/sentry/d3;

    .line 35
    .line 36
    invoke-virtual {p2}, Lio/sentry/a6;->getEnvelopeReader()Lio/sentry/r0;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    invoke-virtual {p2}, Lio/sentry/a6;->getSerializer()Lio/sentry/f1;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 45
    .line 46
    .line 47
    move-result-object v8

    .line 48
    invoke-virtual {p2}, Lio/sentry/a6;->getFlushTimeoutMillis()J

    .line 49
    .line 50
    .line 51
    move-result-wide v9

    .line 52
    invoke-virtual {p2}, Lio/sentry/a6;->getMaxQueueSize()I

    .line 53
    .line 54
    .line 55
    move-result v11

    .line 56
    move-object v5, p1

    .line 57
    invoke-direct/range {v4 .. v11}, Lio/sentry/d3;-><init>(Lio/sentry/a1;Lio/sentry/r0;Lio/sentry/f1;Lio/sentry/ILogger;JI)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    new-instance v5, Ljava/io/File;

    .line 65
    .line 66
    invoke-direct {v5, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    new-instance v1, Lcg/q;

    .line 70
    .line 71
    const/4 v6, 0x3

    .line 72
    invoke-direct/range {v1 .. v6}, Lcg/q;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 73
    .line 74
    .line 75
    return-object v1

    .line 76
    :cond_4b
    :goto_4b
    invoke-virtual {p2}, Lio/sentry/a6;->getLogger()Lio/sentry/ILogger;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    sget-object p2, Lio/sentry/a5;->ERROR:Lio/sentry/a5;

    .line 81
    .line 82
    const/4 v0, 0x0

    .line 83
    new-array v0, v0, [Ljava/lang/Object;

    .line 84
    .line 85
    const-string v1, "No outbox dir path is defined in options."

    .line 86
    .line 87
    invoke-interface {p1, p2, v1, v0}, Lio/sentry/ILogger;->m(Lio/sentry/a5;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    const/4 p1, 0x0

    .line 91
    return-object p1
.end method

.method public k(Landroid/graphics/Typeface;)V
    .registers 3

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lew/a;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lew/a;->q(Landroid/graphics/Typeface;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public l(Lk3/w;)Ljava/lang/String;
    .registers 9

    .line 1
    iget-object v0, p1, Lk3/w;->d:Ljava/lang/String;

    .line 2
    .line 3
    iget-object v1, p1, Lk3/w;->b:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const-string v3, ""

    .line 10
    .line 11
    if-nez v2, :cond_2b

    .line 12
    .line 13
    const-string v2, "und"

    .line 14
    .line 15
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-eqz v2, :cond_15

    .line 20
    .line 21
    goto :goto_2b

    .line 22
    :cond_15
    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sget-object v2, Ln3/l0;->a:Ljava/lang/String;

    .line 27
    .line 28
    sget-object v2, Ljava/util/Locale$Category;->DISPLAY:Ljava/util/Locale$Category;

    .line 29
    .line 30
    invoke-static {v2}, Ljava/util/Locale;->getDefault(Ljava/util/Locale$Category;)Ljava/util/Locale;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {v0, v2}, Ljava/util/Locale;->getDisplayName(Ljava/util/Locale;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 39
    .line 40
    .line 41
    move-result v4

    .line 42
    if-eqz v4, :cond_2d

    .line 43
    .line 44
    :cond_2b
    :goto_2b
    move-object v0, v3

    .line 45
    goto :goto_4e

    .line 46
    :cond_2d
    const/4 v4, 0x1

    .line 47
    const/4 v5, 0x0

    .line 48
    :try_start_2f
    invoke-virtual {v0, v5, v4}, Ljava/lang/String;->offsetByCodePoints(II)I

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    new-instance v6, Ljava/lang/StringBuilder;

    .line 53
    .line 54
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    invoke-virtual {v5, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0
    :try_end_4e
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_2f .. :try_end_4e} :catch_4e

    .line 79
    :catch_4e
    :goto_4e
    invoke-virtual {p0, p1}, La8/d;->p(Lk3/w;)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    filled-new-array {v0, p1}, [Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    invoke-virtual {p0, p1}, La8/d;->x([Ljava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_68

    .line 96
    .line 97
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 98
    .line 99
    .line 100
    move-result p1

    .line 101
    if-eqz p1, :cond_67

    .line 102
    .line 103
    move-object v1, v3

    .line 104
    :cond_67
    move-object p1, v1

    .line 105
    :cond_68
    return-object p1
.end method

.method public lock()V
    .registers 2

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/concurrent/locks/ReentrantLock;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public m()I
    .registers 3

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    iget v1, v0, Landroidx/recyclerview/widget/a;->Q:I

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a;->getPaddingBottom()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    sub-int/2addr v1, v0

    .line 12
    return v1
.end method

.method public n(I)Landroid/view/View;
    .registers 3

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/a;->G(I)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public onMenuItemClick(Landroid/view/MenuItem;)Z
    .registers 4

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lj/f0;

    .line 4
    .line 5
    iget-object v0, v0, Lj/f0;->f:Landroid/view/Window$Callback;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-interface {v0, v1, p1}, Landroid/view/Window$Callback;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1
.end method

.method public p(Lk3/w;)Ljava/lang/String;
    .registers 5

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/Resources;

    .line 4
    .line 5
    iget p1, p1, Lk3/w;->f:I

    .line 6
    .line 7
    and-int/lit8 v1, p1, 0x2

    .line 8
    .line 9
    if-eqz v1, :cond_12

    .line 10
    .line 11
    const v1, 0x7f1300bd

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    goto :goto_14

    .line 19
    :cond_12
    const-string v1, ""

    .line 20
    .line 21
    :goto_14
    and-int/lit8 v2, p1, 0x4

    .line 22
    .line 23
    if-eqz v2, :cond_27

    .line 24
    .line 25
    const v2, 0x7f1300c0

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    filled-new-array {v1, v2}, [Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {p0, v1}, La8/d;->x([Ljava/lang/String;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    :cond_27
    and-int/lit8 v2, p1, 0x8

    .line 41
    .line 42
    if-eqz v2, :cond_3a

    .line 43
    .line 44
    const v2, 0x7f1300bf

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    filled-new-array {v1, v2}, [Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    invoke-virtual {p0, v1}, La8/d;->x([Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    :cond_3a
    and-int/lit16 p1, p1, 0x440

    .line 60
    .line 61
    if-eqz p1, :cond_4e

    .line 62
    .line 63
    const p1, 0x7f1300be

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    filled-new-array {v1, p1}, [Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-virtual {p0, p1}, La8/d;->x([Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    return-object p1

    .line 79
    :cond_4e
    return-object v1
.end method

.method public q()V
    .registers 3

    .line 1
    const-string v0, "DIAGNOSTIC_PROFILE_IS_COMPRESSED"

    .line 2
    .line 3
    const-string v1, "ProfileInstaller"

    .line 4
    .line 5
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public r(Landroid/view/View;)I
    .registers 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Le6/v0;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/a;->K(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 12
    .line 13
    add-int/2addr p1, v0

    .line 14
    return p1
.end method

.method public s(Lio/sentry/android/core/q0;)V
    .registers 4

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lio/sentry/android/core/j0;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v1, 0x1a

    .line 11
    .line 12
    if-lt v0, v1, :cond_2e

    .line 13
    .line 14
    const/16 v1, 0x1c

    .line 15
    .line 16
    if-gt v0, v1, :cond_2e

    .line 17
    .line 18
    invoke-virtual {p1}, Landroid/content/ContentProvider;->getCallingPackage()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    if-eqz v0, :cond_26

    .line 31
    .line 32
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    if-eqz p1, :cond_26

    .line 37
    .line 38
    goto :goto_2e

    .line 39
    :cond_26
    new-instance p1, Ljava/lang/SecurityException;

    .line 40
    .line 41
    const-string v0, "Provider does not allow for granting of Uri permissions"

    .line 42
    .line 43
    invoke-direct {p1, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw p1

    .line 47
    :cond_2e
    :goto_2e
    return-void
.end method

.method public t(Lj4/k;JJZ)V
    .registers 19

    .line 1
    check-cast p1, Lj4/p;

    .line 2
    .line 3
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ld20/z;

    .line 6
    .line 7
    iget-boolean v1, v0, Ld20/z;->a:Z

    .line 8
    .line 9
    if-nez v1, :cond_b

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    move-wide/from16 v3, p4

    .line 13
    .line 14
    invoke-static {p1, p2, p3, v3, v4}, Ld20/z;->a(Lj4/p;JJ)Lf4/u;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iget-object p1, v0, Ld20/z;->g:Ljava/lang/Object;

    .line 19
    .line 20
    move-object v1, p1

    .line 21
    check-cast v1, Lcom/google/android/gms/internal/fido/f8;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    const/16 v3, 0x8

    .line 37
    .line 38
    const/4 v4, -0x1

    .line 39
    const/4 v5, 0x0

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x0

    .line 42
    invoke-virtual/range {v1 .. v11}, Lcom/google/android/gms/internal/fido/f8;->u(Lf4/u;IILk3/w;ILjava/lang/Object;JJ)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public u(ILjava/lang/Object;)V
    .registers 6

    .line 1
    packed-switch p1, :pswitch_data_40

    .line 2
    .line 3
    .line 4
    :pswitch_3
    const-string v0, ""

    .line 5
    .line 6
    goto :goto_23

    .line 7
    :pswitch_6
    const-string v0, "RESULT_DELETE_SKIP_FILE_SUCCESS"

    .line 8
    .line 9
    goto :goto_23

    .line 10
    :pswitch_9
    const-string v0, "RESULT_INSTALL_SKIP_FILE_SUCCESS"

    .line 11
    .line 12
    goto :goto_23

    .line 13
    :pswitch_c
    const-string v0, "RESULT_PARSE_EXCEPTION"

    .line 14
    .line 15
    goto :goto_23

    .line 16
    :pswitch_f
    const-string v0, "RESULT_IO_EXCEPTION"

    .line 17
    .line 18
    goto :goto_23

    .line 19
    :pswitch_12
    const-string v0, "RESULT_BASELINE_PROFILE_NOT_FOUND"

    .line 20
    .line 21
    goto :goto_23

    .line 22
    :pswitch_15
    const-string v0, "RESULT_DESIRED_FORMAT_UNSUPPORTED"

    .line 23
    .line 24
    goto :goto_23

    .line 25
    :pswitch_18
    const-string v0, "RESULT_NOT_WRITABLE"

    .line 26
    .line 27
    goto :goto_23

    .line 28
    :pswitch_1b
    const-string v0, "RESULT_UNSUPPORTED_ART_VERSION"

    .line 29
    .line 30
    goto :goto_23

    .line 31
    :pswitch_1e
    const-string v0, "RESULT_ALREADY_INSTALLED"

    .line 32
    .line 33
    goto :goto_23

    .line 34
    :pswitch_21
    const-string v0, "RESULT_INSTALL_SUCCESS"

    .line 35
    .line 36
    :goto_23
    const/4 v1, 0x6

    .line 37
    const-string v2, "ProfileInstaller"

    .line 38
    .line 39
    if-eq p1, v1, :cond_33

    .line 40
    .line 41
    const/4 v1, 0x7

    .line 42
    if-eq p1, v1, :cond_33

    .line 43
    .line 44
    const/16 v1, 0x8

    .line 45
    .line 46
    if-eq p1, v1, :cond_33

    .line 47
    .line 48
    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 49
    .line 50
    .line 51
    goto :goto_38

    .line 52
    :cond_33
    check-cast p2, Ljava/lang/Throwable;

    .line 53
    .line 54
    invoke-static {v2, v0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 55
    .line 56
    .line 57
    :goto_38
    iget-object p2, p0, La8/d;->e:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p2, Landroidx/profileinstaller/ProfileInstallReceiver;

    .line 60
    .line 61
    invoke-virtual {p2, p1}, Landroid/content/BroadcastReceiver;->setResultCode(I)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :pswitch_data_40
    .packed-switch 0x1
        :pswitch_21
        :pswitch_1e
        :pswitch_1b
        :pswitch_18
        :pswitch_15
        :pswitch_12
        :pswitch_f
        :pswitch_c
        :pswitch_3
        :pswitch_9
        :pswitch_6
    .end packed-switch
.end method

.method public unlock()V
    .registers 2

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/concurrent/locks/ReentrantLock;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public v(Lj4/k;JJLjava/io/IOException;I)Lgs/f;
    .registers 20

    .line 1
    move-object/from16 v0, p6

    .line 2
    .line 3
    check-cast p1, Lj4/p;

    .line 4
    .line 5
    iget-object v1, p0, La8/d;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ld20/z;

    .line 8
    .line 9
    iget-boolean v2, v1, Ld20/z;->a:Z

    .line 10
    .line 11
    sget-object v3, Lj4/n;->e:Lgs/f;

    .line 12
    .line 13
    if-nez v2, :cond_f

    .line 14
    .line 15
    return-object v3

    .line 16
    :cond_f
    instance-of v2, v0, Lq3/t;

    .line 17
    .line 18
    if-eqz v2, :cond_19

    .line 19
    .line 20
    move-object v2, v0

    .line 21
    check-cast v2, Lq3/t;

    .line 22
    .line 23
    iget v2, v2, Lq3/t;->i:I

    .line 24
    .line 25
    goto :goto_1c

    .line 26
    :cond_19
    const v2, 0x7fffffff

    .line 27
    .line 28
    .line 29
    :goto_1c
    const/16 v4, 0x19a

    .line 30
    .line 31
    const/4 v5, 0x0

    .line 32
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    if-ne v2, v4, :cond_3d

    .line 38
    .line 39
    iget-object v2, v1, Ld20/z;->j:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v2, Lj4/n;

    .line 42
    .line 43
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    const/4 v4, 0x0

    .line 47
    invoke-virtual {v2, v4}, Lj4/n;->c(Lj4/l;)V

    .line 48
    .line 49
    .line 50
    iget-object v2, v1, Ld20/z;->i:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v2, Ln3/g0;

    .line 53
    .line 54
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v2}, Ln3/g0;->f()V

    .line 58
    .line 59
    .line 60
    move-wide v8, v6

    .line 61
    goto :goto_75

    .line 62
    :cond_3d
    const/16 v4, 0x1ad

    .line 63
    .line 64
    const-wide/32 v8, 0x493e0

    .line 65
    .line 66
    .line 67
    if-ne v2, v4, :cond_68

    .line 68
    .line 69
    iget-object v2, p1, Lj4/p;->d:Lq3/y;

    .line 70
    .line 71
    iget-object v2, v2, Lq3/y;->v:Ljava/util/Map;

    .line 72
    .line 73
    const-string v4, "Retry-After"

    .line 74
    .line 75
    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    check-cast v2, Ljava/util/List;

    .line 80
    .line 81
    if-eqz v2, :cond_75

    .line 82
    .line 83
    :try_start_52
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    check-cast v2, Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 90
    .line 91
    .line 92
    move-result-wide v8
    :try_end_5c
    .catch Ljava/lang/NumberFormatException; {:try_start_52 .. :try_end_5c} :catch_60

    .line 93
    const-wide/16 v10, 0x3e8

    .line 94
    .line 95
    mul-long/2addr v8, v10

    .line 96
    goto :goto_75

    .line 97
    :catch_60
    const-string v2, "SteeringManifestTracker"

    .line 98
    .line 99
    const-string v4, "Retry-After header string doesn\'t contain a parsable long"

    .line 100
    .line 101
    invoke-static {v2, v4}, Ln3/b;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    goto :goto_75

    .line 105
    :cond_68
    iget-object v2, v1, Ld20/z;->h:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v2, Lk4/c;

    .line 108
    .line 109
    if-eqz v2, :cond_75

    .line 110
    .line 111
    iget-wide v10, v2, Lk4/c;->b:J

    .line 112
    .line 113
    cmp-long v2, v10, v6

    .line 114
    .line 115
    if-eqz v2, :cond_75

    .line 116
    .line 117
    move-wide v8, v10

    .line 118
    :cond_75
    :goto_75
    cmp-long v2, v8, v6

    .line 119
    .line 120
    if-eqz v2, :cond_8b

    .line 121
    .line 122
    iget-object v4, v1, Ld20/z;->i:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v4, Ln3/g0;

    .line 125
    .line 126
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 127
    .line 128
    .line 129
    new-instance v6, Lk4/d;

    .line 130
    .line 131
    const/4 v7, 0x1

    .line 132
    invoke-direct {v6, v1, v7}, Lk4/d;-><init>(Ld20/z;I)V

    .line 133
    .line 134
    .line 135
    iget-object v4, v4, Ln3/g0;->a:Landroid/os/Handler;

    .line 136
    .line 137
    invoke-virtual {v4, v6, v8, v9}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 138
    .line 139
    .line 140
    :cond_8b
    if-nez v2, :cond_8e

    .line 141
    .line 142
    const/4 v5, 0x1

    .line 143
    :cond_8e
    iget-object v2, v1, Ld20/z;->d:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v2, Ln3/g0;

    .line 146
    .line 147
    new-instance v4, Lcom/swmansion/reanimated/keyboard/b;

    .line 148
    .line 149
    invoke-direct {v4, p0, v0, v5}, Lcom/swmansion/reanimated/keyboard/b;-><init>(La8/d;Ljava/io/IOException;Z)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v2, v4}, Ln3/g0;->e(Ljava/lang/Runnable;)Z

    .line 153
    .line 154
    .line 155
    move-wide/from16 v8, p4

    .line 156
    .line 157
    invoke-static {p1, p2, p3, v8, v9}, Ld20/z;->a(Lj4/p;JJ)Lf4/u;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    iget-object v1, v1, Ld20/z;->g:Ljava/lang/Object;

    .line 162
    .line 163
    check-cast v1, Lcom/google/android/gms/internal/fido/f8;

    .line 164
    .line 165
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    const/16 v2, 0x8

    .line 169
    .line 170
    invoke-virtual {v1, p1, v2, v0, v5}, Lcom/google/android/gms/internal/fido/f8;->C(Lf4/u;ILjava/io/IOException;Z)V

    .line 171
    .line 172
    .line 173
    return-object v3
.end method

.method public w(Landroid/content/Context;Ljava/lang/String;Ljava/io/InputStream;Ljava/lang/String;Ljava/lang/String;)Lr7/a0;
    .registers 12

    .line 1
    iget-object v0, p0, La8/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, La8/c;

    .line 4
    .line 5
    if-nez p4, :cond_8

    .line 6
    .line 7
    const-string p4, "application/json"

    .line 8
    .line 9
    :cond_8
    const-string v1, "application/zip"

    .line 10
    .line 11
    invoke-virtual {p4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const/4 v2, 0x0

    .line 16
    if-nez v1, :cond_94

    .line 17
    .line 18
    const-string v1, "application/x-zip"

    .line 19
    .line 20
    invoke-virtual {p4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-nez v1, :cond_94

    .line 25
    .line 26
    const-string v1, "application/x-zip-compressed"

    .line 27
    .line 28
    invoke-virtual {p4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_94

    .line 33
    .line 34
    const-string v1, "\\?"

    .line 35
    .line 36
    invoke-virtual {p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    const/4 v4, 0x0

    .line 41
    aget-object v3, v3, v4

    .line 42
    .line 43
    const-string v5, ".lottie"

    .line 44
    .line 45
    invoke-virtual {v3, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    if-eqz v3, :cond_33

    .line 50
    .line 51
    goto :goto_94

    .line 52
    :cond_33
    const-string p1, "application/gzip"

    .line 53
    .line 54
    invoke-virtual {p4, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    if-nez p1, :cond_70

    .line 59
    .line 60
    const-string p1, "application/x-gzip"

    .line 61
    .line 62
    invoke-virtual {p4, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 63
    .line 64
    .line 65
    move-result p1

    .line 66
    if-nez p1, :cond_70

    .line 67
    .line 68
    invoke-virtual {p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    aget-object p1, p1, v4

    .line 73
    .line 74
    const-string p4, ".tgs"

    .line 75
    .line 76
    invoke-virtual {p1, p4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    if-eqz p1, :cond_52

    .line 81
    .line 82
    goto :goto_70

    .line 83
    :cond_52
    invoke-static {}, Ld8/c;->a()V

    .line 84
    .line 85
    .line 86
    sget-object p1, La8/b;->e:La8/b;

    .line 87
    .line 88
    if-eqz p5, :cond_6b

    .line 89
    .line 90
    invoke-virtual {v0, p2, p3, p1}, La8/c;->z(Ljava/lang/String;Ljava/io/InputStream;La8/b;)Ljava/io/File;

    .line 91
    .line 92
    .line 93
    move-result-object p3

    .line 94
    new-instance p4, Ljava/io/FileInputStream;

    .line 95
    .line 96
    invoke-virtual {p3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object p3

    .line 100
    invoke-direct {p4, p3}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-static {p4, p2}, Lr7/m;->c(Ljava/io/InputStream;Ljava/lang/String;)Lr7/a0;

    .line 104
    .line 105
    .line 106
    move-result-object p3

    .line 107
    goto :goto_ba

    .line 108
    :cond_6b
    invoke-static {p3, v2}, Lr7/m;->c(Ljava/io/InputStream;Ljava/lang/String;)Lr7/a0;

    .line 109
    .line 110
    .line 111
    move-result-object p3

    .line 112
    goto :goto_ba

    .line 113
    :cond_70
    :goto_70
    invoke-static {}, Ld8/c;->a()V

    .line 114
    .line 115
    .line 116
    sget-object p1, La8/b;->v:La8/b;

    .line 117
    .line 118
    if-eqz p5, :cond_8a

    .line 119
    .line 120
    invoke-virtual {v0, p2, p3, p1}, La8/c;->z(Ljava/lang/String;Ljava/io/InputStream;La8/b;)Ljava/io/File;

    .line 121
    .line 122
    .line 123
    move-result-object p3

    .line 124
    new-instance p4, Ljava/util/zip/GZIPInputStream;

    .line 125
    .line 126
    new-instance v1, Ljava/io/FileInputStream;

    .line 127
    .line 128
    invoke-direct {v1, p3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 129
    .line 130
    .line 131
    invoke-direct {p4, v1}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    .line 132
    .line 133
    .line 134
    invoke-static {p4, p2}, Lr7/m;->c(Ljava/io/InputStream;Ljava/lang/String;)Lr7/a0;

    .line 135
    .line 136
    .line 137
    move-result-object p3

    .line 138
    goto :goto_ba

    .line 139
    :cond_8a
    new-instance p4, Ljava/util/zip/GZIPInputStream;

    .line 140
    .line 141
    invoke-direct {p4, p3}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    .line 142
    .line 143
    .line 144
    invoke-static {p4, v2}, Lr7/m;->c(Ljava/io/InputStream;Ljava/lang/String;)Lr7/a0;

    .line 145
    .line 146
    .line 147
    move-result-object p3

    .line 148
    goto :goto_ba

    .line 149
    :cond_94
    :goto_94
    invoke-static {}, Ld8/c;->a()V

    .line 150
    .line 151
    .line 152
    sget-object p4, La8/b;->i:La8/b;

    .line 153
    .line 154
    if-eqz p5, :cond_af

    .line 155
    .line 156
    invoke-virtual {v0, p2, p3, p4}, La8/c;->z(Ljava/lang/String;Ljava/io/InputStream;La8/b;)Ljava/io/File;

    .line 157
    .line 158
    .line 159
    move-result-object p3

    .line 160
    new-instance v1, Ljava/util/zip/ZipInputStream;

    .line 161
    .line 162
    new-instance v2, Ljava/io/FileInputStream;

    .line 163
    .line 164
    invoke-direct {v2, p3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 165
    .line 166
    .line 167
    invoke-direct {v1, v2}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    .line 168
    .line 169
    .line 170
    invoke-static {p1, v1, p2}, Lr7/m;->f(Landroid/content/Context;Ljava/util/zip/ZipInputStream;Ljava/lang/String;)Lr7/a0;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    :goto_ad
    move-object p3, p1

    .line 175
    goto :goto_b9

    .line 176
    :cond_af
    new-instance v1, Ljava/util/zip/ZipInputStream;

    .line 177
    .line 178
    invoke-direct {v1, p3}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    .line 179
    .line 180
    .line 181
    invoke-static {p1, v1, v2}, Lr7/m;->f(Landroid/content/Context;Ljava/util/zip/ZipInputStream;Ljava/lang/String;)Lr7/a0;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    goto :goto_ad

    .line 186
    :goto_b9
    move-object p1, p4

    .line 187
    :goto_ba
    if-eqz p5, :cond_111

    .line 188
    .line 189
    iget-object p4, p3, Lr7/a0;->a:Lr7/i;

    .line 190
    .line 191
    if-eqz p4, :cond_111

    .line 192
    .line 193
    const/4 p4, 0x1

    .line 194
    invoke-static {p2, p1, p4}, La8/c;->q(Ljava/lang/String;La8/b;Z)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    new-instance p2, Ljava/io/File;

    .line 199
    .line 200
    invoke-virtual {v0}, La8/c;->w()Ljava/io/File;

    .line 201
    .line 202
    .line 203
    move-result-object p4

    .line 204
    invoke-direct {p2, p4, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 205
    .line 206
    .line 207
    invoke-virtual {p2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object p1

    .line 211
    const-string p4, ".temp"

    .line 212
    .line 213
    const-string p5, ""

    .line 214
    .line 215
    invoke-virtual {p1, p4, p5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    new-instance p4, Ljava/io/File;

    .line 220
    .line 221
    invoke-direct {p4, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {p2, p4}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 225
    .line 226
    .line 227
    move-result p1

    .line 228
    invoke-virtual {p4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 229
    .line 230
    .line 231
    invoke-static {}, Ld8/c;->a()V

    .line 232
    .line 233
    .line 234
    if-nez p1, :cond_111

    .line 235
    .line 236
    new-instance p1, Ljava/lang/StringBuilder;

    .line 237
    .line 238
    const-string p5, "Unable to rename cache file "

    .line 239
    .line 240
    invoke-direct {p1, p5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {p2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object p2

    .line 247
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    const-string p2, " to "

    .line 251
    .line 252
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 253
    .line 254
    .line 255
    invoke-virtual {p4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 256
    .line 257
    .line 258
    move-result-object p2

    .line 259
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 260
    .line 261
    .line 262
    const-string p2, "."

    .line 263
    .line 264
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object p1

    .line 271
    invoke-static {p1}, Ld8/c;->b(Ljava/lang/String;)V

    .line 272
    .line 273
    .line 274
    :cond_111
    return-object p3
.end method

.method public varargs x([Ljava/lang/String;)Ljava/lang/String;
    .registers 8

    .line 1
    array-length v0, p1

    .line 2
    const-string v1, ""

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    :goto_4
    if-ge v2, v0, :cond_28

    .line 6
    .line 7
    aget-object v3, p1, v2

    .line 8
    .line 9
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v4

    .line 13
    if-nez v4, :cond_25

    .line 14
    .line 15
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v4

    .line 19
    if-eqz v4, :cond_16

    .line 20
    .line 21
    move-object v1, v3

    .line 22
    goto :goto_25

    .line 23
    :cond_16
    iget-object v4, p0, La8/d;->e:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v4, Landroid/content/res/Resources;

    .line 26
    .line 27
    const v5, 0x7f1300b9

    .line 28
    .line 29
    .line 30
    filled-new-array {v1, v3}, [Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-virtual {v4, v5, v1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    :cond_25
    :goto_25
    add-int/lit8 v2, v2, 0x1

    .line 39
    .line 40
    goto :goto_4

    .line 41
    :cond_28
    return-object v1
.end method
