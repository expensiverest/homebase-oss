###### Class aj.b (aj.b)
.class public final synthetic Laj/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic J:Ljava/lang/Object;

.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic i:I

.field public final synthetic v:Ljava/lang/Object;

.field public final synthetic w:Ljava/lang/Object;

.field public final synthetic x:Ljava/lang/Object;

.field public final synthetic y:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ly5/s1;Landroid/os/IBinder;Ly5/y1;Ly5/e0;IILy5/p1;)V
    .registers 9

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Laj/b;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laj/b;->v:Ljava/lang/Object;

    iput-object p2, p0, Laj/b;->w:Ljava/lang/Object;

    iput-object p3, p0, Laj/b;->x:Ljava/lang/Object;

    iput-object p4, p0, Laj/b;->y:Ljava/lang/Object;

    iput p5, p0, Laj/b;->e:I

    iput p6, p0, Laj/b;->i:I

    iput-object p7, p0, Laj/b;->J:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lz5/u;ILg8/i0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V
    .registers 9

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Laj/b;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laj/b;->v:Ljava/lang/Object;

    iput p2, p0, Laj/b;->e:I

    iput-object p3, p0, Laj/b;->w:Ljava/lang/Object;

    iput-object p4, p0, Laj/b;->x:Ljava/lang/Object;

    iput-object p5, p0, Laj/b;->y:Ljava/lang/Object;

    iput-object p6, p0, Laj/b;->J:Ljava/lang/Object;

    iput p7, p0, Laj/b;->i:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    .line 1
    iget v0, p0, Laj/b;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_76

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Laj/b;->v:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ly5/s1;

    .line 9
    .line 10
    iget-object v1, p0, Laj/b;->w:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Landroid/os/IBinder;

    .line 13
    .line 14
    iget-object v2, p0, Laj/b;->x:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Ly5/y1;

    .line 17
    .line 18
    iget-object v3, p0, Laj/b;->y:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v3, Ly5/e0;

    .line 21
    .line 22
    iget-object v4, p0, Laj/b;->J:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v4, Ly5/p1;

    .line 25
    .line 26
    iget-object v0, v0, Ly5/s1;->g:Ly0/c;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ly0/c;->j(Ljava/lang/Object;)Ly5/u;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    if-nez v1, :cond_22

    .line 33
    .line 34
    goto :goto_51

    .line 35
    :cond_22
    invoke-virtual {v0, v1}, Ly0/c;->l(Ly5/u;)Z

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    if-nez v5, :cond_29

    .line 40
    .line 41
    goto :goto_51

    .line 42
    :cond_29
    iget v5, p0, Laj/b;->e:I

    .line 43
    .line 44
    const/4 v6, -0x4

    .line 45
    if-eqz v2, :cond_3d

    .line 46
    .line 47
    invoke-virtual {v0, v1, v2}, Ly0/c;->o(Ly5/u;Ly5/y1;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_4e

    .line 52
    .line 53
    new-instance v0, Ly5/c2;

    .line 54
    .line 55
    invoke-direct {v0, v6}, Ly5/c2;-><init>(I)V

    .line 56
    .line 57
    .line 58
    invoke-static {v3, v1, v5, v0}, Ly5/s1;->F(Ly5/e0;Ly5/u;ILy5/c2;)V

    .line 59
    .line 60
    .line 61
    goto :goto_51

    .line 62
    :cond_3d
    iget v2, p0, Laj/b;->i:I

    .line 63
    .line 64
    invoke-virtual {v0, v1, v2}, Ly0/c;->n(Ly5/u;I)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_4e

    .line 69
    .line 70
    new-instance v0, Ly5/c2;

    .line 71
    .line 72
    invoke-direct {v0, v6}, Ly5/c2;-><init>(I)V

    .line 73
    .line 74
    .line 75
    invoke-static {v3, v1, v5, v0}, Ly5/s1;->F(Ly5/e0;Ly5/u;ILy5/c2;)V

    .line 76
    .line 77
    .line 78
    goto :goto_51

    .line 79
    :cond_4e
    invoke-interface {v4, v3, v1, v5}, Ly5/p1;->e(Ly5/e0;Ly5/u;I)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    :goto_51
    return-void

    .line 83
    :pswitch_52
    iget-object v0, p0, Laj/b;->v:Ljava/lang/Object;

    .line 84
    .line 85
    move-object v1, v0

    .line 86
    check-cast v1, Lz5/u;

    .line 87
    .line 88
    iget-object v0, p0, Laj/b;->w:Ljava/lang/Object;

    .line 89
    .line 90
    move-object v3, v0

    .line 91
    check-cast v3, Lg8/i0;

    .line 92
    .line 93
    iget-object v0, p0, Laj/b;->x:Ljava/lang/Object;

    .line 94
    .line 95
    move-object v4, v0

    .line 96
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 97
    .line 98
    iget-object v0, p0, Laj/b;->y:Ljava/lang/Object;

    .line 99
    .line 100
    move-object v5, v0

    .line 101
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 102
    .line 103
    iget-object v0, p0, Laj/b;->J:Ljava/lang/Object;

    .line 104
    .line 105
    move-object v6, v0

    .line 106
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 107
    .line 108
    iget v0, p0, Laj/b;->i:I

    .line 109
    .line 110
    add-int/lit8 v7, v0, 0x1

    .line 111
    .line 112
    iget v2, p0, Laj/b;->e:I

    .line 113
    .line 114
    invoke-virtual/range {v1 .. v7}, Lz5/u;->V(ILg8/i0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    nop

    .line 119
    :pswitch_data_76
    .packed-switch 0x0
        :pswitch_52
    .end packed-switch
.end method
