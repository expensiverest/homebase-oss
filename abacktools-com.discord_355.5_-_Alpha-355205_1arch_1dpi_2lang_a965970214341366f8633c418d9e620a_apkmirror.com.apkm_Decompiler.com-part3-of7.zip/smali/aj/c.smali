###### Class aj.c (aj.c)
.class public final Laj/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Laj/c;->d:I

    iput-object p2, p0, Laj/c;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(Landroid/view/View;)V
    .registers 2

    .line 1
    return-void
.end method

.method private final b(Landroid/view/View;)V
    .registers 2

    .line 1
    return-void
.end method

.method private final c(Landroid/view/View;)V
    .registers 2

    .line 1
    return-void
.end method

.method private final d(Landroid/view/View;)V
    .registers 2

    .line 1
    return-void
.end method

.method private final e(Landroid/view/View;)V
    .registers 2

    .line 1
    return-void
.end method


# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .registers 6

    .line 1
    iget v0, p0, Laj/c;->d:I

    .line 2
    .line 3
    const-string v1, "view"

    .line 4
    .line 5
    const-string v2, "v"

    .line 6
    .line 7
    iget-object v3, p0, Laj/c;->e:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_76

    .line 10
    .line 11
    .line 12
    invoke-static {p1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    check-cast v3, Lbh/m;

    .line 16
    .line 17
    invoke-virtual {p1}, Landroid/view/View;->isLaidOut()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_2b

    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/view/View;->isLayoutRequested()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_2b

    .line 28
    .line 29
    const-string v0, "Active Voice Bubble"

    .line 30
    .line 31
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    const-string v0, "findViewWithTag(...)"

    .line 36
    .line 37
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v3, p1}, Lbh/c;->b(Landroid/view/View;)V

    .line 41
    .line 42
    .line 43
    goto :goto_34

    .line 44
    :cond_2b
    new-instance v0, Lce/a;

    .line 45
    .line 46
    const/4 v1, 0x2

    .line 47
    invoke-direct {v0, p1, v3, v1}, Lce/a;-><init>(Landroid/view/View;Landroid/view/View;I)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p1, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 51
    .line 52
    .line 53
    :goto_34
    :pswitch_34
    return-void

    .line 54
    :pswitch_35
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v3, Lio/sentry/android/core/internal/util/h;

    .line 59
    .line 60
    invoke-virtual {v0, v3}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 64
    .line 65
    .line 66
    :pswitch_41
    return-void

    .line 67
    :pswitch_42
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :pswitch_46
    invoke-static {p1, v1}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    check-cast v3, Lj00/m;

    .line 79
    .line 80
    iget-object v0, v3, Lj00/m;->d:Lj00/h;

    .line 81
    .line 82
    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :pswitch_55
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    check-cast v3, Lio/sentry/android/core/internal/util/h;

    .line 91
    .line 92
    invoke-virtual {v0, v3}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :pswitch_62
    invoke-static {p1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    return-void

    .line 103
    :pswitch_66
    check-cast v3, Landroid/view/View;

    .line 104
    .line 105
    invoke-virtual {v3, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 106
    .line 107
    .line 108
    sget-object p1, Landroidx/core/view/z0;->a:Ljava/util/WeakHashMap;

    .line 109
    .line 110
    invoke-virtual {v3}, Landroid/view/View;->requestApplyInsets()V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :pswitch_71
    invoke-static {p1, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    nop

    .line 119
    :pswitch_data_76
    .packed-switch 0x0
        :pswitch_71
        :pswitch_66
        :pswitch_62
        :pswitch_55
        :pswitch_46
        :pswitch_42
        :pswitch_41
        :pswitch_41
        :pswitch_35
        :pswitch_34
        :pswitch_34
    .end packed-switch
.end method

.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .registers 4

    .line 1
    iget v0, p0, Laj/c;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e0

    .line 4
    .line 5
    .line 6
    const-string v0, "v"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Laj/c;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lbh/m;

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1b

    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    invoke-virtual {p1, v0}, Lbh/c;->setBubbleTouchable(Z)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1, v0}, Lbh/c;->a(Z)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void

    .line 29
    :pswitch_1c
    iget-object p1, p0, Laj/c;->e:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lcom/google/android/material/behavior/HideViewOnScrollBehavior;

    .line 32
    .line 33
    iget-object v0, p1, Lcom/google/android/material/behavior/HideViewOnScrollBehavior;->c:Ltv/a;

    .line 34
    .line 35
    if-eqz v0, :cond_2e

    .line 36
    .line 37
    iget-object v1, p1, Lcom/google/android/material/behavior/HideViewOnScrollBehavior;->b:Landroid/view/accessibility/AccessibilityManager;

    .line 38
    .line 39
    if-eqz v1, :cond_2e

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Landroid/view/accessibility/AccessibilityManager;->removeTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z

    .line 42
    .line 43
    .line 44
    const/4 v0, 0x0

    .line 45
    iput-object v0, p1, Lcom/google/android/material/behavior/HideViewOnScrollBehavior;->c:Ltv/a;

    .line 46
    .line 47
    :cond_2e
    return-void

    .line 48
    :pswitch_2f
    iget-object p1, p0, Laj/c;->e:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast p1, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;

    .line 51
    .line 52
    iget-object v0, p1, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->h:Ltv/a;

    .line 53
    .line 54
    if-eqz v0, :cond_41

    .line 55
    .line 56
    iget-object v1, p1, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->g:Landroid/view/accessibility/AccessibilityManager;

    .line 57
    .line 58
    if-eqz v1, :cond_41

    .line 59
    .line 60
    invoke-virtual {v1, v0}, Landroid/view/accessibility/AccessibilityManager;->removeTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z

    .line 61
    .line 62
    .line 63
    const/4 v0, 0x0

    .line 64
    iput-object v0, p1, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->h:Ltv/a;

    .line 65
    .line 66
    :cond_41
    return-void

    .line 67
    :pswitch_42
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :pswitch_46
    iget-object v0, p0, Laj/c;->e:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, Lo/b0;

    .line 74
    .line 75
    iget-object v1, v0, Lo/b0;->Q:Landroid/view/ViewTreeObserver;

    .line 76
    .line 77
    if-eqz v1, :cond_61

    .line 78
    .line 79
    invoke-virtual {v1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    if-nez v1, :cond_5a

    .line 84
    .line 85
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    iput-object v1, v0, Lo/b0;->Q:Landroid/view/ViewTreeObserver;

    .line 90
    .line 91
    :cond_5a
    iget-object v1, v0, Lo/b0;->Q:Landroid/view/ViewTreeObserver;

    .line 92
    .line 93
    iget-object v0, v0, Lo/b0;->K:Lj00/h;

    .line 94
    .line 95
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 96
    .line 97
    .line 98
    :cond_61
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :pswitch_65
    iget-object v0, p0, Laj/c;->e:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v0, Lo/e;

    .line 105
    .line 106
    iget-object v1, v0, Lo/e;->Z:Landroid/view/ViewTreeObserver;

    .line 107
    .line 108
    if-eqz v1, :cond_80

    .line 109
    .line 110
    invoke-virtual {v1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    if-nez v1, :cond_79

    .line 115
    .line 116
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    iput-object v1, v0, Lo/e;->Z:Landroid/view/ViewTreeObserver;

    .line 121
    .line 122
    :cond_79
    iget-object v1, v0, Lo/e;->Z:Landroid/view/ViewTreeObserver;

    .line 123
    .line 124
    iget-object v0, v0, Lo/e;->K:Lj00/h;

    .line 125
    .line 126
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 127
    .line 128
    .line 129
    :cond_80
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 130
    .line 131
    .line 132
    return-void

    .line 133
    :pswitch_84
    const-string v0, "view"

    .line 134
    .line 135
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    iget-object v0, p0, Laj/c;->e:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v0, Llg/a;

    .line 141
    .line 142
    new-instance v1, Ljava/lang/StringBuilder;

    .line 143
    .line 144
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    const-string p1, " detached from window"

    .line 151
    .line 152
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    invoke-static {v0, p1}, Llg/a;->a(Llg/a;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    return-void

    .line 163
    :pswitch_a2
    const-string v0, "view"

    .line 164
    .line 165
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    iget-object v0, p0, Laj/c;->e:Ljava/lang/Object;

    .line 173
    .line 174
    check-cast v0, Lj00/m;

    .line 175
    .line 176
    iget-object v0, v0, Lj00/m;->d:Lj00/h;

    .line 177
    .line 178
    invoke-virtual {p1, v0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 179
    .line 180
    .line 181
    return-void

    .line 182
    :pswitch_b5
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 183
    .line 184
    .line 185
    return-void

    .line 186
    :pswitch_b9
    const-string v0, "v"

    .line 187
    .line 188
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    iget-object p1, p0, Laj/c;->e:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast p1, Landroid/animation/Animator;

    .line 194
    .line 195
    invoke-virtual {p1}, Landroid/animation/Animator;->end()V

    .line 196
    .line 197
    .line 198
    :pswitch_c5
    return-void

    .line 199
    :pswitch_c6
    const-string v0, "v"

    .line 200
    .line 201
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    iget-object p1, p0, Laj/c;->e:Ljava/lang/Object;

    .line 205
    .line 206
    check-cast p1, Lz5/u;

    .line 207
    .line 208
    iget-object v0, p1, Lz5/u;->e:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v0, Laj/b;

    .line 211
    .line 212
    if-eqz v0, :cond_df

    .line 213
    .line 214
    iget-object v1, p1, Lz5/u;->d:Ljava/lang/Object;

    .line 215
    .line 216
    check-cast v1, Lcom/discord/device/views/DiscordRecyclerView;

    .line 217
    .line 218
    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 219
    .line 220
    .line 221
    const/4 v0, 0x0

    .line 222
    iput-object v0, p1, Lz5/u;->e:Ljava/lang/Object;

    .line 223
    .line 224
    :cond_df
    return-void

    .line 225
    :pswitch_data_e0
    .packed-switch 0x0
        :pswitch_c6
        :pswitch_c5
        :pswitch_b9
        :pswitch_b5
        :pswitch_a2
        :pswitch_84
        :pswitch_65
        :pswitch_46
        :pswitch_42
        :pswitch_2f
        :pswitch_1c
    .end packed-switch
.end method
