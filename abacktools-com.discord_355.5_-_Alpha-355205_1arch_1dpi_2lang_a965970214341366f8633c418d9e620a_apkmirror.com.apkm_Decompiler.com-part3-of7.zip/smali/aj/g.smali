###### Class aj.g (aj.g)
.class public final Laj/g;
.super Le6/i0;
.source "SourceFile"


# instance fields
.field public final q:Lg8/i0;

.field public final r:Laj/a;

.field public s:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/content/Context;ILg8/i0;Laj/a;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1}, Le6/i0;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Laj/g;->q:Lg8/i0;

    .line 5
    .line 6
    iput-object p4, p0, Laj/g;->r:Laj/a;

    .line 7
    .line 8
    iput p2, p0, Le6/i0;->a:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(IIIII)I
    .registers 8

    .line 1
    iget-object v0, p0, Laj/g;->q:Lg8/i0;

    .line 2
    .line 3
    instance-of v1, v0, Laj/e;

    .line 4
    .line 5
    if-eqz v1, :cond_10

    .line 6
    .line 7
    const/4 p5, 0x2

    .line 8
    invoke-static {p4, p3, p5, p3}, Lhs/q;->b(IIII)I

    .line 9
    .line 10
    .line 11
    move-result p3

    .line 12
    sub-int/2addr p2, p1

    .line 13
    div-int/2addr p2, p5

    .line 14
    add-int/2addr p2, p1

    .line 15
    sub-int/2addr p3, p2

    .line 16
    return p3

    .line 17
    :cond_10
    instance-of v1, v0, Laj/f;

    .line 18
    .line 19
    if-eqz v1, :cond_1b

    .line 20
    .line 21
    sub-int/2addr p3, p1

    .line 22
    check-cast v0, Laj/f;

    .line 23
    .line 24
    iget p1, v0, Laj/f;->a:I

    .line 25
    .line 26
    add-int/2addr p3, p1

    .line 27
    return p3

    .line 28
    :cond_1b
    instance-of v0, v0, Laj/d;

    .line 29
    .line 30
    if-eqz v0, :cond_24

    .line 31
    .line 32
    invoke-super/range {p0 .. p5}, Le6/i0;->a(IIIII)I

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    return p1

    .line 37
    :cond_24
    new-instance p1, Lan/g;

    .line 38
    .line 39
    const/4 p2, 0x0

    .line 40
    invoke-direct {p1, p2}, Lan/g;-><init>(Z)V

    .line 41
    .line 42
    .line 43
    throw p1
.end method

.method public final g(Landroid/view/View;)V
    .registers 4

    .line 1
    const-string v0, "child"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1}, Le6/i0;->g(Landroid/view/View;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Laj/g;->s:Landroid/view/View;

    .line 10
    .line 11
    if-nez v0, :cond_23

    .line 12
    .line 13
    iget-object v0, p0, Le6/i0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->N(Landroid/view/View;)Le6/l1;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eqz v0, :cond_1c

    .line 23
    .line 24
    invoke-virtual {v0}, Le6/l1;->g()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v0, -0x1

    .line 30
    :goto_1d
    iget v1, p0, Le6/i0;->a:I

    .line 31
    .line 32
    if-ne v0, v1, :cond_23

    .line 33
    .line 34
    iput-object p1, p0, Laj/g;->s:Landroid/view/View;

    .line 35
    .line 36
    :cond_23
    return-void
.end method

.method public final h(IILe6/h1;Le6/f1;)V
    .registers 6

    .line 1
    const-string v0, "state"

    .line 2
    .line 3
    invoke-static {p3, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Laj/g;->s:Landroid/view/View;

    .line 7
    .line 8
    if-eqz v0, :cond_d

    .line 9
    .line 10
    invoke-virtual {p0, v0, p4}, Le6/i0;->j(Landroid/view/View;Le6/f1;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    invoke-super {p0, p1, p2, p3, p4}, Le6/i0;->h(IILe6/h1;Le6/f1;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final i()V
    .registers 2

    .line 1
    invoke-super {p0}, Le6/i0;->i()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Laj/g;->r:Laj/a;

    .line 5
    .line 6
    if-eqz v0, :cond_a

    .line 7
    .line 8
    invoke-virtual {v0}, Laj/a;->invoke()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    :cond_a
    const/4 v0, 0x0

    .line 12
    iput-object v0, p0, Laj/g;->s:Landroid/view/View;

    .line 13
    .line 14
    return-void
.end method
