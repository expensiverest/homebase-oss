###### Class aj.a (aj.a)
.class public final synthetic Laj/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, Laj/a;->d:I

    iput-object p2, p0, Laj/a;->e:Ljava/lang/Object;

    iput-object p3, p0, Laj/a;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function2;Lfc/g2;)V
    .registers 4

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Laj/a;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    check-cast p1, Lkotlin/jvm/internal/i;

    iput-object p1, p0, Laj/a;->e:Ljava/lang/Object;

    iput-object p2, p0, Laj/a;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 15

    .line 1
    iget v0, p0, Laj/a;->d:I

    .line 2
    .line 3
    const/16 v1, 0x8

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    packed-switch v0, :pswitch_data_51e

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lpc/b;

    .line 14
    .line 15
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v1, Lbc/y0;

    .line 18
    .line 19
    iget-object v0, v0, Lpc/b;->g:Loc/a;

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Loc/a;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_1a
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Lpc/b;

    .line 30
    .line 31
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v1, Lbc/y;

    .line 34
    .line 35
    iget-object v0, v0, Lpc/b;->g:Loc/a;

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Loc/a;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 41
    .line 42
    return-object v0

    .line 43
    :pswitch_2a
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v0, Ll70/g;

    .line 46
    .line 47
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v1, Lo70/c;

    .line 50
    .line 51
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 52
    .line 53
    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 54
    .line 55
    .line 56
    iget-object v3, v1, Lo70/c;->a:Lo70/h;

    .line 57
    .line 58
    invoke-static {v0, v1}, Lp70/q;->o(Ll70/g;Lo70/c;)V

    .line 59
    .line 60
    .line 61
    invoke-interface {v0}, Ll70/g;->n()I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    move v3, v4

    .line 66
    :goto_41
    if-ge v3, v1, :cond_ec

    .line 67
    .line 68
    invoke-interface {v0, v3}, Ll70/g;->p(I)Ljava/util/List;

    .line 69
    .line 70
    .line 71
    move-result-object v5

    .line 72
    new-instance v6, Ljava/util/ArrayList;

    .line 73
    .line 74
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 75
    .line 76
    .line 77
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 78
    .line 79
    .line 80
    move-result-object v5

    .line 81
    :cond_50
    :goto_50
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 82
    .line 83
    .line 84
    move-result v7

    .line 85
    if-eqz v7, :cond_62

    .line 86
    .line 87
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    instance-of v8, v7, Lo70/r;

    .line 92
    .line 93
    if-eqz v8, :cond_50

    .line 94
    .line 95
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    goto :goto_50

    .line 99
    :cond_62
    invoke-static {v6}, Lm30/q;->K0(Ljava/util/List;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v5

    .line 103
    check-cast v5, Lo70/r;

    .line 104
    .line 105
    if-eqz v5, :cond_e8

    .line 106
    .line 107
    invoke-interface {v5}, Lo70/r;->names()[Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    if-eqz v5, :cond_e8

    .line 112
    .line 113
    array-length v6, v5

    .line 114
    move v7, v4

    .line 115
    :goto_72
    if-ge v7, v6, :cond_e8

    .line 116
    .line 117
    aget-object v8, v5, v7

    .line 118
    .line 119
    invoke-interface {v0}, Ll70/g;->j()Lk80/l;

    .line 120
    .line 121
    .line 122
    move-result-object v9

    .line 123
    sget-object v10, Ll70/k;->i:Ll70/k;

    .line 124
    .line 125
    invoke-static {v9, v10}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v9

    .line 129
    if-eqz v9, :cond_85

    .line 130
    .line 131
    const-string v9, "enum value"

    .line 132
    .line 133
    goto :goto_87

    .line 134
    :cond_85
    const-string v9, "property"

    .line 135
    .line 136
    :goto_87
    invoke-interface {v2, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v10

    .line 140
    if-nez v10, :cond_97

    .line 141
    .line 142
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 143
    .line 144
    .line 145
    move-result-object v9

    .line 146
    invoke-interface {v2, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    add-int/lit8 v7, v7, 0x1

    .line 150
    .line 151
    goto :goto_72

    .line 152
    :cond_97
    new-instance v1, Lj70/k;

    .line 153
    .line 154
    new-instance v4, Ljava/lang/StringBuilder;

    .line 155
    .line 156
    const-string v5, "The suggested name \'"

    .line 157
    .line 158
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 162
    .line 163
    .line 164
    const-string v5, "\' for "

    .line 165
    .line 166
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 167
    .line 168
    .line 169
    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    const/16 v5, 0x20

    .line 173
    .line 174
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-interface {v0, v3}, Ll70/g;->o(I)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    .line 183
    .line 184
    const-string v3, " is already one of the names for "

    .line 185
    .line 186
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 187
    .line 188
    .line 189
    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 190
    .line 191
    .line 192
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    invoke-static {v2, v8}, Lm30/x;->n0(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    check-cast v2, Ljava/lang/Number;

    .line 200
    .line 201
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 202
    .line 203
    .line 204
    move-result v2

    .line 205
    invoke-interface {v0, v2}, Ll70/g;->o(I)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    const-string v2, " in "

    .line 213
    .line 214
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 215
    .line 216
    .line 217
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 218
    .line 219
    .line 220
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    const-string v2, "message"

    .line 225
    .line 226
    invoke-static {v0, v2}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    throw v1

    .line 233
    :cond_e8
    add-int/lit8 v3, v3, 0x1

    .line 234
    .line 235
    goto/16 :goto_41

    .line 236
    .line 237
    :cond_ec
    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    .line 238
    .line 239
    .line 240
    move-result v0

    .line 241
    if-eqz v0, :cond_f4

    .line 242
    .line 243
    sget-object v2, Lm30/t;->d:Lm30/t;

    .line 244
    .line 245
    :cond_f4
    return-object v2

    .line 246
    :pswitch_f5
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 247
    .line 248
    move-object v1, v0

    .line 249
    check-cast v1, Lp10/p;

    .line 250
    .line 251
    iget-object v0, p0, Laj/a;->i:Ljava/lang/Object;

    .line 252
    .line 253
    check-cast v0, Lo10/f;

    .line 254
    .line 255
    monitor-enter v1

    .line 256
    :try_start_ff
    iget-object v3, v1, Lp10/p;->d:Ljava/util/LinkedHashMap;

    .line 257
    .line 258
    iget v4, v0, Lo10/f;->d:I

    .line 259
    .line 260
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 261
    .line 262
    .line 263
    move-result-object v4

    .line 264
    invoke-virtual {v3, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v3

    .line 268
    check-cast v3, Ljava/util/Map;

    .line 269
    .line 270
    if-eqz v3, :cond_11c

    .line 271
    .line 272
    invoke-interface {v3}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 273
    .line 274
    .line 275
    move-result-object v3

    .line 276
    if-eqz v3, :cond_11c

    .line 277
    .line 278
    invoke-static {v3}, Lm30/q;->S0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 279
    .line 280
    .line 281
    move-result-object v2

    .line 282
    goto :goto_11c

    .line 283
    :catchall_11a
    move-exception v0

    .line 284
    goto :goto_138

    .line 285
    :cond_11c
    :goto_11c
    if-nez v2, :cond_120

    .line 286
    .line 287
    sget-object v2, Lm30/s;->d:Lm30/s;
    :try_end_120
    .catchall {:try_start_ff .. :try_end_120} :catchall_11a

    .line 288
    .line 289
    :cond_120
    monitor-exit v1

    .line 290
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 291
    .line 292
    .line 293
    move-result-object v1

    .line 294
    :goto_125
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 295
    .line 296
    .line 297
    move-result v2

    .line 298
    if-eqz v2, :cond_135

    .line 299
    .line 300
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v2

    .line 304
    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 305
    .line 306
    invoke-interface {v2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    goto :goto_125

    .line 310
    :cond_135
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 311
    .line 312
    return-object v0

    .line 313
    :goto_138
    monitor-exit v1

    .line 314
    throw v0

    .line 315
    :pswitch_13a
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 316
    .line 317
    check-cast v0, Lch/m;

    .line 318
    .line 319
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 320
    .line 321
    check-cast v1, Landroid/content/Intent;

    .line 322
    .line 323
    sget v3, Lcom/discord/main/MainActivity;->g0:I

    .line 324
    .line 325
    check-cast v0, Lcom/discord/MainApplication;

    .line 326
    .line 327
    invoke-virtual {v0}, Lcom/discord/MainApplication;->a()Lo8/d;

    .line 328
    .line 329
    .line 330
    move-result-object v0

    .line 331
    iget-object v0, v0, Lo8/d;->b:Lch/l;

    .line 332
    .line 333
    iget-object v0, v0, Lch/l;->c:Ll30/o;

    .line 334
    .line 335
    invoke-virtual {v0}, Ll30/o;->getValue()Ljava/lang/Object;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    check-cast v0, Ljava/lang/Boolean;

    .line 340
    .line 341
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 342
    .line 343
    .line 344
    move-result v0

    .line 345
    if-nez v0, :cond_15b

    .line 346
    .line 347
    goto :goto_19d

    .line 348
    :cond_15b
    const-string v0, "intent"

    .line 349
    .line 350
    invoke-static {v1, v0}, Lkotlin/jvm/internal/k;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 351
    .line 352
    .line 353
    sget-object v0, Lhh/i;->j:Lhh/i;

    .line 354
    .line 355
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 356
    .line 357
    .line 358
    invoke-static {v1}, Lhh/i;->b(Landroid/content/Intent;)Lcom/discord/notifications/actions/intents/ContentAction;

    .line 359
    .line 360
    .line 361
    move-result-object v0

    .line 362
    if-eqz v0, :cond_16d

    .line 363
    .line 364
    iget-object v2, v0, Lcom/discord/notifications/actions/intents/ContentAction;->e:Ljava/util/Map;

    .line 365
    .line 366
    :cond_16d
    if-nez v2, :cond_170

    .line 367
    .line 368
    goto :goto_19d

    .line 369
    :cond_170
    const-string v0, "type"

    .line 370
    .line 371
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    const-string v1, "MESSAGE_CREATE"

    .line 376
    .line 377
    invoke-static {v0, v1}, Lkotlin/jvm/internal/k;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    move-result v0

    .line 381
    if-nez v0, :cond_17f

    .line 382
    .line 383
    goto :goto_19d

    .line 384
    :cond_17f
    const-string v0, "channel_id"

    .line 385
    .line 386
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v0

    .line 390
    check-cast v0, Ljava/lang/String;

    .line 391
    .line 392
    if-nez v0, :cond_18a

    .line 393
    .line 394
    goto :goto_19d

    .line 395
    :cond_18a
    const-string v1, "receiving_user_id"

    .line 396
    .line 397
    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    move-result-object v1

    .line 401
    check-cast v1, Ljava/lang/String;

    .line 402
    .line 403
    if-nez v1, :cond_195

    .line 404
    .line 405
    goto :goto_19d

    .line 406
    :cond_195
    sget-object v2, Ln9/b;->f:Ljava/util/concurrent/CountDownLatch;

    .line 407
    .line 408
    invoke-virtual {v2}, Ljava/util/concurrent/CountDownLatch;->await()V

    .line 409
    .line 410
    .line 411
    invoke-static {v0, v1}, Lul/b;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 412
    .line 413
    .line 414
    :goto_19d
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 415
    .line 416
    return-object v0

    .line 417
    :pswitch_1a0
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 418
    .line 419
    check-cast v0, Landroid/content/Context;

    .line 420
    .line 421
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 422
    .line 423
    check-cast v1, Lcom/discord/MainApplication;

    .line 424
    .line 425
    sget v2, Lcom/discord/MainApplication;->J:I

    .line 426
    .line 427
    sget-object v2, Lcom/facebook/react/soloader/OpenSourceMergedSoMapping;->a:Lcom/facebook/react/soloader/OpenSourceMergedSoMapping;

    .line 428
    .line 429
    sget-boolean v3, Lcom/facebook/soloader/SoLoader;->a:Z

    .line 430
    .line 431
    const-class v5, Lcom/facebook/soloader/SoLoader;

    .line 432
    .line 433
    monitor-enter v5

    .line 434
    :try_start_1b1
    sput-object v2, Lcom/facebook/soloader/SoLoader;->o:Lcom/facebook/react/soloader/OpenSourceMergedSoMapping;

    .line 435
    .line 436
    monitor-exit v5
    :try_end_1b4
    .catchall {:try_start_1b1 .. :try_end_1b4} :catchall_1bf

    .line 437
    invoke-static {v0, v4}, Lcom/facebook/soloader/SoLoader;->init(Landroid/content/Context;I)V

    .line 438
    .line 439
    .line 440
    iget-object v0, v1, Lcom/discord/MainApplication;->d:Ljava/util/concurrent/CountDownLatch;

    .line 441
    .line 442
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 443
    .line 444
    .line 445
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 446
    .line 447
    return-object v0

    .line 448
    :catchall_1bf
    move-exception v0

    .line 449
    :try_start_1c0
    monitor-exit v5
    :try_end_1c1
    .catchall {:try_start_1c0 .. :try_end_1c1} :catchall_1bf

    .line 450
    throw v0

    .line 451
    :pswitch_1c2
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 452
    .line 453
    check-cast v0, Ljava/lang/String;

    .line 454
    .line 455
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 456
    .line 457
    check-cast v1, Lj70/a;

    .line 458
    .line 459
    sget-object v2, Ll70/l;->x:Ll70/l;

    .line 460
    .line 461
    new-array v4, v4, [Ll70/g;

    .line 462
    .line 463
    new-instance v5, Lmd/b;

    .line 464
    .line 465
    invoke-direct {v5, v3, v1}, Lmd/b;-><init>(ILjava/lang/Object;)V

    .line 466
    .line 467
    .line 468
    invoke-static {v0, v2, v4, v5}, Lk80/d;->e(Ljava/lang/String;Lk80/l;[Ll70/g;Lkotlin/jvm/functions/Function1;)Ll70/h;

    .line 469
    .line 470
    .line 471
    move-result-object v0

    .line 472
    return-object v0

    .line 473
    :pswitch_1d8
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 474
    .line 475
    check-cast v0, Lj70/a;

    .line 476
    .line 477
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 478
    .line 479
    check-cast v1, Ljava/lang/String;

    .line 480
    .line 481
    iget-object v2, v0, Lj70/a;->c:Ljava/lang/Object;

    .line 482
    .line 483
    check-cast v2, Ln70/v;

    .line 484
    .line 485
    if-nez v2, :cond_200

    .line 486
    .line 487
    new-instance v2, Ln70/v;

    .line 488
    .line 489
    iget-object v0, v0, Lj70/a;->b:Ljava/lang/Object;

    .line 490
    .line 491
    check-cast v0, [Ljava/lang/Enum;

    .line 492
    .line 493
    array-length v3, v0

    .line 494
    invoke-direct {v2, v1, v3}, Ln70/v;-><init>(Ljava/lang/String;I)V

    .line 495
    .line 496
    .line 497
    array-length v1, v0

    .line 498
    move v3, v4

    .line 499
    :goto_1f2
    if-ge v3, v1, :cond_200

    .line 500
    .line 501
    aget-object v5, v0, v3

    .line 502
    .line 503
    invoke-virtual {v5}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 504
    .line 505
    .line 506
    move-result-object v5

    .line 507
    invoke-virtual {v2, v5, v4}, Ln70/v0;->b(Ljava/lang/String;Z)V

    .line 508
    .line 509
    .line 510
    add-int/lit8 v3, v3, 0x1

    .line 511
    .line 512
    goto :goto_1f2

    .line 513
    :cond_200
    return-object v2

    .line 514
    :pswitch_201
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 515
    .line 516
    move-object v6, v0

    .line 517
    check-cast v6, Lle/j;

    .line 518
    .line 519
    iget-object v0, p0, Laj/a;->i:Ljava/lang/Object;

    .line 520
    .line 521
    check-cast v0, Llf/l;

    .line 522
    .line 523
    const-string v1, "Couldn\'t start ForegroundService"

    .line 524
    .line 525
    sget-object v3, Lke/c;->a:Lke/c;

    .line 526
    .line 527
    const-string v3, "start"

    .line 528
    .line 529
    const-string v4, "permission_rejected"

    .line 530
    .line 531
    const-string v5, "create_or_update"

    .line 532
    .line 533
    invoke-virtual {v0}, Llf/l;->a()Z

    .line 534
    .line 535
    .line 536
    move-result v7

    .line 537
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 538
    .line 539
    .line 540
    move-result-object v7

    .line 541
    iget-object v8, v0, Llf/l;->b:Ljava/lang/String;

    .line 542
    .line 543
    invoke-static/range {v3 .. v8}, Lke/c;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lle/j;Ljava/lang/Boolean;Ljava/lang/String;)Ln30/f;

    .line 544
    .line 545
    .line 546
    move-result-object v0

    .line 547
    invoke-static {v1, v0, v2}, Lme/a;->e(Ljava/lang/String;Ln30/f;Ljava/lang/Exception;)V

    .line 548
    .line 549
    .line 550
    invoke-static {}, Lke/c;->b()V

    .line 551
    .line 552
    .line 553
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 554
    .line 555
    return-object v0

    .line 556
    :pswitch_22b
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 557
    .line 558
    check-cast v0, Lcom/discord/chat/presentation/message/view/botuikit/react/TextDisplayComponentViewManager;

    .line 559
    .line 560
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 561
    .line 562
    check-cast v1, Lhc/h;

    .line 563
    .line 564
    invoke-static {v0, v1}, Lcom/discord/chat/presentation/message/view/botuikit/react/TextDisplayComponentViewManager;->e(Lcom/discord/chat/presentation/message/view/botuikit/react/TextDisplayComponentViewManager;Lhc/h;)Ll30/a0;

    .line 565
    .line 566
    .line 567
    move-result-object v0

    .line 568
    return-object v0

    .line 569
    :pswitch_238
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 570
    .line 571
    check-cast v0, Lcom/discord/chat/presentation/message/view/botuikit/react/SelectActionComponentViewManager;

    .line 572
    .line 573
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 574
    .line 575
    check-cast v1, Lhc/f;

    .line 576
    .line 577
    invoke-static {v0, v1}, Lcom/discord/chat/presentation/message/view/botuikit/react/SelectActionComponentViewManager;->b(Lcom/discord/chat/presentation/message/view/botuikit/react/SelectActionComponentViewManager;Lhc/f;)Ll30/a0;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    return-object v0

    .line 582
    :pswitch_245
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 583
    .line 584
    check-cast v0, Ljava/lang/String;

    .line 585
    .line 586
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 587
    .line 588
    check-cast v1, Lj70/g;

    .line 589
    .line 590
    sget-object v2, Ll70/c;->v:Ll70/c;

    .line 591
    .line 592
    new-array v3, v4, [Ll70/g;

    .line 593
    .line 594
    new-instance v5, Lj70/f;

    .line 595
    .line 596
    invoke-direct {v5, v1, v4}, Lj70/f;-><init>(Lj70/g;I)V

    .line 597
    .line 598
    .line 599
    invoke-static {v0, v2, v3, v5}, Lk80/d;->e(Ljava/lang/String;Lk80/l;[Ll70/g;Lkotlin/jvm/functions/Function1;)Ll70/h;

    .line 600
    .line 601
    .line 602
    move-result-object v0

    .line 603
    return-object v0

    .line 604
    :pswitch_25b
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 605
    .line 606
    check-cast v0, Lcom/discord/chat/presentation/message/view/botuikit/components/checkpoint/CheckpointCardV2026ComponentView;

    .line 607
    .line 608
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 609
    .line 610
    check-cast v1, Landroid/content/Context;

    .line 611
    .line 612
    sget v2, Lcom/discord/chat/presentation/message/view/botuikit/components/checkpoint/CheckpointCardV2026ComponentView;->W:I

    .line 613
    .line 614
    invoke-static {v0}, Lfb/v;->a(Landroid/view/View;)Lfb/v;

    .line 615
    .line 616
    .line 617
    move-result-object v0

    .line 618
    iget-object v2, v0, Lfb/v;->M:Landroid/widget/TextView;

    .line 619
    .line 620
    sget-object v4, Lje/a;->y:Lje/a;

    .line 621
    .line 622
    invoke-static {v2, v4}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 623
    .line 624
    .line 625
    iget-object v2, v0, Lfb/v;->N:Landroid/widget/TextView;

    .line 626
    .line 627
    sget-object v4, Lje/a;->J:Lje/a;

    .line 628
    .line 629
    invoke-static {v2, v4}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 630
    .line 631
    .line 632
    iget-object v2, v0, Lfb/v;->y:Landroid/widget/TextView;

    .line 633
    .line 634
    sget-object v4, Lje/a;->R:Lje/a;

    .line 635
    .line 636
    invoke-static {v2, v4}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 637
    .line 638
    .line 639
    iget-object v2, v0, Lfb/v;->w:Landroid/widget/LinearLayout;

    .line 640
    .line 641
    new-instance v4, Lfc/m1;

    .line 642
    .line 643
    invoke-direct {v4, v3, v1}, Lfc/m1;-><init>(ILjava/lang/Object;)V

    .line 644
    .line 645
    .line 646
    invoke-static {v2, v4}, Landroidx/core/view/z0;->p(Landroid/view/View;Landroidx/core/view/b;)V

    .line 647
    .line 648
    .line 649
    return-object v0

    .line 650
    :pswitch_289
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 651
    .line 652
    check-cast v0, Lcom/discord/chat/presentation/message/view/botuikit/components/checkpoint/CheckpointCardV2025ComponentView;

    .line 653
    .line 654
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 655
    .line 656
    check-cast v1, Landroid/content/Context;

    .line 657
    .line 658
    sget v2, Lcom/discord/chat/presentation/message/view/botuikit/components/checkpoint/CheckpointCardV2025ComponentView;->g0:I

    .line 659
    .line 660
    invoke-static {v0}, Lfb/u;->a(Landroid/view/View;)Lfb/u;

    .line 661
    .line 662
    .line 663
    move-result-object v2

    .line 664
    iget-object v5, v2, Lfb/u;->R:Landroid/widget/TextView;

    .line 665
    .line 666
    iget-object v6, v2, Lfb/u;->Y:Landroid/widget/TextView;

    .line 667
    .line 668
    iget-object v7, v2, Lfb/u;->x:Landroid/widget/TextView;

    .line 669
    .line 670
    iget-object v8, v2, Lfb/u;->J:Landroid/widget/TextView;

    .line 671
    .line 672
    iget-object v9, v2, Lfb/u;->i:Landroid/widget/TextView;

    .line 673
    .line 674
    iget-object v10, v2, Lfb/u;->N:Landroid/widget/TextView;

    .line 675
    .line 676
    filled-new-array/range {v5 .. v10}, [Landroid/widget/TextView;

    .line 677
    .line 678
    .line 679
    move-result-object v5

    .line 680
    move v6, v4

    .line 681
    :goto_2a8
    const/4 v7, 0x6

    .line 682
    if-ge v6, v7, :cond_2b8

    .line 683
    .line 684
    aget-object v7, v5, v6

    .line 685
    .line 686
    invoke-static {v7}, Lkotlin/jvm/internal/k;->d(Ljava/lang/Object;)V

    .line 687
    .line 688
    .line 689
    sget-object v8, Lje/a;->M:Lje/a;

    .line 690
    .line 691
    invoke-static {v7, v8}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 692
    .line 693
    .line 694
    add-int/lit8 v6, v6, 0x1

    .line 695
    .line 696
    goto :goto_2a8

    .line 697
    :cond_2b8
    iget-object v5, v2, Lfb/u;->W:Landroid/widget/TextView;

    .line 698
    .line 699
    sget-object v6, Lje/a;->R:Lje/a;

    .line 700
    .line 701
    invoke-static {v5, v6}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 702
    .line 703
    .line 704
    iget-object v5, v2, Lfb/u;->w:Landroid/widget/TextView;

    .line 705
    .line 706
    sget-object v6, Lje/a;->P:Lje/a;

    .line 707
    .line 708
    invoke-static {v5, v6}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 709
    .line 710
    .line 711
    iget-object v5, v2, Lfb/u;->V:Landroid/widget/TextView;

    .line 712
    .line 713
    sget-object v6, Lje/a;->J:Lje/a;

    .line 714
    .line 715
    invoke-static {v5, v6}, Ls1/e;->M(Landroid/widget/TextView;Lje/a;)V

    .line 716
    .line 717
    .line 718
    new-instance v5, Landroid/widget/ImageView;

    .line 719
    .line 720
    invoke-direct {v5, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 721
    .line 722
    .line 723
    invoke-static {}, Landroid/view/View;->generateViewId()I

    .line 724
    .line 725
    .line 726
    move-result v6

    .line 727
    invoke-virtual {v5, v6}, Landroid/view/View;->setId(I)V

    .line 728
    .line 729
    .line 730
    iget-object v0, v0, Lcom/discord/chat/presentation/message/view/botuikit/components/checkpoint/CheckpointCardV2025ComponentView;->e0:[Ljava/lang/Integer;

    .line 731
    .line 732
    invoke-virtual {v5}, Landroid/view/View;->getId()I

    .line 733
    .line 734
    .line 735
    move-result v6

    .line 736
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 737
    .line 738
    .line 739
    move-result-object v6

    .line 740
    aput-object v6, v0, v4

    .line 741
    .line 742
    const v4, 0x7f0800bc

    .line 743
    .line 744
    .line 745
    invoke-virtual {v5, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 746
    .line 747
    .line 748
    new-instance v4, La1/d;

    .line 749
    .line 750
    const/4 v6, 0x4

    .line 751
    int-to-float v6, v6

    .line 752
    invoke-static {v6}, Lox/b;->k(F)I

    .line 753
    .line 754
    .line 755
    move-result v8

    .line 756
    int-to-float v7, v7

    .line 757
    invoke-static {v7}, Lox/b;->k(F)I

    .line 758
    .line 759
    .line 760
    move-result v9

    .line 761
    invoke-direct {v4, v8, v9}, La1/d;-><init>(II)V

    .line 762
    .line 763
    .line 764
    const/4 v8, 0x2

    .line 765
    int-to-float v8, v8

    .line 766
    invoke-static {v8}, Lox/b;->k(F)I

    .line 767
    .line 768
    .line 769
    move-result v9

    .line 770
    invoke-virtual {v4, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 771
    .line 772
    .line 773
    invoke-virtual {v5, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 774
    .line 775
    .line 776
    new-instance v4, Landroid/widget/ImageView;

    .line 777
    .line 778
    invoke-direct {v4, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 779
    .line 780
    .line 781
    invoke-static {}, Landroid/view/View;->generateViewId()I

    .line 782
    .line 783
    .line 784
    move-result v9

    .line 785
    invoke-virtual {v4, v9}, Landroid/view/View;->setId(I)V

    .line 786
    .line 787
    .line 788
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 789
    .line 790
    .line 791
    move-result v9

    .line 792
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 793
    .line 794
    .line 795
    move-result-object v9

    .line 796
    const/16 v10, 0x9

    .line 797
    .line 798
    aput-object v9, v0, v10

    .line 799
    .line 800
    const v9, 0x7f0800ba

    .line 801
    .line 802
    .line 803
    invoke-virtual {v4, v9}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 804
    .line 805
    .line 806
    new-instance v9, La1/d;

    .line 807
    .line 808
    invoke-static {v6}, Lox/b;->k(F)I

    .line 809
    .line 810
    .line 811
    move-result v11

    .line 812
    invoke-static {v7}, Lox/b;->k(F)I

    .line 813
    .line 814
    .line 815
    move-result v12

    .line 816
    invoke-direct {v9, v11, v12}, La1/d;-><init>(II)V

    .line 817
    .line 818
    .line 819
    invoke-static {v8}, Lox/b;->k(F)I

    .line 820
    .line 821
    .line 822
    move-result v11

    .line 823
    invoke-virtual {v9, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 824
    .line 825
    .line 826
    invoke-virtual {v4, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 827
    .line 828
    .line 829
    iget-object v9, v2, Lfb/u;->S:Landroid/widget/LinearLayout;

    .line 830
    .line 831
    invoke-virtual {v9, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 832
    .line 833
    .line 834
    :goto_341
    if-ge v3, v10, :cond_37c

    .line 835
    .line 836
    new-instance v5, Landroid/widget/ImageView;

    .line 837
    .line 838
    invoke-direct {v5, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 839
    .line 840
    .line 841
    invoke-static {}, Landroid/view/View;->generateViewId()I

    .line 842
    .line 843
    .line 844
    move-result v11

    .line 845
    invoke-virtual {v5, v11}, Landroid/view/View;->setId(I)V

    .line 846
    .line 847
    .line 848
    invoke-virtual {v5}, Landroid/view/View;->getId()I

    .line 849
    .line 850
    .line 851
    move-result v11

    .line 852
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 853
    .line 854
    .line 855
    move-result-object v11

    .line 856
    aput-object v11, v0, v3

    .line 857
    .line 858
    const v11, 0x7f0800bb

    .line 859
    .line 860
    .line 861
    invoke-virtual {v5, v11}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 862
    .line 863
    .line 864
    new-instance v11, La1/d;

    .line 865
    .line 866
    invoke-static {v6}, Lox/b;->k(F)I

    .line 867
    .line 868
    .line 869
    move-result v12

    .line 870
    invoke-static {v7}, Lox/b;->k(F)I

    .line 871
    .line 872
    .line 873
    move-result v13

    .line 874
    invoke-direct {v11, v12, v13}, La1/d;-><init>(II)V

    .line 875
    .line 876
    .line 877
    invoke-static {v8}, Lox/b;->k(F)I

    .line 878
    .line 879
    .line 880
    move-result v12

    .line 881
    invoke-virtual {v11, v12}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 882
    .line 883
    .line 884
    invoke-virtual {v5, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 885
    .line 886
    .line 887
    invoke-virtual {v9, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 888
    .line 889
    .line 890
    add-int/lit8 v3, v3, 0x1

    .line 891
    .line 892
    goto :goto_341

    .line 893
    :cond_37c
    invoke-virtual {v9, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 894
    .line 895
    .line 896
    return-object v2

    .line 897
    :pswitch_380
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 898
    .line 899
    move-object v3, v0

    .line 900
    check-cast v3, Lhi/c;

    .line 901
    .line 902
    iget-object v0, p0, Laj/a;->i:Ljava/lang/Object;

    .line 903
    .line 904
    move-object v5, v0

    .line 905
    check-cast v5, Landroid/os/Bundle;

    .line 906
    .line 907
    :try_start_38a
    sget-object v0, Lhi/h;->a:Ljava/util/concurrent/CountDownLatch;

    .line 908
    .line 909
    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 910
    .line 911
    const-wide/16 v7, 0x1e

    .line 912
    .line 913
    invoke-virtual {v0, v7, v8, v6}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    .line 914
    .line 915
    .line 916
    move-result v6

    .line 917
    if-nez v6, :cond_3af

    .line 918
    .line 919
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 920
    .line 921
    const-string v6, "App load still waiting on application initialization after 30s"

    .line 922
    .line 923
    invoke-direct {v2, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 924
    .line 925
    .line 926
    sget-object v6, Lnf/a;->a:Lnf/a;

    .line 927
    .line 928
    const-string v6, "ActivityDelegate"

    .line 929
    .line 930
    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 931
    .line 932
    .line 933
    move-result-object v7

    .line 934
    if-nez v7, :cond_3a9

    .line 935
    .line 936
    const-string v7, ""

    .line 937
    .line 938
    :cond_3a9
    invoke-static {v6, v7, v2}, Lnf/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 939
    .line 940
    .line 941
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_3af
    .catch Ljava/lang/InterruptedException; {:try_start_38a .. :try_end_3af} :catch_3e2

    .line 942
    .line 943
    .line 944
    :cond_3af
    if-eqz v2, :cond_3b9

    .line 945
    .line 946
    sget-object v0, Lcom/discord/crash_reporting/CrashReporting;->INSTANCE:Lcom/discord/crash_reporting/CrashReporting;

    .line 947
    .line 948
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 949
    .line 950
    .line 951
    invoke-static {v2, v4}, Lcom/discord/crash_reporting/CrashReporting;->c(Ljava/lang/Throwable;Z)V

    .line 952
    .line 953
    .line 954
    :cond_3b9
    :try_start_3b9
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 955
    .line 956
    .line 957
    invoke-static {}, Lhi/c;->h()V
    :try_end_3bf
    .catch Ljava/lang/InterruptedException; {:try_start_3b9 .. :try_end_3bf} :catch_3e2
    .catchall {:try_start_3b9 .. :try_end_3bf} :catchall_3c0

    .line 958
    .line 959
    .line 960
    goto :goto_3c9

    .line 961
    :catchall_3c0
    move-exception v0

    .line 962
    sget-object v2, Lcom/discord/crash_reporting/CrashReporting;->INSTANCE:Lcom/discord/crash_reporting/CrashReporting;

    .line 963
    .line 964
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 965
    .line 966
    .line 967
    invoke-static {v0, v4}, Lcom/discord/crash_reporting/CrashReporting;->c(Ljava/lang/Throwable;Z)V

    .line 968
    .line 969
    .line 970
    :goto_3c9
    new-instance v0, Landroidx/lifecycle/t0;

    .line 971
    .line 972
    invoke-direct {v0, v3, v5}, Landroidx/lifecycle/t0;-><init>(Lhi/c;Landroid/os/Bundle;)V

    .line 973
    .line 974
    .line 975
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 976
    .line 977
    .line 978
    new-instance v2, Landroid/os/Handler;

    .line 979
    .line 980
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 981
    .line 982
    .line 983
    move-result-object v3

    .line 984
    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 985
    .line 986
    .line 987
    new-instance v3, Le/k;

    .line 988
    .line 989
    invoke-direct {v3, v1, v0}, Le/k;-><init>(ILjava/lang/Object;)V

    .line 990
    .line 991
    .line 992
    invoke-virtual {v2, v3}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    .line 993
    .line 994
    .line 995
    :catch_3e2
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 996
    .line 997
    return-object v0

    .line 998
    :pswitch_3e5
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 999
    .line 1000
    check-cast v0, Lgc/b;

    .line 1001
    .line 1002
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1003
    .line 1004
    check-cast v1, Lhc/c;

    .line 1005
    .line 1006
    iget-object v0, v0, Lgc/b;->c:Lgc/e;

    .line 1007
    .line 1008
    iget-object v0, v0, Lgc/e;->b:Lkotlin/jvm/functions/Function0;

    .line 1009
    .line 1010
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1011
    .line 1012
    .line 1013
    iget-object v0, v1, Lhc/c;->d:Lfb/w;

    .line 1014
    .line 1015
    iget-object v0, v0, Lfb/w;->i:Landroid/widget/LinearLayout;

    .line 1016
    .line 1017
    invoke-virtual {v0, v4}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 1018
    .line 1019
    .line 1020
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1021
    .line 1022
    return-object v0

    .line 1023
    :pswitch_3fe
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1024
    .line 1025
    check-cast v0, Lcom/discord/chat/presentation/message/view/SpoilerView;

    .line 1026
    .line 1027
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1028
    .line 1029
    check-cast v1, Landroid/view/View;

    .line 1030
    .line 1031
    sget v2, Lcom/discord/chat/presentation/message/view/SpoilerView;->w:I

    .line 1032
    .line 1033
    invoke-virtual {v0, v1, v3}, Lcom/discord/chat/presentation/message/view/SpoilerView;->d(Landroid/view/View;Z)V

    .line 1034
    .line 1035
    .line 1036
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1037
    .line 1038
    return-object v0

    .line 1039
    :pswitch_40e
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1040
    .line 1041
    check-cast v0, Lfc/c2;

    .line 1042
    .line 1043
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1044
    .line 1045
    check-cast v1, Lcom/discord/chat/presentation/message/view/ObscureOverlayView;

    .line 1046
    .line 1047
    sget v2, Lcom/discord/chat/presentation/message/view/ObscureOverlayView;->e:I

    .line 1048
    .line 1049
    invoke-virtual {v0}, Lfc/c2;->invoke()Ljava/lang/Object;

    .line 1050
    .line 1051
    .line 1052
    iget-object v0, v1, Lcom/discord/chat/presentation/message/view/ObscureOverlayView;->d:Lp/r3;

    .line 1053
    .line 1054
    iget-object v0, v0, Lp/r3;->J:Ljava/lang/Object;

    .line 1055
    .line 1056
    check-cast v0, Lcom/discord/chat/presentation/message/view/IconButtonView;

    .line 1057
    .line 1058
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 1059
    .line 1060
    .line 1061
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1062
    .line 1063
    return-object v0

    .line 1064
    :pswitch_427
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1065
    .line 1066
    check-cast v0, Lcg/e;

    .line 1067
    .line 1068
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1069
    .line 1070
    check-cast v1, Ljava/lang/String;

    .line 1071
    .line 1072
    invoke-virtual {v0, v2, v2, v1}, Lcg/e;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1073
    .line 1074
    .line 1075
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1076
    .line 1077
    return-object v0

    .line 1078
    :pswitch_435
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1079
    .line 1080
    check-cast v0, Lf2/d;

    .line 1081
    .line 1082
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1083
    .line 1084
    check-cast v1, Ly1/p;

    .line 1085
    .line 1086
    invoke-virtual {v0}, Lf2/d;->g()Ljava/util/concurrent/Executor;

    .line 1087
    .line 1088
    .line 1089
    move-result-object v2

    .line 1090
    new-instance v3, La4/c;

    .line 1091
    .line 1092
    const/16 v4, 0x1b

    .line 1093
    .line 1094
    invoke-direct {v3, v4, v0, v1}, La4/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 1095
    .line 1096
    .line 1097
    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 1098
    .line 1099
    .line 1100
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1101
    .line 1102
    return-object v0

    .line 1103
    :pswitch_44e
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1104
    .line 1105
    check-cast v0, Ljava/util/concurrent/Executor;

    .line 1106
    .line 1107
    iget-object v2, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1108
    .line 1109
    check-cast v2, Ly1/i;

    .line 1110
    .line 1111
    new-instance v3, Ld2/b;

    .line 1112
    .line 1113
    invoke-direct {v3, v2, v1}, Ld2/b;-><init>(Ly1/i;I)V

    .line 1114
    .line 1115
    .line 1116
    invoke-interface {v0, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 1117
    .line 1118
    .line 1119
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1120
    .line 1121
    return-object v0

    .line 1122
    :pswitch_461
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1123
    .line 1124
    check-cast v0, Lcom/margelo/nitro/rive/HybridViewModelInstanceSpec;

    .line 1125
    .line 1126
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1127
    .line 1128
    check-cast v1, Lcom/margelo/nitro/rive/HybridRiveView;

    .line 1129
    .line 1130
    invoke-static {v0, v1}, Lcom/margelo/nitro/rive/HybridRiveView;->a(Lcom/margelo/nitro/rive/HybridViewModelInstanceSpec;Lcom/margelo/nitro/rive/HybridRiveView;)Ll30/a0;

    .line 1131
    .line 1132
    .line 1133
    move-result-object v0

    .line 1134
    return-object v0

    .line 1135
    :pswitch_46e
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1136
    .line 1137
    check-cast v0, Lcom/margelo/nitro/rive/HybridRiveView;

    .line 1138
    .line 1139
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1140
    .line 1141
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 1142
    .line 1143
    invoke-static {v0, v1}, Lcom/margelo/nitro/rive/HybridRiveView;->f(Lcom/margelo/nitro/rive/HybridRiveView;Lkotlin/jvm/functions/Function1;)Ll30/a0;

    .line 1144
    .line 1145
    .line 1146
    move-result-object v0

    .line 1147
    return-object v0

    .line 1148
    :pswitch_47b
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1149
    .line 1150
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 1151
    .line 1152
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1153
    .line 1154
    check-cast v1, Ljava/lang/String;

    .line 1155
    .line 1156
    invoke-static {v0, v1}, Lcom/margelo/nitro/rive/BaseHybridViewModelPropertyImpl;->a(Ljava/lang/ref/WeakReference;Ljava/lang/String;)Ll30/a0;

    .line 1157
    .line 1158
    .line 1159
    move-result-object v0

    .line 1160
    return-object v0

    .line 1161
    :pswitch_488
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1162
    .line 1163
    check-cast v0, Lcom/margelo/nitro/nitrofetch/f0;

    .line 1164
    .line 1165
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1166
    .line 1167
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 1168
    .line 1169
    iget-object v2, v0, Lcom/margelo/nitro/nitrofetch/f0;->d:Ljava/lang/Object;

    .line 1170
    .line 1171
    monitor-enter v2

    .line 1172
    :try_start_493
    iput-boolean v3, v0, Lcom/margelo/nitro/nitrofetch/f0;->i:Z

    .line 1173
    .line 1174
    iget-object v5, v0, Lcom/margelo/nitro/nitrofetch/f0;->j:Ljava/util/concurrent/ScheduledFuture;

    .line 1175
    .line 1176
    if-eqz v5, :cond_49f

    .line 1177
    .line 1178
    invoke-interface {v5, v4}, Ljava/util/concurrent/Future;->cancel(Z)Z
    :try_end_49c
    .catchall {:try_start_493 .. :try_end_49c} :catchall_49d

    .line 1179
    .line 1180
    .line 1181
    goto :goto_49f

    .line 1182
    :catchall_49d
    move-exception v0

    .line 1183
    goto :goto_4b5

    .line 1184
    :cond_49f
    :goto_49f
    monitor-exit v2

    .line 1185
    iget-object v0, v0, Lcom/margelo/nitro/nitrofetch/f0;->t:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1186
    .line 1187
    invoke-virtual {v0, v4, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 1188
    .line 1189
    .line 1190
    move-result v0

    .line 1191
    if-eqz v0, :cond_4b2

    .line 1192
    .line 1193
    new-instance v0, Ljava/lang/RuntimeException;

    .line 1194
    .line 1195
    const-string v2, "Cronet canceled"

    .line 1196
    .line 1197
    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1198
    .line 1199
    .line 1200
    invoke-interface {v1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1201
    .line 1202
    .line 1203
    :cond_4b2
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1204
    .line 1205
    return-object v0

    .line 1206
    :goto_4b5
    monitor-exit v2

    .line 1207
    throw v0

    .line 1208
    :pswitch_4b7
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1209
    .line 1210
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 1211
    .line 1212
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1213
    .line 1214
    check-cast v1, Ljava/lang/Throwable;

    .line 1215
    .line 1216
    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1217
    .line 1218
    .line 1219
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1220
    .line 1221
    return-object v0

    .line 1222
    :pswitch_4c5
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1223
    .line 1224
    check-cast v0, Lcom/discord/qr/scanner/QRScannerViewManager;

    .line 1225
    .line 1226
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1227
    .line 1228
    check-cast v1, Lci/a;

    .line 1229
    .line 1230
    invoke-static {v0, v1}, Lcom/discord/qr/scanner/QRScannerViewManager;->a(Lcom/discord/qr/scanner/QRScannerViewManager;Lci/a;)Ll30/a0;

    .line 1231
    .line 1232
    .line 1233
    move-result-object v0

    .line 1234
    return-object v0

    .line 1235
    :pswitch_4d2
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1236
    .line 1237
    check-cast v0, Lbq/h;

    .line 1238
    .line 1239
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1240
    .line 1241
    check-cast v1, Le/l;

    .line 1242
    .line 1243
    iget-object v0, v0, Lbq/h;->v:Lbq/f;

    .line 1244
    .line 1245
    if-eqz v0, :cond_4f2

    .line 1246
    .line 1247
    check-cast v0, Lbq/a;

    .line 1248
    .line 1249
    iget-object v2, v0, Lbq/a;->e:Ljava/lang/Object;

    .line 1250
    .line 1251
    check-cast v2, Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 1252
    .line 1253
    iget-object v3, v0, Lbq/a;->i:Ljava/lang/Object;

    .line 1254
    .line 1255
    check-cast v3, Lcom/facebook/react/uimanager/k0;

    .line 1256
    .line 1257
    iget-object v0, v0, Lbq/a;->v:Ljava/lang/Object;

    .line 1258
    .line 1259
    check-cast v0, Lbq/h;

    .line 1260
    .line 1261
    invoke-static {v2, v3, v0, v1}, Lcom/facebook/react/views/modal/ReactModalHostManager;->b(Lcom/facebook/react/uimanager/events/EventDispatcher;Lcom/facebook/react/uimanager/k0;Lbq/h;Le/l;)V

    .line 1262
    .line 1263
    .line 1264
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1265
    .line 1266
    return-object v0

    .line 1267
    :cond_4f2
    const-string v0, "onRequestClose callback must be set if back key is expected to close the modal"

    .line 1268
    .line 1269
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 1270
    .line 1271
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1272
    .line 1273
    .line 1274
    throw v1

    .line 1275
    :pswitch_4fa
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1276
    .line 1277
    check-cast v0, Lkotlin/jvm/internal/i;

    .line 1278
    .line 1279
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1280
    .line 1281
    check-cast v1, Lfc/g2;

    .line 1282
    .line 1283
    iget-object v2, v1, Lfc/g2;->a:Ljava/lang/String;

    .line 1284
    .line 1285
    iget-object v1, v1, Lfc/g2;->b:Ljava/lang/String;

    .line 1286
    .line 1287
    invoke-interface {v0, v2, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1288
    .line 1289
    .line 1290
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1291
    .line 1292
    return-object v0

    .line 1293
    :pswitch_50c
    iget-object v0, p0, Laj/a;->e:Ljava/lang/Object;

    .line 1294
    .line 1295
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 1296
    .line 1297
    iget-object v1, p0, Laj/a;->i:Ljava/lang/Object;

    .line 1298
    .line 1299
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 1300
    .line 1301
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1302
    .line 1303
    .line 1304
    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1305
    .line 1306
    .line 1307
    sget-object v0, Ll30/a0;->a:Ll30/a0;

    .line 1308
    .line 1309
    return-object v0

    .line 1310
    nop

    .line 1311
    :pswitch_data_51e
    .packed-switch 0x0
        :pswitch_50c
        :pswitch_4fa
        :pswitch_4d2
        :pswitch_4c5
        :pswitch_4b7
        :pswitch_488
        :pswitch_47b
        :pswitch_46e
        :pswitch_461
        :pswitch_44e
        :pswitch_435
        :pswitch_427
        :pswitch_40e
        :pswitch_3fe
        :pswitch_3e5
        :pswitch_380
        :pswitch_289
        :pswitch_25b
        :pswitch_245
        :pswitch_238
        :pswitch_22b
        :pswitch_201
        :pswitch_1d8
        :pswitch_1c2
        :pswitch_1a0
        :pswitch_13a
        :pswitch_f5
        :pswitch_2a
        :pswitch_1a
    .end packed-switch
.end method
