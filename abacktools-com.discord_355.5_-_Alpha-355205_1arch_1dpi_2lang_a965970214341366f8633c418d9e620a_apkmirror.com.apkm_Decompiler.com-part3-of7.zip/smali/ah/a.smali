###### Class ah.a (ah.a)
.class public final Lah/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lkotlin/jvm/functions/Function1;

.field public b:Lyg/h;

.field public c:Lbh/l;

.field public d:Lyg/k;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lah/a;->a:Lkotlin/jvm/functions/Function1;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lbh/l;
    .registers 4

    .line 1
    iget-object v0, p0, Lah/a;->c:Lbh/l;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    iget-object v0, p0, Lah/a;->a:Lkotlin/jvm/functions/Function1;

    .line 7
    .line 8
    invoke-interface {v0, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lbh/l;

    .line 13
    .line 14
    iget-object v1, p0, Lah/a;->b:Lyg/h;

    .line 15
    .line 16
    if-eqz v1, :cond_39

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lbh/l;->setAssets(Lyg/h;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const-string v2, "window"

    .line 26
    .line 27
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v2, "null cannot be cast to non-null type android.view.WindowManager"

    .line 32
    .line 33
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    check-cast v1, Landroid/view/WindowManager;

    .line 37
    .line 38
    invoke-virtual {v0}, Lbh/l;->getInitialLayoutParams()Landroid/view/WindowManager$LayoutParams;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    invoke-interface {v1, v0, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 43
    .line 44
    .line 45
    const/4 v1, 0x1

    .line 46
    iput-boolean v1, v0, Lbh/l;->e:Z

    .line 47
    .line 48
    iget-object v1, p0, Lah/a;->d:Lyg/k;

    .line 49
    .line 50
    if-eqz v1, :cond_36

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Lbh/l;->setData(Lyg/k;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    iput-object v0, p0, Lah/a;->c:Lbh/l;

    .line 56
    .line 57
    return-object v0

    .line 58
    :cond_39
    const-string v0, "assets"

    .line 59
    .line 60
    invoke-static {v0}, Lkotlin/jvm/internal/k;->q(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    const/4 v0, 0x0

    .line 64
    throw v0
.end method

.method public final b()V
    .registers 4

    .line 1
    iget-object v0, p0, Lah/a;->c:Lbh/l;

    .line 2
    .line 3
    if-eqz v0, :cond_1b

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-string v2, "window"

    .line 10
    .line 11
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const-string v2, "null cannot be cast to non-null type android.view.WindowManager"

    .line 16
    .line 17
    invoke-static {v1, v2}, Lkotlin/jvm/internal/k;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    check-cast v1, Landroid/view/WindowManager;

    .line 21
    .line 22
    invoke-interface {v1, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    .line 23
    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    iput-boolean v1, v0, Lbh/l;->e:Z

    .line 27
    .line 28
    :cond_1b
    const/4 v0, 0x0

    .line 29
    iput-object v0, p0, Lah/a;->c:Lbh/l;

    .line 30
    .line 31
    return-void
.end method

.method public final c(Lyg/h;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lah/a;->b:Lyg/h;

    .line 2
    .line 3
    iget-object v0, p0, Lah/a;->c:Lbh/l;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lbh/l;->setAssets(Lyg/h;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public final d(Lyg/k;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lah/a;->d:Lyg/k;

    .line 2
    .line 3
    iget-object v0, p0, Lah/a;->c:Lbh/l;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lbh/l;->setData(Lyg/k;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method
