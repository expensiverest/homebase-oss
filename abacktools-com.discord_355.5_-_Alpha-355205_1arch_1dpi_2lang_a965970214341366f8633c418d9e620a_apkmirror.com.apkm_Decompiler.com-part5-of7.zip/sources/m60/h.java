package m60;

import d60.o;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import kotlin.jvm.functions.Function1;
import m30.s;
import m30.u;
import q40.m0;
import q40.x;

/* JADX INFO: loaded from: classes3.dex */
public class h implements o {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f21211b;

    public h(i iVar, String... formatParams) {
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        String str = iVar.f21217d;
        Object[] objArrCopyOf = Arrays.copyOf(formatParams, formatParams.length);
        this.f21211b = String.format(str, Arrays.copyOf(objArrCopyOf, objArrCopyOf.length));
    }

    @Override // d60.o
    public Set b() {
        return u.f20881d;
    }

    @Override // d60.o
    public Set c() {
        return u.f20881d;
    }

    @Override // d60.q
    public Collection d(d60.f kindFilter, Function1 function1) {
        kotlin.jvm.internal.k.g(kindFilter, "kindFilter");
        return s.f20879d;
    }

    @Override // d60.o
    public Set f() {
        return u.f20881d;
    }

    @Override // d60.q
    public q40.h g(t50.e name, y40.a location) {
        kotlin.jvm.internal.k.g(name, "name");
        kotlin.jvm.internal.k.g(location, "location");
        b[] bVarArr = b.f21202d;
        return new a(t50.e.g(String.format("<Error class: %s>", Arrays.copyOf(new Object[]{name}, 1))));
    }

    @Override // d60.o
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public Set e(t50.e name, y40.c cVar) {
        kotlin.jvm.internal.k.g(name, "name");
        a containingDeclaration = m.f21242c;
        kotlin.jvm.internal.k.g(containingDeclaration, "containingDeclaration");
        b[] bVarArr = b.f21202d;
        d dVar = new d(containingDeclaration, null, r40.g.f27594a, t50.e.g("<Error function>"), 1, m0.f26549u);
        j jVarC = m.c(l.RETURN_TYPE_FOR_FUNCTION, new String[0]);
        x xVar = x.f26583v;
        d50.o oVar = q40.o.f26557e;
        s sVar = s.f20879d;
        dVar.O2(null, null, sVar, sVar, sVar, jVarC, xVar, oVar);
        return su.e.J(dVar);
    }

    @Override // d60.o
    /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
    public Set a(t50.e name, y40.c cVar) {
        kotlin.jvm.internal.k.g(name, "name");
        return m.f21245f;
    }

    public String toString() {
        return a1.h.k(new StringBuilder("ErrorScope{"), this.f21211b, '}');
    }
}
