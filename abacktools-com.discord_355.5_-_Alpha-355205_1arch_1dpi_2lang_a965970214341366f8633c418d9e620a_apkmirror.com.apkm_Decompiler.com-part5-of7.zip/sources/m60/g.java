package m60;

import d50.o;
import hs.q;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import k60.t0;
import k60.w;
import m30.s;
import q40.k0;
import q40.m0;
import q40.x;
import t40.h0;
import t40.i0;
import t40.j0;
import t40.r;
import t40.u;

/* JADX INFO: loaded from: classes3.dex */
public final class g implements k0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ h0 f21210d;

    public g() {
        m mVar = m.f21240a;
        a aVar = m.f21242c;
        x xVar = x.f26583v;
        o oVar = q40.o.f26557e;
        b[] bVarArr = b.f21202d;
        h0 h0VarK2 = h0.K2(aVar, xVar, oVar, true, t50.e.g("<Error property>"), 1, m0.f26549u);
        j jVar = m.f21244e;
        s sVar = s.f20879d;
        h0VarK2.Q2(jVar, sVar, null, null, sVar);
        this.f21210d = h0VarK2;
    }

    @Override // q40.k
    public final q40.k A() {
        q40.k kVarA = this.f21210d.A();
        kotlin.jvm.internal.k.f(kVarA, "getContainingDeclaration(...)");
        return kVarA;
    }

    @Override // q40.k0
    public final r A1() {
        return this.f21210d.f29710b0;
    }

    @Override // q40.b
    public final List B1() {
        List listB1 = this.f21210d.B1();
        kotlin.jvm.internal.k.f(listB1, "getContextReceiverParameters(...)");
        return listB1;
    }

    @Override // q40.c, q40.b
    public final Collection C() {
        Collection collectionC = this.f21210d.C();
        kotlin.jvm.internal.k.f(collectionC, "getOverriddenDescriptors(...)");
        return collectionC;
    }

    @Override // q40.t0
    public final boolean E1() {
        return this.f21210d.Q;
    }

    @Override // q40.w
    public final boolean K0() {
        return this.f21210d.S;
    }

    @Override // q40.k0
    public final boolean O0() {
        return this.f21210d.U;
    }

    @Override // q40.c
    public final void Q1(Collection collection) {
        this.f21210d.N = collection;
    }

    @Override // q40.t0
    public final y50.g V0() {
        return this.f21210d.V0();
    }

    @Override // q40.k
    public final k0 a() {
        k0 k0VarA = this.f21210d.a();
        kotlin.jvm.internal.k.f(k0VarA, "getOriginal(...)");
        return k0VarA;
    }

    @Override // q40.b
    public final List b1() {
        this.f21210d.b1();
        List list = Collections.EMPTY_LIST;
        kotlin.jvm.internal.k.f(list, "getValueParameters(...)");
        return list;
    }

    @Override // q40.k0
    public final i0 c() {
        return this.f21210d.Z;
    }

    @Override // q40.k0
    public final ArrayList e0() {
        return this.f21210d.e0();
    }

    @Override // q40.w
    public final boolean e2() {
        this.f21210d.getClass();
        return false;
    }

    @Override // q40.o0
    public final k0 f(t0 substitutor) {
        kotlin.jvm.internal.k.g(substitutor, "substitutor");
        return this.f21210d.f(substitutor);
    }

    @Override // r40.a
    public final r40.h getAnnotations() {
        r40.h annotations = this.f21210d.getAnnotations();
        kotlin.jvm.internal.k.f(annotations, "<get-annotations>(...)");
        return annotations;
    }

    @Override // q40.k
    public final t50.e getName() {
        t50.e name = this.f21210d.getName();
        kotlin.jvm.internal.k.f(name, "getName(...)");
        return name;
    }

    @Override // q40.b
    public final w getReturnType() {
        return this.f21210d.getReturnType();
    }

    @Override // q40.s0
    public final w getType() {
        w type = this.f21210d.getType();
        kotlin.jvm.internal.k.f(type, "getType(...)");
        return type;
    }

    @Override // q40.b
    public final List getTypeParameters() {
        return this.f21210d.getTypeParameters();
    }

    @Override // q40.n
    public final o getVisibility() {
        o visibility = this.f21210d.getVisibility();
        kotlin.jvm.internal.k.f(visibility, "getVisibility(...)");
        return visibility;
    }

    @Override // q40.k0
    public final j0 h() {
        return this.f21210d.f29709a0;
    }

    @Override // q40.w
    public final boolean isExternal() {
        return this.f21210d.isExternal();
    }

    @Override // q40.c
    public final int j() {
        int iJ = this.f21210d.j();
        q.w(iJ, "getKind(...)");
        return iJ;
    }

    @Override // q40.l
    public final m0 k() {
        m0 m0VarK = this.f21210d.k();
        kotlin.jvm.internal.k.f(m0VarK, "getSource(...)");
        return m0VarK;
    }

    @Override // q40.c
    public final q40.c l2(q40.e eVar, x xVar, o oVar) {
        return this.f21210d.l2(eVar, xVar, oVar);
    }

    @Override // q40.t0
    public final boolean m0() {
        return this.f21210d.R;
    }

    @Override // q40.b
    public final u m1() {
        return this.f21210d.W;
    }

    @Override // q40.w
    public final x p() {
        x xVarP = this.f21210d.p();
        kotlin.jvm.internal.k.f(xVarP, "getModality(...)");
        return xVarP;
    }

    @Override // q40.k
    public final Object r1(q40.m mVar, Object obj) {
        h0 h0Var = this.f21210d;
        h0Var.getClass();
        return mVar.j(h0Var, obj);
    }

    @Override // q40.t0
    public final boolean t1() {
        return this.f21210d.y;
    }

    @Override // q40.b
    public final u v1() {
        return this.f21210d.X;
    }

    @Override // q40.k0
    public final r x1() {
        return this.f21210d.f29711c0;
    }

    @Override // q40.b
    public final boolean y0() {
        this.f21210d.getClass();
        return false;
    }

    @Override // q40.b
    public final Object z1(q40.a aVar) {
        this.f21210d.getClass();
        return null;
    }
}
