package m60;

import java.util.Collection;
import java.util.Set;
import kotlin.jvm.functions.Function1;

/* JADX INFO: loaded from: classes3.dex */
public final class n extends h {
    @Override // m60.h, d60.o
    public final /* bridge */ /* synthetic */ Collection a(t50.e eVar, y40.c cVar) {
        a(eVar, cVar);
        throw null;
    }

    @Override // m60.h, d60.o
    public final Set b() {
        throw new IllegalStateException();
    }

    @Override // m60.h, d60.o
    public final Set c() {
        throw new IllegalStateException();
    }

    @Override // m60.h, d60.q
    public final Collection d(d60.f kindFilter, Function1 function1) {
        kotlin.jvm.internal.k.g(kindFilter, "kindFilter");
        throw new IllegalStateException(this.f21211b);
    }

    @Override // m60.h, d60.o
    public final /* bridge */ /* synthetic */ Collection e(t50.e eVar, y40.a aVar) {
        e(eVar, (y40.c) aVar);
        throw null;
    }

    @Override // m60.h, d60.o
    public final Set f() {
        throw new IllegalStateException();
    }

    @Override // m60.h, d60.q
    public final q40.h g(t50.e name, y40.a location) {
        kotlin.jvm.internal.k.g(name, "name");
        kotlin.jvm.internal.k.g(location, "location");
        throw new IllegalStateException(this.f21211b + ", required name: " + name);
    }

    @Override // m60.h
    /* JADX INFO: renamed from: h */
    public final Set e(t50.e name, y40.c cVar) {
        kotlin.jvm.internal.k.g(name, "name");
        throw new IllegalStateException(this.f21211b + ", required name: " + name);
    }

    @Override // m60.h
    /* JADX INFO: renamed from: i */
    public final Set a(t50.e name, y40.c cVar) {
        kotlin.jvm.internal.k.g(name, "name");
        throw new IllegalStateException(this.f21211b + ", required name: " + name);
    }

    @Override // m60.h
    public final String toString() {
        return a1.h.k(new StringBuilder("ThrowingScope{"), this.f21211b, '}');
    }
}
