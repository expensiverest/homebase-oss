package m60;

import a6.q0;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.functions.Function1;
import l30.o;
import m30.s;
import q40.h0;
import q40.y;

/* JADX INFO: loaded from: classes3.dex */
public final class f implements y {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final f f21206d = new f();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final t50.e f21207e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final s f21208i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final o f21209v;

    static {
        b[] bVarArr = b.f21202d;
        f21207e = t50.e.g("<Error module>");
        f21208i = s.f20879d;
        f21209v = a.a.K(e.f21205d);
    }

    @Override // q40.k
    public final q40.k A() {
        return null;
    }

    @Override // q40.y
    public final List F1() {
        return f21208i;
    }

    @Override // q40.y
    public final boolean M1(y targetModule) {
        kotlin.jvm.internal.k.g(targetModule, "targetModule");
        return false;
    }

    @Override // q40.y
    public final Object S1(q0 capability) {
        kotlin.jvm.internal.k.g(capability, "capability");
        return null;
    }

    @Override // q40.y
    public final n40.i g() {
        return (n40.i) f21209v.getValue();
    }

    @Override // r40.a
    public final r40.h getAnnotations() {
        return r40.g.f27594a;
    }

    @Override // q40.k
    public final t50.e getName() {
        return f21207e;
    }

    @Override // q40.y
    public final h0 q1(t50.c fqName) {
        kotlin.jvm.internal.k.g(fqName, "fqName");
        throw new IllegalStateException("Should not be called!");
    }

    @Override // q40.y
    public final Collection r(t50.c fqName, Function1 function1) {
        kotlin.jvm.internal.k.g(fqName, "fqName");
        return s.f20879d;
    }

    @Override // q40.k
    public final Object r1(q40.m mVar, Object obj) {
        return null;
    }

    @Override // q40.k
    public final q40.k a() {
        return this;
    }
}
