package m60;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import k60.l0;
import m30.s;

/* JADX INFO: loaded from: classes3.dex */
public final class k implements l0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final l f21223a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String[] f21224b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f21225c;

    public k(l kind, String... formatParams) {
        kotlin.jvm.internal.k.g(kind, "kind");
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        this.f21223a = kind;
        this.f21224b = formatParams;
        b[] bVarArr = b.f21202d;
        String str = kind.f21238d;
        Object[] objArrCopyOf = Arrays.copyOf(formatParams, formatParams.length);
        this.f21225c = String.format("[Error type: %s]", Arrays.copyOf(new Object[]{String.format(str, Arrays.copyOf(objArrCopyOf, objArrCopyOf.length))}, 1));
    }

    @Override // k60.l0
    public final n40.i g() {
        return (n40.e) n40.e.f22520f.getValue();
    }

    @Override // k60.l0
    public final List getParameters() {
        return s.f20879d;
    }

    @Override // k60.l0
    public final q40.h h() {
        m.f21240a.getClass();
        return m.f21242c;
    }

    @Override // k60.l0
    public final Collection i() {
        return s.f20879d;
    }

    @Override // k60.l0
    public final boolean j() {
        return false;
    }

    public final String toString() {
        return this.f21225c;
    }
}
