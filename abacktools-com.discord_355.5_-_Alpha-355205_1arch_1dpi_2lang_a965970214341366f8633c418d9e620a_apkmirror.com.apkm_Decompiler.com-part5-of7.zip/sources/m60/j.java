package m60;

import d60.o;
import java.util.Arrays;
import java.util.List;
import k60.a0;
import k60.h0;
import k60.l0;
import k60.w;
import k60.y0;

/* JADX INFO: loaded from: classes3.dex */
public final class j extends a0 {
    public final String J;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final l0 f21218e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final h f21219i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final l f21220v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final List f21221w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final boolean f21222x;
    public final String[] y;

    public j(l0 l0Var, h hVar, l kind, List arguments, boolean z11, String... formatParams) {
        kotlin.jvm.internal.k.g(kind, "kind");
        kotlin.jvm.internal.k.g(arguments, "arguments");
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        this.f21218e = l0Var;
        this.f21219i = hVar;
        this.f21220v = kind;
        this.f21221w = arguments;
        this.f21222x = z11;
        this.y = formatParams;
        String str = kind.f21238d;
        Object[] objArrCopyOf = Arrays.copyOf(formatParams, formatParams.length);
        this.J = String.format(str, Arrays.copyOf(objArrCopyOf, objArrCopyOf.length));
    }

    @Override // k60.w
    public final o Y0() {
        return this.f21219i;
    }

    @Override // k60.w
    public final List l() {
        return this.f21221w;
    }

    @Override // k60.w
    public final h0 m() {
        h0.f19250e.getClass();
        return h0.f19251i;
    }

    @Override // k60.w
    public final l0 n() {
        return this.f21218e;
    }

    @Override // k60.w
    public final boolean o() {
        return this.f21222x;
    }

    @Override // k60.w
    /* JADX INFO: renamed from: q */
    public final w u(l60.f kotlinTypeRefiner) {
        kotlin.jvm.internal.k.g(kotlinTypeRefiner, "kotlinTypeRefiner");
        return this;
    }

    @Override // k60.y0
    public final y0 u(l60.f kotlinTypeRefiner) {
        kotlin.jvm.internal.k.g(kotlinTypeRefiner, "kotlinTypeRefiner");
        return this;
    }

    @Override // k60.a0, k60.y0
    public final y0 v(h0 newAttributes) {
        kotlin.jvm.internal.k.g(newAttributes, "newAttributes");
        return this;
    }

    @Override // k60.a0
    /* JADX INFO: renamed from: x */
    public final a0 t(boolean z11) {
        String[] strArr = this.y;
        return new j(this.f21218e, this.f21219i, this.f21220v, this.f21221w, z11, (String[]) Arrays.copyOf(strArr, strArr.length));
    }

    @Override // k60.a0
    /* JADX INFO: renamed from: y */
    public final a0 v(h0 newAttributes) {
        kotlin.jvm.internal.k.g(newAttributes, "newAttributes");
        return this;
    }
}
