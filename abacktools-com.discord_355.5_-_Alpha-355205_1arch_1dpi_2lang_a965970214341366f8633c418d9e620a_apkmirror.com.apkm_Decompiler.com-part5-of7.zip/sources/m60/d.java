package m60;

import d50.o;
import hs.q;
import java.util.Collection;
import q40.m0;
import q40.s;
import q40.x;
import t40.k0;
import t40.t;

/* JADX INFO: loaded from: classes3.dex */
public final class d extends k0 {
    @Override // t40.t
    /* JADX INFO: renamed from: K2 */
    public final k0 l2(q40.k newOwner, x xVar, o visibility) {
        kotlin.jvm.internal.k.g(newOwner, "newOwner");
        kotlin.jvm.internal.k.g(visibility, "visibility");
        q.q(2, "kind");
        return this;
    }

    @Override // t40.k0, t40.t
    public final t L2(int i11, q40.k newOwner, q40.t tVar, m0 m0Var, r40.h annotations, t50.e eVar) {
        kotlin.jvm.internal.k.g(newOwner, "newOwner");
        q.q(i11, "kind");
        kotlin.jvm.internal.k.g(annotations, "annotations");
        return this;
    }

    @Override // t40.t, q40.c
    public final void Q1(Collection overriddenDescriptors) {
        kotlin.jvm.internal.k.g(overriddenDescriptors, "overriddenDescriptors");
    }

    @Override // t40.k0, t40.t, q40.t
    public final s b2() {
        return new c(0, this);
    }

    @Override // t40.t, q40.t
    public final boolean isSuspend() {
        return false;
    }

    @Override // t40.t, q40.c
    public final /* bridge */ /* synthetic */ q40.c l2(q40.e eVar, x xVar, o oVar) {
        l2(eVar, xVar, oVar);
        return this;
    }

    @Override // t40.t, q40.b
    public final Object z1(q40.a aVar) {
        return null;
    }
}
