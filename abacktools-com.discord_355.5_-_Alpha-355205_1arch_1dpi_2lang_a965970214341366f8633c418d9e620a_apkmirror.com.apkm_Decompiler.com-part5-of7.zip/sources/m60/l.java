package m60;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v74 m60.l[], still in use, count: 1, list:
  (r0v74 m60.l[]) from 0x04f2: INVOKE (r0v74 m60.l[]) STATIC call: oq.a.G(java.lang.Enum[]):t30.a A[MD:(java.lang.Enum[]):t30.a (m)] (LINE:1267)
	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:164)
	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:129)
	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:101)
	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:100)
	at jadx.core.utils.InsnRemover.removeAllAndUnbind(InsnRemover.java:257)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:187)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: loaded from: classes3.dex */
public final class l {
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(0, true),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(1, true),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(2, true),
    UNRESOLVED_JAVA_CLASS(3, true),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_DECLARATION(4, true),
    UNRESOLVED_KCLASS_CONSTANT_VALUE(5, true),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_TYPE_ALIAS(6, false),
    /* JADX INFO: Fake field, exist only in values array */
    RETURN_TYPE(7, false),
    RETURN_TYPE_FOR_FUNCTION(8, false),
    /* JADX INFO: Fake field, exist only in values array */
    RETURN_TYPE_FOR_PROPERTY(9, false),
    /* JADX INFO: Fake field, exist only in values array */
    RETURN_TYPE_FOR_CONSTRUCTOR(10, false),
    /* JADX INFO: Fake field, exist only in values array */
    IMPLICIT_RETURN_TYPE_FOR_FUNCTION(11, false),
    /* JADX INFO: Fake field, exist only in values array */
    IMPLICIT_RETURN_TYPE_FOR_PROPERTY(12, false),
    /* JADX INFO: Fake field, exist only in values array */
    IMPLICIT_RETURN_TYPE_FOR_PROPERTY_ACCESSOR(13, false),
    /* JADX INFO: Fake field, exist only in values array */
    ERROR_TYPE_FOR_DESTRUCTURING_COMPONENT(14, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(15, false),
    RECURSIVE_TYPE_ALIAS(16, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(17, false),
    CYCLIC_UPPER_BOUNDS(18, false),
    CYCLIC_SUPERTYPES(19, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(20, false),
    UNINFERRED_LAMBDA_PARAMETER_TYPE(21, false),
    UNINFERRED_TYPE_VARIABLE(22, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(23, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(24, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(25, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(26, false),
    UNABLE_TO_SUBSTITUTE_TYPE(27, false),
    DONT_CARE(28, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(29, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(30, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(31, false),
    ERROR_FLEXIBLE_TYPE(32, false),
    ERROR_RAW_TYPE(33, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(34, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(35, false),
    CANNOT_LOAD_DESERIALIZE_TYPE_PARAMETER(36, false),
    CANNOT_LOAD_DESERIALIZE_TYPE_PARAMETER_BY_NAME(37, false),
    INCONSISTENT_SUSPEND_FUNCTION(38, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(39, false),
    UNKNOWN_TYPE(40, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(41, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(42, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(43, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(44, false),
    MISSED_TYPE_ARGUMENT_FOR_TYPE_PARAMETER(45, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(46, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(47, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(48, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(49, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(50, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(51, false),
    /* JADX INFO: Fake field, exist only in values array */
    UNRESOLVED_PARCEL_TYPE(52, true),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(53, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(54, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(55, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(56, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(57, false),
    ERROR_CONSTANT_VALUE(58, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(59, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(60, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(61, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(62, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(63, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(64, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(65, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(66, false),
    ERROR_PROPERTY_TYPE(67, false),
    ERROR_CLASS(68, false),
    TYPE_FOR_ERROR_TYPE_CONSTRUCTOR(69, false),
    INTERSECTION_OF_ERROR_TYPES(70, false),
    CANNOT_COMPUTE_ERASED_BOUND(71, false),
    NOT_FOUND_UNSIGNED_TYPE(72, false),
    ERROR_ENUM_TYPE(73, false),
    NO_RECORDED_TYPE(74, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(75, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_CLASS(76, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_DESCRIPTOR_FOR_TYPE_PARAMETER(77, false),
    UNMAPPED_ANNOTATION_TARGET_TYPE(78, false),
    UNKNOWN_ARRAY_ELEMENT_TYPE_OF_ANNOTATION_ARGUMENT(79, false),
    NOT_FOUND_FQNAME_FOR_JAVA_ANNOTATION(80, false),
    /* JADX INFO: Fake field, exist only in values array */
    NOT_FOUND_FQNAME(81, false),
    /* JADX INFO: Fake field, exist only in values array */
    TYPE_FOR_GENERATED_ERROR_EXPRESSION(82, false);


    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f21238d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f21239e;

    static {
        oq.a.G(lVarArr);
    }

    public l(int i11, boolean z11) {
        super(str, i11);
        this.f21238d = str;
        this.f21239e = z11;
    }

    public static l valueOf(String str) {
        return (l) Enum.valueOf(l.class, str);
    }

    public static l[] values() {
        return (l[]) f21233h0.clone();
    }
}
