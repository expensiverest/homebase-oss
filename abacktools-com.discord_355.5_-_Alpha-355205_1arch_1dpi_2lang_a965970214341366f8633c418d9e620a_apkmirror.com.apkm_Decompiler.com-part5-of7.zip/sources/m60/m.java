package m60;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import k60.l0;
import m30.s;

/* JADX INFO: loaded from: classes3.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m f21240a = new m();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final f f21241b = f.f21206d;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a f21242c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final j f21243d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final j f21244e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Set f21245f;

    static {
        b[] bVarArr = b.f21202d;
        f21242c = new a(t50.e.g(String.format("<Error class: %s>", Arrays.copyOf(new Object[]{"unknown class"}, 1))));
        f21243d = c(l.CYCLIC_SUPERTYPES, new String[0]);
        f21244e = c(l.ERROR_PROPERTY_TYPE, new String[0]);
        f21245f = su.e.J(new g());
    }

    public static final h a(i iVar, boolean z11, String... formatParams) {
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        if (!z11) {
            return new h(iVar, (String[]) Arrays.copyOf(formatParams, formatParams.length));
        }
        String[] formatParams2 = (String[]) Arrays.copyOf(formatParams, formatParams.length);
        kotlin.jvm.internal.k.g(formatParams2, "formatParams");
        return new n(iVar, (String[]) Arrays.copyOf(formatParams2, formatParams2.length));
    }

    public static final h b(i iVar, String... strArr) {
        return a(iVar, false, (String[]) Arrays.copyOf(strArr, strArr.length));
    }

    public static final j c(l kind, String... strArr) {
        kotlin.jvm.internal.k.g(kind, "kind");
        String[] formatParams = (String[]) Arrays.copyOf(strArr, strArr.length);
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        return e(kind, s.f20879d, d(kind, (String[]) Arrays.copyOf(formatParams, formatParams.length)), (String[]) Arrays.copyOf(formatParams, formatParams.length));
    }

    public static k d(l kind, String... formatParams) {
        kotlin.jvm.internal.k.g(kind, "kind");
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        return new k(kind, (String[]) Arrays.copyOf(formatParams, formatParams.length));
    }

    public static j e(l kind, List list, l0 l0Var, String... formatParams) {
        kotlin.jvm.internal.k.g(kind, "kind");
        kotlin.jvm.internal.k.g(formatParams, "formatParams");
        return new j(l0Var, b(i.ERROR_TYPE_SCOPE, l0Var.toString()), kind, list, false, (String[]) Arrays.copyOf(formatParams, formatParams.length));
    }

    public static final boolean f(q40.k kVar) {
        if (kVar != null) {
            return (kVar instanceof a) || (kVar.A() instanceof a) || kVar == f21241b;
        }
        return false;
    }
}
