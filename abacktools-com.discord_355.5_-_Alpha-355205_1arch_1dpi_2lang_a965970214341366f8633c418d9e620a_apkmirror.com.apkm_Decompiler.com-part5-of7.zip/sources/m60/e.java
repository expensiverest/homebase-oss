package m60;

import kotlin.jvm.functions.Function0;

/* JADX INFO: loaded from: classes3.dex */
public final class e implements Function0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final e f21205d = new e();

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        f fVar = f.f21206d;
        return (n40.e) n40.e.f22520f.getValue();
    }
}
