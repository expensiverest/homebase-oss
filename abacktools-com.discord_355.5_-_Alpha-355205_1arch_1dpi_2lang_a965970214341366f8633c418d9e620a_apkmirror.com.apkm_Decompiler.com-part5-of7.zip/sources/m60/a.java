package m60;

import java.util.List;
import k60.r0;
import k60.t0;
import m30.s;
import q40.m0;
import q40.o;
import q40.x;

/* JADX INFO: loaded from: classes3.dex */
public final class a extends t40.k {
    /* JADX WARN: Illegal instructions before constructor call */
    public a(t50.e eVar) {
        m mVar = m.f21240a;
        f fVar = m.f21241b;
        x xVar = x.f26583v;
        q40.f fVar2 = q40.f.f26537d;
        j60.b bVar = j60.l.f17956e;
        List list = s.f20879d;
        super(fVar, eVar, xVar, fVar2, list, bVar);
        t40.i iVar = new t40.i(this, null, r40.g.f27594a, true, 1, m0.f26549u);
        iVar.X2(list, o.f26557e);
        i iVar2 = i.SCOPE_FOR_ERROR_CLASS;
        String str = iVar.getName().f29793d;
        kotlin.jvm.internal.k.f(str, "toString(...)");
        h hVarB = m.b(iVar2, str, "");
        l lVar = l.ERROR_CLASS;
        iVar.J = new j(m.d(lVar, new String[0]), hVarB, lVar, list, false, new String[0]);
        l(hVarB, su.e.J(iVar), iVar);
    }

    @Override // t40.b, t40.y
    public final d60.o b(r0 r0Var, l60.f fVar) {
        i iVar = i.SCOPE_FOR_ERROR_CLASS;
        String str = getName().f29793d;
        kotlin.jvm.internal.k.f(str, "toString(...)");
        return m.b(iVar, str, r0Var.toString());
    }

    @Override // t40.b, q40.o0
    public final q40.l f(t0 substitutor) {
        kotlin.jvm.internal.k.g(substitutor, "substitutor");
        return this;
    }

    @Override // t40.b
    /* JADX INFO: renamed from: i */
    public final q40.e f(t0 substitutor) {
        kotlin.jvm.internal.k.g(substitutor, "substitutor");
        return this;
    }

    @Override // t40.k
    public final String toString() {
        String strB = getName().b();
        kotlin.jvm.internal.k.f(strB, "asString(...)");
        return strB;
    }
}
