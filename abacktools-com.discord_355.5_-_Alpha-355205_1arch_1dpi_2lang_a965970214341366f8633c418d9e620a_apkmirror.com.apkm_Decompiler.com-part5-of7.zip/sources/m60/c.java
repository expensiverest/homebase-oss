package m60;

import android.graphics.Rect;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.util.SparseArray;
import android.view.MenuItem;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import b3.n0;
import com.discord.age_assurance.DigitalCredentialModule;
import com.facebook.fresco.animation.factory.AnimatedFactoryV2Impl;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import e1.v0;
import fb.c0;
import hs.q;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.io.EOFException;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.zip.GZIPInputStream;
import k3.t0;
import k60.w;
import k7.p;
import mr.k0;
import mx.e0;
import n3.x;
import o4.o;
import or.i0;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;
import ot.f0;
import ot.g0;
import ot.j0;
import p.x2;
import q40.s;
import q40.t;
import vw.b1;
import z5.u;

/* JADX INFO: loaded from: classes3.dex */
public final class c implements s, m50.l, vm.b, mz.e, o.i, f0, oz.c, b80.j, u80.b, ww.h, x6.l, y1.i {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21203d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f21204e;

    public /* synthetic */ c(int i11, Object obj) {
        this.f21203d = i11;
        this.f21204e = obj;
    }

    @Override // vm.b
    public vm.a B(ld.d dVar, Rect rect) {
        AnimatedFactoryV2Impl animatedFactoryV2Impl = (AnimatedFactoryV2Impl) this.f21204e;
        if (animatedFactoryV2Impl.f5672g == null) {
            animatedFactoryV2Impl.f5672g = new zm.f(26);
        }
        return new vm.a(animatedFactoryV2Impl.f5672g, dVar, rect, animatedFactoryV2Impl.f5669d);
    }

    @Override // m50.l
    public m50.l C(t50.b bVar, t50.e eVar) {
        return null;
    }

    public nw.d E(nw.d dVar) {
        return dVar instanceof nw.j ? dVar : new nw.b(-((nw.i) this.f21204e).e(), dVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void F(FrameLayout frameLayout) {
        z10.b bVar;
        z10.b bVar2;
        z10.a aVar = (z10.a) frameLayout;
        ViewParent parent = frameLayout.getParent();
        while (true) {
            bVar = null;
            if (parent == null) {
                bVar2 = null;
                break;
            } else {
                if (parent instanceof z10.b) {
                    bVar2 = (z10.b) parent;
                    break;
                }
                parent = parent.getParent();
            }
        }
        if (bVar2 != null) {
            bVar2.c(aVar);
            bVar = bVar2;
        }
        this.f21204e = bVar;
    }

    @Override // o.i
    public void G(o.k kVar) {
        Toolbar toolbar = (Toolbar) this.f21204e;
        p.j jVar = toolbar.f1365d.V;
        if (jVar == null || !jVar.i()) {
            Iterator it = ((CopyOnWriteArrayList) toolbar.f1376l0.f19346i).iterator();
            while (it.hasNext()) {
                ((n0) it.next()).f2704a.t(kVar);
            }
        }
        bu.i iVar = toolbar.t0;
        if (iVar != null) {
            iVar.G(kVar);
        }
    }

    public void I(int i11, int[] iArr) {
        int[] iArr2;
        int[] iArr3;
        k7.e eVar;
        k7.e eVar2;
        k7.e eVar3;
        int iB;
        int i12;
        int i13 = i11;
        ty.a aVar = (ty.a) this.f21204e;
        if (iArr.length == 0) {
            throw new IllegalArgumentException();
        }
        int length = iArr.length;
        int i14 = 0;
        int i15 = 1;
        if (length <= 1 || iArr[0] != 0) {
            iArr2 = iArr;
        } else {
            int i16 = 1;
            while (i16 < length && iArr[i16] == 0) {
                i16++;
            }
            if (i16 == length) {
                iArr2 = new int[]{0};
            } else {
                int i17 = length - i16;
                int[] iArr4 = new int[i17];
                System.arraycopy(iArr, i16, iArr4, 0, i17);
                iArr2 = iArr4;
            }
        }
        int[] iArr5 = new int[i13];
        boolean z11 = true;
        for (int i18 = 0; i18 < i13; i18++) {
            int i19 = aVar.f30668a[aVar.f30674g + i18];
            if (i19 == 0) {
                i12 = iArr2[iArr2.length - 1];
            } else {
                if (i19 == 1) {
                    iB = 0;
                    for (int i21 : iArr2) {
                        ty.a aVar2 = ty.a.f30662h;
                        iB ^= i21;
                    }
                } else {
                    iB = iArr2[0];
                    int length2 = iArr2.length;
                    for (int i22 = 1; i22 < length2; i22++) {
                        iB = aVar.b(i19, iB) ^ iArr2[i22];
                    }
                }
                i12 = iB;
            }
            iArr5[(i13 - 1) - i18] = i12;
            if (i12 != 0) {
                z11 = false;
            }
        }
        if (z11) {
            return;
        }
        k7.e eVar4 = new k7.e(aVar, iArr5);
        aVar.getClass();
        k7.e eVar5 = aVar.f30670c;
        if (i13 < 0) {
            throw new IllegalArgumentException();
        }
        int[] iArr6 = new int[i13 + 1];
        iArr6[0] = 1;
        k7.e eVar6 = new k7.e(aVar, iArr6);
        if (eVar6.l() >= eVar4.l()) {
            eVar6 = eVar4;
            eVar4 = eVar6;
        }
        k7.e eVarA = eVar4;
        k7.e eVar7 = eVar6;
        k7.e eVar8 = aVar.f30671d;
        k7.e eVar9 = eVar5;
        while (eVar7.l() >= i13 / 2) {
            if (eVar7.p()) {
                throw new ty.b("r_{i-1} was zero");
            }
            int iA = aVar.a(eVar7.k(eVar7.l()));
            k7.e eVarA2 = eVar5;
            while (eVarA.l() >= eVar7.l() && !eVarA.p()) {
                int iL = eVarA.l() - eVar7.l();
                int iB2 = aVar.b(eVarA.k(eVarA.l()), iA);
                if (iL < 0) {
                    throw new IllegalArgumentException();
                }
                if (iB2 == 0) {
                    eVar2 = eVar5;
                } else {
                    int[] iArr7 = new int[iL + 1];
                    iArr7[i14] = iB2;
                    eVar2 = new k7.e(aVar, iArr7);
                }
                eVarA2 = eVarA2.a(eVar2);
                int[] iArr8 = (int[]) eVar7.f19327i;
                ty.a aVar3 = (ty.a) eVar7.f19326e;
                if (iL < 0) {
                    throw new IllegalArgumentException();
                }
                if (iB2 == 0) {
                    eVar3 = aVar3.f30670c;
                } else {
                    int length3 = iArr8.length;
                    int[] iArr9 = new int[iL + length3];
                    int i23 = 0;
                    while (i23 < length3) {
                        int i24 = i23;
                        iArr9[i24] = aVar3.b(iArr8[i24], iB2);
                        i23 = i24 + 1;
                    }
                    eVar3 = new k7.e(aVar3, iArr9);
                }
                eVarA = eVarA.a(eVar3);
                i15 = i15;
                i14 = 0;
            }
            int i25 = i15;
            ty.a aVar4 = (ty.a) eVarA2.f19326e;
            if (!aVar4.equals((ty.a) eVar8.f19326e)) {
                throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
            }
            if (eVarA2.p() || eVar8.p()) {
                eVar = aVar4.f30670c;
            } else {
                int[] iArr10 = (int[]) eVarA2.f19327i;
                int length4 = iArr10.length;
                int[] iArr11 = (int[]) eVar8.f19327i;
                int length5 = iArr11.length;
                int[] iArr12 = new int[(length4 + length5) - 1];
                for (int i26 = 0; i26 < length4; i26++) {
                    int i27 = iArr10[i26];
                    int i28 = 0;
                    while (i28 < length5) {
                        int i29 = i26 + i28;
                        int i31 = i28;
                        iArr12[i29] = iArr12[i29] ^ aVar4.b(i27, iArr11[i31]);
                        i28 = i31 + 1;
                    }
                }
                eVar = new k7.e(aVar4, iArr12);
            }
            k7.e eVarA3 = eVar.a(eVar9);
            if (eVarA.l() >= eVar7.l()) {
                throw new IllegalStateException("Division algorithm failed to reduce polynomial?");
            }
            k7.e eVar10 = eVarA;
            eVarA = eVar7;
            eVar7 = eVar10;
            eVar9 = eVar8;
            i15 = i25;
            i14 = 0;
            eVar8 = eVarA3;
            i13 = i11;
        }
        int i32 = i14;
        int i33 = i15;
        int iK = eVar8.k(i32);
        if (iK == 0) {
            throw new ty.b("sigmaTilde(0) was zero");
        }
        int iA2 = aVar.a(iK);
        k7.e[] eVarArr = {eVar8.r(iA2), eVar7.r(iA2)};
        k7.e eVar11 = eVarArr[i32];
        k7.e eVar12 = eVarArr[i33];
        int iL2 = eVar11.l();
        if (iL2 == i33) {
            iArr3 = new int[]{eVar11.k(i33)};
        } else {
            int[] iArr13 = new int[iL2];
            int i34 = i32;
            for (int i35 = 1; i35 < aVar.f30672e && i34 < iL2; i35++) {
                if (eVar11.i(i35) == 0) {
                    iArr13[i34] = aVar.a(i35);
                    i34++;
                }
            }
            if (i34 != iL2) {
                throw new ty.b("Error locator degree does not match number of roots");
            }
            iArr3 = iArr13;
        }
        int length6 = iArr3.length;
        int[] iArr14 = new int[length6];
        for (int i36 = i32; i36 < length6; i36++) {
            int iA3 = aVar.a(iArr3[i36]);
            int iB3 = 1;
            for (int i37 = i32; i37 < length6; i37++) {
                if (i36 != i37) {
                    int iB4 = aVar.b(iArr3[i37], iA3);
                    iB3 = aVar.b(iB3, (iB4 & 1) == 0 ? iB4 | 1 : iB4 & (-2));
                }
            }
            int iB5 = aVar.b(eVar12.i(iA3), aVar.a(iB3));
            iArr14[i36] = iB5;
            if (aVar.f30674g != 0) {
                iArr14[i36] = aVar.b(iB5, iA3);
            }
        }
        for (int i38 = i32; i38 < iArr3.length; i38++) {
            int length7 = iArr.length - 1;
            int i39 = iArr3[i38];
            if (i39 == 0) {
                throw new IllegalArgumentException();
            }
            int i40 = length7 - aVar.f30669b[i39];
            if (i40 < 0) {
                throw new ty.b("Bad error location");
            }
            iArr[i40] = iArr[i40] ^ iArr14[i38];
        }
    }

    @Override // ot.f0
    public gs.f J(g0 g0Var, long j6, long j11, IOException iOException, int i11) {
        vs.f fVar = (vs.f) ((c) this.f21204e).f21204e;
        qt.a.s("DashMediaSource", "Failed to resolve time offset.", iOException);
        fVar.x(true);
        return j0.f25063w;
    }

    public void K(Exception exc) {
        qt.a.s("MediaCodecAudioRenderer", "Audio sink error", exc);
        u uVar = ((i0) this.f21204e).f24835i1;
        Handler handler = (Handler) uVar.f37364d;
        if (handler != null) {
            handler.post(new or.n(uVar, exc, 7));
        }
    }

    public void L() {
        long j6;
        vs.f fVar = (vs.f) this.f21204e;
        synchronized (qt.a.f27249i) {
            try {
                j6 = qt.a.f27250j ? qt.a.k : -9223372036854775807L;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        fVar.f32952o0 = j6;
        fVar.x(true);
    }

    public void M() {
        String str;
        v0 v0Var = (v0) ((k0) this.f21204e).f21633d;
        int i11 = ((c0) v0Var.f9815i).e() ? 2 : 1;
        if (v0.d.a(i11, v0Var.f9814e)) {
            return;
        }
        v0Var.f9814e = i11;
        String str2 = (String) ((pz.a) ((p) v0Var.f9816v).N).f26312a;
        WritableMap writableMapCreateMap = Arguments.createMap();
        if (i11 == 1) {
            str = "idle";
        } else {
            if (i11 != 2) {
                throw null;
            }
            str = "spinning";
        }
        writableMapCreateMap.putString("spinnerState", str);
        writableMapCreateMap.putString("id", str2);
        ((DeviceEventManagerModule.RCTDeviceEventEmitter) com.mkuczera.haptic.c.f8414b.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("spinnerStateChange", writableMapCreateMap);
        Iterator it = ((HashSet) v0Var.f9818x).iterator();
        while (it.hasNext()) {
            ((lz.e) it.next()).f20708a.f20709a.getButton(-1).setEnabled(i11 == 1);
        }
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00b5 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:33:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:47:0x00e1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:51:? A[LOOP:1: B:4:0x0008->B:51:?, LOOP_END, SYNTHETIC] */
    public t0 N(o oVar, c5.g gVar, int i11) {
        int i12;
        x xVar = (x) this.f21204e;
        t0 t0VarA0 = null;
        int i13 = 0;
        while (true) {
            int i14 = 0;
            while (true) {
                i12 = i14 % 10;
                int i15 = i12 + 10;
                if (i12 == 0 && i14 != 0) {
                    byte[] bArr = xVar.f22410a;
                    System.arraycopy(bArr, 10, bArr, 0, 9);
                }
                int i16 = i14 == 0 ? 10 : 1;
                try {
                    oVar.q(xVar.f22410a, i15 - i16, i16);
                    xVar.N(i12);
                    xVar.M(i15);
                    if (xVar.a() < 3) {
                        throw new IndexOutOfBoundsException("position=" + xVar.f22411b + ", limit=" + xVar.f22412c);
                    }
                    int iD = xVar.D();
                    xVar.f22411b -= 3;
                    if (iD == 4801587) {
                        xVar.O(3);
                        int iA = xVar.A();
                        if (iA < 2 || iA > 4) {
                            if (i14 == 0) {
                                xVar.c(20);
                            }
                            i14++;
                            if (i14 > i11) {
                            }
                        }
                    } else if (o4.a.h(xVar.i()) == -1) {
                        if (i14 == 0) {
                            xVar.c(20);
                        }
                        i14++;
                        if (i14 > i11) {
                        }
                    }
                    oVar.m();
                    oVar.h(i13);
                    return t0VarA0;
                } catch (EOFException unused) {
                }
            }
            xVar.N(i12);
            int i17 = xVar.f22411b;
            xVar.O(6);
            int iZ = xVar.z();
            int i18 = iZ + 10;
            if (oVar.getLength() != -1 && oVar.g() + ((long) iZ) > oVar.getLength()) {
                StringBuilder sbL = x2.l(i18, "Skipping ID3 tag with tagLength=", " greater than input length=");
                sbL.append(oVar.getLength());
                n3.b.l("Id3Peeker", sbL.toString());
                oVar.m();
                oVar.h(i13);
                return t0VarA0;
            }
            if (t0VarA0 == null) {
                byte[] bArr2 = new byte[i18];
                System.arraycopy(xVar.f22410a, i17, bArr2, 0, 10);
                oVar.q(bArr2, 10, iZ);
                t0VarA0 = new c5.i(gVar).A0(bArr2, i18);
            } else {
                oVar.h(iZ);
            }
            i13 += i18;
        }
    }

    public void O() {
        p70.j jVar = (p70.j) this.f21204e;
        jVar.getClass();
        p70.e eVar = p70.e.f25910c;
        byte[] bArrArray = jVar.f25930c.array();
        kotlin.jvm.internal.k.f(bArrArray, "array(...)");
        eVar.getClass();
        synchronized (eVar) {
            int i11 = eVar.f25913b;
            if (bArrArray.length + i11 < p70.d.f25908a) {
                eVar.f25913b = i11 + (bArrArray.length / 2);
                eVar.f25912a.addLast(bArrArray);
            }
        }
    }

    @Override // q40.s
    public s a(t50.e name) {
        kotlin.jvm.internal.k.g(name, "name");
        return this;
    }

    @Override // ww.h, fx.p
    public Object b() {
        switch (this.f21203d) {
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                return new b1((vw.u) ((ww.g) this.f21204e).b());
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                return ((fx.o) this.f21204e).f12548d;
            default:
                return new ww.c(((fx.o) ((c) this.f21204e).f21204e).f12548d);
        }
    }

    @Override // q40.s
    public t build() {
        return (d) this.f21204e;
    }

    @Override // q40.s
    public s f(w type) {
        kotlin.jvm.internal.k.g(type, "type");
        return this;
    }

    @Override // q40.s
    public s g(r40.h additionalAnnotations) {
        kotlin.jvm.internal.k.g(additionalAnnotations, "additionalAnnotations");
        return this;
    }

    @Override // x6.l
    public StaticsBoundaryInterface getStatics() {
        return (StaticsBoundaryInterface) z80.a.e(StaticsBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f21204e).getStatics());
    }

    @Override // x6.l
    public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
        return (WebkitToCompatConverterBoundaryInterface) z80.a.e(WebkitToCompatConverterBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f21204e).getWebkitToCompatConverter());
    }

    @Override // q40.s
    public s h(int i11) {
        q.q(i11, "kind");
        return this;
    }

    @Override // q40.s
    public s j(d50.o visibility) {
        kotlin.jvm.internal.k.g(visibility, "visibility");
        return this;
    }

    @Override // o.i
    public boolean l(o.k kVar, MenuItem menuItem) {
        return false;
    }

    @Override // u80.b
    public FileChannel m() throws IOException {
        ParcelFileDescriptor parcelFileDescriptor = (ParcelFileDescriptor) this.f21204e;
        if (parcelFileDescriptor.getStatSize() != -1) {
            return new ParcelFileDescriptor.AutoCloseInputStream(parcelFileDescriptor).getChannel();
        }
        parcelFileDescriptor.close();
        throw new IllegalArgumentException("Not a file: ".concat(String.valueOf(parcelFileDescriptor)));
    }

    @Override // b80.j
    public void onFailure(b80.i iVar, IOException iOException) {
        ((e0) this.f21204e).n(iOException);
    }

    @Override // b80.j
    public void onResponse(b80.i iVar, b80.n0 n0Var) {
        ((e0) this.f21204e).m(n0Var);
    }

    @Override // y1.i
    public void onResult(Object obj) {
        y1.p result = (y1.p) obj;
        kotlin.jvm.internal.k.g(result, "result");
        z60.k kVar = (z60.k) this.f21204e;
        if (kVar.w()) {
            kVar.resumeWith(result);
        }
    }

    @Override // x6.l
    public WebViewProviderBoundaryInterface p(com.reactnativecommunity.webview.i iVar) {
        return (WebViewProviderBoundaryInterface) z80.a.e(WebViewProviderBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f21204e).createWebView(iVar));
    }

    @Override // q40.s
    public s r(q40.k owner) {
        kotlin.jvm.internal.k.g(owner, "owner");
        return this;
    }

    @Override // ot.f0
    public void s(g0 g0Var, long j6, long j11) {
        boolean z11;
        c cVar = (c) this.f21204e;
        synchronized (qt.a.f27249i) {
            z11 = qt.a.f27250j;
        }
        if (z11) {
            cVar.L();
            return;
        }
        IOException iOException = new IOException(new ConcurrentModificationException());
        vs.f fVar = (vs.f) cVar.f21204e;
        qt.a.s("DashMediaSource", "Failed to resolve time offset.", iOException);
        fVar.x(true);
    }

    @Override // m50.l
    public m50.m t(t50.e eVar) {
        if ("b".equals(eVar.b())) {
            return new n50.c(this, 2);
        }
        return null;
    }

    @Override // y1.i
    public void u(Object obj) {
        z1.l e4 = (z1.l) obj;
        kotlin.jvm.internal.k.g(e4, "e");
        z60.k kVar = (z60.k) this.f21204e;
        if (kVar.w()) {
            kVar.resumeWith(android.support.v4.media.session.b.q(e4));
        }
    }

    @Override // x6.l
    public String[] x() {
        return ((WebViewProviderFactoryBoundaryInterface) this.f21204e).getSupportedFeatures();
    }

    public c(k0 k0Var, sz.e eVar) {
        this.f21203d = 11;
        this.f21204e = k0Var;
    }

    public c(int i11) {
        this.f21203d = i11;
        switch (i11) {
            case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                this.f21204e = new LinkedHashMap(0, 0.75f, true);
                break;
            case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                this.f21204e = new a4.w(5, 1.0f, false, 2);
                break;
            case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                break;
            case 29:
                this.f21204e = new SparseArray();
                break;
            default:
                this.f21204e = new x(10);
                break;
        }
    }

    public c(TextView textView) {
        this.f21203d = 26;
        this.f21204e = new y2.g(textView);
    }

    public c(GZIPInputStream gZIPInputStream) {
        this.f21203d = 9;
        this.f21204e = new p70.j(gZIPInputStream, w60.a.f33595a);
    }

    @Override // q40.s
    public s A() {
        return this;
    }

    @Override // q40.s
    public s D() {
        return this;
    }

    @Override // q40.s
    public s i() {
        return this;
    }

    @Override // m50.l
    public void k() {
    }

    @Override // q40.s
    public s n() {
        return this;
    }

    @Override // q40.s
    public s o() {
        return this;
    }

    @Override // q40.s
    public s w() {
        return this;
    }

    @Override // q40.s
    public s y() {
        return this;
    }

    @Override // q40.s
    public s c(q40.x xVar) {
        return this;
    }

    @Override // q40.s
    public s d(t40.u uVar) {
        return this;
    }

    @Override // q40.s
    public s e(List list) {
        return this;
    }

    @Override // m50.l
    public void H(t50.e eVar, y50.f fVar) {
    }

    @Override // m50.l
    public void q(t50.e eVar, Object obj) {
    }

    @Override // m50.l
    public void z(t50.e eVar, t50.b bVar, t50.e eVar2) {
    }

    @Override // ot.f0
    public void v(g0 g0Var, long j6, long j11, boolean z11) {
    }
}
