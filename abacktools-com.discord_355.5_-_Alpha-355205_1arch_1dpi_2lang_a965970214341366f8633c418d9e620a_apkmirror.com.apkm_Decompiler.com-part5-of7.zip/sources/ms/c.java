package ms;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import mr.w0;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class c implements is.b {
    public static final Parcelable.Creator<c> CREATOR = new fh.a(20);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final byte[] f21891d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21892e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f21893i;

    public c(byte[] bArr, String str, String str2) {
        this.f21891d = bArr;
        this.f21892e = str;
        this.f21893i = str2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.f21891d, ((c) obj).f21891d);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f21891d);
    }

    public final String toString() {
        return x2.f(this.f21891d.length, "\"", x2.n("ICY: title=\"", this.f21892e, "\", url=\"", this.f21893i, "\", rawMetadata.length=\""));
    }

    @Override // is.b
    public final void w(w0 w0Var) {
        String str = this.f21892e;
        if (str != null) {
            w0Var.f21754a = str;
        }
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        parcel.writeByteArray(this.f21891d);
        parcel.writeString(this.f21892e);
        parcel.writeString(this.f21893i);
    }

    public c(Parcel parcel) {
        byte[] bArrCreateByteArray = parcel.createByteArray();
        bArrCreateByteArray.getClass();
        this.f21891d = bArrCreateByteArray;
        this.f21892e = parcel.readString();
        this.f21893i = parcel.readString();
    }
}
