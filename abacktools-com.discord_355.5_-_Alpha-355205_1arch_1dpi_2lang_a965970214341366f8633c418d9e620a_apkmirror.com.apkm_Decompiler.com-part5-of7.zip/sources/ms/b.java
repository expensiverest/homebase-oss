package ms;

import android.os.Parcel;
import android.os.Parcelable;
import com.reactnativecommunity.webview.RNCWebViewManager;
import hs.q;
import java.util.List;
import java.util.Map;
import mr.w0;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public final class b implements is.b {
    public static final Parcelable.Creator<b> CREATOR = new fh.a(19);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21885d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21886e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f21887i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final String f21888v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f21889w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f21890x;

    public b(int i11, int i12, String str, String str2, String str3, boolean z11) {
        qt.a.g(i12 == -1 || i12 > 0);
        this.f21885d = i11;
        this.f21886e = str;
        this.f21887i = str2;
        this.f21888v = str3;
        this.f21889w = z11;
        this.f21890x = i12;
    }

    public static b b(Map map) {
        boolean z11;
        int i11;
        String str;
        String str2;
        String str3;
        boolean zEquals;
        int i12;
        List list = (List) map.get("icy-br");
        boolean z12 = true;
        int i13 = -1;
        if (list != null) {
            String str4 = (String) list.get(0);
            try {
                i12 = Integer.parseInt(str4) * RNCWebViewManager.COMMAND_CLEAR_FORM_DATA;
                if (i12 > 0) {
                    z11 = true;
                } else {
                    try {
                        qt.a.N("IcyHeaders", "Invalid bitrate: " + str4);
                        z11 = false;
                        i12 = -1;
                    } catch (NumberFormatException unused) {
                        q.u("Invalid bitrate header: ", str4, "IcyHeaders");
                        z11 = false;
                    }
                }
            } catch (NumberFormatException unused2) {
                i12 = -1;
            }
            i11 = i12;
        } else {
            z11 = false;
            i11 = -1;
        }
        List list2 = (List) map.get("icy-genre");
        if (list2 != null) {
            str = (String) list2.get(0);
            z11 = true;
        } else {
            str = null;
        }
        List list3 = (List) map.get("icy-name");
        if (list3 != null) {
            str2 = (String) list3.get(0);
            z11 = true;
        } else {
            str2 = null;
        }
        List list4 = (List) map.get("icy-url");
        if (list4 != null) {
            str3 = (String) list4.get(0);
            z11 = true;
        } else {
            str3 = null;
        }
        List list5 = (List) map.get("icy-pub");
        if (list5 != null) {
            zEquals = ((String) list5.get(0)).equals("1");
            z11 = true;
        } else {
            zEquals = false;
        }
        List list6 = (List) map.get("icy-metaint");
        if (list6 != null) {
            String str5 = (String) list6.get(0);
            try {
                int i14 = Integer.parseInt(str5);
                if (i14 > 0) {
                    i13 = i14;
                } else {
                    try {
                        qt.a.N("IcyHeaders", "Invalid metadata interval: " + str5);
                        z12 = z11;
                    } catch (NumberFormatException unused3) {
                        i13 = i14;
                        q.u("Invalid metadata interval: ", str5, "IcyHeaders");
                    }
                }
                z11 = z12;
            } catch (NumberFormatException unused4) {
            }
        }
        int i15 = i13;
        if (z11) {
            return new b(i11, i15, str, str2, str3, zEquals);
        }
        return null;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && b.class == obj.getClass()) {
            b bVar = (b) obj;
            if (this.f21885d == bVar.f21885d && x.a(this.f21886e, bVar.f21886e) && x.a(this.f21887i, bVar.f21887i) && x.a(this.f21888v, bVar.f21888v) && this.f21889w == bVar.f21889w && this.f21890x == bVar.f21890x) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i11 = (527 + this.f21885d) * 31;
        String str = this.f21886e;
        int iHashCode = (i11 + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f21887i;
        int iHashCode2 = (iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.f21888v;
        return ((((iHashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31) + (this.f21889w ? 1 : 0)) * 31) + this.f21890x;
    }

    public final String toString() {
        return "IcyHeaders: name=\"" + this.f21887i + "\", genre=\"" + this.f21886e + "\", bitrate=" + this.f21885d + ", metadataInterval=" + this.f21890x;
    }

    @Override // is.b
    public final void w(w0 w0Var) {
        String str = this.f21887i;
        if (str != null) {
            w0Var.E = str;
        }
        String str2 = this.f21886e;
        if (str2 != null) {
            w0Var.C = str2;
        }
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        parcel.writeInt(this.f21885d);
        parcel.writeString(this.f21886e);
        parcel.writeString(this.f21887i);
        parcel.writeString(this.f21888v);
        int i12 = x.f27318a;
        parcel.writeInt(this.f21889w ? 1 : 0);
        parcel.writeInt(this.f21890x);
    }

    public b(Parcel parcel) {
        this.f21885d = parcel.readInt();
        this.f21886e = parcel.readString();
        this.f21887i = parcel.readString();
        this.f21888v = parcel.readString();
        int i11 = x.f27318a;
        this.f21889w = parcel.readInt() != 0;
        this.f21890x = parcel.readInt();
    }
}
