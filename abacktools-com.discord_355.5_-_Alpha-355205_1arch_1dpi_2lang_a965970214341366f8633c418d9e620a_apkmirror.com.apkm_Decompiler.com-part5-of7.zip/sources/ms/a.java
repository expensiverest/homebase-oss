package ms;

import gx.j;
import is.e;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import k80.l;
import z20.g;

/* JADX INFO: loaded from: classes3.dex */
public final class a extends g {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Pattern f21882c = Pattern.compile("(.+?)='(.*?)';", 32);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CharsetDecoder f21883a = j.f13622c.newDecoder();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final CharsetDecoder f21884b = j.f13621b.newDecoder();

    @Override // z20.g
    public final is.c l(e eVar, ByteBuffer byteBuffer) {
        String string;
        CharsetDecoder charsetDecoder = this.f21884b;
        CharsetDecoder charsetDecoder2 = this.f21883a;
        String str = null;
        try {
            string = charsetDecoder2.decode(byteBuffer).toString();
            charsetDecoder2.reset();
            byteBuffer.rewind();
        } catch (CharacterCodingException unused) {
            charsetDecoder2.reset();
            byteBuffer.rewind();
            try {
                String string2 = charsetDecoder.decode(byteBuffer).toString();
                charsetDecoder.reset();
                byteBuffer.rewind();
                string = string2;
            } catch (CharacterCodingException unused2) {
                charsetDecoder.reset();
                byteBuffer.rewind();
                string = null;
            } catch (Throwable th2) {
                charsetDecoder.reset();
                byteBuffer.rewind();
                throw th2;
            }
        } catch (Throwable th3) {
            charsetDecoder2.reset();
            byteBuffer.rewind();
            throw th3;
        }
        byte[] bArr = new byte[byteBuffer.limit()];
        byteBuffer.get(bArr);
        if (string == null) {
            return new is.c(new c(bArr, null, null));
        }
        Matcher matcher = f21882c.matcher(string);
        String str2 = null;
        for (int iEnd = 0; matcher.find(iEnd); iEnd = matcher.end()) {
            String strGroup = matcher.group(1);
            String strGroup2 = matcher.group(2);
            if (strGroup != null) {
                String strZ = l.Z(strGroup);
                strZ.getClass();
                if (strZ.equals("streamurl")) {
                    str2 = strGroup2;
                } else if (strZ.equals("streamtitle")) {
                    str = strGroup2;
                }
            }
        }
        return new is.c(new c(bArr, str, str2));
    }
}
