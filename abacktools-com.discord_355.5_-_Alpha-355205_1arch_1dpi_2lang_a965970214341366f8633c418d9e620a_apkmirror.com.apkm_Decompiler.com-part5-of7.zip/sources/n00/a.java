package n00;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f22257a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f22258b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f22259c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f22260d;
}
