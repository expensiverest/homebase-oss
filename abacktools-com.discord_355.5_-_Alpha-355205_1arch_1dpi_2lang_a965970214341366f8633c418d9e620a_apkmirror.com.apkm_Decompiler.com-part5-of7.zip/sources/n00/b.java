package n00;

import ay.f;
import b3.l;
import j00.e;
import j00.k;
import j00.m;

/* JADX INFO: loaded from: classes3.dex */
public final class b extends l {
    public int J;
    public j00.b K;
    public final e L;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final m f22261i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f22262v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f22263w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f22264x;
    public boolean y;

    static {
        new f(11, b.class.getSimpleName());
    }

    public b(m mVar, k kVar) {
        super(kVar);
        this.f22261i = mVar;
        this.f22262v = true;
        this.f22263w = true;
        this.f22264x = true;
        this.y = true;
        this.J = 51;
        this.K = j00.b.f17791p;
        this.L = new e();
    }

    public static float H2(int i11, float f3, boolean z11) {
        int i12 = z11 ? i11 & 7 : i11 & 112;
        if (i12 != 1) {
            if (i12 == 3) {
                return 0.0f;
            }
            if (i12 != 5) {
                if (i12 != 16) {
                    if (i12 == 48 || i12 != 80) {
                        return 0.0f;
                    }
                }
            }
            return f3;
        }
        return f3 * 0.5f;
    }

    public final float I2(boolean z11, boolean z12) {
        float fL2;
        float f3;
        m00.a aVarW2 = w2();
        float f11 = z11 ? aVarW2.f20732e.left : aVarW2.f20732e.top;
        m00.a aVarW3 = w2();
        float f12 = z11 ? aVarW3.f20737j : aVarW3.k;
        m00.a aVarW4 = w2();
        float fWidth = z11 ? aVarW4.f20732e.width() : aVarW4.f20732e.height();
        float fH2 = 0.0f;
        if ((z11 ? this.f22262v : this.f22263w) && z12) {
            fL2 = z11 ? L2() : M2();
        } else {
            fL2 = 0.0f;
        }
        int i11 = 3;
        int i12 = 48;
        if (z11) {
            int i13 = this.J & 240;
            if (i13 != 16) {
                if (i13 != 32) {
                    i11 = i13 != 48 ? 0 : 1;
                } else {
                    i11 = 5;
                }
            }
        } else {
            int i14 = this.J & (-241);
            if (i14 != 1) {
                if (i14 != 2) {
                    i12 = i14 != 3 ? 0 : 16;
                } else {
                    i12 = 80;
                }
            }
            i11 = i12;
        }
        if (fWidth <= f12) {
            f3 = f12 - fWidth;
            if (i11 != 0) {
                fH2 = H2(i11, f3, z11);
                f3 = fH2;
            }
        } else {
            fH2 = f12 - fWidth;
            f3 = 0.0f;
        }
        return sg.a.m(f11, fH2 - fL2, f3 + fL2) - f11;
    }

    public final void J2(boolean z11, a output) {
        kotlin.jvm.internal.k.g(output, "output");
        m00.a aVarW2 = w2();
        int i11 = (int) (z11 ? aVarW2.f20732e.left : aVarW2.f20732e.top);
        m00.a aVarW3 = w2();
        int i12 = (int) (z11 ? aVarW3.f20737j : aVarW3.k);
        m00.a aVarW4 = w2();
        int iWidth = (int) (z11 ? aVarW4.f20732e.width() : aVarW4.f20732e.height());
        int iI2 = (int) I2(z11, false);
        int i13 = z11 ? this.J & 240 : this.J & (-241);
        if (iWidth > i12) {
            output.f22257a = -(iWidth - i12);
            output.f22259c = 0;
        } else if (i13 == 68 || i13 == 0 || i13 == 64 || i13 == 4) {
            output.f22257a = 0;
            output.f22259c = i12 - iWidth;
        } else {
            int i14 = i11 + iI2;
            output.f22257a = i14;
            output.f22259c = i14;
        }
        output.f22258b = i11;
        output.f22260d = iI2 != 0;
    }

    public final e K2() {
        Float fValueOf = Float.valueOf(I2(true, false));
        Float fValueOf2 = Float.valueOf(I2(false, false));
        e eVar = this.L;
        eVar.getClass();
        eVar.f17794a = fValueOf.floatValue();
        eVar.f17795b = fValueOf2.floatValue();
        return eVar;
    }

    public final float L2() {
        float fM = ((al.c) this.K).m(this.f22261i, true);
        if (fM >= 0.0f || fM >= 0.0f) {
            return fM;
        }
        return 0.0f;
    }

    public final float M2() {
        float fM = ((al.c) this.K).m(this.f22261i, false);
        if (fM >= 0.0f || fM >= 0.0f) {
            return fM;
        }
        return 0.0f;
    }
}
