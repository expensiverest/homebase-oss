package n00;

import al.d;
import ay.f;
import b3.l;
import j00.k;
import j00.m;

/* JADX INFO: loaded from: classes3.dex */
public final class c extends l {
    public int J;
    public j00.c K;
    public boolean L;
    public boolean M;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final m f22265i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public float f22266v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public float f22267w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f22268x;
    public float y;

    static {
        new f(11, c.class.getSimpleName());
    }

    public c(m mVar, k kVar) {
        super(kVar);
        this.f22265i = mVar;
        this.f22267w = 0.8f;
        this.y = 2.5f;
        this.K = j00.c.f17792q;
        this.L = true;
        this.M = true;
    }

    public final float H2(float f3, boolean z11) {
        float fJ2 = J2();
        float fI2 = I2();
        if (z11 && this.M) {
            ((d) this.K).getClass();
            m engine = this.f22265i;
            kotlin.jvm.internal.k.g(engine, "engine");
            c cVar = engine.f17816h;
            float f11 = (cVar.y - cVar.f22267w) * 0.1f;
            if (f11 < 0.0f && f11 < 0.0f) {
                f11 = 0.0f;
            }
            fJ2 -= f11;
            ((d) this.K).getClass();
            float f12 = (cVar.y - cVar.f22267w) * 0.1f;
            fI2 += (f12 >= 0.0f || f12 >= 0.0f) ? f12 : 0.0f;
        }
        if (fI2 < fJ2) {
            int i11 = this.J;
            if (i11 == this.f22268x) {
                throw new IllegalStateException("maxZoom is less than minZoom: " + fI2 + " < " + fJ2);
            }
            if (i11 == 0) {
                fJ2 = fI2;
            } else {
                fI2 = fJ2;
            }
        }
        return sg.a.m(f3, fJ2, fI2);
    }

    public final float I2() {
        int i11 = this.J;
        if (i11 == 0) {
            return this.y * this.f22266v;
        }
        if (i11 == 1) {
            return this.y;
        }
        throw new IllegalArgumentException(kotlin.jvm.internal.k.n(Integer.valueOf(this.J), "Unknown ZoomType "));
    }

    public final float J2() {
        int i11 = this.f22268x;
        if (i11 == 0) {
            return this.f22267w * this.f22266v;
        }
        if (i11 == 1) {
            return this.f22267w;
        }
        throw new IllegalArgumentException(kotlin.jvm.internal.k.n(Integer.valueOf(this.f22268x), "Unknown ZoomType "));
    }
}
