package mz;

import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.NumberKeyListener;

/* JADX INFO: loaded from: classes3.dex */
public final class d extends NumberKeyListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ j f22102a;

    public d(j jVar) {
        this.f22102a = jVar;
    }

    @Override // android.text.method.NumberKeyListener, android.text.InputFilter
    public final CharSequence filter(CharSequence charSequence, int i11, int i12, Spanned spanned, int i13, int i14) {
        j jVar = this.f22102a;
        h hVar = jVar.f22123h0;
        if (hVar != null && hVar.f22109v) {
            hVar.f22106d.removeCallbacks(hVar);
            hVar.f22109v = false;
        }
        if (jVar.M == null) {
            CharSequence charSequenceFilter = super.filter(charSequence, i11, i12, spanned, i13, i14);
            if (charSequenceFilter == null) {
                charSequenceFilter = charSequence.subSequence(i11, i12);
            }
            String str = String.valueOf(spanned.subSequence(0, i13)) + ((Object) charSequenceFilter) + ((Object) spanned.subSequence(i14, spanned.length()));
            if ("".equals(str)) {
                return str;
            }
            if (jVar.e(str) <= jVar.O && str.length() <= String.valueOf(jVar.O).length()) {
                return charSequenceFilter;
            }
        } else {
            String strValueOf = String.valueOf(charSequence.subSequence(i11, i12));
            if (!TextUtils.isEmpty(strValueOf)) {
                String str2 = String.valueOf(spanned.subSequence(0, i13)) + ((Object) strValueOf) + ((Object) spanned.subSequence(i14, spanned.length()));
                String lowerCase = String.valueOf(str2).toLowerCase();
                for (String str3 : jVar.M) {
                    if (str3.toLowerCase().startsWith(lowerCase)) {
                        int length = str2.length();
                        int length2 = str3.length();
                        if (jVar.f22123h0 == null) {
                            jVar.f22123h0 = new h(jVar.f22119e);
                        }
                        h hVar2 = jVar.f22123h0;
                        hVar2.f22107e = length;
                        hVar2.f22108i = length2;
                        if (!hVar2.f22109v) {
                            hVar2.f22106d.post(hVar2);
                            hVar2.f22109v = true;
                        }
                        return str3.subSequence(i13, str3.length());
                    }
                }
            }
        }
        return "";
    }

    @Override // android.text.method.NumberKeyListener
    public final char[] getAcceptedChars() {
        return j.K0;
    }

    @Override // android.text.method.KeyListener
    public final int getInputType() {
        return 1;
    }
}
