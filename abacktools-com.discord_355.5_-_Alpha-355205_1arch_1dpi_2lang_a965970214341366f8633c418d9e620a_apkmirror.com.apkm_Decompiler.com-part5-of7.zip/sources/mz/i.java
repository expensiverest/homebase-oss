package mz;

import android.icu.text.DecimalFormatSymbols;
import java.util.Formatter;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public final class i implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final StringBuilder f22110a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public char f22111b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Formatter f22112c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object[] f22113d;

    public i() {
        StringBuilder sb2 = new StringBuilder();
        this.f22110a = sb2;
        this.f22113d = new Object[1];
        Locale locale = Locale.getDefault();
        this.f22112c = new Formatter(sb2, locale);
        this.f22111b = DecimalFormatSymbols.getInstance(locale).getZeroDigit();
    }
}
