package mz;

import android.widget.EditText;

/* JADX INFO: loaded from: classes3.dex */
public final class h implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final EditText f22106d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f22107e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f22108i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f22109v;

    public h(EditText editText) {
        this.f22106d = editText;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f22109v = false;
        this.f22106d.setSelection(this.f22107e, this.f22108i);
    }
}
