package mz;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

/* JADX INFO: loaded from: classes3.dex */
public final class a implements View.OnFocusChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f22096a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f22097b;

    public /* synthetic */ a(ViewGroup viewGroup, int i11) {
        this.f22096a = i11;
        this.f22097b = viewGroup;
    }

    @Override // android.view.View.OnFocusChangeListener
    public final void onFocusChange(View view, boolean z11) {
        switch (this.f22096a) {
            case 0:
                j jVar = (j) this.f22097b;
                EditText editText = jVar.f22119e;
                if (!z11) {
                    editText.setSelection(0, 0);
                    String strValueOf = String.valueOf(((TextView) view).getText());
                    if (!TextUtils.isEmpty(strValueOf)) {
                        jVar.n(jVar.e(strValueOf.toString()), true);
                    } else {
                        jVar.q();
                    }
                } else {
                    editText.selectAll();
                }
                break;
            default:
                t10.a aVar = (t10.a) this.f22097b;
                View.OnFocusChangeListener onFocusChangeListener = aVar.f25507r0;
                if (onFocusChangeListener != null) {
                    onFocusChangeListener.onFocusChange(aVar, z11);
                }
                break;
        }
    }
}
