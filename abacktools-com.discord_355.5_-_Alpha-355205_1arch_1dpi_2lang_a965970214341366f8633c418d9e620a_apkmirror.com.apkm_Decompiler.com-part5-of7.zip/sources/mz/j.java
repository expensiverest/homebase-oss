package mz;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.icu.text.DecimalFormatSymbols;
import android.os.Build;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Scroller;
import androidx.core.view.d0;
import com.henninghall.date_picker.pickers.AndroidNative;
import com.reactnativecommunity.webview.RNCWebViewManager;
import fb.c0;
import hs.q;
import j.e0;
import java.util.Formatter;
import java.util.Locale;
import k7.p;
import lz.n;
import mr.p1;

/* JADX INFO: loaded from: classes3.dex */
public abstract class j extends LinearLayout {
    public static final i J0 = new i();
    public static final char[] K0 = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 2406, 2407, 2408, 2409, 2410, 2411, 2412, 2413, 2414, 2415, 2534, 2535, 2536, 2537, 2538, 2539, 2540, 2541, 2542, 2543, 3302, 3303, 3304, 3305, 3306, 3307, 3308, 3309, 3310, 3311};
    public int A0;
    public int B0;
    public boolean C0;
    public boolean D0;
    public b E0;
    public final g F0;
    public int G0;
    public final boolean H0;
    public long I0;
    public final boolean J;
    public final int K;
    public int L;
    public String[] M;
    public int N;
    public int O;
    public int P;
    public f Q;
    public e R;
    public c S;
    public long T;
    public final SparseArray U;
    public final int[] V;
    public final Paint W;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final Drawable f22114a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public int f22115b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public int f22116c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f22117d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public int f22118d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final EditText f22119e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final Scroller f22120e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final Scroller f22121f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public int f22122g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public h f22123h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f22124i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public a6.b f22125i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public e0 f22126j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public float f22127k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public long f22128l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public float f22129m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public VelocityTracker f22130n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public final int f22131o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public final int f22132p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public final int f22133q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public boolean f22134r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final int f22135s0;
    public final boolean t0;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public final Drawable f22136u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f22137v;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public int f22138v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f22139w;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public int f22140w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f22141x;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public boolean f22142x0;
    public int y;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public boolean f22143y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public int f22144z0;

    public j(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.numberPickerStyle);
    }

    public static final c getTwoDigitFormatter() {
        return J0;
    }

    public static int i(int i11, int i12) {
        if (i12 != -1) {
            int size = View.MeasureSpec.getSize(i11);
            int mode = View.MeasureSpec.getMode(i11);
            if (mode == Integer.MIN_VALUE) {
                return View.MeasureSpec.makeMeasureSpec(Math.min(size, i12), 1073741824);
            }
            if (mode == 0) {
                return View.MeasureSpec.makeMeasureSpec(i12, 1073741824);
            }
            if (mode != 1073741824) {
                throw new IllegalArgumentException(q.j(mode, "Unknown measure mode: "));
            }
        }
        return i11;
    }

    public final void a(boolean z11) {
        if (!this.t0) {
            if (z11) {
                n(this.P + 1, true);
                return;
            } else {
                n(this.P - 1, true);
                return;
            }
        }
        g();
        Scroller scroller = this.f22120e0;
        if (!j(scroller)) {
            j(this.f22121f0);
        }
        this.f22122g0 = 0;
        if (z11) {
            scroller.startScroll(0, 0, 0, -this.f22115b0, 300);
        } else {
            scroller.startScroll(0, 0, 0, this.f22115b0, 300);
        }
        invalidate();
    }

    public final void b(int i11) {
        String strD;
        SparseArray sparseArray = this.U;
        if (((String) sparseArray.get(i11)) != null) {
            return;
        }
        int i12 = this.N;
        if (i11 < i12 || i11 > this.O) {
            strD = "";
        } else {
            String[] strArr = this.M;
            strD = strArr != null ? strArr[i11 - i12] : d(i11);
        }
        sparseArray.put(i11, strD);
    }

    public final void c() {
        int i11 = this.f22116c0 - this.f22118d0;
        if (i11 != 0) {
            this.f22122g0 = 0;
            int iAbs = Math.abs(i11);
            int i12 = this.f22115b0;
            if (iAbs > i12 / 2) {
                if (i11 > 0) {
                    i12 = -i12;
                }
                i11 += i12;
            }
            this.f22121f0.startScroll(0, 0, 0, i11, 800);
            invalidate();
        }
    }

    @Override // android.view.View
    public final void computeScroll() {
        Scroller scroller = this.f22120e0;
        if (scroller.isFinished()) {
            scroller = this.f22121f0;
            if (scroller.isFinished()) {
                return;
            }
        }
        scroller.computeScrollOffset();
        int currY = scroller.getCurrY();
        if (this.f22122g0 == 0) {
            this.f22122g0 = scroller.getStartY();
        }
        scrollBy(0, currY - this.f22122g0);
        this.f22122g0 = currY;
        if (scroller.isFinished()) {
            l(scroller);
        } else {
            invalidate();
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return getHeight();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return this.f22118d0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        return ((this.O - this.N) + 1) * this.f22115b0;
    }

    public final String d(int i11) {
        c cVar = this.S;
        if (cVar == null) {
            return String.format(Locale.getDefault(), "%d", Integer.valueOf(i11));
        }
        i iVar = (i) cVar;
        StringBuilder sb2 = iVar.f22110a;
        Object[] objArr = iVar.f22113d;
        Locale locale = Locale.getDefault();
        if (iVar.f22111b != DecimalFormatSymbols.getInstance(locale).getZeroDigit()) {
            iVar.f22112c = new Formatter(sb2, locale);
            iVar.f22111b = DecimalFormatSymbols.getInstance(locale).getZeroDigit();
        }
        objArr[0] = Integer.valueOf(i11);
        sb2.delete(0, sb2.length());
        iVar.f22112c.format("%02d", objArr);
        return iVar.f22112c.toString();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchHoverEvent(MotionEvent motionEvent) {
        int i11;
        if (!this.t0) {
            return super.dispatchHoverEvent(motionEvent);
        }
        if (!((AccessibilityManager) getContext().getSystemService("accessibility")).isEnabled()) {
            return false;
        }
        int y = (int) motionEvent.getY();
        if (y < this.f22144z0) {
            i11 = 3;
        } else {
            i11 = y > this.A0 ? 1 : 2;
        }
        int actionMasked = motionEvent.getActionMasked();
        b bVar = (b) getAccessibilityNodeProvider();
        if (actionMasked == 7) {
            int i12 = this.B0;
            if (i12 == i11 || i12 == -1) {
                return false;
            }
            bVar.f(i12, 256);
            bVar.f(i11, 128);
            this.B0 = i11;
            bVar.performAction(i11, 64, null);
            return false;
        }
        if (actionMasked == 9) {
            bVar.f(i11, 128);
            this.B0 = i11;
            bVar.performAction(i11, 64, null);
            return false;
        }
        if (actionMasked != 10) {
            return false;
        }
        bVar.f(i11, 256);
        this.B0 = -1;
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        if (keyCode == 19 || keyCode == 20) {
            if (this.t0) {
                int action = keyEvent.getAction();
                if (action == 0) {
                    if (!this.f22134r0) {
                        if (keyCode == 20) {
                        }
                    }
                    requestFocus();
                    this.G0 = keyCode;
                    m();
                    if (this.f22120e0.isFinished()) {
                        a(keyCode == 20);
                    }
                    return true;
                }
                if (action == 1 && this.G0 == keyCode) {
                    this.G0 = -1;
                    return true;
                }
            }
        } else if (keyCode == 23 || keyCode == 66 || keyCode == 160) {
            m();
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 1 || actionMasked == 3) {
            m();
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchTrackballEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 1 || actionMasked == 3) {
            m();
        }
        return super.dispatchTrackballEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f22136u0;
        if (drawable != null && drawable.isStateful() && drawable.setState(getDrawableState())) {
            invalidateDrawable(drawable);
        }
    }

    public final int e(String str) {
        try {
            if (this.M == null) {
                return Integer.parseInt(str);
            }
            for (int i11 = 0; i11 < this.M.length; i11++) {
                str = str.toLowerCase();
                if (this.M[i11].toLowerCase().startsWith(str)) {
                    return this.N + i11;
                }
            }
            return Integer.parseInt(str);
        } catch (NumberFormatException unused) {
            return this.N;
        }
    }

    public final int f(int i11) {
        int i12 = this.O;
        if (i11 > i12) {
            int i13 = this.N;
            return (((i11 - i12) % (i12 - i13)) + i13) - 1;
        }
        int i14 = this.N;
        return i11 < i14 ? (i12 - ((i14 - i11) % (i12 - i14))) + 1 : i11;
    }

    public final void g() {
        InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService(InputMethodManager.class);
        EditText editText = this.f22119e;
        if (inputMethodManager != null && inputMethodManager.isActive(editText)) {
            inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        }
        if (this.t0) {
            editText.setVisibility(4);
        }
    }

    @Override // android.view.View
    public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        if (!this.t0) {
            return super.getAccessibilityNodeProvider();
        }
        if (this.E0 == null) {
            this.E0 = new b(this);
        }
        return this.E0;
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        return 0.9f;
    }

    public CharSequence getDisplayedValueForCurrentSelection() {
        return (CharSequence) this.U.get(getValue());
    }

    public String[] getDisplayedValues() {
        return this.M;
    }

    public int getMaxValue() {
        return this.O;
    }

    public int getMinValue() {
        return this.N;
    }

    public int getSelectionDividerHeight() {
        return this.f22138v0;
    }

    @Override // android.view.View
    public int getSolidColor() {
        return this.f22135s0;
    }

    public int getTextColor() {
        return this.W.getColor();
    }

    public float getTextSize() {
        return this.W.getTextSize();
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        return 0.9f;
    }

    public int getValue() {
        return this.P;
    }

    public boolean getWrapSelectorWheel() {
        return this.f22134r0;
    }

    public final void h() {
        this.U.clear();
        int value = getValue();
        int i11 = 0;
        while (true) {
            int[] iArr = this.V;
            if (i11 >= iArr.length) {
                return;
            }
            int iF = (i11 - 1) + value;
            if (this.f22134r0) {
                iF = f(iF);
            }
            iArr[i11] = iF;
            b(iF);
            i11++;
        }
    }

    public final boolean j(Scroller scroller) {
        scroller.forceFinished(true);
        int finalY = scroller.getFinalY() - scroller.getCurrY();
        int i11 = this.f22116c0 - ((this.f22118d0 + finalY) % this.f22115b0);
        if (i11 == 0) {
            return false;
        }
        int iAbs = Math.abs(i11);
        int i12 = this.f22115b0;
        if (iAbs > i12 / 2) {
            i11 = i11 > 0 ? i11 - i12 : i11 + i12;
        }
        scrollBy(0, finalY + i11);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f22136u0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public final void k(int i11) {
        if (this.f22140w0 == i11) {
            return;
        }
        this.f22140w0 = i11;
        e eVar = this.R;
        if (eVar != null) {
            AndroidNative androidNative = (AndroidNative) ((m60.c) eVar).f21204e;
            if (androidNative.M0 != 0 && i11 == 0) {
                androidNative.s();
            }
            androidNative.M0 = i11;
            if (i11 != 0) {
                androidNative.Q0 = true;
                ((m60.c) androidNative.L0).M();
            }
        }
    }

    public final void l(Scroller scroller) {
        if (scroller == this.f22120e0) {
            c();
            q();
            k(0);
        } else if (this.f22140w0 != 1) {
            q();
        }
    }

    public final void m() {
        a6.b bVar = this.f22125i0;
        if (bVar != null) {
            removeCallbacks(bVar);
        }
        h hVar = this.f22123h0;
        if (hVar != null && hVar.f22109v) {
            hVar.f22106d.removeCallbacks(hVar);
            hVar.f22109v = false;
        }
        e0 e0Var = this.f22126j0;
        if (e0Var != null) {
            removeCallbacks(e0Var);
        }
        this.F0.a();
    }

    public final void n(int i11, boolean z11) {
        f fVar;
        if (this.P == i11) {
            return;
        }
        int iF = this.f22134r0 ? f(i11) : Math.min(Math.max(i11, this.N), this.O);
        int i12 = this.P;
        this.P = iF;
        if (this.f22140w0 != 2) {
            q();
        }
        if (z11 && (fVar = this.Q) != null) {
            int i13 = this.P;
            AndroidNative androidNative = (AndroidNative) ((bu.i) fVar).f4200e;
            oz.d dVar = androidNative.N0;
            if (dVar != null) {
                c0 c0Var = (c0) ((p1) dVar).f21702e;
                p pVar = (p) c0Var.f11572w;
                sz.d dVar2 = (sz.d) c0Var.f11569e;
                if (((d0) pVar.Q).B()) {
                    String str = (String) dVar2.f29495c.get(i12);
                    String str2 = (String) dVar2.f29495c.get(i13);
                    if ((str.equals("12") && str2.equals("11")) || (str.equals("11") && str2.equals("12"))) {
                        oz.e eVar = ((sz.a) c0Var.y).f29496d;
                        ((AndroidNative) eVar).t((eVar.getValue() + 1) % 2);
                    }
                }
            }
            if (androidNative.M0 == 0) {
                androidNative.s();
            }
        }
        h();
        invalidate();
    }

    public final void o() {
        InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService(InputMethodManager.class);
        if (inputMethodManager != null) {
            boolean z11 = this.t0;
            EditText editText = this.f22119e;
            if (z11) {
                editText.setVisibility(0);
            }
            editText.requestFocus();
            inputMethodManager.showSoftInput(editText, 0);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m();
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onDraw(Canvas canvas) {
        Drawable drawable;
        Drawable drawable2;
        if (!this.t0) {
            super.onDraw(canvas);
            return;
        }
        boolean zHasFocus = this.H0 ? hasFocus() : true;
        float right = (getRight() - getLeft()) / 2;
        float f3 = this.f22118d0;
        if (zHasFocus && (drawable2 = this.f22114a0) != null && this.f22140w0 == 0) {
            boolean z11 = this.D0;
            int[] iArr = LinearLayout.PRESSED_STATE_SET;
            if (z11) {
                drawable2.setState(iArr);
                drawable2.setBounds(0, 0, getRight(), this.f22144z0);
                drawable2.draw(canvas);
            }
            if (this.C0) {
                drawable2.setState(iArr);
                drawable2.setBounds(0, this.A0, getRight(), getBottom());
                drawable2.draw(canvas);
            }
        }
        int i11 = 0;
        while (true) {
            int[] iArr2 = this.V;
            if (i11 >= iArr2.length) {
                break;
            }
            String str = (String) this.U.get(iArr2[i11]);
            if ((zHasFocus && i11 != 1) || (i11 == 1 && this.f22119e.getVisibility() != 0)) {
                canvas.drawText(str, right, f3, this.W);
            }
            f3 += this.f22115b0;
            i11++;
        }
        if (!zHasFocus || (drawable = this.f22136u0) == null) {
            return;
        }
        int i12 = this.f22144z0;
        drawable.setBounds(0, i12, getRight(), this.f22138v0 + i12);
        drawable.draw(canvas);
        int i13 = this.A0;
        drawable.setBounds(0, i13 - this.f22138v0, getRight(), i13);
        drawable.draw(canvas);
    }

    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (!this.t0 || !isEnabled()) {
            return super.onGenericMotionEvent(motionEvent);
        }
        if (motionEvent.getActionMasked() == 8) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                long jCurrentTimeMillis = System.currentTimeMillis();
                if (jCurrentTimeMillis - this.I0 >= 150) {
                    this.I0 = jCurrentTimeMillis;
                    if (axisValue < 0.0f) {
                        if (this.f22134r0 || getValue() < getMaxValue()) {
                            a(true);
                            return true;
                        }
                    } else if (this.f22134r0 || getValue() > getMinValue()) {
                        a(false);
                        return true;
                    }
                }
                return true;
            }
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (!this.t0 || !isEnabled() || motionEvent.getActionMasked() != 0) {
            return false;
        }
        m();
        g();
        float y = motionEvent.getY();
        this.f22127k0 = y;
        this.f22129m0 = y;
        this.f22128l0 = motionEvent.getEventTime();
        this.f22142x0 = false;
        this.f22143y0 = false;
        float f3 = this.f22127k0;
        float f11 = this.f22144z0;
        g gVar = this.F0;
        if (f3 < f11) {
            if (this.f22140w0 == 0) {
                gVar.a();
                gVar.f22104e = 1;
                gVar.f22103d = 2;
                gVar.f22105i.postDelayed(gVar, ViewConfiguration.getTapTimeout());
            }
        } else if (f3 > this.A0 && this.f22140w0 == 0) {
            gVar.a();
            gVar.f22104e = 1;
            gVar.f22103d = 1;
            gVar.f22105i.postDelayed(gVar, ViewConfiguration.getTapTimeout());
        }
        getParent().requestDisallowInterceptTouchEvent(true);
        Scroller scroller = this.f22120e0;
        boolean zIsFinished = scroller.isFinished();
        Scroller scroller2 = this.f22121f0;
        if (!zIsFinished) {
            scroller.forceFinished(true);
            scroller2.forceFinished(true);
            l(scroller);
            k(0);
            return true;
        }
        if (!scroller2.isFinished()) {
            scroller.forceFinished(true);
            scroller2.forceFinished(true);
            l(scroller2);
            return true;
        }
        float f12 = this.f22127k0;
        if (f12 < this.f22144z0) {
            long longPressTimeout = ViewConfiguration.getLongPressTimeout();
            Runnable runnable = this.f22125i0;
            if (runnable == null) {
                this.f22125i0 = new a6.b(this, 1);
            } else {
                removeCallbacks(runnable);
            }
            a6.b bVar = this.f22125i0;
            bVar.f410e = false;
            postDelayed(bVar, longPressTimeout);
            return true;
        }
        if (f12 <= this.A0) {
            this.f22143y0 = true;
            Runnable runnable2 = this.f22126j0;
            if (runnable2 == null) {
                this.f22126j0 = new e0(7, this);
            } else {
                removeCallbacks(runnable2);
            }
            postDelayed(this.f22126j0, ViewConfiguration.getLongPressTimeout());
            return true;
        }
        long longPressTimeout2 = ViewConfiguration.getLongPressTimeout();
        Runnable runnable3 = this.f22125i0;
        if (runnable3 == null) {
            this.f22125i0 = new a6.b(this, 1);
        } else {
            removeCallbacks(runnable3);
        }
        a6.b bVar2 = this.f22125i0;
        bVar2.f410e = true;
        postDelayed(bVar2, longPressTimeout2);
        return true;
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z11, int i11, int i12, int i13, int i14) {
        if (!this.t0) {
            super.onLayout(z11, i11, i12, i13, i14);
            return;
        }
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        EditText editText = this.f22119e;
        int measuredWidth2 = editText.getMeasuredWidth();
        int measuredHeight2 = editText.getMeasuredHeight();
        int i15 = (measuredWidth - measuredWidth2) / 2;
        int i16 = (measuredHeight - measuredHeight2) / 2;
        editText.layout(i15, i16, measuredWidth2 + i15, measuredHeight2 + i16);
        if (z11) {
            h();
            int[] iArr = this.V;
            int length = iArr.length;
            int i17 = this.K;
            int bottom = (int) ((((getBottom() - getTop()) - (length * i17)) / iArr.length) + 0.5f);
            this.L = bottom;
            this.f22115b0 = bottom + i17;
            int top = (editText.getTop() + editText.getBaseline()) - this.f22115b0;
            this.f22116c0 = top;
            this.f22118d0 = top;
            q();
            setVerticalFadingEdgeEnabled(true);
            setFadingEdgeLength(((getBottom() - getTop()) - i17) / 2);
            int height = getHeight();
            int i18 = this.f22124i;
            int i19 = this.f22138v0;
            int i21 = ((height - i18) / 2) - i19;
            this.f22144z0 = i21;
            this.A0 = (i19 * 2) + i21 + i18;
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i11, int i12) {
        if (!this.t0) {
            super.onMeasure(i11, i12);
            return;
        }
        super.onMeasure(i(i11, this.y), i(i12, this.f22139w));
        int measuredWidth = getMeasuredWidth();
        int i13 = this.f22141x;
        if (i13 != -1) {
            measuredWidth = View.resolveSizeAndState(Math.max(i13, measuredWidth), i11, 0);
        }
        int measuredHeight = getMeasuredHeight();
        int i14 = this.f22137v;
        if (i14 != -1) {
            measuredHeight = View.resolveSizeAndState(Math.max(i14, measuredHeight), i12, 0);
        }
        setMeasuredDimension(measuredWidth, measuredHeight);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled() || !this.t0) {
            return false;
        }
        if (this.f22130n0 == null) {
            this.f22130n0 = VelocityTracker.obtain();
        }
        this.f22130n0.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int i11 = this.f22131o0;
        if (actionMasked != 1) {
            if (actionMasked != 2 || this.f22142x0) {
                return true;
            }
            float y = motionEvent.getY();
            if (this.f22140w0 == 1) {
                scrollBy(0, (int) (y - this.f22129m0));
                invalidate();
            } else if (((int) Math.abs(y - this.f22127k0)) > i11) {
                m();
                k(1);
            }
            this.f22129m0 = y;
            return true;
        }
        e0 e0Var = this.f22126j0;
        if (e0Var != null) {
            removeCallbacks(e0Var);
        }
        a6.b bVar = this.f22125i0;
        if (bVar != null) {
            removeCallbacks(bVar);
        }
        g gVar = this.F0;
        gVar.a();
        j jVar = gVar.f22105i;
        VelocityTracker velocityTracker = this.f22130n0;
        velocityTracker.computeCurrentVelocity(RNCWebViewManager.COMMAND_CLEAR_FORM_DATA, this.f22133q0);
        int yVelocity = (int) velocityTracker.getYVelocity();
        if (Math.abs(yVelocity) > this.f22132p0) {
            this.f22122g0 = 0;
            Scroller scroller = this.f22120e0;
            if (yVelocity > 0) {
                scroller.fling(0, 0, 0, yVelocity, 0, 0, 0, Integer.MAX_VALUE);
            } else {
                scroller.fling(0, Integer.MAX_VALUE, 0, yVelocity, 0, 0, 0, Integer.MAX_VALUE);
            }
            invalidate();
            k(2);
        } else {
            int y11 = (int) motionEvent.getY();
            int iAbs = (int) Math.abs(y11 - this.f22127k0);
            long eventTime = motionEvent.getEventTime() - this.f22128l0;
            if (iAbs > i11 || eventTime >= ViewConfiguration.getTapTimeout()) {
                c();
            } else if (this.f22143y0) {
                this.f22143y0 = false;
                performClick();
            } else {
                int i12 = (y11 / this.f22115b0) - 1;
                if (i12 > 0) {
                    a(true);
                    gVar.a();
                    gVar.f22104e = 2;
                    gVar.f22103d = 1;
                    jVar.post(gVar);
                } else if (i12 < 0) {
                    a(false);
                    gVar.a();
                    gVar.f22104e = 2;
                    gVar.f22103d = 2;
                    jVar.post(gVar);
                }
            }
            k(0);
        }
        this.f22130n0.recycle();
        this.f22130n0 = null;
        return true;
    }

    public final void p() {
        int i11;
        if (this.J) {
            String[] strArr = this.M;
            Paint paint = this.W;
            int i12 = 0;
            if (strArr == null) {
                float f3 = 0.0f;
                for (int i13 = 0; i13 <= 9; i13++) {
                    float fMeasureText = paint.measureText(String.format(Locale.getDefault(), "%d", Integer.valueOf(i13)));
                    if (fMeasureText > f3) {
                        f3 = fMeasureText;
                    }
                }
                for (int i14 = this.O; i14 > 0; i14 /= 10) {
                    i12++;
                }
                i11 = (int) (i12 * f3);
            } else {
                int length = strArr.length;
                int i15 = 0;
                while (i12 < length) {
                    float fMeasureText2 = paint.measureText(this.M[i12]);
                    if (fMeasureText2 > i15) {
                        i15 = (int) fMeasureText2;
                    }
                    i12++;
                }
                i11 = i15;
            }
            EditText editText = this.f22119e;
            int paddingRight = editText.getPaddingRight() + editText.getPaddingLeft() + i11;
            if (this.y != paddingRight) {
                int i16 = this.f22141x;
                if (paddingRight > i16) {
                    this.y = paddingRight;
                } else {
                    this.y = i16;
                }
                invalidate();
            }
        }
    }

    @Override // android.view.View
    public final boolean performClick() {
        if (!this.t0) {
            return super.performClick();
        }
        if (super.performClick()) {
            return true;
        }
        o();
        return true;
    }

    @Override // android.view.View
    public final boolean performLongClick() {
        if (!this.t0) {
            return super.performLongClick();
        }
        if (!super.performLongClick()) {
            o();
            this.f22142x0 = true;
        }
        return true;
    }

    public final void q() {
        String[] strArr = this.M;
        String strD = strArr == null ? d(this.P) : strArr[this.P - this.N];
        if (TextUtils.isEmpty(strD)) {
            return;
        }
        EditText editText = this.f22119e;
        Editable text = editText.getText();
        if (strD.equals(text.toString())) {
            return;
        }
        editText.setText(strD);
        if (((AccessibilityManager) getContext().getSystemService("accessibility")).isEnabled()) {
            AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain(16);
            editText.onInitializeAccessibilityEvent(accessibilityEventObtain);
            editText.onPopulateAccessibilityEvent(accessibilityEventObtain);
            accessibilityEventObtain.setFromIndex(0);
            accessibilityEventObtain.setRemovedCount(text.length());
            accessibilityEventObtain.setAddedCount(strD.length());
            accessibilityEventObtain.setBeforeText(text);
            accessibilityEventObtain.setSource(this, 2);
            requestSendAccessibilityEvent(this, accessibilityEventObtain);
        }
    }

    public final void r() {
        this.f22134r0 = this.O - this.N >= this.V.length && this.f22117d;
    }

    @Override // android.view.View
    public final void scrollBy(int i11, int i12) {
        int i13;
        int i14 = this.f22118d0;
        boolean z11 = this.f22134r0;
        int[] iArr = this.V;
        if (!z11 && i12 > 0 && iArr[1] <= this.N) {
            this.f22118d0 = this.f22116c0;
            return;
        }
        if (!z11 && i12 < 0 && iArr[1] >= this.O) {
            this.f22118d0 = this.f22116c0;
            return;
        }
        this.f22118d0 = i12 + i14;
        while (true) {
            int i15 = this.f22118d0;
            if (i15 - this.f22116c0 <= this.L) {
                break;
            }
            this.f22118d0 = i15 - this.f22115b0;
            for (int length = iArr.length - 1; length > 0; length--) {
                iArr[length] = iArr[length - 1];
            }
            int i16 = iArr[1] - 1;
            if (this.f22134r0 && i16 < this.N) {
                i16 = this.O;
            }
            iArr[0] = i16;
            b(i16);
            n(iArr[1], true);
            if (!this.f22134r0 && iArr[1] <= this.N) {
                this.f22118d0 = this.f22116c0;
            }
        }
        while (true) {
            i13 = this.f22118d0;
            if (i13 - this.f22116c0 >= (-this.L)) {
                break;
            }
            this.f22118d0 = i13 + this.f22115b0;
            int i17 = 0;
            while (i17 < iArr.length - 1) {
                int i18 = i17 + 1;
                iArr[i17] = iArr[i18];
                i17 = i18;
            }
            int i19 = iArr[iArr.length - 2] + 1;
            if (this.f22134r0 && i19 > this.O) {
                i19 = this.N;
            }
            iArr[iArr.length - 1] = i19;
            b(i19);
            n(iArr[1], true);
            if (!this.f22134r0 && iArr[1] >= this.O) {
                this.f22118d0 = this.f22116c0;
            }
        }
        if (i14 != i13) {
            onScrollChanged(0, i13, 0, i14);
        }
    }

    public void setDisplayedValues(String[] strArr) {
        if (this.M == strArr) {
            return;
        }
        this.M = strArr;
        EditText editText = this.f22119e;
        if (strArr != null) {
            editText.setRawInputType(524289);
        } else {
            editText.setRawInputType(2);
        }
        q();
        h();
        p();
    }

    public void setDividerTint(int i11) {
        this.f22136u0.setTint(i11);
    }

    @Override // android.view.View
    public void setEnabled(boolean z11) {
        super.setEnabled(z11);
        boolean z12 = this.t0;
        if (!z12 || !z12) {
            throw null;
        }
        this.f22119e.setEnabled(z11);
    }

    public void setFormatter(c cVar) {
        if (cVar == this.S) {
            return;
        }
        this.S = cVar;
        h();
        q();
    }

    public void setMaxValue(int i11) {
        if (this.O == i11) {
            return;
        }
        if (i11 < 0) {
            throw new IllegalArgumentException("maxValue must be >= 0");
        }
        this.O = i11;
        if (i11 < this.P) {
            this.P = i11;
        }
        r();
        h();
        q();
        p();
        invalidate();
    }

    public void setMinValue(int i11) {
        if (this.N == i11) {
            return;
        }
        if (i11 < 0) {
            throw new IllegalArgumentException("minValue must be >= 0");
        }
        this.N = i11;
        if (i11 > this.P) {
            this.P = i11;
        }
        r();
        h();
        q();
        p();
        invalidate();
    }

    public void setOnLongPressUpdateInterval(long j6) {
        this.T = j6;
    }

    public void setOnScrollListener(e eVar) {
        this.R = eVar;
    }

    public void setOnValueChangedListener(f fVar) {
        this.Q = fVar;
    }

    public void setSelectionDividerHeight(int i11) {
        this.f22138v0 = i11;
        invalidate();
    }

    public void setTextColor(int i11) {
        this.W.setColor(i11);
        this.f22119e.setTextColor(i11);
        invalidate();
    }

    public void setTextSize(float f3) {
        this.W.setTextSize(f3);
        this.f22119e.setTextSize(0, f3);
        invalidate();
    }

    public void setValue(int i11) {
        n(i11, false);
    }

    public void setWrapSelectorWheel(boolean z11) {
        this.f22117d = z11;
        r();
    }

    public j(Context context, AttributeSet attributeSet, int i11) {
        j jVar;
        Context context2;
        super(context, attributeSet, i11, 0);
        this.f22117d = true;
        this.T = 300L;
        this.U = new SparseArray();
        this.V = new int[3];
        this.f22116c0 = androidx.customview.widget.b.INVALID_ID;
        this.f22140w0 = 0;
        this.G0 = -1;
        this.I0 = 0L;
        int[] iArr = n.f20720a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i11, 0);
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 29) {
            jVar = this;
            context2 = context;
            jVar.saveAttributeDataForStyleable(context2, iArr, attributeSet, typedArrayObtainStyledAttributes, i11, 0);
        } else {
            jVar = this;
            context2 = context;
        }
        jVar.t0 = true;
        jVar.H0 = typedArrayObtainStyledAttributes.getBoolean(0, false);
        jVar.f22135s0 = typedArrayObtainStyledAttributes.getColor(9, 0);
        Drawable drawable = getResources().getDrawable(com.discord.R.drawable.number_picker_divider_material);
        if (drawable != null) {
            drawable.setCallback(this);
            drawable.setLayoutDirection(getLayoutDirection());
            if (drawable.isStateful()) {
                drawable.setState(getDrawableState());
            }
        }
        jVar.f22136u0 = drawable;
        jVar.f22138v0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(7, (int) TypedValue.applyDimension(1, 2.0f, getResources().getDisplayMetrics()));
        jVar.f22124i = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, (int) TypedValue.applyDimension(1, 48.0f, getResources().getDisplayMetrics()));
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(4, -1);
        jVar.f22137v = dimensionPixelSize;
        int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(2, -1);
        jVar.f22139w = dimensionPixelSize2;
        if (dimensionPixelSize != -1 && dimensionPixelSize2 != -1 && dimensionPixelSize > dimensionPixelSize2) {
            throw new IllegalArgumentException("minHeight > maxHeight");
        }
        int dimensionPixelSize3 = typedArrayObtainStyledAttributes.getDimensionPixelSize(5, -1);
        jVar.f22141x = dimensionPixelSize3;
        int dimensionPixelSize4 = typedArrayObtainStyledAttributes.getDimensionPixelSize(3, -1);
        jVar.y = dimensionPixelSize4;
        if (dimensionPixelSize3 != -1 && dimensionPixelSize4 != -1 && dimensionPixelSize3 > dimensionPixelSize4) {
            throw new IllegalArgumentException("minWidth > maxWidth");
        }
        jVar.J = dimensionPixelSize4 == -1;
        jVar.f22114a0 = typedArrayObtainStyledAttributes.getDrawable(10);
        typedArrayObtainStyledAttributes.recycle();
        jVar.F0 = new g(this);
        setWillNotDraw(false);
        ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(com.discord.R.layout.number_picker_material, (ViewGroup) this, true);
        EditText editText = (EditText) findViewById(com.discord.R.id.numberpicker_input);
        jVar.f22119e = editText;
        editText.setOnFocusChangeListener(new a(this, 0));
        editText.setFilters(new InputFilter[]{new d(this)});
        editText.setRawInputType(2);
        editText.setImeOptions(6);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context2);
        jVar.f22131o0 = viewConfiguration.getScaledTouchSlop();
        jVar.f22132p0 = viewConfiguration.getScaledMinimumFlingVelocity();
        jVar.f22133q0 = viewConfiguration.getScaledMaximumFlingVelocity();
        int textSize = (int) editText.getTextSize();
        jVar.K = textSize;
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(textSize);
        paint.setTypeface(editText.getTypeface());
        paint.setColor(editText.getTextColors().getColorForState(LinearLayout.ENABLED_STATE_SET, -1));
        jVar.W = paint;
        jVar.f22120e0 = new Scroller(getContext(), null, true);
        jVar.f22121f0 = new Scroller(getContext(), new DecelerateInterpolator(2.5f));
        q();
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        if (i12 < 26 || getFocusable() != 16) {
            return;
        }
        setFocusable(1);
        setFocusableInTouchMode(true);
    }
}
