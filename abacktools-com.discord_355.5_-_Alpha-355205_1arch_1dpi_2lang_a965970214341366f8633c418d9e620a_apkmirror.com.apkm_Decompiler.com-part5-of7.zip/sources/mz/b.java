package mz;

import android.content.Context;
import android.graphics.Rect;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class b extends AccessibilityNodeProvider {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f22098a = new Rect();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int[] f22099b = new int[2];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f22100c = androidx.customview.widget.b.INVALID_ID;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ j f22101d;

    public b(j jVar) {
        this.f22101d = jVar;
    }

    public final AccessibilityNodeInfo a(int i11, int i12, int i13, int i14, int i15, String str) {
        AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain();
        accessibilityNodeInfoObtain.setClassName(Button.class.getName());
        j jVar = this.f22101d;
        accessibilityNodeInfoObtain.setPackageName(jVar.getContext().getPackageName());
        accessibilityNodeInfoObtain.setSource(jVar, i11);
        accessibilityNodeInfoObtain.setParent(jVar);
        accessibilityNodeInfoObtain.setText(str);
        accessibilityNodeInfoObtain.setClickable(true);
        accessibilityNodeInfoObtain.setLongClickable(true);
        accessibilityNodeInfoObtain.setEnabled(jVar.isEnabled());
        accessibilityNodeInfoObtain.setAccessibilityFocused(this.f22100c == i11);
        Rect rect = this.f22098a;
        rect.set(i12, i13, i14, i15);
        accessibilityNodeInfoObtain.setVisibleToUser(true);
        accessibilityNodeInfoObtain.setBoundsInParent(rect);
        int[] iArr = this.f22099b;
        jVar.getLocationOnScreen(iArr);
        rect.offset(iArr[0], iArr[1]);
        accessibilityNodeInfoObtain.setBoundsInScreen(rect);
        if (this.f22100c != i11) {
            accessibilityNodeInfoObtain.addAction(64);
        }
        if (this.f22100c == i11) {
            accessibilityNodeInfoObtain.addAction(128);
        }
        if (jVar.isEnabled()) {
            accessibilityNodeInfoObtain.addAction(16);
        }
        return accessibilityNodeInfoObtain;
    }

    public final void b(String str, int i11, ArrayList arrayList) {
        EditText editText = this.f22101d.f22119e;
        if (i11 == 1) {
            String strD = d();
            if (TextUtils.isEmpty(strD) || !strD.toString().toLowerCase().contains(str)) {
                return;
            }
            arrayList.add(createAccessibilityNodeInfo(1));
            return;
        }
        if (i11 != 2) {
            if (i11 != 3) {
                return;
            }
            String strC = c();
            if (TextUtils.isEmpty(strC) || !strC.toString().toLowerCase().contains(str)) {
                return;
            }
            arrayList.add(createAccessibilityNodeInfo(3));
            return;
        }
        Editable text = editText.getText();
        if (!TextUtils.isEmpty(text) && text.toString().toLowerCase().contains(str)) {
            arrayList.add(createAccessibilityNodeInfo(2));
            return;
        }
        Editable text2 = editText.getText();
        if (TextUtils.isEmpty(text2) || !text2.toString().toLowerCase().contains(str)) {
            return;
        }
        arrayList.add(createAccessibilityNodeInfo(2));
    }

    public final String c() {
        j jVar = this.f22101d;
        int iF = jVar.P - 1;
        if (jVar.f22134r0) {
            iF = jVar.f(iF);
        }
        int i11 = jVar.N;
        if (iF < i11) {
            return null;
        }
        String[] strArr = jVar.M;
        return strArr == null ? jVar.d(iF) : strArr[iF - i11];
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final AccessibilityNodeInfo createAccessibilityNodeInfo(int i11) {
        int[] iArr = this.f22099b;
        Rect rect = this.f22098a;
        j jVar = this.f22101d;
        if (i11 != -1) {
            if (i11 == 1) {
                return a(1, jVar.getScrollX(), jVar.A0 - jVar.f22138v0, (jVar.getRight() - jVar.getLeft()) + jVar.getScrollX(), (jVar.getBottom() - jVar.getTop()) + jVar.getScrollY(), d());
            }
            if (i11 != 2) {
                if (i11 != 3) {
                    return super.createAccessibilityNodeInfo(i11);
                }
                return a(3, jVar.getScrollX(), jVar.getScrollY(), (jVar.getRight() - jVar.getLeft()) + jVar.getScrollX(), jVar.f22138v0 + jVar.f22144z0, c());
            }
            int scrollX = jVar.getScrollX();
            int i12 = jVar.f22144z0 + jVar.f22138v0;
            int right = (jVar.getRight() - jVar.getLeft()) + jVar.getScrollX();
            int i13 = jVar.A0 - jVar.f22138v0;
            AccessibilityNodeInfo accessibilityNodeInfoCreateAccessibilityNodeInfo = jVar.f22119e.createAccessibilityNodeInfo();
            accessibilityNodeInfoCreateAccessibilityNodeInfo.setSource(jVar, 2);
            accessibilityNodeInfoCreateAccessibilityNodeInfo.setAccessibilityFocused(this.f22100c == 2);
            if (this.f22100c != 2) {
                accessibilityNodeInfoCreateAccessibilityNodeInfo.addAction(64);
            }
            if (this.f22100c == 2) {
                accessibilityNodeInfoCreateAccessibilityNodeInfo.addAction(128);
            }
            rect.set(scrollX, i12, right, i13);
            accessibilityNodeInfoCreateAccessibilityNodeInfo.setVisibleToUser(true);
            accessibilityNodeInfoCreateAccessibilityNodeInfo.setBoundsInParent(rect);
            jVar.getLocationOnScreen(iArr);
            rect.offset(iArr[0], iArr[1]);
            accessibilityNodeInfoCreateAccessibilityNodeInfo.setBoundsInScreen(rect);
            return accessibilityNodeInfoCreateAccessibilityNodeInfo;
        }
        int scrollX2 = jVar.getScrollX();
        int scrollY = jVar.getScrollY();
        int right2 = (jVar.getRight() - jVar.getLeft()) + jVar.getScrollX();
        int bottom = (jVar.getBottom() - jVar.getTop()) + jVar.getScrollY();
        AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain();
        accessibilityNodeInfoObtain.setClassName(j.class.getName());
        accessibilityNodeInfoObtain.setPackageName(jVar.getContext().getPackageName());
        accessibilityNodeInfoObtain.setSource(jVar);
        if (jVar.getWrapSelectorWheel() || jVar.getValue() > jVar.getMinValue()) {
            accessibilityNodeInfoObtain.addChild(jVar, 3);
        }
        accessibilityNodeInfoObtain.addChild(jVar, 2);
        if (jVar.getWrapSelectorWheel() || jVar.getValue() < jVar.getMaxValue()) {
            accessibilityNodeInfoObtain.addChild(jVar, 1);
        }
        accessibilityNodeInfoObtain.setParent((View) jVar.getParentForAccessibility());
        accessibilityNodeInfoObtain.setEnabled(jVar.isEnabled());
        accessibilityNodeInfoObtain.setScrollable(true);
        accessibilityNodeInfoObtain.setAccessibilityFocused(this.f22100c == -1);
        rect.set(scrollX2, scrollY, right2, bottom);
        accessibilityNodeInfoObtain.setBoundsInParent(rect);
        accessibilityNodeInfoObtain.setVisibleToUser(true);
        jVar.getLocationOnScreen(iArr);
        rect.offset(iArr[0], iArr[1]);
        accessibilityNodeInfoObtain.setBoundsInScreen(rect);
        if (this.f22100c != -1) {
            accessibilityNodeInfoObtain.addAction(64);
        }
        if (this.f22100c == -1) {
            accessibilityNodeInfoObtain.addAction(128);
        }
        if (jVar.isEnabled()) {
            if (jVar.getWrapSelectorWheel() || jVar.getValue() < jVar.getMaxValue()) {
                accessibilityNodeInfoObtain.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);
                accessibilityNodeInfoObtain.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN);
            }
            if (jVar.getWrapSelectorWheel() || jVar.getValue() > jVar.getMinValue()) {
                accessibilityNodeInfoObtain.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);
                accessibilityNodeInfoObtain.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP);
            }
        }
        return accessibilityNodeInfoObtain;
    }

    public final String d() {
        j jVar = this.f22101d;
        int iF = jVar.P + 1;
        if (jVar.f22134r0) {
            iF = jVar.f(iF);
        }
        if (iF > jVar.O) {
            return null;
        }
        String[] strArr = jVar.M;
        return strArr == null ? jVar.d(iF) : strArr[iF - jVar.N];
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void e(int i11, int i12, String str) {
        j jVar = this.f22101d;
        if (((AccessibilityManager) jVar.getContext().getSystemService("accessibility")).isEnabled()) {
            AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain(i12);
            accessibilityEventObtain.setClassName(Button.class.getName());
            accessibilityEventObtain.setPackageName(jVar.getContext().getPackageName());
            accessibilityEventObtain.getText().add(str);
            accessibilityEventObtain.setEnabled(jVar.isEnabled());
            accessibilityEventObtain.setSource(jVar, i11);
            jVar.requestSendAccessibilityEvent(jVar, accessibilityEventObtain);
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void f(int i11, int i12) {
        j jVar = this.f22101d;
        if (i11 == 1) {
            if (jVar.getWrapSelectorWheel() || jVar.getValue() < jVar.getMaxValue()) {
                e(i11, i12, d());
                return;
            }
            return;
        }
        if (i11 != 2) {
            if (i11 != 3) {
                return;
            }
            if (jVar.getWrapSelectorWheel() || jVar.getValue() > jVar.getMinValue()) {
                e(i11, i12, c());
                return;
            }
            return;
        }
        Context context = jVar.getContext();
        EditText editText = jVar.f22119e;
        if (((AccessibilityManager) context.getSystemService("accessibility")).isEnabled()) {
            AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain(i12);
            editText.onInitializeAccessibilityEvent(accessibilityEventObtain);
            editText.onPopulateAccessibilityEvent(accessibilityEventObtain);
            accessibilityEventObtain.setSource(jVar, 2);
            jVar.requestSendAccessibilityEvent(jVar, accessibilityEventObtain);
        }
    }

    @Override // android.view.accessibility.AccessibilityNodeProvider
    public final List findAccessibilityNodeInfosByText(String str, int i11) {
        if (TextUtils.isEmpty(str)) {
            return Collections.EMPTY_LIST;
        }
        String lowerCase = str.toLowerCase();
        ArrayList arrayList = new ArrayList();
        if (i11 == -1) {
            b(lowerCase, 3, arrayList);
            b(lowerCase, 2, arrayList);
            b(lowerCase, 1, arrayList);
            return arrayList;
        }
        if (i11 != 1 && i11 != 2 && i11 != 3) {
            return super.findAccessibilityNodeInfosByText(str, i11);
        }
        b(lowerCase, i11, arrayList);
        return arrayList;
    }

    /* JADX WARN: Code restructure failed: missing block: B:103:0x012d, code lost:
    
        if (r12 != 16908346) goto L104;
     */
    @Override // android.view.accessibility.AccessibilityNodeProvider
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean performAction(int r11, int r12, android.os.Bundle r13) {
        /*
            Method dump skipped, instruction units count: 378
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: mz.b.performAction(int, int, android.os.Bundle):boolean");
    }
}
