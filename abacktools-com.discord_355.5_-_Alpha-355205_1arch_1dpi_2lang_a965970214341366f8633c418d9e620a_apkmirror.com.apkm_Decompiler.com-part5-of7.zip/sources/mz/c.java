package mz;

/* JADX INFO: loaded from: classes3.dex */
public interface c {
}
