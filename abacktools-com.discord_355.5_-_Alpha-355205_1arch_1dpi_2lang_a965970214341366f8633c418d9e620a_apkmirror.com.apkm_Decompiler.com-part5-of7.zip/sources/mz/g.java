package mz;

import android.view.ViewConfiguration;

/* JADX INFO: loaded from: classes3.dex */
public final class g implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f22103d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f22104e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ j f22105i;

    public g(j jVar) {
        this.f22105i = jVar;
    }

    public final void a() {
        this.f22104e = 0;
        this.f22103d = 0;
        j jVar = this.f22105i;
        jVar.removeCallbacks(this);
        if (jVar.C0) {
            jVar.C0 = false;
            jVar.invalidate(0, jVar.A0, jVar.getRight(), jVar.getBottom());
        }
        jVar.D0 = false;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i11 = this.f22104e;
        j jVar = this.f22105i;
        if (i11 == 1) {
            int i12 = this.f22103d;
            if (i12 == 1) {
                jVar.C0 = true;
                jVar.invalidate(0, jVar.A0, jVar.getRight(), jVar.getBottom());
                return;
            } else {
                if (i12 != 2) {
                    return;
                }
                jVar.D0 = true;
                jVar.invalidate(0, 0, jVar.getRight(), jVar.f22144z0);
                return;
            }
        }
        if (i11 != 2) {
            return;
        }
        int i13 = this.f22103d;
        if (i13 == 1) {
            if (!jVar.C0) {
                jVar.postDelayed(this, ViewConfiguration.getPressedStateDuration());
            }
            jVar.C0 = !jVar.C0;
            jVar.invalidate(0, jVar.A0, jVar.getRight(), jVar.getBottom());
            return;
        }
        if (i13 != 2) {
            return;
        }
        if (!jVar.D0) {
            jVar.postDelayed(this, ViewConfiguration.getPressedStateDuration());
        }
        jVar.D0 = !jVar.D0;
        jVar.invalidate(0, 0, jVar.getRight(), jVar.f22144z0);
    }
}
