package mi;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.k;
import lq.g;

/* JADX INFO: loaded from: classes.dex */
public final class a extends g {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final /* synthetic */ int f21328i = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Function0 f21329d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Function0 f21330e;

    public final Function0 getOnAccessibilityBlur() {
        return this.f21330e;
    }

    public final Function0 getOnAccessibilityFocus() {
        return this.f21329d;
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEvent(int i11) {
        super.sendAccessibilityEvent(i11);
        if (i11 == 32768) {
            this.f21329d.invoke();
        } else {
            if (i11 != 65536) {
                return;
            }
            this.f21330e.invoke();
        }
    }

    public final void setOnAccessibilityBlur(Function0 function0) {
        k.g(function0, "<set-?>");
        this.f21330e = function0;
    }

    public final void setOnAccessibilityFocus(Function0 function0) {
        k.g(function0, "<set-?>");
        this.f21329d = function0;
    }
}
