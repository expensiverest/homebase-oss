package lv;

import android.os.Parcel;
import android.os.Parcelable;
import hu.p;

/* JADX INFO: loaded from: classes3.dex */
public final class f extends iu.a {
    public static final Parcelable.Creator<f> CREATOR = new fh.a(18);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f20676d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final eu.b f20677e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final p f20678i;

    public f(int i11, eu.b bVar, p pVar) {
        this.f20676d = i11;
        this.f20677e = bVar;
        this.f20678i = pVar;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        int iA0 = ow.a.a0(20293, parcel);
        ow.a.Z(parcel, 1, 4);
        parcel.writeInt(this.f20676d);
        ow.a.T(parcel, 2, this.f20677e, i11);
        ow.a.T(parcel, 3, this.f20678i, i11);
        ow.a.c0(iA0, parcel);
    }
}
