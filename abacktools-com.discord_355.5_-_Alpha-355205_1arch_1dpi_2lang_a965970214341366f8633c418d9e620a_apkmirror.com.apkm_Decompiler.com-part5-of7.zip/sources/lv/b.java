package lv;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import fu.o;

/* JADX INFO: loaded from: classes3.dex */
public final class b extends iu.a implements o {
    public static final Parcelable.Creator<b> CREATOR = new fh.a(16);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f20671d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f20672e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Intent f20673i;

    public b(int i11, int i12, Intent intent) {
        this.f20671d = i11;
        this.f20672e = i12;
        this.f20673i = intent;
    }

    @Override // fu.o
    public final Status b() {
        return this.f20672e == 0 ? Status.f6375w : Status.K;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        int iA0 = ow.a.a0(20293, parcel);
        ow.a.Z(parcel, 1, 4);
        parcel.writeInt(this.f20671d);
        ow.a.Z(parcel, 2, 4);
        parcel.writeInt(this.f20672e);
        ow.a.T(parcel, 3, this.f20673i, i11);
        ow.a.c0(iA0, parcel);
    }
}
