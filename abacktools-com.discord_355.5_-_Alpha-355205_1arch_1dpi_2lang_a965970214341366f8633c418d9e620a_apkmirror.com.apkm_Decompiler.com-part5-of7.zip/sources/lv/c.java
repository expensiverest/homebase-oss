package lv;

import android.os.Parcel;
import av.i;
import com.google.android.gms.internal.play_billing.t0;
import gu.x;

/* JADX INFO: loaded from: classes3.dex */
public abstract class c extends i {
    @Override // av.i
    public final boolean A(int i11, Parcel parcel, Parcel parcel2) {
        switch (i11) {
            case 3:
                cv.a.b(parcel);
                break;
            case 4:
                cv.a.b(parcel);
                break;
            case 5:
            default:
                return false;
            case 6:
                cv.a.b(parcel);
                break;
            case 7:
                cv.a.b(parcel);
                break;
            case 8:
                f fVar = (f) cv.a.a(parcel, f.CREATOR);
                cv.a.b(parcel);
                x xVar = (x) this;
                xVar.f13574h.post(new t0(xVar, fVar, 14, false));
                break;
            case 9:
                cv.a.b(parcel);
                break;
        }
        parcel2.writeNoException();
        return true;
    }
}
