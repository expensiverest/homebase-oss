package lv;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import b80.i0;
import fu.j;
import fu.k;

/* JADX INFO: loaded from: classes3.dex */
public final class a extends hu.f implements fu.c {
    public final i0 A;
    public final Bundle B;
    public final Integer C;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final boolean f20670z;

    public a(Context context, Looper looper, i0 i0Var, Bundle bundle, j jVar, k kVar) {
        super(context, looper, 44, i0Var, jVar, kVar, 0);
        this.f20670z = true;
        this.A = i0Var;
        this.B = bundle;
        this.C = (Integer) i0Var.y;
    }

    @Override // hu.c, fu.c
    public final int a() {
        return 12451000;
    }

    @Override // hu.c, fu.c
    public final boolean b() {
        return this.f20670z;
    }

    @Override // hu.c
    public final IInterface c(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.signin.internal.ISignInService");
        return iInterfaceQueryLocalInterface instanceof d ? (d) iInterfaceQueryLocalInterface : new d(iBinder, "com.google.android.gms.signin.internal.ISignInService", 3);
    }

    @Override // hu.c
    public final Bundle g() {
        i0 i0Var = this.A;
        boolean zEquals = this.f14548c.getPackageName().equals((String) i0Var.f3156e);
        Bundle bundle = this.B;
        if (!zEquals) {
            bundle.putString("com.google.android.gms.signin.internal.realClientPackageName", (String) i0Var.f3156e);
        }
        return bundle;
    }

    @Override // hu.c
    public final String j() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }

    @Override // hu.c
    public final String k() {
        return "com.google.android.gms.signin.service.START";
    }
}
