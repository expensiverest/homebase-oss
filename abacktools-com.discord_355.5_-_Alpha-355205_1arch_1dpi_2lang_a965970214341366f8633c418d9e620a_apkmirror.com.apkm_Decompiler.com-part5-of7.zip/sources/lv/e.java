package lv;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import fu.o;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class e extends iu.a implements o {
    public static final Parcelable.Creator<e> CREATOR = new fh.a(17);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f20674d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f20675e;

    public e(String str, ArrayList arrayList) {
        this.f20674d = arrayList;
        this.f20675e = str;
    }

    @Override // fu.o
    public final Status b() {
        return this.f20675e != null ? Status.f6375w : Status.K;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        int iA0 = ow.a.a0(20293, parcel);
        ow.a.V(parcel, 1, this.f20674d);
        ow.a.U(parcel, 2, this.f20675e);
        ow.a.c0(iA0, parcel);
    }
}
