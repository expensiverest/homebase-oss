package ly;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f20697a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f20698b;

    public b(Set set, c cVar) {
        this.f20697a = b(set);
        this.f20698b = cVar;
    }

    public static String b(Set set) {
        StringBuilder sb2 = new StringBuilder();
        Iterator it = set.iterator();
        while (it.hasNext()) {
            a aVar = (a) it.next();
            sb2.append(aVar.f20695a);
            sb2.append('/');
            sb2.append(aVar.f20696b);
            if (it.hasNext()) {
                sb2.append(' ');
            }
        }
        return sb2.toString();
    }

    public final String a() {
        Set setUnmodifiableSet;
        Set setUnmodifiableSet2;
        String str = this.f20697a;
        c cVar = this.f20698b;
        synchronized (cVar.f20700a) {
            setUnmodifiableSet = Collections.unmodifiableSet(cVar.f20700a);
        }
        if (setUnmodifiableSet.isEmpty()) {
            return str;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append(' ');
        synchronized (cVar.f20700a) {
            setUnmodifiableSet2 = Collections.unmodifiableSet(cVar.f20700a);
        }
        sb2.append(b(setUnmodifiableSet2));
        return sb2.toString();
    }
}
