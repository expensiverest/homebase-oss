package ly;

import com.google.android.gms.internal.fido.nb;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f20695a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f20696b;

    public a(String str, String str2) {
        this.f20695a = str;
        if (str2 == null) {
            throw new NullPointerException("Null version");
        }
        this.f20696b = str2;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof a) {
            a aVar = (a) obj;
            if (this.f20695a.equals(aVar.f20695a) && this.f20696b.equals(aVar.f20696b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.f20695a.hashCode() ^ 1000003) * 1000003) ^ this.f20696b.hashCode();
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("LibraryVersion{libraryName=");
        sb2.append(this.f20695a);
        sb2.append(", version=");
        return nb.o(sb2, this.f20696b, "}");
    }
}
