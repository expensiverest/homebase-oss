package ly;

import java.util.HashSet;

/* JADX INFO: loaded from: classes3.dex */
public final class c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static volatile c f20699b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashSet f20700a;

    public c(int i11) {
        switch (i11) {
            case 1:
                this.f20700a = new HashSet();
                break;
            default:
                this.f20700a = new HashSet();
                break;
        }
    }
}
