package ly;

import android.content.Context;

/* JADX INFO: loaded from: classes3.dex */
public interface d {
    String c(Context context);
}
