package mw;

import android.graphics.Paint;
import android.graphics.Path;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final int[] f22037i = new int[3];

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final float[] f22038j = {0.0f, 0.5f, 1.0f};
    public static final int[] k = new int[4];
    public static final float[] l = {0.0f, 0.0f, 0.5f, 1.0f};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint f22039a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Paint f22040b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Paint f22041c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f22042d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f22043e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f22044f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Path f22045g = new Path();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Paint f22046h;

    public a() {
        Paint paint = new Paint();
        this.f22046h = paint;
        this.f22039a = new Paint();
        a(-16777216);
        paint.setColor(0);
        Paint paint2 = new Paint(4);
        this.f22040b = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.f22041c = new Paint(paint2);
    }

    public final void a(int i11) {
        this.f22042d = i1.a.e(i11, 68);
        this.f22043e = i1.a.e(i11, 20);
        this.f22044f = i1.a.e(i11, 0);
        this.f22039a.setColor(this.f22042d);
    }
}
