package n3;

import android.os.SystemClock;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e0 f22334a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f22335b;

    public i() {
        this(e0.f22318a);
    }

    public final synchronized void a() {
        while (!this.f22335b) {
            this.f22334a.getClass();
            wait();
        }
    }

    public final synchronized boolean b(long j6) {
        try {
            if (j6 <= 0) {
                return this.f22335b;
            }
            this.f22334a.getClass();
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            long j11 = j6 + jElapsedRealtime;
            if (j11 < jElapsedRealtime) {
                a();
            } else {
                while (!this.f22335b && jElapsedRealtime < j11) {
                    this.f22334a.getClass();
                    wait(j11 - jElapsedRealtime);
                    this.f22334a.getClass();
                    jElapsedRealtime = SystemClock.elapsedRealtime();
                }
            }
            return this.f22335b;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized void c() {
        boolean z11 = false;
        while (!this.f22335b) {
            try {
                this.f22334a.getClass();
                wait();
            } catch (InterruptedException unused) {
                z11 = true;
            }
        }
        if (z11) {
            Thread.currentThread().interrupt();
        }
    }

    public final synchronized boolean d(long j6) {
        try {
            if (j6 <= 0) {
                return this.f22335b;
            }
            this.f22334a.getClass();
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            long j11 = j6 + jElapsedRealtime;
            if (j11 < jElapsedRealtime) {
                c();
            } else {
                boolean z11 = false;
                while (!this.f22335b && jElapsedRealtime < j11) {
                    try {
                        this.f22334a.getClass();
                        wait(j11 - jElapsedRealtime);
                    } catch (InterruptedException unused) {
                        z11 = true;
                    }
                    this.f22334a.getClass();
                    jElapsedRealtime = SystemClock.elapsedRealtime();
                }
                if (z11) {
                    Thread.currentThread().interrupt();
                }
            }
            return this.f22335b;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized void e() {
        this.f22335b = false;
    }

    public final synchronized boolean f() {
        if (this.f22335b) {
            return false;
        }
        this.f22335b = true;
        notifyAll();
        return true;
    }

    public i(e0 e0Var) {
        this.f22334a = e0Var;
    }
}
