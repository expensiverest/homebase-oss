package n3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: loaded from: classes.dex */
public final class a extends OutputStream {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f22288d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final FileOutputStream f22289e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f22290i;

    public a(File file, int i11) {
        this.f22288d = i11;
        switch (i11) {
            case 1:
                this.f22290i = false;
                this.f22289e = new FileOutputStream(file);
                break;
            default:
                this.f22290i = false;
                this.f22289e = new FileOutputStream(file);
                break;
        }
    }

    @Override // java.io.OutputStream, java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        switch (this.f22288d) {
            case 0:
                FileOutputStream fileOutputStream = this.f22289e;
                if (!this.f22290i) {
                    this.f22290i = true;
                    flush();
                    try {
                        fileOutputStream.getFD().sync();
                    } catch (IOException e4) {
                        b.m("AtomicFile", "Failed to sync file descriptor:", e4);
                    }
                    fileOutputStream.close();
                    break;
                }
                break;
            default:
                FileOutputStream fileOutputStream2 = this.f22289e;
                if (!this.f22290i) {
                    this.f22290i = true;
                    flush();
                    try {
                        fileOutputStream2.getFD().sync();
                    } catch (IOException e9) {
                        qt.a.O("AtomicFile", "Failed to sync file descriptor:", e9);
                    }
                    fileOutputStream2.close();
                    break;
                }
                break;
        }
    }

    @Override // java.io.OutputStream, java.io.Flushable
    public final void flush() throws IOException {
        switch (this.f22288d) {
            case 0:
                this.f22289e.flush();
                break;
            default:
                this.f22289e.flush();
                break;
        }
    }

    @Override // java.io.OutputStream
    public final void write(int i11) throws IOException {
        switch (this.f22288d) {
            case 0:
                this.f22289e.write(i11);
                break;
            default:
                this.f22289e.write(i11);
                break;
        }
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr) throws IOException {
        switch (this.f22288d) {
            case 0:
                this.f22289e.write(bArr);
                break;
            default:
                this.f22289e.write(bArr);
                break;
        }
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr, int i11, int i12) throws IOException {
        switch (this.f22288d) {
            case 0:
                this.f22289e.write(bArr, i11, i12);
                break;
            default:
                this.f22289e.write(bArr, i11, i12);
                break;
        }
    }
}
