package n3;

import android.os.SystemClock;
import com.google.android.gms.internal.fido.f6;
import java.util.Objects;
import k3.k1;
import k3.n1;

/* JADX INFO: loaded from: classes.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f22301a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f22302b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f22303c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f22304d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f22305e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f22306f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ f6 f22307g;

    public b0(f6 f6Var, int i11) {
        this.f22307g = f6Var;
        this.f22301a = i11;
    }

    public final void a() {
        long duration;
        f6 f6Var = this.f22307g;
        k1 k1Var = (k1) f6Var.f6581w;
        g0 g0Var = (g0) f6Var.f6582x;
        v3.w wVar = (v3.w) f6Var.f6577d;
        n1 n1VarU = wVar.U();
        Object objL = n1VarU.p() ? null : n1VarU.l(wVar.t());
        int iO = wVar.O();
        int iX = wVar.x();
        long jB0 = wVar.b0();
        if (objL == null || iO != -1) {
            duration = iO != -1 ? wVar.getDuration() : -9223372036854775807L;
        } else {
            n1VarU.g(objL, k1Var);
            jB0 -= l0.g0(k1Var.f18673e);
            duration = l0.g0(k1Var.f18672d);
        }
        boolean zK = wVar.K();
        if (!zK || duration == -9223372036854775807L || jB0 < duration) {
            g0Var.g(3);
            if (zK && duration != -9223372036854775807L) {
                g0Var.f22329a.sendEmptyMessageDelayed(3, (int) Math.ceil((duration - jB0) / wVar.e().f19039a));
            }
            this.f22305e = false;
            return;
        }
        ((e0) f6Var.f6580v).getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        boolean z11 = this.f22305e;
        int i11 = this.f22301a;
        if (z11 && Objects.equals(objL, this.f22302b) && iO == this.f22303c && iX == this.f22304d) {
            if (jElapsedRealtime - this.f22306f >= i11) {
                ((v3.q) f6Var.f6579i).f32084d.c3(new v3.i(2, new d0(3, i11), 1003));
                return;
            }
            return;
        }
        this.f22305e = true;
        this.f22306f = jElapsedRealtime;
        this.f22302b = objL;
        this.f22303c = iO;
        this.f22304d = iX;
        g0Var.g(3);
        g0Var.f22329a.sendEmptyMessageDelayed(3, i11);
    }
}
