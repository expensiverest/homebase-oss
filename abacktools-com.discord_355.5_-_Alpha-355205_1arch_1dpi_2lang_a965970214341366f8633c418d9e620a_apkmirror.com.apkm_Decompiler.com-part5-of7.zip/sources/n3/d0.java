package n3;

import p.x2;

/* JADX INFO: loaded from: classes.dex */
public final class d0 extends IllegalStateException {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f22316d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f22317e;

    /* JADX WARN: Illegal instructions before constructor call */
    public d0(int i11, int i12) {
        String strE;
        if (i11 == 0) {
            strE = x2.e(i12, "Player stuck buffering and not loading for ", " ms");
        } else if (i11 == 1) {
            strE = x2.e(i12, "Player stuck buffering with no progress for ", " ms");
        } else if (i11 == 2) {
            strE = x2.e(i12, "Player stuck playing with no progress for ", " ms");
        } else if (i11 == 3) {
            strE = x2.e(i12, "Player stuck playing without ending for ", " ms");
        } else {
            if (i11 != 4) {
                throw new IllegalStateException();
            }
            strE = x2.e(i12, "Player stuck suppressed for ", " ms");
        }
        super(strE);
        this.f22316d = i11;
        this.f22317e = i12;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || d0.class != obj.getClass()) {
            return false;
        }
        d0 d0Var = (d0) obj;
        return this.f22316d == d0Var.f22316d && this.f22317e == d0Var.f22317e;
    }

    public final int hashCode() {
        return ((527 + this.f22316d) * 31) + this.f22317e;
    }
}
