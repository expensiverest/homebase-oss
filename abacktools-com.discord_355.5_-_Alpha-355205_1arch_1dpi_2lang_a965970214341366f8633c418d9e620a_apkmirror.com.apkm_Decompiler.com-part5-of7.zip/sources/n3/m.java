package n3;

import hx.w1;

/* JADX INFO: loaded from: classes.dex */
public final class m extends Exception {
    public m(String str, w1 w1Var) {
        super(str);
        hx.m0.q(w1Var);
    }
}
