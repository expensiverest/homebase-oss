package n3;

import android.R;
import android.util.Pair;
import app.p001rive.runtime.kotlin.renderers.RendererMetrics;
import app.p001rive.semantics.SemanticState;
import com.appsflyer.attribution.RequestError;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import k3.u0;
import org.webrtc.PeerConnection;

/* JADX INFO: loaded from: classes.dex */
public abstract class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final byte[] f22324a = {0, 0, 0, 1};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String[] f22325b = {"", "A", "B", "C"};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Pattern f22326c = Pattern.compile("^\\D?(\\d+)$");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final byte[] f22327d = {-75, 0, -112, 0, 1};

    public static String a(int i11, boolean z11, int i12, int i13, int[] iArr, int i14) {
        Object[] objArr = {f22325b[i11], Integer.valueOf(i12), Integer.valueOf(i13), Character.valueOf(z11 ? 'H' : 'L'), Integer.valueOf(i14)};
        String str = l0.f22358a;
        StringBuilder sb2 = new StringBuilder(String.format(Locale.US, "hvc1.%s%d.%X.%c%d", objArr));
        int length = iArr.length;
        while (length > 0 && iArr[length - 1] == 0) {
            length--;
        }
        for (int i15 = 0; i15 < length; i15++) {
            sb2.append(String.format(".%02X", Integer.valueOf(iArr[i15])));
        }
        return sb2.toString();
    }

    public static Pair b(k3.w wVar) {
        boolean z11;
        f fVarD = d(wVar);
        if (fVarD == null || !(z11 = fVarD.f22322c)) {
            return null;
        }
        oq.a.z(z11);
        Integer numValueOf = Integer.valueOf(fVarD.f22320a);
        oq.a.z(z11);
        return new Pair(numValueOf, Integer.valueOf(fVarD.f22321b));
    }

    public static f c(String str, String[] strArr, k3.m mVar) {
        int i11;
        Integer numValueOf = null;
        if (strArr.length < 4) {
            hs.q.y("Ignoring malformed HEVC codec string: ", str, "CodecSpecificDataUtil");
            return null;
        }
        Matcher matcher = f22326c.matcher(strArr[1]);
        if (!matcher.matches()) {
            hs.q.y("Ignoring malformed HEVC codec string: ", str, "CodecSpecificDataUtil");
            return null;
        }
        String strGroup = matcher.group(1);
        boolean zEquals = "1".equals(strGroup);
        byte b11 = 6;
        f fVar = f.f22319d;
        if (zEquals) {
            i11 = 1;
        } else {
            if (!"2".equals(strGroup)) {
                hs.q.y("Unknown HEVC profile string: ", strGroup, "CodecSpecificDataUtil");
                return fVar;
            }
            i11 = (mVar == null || mVar.f18694c != 6) ? 2 : 4096;
        }
        String str2 = strArr[3];
        str2.getClass();
        switch (str2.hashCode()) {
            case 70821:
                b11 = !str2.equals("H30") ? (byte) -1 : (byte) 0;
                break;
            case 70914:
                b11 = !str2.equals("H60") ? (byte) -1 : (byte) 1;
                break;
            case 70917:
                b11 = !str2.equals("H63") ? (byte) -1 : (byte) 2;
                break;
            case 71007:
                b11 = !str2.equals("H90") ? (byte) -1 : (byte) 3;
                break;
            case 71010:
                b11 = !str2.equals("H93") ? (byte) -1 : (byte) 4;
                break;
            case 74665:
                b11 = !str2.equals("L30") ? (byte) -1 : (byte) 5;
                break;
            case 74758:
                if (!str2.equals("L60")) {
                    b11 = -1;
                }
                break;
            case 74761:
                b11 = !str2.equals("L63") ? (byte) -1 : (byte) 7;
                break;
            case 74851:
                b11 = !str2.equals("L90") ? (byte) -1 : (byte) 8;
                break;
            case 74854:
                b11 = !str2.equals("L93") ? (byte) -1 : (byte) 9;
                break;
            case 2193639:
                b11 = !str2.equals("H120") ? (byte) -1 : (byte) 10;
                break;
            case 2193642:
                b11 = !str2.equals("H123") ? (byte) -1 : (byte) 11;
                break;
            case 2193732:
                b11 = !str2.equals("H150") ? (byte) -1 : (byte) 12;
                break;
            case 2193735:
                b11 = !str2.equals("H153") ? (byte) -1 : (byte) 13;
                break;
            case 2193738:
                b11 = !str2.equals("H156") ? (byte) -1 : (byte) 14;
                break;
            case 2193825:
                b11 = !str2.equals("H180") ? (byte) -1 : (byte) 15;
                break;
            case 2193828:
                b11 = !str2.equals("H183") ? (byte) -1 : (byte) 16;
                break;
            case 2193831:
                b11 = !str2.equals("H186") ? (byte) -1 : (byte) 17;
                break;
            case 2312803:
                b11 = !str2.equals("L120") ? (byte) -1 : (byte) 18;
                break;
            case 2312806:
                b11 = !str2.equals("L123") ? (byte) -1 : (byte) 19;
                break;
            case 2312896:
                b11 = !str2.equals("L150") ? (byte) -1 : (byte) 20;
                break;
            case 2312899:
                b11 = !str2.equals("L153") ? (byte) -1 : (byte) 21;
                break;
            case 2312902:
                b11 = !str2.equals("L156") ? (byte) -1 : (byte) 22;
                break;
            case 2312989:
                b11 = !str2.equals("L180") ? (byte) -1 : (byte) 23;
                break;
            case 2312992:
                b11 = !str2.equals("L183") ? (byte) -1 : (byte) 24;
                break;
            case 2312995:
                b11 = !str2.equals("L186") ? (byte) -1 : (byte) 25;
                break;
            default:
                b11 = -1;
                break;
        }
        switch (b11) {
            case 0:
                numValueOf = 2;
                break;
            case 1:
                numValueOf = 8;
                break;
            case 2:
                numValueOf = 32;
                break;
            case 3:
                numValueOf = 128;
                break;
            case 4:
                numValueOf = 512;
                break;
            case 5:
                numValueOf = 1;
                break;
            case 6:
                numValueOf = 4;
                break;
            case 7:
                numValueOf = 16;
                break;
            case 8:
                numValueOf = 64;
                break;
            case 9:
                numValueOf = 256;
                break;
            case 10:
                numValueOf = Integer.valueOf(SemanticState.Modal);
                break;
            case 11:
                numValueOf = Integer.valueOf(SemanticState.Multiline);
                break;
            case 12:
                numValueOf = Integer.valueOf(PeerConnection.PORTALLOCATOR_ENABLE_ANY_ADDRESS_PORTS);
                break;
            case 13:
                numValueOf = 131072;
                break;
            case 14:
                numValueOf = 524288;
                break;
            case 15:
                numValueOf = 2097152;
                break;
            case 16:
                numValueOf = 8388608;
                break;
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                numValueOf = 33554432;
                break;
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                numValueOf = 1024;
                break;
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                numValueOf = Integer.valueOf(SemanticState.Obscured);
                break;
            case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                numValueOf = 16384;
                break;
            case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                numValueOf = 65536;
                break;
            case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                numValueOf = 262144;
                break;
            case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                numValueOf = 1048576;
                break;
            case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                numValueOf = 4194304;
                break;
            case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                numValueOf = 16777216;
                break;
        }
        if (numValueOf != null) {
            return new f(i11, numValueOf.intValue(), true);
        }
        b.l("CodecSpecificDataUtil", "Unknown HEVC level string: ".concat(str2));
        return fVar;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:154:0x0243  */
    /* JADX WARN: Code duplicated, block: B:17:0x00a2  */
    /* JADX WARN: Code duplicated, block: B:230:0x032e  */
    /* JADX WARN: Code duplicated, block: B:411:0x0585  */
    /* JADX WARN: Code duplicated, block: B:413:0x058b  */
    /* JADX WARN: Code duplicated, block: B:509:0x06b1  */
    /* JADX WARN: Code duplicated, block: B:80:0x0159  */
    /* JADX WARN: Code duplicated, block: B:880:0x0b59  */
    public static f d(k3.w wVar) {
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i21;
        int i22;
        int i23;
        int i24;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        byte b11;
        Integer num;
        Integer numValueOf = 1024;
        Integer numValueOf2 = Integer.valueOf(SemanticState.Modal);
        Integer numValueOf3 = Integer.valueOf(SemanticState.Obscured);
        String str = wVar.l;
        String str2 = wVar.l;
        if (str == null) {
            return null;
        }
        String[] strArrSplit = str.split("\\.");
        boolean zEquals = "video/dolby-vision".equals(wVar.f19012p);
        f fVar = f.f22319d;
        if (zEquals) {
            if (strArrSplit.length < 3) {
                hs.q.y("Ignoring malformed Dolby Vision codec string: ", str2, "CodecSpecificDataUtil");
                return null;
            }
            Matcher matcher = f22326c.matcher(strArrSplit[1]);
            if (!matcher.matches()) {
                hs.q.y("Ignoring malformed Dolby Vision codec string: ", str2, "CodecSpecificDataUtil");
                return null;
            }
            String strGroup = matcher.group(1);
            strGroup.getClass();
            switch (strGroup) {
                case "00":
                    num = 1;
                    break;
                case "01":
                    num = 2;
                    break;
                case "02":
                    num = 4;
                    break;
                case "03":
                    num = 8;
                    break;
                case "04":
                    num = 16;
                    break;
                case "05":
                    num = 32;
                    break;
                case "06":
                    num = 64;
                    break;
                case "07":
                    num = 128;
                    break;
                case "08":
                    num = 256;
                    break;
                case "09":
                    num = 512;
                    break;
                case "10":
                    num = numValueOf;
                    break;
                default:
                    num = null;
                    break;
            }
            if (num == null) {
                b.l("CodecSpecificDataUtil", "Unknown Dolby Vision profile string: ".concat(strGroup));
                return fVar;
            }
            String str3 = strArrSplit[2];
            str3.getClass();
            switch (str3) {
                case "01":
                    numValueOf = 1;
                    break;
                case "02":
                    numValueOf = 2;
                    break;
                case "03":
                    numValueOf = 4;
                    break;
                case "04":
                    numValueOf = 8;
                    break;
                case "05":
                    numValueOf = 16;
                    break;
                case "06":
                    numValueOf = 32;
                    break;
                case "07":
                    numValueOf = 64;
                    break;
                case "08":
                    numValueOf = 128;
                    break;
                case "09":
                    numValueOf = 256;
                    break;
                case "10":
                    numValueOf = 512;
                    break;
                case "11":
                    break;
                case "12":
                    numValueOf = numValueOf2;
                    break;
                case "13":
                    numValueOf = numValueOf3;
                    break;
                default:
                    numValueOf = null;
                    break;
            }
            if (numValueOf != null) {
                return new f(num.intValue(), numValueOf.intValue(), true);
            }
            b.l("CodecSpecificDataUtil", "Unknown Dolby Vision level string: ".concat(str3));
            return null;
        }
        String str4 = strArrSplit[0];
        str4.getClass();
        switch (str4) {
            case "ac-4":
                int i31 = 8;
                if (strArrSplit.length != 4) {
                    hs.q.y("Ignoring malformed AC-4 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i32 = Integer.parseInt(strArrSplit[1]);
                    int i33 = Integer.parseInt(strArrSplit[2]);
                    int i34 = Integer.parseInt(strArrSplit[3]);
                    if (i32 != 0) {
                        if (i32 != 1) {
                            if (i32 != 2) {
                                i11 = -1;
                            } else if (i33 == 1) {
                                i11 = 1026;
                            } else if (i33 == 2) {
                                i11 = 1028;
                            } else {
                                i11 = -1;
                            }
                        } else if (i33 == 0) {
                            i11 = 513;
                        } else if (i33 == 1) {
                            i11 = 514;
                        } else {
                            i11 = -1;
                        }
                    } else if (i33 == 0) {
                        i11 = 257;
                    } else {
                        i11 = -1;
                    }
                    if (i11 == -1) {
                        b.l("CodecSpecificDataUtil", "Unknown AC-4 profile: " + i32 + "." + i33);
                        return fVar;
                    }
                    if (i34 == 0) {
                        i31 = 1;
                    } else if (i34 == 1) {
                        i31 = 2;
                    } else if (i34 == 2) {
                        i31 = 4;
                    } else if (i34 != 3) {
                        i31 = i34 != 4 ? -1 : 16;
                    }
                    if (i31 != -1) {
                        return new f(i11, i31, true);
                    }
                    hs.q.r(i34, "Unknown AC-4 level: ", "CodecSpecificDataUtil");
                    return fVar;
                } catch (NumberFormatException unused) {
                    hs.q.y("Ignoring malformed AC-4 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
            case "apv1":
                if (strArrSplit.length < 4) {
                    hs.q.y("Ignoring malformed APV codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i35 = Integer.parseInt(strArrSplit[1].substring(4));
                    int i36 = Integer.parseInt(strArrSplit[2].substring(4));
                    int i37 = Integer.parseInt(strArrSplit[3].substring(4));
                    if (i35 == 33) {
                        i12 = 1;
                    } else {
                        if (i35 != 44) {
                            hs.q.r(i35, "Unrecognized APV profile: ", "CodecSpecificDataUtil");
                            return fVar;
                        }
                        i12 = 8192;
                    }
                    switch (i36) {
                        case RendererMetrics.SAMPLES /* 30 */:
                            if (i37 == 0) {
                                i13 = 257;
                            } else if (i37 == 1) {
                                i13 = 258;
                            } else if (i37 == 2) {
                                i13 = 260;
                            } else if (i37 == 3) {
                                i13 = 264;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 33:
                            if (i37 == 0) {
                                i13 = 513;
                            } else if (i37 == 1) {
                                i13 = 514;
                            } else if (i37 == 2) {
                                i13 = 516;
                            } else if (i37 == 3) {
                                i13 = 520;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 60:
                            if (i37 == 0) {
                                i13 = 1025;
                            } else if (i37 == 1) {
                                i13 = 1026;
                            } else if (i37 == 2) {
                                i13 = 1028;
                            } else if (i37 == 3) {
                                i13 = 1032;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 63:
                            if (i37 == 0) {
                                i13 = 2049;
                            } else if (i37 == 1) {
                                i13 = 2050;
                            } else if (i37 == 2) {
                                i13 = 2052;
                            } else if (i37 == 3) {
                                i13 = 2056;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 90:
                            if (i37 == 0) {
                                i13 = 4097;
                            } else if (i37 == 1) {
                                i13 = 4098;
                            } else if (i37 == 2) {
                                i13 = 4100;
                            } else if (i37 == 3) {
                                i13 = 4104;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 93:
                            if (i37 == 0) {
                                i13 = 8193;
                            } else if (i37 == 1) {
                                i13 = 8194;
                            } else if (i37 == 2) {
                                i13 = 8196;
                            } else if (i37 == 3) {
                                i13 = 8200;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 120:
                            if (i37 == 0) {
                                i13 = 16385;
                            } else if (i37 == 1) {
                                i13 = 16386;
                            } else if (i37 == 2) {
                                i13 = 16388;
                            } else if (i37 == 3) {
                                i13 = 16392;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 123:
                            if (i37 == 0) {
                                i13 = 32769;
                            } else if (i37 == 1) {
                                i13 = 32770;
                            } else if (i37 == 2) {
                                i13 = 32772;
                            } else if (i37 == 3) {
                                i13 = 32776;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 150:
                            if (i37 == 0) {
                                i13 = 65537;
                            } else if (i37 == 1) {
                                i13 = 65538;
                            } else if (i37 == 2) {
                                i13 = 65540;
                            } else if (i37 == 3) {
                                i13 = 65544;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 153:
                            if (i37 == 0) {
                                i13 = 131073;
                            } else if (i37 == 1) {
                                i13 = 131074;
                            } else if (i37 == 2) {
                                i13 = 131076;
                            } else if (i37 == 3) {
                                i13 = 131080;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 180:
                            if (i37 == 0) {
                                i13 = 262145;
                            } else if (i37 == 1) {
                                i13 = 262146;
                            } else if (i37 == 2) {
                                i13 = 262148;
                            } else if (i37 == 3) {
                                i13 = 262152;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 183:
                            if (i37 == 0) {
                                i13 = 524289;
                            } else if (i37 == 1) {
                                i13 = 524290;
                            } else if (i37 == 2) {
                                i13 = 524292;
                            } else if (i37 == 3) {
                                i13 = 524296;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 210:
                            if (i37 == 0) {
                                i13 = 1048577;
                            } else if (i37 == 1) {
                                i13 = 1048578;
                            } else if (i37 == 2) {
                                i13 = 1048580;
                            } else if (i37 == 3) {
                                i13 = 1048584;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        case 213:
                            if (i37 == 0) {
                                i13 = 2097153;
                            } else if (i37 == 1) {
                                i13 = 2097154;
                            } else if (i37 == 2) {
                                i13 = 2097156;
                            } else if (i37 == 3) {
                                i13 = 2097160;
                            } else {
                                hs.q.r(i37, "Unrecognized APV band: ", "CodecSpecificDataUtil");
                                i13 = -1;
                            }
                            break;
                        default:
                            hs.q.r(i36, "Unrecognized APV level index: ", "CodecSpecificDataUtil");
                            i13 = -1;
                            break;
                    }
                    return i13 == -1 ? fVar : new f(i12, i13, true);
                } catch (NumberFormatException e4) {
                    b.m("CodecSpecificDataUtil", "Ignoring malformed APV codec string: " + str2, e4);
                    return null;
                }
            case "av01":
                k3.m mVar = wVar.H;
                if (strArrSplit.length < 4) {
                    hs.q.y("Ignoring malformed AV1 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i38 = Integer.parseInt(strArrSplit[1]);
                    int i39 = Integer.parseInt(strArrSplit[2].substring(0, 2));
                    int i40 = Integer.parseInt(strArrSplit[3]);
                    if (i38 != 0) {
                        hs.q.r(i38, "Unknown AV1 profile: ", "CodecSpecificDataUtil");
                        return fVar;
                    }
                    int i41 = 8;
                    if (i40 != 8 && i40 != 10) {
                        hs.q.r(i40, "Unknown AV1 bit depth: ", "CodecSpecificDataUtil");
                        return fVar;
                    }
                    int i42 = i40 == 8 ? 1 : (mVar == null || !(mVar.f18695d != null || (i14 = mVar.f18694c) == 7 || i14 == 6)) ? 2 : SemanticState.Obscured;
                    switch (i39) {
                        case 0:
                            i41 = 1;
                            break;
                        case 1:
                            i41 = 2;
                            break;
                        case 2:
                            i41 = 4;
                            break;
                        case 3:
                            break;
                        case 4:
                            i41 = 16;
                            break;
                        case 5:
                            i41 = 32;
                            break;
                        case 6:
                            i41 = 64;
                            break;
                        case 7:
                            i41 = 128;
                            break;
                        case 8:
                            i41 = 256;
                            break;
                        case 9:
                            i41 = 512;
                            break;
                        case 10:
                            i41 = 1024;
                            break;
                        case 11:
                            i41 = SemanticState.Modal;
                            break;
                        case 12:
                            i41 = SemanticState.Obscured;
                            break;
                        case 13:
                            i41 = 8192;
                            break;
                        case 14:
                            i41 = 16384;
                            break;
                        case 15:
                            i41 = 32768;
                            break;
                        case 16:
                            i41 = 65536;
                            break;
                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                            i41 = 131072;
                            break;
                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                            i41 = 262144;
                            break;
                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                            i41 = 524288;
                            break;
                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                            i41 = 1048576;
                            break;
                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                            i41 = 2097152;
                            break;
                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                            i41 = 4194304;
                            break;
                        case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                            i41 = 8388608;
                            break;
                        default:
                            i41 = -1;
                            break;
                    }
                    if (i41 != -1) {
                        return new f(i42, i41, true);
                    }
                    hs.q.r(i39, "Unknown AV1 level: ", "CodecSpecificDataUtil");
                    return fVar;
                } catch (NumberFormatException unused2) {
                    hs.q.y("Ignoring malformed AV1 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
            case "avc1":
            case "avc2":
                if (strArrSplit.length < 2) {
                    hs.q.y("Ignoring malformed AVC codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    if (strArrSplit[1].length() == 6) {
                        i15 = 16;
                        i16 = Integer.parseInt(strArrSplit[1].substring(0, 2), 16);
                        i17 = Integer.parseInt(strArrSplit[1].substring(4), 16);
                    } else {
                        i15 = 16;
                        if (strArrSplit.length < 3) {
                            b.l("CodecSpecificDataUtil", "Ignoring malformed AVC codec string: " + str2);
                            return null;
                        }
                        i16 = Integer.parseInt(strArrSplit[1]);
                        i17 = Integer.parseInt(strArrSplit[2]);
                    }
                    if (i16 == 66) {
                        i18 = 1;
                    } else if (i16 == 77) {
                        i18 = 2;
                    } else if (i16 == 88) {
                        i18 = 4;
                    } else if (i16 == 100) {
                        i18 = 8;
                    } else if (i16 == 110) {
                        i18 = i15;
                    } else if (i16 != 122) {
                        i18 = i16 != 244 ? -1 : 64;
                    } else {
                        i18 = 32;
                    }
                    if (i18 == -1) {
                        hs.q.r(i16, "Unknown AVC profile: ", "CodecSpecificDataUtil");
                        return fVar;
                    }
                    switch (i17) {
                        case 10:
                            i15 = 1;
                            i19 = -1;
                            break;
                        case 11:
                            i19 = -1;
                            i15 = 4;
                            break;
                        case 12:
                            i19 = -1;
                            i15 = 8;
                            break;
                        case 13:
                            i19 = -1;
                            break;
                        default:
                            switch (i17) {
                                case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                                    i19 = -1;
                                    i15 = 32;
                                    break;
                                case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                                    i19 = -1;
                                    i15 = 64;
                                    break;
                                case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                                    i19 = -1;
                                    i15 = 128;
                                    break;
                                default:
                                    switch (i17) {
                                        case RendererMetrics.SAMPLES /* 30 */:
                                            i19 = -1;
                                            i15 = 256;
                                            break;
                                        case 31:
                                            i19 = -1;
                                            i15 = 512;
                                            break;
                                        case 32:
                                            i19 = -1;
                                            i15 = 1024;
                                            break;
                                        default:
                                            switch (i17) {
                                                case RequestError.NETWORK_FAILURE /* 40 */:
                                                    i19 = -1;
                                                    i15 = SemanticState.Modal;
                                                    break;
                                                case RequestError.NO_DEV_KEY /* 41 */:
                                                    i19 = -1;
                                                    i15 = SemanticState.Obscured;
                                                    break;
                                                case 42:
                                                    i15 = 8192;
                                                    i19 = -1;
                                                    break;
                                                default:
                                                    switch (i17) {
                                                        case 50:
                                                            i15 = 16384;
                                                            i19 = -1;
                                                            break;
                                                        case 51:
                                                            i15 = 32768;
                                                            i19 = -1;
                                                            break;
                                                        case 52:
                                                            i15 = 65536;
                                                            i19 = -1;
                                                            break;
                                                        default:
                                                            i19 = -1;
                                                            i15 = -1;
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                    if (i15 != i19) {
                        return new f(i18, i15, true);
                    }
                    hs.q.r(i17, "Unknown AVC level: ", "CodecSpecificDataUtil");
                    return fVar;
                } catch (NumberFormatException unused3) {
                    hs.q.y("Ignoring malformed AVC codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
            case "hev1":
            case "hvc1":
                return c(str2, strArrSplit, wVar.H);
            case "iamf":
                if (strArrSplit.length < 4) {
                    hs.q.y("Ignoring malformed IAMF codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i43 = Integer.parseInt(strArrSplit[1]);
                    String str5 = strArrSplit[3];
                    str5.getClass();
                    switch (str5) {
                        case "Opus":
                            if (i43 != 0) {
                                if (i43 != 1) {
                                    if (i43 != 2) {
                                        hs.q.r(i43, "Unrecognized IAMF Opus profile: ", "CodecSpecificDataUtil");
                                        i21 = -1;
                                        break;
                                    } else {
                                        i21 = R.string.copy;
                                        break;
                                    }
                                } else {
                                    i21 = R.id.checkbox;
                                    break;
                                }
                            } else {
                                i21 = R.attr.label;
                                break;
                            }
                            break;
                        case "fLaC":
                            if (i43 != 0) {
                                if (i43 != 1) {
                                    if (i43 != 2) {
                                        hs.q.r(i43, "Unrecognized IAMF FLAC profile: ", "CodecSpecificDataUtil");
                                        i21 = -1;
                                        break;
                                    } else {
                                        i21 = R.string.defaultVoiceMailAlphaTag;
                                        break;
                                    }
                                } else {
                                    i21 = R.id.empty;
                                    break;
                                }
                            } else {
                                i21 = R.attr.manageSpaceActivity;
                                break;
                            }
                            break;
                        case "ipcm":
                            if (i43 != 0) {
                                if (i43 != 1) {
                                    if (i43 != 2) {
                                        hs.q.r(i43, "Unrecognized IAMF PCM profile: ", "CodecSpecificDataUtil");
                                        i21 = -1;
                                        break;
                                    } else {
                                        i21 = R.string.httpErrorUnsupportedScheme;
                                        break;
                                    }
                                } else {
                                    i21 = R.id.icon2;
                                    break;
                                }
                            } else {
                                i21 = R.attr.writePermission;
                                break;
                            }
                            break;
                        case "mp4a":
                            if (i43 != 0) {
                                if (i43 != 1) {
                                    if (i43 != 2) {
                                        hs.q.r(i43, "Unrecognized IAMF AAC profile: ", "CodecSpecificDataUtil");
                                        i21 = -1;
                                        break;
                                    } else {
                                        i21 = R.string.copyUrl;
                                        break;
                                    }
                                } else {
                                    i21 = R.id.content;
                                    break;
                                }
                            } else {
                                i21 = R.attr.icon;
                                break;
                            }
                            break;
                        default:
                            b.l("CodecSpecificDataUtil", "Unrecognized codec identifier for IAMF auxiliary profile: ".concat(str5));
                            i21 = -1;
                            break;
                    }
                    return i21 == -1 ? fVar : new f(i21, 0, true);
                } catch (NumberFormatException e9) {
                    b.m("CodecSpecificDataUtil", "Ignoring malformed primary profile in IAMF codec string: " + strArrSplit[1], e9);
                    return null;
                }
            case "mp4a":
                if (strArrSplit.length != 3) {
                    hs.q.y("Ignoring malformed MP4A codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    if ("audio/mp4a-latm".equals(u0.e(Integer.parseInt(strArrSplit[1], 16)))) {
                        int i44 = Integer.parseInt(strArrSplit[2]);
                        int i45 = 17;
                        if (i44 == 17) {
                            i22 = -1;
                        } else {
                            if (i44 != 20) {
                                i45 = 23;
                                if (i44 != 23) {
                                    i45 = 29;
                                    if (i44 != 29) {
                                        i45 = 39;
                                        if (i44 != 39) {
                                            i45 = 42;
                                            if (i44 != 42) {
                                                switch (i44) {
                                                    case 1:
                                                        i45 = 1;
                                                        break;
                                                    case 2:
                                                        i22 = -1;
                                                        i45 = 2;
                                                        break;
                                                    case 3:
                                                        i45 = 3;
                                                        break;
                                                    case 4:
                                                        i22 = -1;
                                                        i45 = 4;
                                                        break;
                                                    case 5:
                                                        i45 = 5;
                                                        break;
                                                    case 6:
                                                        i22 = -1;
                                                        i45 = 6;
                                                        break;
                                                    default:
                                                        i22 = -1;
                                                        i45 = -1;
                                                        break;
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                i45 = 20;
                            }
                            i22 = -1;
                        }
                        if (i45 != i22) {
                            return new f(i45, 0, true);
                        }
                        b.l("CodecSpecificDataUtil", "Unrecognized MP4A profile: " + i45);
                        return fVar;
                    }
                } catch (NumberFormatException unused4) {
                    hs.q.y("Ignoring malformed MP4A codec string: ", str2, "CodecSpecificDataUtil");
                }
                return null;
            case "s263":
                if (strArrSplit.length < 3) {
                    hs.q.y("Ignoring malformed H263 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i46 = Integer.parseInt(strArrSplit[1]);
                    int i47 = Integer.parseInt(strArrSplit[2]);
                    switch (i46) {
                        case 0:
                            i23 = 1;
                            break;
                        case 1:
                            i23 = 2;
                            break;
                        case 2:
                            i23 = 4;
                            break;
                        case 3:
                            i23 = 8;
                            break;
                        case 4:
                            i23 = 16;
                            break;
                        case 5:
                            i23 = 32;
                            break;
                        case 6:
                            i23 = 64;
                            break;
                        case 7:
                            i23 = 128;
                            break;
                        case 8:
                            i23 = 256;
                            break;
                        default:
                            i23 = -1;
                            break;
                    }
                    if (i23 == -1) {
                        hs.q.r(i46, "Unknown H263 profile: ", "CodecSpecificDataUtil");
                        return fVar;
                    }
                    if (i47 == 10) {
                        i24 = 1;
                        i25 = -1;
                    } else if (i47 == 20) {
                        i25 = -1;
                        i24 = 2;
                    } else if (i47 == 30) {
                        i25 = -1;
                        i24 = 4;
                    } else if (i47 == 40) {
                        i25 = -1;
                        i24 = 8;
                    } else if (i47 == 45) {
                        i25 = -1;
                        i24 = 16;
                    } else if (i47 == 50) {
                        i25 = -1;
                        i24 = 32;
                    } else if (i47 == 60) {
                        i25 = -1;
                        i24 = 64;
                    } else if (i47 != 70) {
                        i25 = -1;
                        i24 = -1;
                    } else {
                        i25 = -1;
                        i24 = 128;
                    }
                    if (i24 != i25) {
                        return new f(i23, i24, true);
                    }
                    hs.q.r(i47, "Unknown H263 level: ", "CodecSpecificDataUtil");
                    return fVar;
                } catch (NumberFormatException unused5) {
                    hs.q.y("Ignoring malformed H263 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
            case "vp09":
                if (strArrSplit.length < 3) {
                    hs.q.y("Ignoring malformed VP9 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i48 = Integer.parseInt(strArrSplit[1]);
                    int i49 = Integer.parseInt(strArrSplit[2]);
                    if (i48 == 0) {
                        i26 = 1;
                    } else if (i48 == 1) {
                        i26 = 2;
                    } else if (i48 != 2) {
                        i26 = i48 != 3 ? -1 : 8;
                    } else {
                        i26 = 4;
                    }
                    if (i26 == -1) {
                        hs.q.r(i48, "Unknown VP9 profile: ", "CodecSpecificDataUtil");
                        return fVar;
                    }
                    if (i49 != 10) {
                        if (i49 == 11) {
                            i28 = -1;
                            i27 = 2;
                        } else if (i49 == 20) {
                            i28 = -1;
                            i27 = 4;
                        } else if (i49 == 21) {
                            i28 = -1;
                            i27 = 8;
                        } else if (i49 == 30) {
                            i28 = -1;
                            i27 = 16;
                        } else if (i49 == 31) {
                            i28 = -1;
                            i27 = 32;
                        } else if (i49 == 40) {
                            i28 = -1;
                            i27 = 64;
                        } else if (i49 == 41) {
                            i28 = -1;
                            i27 = 128;
                        } else if (i49 == 50) {
                            i28 = -1;
                            i27 = 256;
                        } else if (i49 != 51) {
                            switch (i49) {
                                case 60:
                                    i28 = -1;
                                    i27 = SemanticState.Modal;
                                    break;
                                case 61:
                                    i28 = -1;
                                    i27 = SemanticState.Obscured;
                                    break;
                                case 62:
                                    i27 = 8192;
                                    break;
                                default:
                                    i28 = -1;
                                    i27 = -1;
                                    break;
                            }
                        } else {
                            i28 = -1;
                            i27 = 512;
                        }
                        if (i27 == i28) {
                            return new f(i26, i27, true);
                        }
                        hs.q.r(i49, "Unknown VP9 level: ", "CodecSpecificDataUtil");
                        return fVar;
                    }
                    i27 = 1;
                    i28 = -1;
                    if (i27 == i28) {
                        return new f(i26, i27, true);
                    }
                    hs.q.r(i49, "Unknown VP9 level: ", "CodecSpecificDataUtil");
                    return fVar;
                } catch (NumberFormatException unused6) {
                    hs.q.y("Ignoring malformed VP9 codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
            case "vvc1":
            case "vvi1":
                k3.m mVar2 = wVar.H;
                if (strArrSplit.length < 3) {
                    hs.q.y("Ignoring malformed VVC codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
                try {
                    int i51 = Integer.parseInt(strArrSplit[1]);
                    if (i51 == 1) {
                        i29 = (mVar2 == null || mVar2.f18694c != 6) ? (mVar2 == null || mVar2.f18696e != 8) ? 2 : 1 : SemanticState.Obscured;
                    } else {
                        if (i51 != 65) {
                            b.l("CodecSpecificDataUtil", "Unknown VVC profile IDC: " + strArrSplit[1]);
                            return fVar;
                        }
                        i29 = 4;
                    }
                    String str6 = strArrSplit[2];
                    str6.getClass();
                    switch (str6.hashCode()) {
                        case 70918:
                            if (!str6.equals("H64")) {
                                b11 = -1;
                            } else {
                                b11 = 0;
                            }
                            break;
                        case 70921:
                            if (!str6.equals("H67")) {
                                b11 = -1;
                            } else {
                                b11 = 1;
                            }
                            break;
                        case 70976:
                            if (!str6.equals("H80")) {
                                b11 = -1;
                            } else {
                                b11 = 2;
                            }
                            break;
                        case 70979:
                            if (!str6.equals("H83")) {
                                b11 = -1;
                            }
                            break;
                        case 70982:
                            if (!str6.equals("H86")) {
                                b11 = -1;
                            } else {
                                b11 = 4;
                            }
                            break;
                        case 71013:
                            if (!str6.equals("H96")) {
                                b11 = -1;
                            } else {
                                b11 = 5;
                            }
                            break;
                        case 74609:
                            if (!str6.equals("L16")) {
                                b11 = -1;
                            } else {
                                b11 = 6;
                            }
                            break;
                        case 74667:
                            if (!str6.equals("L32")) {
                                b11 = -1;
                            } else {
                                b11 = 7;
                            }
                            break;
                        case 74670:
                            if (!str6.equals("L35")) {
                                b11 = -1;
                            } else {
                                b11 = 8;
                            }
                            break;
                        case 74704:
                            if (!str6.equals("L48")) {
                                b11 = -1;
                            } else {
                                b11 = 9;
                            }
                            break;
                        case 74728:
                            if (!str6.equals("L51")) {
                                b11 = -1;
                            } else {
                                b11 = 10;
                            }
                            break;
                        case 74762:
                            if (!str6.equals("L64")) {
                                b11 = -1;
                            } else {
                                b11 = 11;
                            }
                            break;
                        case 74765:
                            if (!str6.equals("L67")) {
                                b11 = -1;
                            } else {
                                b11 = 12;
                            }
                            break;
                        case 74820:
                            if (!str6.equals("L80")) {
                                b11 = -1;
                            }
                            break;
                        case 74823:
                            if (!str6.equals("L83")) {
                                b11 = -1;
                            }
                            break;
                        case 74826:
                            if (!str6.equals("L86")) {
                                b11 = -1;
                            }
                            break;
                        case 74857:
                            if (!str6.equals("L96")) {
                                b11 = -1;
                            } else {
                                b11 = 16;
                            }
                            break;
                        case 2193610:
                            if (!str6.equals("H112")) {
                                b11 = -1;
                            }
                            break;
                        case 2193647:
                            if (!str6.equals("H128")) {
                                b11 = -1;
                            }
                            break;
                        case 2193705:
                            if (!str6.equals("H144")) {
                                b11 = -1;
                            }
                            break;
                        case 2312774:
                            if (!str6.equals("L112")) {
                                b11 = -1;
                            } else {
                                b11 = 20;
                            }
                            break;
                        case 2312811:
                            if (!str6.equals("L128")) {
                                b11 = -1;
                            }
                            break;
                        case 2312869:
                            if (!str6.equals("L144")) {
                                b11 = -1;
                            }
                            break;
                        default:
                            b11 = -1;
                            break;
                    }
                    switch (b11) {
                        case 0:
                            numValueOf = 64;
                            break;
                        case 1:
                            numValueOf = 256;
                            break;
                        case 2:
                            break;
                        case 3:
                            numValueOf = numValueOf3;
                            break;
                        case 4:
                            numValueOf = 16384;
                            break;
                        case 5:
                            numValueOf = 65536;
                            break;
                        case 6:
                            numValueOf = 1;
                            break;
                        case 7:
                            numValueOf = 2;
                            break;
                        case 8:
                            numValueOf = 4;
                            break;
                        case 9:
                            numValueOf = 8;
                            break;
                        case 10:
                            numValueOf = 16;
                            break;
                        case 11:
                            numValueOf = 32;
                            break;
                        case 12:
                            numValueOf = 128;
                            break;
                        case 13:
                            numValueOf = 512;
                            break;
                        case 14:
                            numValueOf = numValueOf2;
                            break;
                        case 15:
                            numValueOf = Integer.valueOf(SemanticState.Multiline);
                            break;
                        case 16:
                            numValueOf = Integer.valueOf(PeerConnection.PORTALLOCATOR_ENABLE_ANY_ADDRESS_PORTS);
                            break;
                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                            numValueOf = 262144;
                            break;
                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                            numValueOf = 1048576;
                            break;
                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                            numValueOf = 4194304;
                            break;
                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                            numValueOf = 131072;
                            break;
                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                            numValueOf = 524288;
                            break;
                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                            numValueOf = 2097152;
                            break;
                        default:
                            numValueOf = null;
                            break;
                    }
                    if (numValueOf != null) {
                        return new f(i29, numValueOf.intValue(), true);
                    }
                    b.l("CodecSpecificDataUtil", "Unknown VVC level string: ".concat(str6));
                    return fVar;
                } catch (NumberFormatException unused7) {
                    hs.q.y("Ignoring malformed VVC codec string: ", str2, "CodecSpecificDataUtil");
                    return null;
                }
            default:
                return null;
        }
    }

    public static boolean e(k3.w wVar) {
        if (Objects.equals(wVar.f19012p, "application/x-itut-t35")) {
            for (byte[] bArr : wVar.f19015s) {
                int length = bArr.length;
                byte[] bArr2 = f22327d;
                if (length >= bArr2.length) {
                    for (int i11 = 0; i11 < bArr2.length; i11++) {
                        if (bArr[i11] == bArr2[i11]) {
                        }
                    }
                    return true;
                }
            }
        }
        return false;
    }
}
