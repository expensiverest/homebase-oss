package n3;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class i0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f22336a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long[] f22337b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object[] f22338c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f22339d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f22340e;

    public i0(int i11) {
        this.f22336a = i11;
        switch (i11) {
            case 1:
                this.f22337b = new long[10];
                this.f22338c = new Object[10];
                break;
            default:
                this.f22337b = new long[10];
                this.f22338c = new Object[10];
                break;
        }
    }

    public final synchronized void a(long j6, Object obj) {
        int i11 = this.f22336a;
        synchronized (this) {
            switch (i11) {
                case 0:
                    int i12 = this.f22340e;
                    if (i12 > 0) {
                        if (j6 <= this.f22337b[((this.f22339d + i12) - 1) % this.f22338c.length]) {
                            b();
                        }
                    }
                    c();
                    int i13 = this.f22339d;
                    int i14 = this.f22340e;
                    Object[] objArr = this.f22338c;
                    int length = (i13 + i14) % objArr.length;
                    this.f22337b[length] = j6;
                    objArr[length] = obj;
                    this.f22340e = i14 + 1;
                    return;
                default:
                    int i15 = this.f22340e;
                    if (i15 > 0) {
                        if (j6 <= this.f22337b[((this.f22339d + i15) - 1) % this.f22338c.length]) {
                            b();
                        }
                    }
                    c();
                    int i16 = this.f22339d;
                    int i17 = this.f22340e;
                    Object[] objArr2 = this.f22338c;
                    int length2 = (i16 + i17) % objArr2.length;
                    this.f22337b[length2] = j6;
                    objArr2[length2] = obj;
                    this.f22340e = i17 + 1;
                    return;
            }
        }
    }

    public final synchronized void b() {
        int i11 = this.f22336a;
        synchronized (this) {
            switch (i11) {
                case 0:
                    this.f22339d = 0;
                    this.f22340e = 0;
                    Arrays.fill(this.f22338c, (Object) null);
                    return;
                default:
                    this.f22339d = 0;
                    this.f22340e = 0;
                    Arrays.fill(this.f22338c, (Object) null);
                    return;
            }
        }
    }

    public final void c() {
        switch (this.f22336a) {
            case 0:
                int length = this.f22338c.length;
                if (this.f22340e >= length) {
                    int i11 = length * 2;
                    long[] jArr = new long[i11];
                    Object[] objArr = new Object[i11];
                    int i12 = this.f22339d;
                    int i13 = length - i12;
                    System.arraycopy(this.f22337b, i12, jArr, 0, i13);
                    System.arraycopy(this.f22338c, this.f22339d, objArr, 0, i13);
                    int i14 = this.f22339d;
                    if (i14 > 0) {
                        System.arraycopy(this.f22337b, 0, jArr, i13, i14);
                        System.arraycopy(this.f22338c, 0, objArr, i13, this.f22339d);
                    }
                    this.f22337b = jArr;
                    this.f22338c = objArr;
                    this.f22339d = 0;
                    break;
                }
                break;
            default:
                int length2 = this.f22338c.length;
                if (this.f22340e >= length2) {
                    int i15 = length2 * 2;
                    long[] jArr2 = new long[i15];
                    Object[] objArr2 = new Object[i15];
                    int i16 = this.f22339d;
                    int i17 = length2 - i16;
                    System.arraycopy(this.f22337b, i16, jArr2, 0, i17);
                    System.arraycopy(this.f22338c, this.f22339d, objArr2, 0, i17);
                    int i18 = this.f22339d;
                    if (i18 > 0) {
                        System.arraycopy(this.f22337b, 0, jArr2, i17, i18);
                        System.arraycopy(this.f22338c, 0, objArr2, i17, this.f22339d);
                    }
                    this.f22337b = jArr2;
                    this.f22338c = objArr2;
                    this.f22339d = 0;
                    break;
                }
                break;
        }
    }

    public final Object d(long j6, boolean z11) {
        switch (this.f22336a) {
            case 0:
                Object objG = null;
                long j11 = Long.MAX_VALUE;
                while (this.f22340e > 0) {
                    long j12 = j6 - this.f22337b[this.f22339d];
                    if (j12 < 0 && (z11 || (-j12) >= j11)) {
                        break;
                    }
                    objG = g();
                    j11 = j12;
                }
                return objG;
            default:
                Object objG2 = null;
                long j13 = Long.MAX_VALUE;
                while (this.f22340e > 0) {
                    long j14 = j6 - this.f22337b[this.f22339d];
                    if (j14 < 0 && (z11 || (-j14) >= j13)) {
                        break;
                    }
                    objG2 = g();
                    j13 = j14;
                }
                return objG2;
        }
    }

    public synchronized Object e() {
        return this.f22340e == 0 ? null : g();
    }

    public synchronized Object f(long j6) {
        return d(j6, true);
    }

    public final Object g() {
        switch (this.f22336a) {
            case 0:
                oq.a.z(this.f22340e > 0);
                Object[] objArr = this.f22338c;
                int i11 = this.f22339d;
                Object obj = objArr[i11];
                objArr[i11] = null;
                this.f22339d = (i11 + 1) % objArr.length;
                this.f22340e--;
                return obj;
            default:
                qt.a.k(this.f22340e > 0);
                Object[] objArr2 = this.f22338c;
                int i12 = this.f22339d;
                Object obj2 = objArr2[i12];
                objArr2[i12] = null;
                this.f22339d = (i12 + 1) % objArr2.length;
                this.f22340e--;
                return obj2;
        }
    }

    public synchronized int h() {
        return this.f22340e;
    }
}
