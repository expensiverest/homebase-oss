package n3;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final f f22319d = new f(0, 0, false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f22320a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f22321b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f22322c;

    public f(int i11, int i12, boolean z11) {
        this.f22322c = z11;
        this.f22320a = i11;
        this.f22321b = i12;
    }
}
