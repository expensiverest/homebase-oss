package n3;

import android.os.Handler;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class g0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final ArrayList f22328b = new ArrayList(50);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Handler f22329a;

    public g0(Handler handler) {
        this.f22329a = handler;
    }

    public static f0 d() {
        f0 f0Var;
        ArrayList arrayList = f22328b;
        synchronized (arrayList) {
            try {
                f0Var = arrayList.isEmpty() ? new f0() : (f0) arrayList.remove(arrayList.size() - 1);
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return f0Var;
    }

    public final f0 a(int i11) {
        f0 f0VarD = d();
        f0VarD.f22323a = this.f22329a.obtainMessage(i11);
        return f0VarD;
    }

    public final f0 b(int i11, int i12, int i13) {
        f0 f0VarD = d();
        f0VarD.f22323a = this.f22329a.obtainMessage(i11, i12, i13);
        return f0VarD;
    }

    public final f0 c(int i11, Object obj) {
        f0 f0VarD = d();
        f0VarD.f22323a = this.f22329a.obtainMessage(i11, obj);
        return f0VarD;
    }

    public final boolean e(Runnable runnable) {
        return this.f22329a.post(runnable);
    }

    public final void f() {
        this.f22329a.removeCallbacksAndMessages(null);
    }

    public final void g(int i11) {
        oq.a.n(i11 != 0);
        this.f22329a.removeMessages(i11);
    }

    public final boolean h(int i11) {
        return this.f22329a.sendEmptyMessage(i11);
    }
}
