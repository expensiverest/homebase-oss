package n3;

import android.os.Message;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class f0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Message f22323a;

    public final void a() {
        this.f22323a = null;
        ArrayList arrayList = g0.f22328b;
        synchronized (arrayList) {
            try {
                if (arrayList.size() < 50) {
                    arrayList.add(this);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void b() {
        Message message = this.f22323a;
        message.getClass();
        message.sendToTarget();
        a();
    }
}
