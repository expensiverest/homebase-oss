package n3;

import android.os.SystemClock;
import com.google.android.gms.internal.fido.f6;
import java.util.Objects;
import k3.k1;
import k3.n1;

/* JADX INFO: loaded from: classes.dex */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f22291a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f22292b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f22293c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f22294d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f22295e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f22296f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f22297g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ f6 f22298h;

    public a0(f6 f6Var, int i11) {
        this.f22298h = f6Var;
        this.f22291a = i11;
    }

    public final void a() {
        f6 f6Var = this.f22298h;
        g0 g0Var = (g0) f6Var.f6582x;
        v3.w wVar = (v3.w) f6Var.f6577d;
        if (!wVar.K()) {
            if (this.f22296f) {
                g0Var.g(2);
            }
            this.f22296f = false;
            return;
        }
        n1 n1VarU = wVar.U();
        Object objL = n1VarU.p() ? null : n1VarU.l(wVar.t());
        int iO = wVar.O();
        int iX = wVar.x();
        long jB0 = wVar.b0();
        if (objL != null && iO == -1) {
            jB0 -= l0.g0(n1VarU.g(objL, (k1) f6Var.f6581w).f18673e);
        }
        ((e0) f6Var.f6580v).getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        boolean z11 = this.f22296f;
        int i11 = this.f22291a;
        if (z11 && Objects.equals(objL, this.f22292b) && iO == this.f22293c && iX == this.f22294d && jB0 == this.f22295e) {
            if (jElapsedRealtime - this.f22297g >= i11) {
                ((v3.q) f6Var.f6579i).f32084d.c3(new v3.i(2, new d0(2, i11), 1003));
                return;
            }
            return;
        }
        this.f22296f = true;
        this.f22297g = jElapsedRealtime;
        this.f22292b = objL;
        this.f22293c = iO;
        this.f22294d = iX;
        this.f22295e = jB0;
        g0Var.g(2);
        g0Var.f22329a.sendEmptyMessageDelayed(2, i11);
    }
}
