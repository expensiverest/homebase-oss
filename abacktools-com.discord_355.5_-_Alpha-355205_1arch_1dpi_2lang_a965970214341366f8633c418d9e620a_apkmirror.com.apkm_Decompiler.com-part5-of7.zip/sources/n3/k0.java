package n3;

import java.util.concurrent.ThreadFactory;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class k0 implements ThreadFactory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f22350a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f22351b;

    public /* synthetic */ k0(String str, int i11) {
        this.f22350a = i11;
        this.f22351b = str;
    }

    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        switch (this.f22350a) {
            case 0:
                return new Thread(runnable, this.f22351b);
            case 1:
                return new Thread(runnable, this.f22351b);
            default:
                Thread thread = new Thread(runnable, this.f22351b);
                thread.setPriority(10);
                return thread;
        }
    }
}
