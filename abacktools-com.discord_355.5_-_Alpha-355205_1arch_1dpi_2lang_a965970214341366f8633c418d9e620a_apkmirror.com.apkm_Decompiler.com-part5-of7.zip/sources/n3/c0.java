package n3;

import android.os.SystemClock;
import com.google.android.gms.internal.fido.f6;

/* JADX INFO: loaded from: classes.dex */
public final class c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f22311a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f22312b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f22313c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f22314d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ f6 f22315e;

    public c0(f6 f6Var, int i11) {
        this.f22315e = f6Var;
        this.f22311a = i11;
    }

    public final void a() {
        f6 f6Var = this.f22315e;
        g0 g0Var = (g0) f6Var.f6582x;
        v3.w wVar = (v3.w) f6Var.f6577d;
        int iS = wVar.S();
        if (!wVar.o() || wVar.I() == 1 || wVar.I() == 4 || iS == 0 || iS == 1) {
            if (this.f22313c) {
                g0Var.g(4);
            }
            this.f22313c = false;
            return;
        }
        ((e0) f6Var.f6580v).getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        boolean z11 = this.f22313c;
        int i11 = this.f22311a;
        if (z11 && this.f22312b == iS) {
            if (jElapsedRealtime - this.f22314d >= i11) {
                ((v3.q) f6Var.f6579i).f32084d.c3(new v3.i(2, new d0(4, i11), 1003));
                return;
            }
            return;
        }
        this.f22313c = true;
        this.f22314d = jElapsedRealtime;
        this.f22312b = iS;
        g0Var.g(4);
        g0Var.f22329a.sendEmptyMessageDelayed(4, i11);
    }
}
