package n3;

import android.os.Handler;
import android.os.Looper;

/* JADX INFO: loaded from: classes.dex */
public final class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final e0 f22318a = new e0();

    public final g0 a(Looper looper, Handler.Callback callback) {
        return new g0(new Handler(looper, callback));
    }
}
