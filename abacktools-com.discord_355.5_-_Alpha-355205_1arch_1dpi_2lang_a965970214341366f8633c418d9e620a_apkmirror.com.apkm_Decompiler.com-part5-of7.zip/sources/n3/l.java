package n3;

import android.graphics.SurfaceTexture;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class l implements SurfaceTexture.OnFrameAvailableListener, Runnable {
    public static final int[] y = {12352, 4, 12324, 8, 12323, 8, 12322, 8, 12321, 8, 12325, 0, 12327, 12344, 12339, 4, 12344};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Handler f22352d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[] f22353e = new int[1];

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public EGLDisplay f22354i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public EGLContext f22355v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public EGLSurface f22356w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public SurfaceTexture f22357x;

    public l(Handler handler) {
        this.f22352d = handler;
    }

    @Override // android.graphics.SurfaceTexture.OnFrameAvailableListener
    public final void onFrameAvailable(SurfaceTexture surfaceTexture) {
        this.f22352d.post(this);
    }

    @Override // java.lang.Runnable
    public final void run() {
        SurfaceTexture surfaceTexture = this.f22357x;
        if (surfaceTexture != null) {
            try {
                surfaceTexture.updateTexImage();
            } catch (RuntimeException unused) {
            }
        }
    }
}
