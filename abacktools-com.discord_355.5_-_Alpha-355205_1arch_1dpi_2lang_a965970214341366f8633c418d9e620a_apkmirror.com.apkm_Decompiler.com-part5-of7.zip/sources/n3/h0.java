package n3;

/* JADX INFO: loaded from: classes.dex */
public interface h0 {
    void run();
}
