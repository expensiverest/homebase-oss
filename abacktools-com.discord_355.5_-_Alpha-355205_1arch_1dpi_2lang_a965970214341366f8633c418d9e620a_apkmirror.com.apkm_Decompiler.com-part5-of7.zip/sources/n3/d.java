package n3;

import android.net.Uri;
import k3.r0;

/* JADX INFO: loaded from: classes.dex */
public interface d {
    mx.y I(Uri uri);

    mx.y b0(byte[] bArr);

    default mx.y q0(r0 r0Var) {
        byte[] bArr = r0Var.k;
        if (bArr != null) {
            return b0(bArr);
        }
        Uri uri = r0Var.f18843n;
        if (uri != null) {
            return I(uri);
        }
        return null;
    }
}
