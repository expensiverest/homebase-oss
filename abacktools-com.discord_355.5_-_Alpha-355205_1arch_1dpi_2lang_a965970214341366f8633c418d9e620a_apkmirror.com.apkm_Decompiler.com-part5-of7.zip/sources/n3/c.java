package n3;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f22308d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ e6.b f22309e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f22310i;

    public /* synthetic */ c(e6.b bVar, Object obj, int i11) {
        this.f22308d = i11;
        this.f22309e = bVar;
        this.f22310i = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f22308d) {
            case 0:
                e6.b bVar = this.f22309e;
                if (bVar.f9931a == 0) {
                    bVar.A(this.f22310i);
                }
                break;
            default:
                e6.b bVar2 = this.f22309e;
                int i11 = bVar2.f9931a - 1;
                bVar2.f9931a = i11;
                if (i11 == 0) {
                    bVar2.A(this.f22310i);
                }
                break;
        }
    }
}
