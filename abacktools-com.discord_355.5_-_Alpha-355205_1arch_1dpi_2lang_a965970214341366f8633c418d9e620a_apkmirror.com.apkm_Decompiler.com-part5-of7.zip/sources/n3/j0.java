package n3;

import java.math.RoundingMode;

/* JADX INFO: loaded from: classes.dex */
public final class j0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f22341a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f22342b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f22343c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ThreadLocal f22344d = new ThreadLocal();

    public j0(long j6) {
        f(j6);
    }

    public final synchronized long a(long j6) {
        if (j6 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        try {
            if (!e()) {
                long jLongValue = this.f22341a;
                if (jLongValue == 9223372036854775806L) {
                    Long l = (Long) this.f22344d.get();
                    l.getClass();
                    jLongValue = l.longValue();
                }
                this.f22342b = jLongValue - j6;
                notifyAll();
            }
            this.f22343c = j6;
            return j6 + this.f22342b;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized long b(long j6) {
        if (j6 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        try {
            long j11 = this.f22343c;
            if (j11 != -9223372036854775807L) {
                String str = l0.f22358a;
                long jA0 = l0.a0(j11, 90000L, 1000000L, RoundingMode.DOWN);
                long j12 = (4294967296L + jA0) / 8589934592L;
                long j13 = ((j12 - 1) * 8589934592L) + j6;
                long j14 = (j12 * 8589934592L) + j6;
                j6 = Math.abs(j13 - jA0) < Math.abs(j14 - jA0) ? j13 : j14;
            }
            long j15 = j6;
            String str2 = l0.f22358a;
            return a(l0.a0(j15, 1000000L, 90000L, RoundingMode.DOWN));
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized long c(long j6) {
        if (j6 == -9223372036854775807L) {
            return -9223372036854775807L;
        }
        try {
            long j11 = this.f22343c;
            if (j11 != -9223372036854775807L) {
                String str = l0.f22358a;
                long jA0 = l0.a0(j11, 90000L, 1000000L, RoundingMode.DOWN);
                long j12 = jA0 / 8589934592L;
                long j13 = (j12 * 8589934592L) + j6;
                j6 = j13 >= jA0 ? j13 : ((j12 + 1) * 8589934592L) + j6;
            }
            long j14 = j6;
            String str2 = l0.f22358a;
            return a(l0.a0(j14, 1000000L, 90000L, RoundingMode.DOWN));
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized long d() {
        long j6;
        j6 = this.f22341a;
        if (j6 == Long.MAX_VALUE || j6 == 9223372036854775806L) {
            j6 = -9223372036854775807L;
        }
        return j6;
    }

    public final synchronized boolean e() {
        return this.f22342b != -9223372036854775807L;
    }

    public final synchronized void f(long j6) {
        this.f22341a = j6;
        this.f22342b = j6 == Long.MAX_VALUE ? 0L : -9223372036854775807L;
        this.f22343c = -9223372036854775807L;
    }

    public final synchronized void g(long j6, boolean z11) {
        try {
            oq.a.z(this.f22341a == 9223372036854775806L);
            if (e()) {
                return;
            }
            if (z11) {
                this.f22344d.set(Long.valueOf(j6));
            } else {
                while (!e()) {
                    wait();
                }
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }
}
