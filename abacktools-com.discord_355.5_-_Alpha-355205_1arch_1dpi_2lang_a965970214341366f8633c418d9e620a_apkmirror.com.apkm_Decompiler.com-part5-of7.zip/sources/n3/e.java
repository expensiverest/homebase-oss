package n3;

import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLDisplay;
import android.opengl.GLES20;
import android.opengl.GLU;
import android.os.Bundle;
import android.text.TextUtils;
import hx.w1;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public abstract class e {
    public static void a(int i11, int i12) {
        GLES20.glBindTexture(i11, i12);
        b();
        GLES20.glTexParameteri(i11, 10240, 9729);
        b();
        GLES20.glTexParameteri(i11, 10241, 9729);
        b();
        GLES20.glTexParameteri(i11, 10242, 33071);
        b();
        GLES20.glTexParameteri(i11, 10243, 33071);
        b();
    }

    public static void b() {
        StringBuilder sb2 = new StringBuilder();
        hx.s.g(4, "initialCapacity");
        Object[] objArrCopyOf = new Object[4];
        boolean z11 = false;
        int i11 = 0;
        while (true) {
            int iGlGetError = GLES20.glGetError();
            if (iGlGetError == 0) {
                break;
            }
            if (z11) {
                sb2.append('\n');
            }
            String strGluErrorString = GLU.gluErrorString(iGlGetError);
            if (strGluErrorString == null) {
                strGluErrorString = "error code: 0x" + Integer.toHexString(iGlGetError);
            }
            sb2.append("glError: ");
            sb2.append(strGluErrorString);
            Integer numValueOf = Integer.valueOf(iGlGetError);
            int i12 = i11 + 1;
            int iB = hx.g0.b(objArrCopyOf.length, i12);
            if (iB > objArrCopyOf.length) {
                objArrCopyOf = Arrays.copyOf(objArrCopyOf, iB);
            }
            objArrCopyOf[i11] = numValueOf;
            z11 = true;
            i11 = i12;
        }
        if (z11) {
            throw new m(sb2.toString(), hx.m0.o(i11, objArrCopyOf));
        }
    }

    public static void c(String str, boolean z11) {
        if (z11) {
            return;
        }
        hx.k0 k0Var = hx.m0.f14841e;
        throw new m(str, w1.f14911w);
    }

    public static FloatBuffer d(float[] fArr) {
        return (FloatBuffer) ByteBuffer.allocateDirect(fArr.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(fArr).flip();
    }

    public static w1 e(gx.k kVar, ArrayList arrayList) {
        hx.j0 j0VarP = hx.m0.p();
        for (int i11 = 0; i11 < arrayList.size(); i11++) {
            Bundle bundle = (Bundle) arrayList.get(i11);
            bundle.getClass();
            j0VarP.c(kVar.apply(bundle));
        }
        return j0VarP.g();
    }

    public static int[] f(String str) {
        int iIndexOf;
        int[] iArr = new int[4];
        if (TextUtils.isEmpty(str)) {
            iArr[0] = -1;
            return iArr;
        }
        int length = str.length();
        int iIndexOf2 = str.indexOf(35);
        if (iIndexOf2 != -1) {
            length = iIndexOf2;
        }
        int iIndexOf3 = str.indexOf(63);
        if (iIndexOf3 == -1 || iIndexOf3 > length) {
            iIndexOf3 = length;
        }
        int iIndexOf4 = str.indexOf(47);
        if (iIndexOf4 == -1 || iIndexOf4 > iIndexOf3) {
            iIndexOf4 = iIndexOf3;
        }
        int iIndexOf5 = str.indexOf(58);
        if (iIndexOf5 > iIndexOf4) {
            iIndexOf5 = -1;
        }
        int i11 = iIndexOf5 + 2;
        if (i11 < iIndexOf3 && str.charAt(iIndexOf5 + 1) == '/' && str.charAt(i11) == '/') {
            iIndexOf = str.indexOf(47, iIndexOf5 + 3);
            if (iIndexOf == -1 || iIndexOf > iIndexOf3) {
                iIndexOf = iIndexOf3;
            }
        } else {
            iIndexOf = iIndexOf5 + 1;
        }
        iArr[0] = iIndexOf5;
        iArr[1] = iIndexOf;
        iArr[2] = iIndexOf3;
        iArr[3] = length;
        return iArr;
    }

    public static boolean g(String str) throws m {
        EGLDisplay eGLDisplayEglGetDisplay = EGL14.eglGetDisplay(0);
        c("No EGL display.", !eGLDisplayEglGetDisplay.equals(EGL14.EGL_NO_DISPLAY));
        c("Error in eglInitialize.", EGL14.eglInitialize(eGLDisplayEglGetDisplay, new int[1], 0, new int[1], 0));
        int iEglGetError = EGL14.eglGetError();
        if (iEglGetError == 12288) {
            String strEglQueryString = EGL14.eglQueryString(eGLDisplayEglGetDisplay, 12373);
            return strEglQueryString != null && strEglQueryString.contains(str);
        }
        throw new m("Error in getDefaultEglDisplay, error code: 0x" + Integer.toHexString(iEglGetError), hx.m0.v(Integer.valueOf(iEglGetError)));
    }

    public static String h(int i11, int i12, StringBuilder sb2) {
        int i13;
        int iLastIndexOf;
        if (i11 >= i12) {
            return sb2.toString();
        }
        if (sb2.charAt(i11) == '/') {
            i11++;
        }
        int i14 = i11;
        int i15 = i14;
        while (i14 <= i12) {
            if (i14 == i12) {
                i13 = i14;
            } else if (sb2.charAt(i14) == '/') {
                i13 = i14 + 1;
            } else {
                i14++;
            }
            int i16 = i15 + 1;
            if (i14 == i16 && sb2.charAt(i15) == '.') {
                sb2.delete(i15, i13);
                i12 -= i13 - i15;
            } else {
                if (i14 == i15 + 2 && sb2.charAt(i15) == '.' && sb2.charAt(i16) == '.') {
                    iLastIndexOf = sb2.lastIndexOf("/", i15 - 2) + 1;
                    int i17 = iLastIndexOf > i11 ? iLastIndexOf : i11;
                    sb2.delete(i17, i13);
                    i12 -= i13 - i17;
                } else {
                    iLastIndexOf = i14 + 1;
                }
                i15 = iLastIndexOf;
            }
            i14 = i15;
        }
        return sb2.toString();
    }

    public static String i(String str, String str2) {
        StringBuilder sb2 = new StringBuilder();
        if (str == null) {
            str = "";
        }
        if (str2 == null) {
            str2 = "";
        }
        int[] iArrF = f(str2);
        if (iArrF[0] != -1) {
            sb2.append(str2);
            h(iArrF[1], iArrF[2], sb2);
            return sb2.toString();
        }
        int[] iArrF2 = f(str);
        if (iArrF[3] == 0) {
            sb2.append((CharSequence) str, 0, iArrF2[3]);
            sb2.append(str2);
            return sb2.toString();
        }
        if (iArrF[2] == 0) {
            sb2.append((CharSequence) str, 0, iArrF2[2]);
            sb2.append(str2);
            return sb2.toString();
        }
        int i11 = iArrF[1];
        if (i11 != 0) {
            int i12 = iArrF2[0] + 1;
            sb2.append((CharSequence) str, 0, i12);
            sb2.append(str2);
            return h(iArrF[1] + i12, i12 + iArrF[2], sb2);
        }
        if (str2.charAt(i11) == '/') {
            sb2.append((CharSequence) str, 0, iArrF2[1]);
            sb2.append(str2);
            int i13 = iArrF2[1];
            return h(i13, iArrF[2] + i13, sb2);
        }
        int i14 = iArrF2[0] + 2;
        int i15 = iArrF2[1];
        if (i14 >= i15 || i15 != iArrF2[2]) {
            int iLastIndexOf = str.lastIndexOf(47, iArrF2[2] - 1);
            int i16 = iLastIndexOf == -1 ? iArrF2[1] : iLastIndexOf + 1;
            sb2.append((CharSequence) str, 0, i16);
            sb2.append(str2);
            return h(iArrF2[1], i16 + iArrF[2], sb2);
        }
        sb2.append((CharSequence) str, 0, i15);
        sb2.append('/');
        sb2.append(str2);
        int i17 = iArrF2[1];
        return h(i17, iArrF[2] + i17 + 1, sb2);
    }

    public static Uri j(String str, String str2) {
        return Uri.parse(i(str, str2));
    }

    public static ArrayList k(Collection collection, gx.k kVar) {
        ArrayList arrayList = new ArrayList(collection.size());
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            arrayList.add((Bundle) kVar.apply(it.next()));
        }
        return arrayList;
    }
}
