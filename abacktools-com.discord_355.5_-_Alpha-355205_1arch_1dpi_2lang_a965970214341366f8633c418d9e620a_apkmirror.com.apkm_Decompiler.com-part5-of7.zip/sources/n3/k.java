package n3;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class k implements Iterable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f22345d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f22346e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final HashMap f22347i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Set f22348v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public List f22349w;

    public k(int i11) {
        this.f22345d = i11;
        switch (i11) {
            case 1:
                this.f22346e = new Object();
                this.f22347i = new HashMap();
                this.f22348v = Collections.EMPTY_SET;
                this.f22349w = Collections.EMPTY_LIST;
                break;
            default:
                this.f22346e = new Object();
                this.f22347i = new HashMap();
                this.f22348v = Collections.EMPTY_SET;
                this.f22349w = Collections.EMPTY_LIST;
                break;
        }
    }

    public int a(sr.m mVar) {
        int iIntValue;
        synchronized (this.f22346e) {
            try {
                iIntValue = this.f22347i.containsKey(mVar) ? ((Integer) this.f22347i.get(mVar)).intValue() : 0;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return iIntValue;
    }

    public int b(y3.j jVar) {
        int iIntValue;
        synchronized (this.f22346e) {
            try {
                iIntValue = this.f22347i.containsKey(jVar) ? ((Integer) this.f22347i.get(jVar)).intValue() : 0;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return iIntValue;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        Iterator it;
        Iterator it2;
        switch (this.f22345d) {
            case 0:
                synchronized (this.f22346e) {
                    it = this.f22349w.iterator();
                    break;
                }
                return it;
            default:
                synchronized (this.f22346e) {
                    it2 = this.f22349w.iterator();
                    break;
                }
                return it2;
        }
    }
}
