package n3;

import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.Display;
import android.view.WindowManager;
import app.p001rive.runtime.kotlin.renderers.RendererMetrics;
import com.discord.age_assurance.DigitalCredentialModule;
import com.facebook.imageutils.JfifUtil;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import j$.util.DesugarTimeZone;
import java.io.Closeable;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Formatter;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import k3.e1;
import k3.u0;
import k3.v0;
import org.webrtc.MediaStreamTrack;
import p.x2;

/* JADX INFO: loaded from: classes.dex */
public abstract class l0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f22358a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final byte[] f22359b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final long[] f22360c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Pattern f22361d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Pattern f22362e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Pattern f22363f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static HashMap f22364g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final String[] f22365h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final String[] f22366i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final int[] f22367j;
    public static final int[] k;
    public static final int[] l;

    static {
        String str = Build.DEVICE;
        String str2 = Build.MANUFACTURER;
        f22358a = str + ", " + Build.MODEL + ", " + str2 + ", " + Build.VERSION.SDK_INT;
        f22359b = new byte[0];
        f22360c = new long[0];
        f22361d = Pattern.compile("(\\d\\d\\d\\d)\\-(\\d\\d)\\-(\\d\\d)[Tt ](\\d\\d):(\\d\\d):(\\d\\d)([\\.,](\\d+))?([Zz]|((\\+|\\-)(\\d?\\d):?(\\d\\d)?))?");
        Pattern.compile("^(-)?P(([0-9]*)Y)?(([0-9]*)M)?(([0-9]*)D)?(T(([0-9]*)H)?(([0-9]*)M)?(([0-9.]*)S)?)?$");
        f22362e = Pattern.compile("%([A-Fa-f0-9]{2})");
        f22363f = Pattern.compile("(?:.*\\.)?isml?(?:/(manifest(.*))?)?", 2);
        f22365h = new String[]{"alb", "sq", "arm", "hy", "baq", "eu", "bur", "my", "tib", "bo", "chi", "zh", "cze", "cs", "dut", "nl", "ger", "de", "gre", "el", "fre", "fr", "geo", "ka", "ice", "is", "mac", "mk", "mao", "mi", "may", "ms", "per", "fa", "rum", "ro", "scc", "hbs-srp", "slo", "sk", "wel", "cy", "id", "ms-ind", "iw", "he", "heb", "he", "ji", "yi", "arb", "ar-arb", "in", "ms-ind", "ind", "ms-ind", "nb", "no-nob", "nob", "no-nob", "nn", "no-nno", "nno", "no-nno", "tw", "ak-twi", "twi", "ak-twi", "bs", "hbs-bos", "bos", "hbs-bos", "hr", "hbs-hrv", "hrv", "hbs-hrv", "sr", "hbs-srp", "srp", "hbs-srp", "cmn", "zh-cmn", "hak", "zh-hak", "nan", "zh-nan", "hsn", "zh-hsn"};
        f22366i = new String[]{"i-lux", "lb", "i-hak", "zh-hak", "i-navajo", "nv", "no-bok", "no-nob", "no-nyn", "no-nno", "zh-guoyu", "zh-cmn", "zh-hakka", "zh-hak", "zh-min-nan", "zh-nan", "zh-xiang", "zh-hsn"};
        f22367j = new int[]{0, 79764919, 159529838, 222504665, 319059676, 398814059, 445009330, 507990021, 638119352, 583659535, 797628118, 726387553, 890018660, 835552979, 1015980042, 944750013, 1276238704, 1221641927, 1167319070, 1095957929, 1595256236, 1540665371, 1452775106, 1381403509, 1780037320, 1859660671, 1671105958, 1733955601, 2031960084, 2111593891, 1889500026, 1952343757, -1742489888, -1662866601, -1851683442, -1788833735, -1960329156, -1880695413, -2103051438, -2040207643, -1104454824, -1159051537, -1213636554, -1284997759, -1389417084, -1444007885, -1532160278, -1603531939, -734892656, -789352409, -575645954, -646886583, -952755380, -1007220997, -827056094, -898286187, -231047128, -151282273, -71779514, -8804623, -515967244, -436212925, -390279782, -327299027, 881225847, 809987520, 1023691545, 969234094, 662832811, 591600412, 771767749, 717299826, 311336399, 374308984, 453813921, 533576470, 25881363, 88864420, 134795389, 214552010, 2023205639, 2086057648, 1897238633, 1976864222, 1804852699, 1867694188, 1645340341, 1724971778, 1587496639, 1516133128, 1461550545, 1406951526, 1302016099, 1230646740, 1142491917, 1087903418, -1398421865, -1469785312, -1524105735, -1578704818, -1079922613, -1151291908, -1239184603, -1293773166, -1968362705, -1905510760, -2094067647, -2014441994, -1716953613, -1654112188, -1876203875, -1796572374, -525066777, -462094256, -382327159, -302564546, -206542021, -143559028, -97365931, -17609246, -960696225, -1031934488, -817968335, -872425850, -709327229, -780559564, -600130067, -654598054, 1762451694, 1842216281, 1619975040, 1682949687, 2047383090, 2127137669, 1938468188, 2001449195, 1325665622, 1271206113, 1183200824, 1111960463, 1543535498, 1489069629, 1434599652, 1363369299, 622672798, 568075817, 748617968, 677256519, 907627842, 853037301, 1067152940, 995781531, 51762726, 131386257, 177728840, 240578815, 269590778, 349224269, 429104020, 491947555, -248556018, -168932423, -122852000, -60002089, -500490030, -420856475, -341238852, -278395381, -685261898, -739858943, -559578920, -630940305, -1004286614, -1058877219, -845023740, -916395085, -1119974018, -1174433591, -1262701040, -1333941337, -1371866206, -1426332139, -1481064244, -1552294533, -1690935098, -1611170447, -1833673816, -1770699233, -2009983462, -1930228819, -2119160460, -2056179517, 1569362073, 1498123566, 1409854455, 1355396672, 1317987909, 1246755826, 1192025387, 1137557660, 2072149281, 2135122070, 1912620623, 1992383480, 1753615357, 1816598090, 1627664531, 1707420964, 295390185, 358241886, 404320391, 483945776, 43990325, 106832002, 186451547, 266083308, 932423249, 861060070, 1041341759, 986742920, 613929101, 542559546, 756411363, 701822548, -978770311, -1050133554, -869589737, -924188512, -693284699, -764654318, -550540341, -605129092, -475935807, -413084042, -366743377, -287118056, -257573603, -194731862, -114850189, -35218492, -1984365303, -1921392450, -2143631769, -2063868976, -1698919467, -1635936670, -1824608069, -1744851700, -1347415887, -1418654458, -1506661409, -1561119128, -1129027987, -1200260134, -1254728445, -1309196108};
        k = new int[]{0, 4129, 8258, 12387, 16516, 20645, 24774, 28903, 33032, 37161, 41290, 45419, 49548, 53677, 57806, 61935};
        l = new int[]{0, 7, 14, 9, 28, 27, 18, 21, 56, 63, 54, 49, 36, 35, 42, 45, 112, 119, 126, 121, 108, 107, 98, 101, 72, 79, 70, 65, 84, 83, 90, 93, 224, 231, 238, 233, 252, 251, 242, 245, JfifUtil.MARKER_SOI, 223, 214, 209, 196, 195, 202, 205, 144, 151, 158, 153, 140, 139, 130, 133, 168, 175, 166, 161, 180, 179, 186, 189, 199, JfifUtil.MARKER_SOFn, 201, 206, 219, 220, 213, 210, JfifUtil.MARKER_FIRST_BYTE, 248, 241, 246, 227, 228, 237, 234, 183, 176, 185, 190, 171, 172, 165, 162, 143, 136, 129, 134, 147, 148, 157, 154, 39, 32, 41, 46, 59, 60, 53, 50, 31, 24, 17, 22, 3, 4, 13, 10, 87, 80, 89, 94, 75, 76, 69, 66, 111, 104, 97, 102, 115, 116, 125, 122, 137, 142, 135, 128, 149, 146, 155, 156, 177, 182, 191, 184, 173, 170, 163, 164, 249, 254, 247, 240, 229, 226, 235, 236, 193, 198, 207, 200, 221, JfifUtil.MARKER_SOS, 211, 212, 105, 110, 103, 96, 117, 114, 123, 124, 81, 86, 95, 88, 77, 74, 67, 68, 25, 30, 23, 16, 5, 2, 11, 12, 33, 38, 47, 40, 61, 58, 51, 52, 78, 73, 64, 71, 82, 85, 92, 91, 118, 113, 120, 127, 106, 109, 100, 99, 62, 57, 48, 55, 34, 37, 44, 43, 6, 1, 8, 15, 26, 29, 20, 19, 174, 169, 160, 167, 178, 181, 188, 187, 150, 145, 152, 159, 138, 141, 132, 131, 222, JfifUtil.MARKER_EOI, JfifUtil.MARKER_RST0, JfifUtil.MARKER_RST7, 194, 197, 204, 203, 230, JfifUtil.MARKER_APP1, 232, 239, 250, 253, 244, 243};
    }

    public static int A(String str) {
        String[] strArrSplit;
        int length;
        int i11 = 0;
        if (str == null || (length = (strArrSplit = str.split("_", -1)).length) < 2) {
            return 0;
        }
        String str2 = strArrSplit[length - 1];
        boolean z11 = length >= 3 && "neg".equals(strArrSplit[length - 2]);
        try {
            str2.getClass();
            i11 = Integer.parseInt(str2);
            if (z11) {
                return -i11;
            }
        } catch (NumberFormatException unused) {
        }
        return i11;
    }

    public static int B(int i11, ByteOrder byteOrder) {
        if (i11 == 32) {
            return byteOrder.equals(ByteOrder.LITTLE_ENDIAN) ? 4 : 1895825408;
        }
        if (i11 != 64) {
            return 0;
        }
        return byteOrder.equals(ByteOrder.LITTLE_ENDIAN) ? 1879048192 : 1912602624;
    }

    public static long C(long j6, float f3) {
        return f3 == 1.0f ? j6 : Math.round(j6 * ((double) f3));
    }

    public static long D(long j6) {
        return j6 == -9223372036854775807L ? System.currentTimeMillis() : SystemClock.elapsedRealtime() + j6;
    }

    public static int E(int i11, ByteOrder byteOrder) {
        if (i11 == 8) {
            return 3;
        }
        if (i11 == 16) {
            return byteOrder.equals(ByteOrder.LITTLE_ENDIAN) ? 2 : 268435456;
        }
        if (i11 == 24) {
            return byteOrder.equals(ByteOrder.LITTLE_ENDIAN) ? 21 : 1342177280;
        }
        if (i11 != 32) {
            return 0;
        }
        return byteOrder.equals(ByteOrder.LITTLE_ENDIAN) ? 22 : 1610612736;
    }

    public static long F(long j6, float f3) {
        return f3 == 1.0f ? j6 : Math.round(j6 / ((double) f3));
    }

    public static String G(StringBuilder sb2, Formatter formatter, long j6) {
        if (j6 == -9223372036854775807L) {
            j6 = 0;
        }
        String str = j6 < 0 ? "-" : "";
        long jAbs = (Math.abs(j6) + 500) / 1000;
        long j11 = jAbs % 60;
        long j12 = (jAbs / 60) % 60;
        long j13 = jAbs / 3600;
        sb2.setLength(0);
        return j13 > 0 ? formatter.format("%s%d:%02d:%02d", str, Long.valueOf(j13), Long.valueOf(j12), Long.valueOf(j11)).toString() : formatter.format("%s%02d:%02d", str, Long.valueOf(j12), Long.valueOf(j11)).toString();
    }

    public static String H(String str) {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            return (String) cls.getMethod("get", String.class).invoke(cls, str);
        } catch (Exception e4) {
            b.d("Util", "Failed to read system property ".concat(str), e4);
            return null;
        }
    }

    public static String I(int i11) {
        switch (i11) {
            case -2:
                return "none";
            case -1:
                return "unknown";
            case 0:
                return "default";
            case 1:
                return MediaStreamTrack.AUDIO_TRACK_KIND;
            case 2:
                return MediaStreamTrack.VIDEO_TRACK_KIND;
            case 3:
                return "text";
            case 4:
                return "image";
            case 5:
                return "metadata";
            case 6:
                return "camera motion";
            default:
                return i11 >= 10000 ? x2.e(i11, "custom (", ")") : "?";
        }
    }

    public static boolean J(e1 e1Var) {
        if (e1Var == null || !e1Var.D1(1)) {
            return false;
        }
        e1Var.d();
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:18:0x002a  */
    /* JADX WARN: Code duplicated, block: B:20:0x002e A[RETURN] */
    public static boolean K(e1 e1Var) {
        boolean z11 = false;
        if (e1Var == null) {
            return false;
        }
        int I = e1Var.I();
        if (I != 1 || !e1Var.D1(2)) {
            if (I == 4 && e1Var.D1(4)) {
                e1Var.C0();
            }
            if (e1Var.D1(1)) {
                return z11;
            }
            e1Var.N();
            return true;
        }
        e1Var.b();
        z11 = true;
        if (e1Var.D1(1)) {
            return z11;
        }
        e1Var.N();
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:76:0x00e1 A[RETURN] */
    public static int L(Uri uri, String str) {
        int i11;
        if (str != null) {
            switch (str) {
                case "application/x-mpegURL":
                    return 2;
                case "application/vnd.ms-sstr+xml":
                    return 1;
                case "application/dash+xml":
                    return 0;
                case "application/x-rtsp":
                    return 3;
                default:
                    return 4;
            }
        }
        String scheme = uri.getScheme();
        if (scheme == null || (!k80.l.s("rtsp", scheme) && !k80.l.s("rtspt", scheme))) {
            String lastPathSegment = uri.getLastPathSegment();
            if (lastPathSegment != null) {
                int iLastIndexOf = lastPathSegment.lastIndexOf(46);
                if (iLastIndexOf >= 0) {
                    String strZ = k80.l.Z(lastPathSegment.substring(iLastIndexOf + 1));
                    strZ.getClass();
                    switch (strZ.hashCode()) {
                        case 104579:
                            if (strZ.equals("ism")) {
                            }
                            break;
                        case 108321:
                            if (strZ.equals("mpd")) {
                            }
                            break;
                        case 3242057:
                            if (strZ.equals("isml")) {
                            }
                            break;
                        case 3299913:
                            if (strZ.equals("m3u8")) {
                            }
                            break;
                    }
                    /*  JADX ERROR: Method code generation error
                        java.lang.NullPointerException: Switch insn not found in header
                        	at java.base/java.util.Objects.requireNonNull(Objects.java:259)
                        	at jadx.core.codegen.RegionGen.makeSwitch(RegionGen.java:246)
                        	at jadx.core.dex.regions.SwitchRegion.generate(SwitchRegion.java:90)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                        	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                        	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                        	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:295)
                        	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:274)
                        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                        */
                    /*
                        Method dump skipped, instruction units count: 286
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: n3.l0.L(android.net.Uri, java.lang.String):int");
                }

                public static boolean M(x xVar, x xVar2, Inflater inflater) {
                    if (xVar.a() == 0) {
                        return false;
                    }
                    if (xVar2.f22410a.length < xVar.a()) {
                        xVar2.c(xVar.a() * 2);
                    }
                    if (inflater == null) {
                        inflater = new Inflater();
                    }
                    inflater.setInput(xVar.f22410a, xVar.f22411b, xVar.a());
                    int iInflate = 0;
                    while (true) {
                        try {
                            byte[] bArr = xVar2.f22410a;
                            iInflate += inflater.inflate(bArr, iInflate, bArr.length - iInflate);
                            if (inflater.finished()) {
                                xVar2.M(iInflate);
                                inflater.reset();
                                return true;
                            }
                            if (!inflater.needsDictionary() && !inflater.needsInput()) {
                                byte[] bArr2 = xVar2.f22410a;
                                if (iInflate == bArr2.length) {
                                    xVar2.c(bArr2.length * 2);
                                }
                            }
                            inflater.reset();
                            return false;
                        } catch (DataFormatException unused) {
                            inflater.reset();
                            return false;
                        } catch (Throwable th2) {
                            inflater.reset();
                            throw th2;
                        }
                    }
                }

                public static boolean N(int i11) {
                    return i11 == 3 || i11 == 2 || i11 == 268435456 || i11 == 21 || i11 == 1342177280 || i11 == 22 || i11 == 1610612736 || i11 == 4 || i11 == 1895825408 || i11 == 1879048192 || i11 == 1912602624;
                }

                public static boolean O(Context context) {
                    int i11 = Build.VERSION.SDK_INT;
                    if (i11 < 29 || context.getApplicationInfo().targetSdkVersion < 29) {
                        return true;
                    }
                    if (i11 == 30) {
                        String str = Build.MODEL;
                        if (k80.l.s(str, "moto g(20)") || k80.l.s(str, "rmx3231")) {
                            return true;
                        }
                    }
                    return i11 == 34 && k80.l.s(Build.MODEL, "sm-x200");
                }

                public static boolean P(int i11) {
                    return i11 == 10 || i11 == 13;
                }

                public static boolean Q(Context context) {
                    UiModeManager uiModeManager = (UiModeManager) context.getApplicationContext().getSystemService("uimode");
                    return uiModeManager != null && uiModeManager.getCurrentModeType() == 4;
                }

                public static void R(ArrayList arrayList, int i11, int i12, int i13) {
                    ArrayDeque arrayDeque = new ArrayDeque();
                    for (int i14 = (i12 - i11) - 1; i14 >= 0; i14--) {
                        arrayDeque.addFirst(arrayList.remove(i11 + i14));
                    }
                    arrayList.addAll(Math.min(i13, arrayList.size()), arrayDeque);
                }

                public static long S(long j6) {
                    return (j6 == -9223372036854775807L || j6 == Long.MIN_VALUE) ? j6 : j6 * 1000;
                }

                public static String T(String str) {
                    if (str == null) {
                        return null;
                    }
                    String strReplace = str.replace('_', '-');
                    if (!strReplace.isEmpty() && !strReplace.equals("und")) {
                        str = strReplace;
                    }
                    String strZ = k80.l.Z(str);
                    int i11 = 0;
                    String str2 = strZ.split("-", 2)[0];
                    if (f22364g == null) {
                        String[] iSOLanguages = Locale.getISOLanguages();
                        int length = iSOLanguages.length;
                        String[] strArr = f22365h;
                        HashMap map = new HashMap(length + strArr.length);
                        for (String str3 : iSOLanguages) {
                            try {
                                String iSO3Language = new Locale(str3).getISO3Language();
                                if (!TextUtils.isEmpty(iSO3Language)) {
                                    map.put(iSO3Language, str3);
                                }
                            } catch (MissingResourceException unused) {
                            }
                        }
                        for (int i12 = 0; i12 < strArr.length; i12 += 2) {
                            map.put(strArr[i12], strArr[i12 + 1]);
                        }
                        f22364g = map;
                    }
                    String str4 = (String) f22364g.get(str2);
                    if (str4 != null) {
                        StringBuilder sbB = v0.d.b(str4);
                        sbB.append(strZ.substring(str2.length()));
                        strZ = sbB.toString();
                        str2 = str4;
                    }
                    if (!"no".equals(str2) && !"i".equals(str2) && !"zh".equals(str2)) {
                        return strZ;
                    }
                    while (true) {
                        String[] strArr2 = f22366i;
                        if (i11 >= strArr2.length) {
                            return strZ;
                        }
                        if (strZ.startsWith(strArr2[i11])) {
                            return strArr2[i11 + 1] + strZ.substring(strArr2[i11].length());
                        }
                        i11 += 2;
                    }
                }

                public static Object[] U(int i11, Object[] objArr) {
                    oq.a.n(i11 <= objArr.length);
                    return Arrays.copyOf(objArr, i11);
                }

                public static long V(String str) throws v0 {
                    Matcher matcher = f22361d.matcher(str);
                    if (!matcher.matches()) {
                        throw v0.a("Invalid date/time format: " + str, null);
                    }
                    int i11 = 0;
                    if (matcher.group(9) != null && !matcher.group(9).equalsIgnoreCase("Z")) {
                        int i12 = Integer.parseInt(matcher.group(12)) * 60;
                        String strGroup = matcher.group(13);
                        i11 = strGroup != null ? Integer.parseInt(strGroup) + i12 : i12;
                        if ("-".equals(matcher.group(11))) {
                            i11 *= -1;
                        }
                    }
                    GregorianCalendar gregorianCalendar = new GregorianCalendar(DesugarTimeZone.getTimeZone("GMT"));
                    gregorianCalendar.clear();
                    gregorianCalendar.set(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)) - 1, Integer.parseInt(matcher.group(3)), Integer.parseInt(matcher.group(4)), Integer.parseInt(matcher.group(5)), Integer.parseInt(matcher.group(6)));
                    if (!TextUtils.isEmpty(matcher.group(8))) {
                        gregorianCalendar.set(14, new BigDecimal("0." + matcher.group(8)).movePointRight(3).intValue());
                    }
                    long timeInMillis = gregorianCalendar.getTimeInMillis();
                    return i11 != 0 ? timeInMillis - (((long) i11) * 60000) : timeInMillis;
                }

                public static void W(Handler handler, Runnable runnable) {
                    Looper looper = handler.getLooper();
                    if (looper.getThread().isAlive()) {
                        if (looper == Looper.myLooper()) {
                            runnable.run();
                        } else {
                            handler.post(runnable);
                        }
                    }
                }

                public static void X(Context context, BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
                    if (Build.VERSION.SDK_INT < 33) {
                        context.registerReceiver(broadcastReceiver, intentFilter);
                    } else {
                        context.registerReceiver(broadcastReceiver, intentFilter, 4);
                    }
                }

                public static long Y(int i11, long j6) {
                    return a0(j6, 1000000L, i11, RoundingMode.DOWN);
                }

                public static void Z(long[] jArr, long j6) {
                    long j11;
                    RoundingMode roundingMode = RoundingMode.DOWN;
                    int i11 = 0;
                    if (j6 >= 1000000 && j6 % 1000000 == 0) {
                        long jM = z20.g.m(j6, 1000000L, RoundingMode.UNNECESSARY);
                        while (i11 < jArr.length) {
                            jArr[i11] = z20.g.m(jArr[i11], jM, roundingMode);
                            i11++;
                        }
                        return;
                    }
                    if (j6 < 1000000 && 1000000 % j6 == 0) {
                        long jM2 = z20.g.m(1000000L, j6, RoundingMode.UNNECESSARY);
                        while (i11 < jArr.length) {
                            jArr[i11] = z20.g.S(jArr[i11], jM2);
                            i11++;
                        }
                        return;
                    }
                    int i12 = 0;
                    while (i12 < jArr.length) {
                        long j12 = jArr[i12];
                        if (j12 != 0) {
                            if (j6 >= j12 && j6 % j12 == 0) {
                                jArr[i12] = z20.g.m(1000000L, z20.g.m(j6, j12, RoundingMode.UNNECESSARY), roundingMode);
                            } else if (j6 >= j12 || j12 % j6 != 0) {
                                j11 = j6;
                                jArr[i12] = b0(j12, 1000000L, j11, roundingMode);
                            } else {
                                jArr[i12] = z20.g.S(1000000L, z20.g.m(j12, j6, RoundingMode.UNNECESSARY));
                            }
                            j11 = j6;
                        } else {
                            j11 = j6;
                        }
                        i12++;
                        j6 = j11;
                    }
                }

                public static long a(long j6, long j11) {
                    long j12 = j6 + j11;
                    long j13 = (((j11 ^ j6) > 0L ? 1 : ((j11 ^ j6) == 0L ? 0 : -1)) < 0) | ((j6 ^ j12) >= 0) ? j12 : ((j12 >>> 63) ^ 1) + Long.MAX_VALUE;
                    if ((j13 != Long.MIN_VALUE || j12 == Long.MIN_VALUE) && (j13 != Long.MAX_VALUE || j12 == Long.MAX_VALUE)) {
                        return j13;
                    }
                    return Long.MAX_VALUE;
                }

                public static long a0(long j6, long j11, long j12, RoundingMode roundingMode) {
                    if (j6 == 0 || j11 == 0) {
                        return 0L;
                    }
                    if (j12 >= j11 && j12 % j11 == 0) {
                        return z20.g.m(j6, z20.g.m(j12, j11, RoundingMode.UNNECESSARY), roundingMode);
                    }
                    if (j12 < j11 && j11 % j12 == 0) {
                        return z20.g.S(j6, z20.g.m(j11, j12, RoundingMode.UNNECESSARY));
                    }
                    if (j12 < j6 || j12 % j6 != 0) {
                        return (j12 >= j6 || j6 % j12 != 0) ? b0(j6, j11, j12, roundingMode) : z20.g.S(j11, z20.g.m(j6, j12, RoundingMode.UNNECESSARY));
                    }
                    return z20.g.m(j11, z20.g.m(j12, j6, RoundingMode.UNNECESSARY), roundingMode);
                }

                public static int b(long[] jArr, long j6, boolean z11) {
                    int i11;
                    int iBinarySearch = Arrays.binarySearch(jArr, j6);
                    if (iBinarySearch < 0) {
                        return ~iBinarySearch;
                    }
                    while (true) {
                        i11 = iBinarySearch + 1;
                        if (i11 >= jArr.length || jArr[i11] != j6) {
                            break;
                        }
                        iBinarySearch = i11;
                    }
                    return z11 ? iBinarySearch : i11;
                }

                /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
                /* JADX WARN: Code duplicated, block: B:54:0x00de  */
                /* JADX WARN: Code duplicated, block: B:58:0x00f0  */
                /* JADX WARN: Code duplicated, block: B:59:0x00f2  */
                /* JADX WARN: Code duplicated, block: B:63:0x00f8  */
                /* JADX WARN: Code duplicated, block: B:66:0x00fd  */
                /* JADX WARN: Code duplicated, block: B:68:0x00ff  */
                /* JADX WARN: Instruction removed from duplicated block: B:68:0x00ff, please report this as an issue */
                public static long b0(long j6, long j11, long j12, RoundingMode roundingMode) {
                    double dRint;
                    long j13;
                    boolean z11;
                    long jS = z20.g.S(j6, j11);
                    if (jS != Long.MAX_VALUE && jS != Long.MIN_VALUE) {
                        return z20.g.m(jS, j12, roundingMode);
                    }
                    long jQ = z20.g.q(Math.abs(j11), Math.abs(j12));
                    RoundingMode roundingMode2 = RoundingMode.UNNECESSARY;
                    long jM = z20.g.m(j11, jQ, roundingMode2);
                    long jM2 = z20.g.m(j12, jQ, roundingMode2);
                    long jQ2 = z20.g.q(Math.abs(j6), Math.abs(jM2));
                    long jM3 = z20.g.m(j6, jQ2, roundingMode2);
                    long jM4 = z20.g.m(jM2, jQ2, roundingMode2);
                    long jS2 = z20.g.S(jM3, jM);
                    if (jS2 != Long.MAX_VALUE && jS2 != Long.MIN_VALUE) {
                        return z20.g.m(jS2, jM4, roundingMode);
                    }
                    double d11 = jM3 * (jM / jM4);
                    if (d11 > 9.223372036854776E18d) {
                        return Long.MAX_VALUE;
                    }
                    if (d11 < -9.223372036854776E18d) {
                        return Long.MIN_VALUE;
                    }
                    int i11 = jx.c.f18410a;
                    if (!ul.b.G(d11)) {
                        throw new ArithmeticException("input is infinite or NaN");
                    }
                    switch (jx.b.f18409a[roundingMode.ordinal()]) {
                        case 1:
                            z80.a.g(jx.c.a(d11));
                            dRint = d11;
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 2:
                            if (d11 >= 0.0d || jx.c.a(d11)) {
                                dRint = d11;
                            } else {
                                j13 = ((long) d11) - 1;
                                dRint = j13;
                            }
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 3:
                            if (d11 <= 0.0d || jx.c.a(d11)) {
                                dRint = d11;
                            } else {
                                j13 = ((long) d11) + 1;
                                dRint = j13;
                            }
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 4:
                            dRint = d11;
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 5:
                            if (jx.c.a(d11)) {
                                dRint = d11;
                            } else {
                                dRint = ((long) d11) + ((long) (d11 > 0.0d ? 1 : -1));
                            }
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 6:
                            dRint = Math.rint(d11);
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 7:
                            dRint = Math.rint(d11);
                            if (Math.abs(d11 - dRint) == 0.5d) {
                                dRint = Math.copySign(0.5d, d11) + d11;
                            }
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        case 8:
                            dRint = Math.rint(d11);
                            if (Math.abs(d11 - dRint) == 0.5d) {
                                dRint = d11;
                            }
                            if ((-9.223372036854776E18d) - dRint < 1.0d) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if (z11 && (dRint < 9.223372036854776E18d)) {
                                return (long) dRint;
                            }
                            throw new ArithmeticException("rounded value is out of range for input " + d11 + " and rounding mode " + roundingMode);
                        default:
                            throw new AssertionError();
                    }
                }

                public static int c(List list, Long l2, boolean z11) {
                    int i11;
                    int iBinarySearch = Collections.binarySearch(list, l2);
                    if (iBinarySearch < 0) {
                        i11 = -(iBinarySearch + 2);
                    } else {
                        while (true) {
                            int i12 = iBinarySearch - 1;
                            if (i12 < 0 || ((Comparable) list.get(i12)).compareTo(l2) != 0) {
                                break;
                            }
                            iBinarySearch = i12;
                        }
                        i11 = iBinarySearch;
                    }
                    return z11 ? Math.max(0, i11) : i11;
                }

                public static boolean c0(e1 e1Var, boolean z11) {
                    return e1Var == null || !e1Var.o() || e1Var.I() == 1 || e1Var.I() == 4 || !(!z11 || e1Var.S() == 0 || e1Var.S() == 4);
                }

                public static int d(r rVar, long j6) {
                    int i11 = rVar.f22392b - 1;
                    int i12 = 0;
                    while (i12 <= i11) {
                        int i13 = (i12 + i11) >>> 1;
                        if (rVar.c(i13) < j6) {
                            i12 = i13 + 1;
                        } else {
                            i11 = i13 - 1;
                        }
                    }
                    int i14 = i11 + 1;
                    if (i14 < rVar.f22392b && rVar.c(i14) == j6) {
                        return i14;
                    }
                    if (i11 == -1) {
                        return 0;
                    }
                    return i11;
                }

                public static String[] d0(String str) {
                    return TextUtils.isEmpty(str) ? new String[0] : str.trim().split("(\\s*,\\s*)", -1);
                }

                public static int e(int[] iArr, int i11, boolean z11, boolean z12) {
                    int i12;
                    int i13;
                    int iBinarySearch = Arrays.binarySearch(iArr, i11);
                    if (iBinarySearch < 0) {
                        i13 = -(iBinarySearch + 2);
                    } else {
                        while (true) {
                            i12 = iBinarySearch - 1;
                            if (i12 < 0 || iArr[i12] != i11) {
                                break;
                            }
                            iBinarySearch = i12;
                        }
                        i13 = z11 ? iBinarySearch : i12;
                    }
                    return z12 ? Math.max(0, i13) : i13;
                }

                public static String e0(int i11) {
                    return new String(new byte[]{(byte) (i11 >> 24), (byte) (i11 >> 16), (byte) (i11 >> 8), (byte) i11}, StandardCharsets.US_ASCII);
                }

                public static int f(long[] jArr, long j6, boolean z11) {
                    int i11;
                    int iBinarySearch = Arrays.binarySearch(jArr, j6);
                    if (iBinarySearch < 0) {
                        i11 = -(iBinarySearch + 2);
                    } else {
                        while (true) {
                            int i12 = iBinarySearch - 1;
                            if (i12 < 0 || jArr[i12] != j6) {
                                break;
                            }
                            iBinarySearch = i12;
                        }
                        i11 = iBinarySearch;
                    }
                    return z11 ? Math.max(0, i11) : i11;
                }

                public static mx.e0 f0(mx.y yVar, mx.q qVar) {
                    mx.e0 e0Var = new mx.e0();
                    io.sentry.react.c cVar = new io.sentry.react.c(18, e0Var, yVar);
                    mx.r rVar = mx.r.f22087d;
                    e0Var.a(cVar, rVar);
                    yVar.a(new a6.m0(19, yVar, e0Var, qVar), rVar);
                    return e0Var;
                }

                public static int g(int i11, int i12) {
                    return ((i11 + i12) - 1) / i12;
                }

                public static long g0(long j6) {
                    return (j6 == -9223372036854775807L || j6 == Long.MIN_VALUE) ? j6 : j6 / 1000;
                }

                public static void h(Closeable closeable) {
                    if (closeable != null) {
                        try {
                            closeable.close();
                        } catch (IOException unused) {
                        }
                    }
                }

                public static float i(float f3, float f11, float f12) {
                    return Math.max(f11, Math.min(f3, f12));
                }

                public static int j(int i11, int i12, int i13) {
                    return Math.max(i12, Math.min(i11, i13));
                }

                public static long k(long j6, long j11, long j12) {
                    return Math.max(j11, Math.min(j6, j12));
                }

                public static boolean l(SparseArray sparseArray, int i11) {
                    return sparseArray.indexOfKey(i11) >= 0;
                }

                public static boolean m(Object obj, Object[] objArr) {
                    for (Object obj2 : objArr) {
                        if (Objects.equals(obj2, obj)) {
                            return true;
                        }
                    }
                    return false;
                }

                public static boolean n(SparseArray sparseArray, SparseArray sparseArray2) {
                    if (sparseArray == null) {
                        return sparseArray2 == null;
                    }
                    if (sparseArray2 == null) {
                        return false;
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        return sparseArray.contentEquals(sparseArray2);
                    }
                    int size = sparseArray.size();
                    if (size != sparseArray2.size()) {
                        return false;
                    }
                    for (int i11 = 0; i11 < size; i11++) {
                        if (!Objects.equals(sparseArray.valueAt(i11), sparseArray2.get(sparseArray.keyAt(i11)))) {
                            return false;
                        }
                    }
                    return true;
                }

                public static int o(SparseArray sparseArray) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        return sparseArray.contentHashCode();
                    }
                    int iHashCode = 17;
                    for (int i11 = 0; i11 < sparseArray.size(); i11++) {
                        iHashCode = Objects.hashCode(sparseArray.valueAt(i11)) + ((sparseArray.keyAt(i11) + (iHashCode * 31)) * 31);
                    }
                    return iHashCode;
                }

                public static Bundle p(Bundle bundle) {
                    if (bundle == null) {
                        return null;
                    }
                    ClassLoader classLoader = l0.class.getClassLoader();
                    classLoader.getClass();
                    bundle.setClassLoader(classLoader);
                    try {
                        bundle.isEmpty();
                        return bundle;
                    } catch (RuntimeException e4) {
                        b.d("Util", "Ignoring invalid bundle", e4);
                        return null;
                    }
                }

                public static int q(int i11, int i12, int i13, byte[] bArr) {
                    while (i11 < i12) {
                        i13 = f22367j[((i13 >>> 24) ^ (bArr[i11] & 255)) & JfifUtil.MARKER_FIRST_BYTE] ^ (i13 << 8);
                        i11++;
                    }
                    return i13;
                }

                public static Handler r(m4.m mVar) {
                    Looper looperMyLooper = Looper.myLooper();
                    looperMyLooper.getClass();
                    return new Handler(looperMyLooper, mVar);
                }

                public static int s(int i11) {
                    switch (i11) {
                        case 2:
                        case 3:
                            return 3;
                        case 4:
                        case 5:
                        case 6:
                            return 21;
                        case 7:
                        case 8:
                            return 23;
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                        case 15:
                        case 16:
                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                            return 28;
                        case 13:
                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                        case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                        case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                        case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                        case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                        case 27:
                        case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                        case 29:
                        default:
                            return Integer.MAX_VALUE;
                        case 14:
                            return 25;
                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                            return 30;
                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                            return 31;
                        case RendererMetrics.SAMPLES /* 30 */:
                        case 31:
                            return 34;
                    }
                }

                public static int t(int i11) {
                    if (i11 == 10) {
                        return Build.VERSION.SDK_INT >= 32 ? 737532 : 6396;
                    }
                    if (i11 == 16) {
                        return Build.VERSION.SDK_INT >= 32 ? 205215996 : 0;
                    }
                    if (i11 == 24) {
                        return Build.VERSION.SDK_INT >= 32 ? 67108860 : 0;
                    }
                    switch (i11) {
                        case 1:
                            return 4;
                        case 2:
                            return 12;
                        case 3:
                            return 28;
                        case 4:
                            return 204;
                        case 5:
                            return 220;
                        case 6:
                            return 252;
                        case 7:
                            return 1276;
                        case 8:
                            return 6396;
                        default:
                            switch (i11) {
                                case 12:
                                    return 743676;
                                case 13:
                                    return Build.VERSION.SDK_INT >= 32 ? 30136348 : 0;
                                case 14:
                                    return Build.VERSION.SDK_INT >= 32 ? 202070268 : 0;
                                default:
                                    return 0;
                            }
                    }
                }

                public static int u(int i11) {
                    if (i11 != 2) {
                        if (i11 == 3) {
                            return 1;
                        }
                        if (i11 != 4) {
                            if (i11 != 21) {
                                if (i11 != 22) {
                                    if (i11 != 268435456) {
                                        if (i11 != 1342177280) {
                                            if (i11 != 1610612736) {
                                                if (i11 == 1879048192) {
                                                    return 8;
                                                }
                                                if (i11 != 1895825408) {
                                                    if (i11 == 1912602624) {
                                                        return 8;
                                                    }
                                                    throw new IllegalArgumentException();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return 3;
                        }
                        return 4;
                    }
                    return 2;
                }

                public static int v(int i11, String str) {
                    int i12 = 0;
                    for (String str2 : d0(str)) {
                        if (i11 == u0.h(u0.d(str2))) {
                            i12++;
                        }
                    }
                    return i12;
                }

                public static String w(int i11, String str) {
                    String[] strArrD0 = d0(str);
                    if (strArrD0.length == 0) {
                        return null;
                    }
                    StringBuilder sb2 = new StringBuilder();
                    for (String str2 : strArrD0) {
                        if (i11 == u0.h(u0.d(str2))) {
                            if (sb2.length() > 0) {
                                sb2.append(",");
                            }
                            sb2.append(str2);
                        }
                    }
                    if (sb2.length() > 0) {
                        return sb2.toString();
                    }
                    return null;
                }

                public static Point x(Context context) {
                    DisplayManager displayManager = (DisplayManager) context.getSystemService("display");
                    Display display = displayManager != null ? displayManager.getDisplay(0) : null;
                    if (display == null) {
                        WindowManager windowManager = (WindowManager) context.getSystemService("window");
                        windowManager.getClass();
                        display = windowManager.getDefaultDisplay();
                    }
                    if (display.getDisplayId() == 0 && Q(context)) {
                        String strH = Build.VERSION.SDK_INT < 28 ? H("sys.display-size") : H("vendor.display-size");
                        if (!TextUtils.isEmpty(strH)) {
                            try {
                                String[] strArrSplit = strH.trim().split("x", -1);
                                if (strArrSplit.length == 2) {
                                    int i11 = Integer.parseInt(strArrSplit[0]);
                                    int i12 = Integer.parseInt(strArrSplit[1]);
                                    if (i11 > 0 && i12 > 0) {
                                        return new Point(i11, i12);
                                    }
                                }
                            } catch (NumberFormatException unused) {
                            }
                            b.c("Util", "Invalid display size: " + strH);
                        }
                        if ("Sony".equals(Build.MANUFACTURER) && Build.MODEL.startsWith("BRAVIA") && context.getPackageManager().hasSystemFeature("com.sony.dtv.hardware.panel.qfhd")) {
                            return new Point(3840, 2160);
                        }
                    }
                    Point point = new Point();
                    Display.Mode mode = display.getMode();
                    point.x = mode.getPhysicalWidth();
                    point.y = mode.getPhysicalHeight();
                    return point;
                }

                public static Looper y() {
                    Looper looperMyLooper = Looper.myLooper();
                    return looperMyLooper != null ? looperMyLooper : Looper.getMainLooper();
                }

                public static int z(int i11) {
                    if (i11 == 2 || i11 == 4) {
                        return 6005;
                    }
                    if (i11 == 10) {
                        return 6004;
                    }
                    if (i11 == 7) {
                        return 6005;
                    }
                    if (i11 == 8) {
                        return 6003;
                    }
                    switch (i11) {
                        case 15:
                            return 6003;
                        case 16:
                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                            return 6005;
                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                            return 6004;
                        default:
                            switch (i11) {
                                case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                                case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                                case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                                case 27:
                                case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                                    return 6002;
                                default:
                                    return 6006;
                            }
                    }
                }
            }
