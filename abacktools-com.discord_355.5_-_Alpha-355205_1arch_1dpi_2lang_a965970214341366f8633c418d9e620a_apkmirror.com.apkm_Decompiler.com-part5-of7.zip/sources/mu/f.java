package mu;

import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes3.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f22018a = 0;

    static {
        Pattern.compile("\\$\\{(.*?)\\}");
    }
}
