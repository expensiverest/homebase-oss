package mu;

import androidx.core.view.g0;
import com.google.android.gms.internal.fido.l7;
import com.google.android.gms.internal.fido.r7;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes3.dex */
public abstract class d {
    static {
        Pattern.compile("^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$");
        Pattern.compile("^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$");
        Pattern.compile("^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r1v2, types: [java.util.HashMap] */
    public static Map a(URI uri) {
        String strDecode;
        ?? map = Collections.EMPTY_MAP;
        String rawQuery = uri.getRawQuery();
        if (rawQuery != null && rawQuery.length() > 0) {
            map = new HashMap();
            bj.d dVar = new bj.d(new g0(13, new l7('=', 1)), false, 4);
            bj.d dVar2 = new bj.d(new g0(13, new l7('&', 1)), true, 4);
            r7 r7Var = new r7(dVar2, rawQuery, (l7) ((g0) dVar2.f3726i).f1494e, (byte) 0);
            while (r7Var.hasNext()) {
                String str = (String) r7Var.next();
                str.getClass();
                r7 r7Var2 = new r7(dVar, str, (l7) ((g0) dVar.f3726i).f1494e, (byte) 0);
                ArrayList arrayList = new ArrayList();
                while (r7Var2.hasNext()) {
                    arrayList.add((String) r7Var2.next());
                }
                List listUnmodifiableList = Collections.unmodifiableList(arrayList);
                if (listUnmodifiableList.isEmpty() || listUnmodifiableList.size() > 2) {
                    throw new IllegalArgumentException("bad parameter");
                }
                try {
                    String strDecode2 = URLDecoder.decode((String) listUnmodifiableList.get(0), "UTF-8");
                    if (listUnmodifiableList.size() == 2) {
                        try {
                            strDecode = URLDecoder.decode((String) listUnmodifiableList.get(1), "UTF-8");
                        } catch (UnsupportedEncodingException e4) {
                            throw new IllegalArgumentException(e4);
                        }
                    } else {
                        strDecode = null;
                    }
                    map.put(strDecode2, strDecode);
                } catch (UnsupportedEncodingException e9) {
                    throw new IllegalArgumentException(e9);
                }
            }
        }
        return map;
    }
}
