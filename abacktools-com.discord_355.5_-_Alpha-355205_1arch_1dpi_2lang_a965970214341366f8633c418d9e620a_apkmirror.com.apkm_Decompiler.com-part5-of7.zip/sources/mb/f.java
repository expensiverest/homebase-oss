package mb;

import kotlin.jvm.functions.Function2;
import l30.a0;
import z60.x;
import z60.z;

/* JADX INFO: loaded from: classes.dex */
public final class f extends s30.i implements Function2 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21296d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21297e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(int i11, q30.c cVar, int i12) {
        super(i11, cVar);
        this.f21296d = i12;
    }

    @Override // s30.a
    public final q30.c create(Object obj, q30.c cVar) {
        switch (this.f21296d) {
            case 0:
                return new f(2, cVar, 0);
            case 1:
                return new f(2, cVar, 1);
            case 2:
                return new f(2, cVar, 2);
            case 3:
                return new f(2, cVar, 3);
            default:
                return new f(2, cVar, 4);
        }
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        x xVar = (x) obj;
        q30.c cVar = (q30.c) obj2;
        switch (this.f21296d) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
        return ((f) create(xVar, cVar)).invokeSuspend(a0.f19963a);
    }

    @Override // s30.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f21296d) {
            case 0:
                r30.a aVar = r30.a.f27567d;
                int i11 = this.f21297e;
                if (i11 == 0) {
                    android.support.v4.media.session.b.i0(obj);
                    this.f21297e = 1;
                    if (z.k(100L, this) == aVar) {
                        return aVar;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    android.support.v4.media.session.b.i0(obj);
                }
                return a0.f19963a;
            case 1:
                r30.a aVar2 = r30.a.f27567d;
                int i12 = this.f21297e;
                if (i12 == 0) {
                    android.support.v4.media.session.b.i0(obj);
                    this.f21297e = 1;
                    if (z.k(500L, this) == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i12 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    android.support.v4.media.session.b.i0(obj);
                }
                return a0.f19963a;
            case 2:
                r30.a aVar3 = r30.a.f27567d;
                int i13 = this.f21297e;
                if (i13 == 0) {
                    android.support.v4.media.session.b.i0(obj);
                    this.f21297e = 1;
                    if (z.k(500L, this) == aVar3) {
                        return aVar3;
                    }
                } else {
                    if (i13 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    android.support.v4.media.session.b.i0(obj);
                }
                return a0.f19963a;
            case 3:
                r30.a aVar4 = r30.a.f27567d;
                int i14 = this.f21297e;
                if (i14 == 0) {
                    android.support.v4.media.session.b.i0(obj);
                    this.f21297e = 1;
                    if (z.k(50L, this) == aVar4) {
                        return aVar4;
                    }
                } else {
                    if (i14 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    android.support.v4.media.session.b.i0(obj);
                }
                return a0.f19963a;
            default:
                r30.a aVar5 = r30.a.f27567d;
                int i15 = this.f21297e;
                if (i15 == 0) {
                    android.support.v4.media.session.b.i0(obj);
                    this.f21297e = 1;
                    if (z.k(50L, this) == aVar5) {
                        return aVar5;
                    }
                } else {
                    if (i15 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    android.support.v4.media.session.b.i0(obj);
                }
                return a0.f19963a;
        }
    }
}
