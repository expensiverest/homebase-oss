package mb;

import hs.q;
import kotlin.jvm.internal.k;
import p.x2;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f21290a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f21291b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f21292c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f21293d;

    public d(String str, int i11, int i12, String editId) {
        k.g(editId, "editId");
        this.f21290a = i11;
        this.f21291b = i12;
        this.f21292c = str;
        this.f21293d = editId;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return this.f21290a == dVar.f21290a && this.f21291b == dVar.f21291b && k.b(this.f21292c, dVar.f21292c) && k.b(this.f21293d, dVar.f21293d);
    }

    public final int hashCode() {
        return this.f21293d.hashCode() + q.c(q.a(this.f21291b, Integer.hashCode(this.f21290a) * 31, 31), 31, this.f21292c);
    }

    public final String toString() {
        return x2.k(a1.h.m(this.f21290a, "CurrentTextAndSelection(selectionStart=", this.f21291b, ", selectionEnd=", ", text="), this.f21292c, ", editId=", this.f21293d, ")");
    }
}
