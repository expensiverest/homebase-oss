package mb;

import android.view.View;
import android.view.ViewGroup;
import com.discord.chat.input.ChatInputViewManager;
import com.discord.chat.input.views.DCDChatInput;
import com.facebook.react.uimanager.k0;
import fb.l;
import t10.z0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements View.OnFocusChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f21286a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f21287b;

    public /* synthetic */ a(ViewGroup viewGroup, int i11) {
        this.f21286a = i11;
        this.f21287b = viewGroup;
    }

    @Override // android.view.View.OnFocusChangeListener
    public final void onFocusChange(View view, boolean z11) {
        switch (this.f21286a) {
            case 0:
                g gVar = (g) this.f21287b;
                DCDChatInput dCDChatInput = gVar.y;
                if (!z11) {
                    c cVar = gVar.f21301v;
                    if (cVar != null) {
                        l lVar = (l) cVar;
                        ((ChatInputViewManager) lVar.f11665e).getReactEvents().c((k0) lVar.f11666i, (g) lVar.f11667v, new ib.f(String.valueOf(dCDChatInput.getText())));
                    }
                } else {
                    c cVar2 = gVar.f21301v;
                    if (cVar2 != null) {
                        l lVar2 = (l) cVar2;
                        ((ChatInputViewManager) lVar2.f11665e).getReactEvents().c((k0) lVar2.f11666i, (g) lVar2.f11667v, new ib.i(dCDChatInput.getSelectionStart(), dCDChatInput.getSelectionStart()));
                    }
                }
                break;
            default:
                z0 z0Var = (z0) this.f21287b;
                int i11 = z0Var.O;
                z0Var.t(z11 ? new bq.i(i11, z0Var.getId(), 17) : new bq.i(i11, z0Var.getId(), 15));
                break;
        }
    }
}
