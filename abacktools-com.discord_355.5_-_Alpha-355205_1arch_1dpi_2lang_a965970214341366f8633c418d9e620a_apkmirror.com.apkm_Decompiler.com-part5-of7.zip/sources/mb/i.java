package mb;

import android.content.Context;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i extends kotlin.jvm.internal.a implements Function1 {
    public static final i y = new i(kotlin.jvm.internal.c.NO_RECEIVER, g.class, "<init>", "<init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V");

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Context p11 = (Context) obj;
        k.g(p11, "p0");
        return new g(p11);
    }
}
