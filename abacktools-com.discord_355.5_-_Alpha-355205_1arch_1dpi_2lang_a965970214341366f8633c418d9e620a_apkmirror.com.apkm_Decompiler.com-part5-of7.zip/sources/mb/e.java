package mb;

import android.content.Context;
import android.text.Editable;
import android.text.Selection;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import androidx.core.view.d1;
import com.discord.R;
import com.discord.chat.input.views.DCDChatInput;
import kotlin.jvm.internal.k;
import m30.q;
import w60.v;

/* JADX INFO: loaded from: classes.dex */
public final class e implements ActionMode.Callback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g f21294a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Context f21295b;

    public e(g gVar, Context context) {
        this.f21294a = gVar;
        this.f21295b = context;
    }

    @Override // android.view.ActionMode.Callback
    public final boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
        lb.b bVar = null;
        if (menuItem != null) {
            MenuItem menuItem2 = menuItem.getGroupId() == R.id.chat_input_markdown_style_menu_group ? menuItem : null;
            if (menuItem2 != null) {
                bVar = (lb.b) q.q0(menuItem2.getItemId() - 1, lb.b.f20377w);
            }
        }
        g gVar = this.f21294a;
        if (menuItem != null && menuItem.getItemId() == R.id.chat_input_format_menu_item) {
            gVar.f21300i = true;
            if (actionMode != null) {
                actionMode.invalidate();
                return true;
            }
        } else {
            if (bVar == null) {
                return false;
            }
            char c11 = bVar.f20379e;
            DCDChatInput textView = gVar.y;
            k.g(textView, "textView");
            Editable editableText = textView.getEditableText();
            if (editableText != null) {
                int selectionStart = textView.getSelectionStart();
                int selectionEnd = textView.getSelectionEnd();
                if (selectionStart >= 0 && selectionEnd >= 0) {
                    int iMin = Math.min(selectionStart, selectionEnd);
                    int iMax = Math.max(selectionStart, selectionEnd);
                    int iA = bVar.a(editableText, iMin - 1, -1, 0);
                    int iA2 = bVar.a(editableText, iMax, 1, editableText.length());
                    int iA3 = bVar.a(editableText, iMin, 1, iMax);
                    int i11 = iMin + iA3;
                    int iA4 = bVar.a(editableText, iMax - 1, -1, i11);
                    int i12 = iA3 + iA;
                    int i13 = iA4 + iA2;
                    int i14 = bVar.f20380i;
                    int i15 = i12 ^ i14;
                    int i16 = i14 ^ i13;
                    int i17 = iMax - iA4;
                    if (i16 > i13) {
                        editableText.insert(i17 + i13, v.e0(i16 - i13, String.valueOf(c11)));
                    } else {
                        editableText.delete(i17, (i13 + i17) - i16);
                    }
                    int i18 = iMin - iA;
                    if (i15 > i12) {
                        editableText.insert(i18 + i12, v.e0(i15 - i12, String.valueOf(c11)));
                    } else {
                        editableText.delete(i18, (i18 + i12) - i15);
                    }
                    int i19 = i15 - i12;
                    int i21 = i11 + i19;
                    int i22 = i17 + i19;
                    if (i21 == i22) {
                        Selection.setSelection(editableText, i21);
                    } else {
                        Selection.setSelection(editableText, i21 - Math.max(i15 - iA, 0), Math.max(i16 - iA2, 0) + i22);
                    }
                }
            }
            if (actionMode != null) {
                actionMode.finish();
            }
        }
        return true;
    }

    @Override // android.view.ActionMode.Callback
    public final boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
        g gVar = this.f21294a;
        gVar.f21299e = true;
        gVar.f21300i = false;
        if (gVar.getShowFormatMenu() && menu != null) {
            menu.add(0, R.id.chat_input_format_menu_item, 7, z20.g.H(this.f21295b, ti.b.E1));
        }
        return true;
    }

    @Override // android.view.ActionMode.Callback
    public final void onDestroyActionMode(ActionMode actionMode) {
        g gVar = this.f21294a;
        gVar.f21299e = false;
        gVar.f21300i = false;
        gVar.a(false);
    }

    @Override // android.view.ActionMode.Callback
    public final boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
        if (!this.f21294a.f21300i || menu == null) {
            return false;
        }
        menu.clear();
        t30.a aVar = lb.b.f20377w;
        aVar.getClass();
        d1 d1Var = new d1(7, aVar);
        while (d1Var.hasNext()) {
            lb.b bVar = (lb.b) d1Var.next();
            menu.add(R.id.chat_input_markdown_style_menu_group, bVar.ordinal() + 1, bVar.ordinal(), z20.g.H(this.f21295b, bVar.f20378d));
        }
        return true;
    }
}
