package mb;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.Editable;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import androidx.core.view.q2;
import androidx.core.view.r0;
import androidx.core.view.v;
import androidx.core.view.w0;
import androidx.core.view.z0;
import androidx.lifecycle.p;
import c7.n;
import c70.a0;
import c70.j0;
import c70.n0;
import c9.r;
import com.discord.R;
import com.discord.chat.input.ChatInputViewManager;
import com.discord.chat.input.spans.DCDBoldSpan;
import com.discord.chat.input.spans.DCDColorSpan;
import com.discord.chat.input.views.DCDChatInput;
import com.facebook.react.uimanager.b0;
import com.facebook.react.uimanager.k0;
import fb.l;
import ib.o;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.UUID;
import java.util.WeakHashMap;
import jk.l0;
import kotlin.jvm.internal.k;
import z60.r1;
import z60.z;

/* JADX INFO: loaded from: classes.dex */
public final class g extends RelativeLayout implements jf.a {
    public final LinkedHashSet J;
    public final io.sentry.internal.debugmeta.c K;
    public CharSequence L;
    public final int M;
    public String N;
    public final n0 O;
    public final n0 P;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public r1 f21298d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f21299e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f21300i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public c f21301v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f21302w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final bt.e f21303x;
    public final DCDChatInput y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(final Context context) {
        super(context, null, 0);
        k.g(context, "context");
        int i11 = 0;
        e eVar = new e(this, context);
        LayoutInflater.from(context).inflate(R.layout.chat_input_root_view, this);
        DCDChatInput dCDChatInput = (DCDChatInput) com.facebook.imagepipeline.nativecode.b.x(this, R.id.chat_input_edit_text);
        if (dCDChatInput == null) {
            throw new NullPointerException("Missing required view with ID: ".concat(getResources().getResourceName(R.id.chat_input_edit_text)));
        }
        this.f21303x = new bt.e(this, new b10.c(28, this));
        this.y = dCDChatInput;
        this.J = new LinkedHashSet();
        this.K = new io.sentry.internal.debugmeta.c(dCDChatInput, u6.a.c(this, false));
        this.L = dCDChatInput.getHint();
        this.M = dCDChatInput.getMaxLines();
        String string = UUID.randomUUID().toString();
        k.f(string, "toString(...)");
        this.N = string;
        this.O = j0.c(null);
        this.P = j0.c(0);
        int i12 = 1;
        setClipChildren(true);
        s1.e.M(dCDChatInput, je.a.PrimaryMedium);
        su.e.K(dCDChatInput, 16.0f);
        int i13 = 4;
        dCDChatInput.setOnRequestSend(new ld.c(i13, this));
        dCDChatInput.setOnSelectionChanged(new r(8, this));
        dCDChatInput.setOnFocusChangeListener(new a(this, i11));
        dCDChatInput.setCustomSelectionActionModeCallback(eVar);
        dCDChatInput.setCustomInsertionActionModeCallback(eVar);
        String[] strArr = {"image/*"};
        v vVar = new v() { // from class: mb.b
            @Override // androidx.core.view.v
            public final androidx.core.view.h a(View view, androidx.core.view.h payload) {
                boolean z11;
                c cVar;
                g gVar = this.f21288a;
                LinkedHashSet linkedHashSet = gVar.J;
                k.g(view, "<unused var>");
                k.g(payload, "payload");
                Pair pairB = payload.b(new n(context, 4));
                k.f(pairB, "partition(...)");
                androidx.core.view.h hVar = (androidx.core.view.h) pairB.first;
                androidx.core.view.h hVar2 = (androidx.core.view.h) pairB.second;
                if (hVar != null) {
                    androidx.core.view.g gVar2 = hVar.f1499a;
                    linkedHashSet.add(payload);
                    int itemCount = gVar2.r().getItemCount();
                    for (int i14 = 0; i14 < itemCount; i14++) {
                        Uri uri = gVar2.r().getItemAt(i14).getUri();
                        k.f(uri, "getUri(...)");
                        c cVar2 = gVar.f21301v;
                        if (cVar2 != null) {
                            l lVar = (l) cVar2;
                            ui.b reactEvents = ((ChatInputViewManager) lVar.f11665e).getReactEvents();
                            k0 k0Var = (k0) lVar.f11666i;
                            g gVar3 = (g) lVar.f11667v;
                            String string2 = uri.toString();
                            k.f(string2, "toString(...)");
                            reactEvents.c(k0Var, gVar3, new o(string2, k0Var.getContentResolver().getType(uri)));
                        }
                    }
                    z11 = true;
                } else {
                    z11 = false;
                }
                if (hVar2 != null) {
                    Editable text = gVar.y.getText();
                    if (text != null && !w60.o.y0(text)) {
                        return hVar2;
                    }
                    Pair pairB2 = hVar2.b(new j10.a(27));
                    k.f(pairB2, "partition(...)");
                    androidx.core.view.h hVar3 = (androidx.core.view.h) pairB2.first;
                    hVar2 = (androidx.core.view.h) pairB2.second;
                    if (hVar3 != null) {
                        androidx.core.view.g gVar4 = hVar3.f1499a;
                        if (!z11) {
                            linkedHashSet.add(payload);
                        }
                        int itemCount2 = gVar4.r().getItemCount();
                        for (int i15 = 0; i15 < itemCount2; i15++) {
                            Intent intent = gVar4.r().getItemAt(i15).getIntent();
                            k.f(intent, "getIntent(...)");
                            String stringExtra = intent.getStringExtra("data");
                            if (stringExtra != null && (cVar = gVar.f21301v) != null) {
                                l lVar2 = (l) cVar;
                                ((ChatInputViewManager) lVar2.f11665e).getReactEvents().c((k0) lVar2.f11666i, (g) lVar2.f11667v, new ib.l(stringExtra));
                            }
                        }
                        return null;
                    }
                }
                return hVar2;
            }
        };
        WeakHashMap weakHashMap = z0.f1608a;
        if (Build.VERSION.SDK_INT >= 31) {
            w0.c(dCDChatInput, strArr, vVar);
        } else {
            b0.J("A MIME type set here must not start with *: " + Arrays.toString(strArr), !strArr[0].startsWith("*"));
            dCDChatInput.setTag(R.id.tag_on_receive_content_mime_types, strArr);
            dCDChatInput.setTag(R.id.tag_on_receive_content_listener, vVar);
        }
        dCDChatInput.addTextChangedListener(new bh.o(this, i12));
        dCDChatInput.addTextChangedListener(new jb.b());
        addOnLayoutChangeListener(new a6.j(i13, this));
    }

    public final void a(boolean z11) {
        r1 r1Var = this.f21298d;
        q30.c cVar = null;
        if (r1Var != null) {
            r1Var.d(null);
        }
        if (z11) {
            return;
        }
        WeakHashMap weakHashMap = z0.f1608a;
        q2 q2VarA = r0.a(this);
        if (q2VarA == null || !q2VarA.f1566a.u(8)) {
            this.f21298d = z.v(u6.a.c(this, false), null, new b7.f(this, cVar, 6), 3);
        }
    }

    public final void b(int i11, List list) {
        DCDChatInput dCDChatInput;
        Drawable drawableA;
        ArrayList arrayList = new ArrayList(m30.l.W(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            hb.c cVar = (hb.c) it.next();
            arrayList.add(new hb.c(cVar.f14148a, cVar.f14149b + i11, cVar.f14150c, cVar.f14151d, cVar.f14152e, cVar.f14153f, cVar.f14154g, cVar.f14155h, cVar.f14156i, cVar.f14157j, cVar.k));
        }
        Iterator it2 = arrayList.iterator();
        boolean z11 = false;
        while (true) {
            boolean zHasNext = it2.hasNext();
            dCDChatInput = this.y;
            if (!zHasNext) {
                break;
            }
            hb.c node = (hb.c) it2.next();
            Editable editableText = dCDChatInput.getEditableText();
            k.f(editableText, "getEditableText(...)");
            k.g(node, "node");
            String str = node.f14155h;
            hb.h hVar = node.f14151d;
            q30.c cVar2 = null;
            if (hVar != null) {
                s1.e.c(editableText, new DCDColorSpan(hVar.f14163b), node);
                yj.c cVar3 = hVar.f14164c;
                if (cVar3 != null) {
                    s1.e.c(editableText, new kb.a(cVar3, null, 6), node);
                }
                hb.e eVar = hVar.f14165d;
                if ((eVar == null ? -1 : lb.a.f20375a[eVar.ordinal()]) == 1) {
                    s1.e.c(editableText, new DCDBoldSpan(), node);
                }
            }
            if (node.f14152e) {
                s1.e.c(editableText, new kb.b(), node);
            }
            if (node.f14154g) {
                s1.e.c(editableText, new kb.e(), node);
            }
            if (!(str == null || str.length() == 0)) {
                io.sentry.internal.debugmeta.c cVar4 = this.K;
                f10.e eVar2 = (f10.e) cVar4.f16765i;
                Editable editableText2 = ((DCDChatInput) cVar4.f16764e).getEditableText();
                int i12 = node.f14149b;
                int i13 = i12 + 1;
                if (i12 >= 0 && i13 <= editableText2.length() && str != null) {
                    String str2 = str.length() > 0 ? str : null;
                    if (str2 != null) {
                        Float f3 = node.f14156i;
                        int iO = ox.b.o(s1.e.H(f3 != null ? f3.floatValue() : 16.0f));
                        Float f11 = node.f14157j;
                        float fO = ox.b.o(s1.e.H(f11 != null ? f11.floatValue() : 4.0f));
                        Float f12 = node.k;
                        int iO2 = ox.b.o(s1.e.H(f12 != null ? f12.floatValue() : 4.0f));
                        eVar2.getClass();
                        Bitmap bitmap = (Bitmap) ((e6.r1) eVar2.f11020v).f(str2);
                        if (bitmap != null) {
                            drawableA = cVar4.A(bitmap, iO, fO);
                        } else {
                            GradientDrawable gradientDrawable = new GradientDrawable();
                            gradientDrawable.setShape(0);
                            gradientDrawable.setCornerRadius(fO);
                            gradientDrawable.setColor(l0.a().g());
                            gradientDrawable.setBounds(0, 0, iO, iO);
                            drawableA = gradientDrawable;
                        }
                        editableText2.setSpan(new kb.d(str2, drawableA, iO, fO, iO2, iO2), i12, i13, 33);
                        if (bitmap == null) {
                            a70.d dVar = new a70.d(22, cVar4, str2);
                            if (!((LinkedHashSet) eVar2.f11022x).contains(str2) && ((LinkedHashSet) eVar2.f11021w).add(str2)) {
                                z.v((lg.a) eVar2.f11019i, null, new b7.e(eVar2, str2, dVar, cVar2, 9), 3);
                            }
                        }
                    }
                }
                z11 = true;
            }
        }
        Editable editableText3 = dCDChatInput.getEditableText();
        k.f(editableText3, "getEditableText(...)");
        Object[] spans = editableText3.getSpans(0, editableText3.length(), xj.a.class);
        k.f(spans, "getSpans(...)");
        if (spans.length == 0) {
            Editable editableText4 = dCDChatInput.getEditableText();
            k.f(editableText4, "getEditableText(...)");
            z20.g.i(editableText4, new xj.a(dCDChatInput));
        }
        Editable editableText5 = dCDChatInput.getEditableText();
        k.f(editableText5, "getEditableText(...)");
        Object[] spans2 = editableText5.getSpans(0, editableText5.length(), jb.c.class);
        k.f(spans2, "getSpans(...)");
        if (spans2.length == 0) {
            Editable editableText6 = dCDChatInput.getEditableText();
            k.f(editableText6, "getEditableText(...)");
            z20.g.i(editableText6, new jb.c());
        }
        if (z11) {
            this.f21303x.j(false);
        }
    }

    public final void c() {
        DCDChatInput dCDChatInput = this.y;
        if (dCDChatInput.length() != 0) {
            k.g(dCDChatInput, "<this>");
            int maxLines = dCDChatInput.getMaxLines();
            int i11 = this.M;
            if (maxLines != i11) {
                dCDChatInput.setMaxLines(i11);
            }
            dCDChatInput.setEllipsize(null);
            dCDChatInput.setHint((CharSequence) null);
            return;
        }
        CharSequence charSequence = this.L;
        TextUtils.TruncateAt hintTruncateAt = TextUtils.TruncateAt.END;
        k.g(dCDChatInput, "<this>");
        k.g(hintTruncateAt, "hintTruncateAt");
        if (dCDChatInput.getMaxLines() != 1) {
            dCDChatInput.setMaxLines(1);
        }
        dCDChatInput.setEllipsize(hintTruncateAt);
        dCDChatInput.setHint(charSequence);
    }

    public final String getHint() {
        CharSequence hint = this.y.getHint();
        if (hint != null) {
            return hint.toString();
        }
        return null;
    }

    public final int getHintTextColor() {
        return this.y.getCurrentHintTextColor();
    }

    public final Integer getLineCount() {
        Layout layout = this.y.getLayout();
        if (layout != null) {
            return Integer.valueOf(layout.getLineCount());
        }
        return null;
    }

    public final c getListener() {
        return this.f21301v;
    }

    public final boolean getShowFormatMenu() {
        return this.f21302w;
    }

    public final String getText() {
        return String.valueOf(this.y.getText());
    }

    public final int getTextColor() {
        return this.y.getCurrentTextColor();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        q30.c cVar = null;
        z.v(u6.a.c(this, false), null, new b7.f(new a0(j0.g(this.O, 100L), new p(this, cVar, 9)), cVar, 1), 3);
        z.v(u6.a.c(this, false), null, new b7.f(new a0(j0.g(this.P, 32L), new bg.n(this, cVar, 7)), cVar, 1), 3);
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEvent(int i11) {
        if (i11 == 8) {
            this.y.performAccessibilityAction(64, null);
        } else {
            super.sendAccessibilityEvent(i11);
        }
    }

    public final void setContentMaxHeight(float f3) {
        this.y.setContentMaxHeightPx(ox.b.k(f3));
    }

    public final void setCursorVisible(boolean z11) {
        this.y.setCursorVisible(z11);
    }

    public final void setEditTextEnabled(boolean z11) {
        this.y.setEnabled(z11);
    }

    public final void setHint(String str) {
        if (h.f21304a.a(str == null ? "" : str)) {
            Context context = getContext();
            k.f(context, "getContext(...)");
            str = z20.g.H(context, ti.b.f30387w).toString();
        }
        this.y.setHint(str);
        this.L = str;
        c();
    }

    public final void setHintTextColor(int i11) {
        this.y.setHintTextColor(i11);
    }

    public final void setListener(c cVar) {
        this.f21301v = cVar;
    }

    public final void setMeasurementText$chat_input_androidRelease(CharSequence value) {
        k.g(value, "value");
        this.y.setText(value);
    }

    public final void setNoExtractUI(boolean z11) {
        this.y.setNoExtractUI(z11);
    }

    public final void setShowFormatMenu(boolean z11) {
        this.f21302w = z11;
    }

    public final void setText(String value) {
        k.g(value, "value");
        this.y.setText(value);
    }

    public final void setTextColor(int i11) {
        this.y.setTextColor(i11);
    }
}
