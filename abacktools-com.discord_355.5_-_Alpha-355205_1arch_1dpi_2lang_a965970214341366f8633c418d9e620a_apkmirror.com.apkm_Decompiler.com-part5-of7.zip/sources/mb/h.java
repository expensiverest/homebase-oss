package mb;

import w60.m;
import w60.n;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m f21304a = new m("MFA|OTP|user[ _-]?name|password|passwd|log[ _-]?in|sign[ _-]?in|e-?mail", n.IGNORE_CASE);
}
