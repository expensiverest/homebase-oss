package lq;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.util.TypedValue;
import com.facebook.react.bridge.ColorPropConverter;
import com.facebook.react.bridge.JSApplicationCausedNativeException;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.b0;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final TypedValue f20596a = new TypedValue();

    /* JADX WARN: Code duplicated, block: B:35:0x00c3  */
    /* JADX WARN: Code duplicated, block: B:58:0x0147  */
    public static final Drawable a(Context context, ReadableMap readableMap) {
        Object objValueOf;
        Integer color;
        int color2;
        Drawable colorDrawable;
        String string = readableMap.getString("type");
        boolean zEquals = "ThemeAttrAndroid".equals(string);
        TypedValue typedValue = f20596a;
        if (zEquals) {
            String string2 = readableMap.getString("attribute");
            if (string2 == null) {
                throw new JSApplicationIllegalArgumentException("JS description missing 'attribute' field");
            }
            int identifier = "selectableItemBackground".equals(string2) ? R.attr.selectableItemBackground : "selectableItemBackgroundBorderless".equals(string2) ? R.attr.selectableItemBackgroundBorderless : context.getResources().getIdentifier(string2, "attr", "android");
            if (context.getTheme().resolveAttribute(identifier, typedValue, true)) {
                Drawable drawable = context.getResources().getDrawable(typedValue.resourceId, context.getTheme());
                if (readableMap.hasKey("rippleRadius") && (drawable instanceof RippleDrawable)) {
                    ((RippleDrawable) drawable).setRadius((int) b0.w0((float) readableMap.getDouble("rippleRadius")));
                }
                return drawable;
            }
            throw new JSApplicationIllegalArgumentException("Attribute " + string2 + " with id " + identifier + " couldn't be resolved into a drawable");
        }
        if (!"RippleAndroid".equals(string)) {
            throw new JSApplicationIllegalArgumentException(a1.h.i("Invalid type for android drawable: ", string));
        }
        if (!readableMap.hasKey("color") || readableMap.isNull("color")) {
            objValueOf = null;
        } else {
            int i11 = a.f20595a[readableMap.getType("color").ordinal()];
            if (i11 == 1) {
                objValueOf = Double.valueOf(readableMap.getDouble("color"));
            } else if (i11 != 2) {
                objValueOf = null;
            } else {
                objValueOf = readableMap.getMap("color");
            }
        }
        try {
            color = ColorPropConverter.getColor(objValueOf, context);
        } catch (JSApplicationCausedNativeException e4) {
            gl.a.u(e4, "android_ripple: color resource not found, using colorControlHighlight", new Object[0]);
            color = null;
        }
        if (color != null) {
            color2 = color.intValue();
        } else {
            if (!context.getTheme().resolveAttribute(R.attr.colorControlHighlight, typedValue, true)) {
                throw new JSApplicationIllegalArgumentException("Attribute colorControlHighlight couldn't be resolved into a drawable");
            }
            color2 = context.getResources().getColor(typedValue.resourceId, context.getTheme());
        }
        if (color != null && readableMap.hasKey("alpha") && !readableMap.isNull("alpha")) {
            color2 = Color.argb(s1.e.G(((double) Color.alpha(color2)) * sg.a.l(readableMap.getDouble("alpha"), 0.0d, 1.0d)), Color.red(color2), Color.green(color2), Color.blue(color2));
        }
        if (readableMap.hasKey("borderless") && readableMap.getBoolean("borderless")) {
            colorDrawable = null;
        } else if (readableMap.hasKey("rippleCornerRadius")) {
            float fW0 = b0.w0((float) readableMap.getDouble("rippleCornerRadius"));
            float[] fArr = new float[8];
            for (int i12 = 0; i12 < 8; i12++) {
                fArr[i12] = fW0;
            }
            colorDrawable = new ShapeDrawable(new RoundRectShape(fArr, null, null));
        } else if (readableMap.hasKey("borderless") && !readableMap.isNull("borderless") && readableMap.getBoolean("borderless")) {
            colorDrawable = null;
        } else {
            colorDrawable = new ColorDrawable(-1);
        }
        RippleDrawable rippleDrawable = new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{color2}), null, colorDrawable);
        if (readableMap.hasKey("rippleRadius")) {
            rippleDrawable.setRadius((int) b0.w0((float) readableMap.getDouble("rippleRadius")));
        }
        return rippleDrawable;
    }
}
