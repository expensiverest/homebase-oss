package lq;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class d implements View.OnLayoutChangeListener {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public g f20599d;

    @Override // android.view.View.OnLayoutChangeListener
    public final void onLayoutChange(View v11, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18) {
        g gVar;
        kotlin.jvm.internal.k.g(v11, "v");
        g gVar2 = this.f20599d;
        if (gVar2 == null || !gVar2.getRemoveClippedSubviews() || (gVar = this.f20599d) == null) {
            return;
        }
        g.access$updateSubviewClipStatus(gVar, v11);
    }
}
