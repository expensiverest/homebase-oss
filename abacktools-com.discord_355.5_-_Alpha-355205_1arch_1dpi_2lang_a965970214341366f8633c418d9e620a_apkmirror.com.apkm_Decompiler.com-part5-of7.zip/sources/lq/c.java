package lq;

import android.view.View;
import android.view.accessibility.AccessibilityManager;
import com.discord.device.DeviceAccessibilityModule;
import g8.i0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements AccessibilityManager.AccessibilityStateChangeListener {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20597d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f20598e;

    public /* synthetic */ c(int i11, Object obj) {
        this.f20597d = i11;
        this.f20598e = obj;
    }

    @Override // android.view.accessibility.AccessibilityManager.AccessibilityStateChangeListener
    public final void onAccessibilityStateChanged(boolean z11) {
        switch (this.f20597d) {
            case 0:
                g gVar = (g) this.f20598e;
                if (!z11) {
                    int childCount = gVar.getChildCount();
                    for (int i11 = 0; i11 < childCount; i11++) {
                        View childAt = gVar.getChildAt(i11);
                        kotlin.jvm.internal.k.f(childAt, "getChildAt(...)");
                        i0.x(childAt);
                    }
                }
                break;
            default:
                ((DeviceAccessibilityModule) this.f20598e).emitOnAccessibilityServiceEnabledChanged(z11);
                break;
        }
    }
}
