package lq;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import androidx.core.view.g0;
import androidx.core.view.j1;
import androidx.core.view.r2;
import androidx.core.view.s2;
import androidx.core.view.u2;
import androidx.core.view.v2;
import androidx.core.view.z0;
import app.p001rive.semantics.SemanticState;
import com.facebook.imageutils.JfifUtil;
import java.util.WeakHashMap;
import k80.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int f20602a = Color.argb(230, JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int f20603b = Color.argb(128, 27, 27, 27);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static boolean f20604c;

    public static final void a(Window window) {
        s1.e s2Var;
        boolean z11 = false;
        j1.D(window, false);
        g0 g0Var = new g0(window.getDecorView());
        int i11 = Build.VERSION.SDK_INT;
        if (i11 >= 35) {
            s2Var = new v2(window, g0Var);
        } else if (i11 >= 30) {
            s2Var = new u2(window, g0Var);
        } else {
            s2Var = i11 >= 26 ? new s2(window, g0Var) : new r2(window, g0Var);
        }
        Context context = window.getContext();
        kotlin.jvm.internal.k.f(context, "getContext(...)");
        boolean zK = l.K(context);
        window.setStatusBarColor(0);
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 29) {
            window.setNavigationBarColor(0);
            TypedArray typedArrayObtainStyledAttributes = window.getContext().getTheme().obtainStyledAttributes(new int[]{R.attr.enforceNavigationBarContrast});
            kotlin.jvm.internal.k.f(typedArrayObtainStyledAttributes, "obtainStyledAttributes(...)");
            try {
                boolean z12 = typedArrayObtainStyledAttributes.getBoolean(0, true);
                typedArrayObtainStyledAttributes.recycle();
                window.setStatusBarContrastEnforced(false);
                window.setNavigationBarContrastEnforced(z12);
                if (z12) {
                    s2Var.K(!zK);
                }
            } catch (Throwable th2) {
                typedArrayObtainStyledAttributes.recycle();
                throw th2;
            }
        } else {
            if (i12 >= 26 && !zK) {
                z11 = true;
            }
            window.setNavigationBarColor(z11 ? f20602a : f20603b);
            s2Var.K(z11);
        }
        if (i12 >= 28) {
            window.getAttributes().layoutInDisplayCutoutMode = i12 >= 30 ? 3 : 1;
        }
    }

    public static final void b(Window window, String str) {
        if (Build.VERSION.SDK_INT <= 30) {
            int systemUiVisibility = window.getDecorView().getSystemUiVisibility();
            window.getDecorView().setSystemUiVisibility("dark-content".equals(str) ? systemUiVisibility | SemanticState.Multiline : systemUiVisibility & (-8193));
        } else {
            if ("dark-content".equals(str)) {
                WindowInsetsController insetsController = window.getInsetsController();
                if (insetsController != null) {
                    insetsController.setSystemBarsAppearance(8, 8);
                    return;
                }
                return;
            }
            WindowInsetsController insetsController2 = window.getInsetsController();
            if (insetsController2 != null) {
                insetsController2.setSystemBarsAppearance(0, 8);
            }
        }
    }

    public static final void c(Window window, boolean z11) {
        if (z11) {
            window.getDecorView().setOnApplyWindowInsetsListener(new j());
        } else {
            window.getDecorView().setOnApplyWindowInsetsListener(null);
        }
        View decorView = window.getDecorView();
        WeakHashMap weakHashMap = z0.f1608a;
        decorView.requestApplyInsets();
    }

    public static final void d(Window window, boolean z11) {
        s1.e s2Var;
        s1.e s2Var2;
        if (z11) {
            if (!f20604c) {
                if (Build.VERSION.SDK_INT >= 30) {
                    window.getAttributes().layoutInDisplayCutoutMode = 1;
                    window.setDecorFitsSystemWindows(false);
                }
                window.addFlags(1024);
                window.clearFlags(SemanticState.Modal);
                return;
            }
            g0 g0Var = new g0(window.getDecorView());
            int i11 = Build.VERSION.SDK_INT;
            if (i11 >= 35) {
                s2Var2 = new v2(window, g0Var);
            } else if (i11 >= 30) {
                s2Var2 = new u2(window, g0Var);
            } else {
                s2Var2 = i11 >= 26 ? new s2(window, g0Var) : new r2(window, g0Var);
            }
            s2Var2.N();
            s2Var2.q(1);
            return;
        }
        if (!f20604c) {
            if (Build.VERSION.SDK_INT >= 30) {
                window.getAttributes().layoutInDisplayCutoutMode = 0;
                window.setDecorFitsSystemWindows(true);
            }
            window.addFlags(SemanticState.Modal);
            window.clearFlags(1024);
            return;
        }
        g0 g0Var2 = new g0(window.getDecorView());
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 35) {
            s2Var = new v2(window, g0Var2);
        } else if (i12 >= 30) {
            s2Var = new u2(window, g0Var2);
        } else {
            s2Var = i12 >= 26 ? new s2(window, g0Var2) : new r2(window, g0Var2);
        }
        s2Var.N();
        s2Var.O(1);
    }
}
