package lq;

import rp.i0;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f20600a;

    static {
        int[] iArr = new int[i0.values().length];
        try {
            il.c cVar = i0.f28334d;
            iArr[1] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            il.c cVar2 = i0.f28334d;
            iArr[2] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            il.c cVar3 = i0.f28334d;
            iArr[0] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        f20600a = iArr;
    }
}
