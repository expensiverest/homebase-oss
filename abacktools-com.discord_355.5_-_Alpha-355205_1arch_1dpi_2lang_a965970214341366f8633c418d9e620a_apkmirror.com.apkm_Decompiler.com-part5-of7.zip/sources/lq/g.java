package lq;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Animation;
import androidx.core.view.j1;
import com.discord.R;
import com.facebook.react.bridge.ReactNoCrashSoftException;
import com.facebook.react.bridge.ReactSoftExceptionLogger;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.UiThreadUtil;
import com.facebook.react.config.ReactFeatureFlags;
import com.facebook.react.uimanager.b0;
import com.facebook.react.uimanager.f0;
import com.facebook.react.uimanager.l;
import com.facebook.react.uimanager.m;
import com.facebook.react.uimanager.o;
import com.facebook.react.uimanager.t0;
import com.facebook.react.uimanager.u;
import com.facebook.react.uimanager.v;
import com.facebook.react.uimanager.y;
import com.facebook.react.uimanager.z;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import rp.g0;
import rp.i0;

/* JADX INFO: loaded from: classes.dex */
public class g extends ViewGroup implements np.d, u, z, np.c, f0, y {
    private static final int ARRAY_CAPACITY_INCREMENT = 12;
    private static final e Companion = new e();
    private static final ViewGroup.LayoutParams defaultLayoutParam = new ViewGroup.LayoutParams(0, 0);
    private i0 _overflow;
    private boolean _removeClippedSubviews;
    private AccessibilityManager.AccessibilityStateChangeListener accessibilityStateChangeListener;
    private View[] allChildren;
    private int allChildrenCount;
    private List<String> axOrderList;
    private float backfaceOpacity;
    private boolean backfaceVisible;
    private d childrenLayoutChangeListener;
    private Set<Integer> childrenRemovedWhileTransitioning;
    private Rect clippingRect;
    private boolean focusOnAttach;
    private Rect hitSlopRect;
    private volatile boolean inSubviewClippingLoop;
    private ReadableMap nativeBackgroundMap;
    private ReadableMap nativeForegroundMap;
    private boolean needsOffscreenAlphaCompositing;
    private np.b onInterceptTouchEventListener;
    private final Rect overflowInset;
    private o pointerEvents;
    private boolean preventClipping;
    private int recycleCount;

    public g(Context context) {
        super(context);
        this.overflowInset = new Rect();
        this.pointerEvents = o.f6126w;
        h();
    }

    public static final void access$updateSubviewClipStatus(g gVar, View view) {
        if (!gVar._removeClippedSubviews || gVar.getParent() == null) {
            return;
        }
        Rect rect = gVar.clippingRect;
        if (rect == null) {
            throw new IllegalStateException("Required value was null.");
        }
        View[] viewArr = gVar.allChildren;
        if (viewArr == null) {
            throw new IllegalStateException("Required value was null.");
        }
        if (rect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()) != (!gVar.i(view, null))) {
            gVar.inSubviewClippingLoop = true;
            int i11 = gVar.allChildrenCount;
            int i12 = 0;
            for (int i13 = 0; i13 < i11; i13++) {
                View view2 = viewArr[i13];
                if (view2 == view) {
                    updateSubviewClipStatus$default(gVar, rect, i13, i12, null, 8, null);
                    break;
                } else {
                    if (gVar.i(view2, Integer.valueOf(i13))) {
                        i12++;
                    }
                }
            }
            gVar.inSubviewClippingLoop = false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void updateClippingToRect$ReactAndroid_release$default(g gVar, Rect rect, Set set, int i11, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: updateClippingToRect");
        }
        if ((i11 & 2) != 0) {
            set = null;
        }
        gVar.updateClippingToRect$ReactAndroid_release(rect, set);
    }

    public static /* synthetic */ void updateSubviewClipStatus$default(g gVar, Rect rect, int i11, int i12, Set set, int i13, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: updateSubviewClipStatus");
        }
        if ((i13 & 8) != 0) {
            set = null;
        }
        gVar.k(rect, i11, i12, set);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addChildrenForAccessibility(ArrayList<View> outChildren) {
        kotlin.jvm.internal.k.g(outChildren, "outChildren");
        Object tag = getTag(R.id.accessibility_order_parent);
        List<String> list = tag instanceof g ? ((g) tag).axOrderList : null;
        List<String> list2 = this.axOrderList;
        int i11 = 0;
        if (list2 == null) {
            if (list == null) {
                j(outChildren);
                return;
            }
            if (!isFocusable()) {
                j(outChildren);
                return;
            }
            if (!isFocusable() || (getContentDescription() != null && !kotlin.jvm.internal.k.b(getContentDescription(), ""))) {
                if (!isFocusable() || getContentDescription() == null) {
                    return;
                }
                kotlin.jvm.internal.k.b(getContentDescription(), "");
                return;
            }
            j(outChildren);
            int childCount = getChildCount();
            while (i11 < childCount) {
                View childAt = getChildAt(i11);
                kotlin.jvm.internal.k.f(childAt, "getChildAt(...)");
                g8.i0.k(childAt, list);
                i11++;
            }
            return;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) getContext().getSystemService("accessibility");
        if (this.accessibilityStateChangeListener == null && accessibilityManager != null) {
            c cVar = new c(i11, this);
            accessibilityManager.addAccessibilityStateChangeListener(cVar);
            this.accessibilityStateChangeListener = cVar;
        }
        int size = list2.size();
        View[] viewArr = new View[size];
        int childCount2 = getChildCount();
        for (int i12 = 0; i12 < childCount2; i12++) {
            View childAt2 = getChildAt(i12);
            kotlin.jvm.internal.k.f(childAt2, "getChildAt(...)");
            g8.i0.e(childAt2, this, list2, viewArr);
        }
        while (i11 < size) {
            View view = viewArr[i11];
            if (view != null) {
                if (view.isFocusable()) {
                    outChildren.add(view);
                } else {
                    view.addChildrenForAccessibility(outChildren);
                }
            }
            i11++;
        }
    }

    public final void addViewWithSubviewClippingEnabled$ReactAndroid_release(View child, int i11) {
        kotlin.jvm.internal.k.g(child, "child");
        if (!this._removeClippedSubviews) {
            throw new IllegalStateException("Check failed.");
        }
        Companion.getClass();
        child.setTag(R.id.view_clipped, Boolean.TRUE);
        View[] viewArr = this.allChildren;
        if (viewArr == null) {
            throw new IllegalStateException("Required value was null.");
        }
        int i12 = this.allChildrenCount;
        int length = viewArr.length;
        if (i11 == i12) {
            if (length == i12) {
                View[] viewArr2 = new View[length + 12];
                System.arraycopy(viewArr, 0, viewArr2, 0, length);
                this.allChildren = viewArr2;
                viewArr = viewArr2;
            }
            int i13 = this.allChildrenCount;
            this.allChildrenCount = i13 + 1;
            viewArr[i13] = child;
        } else {
            if (i11 >= i12) {
                throw new IndexOutOfBoundsException(a1.h.g("index=", i11, i12, " count="));
            }
            if (length == i12) {
                View[] viewArr3 = new View[length + 12];
                System.arraycopy(viewArr, 0, viewArr3, 0, i11);
                System.arraycopy(viewArr, i11, viewArr3, i11 + 1, i12 - i11);
                this.allChildren = viewArr3;
                viewArr = viewArr3;
            } else {
                System.arraycopy(viewArr, i11, viewArr, i11 + 1, i12 - i11);
            }
            viewArr[i11] = child;
            this.allChildrenCount++;
        }
        Rect rect = this.clippingRect;
        if (rect == null) {
            throw new IllegalStateException("Required value was null.");
        }
        View[] viewArr4 = this.allChildren;
        if (viewArr4 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.inSubviewClippingLoop = true;
        int i14 = 0;
        for (int i15 = 0; i15 < i11; i15++) {
            if (i(viewArr4[i15], Integer.valueOf(i15))) {
                i14++;
            }
        }
        updateSubviewClipStatus$default(this, rect, i11, i14, null, 8, null);
        this.inSubviewClippingLoop = false;
        child.addOnLayoutChangeListener(this.childrenLayoutChangeListener);
    }

    public final void applyNativeBackground$ReactAndroid_release(ReadableMap readableMap) {
        Drawable drawableA;
        this.nativeBackgroundMap = readableMap;
        if (readableMap != null) {
            Context context = getContext();
            kotlin.jvm.internal.k.f(context, "getContext(...)");
            drawableA = b.a(context, readableMap);
        } else {
            drawableA = null;
        }
        a.a.Y(this, drawableA);
    }

    public final void applyNativeForeground$ReactAndroid_release(ReadableMap readableMap) {
        Drawable drawableA;
        this.nativeForegroundMap = readableMap;
        if (readableMap != null) {
            Context context = getContext();
            kotlin.jvm.internal.k.f(context, "getContext(...)");
            drawableA = b.a(context, readableMap);
        } else {
            drawableA = null;
        }
        setForeground(drawableA);
    }

    public final void cleanUpAxOrderListener() {
        AccessibilityManager.AccessibilityStateChangeListener accessibilityStateChangeListener;
        Object systemService = getContext().getSystemService("accessibility");
        AccessibilityManager accessibilityManager = systemService instanceof AccessibilityManager ? (AccessibilityManager) systemService : null;
        if (accessibilityManager != null && (accessibilityStateChangeListener = this.accessibilityStateChangeListener) != null) {
            accessibilityManager.removeAccessibilityStateChangeListener(accessibilityStateChangeListener);
        }
        this.accessibilityStateChangeListener = null;
    }

    public final void clearFocusFromJS$ReactAndroid_release() {
        this.focusOnAttach = false;
        super.clearFocus();
    }

    public final String describeChildren() {
        StringBuilder sb2 = new StringBuilder("  Attached children: ");
        int childCount = getChildCount();
        if (childCount == 0) {
            sb2.append("    (none)\n");
        } else {
            for (int i11 = 0; i11 < childCount; i11++) {
                try {
                    View childAt = getChildAt(i11);
                    if (childAt == null) {
                        sb2.append("    [" + i11 + "] NULL CHILD!\n");
                    } else {
                        Object tag = childAt.getTag(R.id.view_tag_native_id);
                        Object tag2 = childAt.getTag(R.id.react_test_id);
                        sb2.append("    [" + i11 + "] ");
                        sb2.append(childAt.getClass().getSimpleName());
                        sb2.append(" id=");
                        sb2.append(childAt.getId());
                        if (tag != null) {
                            sb2.append(" nativeID=");
                            sb2.append(tag);
                        }
                        if (tag2 != null) {
                            sb2.append(" testID=");
                            sb2.append(tag2);
                        }
                        sb2.append(" parent=");
                        sb2.append(childAt.getParent() != null ? "attached" : "DETACHED");
                        sb2.append('\n');
                    }
                } catch (Exception e4) {
                    sb2.append("    [" + i11 + "] ERROR: ");
                    sb2.append(e4.getMessage());
                    sb2.append('\n');
                }
            }
        }
        try {
            if (getRemoveClippedSubviews() && this.allChildren != null && this.allChildrenCount > childCount) {
                sb2.append("  Clipped children:\n");
                int i12 = this.allChildrenCount;
                for (int i13 = 0; i13 < i12; i13++) {
                    View[] viewArr = this.allChildren;
                    kotlin.jvm.internal.k.d(viewArr);
                    View view = viewArr[i13];
                    if (view != null && view.getParent() == null) {
                        Object tag3 = view.getTag(R.id.view_tag_native_id);
                        sb2.append("    [" + i13 + "] ");
                        sb2.append(view.getClass().getSimpleName());
                        sb2.append(" id=");
                        sb2.append(view.getId());
                        if (tag3 != null) {
                            sb2.append(" nativeID=");
                            sb2.append(tag3);
                        }
                        sb2.append(" (CLIPPED)\n");
                    }
                }
            }
        } catch (Exception e9) {
            sb2.append("  Error describing clipped children: ");
            sb2.append(e9.getMessage());
            sb2.append('\n');
        }
        String string = sb2.toString();
        kotlin.jvm.internal.k.f(string, "toString(...)");
        return string;
    }

    public final String describeViewAncestry(View start) {
        kotlin.jvm.internal.k.g(start, "start");
        StringBuilder sb2 = new StringBuilder();
        int i11 = 0;
        while (start != null) {
            Object tag = start.getTag(R.id.view_tag_native_id);
            Object tag2 = start.getTag(R.id.react_test_id);
            String strValueOf = String.valueOf(2);
            CharSequence contentDescription = start.getContentDescription();
            sb2.append("#");
            sb2.append(i11);
            sb2.append(" class=");
            sb2.append(start.getClass().getName());
            sb2.append(" tag=");
            sb2.append(start.getId());
            sb2.append(" ui=");
            sb2.append(strValueOf);
            if (tag != null) {
                sb2.append(" nativeID=");
                sb2.append(tag);
            }
            if (tag2 != null) {
                sb2.append(" testID=");
                sb2.append(tag2);
            }
            if (contentDescription != null) {
                sb2.append(" contentDesc=");
                sb2.append(contentDescription);
            }
            sb2.append('\n');
            Object parent = start.getParent();
            start = parent instanceof View ? (View) parent : null;
            i11++;
        }
        String string = sb2.toString();
        kotlin.jvm.internal.k.f(string, "toString(...)");
        return string;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        kotlin.jvm.internal.k.g(canvas, "canvas");
        if (this._overflow != i0.f28335e || getTag(R.id.filter) != null) {
            a.a.e(canvas, this);
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.View
    public boolean dispatchGenericMotionEvent(MotionEvent ev2) {
        kotlin.jvm.internal.k.g(ev2, "ev");
        t0 t0Var = o.f6122d;
        o pointerEvents = getPointerEvents();
        t0Var.getClass();
        if (t0.c(pointerEvents)) {
            return super.dispatchGenericMotionEvent(ev2);
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    @TargetApi(TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER)
    public void dispatchProvideStructure(ViewStructure structure) {
        kotlin.jvm.internal.k.g(structure, "structure");
        try {
            super.dispatchProvideStructure(structure);
        } catch (NullPointerException e4) {
            gl.a.h("ReactNative", "NullPointerException when executing dispatchProvideStructure", e4);
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        kotlin.jvm.internal.k.g(canvas, "canvas");
        if (Build.VERSION.SDK_INT < 29 || !j1.t(this)) {
            super.draw(canvas);
            return;
        }
        Rect overflowInset = getOverflowInset();
        canvas.saveLayer(overflowInset.left, overflowInset.top, getWidth() + (-overflowInset.right), getHeight() + (-overflowInset.bottom), null);
        super.draw(canvas);
        canvas.restore();
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0064 A[PHI: r4
      0x0064: PHI (r4v1 android.graphics.BlendMode) = (r4v0 android.graphics.BlendMode), (r4v0 android.graphics.BlendMode), (r4v3 android.graphics.BlendMode) binds: [B:9:0x0022, B:11:0x0028, B:15:0x0039] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View child, long j6) {
        Canvas canvas2;
        kotlin.jvm.internal.k.g(canvas, "canvas");
        kotlin.jvm.internal.k.g(child, "child");
        boolean z11 = child.getElevation() > 0.0f;
        if (z11) {
            j1.g(canvas, true);
        }
        BlendMode blendModeI = null;
        if (Build.VERSION.SDK_INT < 29 || !j1.t(this)) {
            canvas2 = canvas;
        } else {
            Object tag = child.getTag(R.id.mix_blend_mode);
            blendModeI = tag instanceof BlendMode ? ox.h.i(tag) : null;
            if (blendModeI != null) {
                Paint paint = new Paint();
                paint.setBlendMode(blendModeI);
                Rect overflowInset = getOverflowInset();
                canvas2 = canvas;
                canvas2.saveLayer(overflowInset.left, overflowInset.top, getWidth() + (-overflowInset.right), getHeight() + (-overflowInset.bottom), paint);
            } else {
                canvas2 = canvas;
            }
        }
        boolean zDrawChild = super.drawChild(canvas2, child, j6);
        if (blendModeI != null) {
            canvas2.restore();
        }
        if (z11) {
            j1.g(canvas2, false);
        }
        return zDrawChild;
    }

    @Override // android.view.ViewGroup
    public void endViewTransition(View view) {
        kotlin.jvm.internal.k.g(view, "view");
        super.endViewTransition(view);
        Set<Integer> set = this.childrenRemovedWhileTransitioning;
        if (set != null) {
            set.remove(Integer.valueOf(view.getId()));
        }
    }

    public final void g(View view, boolean z11) {
        if (this.inSubviewClippingLoop) {
            Object tag = view.getTag(R.id.view_clipped);
            if (!Boolean.valueOf(z11).equals(tag)) {
                ReactSoftExceptionLogger.logSoftException(ReactSoftExceptionLogger.Categories.RVG_ON_VIEW_REMOVED, new ReactNoCrashSoftException("View clipping tag mismatch: tag=" + tag + " expected=" + z11));
            }
        }
        if (this._removeClippedSubviews) {
            view.setTag(R.id.view_clipped, Boolean.valueOf(z11));
        } else {
            view.setTag(R.id.view_clipped, null);
        }
    }

    public final int getAllChildrenCount$ReactAndroid_release() {
        return this.allChildrenCount;
    }

    public final List<String> getAxOrderList() {
        return this.axOrderList;
    }

    public final View getChildAtWithSubviewClippingEnabled$ReactAndroid_release(int i11) {
        if (i11 < 0 || i11 >= this.allChildrenCount) {
            return null;
        }
        View[] viewArr = this.allChildren;
        if (viewArr != null) {
            return viewArr[i11];
        }
        throw new IllegalStateException("Required value was null.");
    }

    @Override // android.view.View
    public Rect getClipBounds() {
        i0 i0Var;
        if (!((fo.c) fo.a.f12125a).syncAndroidClipBoundsWithOverflow() || (i0Var = this._overflow) == null || i0Var == i0.f28335e) {
            return super.getClipBounds();
        }
        Rect rect = new Rect();
        a.a.E(this, rect);
        return rect;
    }

    @Override // com.facebook.react.uimanager.u
    public void getClippingRect(Rect outClippingRect) {
        kotlin.jvm.internal.k.g(outClippingRect, "outClippingRect");
        Rect rect = this.clippingRect;
        if (rect == null) {
            throw new IllegalStateException("Required value was null.");
        }
        outClippingRect.set(rect);
    }

    public final Rect getClippingRect$ReactAndroid_release() {
        return this.clippingRect;
    }

    public Rect getHitSlopRect() {
        return this.hitSlopRect;
    }

    public final ReadableMap getNativeBackgroundMap$ReactAndroid_release() {
        return this.nativeBackgroundMap;
    }

    public final ReadableMap getNativeForegroundMap$ReactAndroid_release() {
        return this.nativeForegroundMap;
    }

    @Override // com.facebook.react.uimanager.y
    public String getOverflow() {
        i0 i0Var = this._overflow;
        int i11 = i0Var == null ? -1 : f.f20600a[i0Var.ordinal()];
        if (i11 == 1) {
            return "hidden";
        }
        if (i11 == 2) {
            return "scroll";
        }
        if (i11 != 3) {
            return null;
        }
        return "visible";
    }

    @Override // com.facebook.react.uimanager.y
    public Rect getOverflowInset() {
        return this.overflowInset;
    }

    @Override // com.facebook.react.uimanager.z
    public o getPointerEvents() {
        return this.pointerEvents;
    }

    public final boolean getPreventClipping() {
        return this.preventClipping;
    }

    @Override // com.facebook.react.uimanager.u
    public boolean getRemoveClippedSubviews() {
        if (((fo.c) fo.a.f12125a).disableSubviewClippingAndroid()) {
            return false;
        }
        return this._removeClippedSubviews;
    }

    public final boolean get_removeClippedSubviews$ReactAndroid_release() {
        return this._removeClippedSubviews;
    }

    public final void h() {
        setClipChildren(false);
        this._removeClippedSubviews = false;
        this.inSubviewClippingLoop = false;
        this.allChildren = null;
        this.allChildrenCount = 0;
        this.clippingRect = null;
        setHitSlopRect(null);
        this._overflow = i0.f28335e;
        setPointerEvents(o.f6126w);
        ow.a.D(this, getPointerEvents());
        this.childrenLayoutChangeListener = null;
        this.onInterceptTouchEventListener = null;
        this.needsOffscreenAlphaCompositing = false;
        this.backfaceOpacity = 1.0f;
        this.backfaceVisible = true;
        this.childrenRemovedWhileTransitioning = null;
        this.nativeBackgroundMap = null;
        this.nativeForegroundMap = null;
        this.preventClipping = false;
    }

    @Override // android.view.View
    public boolean hasOverlappingRendering() {
        return this.needsOffscreenAlphaCompositing;
    }

    public final boolean i(View view, Integer num) {
        if (view == null) {
            throw new IllegalStateException("Required value was null.");
        }
        Object tag = view.getTag(R.id.view_clipped);
        if (tag != null) {
            return ((Boolean) tag).booleanValue();
        }
        ViewParent parent = view.getParent();
        Set<Integer> set = this.childrenRemovedWhileTransitioning;
        boolean z11 = set != null && set.contains(Integer.valueOf(view.getId()));
        if (num != null) {
            ReactSoftExceptionLogger.logSoftException(ReactSoftExceptionLogger.Categories.RVG_IS_VIEW_CLIPPED, new ReactNoCrashSoftException("View missing clipping tag: index=" + num + " parentNull=" + (parent == null) + " parentThis=" + (parent == this) + " transitioning=" + z11));
        }
        if (parent == null || z11) {
            return true;
        }
        if (parent == this) {
            return false;
        }
        throw new IllegalStateException("Check failed.");
    }

    public final void j(ArrayList arrayList) {
        try {
            super.addChildrenForAccessibility(arrayList);
        } catch (IllegalArgumentException e4) {
            String message = e4.getMessage();
            if (message == null || !w60.o.m0(message, "descendant of this view", false)) {
                throw e4;
            }
            ReactSoftExceptionLogger.logSoftException(ReactSoftExceptionLogger.Categories.RVG_ADD_CHILDREN_FOR_ACCESSIBILITY, e4);
        }
    }

    /* JADX WARN: Code duplicated, block: B:57:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:59:0x00c6  */
    /* JADX WARN: Code duplicated, block: B:65:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:69:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:70:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    public final void k(Rect rect, int i11, int i12, Set set) {
        View view;
        boolean z11;
        u uVar;
        View view2;
        UiThreadUtil.assertOnUiThread();
        View[] viewArr = this.allChildren;
        if (viewArr != null) {
            view2 = viewArr[i11];
        } else {
            view = 0;
        }
        if (view == 0) {
            view = view2;
            throw new IllegalStateException("Required value was null.");
        }
        boolean zIntersects = rect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        Animation animation = view.getAnimation();
        boolean z12 = false;
        if (animation == null || animation.hasEnded()) {
            view = view2;
            view = view2;
            z11 = false;
        } else {
            view = view2;
            z11 = true;
        }
        g gVar = view instanceof g ? (g) view : null;
        boolean z13 = gVar != null && gVar.preventClipping;
        boolean z14 = set != null && set.contains(Integer.valueOf(view.getId()));
        boolean z15 = set != null;
        if (!zIntersects && !i(view, Integer.valueOf(i11)) && !z11 && view != getFocusedChild() && !z14 && !z13) {
            Companion.getClass();
            view.setTag(R.id.view_clipped, Boolean.TRUE);
            removeViewInLayout(view);
        } else {
            if ((((!z14 && !zIntersects) || !i(view, Integer.valueOf(i11))) && !z13) || view.getParent() != null) {
                if (zIntersects || z13) {
                }
                if (z15) {
                    uVar = view instanceof u ? (u) view : null;
                    if (uVar != null && uVar.getRemoveClippedSubviews()) {
                        z12 = true;
                    }
                    if (z12) {
                        ((u) view).updateClippingRect(set);
                    }
                }
            }
            int i13 = i11 - i12;
            if (i13 < 0) {
                throw new IllegalStateException("Check failed.");
            }
            Companion.getClass();
            view.setTag(R.id.view_clipped, Boolean.FALSE);
            addViewInLayout(view, i13, defaultLayoutParam, true);
            invalidate();
        }
        z15 = true;
        if (z15) {
            if (view instanceof u) {
            }
            if (uVar != null) {
                z12 = true;
            }
            if (z12) {
                ((u) view).updateClippingRect(set);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this._removeClippedSubviews) {
            updateClippingRect();
        }
        if (this.focusOnAttach) {
            requestFocusFromJS$ReactAndroid_release();
            this.focusOnAttach = false;
        }
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration newConfig) {
        kotlin.jvm.internal.k.g(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        ReadableMap readableMap = this.nativeBackgroundMap;
        if (readableMap != null) {
            applyNativeBackground$ReactAndroid_release(readableMap);
        }
        ReadableMap readableMap2 = this.nativeForegroundMap;
        if (readableMap2 != null) {
            applyNativeForeground$ReactAndroid_release(readableMap2);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent event) {
        kotlin.jvm.internal.k.g(event, "event");
        if (!ReactFeatureFlags.dispatchPointerEvents) {
            return super.onHoverEvent(event);
        }
        t0 t0Var = o.f6122d;
        o pointerEvents = getPointerEvents();
        t0Var.getClass();
        return t0.b(pointerEvents);
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent event) {
        int i11;
        kotlin.jvm.internal.k.g(event, "event");
        np.b bVar = this.onInterceptTouchEventListener;
        if (bVar == null || (i11 = ((np.a) bVar).f23264a) == -1 || event.getAction() == 1 || getId() != i11) {
            t0 t0Var = o.f6122d;
            o pointerEvents = getPointerEvents();
            t0Var.getClass();
            if (t0.c(pointerEvents)) {
                return super.onInterceptTouchEvent(event);
            }
        }
        return true;
    }

    @Override // android.view.View
    public void onMeasure(int i11, int i12) {
        com.facebook.imagepipeline.nativecode.c.L(i11, i12);
        setMeasuredDimension(View.MeasureSpec.getSize(i11), View.MeasureSpec.getSize(i12));
    }

    @Override // android.view.View
    public void onSizeChanged(int i11, int i12, int i13, int i14) {
        super.onSizeChanged(i11, i12, i13, i14);
        if (this._removeClippedSubviews) {
            updateClippingRect();
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        kotlin.jvm.internal.k.g(event, "event");
        t0 t0Var = o.f6122d;
        o pointerEvents = getPointerEvents();
        t0Var.getClass();
        return t0.b(pointerEvents);
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View child) {
        kotlin.jvm.internal.k.g(child, "child");
        UiThreadUtil.assertOnUiThread();
        g(child, false);
        super.onViewAdded(child);
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View child) {
        kotlin.jvm.internal.k.g(child, "child");
        UiThreadUtil.assertOnUiThread();
        g(child, true);
        if (child.getParent() != null) {
            int id2 = child.getId();
            if (this.childrenRemovedWhileTransitioning == null) {
                this.childrenRemovedWhileTransitioning = new LinkedHashSet();
            }
            Set<Integer> set = this.childrenRemovedWhileTransitioning;
            if (set != null) {
                set.add(Integer.valueOf(id2));
            }
        }
        super.onViewRemoved(child);
    }

    public void recycleView$ReactAndroid_release() {
        d dVar;
        this.recycleCount++;
        View[] viewArr = this.allChildren;
        if (viewArr != null && (dVar = this.childrenLayoutChangeListener) != null) {
            if (dVar != null) {
                dVar.f20599d = null;
            }
            int i11 = this.allChildrenCount;
            for (int i12 = 0; i12 < i11; i12++) {
                View view = viewArr[i12];
                if (view != null) {
                    view.removeOnLayoutChangeListener(this.childrenLayoutChangeListener);
                }
            }
        }
        h();
        getOverflowInset().setEmpty();
        removeAllViews();
        if (getParent() != null) {
            ViewParent parent = getParent();
            kotlin.jvm.internal.k.e(parent, "null cannot be cast to non-null type android.view.ViewGroup");
            ((ViewGroup) parent).removeView(this);
        }
        super.setBackground(null);
        setPointerEvents(o.f6126w);
        this.focusOnAttach = false;
    }

    public final void removeAllViewsWithSubviewClippingEnabled$ReactAndroid_release() {
        if (!this._removeClippedSubviews) {
            throw new IllegalStateException("Check failed.");
        }
        View[] viewArr = this.allChildren;
        if (viewArr == null) {
            throw new IllegalStateException("Required value was null.");
        }
        int i11 = this.allChildrenCount;
        for (int i12 = 0; i12 < i11; i12++) {
            View view = viewArr[i12];
            if (view != null) {
                view.removeOnLayoutChangeListener(this.childrenLayoutChangeListener);
            }
        }
        removeAllViewsInLayout();
        this.allChildrenCount = 0;
    }

    public final void removeViewWithSubviewClippingEnabled$ReactAndroid_release(View view) {
        kotlin.jvm.internal.k.g(view, "view");
        UiThreadUtil.assertOnUiThread();
        if (!this._removeClippedSubviews) {
            throw new IllegalStateException("Check failed.");
        }
        View[] viewArr = this.allChildren;
        if (viewArr == null) {
            throw new IllegalStateException("Required value was null.");
        }
        view.removeOnLayoutChangeListener(this.childrenLayoutChangeListener);
        int i11 = this.allChildrenCount;
        View[] viewArr2 = this.allChildren;
        if (viewArr2 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        int i12 = 0;
        while (true) {
            if (i12 >= i11) {
                i12 = -1;
                break;
            } else if (viewArr2[i12] == view) {
                break;
            } else {
                i12++;
            }
        }
        if (!i(viewArr[i12], Integer.valueOf(i12))) {
            int i13 = 0;
            for (int i14 = 0; i14 < i12; i14++) {
                if (i(viewArr[i14], Integer.valueOf(i14))) {
                    i13++;
                }
            }
            removeViewsInLayout(i12 - i13, 1);
            invalidate();
        }
        View[] viewArr3 = this.allChildren;
        if (viewArr3 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        int i15 = this.allChildrenCount;
        if (i12 == i15 - 1) {
            int i16 = i15 - 1;
            this.allChildrenCount = i16;
            viewArr3[i16] = null;
        } else {
            if (i12 < 0 || i12 >= i15) {
                throw new IndexOutOfBoundsException();
            }
            System.arraycopy(viewArr3, i12 + 1, viewArr3, i12, (i15 - i12) - 1);
            int i17 = this.allChildrenCount - 1;
            this.allChildrenCount = i17;
            viewArr3[i17] = null;
        }
    }

    public final void requestFocusFromJS$ReactAndroid_release() {
        if (isAttachedToWindow()) {
            super.requestFocus(130, null);
        } else {
            this.focusOnAttach = true;
        }
    }

    public final void setAxOrderList(List<String> list) {
        this.axOrderList = list;
    }

    public final void setBackfaceVisibility(String backfaceVisibility) {
        kotlin.jvm.internal.k.g(backfaceVisibility, "backfaceVisibility");
        this.backfaceVisible = "visible".equals(backfaceVisibility);
        setBackfaceVisibilityDependantOpacity();
    }

    public final void setBackfaceVisibilityDependantOpacity() {
        if (this.backfaceVisible) {
            setAlpha(this.backfaceOpacity);
            return;
        }
        float rotationX = getRotationX();
        float rotationY = getRotationY();
        if (rotationX < -90.0f || rotationX >= 90.0f || rotationY < -90.0f || rotationY >= 90.0f) {
            setAlpha(0.0f);
        } else {
            setAlpha(this.backfaceOpacity);
        }
    }

    @Override // android.view.View
    public void setBackgroundColor(int i11) {
        a.a.S(this, Integer.valueOf(i11));
    }

    public final void setBorderColor(int i11, Integer num) {
        a.a.T(this, (g0) g0.Q.get(i11), num);
    }

    @l30.c
    public final void setBorderRadius(float f3) {
        a.a.U(this, rp.h.f28312d, Float.isNaN(f3) ? null : new l(f3, m.f6102d));
    }

    public final void setBorderStyle(String str) {
        rp.j jVarJ;
        if (str != null) {
            rp.j.f28339d.getClass();
            jVarJ = al.c.j(str);
        } else {
            jVarJ = null;
        }
        a.a.V(this, jVarJ);
    }

    public final void setBorderWidth(int i11, float f3) {
        a.a.W(this, (g0) g0.Q.get(i11), Float.valueOf(b0.t0(f3)));
    }

    public final void setClippingRect$ReactAndroid_release(Rect rect) {
        this.clippingRect = rect;
    }

    public void setHitSlopRect(Rect rect) {
        this.hitSlopRect = rect;
    }

    public final void setNativeBackgroundMap$ReactAndroid_release(ReadableMap readableMap) {
        this.nativeBackgroundMap = readableMap;
    }

    public final void setNativeForegroundMap$ReactAndroid_release(ReadableMap readableMap) {
        this.nativeForegroundMap = readableMap;
    }

    public final void setNeedsOffscreenAlphaCompositing(boolean z11) {
        this.needsOffscreenAlphaCompositing = z11;
    }

    @Override // np.d
    public void setOnInterceptTouchEventListener(np.b listener) {
        kotlin.jvm.internal.k.g(listener, "listener");
        this.onInterceptTouchEventListener = listener;
    }

    public final void setOpacityIfPossible(float f3) {
        this.backfaceOpacity = f3;
        setBackfaceVisibilityDependantOpacity();
    }

    public void setOverflow(String str) {
        i0 i0VarM;
        if (str == null) {
            i0VarM = i0.f28335e;
        } else {
            i0.f28334d.getClass();
            i0VarM = il.c.m(str);
        }
        this._overflow = i0VarM;
        invalidate();
    }

    @Override // com.facebook.react.uimanager.y
    public void setOverflowInset(int i11, int i12, int i13, int i14) {
        if (j1.t(this) && (getOverflowInset().left != i11 || getOverflowInset().top != i12 || getOverflowInset().right != i13 || getOverflowInset().bottom != i14)) {
            invalidate();
        }
        getOverflowInset().set(i11, i12, i13, i14);
    }

    public void setPointerEvents(o oVar) {
        kotlin.jvm.internal.k.g(oVar, "<set-?>");
        this.pointerEvents = oVar;
    }

    public final void setPreventClipping(boolean z11) {
        this.preventClipping = z11;
    }

    public void setRemoveClippedSubviews(boolean z11) {
        if (((fo.c) fo.a.f12125a).disableSubviewClippingAndroid() || z11 == this._removeClippedSubviews) {
            return;
        }
        this._removeClippedSubviews = z11;
        this.childrenRemovedWhileTransitioning = null;
        if (z11) {
            Rect rect = new Rect();
            v.a(this, rect);
            this.clippingRect = rect;
            int childCount = getChildCount();
            this.allChildrenCount = childCount;
            View[] viewArr = new View[Math.max(12, childCount)];
            d dVar = new d();
            dVar.f20599d = this;
            this.childrenLayoutChangeListener = dVar;
            int i11 = this.allChildrenCount;
            for (int i12 = 0; i12 < i11; i12++) {
                View childAt = getChildAt(i12);
                viewArr[i12] = childAt;
                childAt.addOnLayoutChangeListener(this.childrenLayoutChangeListener);
                Companion.getClass();
                childAt.setTag(R.id.view_clipped, Boolean.FALSE);
            }
            this.allChildren = viewArr;
            updateClippingRect();
            return;
        }
        View[] viewArr2 = this.allChildren;
        if (viewArr2 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        if (this.childrenLayoutChangeListener == null) {
            throw new IllegalStateException("Required value was null.");
        }
        int i13 = this.allChildrenCount;
        for (int i14 = 0; i14 < i13; i14++) {
            View view = viewArr2[i14];
            if (view != null) {
                view.removeOnLayoutChangeListener(this.childrenLayoutChangeListener);
            }
        }
        Rect rect2 = this.clippingRect;
        if (rect2 == null) {
            throw new IllegalStateException("Required value was null.");
        }
        getDrawingRect(rect2);
        updateClippingToRect$ReactAndroid_release$default(this, rect2, null, 2, null);
        this.allChildren = null;
        this.clippingRect = null;
        this.allChildrenCount = 0;
        this.childrenLayoutChangeListener = null;
    }

    @l30.c
    public final void setTranslucentBackgroundDrawable(Drawable drawable) {
        a.a.Y(this, drawable);
    }

    public final void set_removeClippedSubviews$ReactAndroid_release(boolean z11) {
        this._removeClippedSubviews = z11;
    }

    public void updateClippingRect() {
        updateClippingRect(null);
    }

    public final void updateClippingToRect$ReactAndroid_release(Rect clippingRect, Set<Integer> set) {
        kotlin.jvm.internal.k.g(clippingRect, "clippingRect");
        View[] viewArr = this.allChildren;
        if (viewArr == null) {
            throw new IllegalStateException("Required value was null.");
        }
        this.inSubviewClippingLoop = true;
        int i11 = this.allChildrenCount;
        int i12 = 0;
        for (int i13 = 0; i13 < i11; i13++) {
            try {
                k(clippingRect, i13, i12, set);
                if (i(viewArr[i13], Integer.valueOf(i13))) {
                    i12++;
                }
                if (i13 - i12 > getChildCount()) {
                    int childCount = getChildCount();
                    int i14 = this.allChildrenCount;
                    int i15 = this.recycleCount;
                    int size = set != null ? set.size() : 0;
                    StringBuilder sbM = a1.h.m(i13, "Invalid clipping state. i=", i12, " clippedSoFar=", " count=");
                    a1.h.t(sbM, childCount, " allChildrenCount=", i14, " recycleCount=");
                    sbM.append(i15);
                    sbM.append("  excludedViews=");
                    sbM.append(size);
                    throw new IllegalStateException(sbM.toString());
                }
            } catch (IndexOutOfBoundsException e4) {
                HashSet hashSet = new HashSet();
                int i16 = 0;
                for (int i17 = 0; i17 < i13; i17++) {
                    i16 += i(viewArr[i17], Integer.valueOf(i17)) ? 1 : 0;
                    hashSet.add(viewArr[i17]);
                }
                int childCount2 = getChildCount();
                int i18 = this.allChildrenCount;
                int i19 = this.recycleCount;
                int size2 = hashSet.size();
                int size3 = set != null ? set.size() : 0;
                StringBuilder sbM2 = a1.h.m(i13, "Invalid clipping state. i=", i12, " clippedSoFar=", " count=");
                a1.h.t(sbM2, childCount2, " allChildrenCount=", i18, " recycleCount=");
                a1.h.t(sbM2, i19, " realClippedSoFar=", i16, " uniqueViewsCount=");
                sbM2.append(size2);
                sbM2.append(" excludedViews=");
                sbM2.append(size3);
                throw new IllegalStateException(sbM2.toString(), e4);
            }
        }
        this.inSubviewClippingLoop = false;
    }

    @Override // com.facebook.react.uimanager.u
    public void updateClippingRect(Set<Integer> set) {
        if (this._removeClippedSubviews) {
            Rect rect = this.clippingRect;
            if (rect == null) {
                throw new IllegalStateException("Required value was null.");
            }
            v.a(this, rect);
            updateClippingToRect$ReactAndroid_release(rect, set);
        }
    }

    @l30.c
    public final void setBorderRadius(float f3, int i11) {
        a.a.U(this, (rp.h) rp.h.Q.get(i11), Float.isNaN(f3) ? null : new l(f3, m.f6102d));
    }

    @Override // android.view.View
    public boolean getClipBounds(Rect outRect) {
        i0 i0Var;
        kotlin.jvm.internal.k.g(outRect, "outRect");
        if (((fo.c) fo.a.f12125a).syncAndroidClipBoundsWithOverflow() && (i0Var = this._overflow) != null && i0Var != i0.f28335e) {
            a.a.E(this, outRect);
            return true;
        }
        return super.getClipBounds(outRect);
    }

    public final void setBorderRadius(rp.h property, l lVar) {
        kotlin.jvm.internal.k.g(property, "property");
        a.a.U(this, property, lVar);
    }

    @Override // android.view.View, android.view.ViewParent
    @SuppressLint({"MissingSuperCall"})
    public void requestLayout() {
    }

    @Override // com.facebook.react.uimanager.f0
    public void updateDrawingOrder() {
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchSetPressed(boolean z11) {
    }

    public int getZIndexMappedChildIndex(int i11) {
        return i11;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z11, int i11, int i12, int i13, int i14) {
    }
}
