package lr;

import android.util.SparseArray;
import hs.q;
import java.util.HashMap;
import yq.d;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final SparseArray f20605a = new SparseArray();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final HashMap f20606b;

    static {
        HashMap map = new HashMap();
        f20606b = map;
        map.put(d.f36757d, 0);
        map.put(d.f36758e, 1);
        map.put(d.f36759i, 2);
        for (d dVar : map.keySet()) {
            f20605a.append(((Integer) f20606b.get(dVar)).intValue(), dVar);
        }
    }

    public static int a(d dVar) {
        Integer num = (Integer) f20606b.get(dVar);
        if (num != null) {
            return num.intValue();
        }
        throw new IllegalStateException("PriorityMapping is missing known Priority value " + dVar);
    }

    public static d b(int i11) {
        d dVar = (d) f20605a.get(i11);
        if (dVar != null) {
            return dVar;
        }
        throw new IllegalArgumentException(q.j(i11, "Unknown Priority for value "));
    }
}
