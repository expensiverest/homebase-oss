package ma;

import hs.q;
import j70.h;
import kotlin.jvm.internal.k;
import n70.t0;
import p.x2;

/* JADX INFO: loaded from: classes.dex */
@h
public final class c {
    public static final b Companion = new b();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f21280a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f21281b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f21282c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f21283d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21284e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f21285f;

    public /* synthetic */ c(int i11, String str, String str2, String str3, String str4, String str5, String str6) {
        if (63 != (i11 & 63)) {
            t0.j(i11, 63, a.f21279a.d());
            throw null;
        }
        this.f21280a = str;
        this.f21281b = str2;
        this.f21282c = str3;
        this.f21283d = str4;
        this.f21284e = str5;
        this.f21285f = str6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return k.b(this.f21280a, cVar.f21280a) && k.b(this.f21281b, cVar.f21281b) && k.b(this.f21282c, cVar.f21282c) && k.b(this.f21283d, cVar.f21283d) && k.b(this.f21284e, cVar.f21284e) && k.b(this.f21285f, cVar.f21285f);
    }

    public final int hashCode() {
        return this.f21285f.hashCode() + q.c(q.c(q.c(q.c(this.f21280a.hashCode() * 31, 31, this.f21281b), 31, this.f21282c), 31, this.f21283d), 31, this.f21284e);
    }

    public final String toString() {
        StringBuilder sbN = x2.n("SafetyPolicyNoticeEmbed(classificationId=", this.f21280a, ", titleText=", this.f21281b, ", titleIcon=");
        x2.t(sbN, this.f21282c, ", subtitleText=", this.f21283d, ", descriptionText=");
        return x2.k(sbN, this.f21284e, ", ctaText=", this.f21285f, ")");
    }
}
