package ma;

import j70.k;
import l70.g;
import m70.d;
import n70.h1;
import n70.v0;
import n70.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f21279a;
    private static final g descriptor;

    static {
        a aVar = new a();
        f21279a = aVar;
        v0 v0Var = new v0("com.discord.chat.bridge.policynotice.SafetyPolicyNoticeEmbed", aVar, 6);
        v0Var.b("classificationId", false);
        v0Var.b("titleText", false);
        v0Var.b("titleIcon", false);
        v0Var.b("subtitleText", false);
        v0Var.b("descriptionText", false);
        v0Var.b("ctaText", false);
        descriptor = v0Var;
    }

    @Override // j70.b
    public final Object a(m70.c cVar) {
        String strX;
        String strX2;
        String str;
        String str2;
        String str3;
        String str4;
        int i11;
        g gVar = descriptor;
        m70.a aVarB = cVar.b(gVar);
        if (aVarB.z()) {
            strX = aVarB.x(gVar, 0);
            String strX3 = aVarB.x(gVar, 1);
            String strX4 = aVarB.x(gVar, 2);
            String strX5 = aVarB.x(gVar, 3);
            String strX6 = aVarB.x(gVar, 4);
            strX2 = aVarB.x(gVar, 5);
            str = strX5;
            str2 = strX6;
            str3 = strX4;
            str4 = strX3;
            i11 = 63;
        } else {
            strX = null;
            String strX7 = null;
            String strX8 = null;
            String strX9 = null;
            String strX10 = null;
            String strX11 = null;
            boolean z11 = true;
            int i12 = 0;
            while (z11) {
                int iM = aVarB.m(gVar);
                switch (iM) {
                    case -1:
                        z11 = false;
                        continue;
                    case 0:
                        strX = aVarB.x(gVar, 0);
                        i12 |= 1;
                        continue;
                    case 1:
                        strX11 = aVarB.x(gVar, 1);
                        i12 |= 2;
                        break;
                    case 2:
                        strX10 = aVarB.x(gVar, 2);
                        i12 |= 4;
                        break;
                    case 3:
                        strX8 = aVarB.x(gVar, 3);
                        i12 |= 8;
                        break;
                    case 4:
                        strX9 = aVarB.x(gVar, 4);
                        i12 |= 16;
                        break;
                    case 5:
                        strX7 = aVarB.x(gVar, 5);
                        i12 |= 32;
                        break;
                    default:
                        throw new k(iM);
                }
            }
            strX2 = strX7;
            str = strX8;
            str2 = strX9;
            str3 = strX10;
            str4 = strX11;
            i11 = i12;
        }
        String str5 = strX;
        aVarB.c(gVar);
        return new c(i11, str5, str4, str3, str, str2, strX2);
    }

    @Override // n70.z
    public final j70.b[] b() {
        h1 h1Var = h1.f22707a;
        return new j70.b[]{h1Var, h1Var, h1Var, h1Var, h1Var, h1Var};
    }

    @Override // j70.j
    public final void c(d dVar, Object obj) {
        c value = (c) obj;
        kotlin.jvm.internal.k.g(value, "value");
        g gVar = descriptor;
        m70.b bVarB = dVar.b(gVar);
        bVarB.d(gVar, 0, value.f21280a);
        bVarB.d(gVar, 1, value.f21281b);
        bVarB.d(gVar, 2, value.f21282c);
        bVarB.d(gVar, 3, value.f21283d);
        bVarB.d(gVar, 4, value.f21284e);
        bVarB.d(gVar, 5, value.f21285f);
        bVarB.c(gVar);
    }

    @Override // j70.j
    public final g d() {
        return descriptor;
    }
}
