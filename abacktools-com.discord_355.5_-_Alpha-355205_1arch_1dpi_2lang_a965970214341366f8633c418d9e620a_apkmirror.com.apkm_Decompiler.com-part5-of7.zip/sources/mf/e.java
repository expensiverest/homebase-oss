package mf;

/* JADX INFO: loaded from: classes.dex */
public final class e {
    public final j70.b serializer() {
        return d.f21327a;
    }
}
