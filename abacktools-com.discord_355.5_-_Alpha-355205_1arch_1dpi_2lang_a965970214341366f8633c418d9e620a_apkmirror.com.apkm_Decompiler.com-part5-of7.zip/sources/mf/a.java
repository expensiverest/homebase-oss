package mf;

import j70.k;
import l70.g;
import n70.v0;
import n70.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f21326a;
    private static final g descriptor;

    static {
        a aVar = new a();
        f21326a = aVar;
        descriptor = new v0("com.discord.lifecycle.react.events.OnAppWillEnterForegroundEvent", aVar, 0);
    }

    @Override // j70.b
    public final Object a(m70.c cVar) {
        int iM;
        g gVar = descriptor;
        m70.a aVarB = cVar.b(gVar);
        if (!aVarB.z() && (iM = aVarB.m(gVar)) != -1) {
            throw new k(iM);
        }
        aVarB.c(gVar);
        return new c();
    }

    @Override // n70.z
    public final j70.b[] b() {
        return new j70.b[0];
    }

    @Override // j70.j
    public final void c(m70.d dVar, Object obj) {
        c value = (c) obj;
        kotlin.jvm.internal.k.g(value, "value");
        g gVar = descriptor;
        dVar.b(gVar).c(gVar);
    }

    @Override // j70.j
    public final g d() {
        return descriptor;
    }
}
