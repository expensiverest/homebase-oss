package mf;

import com.facebook.react.bridge.WritableMap;
import j70.h;

/* JADX INFO: loaded from: classes.dex */
@h
public final class c implements ui.a {
    public static final b Companion = new b();

    @Override // ui.a
    public final /* bridge */ WritableMap a() {
        return s1.e.J(this);
    }
}
