package mf;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public final j70.b serializer() {
        return a.f21326a;
    }
}
