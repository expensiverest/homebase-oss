package mx;

import java.util.concurrent.Delayed;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes3.dex */
public final class b0 extends hx.s implements ScheduledFuture, y, Future {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final o f22054e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ScheduledFuture f22055i;

    public b0(o oVar, ScheduledFuture scheduledFuture) {
        this.f22054e = oVar;
        this.f22055i = scheduledFuture;
    }

    public final boolean A(boolean z11) {
        return this.f22054e.cancel(z11);
    }

    @Override // mx.y
    public final void a(Runnable runnable, Executor executor) {
        this.f22054e.a(runnable, executor);
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z11) {
        boolean zA = A(z11);
        if (zA) {
            this.f22055i.cancel(z11);
        }
        return zA;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Delayed delayed) {
        return this.f22055i.compareTo(delayed);
    }

    @Override // java.util.concurrent.Future
    public final Object get() {
        return this.f22054e.get();
    }

    @Override // java.util.concurrent.Delayed
    public final long getDelay(TimeUnit timeUnit) {
        return this.f22055i.getDelay(timeUnit);
    }

    @Override // hx.s
    public final Object i() {
        return this.f22054e;
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f22054e.isCancelled();
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        return this.f22054e.isDone();
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j6, TimeUnit timeUnit) {
        return this.f22054e.get(j6, timeUnit);
    }
}
