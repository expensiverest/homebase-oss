package mx;

import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;

/* JADX INFO: loaded from: classes3.dex */
public final class f0 extends AtomicReference implements Runnable {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final gu.w f22068i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final gu.w f22069v;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Callable f22070d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ g0 f22071e;

    static {
        int i11 = 1;
        f22068i = new gu.w(i11);
        f22069v = new gu.w(i11);
    }

    public f0(g0 g0Var, Callable callable) {
        this.f22071e = g0Var;
        callable.getClass();
        this.f22070d = callable;
    }

    public final void a(Thread thread) {
        Runnable runnable = (Runnable) get();
        x xVar = null;
        boolean z11 = false;
        int i11 = 0;
        while (true) {
            boolean z12 = runnable instanceof x;
            gu.w wVar = f22069v;
            if (!z12 && runnable != wVar) {
                break;
            }
            if (z12) {
                xVar = (x) runnable;
            }
            i11++;
            if (i11 <= 1000) {
                Thread.yield();
            } else if (runnable == wVar || compareAndSet(runnable, wVar)) {
                z11 = Thread.interrupted() || z11;
                LockSupport.park(xVar);
            }
            runnable = (Runnable) get();
        }
        if (z11) {
            thread.interrupt();
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        Thread threadCurrentThread = Thread.currentThread();
        Object objCall = null;
        if (compareAndSet(null, threadCurrentThread)) {
            g0 g0Var = this.f22071e;
            boolean zIsDone = g0Var.isDone();
            gu.w wVar = f22068i;
            if (!zIsDone) {
                try {
                    objCall = this.f22070d.call();
                } catch (Throwable th2) {
                    try {
                        if (th2 instanceof InterruptedException) {
                            Thread.currentThread().interrupt();
                        }
                        if (!compareAndSet(threadCurrentThread, wVar)) {
                            a(threadCurrentThread);
                        }
                        if (zIsDone) {
                            return;
                        }
                        g0Var.n(th2);
                        return;
                    } catch (Throwable th3) {
                        if (!compareAndSet(threadCurrentThread, wVar)) {
                            a(threadCurrentThread);
                        }
                        if (!zIsDone) {
                            g0Var.m(null);
                        }
                        throw th3;
                    }
                }
            }
            if (!compareAndSet(threadCurrentThread, wVar)) {
                a(threadCurrentThread);
            }
            if (zIsDone) {
                return;
            }
            g0Var.m(objCall);
        }
    }

    @Override // java.util.concurrent.atomic.AtomicReference
    public final String toString() {
        String str;
        Runnable runnable = (Runnable) get();
        if (runnable == f22068i) {
            str = "running=[DONE]";
        } else if (runnable instanceof x) {
            str = "running=[INTERRUPTED]";
        } else if (runnable instanceof Thread) {
            str = "running=[RUNNING ON " + ((Thread) runnable).getName() + "]";
        } else {
            str = "running=[NOT STARTED YET]";
        }
        StringBuilder sbC = v0.d.c(str, ", ");
        sbC.append(this.f22070d.toString());
        return sbC.toString();
    }
}
