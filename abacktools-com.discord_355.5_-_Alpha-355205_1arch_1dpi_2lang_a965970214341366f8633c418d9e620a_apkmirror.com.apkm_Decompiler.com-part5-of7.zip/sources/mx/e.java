package mx;

/* JADX INFO: loaded from: classes3.dex */
public final class e implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final o f22066d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final y f22067e;

    public e(o oVar, y yVar) {
        this.f22066d = oVar;
        this.f22067e = yVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.f22066d.f22084d != this) {
            return;
        }
        if (o.f22083x.f(this.f22066d, this, o.j(this.f22067e))) {
            o.g(this.f22066d, false);
        }
    }
}
