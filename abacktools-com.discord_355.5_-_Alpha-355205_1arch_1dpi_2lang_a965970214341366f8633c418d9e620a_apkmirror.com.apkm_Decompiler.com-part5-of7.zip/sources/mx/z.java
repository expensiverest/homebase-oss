package mx;

import java.util.concurrent.ExecutorService;

/* JADX INFO: loaded from: classes3.dex */
public interface z extends ExecutorService, AutoCloseable {
}
