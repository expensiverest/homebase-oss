package mx;

import com.google.android.gms.internal.fido.he;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/* JADX INFO: loaded from: classes3.dex */
public final class w implements y {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final w f22092e = new w(null);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final he f22093i = new he(2, w.class);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f22094d;

    public w(Object obj) {
        this.f22094d = obj;
    }

    @Override // mx.y
    public final void a(Runnable runnable, Executor executor) {
        oq.a.t(executor, "Executor was null.");
        try {
            executor.execute(runnable);
        } catch (Exception e4) {
            f22093i.a().log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, (Throwable) e4);
        }
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z11) {
        return false;
    }

    @Override // java.util.concurrent.Future
    public final Object get() {
        return this.f22094d;
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return false;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        return true;
    }

    public final String toString() {
        return super.toString() + "[status=SUCCESS, result=[" + this.f22094d + "]]";
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j6, TimeUnit timeUnit) {
        timeUnit.getClass();
        return this.f22094d;
    }
}
