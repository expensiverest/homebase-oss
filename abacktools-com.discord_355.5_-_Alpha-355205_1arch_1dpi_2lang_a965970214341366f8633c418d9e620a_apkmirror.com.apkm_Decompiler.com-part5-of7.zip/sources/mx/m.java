package mx;

import java.security.AccessController;
import java.security.PrivilegedActionException;
import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes3.dex */
public final class m extends io.sentry.config.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Unsafe f22072a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long f22073b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final long f22074c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final long f22075d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final long f22076e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final long f22077f;

    static {
        Unsafe unsafe;
        try {
            try {
                unsafe = Unsafe.getUnsafe();
            } catch (PrivilegedActionException e4) {
                throw new RuntimeException("Could not initialize intrinsics", e4.getCause());
            }
        } catch (SecurityException unused) {
            unsafe = (Unsafe) AccessController.doPrivileged(new l());
        }
        try {
            f22074c = unsafe.objectFieldOffset(o.class.getDeclaredField("i"));
            f22073b = unsafe.objectFieldOffset(o.class.getDeclaredField("e"));
            f22075d = unsafe.objectFieldOffset(o.class.getDeclaredField("d"));
            f22076e = unsafe.objectFieldOffset(n.class.getDeclaredField("a"));
            f22077f = unsafe.objectFieldOffset(n.class.getDeclaredField("b"));
            f22072a = unsafe;
        } catch (NoSuchFieldException e9) {
            throw new RuntimeException(e9);
        }
    }

    @Override // io.sentry.config.a
    public final void M(n nVar, n nVar2) {
        f22072a.putObject(nVar, f22077f, nVar2);
    }

    @Override // io.sentry.config.a
    public final void N(n nVar, Thread thread) {
        f22072a.putObject(nVar, f22076e, thread);
    }

    @Override // io.sentry.config.a
    public final boolean e(o oVar, c cVar, c cVar2) {
        return j.a(f22072a, oVar, f22073b, cVar, cVar2);
    }

    @Override // io.sentry.config.a
    public final boolean f(o oVar, Object obj, Object obj2) {
        return k.a(f22072a, oVar, f22075d, obj, obj2);
    }

    @Override // io.sentry.config.a
    public final boolean g(o oVar, n nVar, n nVar2) {
        return i.a(f22072a, oVar, f22074c, nVar, nVar2);
    }

    @Override // io.sentry.config.a
    public final c v(o oVar) {
        c cVar;
        c cVar2 = c.f22056d;
        do {
            cVar = oVar.f22085e;
            if (cVar2 == cVar) {
                break;
            }
        } while (!e(oVar, cVar, cVar2));
        return cVar;
    }

    @Override // io.sentry.config.a
    public final n w(o oVar) {
        n nVar;
        n nVar2 = n.f22078c;
        do {
            nVar = oVar.f22086i;
            if (nVar2 == nVar) {
                break;
            }
        } while (!g(oVar, nVar, nVar2));
        return nVar;
    }
}
