package mx;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a f22047c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a f22048d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f22049a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Throwable f22050b;

    static {
        if (o.f22081v) {
            f22048d = null;
            f22047c = null;
        } else {
            f22048d = new a(null, false);
            f22047c = new a(null, true);
        }
    }

    public a(Throwable th2, boolean z11) {
        this.f22049a = z11;
        this.f22050b = th2;
    }
}
