package mx;

/* JADX INFO: loaded from: classes3.dex */
public final class n {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final n f22078c = new n();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Thread f22079a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile n f22080b;

    public n() {
        o.f22083x.N(this, Thread.currentThread());
    }
}
