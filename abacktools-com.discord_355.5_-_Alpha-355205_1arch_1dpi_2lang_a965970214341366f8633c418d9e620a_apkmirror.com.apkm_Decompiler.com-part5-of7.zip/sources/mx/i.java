package mx;

import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes3.dex */
public abstract /* synthetic */ class i {
    public static /* synthetic */ boolean a(Unsafe unsafe, o oVar, long j6, n nVar, n nVar2) {
        while (!unsafe.compareAndSwapObject(oVar, j6, nVar, nVar2)) {
            if (unsafe.getObject(oVar, j6) != nVar) {
                return false;
            }
        }
        return true;
    }
}
