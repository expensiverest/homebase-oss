package mx;

import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes3.dex */
public abstract /* synthetic */ class k {
    public static /* synthetic */ boolean a(Unsafe unsafe, o oVar, long j6, Object obj, Object obj2) {
        while (!unsafe.compareAndSwapObject(oVar, j6, obj, obj2)) {
            if (unsafe.getObject(oVar, j6) != obj) {
                return false;
            }
        }
        return true;
    }
}
