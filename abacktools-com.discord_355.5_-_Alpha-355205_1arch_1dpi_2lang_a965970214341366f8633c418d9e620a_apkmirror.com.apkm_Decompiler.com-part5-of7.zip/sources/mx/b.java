package mx;

import com.google.android.gms.internal.play_billing.l1;

/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f22052b = new b(new l1("Failure occurred while trying to finish a future.", 3));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Throwable f22053a;

    public b(Throwable th2) {
        th2.getClass();
        this.f22053a = th2;
    }
}
