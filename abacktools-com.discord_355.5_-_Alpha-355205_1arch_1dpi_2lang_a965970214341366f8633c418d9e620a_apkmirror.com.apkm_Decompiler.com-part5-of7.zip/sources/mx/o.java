package mx;

import com.discord.age_assurance.DigitalCredentialModule;
import com.google.android.gms.internal.fido.he;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public abstract class o extends nx.a implements y {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final boolean f22081v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final he f22082w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final io.sentry.config.a f22083x;
    public static final Object y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile Object f22084d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile c f22085e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public volatile n f22086i;

    static {
        boolean z11;
        Throwable th2;
        io.sentry.config.a fVar;
        try {
            z11 = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
        } catch (SecurityException unused) {
            z11 = false;
        }
        f22081v = z11;
        f22082w = new he(2, o.class);
        Throwable th3 = null;
        try {
            fVar = new m();
            th2 = null;
        } catch (Error | Exception e4) {
            th2 = e4;
            try {
                fVar = new d(AtomicReferenceFieldUpdater.newUpdater(n.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(n.class, n.class, "b"), AtomicReferenceFieldUpdater.newUpdater(o.class, n.class, "i"), AtomicReferenceFieldUpdater.newUpdater(o.class, c.class, "e"), AtomicReferenceFieldUpdater.newUpdater(o.class, Object.class, "d"));
            } catch (Error | Exception e9) {
                th3 = e9;
                fVar = new f();
            }
        }
        f22083x = fVar;
        if (th3 != null) {
            he heVar = f22082w;
            Logger loggerA = heVar.a();
            Level level = Level.SEVERE;
            loggerA.log(level, "UnsafeAtomicHelper is broken!", th2);
            heVar.a().log(level, "SafeAtomicHelper is broken!", th3);
        }
        y = new Object();
    }

    public static void g(o oVar, boolean z11) {
        c cVar = null;
        while (true) {
            for (n nVarW = f22083x.w(oVar); nVarW != null; nVarW = nVarW.f22080b) {
                Thread thread = nVarW.f22079a;
                if (thread != null) {
                    nVarW.f22079a = null;
                    LockSupport.unpark(thread);
                }
            }
            if (z11) {
                z11 = false;
            }
            oVar.e();
            c cVar2 = cVar;
            c cVarV = f22083x.v(oVar);
            c cVar3 = cVar2;
            while (cVarV != null) {
                c cVar4 = cVarV.f22059c;
                cVarV.f22059c = cVar3;
                cVar3 = cVarV;
                cVarV = cVar4;
            }
            while (cVar3 != null) {
                cVar = cVar3.f22059c;
                Runnable runnable = cVar3.f22057a;
                Objects.requireNonNull(runnable);
                if (runnable instanceof e) {
                    e eVar = (e) runnable;
                    oVar = eVar.f22066d;
                    if (oVar.f22084d == eVar) {
                        if (f22083x.f(oVar, eVar, j(eVar.f22067e))) {
                        }
                    } else {
                        continue;
                    }
                } else {
                    Executor executor = cVar3.f22058b;
                    Objects.requireNonNull(executor);
                    h(runnable, executor);
                }
                cVar3 = cVar;
            }
            return;
        }
    }

    public static void h(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (Exception e4) {
            f22082w.a().log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, (Throwable) e4);
        }
    }

    public static Object i(Object obj) throws ExecutionException {
        if (obj instanceof a) {
            Throwable th2 = ((a) obj).f22050b;
            CancellationException cancellationException = new CancellationException("Task was cancelled.");
            cancellationException.initCause(th2);
            throw cancellationException;
        }
        if (obj instanceof b) {
            throw new ExecutionException(((b) obj).f22053a);
        }
        if (obj == y) {
            return null;
        }
        return obj;
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0046  */
    /* JADX WARN: Multi-variable type inference failed */
    public static Object j(y yVar) {
        Object obj;
        Throwable th2;
        if (yVar instanceof g) {
            Object aVar = ((o) yVar).f22084d;
            if (aVar instanceof a) {
                a aVar2 = (a) aVar;
                if (aVar2.f22049a) {
                    aVar = aVar2.f22050b != null ? new a(aVar2.f22050b, false) : a.f22048d;
                }
            }
            Objects.requireNonNull(aVar);
            return aVar;
        }
        if (yVar instanceof nx.a) {
            o oVar = (o) ((nx.a) yVar);
            if (oVar instanceof g) {
                Object obj2 = oVar.f22084d;
                th2 = obj2 instanceof b ? ((b) obj2).f22053a : null;
                if (th2 != null) {
                    return new b(th2);
                }
            } else {
                oVar.getClass();
            }
            if (th2 != null) {
                return new b(th2);
            }
        }
        boolean zIsCancelled = yVar.isCancelled();
        boolean z11 = true;
        if ((!f22081v) && zIsCancelled) {
            a aVar3 = a.f22048d;
            Objects.requireNonNull(aVar3);
            return aVar3;
        }
        boolean z12 = false;
        while (true) {
            try {
                try {
                    try {
                        obj = yVar.get();
                        break;
                    } catch (Error e4) {
                        e = e4;
                        return new b(e);
                    }
                } catch (InterruptedException unused) {
                    z12 = z11;
                } catch (Throwable th3) {
                    if (z12) {
                        Thread.currentThread().interrupt();
                    }
                    throw th3;
                }
            } catch (Error | Exception e9) {
                e = e9;
                return new b(e);
            } catch (CancellationException e11) {
                if (zIsCancelled) {
                    return new a(e11, false);
                }
                return new b(new IllegalArgumentException("get() threw CancellationException, despite reporting isCancelled() == false: " + yVar, e11));
            } catch (ExecutionException e12) {
                if (!zIsCancelled) {
                    return new b(e12.getCause());
                }
                return new a(new IllegalArgumentException("get() did not throw CancellationException, despite reporting isCancelled() == true: " + yVar, e12), false);
            }
        }
        if (z12) {
            Thread.currentThread().interrupt();
        }
        if (!zIsCancelled) {
            return obj == null ? y : obj;
        }
        return new a(new IllegalArgumentException("get() did not throw CancellationException, despite reporting isCancelled() == true: " + yVar), false);
    }

    @Override // mx.y
    public void a(Runnable runnable, Executor executor) {
        c cVar;
        c cVar2 = c.f22056d;
        oq.a.t(executor, "Executor was null.");
        if (!isDone() && (cVar = this.f22085e) != cVar2) {
            c cVar3 = new c(runnable, executor);
            do {
                cVar3.f22059c = cVar;
                if (f22083x.e(this, cVar, cVar3)) {
                    return;
                } else {
                    cVar = this.f22085e;
                }
            } while (cVar != cVar2);
        }
        h(runnable, executor);
    }

    @Override // java.util.concurrent.Future
    public boolean cancel(boolean z11) {
        a aVar;
        Object obj = this.f22084d;
        if (!(obj == null) && !(obj instanceof e)) {
            return false;
        }
        if (f22081v) {
            aVar = new a(new CancellationException("Future.cancel() was called."), z11);
        } else {
            aVar = z11 ? a.f22047c : a.f22048d;
            Objects.requireNonNull(aVar);
        }
        o oVar = this;
        boolean z12 = false;
        while (true) {
            if (f22083x.f(oVar, obj, aVar)) {
                g(oVar, z11);
                if (obj instanceof e) {
                    y yVar = ((e) obj).f22067e;
                    if (yVar instanceof g) {
                        oVar = (o) yVar;
                        obj = oVar.f22084d;
                        if ((obj == null) | (obj instanceof e)) {
                            z12 = true;
                        }
                    } else {
                        yVar.cancel(z11);
                    }
                }
                return true;
            }
            obj = oVar.f22084d;
            if (!(obj instanceof e)) {
                return z12;
            }
        }
    }

    public final void d(StringBuilder sb2) {
        Object obj;
        boolean z11 = false;
        while (true) {
            try {
                try {
                    obj = get();
                    break;
                } catch (InterruptedException unused) {
                    z11 = true;
                } catch (Throwable th2) {
                    if (z11) {
                        Thread.currentThread().interrupt();
                    }
                    throw th2;
                }
            } catch (CancellationException unused2) {
                sb2.append(DigitalCredentialModule.CODE_CANCELLED);
                return;
            } catch (ExecutionException e4) {
                sb2.append("FAILURE, cause=[");
                sb2.append(e4.getCause());
                sb2.append("]");
                return;
            } catch (Exception e9) {
                sb2.append("UNKNOWN, cause=[");
                sb2.append(e9.getClass());
                sb2.append(" thrown from get()]");
                return;
            }
        }
        if (z11) {
            Thread.currentThread().interrupt();
        }
        sb2.append("SUCCESS, result=[");
        f(sb2, obj);
        sb2.append("]");
    }

    public final void f(StringBuilder sb2, Object obj) {
        if (obj == null) {
            sb2.append("null");
        } else {
            if (obj == this) {
                sb2.append("this future");
                return;
            }
            sb2.append(obj.getClass().getName());
            sb2.append("@");
            sb2.append(Integer.toHexString(System.identityHashCode(obj)));
        }
    }

    @Override // java.util.concurrent.Future
    public Object get(long j6, TimeUnit timeUnit) throws InterruptedException, TimeoutException {
        boolean z11;
        long j11;
        n nVar = n.f22078c;
        long nanos = timeUnit.toNanos(j6);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f22084d;
        if ((obj != null) && (!(obj instanceof e))) {
            return i(obj);
        }
        long j12 = 0;
        long jNanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            n nVar2 = this.f22086i;
            if (nVar2 != nVar) {
                n nVar3 = new n();
                z11 = true;
                while (true) {
                    io.sentry.config.a aVar = f22083x;
                    aVar.M(nVar3, nVar2);
                    if (aVar.g(this, nVar2, nVar3)) {
                        j11 = j12;
                        do {
                            LockSupport.parkNanos(this, Math.min(nanos, 2147483647999999999L));
                            if (Thread.interrupted()) {
                                l(nVar3);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f22084d;
                            if ((obj2 != null) && (!(obj2 instanceof e))) {
                                return i(obj2);
                            }
                            nanos = jNanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        l(nVar3);
                        break;
                    }
                    long j13 = j12;
                    nVar2 = this.f22086i;
                    if (nVar2 != nVar) {
                        j12 = j13;
                    }
                }
            }
            Object obj3 = this.f22084d;
            Objects.requireNonNull(obj3);
            return i(obj3);
        }
        z11 = true;
        j11 = 0;
        while (nanos > j11) {
            Object obj4 = this.f22084d;
            if ((obj4 != null ? z11 : false) && (!(obj4 instanceof e))) {
                return i(obj4);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = jNanoTime - System.nanoTime();
        }
        String string = toString();
        String string2 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = string2.toLowerCase(locale);
        StringBuilder sbM = x2.m(j6, "Waited ", " ");
        sbM.append(timeUnit.toString().toLowerCase(locale));
        String string3 = sbM.toString();
        if (nanos + 1000 < j11) {
            String strG = x2.g(string3, " (plus ");
            long j14 = -nanos;
            long jConvert = timeUnit.convert(j14, TimeUnit.NANOSECONDS);
            long nanos2 = j14 - timeUnit.toNanos(jConvert);
            boolean z12 = (jConvert == j11 || nanos2 > 1000) ? z11 : false;
            if (jConvert > j11) {
                String strG2 = strG + jConvert + " " + lowerCase;
                if (z12) {
                    strG2 = x2.g(strG2, ",");
                }
                strG = x2.g(strG2, " ");
            }
            if (z12) {
                strG = strG + nanos2 + " nanoseconds ";
            }
            string3 = x2.g(strG, "delay)");
        }
        if (isDone()) {
            throw new TimeoutException(x2.g(string3, " but future completed as timeout expired"));
        }
        throw new TimeoutException(x2.h(string3, " for ", string));
    }

    public boolean isCancelled() {
        return this.f22084d instanceof a;
    }

    @Override // java.util.concurrent.Future
    public boolean isDone() {
        Object obj = this.f22084d;
        return (!(obj instanceof e)) & (obj != null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public String k() {
        if (!(this instanceof ScheduledFuture)) {
            return null;
        }
        return "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
    }

    public final void l(n nVar) {
        nVar.f22079a = null;
        while (true) {
            n nVar2 = this.f22086i;
            if (nVar2 == n.f22078c) {
                return;
            }
            n nVar3 = null;
            while (nVar2 != null) {
                n nVar4 = nVar2.f22080b;
                if (nVar2.f22079a != null) {
                    nVar3 = nVar2;
                } else if (nVar3 != null) {
                    nVar3.f22080b = nVar4;
                    if (nVar3.f22079a == null) {
                    }
                } else if (!f22083x.g(this, nVar2, nVar4)) {
                }
                nVar2 = nVar4;
            }
            return;
        }
    }

    public boolean m(Object obj) {
        if (obj == null) {
            obj = y;
        }
        if (!f22083x.f(this, null, obj)) {
            return false;
        }
        g(this, false);
        return true;
    }

    public boolean n(Throwable th2) {
        th2.getClass();
        if (!f22083x.f(this, null, new b(th2))) {
            return false;
        }
        g(this, false);
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0048  */
    public boolean o(y yVar) {
        b bVar;
        yVar.getClass();
        Object obj = this.f22084d;
        if (obj != null) {
            if (obj instanceof a) {
                yVar.cancel(((a) obj).f22049a);
            }
        } else if (yVar.isDone()) {
            if (f22083x.f(this, null, j(yVar))) {
                g(this, false);
                return true;
            }
        } else {
            e eVar = new e(this, yVar);
            if (f22083x.f(this, null, eVar)) {
                try {
                    yVar.a(eVar, r.f22087d);
                    return true;
                } catch (Throwable th2) {
                    try {
                        bVar = new b(th2);
                    } catch (Error | Exception unused) {
                        bVar = b.f22052b;
                    }
                    f22083x.f(this, eVar, bVar);
                    return true;
                }
            }
            obj = this.f22084d;
            if (obj instanceof a) {
                yVar.cancel(((a) obj).f22049a);
            }
        }
        return false;
    }

    public final String toString() {
        String strK;
        StringBuilder sb2 = new StringBuilder();
        if (getClass().getName().startsWith("com.google.common.util.concurrent.")) {
            sb2.append(getClass().getSimpleName());
        } else {
            sb2.append(getClass().getName());
        }
        sb2.append('@');
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        sb2.append("[status=");
        if (isCancelled()) {
            sb2.append(DigitalCredentialModule.CODE_CANCELLED);
        } else if (isDone()) {
            d(sb2);
        } else {
            int length = sb2.length();
            sb2.append("PENDING");
            Object obj = this.f22084d;
            if (obj instanceof e) {
                sb2.append(", setFuture=[");
                y yVar = ((e) obj).f22067e;
                try {
                    if (yVar == this) {
                        sb2.append("this future");
                    } else {
                        sb2.append(yVar);
                    }
                } catch (Exception e4) {
                    e = e4;
                    sb2.append("Exception thrown from implementation: ");
                    sb2.append(e.getClass());
                } catch (StackOverflowError e9) {
                    e = e9;
                    sb2.append("Exception thrown from implementation: ");
                    sb2.append(e.getClass());
                }
                sb2.append("]");
            } else {
                try {
                    strK = k();
                    if (strK == null || strK.isEmpty()) {
                        strK = null;
                    }
                } catch (Exception | StackOverflowError e11) {
                    strK = "Exception thrown from implementation: " + e11.getClass();
                }
                if (strK != null) {
                    sb2.append(", info=[");
                    sb2.append(strK);
                    sb2.append("]");
                }
            }
            if (isDone()) {
                sb2.delete(length, sb2.length());
                d(sb2);
            }
        }
        sb2.append("]");
        return sb2.toString();
    }

    public void e() {
    }

    @Override // java.util.concurrent.Future
    public Object get() throws InterruptedException {
        Object obj;
        n nVar = n.f22078c;
        if (!Thread.interrupted()) {
            Object obj2 = this.f22084d;
            if ((obj2 != null) & (!(obj2 instanceof e))) {
                return i(obj2);
            }
            n nVar2 = this.f22086i;
            if (nVar2 != nVar) {
                n nVar3 = new n();
                do {
                    io.sentry.config.a aVar = f22083x;
                    aVar.M(nVar3, nVar2);
                    if (aVar.g(this, nVar2, nVar3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f22084d;
                            } else {
                                l(nVar3);
                                throw new InterruptedException();
                            }
                        } while (!((obj != null) & (!(obj instanceof e))));
                        return i(obj);
                    }
                    nVar2 = this.f22086i;
                } while (nVar2 != nVar);
            }
            Object obj3 = this.f22084d;
            Objects.requireNonNull(obj3);
            return i(obj3);
        }
        throw new InterruptedException();
    }
}
