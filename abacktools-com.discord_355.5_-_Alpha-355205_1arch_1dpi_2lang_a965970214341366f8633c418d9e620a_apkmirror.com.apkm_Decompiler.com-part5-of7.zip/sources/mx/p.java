package mx;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class p extends s implements Runnable {
    public y J;
    public gx.k K;

    @Override // mx.o
    public final void e() {
        y yVar = this.J;
        boolean z11 = false;
        if ((yVar != null) & (this.f22084d instanceof a)) {
            Object obj = this.f22084d;
            if ((obj instanceof a) && ((a) obj).f22049a) {
                z11 = true;
            }
            yVar.cancel(z11);
        }
        this.J = null;
        this.K = null;
    }

    @Override // mx.o
    public final String k() {
        String str;
        y yVar = this.J;
        gx.k kVar = this.K;
        String strK = super.k();
        if (yVar != null) {
            str = "inputFuture=[" + yVar + "], ";
        } else {
            str = "";
        }
        if (kVar == null) {
            if (strK != null) {
                return x2.g(str, strK);
            }
            return null;
        }
        return str + "function=[" + kVar + "]";
    }

    @Override // java.lang.Runnable
    public final void run() {
        y yVar = this.J;
        gx.k kVar = this.K;
        if (((this.f22084d instanceof a) | (yVar == null)) || (kVar == null)) {
            return;
        }
        this.J = null;
        if (yVar.isCancelled()) {
            o(yVar);
            return;
        }
        try {
            try {
                Object objApply = kVar.apply(k7.f.q(yVar));
                this.K = null;
                m(objApply);
            } catch (Throwable th2) {
                try {
                    if (th2 instanceof InterruptedException) {
                        Thread.currentThread().interrupt();
                    }
                    n(th2);
                } finally {
                    this.K = null;
                }
            }
        } catch (Error e4) {
            n(e4);
        } catch (CancellationException unused) {
            cancel(false);
        } catch (ExecutionException e9) {
            n(e9.getCause());
        } catch (Exception e11) {
            n(e11);
        }
    }
}
