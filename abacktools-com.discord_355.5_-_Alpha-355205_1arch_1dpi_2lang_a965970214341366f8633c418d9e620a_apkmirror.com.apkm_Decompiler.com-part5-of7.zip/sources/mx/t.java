package mx;

/* JADX INFO: loaded from: classes3.dex */
public interface t {
    void d(Object obj);

    void onFailure(Throwable th2);
}
