package mx;

import java.util.concurrent.Executor;
import java.util.concurrent.Future;

/* JADX INFO: loaded from: classes3.dex */
public interface y extends Future {
    void a(Runnable runnable, Executor executor);
}
