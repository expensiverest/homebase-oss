package mx;

import java.util.concurrent.locks.AbstractOwnableSynchronizer;

/* JADX INFO: loaded from: classes3.dex */
public final class x extends AbstractOwnableSynchronizer implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final f0 f22095d;

    public x(f0 f0Var) {
        this.f22095d = f0Var;
    }

    public static void a(x xVar, Thread thread) {
        xVar.setExclusiveOwnerThread(thread);
    }

    public final String toString() {
        return this.f22095d.toString();
    }

    @Override // java.lang.Runnable
    public final void run() {
    }
}
