package mx;

import java.util.concurrent.Callable;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.locks.LockSupport;

/* JADX INFO: loaded from: classes3.dex */
public final class g0 extends s implements RunnableFuture {
    public volatile f0 J;

    public g0(Callable callable) {
        this.J = new f0(this, callable);
    }

    @Override // mx.o
    public final void e() {
        f0 f0Var;
        Object obj = this.f22084d;
        if ((obj instanceof a) && ((a) obj).f22049a && (f0Var = this.J) != null) {
            gu.w wVar = f0.f22069v;
            gu.w wVar2 = f0.f22068i;
            Runnable runnable = (Runnable) f0Var.get();
            if (runnable instanceof Thread) {
                x xVar = new x(f0Var);
                x.a(xVar, Thread.currentThread());
                if (f0Var.compareAndSet(runnable, xVar)) {
                    try {
                        ((Thread) runnable).interrupt();
                        if (((Runnable) f0Var.getAndSet(wVar2)) == wVar) {
                            LockSupport.unpark((Thread) runnable);
                        }
                    } catch (Throwable th2) {
                        if (((Runnable) f0Var.getAndSet(wVar2)) == wVar) {
                            LockSupport.unpark((Thread) runnable);
                        }
                        throw th2;
                    }
                }
            }
        }
        this.J = null;
    }

    @Override // mx.o
    public final String k() {
        f0 f0Var = this.J;
        if (f0Var == null) {
            return super.k();
        }
        return "task=[" + f0Var + "]";
    }

    @Override // java.util.concurrent.RunnableFuture, java.lang.Runnable
    public final void run() {
        f0 f0Var = this.J;
        if (f0Var != null) {
            f0Var.run();
        }
        this.J = null;
    }
}
