package mx;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.widget.ProgressBar;
import androidx.core.view.j1;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.internal.fido.b4;
import com.google.android.gms.internal.fido.f4;
import com.google.android.gms.internal.fido.h4;
import com.google.android.gms.internal.fido.i4;
import com.google.android.gms.internal.fido.ie;
import com.google.android.gms.internal.fido.oe;
import com.google.android.gms.internal.fido.p4;
import com.google.android.gms.internal.fido.td;
import com.google.android.gms.internal.fido.u4;
import com.google.android.gms.internal.fido.xe;
import com.google.android.gms.internal.fido.y3;
import com.google.android.gms.tasks.Task;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes3.dex */
public final class u implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f22089d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f22090e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Object f22091i;

    public /* synthetic */ u(int i11, Object obj, Object obj2) {
        this.f22089d = i11;
        this.f22090e = obj;
        this.f22091i = obj2;
    }

    private final void a() {
        int i11 = 0;
        while (true) {
            try {
                ((Runnable) this.f22090e).run();
            } catch (Throwable th2) {
                z60.z.s(th2, q30.i.f26481d);
            }
            try {
                Runnable runnableP0 = ((e70.h) this.f22091i).p0();
                if (runnableP0 == null) {
                    return;
                }
                this.f22090e = runnableP0;
                i11++;
                if (i11 >= 16) {
                    e70.h hVar = (e70.h) this.f22091i;
                    if (e70.b.j(hVar.f10283v, hVar)) {
                        e70.h hVar2 = (e70.h) this.f22091i;
                        e70.b.i(hVar2.f10283v, hVar2, this);
                        return;
                    }
                }
            } catch (Throwable th3) {
                e70.h hVar3 = (e70.h) this.f22091i;
                synchronized (hVar3.y) {
                    e70.h.J.decrementAndGet(hVar3);
                    throw th3;
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:47:0x00af A[Catch: all -> 0x00ad, TryCatch #1 {all -> 0x00ad, blocks: (B:33:0x008f, B:35:0x0093, B:37:0x0097, B:42:0x00a4, B:47:0x00af, B:48:0x00bb), top: B:61:0x008f }] */
    private final void b() {
        boolean z11;
        boolean z12;
        g8.a aVar = (g8.a) this.f22090e;
        h4 h4Var = (h4) this.f22091i;
        k7.e eVar = (k7.e) aVar.f12962b;
        if (eVar == null) {
            return;
        }
        h4Var.getClass();
        try {
            byte[] bArr = (byte[]) h4Var.f6646e;
            com.google.android.gms.internal.fido.k kVar = com.google.android.gms.internal.fido.k.f6733a;
            int i11 = xe.f7132a;
            i4 i4VarT = i4.t(bArr, com.google.android.gms.internal.fido.k.f6734b);
            boolean z13 = false;
            for (b4 b4Var : ((p4) eVar.f19327i).f6900f) {
                List listS = i4VarT.s();
                b4Var.getClass();
                h4 h4Var2 = f4.f6566i;
                h4Var2.getClass();
                if (listS == null || listS.isEmpty()) {
                    z11 = false;
                } else {
                    Iterator it = listS.iterator();
                    z11 = false;
                    while (it.hasNext()) {
                        y3 y3Var = (y3) ((ConcurrentHashMap) h4Var2.f6646e).get((String) it.next());
                        if (y3Var != null) {
                            f4 f4Var = y3Var.f7142a;
                            if (f4Var.f6572e) {
                                lm.a aVar2 = f4Var.f6568a;
                                if (aVar2 != null && (aVar2.f20528b || ((c5.h) aVar2.f20532f).f4443b == 3 || f4Var.f6575h.z())) {
                                    synchronized (f4Var) {
                                        try {
                                            lm.a aVar3 = f4Var.f6568a;
                                            if (aVar3 != null) {
                                                if (aVar3.f20528b) {
                                                    f4Var.f6568a = null;
                                                    ((AtomicInteger) f4Var.f6574g.f6646e).incrementAndGet();
                                                } else if ((((c5.h) aVar3.f20532f).f4443b == 3) || f4Var.f6575h.z()) {
                                                    f4Var.f6568a = null;
                                                    ((AtomicInteger) f4Var.f6574g.f6646e).incrementAndGet();
                                                }
                                            }
                                        } catch (Throwable th2) {
                                            throw th2;
                                        }
                                    }
                                }
                                z12 = false;
                            } else {
                                z12 = true;
                            }
                            z11 |= z12;
                        }
                    }
                }
                if (z11 && !z13) {
                    ((u4) eVar.f19326e).zza();
                    z13 = true;
                }
            }
        } catch (com.google.android.gms.internal.fido.z unused) {
            eVar.getClass();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v11, types: [gu.f, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v9, types: [gu.f, java.lang.Object] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    private final void c() {
        gu.j jVar = (gu.j) this.f22091i;
        if (jVar.f13524e) {
            gu.c0 c0Var = (gu.c0) this.f22090e;
            eu.b bVar = c0Var.f13507b;
            boolean z11 = false;
            if (bVar.f10773e != 0 && bVar.f10774i != null) {
                ?? r11 = jVar.f13523d;
                Activity activityA = jVar.a();
                PendingIntent pendingIntent = bVar.f10774i;
                hu.s.g(pendingIntent);
                int i11 = c0Var.f13506a;
                int i12 = GoogleApiActivity.f6371e;
                Intent intent = new Intent(activityA, (Class<?>) GoogleApiActivity.class);
                intent.putExtra("pending_intent", pendingIntent);
                intent.putExtra("failing_client_id", i11);
                intent.putExtra("notify_manager", false);
                r11.startActivityForResult(intent, 1);
                return;
            }
            Activity activityA2 = jVar.a();
            int i13 = bVar.f10773e;
            eu.e eVar = jVar.f13527w;
            if (eVar.a(i13, activityA2, null) != null) {
                eVar.f(jVar.a(), jVar.f13523d, bVar.f10773e, jVar);
                return;
            }
            if (bVar.f10773e != 18) {
                int i14 = c0Var.f13506a;
                jVar.f13525i.set(null);
                jVar.y.i(bVar, i14);
                return;
            }
            Activity activityA3 = jVar.a();
            ProgressBar progressBar = new ProgressBar(activityA3, null, R.attr.progressBarStyleLarge);
            progressBar.setIndeterminate(true);
            progressBar.setVisibility(0);
            AlertDialog.Builder builder = new AlertDialog.Builder(activityA3);
            builder.setView(progressBar);
            builder.setMessage(hu.m.b(activityA3, 18));
            builder.setPositiveButton("", (DialogInterface.OnClickListener) null);
            AlertDialog alertDialogCreate = builder.create();
            eu.e.h(activityA3, alertDialogCreate, "GooglePlayServicesUpdatingDialog", jVar);
            Context applicationContext = jVar.a().getApplicationContext();
            k7.l lVar = new k7.l(this, alertDialogCreate, z11);
            IntentFilter intentFilter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
            intentFilter.addDataScheme("package");
            gu.q qVar = new gu.q(lVar);
            j1.z(applicationContext, qVar, intentFilter, null, 2);
            qVar.f13554b = applicationContext;
            if (eu.i.a(applicationContext)) {
                return;
            }
            gu.j jVar2 = (gu.j) this.f22091i;
            jVar2.f13525i.set(null);
            com.facebook.react.uimanager.s sVar = jVar2.y.P;
            sVar.sendMessage(sVar.obtainMessage(3));
            if (alertDialogCreate.isShowing()) {
                alertDialogCreate.dismiss();
            }
            synchronized (qVar) {
                try {
                    Context context = qVar.f13554b;
                    if (context != null) {
                        context.unregisterReceiver(qVar);
                    }
                    qVar.f13554b = null;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    private final void d() {
        k7.o oVar;
        c7.f fVar = ((j7.b) this.f22091i).f17960d.f4576f;
        String str = (String) this.f22090e;
        synchronized (fVar.k) {
            try {
                c7.u uVarC = fVar.c(str);
                oVar = uVarC != null ? uVarC.f4584i : null;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (oVar == null || !oVar.b()) {
            return;
        }
        synchronized (((j7.b) this.f22091i).f17962i) {
            ((j7.b) this.f22091i).f17965x.put(k80.d.w(oVar), oVar);
            j7.b bVar = (j7.b) this.f22091i;
            ((j7.b) this.f22091i).y.put(k80.d.w(oVar), g7.i.a(bVar.J, oVar, bVar.f17961e.f22668b, bVar));
        }
    }

    private final void e() {
        nv.k kVar = (nv.k) this.f22091i;
        synchronized (kVar.f23541i) {
            ((nv.c) kVar.f23542v).onComplete((Task) this.f22090e);
        }
    }

    private final void f() {
        nv.k kVar = (nv.k) this.f22091i;
        synchronized (kVar.f23541i) {
            try {
                nv.e eVar = (nv.e) kVar.f23542v;
                if (eVar != null) {
                    eVar.d(((Task) this.f22090e).f());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:346:0x05c4 A[SYNTHETIC] */
    /* JADX WARN: Code restructure failed: missing block: B:192:0x05cb, code lost:
    
        if (r3 == false) goto L370;
     */
    /* JADX WARN: Code restructure failed: missing block: B:197:0x05d4, code lost:
    
        r3 = r3 | java.lang.Thread.interrupted();
     */
    /* JADX WARN: Code restructure failed: missing block: B:198:0x05d5, code lost:
    
        ((java.lang.Runnable) r20.f22090e).run();
     */
    /* JADX WARN: Code restructure failed: missing block: B:199:0x05dc, code lost:
    
        r20.f22090e = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:203:0x05e2, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:205:0x05e4, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:207:0x05e6, code lost:
    
        r8 = com.google.android.gms.internal.fido.oe.f6883x.b();
        r9 = java.util.logging.Level.SEVERE;
        r0 = java.lang.String.valueOf((java.lang.Runnable) r20.f22090e);
        r5 = new java.lang.StringBuilder(r0.length() + 35);
        r5.append("Exception while executing runnable ");
        r5.append(r0);
        r8.logp(r9, "com.google.common.util.concurrent.SequentialExecutor$QueueWorker", "workOnQueue", r5.toString(), (java.lang.Throwable) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:208:0x0612, code lost:
    
        r20.f22090e = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:209:0x0615, code lost:
    
        r20.f22090e = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:210:0x0617, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:370:?, code lost:
    
        return;
     */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void run() {
        /*
            Method dump skipped, instruction units count: 2068
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: mx.u.run():void");
    }

    public String toString() {
        String str;
        switch (this.f22089d) {
            case 0:
                fb.l lVar = new fb.l(u.class.getSimpleName(), 20);
                t tVar = (t) this.f22091i;
                z5.u uVar = new z5.u();
                ((z5.u) lVar.f11667v).f37365e = uVar;
                lVar.f11667v = uVar;
                uVar.f37364d = tVar;
                return lVar.toString();
            case 5:
                Runnable runnable = (Runnable) this.f22090e;
                if (runnable != null) {
                    String string = runnable.toString();
                    return a1.h.l(new StringBuilder(string.length() + 34), "SequentialExecutorWorker{running=", string, "}");
                }
                int i11 = ((oe) this.f22091i).f6888w;
                if (i11 == 1) {
                    str = "IDLE";
                } else if (i11 == 2) {
                    str = "QUEUING";
                } else if (i11 != 3) {
                    str = i11 != 4 ? "null" : "RUNNING";
                } else {
                    str = "QUEUED";
                }
                return a1.h.l(new StringBuilder(str.length() + 32), "SequentialExecutorWorker{state=", str, "}");
            default:
                return super.toString();
        }
    }

    public /* synthetic */ u(td tdVar, int i11, ie ieVar) {
        this.f22089d = 4;
        this.f22090e = tdVar;
        this.f22091i = ieVar;
    }

    public /* synthetic */ u(Object obj, Object obj2, int i11, boolean z11) {
        this.f22089d = i11;
        this.f22091i = obj;
        this.f22090e = obj2;
    }

    public /* synthetic */ u(oe oeVar) {
        this.f22089d = 5;
        this.f22091i = oeVar;
    }

    public u(gu.j jVar, gu.c0 c0Var) {
        this.f22089d = 16;
        Objects.requireNonNull(jVar);
        this.f22091i = jVar;
        this.f22090e = c0Var;
    }
}
