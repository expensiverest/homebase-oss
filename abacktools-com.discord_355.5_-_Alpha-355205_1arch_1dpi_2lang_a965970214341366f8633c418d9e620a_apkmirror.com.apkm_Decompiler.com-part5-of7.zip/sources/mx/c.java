package mx;

import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes3.dex */
public final class c {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final c f22056d = new c();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Runnable f22057a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Executor f22058b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public c f22059c;

    public c(Runnable runnable, Executor executor) {
        this.f22057a = runnable;
        this.f22058b = executor;
    }

    public c() {
        this.f22057a = null;
        this.f22058b = null;
    }
}
