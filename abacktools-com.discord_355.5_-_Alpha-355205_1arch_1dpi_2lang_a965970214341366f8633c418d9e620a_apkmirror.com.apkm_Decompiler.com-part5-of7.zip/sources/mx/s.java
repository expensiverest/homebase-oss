package mx;

/* JADX INFO: loaded from: classes3.dex */
public abstract class s extends o implements g {
    @Override // mx.o, java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f22084d instanceof a;
    }
}
