package mx;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: loaded from: classes3.dex */
public final class d extends io.sentry.config.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f22060a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f22061b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f22062c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f22063d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f22064e;

    public d(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
        this.f22060a = atomicReferenceFieldUpdater;
        this.f22061b = atomicReferenceFieldUpdater2;
        this.f22062c = atomicReferenceFieldUpdater3;
        this.f22063d = atomicReferenceFieldUpdater4;
        this.f22064e = atomicReferenceFieldUpdater5;
    }

    @Override // io.sentry.config.a
    public final void M(n nVar, n nVar2) {
        this.f22061b.lazySet(nVar, nVar2);
    }

    @Override // io.sentry.config.a
    public final void N(n nVar, Thread thread) {
        this.f22060a.lazySet(nVar, thread);
    }

    @Override // io.sentry.config.a
    public final boolean e(o oVar, c cVar, c cVar2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f22063d;
            if (atomicReferenceFieldUpdater.compareAndSet(oVar, cVar, cVar2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(oVar) == cVar);
        return false;
    }

    @Override // io.sentry.config.a
    public final boolean f(o oVar, Object obj, Object obj2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f22064e;
            if (atomicReferenceFieldUpdater.compareAndSet(oVar, obj, obj2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(oVar) == obj);
        return false;
    }

    @Override // io.sentry.config.a
    public final boolean g(o oVar, n nVar, n nVar2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f22062c;
            if (atomicReferenceFieldUpdater.compareAndSet(oVar, nVar, nVar2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(oVar) == nVar);
        return false;
    }

    @Override // io.sentry.config.a
    public final c v(o oVar) {
        return (c) this.f22063d.getAndSet(oVar, c.f22056d);
    }

    @Override // io.sentry.config.a
    public final n w(o oVar) {
        return (n) this.f22062c.getAndSet(oVar, n.f22078c);
    }
}
