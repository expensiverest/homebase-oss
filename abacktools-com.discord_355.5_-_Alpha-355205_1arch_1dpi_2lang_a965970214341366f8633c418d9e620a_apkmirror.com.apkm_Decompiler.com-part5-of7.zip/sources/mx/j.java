package mx;

import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes3.dex */
public abstract /* synthetic */ class j {
    public static /* synthetic */ boolean a(Unsafe unsafe, o oVar, long j6, c cVar, c cVar2) {
        while (!unsafe.compareAndSwapObject(oVar, j6, cVar, cVar2)) {
            if (unsafe.getObject(oVar, j6) != cVar) {
                return false;
            }
        }
        return true;
    }
}
