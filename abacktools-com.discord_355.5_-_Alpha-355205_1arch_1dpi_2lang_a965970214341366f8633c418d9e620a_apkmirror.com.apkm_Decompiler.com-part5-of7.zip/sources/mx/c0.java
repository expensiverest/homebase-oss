package mx;

/* JADX INFO: loaded from: classes3.dex */
public final class c0 extends h implements Runnable {
    public final Runnable J;

    public c0(Runnable runnable) {
        runnable.getClass();
        this.J = runnable;
    }

    @Override // mx.o
    public final String k() {
        return "task=[" + this.J + "]";
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            this.J.run();
        } catch (Throwable th2) {
            n(th2);
            throw th2;
        }
    }
}
