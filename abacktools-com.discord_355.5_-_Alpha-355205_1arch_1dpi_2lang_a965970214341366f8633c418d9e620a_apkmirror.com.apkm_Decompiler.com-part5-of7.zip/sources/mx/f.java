package mx;

/* JADX INFO: loaded from: classes3.dex */
public final class f extends io.sentry.config.a {
    @Override // io.sentry.config.a
    public final void M(n nVar, n nVar2) {
        nVar.f22080b = nVar2;
    }

    @Override // io.sentry.config.a
    public final void N(n nVar, Thread thread) {
        nVar.f22079a = thread;
    }

    @Override // io.sentry.config.a
    public final boolean e(o oVar, c cVar, c cVar2) {
        synchronized (oVar) {
            try {
                if (oVar.f22085e != cVar) {
                    return false;
                }
                oVar.f22085e = cVar2;
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // io.sentry.config.a
    public final boolean f(o oVar, Object obj, Object obj2) {
        synchronized (oVar) {
            try {
                if (oVar.f22084d != obj) {
                    return false;
                }
                oVar.f22084d = obj2;
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // io.sentry.config.a
    public final boolean g(o oVar, n nVar, n nVar2) {
        synchronized (oVar) {
            try {
                if (oVar.f22086i != nVar) {
                    return false;
                }
                oVar.f22086i = nVar2;
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // io.sentry.config.a
    public final c v(o oVar) {
        c cVar;
        c cVar2 = c.f22056d;
        synchronized (oVar) {
            try {
                cVar = oVar.f22085e;
                if (cVar != cVar2) {
                    oVar.f22085e = cVar2;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return cVar;
    }

    @Override // io.sentry.config.a
    public final n w(o oVar) {
        n nVar;
        n nVar2 = n.f22078c;
        synchronized (oVar) {
            try {
                nVar = oVar.f22086i;
                if (nVar != nVar2) {
                    oVar.f22086i = nVar2;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return nVar;
    }
}
