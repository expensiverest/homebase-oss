package mq;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final d f21372d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final d f21373e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final d f21374i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ d[] f21375v;

    static {
        d dVar = new d("Unknown", 0);
        f21372d = dVar;
        d dVar2 = new d("Rendered", 1);
        f21373e = dVar2;
        d dVar3 = new d("None", 2);
        f21374i = dVar3;
        d[] dVarArr = {dVar, dVar2, dVar3};
        f21375v = dVarArr;
        oq.a.G(dVarArr);
    }

    public static d valueOf(String str) {
        return (d) Enum.valueOf(d.class, str);
    }

    public static d[] values() {
        return (d[]) f21375v.clone();
    }
}
