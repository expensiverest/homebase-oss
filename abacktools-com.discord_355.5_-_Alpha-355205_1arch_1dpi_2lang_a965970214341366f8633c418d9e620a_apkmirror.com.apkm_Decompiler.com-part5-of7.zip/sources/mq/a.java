package mq;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v1 mq.a[], still in use, count: 1, list:
  (r0v1 mq.a[]) from 0x0024: INVOKE (r0v1 mq.a[]) STATIC call: oq.a.G(java.lang.Enum[]):t30.a A[MD:(java.lang.Enum[]):t30.a (m)] (LINE:37)
	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:164)
	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:129)
	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:101)
	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:100)
	at jadx.core.utils.InsnRemover.removeAllAndUnbind(InsnRemover.java:257)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:187)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: loaded from: classes.dex */
public final class a {
    Visible(0),
    Prerender(1),
    Hidden(2);


    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21367d;

    static {
        oq.a.G(aVarArr);
    }

    public a(int i11) {
        super(str, i);
        this.f21367d = i11;
    }

    public static a valueOf(String str) {
        return (a) Enum.valueOf(a.class, str);
    }

    public static a[] values() {
        return (a[]) f21366w.clone();
    }
}
