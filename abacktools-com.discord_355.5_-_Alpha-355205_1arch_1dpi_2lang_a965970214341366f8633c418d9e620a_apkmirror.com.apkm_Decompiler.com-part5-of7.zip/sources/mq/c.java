package mq;

import android.graphics.Rect;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import g8.i0;
import kotlin.jvm.internal.k;
import qp.f;

/* JADX INFO: loaded from: classes.dex */
public final class c extends f {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final a f21368d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f21369e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final WritableMap f21370i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final WritableMap f21371v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(int i11, int i12, a aVar, Rect targetRect, Rect thresholdRect, boolean z11) {
        super(i11, i12);
        k.g(targetRect, "targetRect");
        k.g(thresholdRect, "thresholdRect");
        this.f21368d = aVar;
        this.f21369e = z11;
        this.f21370i = i0.b(targetRect);
        this.f21371v = i0.b(thresholdRect);
    }

    @Override // qp.f
    public final boolean experimental_isSynchronous() {
        return this.f21369e;
    }

    @Override // qp.f
    public final WritableMap getEventData() {
        WritableMap writableMapCreateMap = Arguments.createMap();
        writableMapCreateMap.putInt("mode", this.f21368d.f21367d);
        writableMapCreateMap.putMap("targetRect", this.f21370i);
        writableMapCreateMap.putMap("thresholdRect", this.f21371v);
        return writableMapCreateMap;
    }

    @Override // qp.f
    public final String getEventName() {
        return "modeChange";
    }
}
