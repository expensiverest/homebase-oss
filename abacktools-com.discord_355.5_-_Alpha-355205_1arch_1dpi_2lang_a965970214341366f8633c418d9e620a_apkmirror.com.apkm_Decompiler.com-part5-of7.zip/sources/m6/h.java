package m6;

import android.database.sqlite.SQLiteProgram;
import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes.dex */
public class h implements l6.c {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final SQLiteProgram f21200d;

    public h(SQLiteProgram delegate) {
        k.g(delegate, "delegate");
        this.f21200d = delegate;
    }

    @Override // l6.c
    public final void D(int i11, long j6) {
        this.f21200d.bindLong(i11, j6);
    }

    @Override // l6.c
    public final void K(byte[] bArr, int i11) {
        this.f21200d.bindBlob(i11, bArr);
    }

    @Override // l6.c
    public final void V(int i11) {
        this.f21200d.bindNull(i11);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.f21200d.close();
    }

    @Override // l6.c
    public final void q(int i11, String value) {
        k.g(value, "value");
        this.f21200d.bindString(i11, value);
    }

    @Override // l6.c
    public final void w(int i11, double d11) {
        this.f21200d.bindDouble(i11, d11);
    }
}
