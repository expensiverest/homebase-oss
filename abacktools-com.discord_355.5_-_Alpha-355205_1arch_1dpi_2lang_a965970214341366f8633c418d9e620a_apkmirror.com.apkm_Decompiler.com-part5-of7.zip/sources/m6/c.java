package m6;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteStatement;
import java.io.Closeable;
import java.util.List;
import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes.dex */
public final class c implements Closeable {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final String[] f21180i = {"", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE "};

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String[] f21181v = new String[0];

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final SQLiteDatabase f21182d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f21183e;

    public c(SQLiteDatabase sQLiteDatabase) {
        this.f21182d = sQLiteDatabase;
        this.f21183e = sQLiteDatabase.getAttachedDbs();
    }

    public final void A() {
        this.f21182d.setTransactionSuccessful();
    }

    public final void c() {
        this.f21182d.beginTransaction();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.f21182d.close();
    }

    public final void d() {
        this.f21182d.beginTransactionNonExclusive();
    }

    public final i g(String str) {
        SQLiteStatement sQLiteStatementCompileStatement = this.f21182d.compileStatement(str);
        k.f(sQLiteStatementCompileStatement, "delegate.compileStatement(sql)");
        return new i(sQLiteStatementCompileStatement);
    }

    public final void i() {
        this.f21182d.endTransaction();
    }

    public final void j(String sql) {
        k.g(sql, "sql");
        this.f21182d.execSQL(sql);
    }

    public final void l(Object[] objArr) {
        this.f21182d.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", objArr);
    }

    public final boolean n() {
        return this.f21182d.inTransaction();
    }

    public final boolean u() {
        SQLiteDatabase sQLiteDatabase = this.f21182d;
        k.g(sQLiteDatabase, "sQLiteDatabase");
        return sQLiteDatabase.isWriteAheadLoggingEnabled();
    }

    public final Cursor x(String query) {
        k.g(query, "query");
        return z(new dx.e(query, 3, false));
    }

    public final Cursor z(l6.d dVar) {
        final b bVar = new b(dVar);
        Cursor cursorRawQueryWithFactory = this.f21182d.rawQueryWithFactory(new SQLiteDatabase.CursorFactory() { // from class: m6.a
            @Override // android.database.sqlite.SQLiteDatabase.CursorFactory
            public final Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
                return (Cursor) bVar.b(sQLiteDatabase, sQLiteCursorDriver, str, sQLiteQuery);
            }
        }, dVar.c(), f21181v, null);
        k.f(cursorRawQueryWithFactory, "delegate.rawQueryWithFac…EMPTY_STRING_ARRAY, null)");
        return cursorRawQueryWithFactory;
    }
}
