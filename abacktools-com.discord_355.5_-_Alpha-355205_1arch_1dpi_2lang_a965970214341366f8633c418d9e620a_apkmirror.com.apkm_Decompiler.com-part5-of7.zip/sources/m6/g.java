package m6;

import android.content.Context;
import b80.v;
import com.google.android.gms.internal.fido.f8;
import kotlin.jvm.internal.k;
import l30.o;
import l30.x;

/* JADX INFO: loaded from: classes.dex */
public final class g implements l6.b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Context f21194d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21195e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final f8 f21196i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f21197v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f21198w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final o f21199x;
    public boolean y;

    public g(Context context, String str, f8 callback, boolean z11, boolean z12) {
        k.g(callback, "callback");
        this.f21194d = context;
        this.f21195e = str;
        this.f21196i = callback;
        this.f21197v = z11;
        this.f21198w = z12;
        this.f21199x = a.a.K(new v(8, this));
    }

    @Override // l6.b
    public final c I() {
        return ((f) this.f21199x.getValue()).c(true);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.f21199x.f19990e != x.f20001a) {
            ((f) this.f21199x.getValue()).close();
        }
    }

    @Override // l6.b
    public final void setWriteAheadLoggingEnabled(boolean z11) {
        if (this.f21199x.f19990e != x.f20001a) {
            f sQLiteOpenHelper = (f) this.f21199x.getValue();
            k.g(sQLiteOpenHelper, "sQLiteOpenHelper");
            sQLiteOpenHelper.setWriteAheadLoggingEnabled(z11);
        }
        this.y = z11;
    }
}
