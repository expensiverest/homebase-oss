package m6;

import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteQuery;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;

/* JADX INFO: loaded from: classes.dex */
public final class b extends l implements a40.b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ l6.d f21179d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(l6.d dVar) {
        super(4);
        this.f21179d = dVar;
    }

    @Override // a40.b
    public final Object b(Object obj, Object obj2, Object obj3, Object obj4) {
        SQLiteQuery sQLiteQuery = (SQLiteQuery) obj4;
        k.d(sQLiteQuery);
        this.f21179d.d(new h(sQLiteQuery));
        return new SQLiteCursor((SQLiteCursorDriver) obj2, (String) obj3, sQLiteQuery);
    }
}
