package m6;

import hs.q;

/* JADX INFO: loaded from: classes.dex */
public final class e extends RuntimeException {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21186d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Throwable f21187e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(int i11, Throwable th2) {
        super(th2);
        q.q(i11, "callbackName");
        this.f21186d = i11;
        this.f21187e = th2;
    }

    @Override // java.lang.Throwable
    public final Throwable getCause() {
        return this.f21187e;
    }
}
