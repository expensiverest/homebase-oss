package m6;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.util.Pair;
import c7.t;
import com.google.android.gms.internal.fido.f8;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes.dex */
public final class f extends SQLiteOpenHelper {
    public static final /* synthetic */ int J = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Context f21188d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final bu.i f21189e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final f8 f21190i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f21191v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f21192w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final n6.a f21193x;
    public boolean y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(Context context, String str, final bu.i iVar, final f8 callback, boolean z11) {
        String string;
        super(context, str, null, callback.f6587i, new DatabaseErrorHandler() { // from class: m6.d
            @Override // android.database.DatabaseErrorHandler
            public final void onCorruption(SQLiteDatabase dbObj) {
                f8 callback2 = callback;
                k.g(callback2, "$callback");
                int i11 = f.J;
                k.f(dbObj, "dbObj");
                c cVarX = t.x(iVar, dbObj);
                Log.e("SupportSQLite", "Corruption reported by sqlite on database: " + cVarX + ".path");
                SQLiteDatabase sQLiteDatabase = cVarX.f21182d;
                if (!sQLiteDatabase.isOpen()) {
                    String path = sQLiteDatabase.getPath();
                    if (path != null) {
                        f8.h(path);
                        return;
                    }
                    return;
                }
                List list = null;
                try {
                    try {
                        list = cVarX.f21183e;
                    } finally {
                        if (list != null) {
                            Iterator it = list.iterator();
                            while (it.hasNext()) {
                                Object obj = ((Pair) it.next()).second;
                                k.f(obj, "p.second");
                                f8.h((String) obj);
                            }
                        } else {
                            String path2 = sQLiteDatabase.getPath();
                            if (path2 != null) {
                                f8.h(path2);
                            }
                        }
                    }
                } catch (SQLiteException unused) {
                }
                try {
                    cVarX.close();
                } catch (IOException unused2) {
                }
                if (list != null) {
                    return;
                }
            }
        });
        k.g(callback, "callback");
        this.f21188d = context;
        this.f21189e = iVar;
        this.f21190i = callback;
        this.f21191v = z11;
        if (str == null) {
            string = UUID.randomUUID().toString();
            k.f(string, "randomUUID().toString()");
        } else {
            string = str;
        }
        File cacheDir = context.getCacheDir();
        k.f(cacheDir, "context.cacheDir");
        this.f21193x = new n6.a(string, cacheDir, false);
    }

    public final c c(boolean z11) {
        n6.a aVar = this.f21193x;
        try {
            aVar.a((this.y || getDatabaseName() == null) ? false : true);
            this.f21192w = false;
            SQLiteDatabase sQLiteDatabaseG = g(z11);
            if (!this.f21192w) {
                return t.x(this.f21189e, sQLiteDatabaseG);
            }
            close();
            return c(z11);
        } finally {
            aVar.b();
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper, java.lang.AutoCloseable
    public final void close() {
        n6.a aVar = this.f21193x;
        try {
            aVar.a(aVar.f22654a);
            super.close();
            this.f21189e.f4200e = null;
            this.y = false;
        } finally {
            aVar.b();
        }
    }

    public final SQLiteDatabase d(boolean z11) {
        if (z11) {
            SQLiteDatabase writableDatabase = getWritableDatabase();
            k.f(writableDatabase, "{\n                super.…eDatabase()\n            }");
            return writableDatabase;
        }
        SQLiteDatabase readableDatabase = getReadableDatabase();
        k.f(readableDatabase, "{\n                super.…eDatabase()\n            }");
        return readableDatabase;
    }

    public final SQLiteDatabase g(boolean z11) throws Throwable {
        File parentFile;
        String databaseName = getDatabaseName();
        Context context = this.f21188d;
        if (databaseName != null && (parentFile = context.getDatabasePath(databaseName).getParentFile()) != null) {
            parentFile.mkdirs();
            if (!parentFile.isDirectory()) {
                Log.w("SupportSQLite", "Invalid database parent file, not a directory: " + parentFile);
            }
        }
        try {
            return d(z11);
        } catch (Throwable unused) {
            super.close();
            try {
                Thread.sleep(500L);
            } catch (InterruptedException unused2) {
            }
            try {
                return d(z11);
            } catch (Throwable th2) {
                super.close();
                if (th2 instanceof e) {
                    e eVar = th2;
                    int iD = v0.d.d(eVar.f21186d);
                    Throwable th3 = eVar.f21187e;
                    if (iD == 0 || iD == 1 || iD == 2 || iD == 3 || !(th3 instanceof SQLiteException)) {
                        throw th3;
                    }
                } else if (!(th2 instanceof SQLiteException) || databaseName == null || !this.f21191v) {
                    throw th2;
                }
                context.deleteDatabase(databaseName);
                try {
                    return d(z11);
                } catch (e e4) {
                    throw e4.f21187e;
                }
            }
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public final void onConfigure(SQLiteDatabase db2) {
        k.g(db2, "db");
        try {
            f8 f8Var = this.f21190i;
            t.x(this.f21189e, db2);
            f8Var.getClass();
        } catch (Throwable th2) {
            throw new e(1, th2);
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public final void onCreate(SQLiteDatabase sqLiteDatabase) {
        k.g(sqLiteDatabase, "sqLiteDatabase");
        try {
            this.f21190i.N(t.x(this.f21189e, sqLiteDatabase));
        } catch (Throwable th2) {
            throw new e(2, th2);
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public final void onDowngrade(SQLiteDatabase db2, int i11, int i12) {
        k.g(db2, "db");
        this.f21192w = true;
        try {
            this.f21190i.P(t.x(this.f21189e, db2), i11, i12);
        } catch (Throwable th2) {
            throw new e(4, th2);
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public final void onOpen(SQLiteDatabase db2) {
        k.g(db2, "db");
        if (!this.f21192w) {
            try {
                this.f21190i.O(t.x(this.f21189e, db2));
            } catch (Throwable th2) {
                throw new e(5, th2);
            }
        }
        this.y = true;
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public final void onUpgrade(SQLiteDatabase sqLiteDatabase, int i11, int i12) {
        k.g(sqLiteDatabase, "sqLiteDatabase");
        this.f21192w = true;
        try {
            this.f21190i.P(t.x(this.f21189e, sqLiteDatabase), i11, i12);
        } catch (Throwable th2) {
            throw new e(3, th2);
        }
    }
}
