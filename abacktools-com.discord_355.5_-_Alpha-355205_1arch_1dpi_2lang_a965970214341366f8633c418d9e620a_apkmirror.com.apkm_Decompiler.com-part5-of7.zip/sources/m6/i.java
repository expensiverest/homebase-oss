package m6;

import android.database.sqlite.SQLiteStatement;

/* JADX INFO: loaded from: classes.dex */
public final class i extends h implements l6.c {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final SQLiteStatement f21201e;

    public i(SQLiteStatement sQLiteStatement) {
        super(sQLiteStatement);
        this.f21201e = sQLiteStatement;
    }

    public final int c() {
        return this.f21201e.executeUpdateDelete();
    }
}
