package m8;

import zm.f;

/* JADX INFO: loaded from: classes.dex */
public interface a {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final f f21272s = new f(14);

    void q();
}
