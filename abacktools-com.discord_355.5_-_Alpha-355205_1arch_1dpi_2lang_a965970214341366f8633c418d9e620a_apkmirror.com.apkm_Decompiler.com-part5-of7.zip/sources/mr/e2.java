package mr;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class e2 extends z1 {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final String f21439w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f21440x;
    public static final d2 y;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21441i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final float f21442v;

    static {
        int i11 = qt.x.f27318a;
        f21439w = Integer.toString(1, 36);
        f21440x = Integer.toString(2, 36);
        y = new d2(0);
    }

    public e2(float f3, int i11) {
        boolean z11 = false;
        qt.a.f("maxStars must be a positive integer", i11 > 0);
        if (f3 >= 0.0f && f3 <= i11) {
            z11 = true;
        }
        qt.a.f("starRating is out of range [0, maxStars]", z11);
        this.f21441i = i11;
        this.f21442v = f3;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof e2)) {
            return false;
        }
        e2 e2Var = (e2) obj;
        return this.f21441i == e2Var.f21441i && this.f21442v == e2Var.f21442v;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f21441i), Float.valueOf(this.f21442v)});
    }

    public e2(int i11) {
        qt.a.f("maxStars must be a positive integer", i11 > 0);
        this.f21441i = i11;
        this.f21442v = -1.0f;
    }
}
