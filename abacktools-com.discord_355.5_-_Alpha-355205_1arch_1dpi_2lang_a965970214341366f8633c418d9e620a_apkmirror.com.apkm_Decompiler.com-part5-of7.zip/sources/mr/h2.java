package mr;

import com.facebook.imageutils.JfifUtil;

/* JADX INFO: loaded from: classes3.dex */
public final class h2 implements e {
    public static final String J;
    public static final String K;
    public static final String L;
    public static final String M;
    public static final String N;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f21535d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f21536e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f21537i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f21538v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f21539w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f21540x;
    public ts.b y = ts.b.f30643x;

    static {
        int i11 = qt.x.f27318a;
        J = Integer.toString(0, 36);
        K = Integer.toString(1, 36);
        L = Integer.toString(2, 36);
        M = Integer.toString(3, 36);
        N = Integer.toString(4, 36);
    }

    public final long a(int i11, int i12) {
        ts.a aVarA = this.y.a(i11);
        if (aVarA.f30638e != -1) {
            return aVarA.f30642x[i12];
        }
        return -9223372036854775807L;
    }

    public final int b(long j6) {
        ts.a aVarA;
        int i11;
        ts.b bVar = this.y;
        long j11 = this.f21538v;
        int i12 = bVar.f30644d;
        if (j6 != Long.MIN_VALUE && (j11 == -9223372036854775807L || j6 < j11)) {
            int i13 = bVar.f30647v;
            while (i13 < i12 && ((bVar.a(i13).f30637d != Long.MIN_VALUE && bVar.a(i13).f30637d <= j6) || ((i11 = (aVarA = bVar.a(i13)).f30638e) != -1 && aVarA.a(-1) >= i11))) {
                i13++;
            }
            if (i13 < i12) {
                return i13;
            }
        }
        return -1;
    }

    public final int c(long j6) {
        ts.b bVar = this.y;
        long j11 = this.f21538v;
        int i11 = bVar.f30644d - 1;
        int i12 = i11 - (bVar.b(i11) ? 1 : 0);
        while (i12 >= 0 && j6 != Long.MIN_VALUE) {
            ts.a aVarA = bVar.a(i12);
            long j12 = aVarA.f30637d;
            if (j12 != Long.MIN_VALUE) {
                if (j6 >= j12) {
                    break;
                }
                i12--;
            } else {
                if (j11 != -9223372036854775807L && ((!aVarA.J || aVarA.f30638e != -1) && j6 >= j11)) {
                    break;
                }
                i12--;
            }
        }
        if (i12 >= 0) {
            ts.a aVarA2 = bVar.a(i12);
            int i13 = aVarA2.f30638e;
            if (i13 != -1) {
                for (int i14 = 0; i14 < i13; i14++) {
                    int i15 = aVarA2.f30641w[i14];
                    if (i15 != 0 && i15 != 1) {
                    }
                }
            }
            return i12;
        }
        return -1;
    }

    public final long d(int i11) {
        return this.y.a(i11).f30637d;
    }

    public final int e(int i11, int i12) {
        ts.a aVarA = this.y.a(i11);
        if (aVarA.f30638e != -1) {
            return aVarA.f30641w[i12];
        }
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && h2.class.equals(obj.getClass())) {
            h2 h2Var = (h2) obj;
            if (qt.x.a(this.f21535d, h2Var.f21535d) && qt.x.a(this.f21536e, h2Var.f21536e) && this.f21537i == h2Var.f21537i && this.f21538v == h2Var.f21538v && this.f21539w == h2Var.f21539w && this.f21540x == h2Var.f21540x && qt.x.a(this.y, h2Var.y)) {
                return true;
            }
        }
        return false;
    }

    public final int f(int i11) {
        return this.y.a(i11).a(-1);
    }

    public final boolean g(int i11) {
        ts.b bVar = this.y;
        return i11 == bVar.f30644d - 1 && bVar.b(i11);
    }

    public final boolean h(int i11) {
        return this.y.a(i11).J;
    }

    public final int hashCode() {
        Object obj = this.f21535d;
        int iHashCode = (JfifUtil.MARKER_EOI + (obj == null ? 0 : obj.hashCode())) * 31;
        Object obj2 = this.f21536e;
        int iHashCode2 = (((iHashCode + (obj2 != null ? obj2.hashCode() : 0)) * 31) + this.f21537i) * 31;
        long j6 = this.f21538v;
        int i11 = (iHashCode2 + ((int) (j6 ^ (j6 >>> 32)))) * 31;
        long j11 = this.f21539w;
        return this.y.hashCode() + ((((i11 + ((int) (j11 ^ (j11 >>> 32)))) * 31) + (this.f21540x ? 1 : 0)) * 31);
    }

    public final void i(Object obj, Object obj2, int i11, long j6, long j11, ts.b bVar, boolean z11) {
        this.f21535d = obj;
        this.f21536e = obj2;
        this.f21537i = i11;
        this.f21538v = j6;
        this.f21539w = j11;
        this.y = bVar;
        this.f21540x = z11;
    }
}
