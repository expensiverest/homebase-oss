package mr;

/* JADX INFO: loaded from: classes3.dex */
public abstract class c implements v1 {
    public ss.m0 J;
    public i0[] K;
    public long L;
    public boolean N;
    public boolean O;
    public mt.o P;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21406e;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public a2 f21408v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f21409w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public nr.p f21410x;
    public int y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f21405d = new Object();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final k7.c f21407i = new k7.c(22, false);
    public long M = Long.MIN_VALUE;

    public c(int i11) {
        this.f21406e = i11;
    }

    public static int d(int i11, int i12, int i13) {
        return i11 | i12 | i13 | 128;
    }

    public final j f(Exception exc, i0 i0Var, boolean z11, int i11) {
        int iY;
        if (i0Var == null || this.O) {
            iY = 4;
        } else {
            this.O = true;
            try {
                iY = y(i0Var) & 7;
                this.O = false;
            } catch (j unused) {
                this.O = false;
                iY = 4;
            } catch (Throwable th2) {
                this.O = false;
                throw th2;
            }
        }
        return new j(1, exc, i11, h(), this.f21409w, i0Var, i0Var == null ? 4 : iY, z11);
    }

    public qt.j g() {
        return null;
    }

    public abstract String h();

    public final boolean i() {
        return this.M == Long.MIN_VALUE;
    }

    public abstract boolean j();

    public abstract boolean k();

    public abstract void l();

    public abstract void n(long j6, boolean z11);

    public abstract void s(i0[] i0VarArr, long j6, long j11);

    public final int t(k7.c cVar, rr.f fVar, int i11) {
        ss.m0 m0Var = this.J;
        m0Var.getClass();
        int iD = m0Var.d(cVar, fVar, i11);
        if (iD == -4) {
            if (fVar.g(4)) {
                this.M = Long.MIN_VALUE;
                return this.N ? -4 : -3;
            }
            long j6 = fVar.f28408x + this.L;
            fVar.f28408x = j6;
            this.M = Math.max(this.M, j6);
            return iD;
        }
        if (iD == -5) {
            i0 i0Var = (i0) cVar.f19322i;
            i0Var.getClass();
            long j11 = i0Var.R;
            if (j11 != Long.MAX_VALUE) {
                h0 h0VarA = i0Var.a();
                h0VarA.f21521o = j11 + this.L;
                cVar.f19322i = new i0(h0VarA);
            }
        }
        return iD;
    }

    public abstract void u(long j6, long j11);

    public final void v(i0[] i0VarArr, ss.m0 m0Var, long j6, long j11) {
        qt.a.k(!this.N);
        this.J = m0Var;
        if (this.M == Long.MIN_VALUE) {
            this.M = j6;
        }
        this.K = i0VarArr;
        this.L = j11;
        s(i0VarArr, j6, j11);
    }

    public final void w() {
        qt.a.k(this.y == 0);
        this.f21407i.b();
        p();
    }

    public abstract int y(i0 i0Var);

    public int z() {
        return 0;
    }

    public void o() {
    }

    public void p() {
    }

    public void q() {
    }

    public void r() {
    }

    @Override // mr.v1
    public void c(int i11, Object obj) {
    }

    public void m(boolean z11, boolean z12) {
    }

    public void x(float f3, float f11) {
    }
}
