package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ f0 f21379a;

    public a0(f0 f0Var) {
        this.f21379a = f0Var;
    }
}
