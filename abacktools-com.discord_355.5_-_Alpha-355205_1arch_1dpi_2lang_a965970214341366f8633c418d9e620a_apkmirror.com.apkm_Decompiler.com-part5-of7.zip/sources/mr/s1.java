package mr;

import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public interface s1 {
    default void i() {
    }

    default void B(m1 m1Var) {
    }

    default void C(int i11) {
    }

    default void F(q1 q1Var) {
    }

    default void H(r1 r1Var) {
    }

    default void I(bt.c cVar) {
    }

    default void L(o1 o1Var) {
    }

    default void a(int i11) {
    }

    default void b(rt.s sVar) {
    }

    default void c(int i11) {
    }

    default void d(boolean z11) {
    }

    default void f(float f3) {
    }

    default void g(int i11) {
    }

    default void h(boolean z11) {
    }

    default void j(boolean z11) {
    }

    default void k(List list) {
    }

    default void m(m1 m1Var) {
    }

    default void o(boolean z11) {
    }

    default void u(is.c cVar) {
    }

    default void w(x0 x0Var) {
    }

    default void x(l2 l2Var) {
    }

    default void D(v0 v0Var, int i11) {
    }

    default void e(int i11, boolean z11) {
    }

    default void l(int i11, boolean z11) {
    }

    default void n(int i11, int i12) {
    }

    default void K(t1 t1Var, t1 t1Var2, int i11) {
    }
}
