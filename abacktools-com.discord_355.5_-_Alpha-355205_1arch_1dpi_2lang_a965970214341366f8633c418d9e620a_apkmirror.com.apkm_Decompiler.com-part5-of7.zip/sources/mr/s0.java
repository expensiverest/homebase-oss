package mr;

import android.net.Uri;

/* JADX INFO: loaded from: classes3.dex */
public final class s0 implements e {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final s0 f21725i = new s0(new k7.e((char) 0, 22));

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String f21726v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final String f21727w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f21728x;
    public static final mp.a y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Uri f21729d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21730e;

    static {
        int i11 = qt.x.f27318a;
        f21726v = Integer.toString(0, 36);
        f21727w = Integer.toString(1, 36);
        f21728x = Integer.toString(2, 36);
        y = new mp.a(25);
    }

    public s0(k7.e eVar) {
        this.f21729d = (Uri) eVar.f19326e;
        this.f21730e = (String) eVar.f19327i;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s0)) {
            return false;
        }
        s0 s0Var = (s0) obj;
        return qt.x.a(this.f21729d, s0Var.f21729d) && qt.x.a(this.f21730e, s0Var.f21730e);
    }

    public final int hashCode() {
        Uri uri = this.f21729d;
        int iHashCode = (uri == null ? 0 : uri.hashCode()) * 31;
        String str = this.f21730e;
        return iHashCode + (str != null ? str.hashCode() : 0);
    }
}
