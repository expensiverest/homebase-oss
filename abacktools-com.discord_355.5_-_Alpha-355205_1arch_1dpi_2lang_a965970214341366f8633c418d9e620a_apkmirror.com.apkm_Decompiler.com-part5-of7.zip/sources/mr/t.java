package mr;

import android.content.Context;
import android.media.metrics.LogSessionId;
import android.media.metrics.MediaMetricsManager;

/* JADX INFO: loaded from: classes3.dex */
public abstract class t {
    public static nr.p a(Context context, z zVar, boolean z11) {
        MediaMetricsManager mediaMetricsManagerB = w3.c.b(context.getSystemService("media_metrics"));
        nr.j jVar = mediaMetricsManagerB == null ? null : new nr.j(context, mediaMetricsManagerB.createPlaybackSession());
        if (jVar == null) {
            qt.a.N("ExoPlayerImpl", "MediaMetricsService unavailable.");
            return new nr.p(LogSessionId.LOG_SESSION_ID_NONE);
        }
        if (z11) {
            nr.g gVar = zVar.T;
            gVar.getClass();
            gVar.f23295x.a(jVar);
        }
        return new nr.p(jVar.f23314c.getSessionId());
    }
}
