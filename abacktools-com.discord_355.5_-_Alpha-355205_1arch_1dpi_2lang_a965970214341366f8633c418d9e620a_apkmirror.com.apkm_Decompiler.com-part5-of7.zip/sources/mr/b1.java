package mr;

/* JADX INFO: loaded from: classes3.dex */
public interface b1 {
    Object a();

    j2 b();
}
