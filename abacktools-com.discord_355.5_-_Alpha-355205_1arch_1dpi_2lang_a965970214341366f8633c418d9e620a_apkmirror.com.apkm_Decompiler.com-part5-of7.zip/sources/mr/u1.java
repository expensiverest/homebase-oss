package mr;

import android.os.Looper;
import android.view.SurfaceView;
import android.view.TextureView;

/* JADX INFO: loaded from: classes3.dex */
public interface u1 {
    j C1();

    void F(boolean z11);

    long G();

    long H();

    int I();

    l2 J();

    bt.c L();

    int O();

    int P();

    void Q(int i11);

    void R(SurfaceView surfaceView);

    void R0(s1 s1Var);

    int S();

    int T();

    j2 U();

    Looper V();

    boolean W();

    long X();

    void Y(TextureView textureView);

    x0 Z();

    void b();

    long b0();

    long c0();

    o1 e();

    void f0(s1 s1Var);

    long getDuration();

    boolean l();

    long m();

    q1 n();

    boolean o();

    void q(boolean z11);

    void s();

    int t();

    void u(TextureView textureView);

    rt.s v();

    int x();

    void y(SurfaceView surfaceView);
}
