package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class b2 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final b2 f21402c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f21403a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f21404b;

    static {
        b2 b2Var = new b2(0L, 0L);
        new b2(Long.MAX_VALUE, Long.MAX_VALUE);
        new b2(Long.MAX_VALUE, 0L);
        new b2(0L, Long.MAX_VALUE);
        f21402c = b2Var;
    }

    public b2(long j6, long j11) {
        qt.a.g(j6 >= 0);
        qt.a.g(j11 >= 0);
        this.f21403a = j6;
        this.f21404b = j11;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x005d A[RETURN] */
    public final long a(long j6, long j11, long j12) {
        long j13 = this.f21403a;
        long j14 = this.f21404b;
        if (j13 == 0 && j14 == 0) {
            return j6;
        }
        int i11 = qt.x.f27318a;
        long j15 = j6 - j13;
        if (((j13 ^ j6) & (j6 ^ j15)) < 0) {
            j15 = Long.MIN_VALUE;
        }
        long j16 = j6 + j14;
        if (((j14 ^ j16) & (j6 ^ j16)) < 0) {
            j16 = Long.MAX_VALUE;
        }
        boolean z11 = false;
        boolean z12 = j15 <= j11 && j11 <= j16;
        if (j15 <= j12 && j12 <= j16) {
            z11 = true;
        }
        if (z12 && z11) {
            if (Math.abs(j11 - j6) <= Math.abs(j12 - j6)) {
                return j11;
            }
            return j12;
        }
        if (!z12) {
            if (z11) {
                return j12;
            }
            return j15;
        }
        return j11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && b2.class == obj.getClass()) {
            b2 b2Var = (b2) obj;
            if (this.f21403a == b2Var.f21403a && this.f21404b == b2Var.f21404b) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return (((int) this.f21403a) * 31) + ((int) this.f21404b);
    }
}
