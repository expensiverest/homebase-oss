package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f21655a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f21656b = Long.MIN_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f21657c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f21658d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f21659e;
}
