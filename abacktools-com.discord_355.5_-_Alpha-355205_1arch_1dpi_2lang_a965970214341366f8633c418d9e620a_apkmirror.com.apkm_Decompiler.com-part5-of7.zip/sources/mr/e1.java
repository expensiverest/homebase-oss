package mr;

import android.util.Pair;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class e1 implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21436d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ k7.l f21437e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Pair f21438i;

    public /* synthetic */ e1(k7.l lVar, Pair pair, int i11) {
        this.f21436d = i11;
        this.f21437e = lVar;
        this.f21438i = pair;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f21436d) {
            case 0:
                nr.g gVar = (nr.g) ((j1) this.f21437e.f19343e).f21613j;
                Pair pair = this.f21438i;
                gVar.y(((Integer) pair.first).intValue(), (ss.s) pair.second);
                break;
            case 1:
                nr.g gVar2 = (nr.g) ((j1) this.f21437e.f19343e).f21613j;
                Pair pair2 = this.f21438i;
                gVar2.p(((Integer) pair2.first).intValue(), (ss.s) pair2.second);
                break;
            default:
                nr.g gVar3 = (nr.g) ((j1) this.f21437e.f19343e).f21613j;
                Pair pair3 = this.f21438i;
                gVar3.z(((Integer) pair3.first).intValue(), (ss.s) pair3.second);
                break;
        }
    }
}
