package mr;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class f2 extends z1 {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final String f21475w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f21476x;
    public static final d2 y;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f21477i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f21478v;

    static {
        int i11 = qt.x.f27318a;
        f21475w = Integer.toString(1, 36);
        f21476x = Integer.toString(2, 36);
        y = new d2(1);
    }

    public f2() {
        this.f21477i = false;
        this.f21478v = false;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof f2)) {
            return false;
        }
        f2 f2Var = (f2) obj;
        return this.f21478v == f2Var.f21478v && this.f21477i == f2Var.f21477i;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Boolean.valueOf(this.f21477i), Boolean.valueOf(this.f21478v)});
    }

    public f2(boolean z11) {
        this.f21477i = true;
        this.f21478v = z11;
    }
}
