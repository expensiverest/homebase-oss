package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class l2 implements e {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final l2 f21651e;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final hx.m0 f21652d;

    static {
        hx.k0 k0Var = hx.m0.f14841e;
        f21651e = new l2(hx.w1.f14911w);
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
    }

    public l2(hx.w1 w1Var) {
        this.f21652d = hx.m0.q(w1Var);
    }

    public final boolean a(int i11) {
        int i12 = 0;
        while (true) {
            hx.m0 m0Var = this.f21652d;
            if (i12 >= m0Var.size()) {
                return false;
            }
            k2 k2Var = (k2) m0Var.get(i12);
            for (boolean z11 : k2Var.f21641w) {
                if (z11) {
                    if (k2Var.f21638e.f29351i != i11) {
                        break;
                    }
                    return true;
                }
            }
            i12++;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || l2.class != obj.getClass()) {
            return false;
        }
        return this.f21652d.equals(((l2) obj).f21652d);
    }

    public final int hashCode() {
        return this.f21652d.hashCode();
    }
}
