package mr;

import android.util.Pair;
import com.google.android.gms.internal.fido.f8;
import java.io.IOException;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class g1 implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21494d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f21495e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f21496i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ IOException f21497v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ boolean f21498w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ Object f21499x;
    public final /* synthetic */ Object y;

    public /* synthetic */ g1(Object obj, Object obj2, Object obj3, Object obj4, IOException iOException, boolean z11, int i11) {
        this.f21494d = i11;
        this.f21499x = obj;
        this.y = obj2;
        this.f21495e = obj3;
        this.f21496i = obj4;
        this.f21497v = iOException;
        this.f21498w = z11;
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object, ss.w] */
    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f21494d) {
            case 0:
                k7.l lVar = (k7.l) this.f21499x;
                Pair pair = (Pair) this.y;
                ((nr.g) ((j1) lVar.f19343e).f21613j).q(((Integer) pair.first).intValue(), (ss.s) pair.second, (ss.k) this.f21495e, (f4.z) this.f21496i, this.f21497v, this.f21498w);
                break;
            case 1:
                f8 f8Var = (f8) this.f21499x;
                ss.k kVar = (ss.k) this.f21495e;
                f4.z zVar = (f4.z) this.f21496i;
                this.y.q(f8Var.f6587i, (ss.s) f8Var.f6586e, kVar, zVar, this.f21497v, this.f21498w);
                break;
            default:
                v3.u0 u0Var = (v3.u0) this.f21499x;
                Pair pair2 = (Pair) this.y;
                ((w3.e) u0Var.f32112e.k).s(((Integer) pair2.first).intValue(), (f4.d0) pair2.second, (f4.u) this.f21495e, (f4.z) this.f21496i, this.f21497v, this.f21498w);
                break;
        }
    }
}
