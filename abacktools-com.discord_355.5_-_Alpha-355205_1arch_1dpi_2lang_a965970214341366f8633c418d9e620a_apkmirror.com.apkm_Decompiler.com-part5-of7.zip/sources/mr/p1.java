package mr;

import android.content.Context;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Handler;
import android.os.Parcel;
import android.os.SystemClock;
import android.util.SparseArray;
import android.view.MenuItem;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import com.discord.age_assurance.DigitalCredentialModule;
import com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider;
import com.reactnativecommunity.webview.RNCWebViewManager;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import p.g3;
import p.k3;

/* JADX INFO: loaded from: classes3.dex */
public final class p1 implements p.d2, ReactNativeFeatureFlagsProvider, o.i, t60.a, oz.d, sw.b, l5.m, ot.f0, ww.h, w2.g, y1.h, gu.h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21701d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f21702e;

    public /* synthetic */ p1(int i11, Object obj) {
        this.f21701d = i11;
        this.f21702e = obj;
    }

    public static void r(StringBuilder sb2, char[] cArr, char c11) {
        for (int i11 = 0; i11 < sb2.length(); i11++) {
            for (char c12 : cArr) {
                if (sb2.charAt(i11) == c12) {
                    sb2.setCharAt(i11, c11);
                    break;
                }
            }
        }
    }

    public static int u(qm.e eVar) throws bg.u {
        int iOrdinal = eVar.ordinal();
        if (iOrdinal == 0) {
            return 0;
        }
        int i11 = 1;
        if (iOrdinal != 1) {
            i11 = 2;
            if (iOrdinal != 2) {
                if (iOrdinal == 3) {
                    return 3;
                }
                throw new bg.u("Invalid DateStyle: ".concat(eVar.toString()), 13);
            }
        }
        return i11;
    }

    public static int w(qm.n nVar) throws bg.u {
        int iOrdinal = nVar.ordinal();
        if (iOrdinal == 0) {
            return 0;
        }
        int i11 = 1;
        if (iOrdinal != 1) {
            i11 = 2;
            if (iOrdinal != 2) {
                if (iOrdinal == 3) {
                    return 3;
                }
                throw new bg.u("Invalid DateStyle: ".concat(nVar.toString()), 13);
            }
        }
        return i11;
    }

    @Override // o.i
    public void G(o.k kVar) {
        o.i iVar = ((ActionMenuView) this.f21702e).f1345a0;
        if (iVar != null) {
            iVar.G(kVar);
        }
    }

    @Override // ot.f0
    public gs.f J(ot.g0 g0Var, long j6, long j11, IOException iOException, int i11) {
        long jMin;
        ot.n0 n0Var = (ot.n0) g0Var;
        vs.f fVar = (vs.f) this.f21702e;
        long j12 = n0Var.f25072d;
        ot.t0 t0Var = n0Var.f25075v;
        Uri uri = t0Var.f25144i;
        ss.k kVar = new ss.k(t0Var.f25143e, t0Var.f25145v);
        int i12 = n0Var.f25074i;
        fVar.P.getClass();
        if (!(iOException instanceof k1) && !(iOException instanceof FileNotFoundException) && !(iOException instanceof ot.z) && !(iOException instanceof ot.i0)) {
            int i13 = ot.n.f25070e;
            Throwable cause = iOException;
            while (true) {
                if (cause == null) {
                    jMin = Math.min((i11 - 1) * RNCWebViewManager.COMMAND_CLEAR_FORM_DATA, 5000);
                    break;
                }
                if ((cause instanceof ot.n) && ((ot.n) cause).f25071d == 2008) {
                    jMin = -9223372036854775807L;
                    break;
                }
                cause = cause.getCause();
            }
        } else {
            jMin = -9223372036854775807L;
            break;
        }
        gs.f fVar2 = jMin == -9223372036854775807L ? ot.j0.f25064x : new gs.f(0, jMin, (byte) 0);
        fVar.T.E(kVar, i12, iOException, !fVar2.a());
        return fVar2;
    }

    @Override // t60.a
    public Iterable a(Object obj) {
        p40.n nVar = (p40.n) this.f21702e;
        Collection collectionI = ((q40.e) obj).i0().i();
        kotlin.jvm.internal.k.f(collectionI, "getSupertypes(...)");
        ArrayList arrayList = new ArrayList();
        Iterator it = collectionI.iterator();
        while (it.hasNext()) {
            q40.h hVarH = ((k60.w) it.next()).n().h();
            q40.e eVarF = null;
            q40.h hVarA = hVarH != null ? hVarH.a() : null;
            q40.e eVar = hVarA instanceof q40.e ? (q40.e) hVarA : null;
            if (eVar != null && (eVarF = nVar.f(eVar)) == null) {
                eVarF = eVar;
            }
            if (eVarF != null) {
                arrayList.add(eVarF);
            }
        }
        return arrayList;
    }

    @Override // gu.h
    public void accept(Object obj, Object obj2) {
        xu.q qVar = (xu.q) this.f21702e;
        yu.f fVar = new yu.f(2, (nv.h) obj2);
        yu.d dVar = (yu.d) ((yu.e) obj).i();
        fu.f fVarA = gv.b.a();
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeInterfaceToken("com.google.android.gms.identitycredentials.internal.IIdentityCredentialService");
        int i11 = gv.a.f13582a;
        parcelObtain.writeStrongBinder(fVar);
        gv.a.b(parcelObtain, qVar);
        gv.a.b(parcelObtain, fVarA);
        ((yu.b) dVar).k(10, parcelObtain);
    }

    @Override // ww.h, fx.p
    public Object b() {
        switch (this.f21701d) {
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                return new vw.a0(new ww.g(new p1(21, (k0) this.f21702e)));
            default:
                return ((ww.h) this.f21702e).b();
        }
    }

    @Override // sw.b
    public nv.m c(al.c cVar) {
        sw.g gVar = (sw.g) this.f21702e;
        hv.f fVar = gVar.f29447c;
        if (fVar == null) {
            return sw.g.a(-2);
        }
        if (!gVar.b()) {
            return sw.g.a(-6);
        }
        nv.h hVar = new nv.h();
        fVar.a().post(new hv.c(fVar, hVar, hVar, new hv.c(gVar, hVar, hVar, cVar, 1), 0));
        return hVar.f23532a;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean cdpInteractionMetricsEnabled() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean commonTestFlag() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean cxxNativeAnimatedEnabled() {
        return false;
    }

    @Override // p.d2
    public void d(o.k kVar, MenuItem menuItem) {
        ((o.e) this.f21702e).f23701x.removeCallbacksAndMessages(kVar);
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean defaultTextToOverflowHidden() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean disableEarlyViewCommandExecution() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean disableImageViewPreallocationAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean disableMountItemReorderingAndroid() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean disableSubviewClippingAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean disableTextLayoutManagerCacheAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean disableViewPreallocationAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public double discordUiManagerOptimization() {
        return ((Number) ((ch.l) this.f21702e).k.getValue()).intValue();
    }

    @Override // l5.m
    public void e(byte[] bArr, int i11, int i12, l5.l lVar, n3.j jVar) {
        m3.b bVarA;
        n3.x xVar = (n3.x) this.f21702e;
        xVar.L(bArr, i11 + i12);
        xVar.N(i11);
        ArrayList arrayList = new ArrayList();
        while (xVar.a() > 0) {
            oq.a.m("Incomplete Mp4Webvtt Top Level box header found.", xVar.a() >= 8);
            int iM = xVar.m();
            if (xVar.m() == 1987343459) {
                int i13 = iM - 8;
                CharSequence charSequenceF = null;
                m3.a aVarB = null;
                while (i13 > 0) {
                    oq.a.m("Incomplete vtt cue box header found.", i13 >= 8);
                    int iM2 = xVar.m();
                    int iM3 = xVar.m();
                    int i14 = iM2 - 8;
                    byte[] bArr2 = xVar.f22410a;
                    int i15 = xVar.f22411b;
                    String str = n3.l0.f22358a;
                    String str2 = new String(bArr2, i15, i14, StandardCharsets.UTF_8);
                    xVar.O(i14);
                    i13 = (i13 - 8) - i14;
                    if (iM3 == 1937011815) {
                        lt.g gVar = new lt.g();
                        u5.g.e(str2, gVar);
                        aVarB = gVar.b();
                    } else if (iM3 == 1885436268) {
                        charSequenceF = u5.g.f(null, str2.trim(), Collections.EMPTY_LIST);
                    }
                }
                if (charSequenceF == null) {
                    charSequenceF = "";
                }
                if (aVarB != null) {
                    aVarB.f20788a = charSequenceF;
                    aVarB.f20789b = null;
                    bVarA = aVarB.a();
                } else {
                    Pattern pattern = u5.g.f30907a;
                    lt.g gVar2 = new lt.g();
                    gVar2.f20648c = charSequenceF;
                    bVarA = gVar2.b().a();
                }
                arrayList.add(bVarA);
            } else {
                xVar.O(iM - 8);
            }
        }
        jVar.accept(new l5.a(-9223372036854775807L, -9223372036854775807L, arrayList));
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableAccessibilityOrder() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableAccumulatedUpdatesInRawPropsAndroid() {
        return ((ch.l) this.f21702e).a() >= 2;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableAndroidTextMeasurementOptimizations() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableBridgelessArchitecture() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableCppPropsIteratorSetter() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableCustomFocusSearchOnClippedElementsAndroid() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableDestroyShadowTreeRevisionAsync() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableDifferentiatorMutationVectorPreallocation() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableDoubleMeasurementFixAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableEagerMainQueueModulesOnIOS() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableEagerRootViewAttachment() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableExclusivePropsUpdateAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableFabricCommitBranching() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableFabricLogs() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableFabricRenderer() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableFixForParentTagDuringReparenting() {
        return ((Number) ((ch.l) this.f21702e).f5120h.getValue()).intValue() <= 0;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableFontScaleChangesUpdatingLayout() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableIOSExperimentalAutoFocusImplementation() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableIOSTextBaselineOffsetPerLine() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableIOSViewClipToPaddingBox() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableImagePrefetchingAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableImmediateUpdateModeForContentOffsetChanges() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableImperativeFocus() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableInteropViewManagerClassLookUpOptimizationIOS() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableIntersectionObserverByDefault() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableKeyEvents() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableLayoutAnimationsOnAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableLayoutAnimationsOnIOS() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableMainQueueCoordinatorOnIOS() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableModuleArgumentNSNullConversionIOS() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableMountingCoordinatorPullModelAndroid() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableMutationObserverByDefault() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableNativeCSSParsing() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableNativeViewPropTransformations() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableNetworkEventReporting() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enablePreparedTextLayout() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enablePropsUpdateReconciliationAndroid() {
        return ((ch.l) this.f21702e).a() >= 2;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableSchedulerDelegateInvalidation() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableSwiftUIBasedFilters() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableViewCulling() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableViewRecycling() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableViewRecyclingForImage() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableViewRecyclingForScrollView() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableViewRecyclingForText() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableViewRecyclingForView() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableVirtualViewContainerStateExperimental() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean enableVirtualViewDebugFeatures() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fixDifferentiatorParentTagForUnflattenCase() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fixFindShadowNodeByTagRaceCondition() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fixMappingOfEventPrioritiesBetweenFabricAndReact() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fixYogaFlexBasisFitContentInMainAxis() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fuseboxAssertSingleHostState() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fuseboxEnabledRelease() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fuseboxFrameRecordingEnabled() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fuseboxNetworkInspectionEnabled() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean fuseboxScreenshotCaptureEnabled() {
        return false;
    }

    @Override // w2.g
    public void h(w70.m mVar) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new n3.k0("EmojiCompatInitializer", 2));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new v3.r0(4, this, mVar, threadPoolExecutor));
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean hideOffscreenVirtualViewsOnIOS() {
        return false;
    }

    @Override // p.d2
    public void j(o.k kVar, o.m mVar) {
        o.e eVar = (o.e) this.f21702e;
        Handler handler = eVar.f23701x;
        handler.removeCallbacksAndMessages(null);
        ArrayList arrayList = eVar.J;
        int size = arrayList.size();
        int i11 = 0;
        while (true) {
            if (i11 >= size) {
                i11 = -1;
                break;
            } else if (kVar == ((o.d) arrayList.get(i11)).f23693b) {
                break;
            } else {
                i11++;
            }
        }
        if (i11 == -1) {
            return;
        }
        int i12 = i11 + 1;
        handler.postAtTime(new androidx.core.view.n1(this, i12 < arrayList.size() ? (o.d) arrayList.get(i12) : null, mVar, kVar), kVar, SystemClock.uptimeMillis() + 200);
    }

    @Override // o.i
    public boolean l(o.k kVar, MenuItem menuItem) {
        boolean zOnMenuItemClick;
        p.m mVar = ((ActionMenuView) this.f21702e).f1350f0;
        if (mVar != null) {
            Toolbar toolbar = (Toolbar) ((g3) mVar).f25297d;
            Iterator it = ((CopyOnWriteArrayList) toolbar.f1376l0.f19346i).iterator();
            while (true) {
                if (!it.hasNext()) {
                    k3 k3Var = toolbar.f1378n0;
                    if (k3Var == null) {
                        zOnMenuItemClick = false;
                        break;
                    }
                    zOnMenuItemClick = k3Var.onMenuItemClick(menuItem);
                    break;
                }
                if (((b3.n0) it.next()).f2704a.p()) {
                    zOnMenuItemClick = true;
                    break;
                }
            }
            if (zOnMenuItemClick) {
                return true;
            }
        }
        return false;
    }

    @Override // sw.b
    public nv.m m(sw.h hVar) {
        sw.g gVar = (sw.g) this.f21702e;
        hv.f fVar = gVar.f29447c;
        if (fVar == null) {
            return sw.g.a(-2);
        }
        if (!gVar.b()) {
            return sw.g.a(-6);
        }
        nv.h hVar2 = new nv.h();
        fVar.a().post(new hv.c(fVar, hVar2, hVar2, new hv.c(gVar, hVar2, hVar2, hVar, 2), 0));
        return hVar2.f23532a;
    }

    public void n(int i11, boolean z11) {
        k3.t tVar = (k3.t) this.f21702e;
        if (z11) {
            tVar.a(i11);
        } else {
            tVar.getClass();
        }
    }

    public String o(ui.a event) {
        kotlin.jvm.internal.k.g(event, "event");
        LinkedHashMap linkedHashMap = (LinkedHashMap) this.f21702e;
        Class<?> cls = event.getClass();
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.v.f19658a;
        String str = (String) linkedHashMap.get(wVar.b(cls));
        if (str != null) {
            return str;
        }
        throw new IllegalStateException(("No event name registered for event: " + wVar.b(event.getClass())).toString());
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean overrideBySynchronousMountPropsAtMountingAndroid() {
        return true;
    }

    public void p(Exception exc) {
        n3.b.d("MediaCodecAudioRenderer", "Audio sink error", exc);
        v3.f0 f0Var = ((x3.i0) this.f21702e).f34954o1;
        Handler handler = (Handler) f0Var.f31989d;
        if (handler != null) {
            handler.post(new x3.m(f0Var, exc, 7));
        }
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean perfIssuesEnabled() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean perfMonitorV2Enabled() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public double preparedTextCacheSize() {
        return 200.0d;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean preventShadowTreeCommitExhaustion() {
        return true;
    }

    public void q(Object obj, boolean z11) {
        al.a aVar = (al.a) obj;
        ld.d dVar = (ld.d) this.f21702e;
        synchronized (dVar) {
            try {
                if (z11) {
                    ((LinkedHashSet) dVar.f20392w).add(aVar);
                } else {
                    ((LinkedHashSet) dVar.f20392w).remove(aVar);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean redBoxV2Android() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean redBoxV2IOS() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean runtimeCrashUiThreadUtils() {
        return false;
    }

    @Override // ot.f0
    public void s(ot.g0 g0Var, long j6, long j11) {
        ot.n0 n0Var = (ot.n0) g0Var;
        vs.f fVar = (vs.f) this.f21702e;
        long j12 = n0Var.f25072d;
        ot.t0 t0Var = n0Var.f25075v;
        Uri uri = t0Var.f25144i;
        ss.k kVar = new ss.k(t0Var.f25143e, t0Var.f25145v);
        fVar.P.getClass();
        fVar.T.y(kVar, n0Var.f25074i);
        ws.c cVar = (ws.c) n0Var.f25077x;
        ws.c cVar2 = fVar.f32948k0;
        int size = cVar2 == null ? 0 : cVar2.f34462m.size();
        long j13 = cVar.b(0).f34484b;
        int i11 = 0;
        while (i11 < size && fVar.f32948k0.b(i11).f34484b < j13) {
            i11++;
        }
        if (cVar.f34455d) {
            if (size - i11 > cVar.f34462m.size()) {
                qt.a.N("DashMediaSource", "Loaded out of sync manifest");
            } else {
                long j14 = fVar.f32954q0;
                if (j14 == -9223372036854775807L || cVar.f34459h * 1000 > j14) {
                    fVar.f32953p0 = 0;
                } else {
                    qt.a.N("DashMediaSource", "Loaded stale dynamic manifest: " + cVar.f34459h + ", " + fVar.f32954q0);
                }
            }
            int i12 = fVar.f32953p0;
            fVar.f32953p0 = i12 + 1;
            if (i12 < fVar.P.m(n0Var.f25074i)) {
                fVar.f32944g0.postDelayed(fVar.Y, Math.min((fVar.f32953p0 - 1) * RNCWebViewManager.COMMAND_CLEAR_FORM_DATA, 5000));
                return;
            } else {
                fVar.f32943f0 = new a4.a0();
                return;
            }
        }
        fVar.f32948k0 = cVar;
        fVar.f32949l0 = cVar.f34455d & fVar.f32949l0;
        fVar.f32950m0 = j6 - j11;
        fVar.f32951n0 = j6;
        synchronized (fVar.W) {
            try {
                if (n0Var.f25073e.f25094a == fVar.f32946i0) {
                    Uri uri2 = fVar.f32948k0.k;
                    if (uri2 == null) {
                        uri2 = n0Var.f25075v.f25144i;
                    }
                    fVar.f32946i0 = uri2;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (size != 0) {
            fVar.f32955r0 += i11;
            fVar.x(true);
            return;
        }
        ws.c cVar3 = fVar.f32948k0;
        if (!cVar3.f34455d) {
            fVar.x(true);
            return;
        }
        vr.g gVar = cVar3.f34460i;
        if (gVar == null) {
            fVar.u();
            return;
        }
        String str = (String) gVar.f32887e;
        if (qt.x.a(str, "urn:mpeg:dash:utc:direct:2014") || qt.x.a(str, "urn:mpeg:dash:utc:direct:2012")) {
            try {
                fVar.f32952o0 = qt.x.L((String) gVar.f32888i) - fVar.f32951n0;
                fVar.x(true);
                return;
            } catch (k1 e4) {
                qt.a.s("DashMediaSource", "Failed to resolve time offset.", e4);
                fVar.x(true);
                return;
            }
        }
        if (qt.x.a(str, "urn:mpeg:dash:utc:http-iso:2014") || qt.x.a(str, "urn:mpeg:dash:utc:http-iso:2012")) {
            ot.n0 n0Var2 = new ot.n0(fVar.f32940c0, Uri.parse((String) gVar.f32888i), 5, new vs.e());
            fVar.f32941d0.f(n0Var2, new g3(fVar), 1);
            fVar.T.I(new ss.k(n0Var2.f25073e), n0Var2.f25074i, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
        } else if (qt.x.a(str, "urn:mpeg:dash:utc:http-xsdate:2014") || qt.x.a(str, "urn:mpeg:dash:utc:http-xsdate:2012")) {
            ot.n0 n0Var3 = new ot.n0(fVar.f32940c0, Uri.parse((String) gVar.f32888i), 5, new zm.n(24));
            fVar.f32941d0.f(n0Var3, new g3(fVar), 1);
            fVar.T.I(new ss.k(n0Var3.f25073e), n0Var3.f25074i, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
        } else if (qt.x.a(str, "urn:mpeg:dash:utc:ntp:2014") || qt.x.a(str, "urn:mpeg:dash:utc:ntp:2012")) {
            fVar.u();
        } else {
            qt.a.s("DashMediaSource", "Failed to resolve time offset.", new IOException("Unsupported UTC timing scheme"));
            fVar.x(true);
        }
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean shouldPressibilityUseW3CPointerEventsForHover() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean shouldTriggerResponderTransferOnScrollAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean skipActivityIdentityAssertionOnHostPause() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean syncAndroidClipBoundsWithOverflow() {
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:110:0x0147 A[PHI: r5
      0x0147: PHI (r5v18 java.lang.Float) = (r5v10 java.lang.Float), (r5v12 java.lang.Float), (r5v14 java.lang.Float), (r5v16 java.lang.Float) binds: [B:109:0x0145, B:112:0x0150, B:115:0x0157, B:118:0x015e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:129:0x017f A[PHI: r2
      0x017f: PHI (r2v11 java.lang.Float) = (r2v2 java.lang.Float), (r2v4 java.lang.Float), (r2v6 java.lang.Float), (r2v8 java.lang.Float) binds: [B:128:0x017d, B:131:0x0188, B:134:0x018f, B:137:0x0196] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:142:0x01a0 A[PHI: r6
      0x01a0: PHI (r6v13 java.lang.Float) = (r6v2 java.lang.Float), (r6v4 java.lang.Float), (r6v6 java.lang.Float), (r6v8 java.lang.Float), (r6v10 java.lang.Float) binds: [B:141:0x019e, B:144:0x01a9, B:147:0x01b0, B:150:0x01b7, B:153:0x01be] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:158:0x01c8 A[PHI: r7
      0x01c8: PHI (r7v11 java.lang.Float) = (r7v2 java.lang.Float), (r7v4 java.lang.Float), (r7v6 java.lang.Float), (r7v8 java.lang.Float) binds: [B:157:0x01c6, B:160:0x01d1, B:163:0x01d8, B:166:0x01df] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:171:0x01e9 A[PHI: r5
      0x01e9: PHI (r5v9 java.lang.Float) = (r5v1 java.lang.Float), (r5v3 java.lang.Float), (r5v5 java.lang.Float), (r5v7 java.lang.Float) binds: [B:170:0x01e7, B:173:0x01f2, B:176:0x01f9, B:179:0x0200] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:25:0x0067 A[PHI: r7
      0x0067: PHI (r7v33 java.lang.Float) = (r7v25 java.lang.Float), (r7v27 java.lang.Float), (r7v29 java.lang.Float), (r7v31 java.lang.Float) binds: [B:24:0x0065, B:27:0x0070, B:30:0x0077, B:33:0x007e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:38:0x0088 A[PHI: r6
      0x0088: PHI (r6v35 java.lang.Float) = (r6v26 java.lang.Float), (r6v28 java.lang.Float), (r6v30 java.lang.Float), (r6v32 java.lang.Float) binds: [B:37:0x0086, B:40:0x0091, B:43:0x0098, B:46:0x009f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:51:0x00a9 A[PHI: r5
      0x00a9: PHI (r5v27 java.lang.Float) = (r5v19 java.lang.Float), (r5v21 java.lang.Float), (r5v23 java.lang.Float), (r5v25 java.lang.Float) binds: [B:50:0x00a7, B:53:0x00b2, B:56:0x00b9, B:59:0x00c0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:68:0x00d9 A[PHI: r2
      0x00d9: PHI (r2v26 java.lang.Float) = (r2v17 java.lang.Float), (r2v19 java.lang.Float), (r2v21 java.lang.Float), (r2v23 java.lang.Float) binds: [B:67:0x00d7, B:70:0x00e2, B:73:0x00e9, B:76:0x00f0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:84:0x0105 A[PHI: r7
      0x0105: PHI (r7v21 java.lang.Float) = (r7v13 java.lang.Float), (r7v15 java.lang.Float), (r7v17 java.lang.Float), (r7v19 java.lang.Float) binds: [B:83:0x0103, B:86:0x010e, B:89:0x0115, B:92:0x011c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:97:0x0126 A[PHI: r6
      0x0126: PHI (r6v24 java.lang.Float) = (r6v15 java.lang.Float), (r6v17 java.lang.Float), (r6v19 java.lang.Float), (r6v21 java.lang.Float) binds: [B:96:0x0124, B:99:0x012f, B:102:0x0136, B:105:0x013d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:9:0x003b A[PHI: r2
      0x003b: PHI (r2v38 java.lang.Float) = (r2v29 java.lang.Float), (r2v31 java.lang.Float), (r2v33 java.lang.Float), (r2v35 java.lang.Float) binds: [B:8:0x0039, B:11:0x0044, B:14:0x004b, B:17:0x0052] A[DONT_GENERATE, DONT_INLINE]] */
    public RectF t(Context context, int i11) {
        float fFloatValue;
        float fFloatValue2;
        float fFloatValue3;
        float fFloatValue4;
        float fFloatValue5;
        float fFloatValue6;
        float fFloatValue7;
        float fFloatValue8;
        float fFloatValue9;
        Float[] fArr = (Float[]) this.f21702e;
        kotlin.jvm.internal.k.g(context, "context");
        float fFloatValue10 = 0.0f;
        if (i11 == 0) {
            ay.f fVar = rp.g0.f28306d;
            Float f3 = fArr[5];
            if (f3 != null) {
                fFloatValue = f3.floatValue();
            } else {
                ay.f fVar2 = rp.g0.f28306d;
                f3 = fArr[1];
                if (f3 != null) {
                    fFloatValue = f3.floatValue();
                } else {
                    ay.f fVar3 = rp.g0.f28306d;
                    f3 = fArr[7];
                    if (f3 != null) {
                        fFloatValue = f3.floatValue();
                    } else {
                        ay.f fVar4 = rp.g0.f28306d;
                        f3 = fArr[0];
                        if (f3 != null) {
                            fFloatValue = f3.floatValue();
                        } else {
                            fFloatValue = 0.0f;
                        }
                    }
                }
            }
            ay.f fVar5 = rp.g0.f28306d;
            Float f11 = fArr[9];
            if (f11 != null) {
                fFloatValue2 = f11.floatValue();
            } else {
                ay.f fVar6 = rp.g0.f28306d;
                f11 = fArr[3];
                if (f11 != null) {
                    fFloatValue2 = f11.floatValue();
                } else {
                    ay.f fVar7 = rp.g0.f28306d;
                    f11 = fArr[11];
                    if (f11 != null) {
                        fFloatValue2 = f11.floatValue();
                    } else {
                        ay.f fVar8 = rp.g0.f28306d;
                        f11 = fArr[8];
                        if (f11 != null) {
                            fFloatValue2 = f11.floatValue();
                        } else {
                            ay.f fVar9 = rp.g0.f28306d;
                            f11 = fArr[0];
                            if (f11 != null) {
                                fFloatValue2 = f11.floatValue();
                            } else {
                                fFloatValue2 = 0.0f;
                            }
                        }
                    }
                }
            }
            ay.f fVar10 = rp.g0.f28306d;
            Float f12 = fArr[6];
            if (f12 != null) {
                fFloatValue3 = f12.floatValue();
            } else {
                ay.f fVar11 = rp.g0.f28306d;
                f12 = fArr[2];
                if (f12 != null) {
                    fFloatValue3 = f12.floatValue();
                } else {
                    ay.f fVar12 = rp.g0.f28306d;
                    f12 = fArr[7];
                    if (f12 != null) {
                        fFloatValue3 = f12.floatValue();
                    } else {
                        ay.f fVar13 = rp.g0.f28306d;
                        f12 = fArr[0];
                        if (f12 != null) {
                            fFloatValue3 = f12.floatValue();
                        } else {
                            fFloatValue3 = 0.0f;
                        }
                    }
                }
            }
            ay.f fVar14 = rp.g0.f28306d;
            Float f13 = fArr[10];
            if (f13 != null) {
                fFloatValue10 = f13.floatValue();
            } else {
                ay.f fVar15 = rp.g0.f28306d;
                f13 = fArr[4];
                if (f13 != null) {
                    fFloatValue10 = f13.floatValue();
                } else {
                    ay.f fVar16 = rp.g0.f28306d;
                    f13 = fArr[11];
                    if (f13 != null) {
                        fFloatValue10 = f13.floatValue();
                    } else {
                        ay.f fVar17 = rp.g0.f28306d;
                        f13 = fArr[8];
                        if (f13 != null) {
                            fFloatValue10 = f13.floatValue();
                        } else {
                            ay.f fVar18 = rp.g0.f28306d;
                            Float f14 = fArr[0];
                            if (f14 != null) {
                                fFloatValue10 = f14.floatValue();
                            }
                        }
                    }
                }
            }
            return new RectF(fFloatValue, fFloatValue2, fFloatValue3, fFloatValue10);
        }
        if (i11 != 1) {
            throw new IllegalArgumentException("Expected resolved layout direction");
        }
        if (context.getSharedPreferences("com.facebook.react.modules.i18nmanager.I18nUtil", 0).getBoolean("RCTI18nUtil_makeRTLFlipLeftAndRightStyles", true)) {
            ay.f fVar19 = rp.g0.f28306d;
            Float f15 = fArr[6];
            if (f15 != null) {
                fFloatValue7 = f15.floatValue();
            } else {
                ay.f fVar20 = rp.g0.f28306d;
                f15 = fArr[2];
                if (f15 != null) {
                    fFloatValue7 = f15.floatValue();
                } else {
                    ay.f fVar21 = rp.g0.f28306d;
                    f15 = fArr[7];
                    if (f15 != null) {
                        fFloatValue7 = f15.floatValue();
                    } else {
                        ay.f fVar22 = rp.g0.f28306d;
                        f15 = fArr[0];
                        if (f15 != null) {
                            fFloatValue7 = f15.floatValue();
                        } else {
                            fFloatValue7 = 0.0f;
                        }
                    }
                }
            }
            ay.f fVar23 = rp.g0.f28306d;
            Float f16 = fArr[9];
            if (f16 != null) {
                fFloatValue8 = f16.floatValue();
            } else {
                ay.f fVar24 = rp.g0.f28306d;
                Float f17 = fArr[3];
                if (f17 != null) {
                    fFloatValue8 = f17.floatValue();
                } else {
                    ay.f fVar25 = rp.g0.f28306d;
                    f17 = fArr[11];
                    if (f17 != null) {
                        fFloatValue8 = f17.floatValue();
                    } else {
                        ay.f fVar26 = rp.g0.f28306d;
                        f17 = fArr[8];
                        if (f17 != null) {
                            fFloatValue8 = f17.floatValue();
                        } else {
                            ay.f fVar27 = rp.g0.f28306d;
                            f17 = fArr[0];
                            if (f17 != null) {
                                fFloatValue8 = f17.floatValue();
                            } else {
                                fFloatValue8 = 0.0f;
                            }
                        }
                    }
                }
            }
            ay.f fVar28 = rp.g0.f28306d;
            Float f18 = fArr[5];
            if (f18 != null) {
                fFloatValue9 = f18.floatValue();
            } else {
                ay.f fVar29 = rp.g0.f28306d;
                f18 = fArr[1];
                if (f18 != null) {
                    fFloatValue9 = f18.floatValue();
                } else {
                    ay.f fVar30 = rp.g0.f28306d;
                    f18 = fArr[7];
                    if (f18 != null) {
                        fFloatValue9 = f18.floatValue();
                    } else {
                        ay.f fVar31 = rp.g0.f28306d;
                        f18 = fArr[0];
                        if (f18 != null) {
                            fFloatValue9 = f18.floatValue();
                        } else {
                            fFloatValue9 = 0.0f;
                        }
                    }
                }
            }
            ay.f fVar32 = rp.g0.f28306d;
            Float f19 = fArr[10];
            if (f19 != null) {
                fFloatValue10 = f19.floatValue();
            } else {
                ay.f fVar33 = rp.g0.f28306d;
                f19 = fArr[4];
                if (f19 != null) {
                    fFloatValue10 = f19.floatValue();
                } else {
                    ay.f fVar34 = rp.g0.f28306d;
                    f19 = fArr[11];
                    if (f19 != null) {
                        fFloatValue10 = f19.floatValue();
                    } else {
                        ay.f fVar35 = rp.g0.f28306d;
                        f19 = fArr[8];
                        if (f19 != null) {
                            fFloatValue10 = f19.floatValue();
                        } else {
                            ay.f fVar36 = rp.g0.f28306d;
                            Float f21 = fArr[0];
                            if (f21 != null) {
                                fFloatValue10 = f21.floatValue();
                            }
                        }
                    }
                }
            }
            return new RectF(fFloatValue7, fFloatValue8, fFloatValue9, fFloatValue10);
        }
        ay.f fVar37 = rp.g0.f28306d;
        Float f22 = fArr[6];
        if (f22 != null) {
            fFloatValue4 = f22.floatValue();
        } else {
            ay.f fVar38 = rp.g0.f28306d;
            f22 = fArr[1];
            if (f22 != null) {
                fFloatValue4 = f22.floatValue();
            } else {
                ay.f fVar39 = rp.g0.f28306d;
                f22 = fArr[7];
                if (f22 != null) {
                    fFloatValue4 = f22.floatValue();
                } else {
                    ay.f fVar40 = rp.g0.f28306d;
                    f22 = fArr[0];
                    if (f22 != null) {
                        fFloatValue4 = f22.floatValue();
                    } else {
                        fFloatValue4 = 0.0f;
                    }
                }
            }
        }
        ay.f fVar41 = rp.g0.f28306d;
        Float f23 = fArr[9];
        if (f23 != null) {
            fFloatValue5 = f23.floatValue();
        } else {
            ay.f fVar42 = rp.g0.f28306d;
            Float f24 = fArr[3];
            if (f24 != null) {
                fFloatValue5 = f24.floatValue();
            } else {
                ay.f fVar43 = rp.g0.f28306d;
                f24 = fArr[11];
                if (f24 != null) {
                    fFloatValue5 = f24.floatValue();
                } else {
                    ay.f fVar44 = rp.g0.f28306d;
                    f24 = fArr[8];
                    if (f24 != null) {
                        fFloatValue5 = f24.floatValue();
                    } else {
                        ay.f fVar45 = rp.g0.f28306d;
                        f24 = fArr[0];
                        if (f24 != null) {
                            fFloatValue5 = f24.floatValue();
                        } else {
                            fFloatValue5 = 0.0f;
                        }
                    }
                }
            }
        }
        ay.f fVar46 = rp.g0.f28306d;
        Float f25 = fArr[5];
        if (f25 != null) {
            fFloatValue6 = f25.floatValue();
        } else {
            ay.f fVar47 = rp.g0.f28306d;
            f25 = fArr[2];
            if (f25 != null) {
                fFloatValue6 = f25.floatValue();
            } else {
                ay.f fVar48 = rp.g0.f28306d;
                f25 = fArr[7];
                if (f25 != null) {
                    fFloatValue6 = f25.floatValue();
                } else {
                    ay.f fVar49 = rp.g0.f28306d;
                    f25 = fArr[0];
                    if (f25 != null) {
                        fFloatValue6 = f25.floatValue();
                    } else {
                        fFloatValue6 = 0.0f;
                    }
                }
            }
        }
        ay.f fVar50 = rp.g0.f28306d;
        Float f26 = fArr[10];
        if (f26 != null) {
            fFloatValue10 = f26.floatValue();
        } else {
            ay.f fVar51 = rp.g0.f28306d;
            f26 = fArr[4];
            if (f26 != null) {
                fFloatValue10 = f26.floatValue();
            } else {
                ay.f fVar52 = rp.g0.f28306d;
                f26 = fArr[11];
                if (f26 != null) {
                    fFloatValue10 = f26.floatValue();
                } else {
                    ay.f fVar53 = rp.g0.f28306d;
                    f26 = fArr[8];
                    if (f26 != null) {
                        fFloatValue10 = f26.floatValue();
                    } else {
                        ay.f fVar54 = rp.g0.f28306d;
                        Float f27 = fArr[0];
                        if (f27 != null) {
                            fFloatValue10 = f27.floatValue();
                        }
                    }
                }
            }
        }
        return new RectF(fFloatValue4, fFloatValue5, fFloatValue6, fFloatValue10);
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean traceTurboModulePromiseRejectionsOnAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean updateRuntimeShadowNodeReferencesOnCommit() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean updateRuntimeShadowNodeReferencesOnCommitThread() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useAlwaysAvailableJSErrorHandling() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useFabricInterop() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useLISAlgorithmInDifferentiator() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useNativeViewConfigsInBridgelessMode() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useNestedScrollViewAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useOptimizedViewRegistryOnAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean usePullModelOnAndroid() {
        return ((ch.l) this.f21702e).a() == 3;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useSharedAnimatedBackend() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useSilenceErrorSMMViewNotFound() {
        return ((ch.l) this.f21702e).a() == 1;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useTraitHiddenOnAndroid() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useTraitHiddenOnIOS() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useTurboModuleInterop() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useTurboModules() {
        return true;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean useUnorderedMapInDifferentiator() {
        return false;
    }

    @Override // ot.f0
    public void v(ot.g0 g0Var, long j6, long j11, boolean z11) {
        ((vs.f) this.f21702e).w((ot.n0) g0Var);
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public double viewCullingOutsetRatio() {
        return 0.0d;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public boolean viewTransitionEnabled() {
        return false;
    }

    @Override // com.facebook.react.internal.featureflags.ReactNativeFeatureFlagsProvider
    public double virtualViewPrerenderRatio() {
        return 5.0d;
    }

    public p1(Context context, int i11) {
        this.f21701d = i11;
        switch (i11) {
            case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                fx.o oVar = new fx.o(context);
                fx.m mVarA = fx.m.a(new vr.n(oVar, fx.m.a(zw.i.f37985b), new al.d(oVar, zw.i.f37986c)));
                this.f21702e = fx.m.a(new vr.g(8, mVarA, fx.m.a(new g3(mVarA))));
                break;
            default:
                this.f21702e = context.getApplicationContext();
                break;
        }
    }

    public p1(int i11) {
        this.f21701d = i11;
        switch (i11) {
            case 8:
                break;
            case 10:
                this.f21702e = new Float[rp.g0.values().length];
                break;
            case 13:
                this.f21702e = new HashSet();
                break;
            case 14:
                this.f21702e = new n3.x();
                break;
            case 15:
                this.f21702e = new LinkedHashMap();
                break;
            case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                this.f21702e = new SparseArray();
                break;
            case 27:
                this.f21702e = new a4.w(5, 1.0f, false, 3);
                break;
            default:
                this.f21702e = new k3.t(1);
                break;
        }
    }
}
