package mr;

import android.net.Uri;

/* JADX INFO: loaded from: classes3.dex */
public class u0 implements e {
    public static final String J;
    public static final String K;
    public static final String L;
    public static final String M;
    public static final String N;
    public static final String O;
    public static final String P;
    public static final mp.a Q;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Uri f21739d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21740e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f21741i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f21742v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21743w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final String f21744x;
    public final String y;

    static {
        int i11 = qt.x.f27318a;
        J = Integer.toString(0, 36);
        K = Integer.toString(1, 36);
        L = Integer.toString(2, 36);
        M = Integer.toString(3, 36);
        N = Integer.toString(4, 36);
        O = Integer.toString(5, 36);
        P = Integer.toString(6, 36);
        Q = new mp.a(26);
    }

    public u0(k3.m0 m0Var) {
        this.f21739d = m0Var.f18699a;
        this.f21740e = m0Var.f18700b;
        this.f21741i = m0Var.f18701c;
        this.f21742v = m0Var.f18702d;
        this.f21743w = m0Var.f18703e;
        this.f21744x = m0Var.f18704f;
        this.y = m0Var.f18705g;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof u0)) {
            return false;
        }
        u0 u0Var = (u0) obj;
        return this.f21739d.equals(u0Var.f21739d) && qt.x.a(this.f21740e, u0Var.f21740e) && qt.x.a(this.f21741i, u0Var.f21741i) && this.f21742v == u0Var.f21742v && this.f21743w == u0Var.f21743w && qt.x.a(this.f21744x, u0Var.f21744x) && qt.x.a(this.y, u0Var.y);
    }

    public final int hashCode() {
        int iHashCode = this.f21739d.hashCode() * 31;
        String str = this.f21740e;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.f21741i;
        int iHashCode3 = (((((iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31) + this.f21742v) * 31) + this.f21743w) * 31;
        String str3 = this.f21744x;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.y;
        return iHashCode4 + (str4 != null ? str4.hashCode() : 0);
    }
}
