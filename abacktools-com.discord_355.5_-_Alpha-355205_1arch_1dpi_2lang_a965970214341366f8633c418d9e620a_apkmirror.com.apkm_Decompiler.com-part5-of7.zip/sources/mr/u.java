package mr;

import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class u implements qt.g, n3.n {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21737d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ List f21738e;

    public /* synthetic */ u(int i11, List list) {
        this.f21737d = i11;
        this.f21738e = list;
    }

    @Override // qt.g, n3.n
    public final void invoke(Object obj) {
        switch (this.f21737d) {
            case 0:
                ((s1) obj).k(this.f21738e);
                break;
            case 1:
                ((nr.b) obj).getClass();
                break;
            case 2:
                ((k3.c1) obj).k(this.f21738e);
                break;
            default:
                ((w3.b) obj).getClass();
                break;
        }
    }

    public /* synthetic */ u(Object obj, List list, int i11) {
        this.f21737d = i11;
        this.f21738e = list;
    }
}
