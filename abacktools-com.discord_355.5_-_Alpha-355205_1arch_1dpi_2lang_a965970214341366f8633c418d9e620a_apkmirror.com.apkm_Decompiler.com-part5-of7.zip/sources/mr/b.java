package mr;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import org.webrtc.MediaStreamTrack;

/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AudioManager f21393a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l3.e f21394b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public w f21395c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f21396d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f21397e = 1.0f;

    public b(Context context, Handler handler, w wVar) {
        AudioManager audioManager = (AudioManager) context.getApplicationContext().getSystemService(MediaStreamTrack.AUDIO_TRACK_KIND);
        audioManager.getClass();
        this.f21393a = audioManager;
        this.f21395c = wVar;
        this.f21394b = new l3.e(this, handler);
        this.f21396d = 0;
    }

    public final void a() {
        if (this.f21396d == 0) {
            return;
        }
        if (qt.x.f27318a < 26) {
            this.f21393a.abandonAudioFocus(this.f21394b);
        }
        b(0);
    }

    public final void b(int i11) {
        if (this.f21396d == i11) {
            return;
        }
        this.f21396d = i11;
        float f3 = i11 == 3 ? 0.2f : 1.0f;
        if (this.f21397e == f3) {
            return;
        }
        this.f21397e = f3;
        w wVar = this.f21395c;
        if (wVar != null) {
            z zVar = wVar.f21753d;
            zVar.T2(1, 2, Float.valueOf(zVar.C0 * zVar.f21844c0.f21397e));
        }
    }

    public final int c(int i11, boolean z11) {
        a();
        return z11 ? 1 : -1;
    }
}
