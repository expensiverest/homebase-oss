package mr;

import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public final class o1 implements e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final o1 f21689v = new o1(1.0f, 1.0f);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f21690d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final float f21691e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21692i;

    static {
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
        Integer.toString(1, 36);
    }

    public o1(float f3, float f11) {
        qt.a.g(f3 > 0.0f);
        qt.a.g(f11 > 0.0f);
        this.f21690d = f3;
        this.f21691e = f11;
        this.f21692i = Math.round(f3 * 1000.0f);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && o1.class == obj.getClass()) {
            o1 o1Var = (o1) obj;
            if (this.f21690d == o1Var.f21690d && this.f21691e == o1Var.f21691e) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Float.floatToRawIntBits(this.f21691e) + ((Float.floatToRawIntBits(this.f21690d) + 527) * 31);
    }

    public final String toString() {
        Object[] objArr = {Float.valueOf(this.f21690d), Float.valueOf(this.f21691e)};
        int i11 = qt.x.f27318a;
        return String.format(Locale.US, "PlaybackParameters(speed=%.2f, pitch=%.2f)", objArr);
    }
}
