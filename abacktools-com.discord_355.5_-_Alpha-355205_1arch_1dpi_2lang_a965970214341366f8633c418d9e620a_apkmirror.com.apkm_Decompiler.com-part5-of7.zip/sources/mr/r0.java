package mr;

import android.net.Uri;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class r0 implements e {
    public static final String J;
    public static final String K;
    public static final String L;
    public static final String M;
    public static final String N;
    public static final String O;
    public static final String P;
    public static final mp.a Q;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Uri f21715d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21716e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final p0 f21717i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final l0 f21718v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final List f21719w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final String f21720x;
    public final hx.m0 y;

    static {
        int i11 = qt.x.f27318a;
        J = Integer.toString(0, 36);
        K = Integer.toString(1, 36);
        L = Integer.toString(2, 36);
        M = Integer.toString(3, 36);
        N = Integer.toString(4, 36);
        O = Integer.toString(5, 36);
        P = Integer.toString(6, 36);
        Q = new mp.a(24);
    }

    public r0(Uri uri, String str, p0 p0Var, l0 l0Var, List list, String str2, hx.m0 m0Var) {
        this.f21715d = uri;
        this.f21716e = str;
        this.f21717i = p0Var;
        this.f21718v = l0Var;
        this.f21719w = list;
        this.f21720x = str2;
        this.y = m0Var;
        hx.j0 j0VarP = hx.m0.p();
        for (int i11 = 0; i11 < m0Var.size(); i11++) {
            u0 u0Var = (u0) m0Var.get(i11);
            k3.m0 m0Var2 = new k3.m0();
            m0Var2.f18699a = u0Var.f21739d;
            m0Var2.f18700b = u0Var.f21740e;
            m0Var2.f18701c = u0Var.f21741i;
            m0Var2.f18702d = u0Var.f21742v;
            m0Var2.f18703e = u0Var.f21743w;
            m0Var2.f18704f = u0Var.f21744x;
            m0Var2.f18705g = u0Var.y;
            j0VarP.c(new t0(m0Var2));
        }
        j0VarP.g();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r0)) {
            return false;
        }
        r0 r0Var = (r0) obj;
        return this.f21715d.equals(r0Var.f21715d) && qt.x.a(this.f21716e, r0Var.f21716e) && qt.x.a(this.f21717i, r0Var.f21717i) && qt.x.a(this.f21718v, r0Var.f21718v) && this.f21719w.equals(r0Var.f21719w) && qt.x.a(this.f21720x, r0Var.f21720x) && this.y.equals(r0Var.y);
    }

    public final int hashCode() {
        int iHashCode = this.f21715d.hashCode() * 31;
        String str = this.f21716e;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        p0 p0Var = this.f21717i;
        int iHashCode3 = (iHashCode2 + (p0Var == null ? 0 : p0Var.hashCode())) * 31;
        l0 l0Var = this.f21718v;
        int iHashCode4 = (this.f21719w.hashCode() + ((iHashCode3 + (l0Var == null ? 0 : l0Var.hashCode())) * 31)) * 31;
        String str2 = this.f21720x;
        return (this.y.hashCode() + ((iHashCode4 + (str2 != null ? str2.hashCode() : 0)) * 31)) * 31;
    }
}
