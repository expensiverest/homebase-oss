package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class i implements e {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21541d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21542e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21543i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final String f21544v = null;

    static {
        new a50.i(0).a();
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
        Integer.toString(1, 36);
        Integer.toString(2, 36);
        Integer.toString(3, 36);
    }

    public i(a50.i iVar) {
        this.f21541d = iVar.f400a;
        this.f21542e = iVar.f401b;
        this.f21543i = iVar.f402c;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return this.f21541d == iVar.f21541d && this.f21542e == iVar.f21542e && this.f21543i == iVar.f21543i && qt.x.a(this.f21544v, iVar.f21544v);
    }

    public final int hashCode() {
        int i11 = (((((527 + this.f21541d) * 31) + this.f21542e) * 31) + this.f21543i) * 31;
        String str = this.f21544v;
        return i11 + (str == null ? 0 : str.hashCode());
    }
}
