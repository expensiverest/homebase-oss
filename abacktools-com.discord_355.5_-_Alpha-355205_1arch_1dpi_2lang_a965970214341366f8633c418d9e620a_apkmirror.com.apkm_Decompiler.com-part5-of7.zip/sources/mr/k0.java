package mr;

import android.graphics.Rect;
import android.os.Parcel;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import com.facebook.fresco.animation.factory.AnimatedFactoryV2Impl;

/* JADX INFO: loaded from: classes3.dex */
public final class k0 implements m50.l, vm.b, o.v, ss.o0, v1.p, e6.q0, ub.z, nv.e, ww.h, ss.n0, y1.i, gu.h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f21633d;

    public /* synthetic */ k0(Object obj) {
        this.f21633d = obj;
    }

    public static k0 v(boolean z11, int i11, int i12, int i13, int i14) {
        return new k0(AccessibilityNodeInfo.CollectionItemInfo.obtain(i11, i12, i13, i14, false, z11));
    }

    @Override // vm.b
    public vm.a B(ld.d dVar, Rect rect) {
        AnimatedFactoryV2Impl animatedFactoryV2Impl = (AnimatedFactoryV2Impl) this.f21633d;
        if (animatedFactoryV2Impl.f5672g == null) {
            animatedFactoryV2Impl.f5672g = new zm.f(26);
        }
        return new vm.a(animatedFactoryV2Impl.f5672g, dVar, rect, animatedFactoryV2Impl.f5669d);
    }

    @Override // m50.l
    public m50.l C(t50.b bVar, t50.e eVar) {
        return null;
    }

    @Override // o.v
    public boolean D(o.k kVar) {
        p.j jVar = (p.j) this.f21633d;
        if (kVar == jVar.f25320i) {
            return false;
        }
        jVar.f25317a0 = ((o.c0) kVar).A.f23741a;
        o.v vVar = jVar.f25322w;
        if (vVar != null) {
            return vVar.D(kVar);
        }
        return false;
    }

    @Override // ss.n0
    public void a(ss.o0 o0Var) {
        xs.k kVar = (xs.k) this.f21633d;
        kVar.S.a(kVar);
    }

    @Override // gu.h
    public void accept(Object obj, Object obj2) {
        xu.f fVar = (xu.f) this.f21633d;
        yu.f fVar2 = new yu.f(0, (nv.h) obj2);
        yu.d dVar = (yu.d) ((yu.e) obj).i();
        fu.f fVarA = gv.b.a();
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeInterfaceToken("com.google.android.gms.identitycredentials.internal.IIdentityCredentialService");
        int i11 = gv.a.f13582a;
        parcelObtain.writeStrongBinder(fVar2);
        gv.a.b(parcelObtain, fVar);
        gv.a.b(parcelObtain, fVarA);
        ((yu.b) dVar).k(6, parcelObtain);
    }

    @Override // ww.h, fx.p
    public Object b() {
        ww.g gVar = (ww.g) this.f21633d;
        if (gVar != null) {
            return gVar.b();
        }
        throw new IllegalStateException();
    }

    @Override // nv.e
    public void d(Object obj) {
        ((vw.n) this.f21633d).f();
    }

    @Override // o.v
    public void h(o.k kVar, boolean z11) {
        if (kVar instanceof o.c0) {
            ((o.c0) kVar).f23691z.k().c(false);
        }
        o.v vVar = ((p.j) this.f21633d).f25322w;
        if (vVar != null) {
            vVar.h(kVar, z11);
        }
    }

    @Override // ss.o0
    public boolean i() {
        for (ss.o0 o0Var : (ss.o0[]) this.f21633d) {
            if (o0Var.i()) {
                return true;
            }
        }
        return false;
    }

    @Override // ss.o0
    public long j() {
        long jMin = Long.MAX_VALUE;
        for (ss.o0 o0Var : (ss.o0[]) this.f21633d) {
            long j6 = o0Var.j();
            if (j6 != Long.MIN_VALUE) {
                jMin = Math.min(jMin, j6);
            }
        }
        if (jMin == Long.MAX_VALUE) {
            return Long.MIN_VALUE;
        }
        return jMin;
    }

    @Override // ss.o0
    public long n() {
        long jMin = Long.MAX_VALUE;
        for (ss.o0 o0Var : (ss.o0[]) this.f21633d) {
            long jN = o0Var.n();
            if (jN != Long.MIN_VALUE) {
                jMin = Math.min(jMin, jN);
            }
        }
        if (jMin == Long.MAX_VALUE) {
            return Long.MIN_VALUE;
        }
        return jMin;
    }

    @Override // v1.p
    public boolean o(View view) {
        u2.f fVar = (u2.f) this.f21633d;
        if (!u2.f.k(view) || fVar.f(view) == 2) {
            return false;
        }
        fVar.b(view);
        return true;
    }

    @Override // y1.i
    public void onResult(Object obj) {
        y1.w result = (y1.w) obj;
        kotlin.jvm.internal.k.g(result, "result");
        z60.k kVar = (z60.k) this.f21633d;
        if (kVar.w()) {
            kVar.resumeWith(result);
        }
    }

    @Override // ss.o0
    public void p(long j6) {
        for (ss.o0 o0Var : (ss.o0[]) this.f21633d) {
            o0Var.p(j6);
        }
    }

    @Override // m50.l
    public void q(t50.e eVar, Object obj) {
        n50.e eVar2 = (n50.e) this.f21633d;
        String strB = eVar.b();
        if ("version".equals(strB)) {
            if (obj instanceof int[]) {
                eVar2.f22647d = (int[]) obj;
            }
        } else if ("multifileClassName".equals(strB)) {
            eVar2.f22648e = obj instanceof String ? (String) obj : null;
        }
    }

    @Override // m50.l
    public m50.m t(t50.e eVar) {
        String strB = eVar.b();
        if ("data".equals(strB) || "filePartClassNames".equals(strB)) {
            return new n50.d(this, 0);
        }
        if ("strings".equals(strB)) {
            return new n50.d(this, 1);
        }
        return null;
    }

    @Override // y1.i
    public void u(Object obj) {
        b2.c e4 = (b2.c) obj;
        kotlin.jvm.internal.k.g(e4, "e");
        z60.k kVar = (z60.k) this.f21633d;
        if (kVar.w()) {
            kVar.resumeWith(android.support.v4.media.session.b.q(e4));
        }
    }

    @Override // ss.o0
    public boolean w(long j6) {
        boolean zW;
        boolean z11 = false;
        do {
            long j11 = j();
            if (j11 == Long.MIN_VALUE) {
                return z11;
            }
            zW = false;
            for (ss.o0 o0Var : (ss.o0[]) this.f21633d) {
                long j12 = o0Var.j();
                boolean z12 = j12 != Long.MIN_VALUE && j12 <= j6;
                if (j12 == j11 || z12) {
                    zW |= o0Var.w(j6);
                }
            }
            z11 |= zW;
        } while (zW);
        return z11;
    }

    public void y() {
        xs.k kVar = (xs.k) this.f21633d;
        int i11 = kVar.T - 1;
        kVar.T = i11;
        if (i11 > 0) {
            return;
        }
        int i12 = 0;
        for (xs.q qVar : kVar.V) {
            qVar.d();
            i12 += qVar.f35473k0.f29356d;
        }
        ss.v0[] v0VarArr = new ss.v0[i12];
        int i13 = 0;
        for (xs.q qVar2 : kVar.V) {
            qVar2.d();
            int i14 = qVar2.f35473k0.f29356d;
            int i15 = 0;
            while (i15 < i14) {
                qVar2.d();
                v0VarArr[i13] = qVar2.f35473k0.a(i15);
                i15++;
                i13++;
            }
        }
        kVar.U = new ss.w0(v0VarArr);
        kVar.S.s(kVar);
    }

    @Override // m50.l
    public void k() {
    }

    @Override // m50.l
    public void H(t50.e eVar, y50.f fVar) {
    }

    @Override // m50.l
    public void z(t50.e eVar, t50.b bVar, t50.e eVar2) {
    }
}
