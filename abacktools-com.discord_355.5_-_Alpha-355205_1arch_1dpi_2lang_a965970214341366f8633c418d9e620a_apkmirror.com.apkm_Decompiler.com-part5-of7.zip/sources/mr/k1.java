package mr;

import java.io.IOException;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public class k1 extends IOException {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21634d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21635e;

    public k1(String str, Throwable th2, boolean z11, int i11) {
        super(str, th2);
        this.f21634d = z11;
        this.f21635e = i11;
    }

    public static k1 a(RuntimeException runtimeException, String str) {
        return new k1(str, runtimeException, true, 1);
    }

    public static k1 b(String str, Exception exc) {
        return new k1(str, exc, true, 4);
    }

    public static k1 c(String str) {
        return new k1(str, null, false, 1);
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.getMessage());
        sb2.append("{contentIsMalformed=");
        sb2.append(this.f21634d);
        sb2.append(", dataType=");
        return x2.f(this.f21635e, "}", sb2);
    }
}
