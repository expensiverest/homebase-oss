package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class o0 extends n0 {
    public static final o0 O = new o0(new m0());
}
