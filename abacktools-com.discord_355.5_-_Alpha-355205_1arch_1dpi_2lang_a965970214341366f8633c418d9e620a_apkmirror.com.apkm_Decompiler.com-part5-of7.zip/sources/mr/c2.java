package mr;

import android.media.AudioTrack;
import android.os.Looper;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.TextureView;
import java.util.HashSet;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes3.dex */
public final class c2 extends b3.l {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final z f21419i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final bj.d f21420v;

    public c2(k kVar) {
        super(4);
        bj.d dVar = new bj.d(0);
        this.f21420v = dVar;
        try {
            this.f21419i = new z(kVar, this);
            dVar.o();
        } catch (Throwable th2) {
            this.f21420v.o();
            throw th2;
        }
    }

    @Override // mr.u1
    public final j C1() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.J0.f21676f;
    }

    @Override // b3.l
    public final void C2(long j6, int i11, int i12, boolean z11) {
        H2();
        this.f21419i.C2(j6, i11, i12, z11);
    }

    @Override // k3.e1
    public final void D(float f3) {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        float fH = qt.x.h(f3, 0.0f, 1.0f);
        if (zVar.C0 == fH) {
            return;
        }
        zVar.C0 = fH;
        zVar.T2(1, 2, Float.valueOf(zVar.f21844c0.f21397e * fH));
        zVar.O.g(22, new n(fH, 0));
    }

    @Override // k3.e1, mr.u1
    public final void F(boolean z11) {
        H2();
        this.f21419i.F(z11);
    }

    @Override // k3.e1, mr.u1
    public final long G() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.X;
    }

    @Override // k3.e1, mr.u1
    public final long H() {
        H2();
        return this.f21419i.H();
    }

    public final void H2() {
        this.f21420v.e();
    }

    @Override // k3.e1, mr.u1
    public final int I() {
        H2();
        return this.f21419i.I();
    }

    public final void I2() {
        String str;
        boolean z11;
        AudioTrack audioTrack;
        H2();
        z zVar = this.f21419i;
        zVar.getClass();
        StringBuilder sb2 = new StringBuilder("Release ");
        sb2.append(Integer.toHexString(System.identityHashCode(zVar)));
        sb2.append(" [ExoPlayerLib/2.19.1] [");
        sb2.append(qt.x.f27322e);
        sb2.append("] [");
        HashSet hashSet = g0.f21492a;
        synchronized (g0.class) {
            str = g0.f21493b;
        }
        sb2.append(str);
        sb2.append("]");
        qt.a.y("ExoPlayerImpl", sb2.toString());
        zVar.c3();
        int i11 = qt.x.f27318a;
        if (i11 < 21 && (audioTrack = zVar.f21860r0) != null) {
            audioTrack.release();
            zVar.f21860r0 = null;
        }
        zVar.f21843b0.g();
        zVar.f21845d0.getClass();
        zVar.f21846e0.getClass();
        b bVar = zVar.f21844c0;
        bVar.f21395c = null;
        bVar.a();
        f0 f0Var = zVar.N;
        synchronized (f0Var) {
            if (f0Var.f21448a0 || !f0Var.L.getThread().isAlive()) {
                z11 = true;
            } else {
                f0Var.J.d(7);
                f0Var.g0(new f4.o(5, f0Var), f0Var.W);
                z11 = f0Var.f21448a0;
            }
        }
        if (!z11) {
            zVar.O.g(10, new mp.a(14));
        }
        zVar.O.e();
        zVar.L.f27313a.removeCallbacksAndMessages(null);
        ot.f fVar = zVar.V;
        nr.g gVar = zVar.T;
        CopyOnWriteArrayList<ot.d> copyOnWriteArrayList = (CopyOnWriteArrayList) ((ot.s) fVar).f25117b.f21633d;
        for (ot.d dVar : copyOnWriteArrayList) {
            if (dVar.f25050b == gVar) {
                dVar.f25051c = true;
                copyOnWriteArrayList.remove(dVar);
            }
        }
        n1 n1Var = zVar.J0;
        if (n1Var.f21683o) {
            zVar.J0 = n1Var.a();
        }
        n1 n1VarG = zVar.J0.g(1);
        zVar.J0 = n1VarG;
        n1 n1VarB = n1VarG.b(n1VarG.f21672b);
        zVar.J0 = n1VarB;
        n1VarB.f21684p = n1VarB.f21686r;
        zVar.J0.f21685q = 0L;
        nr.g gVar2 = zVar.T;
        qt.u uVar = gVar2.J;
        qt.a.l(uVar);
        uVar.c(new jk.m0(18, gVar2));
        mt.o oVar = (mt.o) zVar.K;
        synchronized (oVar.f21955d) {
            if (i11 >= 32) {
                try {
                    mt.j jVar = oVar.f21960i;
                    if (jVar != null) {
                        jVar.e();
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        oVar.f21970a = null;
        oVar.f21971b = null;
        zVar.S2();
        Surface surface = zVar.t0;
        if (surface != null) {
            surface.release();
            zVar.t0 = null;
        }
        zVar.E0 = bt.c.f4144e;
    }

    @Override // mr.u1
    public final l2 J() {
        H2();
        return this.f21419i.J();
    }

    public final void J2(o1 o1Var) {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        if (zVar.J0.f21682n.equals(o1Var)) {
            return;
        }
        n1 n1VarF = zVar.J0.f(o1Var);
        zVar.f21851i0++;
        zVar.N.J.a(4, o1Var).b();
        zVar.a3(n1VarF, 0, 1, false, 5, -9223372036854775807L, -1, false);
    }

    @Override // mr.u1
    public final bt.c L() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.E0;
    }

    @Override // k3.e1, mr.u1
    public final int O() {
        H2();
        return this.f21419i.O();
    }

    @Override // k3.e1, mr.u1
    public final int P() {
        H2();
        return this.f21419i.P();
    }

    @Override // k3.e1, mr.u1
    public final void Q(int i11) {
        H2();
        this.f21419i.Q(i11);
    }

    @Override // k3.e1, mr.u1
    public final void R(SurfaceView surfaceView) {
        H2();
        this.f21419i.R(surfaceView);
    }

    @Override // mr.u1
    public final void R0(s1 s1Var) {
        H2();
        this.f21419i.R0(s1Var);
    }

    @Override // k3.e1, mr.u1
    public final int S() {
        H2();
        return this.f21419i.S();
    }

    @Override // k3.e1, mr.u1
    public final int T() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.f21848g0;
    }

    @Override // mr.u1
    public final j2 U() {
        H2();
        return this.f21419i.U();
    }

    @Override // k3.e1, mr.u1
    public final Looper V() {
        H2();
        return this.f21419i.U;
    }

    @Override // k3.e1, mr.u1
    public final boolean W() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.f21849h0;
    }

    @Override // k3.e1, mr.u1
    public final long X() {
        H2();
        return this.f21419i.X();
    }

    @Override // k3.e1, mr.u1
    public final void Y(TextureView textureView) {
        H2();
        this.f21419i.Y(textureView);
    }

    @Override // mr.u1
    public final x0 Z() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.f21858p0;
    }

    @Override // k3.e1, mr.u1
    public final void b() {
        H2();
        this.f21419i.b();
    }

    @Override // k3.e1, mr.u1
    public final long b0() {
        H2();
        return this.f21419i.b0();
    }

    @Override // k3.e1, mr.u1
    public final long c0() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.W;
    }

    @Override // mr.u1
    public final o1 e() {
        H2();
        return this.f21419i.e();
    }

    @Override // mr.u1
    public final void f0(s1 s1Var) {
        H2();
        this.f21419i.f0(s1Var);
    }

    @Override // k3.e1, mr.u1
    public final long getDuration() {
        H2();
        return this.f21419i.getDuration();
    }

    @Override // k3.e1, mr.u1
    public final boolean l() {
        H2();
        return this.f21419i.l();
    }

    @Override // k3.e1, mr.u1
    public final long m() {
        H2();
        return this.f21419i.m();
    }

    @Override // mr.u1
    public final q1 n() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.f21857o0;
    }

    @Override // k3.e1, mr.u1
    public final boolean o() {
        H2();
        return this.f21419i.o();
    }

    @Override // k3.e1, mr.u1
    public final void q(boolean z11) {
        H2();
        this.f21419i.q(z11);
    }

    @Override // mr.u1
    public final void s() {
        H2();
        this.f21419i.c3();
    }

    @Override // k3.e1
    public final void stop() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        zVar.f21844c0.c(1, zVar.o());
        zVar.X2(null);
        hx.w1 w1Var = hx.w1.f14911w;
        long j6 = zVar.J0.f21686r;
        zVar.E0 = new bt.c(w1Var);
    }

    @Override // k3.e1, mr.u1
    public final int t() {
        H2();
        return this.f21419i.t();
    }

    @Override // k3.e1, mr.u1
    public final void u(TextureView textureView) {
        H2();
        this.f21419i.u(textureView);
    }

    @Override // mr.u1
    public final rt.s v() {
        H2();
        z zVar = this.f21419i;
        zVar.c3();
        return zVar.H0;
    }

    @Override // k3.e1, mr.u1
    public final int x() {
        H2();
        return this.f21419i.x();
    }

    @Override // k3.e1, mr.u1
    public final void y(SurfaceView surfaceView) {
        H2();
        this.f21419i.y(surfaceView);
    }
}
