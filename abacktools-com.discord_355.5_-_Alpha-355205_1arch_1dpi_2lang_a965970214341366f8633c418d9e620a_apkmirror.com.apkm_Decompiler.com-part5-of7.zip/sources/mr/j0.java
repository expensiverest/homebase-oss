package mr;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class j0 extends z1 {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final String f21600w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f21601x;
    public static final mp.a y;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f21602i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f21603v;

    static {
        int i11 = qt.x.f27318a;
        f21600w = Integer.toString(1, 36);
        f21601x = Integer.toString(2, 36);
        y = new mp.a(18);
    }

    public j0() {
        this.f21602i = false;
        this.f21603v = false;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof j0)) {
            return false;
        }
        j0 j0Var = (j0) obj;
        return this.f21603v == j0Var.f21603v && this.f21602i == j0Var.f21602i;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Boolean.valueOf(this.f21602i), Boolean.valueOf(this.f21603v)});
    }

    public j0(boolean z11) {
        this.f21602i = true;
        this.f21603v = z11;
    }
}
