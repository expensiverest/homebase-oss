package mr;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes3.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f21398a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ss.p0 f21399b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f21400c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f21401d;

    public b0(ArrayList arrayList, ss.p0 p0Var, int i11, long j6) {
        this.f21398a = arrayList;
        this.f21399b = p0Var;
        this.f21400c = i11;
        this.f21401d = j6;
    }
}
