package mr;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class t1 implements e {
    public final int J;
    public final int K;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f21731d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21732e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final v0 f21733i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Object f21734v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21735w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final long f21736x;
    public final long y;

    static {
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
        Integer.toString(1, 36);
        Integer.toString(2, 36);
        Integer.toString(3, 36);
        Integer.toString(4, 36);
        Integer.toString(5, 36);
        Integer.toString(6, 36);
    }

    public t1(Object obj, int i11, v0 v0Var, Object obj2, int i12, long j6, long j11, int i13, int i14) {
        this.f21731d = obj;
        this.f21732e = i11;
        this.f21733i = v0Var;
        this.f21734v = obj2;
        this.f21735w = i12;
        this.f21736x = j6;
        this.y = j11;
        this.J = i13;
        this.K = i14;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && t1.class == obj.getClass()) {
            t1 t1Var = (t1) obj;
            if (this.f21732e == t1Var.f21732e && this.f21735w == t1Var.f21735w && this.f21736x == t1Var.f21736x && this.y == t1Var.y && this.J == t1Var.J && this.K == t1Var.K && mn.a.u(this.f21731d, t1Var.f21731d) && mn.a.u(this.f21734v, t1Var.f21734v) && mn.a.u(this.f21733i, t1Var.f21733i)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f21731d, Integer.valueOf(this.f21732e), this.f21733i, this.f21734v, Integer.valueOf(this.f21735w), Long.valueOf(this.f21736x), Long.valueOf(this.y), Integer.valueOf(this.J), Integer.valueOf(this.K)});
    }
}
