package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class q0 implements e {
    public static final String J;
    public static final String K;
    public static final String L;
    public static final String M;
    public static final mp.a N;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final q0 f21706x = new q0(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L, -3.4028235E38f, -3.4028235E38f);
    public static final String y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f21707d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f21708e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long f21709i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final float f21710v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final float f21711w;

    static {
        int i11 = qt.x.f27318a;
        y = Integer.toString(0, 36);
        J = Integer.toString(1, 36);
        K = Integer.toString(2, 36);
        L = Integer.toString(3, 36);
        M = Integer.toString(4, 36);
        N = new mp.a(23);
    }

    public q0(long j6, long j11, long j12, float f3, float f11) {
        this.f21707d = j6;
        this.f21708e = j11;
        this.f21709i = j12;
        this.f21710v = f3;
        this.f21711w = f11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q0)) {
            return false;
        }
        q0 q0Var = (q0) obj;
        return this.f21707d == q0Var.f21707d && this.f21708e == q0Var.f21708e && this.f21709i == q0Var.f21709i && this.f21710v == q0Var.f21710v && this.f21711w == q0Var.f21711w;
    }

    public final int hashCode() {
        long j6 = this.f21707d;
        long j11 = this.f21708e;
        int i11 = ((((int) (j6 ^ (j6 >>> 32))) * 31) + ((int) (j11 ^ (j11 >>> 32)))) * 31;
        long j12 = this.f21709i;
        int i12 = (i11 + ((int) ((j12 >>> 32) ^ j12))) * 31;
        float f3 = this.f21710v;
        int iFloatToIntBits = (i12 + (f3 != 0.0f ? Float.floatToIntBits(f3) : 0)) * 31;
        float f11 = this.f21711w;
        return iFloatToIntBits + (f11 != 0.0f ? Float.floatToIntBits(f11) : 0);
    }
}
