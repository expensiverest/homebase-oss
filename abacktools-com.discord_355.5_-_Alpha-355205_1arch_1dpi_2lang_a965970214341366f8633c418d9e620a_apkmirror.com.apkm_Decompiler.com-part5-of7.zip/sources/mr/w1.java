package mr;

import android.os.Looper;
import android.os.SystemClock;
import java.util.concurrent.TimeoutException;

/* JADX INFO: loaded from: classes3.dex */
public final class w1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v1 f21777a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final f0 f21778b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final qt.s f21779c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f21780d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f21781e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Looper f21782f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f21783g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f21784h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f21785i;

    public w1(f0 f0Var, v1 v1Var, j2 j2Var, int i11, qt.s sVar, Looper looper) {
        this.f21778b = f0Var;
        this.f21777a = v1Var;
        this.f21782f = looper;
        this.f21779c = sVar;
    }

    public final synchronized void a(long j6) {
        boolean z11;
        qt.a.k(this.f21783g);
        qt.a.k(this.f21782f.getThread() != Thread.currentThread());
        this.f21779c.getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime() + j6;
        while (true) {
            z11 = this.f21785i;
            if (z11 || j6 <= 0) {
                break;
            }
            this.f21779c.getClass();
            wait(j6);
            this.f21779c.getClass();
            j6 = jElapsedRealtime - SystemClock.elapsedRealtime();
        }
        if (!z11) {
            throw new TimeoutException("Message delivery timed out.");
        }
    }

    public final synchronized void b(boolean z11) {
        this.f21784h = z11 | this.f21784h;
        this.f21785i = true;
        notifyAll();
    }

    public final void c() {
        qt.a.k(!this.f21783g);
        this.f21783g = true;
        f0 f0Var = this.f21778b;
        synchronized (f0Var) {
            if (!f0Var.f21448a0 && f0Var.L.getThread().isAlive()) {
                f0Var.J.a(14, this).b();
                return;
            }
            qt.a.N("ExoPlayerImplInternal", "Ignoring messages sent after release.");
            b(false);
        }
    }
}
