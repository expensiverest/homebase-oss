package mr;

import android.os.SystemClock;
import android.text.TextUtils;
import com.reactnativecommunity.webview.RNCWebViewManager;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class j extends m1 {
    public final ss.r J;
    public final boolean K;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21596i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final String f21597v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21598w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final i0 f21599x;
    public final int y;

    static {
        int i11 = qt.x.f27318a;
        Integer.toString(RNCWebViewManager.COMMAND_CLEAR_CACHE, 36);
        Integer.toString(RNCWebViewManager.COMMAND_CLEAR_HISTORY, 36);
        Integer.toString(1003, 36);
        Integer.toString(1004, 36);
        Integer.toString(1005, 36);
        Integer.toString(1006, 36);
    }

    public j(int i11, Exception exc, int i12) {
        this(i11, exc, i12, null, -1, null, 4, false);
    }

    public final j a(ss.r rVar) {
        String message = getMessage();
        int i11 = qt.x.f27318a;
        return new j(message, getCause(), this.f21660d, this.f21596i, this.f21597v, this.f21598w, this.f21599x, this.y, rVar, this.f21661e, this.K);
    }

    public j(String str, Throwable th2, int i11, int i12, String str2, int i13, i0 i0Var, int i14, ss.r rVar, long j6, boolean z11) {
        super(str, th2, i11, j6);
        qt.a.g(!z11 || i12 == 1);
        qt.a.g(th2 != null || i12 == 3);
        this.f21596i = i12;
        this.f21597v = str2;
        this.f21598w = i13;
        this.f21599x = i0Var;
        this.y = i14;
        this.J = rVar;
        this.K = z11;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public j(int i11, Throwable th2, int i12, String str, int i13, i0 i0Var, int i14, boolean z11) {
        String str2;
        int i15;
        i0 i0Var2;
        String string;
        String str3;
        if (i11 == 0) {
            str2 = str;
            i15 = i13;
            i0Var2 = i0Var;
            string = "Source error";
        } else if (i11 != 1) {
            if (i11 != 3) {
                string = "Unexpected runtime error";
            } else {
                string = "Remote error";
            }
            str2 = str;
            i15 = i13;
            i0Var2 = i0Var;
        } else {
            StringBuilder sb2 = new StringBuilder();
            str2 = str;
            sb2.append(str2);
            sb2.append(" error, index=");
            i15 = i13;
            sb2.append(i15);
            sb2.append(", format=");
            i0Var2 = i0Var;
            sb2.append(i0Var2);
            sb2.append(", format_supported=");
            int i16 = qt.x.f27318a;
            if (i14 == 0) {
                str3 = "NO";
            } else if (i14 == 1) {
                str3 = "NO_UNSUPPORTED_TYPE";
            } else if (i14 == 2) {
                str3 = "NO_UNSUPPORTED_DRM";
            } else if (i14 == 3) {
                str3 = "NO_EXCEEDS_CAPABILITIES";
            } else if (i14 == 4) {
                str3 = "YES";
            } else {
                throw new IllegalStateException();
            }
            sb2.append(str3);
            string = sb2.toString();
        }
        this(TextUtils.isEmpty(null) ? string : x2.g(string, ": null"), th2, i12, i11, str2, i15, i0Var2, i14, null, SystemClock.elapsedRealtime(), z11);
    }
}
