package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class x1 extends ss.i {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final i2 f21821i;

    public x1(j2 j2Var) {
        super(j2Var);
        this.f21821i = new i2();
    }

    @Override // ss.i, mr.j2
    public final h2 f(int i11, h2 h2Var, boolean z11) {
        j2 j2Var = this.f29272e;
        h2 h2VarF = j2Var.f(i11, h2Var, z11);
        if (j2Var.m(h2VarF.f21537i, this.f21821i, 0L).a()) {
            h2VarF.i(h2Var.f21535d, h2Var.f21536e, h2Var.f21537i, h2Var.f21538v, h2Var.f21539w, ts.b.f30643x, true);
            return h2VarF;
        }
        h2VarF.f21540x = true;
        return h2VarF;
    }
}
