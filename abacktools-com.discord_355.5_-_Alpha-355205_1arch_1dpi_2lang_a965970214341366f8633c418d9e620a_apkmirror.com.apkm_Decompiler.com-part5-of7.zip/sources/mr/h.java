package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j4.e f21500a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f21501b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f21502c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f21503d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f21504e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f21505f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f21506g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f21507h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f21508i;

    public h(j4.e eVar, int i11, int i12, int i13, int i14) {
        a("bufferForPlaybackMs", i13, 0, "0");
        a("bufferForPlaybackAfterRebufferMs", i14, 0, "0");
        a("minBufferMs", i11, i13, "bufferForPlaybackMs");
        a("minBufferMs", i11, i14, "bufferForPlaybackAfterRebufferMs");
        a("maxBufferMs", i12, i11, "minBufferMs");
        a("backBufferDurationMs", 0, 0, "0");
        this.f21500a = eVar;
        this.f21501b = qt.x.I(i11);
        this.f21502c = qt.x.I(i12);
        this.f21503d = qt.x.I(i13);
        this.f21504e = qt.x.I(i14);
        this.f21505f = -1;
        this.f21507h = 13107200;
        this.f21506g = qt.x.I(0);
    }

    public static void a(String str, int i11, int i12, String str2) {
        qt.a.f(str + " cannot be less than " + str2, i11 >= i12);
    }

    public final void b(boolean z11) {
        int i11 = this.f21505f;
        if (i11 == -1) {
            i11 = 13107200;
        }
        this.f21507h = i11;
        this.f21508i = false;
        if (z11) {
            j4.e eVar = this.f21500a;
            synchronized (eVar) {
                if (eVar.f17865b) {
                    eVar.c(0);
                }
            }
        }
    }

    public final boolean c(long j6, float f3) {
        int i11;
        long j11 = this.f21502c;
        j4.e eVar = this.f21500a;
        synchronized (eVar) {
            i11 = eVar.f17868e * eVar.f17866c;
        }
        boolean z11 = i11 >= this.f21507h;
        long jMin = this.f21501b;
        if (f3 > 1.0f) {
            jMin = Math.min(qt.x.u(jMin, f3), j11);
        }
        if (j6 < Math.max(jMin, 500000L)) {
            this.f21508i = !z11;
            if (z11 && j6 < 500000) {
                qt.a.N("DefaultLoadControl", "Target buffer size reached with less than 500ms of buffered media data.");
            }
        } else if (j6 >= j11 || z11) {
            this.f21508i = false;
        }
        return this.f21508i;
    }
}
