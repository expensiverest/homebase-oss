package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class r1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final qt.e f21721a;

    public r1(qt.e eVar) {
        this.f21721a = eVar;
    }

    public final boolean a(int... iArr) {
        for (int i11 : iArr) {
            if (this.f21721a.f27261a.get(i11)) {
                return true;
            }
        }
        return false;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof r1) {
            return this.f21721a.equals(((r1) obj).f21721a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f21721a.hashCode();
    }
}
