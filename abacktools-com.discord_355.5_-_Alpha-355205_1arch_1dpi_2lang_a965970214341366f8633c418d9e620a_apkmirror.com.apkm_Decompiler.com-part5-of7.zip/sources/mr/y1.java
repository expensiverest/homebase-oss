package mr;

import android.util.Pair;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes3.dex */
public final class y1 extends j2 {
    public static final /* synthetic */ int M = 0;
    public final j2[] J;
    public final Object[] K;
    public final HashMap L;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21837e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ss.p0 f21838i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f21839v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21840w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int[] f21841x;
    public final int[] y;

    /* JADX WARN: Illegal instructions before constructor call */
    public y1(ArrayList arrayList, ss.p0 p0Var) {
        j2[] j2VarArr = new j2[arrayList.size()];
        Iterator it = arrayList.iterator();
        int i11 = 0;
        int i12 = 0;
        while (it.hasNext()) {
            j2VarArr[i12] = ((b1) it.next()).b();
            i12++;
        }
        Object[] objArr = new Object[arrayList.size()];
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            objArr[i11] = ((b1) it2.next()).a();
            i11++;
        }
        this(j2VarArr, objArr, p0Var);
    }

    @Override // mr.j2
    public final int a(boolean z11) {
        if (this.f21837e != 0) {
            int iQ = 0;
            if (z11) {
                int[] iArr = this.f21838i.f29317b;
                iQ = iArr.length > 0 ? iArr[0] : -1;
            }
            do {
                j2[] j2VarArr = this.J;
                if (!j2VarArr[iQ].p()) {
                    return j2VarArr[iQ].a(z11) + this.y[iQ];
                }
                iQ = q(iQ, z11);
            } while (iQ != -1);
        }
        return -1;
    }

    @Override // mr.j2
    public final int b(Object obj) {
        int iB;
        if (obj instanceof Pair) {
            Pair pair = (Pair) obj;
            Object obj2 = pair.first;
            Object obj3 = pair.second;
            Integer num = (Integer) this.L.get(obj2);
            int iIntValue = num == null ? -1 : num.intValue();
            if (iIntValue != -1 && (iB = this.J[iIntValue].b(obj3)) != -1) {
                return this.f21841x[iIntValue] + iB;
            }
        }
        return -1;
    }

    @Override // mr.j2
    public final int c(boolean z11) {
        int iR;
        int i11 = this.f21837e;
        if (i11 != 0) {
            if (z11) {
                int[] iArr = this.f21838i.f29317b;
                iR = iArr.length > 0 ? iArr[iArr.length - 1] : -1;
            } else {
                iR = i11 - 1;
            }
            do {
                j2[] j2VarArr = this.J;
                if (!j2VarArr[iR].p()) {
                    return j2VarArr[iR].c(z11) + this.y[iR];
                }
                iR = r(iR, z11);
            } while (iR != -1);
        }
        return -1;
    }

    @Override // mr.j2
    public final int e(int i11, int i12, boolean z11) {
        int[] iArr = this.y;
        int iD = qt.x.d(iArr, i11 + 1, false, false);
        int i13 = iArr[iD];
        j2[] j2VarArr = this.J;
        int iE = j2VarArr[iD].e(i11 - i13, i12 != 2 ? i12 : 0, z11);
        if (iE != -1) {
            return i13 + iE;
        }
        int iQ = q(iD, z11);
        while (iQ != -1 && j2VarArr[iQ].p()) {
            iQ = q(iQ, z11);
        }
        if (iQ != -1) {
            return j2VarArr[iQ].a(z11) + iArr[iQ];
        }
        if (i12 == 2) {
            return a(z11);
        }
        return -1;
    }

    @Override // mr.j2
    public final h2 f(int i11, h2 h2Var, boolean z11) {
        int[] iArr = this.f21841x;
        int iD = qt.x.d(iArr, i11 + 1, false, false);
        int i12 = this.y[iD];
        this.J[iD].f(i11 - iArr[iD], h2Var, z11);
        h2Var.f21537i += i12;
        if (z11) {
            Object obj = this.K[iD];
            Object obj2 = h2Var.f21536e;
            obj2.getClass();
            h2Var.f21536e = Pair.create(obj, obj2);
        }
        return h2Var;
    }

    @Override // mr.j2
    public final h2 g(Object obj, h2 h2Var) {
        Pair pair = (Pair) obj;
        Object obj2 = pair.first;
        Object obj3 = pair.second;
        Integer num = (Integer) this.L.get(obj2);
        int iIntValue = num == null ? -1 : num.intValue();
        int i11 = this.y[iIntValue];
        this.J[iIntValue].g(obj3, h2Var);
        h2Var.f21537i += i11;
        h2Var.f21536e = obj;
        return h2Var;
    }

    @Override // mr.j2
    public final int h() {
        return this.f21840w;
    }

    @Override // mr.j2
    public final int k(int i11, int i12, boolean z11) {
        int[] iArr = this.y;
        int iD = qt.x.d(iArr, i11 + 1, false, false);
        int i13 = iArr[iD];
        j2[] j2VarArr = this.J;
        int iK = j2VarArr[iD].k(i11 - i13, i12 != 2 ? i12 : 0, z11);
        if (iK != -1) {
            return i13 + iK;
        }
        int iR = r(iD, z11);
        while (iR != -1 && j2VarArr[iR].p()) {
            iR = r(iR, z11);
        }
        if (iR != -1) {
            return j2VarArr[iR].c(z11) + iArr[iR];
        }
        if (i12 == 2) {
            return c(z11);
        }
        return -1;
    }

    @Override // mr.j2
    public final Object l(int i11) {
        int[] iArr = this.f21841x;
        int iD = qt.x.d(iArr, i11 + 1, false, false);
        return Pair.create(this.K[iD], this.J[iD].l(i11 - iArr[iD]));
    }

    @Override // mr.j2
    public final i2 m(int i11, i2 i2Var, long j6) {
        int[] iArr = this.y;
        int iD = qt.x.d(iArr, i11 + 1, false, false);
        int i12 = iArr[iD];
        int i13 = this.f21841x[iD];
        this.J[iD].m(i11 - i12, i2Var, j6);
        Object objCreate = this.K[iD];
        if (!i2.T.equals(i2Var.f21590d)) {
            objCreate = Pair.create(objCreate, i2Var.f21590d);
        }
        i2Var.f21590d = objCreate;
        i2Var.Q += i13;
        i2Var.R += i13;
        return i2Var;
    }

    @Override // mr.j2
    public final int o() {
        return this.f21839v;
    }

    public final int q(int i11, boolean z11) {
        if (!z11) {
            if (i11 < this.f21837e - 1) {
                return i11 + 1;
            }
            return -1;
        }
        ss.p0 p0Var = this.f21838i;
        int i12 = p0Var.f29318c[i11] + 1;
        int[] iArr = p0Var.f29317b;
        if (i12 < iArr.length) {
            return iArr[i12];
        }
        return -1;
    }

    public final int r(int i11, boolean z11) {
        if (!z11) {
            if (i11 > 0) {
                return i11 - 1;
            }
            return -1;
        }
        ss.p0 p0Var = this.f21838i;
        int i12 = p0Var.f29318c[i11] - 1;
        if (i12 >= 0) {
            return p0Var.f29317b[i12];
        }
        return -1;
    }

    public y1(j2[] j2VarArr, Object[] objArr, ss.p0 p0Var) {
        this.f21838i = p0Var;
        this.f21837e = p0Var.f29317b.length;
        int length = j2VarArr.length;
        this.J = j2VarArr;
        this.f21841x = new int[length];
        this.y = new int[length];
        this.K = objArr;
        this.L = new HashMap();
        int length2 = j2VarArr.length;
        int i11 = 0;
        int iO = 0;
        int iH = 0;
        int i12 = 0;
        while (i11 < length2) {
            j2 j2Var = j2VarArr[i11];
            this.J[i12] = j2Var;
            this.y[i12] = iO;
            this.f21841x[i12] = iH;
            iO += j2Var.o();
            iH += this.J[i12].h();
            this.L.put(objArr[i12], Integer.valueOf(i12));
            i11++;
            i12++;
        }
        this.f21839v = iO;
        this.f21840w = iH;
    }
}
