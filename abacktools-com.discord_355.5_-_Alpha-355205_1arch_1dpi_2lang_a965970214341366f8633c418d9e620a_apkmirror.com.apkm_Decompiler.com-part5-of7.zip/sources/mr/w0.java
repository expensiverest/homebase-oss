package mr;

import android.net.Uri;
import android.os.Bundle;

/* JADX INFO: loaded from: classes3.dex */
public final class w0 {
    public Integer A;
    public Integer B;
    public CharSequence C;
    public CharSequence D;
    public CharSequence E;
    public Integer F;
    public Bundle G;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CharSequence f21754a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f21755b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f21756c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f21757d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CharSequence f21758e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public CharSequence f21759f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public CharSequence f21760g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public z1 f21761h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public z1 f21762i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public byte[] f21763j;
    public Integer k;
    public Uri l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Integer f21764m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Integer f21765n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Integer f21766o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Boolean f21767p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Boolean f21768q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Integer f21769r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Integer f21770s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public Integer f21771t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Integer f21772u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Integer f21773v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Integer f21774w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public CharSequence f21775x;
    public CharSequence y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public CharSequence f21776z;

    public final void a(byte[] bArr, int i11) {
        if (this.f21763j != null) {
            Integer numValueOf = Integer.valueOf(i11);
            int i12 = qt.x.f27318a;
            if (!numValueOf.equals(3) && qt.x.a(this.k, 3)) {
                return;
            }
        }
        this.f21763j = (byte[]) bArr.clone();
        this.k = Integer.valueOf(i11);
    }
}
