package mr;

import android.net.Uri;
import com.facebook.imageutils.JfifUtil;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/* JADX INFO: loaded from: classes3.dex */
public final class i2 implements e {
    public static final Object T = new Object();
    public static final Object U = new Object();
    public static final v0 V;
    public static final String W;
    public static final String X;
    public static final String Y;
    public static final String Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public static final String f21581a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public static final String f21582b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public static final String f21583c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public static final String f21584d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public static final String f21585e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public static final String f21586f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public static final String f21587g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public static final String f21588h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public static final String f21589i0;
    public boolean J;
    public boolean K;
    public boolean L;
    public q0 M;
    public boolean N;
    public long O;
    public long P;
    public int Q;
    public int R;
    public long S;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f21591e;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Object f21593v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f21594w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public long f21595x;
    public long y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f21590d = T;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public v0 f21592i = V;

    static {
        r0 r0Var;
        m0 m0Var = new m0();
        k3.e0 e0Var = new k3.e0();
        e0Var.f18576c = hx.b2.y;
        hx.k0 k0Var = hx.m0.f14841e;
        hx.w1 w1Var = hx.w1.f14911w;
        e0Var.f18580g = w1Var;
        List list = Collections.EMPTY_LIST;
        s0 s0Var = s0.f21725i;
        Uri uri = Uri.EMPTY;
        qt.a.k(((Uri) e0Var.f18575b) == null || ((UUID) e0Var.f18574a) != null);
        if (uri != null) {
            r0Var = new r0(uri, null, ((UUID) e0Var.f18574a) != null ? new p0(e0Var) : null, null, list, null, w1Var);
        } else {
            r0Var = null;
        }
        V = new v0("com.google.android.exoplayer2.Timeline", new o0(m0Var), r0Var, new q0(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L, -3.4028235E38f, -3.4028235E38f), x0.f21790k0, s0Var);
        int i11 = qt.x.f27318a;
        W = Integer.toString(1, 36);
        X = Integer.toString(2, 36);
        Y = Integer.toString(3, 36);
        Z = Integer.toString(4, 36);
        f21581a0 = Integer.toString(5, 36);
        f21582b0 = Integer.toString(6, 36);
        f21583c0 = Integer.toString(7, 36);
        f21584d0 = Integer.toString(8, 36);
        f21585e0 = Integer.toString(9, 36);
        f21586f0 = Integer.toString(10, 36);
        f21587g0 = Integer.toString(11, 36);
        f21588h0 = Integer.toString(12, 36);
        f21589i0 = Integer.toString(13, 36);
    }

    public final boolean a() {
        qt.a.k(this.L == (this.M != null));
        return this.M != null;
    }

    public final void b(Object obj, v0 v0Var, Object obj2, long j6, long j11, long j12, boolean z11, boolean z12, q0 q0Var, long j13, long j14, int i11, int i12, long j15) {
        this.f21590d = obj;
        this.f21592i = v0Var != null ? v0Var : V;
        if (v0Var != null) {
            r0 r0Var = v0Var.f21748e;
        }
        this.f21591e = null;
        this.f21593v = obj2;
        this.f21594w = j6;
        this.f21595x = j11;
        this.y = j12;
        this.J = z11;
        this.K = z12;
        this.L = q0Var != null;
        this.M = q0Var;
        this.O = j13;
        this.P = j14;
        this.Q = i11;
        this.R = i12;
        this.S = j15;
        this.N = false;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && i2.class.equals(obj.getClass())) {
            i2 i2Var = (i2) obj;
            if (qt.x.a(this.f21590d, i2Var.f21590d) && qt.x.a(this.f21592i, i2Var.f21592i) && qt.x.a(this.f21593v, i2Var.f21593v) && qt.x.a(this.M, i2Var.M) && this.f21594w == i2Var.f21594w && this.f21595x == i2Var.f21595x && this.y == i2Var.y && this.J == i2Var.J && this.K == i2Var.K && this.N == i2Var.N && this.O == i2Var.O && this.P == i2Var.P && this.Q == i2Var.Q && this.R == i2Var.R && this.S == i2Var.S) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = (this.f21592i.hashCode() + ((this.f21590d.hashCode() + JfifUtil.MARKER_EOI) * 31)) * 31;
        Object obj = this.f21593v;
        int iHashCode2 = (iHashCode + (obj == null ? 0 : obj.hashCode())) * 31;
        q0 q0Var = this.M;
        int iHashCode3 = (iHashCode2 + (q0Var != null ? q0Var.hashCode() : 0)) * 31;
        long j6 = this.f21594w;
        int i11 = (iHashCode3 + ((int) (j6 ^ (j6 >>> 32)))) * 31;
        long j11 = this.f21595x;
        int i12 = (i11 + ((int) (j11 ^ (j11 >>> 32)))) * 31;
        long j12 = this.y;
        int i13 = (((((((i12 + ((int) (j12 ^ (j12 >>> 32)))) * 31) + (this.J ? 1 : 0)) * 31) + (this.K ? 1 : 0)) * 31) + (this.N ? 1 : 0)) * 31;
        long j13 = this.O;
        int i14 = (i13 + ((int) (j13 ^ (j13 >>> 32)))) * 31;
        long j14 = this.P;
        int i15 = (((((i14 + ((int) (j14 ^ (j14 >>> 32)))) * 31) + this.Q) * 31) + this.R) * 31;
        long j15 = this.S;
        return i15 + ((int) (j15 ^ (j15 >>> 32)));
    }
}
