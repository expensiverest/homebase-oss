package mr;

import android.net.Uri;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/* JADX INFO: loaded from: classes3.dex */
public final class v0 implements e {
    public static final v0 J;
    public static final String K;
    public static final String L;
    public static final String M;
    public static final String N;
    public static final String O;
    public static final String P;
    public static final mp.a Q;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f21747d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final r0 f21748e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final r0 f21749i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final q0 f21750v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final x0 f21751w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final o0 f21752x;
    public final s0 y;

    static {
        m0 m0Var = new m0();
        hx.k0 k0Var = hx.m0.f14841e;
        hx.w1 w1Var = hx.w1.f14911w;
        List list = Collections.EMPTY_LIST;
        J = new v0("", new o0(m0Var), null, new q0(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L, -3.4028235E38f, -3.4028235E38f), x0.f21790k0, s0.f21725i);
        int i11 = qt.x.f27318a;
        K = Integer.toString(0, 36);
        L = Integer.toString(1, 36);
        M = Integer.toString(2, 36);
        N = Integer.toString(3, 36);
        O = Integer.toString(4, 36);
        P = Integer.toString(5, 36);
        Q = new mp.a(19);
    }

    public v0(String str, o0 o0Var, r0 r0Var, q0 q0Var, x0 x0Var, s0 s0Var) {
        this.f21747d = str;
        this.f21748e = r0Var;
        this.f21749i = r0Var;
        this.f21750v = q0Var;
        this.f21751w = x0Var;
        this.f21752x = o0Var;
        this.y = s0Var;
    }

    public static v0 a(String str) {
        r0 r0Var;
        m0 m0Var = new m0();
        k3.e0 e0Var = new k3.e0();
        e0Var.f18576c = hx.b2.y;
        hx.k0 k0Var = hx.m0.f14841e;
        hx.w1 w1Var = hx.w1.f14911w;
        e0Var.f18580g = w1Var;
        List list = Collections.EMPTY_LIST;
        s0 s0Var = s0.f21725i;
        Uri uri = str == null ? null : Uri.parse(str);
        qt.a.k(((Uri) e0Var.f18575b) == null || ((UUID) e0Var.f18574a) != null);
        if (uri != null) {
            r0Var = new r0(uri, null, ((UUID) e0Var.f18574a) != null ? new p0(e0Var) : null, null, list, null, w1Var);
        } else {
            r0Var = null;
        }
        return new v0("", new o0(m0Var), r0Var, new q0(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L, -3.4028235E38f, -3.4028235E38f), x0.f21790k0, s0Var);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof v0)) {
            return false;
        }
        v0 v0Var = (v0) obj;
        return qt.x.a(this.f21747d, v0Var.f21747d) && this.f21752x.equals(v0Var.f21752x) && qt.x.a(this.f21748e, v0Var.f21748e) && qt.x.a(this.f21750v, v0Var.f21750v) && qt.x.a(this.f21751w, v0Var.f21751w) && qt.x.a(this.y, v0Var.y);
    }

    public final int hashCode() {
        int iHashCode = this.f21747d.hashCode() * 31;
        r0 r0Var = this.f21748e;
        return this.y.hashCode() + ((this.f21751w.hashCode() + ((this.f21752x.hashCode() + ((this.f21750v.hashCode() + ((iHashCode + (r0Var != null ? r0Var.hashCode() : 0)) * 31)) * 31)) * 31)) * 31);
    }
}
