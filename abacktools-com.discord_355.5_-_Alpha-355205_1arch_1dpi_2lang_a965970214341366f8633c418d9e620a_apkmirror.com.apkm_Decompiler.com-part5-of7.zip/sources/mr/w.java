package mr;

import android.graphics.SurfaceTexture;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.TextureView;

/* JADX INFO: loaded from: classes3.dex */
public final class w implements SurfaceHolder.Callback, TextureView.SurfaceTextureListener {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ z f21753d;

    public w(z zVar) {
        this.f21753d = zVar;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i11, int i12) {
        Surface surface = new Surface(surfaceTexture);
        z zVar = this.f21753d;
        zVar.W2(surface);
        zVar.t0 = surface;
        zVar.Q2(i11, i12);
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        z zVar = this.f21753d;
        zVar.W2(null);
        zVar.Q2(0, 0);
        return true;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i11, int i12) {
        this.f21753d.Q2(i11, i12);
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i11, int i12, int i13) {
        this.f21753d.Q2(i12, i13);
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        z zVar = this.f21753d;
        if (zVar.f21866w0) {
            zVar.W2(surfaceHolder.getSurface());
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        z zVar = this.f21753d;
        if (zVar.f21866w0) {
            zVar.W2(null);
        }
        zVar.Q2(0, 0);
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
    }
}
