package mr;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class l1 extends z1 {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String f21648v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final mp.a f21649w;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final float f21650i;

    static {
        int i11 = qt.x.f27318a;
        f21648v = Integer.toString(1, 36);
        f21649w = new mp.a(28);
    }

    public l1() {
        this.f21650i = -1.0f;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof l1) {
            return this.f21650i == ((l1) obj).f21650i;
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f21650i)});
    }

    public l1(float f3) {
        qt.a.f("percent must be in the range of [0, 100]", f3 >= 0.0f && f3 <= 100.0f);
        this.f21650i = f3;
    }
}
