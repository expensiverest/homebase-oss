package mr;

import android.os.Bundle;
import com.discord.age_assurance.DigitalCredentialModule;
import com.swmansion.gesturehandler.react.RNGestureHandlerButtonViewManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerDetectorViewManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerRootViewManager;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import javax.inject.Provider;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class d2 implements d, Provider, nv.d, qt.g, qt.h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21432d;

    public /* synthetic */ d2(int i11) {
        this.f21432d = i11;
    }

    @Override // qt.h
    public void a(Object obj, qt.e eVar) {
    }

    @Override // mr.d
    public e e(Bundle bundle) {
        switch (this.f21432d) {
            case 0:
                qt.a.g(bundle.getInt(z1.f21880d, -1) == 2);
                int i11 = bundle.getInt(e2.f21439w, 5);
                float f3 = bundle.getFloat(e2.f21440x, -1.0f);
                return f3 == -1.0f ? new e2(i11) : new e2(f3, i11);
            case 1:
                qt.a.g(bundle.getInt(z1.f21880d, -1) == 3);
                return bundle.getBoolean(f2.f21475w, false) ? new f2(bundle.getBoolean(f2.f21476x, false)) : new f2();
            case 2:
                int i12 = bundle.getInt(h2.J, 0);
                long j6 = bundle.getLong(h2.K, -9223372036854775807L);
                long j11 = bundle.getLong(h2.L, 0L);
                boolean z11 = bundle.getBoolean(h2.M, false);
                Bundle bundle2 = bundle.getBundle(h2.N);
                ts.b bVar = bundle2 != null ? (ts.b) ts.b.N.e(bundle2) : ts.b.f30643x;
                h2 h2Var = new h2();
                h2Var.i(null, null, i12, j6, j11, bVar, z11);
                return h2Var;
            case 3:
                Bundle bundle3 = bundle.getBundle(i2.W);
                v0 v0Var = bundle3 != null ? (v0) v0.Q.e(bundle3) : v0.J;
                long j12 = bundle.getLong(i2.X, -9223372036854775807L);
                long j13 = bundle.getLong(i2.Y, -9223372036854775807L);
                long j14 = bundle.getLong(i2.Z, -9223372036854775807L);
                boolean z12 = bundle.getBoolean(i2.f21581a0, false);
                boolean z13 = bundle.getBoolean(i2.f21582b0, false);
                Bundle bundle4 = bundle.getBundle(i2.f21583c0);
                q0 q0Var = bundle4 != null ? (q0) q0.N.e(bundle4) : null;
                boolean z14 = bundle.getBoolean(i2.f21584d0, false);
                long j15 = bundle.getLong(i2.f21585e0, 0L);
                long j16 = bundle.getLong(i2.f21586f0, -9223372036854775807L);
                int i13 = bundle.getInt(i2.f21587g0, 0);
                int i14 = bundle.getInt(i2.f21588h0, 0);
                long j17 = bundle.getLong(i2.f21589i0, 0L);
                i2 i2Var = new i2();
                i2Var.b(i2.U, v0Var, null, j12, j13, j14, z12, z13, q0Var, j15, j16, i13, i14, j17);
                i2Var.N = z14;
                return i2Var;
            case 4:
                ox.h hVar = ss.v0.J;
                Bundle bundle5 = bundle.getBundle(k2.f21636x);
                bundle5.getClass();
                ss.v0 v0Var2 = (ss.v0) hVar.e(bundle5);
                int[] intArray = bundle.getIntArray(k2.y);
                int i15 = v0Var2.f29349d;
                int[] iArr = new int[i15];
                if (intArray == null) {
                    intArray = iArr;
                }
                boolean[] booleanArray = bundle.getBooleanArray(k2.J);
                boolean[] zArr = new boolean[i15];
                if (booleanArray == null) {
                    booleanArray = zArr;
                }
                return new k2(v0Var2, bundle.getBoolean(k2.K, false), intArray, booleanArray);
            default:
                int i16 = bundle.getInt(mt.i.f21937v, -1);
                int[] intArray2 = bundle.getIntArray(mt.i.f21938w);
                int i17 = bundle.getInt(mt.i.f21939x, -1);
                qt.a.g(i16 >= 0 && i17 >= 0);
                intArray2.getClass();
                return new mt.i(i16, i17, intArray2);
        }
    }

    @Override // javax.inject.Provider
    public Object get() {
        switch (this.f21432d) {
            case 7:
                return new RNGestureHandlerRootViewManager();
            case 8:
                return new RNGestureHandlerButtonViewManager();
            default:
                return new RNGestureHandlerDetectorViewManager();
        }
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        nr.b bVar = (nr.b) obj;
        switch (this.f21432d) {
            case 11:
                bVar.getClass();
                break;
            case 12:
                bVar.getClass();
                break;
            case 13:
                bVar.getClass();
                break;
            case 14:
                bVar.getClass();
                break;
            case 15:
                bVar.getClass();
                break;
            case 16:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                bVar.getClass();
                break;
            case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                bVar.getClass();
                break;
            case 27:
            default:
                bVar.getClass();
                break;
            case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                bVar.getClass();
                break;
        }
    }

    @Override // nv.d
    public void s(Exception exc) {
        nf.a aVar = nf.a.f23220a;
        nf.a.c(exc.getClass().getSimpleName(), "Fetching FCM registration token failed", exc);
    }
}
