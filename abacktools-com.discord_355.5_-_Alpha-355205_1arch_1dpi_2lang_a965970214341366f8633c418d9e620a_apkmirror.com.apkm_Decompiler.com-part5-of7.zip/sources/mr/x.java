package mr;

import android.media.MediaFormat;

/* JADX INFO: loaded from: classes3.dex */
public final class x implements rt.l, st.a, v1 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public rt.l f21786d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public st.a f21787e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public rt.l f21788i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public st.a f21789v;

    @Override // st.a
    public final void a(long j6, float[] fArr) {
        st.a aVar = this.f21789v;
        if (aVar != null) {
            aVar.a(j6, fArr);
        }
        st.a aVar2 = this.f21787e;
        if (aVar2 != null) {
            aVar2.a(j6, fArr);
        }
    }

    @Override // st.a
    public final void b() {
        st.a aVar = this.f21789v;
        if (aVar != null) {
            aVar.b();
        }
        st.a aVar2 = this.f21787e;
        if (aVar2 != null) {
            aVar2.b();
        }
    }

    @Override // mr.v1
    public final void c(int i11, Object obj) {
        if (i11 == 7) {
            this.f21786d = (rt.l) obj;
            return;
        }
        if (i11 == 8) {
            this.f21787e = (st.a) obj;
            return;
        }
        if (i11 != 10000) {
            return;
        }
        st.h hVar = (st.h) obj;
        if (hVar == null) {
            this.f21788i = null;
            this.f21789v = null;
        } else {
            this.f21788i = hVar.getVideoFrameMetadataListener();
            this.f21789v = hVar.getCameraMotionListener();
        }
    }

    @Override // rt.l
    public final void d(long j6, long j11, i0 i0Var, MediaFormat mediaFormat) {
        long j12;
        long j13;
        i0 i0Var2;
        MediaFormat mediaFormat2;
        rt.l lVar = this.f21788i;
        if (lVar != null) {
            lVar.d(j6, j11, i0Var, mediaFormat);
            mediaFormat2 = mediaFormat;
            i0Var2 = i0Var;
            j13 = j11;
            j12 = j6;
        } else {
            j12 = j6;
            j13 = j11;
            i0Var2 = i0Var;
            mediaFormat2 = mediaFormat;
        }
        rt.l lVar2 = this.f21786d;
        if (lVar2 != null) {
            lVar2.d(j12, j13, i0Var2, mediaFormat2);
        }
    }
}
