package mr;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes3.dex */
public final class i1 implements b1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ss.o f21576a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f21579d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f21580e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f21578c = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f21577b = new Object();

    public i1(ss.a aVar, boolean z11) {
        this.f21576a = new ss.o(aVar, z11);
    }

    @Override // mr.b1
    public final Object a() {
        return this.f21577b;
    }

    @Override // mr.b1
    public final j2 b() {
        return this.f21576a.Q;
    }
}
