package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class h1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ss.a f21532a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c1 f21533b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final k7.l f21534c;

    public h1(ss.a aVar, c1 c1Var, k7.l lVar) {
        this.f21532a = aVar;
        this.f21533b = c1Var;
        this.f21534c = lVar;
    }
}
