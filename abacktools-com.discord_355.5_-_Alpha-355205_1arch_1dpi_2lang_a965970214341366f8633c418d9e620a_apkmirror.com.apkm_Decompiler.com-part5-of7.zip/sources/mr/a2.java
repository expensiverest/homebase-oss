package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class a2 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a2 f21391b = new a2(false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f21392a;

    public a2(boolean z11) {
        this.f21392a = z11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && a2.class == obj.getClass() && this.f21392a == ((a2) obj).f21392a;
    }

    public final int hashCode() {
        return !this.f21392a ? 1 : 0;
    }
}
