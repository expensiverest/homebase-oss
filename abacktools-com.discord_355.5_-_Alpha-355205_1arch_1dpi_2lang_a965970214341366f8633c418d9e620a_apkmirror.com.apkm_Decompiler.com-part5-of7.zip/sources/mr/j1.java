package mr;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.internal.fido.f8;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import k3.n1;

/* JADX INFO: loaded from: classes3.dex */
public final class j1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f21604a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f21605b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f21606c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f21607d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f21608e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Object f21609f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Object f21610g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Object f21611h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Object f21612i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Object f21613j;
    public final Object k;
    public Object l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Object f21614m;

    public j1() {
        this.f21604a = 1;
        this.f21606c = new e8.b[4];
        this.f21607d = new Matrix[4];
        this.f21608e = new Matrix[4];
        this.f21609f = new PointF();
        this.f21610g = new Path();
        this.f21611h = new Path();
        this.f21612i = new e8.b();
        this.f21613j = new float[2];
        this.k = new float[2];
        this.l = new Path();
        this.f21614m = new Path();
        this.f21605b = true;
        for (int i11 = 0; i11 < 4; i11++) {
            ((e8.b[]) this.f21606c)[i11] = new e8.b();
            ((Matrix[]) this.f21607d)[i11] = new Matrix();
            ((Matrix[]) this.f21608e)[i11] = new Matrix();
        }
    }

    public k3.n1 a(int i11, ArrayList arrayList, f4.h1 h1Var) {
        ArrayList arrayList2 = (ArrayList) this.f21607d;
        if (!arrayList.isEmpty()) {
            this.f21614m = h1Var;
            for (int i12 = i11; i12 < arrayList.size() + i11; i12++) {
                v3.w0 w0Var = (v3.w0) arrayList.get(i12 - i11);
                if (i12 > 0) {
                    v3.w0 w0Var2 = (v3.w0) arrayList2.get(i12 - 1);
                    w0Var.f32151d = w0Var2.f32148a.f11362o.f11277e.o() + w0Var2.f32151d;
                    w0Var.f32152e = false;
                    w0Var.f32150c.clear();
                } else {
                    w0Var.f32151d = 0;
                    w0Var.f32152e = false;
                    w0Var.f32150c.clear();
                }
                int iO = w0Var.f32148a.f11362o.f11277e.o();
                for (int i13 = i12; i13 < arrayList2.size(); i13++) {
                    ((v3.w0) arrayList2.get(i13)).f32151d += iO;
                }
                arrayList2.add(i12, w0Var);
                ((HashMap) this.f21609f).put(w0Var.f32149b, w0Var);
                if (this.f21605b) {
                    k(w0Var);
                    if (((IdentityHashMap) this.f21608e).isEmpty()) {
                        ((HashSet) this.f21612i).add(w0Var);
                    } else {
                        v3.v0 v0Var = (v3.v0) ((HashMap) this.f21610g).get(w0Var);
                        if (v0Var != null) {
                            v0Var.f32116a.c(v0Var.f32117b);
                        }
                    }
                }
            }
        }
        return d();
    }

    public j2 b(int i11, ArrayList arrayList, ss.p0 p0Var) {
        ArrayList arrayList2 = (ArrayList) this.f21607d;
        if (!arrayList.isEmpty()) {
            this.l = p0Var;
            for (int i12 = i11; i12 < arrayList.size() + i11; i12++) {
                i1 i1Var = (i1) arrayList.get(i12 - i11);
                if (i12 > 0) {
                    i1 i1Var2 = (i1) arrayList2.get(i12 - 1);
                    i1Var.f21579d = i1Var2.f21576a.Q.f29272e.o() + i1Var2.f21579d;
                    i1Var.f21580e = false;
                    i1Var.f21578c.clear();
                } else {
                    i1Var.f21579d = 0;
                    i1Var.f21580e = false;
                    i1Var.f21578c.clear();
                }
                int iO = i1Var.f21576a.Q.f29272e.o();
                for (int i13 = i12; i13 < arrayList2.size(); i13++) {
                    ((i1) arrayList2.get(i13)).f21579d += iO;
                }
                arrayList2.add(i12, i1Var);
                ((HashMap) this.f21609f).put(i1Var.f21577b, i1Var);
                if (this.f21605b) {
                    j(i1Var);
                    if (((IdentityHashMap) this.f21608e).isEmpty()) {
                        ((HashSet) this.f21612i).add(i1Var);
                    } else {
                        h1 h1Var = (h1) ((HashMap) this.f21610g).get(i1Var);
                        if (h1Var != null) {
                            h1Var.f21532a.c(h1Var.f21533b);
                        }
                    }
                }
            }
        }
        return e();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void c(nw.l lVar, float[] fArr, float f3, RectF rectF, k0 k0Var, Path path) {
        int i11;
        char c11;
        nw.f fVar;
        k0 k0Var2;
        char c12;
        nw.d cVar;
        com.facebook.imagepipeline.nativecode.b bVar;
        k0 k0Var3 = k0Var;
        Matrix[] matrixArr = (Matrix[]) this.f21608e;
        float[] fArr2 = (float[]) this.f21613j;
        e8.b[] bVarArr = (e8.b[]) this.f21606c;
        Matrix[] matrixArr2 = (Matrix[]) this.f21607d;
        path.rewind();
        Path path2 = (Path) this.f21610g;
        path2.rewind();
        Path path3 = (Path) this.f21611h;
        path3.rewind();
        path3.addRect(rectF, Path.Direction.CW);
        int i12 = 0;
        while (true) {
            c11 = 0;
            if (i12 >= 4) {
                break;
            }
            PointF pointF = (PointF) this.f21609f;
            if (fArr != null) {
                cVar = new nw.c(fArr[i12]);
            } else if (i12 == 1) {
                cVar = lVar.f23592g;
            } else if (i12 != 2) {
                cVar = i12 != 3 ? lVar.f23591f : lVar.f23590e;
            } else {
                cVar = lVar.f23593h;
            }
            if (i12 == 1) {
                bVar = lVar.f23588c;
            } else if (i12 != 2) {
                bVar = i12 != 3 ? lVar.f23587b : lVar.f23586a;
            } else {
                bVar = lVar.f23589d;
            }
            e8.b bVar2 = bVarArr[i12];
            bVar.getClass();
            Matrix[] matrixArr3 = matrixArr;
            bVar.C(bVar2, f3, cVar.a(rectF));
            int i13 = i12 + 1;
            float f11 = (i13 % 4) * 90;
            matrixArr2[i12].reset();
            if (i12 == 1) {
                pointF.set(rectF.right, rectF.bottom);
            } else if (i12 == 2) {
                pointF.set(rectF.left, rectF.bottom);
            } else if (i12 != 3) {
                pointF.set(rectF.right, rectF.top);
            } else {
                pointF.set(rectF.left, rectF.top);
            }
            matrixArr2[i12].setTranslate(pointF.x, pointF.y);
            matrixArr2[i12].preRotate(f11);
            e8.b bVar3 = bVarArr[i12];
            fArr2[0] = bVar3.f10325b;
            fArr2[1] = bVar3.f10326c;
            matrixArr2[i12].mapPoints(fArr2);
            matrixArr3[i12].reset();
            matrixArr3[i12].setTranslate(fArr2[0], fArr2[1]);
            matrixArr3[i12].preRotate(f11);
            i12 = i13;
            matrixArr = matrixArr3;
        }
        Matrix[] matrixArr4 = matrixArr;
        int i14 = 0;
        for (i11 = 4; i14 < i11; i11 = 4) {
            e8.b bVar4 = bVarArr[i14];
            bVar4.getClass();
            fArr2[c11] = 0.0f;
            fArr2[1] = bVar4.f10324a;
            matrixArr2[i14].mapPoints(fArr2);
            if (i14 == 0) {
                path.moveTo(fArr2[c11], fArr2[1]);
            } else {
                path.lineTo(fArr2[c11], fArr2[1]);
            }
            bVarArr[i14].b(matrixArr2[i14], path);
            if (k0Var3 != null) {
                e8.b bVar5 = bVarArr[i14];
                Matrix matrix = matrixArr2[i14];
                nw.i iVar = (nw.i) k0Var3.f21633d;
                BitSet bitSet = iVar.f23583w;
                bVar5.getClass();
                bitSet.set(i14, (boolean) c11);
                nw.t[] tVarArr = iVar.f23581i;
                bVar5.a(bVar5.f10328e);
                tVarArr[i14] = new nw.n(new ArrayList((ArrayList) bVar5.f10330g), new Matrix(matrix));
            }
            Path path4 = (Path) this.l;
            e8.b bVar6 = (e8.b) this.f21612i;
            int i15 = i14 + 1;
            int i16 = i15 % 4;
            e8.b bVar7 = bVarArr[i14];
            fArr2[0] = bVar7.f10325b;
            fArr2[1] = bVar7.f10326c;
            matrixArr2[i14].mapPoints(fArr2);
            float[] fArr3 = (float[]) this.k;
            e8.b bVar8 = bVarArr[i16];
            bVar8.getClass();
            fArr3[0] = 0.0f;
            fArr3[1] = bVar8.f10324a;
            matrixArr2[i16].mapPoints(fArr3);
            e8.b[] bVarArr2 = bVarArr;
            Matrix[] matrixArr5 = matrixArr2;
            float fMax = Math.max(((float) Math.hypot(fArr2[0] - fArr3[0], fArr2[1] - fArr3[1])) - 0.001f, 0.0f);
            e8.b bVar9 = bVarArr2[i14];
            fArr2[0] = bVar9.f10325b;
            fArr2[1] = bVar9.f10326c;
            matrixArr5[i14].mapPoints(fArr2);
            if (i14 == 1 || i14 == 3) {
                Math.abs(rectF.centerX() - fArr2[0]);
            } else {
                Math.abs(rectF.centerY() - fArr2[1]);
            }
            bVar6.d(0.0f, 270.0f, 0.0f);
            if (i14 == 1) {
                fVar = lVar.k;
            } else if (i14 != 2) {
                fVar = i14 != 3 ? lVar.f23595j : lVar.f23594i;
            } else {
                fVar = lVar.l;
            }
            fVar.getClass();
            bVar6.c(fMax, 0.0f);
            path4.reset();
            bVar6.b(matrixArr4[i14], path4);
            if (this.f21605b && (i(path4, i14) || i(path4, i16))) {
                path4.op(path4, path3, Path.Op.DIFFERENCE);
                fArr2[0] = 0.0f;
                fArr2[1] = bVar6.f10324a;
                matrixArr4[i14].mapPoints(fArr2);
                path2.moveTo(fArr2[0], fArr2[1]);
                bVar6.b(matrixArr4[i14], path2);
            } else {
                bVar6.b(matrixArr4[i14], path);
            }
            if (k0Var != null) {
                Matrix matrix2 = matrixArr4[i14];
                k0Var2 = k0Var;
                nw.i iVar2 = (nw.i) k0Var2.f21633d;
                c12 = 0;
                iVar2.f23583w.set(i14 + 4, false);
                nw.t[] tVarArr2 = iVar2.f23582v;
                bVar6.a(bVar6.f10328e);
                tVarArr2[i14] = new nw.n(new ArrayList((ArrayList) bVar6.f10330g), new Matrix(matrix2));
            } else {
                k0Var2 = k0Var;
                c12 = 0;
            }
            c11 = c12;
            k0Var3 = k0Var2;
            i14 = i15;
            bVarArr = bVarArr2;
            matrixArr2 = matrixArr5;
        }
        path.close();
        path2.close();
        if (path2.isEmpty()) {
            return;
        }
        path.op(path2, Path.Op.UNION);
    }

    public k3.n1 d() {
        ArrayList arrayList = (ArrayList) this.f21607d;
        if (arrayList.isEmpty()) {
            return k3.n1.f18741a;
        }
        int iO = 0;
        for (int i11 = 0; i11 < arrayList.size(); i11++) {
            v3.w0 w0Var = (v3.w0) arrayList.get(i11);
            w0Var.f32151d = iO;
            iO += w0Var.f32148a.f11362o.f11277e.o();
        }
        return new v3.c1(arrayList, (f4.h1) this.f21614m);
    }

    public j2 e() {
        ArrayList arrayList = (ArrayList) this.f21607d;
        if (arrayList.isEmpty()) {
            return j2.f21615d;
        }
        int iO = 0;
        for (int i11 = 0; i11 < arrayList.size(); i11++) {
            i1 i1Var = (i1) arrayList.get(i11);
            i1Var.f21579d = iO;
            iO += i1Var.f21576a.Q.f29272e.o();
        }
        return new y1(arrayList, (ss.p0) this.l);
    }

    public void f() {
        switch (this.f21604a) {
            case 0:
                Iterator it = ((HashSet) this.f21612i).iterator();
                while (it.hasNext()) {
                    i1 i1Var = (i1) it.next();
                    if (i1Var.f21578c.isEmpty()) {
                        h1 h1Var = (h1) ((HashMap) this.f21610g).get(i1Var);
                        if (h1Var != null) {
                            h1Var.f21532a.c(h1Var.f21533b);
                        }
                        it.remove();
                    }
                }
                break;
            default:
                Iterator it2 = ((HashSet) this.f21612i).iterator();
                while (it2.hasNext()) {
                    v3.w0 w0Var = (v3.w0) it2.next();
                    if (w0Var.f32150c.isEmpty()) {
                        v3.v0 v0Var = (v3.v0) ((HashMap) this.f21610g).get(w0Var);
                        if (v0Var != null) {
                            v0Var.f32116a.c(v0Var.f32117b);
                        }
                        it2.remove();
                    }
                }
                break;
        }
    }

    public void g(i1 i1Var) {
        if (i1Var.f21580e && i1Var.f21578c.isEmpty()) {
            h1 h1Var = (h1) ((HashMap) this.f21610g).remove(i1Var);
            h1Var.getClass();
            k7.l lVar = h1Var.f21534c;
            ss.a aVar = h1Var.f21532a;
            aVar.o(h1Var.f21533b);
            aVar.r(lVar);
            aVar.q(lVar);
            ((HashSet) this.f21612i).remove(i1Var);
        }
    }

    public void h(v3.w0 w0Var) {
        if (w0Var.f32152e && w0Var.f32150c.isEmpty()) {
            v3.v0 v0Var = (v3.v0) ((HashMap) this.f21610g).remove(w0Var);
            v0Var.getClass();
            v3.u0 u0Var = v0Var.f32118c;
            f4.a aVar = v0Var.f32116a;
            aVar.o(v0Var.f32117b);
            aVar.r(u0Var);
            aVar.q(u0Var);
            ((HashSet) this.f21612i).remove(w0Var);
        }
    }

    public boolean i(Path path, int i11) {
        Path path2 = (Path) this.f21614m;
        path2.reset();
        ((e8.b[]) this.f21606c)[i11].b(((Matrix[]) this.f21607d)[i11], path2);
        RectF rectF = new RectF();
        path.computeBounds(rectF, true);
        path2.computeBounds(rectF, true);
        path.op(path2, Path.Op.INTERSECT);
        path.computeBounds(rectF, true);
        return !rectF.isEmpty() || (rectF.width() > 1.0f && rectF.height() > 1.0f);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [mr.c1, ss.t] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public void j(i1 i1Var) {
        ss.o oVar = i1Var.f21576a;
        ?? r11 = new ss.t() { // from class: mr.c1
            @Override // ss.t
            public final void a(ss.a aVar, j2 j2Var) {
                ((f0) this.f21418a.f21611h).J.d(22);
            }
        };
        k7.l lVar = new k7.l(this, i1Var, false);
        ((HashMap) this.f21610g).put(i1Var, new h1(oVar, r11, lVar));
        int i11 = qt.x.f27318a;
        Looper looperMyLooper = Looper.myLooper();
        if (looperMyLooper == null) {
            looperMyLooper = Looper.getMainLooper();
        }
        Handler handler = new Handler(looperMyLooper, null);
        oVar.getClass();
        f8 f8Var = oVar.f29215i;
        f8Var.getClass();
        CopyOnWriteArrayList copyOnWriteArrayList = (CopyOnWriteArrayList) f8Var.f6588v;
        ss.v vVar = new ss.v();
        vVar.f29346a = handler;
        vVar.f29347b = lVar;
        copyOnWriteArrayList.add(vVar);
        Looper looperMyLooper2 = Looper.myLooper();
        if (looperMyLooper2 == null) {
            looperMyLooper2 = Looper.getMainLooper();
        }
        Handler handler2 = new Handler(looperMyLooper2, null);
        sr.m mVar = oVar.f29216v;
        mVar.getClass();
        CopyOnWriteArrayList copyOnWriteArrayList2 = mVar.f29199c;
        sr.l lVar2 = new sr.l();
        lVar2.f29195a = handler2;
        lVar2.f29196b = lVar;
        copyOnWriteArrayList2.add(lVar2);
        oVar.k(r11, (ot.v0) this.f21614m, (nr.p) this.f21606c);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [f4.e0, v3.p0] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public void k(v3.w0 w0Var) {
        f4.y yVar = w0Var.f32148a;
        ?? r11 = new f4.e0() { // from class: v3.p0
            @Override // f4.e0
            public final void a(f4.a aVar, n1 n1Var) {
                n3.g0 g0Var = ((e0) this.f32083a.f21613j).y;
                g0Var.g(2);
                g0Var.h(22);
            }
        };
        v3.u0 u0Var = new v3.u0(this, w0Var);
        ((HashMap) this.f21610g).put(w0Var, new v3.v0(yVar, r11, u0Var));
        Handler handler = new Handler(n3.l0.y(), null);
        yVar.getClass();
        f8 f8Var = yVar.f11089c;
        f8Var.getClass();
        CopyOnWriteArrayList copyOnWriteArrayList = (CopyOnWriteArrayList) f8Var.f6588v;
        f4.i0 i0Var = new f4.i0();
        i0Var.f11175a = handler;
        i0Var.f11176b = u0Var;
        copyOnWriteArrayList.add(i0Var);
        Handler handler2 = new Handler(n3.l0.y(), null);
        y3.j jVar = yVar.f11090d;
        jVar.getClass();
        CopyOnWriteArrayList copyOnWriteArrayList2 = jVar.f35768c;
        y3.i iVar = new y3.i();
        iVar.f35764a = handler2;
        iVar.f35765b = u0Var;
        copyOnWriteArrayList2.add(iVar);
        yVar.k(r11, (w3.n) this.f21606c, (j4.d) this.f21611h);
    }

    public void l(ss.q qVar) {
        IdentityHashMap identityHashMap = (IdentityHashMap) this.f21608e;
        i1 i1Var = (i1) identityHashMap.remove(qVar);
        i1Var.getClass();
        i1Var.f21576a.n(qVar);
        i1Var.f21578c.remove(((ss.l) qVar).f29283d);
        if (!identityHashMap.isEmpty()) {
            f();
        }
        g(i1Var);
    }

    public void m(int i11, int i12) {
        switch (this.f21604a) {
            case 0:
                ArrayList arrayList = (ArrayList) this.f21607d;
                for (int i13 = i12 - 1; i13 >= i11; i13--) {
                    i1 i1Var = (i1) arrayList.remove(i13);
                    ((HashMap) this.f21609f).remove(i1Var.f21577b);
                    int i14 = -i1Var.f21576a.Q.f29272e.o();
                    for (int i15 = i13; i15 < arrayList.size(); i15++) {
                        ((i1) arrayList.get(i15)).f21579d += i14;
                    }
                    i1Var.f21580e = true;
                    if (this.f21605b) {
                        g(i1Var);
                    }
                }
                break;
            default:
                ArrayList arrayList2 = (ArrayList) this.f21607d;
                for (int i16 = i12 - 1; i16 >= i11; i16--) {
                    v3.w0 w0Var = (v3.w0) arrayList2.remove(i16);
                    ((HashMap) this.f21609f).remove(w0Var.f32149b);
                    int i17 = -w0Var.f32148a.f11362o.f11277e.o();
                    for (int i18 = i16; i18 < arrayList2.size(); i18++) {
                        ((v3.w0) arrayList2.get(i18)).f32151d += i17;
                    }
                    w0Var.f32152e = true;
                    if (this.f21605b) {
                        h(w0Var);
                    }
                }
                break;
        }
    }

    public j1(v3.e0 e0Var, w3.e eVar, n3.g0 g0Var, w3.n nVar, j4.d dVar) {
        this.f21604a = 2;
        this.f21606c = nVar;
        this.f21611h = dVar;
        this.f21613j = e0Var;
        this.f21614m = new f4.h1();
        this.f21608e = new IdentityHashMap();
        this.f21609f = new HashMap();
        this.f21607d = new ArrayList();
        this.k = eVar;
        this.l = g0Var;
        this.f21610g = new HashMap();
        this.f21612i = new HashSet();
    }

    public j1(f0 f0Var, nr.g gVar, qt.u uVar, nr.p pVar) {
        this.f21604a = 0;
        this.f21606c = pVar;
        this.f21611h = f0Var;
        this.l = new ss.p0();
        this.f21608e = new IdentityHashMap();
        this.f21609f = new HashMap();
        this.f21607d = new ArrayList();
        this.f21613j = gVar;
        this.k = uVar;
        this.f21610g = new HashMap();
        this.f21612i = new HashSet();
    }
}
