package mr;

/* JADX INFO: loaded from: classes3.dex */
public abstract class m1 extends Exception implements e {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21660d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f21661e;

    static {
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
        Integer.toString(1, 36);
        Integer.toString(2, 36);
        Integer.toString(3, 36);
        Integer.toString(4, 36);
    }

    public m1(String str, Throwable th2, int i11, long j6) {
        super(str, th2);
        this.f21660d = i11;
        this.f21661e = j6;
    }
}
