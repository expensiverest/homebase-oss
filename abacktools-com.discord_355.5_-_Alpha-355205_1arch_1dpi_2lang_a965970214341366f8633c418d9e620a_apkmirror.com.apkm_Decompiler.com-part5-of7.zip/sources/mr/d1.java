package mr;

import android.util.Pair;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class d1 implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21427d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ k7.l f21428e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Pair f21429i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ ss.k f21430v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ f4.z f21431w;

    public /* synthetic */ d1(k7.l lVar, Pair pair, ss.k kVar, f4.z zVar, int i11) {
        this.f21427d = i11;
        this.f21428e = lVar;
        this.f21429i = pair;
        this.f21430v = kVar;
        this.f21431w = zVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f21427d) {
            case 0:
                nr.g gVar = (nr.g) ((j1) this.f21428e.f19343e).f21613j;
                Pair pair = this.f21429i;
                gVar.E(((Integer) pair.first).intValue(), (ss.s) pair.second, this.f21430v, this.f21431w);
                break;
            case 1:
                nr.g gVar2 = (nr.g) ((j1) this.f21428e.f19343e).f21613j;
                Pair pair2 = this.f21429i;
                gVar2.s(((Integer) pair2.first).intValue(), (ss.s) pair2.second, this.f21430v, this.f21431w);
                break;
            default:
                nr.g gVar3 = (nr.g) ((j1) this.f21428e.f19343e).f21613j;
                Pair pair3 = this.f21429i;
                gVar3.J(((Integer) pair3.first).intValue(), (ss.s) pair3.second, this.f21430v, this.f21431w);
                break;
        }
    }
}
