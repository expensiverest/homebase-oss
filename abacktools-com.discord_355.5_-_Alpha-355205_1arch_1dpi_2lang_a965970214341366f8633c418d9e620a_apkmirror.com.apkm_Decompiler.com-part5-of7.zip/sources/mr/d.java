package mr;

import android.os.Bundle;

/* JADX INFO: loaded from: classes3.dex */
public interface d {
    e e(Bundle bundle);
}
