package mr;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class n implements qt.g, n3.n, n3.j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21662d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ float f21663e;

    public /* synthetic */ n(float f3, int i11) {
        this.f21662d = i11;
        this.f21663e = f3;
    }

    @Override // n3.j
    public void accept(Object obj) {
        switch (this.f21662d) {
            case 2:
                ((y5.w1) obj).E(this.f21663e);
                break;
            default:
                ((y5.w1) obj).D(this.f21663e);
                break;
        }
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        switch (this.f21662d) {
            case 0:
                ((s1) obj).f(this.f21663e);
                break;
            default:
                ((k3.c1) obj).f(this.f21663e);
                break;
        }
    }
}
