package mr;

import android.util.SparseBooleanArray;

/* JADX INFO: loaded from: classes3.dex */
public final class q1 implements e {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final qt.e f21712d;

    static {
        SparseBooleanArray sparseBooleanArray = new SparseBooleanArray();
        qt.a.k(!false);
        new qt.e(sparseBooleanArray);
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
    }

    public q1(qt.e eVar) {
        this.f21712d = eVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof q1) {
            return this.f21712d.equals(((q1) obj).f21712d);
        }
        return false;
    }

    public final int hashCode() {
        return this.f21712d.hashCode();
    }
}
