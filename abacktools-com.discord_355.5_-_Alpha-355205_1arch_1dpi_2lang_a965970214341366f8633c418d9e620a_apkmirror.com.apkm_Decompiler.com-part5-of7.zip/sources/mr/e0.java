package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j2 f21433a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f21434b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f21435c;

    public e0(j2 j2Var, int i11, long j6) {
        this.f21433a = j2Var;
        this.f21434b = i11;
        this.f21435c = j6;
    }
}
