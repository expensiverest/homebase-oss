package mr;

import android.os.Looper;
import android.util.Pair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes3.dex */
public final class y0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f21824a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f21825b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ss.m0[] f21826c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f21827d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f21828e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public z0 f21829f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f21830g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean[] f21831h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final c[] f21832i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final mt.t f21833j;
    public final j1 k;
    public y0 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public ss.w0 f21834m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public mt.x f21835n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f21836o;

    public y0(c[] cVarArr, long j6, mt.t tVar, j4.e eVar, j1 j1Var, z0 z0Var, mt.x xVar) {
        this.f21832i = cVarArr;
        this.f21836o = j6;
        this.f21833j = tVar;
        this.k = j1Var;
        ss.s sVar = z0Var.f21871a;
        this.f21825b = sVar.f29324a;
        this.f21829f = z0Var;
        this.f21834m = ss.w0.f29354v;
        this.f21835n = xVar;
        this.f21826c = new ss.m0[cVarArr.length];
        this.f21831h = new boolean[cVarArr.length];
        long j11 = z0Var.f21872b;
        long j12 = z0Var.f21874d;
        j1Var.getClass();
        Object obj = sVar.f29324a;
        int i11 = y1.M;
        Pair pair = (Pair) obj;
        Object obj2 = pair.first;
        ss.s sVarB = sVar.b(pair.second);
        i1 i1Var = (i1) ((HashMap) j1Var.f21609f).get(obj2);
        i1Var.getClass();
        ((HashSet) j1Var.f21612i).add(i1Var);
        h1 h1Var = (h1) ((HashMap) j1Var.f21610g).get(i1Var);
        if (h1Var != null) {
            h1Var.f21532a.e(h1Var.f21533b);
        }
        i1Var.f21578c.add(sVarB);
        ss.q qVarB = i1Var.f21576a.b(sVarB, eVar, j11);
        ((IdentityHashMap) j1Var.f21608e).put(qVarB, i1Var);
        j1Var.f();
        this.f21824a = j12 != -9223372036854775807L ? new ss.d(qVarB, j12) : qVarB;
    }

    /* JADX WARN: Type inference failed for: r9v0, types: [java.lang.Object, ss.q] */
    public final long a(mt.x xVar, long j6, boolean z11, boolean[] zArr) {
        c[] cVarArr;
        ss.m0[] m0VarArr;
        int i11 = 0;
        while (true) {
            boolean z12 = true;
            if (i11 >= xVar.f22004a) {
                break;
            }
            if (z11 || !xVar.a(this.f21835n, i11)) {
                z12 = false;
            }
            this.f21831h[i11] = z12;
            i11++;
        }
        int i12 = 0;
        while (true) {
            cVarArr = this.f21832i;
            int length = cVarArr.length;
            m0VarArr = this.f21826c;
            if (i12 >= length) {
                break;
            }
            if (cVarArr[i12].f21406e == -2) {
                m0VarArr[i12] = null;
            }
            i12++;
        }
        b();
        this.f21835n = xVar;
        c();
        long jR = this.f21824a.r(xVar.f22006c, this.f21831h, this.f21826c, zArr, j6);
        for (int i13 = 0; i13 < cVarArr.length; i13++) {
            if (cVarArr[i13].f21406e == -2 && this.f21835n.b(i13)) {
                m0VarArr[i13] = new ss.h();
            }
        }
        this.f21828e = false;
        for (int i14 = 0; i14 < m0VarArr.length; i14++) {
            if (m0VarArr[i14] != null) {
                qt.a.k(xVar.b(i14));
                if (cVarArr[i14].f21406e != -2) {
                    this.f21828e = true;
                }
            } else {
                qt.a.k(xVar.f22006c[i14] == null);
            }
        }
        return jR;
    }

    public final void b() {
        if (this.l != null) {
            return;
        }
        int i11 = 0;
        while (true) {
            mt.x xVar = this.f21835n;
            if (i11 >= xVar.f22004a) {
                return;
            }
            boolean zB = xVar.b(i11);
            mt.q qVar = this.f21835n.f22006c[i11];
            if (zB && qVar != null) {
                qVar.disable();
            }
            i11++;
        }
    }

    public final void c() {
        if (this.l != null) {
            return;
        }
        int i11 = 0;
        while (true) {
            mt.x xVar = this.f21835n;
            if (i11 >= xVar.f22004a) {
                return;
            }
            boolean zB = xVar.b(i11);
            mt.q qVar = this.f21835n.f22006c[i11];
            if (zB && qVar != null) {
                qVar.enable();
            }
            i11++;
        }
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Object, ss.o0] */
    public final long d() {
        if (!this.f21827d) {
            return this.f21829f.f21872b;
        }
        long jN = this.f21828e ? this.f21824a.n() : Long.MIN_VALUE;
        return jN == Long.MIN_VALUE ? this.f21829f.f21875e : jN;
    }

    public final long e() {
        return this.f21829f.f21872b + this.f21836o;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void f() {
        b();
        ?? r11 = this.f21824a;
        try {
            boolean z11 = r11 instanceof ss.d;
            j1 j1Var = this.k;
            if (z11) {
                j1Var.l(((ss.d) r11).f29230d);
            } else {
                j1Var.l(r11);
            }
        } catch (RuntimeException e4) {
            qt.a.s("MediaPeriodHolder", "Period release failed.", e4);
        }
    }

    /* JADX WARN: Code duplicated, block: B:132:0x030c  */
    /* JADX WARN: Multi-variable type inference failed */
    public final mt.x g(float f3, j2 j2Var) {
        mt.h hVar;
        int i11;
        boolean z11;
        String str;
        boolean z12;
        hx.w1 w1VarV;
        boolean z13;
        int i12;
        mt.q bVar;
        int i13;
        int[] iArr;
        Object obj;
        mt.p pVar;
        int i14;
        ss.v0 v0Var;
        int i15;
        mt.j jVar;
        int[] iArr2;
        mt.t tVar = this.f21833j;
        c[] cVarArr = this.f21832i;
        ss.w0 w0Var = this.f21834m;
        tVar.getClass();
        int i16 = 1;
        int[] iArr3 = new int[cVarArr.length + 1];
        int length = cVarArr.length + 1;
        ss.v0[][] v0VarArr = new ss.v0[length][];
        int[][][] iArr4 = new int[cVarArr.length + 1][][];
        for (int i17 = 0; i17 < length; i17++) {
            int i18 = w0Var.f29356d;
            v0VarArr[i17] = new ss.v0[i18];
            iArr4[i17] = new int[i18][];
        }
        int length2 = cVarArr.length;
        int[] iArr5 = new int[length2];
        for (int i19 = 0; i19 < length2; i19++) {
            iArr5[i19] = cVarArr[i19].z();
        }
        int i21 = 0;
        while (i21 < w0Var.f29356d) {
            ss.v0 v0VarA = w0Var.a(i21);
            int i22 = v0VarA.f29351i == 5 ? i16 : 0;
            int length3 = cVarArr.length;
            int i23 = i16;
            int i24 = 0;
            int i25 = 0;
            while (i24 < cVarArr.length) {
                c cVar = cVarArr[i24];
                mt.t tVar2 = tVar;
                int i26 = i16;
                int iMax = 0;
                for (int i27 = 0; i27 < v0VarA.f29349d; i27++) {
                    iMax = Math.max(iMax, cVar.y(v0VarA.f29352v[i27]) & 7);
                }
                int i28 = iArr3[i24] == 0 ? i26 : 0;
                if (iMax > i25 || (iMax == i25 && i22 != 0 && i23 == 0 && i28 != 0)) {
                    i25 = iMax;
                    i23 = i28;
                    length3 = i24;
                }
                i24++;
                i16 = i26;
                tVar = tVar2;
            }
            mt.t tVar3 = tVar;
            int i29 = i16;
            if (length3 == cVarArr.length) {
                iArr2 = new int[v0VarA.f29349d];
            } else {
                c cVar2 = cVarArr[length3];
                int[] iArr6 = new int[v0VarA.f29349d];
                for (int i31 = 0; i31 < v0VarA.f29349d; i31++) {
                    iArr6[i31] = cVar2.y(v0VarA.f29352v[i31]);
                }
                iArr2 = iArr6;
            }
            int i32 = iArr3[length3];
            v0VarArr[length3][i32] = v0VarA;
            iArr4[length3][i32] = iArr2;
            iArr3[length3] = i32 + 1;
            i21++;
            i16 = i29;
            tVar = tVar3;
        }
        mt.t tVar4 = tVar;
        int i33 = i16;
        int i34 = 0;
        ss.w0[] w0VarArr = new ss.w0[cVarArr.length];
        String[] strArr = new String[cVarArr.length];
        int[] iArr7 = new int[cVarArr.length];
        for (int i35 = 0; i35 < cVarArr.length; i35++) {
            int i36 = iArr3[i35];
            w0VarArr[i35] = new ss.w0((ss.v0[]) qt.x.K(i36, v0VarArr[i35]));
            iArr4[i35] = (int[][]) qt.x.K(i36, iArr4[i35]);
            strArr[i35] = cVarArr[i35].h();
            iArr7[i35] = cVarArr[i35].f21406e;
        }
        mt.s sVar = new mt.s(iArr7, w0VarArr, iArr5, iArr4, new ss.w0((ss.v0[]) qt.x.K(iArr3[cVarArr.length], v0VarArr[cVarArr.length])));
        mt.o oVar = (mt.o) tVar4;
        synchronized (oVar.f21955d) {
            try {
                hVar = oVar.f21959h;
                i11 = 32;
                if (hVar.f21930l0 && qt.x.f27318a >= 32 && (jVar = oVar.f21960i) != null) {
                    Looper looperMyLooper = Looper.myLooper();
                    qt.a.l(looperMyLooper);
                    jVar.b(oVar, looperMyLooper);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        int i37 = sVar.f21964a;
        mt.p[] pVarArr = new mt.p[i37];
        int i38 = 2;
        Pair pairG = mt.o.g(2, sVar, iArr4, new l5.g(i38, hVar, iArr5), new a4.h(23));
        if (pairG != null) {
            pVarArr[((Integer) pairG.second).intValue()] = (mt.p) pairG.first;
        }
        int i39 = 0;
        while (true) {
            if (i39 >= sVar.f21964a) {
                z11 = 0;
                break;
            }
            if (2 == iArr7[i39] && w0VarArr[i39].f29356d > 0) {
                z11 = i33;
                break;
            }
            i39++;
        }
        char c11 = 24;
        Pair pairG2 = mt.o.g(i33, sVar, iArr4, new com.google.firebase.messaging.i(oVar, hVar, z11), new a4.h(24));
        if (pairG2 != null) {
            pVarArr[((Integer) pairG2.second).intValue()] = (mt.p) pairG2.first;
        }
        if (pairG2 == null) {
            str = null;
        } else {
            mt.p pVar2 = (mt.p) pairG2.first;
            str = pVar2.f21962a.f29352v[pVar2.f21963b[0]].f21570i;
        }
        int i40 = 3;
        Pair pairG3 = mt.o.g(3, sVar, iArr4, new l5.g(i40, hVar, str), new a4.h(25));
        if (pairG3 != null) {
            pVarArr[((Integer) pairG3.second).intValue()] = (mt.p) pairG3.first;
        }
        int i41 = 0;
        while (i41 < i37) {
            int i42 = iArr7[i41];
            if (i42 == i38 || i42 == 1 || i42 == i40) {
                i14 = i41;
            } else {
                ss.w0 w0Var2 = w0VarArr[i41];
                int[][] iArr8 = iArr4[i41];
                int i43 = i34;
                ss.v0 v0Var2 = null;
                mt.f fVar = null;
                int i44 = i43;
                while (i44 < w0Var2.f29356d) {
                    ss.v0 v0VarA2 = w0Var2.a(i44);
                    int[] iArr9 = iArr8[i44];
                    mt.f fVar2 = fVar;
                    int i45 = i43;
                    ss.v0 v0Var3 = v0Var2;
                    int i46 = i34;
                    while (i46 < v0VarA2.f29349d) {
                        int i47 = i41;
                        if (mt.o.d(iArr9[i46], hVar.f21931m0)) {
                            v0Var = v0VarA2;
                            mt.f fVar3 = new mt.f(v0VarA2.f29352v[i46], iArr9[i46]);
                            if (fVar2 != null) {
                                i15 = i44;
                                if (hx.a0.f14763a.c(fVar3.f21919e, fVar2.f21919e).c(fVar3.f21918d, fVar2.f21918d).e() > 0) {
                                }
                            } else {
                                i15 = i44;
                            }
                            fVar2 = fVar3;
                            i45 = i46;
                            v0Var3 = v0Var;
                        } else {
                            v0Var = v0VarA2;
                            i15 = i44;
                        }
                        i46++;
                        i41 = i47;
                        v0VarA2 = v0Var;
                        i44 = i15;
                    }
                    i44++;
                    v0Var2 = v0Var3;
                    i43 = i45;
                    fVar = fVar2;
                }
                i14 = i41;
                pVarArr[i14] = v0Var2 == null ? null : new mt.p(i34, v0Var2, new int[]{i43});
            }
            i41 = i14 + 1;
            c11 = c11;
            i11 = i11;
            i34 = 0;
            i38 = 2;
            i40 = 3;
        }
        int i48 = i11;
        Object obj2 = null;
        int i49 = sVar.f21964a;
        ss.w0[] w0VarArr2 = sVar.f21966c;
        HashMap map = new HashMap();
        for (int i51 = 0; i51 < i49; i51++) {
            mt.o.a(w0VarArr2[i51], hVar, map);
        }
        mt.o.a(sVar.f21969f, hVar, map);
        for (int i52 = 0; i52 < i49; i52++) {
        }
        int i53 = sVar.f21964a;
        for (int i54 = 0; i54 < i53; i54++) {
            ss.w0 w0Var3 = sVar.f21966c[i54];
            Map map2 = (Map) hVar.f21935q0.get(i54);
            if (map2 != null && map2.containsKey(w0Var3)) {
                Map map3 = (Map) hVar.f21935q0.get(i54);
                mt.i iVar = map3 != null ? (mt.i) map3.get(w0Var3) : null;
                if (iVar != null) {
                    int[] iArr10 = iVar.f21941e;
                    if (iArr10.length != 0) {
                        pVar = new mt.p(iVar.f21942i, w0Var3.a(iVar.f21940d), iArr10);
                    } else {
                        pVar = null;
                    }
                } else {
                    pVar = null;
                }
                pVarArr[i54] = pVar;
            }
        }
        for (int i55 = 0; i55 < i37; i55++) {
            int i56 = sVar.f21965b[i55];
            if (hVar.f21936r0.get(i55) || hVar.f21997b0.contains(Integer.valueOf(i56))) {
                pVarArr[i55] = null;
            }
        }
        cl.a aVar = oVar.f21957f;
        ot.f fVar4 = oVar.f21971b;
        qt.a.l(fVar4);
        aVar.getClass();
        ArrayList arrayList = new ArrayList();
        int i57 = 0;
        while (i57 < pVarArr.length) {
            mt.p pVar3 = pVarArr[i57];
            if (pVar3 == null || pVar3.f21963b.length <= 1) {
                obj = obj2;
                arrayList.add(obj);
            } else {
                hx.j0 j0VarP = hx.m0.p();
                j0VarP.c(new mt.a(0L, 0L));
                arrayList.add(j0VarP);
                obj = obj2;
            }
            i57++;
            obj2 = obj;
        }
        int length4 = pVarArr.length;
        long[][] jArr = new long[length4][];
        for (int i58 = 0; i58 < pVarArr.length; i58++) {
            mt.p pVar4 = pVarArr[i58];
            if (pVar4 == null) {
                jArr[i58] = new long[0];
            } else {
                int[] iArr11 = pVar4.f21963b;
                jArr[i58] = new long[iArr11.length];
                for (int i59 = 0; i59 < iArr11.length; i59++) {
                    long j6 = pVar4.f21962a.f29352v[iArr11[i59]].J;
                    long[] jArr2 = jArr[i58];
                    if (j6 == -1) {
                        j6 = 0;
                    }
                    jArr2[i59] = j6;
                }
                Arrays.sort(jArr[i58]);
            }
        }
        int[] iArr12 = new int[length4];
        long[] jArr3 = new long[length4];
        for (int i61 = 0; i61 < length4; i61++) {
            long[] jArr4 = jArr[i61];
            jArr3[i61] = jArr4.length == 0 ? 0L : jArr4[0];
        }
        mt.b.t(arrayList, jArr3);
        hx.s.g(2, "expectedValuesPerKey");
        TreeMap treeMap = new TreeMap(hx.r1.f14867e);
        hx.n1 n1Var = new hx.n1();
        hx.o1 o1Var = new hx.o1(treeMap);
        o1Var.y = n1Var;
        int i62 = 0;
        while (i62 < length4) {
            long[] jArr5 = jArr[i62];
            if (jArr5.length <= 1) {
                i13 = length4;
                iArr = iArr12;
            } else {
                int length5 = jArr5.length;
                double[] dArr = new double[length5];
                int i63 = 0;
                while (true) {
                    long[] jArr6 = jArr[i62];
                    i13 = length4;
                    double dLog = 0.0d;
                    if (i63 >= jArr6.length) {
                        break;
                    }
                    int[] iArr13 = iArr12;
                    long j11 = jArr6[i63];
                    if (j11 != -1) {
                        dLog = Math.log(j11);
                    }
                    dArr[i63] = dLog;
                    i63++;
                    length4 = i13;
                    iArr12 = iArr13;
                }
                iArr = iArr12;
                int i64 = length5 - 1;
                double d11 = dArr[i64] - dArr[0];
                int i65 = 0;
                while (i65 < i64) {
                    double d12 = dArr[i65];
                    int i66 = i65 + 1;
                    o1Var.h(Double.valueOf(d11 == 0.0d ? 1.0d : (((d12 + dArr[i66]) * 0.5d) - dArr[0]) / d11), Integer.valueOf(i62));
                    i65 = i66;
                }
            }
            i62++;
            length4 = i13;
            iArr12 = iArr;
            fVar4 = fVar4;
        }
        ot.f fVar5 = fVar4;
        int[] iArr14 = iArr12;
        hx.m0 m0VarQ = hx.m0.q(o1Var.i());
        for (int i67 = 0; i67 < m0VarQ.size(); i67++) {
            int iIntValue = ((Integer) m0VarQ.get(i67)).intValue();
            int i68 = iArr14[iIntValue] + 1;
            iArr14[iIntValue] = i68;
            jArr3[iIntValue] = jArr[iIntValue][i68];
            mt.b.t(arrayList, jArr3);
        }
        for (int i69 = 0; i69 < pVarArr.length; i69++) {
            if (arrayList.get(i69) != null) {
                jArr3[i69] = jArr3[i69] * 2;
            }
        }
        mt.b.t(arrayList, jArr3);
        hx.j0 j0VarP2 = hx.m0.p();
        for (int i71 = 0; i71 < arrayList.size(); i71++) {
            hx.j0 j0Var = (hx.j0) arrayList.get(i71);
            j0VarP2.c(j0Var == null ? hx.w1.f14911w : j0Var.g());
        }
        hx.w1 w1VarG = j0VarP2.g();
        mt.q[] qVarArr = new mt.q[pVarArr.length];
        for (int i72 = 0; i72 < pVarArr.length; i72++) {
            mt.p pVar5 = pVarArr[i72];
            if (pVar5 != null) {
                int[] iArr15 = pVar5.f21963b;
                if (iArr15.length != 0) {
                    if (iArr15.length == 1) {
                        bVar = new mt.r(pVar5.f21962a, new int[]{iArr15[0]});
                    } else {
                        long j12 = 25000;
                        bVar = new mt.b(pVar5.f21962a, iArr15, fVar5, 10000, j12, j12, (hx.m0) w1VarG.get(i72));
                    }
                    qVarArr[i72] = bVar;
                }
            }
        }
        a2[] a2VarArr = new a2[i37];
        for (int i73 = 0; i73 < i37; i73++) {
            a2VarArr[i73] = (hVar.f21936r0.get(i73) || hVar.f21997b0.contains(Integer.valueOf(sVar.f21965b[i73])) || (sVar.f21965b[i73] != -2 && qVarArr[i73] == null)) ? null : a2.f21391b;
        }
        boolean z14 = hVar.f21932n0;
        byte b11 = -1;
        if (z14) {
            int i74 = -1;
            int i75 = -1;
            int i76 = 0;
            while (true) {
                if (i76 >= sVar.f21964a) {
                    z13 = true;
                    break;
                }
                int i77 = sVar.f21965b[i76];
                mt.q qVar = qVarArr[i76];
                if ((i77 == 1 || i77 == 2) && qVar != null) {
                    int[][] iArr16 = iArr4[i76];
                    int iB = sVar.f21966c[i76].b(qVar.b());
                    int i78 = 0;
                    while (true) {
                        if (i78 >= qVar.length()) {
                            i12 = i48;
                            if (i77 != 1) {
                                if (i74 == -1) {
                                    i74 = i76;
                                    break;
                                }
                                z13 = false;
                                break;
                            }
                            if (i75 == -1) {
                                i75 = i76;
                                break;
                            }
                            z13 = false;
                            break;
                        }
                        i12 = i48;
                        if ((iArr16[iB][qVar.f(i78)] & 32) != i12) {
                            break;
                        }
                        i78++;
                        i48 = i12;
                    }
                } else {
                    i12 = i48;
                }
                i76++;
                i48 = i12;
            }
            if (z13 & ((i75 == -1 || i74 == -1) ? false : true)) {
                a2 a2Var = new a2(true);
                a2VarArr[i75] = a2Var;
                a2VarArr[i74] = a2Var;
            }
        }
        Pair pairCreate = Pair.create(a2VarArr, qVarArr);
        mt.q[] qVarArr2 = (mt.q[]) pairCreate.second;
        List[] listArr = new List[qVarArr2.length];
        for (int i79 = 0; i79 < qVarArr2.length; i79++) {
            mt.q qVar2 = qVarArr2[i79];
            if (qVar2 != null) {
                w1VarV = hx.m0.v(qVar2);
            } else {
                hx.k0 k0Var = hx.m0.f14841e;
                w1VarV = hx.w1.f14911w;
            }
            listArr[i79] = w1VarV;
        }
        int i81 = 4;
        hx.j0 j0Var2 = new hx.j0(4);
        int i82 = 0;
        while (true) {
            int i83 = sVar.f21964a;
            ss.w0[] w0VarArr3 = sVar.f21966c;
            if (i82 >= i83) {
                break;
            }
            ss.w0 w0Var4 = w0VarArr3[i82];
            List list = listArr[i82];
            int i84 = 0;
            while (i84 < w0Var4.f29356d) {
                ss.v0 v0VarA3 = w0Var4.a(i84);
                int i85 = w0VarArr3[i82].a(i84).f29349d;
                int[] iArr17 = new int[i85];
                int i86 = 0;
                for (int i87 = 0; i87 < i85; i87++) {
                    if ((sVar.f21968e[i82][i84][i87] & 7) == i81) {
                        iArr17[i86] = i87;
                        i86++;
                    }
                }
                int[] iArrCopyOf = Arrays.copyOf(iArr17, i86);
                List[] listArr2 = listArr;
                int iMin = 16;
                String str2 = null;
                int i88 = 0;
                boolean z15 = false;
                int i89 = 0;
                while (i88 < iArrCopyOf.length) {
                    int[] iArr18 = iArrCopyOf;
                    String str3 = w0VarArr3[i82].a(i84).f29352v[iArrCopyOf[i88]].N;
                    int i90 = i89 + 1;
                    if (i89 == 0) {
                        str2 = str3;
                    } else {
                        z15 = (!qt.x.a(str2, str3)) | z15;
                    }
                    iMin = Math.min(iMin, sVar.f21968e[i82][i84][i88] & 24);
                    i88++;
                    i89 = i90;
                    iArrCopyOf = iArr18;
                }
                if (z15) {
                    iMin = Math.min(iMin, sVar.f21967d[i82]);
                }
                boolean z16 = iMin != 0;
                int i91 = v0VarA3.f29349d;
                int[] iArr19 = new int[i91];
                boolean[] zArr = new boolean[i91];
                for (int i92 = 0; i92 < v0VarA3.f29349d; i92++) {
                    iArr19[i92] = sVar.f21968e[i82][i84][i92] & 7;
                    int i93 = 0;
                    while (true) {
                        if (i93 >= list.size()) {
                            z12 = false;
                            break;
                        }
                        mt.q qVar3 = (mt.q) list.get(i93);
                        if (qVar3.b().equals(v0VarA3) && qVar3.p(i92) != -1) {
                            z12 = true;
                            break;
                        }
                        i93++;
                    }
                    zArr[i92] = z12;
                }
                j0Var2.c(new k2(v0VarA3, z16, iArr19, zArr));
                i84++;
                b11 = -1;
                listArr = listArr2;
                i81 = 4;
            }
            i82++;
            i81 = 4;
        }
        ss.w0 w0Var5 = sVar.f21969f;
        for (int i94 = 0; i94 < w0Var5.f29356d; i94++) {
            ss.v0 v0VarA4 = w0Var5.a(i94);
            int[] iArr20 = new int[v0VarA4.f29349d];
            Arrays.fill(iArr20, 0);
            j0Var2.c(new k2(v0VarA4, false, iArr20, new boolean[v0VarA4.f29349d]));
        }
        mt.x xVar = new mt.x((a2[]) pairCreate.first, (mt.q[]) pairCreate.second, new l2(j0Var2.g()), sVar);
        for (mt.q qVar4 : xVar.f22006c) {
            if (qVar4 != null) {
                qVar4.l(f3);
            }
        }
        return xVar;
    }

    public final void h() {
        Object obj = this.f21824a;
        if (obj instanceof ss.d) {
            long j6 = this.f21829f.f21874d;
            if (j6 == -9223372036854775807L) {
                j6 = Long.MIN_VALUE;
            }
            ((ss.d) obj).f29234w = j6;
        }
    }
}
