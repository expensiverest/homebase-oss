package mr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class i0 implements e {
    public final int J;
    public final String K;
    public final is.c L;
    public final String M;
    public final String N;
    public final int O;
    public final List P;
    public final sr.h Q;
    public final long R;
    public final int S;
    public final int T;
    public final float U;
    public final int V;
    public final float W;
    public final byte[] X;
    public final int Y;
    public final rt.b Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final int f21560a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final int f21561b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public final int f21562c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f21563d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final int f21564d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f21565e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final int f21566e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final int f21567f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public final int f21568g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public final int f21569h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f21570i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public final int f21571i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public int f21572j0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f21573v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21574w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f21575x;
    public final int y;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public static final i0 f21545k0 = new i0(new h0());

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public static final String f21546l0 = Integer.toString(0, 36);

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public static final String f21547m0 = Integer.toString(1, 36);

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public static final String f21548n0 = Integer.toString(2, 36);

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public static final String f21549o0 = Integer.toString(3, 36);

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public static final String f21550p0 = Integer.toString(4, 36);

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public static final String f21551q0 = Integer.toString(5, 36);

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static final String f21552r0 = Integer.toString(6, 36);

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final String f21553s0 = Integer.toString(7, 36);
    public static final String t0 = Integer.toString(8, 36);

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public static final String f21554u0 = Integer.toString(9, 36);

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public static final String f21555v0 = Integer.toString(10, 36);

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public static final String f21556w0 = Integer.toString(11, 36);

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public static final String f21557x0 = Integer.toString(12, 36);

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public static final String f21558y0 = Integer.toString(13, 36);

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public static final String f21559z0 = Integer.toString(14, 36);
    public static final String A0 = Integer.toString(15, 36);
    public static final String B0 = Integer.toString(16, 36);
    public static final String C0 = Integer.toString(17, 36);
    public static final String D0 = Integer.toString(18, 36);
    public static final String E0 = Integer.toString(19, 36);
    public static final String F0 = Integer.toString(20, 36);
    public static final String G0 = Integer.toString(21, 36);
    public static final String H0 = Integer.toString(22, 36);
    public static final String I0 = Integer.toString(23, 36);
    public static final String J0 = Integer.toString(24, 36);
    public static final String K0 = Integer.toString(25, 36);
    public static final String L0 = Integer.toString(26, 36);
    public static final String M0 = Integer.toString(27, 36);
    public static final String N0 = Integer.toString(28, 36);
    public static final String O0 = Integer.toString(29, 36);
    public static final String P0 = Integer.toString(30, 36);
    public static final String Q0 = Integer.toString(31, 36);
    public static final mp.a R0 = new mp.a(17);

    public i0(h0 h0Var) {
        this.f21563d = h0Var.f21509a;
        this.f21565e = h0Var.f21510b;
        this.f21570i = qt.x.J(h0Var.f21511c);
        this.f21573v = h0Var.f21512d;
        this.f21574w = h0Var.f21513e;
        int i11 = h0Var.f21514f;
        this.f21575x = i11;
        int i12 = h0Var.f21515g;
        this.y = i12;
        this.J = i12 != -1 ? i12 : i11;
        this.K = h0Var.f21516h;
        this.L = h0Var.f21517i;
        this.M = h0Var.f21518j;
        this.N = h0Var.k;
        this.O = h0Var.l;
        List list = h0Var.f21519m;
        this.P = list == null ? Collections.EMPTY_LIST : list;
        sr.h hVar = h0Var.f21520n;
        this.Q = hVar;
        this.R = h0Var.f21521o;
        this.S = h0Var.f21522p;
        this.T = h0Var.f21523q;
        this.U = h0Var.f21524r;
        int i13 = h0Var.f21525s;
        this.V = i13 == -1 ? 0 : i13;
        float f3 = h0Var.f21526t;
        this.W = f3 == -1.0f ? 1.0f : f3;
        this.X = h0Var.f21527u;
        this.Y = h0Var.f21528v;
        this.Z = h0Var.f21529w;
        this.f21560a0 = h0Var.f21530x;
        this.f21561b0 = h0Var.y;
        this.f21562c0 = h0Var.f21531z;
        int i14 = h0Var.A;
        this.f21564d0 = i14 == -1 ? 0 : i14;
        int i15 = h0Var.B;
        this.f21566e0 = i15 != -1 ? i15 : 0;
        this.f21567f0 = h0Var.C;
        this.f21568g0 = h0Var.D;
        this.f21569h0 = h0Var.E;
        int i16 = h0Var.F;
        if (i16 != 0 || hVar == null) {
            this.f21571i0 = i16;
        } else {
            this.f21571i0 = 1;
        }
    }

    public final h0 a() {
        h0 h0Var = new h0();
        h0Var.f21509a = this.f21563d;
        h0Var.f21510b = this.f21565e;
        h0Var.f21511c = this.f21570i;
        h0Var.f21512d = this.f21573v;
        h0Var.f21513e = this.f21574w;
        h0Var.f21514f = this.f21575x;
        h0Var.f21515g = this.y;
        h0Var.f21516h = this.K;
        h0Var.f21517i = this.L;
        h0Var.f21518j = this.M;
        h0Var.k = this.N;
        h0Var.l = this.O;
        h0Var.f21519m = this.P;
        h0Var.f21520n = this.Q;
        h0Var.f21521o = this.R;
        h0Var.f21522p = this.S;
        h0Var.f21523q = this.T;
        h0Var.f21524r = this.U;
        h0Var.f21525s = this.V;
        h0Var.f21526t = this.W;
        h0Var.f21527u = this.X;
        h0Var.f21528v = this.Y;
        h0Var.f21529w = this.Z;
        h0Var.f21530x = this.f21560a0;
        h0Var.y = this.f21561b0;
        h0Var.f21531z = this.f21562c0;
        h0Var.A = this.f21564d0;
        h0Var.B = this.f21566e0;
        h0Var.C = this.f21567f0;
        h0Var.D = this.f21568g0;
        h0Var.E = this.f21569h0;
        h0Var.F = this.f21571i0;
        return h0Var;
    }

    public final boolean b(i0 i0Var) {
        List list = this.P;
        if (list.size() != i0Var.P.size()) {
            return false;
        }
        for (int i11 = 0; i11 < list.size(); i11++) {
            if (!Arrays.equals((byte[]) list.get(i11), (byte[]) i0Var.P.get(i11))) {
                return false;
            }
        }
        return true;
    }

    public final i0 c(i0 i0Var) {
        String str;
        String str2;
        int i11;
        int i12;
        if (this == i0Var) {
            return this;
        }
        int iG = qt.k.g(this.N);
        String str3 = i0Var.f21563d;
        is.c cVarB = i0Var.L;
        String str4 = i0Var.f21565e;
        if (str4 == null) {
            str4 = this.f21565e;
        }
        if ((iG != 3 && iG != 1) || (str = i0Var.f21570i) == null) {
            str = this.f21570i;
        }
        int i13 = this.f21575x;
        if (i13 == -1) {
            i13 = i0Var.f21575x;
        }
        int i14 = this.y;
        if (i14 == -1) {
            i14 = i0Var.y;
        }
        String str5 = this.K;
        if (str5 == null) {
            String strQ = qt.x.q(iG, i0Var.K);
            if (qt.x.S(strQ).length == 1) {
                str5 = strQ;
            }
        }
        is.c cVar = this.L;
        if (cVar != null) {
            cVarB = cVarB == null ? cVar : cVar.b(cVarB.f17374d);
        }
        float f3 = this.U;
        if (f3 == -1.0f && iG == 2) {
            f3 = i0Var.U;
        }
        int i15 = this.f21573v | i0Var.f21573v;
        int i16 = this.f21574w | i0Var.f21574w;
        sr.h hVar = i0Var.Q;
        ArrayList arrayList = new ArrayList();
        if (hVar != null) {
            str2 = hVar.f29189i;
            sr.g[] gVarArr = hVar.f29187d;
            int length = gVarArr.length;
            int i17 = 0;
            while (i17 < length) {
                sr.g[] gVarArr2 = gVarArr;
                sr.g gVar = gVarArr2[i17];
                int i18 = length;
                if (gVar.f29186w != null) {
                    arrayList.add(gVar);
                }
                i17++;
                gVarArr = gVarArr2;
                length = i18;
            }
        } else {
            str2 = null;
        }
        sr.h hVar2 = this.Q;
        if (hVar2 != null) {
            if (str2 == null) {
                str2 = hVar2.f29189i;
            }
            int size = arrayList.size();
            sr.g[] gVarArr3 = hVar2.f29187d;
            int length2 = gVarArr3.length;
            int i19 = 0;
            while (i19 < length2) {
                int i21 = i19;
                sr.g gVar2 = gVarArr3[i21];
                sr.g[] gVarArr4 = gVarArr3;
                if (gVar2.f29186w != null) {
                    UUID uuid = gVar2.f29183e;
                    i12 = length2;
                    int i22 = 0;
                    while (true) {
                        if (i22 >= size) {
                            i11 = size;
                            arrayList.add(gVar2);
                            break;
                        }
                        i11 = size;
                        if (((sr.g) arrayList.get(i22)).f29183e.equals(uuid)) {
                            break;
                        }
                        i22++;
                        size = i11;
                    }
                } else {
                    i11 = size;
                    i12 = length2;
                }
                i19 = i21 + 1;
                gVarArr3 = gVarArr4;
                length2 = i12;
                size = i11;
            }
        }
        sr.h hVar3 = arrayList.isEmpty() ? null : new sr.h(str2, arrayList);
        h0 h0VarA = a();
        h0VarA.f21509a = str3;
        h0VarA.f21510b = str4;
        h0VarA.f21511c = str;
        h0VarA.f21512d = i15;
        h0VarA.f21513e = i16;
        h0VarA.f21514f = i13;
        h0VarA.f21515g = i14;
        h0VarA.f21516h = str5;
        h0VarA.f21517i = cVarB;
        h0VarA.f21520n = hVar3;
        h0VarA.f21524r = f3;
        return new i0(h0VarA);
    }

    public final boolean equals(Object obj) {
        int i11;
        if (this == obj) {
            return true;
        }
        if (obj != null && i0.class == obj.getClass()) {
            i0 i0Var = (i0) obj;
            int i12 = this.f21572j0;
            if ((i12 == 0 || (i11 = i0Var.f21572j0) == 0 || i12 == i11) && this.f21573v == i0Var.f21573v && this.f21574w == i0Var.f21574w && this.f21575x == i0Var.f21575x && this.y == i0Var.y && this.O == i0Var.O && this.R == i0Var.R && this.S == i0Var.S && this.T == i0Var.T && this.V == i0Var.V && this.Y == i0Var.Y && this.f21560a0 == i0Var.f21560a0 && this.f21561b0 == i0Var.f21561b0 && this.f21562c0 == i0Var.f21562c0 && this.f21564d0 == i0Var.f21564d0 && this.f21566e0 == i0Var.f21566e0 && this.f21567f0 == i0Var.f21567f0 && this.f21568g0 == i0Var.f21568g0 && this.f21569h0 == i0Var.f21569h0 && this.f21571i0 == i0Var.f21571i0 && Float.compare(this.U, i0Var.U) == 0 && Float.compare(this.W, i0Var.W) == 0 && qt.x.a(this.f21563d, i0Var.f21563d) && qt.x.a(this.f21565e, i0Var.f21565e) && qt.x.a(this.K, i0Var.K) && qt.x.a(this.M, i0Var.M) && qt.x.a(this.N, i0Var.N) && qt.x.a(this.f21570i, i0Var.f21570i) && Arrays.equals(this.X, i0Var.X) && qt.x.a(this.L, i0Var.L) && qt.x.a(this.Z, i0Var.Z) && qt.x.a(this.Q, i0Var.Q) && b(i0Var)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        if (this.f21572j0 == 0) {
            String str = this.f21563d;
            int iHashCode = (527 + (str == null ? 0 : str.hashCode())) * 31;
            String str2 = this.f21565e;
            int iHashCode2 = (iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
            String str3 = this.f21570i;
            int iHashCode3 = (((((((((iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31) + this.f21573v) * 31) + this.f21574w) * 31) + this.f21575x) * 31) + this.y) * 31;
            String str4 = this.K;
            int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
            is.c cVar = this.L;
            int iHashCode5 = (iHashCode4 + (cVar == null ? 0 : cVar.hashCode())) * 31;
            String str5 = this.M;
            int iHashCode6 = (iHashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
            String str6 = this.N;
            this.f21572j0 = ((((((((((((((((((((Float.floatToIntBits(this.W) + ((((Float.floatToIntBits(this.U) + ((((((((((iHashCode6 + (str6 != null ? str6.hashCode() : 0)) * 31) + this.O) * 31) + ((int) this.R)) * 31) + this.S) * 31) + this.T) * 31)) * 31) + this.V) * 31)) * 31) + this.Y) * 31) + this.f21560a0) * 31) + this.f21561b0) * 31) + this.f21562c0) * 31) + this.f21564d0) * 31) + this.f21566e0) * 31) + this.f21567f0) * 31) + this.f21568g0) * 31) + this.f21569h0) * 31) + this.f21571i0;
        }
        return this.f21572j0;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Format(");
        sb2.append(this.f21563d);
        sb2.append(", ");
        sb2.append(this.f21565e);
        sb2.append(", ");
        sb2.append(this.M);
        sb2.append(", ");
        sb2.append(this.N);
        sb2.append(", ");
        sb2.append(this.K);
        sb2.append(", ");
        sb2.append(this.J);
        sb2.append(", ");
        sb2.append(this.f21570i);
        sb2.append(", [");
        sb2.append(this.S);
        sb2.append(", ");
        sb2.append(this.T);
        sb2.append(", ");
        sb2.append(this.U);
        sb2.append(", ");
        sb2.append(this.Z);
        sb2.append("], [");
        sb2.append(this.f21560a0);
        sb2.append(", ");
        return x2.f(this.f21561b0, "])", sb2);
    }
}
