package mr;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class q implements qt.g, n3.n, y5.d0, n3.j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21703d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f21704e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ int f21705i;

    public /* synthetic */ q(int i11, int i12, int i13) {
        this.f21703d = i13;
        this.f21704e = i11;
        this.f21705i = i12;
    }

    @Override // y5.d0
    public void a(y5.t tVar, int i11) {
        tVar.c(i11, this.f21704e, this.f21705i);
    }

    @Override // n3.j
    public void accept(Object obj) {
        switch (this.f21703d) {
            case 3:
                ((y5.w1) obj).I0(this.f21704e, this.f21705i);
                break;
            default:
                ((y5.w1) obj).K1(this.f21704e, this.f21705i);
                break;
        }
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        switch (this.f21703d) {
            case 0:
                ((s1) obj).n(this.f21704e, this.f21705i);
                break;
            default:
                ((k3.c1) obj).n(this.f21704e, this.f21705i);
                break;
        }
    }
}
