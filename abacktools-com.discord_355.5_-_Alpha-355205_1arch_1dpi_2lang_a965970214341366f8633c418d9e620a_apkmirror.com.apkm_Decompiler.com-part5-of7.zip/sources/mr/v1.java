package mr;

/* JADX INFO: loaded from: classes3.dex */
public interface v1 {
    void c(int i11, Object obj);
}
