package mr;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class o implements qt.g {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ z f21688d;

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        ((s1) obj).F(this.f21688d.f21857o0);
    }
}
