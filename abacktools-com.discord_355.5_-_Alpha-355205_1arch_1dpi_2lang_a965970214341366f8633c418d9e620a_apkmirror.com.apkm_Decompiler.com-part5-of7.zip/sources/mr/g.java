package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f21479a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f21480b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f21481c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f21482d = -9223372036854775807L;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f21483e = -9223372036854775807L;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f21485g = -9223372036854775807L;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f21486h = -9223372036854775807L;
    public float k = 0.97f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f21488j = 1.03f;
    public float l = 1.0f;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f21489m = -9223372036854775807L;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f21484f = -9223372036854775807L;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public long f21487i = -9223372036854775807L;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public long f21490n = -9223372036854775807L;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f21491o = -9223372036854775807L;

    public /* synthetic */ g(long j6, int i11, long j11) {
        this.f21479a = i11;
        this.f21480b = j6;
        this.f21481c = j11;
    }

    public final void a() {
        long j6;
        switch (this.f21479a) {
            case 0:
                long j11 = this.f21482d;
                if (j11 != -9223372036854775807L) {
                    long j12 = this.f21483e;
                    if (j12 != -9223372036854775807L) {
                        j11 = j12;
                    }
                    long j13 = this.f21485g;
                    if (j13 != -9223372036854775807L && j11 < j13) {
                        j11 = j13;
                    }
                    long j14 = this.f21486h;
                    if (j14 != -9223372036854775807L && j11 > j14) {
                        j11 = j14;
                    }
                } else {
                    j11 = -9223372036854775807L;
                }
                if (this.f21484f != j11) {
                    this.f21484f = j11;
                    this.f21487i = j11;
                    this.f21490n = -9223372036854775807L;
                    this.f21491o = -9223372036854775807L;
                    this.f21489m = -9223372036854775807L;
                    break;
                }
                break;
            default:
                long j15 = this.f21482d;
                if (j15 != -9223372036854775807L) {
                    j6 = this.f21483e;
                    if (j6 == -9223372036854775807L) {
                        long j16 = this.f21485g;
                        if (j16 != -9223372036854775807L && j15 < j16) {
                            j15 = j16;
                        }
                        j6 = this.f21486h;
                        if (j6 == -9223372036854775807L || j15 <= j6) {
                            j6 = j15;
                        }
                    }
                } else {
                    j6 = -9223372036854775807L;
                }
                if (this.f21484f != j6) {
                    this.f21484f = j6;
                    this.f21487i = j6;
                    this.f21490n = -9223372036854775807L;
                    this.f21491o = -9223372036854775807L;
                    this.f21489m = -9223372036854775807L;
                    break;
                }
                break;
        }
    }
}
