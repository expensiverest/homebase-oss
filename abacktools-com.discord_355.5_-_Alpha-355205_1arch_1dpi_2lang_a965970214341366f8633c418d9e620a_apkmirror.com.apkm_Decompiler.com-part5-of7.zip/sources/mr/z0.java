package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class z0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ss.s f21871a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f21872b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f21873c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f21874d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f21875e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f21876f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f21877g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f21878h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f21879i;

    public z0(ss.s sVar, long j6, long j11, long j12, long j13, boolean z11, boolean z12, boolean z13, boolean z14) {
        boolean z15 = true;
        qt.a.g(!z14 || z12);
        qt.a.g(!z13 || z12);
        if (z11 && (z12 || z13 || z14)) {
            z15 = false;
        }
        qt.a.g(z15);
        this.f21871a = sVar;
        this.f21872b = j6;
        this.f21873c = j11;
        this.f21874d = j12;
        this.f21875e = j13;
        this.f21876f = z11;
        this.f21877g = z12;
        this.f21878h = z13;
        this.f21879i = z14;
    }

    public final z0 a(long j6) {
        if (j6 == this.f21873c) {
            return this;
        }
        return new z0(this.f21871a, this.f21872b, j6, this.f21874d, this.f21875e, this.f21876f, this.f21877g, this.f21878h, this.f21879i);
    }

    public final z0 b(long j6) {
        if (j6 == this.f21872b) {
            return this;
        }
        return new z0(this.f21871a, j6, this.f21873c, this.f21874d, this.f21875e, this.f21876f, this.f21877g, this.f21878h, this.f21879i);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && z0.class == obj.getClass()) {
            z0 z0Var = (z0) obj;
            if (this.f21872b == z0Var.f21872b && this.f21873c == z0Var.f21873c && this.f21874d == z0Var.f21874d && this.f21875e == z0Var.f21875e && this.f21876f == z0Var.f21876f && this.f21877g == z0Var.f21877g && this.f21878h == z0Var.f21878h && this.f21879i == z0Var.f21879i && qt.x.a(this.f21871a, z0Var.f21871a)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((((((((((((((this.f21871a.hashCode() + 527) * 31) + ((int) this.f21872b)) * 31) + ((int) this.f21873c)) * 31) + ((int) this.f21874d)) * 31) + ((int) this.f21875e)) * 31) + (this.f21876f ? 1 : 0)) * 31) + (this.f21877g ? 1 : 0)) * 31) + (this.f21878h ? 1 : 0)) * 31) + (this.f21879i ? 1 : 0);
    }
}
