package mr;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class v implements qt.g {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21745d = 1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ rt.s f21746e;

    @Override // qt.g, n3.n
    public final void invoke(Object obj) {
        switch (this.f21745d) {
            case 0:
                ((s1) obj).b(this.f21746e);
                break;
            default:
                rt.s sVar = this.f21746e;
                ((nr.b) obj).b(sVar);
                int i11 = sVar.f28504d;
                break;
        }
    }

    public /* synthetic */ v(rt.s sVar) {
        this.f21746e = sVar;
    }
}
