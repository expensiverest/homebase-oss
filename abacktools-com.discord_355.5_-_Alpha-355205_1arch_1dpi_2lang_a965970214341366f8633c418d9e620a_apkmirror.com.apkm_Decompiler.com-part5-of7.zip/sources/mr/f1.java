package mr;

import android.util.Pair;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class f1 implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21471d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ k7.l f21472e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Pair f21473i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ f4.z f21474v;

    public /* synthetic */ f1(k7.l lVar, Pair pair, f4.z zVar, int i11) {
        this.f21471d = i11;
        this.f21472e = lVar;
        this.f21473i = pair;
        this.f21474v = zVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f21471d) {
            case 0:
                nr.g gVar = (nr.g) ((j1) this.f21472e.f19343e).f21613j;
                Pair pair = this.f21473i;
                gVar.t(((Integer) pair.first).intValue(), (ss.s) pair.second, this.f21474v);
                break;
            default:
                nr.g gVar2 = (nr.g) ((j1) this.f21472e.f19343e).f21613j;
                Pair pair2 = this.f21473i;
                int iIntValue = ((Integer) pair2.first).intValue();
                ss.s sVar = (ss.s) pair2.second;
                sVar.getClass();
                gVar2.v(iIntValue, sVar, this.f21474v);
                break;
        }
    }
}
