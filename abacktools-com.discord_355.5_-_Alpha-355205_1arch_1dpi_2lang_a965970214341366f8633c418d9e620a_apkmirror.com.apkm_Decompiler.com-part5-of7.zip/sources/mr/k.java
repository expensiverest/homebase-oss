package mr;

import android.content.Context;
import android.os.Looper;

/* JADX INFO: loaded from: classes3.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f21616a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final qt.s f21617b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f4.o f21618c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final l3.c f21619d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public gx.v f21620e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public gx.v f21621f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public gx.v f21622g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Looper f21623h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final or.d f21624i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f21625j;
    public final boolean k;
    public final b2 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final long f21626m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final long f21627n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final g f21628o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final long f21629p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final long f21630q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final boolean f21631r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f21632s;

    public k(Context context, an.c cVar) {
        f4.o oVar = new f4.o(4, cVar);
        l3.c cVar2 = new l3.c(context, 1);
        l3.c cVar3 = new l3.c(context, 2);
        gx.x xVar = new gx.x(2);
        l3.c cVar4 = new l3.c(context, 3);
        context.getClass();
        this.f21616a = context;
        this.f21618c = oVar;
        this.f21619d = cVar2;
        this.f21620e = cVar3;
        this.f21621f = xVar;
        this.f21622g = cVar4;
        int i11 = qt.x.f27318a;
        Looper looperMyLooper = Looper.myLooper();
        this.f21623h = looperMyLooper == null ? Looper.getMainLooper() : looperMyLooper;
        this.f21624i = or.d.y;
        this.f21625j = 1;
        this.k = true;
        this.l = b2.f21402c;
        this.f21626m = 5000L;
        this.f21627n = 15000L;
        this.f21628o = new g(qt.x.I(20L), 0, qt.x.I(500L));
        this.f21617b = qt.s.f27310a;
        this.f21629p = 500L;
        this.f21630q = 2000L;
        this.f21631r = true;
    }
}
