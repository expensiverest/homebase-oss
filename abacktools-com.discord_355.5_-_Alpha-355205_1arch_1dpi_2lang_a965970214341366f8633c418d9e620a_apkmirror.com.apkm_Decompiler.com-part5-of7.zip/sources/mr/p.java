package mr;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class p implements qt.g, n3.n, gx.k, n3.j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21693d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f21694e;

    public /* synthetic */ p(int i11, int i12) {
        this.f21693d = i12;
        this.f21694e = i11;
    }

    @Override // n3.j
    public void accept(Object obj) {
        switch (this.f21693d) {
            case 6:
                ((y5.w1) obj).u1(this.f21694e);
                break;
            case 7:
                ((y5.w1) obj).J0(this.f21694e);
                break;
            case 8:
                ((y5.w1) obj).Q(this.f21694e);
                break;
            default:
                ((y5.w1) obj).d2(this.f21694e);
                break;
        }
    }

    @Override // gx.k
    public Object apply(Object obj) {
        return Integer.valueOf(this.f21694e);
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        switch (this.f21693d) {
            case 0:
                ((s1) obj).a(this.f21694e);
                break;
            case 1:
                ((nr.b) obj).d(this.f21694e);
                break;
            case 2:
                ((k3.c1) obj).a(this.f21694e);
                break;
            case 3:
                ((k3.c1) obj).u(this.f21694e);
                break;
            default:
                ((w3.b) obj).d(this.f21694e);
                break;
        }
    }

    public /* synthetic */ p(Object obj, int i11, long j6, int i12) {
        this.f21693d = i12;
        this.f21694e = i11;
    }
}
