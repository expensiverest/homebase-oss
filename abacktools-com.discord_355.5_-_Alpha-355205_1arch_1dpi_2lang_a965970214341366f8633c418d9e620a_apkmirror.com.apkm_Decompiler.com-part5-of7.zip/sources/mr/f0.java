package mr;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Pair;
import com.reactnativecommunity.webview.RNCWebViewManager;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes3.dex */
public final class f0 implements Handler.Callback, ss.p {
    public final qt.u J;
    public final HandlerThread K;
    public final Looper L;
    public final i2 M;
    public final h2 N;
    public final long O;
    public final f80.e P;
    public final ArrayList Q;
    public final qt.s R;
    public final o S;
    public final a1 T;
    public final j1 U;
    public final g V;
    public final long W;
    public b2 X;
    public n1 Y;
    public c0 Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public boolean f21448a0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public boolean f21450c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c[] f21451d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public boolean f21452d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Set f21453e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public boolean f21454e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public int f21455f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public boolean f21456g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public boolean f21457h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final c[] f21458i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public boolean f21459i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public boolean f21460j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public int f21461k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public e0 f21462l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public long f21463m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public int f21464n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public boolean f21465o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public j f21466p0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final mt.t f21468v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final mt.x f21469w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final h f21470x;
    public final ot.f y;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public boolean f21449b0 = false;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public long f21467q0 = -9223372036854775807L;

    public f0(c[] cVarArr, mt.t tVar, mt.x xVar, h hVar, ot.f fVar, int i11, boolean z11, nr.g gVar, b2 b2Var, g gVar2, long j6, Looper looper, qt.s sVar, o oVar, nr.p pVar) {
        this.S = oVar;
        this.f21451d = cVarArr;
        this.f21468v = tVar;
        this.f21469w = xVar;
        this.f21470x = hVar;
        this.y = fVar;
        this.f21455f0 = i11;
        this.f21456g0 = z11;
        this.X = b2Var;
        this.V = gVar2;
        this.W = j6;
        this.R = sVar;
        this.O = hVar.f21506g;
        hVar.getClass();
        n1 n1VarI = n1.i(xVar);
        this.Y = n1VarI;
        this.Z = new c0(n1VarI);
        this.f21458i = new c[cVarArr.length];
        mt.o oVar2 = (mt.o) tVar;
        oVar2.getClass();
        for (int i12 = 0; i12 < cVarArr.length; i12++) {
            c cVar = cVarArr[i12];
            cVar.f21409w = i12;
            cVar.f21410x = pVar;
            this.f21458i[i12] = cVar;
            synchronized (cVar.f21405d) {
                cVar.P = oVar2;
            }
        }
        this.P = new f80.e(this, sVar);
        this.Q = new ArrayList();
        this.f21453e = Collections.newSetFromMap(new IdentityHashMap());
        this.M = new i2();
        this.N = new h2();
        tVar.f21970a = this;
        tVar.f21971b = fVar;
        this.f21465o0 = true;
        qt.u uVarA = sVar.a(looper, null);
        this.T = new a1(gVar, uVarA);
        this.U = new j1(this, gVar, uVarA, pVar);
        HandlerThread handlerThread = new HandlerThread("ExoPlayer:Playback", -16);
        this.K = handlerThread;
        handlerThread.start();
        Looper looper2 = handlerThread.getLooper();
        this.L = looper2;
        this.J = sVar.a(looper2, this);
    }

    public static Pair F(j2 j2Var, e0 e0Var, boolean z11, int i11, boolean z12, i2 i2Var, h2 h2Var) {
        Object objG;
        j2 j2Var2 = e0Var.f21433a;
        if (j2Var.p()) {
            return null;
        }
        j2 j2Var3 = j2Var2.p() ? j2Var : j2Var2;
        try {
            Pair pairI = j2Var3.i(i2Var, h2Var, e0Var.f21434b, e0Var.f21435c);
            if (!j2Var.equals(j2Var3)) {
                if (j2Var.b(pairI.first) == -1) {
                    if (!z11 || (objG = G(i2Var, h2Var, i11, z12, pairI.first, j2Var3, j2Var)) == null) {
                        return null;
                    }
                    return j2Var.i(i2Var, h2Var, j2Var.g(objG, h2Var).f21537i, -9223372036854775807L);
                }
                if (j2Var3.g(pairI.first, h2Var).f21540x && j2Var3.m(h2Var.f21537i, i2Var, 0L).Q == j2Var3.b(pairI.first)) {
                    return j2Var.i(i2Var, h2Var, j2Var.g(pairI.first, h2Var).f21537i, e0Var.f21435c);
                }
            }
            return pairI;
        } catch (IndexOutOfBoundsException unused) {
            return null;
        }
    }

    public static Object G(i2 i2Var, h2 h2Var, int i11, boolean z11, Object obj, j2 j2Var, j2 j2Var2) {
        int iB = j2Var.b(obj);
        int iH = j2Var.h();
        int i12 = 0;
        int iD = iB;
        int iB2 = -1;
        while (i12 < iH && iB2 == -1) {
            i2 i2Var2 = i2Var;
            h2 h2Var2 = h2Var;
            int i13 = i11;
            boolean z12 = z11;
            j2 j2Var3 = j2Var;
            iD = j2Var3.d(iD, h2Var2, i2Var2, i13, z12);
            if (iD == -1) {
                break;
            }
            iB2 = j2Var2.b(j2Var3.l(iD));
            i12++;
            j2Var = j2Var3;
            h2Var = h2Var2;
            i2Var = i2Var2;
            i11 = i13;
            z11 = z12;
        }
        if (iB2 == -1) {
            return null;
        }
        return j2Var2.l(iB2);
    }

    public static void M(c cVar, long j6) {
        cVar.N = true;
        if (cVar instanceof bt.l) {
            bt.l lVar = (bt.l) cVar;
            qt.a.k(lVar.N);
            lVar.f4169e0 = j6;
        }
    }

    public static void c(w1 w1Var) {
        try {
            synchronized (w1Var) {
                synchronized (w1Var) {
                }
                w1Var.f21777a.c(w1Var.f21780d, w1Var.f21781e);
                return;
            }
            w1Var.f21777a.c(w1Var.f21780d, w1Var.f21781e);
            return;
        } finally {
            w1Var.b(true);
        }
    }

    public static boolean q(c cVar) {
        return cVar.y != 0;
    }

    public final void A() throws j {
        int i11;
        float f3 = this.P.mo362e().f21690d;
        a1 a1Var = this.T;
        y0 y0Var = a1Var.f21387h;
        y0 y0Var2 = a1Var.f21388i;
        boolean z11 = true;
        for (y0 y0Var3 = y0Var; y0Var3 != null && y0Var3.f21827d; y0Var3 = y0Var3.l) {
            mt.x xVarG = y0Var3.g(f3, this.Y.f21671a);
            mt.x xVar = y0Var3.f21835n;
            mt.q[] qVarArr = xVarG.f22006c;
            boolean z12 = false;
            if (xVar != null && xVar.f22006c.length == qVarArr.length) {
                int i12 = 0;
                while (true) {
                    if (i12 >= qVarArr.length) {
                        if (y0Var3 == y0Var2) {
                            z11 = false;
                        }
                    } else if (xVarG.a(xVar, i12)) {
                        i12++;
                    }
                }
            }
            if (z11) {
                a1 a1Var2 = this.T;
                y0 y0Var4 = a1Var2.f21387h;
                boolean zL = a1Var2.l(y0Var4);
                boolean[] zArr = new boolean[this.f21451d.length];
                long jA = y0Var4.a(xVarG, this.Y.f21686r, zL, zArr);
                n1 n1Var = this.Y;
                if (n1Var.f21675e != 4 && jA != n1Var.f21686r) {
                    z12 = true;
                }
                n1 n1Var2 = this.Y;
                i11 = 4;
                this.Y = o(n1Var2.f21672b, jA, n1Var2.f21673c, n1Var2.f21674d, z12, 5);
                if (z12) {
                    D(jA);
                }
                boolean[] zArr2 = new boolean[this.f21451d.length];
                int i13 = 0;
                while (true) {
                    c[] cVarArr = this.f21451d;
                    if (i13 >= cVarArr.length) {
                        break;
                    }
                    c cVar = cVarArr[i13];
                    boolean zQ = q(cVar);
                    zArr2[i13] = zQ;
                    ss.m0 m0Var = y0Var4.f21826c[i13];
                    if (zQ) {
                        if (m0Var != cVar.J) {
                            d(cVar);
                        } else if (zArr[i13]) {
                            long j6 = this.f21463m0;
                            cVar.N = false;
                            cVar.M = j6;
                            cVar.n(j6, false);
                        }
                    }
                    i13++;
                }
                f(zArr2);
            } else {
                i11 = 4;
                this.T.l(y0Var3);
                if (y0Var3.f21827d) {
                    y0Var3.a(xVarG, Math.max(y0Var3.f21829f.f21872b, this.f21463m0 - y0Var3.f21836o), false, new boolean[y0Var3.f21832i.length]);
                }
            }
            k(true);
            if (this.Y.f21675e != i11) {
                t();
                e0();
                this.J.d(2);
                return;
            }
            return;
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0094  */
    /* JADX WARN: Code duplicated, block: B:40:0x00c3 A[PHI: r4 r5 r7
      0x00c3: PHI (r4v4 ss.s) = (r4v3 ss.s), (r4v11 ss.s) binds: [B:35:0x0098, B:37:0x00bd] A[DONT_GENERATE, DONT_INLINE]
      0x00c3: PHI (r5v2 long) = (r5v1 long), (r5v17 long) binds: [B:35:0x0098, B:37:0x00bd] A[DONT_GENERATE, DONT_INLINE]
      0x00c3: PHI (r7v3 long) = (r7v2 long), (r7v14 long) binds: [B:35:0x0098, B:37:0x00bd] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:54:0x0123  */
    public final void B(boolean z11, boolean z12, boolean z13, boolean z14) {
        long j6;
        boolean z15;
        ss.s sVar;
        j2 j2Var;
        List list;
        this.J.f27313a.removeMessages(2);
        this.f21466p0 = null;
        this.f21452d0 = false;
        f80.e eVar = this.P;
        eVar.f11489i = false;
        io.sentry.android.core.q qVar = (io.sentry.android.core.q) eVar.f11490v;
        if (qVar.f16224e) {
            qVar.c(qVar.a());
            qVar.f16224e = false;
        }
        this.f21463m0 = 1000000000000L;
        for (c cVar : this.f21451d) {
            try {
                d(cVar);
            } catch (RuntimeException | j e4) {
                qt.a.s("ExoPlayerImplInternal", "Disable failed.", e4);
            }
        }
        if (z11) {
            for (c cVar2 : this.f21451d) {
                if (this.f21453e.remove(cVar2)) {
                    try {
                        cVar2.w();
                    } catch (RuntimeException e9) {
                        qt.a.s("ExoPlayerImplInternal", "Reset failed.", e9);
                    }
                }
            }
        }
        this.f21461k0 = 0;
        n1 n1Var = this.Y;
        ss.s sVar2 = n1Var.f21672b;
        long jLongValue = n1Var.f21686r;
        if (this.Y.f21672b.a()) {
            j6 = this.Y.f21673c;
        } else {
            n1 n1Var2 = this.Y;
            h2 h2Var = this.N;
            ss.s sVar3 = n1Var2.f21672b;
            j2 j2Var2 = n1Var2.f21671a;
            if (j2Var2.p() || j2Var2.g(sVar3.f29324a, h2Var).f21540x) {
                j6 = this.Y.f21673c;
            } else {
                j6 = this.Y.f21686r;
            }
        }
        if (z12) {
            this.f21462l0 = null;
            Pair pairH = h(this.Y.f21671a);
            sVar2 = (ss.s) pairH.first;
            jLongValue = ((Long) pairH.second).longValue();
            j6 = -9223372036854775807L;
            if (sVar2.equals(this.Y.f21672b)) {
                z15 = false;
            } else {
                z15 = true;
            }
        } else {
            z15 = false;
        }
        long j11 = jLongValue;
        long j12 = j6;
        this.T.b();
        this.f21454e0 = false;
        j2 j2Var3 = this.Y.f21671a;
        if (z13 && (j2Var3 instanceof y1)) {
            y1 y1Var = (y1) j2Var3;
            ss.p0 p0Var = (ss.p0) this.U.l;
            j2[] j2VarArr = y1Var.J;
            j2[] j2VarArr2 = new j2[j2VarArr.length];
            for (int i11 = 0; i11 < j2VarArr.length; i11++) {
                j2VarArr2[i11] = new x1(j2VarArr[i11]);
            }
            y1 y1Var2 = new y1(j2VarArr2, y1Var.K, p0Var);
            if (sVar2.f29325b != -1) {
                y1Var2.g(sVar2.f29324a, this.N);
                int i12 = this.N.f21537i;
                i2 i2Var = this.M;
                y1Var2.m(i12, i2Var, 0L);
                if (i2Var.a()) {
                    j2Var = y1Var2;
                    sVar = new ss.s(sVar2.f29327d, sVar2.f29324a);
                } else {
                    j2Var = y1Var2;
                    sVar = sVar2;
                }
            } else {
                j2Var = y1Var2;
                sVar = sVar2;
            }
        } else {
            sVar = sVar2;
            j2Var = j2Var3;
        }
        n1 n1Var3 = this.Y;
        int i13 = n1Var3.f21675e;
        j jVar = z14 ? null : n1Var3.f21676f;
        ss.w0 w0Var = z15 ? ss.w0.f29354v : n1Var3.f21678h;
        mt.x xVar = z15 ? this.f21469w : n1Var3.f21679i;
        if (z15) {
            hx.k0 k0Var = hx.m0.f14841e;
            list = hx.w1.f14911w;
        } else {
            list = n1Var3.f21680j;
        }
        this.Y = new n1(j2Var, sVar, j12, j11, i13, jVar, false, w0Var, xVar, list, sVar, n1Var3.l, n1Var3.f21681m, n1Var3.f21682n, j11, 0L, j11, 0L, false);
        if (z13) {
            j1 j1Var = this.U;
            HashMap map = (HashMap) j1Var.f21610g;
            for (h1 h1Var : map.values()) {
                try {
                    h1Var.f21532a.o(h1Var.f21533b);
                } catch (RuntimeException e11) {
                    qt.a.s("MediaSourceList", "Failed to release child source.", e11);
                }
                ss.a aVar = h1Var.f21532a;
                k7.l lVar = h1Var.f21534c;
                aVar.r(lVar);
                h1Var.f21532a.q(lVar);
            }
            map.clear();
            ((HashSet) j1Var.f21612i).clear();
            j1Var.f21605b = false;
        }
    }

    public final void C() {
        y0 y0Var = this.T.f21387h;
        this.f21450c0 = y0Var != null && y0Var.f21829f.f21878h && this.f21449b0;
    }

    public final void D(long j6) {
        y0 y0Var = this.T.f21387h;
        long j11 = j6 + (y0Var == null ? 1000000000000L : y0Var.f21836o);
        this.f21463m0 = j11;
        ((io.sentry.android.core.q) this.P.f11490v).c(j11);
        for (c cVar : this.f21451d) {
            if (q(cVar)) {
                long j12 = this.f21463m0;
                cVar.N = false;
                cVar.M = j12;
                cVar.n(j12, false);
            }
        }
        for (y0 y0Var2 = r0.f21387h; y0Var2 != null; y0Var2 = y0Var2.l) {
            for (mt.q qVar : y0Var2.f21835n.f22006c) {
                if (qVar != null) {
                    qVar.n();
                }
            }
        }
    }

    public final void E(j2 j2Var, j2 j2Var2) {
        if (j2Var.p() && j2Var2.p()) {
            return;
        }
        ArrayList arrayList = this.Q;
        int size = arrayList.size() - 1;
        if (size < 0) {
            Collections.sort(arrayList);
        } else {
            a1.h.s(arrayList.get(size));
            throw null;
        }
    }

    public final void H(boolean z11) throws j {
        ss.s sVar = this.T.f21387h.f21829f.f21871a;
        long J = J(sVar, this.Y.f21686r, true, false);
        if (J != this.Y.f21686r) {
            n1 n1Var = this.Y;
            this.Y = o(sVar, J, n1Var.f21673c, n1Var.f21674d, z11, 5);
        }
    }

    /* JADX WARN: Code duplicated, block: B:103:0x00c8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:24:0x00a1 A[Catch: all -> 0x00a4, TryCatch #1 {all -> 0x00a4, blocks: (B:22:0x0097, B:24:0x00a1, B:31:0x00ad, B:33:0x00b3, B:34:0x00b6, B:36:0x00be, B:40:0x00ce, B:44:0x00d6), top: B:98:0x0097 }] */
    /* JADX WARN: Code duplicated, block: B:29:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:31:0x00ad A[Catch: all -> 0x00a4, TryCatch #1 {all -> 0x00a4, blocks: (B:22:0x0097, B:24:0x00a1, B:31:0x00ad, B:33:0x00b3, B:34:0x00b6, B:36:0x00be, B:40:0x00ce, B:44:0x00d6), top: B:98:0x0097 }] */
    /* JADX WARN: Code duplicated, block: B:33:0x00b3 A[Catch: all -> 0x00a4, TryCatch #1 {all -> 0x00a4, blocks: (B:22:0x0097, B:24:0x00a1, B:31:0x00ad, B:33:0x00b3, B:34:0x00b6, B:36:0x00be, B:40:0x00ce, B:44:0x00d6), top: B:98:0x0097 }] */
    /* JADX WARN: Code duplicated, block: B:36:0x00be A[Catch: all -> 0x00a4, TRY_LEAVE, TryCatch #1 {all -> 0x00a4, blocks: (B:22:0x0097, B:24:0x00a1, B:31:0x00ad, B:33:0x00b3, B:34:0x00b6, B:36:0x00be, B:40:0x00ce, B:44:0x00d6), top: B:98:0x0097 }] */
    /* JADX WARN: Code duplicated, block: B:46:0x00df  */
    /* JADX WARN: Code duplicated, block: B:61:0x0110  */
    /* JADX WARN: Code duplicated, block: B:64:0x011a  */
    /* JADX WARN: Code duplicated, block: B:65:0x011c  */
    /* JADX WARN: Code duplicated, block: B:68:0x0125  */
    /* JADX WARN: Code duplicated, block: B:70:0x0128  */
    /* JADX WARN: Code duplicated, block: B:74:0x0132  */
    /* JADX WARN: Code duplicated, block: B:75:0x0135  */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Object, ss.q] */
    public final void I(e0 e0Var) throws Throwable {
        long jLongValue;
        ss.s sVarN;
        long j6;
        boolean z11;
        long j11;
        long j12;
        y0 y0Var;
        long jC;
        n1 n1Var;
        int i11;
        long j13;
        ss.s sVar;
        int i12;
        long j14;
        boolean z12;
        a1 a1Var;
        boolean z13;
        long J;
        boolean z14;
        ss.s sVar2;
        long j15;
        f0 f0Var = this;
        f0Var.Z.a(1);
        Pair pairF = F(f0Var.Y.f21671a, e0Var, true, f0Var.f21455f0, f0Var.f21456g0, f0Var.M, f0Var.N);
        try {
            if (pairF != null) {
                Object obj = pairF.first;
                jLongValue = ((Long) pairF.second).longValue();
                long j16 = e0Var.f21435c == -9223372036854775807L ? -9223372036854775807L : jLongValue;
                sVarN = f0Var.T.n(f0Var.Y.f21671a, obj, jLongValue);
                if (sVarN.a()) {
                    f0Var.Y.f21671a.g(sVarN.f29324a, f0Var.N);
                    jLongValue = f0Var.N.f(sVarN.f29325b) == sVarN.f29326c ? f0Var.N.y.f30645e : 0L;
                    z11 = true;
                    j11 = j16;
                } else {
                    j6 = 0;
                    z11 = e0Var.f21435c == -9223372036854775807L;
                    j11 = j16;
                }
                if (f0Var.Y.f21671a.p()) {
                    if (pairF == null) {
                        if (f0Var.Y.f21675e != 1) {
                            f0Var.W(4);
                        }
                        f0Var.B(false, true, false, true);
                    } else {
                        if (sVarN.equals(f0Var.Y.f21672b)) {
                            try {
                                y0Var = f0Var.T.f21387h;
                                if (y0Var == null && y0Var.f21827d && jLongValue != j6) {
                                    jC = y0Var.f21824a.c(jLongValue, f0Var.X);
                                } else {
                                    jC = jLongValue;
                                }
                                if (qt.x.U(jC) != qt.x.U(f0Var.Y.f21686r) && ((i11 = (n1Var = f0Var.Y).f21675e) == 2 || i11 == 3)) {
                                    j13 = n1Var.f21686r;
                                    z11 = z11;
                                    sVar = sVarN;
                                    i12 = 2;
                                    j14 = j13;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                sVarN = sVarN;
                                j12 = jLongValue;
                                f0Var.Y = f0Var.o(sVarN, j12, j11, j12, z11, 2);
                                throw th;
                            }
                        } else {
                            jC = jLongValue;
                        }
                        try {
                            if (f0Var.Y.f21675e == 4) {
                                z12 = true;
                            } else {
                                z12 = false;
                            }
                            a1Var = f0Var.T;
                            if (a1Var.f21387h != a1Var.f21388i) {
                                z13 = true;
                            } else {
                                z13 = false;
                            }
                            J = f0Var.J(sVarN, jC, z13, z12);
                            if (jLongValue != J) {
                                z14 = true;
                            } else {
                                z14 = false;
                            }
                            z11 |= z14;
                            try {
                                n1 n1Var2 = f0Var.Y;
                                sVar2 = sVarN;
                                try {
                                    j2 j2Var = n1Var2.f21671a;
                                    j15 = j11;
                                    try {
                                        f0Var.f0(j2Var, sVar2, j2Var, n1Var2.f21672b, j15, true);
                                        sVar = sVar2;
                                        j11 = j15;
                                        j13 = J;
                                        i12 = 2;
                                        j14 = j13;
                                        f0Var = this;
                                    } catch (Throwable th3) {
                                        th = th3;
                                        sVarN = sVar2;
                                        j11 = j15;
                                        j12 = J;
                                        f0Var.Y = f0Var.o(sVarN, j12, j11, j12, z11, 2);
                                        throw th;
                                    }
                                } catch (Throwable th4) {
                                    th = th4;
                                    sVarN = sVar2;
                                    j11 = j11;
                                    j12 = J;
                                    f0Var.Y = f0Var.o(sVarN, j12, j11, j12, z11, 2);
                                    throw th;
                                }
                            } catch (Throwable th5) {
                                th = th5;
                            }
                        } catch (Throwable th6) {
                            th = th6;
                            j11 = j11;
                            j12 = jLongValue;
                            f0Var.Y = f0Var.o(sVarN, j12, j11, j12, z11, 2);
                            throw th;
                        }
                    }
                    f0Var.Y = f0Var.o(sVar, j13, j11, j14, z11, i12);
                    return;
                }
                f0Var.f21462l0 = e0Var;
                z11 = z11;
                sVar = sVarN;
                j13 = jLongValue;
                i12 = 2;
                j14 = j13;
                f0Var = this;
                f0Var.Y = f0Var.o(sVar, j13, j11, j14, z11, i12);
                return;
            }
            Pair pairH = f0Var.h(f0Var.Y.f21671a);
            sVarN = (ss.s) pairH.first;
            jLongValue = ((Long) pairH.second).longValue();
            z11 = !f0Var.Y.f21671a.p();
            j11 = -9223372036854775807L;
            if (f0Var.Y.f21671a.p()) {
                if (pairF == null) {
                    if (f0Var.Y.f21675e != 1) {
                        f0Var.W(4);
                    }
                    f0Var.B(false, true, false, true);
                } else {
                    if (sVarN.equals(f0Var.Y.f21672b)) {
                        y0Var = f0Var.T.f21387h;
                        if (y0Var == null) {
                            jC = jLongValue;
                        } else {
                            jC = jLongValue;
                        }
                        if (qt.x.U(jC) != qt.x.U(f0Var.Y.f21686r)) {
                        }
                    } else {
                        jC = jLongValue;
                    }
                    if (f0Var.Y.f21675e == 4) {
                        z12 = true;
                    } else {
                        z12 = false;
                    }
                    a1Var = f0Var.T;
                    if (a1Var.f21387h != a1Var.f21388i) {
                        z13 = true;
                    } else {
                        z13 = false;
                    }
                    J = f0Var.J(sVarN, jC, z13, z12);
                    if (jLongValue != J) {
                        z14 = true;
                    } else {
                        z14 = false;
                    }
                    z11 |= z14;
                    n1 n1Var3 = f0Var.Y;
                    sVar2 = sVarN;
                    j2 j2Var2 = n1Var3.f21671a;
                    j15 = j11;
                    f0Var.f0(j2Var2, sVar2, j2Var2, n1Var3.f21672b, j15, true);
                    sVar = sVar2;
                    j11 = j15;
                    j13 = J;
                    i12 = 2;
                    j14 = j13;
                    f0Var = this;
                }
                f0Var.Y = f0Var.o(sVar, j13, j11, j14, z11, i12);
                return;
            }
            f0Var.f21462l0 = e0Var;
            z11 = z11;
            sVar = sVarN;
            j13 = jLongValue;
            i12 = 2;
            j14 = j13;
            f0Var = this;
            f0Var.Y = f0Var.o(sVar, j13, j11, j14, z11, i12);
            return;
        } catch (Throwable th7) {
            th = th7;
        }
        j6 = 0;
    }

    /* JADX WARN: Type inference failed for: r9v5, types: [java.lang.Object, ss.q] */
    public final long J(ss.s sVar, long j6, boolean z11, boolean z12) throws j {
        b0();
        this.f21452d0 = false;
        if (z12 || this.Y.f21675e == 3) {
            W(2);
        }
        a1 a1Var = this.T;
        y0 y0Var = a1Var.f21387h;
        y0 y0Var2 = y0Var;
        while (y0Var2 != null && !sVar.equals(y0Var2.f21829f.f21871a)) {
            y0Var2 = y0Var2.l;
        }
        if (z11 || y0Var != y0Var2 || (y0Var2 != null && y0Var2.f21836o + j6 < 0)) {
            c[] cVarArr = this.f21451d;
            for (c cVar : cVarArr) {
                d(cVar);
            }
            if (y0Var2 != null) {
                while (a1Var.f21387h != y0Var2) {
                    a1Var.a();
                }
                a1Var.l(y0Var2);
                y0Var2.f21836o = 1000000000000L;
                f(new boolean[cVarArr.length]);
            }
        }
        if (y0Var2 != null) {
            ?? r11 = y0Var2.f21824a;
            a1Var.l(y0Var2);
            if (!y0Var2.f21827d) {
                y0Var2.f21829f = y0Var2.f21829f.b(j6);
            } else if (y0Var2.f21828e) {
                j6 = r11.f(j6);
                r11.g(j6 - this.O);
            }
            D(j6);
            t();
        } else {
            a1Var.b();
            D(j6);
        }
        k(false);
        this.J.d(2);
        return j6;
    }

    public final void K(w1 w1Var) {
        Looper looper = w1Var.f21782f;
        Looper looper2 = this.L;
        qt.u uVar = this.J;
        if (looper != looper2) {
            uVar.a(15, w1Var).b();
            return;
        }
        c(w1Var);
        int i11 = this.Y.f21675e;
        if (i11 == 3 || i11 == 2) {
            uVar.d(2);
        }
    }

    public final void L(w1 w1Var) {
        Looper looper = w1Var.f21782f;
        if (looper.getThread().isAlive()) {
            this.R.a(looper, null).c(new jk.m0(this, w1Var));
        } else {
            qt.a.N("TAG", "Trying to send message on a dead thread.");
            w1Var.b(false);
        }
    }

    public final void N(boolean z11, AtomicBoolean atomicBoolean) {
        if (this.f21457h0 != z11) {
            this.f21457h0 = z11;
            if (!z11) {
                for (c cVar : this.f21451d) {
                    if (!q(cVar) && this.f21453e.remove(cVar)) {
                        cVar.w();
                    }
                }
            }
        }
        if (atomicBoolean != null) {
            synchronized (this) {
                atomicBoolean.set(true);
                notifyAll();
            }
        }
    }

    public final void O(b0 b0Var) throws Throwable {
        this.Z.a(1);
        int i11 = b0Var.f21400c;
        ss.p0 p0Var = b0Var.f21399b;
        ArrayList arrayList = b0Var.f21398a;
        if (i11 != -1) {
            this.f21462l0 = new e0(new y1(arrayList, p0Var), b0Var.f21400c, b0Var.f21401d);
        }
        j1 j1Var = this.U;
        ArrayList arrayList2 = (ArrayList) j1Var.f21607d;
        j1Var.m(0, arrayList2.size());
        l(j1Var.b(arrayList2.size(), arrayList, p0Var), false);
    }

    public final void P(boolean z11) {
        if (z11 == this.f21460j0) {
            return;
        }
        this.f21460j0 = z11;
        if (z11 || !this.Y.f21683o) {
            return;
        }
        this.J.d(2);
    }

    public final void Q(boolean z11) throws j {
        this.f21449b0 = z11;
        C();
        if (this.f21450c0) {
            a1 a1Var = this.T;
            if (a1Var.f21388i != a1Var.f21387h) {
                H(true);
                k(false);
            }
        }
    }

    public final void R(int i11, int i12, boolean z11, boolean z12) {
        this.Z.a(z12 ? 1 : 0);
        c0 c0Var = this.Z;
        c0Var.f21411a = true;
        c0Var.f21416f = true;
        c0Var.f21417g = i12;
        this.Y = this.Y.d(i11, z11);
        this.f21452d0 = false;
        for (y0 y0Var = this.T.f21387h; y0Var != null; y0Var = y0Var.l) {
            for (mt.q qVar : y0Var.f21835n.f22006c) {
                if (qVar != null) {
                    qVar.d(z11);
                }
            }
        }
        if (!X()) {
            b0();
            e0();
            return;
        }
        int i13 = this.Y.f21675e;
        qt.u uVar = this.J;
        if (i13 == 3) {
            Z();
            uVar.d(2);
        } else if (i13 == 2) {
            uVar.d(2);
        }
    }

    public final void S(o1 o1Var) {
        this.J.f27313a.removeMessages(16);
        f80.e eVar = this.P;
        eVar.b(o1Var);
        o1 o1VarMo362e = eVar.mo362e();
        n(o1VarMo362e, o1VarMo362e.f21690d, true, true);
    }

    public final void T(int i11) throws j {
        this.f21455f0 = i11;
        j2 j2Var = this.Y.f21671a;
        a1 a1Var = this.T;
        a1Var.f21385f = i11;
        if (!a1Var.o(j2Var)) {
            H(true);
        }
        k(false);
    }

    public final void U(boolean z11) throws j {
        this.f21456g0 = z11;
        j2 j2Var = this.Y.f21671a;
        a1 a1Var = this.T;
        a1Var.f21386g = z11;
        if (!a1Var.o(j2Var)) {
            H(true);
        }
        k(false);
    }

    public final void V(ss.p0 p0Var) throws Throwable {
        this.Z.a(1);
        j1 j1Var = this.U;
        int size = ((ArrayList) j1Var.f21607d).size();
        if (p0Var.f29317b.length != size) {
            p0Var = new ss.p0(new Random(p0Var.f29316a.nextLong())).a(size);
        }
        j1Var.l = p0Var;
        l(j1Var.e(), false);
    }

    public final void W(int i11) {
        n1 n1Var = this.Y;
        if (n1Var.f21675e != i11) {
            if (i11 != 2) {
                this.f21467q0 = -9223372036854775807L;
            }
            this.Y = n1Var.g(i11);
        }
    }

    public final boolean X() {
        n1 n1Var = this.Y;
        return n1Var.l && n1Var.f21681m == 0;
    }

    public final boolean Y(j2 j2Var, ss.s sVar) {
        if (sVar.a() || j2Var.p()) {
            return false;
        }
        int i11 = j2Var.g(sVar.f29324a, this.N).f21537i;
        i2 i2Var = this.M;
        j2Var.n(i11, i2Var);
        return i2Var.a() && i2Var.K && i2Var.f21595x != -9223372036854775807L;
    }

    public final void Z() {
        this.f21452d0 = false;
        f80.e eVar = this.P;
        eVar.f11489i = true;
        ((io.sentry.android.core.q) eVar.f11490v).f();
        for (c cVar : this.f21451d) {
            if (q(cVar)) {
                qt.a.k(cVar.y == 1);
                cVar.y = 2;
                cVar.q();
            }
        }
    }

    @Override // ss.n0
    public final void a(ss.o0 o0Var) {
        this.J.a(9, (ss.q) o0Var).b();
    }

    public final void a0(boolean z11, boolean z12) {
        B(z11 || !this.f21457h0, false, true, false);
        this.Z.a(z12 ? 1 : 0);
        this.f21470x.b(true);
        W(1);
    }

    public final void b(b0 b0Var, int i11) throws Throwable {
        this.Z.a(1);
        j1 j1Var = this.U;
        if (i11 == -1) {
            i11 = ((ArrayList) j1Var.f21607d).size();
        }
        l(j1Var.b(i11, b0Var.f21398a, b0Var.f21399b), false);
    }

    public final void b0() {
        int i11;
        f80.e eVar = this.P;
        eVar.f11489i = false;
        io.sentry.android.core.q qVar = (io.sentry.android.core.q) eVar.f11490v;
        if (qVar.f16224e) {
            qVar.c(qVar.a());
            qVar.f16224e = false;
        }
        for (c cVar : this.f21451d) {
            if (q(cVar) && (i11 = cVar.y) == 2) {
                qt.a.k(i11 == 2);
                cVar.y = 1;
                cVar.r();
            }
        }
    }

    /* JADX WARN: Type inference failed for: r1v7, types: [java.lang.Object, ss.o0] */
    public final void c0() {
        y0 y0Var = this.T.f21389j;
        boolean z11 = this.f21454e0 || (y0Var != null && y0Var.f21824a.i());
        n1 n1Var = this.Y;
        if (z11 != n1Var.f21677g) {
            this.Y = new n1(n1Var.f21671a, n1Var.f21672b, n1Var.f21673c, n1Var.f21674d, n1Var.f21675e, n1Var.f21676f, z11, n1Var.f21678h, n1Var.f21679i, n1Var.f21680j, n1Var.k, n1Var.l, n1Var.f21681m, n1Var.f21682n, n1Var.f21684p, n1Var.f21685q, n1Var.f21686r, n1Var.f21687s, n1Var.f21683o);
        }
    }

    public final void d(c cVar) {
        if (q(cVar)) {
            f80.e eVar = this.P;
            if (cVar == ((c) eVar.f11492x)) {
                eVar.y = null;
                eVar.f11492x = null;
                eVar.f11488e = true;
            }
            int i11 = cVar.y;
            if (i11 == 2) {
                qt.a.k(i11 == 2);
                cVar.y = 1;
                cVar.r();
            }
            qt.a.k(cVar.y == 1);
            cVar.f21407i.b();
            cVar.y = 0;
            cVar.J = null;
            cVar.K = null;
            cVar.N = false;
            cVar.l();
            this.f21461k0--;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public final void d0(mt.x xVar) {
        j2 j2Var = this.Y.f21671a;
        mt.q[] qVarArr = xVar.f22006c;
        h hVar = this.f21470x;
        int iMax = hVar.f21505f;
        if (iMax == -1) {
            int i11 = 0;
            int i12 = 0;
            while (true) {
                c[] cVarArr = this.f21451d;
                int i13 = 13107200;
                if (i11 >= cVarArr.length) {
                    iMax = Math.max(13107200, i12);
                    break;
                }
                if (qVarArr[i11] != null) {
                    switch (cVarArr[i11].f21406e) {
                        case 0:
                            i13 = 144310272;
                            i12 += i13;
                            break;
                        case 1:
                            i12 += i13;
                            break;
                        case 2:
                            i13 = 131072000;
                            i12 += i13;
                            break;
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            i13 = 131072;
                            i12 += i13;
                            break;
                        default:
                            throw new IllegalArgumentException();
                    }
                }
                i11++;
            }
        }
        hVar.f21507h = iMax;
        hVar.f21500a.c(iMax);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0058  */
    /* JADX WARN: Code duplicated, block: B:214:0x036d  */
    /* JADX WARN: Code duplicated, block: B:347:0x0549  */
    /* JADX WARN: Code duplicated, block: B:349:0x0554  */
    /* JADX WARN: Code duplicated, block: B:398:0x05fa  */
    /* JADX WARN: Code duplicated, block: B:61:0x0160 A[EDGE_INSN: B:61:0x0160->B:149:0x0291 BREAK  A[LOOP:7: B:71:0x017a->B:88:0x01ad]] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v26 */
    /* JADX WARN: Type inference failed for: r10v27, types: [int] */
    /* JADX WARN: Type inference failed for: r10v33 */
    /* JADX WARN: Type inference failed for: r2v42, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference failed for: r2v60, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference failed for: r2v80, types: [java.lang.Object, ss.o0] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference failed for: r4v30 */
    /* JADX WARN: Type inference failed for: r4v31, types: [int] */
    /* JADX WARN: Type inference failed for: r4v66 */
    /* JADX WARN: Type inference failed for: r5v24, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference failed for: r6v19, types: [java.lang.Object, ss.o0] */
    /* JADX WARN: Type inference failed for: r7v50, types: [java.lang.Object, ss.o0] */
    public final void e() throws j {
        j jVar;
        boolean z11;
        boolean z12;
        long j6;
        boolean z13;
        boolean z14;
        boolean zR;
        int i11;
        boolean z15;
        boolean z16;
        int i12;
        ss.m0 m0Var;
        long j11;
        boolean z17;
        z0 z0VarD;
        boolean z18;
        boolean z19;
        y0 y0Var;
        y0 y0Var2;
        boolean z21;
        c[] cVarArr;
        this.R.getClass();
        long jUptimeMillis = SystemClock.uptimeMillis();
        this.J.f27313a.removeMessages(2);
        long j12 = Long.MIN_VALUE;
        j jVar2 = null;
        if (this.Y.f21671a.p() || !this.U.f21605b) {
            jVar = null;
            jUptimeMillis = jUptimeMillis;
            j12 = Long.MIN_VALUE;
            z11 = false;
            z12 = true;
            j6 = -9223372036854775807L;
        } else {
            a1 a1Var = this.T;
            long j13 = this.f21463m0;
            y0 y0Var3 = a1Var.f21389j;
            if (y0Var3 == null) {
                j11 = -9223372036854775807L;
            } else {
                qt.a.k(y0Var3.l == null);
                if (y0Var3.f21827d) {
                    j11 = -9223372036854775807L;
                    y0Var3.f21824a.p(j13 - y0Var3.f21836o);
                } else {
                    j11 = -9223372036854775807L;
                }
            }
            a1 a1Var2 = this.T;
            y0 y0Var4 = a1Var2.f21389j;
            if (y0Var4 == null || (!y0Var4.f21829f.f21879i && y0Var4.f21827d && ((!y0Var4.f21828e || y0Var4.f21824a.n() == Long.MIN_VALUE) && a1Var2.f21389j.f21829f.f21875e != j11 && a1Var2.k < 100))) {
                a1 a1Var3 = this.T;
                long j14 = this.f21463m0;
                n1 n1Var = this.Y;
                y0 y0Var5 = a1Var3.f21389j;
                if (y0Var5 == null) {
                    z17 = true;
                    z0VarD = a1Var3.e(n1Var.f21671a, n1Var.f21672b, n1Var.f21673c, n1Var.f21686r);
                } else {
                    z17 = true;
                    z0VarD = a1Var3.d(n1Var.f21671a, y0Var5, j14);
                }
                if (z0VarD != null) {
                    a1 a1Var4 = this.T;
                    c[] cVarArr2 = this.f21458i;
                    mt.t tVar = this.f21468v;
                    j4.e eVar = this.f21470x.f21500a;
                    j1 j1Var = this.U;
                    mt.x xVar = this.f21469w;
                    z18 = z17;
                    y0 y0Var6 = a1Var4.f21389j;
                    y0 y0Var7 = new y0(cVarArr2, y0Var6 == null ? 1000000000000L : (y0Var6.f21836o + y0Var6.f21829f.f21875e) - z0VarD.f21872b, tVar, eVar, j1Var, z0VarD, xVar);
                    y0 y0Var8 = a1Var4.f21389j;
                    if (y0Var8 == null) {
                        a1Var4.f21387h = y0Var7;
                        a1Var4.f21388i = y0Var7;
                    } else if (y0Var7 != y0Var8.l) {
                        y0Var8.b();
                        y0Var8.l = y0Var7;
                        y0Var8.c();
                    }
                    a1Var4.l = null;
                    a1Var4.f21389j = y0Var7;
                    a1Var4.k++;
                    a1Var4.k();
                    y0Var7.f21824a.x(this, z0VarD.f21872b);
                    if (this.T.f21387h == y0Var7) {
                        D(z0VarD.f21872b);
                    }
                    z19 = false;
                    k(false);
                } else {
                    z18 = z17;
                    jUptimeMillis = jUptimeMillis;
                    j12 = Long.MIN_VALUE;
                    z19 = false;
                }
            } else {
                jUptimeMillis = jUptimeMillis;
                j12 = Long.MIN_VALUE;
                z19 = false;
                z18 = true;
            }
            if (this.f21454e0) {
                this.f21454e0 = p();
                c0();
            } else {
                t();
            }
            c[] cVarArr3 = this.f21451d;
            a1 a1Var5 = this.T;
            y0 y0Var9 = a1Var5.f21388i;
            if (y0Var9 == null) {
                j6 = j11;
                z12 = z18;
                break;
            }
            if (y0Var9.l != null && !this.f21450c0) {
                if (!y0Var9.f21827d) {
                    j6 = j11;
                    z12 = z18;
                    break;
                }
                ?? r11 = z19;
                while (true) {
                    if (r11 >= cVarArr3.length) {
                        y0 y0Var10 = y0Var9.l;
                        if (y0Var10.f21827d || this.f21463m0 >= y0Var10.e()) {
                            mt.x xVar2 = y0Var9.f21835n;
                            y0 y0Var11 = a1Var5.f21388i;
                            qt.a.k((y0Var11 == null || y0Var11.l == null) ? z19 : z18);
                            a1Var5.f21388i = a1Var5.f21388i.l;
                            a1Var5.k();
                            y0 y0Var12 = a1Var5.f21388i;
                            mt.x xVar3 = y0Var12.f21835n;
                            j2 j2Var = this.Y.f21671a;
                            j6 = j11;
                            z12 = z18;
                            f0(j2Var, y0Var12.f21829f.f21871a, j2Var, y0Var9.f21829f.f21871a, -9223372036854775807L, false);
                            if (y0Var12.f21827d && y0Var12.f21824a.l() != j6) {
                                long jE = y0Var12.e();
                                for (c cVar : cVarArr3) {
                                    if (cVar.J != null) {
                                        M(cVar, jE);
                                    }
                                }
                                break;
                            }
                            for (int i13 = 0; i13 < cVarArr3.length; i13++) {
                                boolean zB = xVar2.b(i13);
                                boolean zB2 = xVar3.b(i13);
                                if (zB && !cVarArr3[i13].N) {
                                    boolean z22 = this.f21458i[i13].f21406e == -2 ? z12 : false;
                                    a2 a2Var = xVar2.f22005b[i13];
                                    a2 a2Var2 = xVar3.f22005b[i13];
                                    if (!zB2 || !a2Var2.equals(a2Var) || z22) {
                                        M(cVarArr3[i13], y0Var12.e());
                                    }
                                }
                            }
                            break;
                        }
                    } else {
                        c cVar2 = cVarArr3[r11];
                        ss.m0 m0Var2 = y0Var9.f21826c[r11];
                        if (cVar2.J == m0Var2) {
                            if (m0Var2 != null && !cVar2.i()) {
                                y0 y0Var13 = y0Var9.l;
                                if (!y0Var9.f21829f.f21876f || !y0Var13.f21827d || (!(cVar2 instanceof bt.l) && !(cVar2 instanceof is.f) && cVar2.M < y0Var13.e())) {
                                }
                            }
                            r11++;
                        }
                    }
                    j6 = j11;
                    z12 = z18;
                    break;
                }
            }
            j6 = j11;
            z12 = z18;
            if (y0Var9.f21829f.f21879i || this.f21450c0) {
                for (int i14 = 0; i14 < cVarArr3.length; i14++) {
                    c cVar3 = cVarArr3[i14];
                    ss.m0 m0Var3 = y0Var9.f21826c[i14];
                    if (m0Var3 != null && cVar3.J == m0Var3 && cVar3.i()) {
                        long j15 = y0Var9.f21829f.f21875e;
                        M(cVar3, (j15 == j6 || j15 == j12) ? j6 : j15 + y0Var9.f21836o);
                    }
                }
            }
            a1 a1Var6 = this.T;
            y0 y0Var14 = a1Var6.f21388i;
            if (y0Var14 != null && a1Var6.f21387h != y0Var14 && !y0Var14.f21830g) {
                mt.x xVar4 = y0Var14.f21835n;
                ss.m0[] m0VarArr = y0Var14.f21826c;
                boolean z23 = false;
                int i15 = 0;
                while (true) {
                    cVarArr = this.f21451d;
                    if (i15 >= cVarArr.length) {
                        break;
                    }
                    c cVar4 = cVarArr[i15];
                    if (q(cVar4)) {
                        boolean z24 = cVar4.J != m0VarArr[i15] ? z12 : false;
                        if (!xVar4.b(i15) || z24) {
                            if (!cVar4.N) {
                                mt.q qVar = xVar4.f22006c[i15];
                                int length = qVar != null ? qVar.length() : 0;
                                i0[] i0VarArr = new i0[length];
                                for (int i16 = 0; i16 < length; i16++) {
                                    i0VarArr[i16] = qVar.e(i16);
                                }
                                cVar4.v(i0VarArr, m0VarArr[i15], y0Var14.e(), y0Var14.f21836o);
                            } else if (cVar4.j()) {
                                d(cVar4);
                            } else {
                                z23 = z12;
                            }
                        }
                    }
                    i15++;
                }
                if (!z23) {
                    f(new boolean[cVarArr.length]);
                }
            }
            a1 a1Var7 = this.T;
            boolean z25 = false;
            while (X() && !this.f21450c0 && (y0Var = a1Var7.f21387h) != null && (y0Var2 = y0Var.l) != null && this.f21463m0 >= y0Var2.e() && y0Var2.f21830g) {
                if (z25) {
                    u();
                }
                y0 y0VarA = a1Var7.a();
                y0VarA.getClass();
                if (this.Y.f21672b.f29324a.equals(y0VarA.f21829f.f21871a.f29324a)) {
                    ss.s sVar = this.Y.f21672b;
                    if (sVar.f29325b == -1) {
                        ss.s sVar2 = y0VarA.f21829f.f21871a;
                        if (sVar2.f29325b != -1 || sVar.f29328e == sVar2.f29328e) {
                            z21 = false;
                        } else {
                            z21 = z12;
                        }
                    } else {
                        z21 = false;
                    }
                } else {
                    z21 = false;
                }
                z0 z0Var = y0VarA.f21829f;
                ss.s sVar3 = z0Var.f21871a;
                long j16 = z0Var.f21872b;
                this.Y = o(sVar3, j16, z0Var.f21873c, j16, !z21, 0);
                C();
                e0();
                z25 = z12;
                jVar2 = jVar2;
            }
            jVar = jVar2;
            z11 = false;
        }
        int i17 = this.Y.f21675e;
        if (i17 == z12 || i17 == 4) {
            return;
        }
        y0 y0Var15 = this.T.f21387h;
        if (y0Var15 == null) {
            this.J.f27313a.sendEmptyMessageAtTime(2, jUptimeMillis + 10);
            return;
        }
        qt.a.c("doSomeWork");
        e0();
        if (y0Var15.f21827d) {
            long jElapsedRealtime = SystemClock.elapsedRealtime() * 1000;
            y0Var15.f21824a.g(this.Y.f21686r - this.O);
            ?? r12 = z11;
            z13 = z12;
            z14 = z13;
            while (true) {
                c[] cVarArr4 = this.f21451d;
                if (r12 >= cVarArr4.length) {
                    break;
                }
                c cVar5 = cVarArr4[r12];
                if (q(cVar5)) {
                    cVar5.u(this.f21463m0, jElapsedRealtime);
                    z14 = (z14 && cVar5.j()) ? z12 : z11;
                    boolean z26 = y0Var15.f21826c[r12] != cVar5.J ? z12 : z11;
                    boolean z27 = (z26 || ((z26 || !cVar5.i()) ? z11 : z12) || cVar5.k() || cVar5.j()) ? z12 : z11;
                    z13 = (z13 && z27) ? z12 : z11;
                    if (!z27) {
                        ss.m0 m0Var4 = cVar5.J;
                        m0Var4.getClass();
                        m0Var4.a();
                    }
                }
                r12++;
            }
        } else {
            y0Var15.f21824a.e();
            z13 = z12;
            z14 = z13;
        }
        long j17 = y0Var15.f21829f.f21875e;
        boolean z28 = (z14 && y0Var15.f21827d && (j17 == j6 || j17 <= this.Y.f21686r)) ? z12 : z11;
        if (z28 && this.f21450c0) {
            this.f21450c0 = z11;
            R(this.Y.f21681m, 5, z11, z11);
        }
        if (z28 && y0Var15.f21829f.f21879i) {
            W(4);
            b0();
        } else {
            n1 n1Var2 = this.Y;
            if (n1Var2.f21675e == 2) {
                a1 a1Var8 = this.T;
                if (this.f21461k0 == 0) {
                    zR = r();
                } else if (z13) {
                    if (n1Var2.f21677g) {
                        long j18 = Y(n1Var2.f21671a, a1Var8.f21387h.f21829f.f21871a) ? this.V.f21487i : j6;
                        y0 y0Var16 = a1Var8.f21389j;
                        boolean z29 = (!y0Var16.f21827d || (y0Var16.f21828e && y0Var16.f21824a.n() != j12) || !y0Var16.f21829f.f21879i) ? z11 : z12;
                        boolean z30 = (!y0Var16.f21829f.f21871a.a() || y0Var16.f21827d) ? z11 : z12;
                        if (z29 || z30) {
                            z13 = z13;
                            j6 = j6;
                        } else {
                            h hVar = this.f21470x;
                            n1 n1Var3 = this.Y;
                            j2 j2Var2 = n1Var3.f21671a;
                            long j19 = n1Var3.f21684p;
                            y0 y0Var17 = this.T.f21389j;
                            z13 = z13;
                            long jMax = y0Var17 == null ? 0L : Math.max(0L, j19 - (this.f21463m0 - y0Var17.f21836o));
                            float f3 = this.P.mo362e().f21690d;
                            boolean z31 = this.f21452d0;
                            hVar.getClass();
                            long jY = qt.x.y(jMax, f3);
                            long jMin = z31 ? hVar.f21504e : hVar.f21503d;
                            if (j18 != j6) {
                                jMin = Math.min(j18 / 2, jMin);
                            }
                            if (jMin > 0 && jY < jMin) {
                                j4.e eVar2 = hVar.f21500a;
                                synchronized (eVar2) {
                                    i11 = eVar2.f17868e * eVar2.f17866c;
                                }
                                if (i11 < hVar.f21507h) {
                                    zR = false;
                                }
                            }
                        }
                        zR = true;
                    } else {
                        zR = z12;
                    }
                    if (zR) {
                        W(3);
                        this.f21466p0 = jVar;
                        if (X()) {
                            Z();
                        }
                    }
                } else {
                    zR = z11;
                }
                j6 = j6;
                if (zR) {
                    W(3);
                    this.f21466p0 = jVar;
                    if (X()) {
                        Z();
                    }
                }
            } else {
                z13 = z13;
                j6 = j6;
            }
            if (this.Y.f21675e == 3 && (this.f21461k0 != 0 ? !z13 : !r())) {
                this.f21452d0 = X();
                W(2);
                if (this.f21452d0) {
                    for (y0 y0Var18 = this.T.f21387h; y0Var18 != null; y0Var18 = y0Var18.l) {
                        for (mt.q qVar2 : y0Var18.f21835n.f22006c) {
                            if (qVar2 != null) {
                                qVar2.o();
                            }
                        }
                    }
                    g gVar = this.V;
                    long j21 = gVar.f21487i;
                    if (j21 != j6) {
                        long j22 = j21 + gVar.f21481c;
                        gVar.f21487i = j22;
                        long j23 = gVar.f21486h;
                        if (j23 != j6 && j22 > j23) {
                            gVar.f21487i = j23;
                        }
                        gVar.f21489m = j6;
                    }
                }
                b0();
            }
        }
        if (this.Y.f21675e == 2) {
            int i18 = 0;
            while (true) {
                c[] cVarArr5 = this.f21451d;
                if (i18 >= cVarArr5.length) {
                    break;
                }
                if (q(cVarArr5[i18]) && (m0Var = this.f21451d[i18].J) == y0Var15.f21826c[i18]) {
                    m0Var.getClass();
                    m0Var.a();
                }
                i18++;
            }
            n1 n1Var4 = this.Y;
            if (n1Var4.f21677g || n1Var4.f21685q >= 500000 || !p()) {
                z15 = false;
            } else {
                z15 = true;
            }
        } else {
            z15 = false;
        }
        if (!z15) {
            this.f21467q0 = -9223372036854775807L;
        } else if (this.f21467q0 == -9223372036854775807L) {
            this.R.getClass();
            this.f21467q0 = SystemClock.elapsedRealtime();
        } else {
            this.R.getClass();
            if (SystemClock.elapsedRealtime() - this.f21467q0 >= 4000) {
                throw new IllegalStateException("Playback stuck buffering and not loading");
            }
        }
        boolean z32 = X() && this.Y.f21675e == 3;
        boolean z33 = this.f21460j0 && this.f21459i0 && z32;
        n1 n1Var5 = this.Y;
        if (n1Var5.f21683o != z33) {
            z16 = z33;
            this.Y = new n1(n1Var5.f21671a, n1Var5.f21672b, n1Var5.f21673c, n1Var5.f21674d, n1Var5.f21675e, n1Var5.f21676f, n1Var5.f21677g, n1Var5.f21678h, n1Var5.f21679i, n1Var5.f21680j, n1Var5.k, n1Var5.l, n1Var5.f21681m, n1Var5.f21682n, n1Var5.f21684p, n1Var5.f21685q, n1Var5.f21686r, n1Var5.f21687s, z16);
        } else {
            z16 = z33;
        }
        this.f21459i0 = false;
        if (!z16 && (i12 = this.Y.f21675e) != 4) {
            if (z32 || i12 == 2) {
                this.J.f27313a.sendEmptyMessageAtTime(2, jUptimeMillis + 10);
            } else if (i12 == 3 && this.f21461k0 != 0) {
                this.J.f27313a.sendEmptyMessageAtTime(2, jUptimeMillis + 1000);
            }
        }
        qt.a.t();
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00b2  */
    /* JADX WARN: Type inference failed for: r2v24, types: [java.lang.Object, ss.q] */
    public final void e0() {
        o1 o1VarMo362e;
        char c11;
        long jMax;
        y0 y0Var = this.T.f21387h;
        if (y0Var == null) {
            return;
        }
        long jL = y0Var.f21827d ? y0Var.f21824a.l() : -9223372036854775807L;
        if (jL != -9223372036854775807L) {
            D(jL);
            if (jL != this.Y.f21686r) {
                n1 n1Var = this.Y;
                this.Y = o(n1Var.f21672b, jL, n1Var.f21673c, jL, true, 5);
            }
        } else {
            f80.e eVar = this.P;
            boolean z11 = y0Var != this.T.f21388i;
            io.sentry.android.core.q qVar = (io.sentry.android.core.q) eVar.f11490v;
            c cVar = (c) eVar.f11492x;
            if (cVar == null || cVar.j() || (!((c) eVar.f11492x).k() && (z11 || ((c) eVar.f11492x).i()))) {
                eVar.f11488e = true;
                if (eVar.f11489i) {
                    qVar.f();
                }
            } else {
                qt.j jVar = (qt.j) eVar.y;
                jVar.getClass();
                long jA = jVar.a();
                if (!eVar.f11488e) {
                    qVar.c(jA);
                    o1VarMo362e = jVar.mo362e();
                    if (!o1VarMo362e.equals((o1) qVar.f16228x)) {
                        qVar.b(o1VarMo362e);
                        ((f0) eVar.f11491w).J.a(16, o1VarMo362e).b();
                    }
                } else if (jA >= qVar.a()) {
                    eVar.f11488e = false;
                    if (eVar.f11489i) {
                        qVar.f();
                    }
                    qVar.c(jA);
                    o1VarMo362e = jVar.mo362e();
                    if (!o1VarMo362e.equals((o1) qVar.f16228x)) {
                        qVar.b(o1VarMo362e);
                        ((f0) eVar.f11491w).J.a(16, o1VarMo362e).b();
                    }
                } else if (qVar.f16224e) {
                    qVar.c(qVar.a());
                    qVar.f16224e = false;
                }
            }
            long jA2 = eVar.a();
            this.f21463m0 = jA2;
            long j6 = jA2 - y0Var.f21836o;
            long j11 = this.Y.f21686r;
            ArrayList arrayList = this.Q;
            if (!arrayList.isEmpty() && !this.Y.f21672b.a()) {
                if (this.f21465o0) {
                    this.f21465o0 = false;
                }
                n1 n1Var2 = this.Y;
                n1Var2.f21671a.b(n1Var2.f21672b.f29324a);
                int iMin = Math.min(this.f21464n0, arrayList.size());
                if (iMin > 0 && arrayList.get(iMin - 1) != null) {
                    throw new ClassCastException();
                }
                if (iMin < arrayList.size() && arrayList.get(iMin) != null) {
                    throw new ClassCastException();
                }
                this.f21464n0 = iMin;
            }
            n1 n1Var3 = this.Y;
            n1Var3.f21686r = j6;
            n1Var3.f21687s = SystemClock.elapsedRealtime();
        }
        this.Y.f21684p = this.T.f21389j.d();
        n1 n1Var4 = this.Y;
        long j12 = n1Var4.f21684p;
        y0 y0Var2 = this.T.f21389j;
        n1Var4.f21685q = y0Var2 == null ? 0L : Math.max(0L, j12 - (this.f21463m0 - y0Var2.f21836o));
        n1 n1Var5 = this.Y;
        if (n1Var5.l && n1Var5.f21675e == 3 && Y(n1Var5.f21671a, n1Var5.f21672b)) {
            n1 n1Var6 = this.Y;
            float f3 = 1.0f;
            if (n1Var6.f21682n.f21690d == 1.0f) {
                g gVar = this.V;
                long jG = g(n1Var6.f21671a, n1Var6.f21672b.f29324a, n1Var6.f21686r);
                long j13 = this.Y.f21684p;
                y0 y0Var3 = this.T.f21389j;
                if (y0Var3 == null) {
                    jMax = 0;
                    c11 = 1;
                } else {
                    c11 = 1;
                    jMax = Math.max(0L, j13 - (this.f21463m0 - y0Var3.f21836o));
                }
                if (gVar.f21482d != -9223372036854775807) {
                    long j14 = jG - jMax;
                    long j15 = gVar.f21490n;
                    if (j15 == -9223372036854775807) {
                        gVar.f21490n = j14;
                        gVar.f21491o = 0L;
                    } else {
                        long jMax2 = Math.max(j14, (long) ((j14 * 9.999871E-4f) + (j15 * 0.999f)));
                        gVar.f21490n = jMax2;
                        gVar.f21491o = (long) ((9.999871E-4f * Math.abs(j14 - jMax2)) + (0.999f * gVar.f21491o));
                    }
                    if (gVar.f21489m == -9223372036854775807 || SystemClock.elapsedRealtime() - gVar.f21489m >= 1000) {
                        gVar.f21489m = SystemClock.elapsedRealtime();
                        long j16 = (gVar.f21491o * 3) + gVar.f21490n;
                        if (gVar.f21487i > j16) {
                            float fI = qt.x.I(1000L);
                            long j17 = ((long) ((gVar.l - 1.0f) * fI)) + ((long) ((gVar.f21488j - 1.0f) * fI));
                            long j18 = gVar.f21484f;
                            long j19 = gVar.f21487i - j17;
                            long[] jArr = new long[3];
                            jArr[0] = j16;
                            jArr[c11] = j18;
                            jArr[2] = j19;
                            gVar.f21487i = com.facebook.imagepipeline.nativecode.b.S(jArr);
                        } else {
                            long j21 = qt.x.j(jG - ((long) (Math.max(0.0f, gVar.l - 1.0f) / 1.0E-7f)), gVar.f21487i, j16);
                            gVar.f21487i = j21;
                            long j22 = gVar.f21486h;
                            if (j22 != -9223372036854775807 && j21 > j22) {
                                gVar.f21487i = j22;
                            }
                        }
                        long j23 = jG - gVar.f21487i;
                        if (Math.abs(j23) < gVar.f21480b) {
                            gVar.l = 1.0f;
                        } else {
                            gVar.l = qt.x.h((1.0E-7f * j23) + 1.0f, gVar.k, gVar.f21488j);
                        }
                        f3 = gVar.l;
                    } else {
                        f3 = gVar.l;
                    }
                }
                if (this.P.mo362e().f21690d != f3) {
                    o1 o1Var = new o1(f3, this.Y.f21682n.f21691e);
                    this.J.f27313a.removeMessages(16);
                    this.P.b(o1Var);
                    n(this.Y.f21682n, this.P.mo362e().f21690d, false, false);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:58:0x0112  */
    public final void f(boolean[] zArr) throws j {
        c[] cVarArr;
        Set set;
        mt.x xVar;
        int i11;
        c[] cVarArr2;
        qt.j jVar;
        a1 a1Var = this.T;
        y0 y0Var = a1Var.f21388i;
        mt.x xVar2 = y0Var.f21835n;
        int i12 = 0;
        while (true) {
            cVarArr = this.f21451d;
            int length = cVarArr.length;
            set = this.f21453e;
            if (i12 >= length) {
                break;
            }
            if (!xVar2.b(i12) && set.remove(cVarArr[i12])) {
                cVarArr[i12].w();
            }
            i12++;
        }
        int i13 = 0;
        while (i13 < cVarArr.length) {
            if (xVar2.b(i13)) {
                boolean z11 = zArr[i13];
                c cVar = cVarArr[i13];
                if (q(cVar)) {
                    xVar = xVar2;
                    i11 = i13;
                    cVarArr2 = cVarArr;
                } else {
                    y0 y0Var2 = a1Var.f21388i;
                    boolean z12 = y0Var2 == a1Var.f21387h;
                    mt.x xVar3 = y0Var2.f21835n;
                    a2 a2Var = xVar3.f22005b[i13];
                    mt.q qVar = xVar3.f22006c[i13];
                    int length2 = qVar != null ? qVar.length() : 0;
                    i0[] i0VarArr = new i0[length2];
                    for (int i14 = 0; i14 < length2; i14++) {
                        i0VarArr[i14] = qVar.e(i14);
                    }
                    boolean z13 = X() && this.Y.f21675e == 3;
                    boolean z14 = !z11 && z13;
                    this.f21461k0++;
                    set.add(cVar);
                    ss.m0 m0Var = y0Var2.f21826c[i13];
                    xVar = xVar2;
                    long j6 = this.f21463m0;
                    long jE = y0Var2.e();
                    i11 = i13;
                    cVarArr2 = cVarArr;
                    long j11 = y0Var2.f21836o;
                    qt.a.k(cVar.y == 0);
                    cVar.f21408v = a2Var;
                    cVar.y = 1;
                    cVar.m(z14, z12);
                    cVar.v(i0VarArr, m0Var, jE, j11);
                    cVar.N = false;
                    cVar.M = j6;
                    cVar.n(j6, z14);
                    cVar.c(11, new a0(this));
                    f80.e eVar = this.P;
                    eVar.getClass();
                    qt.j jVarG = cVar.g();
                    if (jVarG != null && jVarG != (jVar = (qt.j) eVar.y)) {
                        if (jVar != null) {
                            throw new j(2, new IllegalStateException("Multiple renderer media clocks enabled."), RNCWebViewManager.COMMAND_CLEAR_FORM_DATA);
                        }
                        eVar.y = jVarG;
                        eVar.f11492x = cVar;
                        ((or.i0) jVarG).b((o1) ((io.sentry.android.core.q) eVar.f11490v).f16228x);
                    }
                    if (z13) {
                        qt.a.k(cVar.y == 1);
                        cVar.y = 2;
                        cVar.q();
                    }
                }
            } else {
                xVar = xVar2;
                i11 = i13;
                cVarArr2 = cVarArr;
            }
            i13 = i11 + 1;
            xVar2 = xVar;
            cVarArr = cVarArr2;
        }
        y0Var.f21830g = true;
    }

    public final void f0(j2 j2Var, ss.s sVar, j2 j2Var2, ss.s sVar2, long j6, boolean z11) {
        boolean zY = Y(j2Var, sVar);
        Object obj = sVar.f29324a;
        if (!zY) {
            o1 o1Var = sVar.a() ? o1.f21689v : this.Y.f21682n;
            f80.e eVar = this.P;
            if (eVar.mo362e().equals(o1Var)) {
                return;
            }
            this.J.f27313a.removeMessages(16);
            eVar.b(o1Var);
            n(this.Y.f21682n, o1Var.f21690d, false, false);
            return;
        }
        h2 h2Var = this.N;
        int i11 = j2Var.g(obj, h2Var).f21537i;
        i2 i2Var = this.M;
        j2Var.n(i11, i2Var);
        q0 q0Var = i2Var.M;
        int i12 = qt.x.f27318a;
        g gVar = this.V;
        gVar.getClass();
        gVar.f21482d = qt.x.I(q0Var.f21707d);
        gVar.f21485g = qt.x.I(q0Var.f21708e);
        gVar.f21486h = qt.x.I(q0Var.f21709i);
        float f3 = q0Var.f21710v;
        if (f3 == -3.4028235E38f) {
            f3 = 0.97f;
        }
        gVar.k = f3;
        float f11 = q0Var.f21711w;
        if (f11 == -3.4028235E38f) {
            f11 = 1.03f;
        }
        gVar.f21488j = f11;
        if (f3 == 1.0f && f11 == 1.0f) {
            gVar.f21482d = -9223372036854775807L;
        }
        gVar.a();
        if (j6 != -9223372036854775807L) {
            gVar.f21483e = g(j2Var, obj, j6);
            gVar.a();
            return;
        }
        if (!qt.x.a(!j2Var2.p() ? j2Var2.m(j2Var2.g(sVar2.f29324a, h2Var).f21537i, i2Var, 0L).f21590d : null, i2Var.f21590d) || z11) {
            gVar.f21483e = -9223372036854775807L;
            gVar.a();
        }
    }

    public final long g(j2 j2Var, Object obj, long j6) {
        h2 h2Var = this.N;
        int i11 = j2Var.g(obj, h2Var).f21537i;
        i2 i2Var = this.M;
        j2Var.n(i11, i2Var);
        if (i2Var.f21595x != -9223372036854775807L && i2Var.a() && i2Var.K) {
            return qt.x.I(qt.x.v(i2Var.y) - i2Var.f21595x) - (j6 + h2Var.f21539w);
        }
        return -9223372036854775807L;
    }

    public final synchronized void g0(f4.o oVar, long j6) {
        this.R.getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime() + j6;
        boolean z11 = false;
        while (!((Boolean) oVar.get()).booleanValue() && j6 > 0) {
            try {
                this.R.getClass();
                wait(j6);
            } catch (InterruptedException unused) {
                z11 = true;
            }
            this.R.getClass();
            j6 = jElapsedRealtime - SystemClock.elapsedRealtime();
        }
        if (z11) {
            Thread.currentThread().interrupt();
        }
    }

    public final Pair h(j2 j2Var) {
        if (j2Var.p()) {
            return Pair.create(n1.f21670t, 0L);
        }
        Pair pairI = j2Var.i(this.M, this.N, j2Var.a(this.f21456g0), -9223372036854775807L);
        ss.s sVarN = this.T.n(j2Var, pairI.first, 0L);
        long jLongValue = ((Long) pairI.second).longValue();
        if (sVarN.a()) {
            Object obj = sVarN.f29324a;
            h2 h2Var = this.N;
            j2Var.g(obj, h2Var);
            jLongValue = sVarN.f29326c == h2Var.f(sVarN.f29325b) ? h2Var.y.f30645e : 0L;
        }
        return Pair.create(sVarN, Long.valueOf(jLongValue));
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) throws Throwable {
        int i11;
        y0 y0Var;
        y0 y0Var2;
        int i12 = RNCWebViewManager.COMMAND_CLEAR_FORM_DATA;
        try {
            switch (message.what) {
                case 0:
                    x();
                    break;
                case 1:
                    R(message.arg2, 1, message.arg1 != 0, true);
                    break;
                case 2:
                    e();
                    break;
                case 3:
                    I((e0) message.obj);
                    break;
                case 4:
                    S((o1) message.obj);
                    break;
                case 5:
                    this.X = (b2) message.obj;
                    break;
                case 6:
                    a0(false, true);
                    break;
                case 7:
                    y();
                    return true;
                case 8:
                    m((ss.q) message.obj);
                    break;
                case 9:
                    i((ss.q) message.obj);
                    break;
                case 10:
                    A();
                    break;
                case 11:
                    T(message.arg1);
                    break;
                case 12:
                    U(message.arg1 != 0);
                    break;
                case 13:
                    N(message.arg1 != 0, (AtomicBoolean) message.obj);
                    break;
                case 14:
                    w1 w1Var = (w1) message.obj;
                    w1Var.getClass();
                    K(w1Var);
                    break;
                case 15:
                    L((w1) message.obj);
                    break;
                case 16:
                    o1 o1Var = (o1) message.obj;
                    n(o1Var, o1Var.f21690d, true, false);
                    break;
                case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                    O((b0) message.obj);
                    break;
                case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                    b((b0) message.obj, message.arg1);
                    break;
                case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                    a1.h.s(message.obj);
                    w();
                    throw null;
                case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                    z(message.arg1, message.arg2, (ss.p0) message.obj);
                    break;
                case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                    V((ss.p0) message.obj);
                    break;
                case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                    v();
                    break;
                case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                    Q(message.arg1 != 0);
                    break;
                case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                    P(message.arg1 == 1);
                    break;
                case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                    A();
                    H(true);
                    break;
                case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                    A();
                    H(true);
                    break;
                default:
                    return false;
            }
        } catch (RuntimeException e4) {
            if ((e4 instanceof IllegalStateException) || (e4 instanceof IllegalArgumentException)) {
                i12 = 1004;
            }
            j jVar = new j(2, e4, i12);
            qt.a.s("ExoPlayerImplInternal", "Playback error", jVar);
            a0(true, false);
            this.Y = this.Y.e(jVar);
        } catch (j e9) {
            e = e9;
            int i13 = e.f21596i;
            a1 a1Var = this.T;
            if (i13 == 1 && (y0Var2 = a1Var.f21388i) != null) {
                e = e.a(y0Var2.f21829f.f21871a);
            }
            if (e.K && this.f21466p0 == null) {
                qt.a.O("ExoPlayerImplInternal", "Recoverable renderer error", e);
                this.f21466p0 = e;
                qt.u uVar = this.J;
                qt.t tVarA = uVar.a(25, e);
                Handler handler = uVar.f27313a;
                Message message2 = tVarA.f27311a;
                message2.getClass();
                handler.sendMessageAtFrontOfQueue(message2);
                tVarA.a();
            } else {
                j jVar2 = this.f21466p0;
                if (jVar2 != null) {
                    jVar2.addSuppressed(e);
                    e = this.f21466p0;
                }
                qt.a.s("ExoPlayerImplInternal", "Playback error", e);
                if (e.f21596i == 1 && a1Var.f21387h != a1Var.f21388i) {
                    while (true) {
                        y0Var = a1Var.f21387h;
                        if (y0Var == a1Var.f21388i) {
                            break;
                        }
                        a1Var.a();
                    }
                    y0Var.getClass();
                    z0 z0Var = y0Var.f21829f;
                    ss.s sVar = z0Var.f21871a;
                    long j6 = z0Var.f21872b;
                    this.Y = o(sVar, j6, z0Var.f21873c, j6, true, 0);
                }
                a0(true, false);
                this.Y = this.Y.e(e);
            }
        } catch (k1 e11) {
            boolean z11 = e11.f21634d;
            int i14 = e11.f21635e;
            if (i14 == 1) {
                i11 = z11 ? 3001 : 3003;
            } else {
                if (i14 == 4) {
                    i11 = z11 ? 3002 : 3004;
                }
                j(i12, e11);
            }
            i12 = i11;
            j(i12, e11);
        } catch (ot.n e12) {
            j(e12.f25071d, e12);
        } catch (sr.i e13) {
            j(e13.f29191d, e13);
        } catch (ss.b e14) {
            j(RNCWebViewManager.COMMAND_CLEAR_HISTORY, e14);
        } catch (IOException e15) {
            j(2000, e15);
        }
        u();
        return true;
    }

    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Object, ss.o0] */
    public final void i(ss.q qVar) {
        y0 y0Var = this.T.f21389j;
        if (y0Var == null || y0Var.f21824a != qVar) {
            return;
        }
        long j6 = this.f21463m0;
        if (y0Var != null) {
            qt.a.k(y0Var.l == null);
            if (y0Var.f21827d) {
                y0Var.f21824a.p(j6 - y0Var.f21836o);
            }
        }
        t();
    }

    public final void j(int i11, IOException iOException) {
        j jVar = new j(0, iOException, i11);
        y0 y0Var = this.T.f21387h;
        if (y0Var != null) {
            jVar = jVar.a(y0Var.f21829f.f21871a);
        }
        qt.a.s("ExoPlayerImplInternal", "Playback error", jVar);
        a0(false, false);
        this.Y = this.Y.e(jVar);
    }

    public final void k(boolean z11) {
        y0 y0Var = this.T.f21389j;
        ss.s sVar = y0Var == null ? this.Y.f21672b : y0Var.f21829f.f21871a;
        boolean zEquals = this.Y.k.equals(sVar);
        if (!zEquals) {
            this.Y = this.Y.b(sVar);
        }
        n1 n1Var = this.Y;
        n1Var.f21684p = y0Var == null ? n1Var.f21686r : y0Var.d();
        n1 n1Var2 = this.Y;
        long j6 = n1Var2.f21684p;
        y0 y0Var2 = this.T.f21389j;
        n1Var2.f21685q = y0Var2 != null ? Math.max(0L, j6 - (this.f21463m0 - y0Var2.f21836o)) : 0L;
        if ((!zEquals || z11) && y0Var != null && y0Var.f21827d) {
            d0(y0Var.f21835n);
        }
    }

    /* JADX WARN: Code duplicated, block: B:166:0x0300 A[Catch: all -> 0x0306, TRY_ENTER, TryCatch #2 {all -> 0x0306, blocks: (B:166:0x0300, B:179:0x031e, B:181:0x0328, B:183:0x032e, B:185:0x0338, B:186:0x0345), top: B:263:0x028b }] */
    /* JADX WARN: Code duplicated, block: B:201:0x036b  */
    /* JADX WARN: Code duplicated, block: B:202:0x036d  */
    /* JADX WARN: Code duplicated, block: B:205:0x0378  */
    /* JADX WARN: Code duplicated, block: B:209:0x0383  */
    /* JADX WARN: Code duplicated, block: B:211:0x038d A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:217:0x03a2  */
    /* JADX WARN: Code duplicated, block: B:220:0x03ae  */
    /* JADX WARN: Code duplicated, block: B:222:0x03b4  */
    /* JADX WARN: Code duplicated, block: B:226:0x03d6  */
    /* JADX WARN: Code duplicated, block: B:91:0x01f1  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v1 */
    /* JADX WARN: Type inference failed for: r11v2, types: [mr.j2] */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v5 */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r12v19 */
    /* JADX WARN: Type inference failed for: r12v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r12v20 */
    /* JADX WARN: Type inference failed for: r12v21 */
    /* JADX WARN: Type inference failed for: r12v22 */
    /* JADX WARN: Type inference failed for: r12v23 */
    /* JADX WARN: Type inference failed for: r12v24 */
    /* JADX WARN: Type inference failed for: r12v25 */
    /* JADX WARN: Type inference failed for: r12v26 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r19v1 */
    /* JADX WARN: Type inference failed for: r19v10 */
    /* JADX WARN: Type inference failed for: r19v11 */
    /* JADX WARN: Type inference failed for: r19v12 */
    /* JADX WARN: Type inference failed for: r19v15 */
    /* JADX WARN: Type inference failed for: r19v16 */
    /* JADX WARN: Type inference failed for: r19v17 */
    /* JADX WARN: Type inference failed for: r19v18 */
    /* JADX WARN: Type inference failed for: r19v19 */
    /* JADX WARN: Type inference failed for: r19v2 */
    /* JADX WARN: Type inference failed for: r19v20 */
    /* JADX WARN: Type inference failed for: r19v21 */
    /* JADX WARN: Type inference failed for: r19v22 */
    /* JADX WARN: Type inference failed for: r19v23 */
    /* JADX WARN: Type inference failed for: r19v24 */
    /* JADX WARN: Type inference failed for: r19v3 */
    /* JADX WARN: Type inference failed for: r19v4 */
    /* JADX WARN: Type inference failed for: r19v5 */
    /* JADX WARN: Type inference failed for: r19v6 */
    /* JADX WARN: Type inference failed for: r19v7 */
    /* JADX WARN: Type inference failed for: r19v8 */
    /* JADX WARN: Type inference failed for: r19v9 */
    /* JADX WARN: Type inference failed for: r27v0 */
    /* JADX WARN: Type inference failed for: r27v1 */
    /* JADX WARN: Type inference failed for: r27v2 */
    /* JADX WARN: Type inference failed for: r2v23, types: [mr.j2] */
    /* JADX WARN: Type inference failed for: r2v28, types: [mr.n1] */
    /* JADX WARN: Type inference failed for: r2v51, types: [mr.a1] */
    /* JADX WARN: Type inference failed for: r39v0, types: [mr.f0] */
    /* JADX WARN: Type inference failed for: r3v53 */
    /* JADX WARN: Type inference failed for: r3v54 */
    /* JADX WARN: Type inference failed for: r3v67 */
    /* JADX WARN: Type inference failed for: r5v34 */
    /* JADX WARN: Type inference failed for: r5v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r5v36 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v13 */
    /* JADX WARN: Type inference failed for: r7v20 */
    /* JADX WARN: Type inference failed for: r7v21 */
    /* JADX WARN: Type inference failed for: r7v23 */
    /* JADX WARN: Type inference failed for: r7v25 */
    /* JADX WARN: Type inference failed for: r7v26 */
    /* JADX WARN: Type inference failed for: r7v27 */
    /* JADX WARN: Type inference failed for: r7v28 */
    /* JADX WARN: Type inference failed for: r7v34 */
    /* JADX WARN: Type inference failed for: r7v38, types: [mr.j2] */
    /* JADX WARN: Type inference failed for: r7v39 */
    /* JADX WARN: Type inference failed for: r7v40 */
    /* JADX WARN: Type inference failed for: r9v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v22 */
    /* JADX WARN: Type inference failed for: r9v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v24 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void l(j2 j2Var, boolean z11) throws Throwable {
        Object obj;
        i2 i2Var;
        long j6;
        int iA;
        int i11;
        boolean z12;
        boolean z13;
        boolean z14;
        int iA2;
        boolean z15;
        j2 j2Var2;
        long j11;
        ?? r11;
        boolean z16;
        long j12;
        d0 d0Var;
        int i12;
        long jLongValue;
        boolean z17;
        int i13;
        boolean z18;
        boolean z19;
        long j13;
        int iA3;
        boolean z21;
        ?? r19;
        ?? r12;
        ss.s sVar;
        long j14;
        ?? r13;
        ?? r110;
        boolean z22;
        boolean z23;
        ?? r111;
        ?? r14;
        ?? r15;
        long j15;
        c[] cVarArr;
        a1 a1Var;
        ?? r112;
        ?? r16;
        long j16;
        ss.s sVar2;
        Object obj2;
        ?? r17;
        int i14;
        ?? r113;
        ?? r18;
        n1 n1Var = this.Y;
        e0 e0Var = this.f21462l0;
        a1 a1Var2 = this.T;
        int i15 = this.f21455f0;
        boolean z24 = this.f21456g0;
        i2 i2Var2 = this.M;
        h2 h2Var = this.N;
        ?? r114 = 4;
        if (j2Var.p()) {
            ss.s sVar3 = n1.f21670t;
            j2Var2 = j2Var;
            d0Var = new d0(sVar3, 0L, -9223372036854775807L, false, true, false);
            j6 = 0;
            r19 = sVar3;
        } else {
            ss.s sVar4 = n1Var.f21672b;
            Object obj3 = sVar4.f29324a;
            j2 j2Var3 = n1Var.f21671a;
            boolean zP = j2Var3.p();
            boolean z25 = zP || j2Var3.g(sVar4.f29324a, h2Var).f21540x;
            long jLongValue2 = (n1Var.f21672b.a() || z25) ? n1Var.f21673c : n1Var.f21686r;
            if (e0Var != null) {
                Pair pairF = F(j2Var, e0Var, true, i15, z24, i2Var2, h2Var);
                if (pairF == null) {
                    iA3 = j2Var.a(z24);
                    j13 = jLongValue2;
                    obj = obj3;
                    z19 = false;
                    z21 = true;
                    z18 = false;
                } else {
                    if (e0Var.f21435c == -9223372036854775807L) {
                        jLongValue = jLongValue2;
                        obj = obj3;
                        z17 = false;
                        i13 = j2Var.g(pairF.first, h2Var).f21537i;
                    } else {
                        obj = pairF.first;
                        jLongValue = ((Long) pairF.second).longValue();
                        z17 = true;
                        i13 = -1;
                    }
                    z18 = z17;
                    z19 = n1Var.f21675e == 4;
                    j13 = jLongValue;
                    iA3 = i13;
                    z21 = false;
                }
                z12 = z19;
                z13 = z21;
                z14 = z18;
                iA = iA3;
                i11 = -1;
                j6 = 0;
                jLongValue2 = j13;
                i2Var = i2Var2;
            } else {
                obj = obj3;
                if (n1Var.f21671a.p()) {
                    iA = j2Var.a(z24);
                    i2Var = i2Var2;
                } else if (j2Var.b(obj) == -1) {
                    Object objG = G(i2Var2, h2Var, i15, z24, obj, n1Var.f21671a, j2Var);
                    i2Var = i2Var2;
                    if (objG == null) {
                        h2Var = h2Var;
                        iA2 = j2Var.a(z24);
                        z15 = true;
                    } else {
                        h2Var = h2Var;
                        iA2 = j2Var.g(objG, h2Var).f21537i;
                        z15 = false;
                    }
                    iA = iA2;
                    z13 = z15;
                    jLongValue2 = jLongValue2;
                    obj = obj;
                    i11 = -1;
                    j6 = 0;
                    z12 = false;
                    z14 = false;
                } else {
                    i2Var = i2Var2;
                    if (jLongValue2 == -9223372036854775807L) {
                        iA = j2Var.g(obj, h2Var).f21537i;
                    } else if (z25) {
                        n1Var.f21671a.g(sVar4.f29324a, h2Var);
                        if (n1Var.f21671a.m(h2Var.f21537i, i2Var, 0L).Q == n1Var.f21671a.b(sVar4.f29324a)) {
                            j6 = 0;
                            Pair pairI = j2Var.i(i2Var, h2Var, j2Var.g(obj, h2Var).f21537i, jLongValue2 + h2Var.f21539w);
                            obj = pairI.first;
                            jLongValue2 = ((Long) pairI.second).longValue();
                        } else {
                            j6 = 0;
                            jLongValue2 = jLongValue2;
                            obj = obj;
                        }
                        iA = -1;
                        i11 = -1;
                        z12 = false;
                        z13 = false;
                        z14 = true;
                    } else {
                        j6 = 0;
                        iA = -1;
                        i11 = -1;
                        z12 = false;
                        z13 = false;
                        z14 = false;
                    }
                }
                i11 = -1;
                j6 = 0;
                z12 = false;
                z13 = false;
                z14 = false;
            }
            if (iA != i11) {
                int i16 = iA;
                j2Var2 = j2Var;
                Pair pairI2 = j2Var2.i(i2Var, h2Var, i16, -9223372036854775807L);
                obj = pairI2.first;
                jLongValue2 = ((Long) pairI2.second).longValue();
                j11 = -9223372036854775807L;
            } else {
                j2Var2 = j2Var;
                j11 = jLongValue2;
            }
            ss.s sVarN = a1Var2.n(j2Var2, obj, jLongValue2);
            int i17 = sVarN.f29328e;
            r11 = (!sVar4.f29324a.equals(obj) || sVar4.a() || sVarN.a() || !(i17 == i11 || ((i12 = sVar4.f29328e) != i11 && i17 >= i12))) ? 0 : 1;
            h2 h2VarG = j2Var2.g(obj, h2Var);
            if (z25 || jLongValue2 != j11) {
                z16 = false;
            } else {
                Object obj4 = sVar4.f29324a;
                int i18 = sVar4.f29326c;
                int i19 = sVar4.f29325b;
                if (obj4.equals(sVarN.f29324a) && (!(sVar4.a() && h2VarG.h(i19)) ? sVarN.a() && h2VarG.h(sVarN.f29325b) : !(h2VarG.e(i19, i18) == 4 || h2VarG.e(i19, i18) == 2))) {
                    z16 = true;
                } else {
                    z16 = false;
                }
            }
            if (r11 != 0 || z16) {
                sVarN = sVar4;
            }
            if (!sVarN.a()) {
                j12 = jLongValue2;
            } else if (sVarN.equals(sVar4)) {
                jLongValue2 = n1Var.f21686r;
                j12 = jLongValue2;
            } else {
                j2Var2.g(sVarN.f29324a, h2Var);
                j12 = sVarN.f29326c == h2Var.f(sVarN.f29325b) ? h2Var.y.f30645e : j6;
            }
            d0Var = new d0(sVarN, j12, j11, z12, z13, z14);
            r19 = zP;
        }
        ss.s sVar5 = d0Var.f21421a;
        long j17 = d0Var.f21423c;
        boolean z26 = d0Var.f21424d;
        long J = d0Var.f21422b;
        boolean z27 = (this.Y.f21672b.equals(sVar5) && J == this.Y.f21686r) ? false : true;
        try {
            if (d0Var.f21425e) {
                try {
                    z22 = true;
                    if (this.Y.f21675e != 1) {
                        try {
                            W(4);
                        } catch (Throwable th2) {
                            th = th2;
                            r12 = j2Var2;
                            sVar = sVar5;
                            j14 = j17;
                            r110 = 1;
                            r13 = 0;
                        }
                    }
                    z23 = false;
                    try {
                        B(false, false, false, true);
                    } catch (Throwable th3) {
                        th = th3;
                        r12 = j2Var2;
                        sVar = sVar5;
                        j14 = j17;
                        r110 = z22;
                        r13 = z23;
                    }
                } catch (Throwable th4) {
                    th = th4;
                    z22 = true;
                    z23 = false;
                }
            } else {
                z22 = true;
                z23 = false;
            }
            try {
                if (z27) {
                    r11 = j2Var2;
                    r19 = z22;
                    r114 = z23;
                    if (r11.p()) {
                        r18 = r114;
                        r113 = r19;
                        sVar = sVar5;
                        r16 = r18;
                        r112 = r113;
                    } else {
                        for (y0 y0Var = this.T.f21387h; y0Var != null; y0Var = y0Var.l) {
                            if (y0Var.f21829f.f21871a.equals(sVar5)) {
                                r18 = r114;
                                r113 = r19;
                                y0Var.f21829f = this.T.h(r11, y0Var.f21829f);
                                y0Var.h();
                            } else {
                                r18 = r114;
                                r113 = r19;
                            }
                        }
                        try {
                            r18 = r114;
                            r113 = r19;
                            a1 a1Var3 = this.T;
                            sVar = sVar5;
                            try {
                                J = J(sVar, J, a1Var3.f21387h != a1Var3.f21388i ? r19 == true ? 1 : 0 : r114, z26);
                                r16 = r114;
                                r112 = r19;
                            } catch (Throwable th5) {
                                th = th5;
                                J = J;
                                r15 = r11;
                                r14 = r114;
                                r111 = r19;
                            }
                        } catch (Throwable th6) {
                            th = th6;
                            sVar = sVar5;
                            r15 = r11;
                            r14 = r114;
                            r111 = r19;
                        }
                    }
                    n1 n1Var2 = this.Y;
                    j2 j2Var4 = n1Var2.f21671a;
                    ss.s sVar6 = n1Var2.f21672b;
                    if (d0Var.f21426f) {
                        j16 = J;
                    } else {
                        j16 = -9223372036854775807L;
                    }
                    sVar2 = sVar;
                    f0(j2Var, sVar2, j2Var4, sVar6, j16, false);
                    if (z27) {
                        n1 n1Var3 = this.Y;
                        obj2 = n1Var3.f21672b.f29324a;
                        j2 j2Var5 = n1Var3.f21671a;
                        if (z27) {
                            r17 = r16;
                        } else {
                            r17 = r16;
                        }
                        long j18 = this.Y.f21674d;
                        if (j2Var.b(obj2) == -1) {
                            i14 = 4;
                        } else {
                            i14 = 3;
                        }
                        this.Y = o(sVar2, J, j17, j18, r17, i14);
                    } else {
                        n1 n1Var4 = this.Y;
                        obj2 = n1Var4.f21672b.f29324a;
                        j2 j2Var6 = n1Var4.f21671a;
                        if (z27) {
                            r17 = r16;
                        } else {
                            r17 = r16;
                        }
                        long j19 = this.Y.f21674d;
                        if (j2Var.b(obj2) == -1) {
                            i14 = 4;
                        } else {
                            i14 = 3;
                        }
                        this.Y = o(sVar2, J, j17, j19, r17, i14);
                    }
                    C();
                    E(j2Var, this.Y.f21671a);
                    this.Y = this.Y.h(j2Var);
                    if (!j2Var.p()) {
                        this.f21462l0 = null;
                    }
                    k(r16);
                    return;
                }
                try {
                    a1 a1Var4 = this.T;
                    r19 = z22;
                    r114 = z23;
                    try {
                        long j21 = this.f21463m0;
                        try {
                            c[] cVarArr2 = this.f21451d;
                            y0 y0Var2 = a1Var4.f21388i;
                            try {
                                if (y0Var2 != null) {
                                    long j22 = y0Var2.f21836o;
                                    if (y0Var2.f21827d) {
                                        long jMax = j22;
                                        ?? r21 = r114;
                                        while (true) {
                                            if (r21 < cVarArr2.length) {
                                                if (q(cVarArr2[r21])) {
                                                    c cVar = cVarArr2[r21];
                                                    cVarArr = cVarArr2;
                                                    if (cVar.J == y0Var2.f21826c[r21]) {
                                                        a1Var = a1Var4;
                                                        long j23 = cVar.M;
                                                        if (j23 == Long.MIN_VALUE) {
                                                            j2Var = j2Var;
                                                            a1Var4 = a1Var;
                                                            j21 = j21;
                                                            j15 = Long.MIN_VALUE;
                                                            break;
                                                        }
                                                        jMax = Math.max(j23, jMax);
                                                        sVar = sVar5;
                                                        r15 = r11;
                                                        r14 = r114;
                                                        r111 = r19;
                                                        j14 = j17;
                                                        r12 = r15;
                                                        r13 = r14;
                                                        r110 = r111;
                                                    }
                                                    a1Var4 = a1Var;
                                                    cVarArr2 = cVarArr;
                                                    r21++;
                                                } else {
                                                    cVarArr = cVarArr2;
                                                }
                                                a1Var = a1Var4;
                                                a1Var4 = a1Var;
                                                cVarArr2 = cVarArr;
                                                r21++;
                                            } else {
                                                j15 = jMax;
                                                j21 = j21;
                                            }
                                        }
                                    } else {
                                        j15 = j22;
                                        j21 = j21;
                                        j2Var = j2Var;
                                    }
                                    r18 = r114;
                                    r113 = r19;
                                    if (!a1Var4.p(j2Var, j21, j15)) {
                                        H(r114);
                                        r18 = r114;
                                        r113 = r19;
                                    }
                                    r18 = r114;
                                    r113 = r19;
                                    sVar = sVar5;
                                    r16 = r18;
                                    r112 = r113;
                                    n1 n1Var5 = this.Y;
                                    j2 j2Var7 = n1Var5.f21671a;
                                    ss.s sVar7 = n1Var5.f21672b;
                                    if (d0Var.f21426f) {
                                        j16 = J;
                                    } else {
                                        j16 = -9223372036854775807L;
                                    }
                                    sVar2 = sVar;
                                    f0(j2Var, sVar2, j2Var7, sVar7, j16, false);
                                    if (z27 || j17 != this.Y.f21673c) {
                                        n1 n1Var6 = this.Y;
                                        obj2 = n1Var6.f21672b.f29324a;
                                        j2 j2Var8 = n1Var6.f21671a;
                                        if (z27 || !z11 || j2Var8.p() || j2Var8.g(obj2, this.N).f21540x) {
                                            r17 = r16;
                                        } else {
                                            r17 = r112;
                                        }
                                        long j110 = this.Y.f21674d;
                                        if (j2Var.b(obj2) == -1) {
                                            i14 = 4;
                                        } else {
                                            i14 = 3;
                                        }
                                        this.Y = o(sVar2, J, j17, j110, r17, i14);
                                    }
                                    C();
                                    E(j2Var, this.Y.f21671a);
                                    this.Y = this.Y.h(j2Var);
                                    if (!j2Var.p()) {
                                        this.f21462l0 = null;
                                    }
                                    k(r16);
                                    return;
                                }
                                j15 = j6;
                                r18 = r114;
                                r113 = r19;
                                if (!a1Var4.p(j2Var, j21, j15)) {
                                    H(r114);
                                    r18 = r114;
                                    r113 = r19;
                                }
                                r18 = r114;
                                r113 = r19;
                                sVar = sVar5;
                                r16 = r18;
                                r112 = r113;
                                n1 n1Var7 = this.Y;
                                j2 j2Var9 = n1Var7.f21671a;
                                ss.s sVar8 = n1Var7.f21672b;
                                if (d0Var.f21426f) {
                                    j16 = J;
                                } else {
                                    j16 = -9223372036854775807L;
                                }
                                sVar2 = sVar;
                                f0(j2Var, sVar2, j2Var9, sVar8, j16, false);
                                if (z27) {
                                    n1 n1Var8 = this.Y;
                                    obj2 = n1Var8.f21672b.f29324a;
                                    j2 j2Var10 = n1Var8.f21671a;
                                    if (z27) {
                                        r17 = r16;
                                    } else {
                                        r17 = r16;
                                    }
                                    long j111 = this.Y.f21674d;
                                    if (j2Var.b(obj2) == -1) {
                                        i14 = 4;
                                    } else {
                                        i14 = 3;
                                    }
                                    this.Y = o(sVar2, J, j17, j111, r17, i14);
                                } else {
                                    n1 n1Var9 = this.Y;
                                    obj2 = n1Var9.f21672b.f29324a;
                                    j2 j2Var11 = n1Var9.f21671a;
                                    if (z27) {
                                        r17 = r16;
                                    } else {
                                        r17 = r16;
                                    }
                                    long j112 = this.Y.f21674d;
                                    if (j2Var.b(obj2) == -1) {
                                        i14 = 4;
                                    } else {
                                        i14 = 3;
                                    }
                                    this.Y = o(sVar2, J, j17, j112, r17, i14);
                                }
                                C();
                                E(j2Var, this.Y.f21671a);
                                this.Y = this.Y.h(j2Var);
                                if (!j2Var.p()) {
                                    this.f21462l0 = null;
                                }
                                k(r16);
                                return;
                            } catch (Throwable th7) {
                                th = th7;
                                r11 = j2Var;
                            }
                            break;
                        } catch (Throwable th8) {
                            th = th8;
                            r11 = j2Var;
                            r114 = r114;
                        }
                    } catch (Throwable th9) {
                        th = th9;
                    }
                } catch (Throwable th10) {
                    th = th10;
                    r11 = j2Var;
                    r19 = z22;
                    r114 = z23;
                }
            } catch (Throwable th11) {
                th = th11;
            }
        } catch (Throwable th12) {
            th = th12;
            r12 = j2Var2;
            sVar = sVar5;
            j14 = j17;
            r13 = 0;
            r110 = 1;
        }
        n1 n1Var10 = this.Y;
        j2 j2Var12 = n1Var10.f21671a;
        ss.s sVar9 = n1Var10.f21672b;
        ss.s sVar10 = sVar;
        f0(r12, sVar10, j2Var12, sVar9, d0Var.f21426f ? J : -9223372036854775807L, false);
        if (z27 || j14 != this.Y.f21673c) {
            n1 n1Var11 = this.Y;
            Object obj5 = n1Var11.f21672b.f29324a;
            j2 j2Var13 = n1Var11.f21671a;
            this.Y = o(sVar10, J, j14, this.Y.f21674d, (!z27 || !z11 || j2Var13.p() || j2Var13.g(obj5, this.N).f21540x) ? r13 : r110, r12.b(obj5) == -1 ? 4 : 3);
        }
        C();
        E(r12, this.Y.f21671a);
        this.Y = this.Y.h(r12);
        if (!r12.p()) {
            this.f21462l0 = null;
        }
        k(r13);
        throw th;
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object, ss.q] */
    public final void m(ss.q qVar) throws j {
        a1 a1Var = this.T;
        y0 y0Var = a1Var.f21389j;
        if (y0Var == null || y0Var.f21824a != qVar) {
            return;
        }
        float f3 = this.P.mo362e().f21690d;
        j2 j2Var = this.Y.f21671a;
        y0Var.f21827d = true;
        y0Var.f21834m = y0Var.f21824a.m();
        mt.x xVarG = y0Var.g(f3, j2Var);
        z0 z0Var = y0Var.f21829f;
        long jMax = z0Var.f21872b;
        long j6 = z0Var.f21875e;
        if (j6 != -9223372036854775807L && jMax >= j6) {
            jMax = Math.max(0L, j6 - 1);
        }
        long jA = y0Var.a(xVarG, jMax, false, new boolean[y0Var.f21832i.length]);
        long j11 = y0Var.f21836o;
        z0 z0Var2 = y0Var.f21829f;
        y0Var.f21836o = (z0Var2.f21872b - jA) + j11;
        y0Var.f21829f = z0Var2.b(jA);
        d0(y0Var.f21835n);
        if (y0Var == a1Var.f21387h) {
            D(y0Var.f21829f.f21872b);
            f(new boolean[this.f21451d.length]);
            n1 n1Var = this.Y;
            ss.s sVar = n1Var.f21672b;
            long j12 = y0Var.f21829f.f21872b;
            this.Y = o(sVar, j12, n1Var.f21673c, j12, false, 5);
        }
        t();
    }

    public final void n(o1 o1Var, float f3, boolean z11, boolean z12) {
        int i11;
        if (z11) {
            if (z12) {
                this.Z.a(1);
            }
            this.Y = this.Y.f(o1Var);
        }
        float f11 = o1Var.f21690d;
        y0 y0Var = this.T.f21387h;
        while (true) {
            i11 = 0;
            if (y0Var == null) {
                break;
            }
            mt.q[] qVarArr = y0Var.f21835n.f22006c;
            int length = qVarArr.length;
            while (i11 < length) {
                mt.q qVar = qVarArr[i11];
                if (qVar != null) {
                    qVar.l(f11);
                }
                i11++;
            }
            y0Var = y0Var.l;
        }
        c[] cVarArr = this.f21451d;
        int length2 = cVarArr.length;
        while (i11 < length2) {
            c cVar = cVarArr[i11];
            if (cVar != null) {
                cVar.x(f3, o1Var.f21690d);
            }
            i11++;
        }
    }

    public final n1 o(ss.s sVar, long j6, long j11, long j12, boolean z11, int i11) {
        hx.w1 w1VarG;
        this.f21465o0 = (!this.f21465o0 && j6 == this.Y.f21686r && sVar.equals(this.Y.f21672b)) ? false : true;
        C();
        n1 n1Var = this.Y;
        ss.w0 w0Var = n1Var.f21678h;
        mt.x xVar = n1Var.f21679i;
        List list = n1Var.f21680j;
        if (this.U.f21605b) {
            y0 y0Var = this.T.f21387h;
            w0Var = y0Var == null ? ss.w0.f29354v : y0Var.f21834m;
            xVar = y0Var == null ? this.f21469w : y0Var.f21835n;
            mt.q[] qVarArr = xVar.f22006c;
            hx.j0 j0Var = new hx.j0(4);
            boolean z12 = false;
            for (mt.q qVar : qVarArr) {
                if (qVar != null) {
                    is.c cVar = qVar.e(0).L;
                    if (cVar == null) {
                        j0Var.c(new is.c(new is.b[0]));
                    } else {
                        j0Var.c(cVar);
                        z12 = true;
                    }
                }
            }
            if (z12) {
                w1VarG = j0Var.g();
            } else {
                hx.k0 k0Var = hx.m0.f14841e;
                w1VarG = hx.w1.f14911w;
            }
            list = w1VarG;
            if (y0Var != null) {
                z0 z0Var = y0Var.f21829f;
                if (z0Var.f21873c != j11) {
                    y0Var.f21829f = z0Var.a(j11);
                }
            }
        } else if (!sVar.equals(n1Var.f21672b)) {
            w0Var = ss.w0.f29354v;
            xVar = this.f21469w;
            list = hx.w1.f14911w;
        }
        ss.w0 w0Var2 = w0Var;
        mt.x xVar2 = xVar;
        List list2 = list;
        if (z11) {
            c0 c0Var = this.Z;
            if (!c0Var.f21414d || c0Var.f21415e == 5) {
                c0Var.f21411a = true;
                c0Var.f21414d = true;
                c0Var.f21415e = i11;
            } else {
                qt.a.g(i11 == 5);
            }
        }
        n1 n1Var2 = this.Y;
        long j13 = n1Var2.f21684p;
        y0 y0Var2 = this.T.f21389j;
        return n1Var2.c(sVar, j6, j11, j12, y0Var2 == null ? 0L : Math.max(0L, j13 - (this.f21463m0 - y0Var2.f21836o)), w0Var2, xVar2, list2);
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Object, ss.o0] */
    public final boolean p() {
        y0 y0Var = this.T.f21389j;
        if (y0Var == null) {
            return false;
        }
        return (!y0Var.f21827d ? 0L : y0Var.f21824a.j()) != Long.MIN_VALUE;
    }

    public final boolean r() {
        y0 y0Var = this.T.f21387h;
        long j6 = y0Var.f21829f.f21875e;
        if (y0Var.f21827d) {
            return j6 == -9223372036854775807L || this.Y.f21686r < j6 || !X();
        }
        return false;
    }

    @Override // ss.p
    public final void s(ss.q qVar) {
        this.J.a(8, qVar).b();
    }

    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Object, ss.q] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.Object, ss.o0] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Object, ss.o0] */
    public final void t() {
        boolean zC;
        if (p()) {
            y0 y0Var = this.T.f21389j;
            long j6 = !y0Var.f21827d ? 0L : y0Var.f21824a.j();
            y0 y0Var2 = this.T.f21389j;
            long jMax = y0Var2 == null ? 0L : Math.max(0L, j6 - (this.f21463m0 - y0Var2.f21836o));
            y0 y0Var3 = this.T.f21387h;
            zC = this.f21470x.c(jMax, this.P.mo362e().f21690d);
            if (!zC && jMax < 500000 && this.O > 0) {
                this.T.f21387h.f21824a.g(this.Y.f21686r);
                zC = this.f21470x.c(jMax, this.P.mo362e().f21690d);
            }
        } else {
            zC = false;
        }
        this.f21454e0 = zC;
        if (zC) {
            y0 y0Var4 = this.T.f21389j;
            long j11 = this.f21463m0;
            qt.a.k(y0Var4.l == null);
            y0Var4.f21824a.w(j11 - y0Var4.f21836o);
        }
        c0();
    }

    public final void u() {
        c0 c0Var = this.Z;
        n1 n1Var = this.Y;
        boolean z11 = c0Var.f21411a | (c0Var.f21412b != n1Var);
        c0Var.f21411a = z11;
        c0Var.f21412b = n1Var;
        if (z11) {
            z zVar = this.S.f21688d;
            zVar.L.c(new io.sentry.react.c(14, zVar, c0Var));
            this.Z = new c0(this.Y);
        }
    }

    public final void v() throws Throwable {
        l(this.U.e(), true);
    }

    public final void w() {
        this.Z.a(1);
        throw null;
    }

    public final void x() {
        this.Z.a(1);
        B(false, false, false, true);
        this.f21470x.b(false);
        W(this.Y.f21671a.p() ? 4 : 2);
        ot.s sVar = (ot.s) this.y;
        sVar.getClass();
        j1 j1Var = this.U;
        ArrayList arrayList = (ArrayList) j1Var.f21607d;
        qt.a.k(!j1Var.f21605b);
        j1Var.f21614m = sVar;
        for (int i11 = 0; i11 < arrayList.size(); i11++) {
            i1 i1Var = (i1) arrayList.get(i11);
            j1Var.j(i1Var);
            ((HashSet) j1Var.f21612i).add(i1Var);
        }
        j1Var.f21605b = true;
        this.J.d(2);
    }

    public final void y() {
        B(true, false, true, false);
        for (int i11 = 0; i11 < this.f21451d.length; i11++) {
            c cVar = this.f21458i[i11];
            synchronized (cVar.f21405d) {
                cVar.P = null;
            }
            c cVar2 = this.f21451d[i11];
            qt.a.k(cVar2.y == 0);
            cVar2.o();
        }
        this.f21470x.b(true);
        W(1);
        HandlerThread handlerThread = this.K;
        if (handlerThread != null) {
            handlerThread.quit();
        }
        synchronized (this) {
            this.f21448a0 = true;
            notifyAll();
        }
    }

    public final void z(int i11, int i12, ss.p0 p0Var) throws Throwable {
        this.Z.a(1);
        j1 j1Var = this.U;
        j1Var.getClass();
        qt.a.g(i11 >= 0 && i11 <= i12 && i12 <= ((ArrayList) j1Var.f21607d).size());
        j1Var.l = p0Var;
        j1Var.m(i11, i12);
        l(j1Var.e(), false);
    }
}
