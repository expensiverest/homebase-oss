package mr;

import java.util.HashSet;

/* JADX INFO: loaded from: classes3.dex */
public abstract class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final HashSet f21492a = new HashSet();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static String f21493b = "goog.exo.core";

    public static synchronized void a(String str) {
        if (f21492a.add(str)) {
            f21493b += ", " + str;
        }
    }
}
