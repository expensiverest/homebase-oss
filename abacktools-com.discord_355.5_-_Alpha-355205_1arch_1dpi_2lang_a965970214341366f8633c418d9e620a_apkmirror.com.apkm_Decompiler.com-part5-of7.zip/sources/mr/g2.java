package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class g2 extends j2 {
    @Override // mr.j2
    public final int b(Object obj) {
        return -1;
    }

    @Override // mr.j2
    public final h2 f(int i11, h2 h2Var, boolean z11) {
        throw new IndexOutOfBoundsException();
    }

    @Override // mr.j2
    public final int h() {
        return 0;
    }

    @Override // mr.j2
    public final Object l(int i11) {
        throw new IndexOutOfBoundsException();
    }

    @Override // mr.j2
    public final i2 m(int i11, i2 i2Var, long j6) {
        throw new IndexOutOfBoundsException();
    }

    @Override // mr.j2
    public final int o() {
        return 0;
    }
}
