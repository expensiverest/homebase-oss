package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class y implements b1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f21822a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public j2 f21823b;

    public y(Object obj, j2 j2Var) {
        this.f21822a = obj;
        this.f21823b = j2Var;
    }

    @Override // mr.b1
    public final Object a() {
        return this.f21822a;
    }

    @Override // mr.b1
    public final j2 b() {
        return this.f21823b;
    }
}
