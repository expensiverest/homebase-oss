package mr;

import android.net.Uri;
import android.os.Bundle;
import app.p001rive.runtime.kotlin.renderers.RendererMetrics;
import com.discord.age_assurance.DigitalCredentialModule;
import com.reactnativecommunity.webview.RNCWebViewManager;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class x0 implements e {
    public static final String A0;
    public static final String B0;
    public static final String C0;
    public static final String D0;
    public static final String E0;
    public static final String F0;
    public static final String G0;
    public static final String H0;
    public static final String I0;
    public static final String J0;
    public static final String K0;
    public static final String L0;
    public static final String M0;
    public static final String N0;
    public static final String O0;
    public static final String P0;
    public static final String Q0;
    public static final String R0;
    public static final mp.a S0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public static final x0 f21790k0 = new x0(new w0());

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public static final String f21791l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public static final String f21792m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public static final String f21793n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public static final String f21794o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public static final String f21795p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public static final String f21796q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public static final String f21797r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final String f21798s0;
    public static final String t0;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public static final String f21799u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public static final String f21800v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public static final String f21801w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public static final String f21802x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public static final String f21803y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public static final String f21804z0;
    public final z1 J;
    public final z1 K;
    public final byte[] L;
    public final Integer M;
    public final Uri N;
    public final Integer O;
    public final Integer P;
    public final Integer Q;
    public final Boolean R;
    public final Boolean S;
    public final Integer T;
    public final Integer U;
    public final Integer V;
    public final Integer W;
    public final Integer X;
    public final Integer Y;
    public final Integer Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final CharSequence f21805a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final CharSequence f21806b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public final CharSequence f21807c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final CharSequence f21808d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final Integer f21809d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final CharSequence f21810e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final Integer f21811e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final CharSequence f21812f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public final CharSequence f21813g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public final CharSequence f21814h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f21815i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public final Integer f21816i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public final Bundle f21817j0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final CharSequence f21818v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final CharSequence f21819w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final CharSequence f21820x;
    public final CharSequence y;

    static {
        int i11 = qt.x.f27318a;
        f21791l0 = Integer.toString(0, 36);
        f21792m0 = Integer.toString(1, 36);
        f21793n0 = Integer.toString(2, 36);
        f21794o0 = Integer.toString(3, 36);
        f21795p0 = Integer.toString(4, 36);
        f21796q0 = Integer.toString(5, 36);
        f21797r0 = Integer.toString(6, 36);
        f21798s0 = Integer.toString(8, 36);
        t0 = Integer.toString(9, 36);
        f21799u0 = Integer.toString(10, 36);
        f21800v0 = Integer.toString(11, 36);
        f21801w0 = Integer.toString(12, 36);
        f21802x0 = Integer.toString(13, 36);
        f21803y0 = Integer.toString(14, 36);
        f21804z0 = Integer.toString(15, 36);
        A0 = Integer.toString(16, 36);
        B0 = Integer.toString(17, 36);
        C0 = Integer.toString(18, 36);
        D0 = Integer.toString(19, 36);
        E0 = Integer.toString(20, 36);
        F0 = Integer.toString(21, 36);
        G0 = Integer.toString(22, 36);
        H0 = Integer.toString(23, 36);
        I0 = Integer.toString(24, 36);
        J0 = Integer.toString(25, 36);
        K0 = Integer.toString(26, 36);
        L0 = Integer.toString(27, 36);
        M0 = Integer.toString(28, 36);
        N0 = Integer.toString(29, 36);
        O0 = Integer.toString(30, 36);
        P0 = Integer.toString(31, 36);
        Q0 = Integer.toString(32, 36);
        R0 = Integer.toString(RNCWebViewManager.COMMAND_CLEAR_FORM_DATA, 36);
        S0 = new mp.a(27);
    }

    public x0(w0 w0Var) {
        Boolean boolValueOf = w0Var.f21767p;
        Integer numValueOf = w0Var.f21766o;
        Integer numValueOf2 = w0Var.F;
        int i11 = 1;
        int i12 = 0;
        int i13 = 0;
        if (boolValueOf != null) {
            if (!boolValueOf.booleanValue()) {
                numValueOf = -1;
            } else if (numValueOf == null || numValueOf.intValue() == -1) {
                if (numValueOf2 != null) {
                    switch (numValueOf2.intValue()) {
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                        case 13:
                        case 14:
                        case 15:
                        case 16:
                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                        case 31:
                        case 32:
                        case 33:
                        case 34:
                        case 35:
                            break;
                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                        case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                        case 27:
                        case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                        case 29:
                        case RendererMetrics.SAMPLES /* 30 */:
                        default:
                            i11 = 0;
                            break;
                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                            i11 = 2;
                            break;
                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                            i11 = 3;
                            break;
                        case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                            i11 = 4;
                            break;
                        case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                            i11 = 5;
                            break;
                        case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                            i11 = 6;
                            break;
                    }
                    i13 = i11;
                }
                numValueOf = Integer.valueOf(i13);
            }
        } else if (numValueOf != null) {
            boolean z11 = numValueOf.intValue() != -1;
            boolValueOf = Boolean.valueOf(z11);
            if (z11 && numValueOf2 == null) {
                switch (numValueOf.intValue()) {
                    case 1:
                        break;
                    case 2:
                        i12 = 21;
                        break;
                    case 3:
                        i12 = 22;
                        break;
                    case 4:
                        i12 = 23;
                        break;
                    case 5:
                        i12 = 24;
                        break;
                    case 6:
                        i12 = 25;
                        break;
                    default:
                        i12 = 20;
                        break;
                }
                numValueOf2 = Integer.valueOf(i12);
            }
        }
        this.f21808d = w0Var.f21754a;
        this.f21810e = w0Var.f21755b;
        this.f21815i = w0Var.f21756c;
        this.f21818v = w0Var.f21757d;
        this.f21819w = w0Var.f21758e;
        this.f21820x = w0Var.f21759f;
        this.y = w0Var.f21760g;
        this.J = w0Var.f21761h;
        this.K = w0Var.f21762i;
        this.L = w0Var.f21763j;
        this.M = w0Var.k;
        this.N = w0Var.l;
        this.O = w0Var.f21764m;
        this.P = w0Var.f21765n;
        this.Q = numValueOf;
        this.R = boolValueOf;
        this.S = w0Var.f21768q;
        Integer num = w0Var.f21769r;
        this.T = num;
        this.U = num;
        this.V = w0Var.f21770s;
        this.W = w0Var.f21771t;
        this.X = w0Var.f21772u;
        this.Y = w0Var.f21773v;
        this.Z = w0Var.f21774w;
        this.f21805a0 = w0Var.f21775x;
        this.f21806b0 = w0Var.y;
        this.f21807c0 = w0Var.f21776z;
        this.f21809d0 = w0Var.A;
        this.f21811e0 = w0Var.B;
        this.f21812f0 = w0Var.C;
        this.f21813g0 = w0Var.D;
        this.f21814h0 = w0Var.E;
        this.f21816i0 = numValueOf2;
        this.f21817j0 = w0Var.G;
    }

    public final w0 a() {
        w0 w0Var = new w0();
        w0Var.f21754a = this.f21808d;
        w0Var.f21755b = this.f21810e;
        w0Var.f21756c = this.f21815i;
        w0Var.f21757d = this.f21818v;
        w0Var.f21758e = this.f21819w;
        w0Var.f21759f = this.f21820x;
        w0Var.f21760g = this.y;
        w0Var.f21761h = this.J;
        w0Var.f21762i = this.K;
        w0Var.f21763j = this.L;
        w0Var.k = this.M;
        w0Var.l = this.N;
        w0Var.f21764m = this.O;
        w0Var.f21765n = this.P;
        w0Var.f21766o = this.Q;
        w0Var.f21767p = this.R;
        w0Var.f21768q = this.S;
        w0Var.f21769r = this.U;
        w0Var.f21770s = this.V;
        w0Var.f21771t = this.W;
        w0Var.f21772u = this.X;
        w0Var.f21773v = this.Y;
        w0Var.f21774w = this.Z;
        w0Var.f21775x = this.f21805a0;
        w0Var.y = this.f21806b0;
        w0Var.f21776z = this.f21807c0;
        w0Var.A = this.f21809d0;
        w0Var.B = this.f21811e0;
        w0Var.C = this.f21812f0;
        w0Var.D = this.f21813g0;
        w0Var.E = this.f21814h0;
        w0Var.F = this.f21816i0;
        w0Var.G = this.f21817j0;
        return w0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && x0.class == obj.getClass()) {
            x0 x0Var = (x0) obj;
            if (qt.x.a(this.f21808d, x0Var.f21808d) && qt.x.a(this.f21810e, x0Var.f21810e) && qt.x.a(this.f21815i, x0Var.f21815i) && qt.x.a(this.f21818v, x0Var.f21818v) && qt.x.a(this.f21819w, x0Var.f21819w) && qt.x.a(this.f21820x, x0Var.f21820x) && qt.x.a(this.y, x0Var.y) && qt.x.a(this.J, x0Var.J) && qt.x.a(this.K, x0Var.K) && Arrays.equals(this.L, x0Var.L) && qt.x.a(this.M, x0Var.M) && qt.x.a(this.N, x0Var.N) && qt.x.a(this.O, x0Var.O) && qt.x.a(this.P, x0Var.P) && qt.x.a(this.Q, x0Var.Q) && qt.x.a(this.R, x0Var.R) && qt.x.a(this.S, x0Var.S) && qt.x.a(this.U, x0Var.U) && qt.x.a(this.V, x0Var.V) && qt.x.a(this.W, x0Var.W) && qt.x.a(this.X, x0Var.X) && qt.x.a(this.Y, x0Var.Y) && qt.x.a(this.Z, x0Var.Z) && qt.x.a(this.f21805a0, x0Var.f21805a0) && qt.x.a(this.f21806b0, x0Var.f21806b0) && qt.x.a(this.f21807c0, x0Var.f21807c0) && qt.x.a(this.f21809d0, x0Var.f21809d0) && qt.x.a(this.f21811e0, x0Var.f21811e0) && qt.x.a(this.f21812f0, x0Var.f21812f0) && qt.x.a(this.f21813g0, x0Var.f21813g0) && qt.x.a(this.f21814h0, x0Var.f21814h0) && qt.x.a(this.f21816i0, x0Var.f21816i0)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f21808d, this.f21810e, this.f21815i, this.f21818v, this.f21819w, this.f21820x, this.y, this.J, this.K, Integer.valueOf(Arrays.hashCode(this.L)), this.M, this.N, this.O, this.P, this.Q, this.R, this.S, this.U, this.V, this.W, this.X, this.Y, this.Z, this.f21805a0, this.f21806b0, this.f21807c0, this.f21809d0, this.f21811e0, this.f21812f0, this.f21813g0, this.f21814h0, this.f21816i0});
    }
}
