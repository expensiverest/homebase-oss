package mr;

import android.util.Pair;

/* JADX INFO: loaded from: classes3.dex */
public final class a1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final h2 f21380a = new h2();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final i2 f21381b = new i2();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final nr.g f21382c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final qt.u f21383d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f21384e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f21385f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f21386g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public y0 f21387h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public y0 f21388i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public y0 f21389j;
    public int k;
    public Object l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f21390m;

    public a1(nr.g gVar, qt.u uVar) {
        this.f21382c = gVar;
        this.f21383d = uVar;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x005e  */
    /* JADX WARN: Code duplicated, block: B:28:0x0062 A[LOOP:0: B:3:0x0013->B:28:0x0062, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:40:0x006d A[EDGE_INSN: B:40:0x006d->B:29:0x006d BREAK  A[LOOP:0: B:3:0x0013->B:28:0x0062], SYNTHETIC] */
    public static ss.s m(j2 j2Var, Object obj, long j6, long j11, i2 i2Var, h2 h2Var) {
        j2Var.g(obj, h2Var);
        j2Var.n(h2Var.f21537i, i2Var);
        int iB = j2Var.b(obj);
        Object obj2 = obj;
        while (true) {
            int i11 = h2Var.y.f30644d;
            if (i11 == 0) {
                break;
            }
            if ((i11 == 1 && h2Var.g(0)) || !h2Var.h(h2Var.y.f30647v)) {
                break;
            }
            long j12 = 0;
            if (h2Var.c(0L) != -1) {
                break;
            }
            if (h2Var.f21538v == 0) {
                if (iB <= i2Var.R) {
                    break;
                    break;
                }
                j2Var.f(iB, h2Var, true);
                obj2 = h2Var.f21536e;
                obj2.getClass();
                iB++;
            } else {
                int i12 = i11 - (h2Var.g(i11 + (-1)) ? 2 : 1);
                for (int i13 = 0; i13 <= i12; i13++) {
                    j12 += h2Var.y.a(i13).y;
                }
                if (h2Var.f21538v > j12) {
                    break;
                }
                if (iB <= i2Var.R) {
                    break;
                }
                j2Var.f(iB, h2Var, true);
                obj2 = h2Var.f21536e;
                obj2.getClass();
                iB++;
            }
        }
        j2Var.g(obj2, h2Var);
        int iC = h2Var.c(j6);
        return iC == -1 ? new ss.s(obj2, j11, h2Var.b(j6)) : new ss.s(obj2, iC, h2Var.f(iC), j11, -1);
    }

    public final y0 a() {
        y0 y0Var = this.f21387h;
        if (y0Var == null) {
            return null;
        }
        if (y0Var == this.f21388i) {
            this.f21388i = y0Var.l;
        }
        y0Var.f();
        int i11 = this.k - 1;
        this.k = i11;
        if (i11 == 0) {
            this.f21389j = null;
            y0 y0Var2 = this.f21387h;
            this.l = y0Var2.f21825b;
            this.f21390m = y0Var2.f21829f.f21871a.f29327d;
        }
        this.f21387h = this.f21387h.l;
        k();
        return this.f21387h;
    }

    public final void b() {
        if (this.k == 0) {
            return;
        }
        y0 y0Var = this.f21387h;
        qt.a.l(y0Var);
        this.l = y0Var.f21825b;
        this.f21390m = y0Var.f21829f.f21871a.f29327d;
        while (y0Var != null) {
            y0Var.f();
            y0Var = y0Var.l;
        }
        this.f21387h = null;
        this.f21389j = null;
        this.f21388i = null;
        this.k = 0;
        k();
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00cd  */
    public final z0 c(j2 j2Var, y0 y0Var, long j6) {
        Object obj;
        long j11;
        long j12;
        long j13;
        z0 z0Var = y0Var.f21829f;
        ss.s sVar = z0Var.f21871a;
        long j14 = z0Var.f21873c;
        int iD = j2Var.d(j2Var.b(sVar.f29324a), this.f21380a, this.f21381b, this.f21385f, this.f21386g);
        if (iD == -1) {
            return null;
        }
        h2 h2Var = this.f21380a;
        int i11 = j2Var.f(iD, h2Var, true).f21537i;
        Object obj2 = h2Var.f21536e;
        obj2.getClass();
        long j15 = sVar.f29327d;
        long j16 = 0;
        if (j2Var.m(i11, this.f21381b, 0L).Q == iD) {
            Pair pairJ = j2Var.j(this.f21381b, this.f21380a, i11, -9223372036854775807L, Math.max(0L, j6));
            if (pairJ == null) {
                return null;
            }
            Object obj3 = pairJ.first;
            long jLongValue = ((Long) pairJ.second).longValue();
            y0 y0Var2 = y0Var.l;
            if (y0Var2 == null || !y0Var2.f21825b.equals(obj3)) {
                j15 = this.f21384e;
                this.f21384e = 1 + j15;
            } else {
                j15 = y0Var2.f21829f.f21871a.f29327d;
            }
            obj = obj3;
            j11 = jLongValue;
            j16 = -9223372036854775807L;
        } else {
            obj = obj2;
            j11 = 0;
        }
        ss.s sVarM = m(j2Var, obj, j11, j15, this.f21381b, this.f21380a);
        if (j16 == -9223372036854775807L || j14 == -9223372036854775807L) {
            j12 = j11;
            j13 = j16;
        } else {
            int i12 = j2Var.g(sVar.f29324a, h2Var).y.f30644d;
            int i13 = h2Var.y.f30647v;
            boolean z11 = i12 > 0 && h2Var.h(i13) && (i12 > 1 || h2Var.d(i13) != Long.MIN_VALUE);
            if (sVarM.a() && z11) {
                j12 = j11;
                j13 = j14;
            } else {
                if (z11) {
                    j12 = j14;
                } else {
                    j12 = j11;
                }
                j13 = j16;
            }
        }
        return e(j2Var, sVarM, j13, j12);
    }

    public final z0 d(j2 j2Var, y0 y0Var, long j6) {
        j2 j2Var2;
        z0 z0Var = y0Var.f21829f;
        long j11 = (y0Var.f21836o + z0Var.f21875e) - j6;
        if (z0Var.f21877g) {
            return c(j2Var, y0Var, j11);
        }
        ss.s sVar = z0Var.f21871a;
        Object obj = sVar.f29324a;
        int i11 = sVar.f29328e;
        h2 h2Var = this.f21380a;
        j2Var.g(obj, h2Var);
        if (!sVar.a()) {
            if (i11 != -1 && h2Var.g(i11)) {
                return c(j2Var, y0Var, j11);
            }
            int iF = h2Var.f(i11);
            boolean z11 = h2Var.h(i11) && h2Var.e(i11, iF) == 3;
            if (iF != h2Var.y.a(i11).f30638e && !z11) {
                return f(j2Var, sVar.f29324a, sVar.f29328e, iF, z0Var.f21875e, sVar.f29327d);
            }
            j2Var.g(obj, h2Var);
            long jD = h2Var.d(i11);
            return g(j2Var, sVar.f29324a, jD == Long.MIN_VALUE ? h2Var.f21538v : h2Var.y.a(i11).y + jD, z0Var.f21875e, sVar.f29327d);
        }
        int i12 = sVar.f29325b;
        int i13 = h2Var.y.a(i12).f30638e;
        if (i13 == -1) {
            return null;
        }
        int iA = h2Var.y.a(i12).a(sVar.f29326c);
        if (iA < i13) {
            return f(j2Var, sVar.f29324a, i12, iA, z0Var.f21873c, sVar.f29327d);
        }
        long jLongValue = z0Var.f21873c;
        if (jLongValue == -9223372036854775807L) {
            Pair pairJ = j2Var.j(this.f21381b, h2Var, h2Var.f21537i, -9223372036854775807L, Math.max(0L, j11));
            j2Var2 = j2Var;
            if (pairJ == null) {
                return null;
            }
            jLongValue = ((Long) pairJ.second).longValue();
        } else {
            j2Var2 = j2Var;
        }
        int i14 = sVar.f29325b;
        j2Var2.g(obj, h2Var);
        long jD2 = h2Var.d(i14);
        return g(j2Var, sVar.f29324a, Math.max(jD2 == Long.MIN_VALUE ? h2Var.f21538v : h2Var.y.a(i14).y + jD2, jLongValue), z0Var.f21873c, sVar.f29327d);
    }

    public final z0 e(j2 j2Var, ss.s sVar, long j6, long j11) {
        j2Var.g(sVar.f29324a, this.f21380a);
        return sVar.a() ? f(j2Var, sVar.f29324a, sVar.f29325b, sVar.f29326c, j6, sVar.f29327d) : g(j2Var, sVar.f29324a, j11, j6, sVar.f29327d);
    }

    public final z0 f(j2 j2Var, Object obj, int i11, int i12, long j6, long j11) {
        ss.s sVar = new ss.s(obj, i11, i12, j11, -1);
        h2 h2Var = this.f21380a;
        long jA = j2Var.g(obj, h2Var).a(i11, i12);
        long jMax = i12 == h2Var.f(i11) ? h2Var.y.f30645e : 0L;
        boolean zH = h2Var.h(i11);
        if (jA != -9223372036854775807L && jMax >= jA) {
            jMax = Math.max(0L, jA - 1);
        }
        return new z0(sVar, jMax, j6, -9223372036854775807L, jA, zH, false, false, false);
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0062  */
    /* JADX WARN: Code duplicated, block: B:58:0x00b1  */
    /* JADX WARN: Code duplicated, block: B:65:0x00c1  */
    public final z0 g(j2 j2Var, Object obj, long j6, long j11, long j12) {
        boolean z11;
        boolean z12;
        long j13;
        long jD;
        long j14;
        long jMax = j6;
        h2 h2Var = this.f21380a;
        j2Var.g(obj, h2Var);
        int iB = h2Var.b(jMax);
        boolean z13 = iB != -1 && h2Var.g(iB);
        if (iB == -1) {
            ts.b bVar = h2Var.y;
            if (bVar.f30644d <= 0 || !h2Var.h(bVar.f30647v)) {
                z12 = false;
            } else {
                z12 = true;
            }
        } else if (h2Var.h(iB) && h2Var.d(iB) == h2Var.f21538v) {
            ts.a aVarA = h2Var.y.a(iB);
            int i11 = aVarA.f30638e;
            if (i11 == -1) {
                z11 = true;
                break;
            }
            int i12 = 0;
            while (true) {
                if (i12 >= i11) {
                    z11 = false;
                    break;
                }
                int i13 = aVarA.f30641w[i12];
                if (i13 == 0 || i13 == 1) {
                    z11 = true;
                    break;
                }
                i12++;
            }
            if (z11) {
                z12 = false;
            } else {
                z12 = true;
                iB = -1;
            }
        } else {
            z12 = false;
        }
        ss.s sVar = new ss.s(obj, j12, iB);
        boolean z14 = !sVar.a() && iB == -1;
        boolean zJ = j(j2Var, sVar);
        boolean zI = i(j2Var, sVar, z14);
        boolean z15 = (iB == -1 || !h2Var.h(iB) || z13) ? false : true;
        if (iB == -1 || z13) {
            if (z12) {
                jD = h2Var.f21538v;
            } else {
                j13 = -9223372036854775807L;
            }
            if (j13 != -9223372036854775807L || j13 == Long.MIN_VALUE) {
                j14 = h2Var.f21538v;
            } else {
                j14 = j13;
            }
            if (j14 != -9223372036854775807L && jMax >= j14) {
                jMax = Math.max(0L, j14 - ((long) ((zI && z12) ? 0 : 1)));
            }
            return new z0(sVar, jMax, j11, j13, j14, z15, z14, zJ, zI);
        }
        jD = h2Var.d(iB);
        j13 = jD;
        if (j13 != -9223372036854775807L) {
            j14 = h2Var.f21538v;
        } else {
            j14 = h2Var.f21538v;
        }
        if (j14 != -9223372036854775807L) {
            jMax = Math.max(0L, j14 - ((long) ((zI && z12) ? 0 : 1)));
        }
        return new z0(sVar, jMax, j11, j13, j14, z15, z14, zJ, zI);
    }

    public final z0 h(j2 j2Var, z0 z0Var) {
        long jA;
        boolean zH;
        ss.s sVar = z0Var.f21871a;
        boolean zA = sVar.a();
        int i11 = sVar.f29328e;
        boolean z11 = !zA && i11 == -1;
        int i12 = sVar.f29325b;
        boolean zJ = j(j2Var, sVar);
        boolean zI = i(j2Var, sVar, z11);
        Object obj = sVar.f29324a;
        h2 h2Var = this.f21380a;
        j2Var.g(obj, h2Var);
        long jD = (sVar.a() || i11 == -1) ? -9223372036854775807L : h2Var.d(i11);
        if (sVar.a()) {
            jA = h2Var.a(i12, sVar.f29326c);
        } else {
            jA = (jD == -9223372036854775807L || jD == Long.MIN_VALUE) ? h2Var.f21538v : jD;
        }
        if (sVar.a()) {
            zH = h2Var.h(i12);
        } else {
            zH = i11 != -1 && h2Var.h(i11);
        }
        return new z0(sVar, z0Var.f21872b, z0Var.f21873c, jD, jA, zH, z11, zJ, zI);
    }

    public final boolean i(j2 j2Var, ss.s sVar, boolean z11) {
        int iB = j2Var.b(sVar.f29324a);
        if (!j2Var.m(j2Var.f(iB, this.f21380a, false).f21537i, this.f21381b, 0L).K) {
            if (j2Var.d(iB, this.f21380a, this.f21381b, this.f21385f, this.f21386g) == -1 && z11) {
                return true;
            }
        }
        return false;
    }

    public final boolean j(j2 j2Var, ss.s sVar) {
        boolean z11 = !sVar.a() && sVar.f29328e == -1;
        Object obj = sVar.f29324a;
        if (z11) {
            if (j2Var.m(j2Var.g(obj, this.f21380a).f21537i, this.f21381b, 0L).R == j2Var.b(obj)) {
                return true;
            }
        }
        return false;
    }

    public final void k() {
        hx.j0 j0VarP = hx.m0.p();
        for (y0 y0Var = this.f21387h; y0Var != null; y0Var = y0Var.l) {
            j0VarP.c(y0Var.f21829f.f21871a);
        }
        y0 y0Var2 = this.f21388i;
        this.f21383d.c(new a6.m0(17, this, j0VarP, y0Var2 == null ? null : y0Var2.f21829f.f21871a));
    }

    public final boolean l(y0 y0Var) {
        boolean z11 = false;
        qt.a.k(y0Var != null);
        if (y0Var.equals(this.f21389j)) {
            return false;
        }
        this.f21389j = y0Var;
        while (true) {
            y0Var = y0Var.l;
            if (y0Var == null) {
                break;
            }
            if (y0Var == this.f21388i) {
                this.f21388i = this.f21387h;
                z11 = true;
            }
            y0Var.f();
            this.k--;
        }
        y0 y0Var2 = this.f21389j;
        if (y0Var2.l != null) {
            y0Var2.b();
            y0Var2.l = null;
            y0Var2.c();
        }
        k();
        return z11;
    }

    public final ss.s n(j2 j2Var, Object obj, long j6) {
        long j11;
        int iB;
        Object obj2 = obj;
        h2 h2Var = this.f21380a;
        int i11 = j2Var.g(obj2, h2Var).f21537i;
        Object obj3 = this.l;
        if (obj3 == null || (iB = j2Var.b(obj3)) == -1 || j2Var.f(iB, h2Var, false).f21537i != i11) {
            y0 y0Var = this.f21387h;
            while (true) {
                if (y0Var == null) {
                    y0 y0Var2 = this.f21387h;
                    while (true) {
                        if (y0Var2 == null) {
                            j11 = this.f21384e;
                            this.f21384e = 1 + j11;
                            if (this.f21387h != null) {
                                break;
                            }
                            this.l = obj2;
                            this.f21390m = j11;
                            break;
                        }
                        int iB2 = j2Var.b(y0Var2.f21825b);
                        if (iB2 != -1 && j2Var.f(iB2, h2Var, false).f21537i == i11) {
                            j11 = y0Var2.f21829f.f21871a.f29327d;
                            break;
                        }
                        y0Var2 = y0Var2.l;
                    }
                } else {
                    if (y0Var.f21825b.equals(obj2)) {
                        j11 = y0Var.f21829f.f21871a.f29327d;
                        break;
                    }
                    y0Var = y0Var.l;
                }
            }
        } else {
            j11 = this.f21390m;
        }
        j2Var.g(obj2, h2Var);
        int i12 = h2Var.f21537i;
        i2 i2Var = this.f21381b;
        j2Var.n(i12, i2Var);
        boolean z11 = false;
        for (int iB3 = j2Var.b(obj); iB3 >= i2Var.Q; iB3--) {
            j2Var.f(iB3, h2Var, true);
            boolean z12 = h2Var.y.f30644d > 0;
            z11 |= z12;
            if (h2Var.c(h2Var.f21538v) != -1) {
                obj2 = h2Var.f21536e;
                obj2.getClass();
            }
            if (z11 && (!z12 || h2Var.f21538v != 0)) {
                break;
            }
        }
        return m(j2Var, obj2, j6, j11, this.f21381b, this.f21380a);
    }

    public final boolean o(j2 j2Var) {
        j2 j2Var2;
        y0 y0Var;
        y0 y0Var2 = this.f21387h;
        if (y0Var2 == null) {
            return true;
        }
        int iB = j2Var.b(y0Var2.f21825b);
        while (true) {
            j2Var2 = j2Var;
            iB = j2Var2.d(iB, this.f21380a, this.f21381b, this.f21385f, this.f21386g);
            while (true) {
                y0Var = y0Var2.l;
                if (y0Var == null || y0Var2.f21829f.f21877g) {
                    break;
                }
                y0Var2 = y0Var;
            }
            if (iB == -1 || y0Var == null || j2Var2.b(y0Var.f21825b) != iB) {
                break;
            }
            y0Var2 = y0Var;
            j2Var = j2Var2;
        }
        boolean zL = l(y0Var2);
        y0Var2.f21829f = h(j2Var2, y0Var2.f21829f);
        return !zL;
    }

    public final boolean p(j2 j2Var, long j6, long j11) {
        boolean zL;
        z0 z0VarH;
        y0 y0Var = this.f21387h;
        y0 y0Var2 = null;
        while (y0Var != null) {
            z0 z0Var = y0Var.f21829f;
            if (y0Var2 != null) {
                z0 z0VarD = d(j2Var, y0Var2, j6);
                if (z0VarD == null) {
                    zL = l(y0Var2);
                } else if (z0Var.f21872b == z0VarD.f21872b && z0Var.f21871a.equals(z0VarD.f21871a)) {
                    z0VarH = z0VarD;
                } else {
                    zL = l(y0Var2);
                }
                return !zL;
            }
            z0VarH = h(j2Var, z0Var);
            long j12 = z0VarH.f21875e;
            y0Var.f21829f = z0VarH.a(z0Var.f21873c);
            long j13 = z0Var.f21875e;
            if (j13 == -9223372036854775807L || j13 == j12) {
                y0Var2 = y0Var;
                y0Var = y0Var.l;
            } else {
                y0Var.h();
                boolean z11 = y0Var == this.f21388i && !y0Var.f21829f.f21876f && (j11 == Long.MIN_VALUE || j11 >= ((j12 > (-9223372036854775807L) ? 1 : (j12 == (-9223372036854775807L) ? 0 : -1)) == 0 ? Long.MAX_VALUE : y0Var.f21836o + j12));
                if (l(y0Var) || z11) {
                    return false;
                }
            }
        }
        return true;
    }
}
