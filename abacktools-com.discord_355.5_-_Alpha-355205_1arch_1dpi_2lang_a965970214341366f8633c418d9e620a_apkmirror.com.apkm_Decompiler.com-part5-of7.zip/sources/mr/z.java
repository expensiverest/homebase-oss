package mr;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Pair;
import android.util.SparseBooleanArray;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.TimeoutException;
import org.webrtc.MediaStreamTrack;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class z extends b3.l {
    public final int A0;
    public final or.d B0;
    public float C0;
    public boolean D0;
    public bt.c E0;
    public final boolean F0;
    public boolean G0;
    public rt.s H0;
    public x0 I0;
    public final c[] J;
    public n1 J0;
    public final mt.t K;
    public int K0;
    public final qt.u L;
    public long L0;
    public final o M;
    public final f0 N;
    public final n3.q O;
    public final CopyOnWriteArraySet P;
    public final h2 Q;
    public final ArrayList R;
    public final boolean S;
    public final nr.g T;
    public final Looper U;
    public final ot.f V;
    public final long W;
    public final long X;
    public final qt.s Y;
    public final w Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final x f21842a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final an.c f21843b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public final b f21844c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final al.d f21845d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final ay.f f21846e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final long f21847f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public int f21848g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public boolean f21849h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final mt.x f21850i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public int f21851i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public int f21852j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public boolean f21853k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public int f21854l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public final b2 f21855m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public ss.p0 f21856n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public q1 f21857o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public x0 f21858p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public i0 f21859q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public AudioTrack f21860r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public Object f21861s0;
    public Surface t0;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public SurfaceHolder f21862u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final q1 f21863v;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public st.h f21864v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final bj.d f21865w;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public boolean f21866w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Context f21867x;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public TextureView f21868x0;
    public final b3.l y;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public int f21869y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public qt.r f21870z0;

    static {
        g0.a("goog.exo.exoplayer");
    }

    public z(k kVar, c2 c2Var) {
        boolean zEquals;
        super(4);
        this.f21865w = new bj.d(0);
        try {
            qt.a.y("ExoPlayerImpl", "Init " + Integer.toHexString(System.identityHashCode(this)) + " [ExoPlayerLib/2.19.1] [" + qt.x.f27322e + "]");
            this.f21867x = kVar.f21616a.getApplicationContext();
            this.T = new nr.g(kVar.f21617b);
            this.B0 = kVar.f21624i;
            this.f21869y0 = kVar.f21625j;
            this.D0 = false;
            this.f21847f0 = kVar.f21630q;
            w wVar = new w(this);
            this.Z = wVar;
            this.f21842a0 = new x();
            Handler handler = new Handler(kVar.f21623h);
            c[] cVarArrC = ((an.c) kVar.f21618c.f11240e).c(handler, wVar, wVar, wVar, wVar);
            this.J = cVarArrC;
            qt.a.k(cVarArrC.length > 0);
            this.K = (mt.t) kVar.f21620e.get();
            kVar.f21619d.get();
            this.V = (ot.f) kVar.f21622g.get();
            this.S = kVar.k;
            this.f21855m0 = kVar.l;
            this.W = kVar.f21626m;
            this.X = kVar.f21627n;
            Looper looper = kVar.f21623h;
            this.U = looper;
            qt.s sVar = kVar.f21617b;
            this.Y = sVar;
            this.y = c2Var;
            this.O = new n3.q(looper, sVar, new mp.a(this));
            this.P = new CopyOnWriteArraySet();
            this.R = new ArrayList();
            this.f21856n0 = new ss.p0();
            this.f21850i = new mt.x(new a2[cVarArrC.length], new mt.q[cVarArrC.length], l2.f21651e, null);
            this.Q = new h2();
            SparseBooleanArray sparseBooleanArray = new SparseBooleanArray();
            int[] iArr = {1, 2, 3, 13, 14, 15, 16, 17, 18, 19, 31, 20, 30, 21, 22, 24, 27, 28, 32};
            for (int i11 = 0; i11 < 19; i11++) {
                int i12 = iArr[i11];
                qt.a.k(!false);
                sparseBooleanArray.append(i12, true);
            }
            this.K.getClass();
            qt.a.k(!false);
            sparseBooleanArray.append(29, true);
            qt.a.k(!false);
            qt.e eVar = new qt.e(sparseBooleanArray);
            this.f21863v = new q1(eVar);
            SparseBooleanArray sparseBooleanArray2 = new SparseBooleanArray();
            for (int i13 = 0; i13 < eVar.f27261a.size(); i13++) {
                int iA = eVar.a(i13);
                qt.a.k(!false);
                sparseBooleanArray2.append(iA, true);
            }
            qt.a.k(!false);
            sparseBooleanArray2.append(4, true);
            qt.a.k(!false);
            sparseBooleanArray2.append(10, true);
            qt.a.k(!false);
            this.f21857o0 = new q1(new qt.e(sparseBooleanArray2));
            this.L = this.Y.a(this.U, null);
            o oVar = new o(this);
            this.M = oVar;
            this.J0 = n1.i(this.f21850i);
            this.T.S(this.y, this.U);
            int i14 = qt.x.f27318a;
            this.N = new f0(this.J, this.K, this.f21850i, (h) kVar.f21621f.get(), this.V, this.f21848g0, this.f21849h0, this.T, this.f21855m0, kVar.f21628o, kVar.f21629p, this.U, this.Y, oVar, i14 < 31 ? new nr.p() : t.a(this.f21867x, this, kVar.f21631r));
            this.C0 = 1.0f;
            this.f21848g0 = 0;
            x0 x0Var = x0.f21790k0;
            this.f21858p0 = x0Var;
            this.I0 = x0Var;
            int iGenerateAudioSessionId = -1;
            this.K0 = -1;
            if (i14 < 21) {
                AudioTrack audioTrack = this.f21860r0;
                if (audioTrack != null && audioTrack.getAudioSessionId() != 0) {
                    this.f21860r0.release();
                    this.f21860r0 = null;
                }
                if (this.f21860r0 == null) {
                    this.f21860r0 = new AudioTrack(3, 4000, 4, 2, 2, 0, 0);
                }
                this.A0 = this.f21860r0.getAudioSessionId();
            } else {
                AudioManager audioManager = (AudioManager) this.f21867x.getSystemService(MediaStreamTrack.AUDIO_TRACK_KIND);
                if (audioManager != null) {
                    iGenerateAudioSessionId = audioManager.generateAudioSessionId();
                }
                this.A0 = iGenerateAudioSessionId;
            }
            this.E0 = bt.c.f4144e;
            this.F0 = true;
            f0(this.T);
            ot.f fVar = this.V;
            Handler handler2 = new Handler(this.U);
            nr.g gVar = this.T;
            ot.s sVar2 = (ot.s) fVar;
            sVar2.getClass();
            gVar.getClass();
            k0 k0Var = sVar2.f25117b;
            k0Var.getClass();
            CopyOnWriteArrayList<ot.d> copyOnWriteArrayList = (CopyOnWriteArrayList) k0Var.f21633d;
            for (ot.d dVar : copyOnWriteArrayList) {
                if (dVar.f25050b == gVar) {
                    dVar.f25051c = true;
                    copyOnWriteArrayList.remove(dVar);
                }
            }
            copyOnWriteArrayList.add(new ot.d(handler2, gVar));
            this.P.add(this.Z);
            an.c cVar = new an.c(kVar.f21616a, handler, this.Z);
            this.f21843b0 = cVar;
            cVar.g();
            this.f21844c0 = new b(kVar.f21616a, handler, this.Z);
            int i15 = qt.x.f27318a;
            Context context = kVar.f21616a;
            al.d dVar2 = new al.d(15);
            this.f21845d0 = dVar2;
            Context context2 = kVar.f21616a;
            ay.f fVar2 = new ay.f(15);
            this.f21846e0 = fVar2;
            a50.i iVar = new a50.i(0);
            iVar.f401b = 0;
            iVar.f402c = 0;
            iVar.a();
            this.H0 = rt.s.f28503w;
            this.f21870z0 = qt.r.f27307c;
            mt.t tVar = this.K;
            or.d dVar3 = this.B0;
            mt.o oVar2 = (mt.o) tVar;
            synchronized (oVar2.f21955d) {
                zEquals = oVar2.f21961j.equals(dVar3);
                oVar2.f21961j = dVar3;
            }
            if (!zEquals) {
                oVar2.e();
            }
            T2(1, 10, Integer.valueOf(this.A0));
            T2(2, 10, Integer.valueOf(this.A0));
            T2(1, 3, this.B0);
            T2(2, 4, Integer.valueOf(this.f21869y0));
            T2(2, 5, 0);
            T2(1, 9, Boolean.valueOf(this.D0));
            T2(2, 7, this.f21842a0);
            T2(6, 8, this.f21842a0);
            this.f21865w.o();
        } catch (Throwable th2) {
            this.f21865w.o();
            throw th2;
        }
    }

    public static long N2(n1 n1Var) {
        i2 i2Var = new i2();
        h2 h2Var = new h2();
        n1Var.f21671a.g(n1Var.f21672b.f29324a, h2Var);
        long j6 = n1Var.f21673c;
        return j6 == -9223372036854775807L ? n1Var.f21671a.m(h2Var.f21537i, i2Var, 0L).O : h2Var.f21539w + j6;
    }

    @Override // mr.u1
    public final j C1() {
        c3();
        return this.J0.f21676f;
    }

    @Override // b3.l
    public final void C2(long j6, int i11, int i12, boolean z11) {
        c3();
        qt.a.g(i11 >= 0);
        nr.g gVar = this.T;
        if (!gVar.K) {
            nr.a aVarM = gVar.M();
            gVar.K = true;
            gVar.R(aVarM, -1, new d2(17));
        }
        j2 j2Var = this.J0.f21671a;
        if (j2Var.p() || i11 < j2Var.o()) {
            this.f21851i0++;
            if (l()) {
                qt.a.N("ExoPlayerImpl", "seekTo ignored because an ad is playing");
                c0 c0Var = new c0(this.J0);
                c0Var.a(1);
                z zVar = this.M.f21688d;
                zVar.L.c(new io.sentry.react.c(14, zVar, c0Var));
                return;
            }
            n1 n1VarG = this.J0;
            int i13 = n1VarG.f21675e;
            if (i13 == 3 || (i13 == 4 && !j2Var.p())) {
                n1VarG = this.J0.g(2);
            }
            int iP = P();
            n1 n1VarO2 = O2(n1VarG, j2Var, P2(j2Var, i11, j6));
            this.N.J.a(3, new e0(j2Var, i11, qt.x.I(j6))).b();
            a3(n1VarO2, 0, 1, true, 1, L2(n1VarO2), iP, z11);
        }
    }

    @Override // k3.e1, mr.u1
    public final void F(boolean z11) {
        c3();
        int iC = this.f21844c0.c(I(), z11);
        int i11 = 1;
        if (z11 && iC != 1) {
            i11 = 2;
        }
        Z2(iC, i11, z11);
    }

    @Override // k3.e1, mr.u1
    public final long G() {
        c3();
        return this.X;
    }

    @Override // k3.e1, mr.u1
    public final long H() {
        c3();
        return K2(this.J0);
    }

    public final x0 H2() {
        j2 j2VarU = U();
        if (j2VarU.p()) {
            return this.I0;
        }
        v0 v0Var = j2VarU.m(P(), (i2) this.f2686e, 0L).f21592i;
        w0 w0VarA = this.I0.a();
        x0 x0Var = v0Var.f21751w;
        if (x0Var != null) {
            CharSequence charSequence = x0Var.f21808d;
            if (charSequence != null) {
                w0VarA.f21754a = charSequence;
            }
            CharSequence charSequence2 = x0Var.f21810e;
            if (charSequence2 != null) {
                w0VarA.f21755b = charSequence2;
            }
            CharSequence charSequence3 = x0Var.f21815i;
            if (charSequence3 != null) {
                w0VarA.f21756c = charSequence3;
            }
            CharSequence charSequence4 = x0Var.f21818v;
            if (charSequence4 != null) {
                w0VarA.f21757d = charSequence4;
            }
            CharSequence charSequence5 = x0Var.f21819w;
            if (charSequence5 != null) {
                w0VarA.f21758e = charSequence5;
            }
            CharSequence charSequence6 = x0Var.f21820x;
            if (charSequence6 != null) {
                w0VarA.f21759f = charSequence6;
            }
            CharSequence charSequence7 = x0Var.y;
            if (charSequence7 != null) {
                w0VarA.f21760g = charSequence7;
            }
            z1 z1Var = x0Var.J;
            if (z1Var != null) {
                w0VarA.f21761h = z1Var;
            }
            z1 z1Var2 = x0Var.K;
            if (z1Var2 != null) {
                w0VarA.f21762i = z1Var2;
            }
            byte[] bArr = x0Var.L;
            if (bArr != null) {
                Integer num = x0Var.M;
                w0VarA.f21763j = (byte[]) bArr.clone();
                w0VarA.k = num;
            }
            Uri uri = x0Var.N;
            if (uri != null) {
                w0VarA.l = uri;
            }
            Integer num2 = x0Var.O;
            if (num2 != null) {
                w0VarA.f21764m = num2;
            }
            Integer num3 = x0Var.P;
            if (num3 != null) {
                w0VarA.f21765n = num3;
            }
            Integer num4 = x0Var.Q;
            if (num4 != null) {
                w0VarA.f21766o = num4;
            }
            Boolean bool = x0Var.R;
            if (bool != null) {
                w0VarA.f21767p = bool;
            }
            Boolean bool2 = x0Var.S;
            if (bool2 != null) {
                w0VarA.f21768q = bool2;
            }
            Integer num5 = x0Var.T;
            if (num5 != null) {
                w0VarA.f21769r = num5;
            }
            Integer num6 = x0Var.U;
            if (num6 != null) {
                w0VarA.f21769r = num6;
            }
            Integer num7 = x0Var.V;
            if (num7 != null) {
                w0VarA.f21770s = num7;
            }
            Integer num8 = x0Var.W;
            if (num8 != null) {
                w0VarA.f21771t = num8;
            }
            Integer num9 = x0Var.X;
            if (num9 != null) {
                w0VarA.f21772u = num9;
            }
            Integer num10 = x0Var.Y;
            if (num10 != null) {
                w0VarA.f21773v = num10;
            }
            Integer num11 = x0Var.Z;
            if (num11 != null) {
                w0VarA.f21774w = num11;
            }
            CharSequence charSequence8 = x0Var.f21805a0;
            if (charSequence8 != null) {
                w0VarA.f21775x = charSequence8;
            }
            CharSequence charSequence9 = x0Var.f21806b0;
            if (charSequence9 != null) {
                w0VarA.y = charSequence9;
            }
            CharSequence charSequence10 = x0Var.f21807c0;
            if (charSequence10 != null) {
                w0VarA.f21776z = charSequence10;
            }
            Integer num12 = x0Var.f21809d0;
            if (num12 != null) {
                w0VarA.A = num12;
            }
            Integer num13 = x0Var.f21811e0;
            if (num13 != null) {
                w0VarA.B = num13;
            }
            CharSequence charSequence11 = x0Var.f21812f0;
            if (charSequence11 != null) {
                w0VarA.C = charSequence11;
            }
            CharSequence charSequence12 = x0Var.f21813g0;
            if (charSequence12 != null) {
                w0VarA.D = charSequence12;
            }
            CharSequence charSequence13 = x0Var.f21814h0;
            if (charSequence13 != null) {
                w0VarA.E = charSequence13;
            }
            Integer num14 = x0Var.f21816i0;
            if (num14 != null) {
                w0VarA.F = num14;
            }
            Bundle bundle = x0Var.f21817j0;
            if (bundle != null) {
                w0VarA.G = bundle;
            }
        }
        return new x0(w0VarA);
    }

    @Override // k3.e1, mr.u1
    public final int I() {
        c3();
        return this.J0.f21675e;
    }

    public final void I2() {
        c3();
        S2();
        W2(null);
        Q2(0, 0);
    }

    @Override // mr.u1
    public final l2 J() {
        c3();
        return this.J0.f21679i.f22007d;
    }

    public final w1 J2(v1 v1Var) {
        int iM2 = M2(this.J0);
        j2 j2Var = this.J0.f21671a;
        if (iM2 == -1) {
            iM2 = 0;
        }
        qt.s sVar = this.Y;
        f0 f0Var = this.N;
        return new w1(f0Var, v1Var, j2Var, iM2, sVar, f0Var.L);
    }

    public final long K2(n1 n1Var) {
        ss.s sVar = n1Var.f21672b;
        long j6 = n1Var.f21673c;
        j2 j2Var = n1Var.f21671a;
        if (!sVar.a()) {
            return qt.x.U(L2(n1Var));
        }
        Object obj = n1Var.f21672b.f29324a;
        h2 h2Var = this.Q;
        j2Var.g(obj, h2Var);
        if (j6 == -9223372036854775807L) {
            return qt.x.U(j2Var.m(M2(n1Var), (i2) this.f2686e, 0L).O);
        }
        return qt.x.U(j6) + qt.x.U(h2Var.f21539w);
    }

    @Override // mr.u1
    public final bt.c L() {
        c3();
        return this.E0;
    }

    public final long L2(n1 n1Var) {
        if (n1Var.f21671a.p()) {
            return qt.x.I(this.L0);
        }
        long j6 = n1Var.f21683o ? n1Var.j() : n1Var.f21686r;
        if (n1Var.f21672b.a()) {
            return j6;
        }
        j2 j2Var = n1Var.f21671a;
        Object obj = n1Var.f21672b.f29324a;
        h2 h2Var = this.Q;
        j2Var.g(obj, h2Var);
        return j6 + h2Var.f21539w;
    }

    public final int M2(n1 n1Var) {
        return n1Var.f21671a.p() ? this.K0 : n1Var.f21671a.g(n1Var.f21672b.f29324a, this.Q).f21537i;
    }

    @Override // k3.e1, mr.u1
    public final int O() {
        c3();
        if (l()) {
            return this.J0.f21672b.f29325b;
        }
        return -1;
    }

    public final n1 O2(n1 n1Var, j2 j2Var, Pair pair) {
        List list;
        qt.a.g(j2Var.p() || pair != null);
        j2 j2Var2 = n1Var.f21671a;
        long jK2 = K2(n1Var);
        n1 n1VarH = n1Var.h(j2Var);
        if (j2Var.p()) {
            ss.s sVar = n1.f21670t;
            long jI = qt.x.I(this.L0);
            n1 n1VarB = n1VarH.c(sVar, jI, jI, jI, 0L, ss.w0.f29354v, this.f21850i, hx.w1.f14911w).b(sVar);
            n1VarB.f21684p = n1VarB.f21686r;
            return n1VarB;
        }
        Object obj = n1VarH.f21672b.f29324a;
        int i11 = qt.x.f27318a;
        boolean zEquals = obj.equals(pair.first);
        ss.s sVar2 = !zEquals ? new ss.s(pair.first) : n1VarH.f21672b;
        long jLongValue = ((Long) pair.second).longValue();
        long jI2 = qt.x.I(jK2);
        if (!j2Var2.p()) {
            jI2 -= j2Var2.g(obj, this.Q).f21539w;
        }
        if (!zEquals || jLongValue < jI2) {
            ss.s sVar3 = sVar2;
            qt.a.k(!sVar3.a());
            ss.w0 w0Var = !zEquals ? ss.w0.f29354v : n1VarH.f21678h;
            mt.x xVar = !zEquals ? this.f21850i : n1VarH.f21679i;
            if (zEquals) {
                list = n1VarH.f21680j;
            } else {
                hx.k0 k0Var = hx.m0.f14841e;
                list = hx.w1.f14911w;
            }
            n1 n1VarB2 = n1VarH.c(sVar3, jLongValue, jLongValue, jLongValue, 0L, w0Var, xVar, list).b(sVar3);
            n1VarB2.f21684p = jLongValue;
            return n1VarB2;
        }
        if (jLongValue != jI2) {
            ss.s sVar4 = sVar2;
            qt.a.k(!sVar4.a());
            long jMax = Math.max(0L, n1VarH.f21685q - (jLongValue - jI2));
            long j6 = n1VarH.f21684p;
            if (n1VarH.k.equals(n1VarH.f21672b)) {
                j6 = jLongValue + jMax;
            }
            n1 n1VarC = n1VarH.c(sVar4, jLongValue, jLongValue, jLongValue, jMax, n1VarH.f21678h, n1VarH.f21679i, n1VarH.f21680j);
            n1VarC.f21684p = j6;
            return n1VarC;
        }
        int iB = j2Var.b(n1VarH.k.f29324a);
        if (iB != -1 && j2Var.f(iB, this.Q, false).f21537i == j2Var.g(sVar2.f29324a, this.Q).f21537i) {
            return n1VarH;
        }
        j2Var.g(sVar2.f29324a, this.Q);
        long jA = sVar2.a() ? this.Q.a(sVar2.f29325b, sVar2.f29326c) : this.Q.f21538v;
        ss.s sVar5 = sVar2;
        n1 n1VarB3 = n1VarH.c(sVar5, n1VarH.f21686r, n1VarH.f21686r, n1VarH.f21674d, jA - n1VarH.f21686r, n1VarH.f21678h, n1VarH.f21679i, n1VarH.f21680j).b(sVar5);
        n1VarB3.f21684p = jA;
        return n1VarB3;
    }

    @Override // k3.e1, mr.u1
    public final int P() {
        c3();
        int iM2 = M2(this.J0);
        if (iM2 == -1) {
            return 0;
        }
        return iM2;
    }

    public final Pair P2(j2 j2Var, int i11, long j6) {
        if (j2Var.p()) {
            this.K0 = i11;
            if (j6 == -9223372036854775807L) {
                j6 = 0;
            }
            this.L0 = j6;
            return null;
        }
        if (i11 == -1 || i11 >= j2Var.o()) {
            i11 = j2Var.a(this.f21849h0);
            j6 = qt.x.U(j2Var.m(i11, (i2) this.f2686e, 0L).O);
        }
        return j2Var.i((i2) this.f2686e, this.Q, i11, qt.x.I(j6));
    }

    @Override // k3.e1, mr.u1
    public final void Q(int i11) {
        c3();
        if (this.f21848g0 != i11) {
            this.f21848g0 = i11;
            qt.u uVar = this.N.J;
            uVar.getClass();
            qt.t tVarB = qt.u.b();
            tVarB.f27311a = uVar.f27313a.obtainMessage(11, i11, 0);
            tVarB.b();
            p pVar = new p(i11, 0);
            n3.q qVar = this.O;
            qVar.d(8, pVar);
            Y2();
            qVar.b();
        }
    }

    public final void Q2(int i11, int i12) {
        qt.r rVar = this.f21870z0;
        if (i11 == rVar.f27308a && i12 == rVar.f27309b) {
            return;
        }
        this.f21870z0 = new qt.r(i11, i12);
        this.O.g(24, new q(i11, i12, 0));
        T2(2, 14, new qt.r(i11, i12));
    }

    @Override // k3.e1, mr.u1
    public final void R(SurfaceView surfaceView) {
        c3();
        SurfaceHolder holder = surfaceView == null ? null : surfaceView.getHolder();
        c3();
        if (holder == null || holder != this.f21862u0) {
            return;
        }
        I2();
    }

    @Override // mr.u1
    public final void R0(s1 s1Var) {
        c3();
        s1Var.getClass();
        n3.q qVar = this.O;
        qVar.h();
        CopyOnWriteArraySet<qt.i> copyOnWriteArraySet = qVar.f22382b;
        for (qt.i iVar : copyOnWriteArraySet) {
            if (iVar.f27262a.equals(s1Var)) {
                qt.h hVar = (qt.h) qVar.f22390j;
                iVar.f27265d = true;
                if (iVar.f27264c) {
                    iVar.f27264c = false;
                    hVar.a(iVar.f27262a, iVar.f27263b.e());
                }
                copyOnWriteArraySet.remove(iVar);
            }
        }
    }

    public final void R2(int i11) {
        for (int i12 = i11 - 1; i12 >= 0; i12--) {
            this.R.remove(i12);
        }
        ss.p0 p0Var = this.f21856n0;
        int[] iArr = p0Var.f29317b;
        int[] iArr2 = new int[iArr.length - i11];
        int i13 = 0;
        for (int i14 = 0; i14 < iArr.length; i14++) {
            int i15 = iArr[i14];
            if (i15 < 0 || i15 >= i11) {
                int i16 = i14 - i13;
                if (i15 >= 0) {
                    i15 -= i11;
                }
                iArr2[i16] = i15;
            } else {
                i13++;
            }
        }
        this.f21856n0 = new ss.p0(iArr2, new Random(p0Var.f29316a.nextLong()));
    }

    @Override // k3.e1, mr.u1
    public final int S() {
        c3();
        return this.J0.f21681m;
    }

    public final void S2() {
        st.h hVar = this.f21864v0;
        w wVar = this.Z;
        if (hVar != null) {
            w1 w1VarJ2 = J2(this.f21842a0);
            qt.a.k(!w1VarJ2.f21783g);
            w1VarJ2.f21780d = 10000;
            qt.a.k(!w1VarJ2.f21783g);
            w1VarJ2.f21781e = null;
            w1VarJ2.c();
            this.f21864v0.f29387d.remove(wVar);
            this.f21864v0 = null;
        }
        TextureView textureView = this.f21868x0;
        if (textureView != null) {
            if (textureView.getSurfaceTextureListener() != wVar) {
                qt.a.N("ExoPlayerImpl", "SurfaceTextureListener already unset or replaced.");
            } else {
                this.f21868x0.setSurfaceTextureListener(null);
            }
            this.f21868x0 = null;
        }
        SurfaceHolder surfaceHolder = this.f21862u0;
        if (surfaceHolder != null) {
            surfaceHolder.removeCallback(wVar);
            this.f21862u0 = null;
        }
    }

    @Override // k3.e1, mr.u1
    public final int T() {
        c3();
        return this.f21848g0;
    }

    public final void T2(int i11, int i12, Object obj) {
        for (c cVar : this.J) {
            if (cVar.f21406e == i11) {
                w1 w1VarJ2 = J2(cVar);
                qt.a.k(!w1VarJ2.f21783g);
                w1VarJ2.f21780d = i12;
                qt.a.k(!w1VarJ2.f21783g);
                w1VarJ2.f21781e = obj;
                w1VarJ2.c();
            }
        }
    }

    @Override // mr.u1
    public final j2 U() {
        c3();
        return this.J0.f21671a;
    }

    public final void U2(List list, boolean z11) {
        c3();
        int iM2 = M2(this.J0);
        long jB0 = b0();
        this.f21851i0++;
        ArrayList arrayList = this.R;
        if (!arrayList.isEmpty()) {
            R2(arrayList.size());
        }
        ArrayList arrayList2 = new ArrayList();
        for (int i11 = 0; i11 < list.size(); i11++) {
            i1 i1Var = new i1((ss.a) list.get(i11), this.S);
            arrayList2.add(i1Var);
            arrayList.add(i11, new y(i1Var.f21577b, i1Var.f21576a.Q));
        }
        this.f21856n0 = this.f21856n0.a(arrayList2.size());
        y1 y1Var = new y1(arrayList, this.f21856n0);
        boolean zP = y1Var.p();
        int i12 = y1Var.f21839v;
        if (!zP && -1 >= i12) {
            throw new b70.r();
        }
        if (z11) {
            iM2 = y1Var.a(this.f21849h0);
            jB0 = -9223372036854775807L;
        }
        n1 n1VarO2 = O2(this.J0, y1Var, P2(y1Var, iM2, jB0));
        int i13 = n1VarO2.f21675e;
        if (iM2 != -1 && i13 != 1) {
            i13 = (y1Var.p() || iM2 >= i12) ? 4 : 2;
        }
        n1 n1VarG = n1VarO2.g(i13);
        this.N.J.a(17, new b0(arrayList2, this.f21856n0, iM2, qt.x.I(jB0))).b();
        a3(n1VarG, 0, 1, (this.J0.f21672b.f29324a.equals(n1VarG.f21672b.f29324a) || this.J0.f21671a.p()) ? false : true, 4, L2(n1VarG), -1, false);
    }

    @Override // k3.e1, mr.u1
    public final Looper V() {
        return this.U;
    }

    public final void V2(SurfaceHolder surfaceHolder) {
        this.f21866w0 = false;
        this.f21862u0 = surfaceHolder;
        surfaceHolder.addCallback(this.Z);
        Surface surface = this.f21862u0.getSurface();
        if (surface == null || !surface.isValid()) {
            Q2(0, 0);
        } else {
            Rect surfaceFrame = this.f21862u0.getSurfaceFrame();
            Q2(surfaceFrame.width(), surfaceFrame.height());
        }
    }

    @Override // k3.e1, mr.u1
    public final boolean W() {
        c3();
        return this.f21849h0;
    }

    public final void W2(Object obj) {
        ArrayList arrayList = new ArrayList();
        boolean z11 = false;
        for (c cVar : this.J) {
            if (cVar.f21406e == 2) {
                w1 w1VarJ2 = J2(cVar);
                qt.a.k(!w1VarJ2.f21783g);
                w1VarJ2.f21780d = 1;
                qt.a.k(true ^ w1VarJ2.f21783g);
                w1VarJ2.f21781e = obj;
                w1VarJ2.c();
                arrayList.add(w1VarJ2);
            }
        }
        Object obj2 = this.f21861s0;
        if (obj2 != null && obj2 != obj) {
            try {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((w1) it.next()).a(this.f21847f0);
                }
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
            } catch (TimeoutException unused2) {
                z11 = true;
            }
            Object obj3 = this.f21861s0;
            Surface surface = this.t0;
            if (obj3 == surface) {
                surface.release();
                this.t0 = null;
            }
        }
        this.f21861s0 = obj;
        if (z11) {
            X2(new j(2, new an.g("Detaching surface timed out.", 19), 1003));
        }
    }

    @Override // k3.e1, mr.u1
    public final long X() {
        c3();
        if (this.J0.f21671a.p()) {
            return this.L0;
        }
        n1 n1Var = this.J0;
        if (n1Var.k.f29327d != n1Var.f21672b.f29327d) {
            return qt.x.U(n1Var.f21671a.m(P(), (i2) this.f2686e, 0L).P);
        }
        long j6 = n1Var.f21684p;
        if (this.J0.k.a()) {
            n1 n1Var2 = this.J0;
            h2 h2VarG = n1Var2.f21671a.g(n1Var2.k.f29324a, this.Q);
            long jD = h2VarG.d(this.J0.k.f29325b);
            j6 = jD == Long.MIN_VALUE ? h2VarG.f21538v : jD;
        }
        n1 n1Var3 = this.J0;
        j2 j2Var = n1Var3.f21671a;
        Object obj = n1Var3.k.f29324a;
        h2 h2Var = this.Q;
        j2Var.g(obj, h2Var);
        return qt.x.U(j6 + h2Var.f21539w);
    }

    public final void X2(j jVar) {
        n1 n1Var = this.J0;
        n1 n1VarB = n1Var.b(n1Var.f21672b);
        n1VarB.f21684p = n1VarB.f21686r;
        n1VarB.f21685q = 0L;
        n1 n1VarG = n1VarB.g(1);
        if (jVar != null) {
            n1VarG = n1VarG.e(jVar);
        }
        n1 n1Var2 = n1VarG;
        this.f21851i0++;
        qt.u uVar = this.N.J;
        uVar.getClass();
        qt.t tVarB = qt.u.b();
        tVarB.f27311a = uVar.f27313a.obtainMessage(6);
        tVarB.b();
        a3(n1Var2, 0, 1, false, 5, -9223372036854775807L, -1, false);
    }

    @Override // k3.e1, mr.u1
    public final void Y(TextureView textureView) {
        c3();
        if (textureView == null) {
            I2();
            return;
        }
        S2();
        this.f21868x0 = textureView;
        if (textureView.getSurfaceTextureListener() != null) {
            qt.a.N("ExoPlayerImpl", "Replacing existing SurfaceTextureListener.");
        }
        textureView.setSurfaceTextureListener(this.Z);
        SurfaceTexture surfaceTexture = textureView.isAvailable() ? textureView.getSurfaceTexture() : null;
        if (surfaceTexture == null) {
            W2(null);
            Q2(0, 0);
        } else {
            Surface surface = new Surface(surfaceTexture);
            W2(surface);
            this.t0 = surface;
            Q2(textureView.getWidth(), textureView.getHeight());
        }
    }

    public final void Y2() {
        int iK;
        int iE;
        q1 q1Var = this.f21857o0;
        int i11 = qt.x.f27318a;
        b3.l lVar = this.y;
        boolean zL = lVar.l();
        boolean zN1 = lVar.n1();
        j2 j2VarU = lVar.U();
        boolean z11 = false;
        if (j2VarU.p()) {
            iK = -1;
        } else {
            int iP = lVar.P();
            int iT = lVar.T();
            if (iT == 1) {
                iT = 0;
            }
            iK = j2VarU.k(iP, iT, lVar.W());
        }
        boolean z12 = iK != -1;
        j2 j2VarU2 = lVar.U();
        if (j2VarU2.p()) {
            iE = -1;
        } else {
            int iP2 = lVar.P();
            int iT2 = lVar.T();
            if (iT2 == 1) {
                iT2 = 0;
            }
            iE = j2VarU2.e(iP2, iT2, lVar.W());
        }
        boolean z13 = iE != -1;
        boolean zP2 = lVar.p2();
        j2 j2VarU3 = lVar.U();
        boolean z14 = !j2VarU3.p() && j2VarU3.m(lVar.P(), (i2) lVar.f2686e, 0L).K;
        boolean zP = lVar.U().p();
        p1 p1Var = new p1(0);
        k3.t tVar = (k3.t) p1Var.f21702e;
        qt.e eVar = this.f21863v.f21712d;
        tVar.getClass();
        for (int i12 = 0; i12 < eVar.f27261a.size(); i12++) {
            tVar.a(eVar.a(i12));
        }
        boolean z15 = !zL;
        p1Var.n(4, z15);
        p1Var.n(5, zN1 && !zL);
        p1Var.n(6, z12 && !zL);
        p1Var.n(7, !zP && (z12 || !zP2 || zN1) && !zL);
        p1Var.n(8, z13 && !zL);
        p1Var.n(9, !zP && (z13 || (zP2 && z14)) && !zL);
        p1Var.n(10, z15);
        p1Var.n(11, zN1 && !zL);
        if (zN1 && !zL) {
            z11 = true;
        }
        p1Var.n(12, z11);
        q1 q1Var2 = new q1(tVar.e());
        this.f21857o0 = q1Var2;
        if (q1Var2.equals(q1Var)) {
            return;
        }
        this.O.d(13, new o(this));
    }

    @Override // mr.u1
    public final x0 Z() {
        c3();
        return this.f21858p0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v2, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r15v4 */
    public final void Z2(int i11, int i12, boolean z11) {
        int i13 = 0;
        ?? r15 = (!z11 || i11 == -1) ? 0 : 1;
        if (r15 != 0 && i11 != 1) {
            i13 = 1;
        }
        n1 n1Var = this.J0;
        if (n1Var.l == r15 && n1Var.f21681m == i13) {
            return;
        }
        this.f21851i0++;
        boolean z12 = n1Var.f21683o;
        n1 n1VarA = n1Var;
        if (z12) {
            n1VarA = n1Var.a();
        }
        n1 n1VarD = n1VarA.d(i13, r15);
        qt.u uVar = this.N.J;
        uVar.getClass();
        qt.t tVarB = qt.u.b();
        tVarB.f27311a = uVar.f27313a.obtainMessage(1, r15, i13);
        tVarB.b();
        a3(n1VarD, 0, i12, false, 5, -9223372036854775807L, -1, false);
    }

    public final void a3(final n1 n1Var, final int i11, final int i12, boolean z11, int i13, long j6, int i14, boolean z12) {
        Pair pair;
        int i15;
        v0 v0Var;
        int i16;
        Object obj;
        v0 v0Var2;
        Object obj2;
        int i17;
        long j11;
        long j12;
        long jN2;
        long jN3;
        Object obj3;
        v0 v0Var3;
        Object obj4;
        int i18;
        n1 n1Var2 = this.J0;
        this.J0 = n1Var;
        boolean zEquals = n1Var2.f21671a.equals(n1Var.f21671a);
        i2 i2Var = (i2) this.f2686e;
        h2 h2Var = this.Q;
        j2 j2Var = n1Var2.f21671a;
        ss.s sVar = n1Var2.f21672b;
        j2 j2Var2 = n1Var.f21671a;
        ss.s sVar2 = n1Var.f21672b;
        if (j2Var2.p() && j2Var.p()) {
            pair = new Pair(Boolean.FALSE, -1);
        } else if (j2Var2.p() != j2Var.p()) {
            pair = new Pair(Boolean.TRUE, 3);
        } else if (!j2Var.m(j2Var.g(sVar.f29324a, h2Var).f21537i, i2Var, 0L).f21590d.equals(j2Var2.m(j2Var2.g(sVar2.f29324a, h2Var).f21537i, i2Var, 0L).f21590d)) {
            if (z11 && i13 == 0) {
                i15 = 1;
            } else if (z11 && i13 == 1) {
                i15 = 2;
            } else {
                if (zEquals) {
                    throw new IllegalStateException();
                }
                i15 = 3;
            }
            pair = new Pair(Boolean.TRUE, Integer.valueOf(i15));
        } else if (z11 && i13 == 0 && sVar.f29327d < sVar2.f29327d) {
            pair = new Pair(Boolean.TRUE, 0);
        } else {
            pair = (z11 && i13 == 1 && z12) ? new Pair(Boolean.TRUE, 2) : new Pair(Boolean.FALSE, -1);
        }
        boolean zBooleanValue = ((Boolean) pair.first).booleanValue();
        int iIntValue = ((Integer) pair.second).intValue();
        x0 x0VarH2 = this.f21858p0;
        if (zBooleanValue) {
            v0Var = n1Var.f21671a.p() ? null : n1Var.f21671a.m(n1Var.f21671a.g(n1Var.f21672b.f29324a, this.Q).f21537i, (i2) this.f2686e, 0L).f21592i;
            this.I0 = x0.f21790k0;
        } else {
            v0Var = null;
        }
        if (zBooleanValue || !n1Var2.f21680j.equals(n1Var.f21680j)) {
            w0 w0VarA = this.I0.a();
            List list = n1Var.f21680j;
            for (int i19 = 0; i19 < list.size(); i19++) {
                is.c cVar = (is.c) list.get(i19);
                int i21 = 0;
                while (true) {
                    is.b[] bVarArr = cVar.f17374d;
                    if (i21 < bVarArr.length) {
                        bVarArr[i21].w(w0VarA);
                        i21++;
                    }
                }
            }
            this.I0 = new x0(w0VarA);
            x0VarH2 = H2();
        }
        boolean zEquals2 = x0VarH2.equals(this.f21858p0);
        this.f21858p0 = x0VarH2;
        boolean z13 = n1Var2.l != n1Var.l;
        boolean z14 = n1Var2.f21675e != n1Var.f21675e;
        if (z14 || z13) {
            b3();
        }
        boolean z15 = n1Var2.f21677g != n1Var.f21677g;
        if (!zEquals) {
            final int i22 = 0;
            this.O.d(0, new qt.g() { // from class: mr.l
                @Override // qt.g, n3.n
                public final void invoke(Object obj5) {
                    s1 s1Var = (s1) obj5;
                    switch (i22) {
                        case 0:
                            j2 j2Var3 = n1Var.f21671a;
                            s1Var.C(i11);
                            break;
                        default:
                            s1Var.e(i11, n1Var.l);
                            break;
                    }
                }
            });
        }
        if (z11) {
            h2 h2Var2 = new h2();
            if (n1Var2.f21671a.p()) {
                i16 = i14;
                obj = null;
                v0Var2 = null;
                obj2 = null;
                i17 = -1;
            } else {
                Object obj5 = n1Var2.f21672b.f29324a;
                n1Var2.f21671a.g(obj5, h2Var2);
                int i23 = h2Var2.f21537i;
                int iB = n1Var2.f21671a.b(obj5);
                obj = n1Var2.f21671a.m(i23, (i2) this.f2686e, 0L).f21590d;
                v0Var2 = ((i2) this.f2686e).f21592i;
                obj2 = obj5;
                i16 = i23;
                i17 = iB;
            }
            if (i13 == 0) {
                if (n1Var2.f21672b.a()) {
                    ss.s sVar3 = n1Var2.f21672b;
                    jN2 = h2Var2.a(sVar3.f29325b, sVar3.f29326c);
                    jN3 = N2(n1Var2);
                } else {
                    if (n1Var2.f21672b.f29328e != -1) {
                        jN2 = N2(this.J0);
                    } else {
                        j11 = h2Var2.f21539w;
                        j12 = h2Var2.f21538v;
                        jN2 = j11 + j12;
                    }
                    jN3 = jN2;
                }
            } else if (n1Var2.f21672b.a()) {
                jN2 = n1Var2.f21686r;
                jN3 = N2(n1Var2);
            } else {
                j11 = h2Var2.f21539w;
                j12 = n1Var2.f21686r;
                jN2 = j11 + j12;
                jN3 = jN2;
            }
            long jU = qt.x.U(jN2);
            long jU2 = qt.x.U(jN3);
            ss.s sVar4 = n1Var2.f21672b;
            t1 t1Var = new t1(obj, i16, v0Var2, obj2, i17, jU, jU2, sVar4.f29325b, sVar4.f29326c);
            i2 i2Var2 = (i2) this.f2686e;
            int iP = P();
            if (this.J0.f21671a.p()) {
                obj3 = null;
                v0Var3 = null;
                obj4 = null;
                i18 = -1;
            } else {
                n1 n1Var3 = this.J0;
                Object obj6 = n1Var3.f21672b.f29324a;
                n1Var3.f21671a.g(obj6, this.Q);
                int iB2 = this.J0.f21671a.b(obj6);
                Object obj7 = this.J0.f21671a.m(iP, i2Var2, 0L).f21590d;
                v0Var3 = i2Var2.f21592i;
                i18 = iB2;
                obj4 = obj6;
                obj3 = obj7;
            }
            long jU3 = qt.x.U(j6);
            long jU4 = this.J0.f21672b.a() ? qt.x.U(N2(this.J0)) : jU3;
            ss.s sVar5 = this.J0.f21672b;
            this.O.d(11, new com.facebook.imagepipeline.producers.o(i13, t1Var, new t1(obj3, iP, v0Var3, obj4, i18, jU3, jU4, sVar5.f29325b, sVar5.f29326c), 2));
        } else {
            zBooleanValue = zBooleanValue;
            z13 = z13;
            zEquals2 = zEquals2;
        }
        if (zBooleanValue) {
            this.O.d(1, new s(iIntValue, 0, v0Var));
        }
        if (n1Var2.f21676f != n1Var.f21676f) {
            final int i24 = 6;
            this.O.d(10, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj8) {
                    s1 s1Var = (s1) obj8;
                    switch (i24) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
            if (n1Var.f21676f != null) {
                final int i25 = 7;
                this.O.d(10, new qt.g() { // from class: mr.m
                    @Override // qt.g, n3.n
                    public final void invoke(Object obj8) {
                        s1 s1Var = (s1) obj8;
                        switch (i25) {
                            case 0:
                                n1 n1Var4 = n1Var;
                                boolean z16 = n1Var4.f21677g;
                                s1Var.getClass();
                                s1Var.d(n1Var4.f21677g);
                                break;
                            case 1:
                                n1 n1Var5 = n1Var;
                                s1Var.l(n1Var5.f21675e, n1Var5.l);
                                break;
                            case 2:
                                s1Var.g(n1Var.f21675e);
                                break;
                            case 3:
                                s1Var.c(n1Var.f21681m);
                                break;
                            case 4:
                                s1Var.o(n1Var.k());
                                break;
                            case 5:
                                s1Var.L(n1Var.f21682n);
                                break;
                            case 6:
                                s1Var.B(n1Var.f21676f);
                                break;
                            case 7:
                                s1Var.m(n1Var.f21676f);
                                break;
                            default:
                                s1Var.x(n1Var.f21679i.f22007d);
                                break;
                        }
                    }
                });
            }
        }
        mt.x xVar = n1Var2.f21679i;
        mt.x xVar2 = n1Var.f21679i;
        if (xVar != xVar2) {
            mt.t tVar = this.K;
            Object obj8 = xVar2.f22008e;
            tVar.getClass();
            tVar.f21972c = (mt.s) obj8;
            final int i26 = 8;
            this.O.d(2, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i26) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        if (!zEquals2) {
            this.O.d(14, new io.sentry.android.core.n0(20, this.f21858p0));
        }
        if (z15) {
            final int i27 = 0;
            this.O.d(3, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i27) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        if (z14 || z13) {
            final int i28 = 1;
            this.O.d(-1, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i28) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        if (z14) {
            final int i29 = 2;
            this.O.d(4, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i29) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        if (z13) {
            final int i31 = 1;
            this.O.d(5, new qt.g() { // from class: mr.l
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i31) {
                        case 0:
                            j2 j2Var3 = n1Var.f21671a;
                            s1Var.C(i12);
                            break;
                        default:
                            s1Var.e(i12, n1Var.l);
                            break;
                    }
                }
            });
        }
        if (n1Var2.f21681m != n1Var.f21681m) {
            final int i32 = 3;
            this.O.d(6, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i32) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        if (n1Var2.k() != n1Var.k()) {
            final int i33 = 4;
            this.O.d(7, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i33) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        if (!n1Var2.f21682n.equals(n1Var.f21682n)) {
            final int i34 = 5;
            this.O.d(12, new qt.g() { // from class: mr.m
                @Override // qt.g, n3.n
                public final void invoke(Object obj9) {
                    s1 s1Var = (s1) obj9;
                    switch (i34) {
                        case 0:
                            n1 n1Var4 = n1Var;
                            boolean z16 = n1Var4.f21677g;
                            s1Var.getClass();
                            s1Var.d(n1Var4.f21677g);
                            break;
                        case 1:
                            n1 n1Var5 = n1Var;
                            s1Var.l(n1Var5.f21675e, n1Var5.l);
                            break;
                        case 2:
                            s1Var.g(n1Var.f21675e);
                            break;
                        case 3:
                            s1Var.c(n1Var.f21681m);
                            break;
                        case 4:
                            s1Var.o(n1Var.k());
                            break;
                        case 5:
                            s1Var.L(n1Var.f21682n);
                            break;
                        case 6:
                            s1Var.B(n1Var.f21676f);
                            break;
                        case 7:
                            s1Var.m(n1Var.f21676f);
                            break;
                        default:
                            s1Var.x(n1Var.f21679i.f22007d);
                            break;
                    }
                }
            });
        }
        Y2();
        this.O.b();
        if (n1Var2.f21683o != n1Var.f21683o) {
            Iterator it = this.P.iterator();
            while (it.hasNext()) {
                ((w) it.next()).f21753d.b3();
            }
        }
    }

    @Override // k3.e1, mr.u1
    public final void b() {
        c3();
        boolean zO = o();
        int iC = this.f21844c0.c(2, zO);
        Z2(iC, (!zO || iC == 1) ? 1 : 2, zO);
        n1 n1Var = this.J0;
        if (n1Var.f21675e != 1) {
            return;
        }
        n1 n1VarE = n1Var.e(null);
        n1 n1VarG = n1VarE.g(n1VarE.f21671a.p() ? 4 : 2);
        this.f21851i0++;
        qt.u uVar = this.N.J;
        uVar.getClass();
        qt.t tVarB = qt.u.b();
        tVarB.f27311a = uVar.f27313a.obtainMessage(0);
        tVarB.b();
        a3(n1VarG, 1, 1, false, 5, -9223372036854775807L, -1, false);
    }

    @Override // k3.e1, mr.u1
    public final long b0() {
        c3();
        return qt.x.U(L2(this.J0));
    }

    public final void b3() {
        int I = I();
        ay.f fVar = this.f21846e0;
        al.d dVar = this.f21845d0;
        if (I != 1) {
            if (I == 2 || I == 3) {
                c3();
                boolean z11 = this.J0.f21683o;
                o();
                dVar.getClass();
                o();
                fVar.getClass();
                return;
            }
            if (I != 4) {
                throw new IllegalStateException();
            }
        }
        dVar.getClass();
        fVar.getClass();
    }

    @Override // k3.e1, mr.u1
    public final long c0() {
        c3();
        return this.W;
    }

    public final void c3() {
        this.f21865w.e();
        Thread threadCurrentThread = Thread.currentThread();
        Looper looper = this.U;
        if (threadCurrentThread != looper.getThread()) {
            String name = Thread.currentThread().getName();
            String name2 = looper.getThread().getName();
            int i11 = qt.x.f27318a;
            Locale locale = Locale.US;
            String strI = x2.i("Player is accessed on the wrong thread.\nCurrent thread: '", name, "'\nExpected thread: '", name2, "'\nSee https://developer.android.com/guide/topics/media/issues/player-accessed-on-wrong-thread");
            if (this.F0) {
                throw new IllegalStateException(strI);
            }
            qt.a.O("ExoPlayerImpl", strI, this.G0 ? null : new IllegalStateException());
            this.G0 = true;
        }
    }

    @Override // mr.u1
    public final o1 e() {
        c3();
        return this.J0.f21682n;
    }

    @Override // mr.u1
    public final void f0(s1 s1Var) {
        s1Var.getClass();
        this.O.a(s1Var);
    }

    @Override // k3.e1, mr.u1
    public final long getDuration() {
        c3();
        if (!l()) {
            j2 j2VarU = U();
            if (j2VarU.p()) {
                return -9223372036854775807L;
            }
            return qt.x.U(j2VarU.m(P(), (i2) this.f2686e, 0L).P);
        }
        n1 n1Var = this.J0;
        ss.s sVar = n1Var.f21672b;
        j2 j2Var = n1Var.f21671a;
        Object obj = sVar.f29324a;
        h2 h2Var = this.Q;
        j2Var.g(obj, h2Var);
        return qt.x.U(h2Var.a(sVar.f29325b, sVar.f29326c));
    }

    @Override // k3.e1, mr.u1
    public final boolean l() {
        c3();
        return this.J0.f21672b.a();
    }

    @Override // k3.e1, mr.u1
    public final long m() {
        c3();
        return qt.x.U(this.J0.f21685q);
    }

    @Override // mr.u1
    public final q1 n() {
        c3();
        return this.f21857o0;
    }

    @Override // k3.e1, mr.u1
    public final boolean o() {
        c3();
        return this.J0.l;
    }

    @Override // k3.e1, mr.u1
    public final void q(boolean z11) {
        c3();
        if (this.f21849h0 != z11) {
            this.f21849h0 = z11;
            qt.u uVar = this.N.J;
            uVar.getClass();
            qt.t tVarB = qt.u.b();
            tVarB.f27311a = uVar.f27313a.obtainMessage(12, z11 ? 1 : 0, 0);
            tVarB.b();
            r rVar = new r(0, z11);
            n3.q qVar = this.O;
            qVar.d(9, rVar);
            Y2();
            qVar.b();
        }
    }

    @Override // mr.u1
    public final void s() {
        c3();
    }

    @Override // k3.e1, mr.u1
    public final int t() {
        c3();
        if (this.J0.f21671a.p()) {
            return 0;
        }
        n1 n1Var = this.J0;
        return n1Var.f21671a.b(n1Var.f21672b.f29324a);
    }

    @Override // k3.e1, mr.u1
    public final void u(TextureView textureView) {
        c3();
        if (textureView == null || textureView != this.f21868x0) {
            return;
        }
        I2();
    }

    @Override // mr.u1
    public final rt.s v() {
        c3();
        return this.H0;
    }

    @Override // k3.e1, mr.u1
    public final int x() {
        c3();
        if (l()) {
            return this.J0.f21672b.f29326c;
        }
        return -1;
    }

    @Override // k3.e1, mr.u1
    public final void y(SurfaceView surfaceView) {
        c3();
        if (surfaceView instanceof rt.k) {
            S2();
            W2(surfaceView);
            V2(surfaceView.getHolder());
            return;
        }
        boolean z11 = surfaceView instanceof st.h;
        w wVar = this.Z;
        if (z11) {
            S2();
            this.f21864v0 = (st.h) surfaceView;
            w1 w1VarJ2 = J2(this.f21842a0);
            qt.a.k(!w1VarJ2.f21783g);
            w1VarJ2.f21780d = 10000;
            st.h hVar = this.f21864v0;
            qt.a.k(true ^ w1VarJ2.f21783g);
            w1VarJ2.f21781e = hVar;
            w1VarJ2.c();
            this.f21864v0.f29387d.add(wVar);
            W2(this.f21864v0.getVideoSurface());
            V2(surfaceView.getHolder());
            return;
        }
        SurfaceHolder holder = surfaceView == null ? null : surfaceView.getHolder();
        c3();
        if (holder == null) {
            I2();
            return;
        }
        S2();
        this.f21866w0 = true;
        this.f21862u0 = holder;
        holder.addCallback(wVar);
        Surface surface = holder.getSurface();
        if (surface == null || !surface.isValid()) {
            W2(null);
            Q2(0, 0);
        } else {
            W2(surface);
            Rect surfaceFrame = holder.getSurfaceFrame();
            Q2(surfaceFrame.width(), surfaceFrame.height());
        }
    }
}
