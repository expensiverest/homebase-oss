package mr;

import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class h0 {
    public int A;
    public int B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f21509a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f21510b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f21511c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f21512d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21513e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f21516h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public is.c f21517i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f21518j;
    public String k;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public List f21519m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public sr.h f21520n;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f21525s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public byte[] f21527u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public rt.b f21529w;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f21514f = -1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f21515g = -1;
    public int l = -1;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f21521o = Long.MAX_VALUE;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f21522p = -1;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f21523q = -1;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public float f21524r = -1.0f;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public float f21526t = 1.0f;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f21528v = -1;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f21530x = -1;
    public int y = -1;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f21531z = -1;
    public int C = -1;
    public int D = -1;
    public int E = -1;
    public int F = 0;
}
