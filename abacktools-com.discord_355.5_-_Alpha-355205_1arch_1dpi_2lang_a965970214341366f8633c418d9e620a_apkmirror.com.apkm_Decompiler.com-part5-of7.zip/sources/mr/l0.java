package mr;

import android.net.Uri;

/* JADX INFO: loaded from: classes3.dex */
public final class l0 implements e {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f21645e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final mp.a f21646i;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Uri f21647d;

    static {
        int i11 = qt.x.f27318a;
        f21645e = Integer.toString(0, 36);
        f21646i = new mp.a(20);
    }

    public l0(k0 k0Var) {
        this.f21647d = (Uri) k0Var.f21633d;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l0) || !this.f21647d.equals(((l0) obj).f21647d)) {
            return false;
        }
        int i11 = qt.x.f27318a;
        return true;
    }

    public final int hashCode() {
        return this.f21647d.hashCode() * 31;
    }
}
