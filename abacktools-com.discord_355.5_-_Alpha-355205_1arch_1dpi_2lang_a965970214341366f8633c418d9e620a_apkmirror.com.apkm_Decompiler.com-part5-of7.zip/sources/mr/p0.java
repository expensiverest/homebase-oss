package mr;

import android.net.Uri;
import java.util.Arrays;
import java.util.UUID;

/* JADX INFO: loaded from: classes3.dex */
public final class p0 implements e {
    public static final String K;
    public static final String L;
    public static final String M;
    public static final String N;
    public static final String O;
    public static final String P;
    public static final String Q;
    public static final String R;
    public static final mp.a S;
    public final byte[] J;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final UUID f21695d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Uri f21696e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final hx.p0 f21697i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f21698v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f21699w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final boolean f21700x;
    public final hx.m0 y;

    static {
        int i11 = qt.x.f27318a;
        K = Integer.toString(0, 36);
        L = Integer.toString(1, 36);
        M = Integer.toString(2, 36);
        N = Integer.toString(3, 36);
        O = Integer.toString(4, 36);
        P = Integer.toString(5, 36);
        Q = Integer.toString(6, 36);
        R = Integer.toString(7, 36);
        S = new mp.a(22);
    }

    public p0(k3.e0 e0Var) {
        qt.a.k((e0Var.f18579f && ((Uri) e0Var.f18575b) == null) ? false : true);
        UUID uuid = (UUID) e0Var.f18574a;
        uuid.getClass();
        this.f21695d = uuid;
        this.f21696e = (Uri) e0Var.f18575b;
        this.f21697i = (hx.p0) e0Var.f18576c;
        this.f21698v = e0Var.f18577d;
        this.f21700x = e0Var.f18579f;
        this.f21699w = e0Var.f18578e;
        this.y = (hx.m0) e0Var.f18580g;
        byte[] bArr = (byte[]) e0Var.f18581h;
        this.J = bArr != null ? Arrays.copyOf(bArr, bArr.length) : null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p0)) {
            return false;
        }
        p0 p0Var = (p0) obj;
        return this.f21695d.equals(p0Var.f21695d) && qt.x.a(this.f21696e, p0Var.f21696e) && qt.x.a(this.f21697i, p0Var.f21697i) && this.f21698v == p0Var.f21698v && this.f21700x == p0Var.f21700x && this.f21699w == p0Var.f21699w && this.y.equals(p0Var.y) && Arrays.equals(this.J, p0Var.J);
    }

    public final int hashCode() {
        int iHashCode = this.f21695d.hashCode() * 31;
        Uri uri = this.f21696e;
        return Arrays.hashCode(this.J) + ((this.y.hashCode() + ((((((((this.f21697i.hashCode() + ((iHashCode + (uri != null ? uri.hashCode() : 0)) * 31)) * 31) + (this.f21698v ? 1 : 0)) * 31) + (this.f21700x ? 1 : 0)) * 31) + (this.f21699w ? 1 : 0)) * 31)) * 31);
    }
}
