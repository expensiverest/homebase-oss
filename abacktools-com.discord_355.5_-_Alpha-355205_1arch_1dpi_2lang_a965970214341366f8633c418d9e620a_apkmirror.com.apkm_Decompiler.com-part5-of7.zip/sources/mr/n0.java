package mr;

/* JADX INFO: loaded from: classes3.dex */
public abstract class n0 implements e {
    public static final String J;
    public static final String K;
    public static final String L;
    public static final String M;
    public static final mp.a N;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final o0 f21664x = new o0(new m0());
    public static final String y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f21665d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f21666e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f21667i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f21668v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f21669w;

    static {
        int i11 = qt.x.f27318a;
        y = Integer.toString(0, 36);
        J = Integer.toString(1, 36);
        K = Integer.toString(2, 36);
        L = Integer.toString(3, 36);
        M = Integer.toString(4, 36);
        N = new mp.a(21);
    }

    public n0(m0 m0Var) {
        this.f21665d = m0Var.f21655a;
        this.f21666e = m0Var.f21656b;
        this.f21667i = m0Var.f21657c;
        this.f21668v = m0Var.f21658d;
        this.f21669w = m0Var.f21659e;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n0)) {
            return false;
        }
        n0 n0Var = (n0) obj;
        return this.f21665d == n0Var.f21665d && this.f21666e == n0Var.f21666e && this.f21667i == n0Var.f21667i && this.f21668v == n0Var.f21668v && this.f21669w == n0Var.f21669w;
    }

    public final int hashCode() {
        long j6 = this.f21665d;
        int i11 = ((int) (j6 ^ (j6 >>> 32))) * 31;
        long j11 = this.f21666e;
        return ((((((i11 + ((int) ((j11 >>> 32) ^ j11))) * 31) + (this.f21667i ? 1 : 0)) * 31) + (this.f21668v ? 1 : 0)) * 31) + (this.f21669w ? 1 : 0);
    }
}
