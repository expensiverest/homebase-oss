package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f21411a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n1 f21412b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f21413c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f21414d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21415e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f21416f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f21417g;

    public c0(n1 n1Var) {
        this.f21412b = n1Var;
    }

    public final void a(int i11) {
        this.f21411a |= i11 > 0;
        this.f21413c += i11;
    }
}
