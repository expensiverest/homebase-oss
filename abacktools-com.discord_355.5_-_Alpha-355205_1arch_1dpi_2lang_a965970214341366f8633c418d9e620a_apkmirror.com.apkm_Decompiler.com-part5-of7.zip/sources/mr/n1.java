package mr;

import android.os.SystemClock;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class n1 {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final ss.s f21670t = new ss.s(new Object());

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j2 f21671a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ss.s f21672b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f21673c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f21674d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21675e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final j f21676f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f21677g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ss.w0 f21678h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final mt.x f21679i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final List f21680j;
    public final ss.s k;
    public final boolean l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f21681m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final o1 f21682n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final boolean f21683o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public volatile long f21684p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public volatile long f21685q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public volatile long f21686r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public volatile long f21687s;

    public n1(j2 j2Var, ss.s sVar, long j6, long j11, int i11, j jVar, boolean z11, ss.w0 w0Var, mt.x xVar, List list, ss.s sVar2, boolean z12, int i12, o1 o1Var, long j12, long j13, long j14, long j15, boolean z13) {
        this.f21671a = j2Var;
        this.f21672b = sVar;
        this.f21673c = j6;
        this.f21674d = j11;
        this.f21675e = i11;
        this.f21676f = jVar;
        this.f21677g = z11;
        this.f21678h = w0Var;
        this.f21679i = xVar;
        this.f21680j = list;
        this.k = sVar2;
        this.l = z12;
        this.f21681m = i12;
        this.f21682n = o1Var;
        this.f21684p = j12;
        this.f21685q = j13;
        this.f21686r = j14;
        this.f21687s = j15;
        this.f21683o = z13;
    }

    public static n1 i(mt.x xVar) {
        g2 g2Var = j2.f21615d;
        ss.w0 w0Var = ss.w0.f29354v;
        hx.w1 w1Var = hx.w1.f14911w;
        o1 o1Var = o1.f21689v;
        ss.s sVar = f21670t;
        return new n1(g2Var, sVar, -9223372036854775807L, 0L, 1, null, false, w0Var, xVar, w1Var, sVar, false, 0, o1Var, 0L, 0L, 0L, 0L, false);
    }

    public final n1 a() {
        return new n1(this.f21671a, this.f21672b, this.f21673c, this.f21674d, this.f21675e, this.f21676f, this.f21677g, this.f21678h, this.f21679i, this.f21680j, this.k, this.l, this.f21681m, this.f21682n, this.f21684p, this.f21685q, j(), SystemClock.elapsedRealtime(), this.f21683o);
    }

    public final n1 b(ss.s sVar) {
        return new n1(this.f21671a, this.f21672b, this.f21673c, this.f21674d, this.f21675e, this.f21676f, this.f21677g, this.f21678h, this.f21679i, this.f21680j, sVar, this.l, this.f21681m, this.f21682n, this.f21684p, this.f21685q, this.f21686r, this.f21687s, this.f21683o);
    }

    public final n1 c(ss.s sVar, long j6, long j11, long j12, long j13, ss.w0 w0Var, mt.x xVar, List list) {
        return new n1(this.f21671a, sVar, j11, j12, this.f21675e, this.f21676f, this.f21677g, w0Var, xVar, list, this.k, this.l, this.f21681m, this.f21682n, this.f21684p, j13, j6, SystemClock.elapsedRealtime(), this.f21683o);
    }

    public final n1 d(int i11, boolean z11) {
        return new n1(this.f21671a, this.f21672b, this.f21673c, this.f21674d, this.f21675e, this.f21676f, this.f21677g, this.f21678h, this.f21679i, this.f21680j, this.k, z11, i11, this.f21682n, this.f21684p, this.f21685q, this.f21686r, this.f21687s, this.f21683o);
    }

    public final n1 e(j jVar) {
        return new n1(this.f21671a, this.f21672b, this.f21673c, this.f21674d, this.f21675e, jVar, this.f21677g, this.f21678h, this.f21679i, this.f21680j, this.k, this.l, this.f21681m, this.f21682n, this.f21684p, this.f21685q, this.f21686r, this.f21687s, this.f21683o);
    }

    public final n1 f(o1 o1Var) {
        return new n1(this.f21671a, this.f21672b, this.f21673c, this.f21674d, this.f21675e, this.f21676f, this.f21677g, this.f21678h, this.f21679i, this.f21680j, this.k, this.l, this.f21681m, o1Var, this.f21684p, this.f21685q, this.f21686r, this.f21687s, this.f21683o);
    }

    public final n1 g(int i11) {
        return new n1(this.f21671a, this.f21672b, this.f21673c, this.f21674d, i11, this.f21676f, this.f21677g, this.f21678h, this.f21679i, this.f21680j, this.k, this.l, this.f21681m, this.f21682n, this.f21684p, this.f21685q, this.f21686r, this.f21687s, this.f21683o);
    }

    public final n1 h(j2 j2Var) {
        return new n1(j2Var, this.f21672b, this.f21673c, this.f21674d, this.f21675e, this.f21676f, this.f21677g, this.f21678h, this.f21679i, this.f21680j, this.k, this.l, this.f21681m, this.f21682n, this.f21684p, this.f21685q, this.f21686r, this.f21687s, this.f21683o);
    }

    public final long j() {
        long j6;
        long j11;
        if (!k()) {
            return this.f21686r;
        }
        do {
            j6 = this.f21687s;
            j11 = this.f21686r;
        } while (j6 != this.f21687s);
        return qt.x.I(qt.x.U(j11) + ((long) ((SystemClock.elapsedRealtime() - j6) * this.f21682n.f21690d)));
    }

    public final boolean k() {
        return this.f21675e == 3 && this.l && this.f21681m == 0;
    }
}
