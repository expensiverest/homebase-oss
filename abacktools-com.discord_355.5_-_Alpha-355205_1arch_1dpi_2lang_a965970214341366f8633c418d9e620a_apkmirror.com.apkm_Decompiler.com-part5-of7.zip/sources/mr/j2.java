package mr;

import android.util.Pair;
import com.facebook.imageutils.JfifUtil;

/* JADX INFO: loaded from: classes3.dex */
public abstract class j2 implements e {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final g2 f21615d = new g2();

    static {
        int i11 = qt.x.f27318a;
        Integer.toString(0, 36);
        Integer.toString(1, 36);
        Integer.toString(2, 36);
    }

    public int a(boolean z11) {
        return p() ? -1 : 0;
    }

    public abstract int b(Object obj);

    public int c(boolean z11) {
        if (p()) {
            return -1;
        }
        return o() - 1;
    }

    public final int d(int i11, h2 h2Var, i2 i2Var, int i12, boolean z11) {
        int i13 = f(i11, h2Var, false).f21537i;
        if (m(i13, i2Var, 0L).R != i11) {
            return i11 + 1;
        }
        int iE = e(i13, i12, z11);
        if (iE == -1) {
            return -1;
        }
        return m(iE, i2Var, 0L).Q;
    }

    public int e(int i11, int i12, boolean z11) {
        if (i12 == 0) {
            if (i11 == c(z11)) {
                return -1;
            }
            return i11 + 1;
        }
        if (i12 == 1) {
            return i11;
        }
        if (i12 == 2) {
            return i11 == c(z11) ? a(z11) : i11 + 1;
        }
        throw new IllegalStateException();
    }

    public final boolean equals(Object obj) {
        int iC;
        if (this != obj) {
            if (obj instanceof j2) {
                j2 j2Var = (j2) obj;
                if (j2Var.o() == o() && j2Var.h() == h()) {
                    i2 i2Var = new i2();
                    h2 h2Var = new h2();
                    i2 i2Var2 = new i2();
                    h2 h2Var2 = new h2();
                    int i11 = 0;
                    while (true) {
                        if (i11 >= o()) {
                            int i12 = 0;
                            while (true) {
                                if (i12 >= h()) {
                                    int iA = a(true);
                                    if (iA != j2Var.a(true) || (iC = c(true)) != j2Var.c(true)) {
                                        break;
                                        break;
                                    }
                                    while (iA != iC) {
                                        int iE = e(iA, 0, true);
                                        if (iE != j2Var.e(iA, 0, true)) {
                                            break;
                                        }
                                        iA = iE;
                                    }
                                } else {
                                    if (!f(i12, h2Var, true).equals(j2Var.f(i12, h2Var2, true))) {
                                        break;
                                    }
                                    i12++;
                                }
                            }
                        } else {
                            if (!m(i11, i2Var, 0L).equals(j2Var.m(i11, i2Var2, 0L))) {
                                break;
                            }
                            i11++;
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public abstract h2 f(int i11, h2 h2Var, boolean z11);

    public h2 g(Object obj, h2 h2Var) {
        return f(b(obj), h2Var, true);
    }

    public abstract int h();

    public final int hashCode() {
        i2 i2Var = new i2();
        h2 h2Var = new h2();
        int iO = o() + JfifUtil.MARKER_EOI;
        for (int i11 = 0; i11 < o(); i11++) {
            iO = (iO * 31) + m(i11, i2Var, 0L).hashCode();
        }
        int iH = h() + (iO * 31);
        for (int i12 = 0; i12 < h(); i12++) {
            iH = (iH * 31) + f(i12, h2Var, true).hashCode();
        }
        int iA = a(true);
        while (iA != -1) {
            iH = (iH * 31) + iA;
            iA = e(iA, 0, true);
        }
        return iH;
    }

    public final Pair i(i2 i2Var, h2 h2Var, int i11, long j6) {
        Pair pairJ = j(i2Var, h2Var, i11, j6, 0L);
        pairJ.getClass();
        return pairJ;
    }

    public final Pair j(i2 i2Var, h2 h2Var, int i11, long j6, long j11) {
        qt.a.j(i11, o());
        m(i11, i2Var, j11);
        if (j6 == -9223372036854775807L) {
            j6 = i2Var.O;
            if (j6 == -9223372036854775807L) {
                return null;
            }
        }
        int i12 = i2Var.Q;
        f(i12, h2Var, false);
        while (i12 < i2Var.R && h2Var.f21539w != j6) {
            int i13 = i12 + 1;
            if (f(i13, h2Var, false).f21539w > j6) {
                break;
            }
            i12 = i13;
        }
        f(i12, h2Var, true);
        long jMin = j6 - h2Var.f21539w;
        long j12 = h2Var.f21538v;
        if (j12 != -9223372036854775807L) {
            jMin = Math.min(jMin, j12 - 1);
        }
        long jMax = Math.max(0L, jMin);
        Object obj = h2Var.f21536e;
        obj.getClass();
        return Pair.create(obj, Long.valueOf(jMax));
    }

    public int k(int i11, int i12, boolean z11) {
        if (i12 == 0) {
            if (i11 == a(z11)) {
                return -1;
            }
            return i11 - 1;
        }
        if (i12 == 1) {
            return i11;
        }
        if (i12 == 2) {
            return i11 == a(z11) ? c(z11) : i11 - 1;
        }
        throw new IllegalStateException();
    }

    public abstract Object l(int i11);

    public abstract i2 m(int i11, i2 i2Var, long j6);

    public final void n(int i11, i2 i2Var) {
        m(i11, i2Var, 0L);
    }

    public abstract int o();

    public final boolean p() {
        return o() == 0;
    }
}
