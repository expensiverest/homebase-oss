package mr;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class k2 implements e {
    public static final String J;
    public static final String K;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f21636x;
    public static final String y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21637d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ss.v0 f21638e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f21639i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int[] f21640v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean[] f21641w;

    static {
        int i11 = qt.x.f27318a;
        f21636x = Integer.toString(0, 36);
        y = Integer.toString(1, 36);
        J = Integer.toString(3, 36);
        K = Integer.toString(4, 36);
    }

    public k2(ss.v0 v0Var, boolean z11, int[] iArr, boolean[] zArr) {
        int i11 = v0Var.f29349d;
        this.f21637d = i11;
        boolean z12 = false;
        qt.a.g(i11 == iArr.length && i11 == zArr.length);
        this.f21638e = v0Var;
        if (z11 && i11 > 1) {
            z12 = true;
        }
        this.f21639i = z12;
        this.f21640v = (int[]) iArr.clone();
        this.f21641w = (boolean[]) zArr.clone();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && k2.class == obj.getClass()) {
            k2 k2Var = (k2) obj;
            if (this.f21639i == k2Var.f21639i && this.f21638e.equals(k2Var.f21638e) && Arrays.equals(this.f21640v, k2Var.f21640v) && Arrays.equals(this.f21641w, k2Var.f21641w)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f21641w) + ((Arrays.hashCode(this.f21640v) + (((this.f21638e.hashCode() * 31) + (this.f21639i ? 1 : 0)) * 31)) * 31);
    }
}
