package mr;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;

/* JADX INFO: loaded from: classes3.dex */
public final class a extends BroadcastReceiver implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final w f21376d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Handler f21377e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ an.c f21378i;

    public a(an.c cVar, Handler handler, w wVar) {
        this.f21378i = cVar;
        this.f21377e = handler;
        this.f21376d = wVar;
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if ("android.media.AUDIO_BECOMING_NOISY".equals(intent.getAction())) {
            this.f21377e.post(this);
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.f21378i.f1253e) {
            this.f21376d.f21753d.Z2(-1, 3, false);
        }
    }
}
