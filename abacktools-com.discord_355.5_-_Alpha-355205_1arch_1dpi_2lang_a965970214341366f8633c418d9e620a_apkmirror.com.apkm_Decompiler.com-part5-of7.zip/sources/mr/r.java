package mr;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class r implements qt.g, n3.n, n3.j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21713d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ boolean f21714e;

    public /* synthetic */ r(int i11, boolean z11) {
        this.f21713d = i11;
        this.f21714e = z11;
    }

    @Override // n3.j
    public void accept(Object obj) {
        switch (this.f21713d) {
            case 4:
                ((y5.w1) obj).F(this.f21714e);
                break;
            case 5:
                ((y5.w1) obj).I1(this.f21714e);
                break;
            default:
                ((y5.w1) obj).q(this.f21714e);
                break;
        }
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        switch (this.f21713d) {
            case 0:
                ((s1) obj).h(this.f21714e);
                break;
            case 1:
                ((s1) obj).j(this.f21714e);
                break;
            case 2:
                ((k3.c1) obj).h(this.f21714e);
                break;
            default:
                ((k3.c1) obj).j(this.f21714e);
                break;
        }
    }
}
