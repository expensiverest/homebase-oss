package mr;

/* JADX INFO: loaded from: classes3.dex */
public final class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ss.s f21421a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f21422b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f21423c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21424d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f21425e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f21426f;

    public d0(ss.s sVar, long j6, long j11, boolean z11, boolean z12, boolean z13) {
        this.f21421a = sVar;
        this.f21422b = j6;
        this.f21423c = j11;
        this.f21424d = z11;
        this.f21425e = z12;
        this.f21426f = z13;
    }
}
