package mr;

import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.view.View;
import com.google.android.material.sidesheet.SideSheetBehavior;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class s implements qt.g, v1.p, n3.n, n3.j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21722d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f21723e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f21724i;

    public /* synthetic */ s(int i11, int i12, Object obj) {
        this.f21722d = i12;
        this.f21724i = obj;
        this.f21723e = i11;
    }

    @Override // n3.j
    public void accept(Object obj) {
        y5.n nVar;
        y5.n nVar2;
        y5.u uVar = (y5.u) this.f21724i;
        int i11 = this.f21723e;
        try {
            nVar2 = (y5.n) ((mx.y) obj).get();
            oq.a.t(nVar2, "LibraryResult must not be null");
        } catch (InterruptedException e4) {
            e = e4;
            n3.b.m("MediaSessionStub", "Library operation failed", e);
            String str = y5.n.f36009d;
            y5.a2 a2Var = new y5.a2(-1, "no error message provided", Bundle.EMPTY);
            nVar = new y5.n(a2Var.f35808a, SystemClock.elapsedRealtime(), a2Var);
            nVar2 = nVar;
        } catch (CancellationException e9) {
            n3.b.m("MediaSessionStub", "Library operation cancelled", e9);
            String str2 = y5.n.f36009d;
            y5.a2 a2Var2 = new y5.a2(1, "no error message provided", Bundle.EMPTY);
            nVar = new y5.n(a2Var2.f35808a, SystemClock.elapsedRealtime(), a2Var2);
            nVar2 = nVar;
        } catch (ExecutionException e11) {
            e = e11;
            n3.b.m("MediaSessionStub", "Library operation failed", e);
            String str3 = y5.n.f36009d;
            y5.a2 a2Var3 = new y5.a2(-1, "no error message provided", Bundle.EMPTY);
            nVar = new y5.n(a2Var3.f35808a, SystemClock.elapsedRealtime(), a2Var3);
            nVar2 = nVar;
        }
        try {
            y5.t tVar = uVar.f36088e;
            tVar.getClass();
            tVar.g(i11, nVar2);
        } catch (RemoteException e12) {
            n3.b.m("MediaSessionStub", "Failed to send result to browser " + uVar, e12);
        }
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        switch (this.f21722d) {
            case 0:
                ((s1) obj).D((v0) this.f21724i, this.f21723e);
                break;
            case 1:
                t1 t1Var = (t1) this.f21724i;
                nr.b bVar = (nr.b) obj;
                bVar.getClass();
                bVar.i(t1Var, this.f21723e);
                break;
            case 2:
            default:
                k3.d1 d1Var = (k3.d1) this.f21724i;
                w3.b bVar2 = (w3.b) obj;
                bVar2.getClass();
                bVar2.l(d1Var, this.f21723e);
                break;
            case 3:
                ((k3.c1) obj).M(((v3.x0) this.f21724i).f32156a, this.f21723e);
                break;
            case 4:
                k3.c1 c1Var = (k3.c1) obj;
                c1Var.x(this.f21723e, (k3.o0) this.f21724i);
                break;
        }
    }

    @Override // v1.p
    public boolean o(View view) {
        ((SideSheetBehavior) this.f21724i).w(this.f21723e);
        return true;
    }

    public /* synthetic */ s(int i11, int i12, Object obj, Object obj2, Object obj3) {
        this.f21722d = i12;
        this.f21723e = i11;
        this.f21724i = obj2;
    }
}
