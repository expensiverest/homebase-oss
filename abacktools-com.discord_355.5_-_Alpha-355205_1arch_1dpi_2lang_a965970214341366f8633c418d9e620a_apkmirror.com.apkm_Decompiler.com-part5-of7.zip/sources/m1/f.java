package m1;

import android.os.Build;
import android.os.Trace;
import android.util.Log;
import androidx.core.view.j1;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final long f20768a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Method f20769b;

    static {
        if (Build.VERSION.SDK_INT < 29) {
            try {
                f20768a = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                Class cls = Long.TYPE;
                f20769b = Trace.class.getMethod("isTagEnabled", cls);
                Class cls2 = Integer.TYPE;
                Trace.class.getMethod("asyncTraceBegin", cls, String.class, cls2);
                Trace.class.getMethod("asyncTraceEnd", cls, String.class, cls2);
                Trace.class.getMethod("traceCounter", cls, String.class, cls2);
            } catch (Exception e4) {
                Log.i("TraceCompat", "Unable to initialize via reflection.", e4);
            }
        }
    }

    public static boolean a() {
        if (Build.VERSION.SDK_INT >= 29) {
            return j1.q();
        }
        try {
            return ((Boolean) f20769b.invoke(null, Long.valueOf(f20768a))).booleanValue();
        } catch (Exception unused) {
            Log.v("TraceCompat", "Unable to invoke isTagEnabled() via reflection.");
            return false;
        }
    }
}
