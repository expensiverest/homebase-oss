package m1;

import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f20761a = 0;

    static {
        int i11 = Build.VERSION.SDK_INT;
        if (i11 >= 30) {
            g1.e.b(30);
        }
        if (i11 >= 30) {
            g1.e.b(31);
        }
        if (i11 >= 30) {
            g1.e.b(33);
        }
        if (i11 >= 30) {
            g1.e.b(1000000);
        }
    }
}
