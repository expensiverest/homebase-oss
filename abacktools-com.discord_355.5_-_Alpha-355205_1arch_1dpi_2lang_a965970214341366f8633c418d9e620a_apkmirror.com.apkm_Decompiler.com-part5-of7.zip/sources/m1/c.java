package m1;

import s6.u;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f20762a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public bq.a f20763b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f20764c;

    public final void a() {
        synchronized (this) {
            try {
                if (this.f20762a) {
                    return;
                }
                this.f20762a = true;
                this.f20764c = true;
                bq.a aVar = this.f20763b;
                if (aVar != null) {
                    try {
                        Runnable runnable = (Runnable) aVar.f3970e;
                        u uVar = (u) aVar.f3971i;
                        Runnable runnable2 = (Runnable) aVar.f3972v;
                        if (runnable == null) {
                            uVar.d();
                            runnable2.run();
                        } else {
                            runnable.run();
                        }
                    } catch (Throwable th2) {
                        synchronized (this) {
                            this.f20764c = false;
                            notifyAll();
                            throw th2;
                        }
                    }
                }
                synchronized (this) {
                    this.f20764c = false;
                    notifyAll();
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
    }
}
