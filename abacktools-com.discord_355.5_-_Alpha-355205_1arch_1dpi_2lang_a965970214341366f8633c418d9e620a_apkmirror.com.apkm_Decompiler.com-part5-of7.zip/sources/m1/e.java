package m1;

import android.os.LocaleList;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LocaleList f20767a;

    public e(LocaleList localeList) {
        this.f20767a = localeList;
    }

    public final boolean equals(Object obj) {
        return this.f20767a.equals(((e) obj).f20767a);
    }

    public final int hashCode() {
        return this.f20767a.hashCode();
    }

    public final String toString() {
        return this.f20767a.toString();
    }
}
