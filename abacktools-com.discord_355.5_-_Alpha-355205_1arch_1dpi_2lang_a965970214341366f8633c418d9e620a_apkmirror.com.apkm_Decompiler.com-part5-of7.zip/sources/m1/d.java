package m1;

import android.os.LocaleList;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d f20765b = new d(new e(new LocaleList(new Locale[0])));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f20766a;

    public d(e eVar) {
        this.f20766a = eVar;
    }

    public static d a(String str) {
        if (str == null || str.isEmpty()) {
            return f20765b;
        }
        String[] strArrSplit = str.split(",", -1);
        int length = strArrSplit.length;
        Locale[] localeArr = new Locale[length];
        for (int i11 = 0; i11 < length; i11++) {
            localeArr[i11] = Locale.forLanguageTag(strArrSplit[i11]);
        }
        return new d(new e(new LocaleList(localeArr)));
    }

    public final boolean equals(Object obj) {
        if (obj instanceof d) {
            return this.f20766a.equals(((d) obj).f20766a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f20766a.f20767a.hashCode();
    }

    public final String toString() {
        return this.f20766a.f20767a.toString();
    }
}
