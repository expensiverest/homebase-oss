package m1;

import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class a {
    public static /* synthetic */ int a() {
        int i11 = Build.VERSION.SDK_INT;
        return i11 < 36 ? i11 * 100000 : Build.VERSION.SDK_INT_FULL;
    }
}
