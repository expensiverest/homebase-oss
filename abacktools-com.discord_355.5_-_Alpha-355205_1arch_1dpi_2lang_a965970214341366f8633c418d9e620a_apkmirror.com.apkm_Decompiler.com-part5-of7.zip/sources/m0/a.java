package m0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a f20722d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f20723e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final a f20724i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ a[] f20725v;

    static {
        a aVar = new a("On", 0);
        f20722d = aVar;
        a aVar2 = new a("Off", 1);
        f20723e = aVar2;
        a aVar3 = new a("Indeterminate", 2);
        f20724i = aVar3;
        a[] aVarArr = {aVar, aVar2, aVar3};
        f20725v = aVarArr;
        oq.a.G(aVarArr);
    }

    public static a valueOf(String str) {
        return (a) Enum.valueOf(a.class, str);
    }

    public static a[] values() {
        return (a[]) f20725v.clone();
    }
}
