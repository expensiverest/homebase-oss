package m2;

import android.database.ContentObserver;
import android.database.Cursor;
import android.os.Handler;
import android.provider.Settings;
import p.z2;

/* JADX INFO: loaded from: classes.dex */
public final class a extends ContentObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f20770a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f20771b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(wq.a aVar, Handler handler) {
        super(handler);
        this.f20771b = aVar;
    }

    @Override // android.database.ContentObserver
    public final boolean deliverSelfNotifications() {
        switch (this.f20770a) {
        }
        return true;
    }

    @Override // android.database.ContentObserver
    public final void onChange(boolean z11) {
        Cursor cursor;
        switch (this.f20770a) {
            case 0:
                z2 z2Var = (z2) this.f20771b;
                if (z2Var.f20775e && (cursor = z2Var.f20776i) != null && !cursor.isClosed()) {
                    z2Var.f20774d = z2Var.f20776i.requery();
                    break;
                }
                break;
            default:
                super.onChange(z11);
                wq.a aVar = (wq.a) this.f20771b;
                aVar.f34413e.invoke(Boolean.valueOf(Settings.System.getInt(aVar.f34412d.getContentResolver(), aVar.f34415v, 0) == 1));
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(z2 z2Var) {
        super(new Handler());
        this.f20771b = z2Var;
    }
}
