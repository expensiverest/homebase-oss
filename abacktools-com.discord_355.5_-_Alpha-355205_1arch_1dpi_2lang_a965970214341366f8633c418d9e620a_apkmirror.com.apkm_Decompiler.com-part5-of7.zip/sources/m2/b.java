package m2;

import android.database.DataSetObserver;
import p.c2;
import p.z2;

/* JADX INFO: loaded from: classes.dex */
public final class b extends DataSetObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f20772a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f20773b;

    public /* synthetic */ b(int i11, Object obj) {
        this.f20772a = i11;
        this.f20773b = obj;
    }

    @Override // android.database.DataSetObserver
    public final void onChanged() {
        switch (this.f20772a) {
            case 0:
                z2 z2Var = (z2) this.f20773b;
                z2Var.f20774d = true;
                z2Var.notifyDataSetChanged();
                break;
            default:
                c2 c2Var = (c2) this.f20773b;
                if (c2Var.f25255b0.isShowing()) {
                    c2Var.b();
                }
                break;
        }
    }

    @Override // android.database.DataSetObserver
    public final void onInvalidated() {
        switch (this.f20772a) {
            case 0:
                z2 z2Var = (z2) this.f20773b;
                z2Var.f20774d = false;
                z2Var.notifyDataSetInvalidated();
                break;
            default:
                ((c2) this.f20773b).dismiss();
                break;
        }
    }
}
