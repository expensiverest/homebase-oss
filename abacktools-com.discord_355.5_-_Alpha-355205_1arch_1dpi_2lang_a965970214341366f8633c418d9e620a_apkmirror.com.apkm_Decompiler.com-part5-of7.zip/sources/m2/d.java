package m2;

import android.database.Cursor;
import android.util.Log;
import android.widget.Filter;
import p.w2;
import p.z2;

/* JADX INFO: loaded from: classes.dex */
public final class d extends Filter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public c f20780a;

    @Override // android.widget.Filter
    public final CharSequence convertResultToString(Object obj) {
        return ((z2) this.f20780a).c((Cursor) obj);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0031  */
    @Override // android.widget.Filter
    public final Filter.FilterResults performFiltering(CharSequence charSequence) {
        Cursor cursorF;
        z2 z2Var = (z2) this.f20780a;
        w2 w2Var = z2Var.M;
        String string = charSequence == null ? "" : charSequence.toString();
        if (w2Var.getVisibility() == 0 && w2Var.getWindowVisibility() == 0) {
            try {
                cursorF = z2Var.f(z2Var.N, string);
                if (cursorF != null) {
                    cursorF.getCount();
                } else {
                    cursorF = null;
                }
            } catch (RuntimeException e4) {
                Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", e4);
            }
        } else {
            cursorF = null;
        }
        Filter.FilterResults filterResults = new Filter.FilterResults();
        if (cursorF != null) {
            filterResults.count = cursorF.getCount();
            filterResults.values = cursorF;
        } else {
            filterResults.count = 0;
            filterResults.values = null;
        }
        return filterResults;
    }

    @Override // android.widget.Filter
    public final void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
        c cVar = this.f20780a;
        Cursor cursor = cVar.f20776i;
        Object obj = filterResults.values;
        if (obj == null || obj == cursor) {
            return;
        }
        ((z2) cVar).b((Cursor) obj);
    }
}
