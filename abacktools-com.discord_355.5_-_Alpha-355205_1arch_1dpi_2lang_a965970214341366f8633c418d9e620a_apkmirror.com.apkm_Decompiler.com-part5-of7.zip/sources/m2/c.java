package m2;

import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import com.discord.R;
import hs.q;
import p.y2;
import p.z2;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends BaseAdapter implements Filterable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f20774d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f20775e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Cursor f20776i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f20777v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public a f20778w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public b f20779x;
    public d y;

    public abstract void a(View view, Cursor cursor);

    public void b(Cursor cursor) {
        Cursor cursor2 = this.f20776i;
        if (cursor == cursor2) {
            cursor2 = null;
        } else {
            if (cursor2 != null) {
                a aVar = this.f20778w;
                if (aVar != null) {
                    cursor2.unregisterContentObserver(aVar);
                }
                b bVar = this.f20779x;
                if (bVar != null) {
                    cursor2.unregisterDataSetObserver(bVar);
                }
            }
            this.f20776i = cursor;
            if (cursor != null) {
                a aVar2 = this.f20778w;
                if (aVar2 != null) {
                    cursor.registerContentObserver(aVar2);
                }
                b bVar2 = this.f20779x;
                if (bVar2 != null) {
                    cursor.registerDataSetObserver(bVar2);
                }
                this.f20777v = cursor.getColumnIndexOrThrow("_id");
                this.f20774d = true;
                notifyDataSetChanged();
            } else {
                this.f20777v = -1;
                this.f20774d = false;
                notifyDataSetInvalidated();
            }
        }
        if (cursor2 != null) {
            cursor2.close();
        }
    }

    public abstract String c(Cursor cursor);

    @Override // android.widget.Adapter
    public final int getCount() {
        Cursor cursor;
        if (!this.f20774d || (cursor = this.f20776i) == null) {
            return 0;
        }
        return cursor.getCount();
    }

    @Override // android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i11, View view, ViewGroup viewGroup) {
        if (!this.f20774d) {
            return null;
        }
        this.f20776i.moveToPosition(i11);
        if (view == null) {
            z2 z2Var = (z2) this;
            view = z2Var.L.inflate(z2Var.K, viewGroup, false);
        }
        a(view, this.f20776i);
        return view;
    }

    @Override // android.widget.Filterable
    public final Filter getFilter() {
        if (this.y == null) {
            d dVar = new d();
            dVar.f20780a = this;
            this.y = dVar;
        }
        return this.y;
    }

    @Override // android.widget.Adapter
    public final Object getItem(int i11) {
        Cursor cursor;
        if (!this.f20774d || (cursor = this.f20776i) == null) {
            return null;
        }
        cursor.moveToPosition(i11);
        return this.f20776i;
    }

    @Override // android.widget.Adapter
    public final long getItemId(int i11) {
        Cursor cursor;
        if (this.f20774d && (cursor = this.f20776i) != null && cursor.moveToPosition(i11)) {
            return this.f20776i.getLong(this.f20777v);
        }
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int i11, View view, ViewGroup viewGroup) {
        if (!this.f20774d) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        }
        if (!this.f20776i.moveToPosition(i11)) {
            throw new IllegalStateException(q.j(i11, "couldn't move cursor to position "));
        }
        if (view == null) {
            z2 z2Var = (z2) this;
            view = z2Var.L.inflate(z2Var.J, viewGroup, false);
            view.setTag(new y2(view));
            ((ImageView) view.findViewById(R.id.edit_query)).setImageResource(z2Var.Q);
        }
        a(view, this.f20776i);
        return view;
    }
}
