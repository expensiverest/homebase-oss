package me;

import com.discord.crash_reporting.CrashReporting;
import java.util.Map;
import jj.c;
import kotlin.jvm.internal.k;
import m30.t;
import n30.f;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    public static f a(String str, Map map) {
        f fVar = new f();
        Object obj = map.get("action");
        if (obj == null) {
            obj = "log";
        }
        fVar.put("action", obj);
        Object obj2 = map.get("detail");
        Object obj3 = str;
        if (obj2 != null) {
            obj3 = obj2;
        }
        fVar.put("detail", obj3);
        Object obj4 = map.get("fgs_operation");
        fVar.put("fgs_operation", obj4 != null ? obj4 : "log");
        fVar.putAll(map);
        return fVar.b();
    }

    public static void b(String message) {
        k.g(message, "message");
        d(message, a("info", t.f20880d), new c(3, nf.a.f23220a, nf.a.class, "i", "i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V", 0, 3), null);
    }

    public static void c(String message, Map map) {
        k.g(message, "message");
        d(message, a("info", map), new c(3, nf.a.f23220a, nf.a.class, "i", "i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V", 0, 4), null);
    }

    public static void d(String str, f fVar, a40.a aVar, Exception exc) {
        CrashReporting.b(CrashReporting.INSTANCE, str, fVar, "ForegroundService", 24);
        aVar.invoke("ForegroundService", str, exc);
    }

    public static void e(String message, f fVar, Exception exc) {
        k.g(message, "message");
        d(message, a("warn", fVar), new c(3, nf.a.f23220a, nf.a.class, "w", "w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V", 0, 5), exc);
    }
}
