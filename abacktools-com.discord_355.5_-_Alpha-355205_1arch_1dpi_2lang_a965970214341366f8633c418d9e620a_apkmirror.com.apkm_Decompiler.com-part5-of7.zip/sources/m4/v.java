package m4;

import android.content.Context;
import android.util.Pair;
import android.util.SparseArray;
import hx.w1;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: loaded from: classes.dex */
public final class v {

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final b f21039q = new b(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f21040a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final t f21041b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final SparseArray f21042c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21043d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final e f21044e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final n3.e0 f21045f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final CopyOnWriteArraySet f21046g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f21047h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final b0 f21048i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public n3.i0 f21049j = new n3.i0(0);
    public n3.g0 k;
    public Pair l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f21050m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f21051n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f21052o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f21053p;

    public v(q qVar) {
        this.f21040a = qVar.f21023a;
        t tVar = qVar.f21025c;
        tVar.getClass();
        this.f21041b = tVar;
        this.f21042c = new SparseArray();
        hx.k0 k0Var = hx.m0.f14841e;
        w1 w1Var = w1.f14911w;
        this.f21043d = qVar.f21026d;
        n3.e0 e0Var = qVar.f21027e;
        this.f21045f = e0Var;
        long j6 = qVar.f21029g;
        this.f21047h = j6 != -9223372036854775807L ? -j6 : -9223372036854775807L;
        b0 b0Var = qVar.f21030h;
        this.f21048i = b0Var;
        this.f21044e = new e(qVar.f21024b, b0Var, e0Var);
        this.f21046g = new CopyOnWriteArraySet();
        new k3.v().a();
        this.f21052o = -9223372036854775807L;
        this.f21053p = -1;
        this.f21051n = 0;
    }
}
