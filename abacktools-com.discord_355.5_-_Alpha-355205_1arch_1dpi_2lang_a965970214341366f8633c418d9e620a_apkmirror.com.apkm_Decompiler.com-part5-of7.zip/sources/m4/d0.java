package m4;

import android.hardware.display.DisplayManager;
import android.view.Choreographer;

/* JADX INFO: loaded from: classes.dex */
public abstract class d0 implements DisplayManager.DisplayListener {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Choreographer f20910d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final DisplayManager f20911e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public volatile long f20912i = -9223372036854775807L;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public volatile long f20913v = -9223372036854775807L;

    public d0(Choreographer choreographer, DisplayManager displayManager) {
        this.f20910d = choreographer;
        this.f20911e = displayManager;
    }

    public abstract void a();

    public abstract void b();

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayAdded(int i11) {
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayRemoved(int i11) {
    }
}
