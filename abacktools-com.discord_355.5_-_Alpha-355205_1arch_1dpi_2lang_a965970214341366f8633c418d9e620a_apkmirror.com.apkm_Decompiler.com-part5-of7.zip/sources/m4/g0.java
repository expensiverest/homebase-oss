package m4;

import android.content.Context;
import android.os.Build;
import android.view.Surface;

/* JADX INFO: loaded from: classes.dex */
public final class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f20943a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f20944b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public d0 f20945c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f20946d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Surface f20947e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f20948f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f20949g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f20950h = 1.0f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20951i = 0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public long f20952j;
    public long k;
    public long l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f20953m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public long f20954n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f20955o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public long f20956p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public long f20957q;

    public g0(Context context) {
        this.f20943a = context;
    }

    public final void a() {
        Surface surface;
        if (Build.VERSION.SDK_INT < 30 || (surface = this.f20947e) == null || this.f20951i == Integer.MIN_VALUE || this.f20949g == 0.0f || !surface.isValid()) {
            return;
        }
        this.f20949g = 0.0f;
        c0.a(this.f20947e, 0.0f);
    }

    public final void b() {
        this.f20955o = -1L;
        this.l = -1L;
        this.f20954n = -9223372036854775807L;
        this.f20952j = 0L;
        this.k = 0L;
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0027  */
    public final void c(boolean z11) {
        Surface surface;
        float f3;
        if (Build.VERSION.SDK_INT < 30 || (surface = this.f20947e) == null || this.f20951i == Integer.MIN_VALUE || !surface.isValid()) {
            return;
        }
        if (this.f20946d) {
            float f11 = this.f20948f;
            if (f11 != -1.0f) {
                f3 = f11 * this.f20950h;
            } else {
                f3 = 0.0f;
            }
        } else {
            f3 = 0.0f;
        }
        if (z11 || this.f20949g != f3) {
            this.f20949g = f3;
            c0.a(this.f20947e, f3);
        }
    }
}
