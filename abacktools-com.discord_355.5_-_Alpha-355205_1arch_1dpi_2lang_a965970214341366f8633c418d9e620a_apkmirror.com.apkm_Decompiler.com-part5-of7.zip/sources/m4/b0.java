package m4;

import android.util.Range;

/* JADX INFO: loaded from: classes.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f20904a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f20905b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public double f20906c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Range f20907d;

    public b0() {
        Range range = new Range(Double.valueOf(0.0d), Double.valueOf(1.0d / ((double) 1.0f)));
        this.f20907d = range;
        this.f20906c = ((Double) range.getUpper()).doubleValue();
        this.f20904a = -9223372036854775807L;
        this.f20905b = -9223372036854775807L;
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0031  */
    public final void a(long j6, long j11) {
        double dDoubleValue;
        oq.a.n(j6 != -9223372036854775807L);
        oq.a.n(j11 != -9223372036854775807L);
        long j12 = this.f20904a;
        if (j12 != -9223372036854775807L) {
            long j13 = this.f20905b;
            if (j13 == -9223372036854775807L || j6 == j12) {
                dDoubleValue = ((Double) this.f20907d.getUpper()).doubleValue();
            } else {
                dDoubleValue = (j11 - j13) / (j6 - j12);
            }
        } else {
            dDoubleValue = ((Double) this.f20907d.getUpper()).doubleValue();
        }
        this.f20906c = (((Double) this.f20907d.clamp(Double.valueOf(dDoubleValue))).doubleValue() * 0.20000000298023224d) + (this.f20906c * 0.800000011920929d);
        this.f20904a = j6;
        this.f20905b = j11;
    }

    public final void b() {
        this.f20906c = ((Double) this.f20907d.getUpper()).doubleValue();
        this.f20904a = -9223372036854775807L;
        this.f20905b = -9223372036854775807L;
    }

    public final void c(float f3) {
        oq.a.n(f3 > 0.0f);
        this.f20907d = new Range(Double.valueOf(0.0d), Double.valueOf(1.0d / ((double) f3)));
        b();
    }
}
