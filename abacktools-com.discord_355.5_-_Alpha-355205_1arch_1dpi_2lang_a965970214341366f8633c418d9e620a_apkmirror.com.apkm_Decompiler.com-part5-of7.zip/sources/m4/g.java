package m4;

import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import io.sentry.android.core.n0;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f20936c;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f20938e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f20941h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final n0 f20942i;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public f f20934a = new f(0);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public f f20935b = new f(0);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f20937d = -9223372036854775807L;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f20939f = -1.0f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f20940g = -1.0f;

    public g(n0 n0Var) {
        this.f20942i = n0Var;
    }

    public final long a() {
        if (!this.f20934a.a()) {
            return -9223372036854775807L;
        }
        f fVar = this.f20934a;
        long j6 = fVar.f20929f;
        if (j6 == 0) {
            return 0L;
        }
        return fVar.f20930g / j6;
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0046  */
    public final void b(long j6) {
        if (j6 == this.f20937d) {
            return;
        }
        this.f20941h++;
        this.f20934a.b(j6);
        if (this.f20934a.a()) {
            this.f20936c = false;
        } else if (this.f20937d != -9223372036854775807L) {
            if (this.f20936c) {
                f fVar = this.f20935b;
                long j11 = fVar.f20928e;
                if (j11 == 0 ? false : fVar.f20931h[(int) ((j11 - 1) % 15)]) {
                    this.f20935b.c();
                    this.f20935b.b(this.f20937d);
                }
            } else {
                this.f20935b.c();
                this.f20935b.b(this.f20937d);
            }
            this.f20936c = true;
            this.f20935b.b(j6);
        }
        if (this.f20936c && this.f20935b.a()) {
            f fVar2 = this.f20934a;
            this.f20934a = this.f20935b;
            this.f20935b = fVar2;
            this.f20936c = false;
        }
        this.f20937d = j6;
        this.f20938e = this.f20934a.a() ? 0 : this.f20938e + 1;
        c();
    }

    public final void c() {
        float f3;
        boolean zA = this.f20934a.a();
        if (zA) {
            f fVar = this.f20934a;
            long j6 = fVar.f20929f;
            f3 = (float) (1.0E9d / (j6 != 0 ? fVar.f20930g / j6 : 0L));
        } else {
            f3 = this.f20939f;
        }
        float f11 = this.f20940g;
        if (f3 == f11) {
            return;
        }
        if (f3 != -1.0f && f11 != -1.0f) {
            if (Math.abs(f3 - f11) < ((!zA || this.f20934a.f20930g < 5000000000L) ? 1.0f : 0.1f)) {
                return;
            }
        } else if (f3 == -1.0f && this.f20938e < 30) {
            return;
        }
        this.f20940g = f3;
        n0 n0Var = this.f20942i;
        int i11 = n0Var.f16187d;
        Object obj = n0Var.f16188e;
        switch (i11) {
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                g0 g0Var = ((a0) obj).f20893b;
                if (g0Var.f20948f != f3) {
                    g0Var.f20948f = f3;
                    g0Var.c(false);
                    break;
                }
                break;
            default:
                n nVar = (n) obj;
                g0 g0Var2 = nVar.f21004s1.f20893b;
                if (g0Var2.f20948f != f3) {
                    g0Var2.f20948f = f3;
                    g0Var2.c(false);
                }
                nVar.D0(nVar.f4404r0);
                break;
        }
    }
}
