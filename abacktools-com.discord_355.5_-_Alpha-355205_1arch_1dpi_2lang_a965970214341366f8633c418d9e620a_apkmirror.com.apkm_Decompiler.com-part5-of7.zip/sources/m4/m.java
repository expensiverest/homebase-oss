package m4;

import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.Surface;
import k3.z1;

/* JADX INFO: loaded from: classes.dex */
public final class m implements Handler.Callback {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20985d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Handler f20986e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f20987i;

    public m(rt.g gVar, hs.h hVar) {
        this.f20987i = gVar;
        Handler handlerM = qt.x.m(this);
        this.f20986e = handlerM;
        hVar.i(this, handlerM);
    }

    public final void a(long j6) {
        Surface surface;
        switch (this.f20985d) {
            case 0:
                n nVar = (n) this.f20987i;
                k7.l lVar = nVar.f21001p1;
                if (this == nVar.f20994d2 && nVar.f4403q0 != null) {
                    if (j6 == Long.MAX_VALUE) {
                        nVar.Z0 = true;
                    } else {
                        try {
                            nVar.F0(j6);
                            z1 z1Var = nVar.Y1;
                            if (!z1Var.equals(z1.f19050d) && !z1Var.equals(nVar.Z1)) {
                                nVar.Z1 = z1Var;
                                lVar.e0(z1Var);
                            }
                            nVar.f4379b1.f28399f++;
                            a0 a0Var = nVar.f21004s1;
                            boolean z11 = a0Var.f20896e != 3;
                            a0Var.f20896e = 3;
                            a0Var.k.getClass();
                            a0Var.f20898g = n3.l0.S(SystemClock.elapsedRealtime());
                            if (z11 && (surface = nVar.I1) != null) {
                                Handler handler = (Handler) lVar.f19342d;
                                if (handler != null) {
                                    handler.post(new app.p001rive.core.b(lVar, surface, SystemClock.elapsedRealtime(), 3));
                                }
                                nVar.L1 = true;
                            }
                            nVar.k0(j6);
                        } catch (v3.i e4) {
                            nVar.f4377a1 = e4;
                            return;
                        }
                    }
                    break;
                }
                break;
            default:
                rt.g gVar = (rt.g) this.f20987i;
                if (this == gVar.N1 && gVar.f14511l0 != null) {
                    if (j6 == Long.MAX_VALUE) {
                        gVar.f14495a1 = true;
                    } else {
                        try {
                            gVar.q0(j6);
                            gVar.y0(gVar.J1);
                            gVar.f14499c1.f28399f++;
                            gVar.x0();
                            gVar.Y(j6);
                        } catch (mr.j e9) {
                            gVar.f14497b1 = e9;
                        }
                    }
                    break;
                }
                break;
        }
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        switch (this.f20985d) {
            case 0:
                if (message.what != 0) {
                    return false;
                }
                int i11 = message.arg1;
                int i12 = message.arg2;
                String str = n3.l0.f22358a;
                a((((long) i12) & 4294967295L) | ((((long) i11) & 4294967295L) << 32));
                return true;
            default:
                if (message.what != 0) {
                    return false;
                }
                int i13 = message.arg1;
                int i14 = message.arg2;
                int i15 = qt.x.f27318a;
                a((((long) i14) & 4294967295L) | ((((long) i13) & 4294967295L) << 32));
                return true;
        }
    }

    public m(n nVar, c4.n nVar2) {
        this.f20987i = nVar;
        Handler handlerR = n3.l0.r(this);
        this.f20986e = handlerR;
        nVar2.m(this, handlerR);
    }
}
