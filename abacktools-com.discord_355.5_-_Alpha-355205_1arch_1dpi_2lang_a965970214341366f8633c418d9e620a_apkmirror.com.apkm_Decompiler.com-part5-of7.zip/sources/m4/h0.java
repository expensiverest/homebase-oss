package m4;

import android.os.SystemClock;
import android.os.Trace;
import java.util.NoSuchElementException;
import k3.u0;
import k3.z1;

/* JADX INFO: loaded from: classes.dex */
public final class h0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k7.e f20958a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0 f20959b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final bl.h f20960c = new bl.h();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final n3.i0 f20961d = new n3.i0(0);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final n3.i0 f20962e = new n3.i0(0);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ds.g f20963f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final b0 f20964g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final g f20965h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public long f20966i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public long f20967j;
    public long k;
    public z1 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f20968m;

    public h0(k7.e eVar, a0 a0Var, b0 b0Var, g gVar) {
        this.f20958a = eVar;
        this.f20959b = a0Var;
        this.f20964g = b0Var;
        this.f20965h = gVar;
        ds.g gVar2 = new ds.g(3);
        int iHighestOneBit = Integer.bitCount(16) != 1 ? Integer.highestOneBit(15) << 1 : 16;
        gVar2.f9338e = 0;
        gVar2.f9339i = -1;
        gVar2.f9340v = 0;
        gVar2.f9342x = new long[iHighestOneBit];
        gVar2.f9341w = iHighestOneBit - 1;
        this.f20963f = gVar2;
        this.f20966i = -9223372036854775807L;
        this.l = z1.f19050d;
        this.f20967j = -9223372036854775807L;
        this.k = -9223372036854775807L;
    }

    public final void a(long j6, long j11) {
        final k7.e eVar = this.f20958a;
        e eVar2 = (e) eVar.f19327i;
        while (true) {
            ds.g gVar = this.f20963f;
            int i11 = gVar.f9340v;
            if (i11 == 0) {
                return;
            }
            if (i11 == 0) {
                throw new NoSuchElementException();
            }
            long j12 = ((long[]) gVar.f9342x)[gVar.f9338e];
            Long l = (Long) this.f20962e.f(j12);
            a0 a0Var = this.f20959b;
            if (l != null && l.longValue() != this.f20968m) {
                this.f20968m = l.longValue();
                a0Var.e(2);
            }
            g gVar2 = this.f20965h;
            gVar2.b(1000 * j12);
            long j13 = this.f20968m;
            long jA = gVar2.a();
            long j14 = gVar2.f20941h;
            a0 a0Var2 = this.f20959b;
            bl.h hVar = this.f20960c;
            int iA = a0Var2.a(j12, j6, j11, j13, false, false, jA, j14, hVar);
            if (iA != 5 && iA != 4) {
                this.f20964g.a(j12, hVar.f3773a);
            }
            if (iA == 0 || iA == 1) {
                this.f20967j = j12;
                boolean z11 = iA == 0;
                long jH = gVar.h();
                z1 z1Var = (z1) this.f20961d.f(jH);
                if (z1Var != null && !z1Var.equals(z1.f19050d) && !z1Var.equals(this.l)) {
                    this.l = z1Var;
                    k3.v vVar = new k3.v();
                    vVar.f18965v = z1Var.f19054a;
                    vVar.f18966w = z1Var.f19055b;
                    vVar.f18958o = u0.n("video/raw");
                    eVar.f19326e = new k3.w(vVar);
                    eVar2.f20923j.execute(new io.sentry.react.c(10, eVar, z1Var));
                }
                long jNanoTime = z11 ? System.nanoTime() : hVar.f3774b;
                boolean z12 = a0Var.f20896e != 3;
                a0Var.f20896e = 3;
                a0Var.k.getClass();
                a0Var.f20898g = n3.l0.S(SystemClock.elapsedRealtime());
                if (z12 && eVar2.f20919f != null) {
                    final int i12 = 0;
                    eVar2.f20923j.execute(new Runnable() { // from class: m4.d
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i12) {
                                case 0:
                                    ((e) eVar.f19327i).f20922i.onFirstFrameRendered();
                                    break;
                                default:
                                    ((e) eVar.f19327i).f20922i.a();
                                    break;
                            }
                        }
                    });
                }
                k3.w wVar = (k3.w) eVar.f19326e;
                eVar2.k.d(jH, jNanoTime, wVar == null ? new k3.w(new k3.v()) : wVar, null);
                j jVar = (j) eVar2.f20917d.remove();
                jVar.f20974c.P0(jVar.f20972a, jVar.f20973b, jNanoTime);
            } else if (iA == 2 || iA == 3) {
                this.f20967j = j12;
                gVar.h();
                final int i13 = 1;
                eVar2.f20923j.execute(new Runnable() { // from class: m4.d
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i13) {
                            case 0:
                                ((e) eVar.f19327i).f20922i.onFirstFrameRendered();
                                break;
                            default:
                                ((e) eVar.f19327i).f20922i.a();
                                break;
                        }
                    }
                });
                j jVar2 = (j) eVar2.f20917d.remove();
                n nVar = jVar2.f20974c;
                c4.n nVar2 = jVar2.f20972a;
                int i14 = jVar2.f20973b;
                Trace.beginSection("dropVideoBuffer");
                nVar2.j(i14);
                Trace.endSection();
                nVar.U0(0, 1);
            } else {
                if (iA != 4) {
                    if (iA != 5) {
                        throw new IllegalStateException(String.valueOf(iA));
                    }
                    return;
                }
                this.f20967j = j12;
            }
        }
    }
}
