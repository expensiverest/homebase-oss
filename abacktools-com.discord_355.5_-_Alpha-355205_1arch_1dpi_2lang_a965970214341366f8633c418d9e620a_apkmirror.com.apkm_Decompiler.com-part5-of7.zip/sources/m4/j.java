package m4;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ c4.n f20972a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f20973b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ n f20974c;

    public j(n nVar, c4.n nVar2, int i11, long j6) {
        this.f20974c = nVar;
        this.f20972a = nVar2;
        this.f20973b = i11;
    }
}
