package m4;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i0 implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20970d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ k7.l f20971e;

    public /* synthetic */ i0(k7.l lVar, long j6, int i11) {
        this.f20970d = 2;
        this.f20971e = lVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i11 = this.f20970d;
        k7.l lVar = this.f20971e;
        switch (i11) {
            case 0:
                v3.q qVar = (v3.q) lVar.f19343e;
                String str = n3.l0.f22358a;
                w3.e eVar = qVar.f32084d.V;
                eVar.W(eVar.V(), 1016, new w3.c(12));
                break;
            case 1:
                v3.q qVar2 = (v3.q) lVar.f19343e;
                String str2 = n3.l0.f22358a;
                w3.e eVar2 = qVar2.f32084d.V;
                eVar2.W(eVar2.V(), 1019, new w3.c(2));
                break;
            case 2:
                v3.q qVar3 = (v3.q) lVar.f19343e;
                String str3 = n3.l0.f22358a;
                w3.e eVar3 = qVar3.f32084d.V;
                eVar3.W(eVar3.S((f4.d0) eVar3.f33371v.f3160x), 1021, new w3.c(3));
                break;
            case 3:
                v3.q qVar4 = (v3.q) lVar.f19343e;
                String str4 = n3.l0.f22358a;
                w3.e eVar4 = qVar4.f32084d.V;
                eVar4.W(eVar4.V(), 1030, new w3.c(0));
                break;
            default:
                v3.q qVar5 = (v3.q) lVar.f19343e;
                String str5 = n3.l0.f22358a;
                w3.e eVar5 = qVar5.f32084d.V;
                eVar5.W(eVar5.V(), 1015, new w3.c(10));
                break;
        }
    }

    public /* synthetic */ i0(k7.l lVar, Object obj, int i11) {
        this.f20970d = i11;
        this.f20971e = lVar;
    }

    public /* synthetic */ i0(k7.l lVar, String str, long j6, long j11) {
        this.f20970d = 0;
        this.f20971e = lVar;
    }
}
