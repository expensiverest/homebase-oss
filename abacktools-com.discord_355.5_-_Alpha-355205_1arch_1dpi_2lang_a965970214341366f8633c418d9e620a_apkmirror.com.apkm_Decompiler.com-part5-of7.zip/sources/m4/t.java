package m4;

import k3.x1;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s f21038a = new s();

    public final void a() {
        try {
            ((t) Class.forName("androidx.media3.effect.SingleInputVideoGraph$Factory").getConstructor(x1.class).newInstance(this.f21038a)).a();
        } catch (Exception e4) {
            throw new IllegalStateException(e4);
        }
    }
}
