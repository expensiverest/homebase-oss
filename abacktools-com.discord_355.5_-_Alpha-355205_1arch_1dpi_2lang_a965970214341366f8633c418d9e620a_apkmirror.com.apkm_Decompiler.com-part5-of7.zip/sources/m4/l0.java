package m4;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends Exception {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k3.w f20984d;

    public l0(Exception exc, k3.w wVar) {
        super(exc);
        this.f20984d = wVar;
    }
}
