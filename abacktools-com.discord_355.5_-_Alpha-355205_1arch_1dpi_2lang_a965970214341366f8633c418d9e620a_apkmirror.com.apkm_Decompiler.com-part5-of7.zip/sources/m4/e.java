package m4;

import android.view.Surface;
import io.sentry.android.core.n0;
import java.util.ArrayDeque;
import java.util.List;
import java.util.concurrent.Executor;
import k3.z1;

/* JADX INFO: loaded from: classes.dex */
public final class e implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a0 f20914a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b0 f20915b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final h0 f20916c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayDeque f20917d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final g f20918e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Surface f20919f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public k3.w f20920g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f20921h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public k0 f20922i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Executor f20923j;
    public z k;

    public e(a0 a0Var, b0 b0Var, n3.e0 e0Var) {
        this.f20914a = a0Var;
        this.f20915b = b0Var;
        a0Var.k = e0Var;
        g gVar = new g(new n0(17, a0Var));
        this.f20918e = gVar;
        this.f20916c = new h0(new k7.e(this), a0Var, b0Var, gVar);
        this.f20917d = new ArrayDeque();
        this.f20920g = new k3.w(new k3.v());
        this.f20921h = -9223372036854775807L;
        this.f20922i = k0.f20975a;
        this.f20923j = new b(0);
        this.k = new c();
    }

    @Override // m4.m0
    public final void E(float f3) {
        this.f20914a.g(f3);
    }

    @Override // m4.m0
    public final Surface a() {
        Surface surface = this.f20919f;
        surface.getClass();
        return surface;
    }

    @Override // m4.m0
    public final void b() {
        this.f20915b.b();
        a0 a0Var = this.f20914a;
        a0Var.f20895d = false;
        a0Var.f20899h = -9223372036854775807L;
        g0 g0Var = a0Var.f20893b;
        g0Var.f20946d = false;
        d0 d0Var = g0Var.f20945c;
        if (d0Var != null) {
            d0Var.b();
        }
        g0Var.a();
    }

    @Override // m4.m0
    public final void c() {
        this.f20915b.b();
        this.f20914a.d();
    }

    @Override // m4.m0
    public final boolean d() {
        h0 h0Var = this.f20916c;
        long j6 = h0Var.k;
        return j6 != -9223372036854775807L && h0Var.f20967j == j6;
    }

    @Override // m4.m0
    public final void e(long j6) {
        throw new UnsupportedOperationException();
    }

    @Override // m4.m0
    public final void f(Surface surface, n3.y yVar) {
        this.f20919f = surface;
        this.f20914a.f(surface);
    }

    @Override // m4.m0
    public final void g() {
        h0 h0Var = this.f20916c;
        if (h0Var.f20966i == -9223372036854775807L) {
            h0Var.f20966i = Long.MIN_VALUE;
            h0Var.f20967j = Long.MIN_VALUE;
        }
        h0Var.k = h0Var.f20966i;
    }

    @Override // m4.m0
    public final void h(int i11) {
        g0 g0Var = this.f20914a.f20893b;
        if (g0Var.f20951i == i11) {
            return;
        }
        g0Var.f20951i = i11;
        g0Var.c(true);
    }

    @Override // m4.m0
    public final void i() {
        this.f20919f = null;
        this.f20914a.f(null);
    }

    @Override // m4.m0
    public final boolean isInitialized() {
        return true;
    }

    @Override // m4.m0
    public final boolean j(long j6, j jVar) {
        this.f20917d.add(jVar);
        h0 h0Var = this.f20916c;
        ds.g gVar = h0Var.f20963f;
        int i11 = gVar.f9340v;
        long[] jArr = (long[]) gVar.f9342x;
        if (i11 == jArr.length) {
            int length = jArr.length << 1;
            if (length < 0) {
                throw new IllegalStateException();
            }
            long[] jArr2 = new long[length];
            int length2 = jArr.length;
            int i12 = gVar.f9338e;
            int i13 = length2 - i12;
            System.arraycopy(jArr, i12, jArr2, 0, i13);
            System.arraycopy((long[]) gVar.f9342x, 0, jArr2, i13, i12);
            gVar.f9338e = 0;
            gVar.f9339i = gVar.f9340v - 1;
            gVar.f9342x = jArr2;
            gVar.f9341w = length - 1;
        }
        int i14 = (gVar.f9339i + 1) & gVar.f9341w;
        gVar.f9339i = i14;
        ((long[]) gVar.f9342x)[i14] = j6;
        gVar.f9340v++;
        h0Var.f20966i = j6;
        h0Var.k = -9223372036854775807L;
        this.f20923j.execute(new jk.m0(8, this));
        return true;
    }

    @Override // m4.m0
    public final void k(boolean z11) {
        if (z11) {
            a0 a0Var = this.f20914a;
            a0Var.f20893b.b();
            a0Var.f20897f = -9223372036854775807L;
            a0Var.f20896e = Math.min(a0Var.f20896e, 1);
            a0Var.f20899h = -9223372036854775807L;
            a0Var.f20902m = false;
        }
        this.f20915b.b();
        h0 h0Var = this.f20916c;
        n3.i0 i0Var = h0Var.f20961d;
        ds.g gVar = h0Var.f20963f;
        gVar.f9338e = 0;
        gVar.f9339i = -1;
        gVar.f9340v = 0;
        h0Var.f20966i = -9223372036854775807L;
        h0Var.f20967j = -9223372036854775807L;
        h0Var.k = -9223372036854775807L;
        n3.i0 i0Var2 = h0Var.f20962e;
        if (i0Var2.h() > 0) {
            oq.a.n(i0Var2.h() > 0);
            while (i0Var2.h() > 1) {
                i0Var2.e();
            }
            Object objE = i0Var2.e();
            objE.getClass();
            h0Var.f20968m = ((Long) objE).longValue();
        }
        if (i0Var.h() > 0) {
            oq.a.n(i0Var.h() > 0);
            while (i0Var.h() > 1) {
                i0Var.e();
            }
            Object objE2 = i0Var.e();
            objE2.getClass();
            i0Var.a(0L, (z1) objE2);
        }
        this.f20917d.clear();
    }

    @Override // m4.m0
    public final void l(List list) {
        throw new UnsupportedOperationException();
    }

    @Override // m4.m0
    public final boolean m(k3.w wVar) {
        return true;
    }

    @Override // m4.m0
    public final void n(long j6, long j11) throws l0 {
        try {
            this.f20916c.a(j6, j11);
        } catch (v3.i e4) {
            throw new l0(e4, this.f20920g);
        }
    }

    @Override // m4.m0
    public final void o(z zVar) {
        this.k = zVar;
    }

    @Override // m4.m0
    public final void p(boolean z11) {
        this.f20914a.c(z11);
    }

    @Override // m4.m0
    public final boolean q(boolean z11) {
        return this.f20914a.b(z11);
    }

    @Override // m4.m0
    public final void r() {
        throw new UnsupportedOperationException();
    }

    @Override // m4.m0
    public final void s(i iVar) {
        this.f20922i = iVar;
        this.f20923j = mx.r.f22087d;
    }

    @Override // m4.m0
    public final void t(k3.w wVar, long j6, int i11, List list) {
        oq.a.z(list.isEmpty());
        int i12 = wVar.f19019w;
        int i13 = wVar.f19020x;
        k3.w wVar2 = this.f20920g;
        int i14 = wVar2.f19019w;
        h0 h0Var = this.f20916c;
        if (i12 != i14 || i13 != wVar2.f19020x) {
            n3.i0 i0Var = h0Var.f20961d;
            long j11 = h0Var.f20966i;
            i0Var.a(j11 == -9223372036854775807L ? 0L : j11 + 1, new z1(i12, i13));
        }
        float f3 = wVar.B;
        if (f3 != this.f20920g.B) {
            g gVar = this.f20918e;
            gVar.f20939f = f3;
            gVar.f20934a.c();
            gVar.f20935b.c();
            gVar.f20936c = false;
            gVar.f20937d = -9223372036854775807L;
            gVar.f20938e = 0;
            gVar.c();
        }
        this.f20920g = wVar;
        if (j6 != this.f20921h) {
            if (h0Var.f20963f.f9340v == 0) {
                h0Var.f20959b.e(i11);
                h0Var.f20968m = j6;
            } else {
                n3.i0 i0Var2 = h0Var.f20962e;
                long j12 = h0Var.f20966i;
                i0Var2.a(j12 == -9223372036854775807L ? -4611686018427387904L : j12 + 1, Long.valueOf(j6));
            }
            this.f20921h = j6;
        }
    }

    @Override // m4.m0
    public final void u() {
        a0 a0Var = this.f20914a;
        if (a0Var.f20896e == 0) {
            a0Var.f20896e = 1;
        }
    }

    @Override // m4.m0
    public final void release() {
    }
}
