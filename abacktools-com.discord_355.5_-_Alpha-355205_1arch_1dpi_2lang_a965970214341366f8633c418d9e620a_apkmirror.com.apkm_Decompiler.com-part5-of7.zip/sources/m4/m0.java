package m4;

import android.view.Surface;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface m0 {
    void E(float f3);

    Surface a();

    void b();

    void c();

    boolean d();

    void e(long j6);

    void f(Surface surface, n3.y yVar);

    void g();

    void h(int i11);

    void i();

    boolean isInitialized();

    boolean j(long j6, j jVar);

    void k(boolean z11);

    void l(List list);

    boolean m(k3.w wVar);

    void n(long j6, long j11);

    void o(z zVar);

    void p(boolean z11);

    boolean q(boolean z11);

    void r();

    void release();

    void s(i iVar);

    void t(k3.w wVar, long j6, int i11, List list);

    void u();
}
