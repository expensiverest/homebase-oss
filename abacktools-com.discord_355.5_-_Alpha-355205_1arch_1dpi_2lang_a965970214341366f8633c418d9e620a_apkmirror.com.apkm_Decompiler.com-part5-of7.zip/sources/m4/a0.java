package m4;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.SystemClock;
import android.view.Choreographer;
import android.view.Surface;

/* JADX INFO: loaded from: classes.dex */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f20892a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g0 f20893b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f20894c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f20895d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f20898g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f20900i;
    public boolean l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f20902m;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f20896e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f20897f = -9223372036854775807L;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f20899h = -9223372036854775807L;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f20901j = 1.0f;
    public n3.e0 k = n3.e0.f22318a;

    public a0(Context context, n nVar, long j6) {
        this.f20892a = nVar;
        this.f20894c = j6;
        this.f20893b = new g0(context);
    }

    /* JADX WARN: Code duplicated, block: B:30:0x0077  */
    /* JADX WARN: Code duplicated, block: B:76:0x0139  */
    public final int a(long j6, long j11, long j12, long j13, boolean z11, boolean z12, long j14, long j15, bl.h hVar) {
        boolean z13;
        long j16;
        long j17;
        long j18;
        float f3;
        float f11;
        hVar.f3773a = -9223372036854775807L;
        hVar.f3774b = -9223372036854775807L;
        boolean z14 = this.f20895d;
        if (z14 && this.f20897f == -9223372036854775807L) {
            this.f20897f = j11;
        }
        long jS = (long) ((j6 - j11) / ((double) this.f20901j));
        if (z14) {
            this.k.getClass();
            jS -= n3.l0.S(SystemClock.elapsedRealtime()) - j12;
        }
        hVar.f3773a = jS;
        if (!z11 || z12) {
            if (this.l) {
                boolean z15 = false;
                if (this.f20899h == -9223372036854775807L || this.f20900i) {
                    int i11 = this.f20896e;
                    if (i11 != 0) {
                        if (i11 != 1) {
                            if (i11 != 2) {
                                if (i11 != 3) {
                                    throw new IllegalStateException();
                                }
                                this.k.getClass();
                                long jS2 = n3.l0.S(SystemClock.elapsedRealtime()) - this.f20898g;
                                if (this.f20895d) {
                                    long j19 = this.f20897f;
                                    if (j19 == -9223372036854775807L || j19 == j11 || jS >= -30000 || jS2 <= 100000) {
                                    }
                                }
                                z13 = false;
                            } else if (j11 < j13) {
                                z13 = false;
                            }
                        }
                        z13 = true;
                    } else {
                        z13 = this.f20895d;
                    }
                } else {
                    z13 = false;
                }
                if (z13) {
                    return 0;
                }
                if (!this.f20895d || j11 == this.f20897f) {
                    return 5;
                }
                this.k.getClass();
                long jNanoTime = System.nanoTime();
                g0 g0Var = this.f20893b;
                long j21 = (hVar.f3773a * 1000) + jNanoTime;
                long j22 = g0Var.f20954n;
                if (j6 != j22) {
                    g0Var.f20955o = g0Var.l;
                    g0Var.f20956p = g0Var.f20953m;
                    g0Var.f20957q = j22;
                    g0Var.f20952j = g0Var.k;
                }
                long j23 = g0Var.f20955o;
                if (j23 != -1) {
                    if (j14 != -9223372036854775807L) {
                        f3 = (j15 - j23) * j14;
                        f11 = g0Var.f20950h;
                    } else {
                        f3 = (j6 - g0Var.f20957q) * 1000;
                        f11 = g0Var.f20950h;
                    }
                    long j24 = g0Var.f20956p + ((long) (f3 / f11));
                    if (Math.abs(j21 - j24) <= 20000000) {
                        j21 = j24;
                    } else {
                        g0Var.b();
                    }
                }
                g0Var.l = j15;
                g0Var.f20953m = j21;
                g0Var.f20954n = j6;
                d0 d0Var = g0Var.f20945c;
                if (d0Var == null) {
                    j18 = jNanoTime;
                } else {
                    long j25 = d0Var.f20912i;
                    long j26 = g0Var.f20945c.f20913v;
                    if (j25 == -9223372036854775807L || j26 == -9223372036854775807L) {
                        j18 = jNanoTime;
                    } else {
                        long j27 = (((j21 - j25) / j26) * j26) + j25;
                        if (j21 <= j27) {
                            j16 = j27 - j26;
                        } else {
                            j27 += j26;
                            j16 = j27;
                        }
                        long j28 = j27 - j21;
                        long j29 = j21 - j16;
                        long jAbs = Math.abs(j28 - j29);
                        if (jAbs < j26 / 2) {
                            j17 = j16;
                            long j31 = j26 / 4;
                            j18 = jNanoTime;
                            if (jAbs < j31) {
                                long j32 = g0Var.f20952j;
                                if (j32 != 0) {
                                    g0Var.k = j32;
                                } else {
                                    if (j28 < j29) {
                                        j31 = -j31;
                                    }
                                    g0Var.k = j31;
                                }
                            } else {
                                g0Var.k = 0L;
                            }
                        } else {
                            j17 = j16;
                            j18 = jNanoTime;
                            g0Var.k = g0Var.f20952j;
                        }
                        if (j28 + g0Var.k >= j29) {
                            j27 = j17;
                        }
                        j21 = j27 - ((j26 * 80) / 100);
                    }
                }
                hVar.f3774b = j21;
                long j33 = (j21 - j18) / 1000;
                hVar.f3773a = j33;
                boolean z16 = (this.f20899h == -9223372036854775807L || this.f20900i) ? false : true;
                if (this.f20892a.R0(j33, j11, z12, z16)) {
                    return 4;
                }
                long j34 = hVar.f3773a;
                if (j34 < -30000 && !z12) {
                    z15 = true;
                }
                if (z15) {
                    return z16 ? 3 : 2;
                }
                return j34 > 50000 ? 5 : 1;
            }
            if (this.f20892a.R0(jS, j11, z12, true)) {
                return 4;
            }
            if (!this.f20895d || hVar.f3773a >= 30000) {
                this.f20902m = true;
                return 5;
            }
        }
        return 3;
    }

    public final boolean b(boolean z11) {
        if (z11 && (this.f20896e == 3 || (this.f20902m && !this.l))) {
            this.f20899h = -9223372036854775807L;
            return true;
        }
        if (this.f20899h == -9223372036854775807L) {
            return false;
        }
        this.k.getClass();
        if (SystemClock.elapsedRealtime() < this.f20899h) {
            return true;
        }
        this.f20899h = -9223372036854775807L;
        return false;
    }

    public final void c(boolean z11) {
        long jElapsedRealtime;
        this.f20900i = z11;
        long j6 = this.f20894c;
        if (j6 > 0) {
            this.k.getClass();
            jElapsedRealtime = SystemClock.elapsedRealtime() + j6;
        } else {
            jElapsedRealtime = -9223372036854775807L;
        }
        this.f20899h = jElapsedRealtime;
    }

    public final void d() {
        this.f20895d = true;
        this.k.getClass();
        this.f20898g = n3.l0.S(SystemClock.elapsedRealtime());
        g0 g0Var = this.f20893b;
        g0Var.f20946d = true;
        g0Var.b();
        if (!g0Var.f20944b) {
            DisplayManager displayManager = (DisplayManager) g0Var.f20943a.getSystemService("display");
            d0 f0Var = null;
            if (displayManager != null) {
                try {
                    Choreographer choreographer = Choreographer.getInstance();
                    f0Var = Build.VERSION.SDK_INT >= 33 ? new f0(choreographer, displayManager) : new e0(choreographer, displayManager);
                } catch (RuntimeException e4) {
                    n3.b.m("VideoFrameReleaseHelper", "Vsync sampling disabled due to platform error", e4);
                }
            }
            g0Var.f20945c = f0Var;
            g0Var.f20944b = true;
        }
        d0 d0Var = g0Var.f20945c;
        if (d0Var != null) {
            d0Var.a();
        }
        g0Var.c(false);
    }

    public final void e(int i11) {
        if (i11 == 0) {
            this.f20896e = 1;
        } else if (i11 == 1) {
            this.f20896e = 0;
        } else {
            if (i11 != 2) {
                throw new IllegalStateException();
            }
            this.f20896e = Math.min(this.f20896e, 2);
        }
        this.f20893b.b();
    }

    public final void f(Surface surface) {
        this.l = surface != null;
        this.f20902m = false;
        g0 g0Var = this.f20893b;
        if (g0Var.f20947e != surface) {
            g0Var.a();
            g0Var.f20947e = surface;
            g0Var.c(true);
        }
        this.f20896e = Math.min(this.f20896e, 1);
    }

    public final void g(float f3) {
        oq.a.n(f3 > 0.0f);
        if (f3 == this.f20901j) {
            return;
        }
        this.f20901j = f3;
        g0 g0Var = this.f20893b;
        g0Var.f20950h = f3;
        g0Var.c(false);
    }
}
