package m4;

import android.content.Context;
import android.os.Build;
import android.os.Looper;
import android.os.Trace;
import android.util.Pair;
import android.view.Surface;
import hx.w1;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class r implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public hx.m0 f21031a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public k3.w f21032b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f21033c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f21034d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21035e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Executor f21036f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ v f21037g;

    public r(v vVar, Context context) {
        this.f21037g = vVar;
        n3.l0.O(context);
        hx.k0 k0Var = hx.m0.f14841e;
        this.f21031a = w1.f14911w;
        this.f21034d = -9223372036854775807L;
        this.f21036f = v.f21039q;
    }

    @Override // m4.m0
    public final void E(float f3) {
        v vVar = this.f21037g;
        vVar.f21048i.c(f3);
        vVar.f21044e.E(f3);
    }

    @Override // m4.m0
    public final Surface a() {
        oq.a.z(false);
        throw null;
    }

    @Override // m4.m0
    public final void b() {
        v vVar = this.f21037g;
        if (vVar.f21043d) {
            vVar.f21044e.b();
        }
    }

    @Override // m4.m0
    public final void c() {
        v vVar = this.f21037g;
        if (vVar.f21043d) {
            vVar.f21044e.c();
        }
    }

    @Override // m4.m0
    public final boolean d() {
        return false;
    }

    @Override // m4.m0
    public final void e(long j6) {
        this.f21033c = j6;
    }

    @Override // m4.m0
    public final void f(Surface surface, n3.y yVar) {
        v vVar = this.f21037g;
        Pair pair = vVar.l;
        if (pair != null && ((Surface) pair.first).equals(surface) && ((n3.y) vVar.l.second).equals(yVar)) {
            return;
        }
        vVar.l = Pair.create(surface, yVar);
        int i11 = yVar.f22414a;
    }

    @Override // m4.m0
    public final void g() {
        long j6 = this.f21034d;
        v vVar = this.f21037g;
        if (vVar.f21052o >= j6) {
            vVar.f21044e.g();
        }
    }

    @Override // m4.m0
    public final void h(int i11) {
        this.f21037g.f21044e.h(i11);
    }

    @Override // m4.m0
    public final void i() {
        v vVar = this.f21037g;
        vVar.getClass();
        int i11 = n3.y.f22413c.f22414a;
        vVar.l = null;
    }

    @Override // m4.m0
    public final boolean isInitialized() {
        return false;
    }

    @Override // m4.m0
    public final boolean j(long j6, j jVar) {
        int i11;
        oq.a.z(false);
        long j11 = j6 + this.f21033c;
        v vVar = this.f21037g;
        b0 b0Var = vVar.f21048i;
        long j12 = b0Var.f20904a;
        long j13 = j12 == -9223372036854775807L ? -9223372036854775807L : (long) (((j11 - j12) * b0Var.f20906c) + b0Var.f20905b);
        if (j13 != -9223372036854775807L) {
            long j14 = vVar.f21047h;
            if (j14 != -9223372036854775807L && j13 < j14 && (i11 = this.f21035e) < 2) {
                this.f21035e = i11 + 1;
                n nVar = jVar.f20974c;
                c4.n nVar2 = jVar.f20972a;
                int i12 = jVar.f20973b;
                Trace.beginSection("dropVideoBuffer");
                nVar2.j(i12);
                Trace.endSection();
                nVar.U0(0, 1);
                return true;
            }
        }
        int i13 = vVar.f21053p;
        if (i13 == -1 || i13 != 0) {
            return false;
        }
        throw null;
    }

    @Override // m4.m0
    public final void k(boolean z11) {
        this.f21034d = -9223372036854775807L;
        v vVar = this.f21037g;
        e eVar = vVar.f21044e;
        if (vVar.f21051n == 1) {
            vVar.f21050m++;
            eVar.k(z11);
            while (vVar.f21049j.h() > 1) {
                vVar.f21049j.e();
            }
            if (vVar.f21049j.h() == 1) {
                ((u) vVar.f21049j.e()).getClass();
                throw null;
            }
            vVar.f21052o = -9223372036854775807L;
            n3.g0 g0Var = vVar.k;
            g0Var.getClass();
            g0Var.e(new jk.m0(9, vVar));
        }
    }

    @Override // m4.m0
    public final void l(List list) {
        if (this.f21031a.equals(list)) {
            return;
        }
        this.f21031a = hx.m0.q(list);
        k3.w wVar = this.f21032b;
        if (wVar == null) {
            return;
        }
        k3.v vVarA = wVar.a();
        k3.m mVar = wVar.H;
        if (mVar == null || !mVar.d()) {
            mVar = k3.m.f18687h;
        }
        vVarA.G = mVar;
        vVarA.a();
        throw null;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x003f  */
    /* JADX WARN: Code duplicated, block: B:28:0x0042 A[Catch: m -> 0x0036, TryCatch #0 {m -> 0x0036, blocks: (B:14:0x0026, B:17:0x002e, B:25:0x003c, B:28:0x0042, B:30:0x0046, B:37:0x0059, B:40:0x0060, B:45:0x0082, B:35:0x0051), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:30:0x0046 A[Catch: m -> 0x0036, TryCatch #0 {m -> 0x0036, blocks: (B:14:0x0026, B:17:0x002e, B:25:0x003c, B:28:0x0042, B:30:0x0046, B:37:0x0059, B:40:0x0060, B:45:0x0082, B:35:0x0051), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:33:0x004d  */
    /* JADX WARN: Code duplicated, block: B:34:0x004f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x0051 A[Catch: m -> 0x0036, TryCatch #0 {m -> 0x0036, blocks: (B:14:0x0026, B:17:0x002e, B:25:0x003c, B:28:0x0042, B:30:0x0046, B:37:0x0059, B:40:0x0060, B:45:0x0082, B:35:0x0051), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:37:0x0059 A[Catch: m -> 0x0036, TryCatch #0 {m -> 0x0036, blocks: (B:14:0x0026, B:17:0x002e, B:25:0x003c, B:28:0x0042, B:30:0x0046, B:37:0x0059, B:40:0x0060, B:45:0x0082, B:35:0x0051), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:41:0x007b  */
    /* JADX WARN: Code duplicated, block: B:43:0x007e  */
    /* JADX WARN: Code duplicated, block: B:45:0x0082 A[Catch: m -> 0x0036, TRY_LEAVE, TryCatch #0 {m -> 0x0036, blocks: (B:14:0x0026, B:17:0x002e, B:25:0x003c, B:28:0x0042, B:30:0x0046, B:37:0x0059, B:40:0x0060, B:45:0x0082, B:35:0x0051), top: B:50:0x0026 }] */
    @Override // m4.m0
    public final boolean m(k3.w wVar) throws l0 {
        v vVar = this.f21037g;
        boolean zG = true;
        oq.a.z(vVar.f21051n == 0);
        k3.m mVar = wVar.H;
        if (mVar == null || !mVar.d()) {
            mVar = k3.m.f18687h;
        }
        int i11 = mVar.f18694c;
        if (i11 == 7) {
            try {
                int i12 = Build.VERSION.SDK_INT;
                if (i12 >= 34) {
                    if (i11 == 6) {
                        if (Build.VERSION.SDK_INT >= 33 || !n3.e.g("EGL_EXT_gl_colorspace_bt2020_pq")) {
                            zG = false;
                        }
                    } else if (i11 == 7) {
                        zG = n3.e.g("EGL_EXT_gl_colorspace_bt2020_hlg");
                    }
                    if (zG && Build.VERSION.SDK_INT >= 29) {
                        Locale locale = Locale.US;
                        n3.b.l("PlaybackVidGraphWrapper", "Color transfer " + i11 + " is not supported. Falling back to OpenGl tone mapping.");
                        k3.m mVar2 = k3.m.f18687h;
                    } else if (i11 != 2 || i11 == 10) {
                        k3.m mVar3 = k3.m.f18687h;
                    }
                } else {
                    if (!(i12 >= 33 && n3.e.g("EGL_EXT_gl_colorspace_bt2020_pq"))) {
                        if (i11 == 6) {
                            if (Build.VERSION.SDK_INT >= 33) {
                                zG = false;
                            } else {
                                zG = false;
                            }
                        } else if (i11 == 7) {
                            zG = n3.e.g("EGL_EXT_gl_colorspace_bt2020_hlg");
                        }
                        if (zG) {
                            if (i11 != 2) {
                                k3.m mVar4 = k3.m.f18687h;
                            } else {
                                k3.m mVar5 = k3.m.f18687h;
                            }
                        } else if (i11 != 2) {
                            k3.m mVar6 = k3.m.f18687h;
                        } else {
                            k3.m mVar7 = k3.m.f18687h;
                        }
                    }
                }
            } catch (n3.m e4) {
                throw new l0(e4, wVar);
            }
        } else {
            if (i11 == 6) {
                if (Build.VERSION.SDK_INT >= 33) {
                    zG = false;
                } else {
                    zG = false;
                }
            } else if (i11 == 7) {
                zG = n3.e.g("EGL_EXT_gl_colorspace_bt2020_hlg");
            }
            if (zG) {
                if (i11 != 2) {
                    k3.m mVar8 = k3.m.f18687h;
                } else {
                    k3.m mVar9 = k3.m.f18687h;
                }
            } else if (i11 != 2) {
                k3.m mVar10 = k3.m.f18687h;
            } else {
                k3.m mVar11 = k3.m.f18687h;
            }
        }
        n3.e0 e0Var = vVar.f21045f;
        Looper looperMyLooper = Looper.myLooper();
        looperMyLooper.getClass();
        vVar.k = e0Var.a(looperMyLooper, null);
        vVar.f21041b.a();
        throw null;
    }

    @Override // m4.m0
    public final void n(long j6, long j11) throws l0 {
        this.f21037g.f21044e.n(j6 + this.f21033c, j11);
    }

    @Override // m4.m0
    public final void o(z zVar) {
        this.f21037g.f21044e.k = zVar;
    }

    @Override // m4.m0
    public final void p(boolean z11) {
        v vVar = this.f21037g;
        if (vVar.f21043d) {
            vVar.f21044e.p(z11);
        }
    }

    @Override // m4.m0
    public final boolean q(boolean z11) {
        return this.f21037g.f21044e.f20914a.b(false);
    }

    @Override // m4.m0
    public final void release() {
        v vVar = this.f21037g;
        if (vVar.f21051n == 2) {
            return;
        }
        n3.g0 g0Var = vVar.k;
        if (g0Var != null) {
            g0Var.f();
        }
        vVar.l = null;
        vVar.f21051n = 2;
    }

    @Override // m4.m0
    public final void s(i iVar) {
        this.f21036f = mx.r.f22087d;
    }

    @Override // m4.m0
    public final void t(k3.w wVar, long j6, int i11, List list) {
        oq.a.z(false);
        this.f21031a = hx.m0.q(list);
        this.f21032b = wVar;
        k3.v vVarA = wVar.a();
        k3.m mVar = wVar.H;
        if (mVar == null || !mVar.d()) {
            mVar = k3.m.f18687h;
        }
        vVarA.G = mVar;
        vVarA.a();
        throw null;
    }

    @Override // m4.m0
    public final void u() {
        v vVar = this.f21037g;
        if (vVar.f21049j.h() == 0) {
            vVar.f21044e.u();
            return;
        }
        n3.i0 i0Var = new n3.i0(0);
        if (vVar.f21049j.h() <= 0) {
            vVar.f21049j = i0Var;
        } else {
            ((u) vVar.f21049j.e()).getClass();
            throw null;
        }
    }

    @Override // m4.m0
    public final void r() {
    }
}
