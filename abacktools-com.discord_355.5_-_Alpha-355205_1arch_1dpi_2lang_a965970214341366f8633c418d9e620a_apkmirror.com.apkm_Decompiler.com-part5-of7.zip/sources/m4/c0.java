package m4;

import android.view.Surface;

/* JADX INFO: loaded from: classes.dex */
public abstract class c0 {
    public static void a(Surface surface, float f3) {
        try {
            surface.setFrameRate(f3, f3 == 0.0f ? 0 : 1);
        } catch (IllegalStateException e4) {
            n3.b.d("VideoFrameReleaseHelper", "Failed to call Surface.setFrameRate", e4);
        }
    }
}
