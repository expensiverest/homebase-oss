package m4;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final byte[] f20891a = {-75, 0, 60, 0, 1, 4};

    public static int a(ByteBuffer byteBuffer, int i11, int i12) {
        int i13 = 0;
        while (i11 < i12) {
            int i14 = byteBuffer.get(i11) & 255;
            if (i13 >= 2 && i14 == 1) {
                return i11 - 2;
            }
            i13 = i14 == 0 ? i13 + 1 : 0;
            i11++;
        }
        return i12;
    }

    public static void b(ByteBuffer byteBuffer, boolean z11) {
        for (o3.p pVar : o3.n.r(byteBuffer.asReadOnlyBuffer())) {
            int i11 = pVar.f24090a;
            ByteBuffer byteBuffer2 = pVar.f24091b;
            if (i11 == 5) {
                try {
                    oq.a.n(i11 == 5);
                    ByteBuffer byteBufferAsReadOnlyBuffer = byteBuffer2.asReadOnlyBuffer();
                    if (o3.n.h(byteBufferAsReadOnlyBuffer) == 4) {
                        if (z11 && byteBufferAsReadOnlyBuffer.remaining() >= 6) {
                            int iPosition = byteBufferAsReadOnlyBuffer.position();
                            for (int i12 = 0; i12 < 6; i12++) {
                                if (byteBufferAsReadOnlyBuffer.get(iPosition + i12) == f20891a[i12]) {
                                }
                            }
                        }
                        byteBuffer.put(byteBuffer2.position(), (byte) 31);
                        break;
                    }
                } catch (BufferUnderflowException unused) {
                }
            }
        }
    }
}
