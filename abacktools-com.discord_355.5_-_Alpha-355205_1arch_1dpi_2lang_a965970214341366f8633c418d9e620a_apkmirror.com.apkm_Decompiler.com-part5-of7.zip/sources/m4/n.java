package m4;

import android.content.Context;
import android.graphics.Point;
import android.media.MediaCodecInfo;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Pair;
import android.util.SparseArray;
import android.view.Surface;
import app.p001rive.runtime.kotlin.renderers.RendererMetrics;
import com.appsflyer.attribution.RequestError;
import com.discord.age_assurance.DigitalCredentialModule;
import hx.w1;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import io.sentry.android.core.n0;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import k3.p0;
import k3.u0;
import k3.y1;
import k3.z1;
import v3.d1;
import v3.e1;

/* JADX INFO: loaded from: classes.dex */
public final class n extends c4.v {

    /* JADX INFO: renamed from: i2, reason: collision with root package name */
    public static final int[] f20988i2 = {1920, 1600, 1440, 1280, 960, 854, 640, 540, 480};

    /* JADX INFO: renamed from: j2, reason: collision with root package name */
    public static boolean f20989j2;

    /* JADX INFO: renamed from: k2, reason: collision with root package name */
    public static boolean f20990k2;
    public boolean A1;
    public boolean B1;
    public boolean C1;
    public boolean D1;
    public m0 E1;
    public boolean F1;
    public int G1;
    public List H1;
    public Surface I1;
    public p J1;
    public n3.y K1;
    public boolean L1;
    public int M1;
    public int N1;
    public long O1;
    public int P1;
    public int Q1;
    public int R1;
    public e1 S1;
    public long T1;
    public boolean U1;
    public long V1;
    public int W1;
    public long X1;
    public z1 Y1;
    public z1 Z1;

    /* JADX INFO: renamed from: a2, reason: collision with root package name */
    public int f20991a2;

    /* JADX INFO: renamed from: b2, reason: collision with root package name */
    public boolean f20992b2;

    /* JADX INFO: renamed from: c2, reason: collision with root package name */
    public int f20993c2;

    /* JADX INFO: renamed from: d2, reason: collision with root package name */
    public m f20994d2;

    /* JADX INFO: renamed from: e2, reason: collision with root package name */
    public z f20995e2;

    /* JADX INFO: renamed from: f2, reason: collision with root package name */
    public long f20996f2;

    /* JADX INFO: renamed from: g2, reason: collision with root package name */
    public boolean f20997g2;

    /* JADX INFO: renamed from: h2, reason: collision with root package name */
    public int f20998h2;

    /* JADX INFO: renamed from: n1, reason: collision with root package name */
    public final Context f20999n1;

    /* JADX INFO: renamed from: o1, reason: collision with root package name */
    public final boolean f21000o1;

    /* JADX INFO: renamed from: p1, reason: collision with root package name */
    public final k7.l f21001p1;

    /* JADX INFO: renamed from: q1, reason: collision with root package name */
    public final int f21002q1;

    /* JADX INFO: renamed from: r1, reason: collision with root package name */
    public final boolean f21003r1;

    /* JADX INFO: renamed from: s1, reason: collision with root package name */
    public final a0 f21004s1;

    /* JADX INFO: renamed from: t1, reason: collision with root package name */
    public final bl.h f21005t1;

    /* JADX INFO: renamed from: u1, reason: collision with root package name */
    public final g f21006u1;

    /* JADX INFO: renamed from: v1, reason: collision with root package name */
    public final k7.c f21007v1;

    /* JADX INFO: renamed from: w1, reason: collision with root package name */
    public final long f21008w1;

    /* JADX INFO: renamed from: x1, reason: collision with root package name */
    public final b0 f21009x1;

    /* JADX INFO: renamed from: y1, reason: collision with root package name */
    public final PriorityQueue f21010y1;

    /* JADX INFO: renamed from: z1, reason: collision with root package name */
    public a50.i f21011z1;

    /* JADX WARN: Illegal instructions before constructor call */
    public n(l lVar) {
        Context context = lVar.f20976a;
        super(context.getApplicationContext(), 2, lVar.f20978c, lVar.f20980e);
        Context applicationContext = context.getApplicationContext();
        this.f20999n1 = applicationContext;
        this.f21002q1 = lVar.f20983h;
        this.E1 = null;
        Handler handler = lVar.f20981f;
        v3.q qVar = lVar.f20982g;
        k7.l lVar2 = new k7.l();
        if (qVar != null) {
            handler.getClass();
        } else {
            handler = null;
        }
        lVar2.f19342d = handler;
        lVar2.f19343e = qVar;
        this.f21001p1 = lVar2;
        this.f21000o1 = this.E1 == null;
        this.f21004s1 = new a0(applicationContext, this, lVar.f20979d);
        this.f21005t1 = new bl.h();
        this.f21006u1 = new g(new n0(18, this));
        HashSet hashSet = p0.f18769a;
        this.f21003r1 = "NVIDIA".equals(Build.MANUFACTURER);
        this.K1 = n3.y.f22413c;
        this.M1 = 1;
        this.N1 = 0;
        this.Y1 = z1.f19050d;
        this.f20993c2 = 0;
        this.Z1 = null;
        this.f20991a2 = -1000;
        this.f20996f2 = -9223372036854775807L;
        this.f21007v1 = new k7.c(21);
        this.f21010y1 = new PriorityQueue();
        this.f21008w1 = -15000L;
        this.f21009x1 = new b0();
        this.S1 = null;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0126  */
    /* JADX WARN: Code duplicated, block: B:102:0x0129  */
    /* JADX WARN: Code duplicated, block: B:105:0x0132  */
    /* JADX WARN: Code duplicated, block: B:106:0x0136  */
    /* JADX WARN: Code duplicated, block: B:109:0x013f  */
    /* JADX WARN: Code duplicated, block: B:110:0x0143  */
    /* JADX WARN: Code duplicated, block: B:113:0x014c  */
    /* JADX WARN: Code duplicated, block: B:114:0x0150  */
    /* JADX WARN: Code duplicated, block: B:117:0x0159  */
    /* JADX WARN: Code duplicated, block: B:118:0x015d  */
    /* JADX WARN: Code duplicated, block: B:121:0x0166  */
    /* JADX WARN: Code duplicated, block: B:122:0x016a  */
    /* JADX WARN: Code duplicated, block: B:125:0x0173  */
    /* JADX WARN: Code duplicated, block: B:126:0x0177  */
    /* JADX WARN: Code duplicated, block: B:129:0x0180  */
    /* JADX WARN: Code duplicated, block: B:130:0x0184  */
    /* JADX WARN: Code duplicated, block: B:133:0x018d  */
    /* JADX WARN: Code duplicated, block: B:134:0x0191  */
    /* JADX WARN: Code duplicated, block: B:137:0x019a  */
    /* JADX WARN: Code duplicated, block: B:138:0x019e  */
    /* JADX WARN: Code duplicated, block: B:141:0x01a8  */
    /* JADX WARN: Code duplicated, block: B:142:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:145:0x01b6  */
    /* JADX WARN: Code duplicated, block: B:146:0x01ba  */
    /* JADX WARN: Code duplicated, block: B:149:0x01c4  */
    /* JADX WARN: Code duplicated, block: B:150:0x01c8  */
    /* JADX WARN: Code duplicated, block: B:153:0x01d2  */
    /* JADX WARN: Code duplicated, block: B:154:0x01d6  */
    /* JADX WARN: Code duplicated, block: B:157:0x01e0  */
    /* JADX WARN: Code duplicated, block: B:158:0x01e4  */
    /* JADX WARN: Code duplicated, block: B:161:0x01ee  */
    /* JADX WARN: Code duplicated, block: B:162:0x01f2  */
    /* JADX WARN: Code duplicated, block: B:165:0x01fc  */
    /* JADX WARN: Code duplicated, block: B:166:0x0200  */
    /* JADX WARN: Code duplicated, block: B:169:0x020a  */
    /* JADX WARN: Code duplicated, block: B:170:0x020e  */
    /* JADX WARN: Code duplicated, block: B:173:0x0218  */
    /* JADX WARN: Code duplicated, block: B:174:0x021c  */
    /* JADX WARN: Code duplicated, block: B:177:0x0226  */
    /* JADX WARN: Code duplicated, block: B:178:0x022a  */
    /* JADX WARN: Code duplicated, block: B:181:0x0234  */
    /* JADX WARN: Code duplicated, block: B:182:0x0238  */
    /* JADX WARN: Code duplicated, block: B:185:0x0242  */
    /* JADX WARN: Code duplicated, block: B:186:0x0246  */
    /* JADX WARN: Code duplicated, block: B:189:0x0250  */
    /* JADX WARN: Code duplicated, block: B:190:0x0254  */
    /* JADX WARN: Code duplicated, block: B:193:0x025e  */
    /* JADX WARN: Code duplicated, block: B:194:0x0262  */
    /* JADX WARN: Code duplicated, block: B:197:0x026c  */
    /* JADX WARN: Code duplicated, block: B:198:0x0270  */
    /* JADX WARN: Code duplicated, block: B:201:0x027a  */
    /* JADX WARN: Code duplicated, block: B:202:0x027e  */
    /* JADX WARN: Code duplicated, block: B:205:0x0288  */
    /* JADX WARN: Code duplicated, block: B:206:0x028c  */
    /* JADX WARN: Code duplicated, block: B:209:0x0296  */
    /* JADX WARN: Code duplicated, block: B:210:0x029a  */
    /* JADX WARN: Code duplicated, block: B:213:0x02a4  */
    /* JADX WARN: Code duplicated, block: B:214:0x02a8  */
    /* JADX WARN: Code duplicated, block: B:217:0x02b2  */
    /* JADX WARN: Code duplicated, block: B:218:0x02b6  */
    /* JADX WARN: Code duplicated, block: B:221:0x02c0  */
    /* JADX WARN: Code duplicated, block: B:222:0x02c4  */
    /* JADX WARN: Code duplicated, block: B:225:0x02ce  */
    /* JADX WARN: Code duplicated, block: B:226:0x02d2  */
    /* JADX WARN: Code duplicated, block: B:229:0x02dc  */
    /* JADX WARN: Code duplicated, block: B:230:0x02e0  */
    /* JADX WARN: Code duplicated, block: B:233:0x02ea  */
    /* JADX WARN: Code duplicated, block: B:234:0x02ee  */
    /* JADX WARN: Code duplicated, block: B:237:0x02f8  */
    /* JADX WARN: Code duplicated, block: B:238:0x02fc  */
    /* JADX WARN: Code duplicated, block: B:241:0x0306  */
    /* JADX WARN: Code duplicated, block: B:242:0x030a  */
    /* JADX WARN: Code duplicated, block: B:245:0x0314  */
    /* JADX WARN: Code duplicated, block: B:246:0x0318  */
    /* JADX WARN: Code duplicated, block: B:249:0x0322  */
    /* JADX WARN: Code duplicated, block: B:250:0x0326  */
    /* JADX WARN: Code duplicated, block: B:253:0x0330  */
    /* JADX WARN: Code duplicated, block: B:254:0x0334  */
    /* JADX WARN: Code duplicated, block: B:257:0x033e  */
    /* JADX WARN: Code duplicated, block: B:258:0x0342  */
    /* JADX WARN: Code duplicated, block: B:261:0x034c  */
    /* JADX WARN: Code duplicated, block: B:262:0x0350  */
    /* JADX WARN: Code duplicated, block: B:265:0x035a  */
    /* JADX WARN: Code duplicated, block: B:266:0x035e  */
    /* JADX WARN: Code duplicated, block: B:269:0x0368  */
    /* JADX WARN: Code duplicated, block: B:270:0x036c  */
    /* JADX WARN: Code duplicated, block: B:273:0x0376  */
    /* JADX WARN: Code duplicated, block: B:274:0x037a  */
    /* JADX WARN: Code duplicated, block: B:277:0x0384  */
    /* JADX WARN: Code duplicated, block: B:278:0x0388  */
    /* JADX WARN: Code duplicated, block: B:281:0x0392  */
    /* JADX WARN: Code duplicated, block: B:282:0x0396  */
    /* JADX WARN: Code duplicated, block: B:285:0x03a0  */
    /* JADX WARN: Code duplicated, block: B:286:0x03a4  */
    /* JADX WARN: Code duplicated, block: B:289:0x03ae  */
    /* JADX WARN: Code duplicated, block: B:290:0x03b2  */
    /* JADX WARN: Code duplicated, block: B:293:0x03bc  */
    /* JADX WARN: Code duplicated, block: B:294:0x03c0  */
    /* JADX WARN: Code duplicated, block: B:297:0x03ca  */
    /* JADX WARN: Code duplicated, block: B:298:0x03ce  */
    /* JADX WARN: Code duplicated, block: B:301:0x03d8  */
    /* JADX WARN: Code duplicated, block: B:302:0x03dc  */
    /* JADX WARN: Code duplicated, block: B:305:0x03e6  */
    /* JADX WARN: Code duplicated, block: B:306:0x03ea  */
    /* JADX WARN: Code duplicated, block: B:309:0x03f4  */
    /* JADX WARN: Code duplicated, block: B:310:0x03f8  */
    /* JADX WARN: Code duplicated, block: B:313:0x0402  */
    /* JADX WARN: Code duplicated, block: B:314:0x0406  */
    /* JADX WARN: Code duplicated, block: B:317:0x0410  */
    /* JADX WARN: Code duplicated, block: B:318:0x0414  */
    /* JADX WARN: Code duplicated, block: B:321:0x041e  */
    /* JADX WARN: Code duplicated, block: B:322:0x0422  */
    /* JADX WARN: Code duplicated, block: B:325:0x042c  */
    /* JADX WARN: Code duplicated, block: B:326:0x0430  */
    /* JADX WARN: Code duplicated, block: B:329:0x043a  */
    /* JADX WARN: Code duplicated, block: B:330:0x043e  */
    /* JADX WARN: Code duplicated, block: B:333:0x0448  */
    /* JADX WARN: Code duplicated, block: B:334:0x044c  */
    /* JADX WARN: Code duplicated, block: B:337:0x0456  */
    /* JADX WARN: Code duplicated, block: B:338:0x045a  */
    /* JADX WARN: Code duplicated, block: B:341:0x0464  */
    /* JADX WARN: Code duplicated, block: B:342:0x0468  */
    /* JADX WARN: Code duplicated, block: B:345:0x0472  */
    /* JADX WARN: Code duplicated, block: B:346:0x0476  */
    /* JADX WARN: Code duplicated, block: B:349:0x0480  */
    /* JADX WARN: Code duplicated, block: B:350:0x0484  */
    /* JADX WARN: Code duplicated, block: B:353:0x048e  */
    /* JADX WARN: Code duplicated, block: B:354:0x0492  */
    /* JADX WARN: Code duplicated, block: B:357:0x049c  */
    /* JADX WARN: Code duplicated, block: B:358:0x04a0  */
    /* JADX WARN: Code duplicated, block: B:361:0x04aa  */
    /* JADX WARN: Code duplicated, block: B:362:0x04ae  */
    /* JADX WARN: Code duplicated, block: B:365:0x04b8  */
    /* JADX WARN: Code duplicated, block: B:366:0x04bc  */
    /* JADX WARN: Code duplicated, block: B:369:0x04c6  */
    /* JADX WARN: Code duplicated, block: B:370:0x04ca  */
    /* JADX WARN: Code duplicated, block: B:373:0x04d4  */
    /* JADX WARN: Code duplicated, block: B:374:0x04d8  */
    /* JADX WARN: Code duplicated, block: B:377:0x04e2  */
    /* JADX WARN: Code duplicated, block: B:378:0x04e6  */
    /* JADX WARN: Code duplicated, block: B:381:0x04f0  */
    /* JADX WARN: Code duplicated, block: B:382:0x04f4  */
    /* JADX WARN: Code duplicated, block: B:385:0x04fe  */
    /* JADX WARN: Code duplicated, block: B:386:0x0502  */
    /* JADX WARN: Code duplicated, block: B:389:0x050c  */
    /* JADX WARN: Code duplicated, block: B:390:0x0510  */
    /* JADX WARN: Code duplicated, block: B:393:0x051a  */
    /* JADX WARN: Code duplicated, block: B:394:0x051e  */
    /* JADX WARN: Code duplicated, block: B:397:0x0528  */
    /* JADX WARN: Code duplicated, block: B:398:0x052c  */
    /* JADX WARN: Code duplicated, block: B:401:0x0536  */
    /* JADX WARN: Code duplicated, block: B:402:0x053a  */
    /* JADX WARN: Code duplicated, block: B:405:0x0544  */
    /* JADX WARN: Code duplicated, block: B:406:0x0548  */
    /* JADX WARN: Code duplicated, block: B:409:0x0552  */
    /* JADX WARN: Code duplicated, block: B:410:0x0556  */
    /* JADX WARN: Code duplicated, block: B:413:0x0560  */
    /* JADX WARN: Code duplicated, block: B:414:0x0564  */
    /* JADX WARN: Code duplicated, block: B:417:0x056e  */
    /* JADX WARN: Code duplicated, block: B:418:0x0572  */
    /* JADX WARN: Code duplicated, block: B:421:0x057c  */
    /* JADX WARN: Code duplicated, block: B:422:0x0580  */
    /* JADX WARN: Code duplicated, block: B:425:0x058a  */
    /* JADX WARN: Code duplicated, block: B:426:0x058e  */
    /* JADX WARN: Code duplicated, block: B:429:0x0598  */
    /* JADX WARN: Code duplicated, block: B:430:0x059c  */
    /* JADX WARN: Code duplicated, block: B:433:0x05a6  */
    /* JADX WARN: Code duplicated, block: B:434:0x05aa  */
    /* JADX WARN: Code duplicated, block: B:437:0x05b4  */
    /* JADX WARN: Code duplicated, block: B:438:0x05b8  */
    /* JADX WARN: Code duplicated, block: B:441:0x05c2  */
    /* JADX WARN: Code duplicated, block: B:442:0x05c6  */
    /* JADX WARN: Code duplicated, block: B:445:0x05d0  */
    /* JADX WARN: Code duplicated, block: B:446:0x05d4  */
    /* JADX WARN: Code duplicated, block: B:449:0x05de  */
    /* JADX WARN: Code duplicated, block: B:450:0x05e2  */
    /* JADX WARN: Code duplicated, block: B:453:0x05ec  */
    /* JADX WARN: Code duplicated, block: B:454:0x05f0  */
    /* JADX WARN: Code duplicated, block: B:457:0x05fa  */
    /* JADX WARN: Code duplicated, block: B:458:0x05fe  */
    /* JADX WARN: Code duplicated, block: B:461:0x0608  */
    /* JADX WARN: Code duplicated, block: B:462:0x060c  */
    /* JADX WARN: Code duplicated, block: B:465:0x0616  */
    /* JADX WARN: Code duplicated, block: B:466:0x061a  */
    /* JADX WARN: Code duplicated, block: B:469:0x0624  */
    /* JADX WARN: Code duplicated, block: B:470:0x0628  */
    /* JADX WARN: Code duplicated, block: B:473:0x0632  */
    /* JADX WARN: Code duplicated, block: B:474:0x0636  */
    /* JADX WARN: Code duplicated, block: B:477:0x0640  */
    /* JADX WARN: Code duplicated, block: B:478:0x0644  */
    /* JADX WARN: Code duplicated, block: B:481:0x064e  */
    /* JADX WARN: Code duplicated, block: B:482:0x0652  */
    /* JADX WARN: Code duplicated, block: B:485:0x065c  */
    /* JADX WARN: Code duplicated, block: B:486:0x0660  */
    /* JADX WARN: Code duplicated, block: B:489:0x066a  */
    /* JADX WARN: Code duplicated, block: B:490:0x066e  */
    /* JADX WARN: Code duplicated, block: B:493:0x0678  */
    /* JADX WARN: Code duplicated, block: B:494:0x067c  */
    /* JADX WARN: Code duplicated, block: B:497:0x0686  */
    /* JADX WARN: Code duplicated, block: B:498:0x068a  */
    /* JADX WARN: Code duplicated, block: B:49:0x008d A[FALL_THROUGH] */
    /* JADX WARN: Code duplicated, block: B:501:0x0694  */
    /* JADX WARN: Code duplicated, block: B:502:0x0698  */
    /* JADX WARN: Code duplicated, block: B:505:0x06a2  */
    /* JADX WARN: Code duplicated, block: B:506:0x06a6  */
    /* JADX WARN: Code duplicated, block: B:509:0x06b0  */
    /* JADX WARN: Code duplicated, block: B:50:0x0090  */
    /* JADX WARN: Code duplicated, block: B:510:0x06b4  */
    /* JADX WARN: Code duplicated, block: B:513:0x06be  */
    /* JADX WARN: Code duplicated, block: B:514:0x06c2  */
    /* JADX WARN: Code duplicated, block: B:517:0x06cc  */
    /* JADX WARN: Code duplicated, block: B:518:0x06d0  */
    /* JADX WARN: Code duplicated, block: B:521:0x06da  */
    /* JADX WARN: Code duplicated, block: B:522:0x06de  */
    /* JADX WARN: Code duplicated, block: B:525:0x06e8  */
    /* JADX WARN: Code duplicated, block: B:526:0x06ec  */
    /* JADX WARN: Code duplicated, block: B:529:0x06f6  */
    /* JADX WARN: Code duplicated, block: B:530:0x06fa  */
    /* JADX WARN: Code duplicated, block: B:533:0x0704  */
    /* JADX WARN: Code duplicated, block: B:534:0x0708  */
    /* JADX WARN: Code duplicated, block: B:537:0x0712  */
    /* JADX WARN: Code duplicated, block: B:538:0x0716  */
    /* JADX WARN: Code duplicated, block: B:541:0x0720  */
    /* JADX WARN: Code duplicated, block: B:542:0x0724  */
    /* JADX WARN: Code duplicated, block: B:545:0x072e  */
    /* JADX WARN: Code duplicated, block: B:546:0x0732  */
    /* JADX WARN: Code duplicated, block: B:549:0x073c  */
    /* JADX WARN: Code duplicated, block: B:552:0x0746  */
    /* JADX WARN: Code duplicated, block: B:553:0x0749  */
    /* JADX WARN: Code duplicated, block: B:556:0x0753  */
    /* JADX WARN: Code duplicated, block: B:557:0x0756  */
    /* JADX WARN: Code duplicated, block: B:55:0x009f A[Catch: all -> 0x08c0, TRY_LEAVE, TryCatch #0 {all -> 0x08c0, blocks: (B:7:0x000f, B:9:0x0013, B:11:0x0023, B:664:0x08bb, B:52:0x0094, B:55:0x009f, B:98:0x011a, B:667:0x08c2), top: B:672:0x000f }] */
    /* JADX WARN: Code duplicated, block: B:560:0x0760  */
    /* JADX WARN: Code duplicated, block: B:561:0x0764  */
    /* JADX WARN: Code duplicated, block: B:564:0x076e  */
    /* JADX WARN: Code duplicated, block: B:565:0x0772  */
    /* JADX WARN: Code duplicated, block: B:568:0x077c  */
    /* JADX WARN: Code duplicated, block: B:569:0x0780  */
    /* JADX WARN: Code duplicated, block: B:572:0x078a  */
    /* JADX WARN: Code duplicated, block: B:573:0x078e  */
    /* JADX WARN: Code duplicated, block: B:576:0x0798  */
    /* JADX WARN: Code duplicated, block: B:577:0x079c  */
    /* JADX WARN: Code duplicated, block: B:580:0x07a6  */
    /* JADX WARN: Code duplicated, block: B:581:0x07aa  */
    /* JADX WARN: Code duplicated, block: B:584:0x07b4  */
    /* JADX WARN: Code duplicated, block: B:585:0x07b8  */
    /* JADX WARN: Code duplicated, block: B:588:0x07c2  */
    /* JADX WARN: Code duplicated, block: B:589:0x07c6  */
    /* JADX WARN: Code duplicated, block: B:58:0x00ad  */
    /* JADX WARN: Code duplicated, block: B:592:0x07d0  */
    /* JADX WARN: Code duplicated, block: B:593:0x07d4  */
    /* JADX WARN: Code duplicated, block: B:596:0x07de  */
    /* JADX WARN: Code duplicated, block: B:597:0x07e2  */
    /* JADX WARN: Code duplicated, block: B:59:0x00b0  */
    /* JADX WARN: Code duplicated, block: B:600:0x07ec  */
    /* JADX WARN: Code duplicated, block: B:601:0x07f0  */
    /* JADX WARN: Code duplicated, block: B:604:0x07fa  */
    /* JADX WARN: Code duplicated, block: B:605:0x07fe  */
    /* JADX WARN: Code duplicated, block: B:608:0x0808  */
    /* JADX WARN: Code duplicated, block: B:609:0x080c  */
    /* JADX WARN: Code duplicated, block: B:612:0x0816  */
    /* JADX WARN: Code duplicated, block: B:613:0x081a  */
    /* JADX WARN: Code duplicated, block: B:616:0x0824  */
    /* JADX WARN: Code duplicated, block: B:617:0x0828  */
    /* JADX WARN: Code duplicated, block: B:620:0x0832  */
    /* JADX WARN: Code duplicated, block: B:621:0x0836  */
    /* JADX WARN: Code duplicated, block: B:624:0x0840  */
    /* JADX WARN: Code duplicated, block: B:625:0x0844  */
    /* JADX WARN: Code duplicated, block: B:628:0x084e  */
    /* JADX WARN: Code duplicated, block: B:629:0x0851  */
    /* JADX WARN: Code duplicated, block: B:62:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:632:0x085b  */
    /* JADX WARN: Code duplicated, block: B:633:0x085d  */
    /* JADX WARN: Code duplicated, block: B:636:0x0867  */
    /* JADX WARN: Code duplicated, block: B:637:0x0869  */
    /* JADX WARN: Code duplicated, block: B:63:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:640:0x0873  */
    /* JADX WARN: Code duplicated, block: B:641:0x0875  */
    /* JADX WARN: Code duplicated, block: B:644:0x087f  */
    /* JADX WARN: Code duplicated, block: B:645:0x0881  */
    /* JADX WARN: Code duplicated, block: B:648:0x088b  */
    /* JADX WARN: Code duplicated, block: B:649:0x088d  */
    /* JADX WARN: Code duplicated, block: B:652:0x0897  */
    /* JADX WARN: Code duplicated, block: B:653:0x0899  */
    /* JADX WARN: Code duplicated, block: B:656:0x08a3  */
    /* JADX WARN: Code duplicated, block: B:657:0x08a5  */
    /* JADX WARN: Code duplicated, block: B:660:0x08af  */
    /* JADX WARN: Code duplicated, block: B:662:0x08b3  */
    /* JADX WARN: Code duplicated, block: B:66:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:67:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:682:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:683:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:684:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:685:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:686:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:687:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:688:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:689:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:690:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:691:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:692:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:693:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:694:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:695:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:696:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:697:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:698:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:699:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:700:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:701:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:702:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:703:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:704:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:705:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:706:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:707:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:708:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:709:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:70:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:710:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:711:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:712:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:713:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:714:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:715:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:716:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:717:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:718:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:719:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:71:0x00d2  */
    /* JADX WARN: Code duplicated, block: B:720:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:721:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:722:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:723:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:724:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:725:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:726:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:727:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:728:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:729:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:730:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:731:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:732:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:733:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:734:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:735:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:736:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:737:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:738:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:739:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:740:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:741:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:742:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:743:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:744:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:745:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:746:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:747:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:748:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:749:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x00db  */
    /* JADX WARN: Code duplicated, block: B:750:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:751:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:752:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:753:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:754:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:755:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:756:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:757:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:758:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:759:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:75:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:760:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:761:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:762:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:763:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:764:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:765:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:766:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:767:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:768:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:769:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:770:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:771:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:772:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:773:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:774:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:775:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:776:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:777:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:778:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:779:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:780:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:781:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:782:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:783:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:784:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:785:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:786:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:787:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:788:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:789:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:78:0x00e6  */
    /* JADX WARN: Code duplicated, block: B:790:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:791:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:792:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:793:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:794:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:795:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:796:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:797:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:798:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:799:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:79:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:800:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:801:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:802:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:803:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:804:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:805:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:806:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:807:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:808:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:809:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:810:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:811:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:812:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:813:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:814:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:815:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:816:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:817:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:818:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:819:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:820:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:821:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:822:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:823:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:824:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:825:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:826:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:827:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:828:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:829:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:82:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:830:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:83:0x00f3  */
    /* JADX WARN: Code duplicated, block: B:86:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:87:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:90:0x0107  */
    /* JADX WARN: Code duplicated, block: B:91:0x0109  */
    /* JADX WARN: Code duplicated, block: B:94:0x0112  */
    /* JADX WARN: Code duplicated, block: B:96:0x0116  */
    /* JADX WARN: Code duplicated, block: B:98:0x011a A[Catch: all -> 0x08c0, TRY_ENTER, TRY_LEAVE, TryCatch #0 {all -> 0x08c0, blocks: (B:7:0x000f, B:9:0x0013, B:11:0x0023, B:664:0x08bb, B:52:0x0094, B:55:0x009f, B:98:0x011a, B:667:0x08c2), top: B:672:0x000f }] */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public static boolean G0(String str) {
        String str2;
        byte b11;
        String str3;
        byte b12;
        boolean z11 = false;
        if (str.startsWith("OMX.google")) {
            return false;
        }
        synchronized (n.class) {
            try {
                if (!f20989j2) {
                    HashSet hashSet = p0.f18769a;
                    int i11 = Build.VERSION.SDK_INT;
                    byte b13 = 28;
                    if (i11 <= 28) {
                        String str4 = Build.DEVICE;
                        str4.getClass();
                        switch (str4.hashCode()) {
                            case -1339091551:
                                b12 = !str4.equals("dangal") ? (byte) -1 : (byte) 0;
                                break;
                            case -1220081023:
                                b12 = !str4.equals("dangalFHD") ? (byte) -1 : (byte) 1;
                                break;
                            case -1220066608:
                                b12 = !str4.equals("dangalUHD") ? (byte) -1 : (byte) 2;
                                break;
                            case -1012436106:
                                b12 = !str4.equals("oneday") ? (byte) -1 : (byte) 3;
                                break;
                            case -760312546:
                                b12 = !str4.equals("aquaman") ? (byte) -1 : (byte) 4;
                                break;
                            case -64886864:
                                b12 = !str4.equals("magnolia") ? (byte) -1 : (byte) 5;
                                break;
                            case 3415681:
                                b12 = !str4.equals("once") ? (byte) -1 : (byte) 6;
                                break;
                            case 825323514:
                                b12 = !str4.equals("machuca") ? (byte) -1 : (byte) 7;
                                break;
                            default:
                                b12 = -1;
                                break;
                        }
                        switch (b12) {
                            default:
                                if (i11 <= 27 || !"HWEML".equals(Build.DEVICE)) {
                                    str2 = Build.MODEL;
                                    str2.getClass();
                                    switch (str2.hashCode()) {
                                        case -349662828:
                                            if (!str2.equals("AFTJMST12")) {
                                                b11 = 0;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case -321033677:
                                            if (!str2.equals("AFTKMST12")) {
                                                b11 = 1;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 2006354:
                                            if (!str2.equals("AFTA")) {
                                                b11 = 2;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 2006367:
                                            if (!str2.equals("AFTN")) {
                                                b11 = 3;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 2006371:
                                            if (!str2.equals("AFTR")) {
                                                b11 = 4;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 1785421873:
                                            if (!str2.equals("AFTEU011")) {
                                                b11 = 5;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 1785421876:
                                            if (!str2.equals("AFTEU014")) {
                                                b11 = 6;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 1798172390:
                                            if (!str2.equals("AFTSO001")) {
                                                b11 = 7;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        case 2119412532:
                                            if (!str2.equals("AFTEUFF014")) {
                                                b11 = 8;
                                            } else {
                                                b11 = -1;
                                            }
                                            break;
                                        default:
                                            b11 = -1;
                                            break;
                                    }
                                    switch (b11) {
                                        default:
                                            if (i11 <= 26) {
                                                str3 = Build.DEVICE;
                                                str3.getClass();
                                                switch (str3.hashCode()) {
                                                    case -2144781245:
                                                        if (!str3.equals("GIONEE_SWW1609")) {
                                                            b13 = 0;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -2144781185:
                                                        if (!str3.equals("GIONEE_SWW1627")) {
                                                            b13 = 1;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -2144781160:
                                                        if (!str3.equals("GIONEE_SWW1631")) {
                                                            b13 = 2;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -2097309513:
                                                        if (!str3.equals("K50a40")) {
                                                            b13 = 3;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -2022874474:
                                                        if (!str3.equals("CP8676_I02")) {
                                                            b13 = 4;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1978993182:
                                                        if (!str3.equals("NX541J")) {
                                                            b13 = 5;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1978990237:
                                                        if (!str3.equals("NX573J")) {
                                                            b13 = 6;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1936688988:
                                                        if (!str3.equals("PGN528")) {
                                                            b13 = 7;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1936688066:
                                                        if (!str3.equals("PGN610")) {
                                                            b13 = 8;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1936688065:
                                                        if (!str3.equals("PGN611")) {
                                                            b13 = 9;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1931988508:
                                                        if (!str3.equals("AquaPowerM")) {
                                                            b13 = 10;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1885099851:
                                                        if (!str3.equals("RAIJIN")) {
                                                            b13 = 11;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1696512866:
                                                        if (!str3.equals("XT1663")) {
                                                            b13 = 12;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1680025915:
                                                        if (!str3.equals("ComioS1")) {
                                                            b13 = 13;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1615810839:
                                                        if (!str3.equals("Phantom6")) {
                                                            b13 = 14;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1600724499:
                                                        if (!str3.equals("pacificrim")) {
                                                            b13 = 15;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1554255044:
                                                        if (!str3.equals("vernee_M5")) {
                                                            b13 = 16;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1481772737:
                                                        if (!str3.equals("panell_dl")) {
                                                            b13 = 17;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1481772730:
                                                        if (!str3.equals("panell_ds")) {
                                                            b13 = 18;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1481772729:
                                                        if (!str3.equals("panell_dt")) {
                                                            b13 = 19;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1320080169:
                                                        if (!str3.equals("GiONEE_GBL7319")) {
                                                            b13 = 20;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1217592143:
                                                        if (!str3.equals("BRAVIA_ATV2")) {
                                                            b13 = 21;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1180384755:
                                                        if (!str3.equals("iris60")) {
                                                            b13 = 22;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1139198265:
                                                        if (!str3.equals("Slate_Pro")) {
                                                            b13 = 23;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -1052835013:
                                                        if (!str3.equals("namath")) {
                                                            b13 = 24;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -993250464:
                                                        if (!str3.equals("A10-70F")) {
                                                            b13 = 25;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -993250458:
                                                        if (!str3.equals("A10-70L")) {
                                                            b13 = 26;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -965403638:
                                                        if (!str3.equals("s905x018")) {
                                                            b13 = 27;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -958336948:
                                                        if (!str3.equals("ELUGA_Ray_X")) {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -879245230:
                                                        if (!str3.equals("tcl_eu")) {
                                                            b13 = 29;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -842500323:
                                                        if (!str3.equals("nicklaus_f")) {
                                                            b13 = 30;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -821392978:
                                                        if (!str3.equals("A7000-a")) {
                                                            b13 = 31;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -797483286:
                                                        if (!str3.equals("SVP-DTV15")) {
                                                            b13 = 32;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -794946968:
                                                        if (!str3.equals("watson")) {
                                                            b13 = 33;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -788334647:
                                                        if (!str3.equals("whyred")) {
                                                            b13 = 34;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -782144577:
                                                        if (!str3.equals("OnePlus5T")) {
                                                            b13 = 35;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -575125681:
                                                        if (!str3.equals("GiONEE_CBL7513")) {
                                                            b13 = 36;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -521118391:
                                                        if (!str3.equals("GIONEE_GBL7360")) {
                                                            b13 = 37;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -430914369:
                                                        if (!str3.equals("Pixi4-7_3G")) {
                                                            b13 = 38;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -290434366:
                                                        if (!str3.equals("taido_row")) {
                                                            b13 = 39;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -282781963:
                                                        if (!str3.equals("BLACK-1X")) {
                                                            b13 = 40;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -277133239:
                                                        if (!str3.equals("Z12_PRO")) {
                                                            b13 = 41;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -173639913:
                                                        if (!str3.equals("ELUGA_A3_Pro")) {
                                                            b13 = 42;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case -56598463:
                                                        if (!str3.equals("woods_fn")) {
                                                            b13 = 43;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2126:
                                                        if (!str3.equals("C1")) {
                                                            b13 = 44;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2564:
                                                        if (!str3.equals("Q5")) {
                                                            b13 = 45;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2715:
                                                        if (!str3.equals("V1")) {
                                                            b13 = 46;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2719:
                                                        if (!str3.equals("V5")) {
                                                            b13 = 47;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 3091:
                                                        if (!str3.equals("b5")) {
                                                            b13 = 48;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 3483:
                                                        if (!str3.equals("mh")) {
                                                            b13 = 49;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 73405:
                                                        if (!str3.equals("JGZ")) {
                                                            b13 = 50;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 75537:
                                                        if (!str3.equals("M04")) {
                                                            b13 = 51;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 75739:
                                                        if (!str3.equals("M5c")) {
                                                            b13 = 52;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 76779:
                                                        if (!str3.equals("MX6")) {
                                                            b13 = 53;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 78669:
                                                        if (!str3.equals("P85")) {
                                                            b13 = 54;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 79305:
                                                        if (!str3.equals("PLE")) {
                                                            b13 = 55;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 80618:
                                                        if (!str3.equals("QX1")) {
                                                            b13 = 56;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 88274:
                                                        if (!str3.equals("Z80")) {
                                                            b13 = 57;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 98846:
                                                        if (!str3.equals("cv1")) {
                                                            b13 = 58;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 98848:
                                                        if (!str3.equals("cv3")) {
                                                            b13 = 59;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 99329:
                                                        if (!str3.equals("deb")) {
                                                            b13 = 60;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 101481:
                                                        if (!str3.equals("flo")) {
                                                            b13 = 61;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1513190:
                                                        if (!str3.equals("1601")) {
                                                            b13 = 62;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1514184:
                                                        if (!str3.equals("1713")) {
                                                            b13 = 63;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1514185:
                                                        if (!str3.equals("1714")) {
                                                            b13 = 64;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2133089:
                                                        if (!str3.equals("F01H")) {
                                                            b13 = 65;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2133091:
                                                        if (!str3.equals("F01J")) {
                                                            b13 = 66;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2133120:
                                                        if (!str3.equals("F02H")) {
                                                            b13 = 67;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2133151:
                                                        if (!str3.equals("F03H")) {
                                                            b13 = 68;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2133182:
                                                        if (!str3.equals("F04H")) {
                                                            b13 = 69;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2133184:
                                                        if (!str3.equals("F04J")) {
                                                            b13 = 70;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2436959:
                                                        if (!str3.equals("P681")) {
                                                            b13 = 71;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2463773:
                                                        if (!str3.equals("Q350")) {
                                                            b13 = 72;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2464648:
                                                        if (!str3.equals("Q427")) {
                                                            b13 = 73;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2689555:
                                                        if (!str3.equals("XE2X")) {
                                                            b13 = 74;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 3154429:
                                                        if (!str3.equals("fugu")) {
                                                            b13 = 75;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 3284551:
                                                        if (!str3.equals("kate")) {
                                                            b13 = 76;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 3351335:
                                                        if (!str3.equals("mido")) {
                                                            b13 = 77;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 3386211:
                                                        if (!str3.equals("p212")) {
                                                            b13 = 78;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 41325051:
                                                        if (!str3.equals("MEIZU_M5")) {
                                                            b13 = 79;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 51349633:
                                                        if (!str3.equals("601LV")) {
                                                            b13 = 80;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 51350594:
                                                        if (!str3.equals("602LV")) {
                                                            b13 = 81;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 55178625:
                                                        if (!str3.equals("Aura_Note_2")) {
                                                            b13 = 82;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 61542055:
                                                        if (!str3.equals("A1601")) {
                                                            b13 = 83;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 65355429:
                                                        if (!str3.equals("E5643")) {
                                                            b13 = 84;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66214468:
                                                        if (!str3.equals("F3111")) {
                                                            b13 = 85;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66214470:
                                                        if (!str3.equals("F3113")) {
                                                            b13 = 86;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66214473:
                                                        if (!str3.equals("F3116")) {
                                                            b13 = 87;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66215429:
                                                        if (!str3.equals("F3211")) {
                                                            b13 = 88;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66215431:
                                                        if (!str3.equals("F3213")) {
                                                            b13 = 89;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66215433:
                                                        if (!str3.equals("F3215")) {
                                                            b13 = 90;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 66216390:
                                                        if (!str3.equals("F3311")) {
                                                            b13 = 91;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 76402249:
                                                        if (!str3.equals("PRO7S")) {
                                                            b13 = 92;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 76404105:
                                                        if (!str3.equals("Q4260")) {
                                                            b13 = 93;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 76404911:
                                                        if (!str3.equals("Q4310")) {
                                                            b13 = 94;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 80963634:
                                                        if (!str3.equals("V23GB")) {
                                                            b13 = 95;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 82882791:
                                                        if (!str3.equals("X3_HK")) {
                                                            b13 = 96;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 98715550:
                                                        if (!str3.equals("i9031")) {
                                                            b13 = 97;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 101370885:
                                                        if (!str3.equals("l5460")) {
                                                            b13 = 98;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 102844228:
                                                        if (!str3.equals("le_x6")) {
                                                            b13 = 99;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 165221241:
                                                        if (!str3.equals("A2016a40")) {
                                                            b13 = 100;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 182191441:
                                                        if (!str3.equals("CPY83_I00")) {
                                                            b13 = 101;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 245388979:
                                                        if (!str3.equals("marino_f")) {
                                                            b13 = 102;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 287431619:
                                                        if (!str3.equals("griffin")) {
                                                            b13 = 103;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 307593612:
                                                        if (!str3.equals("A7010a48")) {
                                                            b13 = 104;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 308517133:
                                                        if (!str3.equals("A7020a48")) {
                                                            b13 = 105;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 316215098:
                                                        if (!str3.equals("TB3-730F")) {
                                                            b13 = 106;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 316215116:
                                                        if (!str3.equals("TB3-730X")) {
                                                            b13 = 107;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 316246811:
                                                        if (!str3.equals("TB3-850F")) {
                                                            b13 = 108;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 316246818:
                                                        if (!str3.equals("TB3-850M")) {
                                                            b13 = 109;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 407160593:
                                                        if (!str3.equals("Pixi5-10_4G")) {
                                                            b13 = 110;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 507412548:
                                                        if (!str3.equals("QM16XE_U")) {
                                                            b13 = 111;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 793982701:
                                                        if (!str3.equals("GIONEE_WBL5708")) {
                                                            b13 = 112;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 794038622:
                                                        if (!str3.equals("GIONEE_WBL7365")) {
                                                            b13 = 113;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 794040393:
                                                        if (!str3.equals("GIONEE_WBL7519")) {
                                                            b13 = 114;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 835649806:
                                                        if (!str3.equals("manning")) {
                                                            b13 = 115;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 917340916:
                                                        if (!str3.equals("A7000plus")) {
                                                            b13 = 116;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 958008161:
                                                        if (!str3.equals("j2xlteins")) {
                                                            b13 = 117;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1060579533:
                                                        if (!str3.equals("panell_d")) {
                                                            b13 = 118;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1150207623:
                                                        if (!str3.equals("LS-5017")) {
                                                            b13 = 119;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1176899427:
                                                        if (!str3.equals("itel_S41")) {
                                                            b13 = 120;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1280332038:
                                                        if (!str3.equals("hwALE-H")) {
                                                            b13 = 121;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1306947716:
                                                        if (!str3.equals("EverStar_S")) {
                                                            b13 = 122;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1349174697:
                                                        if (!str3.equals("htc_e56ml_dtul")) {
                                                            b13 = 123;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1522194893:
                                                        if (!str3.equals("woods_f")) {
                                                            b13 = 124;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1691543273:
                                                        if (!str3.equals("CPH1609")) {
                                                            b13 = 125;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1691544261:
                                                        if (!str3.equals("CPH1715")) {
                                                            b13 = 126;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1709443163:
                                                        if (!str3.equals("iball8735_9806")) {
                                                            b13 = 127;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1865889110:
                                                        if (!str3.equals("santoni")) {
                                                            b13 = 128;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1906253259:
                                                        if (!str3.equals("PB2-670M")) {
                                                            b13 = 129;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 1977196784:
                                                        if (!str3.equals("Infinix-X572")) {
                                                            b13 = 130;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2006372676:
                                                        if (!str3.equals("BRAVIA_ATV3_4K")) {
                                                            b13 = 131;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2019281702:
                                                        if (!str3.equals("DM-01K")) {
                                                            b13 = 132;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2029784656:
                                                        if (!str3.equals("HWBLN-H")) {
                                                            b13 = 133;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2030379515:
                                                        if (!str3.equals("HWCAM-H")) {
                                                            b13 = 134;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2033393791:
                                                        if (!str3.equals("ASUS_X00AD_2")) {
                                                            b13 = 135;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2047190025:
                                                        if (!str3.equals("ELUGA_Note")) {
                                                            b13 = 136;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2047252157:
                                                        if (!str3.equals("ELUGA_Prim")) {
                                                            b13 = 137;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2048319463:
                                                        if (!str3.equals("HWVNS-H")) {
                                                            b13 = 138;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    case 2048855701:
                                                        if (!str3.equals("HWWAS-H")) {
                                                            b13 = 139;
                                                        } else {
                                                            b13 = -1;
                                                        }
                                                        break;
                                                    default:
                                                        b13 = -1;
                                                        break;
                                                }
                                                switch (b13) {
                                                    default:
                                                        if (str2.equals("JSN-L21")) {
                                                        }
                                                    case 0:
                                                    case 1:
                                                    case 2:
                                                    case 3:
                                                    case 4:
                                                    case 5:
                                                    case 6:
                                                    case 7:
                                                    case 8:
                                                    case 9:
                                                    case 10:
                                                    case 11:
                                                    case 12:
                                                    case 13:
                                                    case 14:
                                                    case 15:
                                                    case 16:
                                                    case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                                                    case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                                                    case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                                                    case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                                                    case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                                                    case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                                                    case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                                                    case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                                                    case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                                                    case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                                                    case 27:
                                                    case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                                                    case 29:
                                                    case RendererMetrics.SAMPLES /* 30 */:
                                                    case 31:
                                                    case 32:
                                                    case 33:
                                                    case 34:
                                                    case 35:
                                                    case 36:
                                                    case 37:
                                                    case 38:
                                                    case 39:
                                                    case RequestError.NETWORK_FAILURE /* 40 */:
                                                    case RequestError.NO_DEV_KEY /* 41 */:
                                                    case 42:
                                                    case 43:
                                                    case 44:
                                                    case 45:
                                                    case 46:
                                                    case 47:
                                                    case 48:
                                                    case 49:
                                                    case 50:
                                                    case 51:
                                                    case 52:
                                                    case 53:
                                                    case 54:
                                                    case 55:
                                                    case 56:
                                                    case 57:
                                                    case 58:
                                                    case 59:
                                                    case 60:
                                                    case 61:
                                                    case 62:
                                                    case 63:
                                                    case 64:
                                                    case 65:
                                                    case 66:
                                                    case 67:
                                                    case 68:
                                                    case 69:
                                                    case 70:
                                                    case 71:
                                                    case 72:
                                                    case 73:
                                                    case 74:
                                                    case 75:
                                                    case 76:
                                                    case 77:
                                                    case 78:
                                                    case 79:
                                                    case 80:
                                                    case 81:
                                                    case 82:
                                                    case 83:
                                                    case 84:
                                                    case 85:
                                                    case 86:
                                                    case 87:
                                                    case 88:
                                                    case 89:
                                                    case 90:
                                                    case 91:
                                                    case 92:
                                                    case 93:
                                                    case 94:
                                                    case 95:
                                                    case 96:
                                                    case 97:
                                                    case 98:
                                                    case 99:
                                                    case 100:
                                                    case 101:
                                                    case 102:
                                                    case 103:
                                                    case 104:
                                                    case 105:
                                                    case 106:
                                                    case 107:
                                                    case 108:
                                                    case 109:
                                                    case 110:
                                                    case 111:
                                                    case 112:
                                                    case 113:
                                                    case 114:
                                                    case 115:
                                                    case 116:
                                                    case 117:
                                                    case 118:
                                                    case 119:
                                                    case 120:
                                                    case 121:
                                                    case 122:
                                                    case 123:
                                                    case 124:
                                                    case 125:
                                                    case 126:
                                                    case 127:
                                                    case 128:
                                                    case 129:
                                                    case 130:
                                                    case 131:
                                                    case 132:
                                                    case 133:
                                                    case 134:
                                                    case 135:
                                                    case 136:
                                                    case 137:
                                                    case 138:
                                                    case 139:
                                                        z11 = true;
                                                        break;
                                                }
                                            }
                                        case 0:
                                        case 1:
                                        case 2:
                                        case 3:
                                        case 4:
                                        case 5:
                                        case 6:
                                        case 7:
                                        case 8:
                                            z11 = true;
                                            break;
                                    }
                                }
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                                z11 = true;
                                break;
                        }
                    } else if (i11 <= 27) {
                        str2 = Build.MODEL;
                        str2.getClass();
                        switch (str2.hashCode()) {
                            case -349662828:
                                if (!str2.equals("AFTJMST12")) {
                                    b11 = 0;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case -321033677:
                                if (!str2.equals("AFTKMST12")) {
                                    b11 = 1;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 2006354:
                                if (!str2.equals("AFTA")) {
                                    b11 = 2;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 2006367:
                                if (!str2.equals("AFTN")) {
                                    b11 = 3;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 2006371:
                                if (!str2.equals("AFTR")) {
                                    b11 = 4;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 1785421873:
                                if (!str2.equals("AFTEU011")) {
                                    b11 = 5;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 1785421876:
                                if (!str2.equals("AFTEU014")) {
                                    b11 = 6;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 1798172390:
                                if (!str2.equals("AFTSO001")) {
                                    b11 = 7;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            case 2119412532:
                                if (!str2.equals("AFTEUFF014")) {
                                    b11 = 8;
                                } else {
                                    b11 = -1;
                                }
                                break;
                            default:
                                b11 = -1;
                                break;
                        }
                        switch (b11) {
                            default:
                                if (i11 <= 26) {
                                    str3 = Build.DEVICE;
                                    str3.getClass();
                                    switch (str3.hashCode()) {
                                        case -2144781245:
                                            if (!str3.equals("GIONEE_SWW1609")) {
                                                b13 = 0;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -2144781185:
                                            if (!str3.equals("GIONEE_SWW1627")) {
                                                b13 = 1;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -2144781160:
                                            if (!str3.equals("GIONEE_SWW1631")) {
                                                b13 = 2;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -2097309513:
                                            if (!str3.equals("K50a40")) {
                                                b13 = 3;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -2022874474:
                                            if (!str3.equals("CP8676_I02")) {
                                                b13 = 4;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1978993182:
                                            if (!str3.equals("NX541J")) {
                                                b13 = 5;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1978990237:
                                            if (!str3.equals("NX573J")) {
                                                b13 = 6;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1936688988:
                                            if (!str3.equals("PGN528")) {
                                                b13 = 7;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1936688066:
                                            if (!str3.equals("PGN610")) {
                                                b13 = 8;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1936688065:
                                            if (!str3.equals("PGN611")) {
                                                b13 = 9;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1931988508:
                                            if (!str3.equals("AquaPowerM")) {
                                                b13 = 10;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1885099851:
                                            if (!str3.equals("RAIJIN")) {
                                                b13 = 11;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1696512866:
                                            if (!str3.equals("XT1663")) {
                                                b13 = 12;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1680025915:
                                            if (!str3.equals("ComioS1")) {
                                                b13 = 13;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1615810839:
                                            if (!str3.equals("Phantom6")) {
                                                b13 = 14;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1600724499:
                                            if (!str3.equals("pacificrim")) {
                                                b13 = 15;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1554255044:
                                            if (!str3.equals("vernee_M5")) {
                                                b13 = 16;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1481772737:
                                            if (!str3.equals("panell_dl")) {
                                                b13 = 17;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1481772730:
                                            if (!str3.equals("panell_ds")) {
                                                b13 = 18;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1481772729:
                                            if (!str3.equals("panell_dt")) {
                                                b13 = 19;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1320080169:
                                            if (!str3.equals("GiONEE_GBL7319")) {
                                                b13 = 20;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1217592143:
                                            if (!str3.equals("BRAVIA_ATV2")) {
                                                b13 = 21;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1180384755:
                                            if (!str3.equals("iris60")) {
                                                b13 = 22;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1139198265:
                                            if (!str3.equals("Slate_Pro")) {
                                                b13 = 23;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -1052835013:
                                            if (!str3.equals("namath")) {
                                                b13 = 24;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -993250464:
                                            if (!str3.equals("A10-70F")) {
                                                b13 = 25;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -993250458:
                                            if (!str3.equals("A10-70L")) {
                                                b13 = 26;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -965403638:
                                            if (!str3.equals("s905x018")) {
                                                b13 = 27;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -958336948:
                                            if (!str3.equals("ELUGA_Ray_X")) {
                                                b13 = -1;
                                            }
                                            break;
                                        case -879245230:
                                            if (!str3.equals("tcl_eu")) {
                                                b13 = 29;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -842500323:
                                            if (!str3.equals("nicklaus_f")) {
                                                b13 = 30;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -821392978:
                                            if (!str3.equals("A7000-a")) {
                                                b13 = 31;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -797483286:
                                            if (!str3.equals("SVP-DTV15")) {
                                                b13 = 32;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -794946968:
                                            if (!str3.equals("watson")) {
                                                b13 = 33;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -788334647:
                                            if (!str3.equals("whyred")) {
                                                b13 = 34;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -782144577:
                                            if (!str3.equals("OnePlus5T")) {
                                                b13 = 35;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -575125681:
                                            if (!str3.equals("GiONEE_CBL7513")) {
                                                b13 = 36;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -521118391:
                                            if (!str3.equals("GIONEE_GBL7360")) {
                                                b13 = 37;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -430914369:
                                            if (!str3.equals("Pixi4-7_3G")) {
                                                b13 = 38;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -290434366:
                                            if (!str3.equals("taido_row")) {
                                                b13 = 39;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -282781963:
                                            if (!str3.equals("BLACK-1X")) {
                                                b13 = 40;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -277133239:
                                            if (!str3.equals("Z12_PRO")) {
                                                b13 = 41;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -173639913:
                                            if (!str3.equals("ELUGA_A3_Pro")) {
                                                b13 = 42;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case -56598463:
                                            if (!str3.equals("woods_fn")) {
                                                b13 = 43;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2126:
                                            if (!str3.equals("C1")) {
                                                b13 = 44;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2564:
                                            if (!str3.equals("Q5")) {
                                                b13 = 45;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2715:
                                            if (!str3.equals("V1")) {
                                                b13 = 46;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2719:
                                            if (!str3.equals("V5")) {
                                                b13 = 47;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 3091:
                                            if (!str3.equals("b5")) {
                                                b13 = 48;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 3483:
                                            if (!str3.equals("mh")) {
                                                b13 = 49;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 73405:
                                            if (!str3.equals("JGZ")) {
                                                b13 = 50;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 75537:
                                            if (!str3.equals("M04")) {
                                                b13 = 51;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 75739:
                                            if (!str3.equals("M5c")) {
                                                b13 = 52;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 76779:
                                            if (!str3.equals("MX6")) {
                                                b13 = 53;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 78669:
                                            if (!str3.equals("P85")) {
                                                b13 = 54;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 79305:
                                            if (!str3.equals("PLE")) {
                                                b13 = 55;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 80618:
                                            if (!str3.equals("QX1")) {
                                                b13 = 56;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 88274:
                                            if (!str3.equals("Z80")) {
                                                b13 = 57;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 98846:
                                            if (!str3.equals("cv1")) {
                                                b13 = 58;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 98848:
                                            if (!str3.equals("cv3")) {
                                                b13 = 59;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 99329:
                                            if (!str3.equals("deb")) {
                                                b13 = 60;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 101481:
                                            if (!str3.equals("flo")) {
                                                b13 = 61;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1513190:
                                            if (!str3.equals("1601")) {
                                                b13 = 62;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1514184:
                                            if (!str3.equals("1713")) {
                                                b13 = 63;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1514185:
                                            if (!str3.equals("1714")) {
                                                b13 = 64;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2133089:
                                            if (!str3.equals("F01H")) {
                                                b13 = 65;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2133091:
                                            if (!str3.equals("F01J")) {
                                                b13 = 66;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2133120:
                                            if (!str3.equals("F02H")) {
                                                b13 = 67;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2133151:
                                            if (!str3.equals("F03H")) {
                                                b13 = 68;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2133182:
                                            if (!str3.equals("F04H")) {
                                                b13 = 69;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2133184:
                                            if (!str3.equals("F04J")) {
                                                b13 = 70;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2436959:
                                            if (!str3.equals("P681")) {
                                                b13 = 71;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2463773:
                                            if (!str3.equals("Q350")) {
                                                b13 = 72;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2464648:
                                            if (!str3.equals("Q427")) {
                                                b13 = 73;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2689555:
                                            if (!str3.equals("XE2X")) {
                                                b13 = 74;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 3154429:
                                            if (!str3.equals("fugu")) {
                                                b13 = 75;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 3284551:
                                            if (!str3.equals("kate")) {
                                                b13 = 76;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 3351335:
                                            if (!str3.equals("mido")) {
                                                b13 = 77;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 3386211:
                                            if (!str3.equals("p212")) {
                                                b13 = 78;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 41325051:
                                            if (!str3.equals("MEIZU_M5")) {
                                                b13 = 79;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 51349633:
                                            if (!str3.equals("601LV")) {
                                                b13 = 80;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 51350594:
                                            if (!str3.equals("602LV")) {
                                                b13 = 81;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 55178625:
                                            if (!str3.equals("Aura_Note_2")) {
                                                b13 = 82;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 61542055:
                                            if (!str3.equals("A1601")) {
                                                b13 = 83;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 65355429:
                                            if (!str3.equals("E5643")) {
                                                b13 = 84;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66214468:
                                            if (!str3.equals("F3111")) {
                                                b13 = 85;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66214470:
                                            if (!str3.equals("F3113")) {
                                                b13 = 86;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66214473:
                                            if (!str3.equals("F3116")) {
                                                b13 = 87;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66215429:
                                            if (!str3.equals("F3211")) {
                                                b13 = 88;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66215431:
                                            if (!str3.equals("F3213")) {
                                                b13 = 89;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66215433:
                                            if (!str3.equals("F3215")) {
                                                b13 = 90;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 66216390:
                                            if (!str3.equals("F3311")) {
                                                b13 = 91;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 76402249:
                                            if (!str3.equals("PRO7S")) {
                                                b13 = 92;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 76404105:
                                            if (!str3.equals("Q4260")) {
                                                b13 = 93;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 76404911:
                                            if (!str3.equals("Q4310")) {
                                                b13 = 94;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 80963634:
                                            if (!str3.equals("V23GB")) {
                                                b13 = 95;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 82882791:
                                            if (!str3.equals("X3_HK")) {
                                                b13 = 96;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 98715550:
                                            if (!str3.equals("i9031")) {
                                                b13 = 97;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 101370885:
                                            if (!str3.equals("l5460")) {
                                                b13 = 98;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 102844228:
                                            if (!str3.equals("le_x6")) {
                                                b13 = 99;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 165221241:
                                            if (!str3.equals("A2016a40")) {
                                                b13 = 100;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 182191441:
                                            if (!str3.equals("CPY83_I00")) {
                                                b13 = 101;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 245388979:
                                            if (!str3.equals("marino_f")) {
                                                b13 = 102;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 287431619:
                                            if (!str3.equals("griffin")) {
                                                b13 = 103;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 307593612:
                                            if (!str3.equals("A7010a48")) {
                                                b13 = 104;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 308517133:
                                            if (!str3.equals("A7020a48")) {
                                                b13 = 105;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 316215098:
                                            if (!str3.equals("TB3-730F")) {
                                                b13 = 106;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 316215116:
                                            if (!str3.equals("TB3-730X")) {
                                                b13 = 107;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 316246811:
                                            if (!str3.equals("TB3-850F")) {
                                                b13 = 108;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 316246818:
                                            if (!str3.equals("TB3-850M")) {
                                                b13 = 109;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 407160593:
                                            if (!str3.equals("Pixi5-10_4G")) {
                                                b13 = 110;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 507412548:
                                            if (!str3.equals("QM16XE_U")) {
                                                b13 = 111;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 793982701:
                                            if (!str3.equals("GIONEE_WBL5708")) {
                                                b13 = 112;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 794038622:
                                            if (!str3.equals("GIONEE_WBL7365")) {
                                                b13 = 113;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 794040393:
                                            if (!str3.equals("GIONEE_WBL7519")) {
                                                b13 = 114;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 835649806:
                                            if (!str3.equals("manning")) {
                                                b13 = 115;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 917340916:
                                            if (!str3.equals("A7000plus")) {
                                                b13 = 116;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 958008161:
                                            if (!str3.equals("j2xlteins")) {
                                                b13 = 117;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1060579533:
                                            if (!str3.equals("panell_d")) {
                                                b13 = 118;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1150207623:
                                            if (!str3.equals("LS-5017")) {
                                                b13 = 119;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1176899427:
                                            if (!str3.equals("itel_S41")) {
                                                b13 = 120;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1280332038:
                                            if (!str3.equals("hwALE-H")) {
                                                b13 = 121;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1306947716:
                                            if (!str3.equals("EverStar_S")) {
                                                b13 = 122;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1349174697:
                                            if (!str3.equals("htc_e56ml_dtul")) {
                                                b13 = 123;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1522194893:
                                            if (!str3.equals("woods_f")) {
                                                b13 = 124;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1691543273:
                                            if (!str3.equals("CPH1609")) {
                                                b13 = 125;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1691544261:
                                            if (!str3.equals("CPH1715")) {
                                                b13 = 126;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1709443163:
                                            if (!str3.equals("iball8735_9806")) {
                                                b13 = 127;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1865889110:
                                            if (!str3.equals("santoni")) {
                                                b13 = 128;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1906253259:
                                            if (!str3.equals("PB2-670M")) {
                                                b13 = 129;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 1977196784:
                                            if (!str3.equals("Infinix-X572")) {
                                                b13 = 130;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2006372676:
                                            if (!str3.equals("BRAVIA_ATV3_4K")) {
                                                b13 = 131;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2019281702:
                                            if (!str3.equals("DM-01K")) {
                                                b13 = 132;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2029784656:
                                            if (!str3.equals("HWBLN-H")) {
                                                b13 = 133;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2030379515:
                                            if (!str3.equals("HWCAM-H")) {
                                                b13 = 134;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2033393791:
                                            if (!str3.equals("ASUS_X00AD_2")) {
                                                b13 = 135;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2047190025:
                                            if (!str3.equals("ELUGA_Note")) {
                                                b13 = 136;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2047252157:
                                            if (!str3.equals("ELUGA_Prim")) {
                                                b13 = 137;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2048319463:
                                            if (!str3.equals("HWVNS-H")) {
                                                b13 = 138;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        case 2048855701:
                                            if (!str3.equals("HWWAS-H")) {
                                                b13 = 139;
                                            } else {
                                                b13 = -1;
                                            }
                                            break;
                                        default:
                                            b13 = -1;
                                            break;
                                    }
                                    switch (b13) {
                                        default:
                                            if (str2.equals("JSN-L21")) {
                                            }
                                        case 0:
                                        case 1:
                                        case 2:
                                        case 3:
                                        case 4:
                                        case 5:
                                        case 6:
                                        case 7:
                                        case 8:
                                        case 9:
                                        case 10:
                                        case 11:
                                        case 12:
                                        case 13:
                                        case 14:
                                        case 15:
                                        case 16:
                                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                                        case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                                        case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                                        case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                                        case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                                        case 27:
                                        case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                                        case 29:
                                        case RendererMetrics.SAMPLES /* 30 */:
                                        case 31:
                                        case 32:
                                        case 33:
                                        case 34:
                                        case 35:
                                        case 36:
                                        case 37:
                                        case 38:
                                        case 39:
                                        case RequestError.NETWORK_FAILURE /* 40 */:
                                        case RequestError.NO_DEV_KEY /* 41 */:
                                        case 42:
                                        case 43:
                                        case 44:
                                        case 45:
                                        case 46:
                                        case 47:
                                        case 48:
                                        case 49:
                                        case 50:
                                        case 51:
                                        case 52:
                                        case 53:
                                        case 54:
                                        case 55:
                                        case 56:
                                        case 57:
                                        case 58:
                                        case 59:
                                        case 60:
                                        case 61:
                                        case 62:
                                        case 63:
                                        case 64:
                                        case 65:
                                        case 66:
                                        case 67:
                                        case 68:
                                        case 69:
                                        case 70:
                                        case 71:
                                        case 72:
                                        case 73:
                                        case 74:
                                        case 75:
                                        case 76:
                                        case 77:
                                        case 78:
                                        case 79:
                                        case 80:
                                        case 81:
                                        case 82:
                                        case 83:
                                        case 84:
                                        case 85:
                                        case 86:
                                        case 87:
                                        case 88:
                                        case 89:
                                        case 90:
                                        case 91:
                                        case 92:
                                        case 93:
                                        case 94:
                                        case 95:
                                        case 96:
                                        case 97:
                                        case 98:
                                        case 99:
                                        case 100:
                                        case 101:
                                        case 102:
                                        case 103:
                                        case 104:
                                        case 105:
                                        case 106:
                                        case 107:
                                        case 108:
                                        case 109:
                                        case 110:
                                        case 111:
                                        case 112:
                                        case 113:
                                        case 114:
                                        case 115:
                                        case 116:
                                        case 117:
                                        case 118:
                                        case 119:
                                        case 120:
                                        case 121:
                                        case 122:
                                        case 123:
                                        case 124:
                                        case 125:
                                        case 126:
                                        case 127:
                                        case 128:
                                        case 129:
                                        case 130:
                                        case 131:
                                        case 132:
                                        case 133:
                                        case 134:
                                        case 135:
                                        case 136:
                                        case 137:
                                        case 138:
                                        case 139:
                                            z11 = true;
                                            break;
                                    }
                                }
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case 8:
                                z11 = true;
                                break;
                        }
                    } else {
                        str2 = Build.MODEL;
                        str2.getClass();
                        switch (str2.hashCode()) {
                            case -349662828:
                                if (!str2.equals("AFTJMST12")) {
                                    b11 = -1;
                                } else {
                                    b11 = 0;
                                }
                                break;
                            case -321033677:
                                if (!str2.equals("AFTKMST12")) {
                                    b11 = -1;
                                } else {
                                    b11 = 1;
                                }
                                break;
                            case 2006354:
                                if (!str2.equals("AFTA")) {
                                    b11 = -1;
                                } else {
                                    b11 = 2;
                                }
                                break;
                            case 2006367:
                                if (!str2.equals("AFTN")) {
                                    b11 = -1;
                                } else {
                                    b11 = 3;
                                }
                                break;
                            case 2006371:
                                if (!str2.equals("AFTR")) {
                                    b11 = -1;
                                } else {
                                    b11 = 4;
                                }
                                break;
                            case 1785421873:
                                if (!str2.equals("AFTEU011")) {
                                    b11 = -1;
                                } else {
                                    b11 = 5;
                                }
                                break;
                            case 1785421876:
                                if (!str2.equals("AFTEU014")) {
                                    b11 = -1;
                                } else {
                                    b11 = 6;
                                }
                                break;
                            case 1798172390:
                                if (!str2.equals("AFTSO001")) {
                                    b11 = -1;
                                } else {
                                    b11 = 7;
                                }
                                break;
                            case 2119412532:
                                if (!str2.equals("AFTEUFF014")) {
                                    b11 = -1;
                                } else {
                                    b11 = 8;
                                }
                                break;
                            default:
                                b11 = -1;
                                break;
                        }
                        switch (b11) {
                            default:
                                if (i11 <= 26) {
                                    str3 = Build.DEVICE;
                                    str3.getClass();
                                    switch (str3.hashCode()) {
                                        case -2144781245:
                                            if (!str3.equals("GIONEE_SWW1609")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 0;
                                            }
                                            break;
                                        case -2144781185:
                                            if (!str3.equals("GIONEE_SWW1627")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 1;
                                            }
                                            break;
                                        case -2144781160:
                                            if (!str3.equals("GIONEE_SWW1631")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 2;
                                            }
                                            break;
                                        case -2097309513:
                                            if (!str3.equals("K50a40")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 3;
                                            }
                                            break;
                                        case -2022874474:
                                            if (!str3.equals("CP8676_I02")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 4;
                                            }
                                            break;
                                        case -1978993182:
                                            if (!str3.equals("NX541J")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 5;
                                            }
                                            break;
                                        case -1978990237:
                                            if (!str3.equals("NX573J")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 6;
                                            }
                                            break;
                                        case -1936688988:
                                            if (!str3.equals("PGN528")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 7;
                                            }
                                            break;
                                        case -1936688066:
                                            if (!str3.equals("PGN610")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 8;
                                            }
                                            break;
                                        case -1936688065:
                                            if (!str3.equals("PGN611")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 9;
                                            }
                                            break;
                                        case -1931988508:
                                            if (!str3.equals("AquaPowerM")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 10;
                                            }
                                            break;
                                        case -1885099851:
                                            if (!str3.equals("RAIJIN")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 11;
                                            }
                                            break;
                                        case -1696512866:
                                            if (!str3.equals("XT1663")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 12;
                                            }
                                            break;
                                        case -1680025915:
                                            if (!str3.equals("ComioS1")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 13;
                                            }
                                            break;
                                        case -1615810839:
                                            if (!str3.equals("Phantom6")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 14;
                                            }
                                            break;
                                        case -1600724499:
                                            if (!str3.equals("pacificrim")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 15;
                                            }
                                            break;
                                        case -1554255044:
                                            if (!str3.equals("vernee_M5")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 16;
                                            }
                                            break;
                                        case -1481772737:
                                            if (!str3.equals("panell_dl")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 17;
                                            }
                                            break;
                                        case -1481772730:
                                            if (!str3.equals("panell_ds")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 18;
                                            }
                                            break;
                                        case -1481772729:
                                            if (!str3.equals("panell_dt")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 19;
                                            }
                                            break;
                                        case -1320080169:
                                            if (!str3.equals("GiONEE_GBL7319")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 20;
                                            }
                                            break;
                                        case -1217592143:
                                            if (!str3.equals("BRAVIA_ATV2")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 21;
                                            }
                                            break;
                                        case -1180384755:
                                            if (!str3.equals("iris60")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 22;
                                            }
                                            break;
                                        case -1139198265:
                                            if (!str3.equals("Slate_Pro")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 23;
                                            }
                                            break;
                                        case -1052835013:
                                            if (!str3.equals("namath")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 24;
                                            }
                                            break;
                                        case -993250464:
                                            if (!str3.equals("A10-70F")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 25;
                                            }
                                            break;
                                        case -993250458:
                                            if (!str3.equals("A10-70L")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 26;
                                            }
                                            break;
                                        case -965403638:
                                            if (!str3.equals("s905x018")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 27;
                                            }
                                            break;
                                        case -958336948:
                                            if (!str3.equals("ELUGA_Ray_X")) {
                                                b13 = -1;
                                            }
                                            break;
                                        case -879245230:
                                            if (!str3.equals("tcl_eu")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 29;
                                            }
                                            break;
                                        case -842500323:
                                            if (!str3.equals("nicklaus_f")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 30;
                                            }
                                            break;
                                        case -821392978:
                                            if (!str3.equals("A7000-a")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 31;
                                            }
                                            break;
                                        case -797483286:
                                            if (!str3.equals("SVP-DTV15")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 32;
                                            }
                                            break;
                                        case -794946968:
                                            if (!str3.equals("watson")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 33;
                                            }
                                            break;
                                        case -788334647:
                                            if (!str3.equals("whyred")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 34;
                                            }
                                            break;
                                        case -782144577:
                                            if (!str3.equals("OnePlus5T")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 35;
                                            }
                                            break;
                                        case -575125681:
                                            if (!str3.equals("GiONEE_CBL7513")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 36;
                                            }
                                            break;
                                        case -521118391:
                                            if (!str3.equals("GIONEE_GBL7360")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 37;
                                            }
                                            break;
                                        case -430914369:
                                            if (!str3.equals("Pixi4-7_3G")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 38;
                                            }
                                            break;
                                        case -290434366:
                                            if (!str3.equals("taido_row")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 39;
                                            }
                                            break;
                                        case -282781963:
                                            if (!str3.equals("BLACK-1X")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 40;
                                            }
                                            break;
                                        case -277133239:
                                            if (!str3.equals("Z12_PRO")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 41;
                                            }
                                            break;
                                        case -173639913:
                                            if (!str3.equals("ELUGA_A3_Pro")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 42;
                                            }
                                            break;
                                        case -56598463:
                                            if (!str3.equals("woods_fn")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 43;
                                            }
                                            break;
                                        case 2126:
                                            if (!str3.equals("C1")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 44;
                                            }
                                            break;
                                        case 2564:
                                            if (!str3.equals("Q5")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 45;
                                            }
                                            break;
                                        case 2715:
                                            if (!str3.equals("V1")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 46;
                                            }
                                            break;
                                        case 2719:
                                            if (!str3.equals("V5")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 47;
                                            }
                                            break;
                                        case 3091:
                                            if (!str3.equals("b5")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 48;
                                            }
                                            break;
                                        case 3483:
                                            if (!str3.equals("mh")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 49;
                                            }
                                            break;
                                        case 73405:
                                            if (!str3.equals("JGZ")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 50;
                                            }
                                            break;
                                        case 75537:
                                            if (!str3.equals("M04")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 51;
                                            }
                                            break;
                                        case 75739:
                                            if (!str3.equals("M5c")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 52;
                                            }
                                            break;
                                        case 76779:
                                            if (!str3.equals("MX6")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 53;
                                            }
                                            break;
                                        case 78669:
                                            if (!str3.equals("P85")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 54;
                                            }
                                            break;
                                        case 79305:
                                            if (!str3.equals("PLE")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 55;
                                            }
                                            break;
                                        case 80618:
                                            if (!str3.equals("QX1")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 56;
                                            }
                                            break;
                                        case 88274:
                                            if (!str3.equals("Z80")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 57;
                                            }
                                            break;
                                        case 98846:
                                            if (!str3.equals("cv1")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 58;
                                            }
                                            break;
                                        case 98848:
                                            if (!str3.equals("cv3")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 59;
                                            }
                                            break;
                                        case 99329:
                                            if (!str3.equals("deb")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 60;
                                            }
                                            break;
                                        case 101481:
                                            if (!str3.equals("flo")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 61;
                                            }
                                            break;
                                        case 1513190:
                                            if (!str3.equals("1601")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 62;
                                            }
                                            break;
                                        case 1514184:
                                            if (!str3.equals("1713")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 63;
                                            }
                                            break;
                                        case 1514185:
                                            if (!str3.equals("1714")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 64;
                                            }
                                            break;
                                        case 2133089:
                                            if (!str3.equals("F01H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 65;
                                            }
                                            break;
                                        case 2133091:
                                            if (!str3.equals("F01J")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 66;
                                            }
                                            break;
                                        case 2133120:
                                            if (!str3.equals("F02H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 67;
                                            }
                                            break;
                                        case 2133151:
                                            if (!str3.equals("F03H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 68;
                                            }
                                            break;
                                        case 2133182:
                                            if (!str3.equals("F04H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 69;
                                            }
                                            break;
                                        case 2133184:
                                            if (!str3.equals("F04J")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 70;
                                            }
                                            break;
                                        case 2436959:
                                            if (!str3.equals("P681")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 71;
                                            }
                                            break;
                                        case 2463773:
                                            if (!str3.equals("Q350")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 72;
                                            }
                                            break;
                                        case 2464648:
                                            if (!str3.equals("Q427")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 73;
                                            }
                                            break;
                                        case 2689555:
                                            if (!str3.equals("XE2X")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 74;
                                            }
                                            break;
                                        case 3154429:
                                            if (!str3.equals("fugu")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 75;
                                            }
                                            break;
                                        case 3284551:
                                            if (!str3.equals("kate")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 76;
                                            }
                                            break;
                                        case 3351335:
                                            if (!str3.equals("mido")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 77;
                                            }
                                            break;
                                        case 3386211:
                                            if (!str3.equals("p212")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 78;
                                            }
                                            break;
                                        case 41325051:
                                            if (!str3.equals("MEIZU_M5")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 79;
                                            }
                                            break;
                                        case 51349633:
                                            if (!str3.equals("601LV")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 80;
                                            }
                                            break;
                                        case 51350594:
                                            if (!str3.equals("602LV")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 81;
                                            }
                                            break;
                                        case 55178625:
                                            if (!str3.equals("Aura_Note_2")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 82;
                                            }
                                            break;
                                        case 61542055:
                                            if (!str3.equals("A1601")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 83;
                                            }
                                            break;
                                        case 65355429:
                                            if (!str3.equals("E5643")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 84;
                                            }
                                            break;
                                        case 66214468:
                                            if (!str3.equals("F3111")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 85;
                                            }
                                            break;
                                        case 66214470:
                                            if (!str3.equals("F3113")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 86;
                                            }
                                            break;
                                        case 66214473:
                                            if (!str3.equals("F3116")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 87;
                                            }
                                            break;
                                        case 66215429:
                                            if (!str3.equals("F3211")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 88;
                                            }
                                            break;
                                        case 66215431:
                                            if (!str3.equals("F3213")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 89;
                                            }
                                            break;
                                        case 66215433:
                                            if (!str3.equals("F3215")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 90;
                                            }
                                            break;
                                        case 66216390:
                                            if (!str3.equals("F3311")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 91;
                                            }
                                            break;
                                        case 76402249:
                                            if (!str3.equals("PRO7S")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 92;
                                            }
                                            break;
                                        case 76404105:
                                            if (!str3.equals("Q4260")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 93;
                                            }
                                            break;
                                        case 76404911:
                                            if (!str3.equals("Q4310")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 94;
                                            }
                                            break;
                                        case 80963634:
                                            if (!str3.equals("V23GB")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 95;
                                            }
                                            break;
                                        case 82882791:
                                            if (!str3.equals("X3_HK")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 96;
                                            }
                                            break;
                                        case 98715550:
                                            if (!str3.equals("i9031")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 97;
                                            }
                                            break;
                                        case 101370885:
                                            if (!str3.equals("l5460")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 98;
                                            }
                                            break;
                                        case 102844228:
                                            if (!str3.equals("le_x6")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 99;
                                            }
                                            break;
                                        case 165221241:
                                            if (!str3.equals("A2016a40")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 100;
                                            }
                                            break;
                                        case 182191441:
                                            if (!str3.equals("CPY83_I00")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 101;
                                            }
                                            break;
                                        case 245388979:
                                            if (!str3.equals("marino_f")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 102;
                                            }
                                            break;
                                        case 287431619:
                                            if (!str3.equals("griffin")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 103;
                                            }
                                            break;
                                        case 307593612:
                                            if (!str3.equals("A7010a48")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 104;
                                            }
                                            break;
                                        case 308517133:
                                            if (!str3.equals("A7020a48")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 105;
                                            }
                                            break;
                                        case 316215098:
                                            if (!str3.equals("TB3-730F")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 106;
                                            }
                                            break;
                                        case 316215116:
                                            if (!str3.equals("TB3-730X")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 107;
                                            }
                                            break;
                                        case 316246811:
                                            if (!str3.equals("TB3-850F")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 108;
                                            }
                                            break;
                                        case 316246818:
                                            if (!str3.equals("TB3-850M")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 109;
                                            }
                                            break;
                                        case 407160593:
                                            if (!str3.equals("Pixi5-10_4G")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 110;
                                            }
                                            break;
                                        case 507412548:
                                            if (!str3.equals("QM16XE_U")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 111;
                                            }
                                            break;
                                        case 793982701:
                                            if (!str3.equals("GIONEE_WBL5708")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 112;
                                            }
                                            break;
                                        case 794038622:
                                            if (!str3.equals("GIONEE_WBL7365")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 113;
                                            }
                                            break;
                                        case 794040393:
                                            if (!str3.equals("GIONEE_WBL7519")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 114;
                                            }
                                            break;
                                        case 835649806:
                                            if (!str3.equals("manning")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 115;
                                            }
                                            break;
                                        case 917340916:
                                            if (!str3.equals("A7000plus")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 116;
                                            }
                                            break;
                                        case 958008161:
                                            if (!str3.equals("j2xlteins")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 117;
                                            }
                                            break;
                                        case 1060579533:
                                            if (!str3.equals("panell_d")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 118;
                                            }
                                            break;
                                        case 1150207623:
                                            if (!str3.equals("LS-5017")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 119;
                                            }
                                            break;
                                        case 1176899427:
                                            if (!str3.equals("itel_S41")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 120;
                                            }
                                            break;
                                        case 1280332038:
                                            if (!str3.equals("hwALE-H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 121;
                                            }
                                            break;
                                        case 1306947716:
                                            if (!str3.equals("EverStar_S")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 122;
                                            }
                                            break;
                                        case 1349174697:
                                            if (!str3.equals("htc_e56ml_dtul")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 123;
                                            }
                                            break;
                                        case 1522194893:
                                            if (!str3.equals("woods_f")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 124;
                                            }
                                            break;
                                        case 1691543273:
                                            if (!str3.equals("CPH1609")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 125;
                                            }
                                            break;
                                        case 1691544261:
                                            if (!str3.equals("CPH1715")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 126;
                                            }
                                            break;
                                        case 1709443163:
                                            if (!str3.equals("iball8735_9806")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 127;
                                            }
                                            break;
                                        case 1865889110:
                                            if (!str3.equals("santoni")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 128;
                                            }
                                            break;
                                        case 1906253259:
                                            if (!str3.equals("PB2-670M")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 129;
                                            }
                                            break;
                                        case 1977196784:
                                            if (!str3.equals("Infinix-X572")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 130;
                                            }
                                            break;
                                        case 2006372676:
                                            if (!str3.equals("BRAVIA_ATV3_4K")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 131;
                                            }
                                            break;
                                        case 2019281702:
                                            if (!str3.equals("DM-01K")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 132;
                                            }
                                            break;
                                        case 2029784656:
                                            if (!str3.equals("HWBLN-H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 133;
                                            }
                                            break;
                                        case 2030379515:
                                            if (!str3.equals("HWCAM-H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 134;
                                            }
                                            break;
                                        case 2033393791:
                                            if (!str3.equals("ASUS_X00AD_2")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 135;
                                            }
                                            break;
                                        case 2047190025:
                                            if (!str3.equals("ELUGA_Note")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 136;
                                            }
                                            break;
                                        case 2047252157:
                                            if (!str3.equals("ELUGA_Prim")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 137;
                                            }
                                            break;
                                        case 2048319463:
                                            if (!str3.equals("HWVNS-H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 138;
                                            }
                                            break;
                                        case 2048855701:
                                            if (!str3.equals("HWWAS-H")) {
                                                b13 = -1;
                                            } else {
                                                b13 = 139;
                                            }
                                            break;
                                        default:
                                            b13 = -1;
                                            break;
                                    }
                                    switch (b13) {
                                        default:
                                            if (str2.equals("JSN-L21")) {
                                            }
                                        case 0:
                                        case 1:
                                        case 2:
                                        case 3:
                                        case 4:
                                        case 5:
                                        case 6:
                                        case 7:
                                        case 8:
                                        case 9:
                                        case 10:
                                        case 11:
                                        case 12:
                                        case 13:
                                        case 14:
                                        case 15:
                                        case 16:
                                        case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                                        case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                                        case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                                        case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                                        case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                                        case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                                        case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                                        case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                                        case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                                        case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                                        case 27:
                                        case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                                        case 29:
                                        case RendererMetrics.SAMPLES /* 30 */:
                                        case 31:
                                        case 32:
                                        case 33:
                                        case 34:
                                        case 35:
                                        case 36:
                                        case 37:
                                        case 38:
                                        case 39:
                                        case RequestError.NETWORK_FAILURE /* 40 */:
                                        case RequestError.NO_DEV_KEY /* 41 */:
                                        case 42:
                                        case 43:
                                        case 44:
                                        case 45:
                                        case 46:
                                        case 47:
                                        case 48:
                                        case 49:
                                        case 50:
                                        case 51:
                                        case 52:
                                        case 53:
                                        case 54:
                                        case 55:
                                        case 56:
                                        case 57:
                                        case 58:
                                        case 59:
                                        case 60:
                                        case 61:
                                        case 62:
                                        case 63:
                                        case 64:
                                        case 65:
                                        case 66:
                                        case 67:
                                        case 68:
                                        case 69:
                                        case 70:
                                        case 71:
                                        case 72:
                                        case 73:
                                        case 74:
                                        case 75:
                                        case 76:
                                        case 77:
                                        case 78:
                                        case 79:
                                        case 80:
                                        case 81:
                                        case 82:
                                        case 83:
                                        case 84:
                                        case 85:
                                        case 86:
                                        case 87:
                                        case 88:
                                        case 89:
                                        case 90:
                                        case 91:
                                        case 92:
                                        case 93:
                                        case 94:
                                        case 95:
                                        case 96:
                                        case 97:
                                        case 98:
                                        case 99:
                                        case 100:
                                        case 101:
                                        case 102:
                                        case 103:
                                        case 104:
                                        case 105:
                                        case 106:
                                        case 107:
                                        case 108:
                                        case 109:
                                        case 110:
                                        case 111:
                                        case 112:
                                        case 113:
                                        case 114:
                                        case 115:
                                        case 116:
                                        case 117:
                                        case 118:
                                        case 119:
                                        case 120:
                                        case 121:
                                        case 122:
                                        case 123:
                                        case 124:
                                        case 125:
                                        case 126:
                                        case 127:
                                        case 128:
                                        case 129:
                                        case 130:
                                        case 131:
                                        case 132:
                                        case 133:
                                        case 134:
                                        case 135:
                                        case 136:
                                        case 137:
                                        case 138:
                                        case 139:
                                            z11 = true;
                                            break;
                                    }
                                }
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case 8:
                                z11 = true;
                                break;
                        }
                    }
                    f20990k2 = z11;
                    f20989j2 = true;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return f20990k2;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:19:0x003f  */
    public static int H0(c4.r rVar, k3.w wVar) {
        int i11 = wVar.f19019w;
        int i12 = wVar.f19020x;
        if (i11 != -1 && i12 != -1) {
            String str = wVar.f19012p;
            str.getClass();
            if ("video/dolby-vision".equals(str)) {
                Pair pairB = n3.g.b(wVar);
                if (pairB == null) {
                    str = "video/hevc";
                } else {
                    int iIntValue = ((Integer) pairB.first).intValue();
                    if (iIntValue == 512 || iIntValue == 1 || iIntValue == 2) {
                        str = "video/avc";
                    } else if (iIntValue == 1024) {
                        str = "video/av01";
                    } else {
                        str = "video/hevc";
                    }
                }
            }
            switch (str) {
                case "video/3gpp":
                case "video/av01":
                case "video/mp4v-es":
                case "video/x-vnd.on2.vp8":
                    return ((i11 * i12) * 3) / 4;
                case "video/hevc":
                    return Math.max(2097152, ((i11 * i12) * 3) / 4);
                case "video/avc":
                    HashSet hashSet = p0.f18769a;
                    String str2 = Build.MODEL;
                    if (!"BRAVIA 4K 2015".equals(str2) && (!"Amazon".equals(Build.MANUFACTURER) || (!"KFSOWI".equals(str2) && (!"AFTS".equals(str2) || !rVar.f4354f)))) {
                        return ((n3.l0.g(i12, 16) * n3.l0.g(i11, 16)) * 768) / 4;
                    }
                    break;
                case "video/x-vnd.on2.vp9":
                    return ((i11 * i12) * 3) / 8;
            }
        }
        return -1;
    }

    public static List I0(Context context, c4.k kVar, k3.w wVar, boolean z11, boolean z12) {
        String str = wVar.f19012p;
        if (str == null) {
            return w1.f14911w;
        }
        if (Build.VERSION.SDK_INT >= 26 && "video/dolby-vision".equals(str) && !k.a(context)) {
            String strC = c4.b0.c(wVar);
            List listB = strC == null ? w1.f14911w : kVar.b(strC, z11, z12);
            if (!listB.isEmpty()) {
                return listB;
            }
        }
        return c4.b0.g(kVar, wVar, z11, z12);
    }

    public static int J0(c4.r rVar, k3.w wVar) {
        int i11 = wVar.f19013q;
        List list = wVar.f19015s;
        if (i11 == -1) {
            return H0(rVar, wVar);
        }
        int size = list.size();
        int length = 0;
        for (int i12 = 0; i12 < size; i12++) {
            length += ((byte[]) list.get(i12)).length;
        }
        return wVar.f19013q + length;
    }

    @Override // c4.v
    public final boolean A0() {
        c4.r rVar = this.f4409x0;
        if (this.E1 != null && rVar != null) {
            String str = rVar.f4349a;
            if (str.equals("c2.mtk.avc.decoder") || str.equals("c2.mtk.hevc.decoder") || str.equals("c2.mtk.vp9.decoder")) {
                return true;
            }
        }
        return super.A0();
    }

    @Override // c4.v, v3.a
    public final void C(float f3, float f11) {
        super.C(f3, f11);
        m0 m0Var = this.E1;
        if (m0Var != null) {
            m0Var.E(f3);
        } else {
            this.f21004s1.g(f3);
        }
        b0 b0Var = this.f21009x1;
        if (b0Var != null) {
            b0Var.c(f3);
        }
    }

    @Override // c4.v
    public final int C0(c4.k kVar, k3.w wVar) {
        boolean z11;
        int i11 = 0;
        if (!u0.m(wVar.f19012p)) {
            return v3.a.b(0, 0, 0, 0);
        }
        int i12 = 1;
        boolean z12 = wVar.f19016t != null;
        Context context = this.f20999n1;
        List listI0 = I0(context, kVar, wVar, z12, false);
        if (z12 && listI0.isEmpty()) {
            listI0 = I0(context, kVar, wVar, false, false);
        }
        if (listI0.isEmpty()) {
            return v3.a.b(1, 0, 0, 0);
        }
        int i13 = wVar.T;
        if (i13 != 0 && i13 != 2) {
            return v3.a.b(2, 0, 0, 0);
        }
        c4.r rVar = (c4.r) listI0.get(0);
        boolean zE = rVar.e(context, wVar);
        if (!zE) {
            int i14 = 1;
            while (true) {
                if (i14 >= listI0.size()) {
                    z11 = true;
                    break;
                }
                c4.r rVar2 = (c4.r) listI0.get(i14);
                if (rVar2.e(context, wVar)) {
                    z11 = false;
                    zE = true;
                    rVar = rVar2;
                    break;
                }
                i14++;
            }
        } else {
            z11 = true;
            break;
        }
        int i15 = zE ? 4 : 3;
        int i16 = rVar.f(wVar) ? 16 : 8;
        int i17 = rVar.f4355g ? 64 : 0;
        int i18 = z11 ? 128 : 0;
        if (Build.VERSION.SDK_INT >= 26 && "video/dolby-vision".equals(wVar.f19012p) && !k.a(context)) {
            i18 = 256;
        }
        if (zE) {
            List listI1 = I0(context, kVar, wVar, z12, true);
            if (!listI1.isEmpty()) {
                HashMap map = c4.b0.f4304a;
                ArrayList arrayList = new ArrayList(listI1);
                Collections.sort(arrayList, new c4.w(i11, new c4.s(i12, context, wVar)));
                c4.r rVar3 = (c4.r) arrayList.get(0);
                if (rVar3.e(context, wVar) && rVar3.f(wVar)) {
                    i11 = 32;
                }
            }
        }
        return i15 | i16 | i11 | i17 | i18;
    }

    @Override // v3.a
    public final boolean F(long j6) {
        if (this.U0 == -9223372036854775807L || j6 < this.T1) {
            return false;
        }
        long j11 = this.f4383d1;
        return j11 == -9223372036854775807L || j6 > j11;
    }

    @Override // c4.v
    public final v3.d J(c4.r rVar, k3.w wVar, k3.w wVar2, boolean z11) {
        int i11;
        v3.d dVarB = rVar.b(wVar, wVar2);
        float f3 = wVar.B;
        float f11 = wVar2.B;
        int i12 = dVarB.f31929e;
        a50.i iVar = this.f21011z1;
        iVar.getClass();
        if (wVar2.f19019w > iVar.f400a || wVar2.f19020x > iVar.f401b) {
            i12 |= 256;
        }
        if (J0(rVar, wVar2) > iVar.f402c) {
            i12 |= 64;
        }
        if (this.N1 != Integer.MIN_VALUE && (i11 = Build.VERSION.SDK_INT) < 31 && ((i11 != 30 || Build.MODEL.startsWith("MiTV")) && f3 != -1.0f && f11 != -1.0f && (!rVar.f4354f || !z11))) {
            float fMax = Math.max(f11, f3) / Math.min(f11, f3);
            if (Math.abs(fMax - Math.round(fMax)) > 0.01f) {
                i12 |= 65536;
            }
        }
        int i13 = i12;
        return new v3.d(rVar.f4349a, wVar, wVar2, i13 != 0 ? 0 : dVarB.f31928d, i13);
    }

    @Override // c4.v
    public final c4.p K(IllegalStateException illegalStateException, c4.r rVar) {
        Surface surface = this.I1;
        h hVar = new h(illegalStateException, rVar);
        System.identityHashCode(surface);
        if (surface != null) {
            surface.isValid();
        }
        return hVar;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0056  */
    /* JADX WARN: Code duplicated, block: B:33:0x0059  */
    /* JADX WARN: Code duplicated, block: B:50:0x0092  */
    /* JADX WARN: Code duplicated, block: B:53:0x009d  */
    /* JADX WARN: Code duplicated, block: B:55:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:56:0x00ab  */
    /* JADX WARN: Code duplicated, block: B:57:0x00ac  */
    /* JADX WARN: Code duplicated, block: B:64:0x0070 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    public final Surface K0(c4.r rVar) {
        boolean z11;
        o oVar;
        int i11;
        RuntimeException runtimeException;
        Error error;
        m0 m0Var = this.E1;
        if (m0Var != null) {
            return m0Var.a();
        }
        Surface surface = this.I1;
        if (surface != null) {
            return surface;
        }
        if (Build.VERSION.SDK_INT >= 35 && rVar.f4356h) {
            return null;
        }
        oq.a.z(S0(rVar));
        p pVar = this.J1;
        if (pVar != null && pVar.f21020d != rVar.f4354f && pVar != null) {
            pVar.release();
            this.J1 = null;
        }
        if (this.J1 == null) {
            Context context = this.f20999n1;
            boolean z12 = rVar.f4354f;
            int i12 = 0;
            if (z12) {
                if (!p.h(context)) {
                    z11 = false;
                }
                oq.a.z(z11);
                oVar = new o("ExoPlayer:PlaceholderSurface", i12);
                if (z12) {
                    i11 = p.f21018v;
                } else {
                    i11 = 0;
                }
                oVar.start();
                Handler handler = new Handler(oVar.getLooper(), oVar);
                oVar.f21013e = handler;
                oVar.f21016w = new n3.l(handler);
                synchronized (oVar) {
                    oVar.f21013e.obtainMessage(1, i11, 0).sendToTarget();
                    while (((p) oVar.f21017x) == null && oVar.f21015v == null && oVar.f21014i == null) {
                        try {
                            oVar.wait();
                        } catch (InterruptedException unused) {
                            i12 = 1;
                        }
                    }
                }
                if (i12 != 0) {
                    Thread.currentThread().interrupt();
                }
                runtimeException = oVar.f21015v;
                if (runtimeException == null) {
                    throw runtimeException;
                }
                error = oVar.f21014i;
                if (error == null) {
                    throw error;
                }
                p pVar2 = (p) oVar.f21017x;
                pVar2.getClass();
                this.J1 = pVar2;
            } else {
                int i13 = p.f21018v;
            }
            z11 = true;
            oq.a.z(z11);
            oVar = new o("ExoPlayer:PlaceholderSurface", i12);
            if (z12) {
                i11 = p.f21018v;
            } else {
                i11 = 0;
            }
            oVar.start();
            Handler handler2 = new Handler(oVar.getLooper(), oVar);
            oVar.f21013e = handler2;
            oVar.f21016w = new n3.l(handler2);
            synchronized (oVar) {
                oVar.f21013e.obtainMessage(1, i11, 0).sendToTarget();
                while (((p) oVar.f21017x) == null) {
                    oVar.wait();
                }
                if (i12 != 0) {
                    Thread.currentThread().interrupt();
                }
                runtimeException = oVar.f21015v;
                if (runtimeException == null) {
                    throw runtimeException;
                }
                error = oVar.f21014i;
                if (error == null) {
                    throw error;
                }
                p pVar3 = (p) oVar.f21017x;
                pVar3.getClass();
                this.J1 = pVar3;
            }
        }
        return this.J1;
    }

    public final boolean L0(c4.r rVar) {
        if (this.E1 != null) {
            return true;
        }
        Surface surface = this.I1;
        if (surface == null || !surface.isValid()) {
            return (Build.VERSION.SDK_INT >= 35 && rVar.f4356h) || S0(rVar);
        }
        return true;
    }

    public final boolean M0(u3.d dVar) {
        if (k() || dVar.g(536870912)) {
            return true;
        }
        long j6 = this.T;
        return j6 == -9223372036854775807L || j6 - (dVar.y - this.f4381c1.f4369c) <= 100000;
    }

    public final void N0() {
        if (this.P1 > 0) {
            this.y.getClass();
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            long j6 = jElapsedRealtime - this.O1;
            int i11 = this.P1;
            k7.l lVar = this.f21001p1;
            Handler handler = (Handler) lVar.f19342d;
            if (handler != null) {
                handler.post(new io.sentry.android.core.a0(lVar, i11, j6, 1));
            }
            this.P1 = 0;
            this.O1 = jElapsedRealtime;
        }
    }

    public final void O0() {
        c4.n nVar;
        if (this.f20992b2 && (nVar = this.f4403q0) != null) {
            this.f20994d2 = new m(this, nVar);
            if (Build.VERSION.SDK_INT >= 33) {
                Bundle bundle = new Bundle();
                bundle.putInt("tunnel-peek", 1);
                nVar.setParameters(bundle);
            }
        }
    }

    public final void P0(c4.n nVar, int i11, long j6) {
        Surface surface;
        Trace.beginSection("releaseOutputBuffer");
        nVar.d(i11, j6);
        Trace.endSection();
        this.f4379b1.f28399f++;
        this.Q1 = 0;
        if (this.E1 == null) {
            z1 z1Var = this.Y1;
            boolean zEquals = z1Var.equals(z1.f19050d);
            k7.l lVar = this.f21001p1;
            if (!zEquals && !z1Var.equals(this.Z1)) {
                this.Z1 = z1Var;
                lVar.e0(z1Var);
            }
            a0 a0Var = this.f21004s1;
            boolean z11 = a0Var.f20896e != 3;
            a0Var.f20896e = 3;
            a0Var.k.getClass();
            a0Var.f20898g = n3.l0.S(SystemClock.elapsedRealtime());
            if (!z11 || (surface = this.I1) == null) {
                return;
            }
            Handler handler = (Handler) lVar.f19342d;
            if (handler != null) {
                handler.post(new app.p001rive.core.b(lVar, surface, SystemClock.elapsedRealtime(), 3));
            }
            this.L1 = true;
        }
    }

    public final void Q0(Object obj) {
        Handler handler;
        Surface surface = obj instanceof Surface ? (Surface) obj : null;
        Surface surface2 = this.I1;
        k7.l lVar = this.f21001p1;
        if (surface2 == surface) {
            if (surface != null) {
                z1 z1Var = this.Z1;
                if (z1Var != null) {
                    lVar.e0(z1Var);
                }
                Surface surface3 = this.I1;
                if (surface3 == null || !this.L1 || (handler = (Handler) lVar.f19342d) == null) {
                    return;
                }
                handler.post(new app.p001rive.core.b(lVar, surface3, SystemClock.elapsedRealtime(), 3));
                return;
            }
            return;
        }
        this.I1 = surface;
        m0 m0Var = this.E1;
        a0 a0Var = this.f21004s1;
        if (m0Var == null) {
            a0Var.f(surface);
        }
        boolean z11 = false;
        this.L1 = false;
        int i11 = this.J;
        c4.n nVar = this.f4403q0;
        if (nVar != null) {
            if (this.E1 == null) {
                c4.r rVar = this.f4409x0;
                rVar.getClass();
                if (!L0(rVar) || this.A1) {
                    q0();
                    a0();
                } else {
                    Surface surfaceK0 = K0(rVar);
                    if (surfaceK0 != null) {
                        nVar.setOutputSurface(surfaceK0);
                    } else {
                        if (Build.VERSION.SDK_INT < 35) {
                            throw new IllegalStateException();
                        }
                        nVar.k();
                    }
                    z11 = true;
                }
            } else {
                z11 = true;
            }
        }
        if (surface != null) {
            z1 z1Var2 = this.Z1;
            if (z1Var2 != null) {
                lVar.e0(z1Var2);
            }
        } else {
            this.Z1 = null;
            m0 m0Var2 = this.E1;
            if (m0Var2 != null) {
                m0Var2.i();
            }
        }
        if (i11 == 2) {
            m0 m0Var3 = this.E1;
            if (m0Var3 != null) {
                m0Var3.p(z11);
            } else {
                a0Var.c(z11);
            }
        }
        O0();
    }

    @Override // c4.v
    public final int R(u3.d dVar) {
        if (Build.VERSION.SDK_INT >= 34) {
            return ((this.S1 == null && !this.f20992b2) || dVar.y >= this.N || M0(dVar)) ? 0 : 32;
        }
        return 0;
    }

    public final boolean R0(long j6, long j11, boolean z11, boolean z12) {
        if (this.E1 != null && this.f21000o1) {
            j11 -= -this.f20996f2;
        }
        if (j6 < -500000 && !z11) {
            f4.e1 e1Var = this.K;
            e1Var.getClass();
            int iH = e1Var.h(j11 - this.M);
            if (iH != 0) {
                this.T1 = j11;
                boolean z13 = this.f21004s1.f20899h != -9223372036854775807L;
                PriorityQueue priorityQueue = this.f21010y1;
                Iterator it = priorityQueue.iterator();
                int i11 = 0;
                int i12 = 0;
                while (it.hasNext()) {
                    if (((Long) it.next()).longValue() < this.N || z13) {
                        i12++;
                    } else {
                        i11++;
                    }
                }
                priorityQueue.clear();
                if (z12) {
                    rr.d dVar = this.f4379b1;
                    int i13 = dVar.f28398e + iH;
                    dVar.f28400g += this.R1;
                    dVar.f28398e = i13 + i11 + i12;
                } else {
                    this.f4379b1.k++;
                    U0(iH + i11, this.R1);
                    this.f4379b1.f28398e += i12;
                }
                if (P()) {
                    a0();
                }
                m0 m0Var = this.E1;
                if (m0Var != null) {
                    m0Var.k(false);
                }
                return true;
            }
        }
        return false;
    }

    @Override // c4.v
    public final float S(float f3, k3.w wVar, k3.w[] wVarArr) {
        c4.r rVar;
        float fA = -1.0f;
        for (k3.w wVar2 : wVarArr) {
            float f11 = wVar2.B;
            if (f11 != -1.0f) {
                fA = Math.max(fA, f11);
            }
        }
        if (fA == -1.0f && this.f4403q0 != null) {
            g gVar = this.f21006u1;
            if (gVar.a() != -9223372036854775807L) {
                fA = 1.0E9f / gVar.a();
            }
        }
        float f12 = fA == -1.0f ? -1.0f : fA * f3;
        if (this.S1 == null || (rVar = this.f4409x0) == null) {
            return f12;
        }
        int i11 = wVar.f19019w;
        int i12 = wVar.f19020x;
        float f13 = -3.4028235E38f;
        if (rVar.f4357i) {
            float f14 = rVar.l;
            if (f14 != -3.4028235E38f && rVar.f4358j == i11 && rVar.k == i12) {
                f13 = f14;
            } else {
                float f15 = 1024.0f;
                if (!rVar.g(i11, 1024.0f, i12)) {
                    f13 = 0.0f;
                    while (true) {
                        float f16 = f15 - f13;
                        if (Math.abs(f16) <= 5.0f) {
                            break;
                        }
                        float f17 = (f16 / 2.0f) + f13;
                        if (rVar.g(i11, f17, i12)) {
                            f13 = f17;
                        } else {
                            f15 = f17;
                        }
                    }
                } else {
                    f13 = 1024.0f;
                }
                rVar.l = f13;
                rVar.f4358j = i11;
                rVar.k = i12;
            }
        }
        return f12 != -1.0f ? Math.max(f12, f13) : f13;
    }

    public final boolean S0(c4.r rVar) {
        if (this.f20992b2 || G0(rVar.f4349a)) {
            return false;
        }
        return !rVar.f4354f || p.h(this.f20999n1);
    }

    @Override // c4.v
    public final ArrayList T(c4.k kVar, k3.w wVar, boolean z11) {
        boolean z12 = this.f20992b2;
        Context context = this.f20999n1;
        List listI0 = I0(context, kVar, wVar, z11, z12);
        HashMap map = c4.b0.f4304a;
        ArrayList arrayList = new ArrayList(listI0);
        Collections.sort(arrayList, new c4.w(0, new c4.s(1, context, wVar)));
        return arrayList;
    }

    public final void T0(c4.n nVar, int i11) {
        Trace.beginSection("skipVideoBuffer");
        nVar.j(i11);
        Trace.endSection();
        this.f4379b1.f28400g++;
    }

    public final void U0(int i11, int i12) {
        rr.d dVar = this.f4379b1;
        dVar.f28402i += i11;
        int i13 = i11 + i12;
        dVar.f28401h += i13;
        this.P1 += i13;
        int i14 = this.Q1 + i13;
        this.Q1 = i14;
        dVar.f28403j = Math.max(i14, dVar.f28403j);
        int i15 = this.f21002q1;
        if (i15 <= 0 || this.P1 < i15) {
            return;
        }
        N0();
    }

    public final void V0(long j6) {
        rr.d dVar = this.f4379b1;
        dVar.l += j6;
        dVar.f28404m++;
        this.V1 += j6;
        this.W1++;
    }

    /* JADX WARN: Code duplicated, block: B:69:0x013c  */
    /* JADX WARN: Instruction removed from duplicated block: B:69:0x013c, please report this as an issue */
    @Override // c4.v
    public final b80.i0 W(c4.r rVar, k3.w wVar, MediaCrypto mediaCrypto, float f3) {
        k3.m mVar;
        int i11;
        a50.i iVar;
        Point point;
        MediaCodecInfo.VideoCapabilities videoCapabilities;
        byte b11;
        boolean z11;
        Pair pairB;
        int iH0;
        String str = rVar.f4351c;
        k3.w[] wVarArr = this.L;
        wVarArr.getClass();
        int i12 = wVar.f19019w;
        float f11 = wVar.B;
        k3.m mVar2 = wVar.H;
        int i13 = wVar.f19020x;
        int iJ0 = J0(rVar, wVar);
        if (wVarArr.length == 1) {
            if (iJ0 != -1 && (iH0 = H0(rVar, wVar)) != -1) {
                iJ0 = Math.min((int) (iJ0 * 1.5f), iH0);
            }
            iVar = new a50.i(i12, i13, iJ0);
            mVar = mVar2;
            i11 = i13;
        } else {
            int length = wVarArr.length;
            int iMax = i12;
            int iMax2 = i13;
            int i14 = 0;
            boolean z12 = false;
            while (i14 < length) {
                k3.w wVar2 = wVarArr[i14];
                k3.w[] wVarArr2 = wVarArr;
                if (mVar2 != null && wVar2.H == null) {
                    k3.v vVarA = wVar2.a();
                    vVarA.G = mVar2;
                    wVar2 = new k3.w(vVarA);
                }
                v3.d dVarB = rVar.b(wVar, wVar2);
                int i15 = length;
                int i16 = wVar2.f19020x;
                if (dVarB.f31928d != 0) {
                    int i17 = wVar2.f19019w;
                    b11 = -1;
                    z12 |= i17 == -1 || i16 == -1;
                    iMax = Math.max(iMax, i17);
                    iMax2 = Math.max(iMax2, i16);
                    iJ0 = Math.max(iJ0, J0(rVar, wVar2));
                } else {
                    b11 = -1;
                }
                length = i15;
                i14++;
                wVarArr = wVarArr2;
            }
            if (z12) {
                n3.b.l("MediaCodecVideoRenderer", "Resolutions unknown. Codec max resolution: " + iMax + "x" + iMax2);
                boolean z13 = i13 > i12;
                int i18 = z13 ? i13 : i12;
                boolean z14 = z13;
                int i19 = z13 ? i12 : i13;
                float f12 = i19 / i18;
                int i21 = 0;
                while (true) {
                    mVar = mVar2;
                    if (i21 < 9) {
                        int i22 = f20988i2[i21];
                        int i23 = i21;
                        int i24 = (int) (i22 * f12);
                        if (i22 > i18 && i24 > i19) {
                            if (!z14) {
                                i24 = i22;
                            }
                            if (!z14) {
                                i22 = i24;
                            }
                            int i25 = i19;
                            MediaCodecInfo.CodecCapabilities codecCapabilities = rVar.f4352d;
                            if (codecCapabilities == null || (videoCapabilities = codecCapabilities.getVideoCapabilities()) == null) {
                                point = null;
                            } else {
                                int widthAlignment = videoCapabilities.getWidthAlignment();
                                int heightAlignment = videoCapabilities.getHeightAlignment();
                                point = new Point(n3.l0.g(i24, widthAlignment) * widthAlignment, n3.l0.g(i22, heightAlignment) * heightAlignment);
                            }
                            if (point != null) {
                                i11 = i13;
                                if (rVar.g(point.x, f11, point.y)) {
                                }
                            } else {
                                i11 = i13;
                            }
                            i21 = i23 + 1;
                            i13 = i11;
                            mVar2 = mVar;
                            i19 = i25;
                            i18 = i18;
                        }
                        if (point != null) {
                            iMax = Math.max(iMax, point.x);
                            iMax2 = Math.max(iMax2, point.y);
                            k3.v vVarA2 = wVar.a();
                            vVarA2.f18965v = iMax;
                            vVarA2.f18966w = iMax2;
                            iJ0 = Math.max(iJ0, H0(rVar, new k3.w(vVarA2)));
                            n3.b.l("MediaCodecVideoRenderer", "Codec max resolution adjusted to: " + iMax + "x" + iMax2);
                        }
                    }
                    i11 = i13;
                    point = null;
                    if (point != null) {
                        iMax = Math.max(iMax, point.x);
                        iMax2 = Math.max(iMax2, point.y);
                        k3.v vVarA3 = wVar.a();
                        vVarA3.f18965v = iMax;
                        vVarA3.f18966w = iMax2;
                        iJ0 = Math.max(iJ0, H0(rVar, new k3.w(vVarA3)));
                        n3.b.l("MediaCodecVideoRenderer", "Codec max resolution adjusted to: " + iMax + "x" + iMax2);
                    }
                }
            } else {
                mVar = mVar2;
                i11 = i13;
            }
            iVar = new a50.i(iMax, iMax2, iJ0);
        }
        this.f21011z1 = iVar;
        int i26 = this.f20992b2 ? this.f20993c2 : 0;
        MediaFormat mediaFormat = new MediaFormat();
        mediaFormat.setString("mime", str);
        mediaFormat.setInteger("width", i12);
        mediaFormat.setInteger("height", i11);
        n3.b.k(mediaFormat, wVar.f19015s);
        if (f11 != -1.0f) {
            mediaFormat.setFloat("frame-rate", f11);
        }
        n3.b.j(mediaFormat, "rotation-degrees", wVar.C);
        if (mVar != null) {
            k3.m mVar3 = mVar;
            n3.b.j(mediaFormat, "color-transfer", mVar3.f18694c);
            n3.b.j(mediaFormat, "color-standard", mVar3.f18692a);
            n3.b.j(mediaFormat, "color-range", mVar3.f18693b);
            byte[] bArr = mVar3.f18695d;
            if (bArr != null) {
                mediaFormat.setByteBuffer("hdr-static-info", ByteBuffer.wrap(bArr));
            }
        }
        if ("video/dolby-vision".equals(wVar.f19012p) && (pairB = n3.g.b(wVar)) != null) {
            n3.b.j(mediaFormat, "profile", ((Integer) pairB.first).intValue());
        }
        mediaFormat.setInteger("max-width", iVar.f400a);
        mediaFormat.setInteger("max-height", iVar.f401b);
        n3.b.j(mediaFormat, "max-input-size", iVar.f402c);
        mediaFormat.setInteger("priority", 0);
        if (f3 != -1.0f) {
            mediaFormat.setFloat("operating-rate", f3);
        }
        if (this.f21003r1) {
            z11 = true;
            mediaFormat.setInteger("no-post-process", 1);
            mediaFormat.setInteger("auto-frc", 0);
        } else {
            z11 = true;
        }
        if (i26 != 0) {
            mediaFormat.setFeatureEnabled("tunneled-playback", z11);
            mediaFormat.setInteger("audio-session-id", i26);
        }
        if (Build.VERSION.SDK_INT >= 35) {
            mediaFormat.setInteger("importance", Math.max(0, -this.f20991a2));
        }
        H(mediaFormat);
        Surface surfaceK0 = K0(rVar);
        if (this.E1 != null && !n3.l0.O(this.f20999n1)) {
            mediaFormat.setInteger("allow-frame-drop", 0);
        }
        return new b80.i0(rVar, mediaFormat, wVar, surfaceK0, mediaCrypto, null, 2);
    }

    @Override // c4.v
    public final void X(u3.d dVar) {
        ByteBuffer byteBuffer = dVar.J;
        if (byteBuffer != null && byteBuffer.remaining() >= 7) {
            byte b11 = byteBuffer.get();
            short s4 = byteBuffer.getShort();
            short s11 = byteBuffer.getShort();
            byte b12 = byteBuffer.get();
            byte b13 = byteBuffer.get();
            byteBuffer.position(0);
            if (b11 == -75 && s4 == 60 && s11 == 1 && b12 == 4 && (b13 == 0 || b13 == 1)) {
                if (this.C1) {
                    byte[] bArr = new byte[byteBuffer.remaining()];
                    byteBuffer.get(bArr);
                    byteBuffer.position(0);
                    c4.n nVar = this.f4403q0;
                    nVar.getClass();
                    Bundle bundle = new Bundle();
                    bundle.putByteArray("hdr10-plus-info", bArr);
                    nVar.setParameters(bundle);
                    return;
                }
                return;
            }
            if (Build.VERSION.SDK_INT >= 37) {
                byte[] bArr2 = n3.g.f22324a;
                int iRemaining = byteBuffer.remaining();
                byte[] bArr3 = n3.g.f22327d;
                if (iRemaining < bArr3.length) {
                    return;
                }
                int iPosition = byteBuffer.position();
                for (int i11 = 0; i11 < bArr3.length; i11++) {
                    if (byteBuffer.get(iPosition + i11) != bArr3[i11]) {
                        return;
                    }
                }
                byteBuffer.position(5);
                int iRemaining2 = byteBuffer.remaining();
                byte[] bArr4 = new byte[iRemaining2];
                byteBuffer.get(bArr4);
                byteBuffer.position(0);
                boolean z11 = iRemaining2 > 0;
                this.D1 = z11;
                if (z11) {
                    Bundle bundle2 = new Bundle();
                    bundle2.putByteArray("hdr-st2094-50-info", bArr4);
                    c4.n nVar2 = this.f4403q0;
                    nVar2.getClass();
                    nVar2.setParameters(bundle2);
                }
            }
        }
    }

    @Override // c4.v, v3.a, v3.z0
    public final void c(int i11, Object obj) {
        if (i11 == 1) {
            Q0(obj);
            return;
        }
        if (i11 == 7) {
            obj.getClass();
            z zVar = (z) obj;
            this.f20995e2 = zVar;
            m0 m0Var = this.E1;
            if (m0Var != null) {
                m0Var.o(zVar);
                return;
            }
            return;
        }
        if (i11 == 10) {
            obj.getClass();
            int iIntValue = ((Integer) obj).intValue();
            if (this.f20993c2 != iIntValue) {
                this.f20993c2 = iIntValue;
                if (this.f20992b2) {
                    q0();
                    return;
                }
                return;
            }
            return;
        }
        if (i11 == 4) {
            obj.getClass();
            int iIntValue2 = ((Integer) obj).intValue();
            this.M1 = iIntValue2;
            c4.n nVar = this.f4403q0;
            if (nVar != null) {
                nVar.g(iIntValue2);
                return;
            }
            return;
        }
        if (i11 == 5) {
            obj.getClass();
            int iIntValue3 = ((Integer) obj).intValue();
            this.N1 = iIntValue3;
            m0 m0Var2 = this.E1;
            if (m0Var2 != null) {
                m0Var2.h(iIntValue3);
                return;
            }
            g0 g0Var = this.f21004s1.f20893b;
            if (g0Var.f20951i == iIntValue3) {
                return;
            }
            g0Var.f20951i = iIntValue3;
            g0Var.c(true);
            return;
        }
        if (i11 == 13) {
            obj.getClass();
            List list = (List) obj;
            if (list.equals(y1.f19042a)) {
                m0 m0Var3 = this.E1;
                if (m0Var3 == null || !m0Var3.isInitialized()) {
                    return;
                }
                this.E1.r();
                return;
            }
            this.H1 = list;
            m0 m0Var4 = this.E1;
            if (m0Var4 != null) {
                m0Var4.l(list);
                return;
            }
            return;
        }
        if (i11 == 14) {
            obj.getClass();
            n3.y yVar = (n3.y) obj;
            if (yVar.f22414a == 0 || yVar.f22415b == 0) {
                return;
            }
            this.K1 = yVar;
            m0 m0Var5 = this.E1;
            if (m0Var5 != null) {
                Surface surface = this.I1;
                surface.getClass();
                m0Var5.f(surface, yVar);
                return;
            }
            return;
        }
        switch (i11) {
            case 16:
                obj.getClass();
                this.f20991a2 = ((Integer) obj).intValue();
                c4.n nVar2 = this.f4403q0;
                if (nVar2 != null && Build.VERSION.SDK_INT >= 35) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("importance", Math.max(0, -this.f20991a2));
                    nVar2.setParameters(bundle);
                }
                break;
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                Surface surface2 = this.I1;
                Q0(null);
                obj.getClass();
                ((n) obj).c(1, surface2);
                break;
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                boolean z11 = this.S1 != null;
                e1 e1Var = (e1) obj;
                this.S1 = e1Var;
                if (z11 != (e1Var != null)) {
                    D0(this.f4404r0);
                }
                break;
            default:
                super.c(i11, obj);
                break;
        }
    }

    @Override // c4.v
    public final boolean c0(k3.w wVar) throws v3.i {
        m0 m0Var = this.E1;
        if (m0Var == null || m0Var.isInitialized()) {
            return true;
        }
        try {
            return this.E1.m(wVar);
        } catch (l0 e4) {
            throw f(e4, wVar, false, 7000);
        }
    }

    @Override // c4.v
    public final void d0(Exception exc) {
        n3.b.d("MediaCodecVideoRenderer", "Video codec error", exc);
        k7.l lVar = this.f21001p1;
        Handler handler = (Handler) lVar.f19342d;
        if (handler != null) {
            handler.post(new i0(lVar, exc, 3));
        }
    }

    @Override // c4.v
    public final void e0(long j6, long j11, String str) {
        String str2;
        boolean z11;
        MediaCodecInfo.CodecProfileLevel[] codecProfileLevelArr;
        k7.l lVar = this.f21001p1;
        Handler handler = (Handler) lVar.f19342d;
        if (handler != null) {
            str2 = str;
            handler.post(new i0(lVar, str2, j6, j11));
        } else {
            str2 = str;
        }
        this.A1 = G0(str2);
        c4.r rVar = this.f4409x0;
        rVar.getClass();
        boolean z12 = false;
        if (Build.VERSION.SDK_INT >= 29 && "video/x-vnd.on2.vp9".equals(rVar.f4350b)) {
            MediaCodecInfo.CodecCapabilities codecCapabilities = rVar.f4352d;
            if (codecCapabilities == null || (codecProfileLevelArr = codecCapabilities.profileLevels) == null) {
                codecProfileLevelArr = new MediaCodecInfo.CodecProfileLevel[0];
            }
            int length = codecProfileLevelArr.length;
            int i11 = 0;
            while (true) {
                if (i11 >= length) {
                    z11 = false;
                    break;
                } else {
                    if (codecProfileLevelArr[i11].profile == 16384) {
                        z11 = true;
                        break;
                    }
                    i11++;
                }
            }
        } else {
            z11 = false;
            break;
        }
        this.C1 = z11;
        if (Build.VERSION.SDK_INT < 37) {
            c4.r rVar2 = this.f4409x0;
            rVar2.getClass();
            if (rVar2.f4350b.equals("video/av01")) {
                z12 = true;
            }
        }
        this.B1 = z12;
        O0();
    }

    @Override // c4.v
    public final void f0(v3.c cVar) {
        k7.l lVar = this.f21001p1;
        Handler handler = (Handler) lVar.f19342d;
        if (handler != null) {
            handler.post(new io.sentry.react.c(13, lVar, cVar));
        }
    }

    @Override // v3.a
    public final void g() {
        m0 m0Var = this.E1;
        if (m0Var == null) {
            a0 a0Var = this.f21004s1;
            if (a0Var.f20896e == 0) {
                a0Var.f20896e = 1;
                return;
            }
            return;
        }
        int i11 = this.G1;
        if (i11 == 0 || i11 == 1) {
            this.G1 = 0;
        } else {
            m0Var.u();
        }
    }

    @Override // c4.v
    public final void g0(String str) {
        k7.l lVar = this.f21001p1;
        Handler handler = (Handler) lVar.f19342d;
        if (handler != null) {
            handler.post(new i0(lVar, str, 1));
        }
    }

    @Override // c4.v
    public final v3.d h0(v3.f0 f0Var) {
        v3.d dVarH0 = super.h0(f0Var);
        this.D1 = false;
        k3.w wVar = (k3.w) f0Var.f31990e;
        wVar.getClass();
        k7.l lVar = this.f21001p1;
        Handler handler = (Handler) lVar.f19342d;
        if (handler != null) {
            handler.post(new a6.m0(16, lVar, wVar, dVarH0));
        }
        b0 b0Var = this.f21009x1;
        if (b0Var != null) {
            b0Var.b();
        }
        return dVarH0;
    }

    @Override // c4.v
    public final void i0(k3.w wVar, MediaFormat mediaFormat) {
        int integer;
        int i11;
        c4.n nVar = this.f4403q0;
        if (nVar != null) {
            nVar.g(this.M1);
        }
        if (this.f20992b2) {
            i11 = wVar.f19019w;
            integer = wVar.f19020x;
        } else {
            mediaFormat.getClass();
            boolean z11 = mediaFormat.containsKey("crop-right") && mediaFormat.containsKey("crop-left") && mediaFormat.containsKey("crop-bottom") && mediaFormat.containsKey("crop-top");
            int integer2 = z11 ? (mediaFormat.getInteger("crop-right") - mediaFormat.getInteger("crop-left")) + 1 : mediaFormat.getInteger("width");
            integer = z11 ? (mediaFormat.getInteger("crop-bottom") - mediaFormat.getInteger("crop-top")) + 1 : mediaFormat.getInteger("height");
            i11 = integer2;
        }
        float f3 = wVar.E;
        int i12 = wVar.C;
        if (i12 == 90 || i12 == 270) {
            f3 = 1.0f / f3;
            int i13 = integer;
            integer = i11;
            i11 = i13;
        }
        this.Y1 = new z1(f3, i11, integer);
        m0 m0Var = this.E1;
        if (m0Var == null || !this.f20997g2) {
            float f11 = wVar.B;
            g gVar = this.f21006u1;
            gVar.f20939f = f11;
            gVar.f20934a.c();
            gVar.f20935b.c();
            gVar.f20936c = false;
            gVar.f20937d = -9223372036854775807L;
            gVar.f20938e = 0;
            gVar.c();
        } else {
            if (i11 <= 0 || integer <= 0) {
                return;
            }
            k3.v vVarA = wVar.a();
            vVarA.f18965v = i11;
            vVarA.f18966w = integer;
            vVarA.D = f3;
            k3.w wVar2 = new k3.w(vVarA);
            int i14 = this.G1;
            List list = this.H1;
            if (list == null) {
                hx.k0 k0Var = hx.m0.f14841e;
                list = w1.f14911w;
            }
            m0Var.t(wVar2, this.f4381c1.f4368b, i14, list);
            this.G1 = 2;
        }
        this.f20997g2 = false;
    }

    @Override // v3.a
    public final String j() {
        return "MediaCodecVideoRenderer";
    }

    @Override // c4.v
    public final void k0(long j6) {
        super.k0(j6);
        if (this.f20992b2) {
            return;
        }
        this.R1--;
    }

    @Override // v3.a
    public final boolean l() {
        if (!this.X0) {
            return false;
        }
        m0 m0Var = this.E1;
        return m0Var == null || m0Var.d();
    }

    @Override // c4.v
    public final void l0() {
        m0 m0Var = this.E1;
        if (m0Var != null) {
            m0Var.g();
            if (this.f20996f2 == -9223372036854775807L) {
                this.f20996f2 = this.f4381c1.f4368b;
            }
            this.E1.e(-this.f20996f2);
        } else {
            this.f21004s1.e(2);
        }
        this.f20997g2 = true;
        O0();
    }

    @Override // c4.v
    public final void m0(u3.d dVar) {
        ByteBuffer byteBuffer;
        int iA;
        int i11;
        ByteBuffer byteBuffer2;
        k3.m mVar;
        c4.r rVar = this.f4409x0;
        rVar.getClass();
        String str = rVar.f4350b;
        if (str.equals("video/av01") && (byteBuffer2 = dVar.f30832w) != null) {
            k3.w wVar = this.f4404r0;
            boolean z11 = (wVar == null || (mVar = wVar.H) == null || mVar.f18696e <= 8) ? false : true;
            if (this.D1 && !byteBuffer2.isReadOnly()) {
                a.b(byteBuffer2, false);
            } else if (z11 && this.B1 && !byteBuffer2.isReadOnly()) {
                a.b(byteBuffer2, true);
            }
            k7.c cVar = this.f21007v1;
            if (cVar != null && dVar.g(1)) {
                int iPosition = byteBuffer2.position();
                int iLimit = byteBuffer2.limit();
                byteBuffer2.limit(Math.min(iLimit, iPosition + 500));
                ByteBuffer byteBuffer3 = (ByteBuffer) cVar.f19321e;
                byteBuffer3.clear();
                byteBuffer3.put(byteBuffer2);
                byteBuffer3.flip();
                byteBuffer2.position(iPosition);
                byteBuffer2.limit(iLimit);
            }
        } else if (str.equals("video/hevc") && (byteBuffer = dVar.f30832w) != null && this.D1 && !byteBuffer.isReadOnly()) {
            ByteBuffer byteBuffer4 = dVar.f30832w;
            int iPosition2 = byteBuffer4.position();
            int iLimit2 = byteBuffer4.limit();
            if (iLimit2 - iPosition2 >= 4) {
                while (iPosition2 < iLimit2) {
                    int iA2 = a.a(byteBuffer4, iPosition2, iLimit2);
                    if (iA2 == iLimit2 || (iA = iA2 + 3) >= iLimit2 || ((i11 = (byteBuffer4.get(iA) & 126) >> 1) >= 0 && i11 <= 31)) {
                        break;
                    }
                    if (i11 == 39) {
                        int i12 = iA2 + 5;
                        iA = a.a(byteBuffer4, i12, iLimit2);
                        int i13 = 0;
                        while (i12 < iA) {
                            int i14 = 0;
                            while (i12 < iA) {
                                int i15 = byteBuffer4.get(i12) & 255;
                                if (i15 != 3 || i13 < 2) {
                                    i13 = i15 == 0 ? i13 + 1 : 0;
                                    int i16 = i12 + 1;
                                    i14 += i15;
                                    if (i15 != 255) {
                                        if (i14 == 4) {
                                            byteBuffer4.put(i12, (byte) -2);
                                        }
                                        i12 = i16;
                                        break;
                                    }
                                    i12 = i16;
                                } else {
                                    i12++;
                                    i13 = 0;
                                }
                            }
                            if (i12 >= iA) {
                                break;
                            }
                            int i17 = 0;
                            while (i12 < iA) {
                                int i18 = byteBuffer4.get(i12) & 255;
                                if (i18 != 3 || i13 < 2) {
                                    i13 = i18 == 0 ? i13 + 1 : 0;
                                    i12++;
                                    i17 += i18;
                                    if (i18 != 255) {
                                        break;
                                    }
                                } else {
                                    i12++;
                                    i13 = 0;
                                }
                            }
                            int i19 = 0;
                            while (i19 < i17 && i12 < iA) {
                                int i21 = i12 + 1;
                                int i22 = byteBuffer4.get(i12) & 255;
                                if (i22 != 3 || i13 < 2) {
                                    if (i22 == 0) {
                                        i13++;
                                    }
                                    i19++;
                                    i12 = i21;
                                } else {
                                    i19--;
                                }
                                i13 = 0;
                                i19++;
                                i12 = i21;
                            }
                        }
                    }
                    iPosition2 = iA;
                }
            }
        }
        this.f20998h2 = 0;
        int iR = R(dVar);
        if ((Build.VERSION.SDK_INT < 34 || (iR & 32) == 0) && !this.f20992b2) {
            this.R1++;
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x003d  */
    @Override // v3.a
    public final boolean n() {
        boolean zIsReady;
        boolean z11 = false;
        if (this.f4390h0 != null) {
            if (k()) {
                zIsReady = this.P;
            } else {
                f4.e1 e1Var = this.K;
                e1Var.getClass();
                zIsReady = e1Var.isReady();
            }
            if (zIsReady) {
                z11 = true;
            } else {
                if (this.H0 >= 0) {
                    z11 = true;
                } else if (this.F0 != -9223372036854775807L) {
                    this.y.getClass();
                    if (SystemClock.elapsedRealtime() < this.F0) {
                        z11 = true;
                    }
                }
            }
        }
        m0 m0Var = this.E1;
        if (m0Var != null) {
            return m0Var.q(z11);
        }
        if (z11 && (this.f4403q0 == null || this.f20992b2)) {
            return true;
        }
        return this.f21004s1.b(z11);
    }

    @Override // c4.v, v3.a
    public final void o() {
        rr.d dVar;
        k7.l lVar = this.f21001p1;
        this.Z1 = null;
        O0();
        this.L1 = false;
        this.f20994d2 = null;
        this.U1 = y0();
        try {
            super.o();
            dVar = this.f4379b1;
            lVar.getClass();
            synchronized (dVar) {
            }
        } finally {
            dVar = this.f4379b1;
            lVar.getClass();
            synchronized (dVar) {
                Handler handler = (Handler) lVar.f19342d;
                if (handler != null) {
                    handler.post(new io.sentry.react.c(12, lVar, dVar));
                }
                lVar.e0(z1.f19050d);
            }
        }
    }

    @Override // c4.v
    public final boolean o0(long j6, long j11, c4.n nVar, ByteBuffer byteBuffer, int i11, int i12, int i13, long j12, boolean z11, boolean z12, k3.w wVar) {
        g gVar;
        nVar.getClass();
        long j13 = j12 - this.f4381c1.f4369c;
        boolean z13 = this.f21004s1.f20899h != -9223372036854775807L;
        int i14 = 0;
        int i15 = 0;
        while (true) {
            PriorityQueue priorityQueue = this.f21010y1;
            Long l = (Long) priorityQueue.peek();
            gVar = this.f21006u1;
            if (l == null || l.longValue() >= j12) {
                break;
            }
            priorityQueue.poll();
            gVar.b(1000 * l.longValue());
            if (l.longValue() < this.N || z13) {
                i15++;
            } else {
                i14++;
            }
        }
        U0(i14, 0);
        this.f4379b1.f28398e += i15;
        gVar.b(j12 * 1000);
        m0 m0Var = this.E1;
        if (m0Var != null) {
            if (!z11 || z12) {
                return m0Var.j(j12, new j(this, nVar, i11, j13));
            }
            T0(nVar, i11);
            return true;
        }
        int iA = this.f21004s1.a(j12, j6, j11, this.f4381c1.f4368b, z11, z12, gVar.a(), gVar.f20941h, this.f21005t1);
        bl.h hVar = this.f21005t1;
        b0 b0Var = this.f21009x1;
        if (b0Var != null && iA != 5 && iA != 4) {
            b0Var.a(j12, hVar.f3773a);
        }
        if (iA == 0) {
            this.y.getClass();
            long jNanoTime = System.nanoTime();
            z zVar = this.f20995e2;
            if (zVar != null) {
                zVar.d(j13, jNanoTime, wVar, this.f4405s0);
            }
            P0(nVar, i11, jNanoTime);
            V0(hVar.f3773a);
            return true;
        }
        if (iA == 1) {
            long j14 = hVar.f3774b;
            long j15 = hVar.f3773a;
            if (j14 == this.X1) {
                T0(nVar, i11);
            } else {
                z zVar2 = this.f20995e2;
                if (zVar2 != null) {
                    zVar2.d(j13, j14, wVar, this.f4405s0);
                }
                P0(nVar, i11, j14);
            }
            V0(j15);
            this.X1 = j14;
            return true;
        }
        if (iA == 2) {
            Trace.beginSection("dropVideoBuffer");
            nVar.j(i11);
            Trace.endSection();
            U0(0, 1);
            V0(hVar.f3773a);
            return true;
        }
        if (iA == 3) {
            T0(nVar, i11);
            V0(hVar.f3773a);
            return true;
        }
        if (iA == 4 || iA == 5) {
            return false;
        }
        throw new IllegalStateException(String.valueOf(iA));
    }

    @Override // v3.a
    public final void p(boolean z11, boolean z12) {
        m0 m0Var;
        this.f4379b1 = new rr.d(1);
        d1 d1Var = this.f31887v;
        d1Var.getClass();
        boolean z13 = d1Var.f31935b;
        oq.a.z((z13 && this.f20993c2 == 0) ? false : true);
        if (this.f20992b2 != z13) {
            this.f20992b2 = z13;
            q0();
        }
        rr.d dVar = this.f4379b1;
        k7.l lVar = this.f21001p1;
        Handler handler = (Handler) lVar.f19342d;
        if (handler != null) {
            handler.post(new i0(lVar, dVar, 4));
        }
        boolean z14 = this.F1;
        a0 a0Var = this.f21004s1;
        if (!z14) {
            if (this.H1 != null && this.E1 == null) {
                q qVar = new q(this.f20999n1, a0Var);
                qVar.f21026d = true;
                long j6 = this.f21008w1;
                qVar.f21029g = j6 != -9223372036854775807L ? -j6 : -9223372036854775807L;
                n3.e0 e0Var = this.y;
                e0Var.getClass();
                qVar.f21027e = e0Var;
                oq.a.z(!qVar.f21028f);
                if (qVar.f21025c == null) {
                    qVar.f21025c = new t();
                }
                v vVar = new v(qVar);
                qVar.f21028f = true;
                if (1 >= vVar.f21053p) {
                    vVar.f21053p = 1;
                }
                SparseArray sparseArray = vVar.f21042c;
                if (n3.l0.l(sparseArray, 0)) {
                    m0Var = (m0) sparseArray.get(0);
                } else {
                    r rVar = new r(vVar, vVar.f21040a);
                    vVar.f21046g.add(rVar);
                    sparseArray.put(0, rVar);
                    m0Var = rVar;
                }
                this.E1 = m0Var;
            }
            this.F1 = true;
        }
        m0 m0Var2 = this.E1;
        if (m0Var2 == null) {
            n3.e0 e0Var2 = this.y;
            e0Var2.getClass();
            a0Var.k = e0Var2;
            a0Var.e(!z12 ? 1 : 0);
            return;
        }
        m0Var2.s(new i(this));
        z zVar = this.f20995e2;
        if (zVar != null) {
            this.E1.o(zVar);
        }
        if (this.I1 != null && !this.K1.equals(n3.y.f22413c)) {
            this.E1.f(this.I1, this.K1);
        }
        this.E1.h(this.N1);
        this.E1.E(this.f4401o0);
        List list = this.H1;
        if (list != null) {
            this.E1.l(list);
        }
        this.G1 = !z12 ? 1 : 0;
        this.f4387f1 = true;
    }

    @Override // c4.v, v3.a
    public final void q(long j6, boolean z11, boolean z12) {
        m0 m0Var = this.E1;
        if (m0Var != null && !z11) {
            m0Var.k(true);
        }
        if (z12) {
            this.T1 = j6;
        }
        super.q(j6, z11, z12);
        m0 m0Var2 = this.E1;
        a0 a0Var = this.f21004s1;
        if (m0Var2 == null) {
            a0Var.f20893b.b();
            a0Var.f20897f = -9223372036854775807L;
            a0Var.f20896e = Math.min(a0Var.f20896e, 1);
            a0Var.f20899h = -9223372036854775807L;
            a0Var.f20902m = false;
        }
        b0 b0Var = this.f21009x1;
        if (b0Var != null) {
            b0Var.b();
        }
        if (z11) {
            m0 m0Var3 = this.E1;
            if (m0Var3 != null) {
                m0Var3.p(false);
            } else {
                a0Var.c(false);
            }
        }
        O0();
        this.Q1 = 0;
    }

    @Override // v3.a
    public final void r() {
        m0 m0Var = this.E1;
        if (m0Var == null || !this.f21000o1) {
            return;
        }
        m0Var.release();
    }

    @Override // c4.v
    public final void r0() {
        m0 m0Var = this.E1;
        if (m0Var != null) {
            m0Var.g();
        } else {
            long j6 = this.f4381c1.f4374h;
        }
    }

    @Override // v3.a
    public final void s() {
        try {
            try {
                this.K0 = false;
                s0();
                q0();
                y3.g gVar = this.f4396k0;
                if (gVar != null) {
                    gVar.f(null);
                }
                this.f4396k0 = null;
                this.F1 = false;
                this.f20996f2 = -9223372036854775807L;
                this.D1 = false;
                p pVar = this.J1;
                if (pVar != null) {
                    pVar.release();
                    this.J1 = null;
                }
            } catch (Throwable th2) {
                y3.g gVar2 = this.f4396k0;
                if (gVar2 != null) {
                    gVar2.f(null);
                }
                this.f4396k0 = null;
                throw th2;
            }
        } catch (Throwable th3) {
            this.F1 = false;
            this.f20996f2 = -9223372036854775807L;
            this.D1 = false;
            p pVar2 = this.J1;
            if (pVar2 != null) {
                pVar2.release();
                this.J1 = null;
            }
            throw th3;
        }
    }

    @Override // v3.a
    public final void t() {
        this.P1 = 0;
        this.y.getClass();
        this.O1 = SystemClock.elapsedRealtime();
        this.V1 = 0L;
        this.W1 = 0;
        m0 m0Var = this.E1;
        if (m0Var != null) {
            m0Var.c();
        } else {
            this.f21004s1.d();
        }
    }

    @Override // c4.v
    public final void t0() {
        super.t0();
        this.f21010y1.clear();
        this.R1 = 0;
        this.f20998h2 = 0;
        this.U1 = false;
        k7.c cVar = this.f21007v1;
        if (cVar != null) {
            cVar.f19322i = null;
            ByteBuffer byteBuffer = (ByteBuffer) cVar.f19321e;
            byteBuffer.position(byteBuffer.limit());
        }
    }

    @Override // v3.a
    public final void u() {
        N0();
        int i11 = this.W1;
        if (i11 != 0) {
            long j6 = this.V1;
            k7.l lVar = this.f21001p1;
            Handler handler = (Handler) lVar.f19342d;
            if (handler != null) {
                handler.post(new i0(lVar, j6, i11));
            }
            this.V1 = 0L;
            this.W1 = 0;
        }
        m0 m0Var = this.E1;
        if (m0Var != null) {
            m0Var.b();
        } else {
            a0 a0Var = this.f21004s1;
            a0Var.f20895d = false;
            a0Var.f20899h = -9223372036854775807L;
            g0 g0Var = a0Var.f20893b;
            g0Var.f20946d = false;
            d0 d0Var = g0Var.f20945c;
            if (d0Var != null) {
                d0Var.b();
            }
            g0Var.a();
        }
        b0 b0Var = this.f21009x1;
        if (b0Var != null) {
            b0Var.b();
        }
    }

    @Override // c4.v, v3.a
    public final void v(k3.w[] wVarArr, long j6, long j11, f4.d0 d0Var) {
        super.v(wVarArr, j6, j11, d0Var);
        b0 b0Var = this.f21009x1;
        if (b0Var != null) {
            b0Var.b();
        }
    }

    /* JADX WARN: Code duplicated, block: B:20:0x003b  */
    /* JADX WARN: Code duplicated, block: B:90:0x013e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:91:0x0140  */
    @Override // c4.v
    public final boolean x0(u3.d dVar) {
        boolean z11;
        ByteBuffer byteBuffer;
        int iLimit;
        o3.q qVar;
        com.facebook.react.devsupport.i iVar;
        boolean z12 = false;
        if (!M0(dVar)) {
            long j6 = dVar.y;
            boolean z13 = j6 < this.N;
            b0 b0Var = this.f21009x1;
            if (b0Var != null) {
                long j11 = b0Var.f20904a;
                long j12 = j11 == -9223372036854775807L ? -9223372036854775807L : (long) (((j6 - j11) * b0Var.f20906c) + b0Var.f20905b);
                if (j12 == -9223372036854775807L || j12 >= this.f21008w1) {
                    z11 = false;
                } else {
                    z11 = true;
                }
            } else {
                z11 = false;
            }
            if ((z13 || z11) && !dVar.g(268435456)) {
                if (!dVar.g(67108864)) {
                    k7.c cVar = this.f21007v1;
                    if (cVar != null) {
                        ByteBuffer byteBuffer2 = (ByteBuffer) cVar.f19321e;
                        c4.r rVar = this.f4409x0;
                        rVar.getClass();
                        if (rVar.f4350b.equals("video/av01") && (byteBuffer = dVar.f30832w) != null) {
                            boolean z14 = z13 || this.f20998h2 <= 0;
                            ByteBuffer byteBufferAsReadOnlyBuffer = byteBuffer.asReadOnlyBuffer();
                            byteBufferAsReadOnlyBuffer.flip();
                            if (byteBuffer2.hasRemaining()) {
                                cVar.r(o3.n.r(byteBuffer2));
                                byteBuffer2.position(byteBuffer2.limit());
                            }
                            ArrayList arrayListR = o3.n.r(byteBufferAsReadOnlyBuffer);
                            cVar.r(arrayListR);
                            int size = arrayListR.size() - 1;
                            int i11 = 0;
                            while (size >= 0) {
                                o3.p pVar = (o3.p) arrayListR.get(size);
                                int i12 = pVar.f24090a;
                                if (i12 != 2 && i12 != 15) {
                                    if ((i12 == 3 && !z14) || ((i12 != 6 && i12 != 3) || (qVar = (o3.q) cVar.f19322i) == null)) {
                                        break;
                                    }
                                    try {
                                        iVar = new com.facebook.react.devsupport.i(qVar, pVar);
                                    } catch (o3.o unused) {
                                        iVar = null;
                                    }
                                    if (iVar == null || iVar.f5962a) {
                                        break;
                                    }
                                }
                                if (((o3.p) arrayListR.get(size)).f24090a == 6 || ((o3.p) arrayListR.get(size)).f24090a == 3) {
                                    i11++;
                                }
                                size--;
                            }
                            if (i11 > 1 || size + 1 >= 8) {
                                iLimit = byteBufferAsReadOnlyBuffer.limit();
                            } else {
                                iLimit = size >= 0 ? ((o3.p) arrayListR.get(size)).f24091b.limit() : byteBufferAsReadOnlyBuffer.position();
                            }
                            if (iLimit == 0) {
                                dVar.o();
                            } else if (iLimit != byteBufferAsReadOnlyBuffer.limit()) {
                                a50.i iVar2 = this.f21011z1;
                                iVar2.getClass();
                                if (iVar2.f402c + iLimit < byteBufferAsReadOnlyBuffer.capacity() && !dVar.g(1073741824)) {
                                    ByteBuffer byteBuffer3 = dVar.f30832w;
                                    byteBuffer3.getClass();
                                    byteBuffer3.position(iLimit);
                                }
                            }
                        }
                    }
                    if (z12) {
                        if (!z13) {
                            this.f20998h2++;
                        }
                        this.f21010y1.add(Long.valueOf(dVar.y));
                    }
                    return z12;
                }
                dVar.o();
                z12 = true;
                if (z12) {
                    if (!z13) {
                        this.f20998h2++;
                    }
                    this.f21010y1.add(Long.valueOf(dVar.y));
                }
                return z12;
            }
        }
        return false;
    }

    @Override // c4.v, v3.a
    public final void y(long j6, long j11) throws v3.i {
        m0 m0Var = this.E1;
        if (m0Var != null) {
            try {
                m0Var.n(j6, j11);
            } catch (l0 e4) {
                throw f(e4, e4.f20984d, false, 7001);
            }
        }
        super.y(j6, j11);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002c  */
    @Override // c4.v
    public final boolean y0() {
        boolean z11;
        if (this.R0) {
            k3.w wVar = this.f4404r0;
            long j6 = this.T;
            if (j6 != -9223372036854775807L) {
                if (this.f4391h1 + 1 + j6 > Long.MAX_VALUE - (this.f4381c1.f4369c + j6)) {
                    z11 = true;
                } else {
                    z11 = false;
                }
            } else {
                z11 = true;
            }
            if (this.S1 == null || this.U1 || this.f20992b2 || ((wVar != null && wVar.f19014r > 0) || z11 || this.f4381c1.f4374h != -9223372036854775807L)) {
                return true;
            }
        }
        return false;
    }

    @Override // c4.v
    public final boolean z0(c4.r rVar) {
        return L0(rVar);
    }
}
