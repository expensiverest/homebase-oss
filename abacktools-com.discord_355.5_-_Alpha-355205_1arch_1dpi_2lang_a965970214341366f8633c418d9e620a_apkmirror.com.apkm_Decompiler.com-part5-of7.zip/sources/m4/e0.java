package m4;

import android.view.Choreographer;
import android.view.Display;

/* JADX INFO: loaded from: classes.dex */
public final class e0 extends d0 implements Choreographer.FrameCallback {
    @Override // m4.d0
    public final void a() {
        long refreshRate;
        this.f20911e.registerDisplayListener(this, n3.l0.r(null));
        this.f20910d.removeFrameCallback(this);
        this.f20910d.postFrameCallback(this);
        Display display = this.f20911e.getDisplay(0);
        if (display != null) {
            refreshRate = (long) (1.0E9d / ((double) display.getRefreshRate()));
        } else {
            n3.b.l("VideoFrameReleaseHelper", "Unable to query display refresh rate");
            refreshRate = -9223372036854775807L;
        }
        this.f20913v = refreshRate;
    }

    @Override // m4.d0
    public final void b() {
        this.f20911e.unregisterDisplayListener(this);
        this.f20910d.removeFrameCallback(this);
        this.f20912i = -9223372036854775807L;
        this.f20913v = -9223372036854775807L;
    }

    @Override // android.view.Choreographer.FrameCallback
    public final void doFrame(long j6) {
        this.f20912i = j6;
        this.f20910d.removeFrameCallback(this);
        this.f20910d.postFrameCallbackDelayed(this, 500L);
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayChanged(int i11) {
        long refreshRate;
        if (i11 == 0) {
            this.f20910d.removeFrameCallback(this);
            this.f20910d.postFrameCallback(this);
            Display display = this.f20911e.getDisplay(0);
            if (display != null) {
                refreshRate = (long) (1.0E9d / ((double) display.getRefreshRate()));
            } else {
                n3.b.l("VideoFrameReleaseHelper", "Unable to query display refresh rate");
                refreshRate = -9223372036854775807L;
            }
            this.f20913v = refreshRate;
        }
    }
}
