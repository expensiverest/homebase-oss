package m4;

import android.media.MediaFormat;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements z {
    @Override // m4.z
    public final void d(long j6, long j11, k3.w wVar, MediaFormat mediaFormat) {
    }
}
