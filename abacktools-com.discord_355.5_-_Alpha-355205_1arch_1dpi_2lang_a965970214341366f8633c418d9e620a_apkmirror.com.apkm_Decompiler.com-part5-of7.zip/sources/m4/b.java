package m4;

import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements Executor {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20903d;

    public /* synthetic */ b(int i11) {
        this.f20903d = i11;
    }

    private final void a(Runnable runnable) {
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable p11) {
        switch (this.f20903d) {
            case 0:
                break;
            case 1:
                p11.run();
                break;
            case 2:
                q.a.T().f26315d.f26318e.execute(p11);
                break;
            case 3:
                p11.run();
                break;
            case 4:
                kotlin.jvm.internal.k.g(p11, "p0");
                p11.run();
                break;
            case 5:
                kotlin.jvm.internal.k.g(p11, "p0");
                p11.run();
                break;
            case 6:
                kotlin.jvm.internal.k.g(p11, "p0");
                p11.run();
                break;
            case 7:
                kotlin.jvm.internal.k.g(p11, "p0");
                p11.run();
                break;
            case 8:
                kotlin.jvm.internal.k.g(p11, "p0");
                p11.run();
                break;
            case 9:
                vg.a.a().post(p11);
                break;
            default:
                p11.run();
                break;
        }
    }
}
