package m4;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f20924a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f20925b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f20926c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f20927d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f20928e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f20929f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f20930g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean[] f20931h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20932i;

    public f(int i11) {
        this.f20924a = i11;
        switch (i11) {
            case 1:
                this.f20931h = new boolean[15];
                break;
            default:
                this.f20931h = new boolean[15];
                break;
        }
    }

    public final boolean a() {
        switch (this.f20924a) {
            case 0:
                return this.f20928e > 15 && this.f20932i == 0;
            default:
                return this.f20928e > 15 && this.f20932i == 0;
        }
    }

    public final void b(long j6) {
        switch (this.f20924a) {
            case 0:
                long j11 = this.f20928e;
                if (j11 == 0) {
                    this.f20925b = j6;
                } else if (j11 == 1) {
                    long j12 = j6 - this.f20925b;
                    this.f20926c = j12;
                    this.f20930g = j12;
                    this.f20929f = 1L;
                } else {
                    long j13 = j6 - this.f20927d;
                    int i11 = (int) (j11 % 15);
                    long jAbs = Math.abs(j13 - this.f20926c);
                    boolean[] zArr = this.f20931h;
                    if (jAbs <= 1000000) {
                        this.f20929f++;
                        this.f20930g += j13;
                        if (zArr[i11]) {
                            zArr[i11] = false;
                            this.f20932i--;
                        }
                    } else if (!zArr[i11]) {
                        zArr[i11] = true;
                        this.f20932i++;
                    }
                }
                this.f20928e++;
                this.f20927d = j6;
                break;
            default:
                long j14 = this.f20928e;
                if (j14 == 0) {
                    this.f20925b = j6;
                } else if (j14 == 1) {
                    long j15 = j6 - this.f20925b;
                    this.f20926c = j15;
                    this.f20930g = j15;
                    this.f20929f = 1L;
                } else {
                    long j16 = j6 - this.f20927d;
                    int i12 = (int) (j14 % 15);
                    long jAbs2 = Math.abs(j16 - this.f20926c);
                    boolean[] zArr2 = this.f20931h;
                    if (jAbs2 <= 1000000) {
                        this.f20929f++;
                        this.f20930g += j16;
                        if (zArr2[i12]) {
                            zArr2[i12] = false;
                            this.f20932i--;
                        }
                    } else if (!zArr2[i12]) {
                        zArr2[i12] = true;
                        this.f20932i++;
                    }
                }
                this.f20928e++;
                this.f20927d = j6;
                break;
        }
    }

    public final void c() {
        switch (this.f20924a) {
            case 0:
                this.f20928e = 0L;
                this.f20929f = 0L;
                this.f20930g = 0L;
                this.f20932i = 0;
                Arrays.fill(this.f20931h, false);
                break;
            default:
                this.f20928e = 0L;
                this.f20929f = 0L;
                this.f20930g = 0L;
                this.f20932i = 0;
                Arrays.fill(this.f20931h, false);
                break;
        }
    }
}
