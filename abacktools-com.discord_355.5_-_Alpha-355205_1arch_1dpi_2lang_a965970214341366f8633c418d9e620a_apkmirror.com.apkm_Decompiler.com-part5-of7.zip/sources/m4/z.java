package m4;

import android.media.MediaFormat;

/* JADX INFO: loaded from: classes.dex */
public interface z {
    void d(long j6, long j11, k3.w wVar, MediaFormat mediaFormat);
}
