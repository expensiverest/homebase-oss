package m4;

import k3.z1;

/* JADX INFO: loaded from: classes.dex */
public interface k0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j0 f20975a = new j0();

    default void a() {
    }

    default void c() {
    }

    default void onFirstFrameRendered() {
    }

    default void b(z1 z1Var) {
    }
}
