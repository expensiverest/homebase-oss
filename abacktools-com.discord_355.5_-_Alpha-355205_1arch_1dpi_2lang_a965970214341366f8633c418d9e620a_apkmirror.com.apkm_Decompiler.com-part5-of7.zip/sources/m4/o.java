package m4;

import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.view.Surface;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class o extends HandlerThread implements Handler.Callback {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21012d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f21013e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Error f21014i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public RuntimeException f21015v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Object f21016w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Surface f21017x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o(String str, int i11) {
        super(str);
        this.f21012d = i11;
    }

    public final void a(int i11) throws qt.f {
        EGLSurface eGLSurface;
        EGLSurface eGLSurface2;
        switch (this.f21012d) {
            case 0:
                ((n3.l) this.f21016w).getClass();
                n3.l lVar = (n3.l) this.f21016w;
                int[] iArr = lVar.f22353e;
                EGLDisplay eGLDisplayEglGetDisplay = EGL14.eglGetDisplay(0);
                n3.e.c("eglGetDisplay failed", eGLDisplayEglGetDisplay != null);
                int[] iArr2 = new int[2];
                n3.e.c("eglInitialize failed", EGL14.eglInitialize(eGLDisplayEglGetDisplay, iArr2, 0, iArr2, 1));
                lVar.f22354i = eGLDisplayEglGetDisplay;
                EGLConfig[] eGLConfigArr = new EGLConfig[1];
                int[] iArr3 = new int[1];
                boolean zEglChooseConfig = EGL14.eglChooseConfig(eGLDisplayEglGetDisplay, n3.l.y, 0, eGLConfigArr, 0, 1, iArr3, 0);
                boolean z11 = zEglChooseConfig && iArr3[0] > 0 && eGLConfigArr[0] != null;
                Object[] objArr = {Boolean.valueOf(zEglChooseConfig), Integer.valueOf(iArr3[0]), eGLConfigArr[0]};
                String str = n3.l0.f22358a;
                n3.e.c(String.format(Locale.US, "eglChooseConfig failed: success=%b, numConfigs[0]=%d, configs[0]=%s", objArr), z11);
                EGLConfig eGLConfig = eGLConfigArr[0];
                EGLContext eGLContextEglCreateContext = EGL14.eglCreateContext(lVar.f22354i, eGLConfig, EGL14.EGL_NO_CONTEXT, i11 == 0 ? new int[]{12440, 2, 12344} : new int[]{12440, 2, 12992, 1, 12344}, 0);
                n3.e.c("eglCreateContext failed", eGLContextEglCreateContext != null);
                lVar.f22355v = eGLContextEglCreateContext;
                EGLDisplay eGLDisplay = lVar.f22354i;
                if (i11 == 1) {
                    eGLSurface = EGL14.EGL_NO_SURFACE;
                } else {
                    EGLSurface eGLSurfaceEglCreatePbufferSurface = EGL14.eglCreatePbufferSurface(eGLDisplay, eGLConfig, i11 == 2 ? new int[]{12375, 1, 12374, 1, 12992, 1, 12344} : new int[]{12375, 1, 12374, 1, 12344}, 0);
                    n3.e.c("eglCreatePbufferSurface failed", eGLSurfaceEglCreatePbufferSurface != null);
                    eGLSurface = eGLSurfaceEglCreatePbufferSurface;
                }
                n3.e.c("eglMakeCurrent failed", EGL14.eglMakeCurrent(eGLDisplay, eGLSurface, eGLSurface, eGLContextEglCreateContext));
                lVar.f22356w = eGLSurface;
                GLES20.glGenTextures(1, iArr, 0);
                n3.e.b();
                SurfaceTexture surfaceTexture = new SurfaceTexture(iArr[0]);
                lVar.f22357x = surfaceTexture;
                surfaceTexture.setOnFrameAvailableListener(lVar);
                SurfaceTexture surfaceTexture2 = ((n3.l) this.f21016w).f22357x;
                surfaceTexture2.getClass();
                this.f21017x = new p(this, surfaceTexture2, i11 != 0);
                break;
            default:
                ((qt.c) this.f21016w).getClass();
                qt.c cVar = (qt.c) this.f21016w;
                int[] iArr4 = cVar.f27256e;
                EGLDisplay eGLDisplayEglGetDisplay2 = EGL14.eglGetDisplay(0);
                qt.a.i("eglGetDisplay failed", eGLDisplayEglGetDisplay2 != null);
                int[] iArr5 = new int[2];
                qt.a.i("eglInitialize failed", EGL14.eglInitialize(eGLDisplayEglGetDisplay2, iArr5, 0, iArr5, 1));
                cVar.f27257i = eGLDisplayEglGetDisplay2;
                EGLConfig[] eGLConfigArr2 = new EGLConfig[1];
                int[] iArr6 = new int[1];
                boolean zEglChooseConfig2 = EGL14.eglChooseConfig(eGLDisplayEglGetDisplay2, qt.c.y, 0, eGLConfigArr2, 0, 1, iArr6, 0);
                boolean z12 = zEglChooseConfig2 && iArr6[0] > 0 && eGLConfigArr2[0] != null;
                Object[] objArr2 = {Boolean.valueOf(zEglChooseConfig2), Integer.valueOf(iArr6[0]), eGLConfigArr2[0]};
                int i12 = qt.x.f27318a;
                qt.a.i(String.format(Locale.US, "eglChooseConfig failed: success=%b, numConfigs[0]=%d, configs[0]=%s", objArr2), z12);
                EGLConfig eGLConfig2 = eGLConfigArr2[0];
                EGLContext eGLContextEglCreateContext2 = EGL14.eglCreateContext(cVar.f27257i, eGLConfig2, EGL14.EGL_NO_CONTEXT, i11 == 0 ? new int[]{12440, 2, 12344} : new int[]{12440, 2, 12992, 1, 12344}, 0);
                qt.a.i("eglCreateContext failed", eGLContextEglCreateContext2 != null);
                cVar.f27258v = eGLContextEglCreateContext2;
                EGLDisplay eGLDisplay2 = cVar.f27257i;
                if (i11 == 1) {
                    eGLSurface2 = EGL14.EGL_NO_SURFACE;
                } else {
                    EGLSurface eGLSurfaceEglCreatePbufferSurface2 = EGL14.eglCreatePbufferSurface(eGLDisplay2, eGLConfig2, i11 == 2 ? new int[]{12375, 1, 12374, 1, 12992, 1, 12344} : new int[]{12375, 1, 12374, 1, 12344}, 0);
                    qt.a.i("eglCreatePbufferSurface failed", eGLSurfaceEglCreatePbufferSurface2 != null);
                    eGLSurface2 = eGLSurfaceEglCreatePbufferSurface2;
                }
                qt.a.i("eglMakeCurrent failed", EGL14.eglMakeCurrent(eGLDisplay2, eGLSurface2, eGLSurface2, eGLContextEglCreateContext2));
                cVar.f27259w = eGLSurface2;
                GLES20.glGenTextures(1, iArr4, 0);
                qt.a.h();
                SurfaceTexture surfaceTexture3 = new SurfaceTexture(iArr4[0]);
                cVar.f27260x = surfaceTexture3;
                surfaceTexture3.setOnFrameAvailableListener(cVar);
                SurfaceTexture surfaceTexture4 = ((qt.c) this.f21016w).f27260x;
                surfaceTexture4.getClass();
                this.f21017x = new rt.h(this, surfaceTexture4, i11 != 0);
                break;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void b() {
        switch (this.f21012d) {
            case 0:
                ((n3.l) this.f21016w).getClass();
                n3.l lVar = (n3.l) this.f21016w;
                lVar.f22352d.removeCallbacks(lVar);
                try {
                    SurfaceTexture surfaceTexture = lVar.f22357x;
                    if (surfaceTexture != null) {
                        surfaceTexture.release();
                        GLES20.glDeleteTextures(1, lVar.f22353e, 0);
                        break;
                    }
                    return;
                } finally {
                    EGLDisplay eGLDisplay = lVar.f22354i;
                    if (eGLDisplay != null && !eGLDisplay.equals(EGL14.EGL_NO_DISPLAY)) {
                        EGLDisplay eGLDisplay2 = lVar.f22354i;
                        EGLSurface eGLSurface = EGL14.EGL_NO_SURFACE;
                        EGL14.eglMakeCurrent(eGLDisplay2, eGLSurface, eGLSurface, EGL14.EGL_NO_CONTEXT);
                    }
                    EGLSurface eGLSurface2 = lVar.f22356w;
                    if (eGLSurface2 != null && !eGLSurface2.equals(EGL14.EGL_NO_SURFACE)) {
                        EGL14.eglDestroySurface(lVar.f22354i, lVar.f22356w);
                    }
                    EGLContext eGLContext = lVar.f22355v;
                    if (eGLContext != null) {
                        EGL14.eglDestroyContext(lVar.f22354i, eGLContext);
                    }
                    EGL14.eglReleaseThread();
                    EGLDisplay eGLDisplay3 = lVar.f22354i;
                    if (eGLDisplay3 != null && !eGLDisplay3.equals(EGL14.EGL_NO_DISPLAY)) {
                        EGL14.eglTerminate(lVar.f22354i);
                    }
                    lVar.f22354i = null;
                    lVar.f22355v = null;
                    lVar.f22356w = null;
                    lVar.f22357x = null;
                }
            default:
                ((qt.c) this.f21016w).getClass();
                qt.c cVar = (qt.c) this.f21016w;
                cVar.f27255d.removeCallbacks(cVar);
                try {
                    SurfaceTexture surfaceTexture2 = cVar.f27260x;
                    if (surfaceTexture2 != null) {
                        surfaceTexture2.release();
                        GLES20.glDeleteTextures(1, cVar.f27256e, 0);
                        break;
                    }
                    return;
                } finally {
                    EGLDisplay eGLDisplay4 = cVar.f27257i;
                    if (eGLDisplay4 != null && !eGLDisplay4.equals(EGL14.EGL_NO_DISPLAY)) {
                        EGLDisplay eGLDisplay5 = cVar.f27257i;
                        EGLSurface eGLSurface3 = EGL14.EGL_NO_SURFACE;
                        EGL14.eglMakeCurrent(eGLDisplay5, eGLSurface3, eGLSurface3, EGL14.EGL_NO_CONTEXT);
                    }
                    EGLSurface eGLSurface4 = cVar.f27259w;
                    if (eGLSurface4 != null && !eGLSurface4.equals(EGL14.EGL_NO_SURFACE)) {
                        EGL14.eglDestroySurface(cVar.f27257i, cVar.f27259w);
                    }
                    EGLContext eGLContext2 = cVar.f27258v;
                    if (eGLContext2 != null) {
                        EGL14.eglDestroyContext(cVar.f27257i, eGLContext2);
                    }
                    if (qt.x.f27318a >= 19) {
                        EGL14.eglReleaseThread();
                    }
                    EGLDisplay eGLDisplay6 = cVar.f27257i;
                    if (eGLDisplay6 != null && !eGLDisplay6.equals(EGL14.EGL_NO_DISPLAY)) {
                        EGL14.eglTerminate(cVar.f27257i);
                    }
                    cVar.f27257i = null;
                    cVar.f27258v = null;
                    cVar.f27259w = null;
                    cVar.f27260x = null;
                }
        }
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        switch (this.f21012d) {
            case 0:
                int i11 = message.what;
                try {
                    if (i11 != 1) {
                        if (i11 == 2) {
                            try {
                                b();
                            } catch (Throwable th2) {
                                try {
                                    n3.b.d("PlaceholderSurface", "Failed to release placeholder surface", th2);
                                } finally {
                                    quit();
                                }
                            }
                        }
                        break;
                    } else {
                        try {
                            try {
                                a(message.arg1);
                                synchronized (this) {
                                    notify();
                                }
                            } catch (n3.m e4) {
                                n3.b.d("PlaceholderSurface", "Failed to initialize placeholder surface", e4);
                                this.f21015v = new IllegalStateException(e4);
                                synchronized (this) {
                                    notify();
                                }
                            }
                        } catch (Error e9) {
                            n3.b.d("PlaceholderSurface", "Failed to initialize placeholder surface", e9);
                            this.f21014i = e9;
                            synchronized (this) {
                                notify();
                            }
                        } catch (RuntimeException e11) {
                            n3.b.d("PlaceholderSurface", "Failed to initialize placeholder surface", e11);
                            this.f21015v = e11;
                            synchronized (this) {
                                notify();
                            }
                        }
                        break;
                    }
                    return true;
                } catch (Throwable th3) {
                    synchronized (this) {
                        notify();
                        throw th3;
                    }
                }
            default:
                int i12 = message.what;
                try {
                    if (i12 != 1) {
                        if (i12 == 2) {
                            try {
                                b();
                            } catch (Throwable th4) {
                                try {
                                    qt.a.s("PlaceholderSurface", "Failed to release placeholder surface", th4);
                                } finally {
                                    quit();
                                }
                            }
                        }
                        break;
                    } else {
                        try {
                            try {
                                a(message.arg1);
                                synchronized (this) {
                                    notify();
                                }
                            } catch (Error e12) {
                                qt.a.s("PlaceholderSurface", "Failed to initialize placeholder surface", e12);
                                this.f21014i = e12;
                                synchronized (this) {
                                    notify();
                                }
                            }
                        } catch (RuntimeException e13) {
                            qt.a.s("PlaceholderSurface", "Failed to initialize placeholder surface", e13);
                            this.f21015v = e13;
                            synchronized (this) {
                                notify();
                            }
                        } catch (qt.f e14) {
                            qt.a.s("PlaceholderSurface", "Failed to initialize placeholder surface", e14);
                            this.f21015v = new IllegalStateException(e14);
                            synchronized (this) {
                                notify();
                            }
                        }
                        break;
                    }
                    return true;
                } catch (Throwable th5) {
                    synchronized (this) {
                        notify();
                        throw th5;
                    }
                }
        }
    }
}
