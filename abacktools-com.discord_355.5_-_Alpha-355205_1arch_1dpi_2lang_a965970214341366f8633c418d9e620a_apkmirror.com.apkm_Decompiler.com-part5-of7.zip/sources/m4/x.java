package m4;

import android.content.Context;
import android.opengl.GLSurfaceView;

/* JADX INFO: loaded from: classes.dex */
public final class x extends GLSurfaceView implements y {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ int f21060e = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final w f21061d;

    public x(Context context) {
        super(context, null);
        w wVar = new w(this);
        this.f21061d = wVar;
        setPreserveEGLContextOnPause(true);
        setEGLContextClientVersion(2);
        setRenderer(wVar);
        setRenderMode(0);
    }

    public void setOutputBuffer(u3.g gVar) {
        w wVar = this.f21061d;
        if (wVar.f21059x.getAndSet(gVar) != null) {
            throw new ClassCastException();
        }
        wVar.f21054d.requestRender();
    }

    @Deprecated
    public y getVideoDecoderOutputBufferRenderer() {
        return this;
    }
}
