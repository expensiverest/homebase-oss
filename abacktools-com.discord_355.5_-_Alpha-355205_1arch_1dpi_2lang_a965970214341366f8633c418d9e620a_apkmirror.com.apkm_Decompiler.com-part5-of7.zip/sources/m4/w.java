package m4;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import e1.v0;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.util.concurrent.atomic.AtomicReference;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/* JADX INFO: loaded from: classes.dex */
public final class w implements GLSurfaceView.Renderer {
    public static final String[] J = {"y_tex", "u_tex", "v_tex"};
    public static final FloatBuffer K = n3.e.d(new float[]{-1.0f, 1.0f, -1.0f, -1.0f, 1.0f, 1.0f, 1.0f, -1.0f});

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final x f21054d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[] f21055e = new int[3];

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f21056i = new int[3];

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int[] f21057v = new int[3];

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int[] f21058w = new int[3];

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final AtomicReference f21059x = new AtomicReference();
    public v0 y;

    public w(x xVar) {
        this.f21054d = xVar;
        for (int i11 = 0; i11 < 3; i11++) {
            int[] iArr = this.f21057v;
            this.f21058w[i11] = -1;
            iArr[i11] = -1;
        }
    }

    public final void a() {
        int[] iArr = this.f21055e;
        try {
            GLES20.glGenTextures(3, iArr, 0);
            for (int i11 = 0; i11 < 3; i11++) {
                v0 v0Var = this.y;
                GLES20.glUniform1i(GLES20.glGetUniformLocation(v0Var.f9814e, J[i11]), i11);
                GLES20.glActiveTexture(33984 + i11);
                n3.e.a(3553, iArr[i11]);
            }
            n3.e.b();
        } catch (n3.m e4) {
            n3.b.d("VideoDecoderGLSV", "Failed to set up the textures", e4);
        }
    }

    @Override // android.opengl.GLSurfaceView.Renderer
    public final void onDrawFrame(GL10 gl10) {
        if (this.f21059x.getAndSet(null) != null) {
            throw new ClassCastException();
        }
    }

    @Override // android.opengl.GLSurfaceView.Renderer
    public final void onSurfaceChanged(GL10 gl10, int i11, int i12) {
        GLES20.glViewport(0, 0, i11, i12);
    }

    @Override // android.opengl.GLSurfaceView.Renderer
    public final void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
        int[] iArr = this.f21056i;
        try {
            v0 v0Var = new v0(5, "varying vec2 interp_tc_y;\nvarying vec2 interp_tc_u;\nvarying vec2 interp_tc_v;\nattribute vec4 in_pos;\nattribute vec2 in_tc_y;\nattribute vec2 in_tc_u;\nattribute vec2 in_tc_v;\nvoid main() {\n  gl_Position = in_pos;\n  interp_tc_y = in_tc_y;\n  interp_tc_u = in_tc_u;\n  interp_tc_v = in_tc_v;\n}\n", "precision mediump float;\nvarying vec2 interp_tc_y;\nvarying vec2 interp_tc_u;\nvarying vec2 interp_tc_v;\nuniform sampler2D y_tex;\nuniform sampler2D u_tex;\nuniform sampler2D v_tex;\nuniform mat3 mColorConversion;\nvoid main() {\n  vec3 yuv;\n  yuv.x = texture2D(y_tex, interp_tc_y).r - 0.0625;\n  yuv.y = texture2D(u_tex, interp_tc_u).r - 0.5;\n  yuv.z = texture2D(v_tex, interp_tc_v).r - 0.5;\n  gl_FragColor = vec4(mColorConversion * yuv, 1.0);\n}\n");
            this.y = v0Var;
            GLES20.glVertexAttribPointer(v0Var.l("in_pos"), 2, 5126, false, 0, (Buffer) K);
            iArr[0] = this.y.l("in_tc_y");
            iArr[1] = this.y.l("in_tc_u");
            iArr[2] = this.y.l("in_tc_v");
            GLES20.glGetUniformLocation(this.y.f9814e, "mColorConversion");
            n3.e.b();
            a();
            n3.e.b();
        } catch (n3.m e4) {
            n3.b.d("VideoDecoderGLSV", "Failed to set up the textures and program", e4);
        }
    }
}
