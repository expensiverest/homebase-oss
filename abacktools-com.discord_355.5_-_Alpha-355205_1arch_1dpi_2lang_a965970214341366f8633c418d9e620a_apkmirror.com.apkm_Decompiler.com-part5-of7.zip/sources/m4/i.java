package m4;

import android.os.Handler;
import android.os.SystemClock;
import android.view.Surface;
import k3.z1;

/* JADX INFO: loaded from: classes.dex */
public final class i implements k0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ n f20969b;

    public i(n nVar) {
        this.f20969b = nVar;
    }

    @Override // m4.k0
    public final void a() {
        n nVar = this.f20969b;
        if (nVar.I1 != null) {
            nVar.U0(0, 1);
        }
    }

    @Override // m4.k0
    public final void c() {
        v3.z zVar = this.f20969b.f4398l0;
        if (zVar != null) {
            zVar.a();
        }
    }

    @Override // m4.k0
    public final void onFirstFrameRendered() {
        n nVar = this.f20969b;
        Surface surface = nVar.I1;
        if (surface != null) {
            k7.l lVar = nVar.f21001p1;
            Handler handler = (Handler) lVar.f19342d;
            if (handler != null) {
                handler.post(new app.p001rive.core.b(lVar, surface, SystemClock.elapsedRealtime(), 3));
            }
            nVar.L1 = true;
        }
    }

    @Override // m4.k0
    public final void b(z1 z1Var) {
    }
}
