package m4;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.view.Surface;

/* JADX INFO: loaded from: classes.dex */
public final class p extends Surface {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static int f21018v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static boolean f21019w;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21020d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final o f21021e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f21022i;

    public p(o oVar, SurfaceTexture surfaceTexture, boolean z11) {
        super(surfaceTexture);
        this.f21021e = oVar;
        this.f21020d = z11;
    }

    public static int b(Context context) {
        try {
            int i11 = Build.VERSION.SDK_INT;
            if (((i11 >= 26 || !("samsung".equals(Build.MANUFACTURER) || "XT1650".equals(Build.MODEL))) && (i11 >= 26 || context.getPackageManager().hasSystemFeature("android.hardware.vr.high_performance"))) ? n3.e.g("EGL_EXT_protected_content") : false) {
                return n3.e.g("EGL_KHR_surfaceless_context") ? 1 : 2;
            }
            return 0;
        } catch (n3.m e4) {
            n3.b.c("PlaceholderSurface", "Failed to determine secure mode due to GL error: " + e4.getMessage());
            return 0;
        }
    }

    public static synchronized boolean h(Context context) {
        try {
            if (!f21019w) {
                f21018v = b(context);
                f21019w = true;
            }
        } catch (Throwable th2) {
            throw th2;
        }
        return f21018v != 0;
    }

    @Override // android.view.Surface
    public final void release() {
        super.release();
        synchronized (this.f21021e) {
            try {
                if (!this.f21022i) {
                    o oVar = this.f21021e;
                    oVar.f21013e.getClass();
                    oVar.f21013e.sendEmptyMessage(2);
                    this.f21022i = true;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
