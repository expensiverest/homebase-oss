package m4;

import k3.x1;

/* JADX INFO: loaded from: classes.dex */
public final class s implements x1 {
    static {
        s1.e.w(new gx.x(1));
    }
}
