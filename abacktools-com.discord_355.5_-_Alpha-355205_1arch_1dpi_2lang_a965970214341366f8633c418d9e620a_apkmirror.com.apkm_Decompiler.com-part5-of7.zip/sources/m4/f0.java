package m4;

import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.view.Choreographer;
import android.view.Choreographer$VsyncCallback;

/* JADX INFO: loaded from: classes.dex */
public final class f0 extends d0 implements Choreographer$VsyncCallback {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final Handler f20933w;

    public f0(Choreographer choreographer, DisplayManager displayManager) {
        super(choreographer, displayManager);
        this.f20933w = n3.l0.r(null);
    }

    @Override // m4.d0
    public final void a() {
        this.f20911e.registerDisplayListener(this, n3.l0.r(null));
        Choreographer choreographer = this.f20910d;
        choreographer.removeVsyncCallback(this);
        choreographer.postVsyncCallback(this);
    }

    @Override // m4.d0
    public final void b() {
        this.f20911e.unregisterDisplayListener(this);
        this.f20933w.removeCallbacksAndMessages(null);
        this.f20910d.removeVsyncCallback(this);
        this.f20912i = -9223372036854775807L;
        this.f20913v = -9223372036854775807L;
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayChanged(int i11) {
        if (i11 == 0) {
            this.f20933w.removeCallbacksAndMessages(null);
            Choreographer choreographer = this.f20910d;
            choreographer.removeVsyncCallback(this);
            choreographer.postVsyncCallback(this);
        }
    }

    public final void onVsync(Choreographer.FrameData frameData) {
        this.f20912i = frameData.getFrameTimeNanos();
        Choreographer.FrameTimeline[] frameTimelines = frameData.getFrameTimelines();
        if (frameTimelines.length >= 2) {
            long expectedPresentationTimeNanos = frameTimelines[1].getExpectedPresentationTimeNanos() - frameTimelines[0].getExpectedPresentationTimeNanos();
            this.f20913v = expectedPresentationTimeNanos != 0 ? expectedPresentationTimeNanos : -9223372036854775807L;
        } else {
            this.f20913v = -9223372036854775807L;
        }
        this.f20933w.removeCallbacksAndMessages(null);
        this.f20933w.postDelayed(new jk.m0(10, this), 500L);
    }
}
