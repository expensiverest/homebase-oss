package m4;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f21023a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0 f21024b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public t f21025c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f21026d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f21028f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f21029g = 15000;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final b0 f21030h = new b0();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public n3.e0 f21027e = n3.e0.f22318a;

    public q(Context context, a0 a0Var) {
        this.f21023a = context.getApplicationContext();
        this.f21024b = a0Var;
    }
}
