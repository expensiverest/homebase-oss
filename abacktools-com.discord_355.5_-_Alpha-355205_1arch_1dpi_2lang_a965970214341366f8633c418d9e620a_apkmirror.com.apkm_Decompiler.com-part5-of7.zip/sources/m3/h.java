package m3;

import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public final class h implements f {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f20842d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f20843e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final String f20844f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f20845a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f20846b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f20847c;

    static {
        String str = l0.f22358a;
        f20842d = Integer.toString(0, 36);
        f20843e = Integer.toString(1, 36);
        f20844f = Integer.toString(2, 36);
    }

    public h(int i11, int i12, int i13) {
        this.f20845a = i11;
        this.f20846b = i12;
        this.f20847c = i13;
    }
}
