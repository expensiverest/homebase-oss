package m3;

import hx.k0;
import hx.m0;
import hx.r;
import hx.r1;
import hx.w1;
import java.util.List;
import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final r f20827c = new r(new j10.a(26), r1.f14867e);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final c f20828d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f20829e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final String f20830f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final w1 f20831a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f20832b;

    static {
        k0 k0Var = m0.f14841e;
        f20828d = new c(0L, w1.f14911w);
        String str = l0.f22358a;
        f20829e = Integer.toString(0, 36);
        f20830f = Integer.toString(1, 36);
    }

    public c(long j6, List list) {
        this.f20831a = m0.y(f20827c, list);
        this.f20832b = j6;
    }
}
