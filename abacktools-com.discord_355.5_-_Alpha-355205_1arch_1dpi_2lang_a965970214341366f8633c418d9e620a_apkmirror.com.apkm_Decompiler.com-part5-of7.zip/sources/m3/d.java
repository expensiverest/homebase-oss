package m3;

import android.os.Bundle;
import android.text.Spanned;
import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f20833a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String f20834b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final String f20835c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f20836d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f20837e;

    static {
        String str = l0.f22358a;
        f20833a = Integer.toString(0, 36);
        f20834b = Integer.toString(1, 36);
        f20835c = Integer.toString(2, 36);
        f20836d = Integer.toString(3, 36);
        f20837e = Integer.toString(4, 36);
    }

    public static Bundle a(Spanned spanned, Object obj, int i11, Bundle bundle) {
        Bundle bundle2 = new Bundle();
        bundle2.putInt(f20833a, spanned.getSpanStart(obj));
        bundle2.putInt(f20834b, spanned.getSpanEnd(obj));
        bundle2.putInt(f20835c, spanned.getSpanFlags(obj));
        bundle2.putInt(f20836d, i11);
        if (bundle != null) {
            bundle2.putBundle(f20837e, bundle);
        }
        return bundle2;
    }
}
