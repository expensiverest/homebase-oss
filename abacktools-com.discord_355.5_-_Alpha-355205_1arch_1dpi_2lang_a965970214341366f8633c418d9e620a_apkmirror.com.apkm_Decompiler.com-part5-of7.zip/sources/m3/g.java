package m3;

import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public final class g implements f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final String f20838c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f20839d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f20840a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f20841b;

    static {
        String str = l0.f22358a;
        f20838c = Integer.toString(0, 36);
        f20839d = Integer.toString(1, 36);
    }

    public g(String str, int i11) {
        this.f20840a = str;
        this.f20841b = i11;
    }
}
