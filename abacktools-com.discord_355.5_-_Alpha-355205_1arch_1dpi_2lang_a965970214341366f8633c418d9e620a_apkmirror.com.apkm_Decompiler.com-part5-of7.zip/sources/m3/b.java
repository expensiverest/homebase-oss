package m3;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Layout;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Objects;
import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public static final String A;
    public static final String B;
    public static final String C;
    public static final String D;
    public static final String E;
    public static final String F;
    public static final String G;
    public static final String H;
    public static final String I;
    public static final String J;
    public static final String K;
    public static final String L;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final String f20804s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final String f20805t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final String f20806u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String f20807v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final String f20808w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f20809x;
    public static final String y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final String f20810z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CharSequence f20811a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Layout.Alignment f20812b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Layout.Alignment f20813c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Bitmap f20814d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final float f20815e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f20816f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f20817g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final float f20818h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f20819i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final float f20820j;
    public final float k;
    public final boolean l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f20821m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f20822n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final float f20823o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f20824p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final float f20825q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f20826r;

    static {
        new b("", null, null, null, -3.4028235E38f, androidx.customview.widget.b.INVALID_ID, androidx.customview.widget.b.INVALID_ID, -3.4028235E38f, androidx.customview.widget.b.INVALID_ID, androidx.customview.widget.b.INVALID_ID, -3.4028235E38f, -3.4028235E38f, -3.4028235E38f, false, -16777216, androidx.customview.widget.b.INVALID_ID, 0.0f, 0);
        String str = l0.f22358a;
        f20804s = Integer.toString(0, 36);
        f20805t = Integer.toString(17, 36);
        f20806u = Integer.toString(1, 36);
        f20807v = Integer.toString(2, 36);
        f20808w = Integer.toString(3, 36);
        f20809x = Integer.toString(18, 36);
        y = Integer.toString(4, 36);
        f20810z = Integer.toString(5, 36);
        A = Integer.toString(6, 36);
        B = Integer.toString(7, 36);
        C = Integer.toString(8, 36);
        D = Integer.toString(9, 36);
        E = Integer.toString(10, 36);
        F = Integer.toString(11, 36);
        G = Integer.toString(12, 36);
        H = Integer.toString(13, 36);
        I = Integer.toString(14, 36);
        J = Integer.toString(15, 36);
        K = Integer.toString(16, 36);
        L = Integer.toString(19, 36);
    }

    public b(CharSequence charSequence, Layout.Alignment alignment, Layout.Alignment alignment2, Bitmap bitmap, float f3, int i11, int i12, float f11, int i13, int i14, float f12, float f13, float f14, boolean z11, int i15, int i16, float f15, int i17) {
        if (charSequence == null) {
            bitmap.getClass();
        } else {
            oq.a.n(bitmap == null);
        }
        if (charSequence instanceof Spanned) {
            this.f20811a = SpannedString.valueOf(charSequence);
        } else if (charSequence != null) {
            this.f20811a = charSequence.toString();
        } else {
            this.f20811a = null;
        }
        this.f20812b = alignment;
        this.f20813c = alignment2;
        this.f20814d = bitmap;
        this.f20815e = f3;
        this.f20816f = i11;
        this.f20817g = i12;
        this.f20818h = f11;
        this.f20819i = i13;
        this.f20820j = f13;
        this.k = f14;
        this.l = z11;
        this.f20821m = i15;
        this.f20822n = i14;
        this.f20823o = f12;
        this.f20824p = i16;
        this.f20825q = f15;
        this.f20826r = i17;
    }

    public final a a() {
        a aVar = new a();
        aVar.f20788a = this.f20811a;
        aVar.f20789b = this.f20814d;
        aVar.f20790c = this.f20812b;
        aVar.f20791d = this.f20813c;
        aVar.f20792e = this.f20815e;
        aVar.f20793f = this.f20816f;
        aVar.f20794g = this.f20817g;
        aVar.f20795h = this.f20818h;
        aVar.f20796i = this.f20819i;
        aVar.f20797j = this.f20822n;
        aVar.k = this.f20823o;
        aVar.l = this.f20820j;
        aVar.f20798m = this.k;
        aVar.f20799n = this.l;
        aVar.f20800o = this.f20821m;
        aVar.f20801p = this.f20824p;
        aVar.f20802q = this.f20825q;
        aVar.f20803r = this.f20826r;
        return aVar;
    }

    public final Bundle b() {
        Bundle bundle = new Bundle();
        CharSequence charSequence = this.f20811a;
        if (charSequence != null) {
            bundle.putCharSequence(f20804s, charSequence);
            if (charSequence instanceof Spanned) {
                Spanned spanned = (Spanned) charSequence;
                String str = d.f20833a;
                ArrayList<? extends Parcelable> arrayList = new ArrayList<>();
                for (g gVar : (g[]) spanned.getSpans(0, spanned.length(), g.class)) {
                    gVar.getClass();
                    Bundle bundle2 = new Bundle();
                    bundle2.putString(g.f20838c, gVar.f20840a);
                    bundle2.putInt(g.f20839d, gVar.f20841b);
                    arrayList.add(d.a(spanned, gVar, 1, bundle2));
                }
                for (h hVar : (h[]) spanned.getSpans(0, spanned.length(), h.class)) {
                    hVar.getClass();
                    Bundle bundle3 = new Bundle();
                    bundle3.putInt(h.f20842d, hVar.f20845a);
                    bundle3.putInt(h.f20843e, hVar.f20846b);
                    bundle3.putInt(h.f20844f, hVar.f20847c);
                    arrayList.add(d.a(spanned, hVar, 2, bundle3));
                }
                for (e eVar : (e[]) spanned.getSpans(0, spanned.length(), e.class)) {
                    arrayList.add(d.a(spanned, eVar, 3, null));
                }
                for (i iVar : (i[]) spanned.getSpans(0, spanned.length(), i.class)) {
                    iVar.getClass();
                    Bundle bundle4 = new Bundle();
                    bundle4.putString(i.f20848b, iVar.f20849a);
                    arrayList.add(d.a(spanned, iVar, 4, bundle4));
                }
                if (!arrayList.isEmpty()) {
                    bundle.putParcelableArrayList(f20805t, arrayList);
                }
            }
        }
        bundle.putSerializable(f20806u, this.f20812b);
        bundle.putSerializable(f20807v, this.f20813c);
        bundle.putFloat(y, this.f20815e);
        bundle.putInt(f20810z, this.f20816f);
        bundle.putInt(A, this.f20817g);
        bundle.putFloat(B, this.f20818h);
        bundle.putInt(C, this.f20819i);
        bundle.putInt(D, this.f20822n);
        bundle.putFloat(E, this.f20823o);
        bundle.putFloat(F, this.f20820j);
        bundle.putFloat(G, this.k);
        bundle.putBoolean(I, this.l);
        bundle.putInt(H, this.f20821m);
        bundle.putInt(J, this.f20824p);
        bundle.putFloat(K, this.f20825q);
        bundle.putInt(L, this.f20826r);
        return bundle;
    }

    public final boolean equals(Object obj) {
        Bitmap bitmap;
        if (this == obj) {
            return true;
        }
        if (obj != null && b.class == obj.getClass()) {
            b bVar = (b) obj;
            Bitmap bitmap2 = bVar.f20814d;
            if (TextUtils.equals(this.f20811a, bVar.f20811a) && this.f20812b == bVar.f20812b && this.f20813c == bVar.f20813c && ((bitmap = this.f20814d) != null ? !(bitmap2 == null || !bitmap.sameAs(bitmap2)) : bitmap2 == null) && this.f20815e == bVar.f20815e && this.f20816f == bVar.f20816f && this.f20817g == bVar.f20817g && this.f20818h == bVar.f20818h && this.f20819i == bVar.f20819i && this.f20820j == bVar.f20820j && this.k == bVar.k && this.l == bVar.l && this.f20821m == bVar.f20821m && this.f20822n == bVar.f20822n && this.f20823o == bVar.f20823o && this.f20824p == bVar.f20824p && this.f20825q == bVar.f20825q && this.f20826r == bVar.f20826r) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(this.f20811a, this.f20812b, this.f20813c, this.f20814d, Float.valueOf(this.f20815e), Integer.valueOf(this.f20816f), Integer.valueOf(this.f20817g), Float.valueOf(this.f20818h), Integer.valueOf(this.f20819i), Float.valueOf(this.f20820j), Float.valueOf(this.k), Boolean.valueOf(this.l), Integer.valueOf(this.f20821m), Integer.valueOf(this.f20822n), Float.valueOf(this.f20823o), Integer.valueOf(this.f20824p), Float.valueOf(this.f20825q), Integer.valueOf(this.f20826r));
    }
}
