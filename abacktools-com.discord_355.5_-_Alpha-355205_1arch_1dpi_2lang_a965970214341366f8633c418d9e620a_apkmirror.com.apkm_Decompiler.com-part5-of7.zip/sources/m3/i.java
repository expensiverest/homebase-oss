package m3;

import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String f20848b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f20849a;

    static {
        String str = l0.f22358a;
        f20848b = Integer.toString(0, 36);
    }

    public i(String str) {
        this.f20849a = str;
    }
}
