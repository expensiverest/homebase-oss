package m3;

/* JADX INFO: loaded from: classes.dex */
public interface f {
}
