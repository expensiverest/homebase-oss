package m20;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import qp.f;

/* JADX INFO: loaded from: classes3.dex */
public abstract class c extends f implements a20.b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f20786d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f20787e;

    public c(String str, int i11, int i12, String str2) {
        super(i11, i12);
        this.f20786d = str;
        this.f20787e = str2;
    }

    @Override // qp.f
    public final short getCoalescingKey() {
        return (short) 0;
    }

    @Override // qp.f
    public WritableMap getEventData() {
        return Arguments.createMap();
    }

    @Override // qp.f
    public final String getEventName() {
        return this.f20786d;
    }

    @Override // a20.b
    public final String x() {
        return this.f20787e;
    }
}
