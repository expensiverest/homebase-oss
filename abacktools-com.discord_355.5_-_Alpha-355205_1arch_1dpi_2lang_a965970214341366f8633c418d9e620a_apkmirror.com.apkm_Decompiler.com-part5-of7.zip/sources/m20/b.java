package m20;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;

/* JADX INFO: loaded from: classes3.dex */
public final class b extends c {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final cl.a f20784v = new cl.a(14);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f20785i;

    public b(int i11, int i12, boolean z11) {
        super("topDismiss", i11, i12, "onDismiss");
        this.f20785i = z11;
    }

    @Override // m20.c, qp.f
    public final WritableMap getEventData() {
        WritableMap writableMapCreateMap = Arguments.createMap();
        writableMapCreateMap.putBoolean("isNativeDismiss", this.f20785i);
        return writableMapCreateMap;
    }
}
