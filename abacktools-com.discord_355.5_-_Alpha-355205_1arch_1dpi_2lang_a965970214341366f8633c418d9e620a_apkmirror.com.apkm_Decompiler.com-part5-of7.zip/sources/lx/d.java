package lx;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final byte[] f20694a;

    static {
        byte[] bArr = new byte[128];
        Arrays.fill(bArr, (byte) -1);
        for (int i11 = 0; i11 < 10; i11++) {
            bArr[i11 + 48] = (byte) i11;
        }
        for (int i12 = 0; i12 < 26; i12++) {
            byte b11 = (byte) (i12 + 10);
            bArr[i12 + 65] = b11;
            bArr[i12 + 97] = b11;
        }
        f20694a = bArr;
    }
}
