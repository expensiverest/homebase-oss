package lx;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public final class b implements Serializable {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final b f20688i = new b(new long[0], 0);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long[] f20689d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f20690e;

    public b(long[] jArr, int i11) {
        this.f20689d = jArr;
        this.f20690e = i11;
    }

    public final long a(int i11) {
        oq.a.s(i11, this.f20690e);
        return this.f20689d[i11];
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof b) {
            b bVar = (b) obj;
            int i11 = bVar.f20690e;
            int i12 = this.f20690e;
            if (i12 == i11) {
                for (int i13 = 0; i13 < i12; i13++) {
                    if (a(i13) == bVar.a(i13)) {
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iJ = 1;
        for (int i11 = 0; i11 < this.f20690e; i11++) {
            iJ = (iJ * 31) + com.facebook.imagepipeline.nativecode.b.J(this.f20689d[i11]);
        }
        return iJ;
    }

    public final String toString() {
        int i11 = this.f20690e;
        if (i11 == 0) {
            return "[]";
        }
        StringBuilder sb2 = new StringBuilder(i11 * 5);
        sb2.append('[');
        long[] jArr = this.f20689d;
        sb2.append(jArr[0]);
        for (int i12 = 1; i12 < i11; i12++) {
            sb2.append(", ");
            sb2.append(jArr[i12]);
        }
        sb2.append(']');
        return sb2.toString();
    }
}
