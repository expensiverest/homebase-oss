package lx;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public final class a implements Serializable {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final a f20685i = new a(0, new int[0]);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f20686d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f20687e;

    public a(int i11, int[] iArr) {
        this.f20686d = iArr;
        this.f20687e = i11;
    }

    public static a c(int... iArr) {
        oq.a.m("the total number of elements must fit in an int", iArr.length <= 2147483646);
        int length = iArr.length + 1;
        int[] iArr2 = new int[length];
        iArr2[0] = 0;
        System.arraycopy(iArr, 0, iArr2, 1, iArr.length);
        return new a(length, iArr2);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0013 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:13:0x0015 A[RETURN] */
    public final boolean a(int i11) {
        int i12 = 0;
        while (i12 < this.f20687e) {
            if (this.f20686d[i12] == i11) {
                if (i12 >= 0) {
                    return true;
                }
                return false;
            }
            i12++;
        }
        i12 = -1;
        if (i12 >= 0) {
            return true;
        }
        return false;
    }

    public final int b(int i11) {
        oq.a.s(i11, this.f20687e);
        return this.f20686d[i11];
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof a) {
            a aVar = (a) obj;
            int i11 = aVar.f20687e;
            int i12 = this.f20687e;
            if (i12 == i11) {
                for (int i13 = 0; i13 < i12; i13++) {
                    if (b(i13) == aVar.b(i13)) {
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i11 = 1;
        for (int i12 = 0; i12 < this.f20687e; i12++) {
            i11 = (i11 * 31) + this.f20686d[i12];
        }
        return i11;
    }

    public final String toString() {
        int i11 = this.f20687e;
        if (i11 == 0) {
            return "[]";
        }
        StringBuilder sb2 = new StringBuilder(i11 * 5);
        sb2.append('[');
        int[] iArr = this.f20686d;
        sb2.append(iArr[0]);
        for (int i12 = 1; i12 < i11; i12++) {
            sb2.append(", ");
            sb2.append(iArr[i12]);
        }
        sb2.append(']');
        return sb2.toString();
    }
}
