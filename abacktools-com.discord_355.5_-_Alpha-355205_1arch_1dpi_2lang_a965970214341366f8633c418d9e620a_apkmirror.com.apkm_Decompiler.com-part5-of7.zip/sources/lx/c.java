package lx;

import c7.t;
import java.io.Serializable;
import java.util.AbstractList;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

/* JADX INFO: loaded from: classes3.dex */
public final class c extends AbstractList implements RandomAccess, Serializable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f20691d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f20692e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f20693i;

    public c(int i11, int i12, int[] iArr) {
        this.f20691d = iArr;
        this.f20692e = i11;
        this.f20693i = i12;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return (obj instanceof Integer) && t.A(((Integer) obj).intValue(), this.f20692e, this.f20693i, this.f20691d) != -1;
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return super.equals(obj);
        }
        c cVar = (c) obj;
        int size = size();
        if (cVar.size() != size) {
            return false;
        }
        for (int i11 = 0; i11 < size; i11++) {
            if (this.f20691d[this.f20692e + i11] != cVar.f20691d[cVar.f20692e + i11]) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i11) {
        oq.a.s(i11, size());
        return Integer.valueOf(this.f20691d[this.f20692e + i11]);
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public final int hashCode() {
        int i11 = 1;
        for (int i12 = this.f20692e; i12 < this.f20693i; i12++) {
            i11 = (i11 * 31) + this.f20691d[i12];
        }
        return i11;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int indexOf(Object obj) {
        if (!(obj instanceof Integer)) {
            return -1;
        }
        int iIntValue = ((Integer) obj).intValue();
        int i11 = this.f20693i;
        int i12 = this.f20692e;
        int iA = t.A(iIntValue, i12, i11, this.f20691d);
        if (iA >= 0) {
            return iA - i12;
        }
        return -1;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean isEmpty() {
        return false;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int lastIndexOf(Object obj) {
        int i11;
        if (obj instanceof Integer) {
            int iIntValue = ((Integer) obj).intValue();
            int i12 = this.f20693i;
            do {
                i12--;
                i11 = this.f20692e;
                if (i12 < i11) {
                    i12 = -1;
                    break;
                }
            } while (this.f20691d[i12] != iIntValue);
            if (i12 >= 0) {
                return i12 - i11;
            }
        }
        return -1;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i11, Object obj) {
        Integer num = (Integer) obj;
        oq.a.s(i11, size());
        int i12 = this.f20692e + i11;
        int[] iArr = this.f20691d;
        int i13 = iArr[i12];
        num.getClass();
        iArr[i12] = num.intValue();
        return Integer.valueOf(i13);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f20693i - this.f20692e;
    }

    @Override // java.util.AbstractList, java.util.List
    public final List subList(int i11, int i12) {
        oq.a.w(i11, i12, size());
        if (i11 == i12) {
            return Collections.EMPTY_LIST;
        }
        int i13 = this.f20692e;
        return new c(i11 + i13, i13 + i12, this.f20691d);
    }

    @Override // java.util.AbstractCollection
    public final String toString() {
        StringBuilder sb2 = new StringBuilder(size() * 5);
        sb2.append('[');
        int[] iArr = this.f20691d;
        int i11 = this.f20692e;
        sb2.append(iArr[i11]);
        while (true) {
            i11++;
            if (i11 >= this.f20693i) {
                sb2.append(']');
                return sb2.toString();
            }
            sb2.append(", ");
            sb2.append(iArr[i11]);
        }
    }
}
