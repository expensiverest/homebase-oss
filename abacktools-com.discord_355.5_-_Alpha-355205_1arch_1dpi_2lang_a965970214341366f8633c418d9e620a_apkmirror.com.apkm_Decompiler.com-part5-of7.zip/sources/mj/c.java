package mj;

import com.facebook.react.bridge.WritableMap;
import j70.h;
import kotlin.jvm.internal.k;
import n70.t0;
import p.x2;
import s1.e;

/* JADX INFO: loaded from: classes.dex */
@h
public final class c implements ui.a {
    public static final b Companion = new b();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f21336a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f21337b;

    public /* synthetic */ c(int i11, String str, String str2) {
        if (3 != (i11 & 3)) {
            t0.j(i11, 3, a.f21335a.d());
            throw null;
        }
        this.f21336a = str;
        this.f21337b = str2;
    }

    @Override // ui.a
    public final /* bridge */ WritableMap a() {
        return e.J(this);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return k.b(this.f21336a, cVar.f21336a) && k.b(this.f21337b, cVar.f21337b);
    }

    public final int hashCode() {
        int iHashCode = this.f21336a.hashCode() * 31;
        String str = this.f21337b;
        return iHashCode + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        return x2.i("ShareBroadcastReceiverAppClicked(app=", this.f21336a, ", location=", this.f21337b, ")");
    }

    public c(String str, String str2) {
        this.f21336a = str;
        this.f21337b = str2;
    }
}
