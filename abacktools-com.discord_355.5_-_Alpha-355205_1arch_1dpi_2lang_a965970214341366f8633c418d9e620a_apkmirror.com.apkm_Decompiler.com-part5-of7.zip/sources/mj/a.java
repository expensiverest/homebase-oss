package mj;

import j70.k;
import l70.g;
import m70.d;
import n70.h1;
import n70.v0;
import n70.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f21335a;
    private static final g descriptor;

    static {
        a aVar = new a();
        f21335a = aVar;
        v0 v0Var = new v0("com.discord.share.react.events.ShareBroadcastReceiverAppClicked", aVar, 2);
        v0Var.b("app", false);
        v0Var.b("location", false);
        descriptor = v0Var;
    }

    @Override // j70.b
    public final Object a(m70.c cVar) {
        int i11;
        String strX;
        String str;
        g gVar = descriptor;
        m70.a aVarB = cVar.b(gVar);
        String strX2 = null;
        if (aVarB.z()) {
            strX = aVarB.x(gVar, 0);
            str = (String) aVarB.s(gVar, 1, h1.f22707a, null);
            i11 = 3;
        } else {
            boolean z11 = true;
            int i12 = 0;
            String str2 = null;
            while (z11) {
                int iM = aVarB.m(gVar);
                if (iM == -1) {
                    z11 = false;
                } else if (iM == 0) {
                    strX2 = aVarB.x(gVar, 0);
                    i12 |= 1;
                } else {
                    if (iM != 1) {
                        throw new k(iM);
                    }
                    str2 = (String) aVarB.s(gVar, 1, h1.f22707a, str2);
                    i12 |= 2;
                }
            }
            i11 = i12;
            strX = strX2;
            str = str2;
        }
        aVarB.c(gVar);
        return new c(i11, strX, str);
    }

    @Override // n70.z
    public final j70.b[] b() {
        h1 h1Var = h1.f22707a;
        return new j70.b[]{h1Var, mn.a.A(h1Var)};
    }

    @Override // j70.j
    public final void c(d dVar, Object obj) {
        c value = (c) obj;
        kotlin.jvm.internal.k.g(value, "value");
        g gVar = descriptor;
        m70.b bVarB = dVar.b(gVar);
        bVarB.d(gVar, 0, value.f21336a);
        bVarB.A(gVar, 1, h1.f22707a, value.f21337b);
        bVarB.c(gVar);
    }

    @Override // j70.j
    public final g d() {
        return descriptor;
    }
}
