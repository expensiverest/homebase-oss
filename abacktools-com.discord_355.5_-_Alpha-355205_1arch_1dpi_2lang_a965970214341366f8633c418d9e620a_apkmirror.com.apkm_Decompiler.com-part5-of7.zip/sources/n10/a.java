package n10;

import com.facebook.react.bridge.ModuleSpec;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.margelo.nitro.nitrofetch.t0;
import com.swmansion.gesturehandler.react.RNGestureHandlerButtonViewManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerDetectorViewManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerModule;
import com.swmansion.gesturehandler.react.RNGestureHandlerRootViewManager;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.inject.Provider;
import kotlin.jvm.internal.k;
import l30.o;
import m30.q;
import s1.e;
import sn.c;
import sn.y;

/* JADX INFO: loaded from: classes3.dex */
public final class a extends c implements y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final o f22270a = a.a.K(new hh.c(18));

    @Override // sn.y
    public final ViewManager createViewManager(ReactApplicationContext reactApplicationContext, String viewManagerName) {
        Provider provider;
        k.g(viewManagerName, "viewManagerName");
        ModuleSpec moduleSpec = (ModuleSpec) ((Map) this.f22270a.getValue()).get(viewManagerName);
        NativeModule nativeModule = (moduleSpec == null || (provider = moduleSpec.provider()) == null) ? null : (NativeModule) provider.get();
        if (nativeModule instanceof ViewManager) {
            return (ViewManager) nativeModule;
        }
        return null;
    }

    @Override // sn.c, sn.p
    public final List createViewManagers(ReactApplicationContext reactContext) {
        k.g(reactContext, "reactContext");
        return e.u(new RNGestureHandlerRootViewManager(), new RNGestureHandlerButtonViewManager(), new RNGestureHandlerDetectorViewManager());
    }

    @Override // sn.c
    public final NativeModule getModule(String name, ReactApplicationContext reactContext) {
        k.g(name, "name");
        k.g(reactContext, "reactContext");
        if (name.equals("RNGestureHandlerModule")) {
            return new RNGestureHandlerModule(reactContext);
        }
        return null;
    }

    @Override // sn.c
    public final jo.a getReactModuleInfoProvider() throws InvocationTargetException {
        try {
            Object objNewInstance = Class.forName("com.swmansion.gesturehandler.RNGestureHandlerPackage$$ReactModuleInfoProvider").getDeclaredConstructor(null).newInstance(null);
            k.e(objNewInstance, "null cannot be cast to non-null type com.facebook.react.module.model.ReactModuleInfoProvider");
            return (jo.a) objNewInstance;
        } catch (ClassNotFoundException unused) {
            return new t0(5);
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("No ReactModuleInfoProvider for RNGestureHandlerPackage$$ReactModuleInfoProvider", e4);
        } catch (InstantiationException e9) {
            throw new RuntimeException("No ReactModuleInfoProvider for RNGestureHandlerPackage$$ReactModuleInfoProvider", e9);
        }
    }

    @Override // sn.y
    public final Collection getViewManagerNames(ReactApplicationContext reactApplicationContext) {
        return q.S0(((Map) this.f22270a.getValue()).keySet());
    }

    @Override // sn.c
    public final List getViewManagers(ReactApplicationContext reactContext) {
        k.g(reactContext, "reactContext");
        return q.T0(((Map) this.f22270a.getValue()).values());
    }
}
