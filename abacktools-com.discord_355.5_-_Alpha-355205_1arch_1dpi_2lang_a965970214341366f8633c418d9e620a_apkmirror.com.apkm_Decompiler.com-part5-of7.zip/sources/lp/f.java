package lp;

import java.util.concurrent.CancellationException;
import kp.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20581d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ a f20582e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ g f20583i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ z f20584v;

    public /* synthetic */ f(a aVar, g gVar, z zVar, int i11) {
        this.f20581d = i11;
        this.f20582e = aVar;
        this.f20583i = gVar;
        this.f20584v = zVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i11 = this.f20581d;
        z zVar = this.f20584v;
        g gVar = this.f20583i;
        a aVar = this.f20582e;
        switch (i11) {
            case 0:
                try {
                    g gVar2 = (g) aVar.a(gVar);
                    if (gVar2 == null) {
                        zVar.p(null);
                    } else {
                        e eVar = new e(zVar, 1);
                        g gVar3 = g.f20585g;
                        gVar2.a(eVar, b.f20572b);
                    }
                } catch (CancellationException unused) {
                    zVar.n();
                    return;
                } catch (Exception e4) {
                    zVar.o(e4);
                    return;
                }
                break;
            default:
                try {
                    zVar.p(aVar.a(gVar));
                } catch (CancellationException unused2) {
                    zVar.n();
                    return;
                } catch (Exception e9) {
                    zVar.o(e9);
                    return;
                }
                break;
        }
    }
}
