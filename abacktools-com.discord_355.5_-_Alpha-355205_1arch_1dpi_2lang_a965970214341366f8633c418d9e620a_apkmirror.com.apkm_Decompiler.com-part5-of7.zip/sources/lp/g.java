package lp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.k;
import kp.z;
import zm.n;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final g f20585g = new g((Boolean) null);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final g f20586h = new g(Boolean.TRUE);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final g f20587i = new g(Boolean.FALSE);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final g f20588j = new g(0);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f20590b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f20591c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f20592d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Exception f20593e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f20589a = new Object();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f20594f = new ArrayList();

    public g() {
    }

    public final g a(a aVar, Executor executor) {
        boolean z11;
        k.g(executor, "executor");
        z zVar = new z(2);
        synchronized (this.f20589a) {
            synchronized (this.f20589a) {
                z11 = this.f20590b;
            }
            if (!z11) {
                this.f20594f.add(new c(zVar, aVar, executor, 1));
            }
        }
        if (z11) {
            try {
                executor.execute(new f(aVar, this, zVar, 1));
            } catch (Exception e4) {
                zVar.o(new an.g(18, e4));
            }
        }
        return (g) zVar.f19723e;
    }

    public final g b(a aVar, Executor executor) {
        boolean z11;
        k.g(executor, "executor");
        z zVar = new z(2);
        synchronized (this.f20589a) {
            synchronized (this.f20589a) {
                z11 = this.f20590b;
            }
            if (!z11) {
                this.f20594f.add(new c(zVar, aVar, executor, 0));
            }
        }
        if (z11) {
            n.d(zVar, aVar, this, executor);
        }
        return (g) zVar.f19723e;
    }

    public final Exception c() {
        Exception exc;
        synchronized (this.f20589a) {
            exc = this.f20593e;
        }
        return exc;
    }

    public final Object d() {
        Object obj;
        synchronized (this.f20589a) {
            obj = this.f20592d;
        }
        return obj;
    }

    public final boolean e() {
        boolean z11;
        synchronized (this.f20589a) {
            z11 = this.f20591c;
        }
        return z11;
    }

    public final boolean f() {
        boolean z11;
        synchronized (this.f20589a) {
            z11 = c() != null;
        }
        return z11;
    }

    public final g g(a aVar, Executor executor) {
        k.g(executor, "executor");
        return b(new d(aVar, 1), executor);
    }

    public final void h() {
        synchronized (this.f20589a) {
            Iterator it = this.f20594f.iterator();
            while (it.hasNext()) {
                try {
                } catch (RuntimeException e4) {
                    throw e4;
                } catch (Exception e9) {
                    throw new RuntimeException(e9);
                }
            }
            this.f20594f.clear();
        }
    }

    public final boolean i() {
        synchronized (this.f20589a) {
            if (this.f20590b) {
                return false;
            }
            this.f20590b = true;
            this.f20591c = true;
            this.f20589a.notifyAll();
            h();
            return true;
        }
    }

    public final boolean j(Object obj) {
        synchronized (this.f20589a) {
            if (this.f20590b) {
                return false;
            }
            this.f20590b = true;
            this.f20592d = obj;
            this.f20589a.notifyAll();
            h();
            return true;
        }
    }

    public g(Boolean bool) {
        j(bool);
    }

    public g(int i11) {
        i();
    }
}
