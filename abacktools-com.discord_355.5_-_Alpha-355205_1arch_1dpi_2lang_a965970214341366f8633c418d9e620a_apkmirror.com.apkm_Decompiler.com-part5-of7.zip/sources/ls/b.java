package ls;

import android.os.Parcel;
import android.os.Parcelable;
import hs.q;
import mr.w0;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public class b implements is.b {
    public static final Parcelable.Creator<b> CREATOR = new fh.a(15);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f20613d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f20614e;

    public b(String str, String str2) {
        this.f20613d = str;
        this.f20614e = str2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            b bVar = (b) obj;
            if (this.f20613d.equals(bVar.f20613d) && this.f20614e.equals(bVar.f20614e)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f20614e.hashCode() + q.c(527, 31, this.f20613d);
    }

    public final String toString() {
        return "VC: " + this.f20613d + "=" + this.f20614e;
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // is.b
    public final void w(w0 w0Var) {
        String str = this.f20613d;
        str.getClass();
        byte b11 = -1;
        switch (str.hashCode()) {
            case 62359119:
                if (str.equals("ALBUM")) {
                    b11 = 0;
                }
                break;
            case 79833656:
                if (str.equals("TITLE")) {
                    b11 = 1;
                }
                break;
            case 428414940:
                if (str.equals("DESCRIPTION")) {
                    b11 = 2;
                }
                break;
            case 1746739798:
                if (str.equals("ALBUMARTIST")) {
                    b11 = 3;
                }
                break;
            case 1939198791:
                if (str.equals("ARTIST")) {
                    b11 = 4;
                }
                break;
        }
        String str2 = this.f20614e;
        switch (b11) {
            case 0:
                w0Var.f21756c = str2;
                break;
            case 1:
                w0Var.f21754a = str2;
                break;
            case 2:
                w0Var.f21760g = str2;
                break;
            case 3:
                w0Var.f21757d = str2;
                break;
            case 4:
                w0Var.f21755b = str2;
                break;
        }
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        parcel.writeString(this.f20613d);
        parcel.writeString(this.f20614e);
    }

    public b(Parcel parcel) {
        String string = parcel.readString();
        int i11 = x.f27318a;
        this.f20613d = string;
        this.f20614e = parcel.readString();
    }
}
