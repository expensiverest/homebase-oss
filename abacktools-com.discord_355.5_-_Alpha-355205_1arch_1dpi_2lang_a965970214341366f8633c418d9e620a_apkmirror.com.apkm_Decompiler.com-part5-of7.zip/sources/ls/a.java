package ls;

import android.os.Parcel;
import android.os.Parcelable;
import gx.j;
import java.util.Arrays;
import mr.w0;
import qt.q;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public final class a implements is.b {
    public static final Parcelable.Creator<a> CREATOR = new fh.a(14);
    public final byte[] J;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f20607d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f20608e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f20609i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f20610v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f20611w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f20612x;
    public final int y;

    public a(int i11, String str, String str2, int i12, int i13, int i14, int i15, byte[] bArr) {
        this.f20607d = i11;
        this.f20608e = str;
        this.f20609i = str2;
        this.f20610v = i12;
        this.f20611w = i13;
        this.f20612x = i14;
        this.y = i15;
        this.J = bArr;
    }

    public static a b(q qVar) {
        int iG = qVar.g();
        String strS = qVar.s(qVar.g(), j.f13620a);
        String strS2 = qVar.s(qVar.g(), j.f13622c);
        int iG2 = qVar.g();
        int iG3 = qVar.g();
        int iG4 = qVar.g();
        int iG5 = qVar.g();
        int iG6 = qVar.g();
        byte[] bArr = new byte[iG6];
        qVar.e(bArr, 0, iG6);
        return new a(iG, strS, strS2, iG2, iG3, iG4, iG5, bArr);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && a.class == obj.getClass()) {
            a aVar = (a) obj;
            if (this.f20607d == aVar.f20607d && this.f20608e.equals(aVar.f20608e) && this.f20609i.equals(aVar.f20609i) && this.f20610v == aVar.f20610v && this.f20611w == aVar.f20611w && this.f20612x == aVar.f20612x && this.y == aVar.y && Arrays.equals(this.J, aVar.J)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(this.J) + ((((((((hs.q.c(hs.q.c((527 + this.f20607d) * 31, 31, this.f20608e), 31, this.f20609i) + this.f20610v) * 31) + this.f20611w) * 31) + this.f20612x) * 31) + this.y) * 31);
    }

    public final String toString() {
        return "Picture: mimeType=" + this.f20608e + ", description=" + this.f20609i;
    }

    @Override // is.b
    public final void w(w0 w0Var) {
        w0Var.a(this.J, this.f20607d);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i11) {
        parcel.writeInt(this.f20607d);
        parcel.writeString(this.f20608e);
        parcel.writeString(this.f20609i);
        parcel.writeInt(this.f20610v);
        parcel.writeInt(this.f20611w);
        parcel.writeInt(this.f20612x);
        parcel.writeInt(this.y);
        parcel.writeByteArray(this.J);
    }

    public a(Parcel parcel) {
        this.f20607d = parcel.readInt();
        String string = parcel.readString();
        int i11 = x.f27318a;
        this.f20608e = string;
        this.f20609i = parcel.readString();
        this.f20610v = parcel.readInt();
        this.f20611w = parcel.readInt();
        this.f20612x = parcel.readInt();
        this.y = parcel.readInt();
        this.J = parcel.createByteArray();
    }
}
