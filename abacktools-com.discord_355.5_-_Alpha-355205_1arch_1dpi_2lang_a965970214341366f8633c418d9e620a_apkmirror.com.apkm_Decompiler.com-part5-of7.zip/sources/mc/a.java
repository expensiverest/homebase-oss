package mc;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.discord.R;
import com.discord.chat.presentation.message.view.customthemes.ThemePreviewView;
import com.discord.core.DCDButton;
import com.discord.primitives.MessageId;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.nativecode.b;
import com.google.android.flexbox.FlexboxLayout;
import fb.l0;
import zb.m;

/* JADX INFO: loaded from: classes.dex */
public final class a extends LinearLayout {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final l0 f21307d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final SimpleDraweeView f21308e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public m f21309i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public String f21310v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f21311w;

    public a(Context context) {
        super(context, null);
        LayoutInflater.from(context).inflate(R.layout.shared_custom_theme_view, this);
        int i11 = R.id.createdBy;
        TextView textView = (TextView) b.x(this, R.id.createdBy);
        if (textView != null) {
            i11 = R.id.createdByContainer;
            FlexboxLayout flexboxLayout = (FlexboxLayout) b.x(this, R.id.createdByContainer);
            if (flexboxLayout != null) {
                i11 = R.id.heading;
                FlexboxLayout flexboxLayout2 = (FlexboxLayout) b.x(this, R.id.heading);
                if (flexboxLayout2 != null) {
                    i11 = R.id.previewBtn;
                    DCDButton dCDButton = (DCDButton) b.x(this, R.id.previewBtn);
                    if (dCDButton != null) {
                        i11 = R.id.previewHeading;
                        TextView textView2 = (TextView) b.x(this, R.id.previewHeading);
                        if (textView2 != null) {
                            i11 = R.id.themePreview;
                            ThemePreviewView themePreviewView = (ThemePreviewView) b.x(this, R.id.themePreview);
                            if (themePreviewView != null) {
                                this.f21307d = new l0(this, textView, flexboxLayout, flexboxLayout2, dCDButton, textView2, themePreviewView);
                                this.f21308e = new SimpleDraweeView(context);
                                GradientDrawable gradientDrawable = new GradientDrawable();
                                gradientDrawable.setShape(0);
                                gradientDrawable.setCornerRadius(ox.b.k(8));
                                gradientDrawable.setColor(jk.l0.a().h());
                                gradientDrawable.setStroke(ox.b.k(2), jk.l0.a().o());
                                setBackground(gradientDrawable);
                                int iK = ox.b.k(12);
                                setPadding(iK, iK, iK, iK);
                                return;
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(getResources().getResourceName(i11)));
    }

    public final l0 getBinding() {
        return this.f21307d;
    }

    public final SimpleDraweeView getNitroWheelIcon() {
        return this.f21308e;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        String str;
        super.onAttachedToWindow();
        if (this.f21311w || (str = this.f21310v) == null) {
            return;
        }
        m mVar = this.f21309i;
        if (mVar != null) {
            mVar.invoke(new MessageId(str));
        }
        this.f21311w = true;
    }
}
