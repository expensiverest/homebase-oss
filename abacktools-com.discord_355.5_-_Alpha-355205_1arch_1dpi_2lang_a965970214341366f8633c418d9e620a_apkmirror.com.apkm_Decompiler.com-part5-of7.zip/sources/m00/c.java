package m00;

import j00.e;

/* JADX INFO: loaded from: classes3.dex */
public final class c {
    public static final /* synthetic */ int k = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f20751a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f20752b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final j00.a f20753c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f20754d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f20755e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f20756f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Float f20757g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Float f20758h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f20759i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final boolean f20760j;

    public c(float f3, boolean z11, j00.a aVar, e eVar, boolean z12, boolean z13, Float f11, Float f12, boolean z14) {
        this.f20751a = f3;
        this.f20752b = z11;
        this.f20753c = aVar;
        this.f20754d = eVar;
        this.f20755e = z12;
        this.f20756f = z13;
        this.f20757g = f11;
        this.f20758h = f12;
        this.f20759i = z14;
        if (aVar != null && eVar != null) {
            throw new IllegalStateException("Can only use either pan or scaledPan");
        }
        this.f20760j = (aVar == null && eVar == null) ? false : true;
    }
}
