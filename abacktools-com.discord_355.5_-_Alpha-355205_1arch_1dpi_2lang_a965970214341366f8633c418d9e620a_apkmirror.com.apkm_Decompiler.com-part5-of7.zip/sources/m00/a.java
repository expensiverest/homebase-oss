package m00;

import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.animation.AccelerateDecelerateInterpolator;
import androidx.core.view.f1;
import ay.f;
import h40.f0;
import j00.e;
import j00.g;
import j00.h;
import j00.i;
import j00.m;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final f f20726q = new f(11, a.class.getSimpleName());

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final AccelerateDecelerateInterpolator f20727r = new AccelerateDecelerateInterpolator();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n00.c f20728a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final n00.b f20729b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final k00.a f20730c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final h f20731d;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f20735h;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f20737j;
    public float k;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final RectF f20732e = new RectF();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final RectF f20733f = new RectF();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Matrix f20734g = new Matrix();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Matrix f20736i = new Matrix();
    public final e l = new e();

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final j00.a f20738m = new j00.a();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public long f20739n = 280;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final LinkedHashSet f20740o = new LinkedHashSet();

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final gw.f f20741p = new gw.f(1, this);

    public a(n00.c cVar, n00.b bVar, k00.a aVar, h hVar) {
        this.f20728a = cVar;
        this.f20729b = bVar;
        this.f20730c = aVar;
        this.f20731d = hVar;
    }

    public final void a(c cVar) {
        float f3 = cVar.f20751a;
        e eVar = cVar.f20754d;
        boolean z11 = cVar.f20755e;
        j00.a aVarA = cVar.f20753c;
        if (this.f20735h && this.f20730c.b(3)) {
            ArrayList arrayList = new ArrayList();
            int i11 = 2;
            RectF rectF = this.f20732e;
            if (aVarA != null) {
                if (z11) {
                    aVarA = c().a(aVarA);
                }
                PropertyValuesHolder propertyValuesHolderOfFloat = PropertyValuesHolder.ofFloat("panX", rectF.left / e(), aVarA.f17789a);
                k.f(propertyValuesHolderOfFloat, "ofFloat(\"panX\", panX, target.x)");
                arrayList.add(propertyValuesHolderOfFloat);
                PropertyValuesHolder propertyValuesHolderOfFloat2 = PropertyValuesHolder.ofFloat("panY", rectF.top / e(), aVarA.f17790b);
                k.f(propertyValuesHolderOfFloat2, "ofFloat(\"panY\", panY, target.y)");
                arrayList.add(propertyValuesHolderOfFloat2);
            } else if (eVar != null) {
                if (z11) {
                    e eVarD = d();
                    eVar = new e(eVarD.f17794a + eVar.f17794a, eVarD.f17795b + eVar.f17795b);
                }
                PropertyValuesHolder propertyValuesHolderOfFloat3 = PropertyValuesHolder.ofFloat("panX", rectF.left, eVar.f17794a);
                k.f(propertyValuesHolderOfFloat3, "ofFloat(\"panX\", scaledPanX, target.x)");
                arrayList.add(propertyValuesHolderOfFloat3);
                PropertyValuesHolder propertyValuesHolderOfFloat4 = PropertyValuesHolder.ofFloat("panY", rectF.top, eVar.f17795b);
                k.f(propertyValuesHolderOfFloat4, "ofFloat(\"panY\", scaledPanY, target.y)");
                arrayList.add(propertyValuesHolderOfFloat4);
            }
            if (!Float.isNaN(f3)) {
                PropertyValuesHolder propertyValuesHolderOfFloat5 = PropertyValuesHolder.ofFloat("zoom", e(), this.f20728a.H2(f3, cVar.f20752b));
                k.f(propertyValuesHolderOfFloat5, "ofFloat(\"zoom\", zoom, newZoom)");
                arrayList.add(propertyValuesHolderOfFloat5);
            }
            Object[] array = arrayList.toArray(new PropertyValuesHolder[0]);
            if (array == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            PropertyValuesHolder[] propertyValuesHolderArr = (PropertyValuesHolder[]) array;
            ValueAnimator valueAnimatorOfPropertyValuesHolder = ValueAnimator.ofPropertyValuesHolder((PropertyValuesHolder[]) Arrays.copyOf(propertyValuesHolderArr, propertyValuesHolderArr.length));
            valueAnimatorOfPropertyValuesHolder.setDuration(this.f20739n);
            valueAnimatorOfPropertyValuesHolder.setInterpolator(f20727r);
            valueAnimatorOfPropertyValuesHolder.addListener(this.f20741p);
            valueAnimatorOfPropertyValuesHolder.addUpdateListener(new f1(i11, this, cVar));
            valueAnimatorOfPropertyValuesHolder.start();
            this.f20740o.add(valueAnimatorOfPropertyValuesHolder);
        }
    }

    public final void b(c cVar) {
        float f3 = cVar.f20751a;
        boolean z11 = cVar.f20760j;
        boolean z12 = cVar.f20755e;
        if (this.f20735h) {
            j00.a aVar = cVar.f20753c;
            RectF rectF = this.f20733f;
            RectF rectF2 = this.f20732e;
            Matrix matrix = this.f20734g;
            if (aVar != null) {
                if (!z12) {
                    j00.a aVarC = c();
                    aVar = new j00.a(aVar.f17789a - aVarC.f17789a, aVar.f17790b - aVarC.f17790b);
                }
                matrix.preTranslate(aVar.f17789a, aVar.f17790b);
                matrix.mapRect(rectF2, rectF);
            } else {
                e eVar = cVar.f20754d;
                if (eVar != null) {
                    if (!z12) {
                        e eVarD = d();
                        eVar = new e(eVar.f17794a - eVarD.f17794a, eVar.f17795b - eVarD.f17795b);
                    }
                    matrix.postTranslate(eVar.f17794a, eVar.f17795b);
                    matrix.mapRect(rectF2, rectF);
                }
            }
            if (!Float.isNaN(f3)) {
                float fH2 = this.f20728a.H2(f3, cVar.f20752b) / e();
                Float f11 = cVar.f20757g;
                float fFloatValue = f11 != null ? f11.floatValue() : z11 ? 0.0f : this.f20737j / 2.0f;
                Float f12 = cVar.f20758h;
                matrix.postScale(fH2, fH2, fFloatValue, f12 != null ? f12.floatValue() : z11 ? 0.0f : this.k / 2.0f);
                matrix.mapRect(rectF2, rectF);
            }
            boolean z13 = cVar.f20756f;
            n00.b bVar = this.f20729b;
            float fI2 = bVar.I2(true, z13);
            float fI3 = bVar.I2(false, z13);
            if (fI2 != 0.0f || fI3 != 0.0f) {
                matrix.postTranslate(fI2, fI3);
                matrix.mapRect(rectF2, rectF);
            }
            if (cVar.f20759i) {
                k7.c cVar2 = ((m) this.f20731d.f17801e).f17813e;
                for (i iVar : (ArrayList) cVar2.f19322i) {
                    m mVar = (m) cVar2.f19321e;
                    a aVar2 = mVar.f17817i;
                    Matrix matrix2 = aVar2.f20736i;
                    matrix2.set(aVar2.f20734g);
                    iVar.a(mVar, matrix2);
                }
            }
        }
    }

    public final j00.a c() {
        RectF rectF = this.f20732e;
        Float fValueOf = Float.valueOf(rectF.left / e());
        Float fValueOf2 = Float.valueOf(rectF.top / e());
        j00.a aVar = this.f20738m;
        aVar.c(fValueOf, fValueOf2);
        return aVar;
    }

    public final e d() {
        RectF rectF = this.f20732e;
        Float fValueOf = Float.valueOf(rectF.left);
        Float fValueOf2 = Float.valueOf(rectF.top);
        e eVar = this.l;
        eVar.getClass();
        eVar.f17794a = fValueOf.floatValue();
        eVar.f17795b = fValueOf2.floatValue();
        return eVar;
    }

    public final float e() {
        return this.f20732e.width() / this.f20733f.width();
    }

    public final void f(float f3, boolean z11) {
        a aVar;
        int i11;
        Matrix matrix = this.f20734g;
        RectF rectF = this.f20732e;
        RectF rectF2 = this.f20733f;
        matrix.mapRect(rectF, rectF2);
        if (rectF2.width() <= 0.0f || rectF2.height() <= 0.0f) {
            return;
        }
        float f11 = this.f20737j;
        if (f11 <= 0.0f || this.k <= 0.0f) {
            return;
        }
        f20726q.n(f.l(2, Arrays.copyOf(new Object[]{"onSizeChanged:", "containerWidth:", Float.valueOf(f11), "containerHeight:", Float.valueOf(this.k), "contentWidth:", Float.valueOf(rectF2.width()), "contentHeight:", Float.valueOf(rectF2.height())}, 9)));
        int i12 = 0;
        int i13 = 1;
        boolean z12 = !this.f20735h || z11;
        this.f20735h = true;
        f fVar = m.l;
        Boolean boolValueOf = Boolean.valueOf(z12);
        Float fValueOf = Float.valueOf(f3);
        m mVar = (m) this.f20731d.f17801e;
        n00.c cVar = mVar.f17816h;
        a aVar2 = mVar.f17817i;
        fVar.n(f.l(2, Arrays.copyOf(new Object[]{"onMatrixSizeChanged: firstTime:", boolValueOf, "oldZoom:", fValueOf, "transformation:", Integer.valueOf(mVar.f17809a), "transformationZoom:", Float.valueOf(cVar.f22266v)}, 8)));
        mVar.f17814f.b(0);
        if (z12) {
            cVar.f22266v = m.a(mVar);
            j00.f fVar2 = new j00.f(mVar, i12);
            aVar2.getClass();
            aVar = aVar2;
            aVar.b(f0.z(fVar2));
            float fE = (aVar.e() * aVar.f20733f.width()) - aVar.f20737j;
            float fE2 = (aVar.e() * aVar.f20733f.height()) - aVar.k;
            int i14 = mVar.f17810b;
            n00.b bVar = mVar.f17815g;
            if (i14 == 0) {
                int i15 = bVar.J;
                int i16 = i15 & 240;
                int i17 = 16;
                if (i16 != 16) {
                    i11 = i16 != 32 ? 1 : 5;
                } else {
                    i11 = 3;
                }
                int i18 = i15 & (-241);
                if (i18 == 1) {
                    i17 = 48;
                } else if (i18 == 2) {
                    i17 = 80;
                }
                i14 = i11 | i17;
            }
            bVar.getClass();
            aVar.b(f0.z(new g(new e(-n00.b.H2(i14, fE, true), -n00.b.H2(i14, fE2, false)), 0)));
        } else {
            aVar = aVar2;
            cVar.f22266v = m.a(mVar);
            j00.f fVar3 = new j00.f(mVar, i13);
            aVar.getClass();
            aVar.b(f0.z(fVar3));
        }
        fVar.h("onMatrixSizeChanged: newTransformationZoom:", Float.valueOf(cVar.f22266v), "newRealZoom:", Float.valueOf(aVar.e()), "newZoom:", Float.valueOf(aVar.e() / cVar.f22266v));
    }
}
