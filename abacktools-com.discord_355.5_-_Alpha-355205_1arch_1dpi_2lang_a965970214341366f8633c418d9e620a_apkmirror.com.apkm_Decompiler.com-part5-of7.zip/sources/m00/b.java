package m00;

import j00.e;

/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f20742a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f20743b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public j00.a f20744c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public e f20745d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f20746e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f20747f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Float f20748g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Float f20749h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f20750i;
}
