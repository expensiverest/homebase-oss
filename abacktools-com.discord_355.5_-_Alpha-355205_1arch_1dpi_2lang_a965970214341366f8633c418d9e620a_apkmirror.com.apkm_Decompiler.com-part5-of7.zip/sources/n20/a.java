package n20;

import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f22272a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Integer f22273b;

    public a(Integer num, Integer num2) {
        this.f22272a = num;
        this.f22273b = num2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return k.b(this.f22272a, aVar.f22272a) && k.b(this.f22273b, aVar.f22273b);
    }

    public final int hashCode() {
        Integer num = this.f22272a;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        Integer num2 = this.f22273b;
        return iHashCode + (num2 != null ? num2.hashCode() : 0);
    }

    public final String toString() {
        return "ItemStateAppearance(tabBarItemIconColor=" + this.f22272a + ", tabBarItemTitleFontColor=" + this.f22273b + ")";
    }
}
