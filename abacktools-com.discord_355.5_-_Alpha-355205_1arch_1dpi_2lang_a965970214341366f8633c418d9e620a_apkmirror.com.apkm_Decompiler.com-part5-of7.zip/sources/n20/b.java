package n20;

import kotlin.jvm.internal.k;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f22274a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Integer f22275b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f22276c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final a f22277d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final a f22278e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final a f22279f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final a f22280g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Integer f22281h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Boolean f22282i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final String f22283j;
    public final Float k;
    public final Float l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final String f22284m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final String f22285n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Integer f22286o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Integer f22287p;

    public b(Integer num, Integer num2, String str, a aVar, a aVar2, a aVar3, a aVar4, Integer num3, Boolean bool, String str2, Float f3, Float f11, String str3, String str4, Integer num4, Integer num5) {
        this.f22274a = num;
        this.f22275b = num2;
        this.f22276c = str;
        this.f22277d = aVar;
        this.f22278e = aVar2;
        this.f22279f = aVar3;
        this.f22280g = aVar4;
        this.f22281h = num3;
        this.f22282i = bool;
        this.f22283j = str2;
        this.k = f3;
        this.l = f11;
        this.f22284m = str3;
        this.f22285n = str4;
        this.f22286o = num4;
        this.f22287p = num5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return k.b(this.f22274a, bVar.f22274a) && k.b(this.f22275b, bVar.f22275b) && k.b(this.f22276c, bVar.f22276c) && k.b(this.f22277d, bVar.f22277d) && k.b(this.f22278e, bVar.f22278e) && k.b(this.f22279f, bVar.f22279f) && k.b(this.f22280g, bVar.f22280g) && k.b(this.f22281h, bVar.f22281h) && k.b(this.f22282i, bVar.f22282i) && k.b(this.f22283j, bVar.f22283j) && k.b(this.k, bVar.k) && k.b(this.l, bVar.l) && k.b(this.f22284m, bVar.f22284m) && k.b(this.f22285n, bVar.f22285n) && k.b(this.f22286o, bVar.f22286o) && k.b(this.f22287p, bVar.f22287p);
    }

    public final int hashCode() {
        Integer num = this.f22274a;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        Integer num2 = this.f22275b;
        int iHashCode2 = (iHashCode + (num2 == null ? 0 : num2.hashCode())) * 31;
        String str = this.f22276c;
        int iHashCode3 = (iHashCode2 + (str == null ? 0 : str.hashCode())) * 31;
        a aVar = this.f22277d;
        int iHashCode4 = (iHashCode3 + (aVar == null ? 0 : aVar.hashCode())) * 31;
        a aVar2 = this.f22278e;
        int iHashCode5 = (iHashCode4 + (aVar2 == null ? 0 : aVar2.hashCode())) * 31;
        a aVar3 = this.f22279f;
        int iHashCode6 = (iHashCode5 + (aVar3 == null ? 0 : aVar3.hashCode())) * 31;
        a aVar4 = this.f22280g;
        int iHashCode7 = (iHashCode6 + (aVar4 == null ? 0 : aVar4.hashCode())) * 31;
        Integer num3 = this.f22281h;
        int iHashCode8 = (iHashCode7 + (num3 == null ? 0 : num3.hashCode())) * 31;
        Boolean bool = this.f22282i;
        int iHashCode9 = (iHashCode8 + (bool == null ? 0 : bool.hashCode())) * 31;
        String str2 = this.f22283j;
        int iHashCode10 = (iHashCode9 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Float f3 = this.k;
        int iHashCode11 = (iHashCode10 + (f3 == null ? 0 : f3.hashCode())) * 31;
        Float f11 = this.l;
        int iHashCode12 = (iHashCode11 + (f11 == null ? 0 : f11.hashCode())) * 31;
        String str3 = this.f22284m;
        int iHashCode13 = (iHashCode12 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f22285n;
        int iHashCode14 = (iHashCode13 + (str4 == null ? 0 : str4.hashCode())) * 31;
        Integer num4 = this.f22286o;
        int iHashCode15 = (iHashCode14 + (num4 == null ? 0 : num4.hashCode())) * 31;
        Integer num5 = this.f22287p;
        return iHashCode15 + (num5 != null ? num5.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("TabsAppearance(tabBarBackgroundColor=");
        sb2.append(this.f22274a);
        sb2.append(", tabBarItemRippleColor=");
        sb2.append(this.f22275b);
        sb2.append(", tabBarItemLabelVisibilityMode=");
        sb2.append(this.f22276c);
        sb2.append(", normal=");
        sb2.append(this.f22277d);
        sb2.append(", selected=");
        sb2.append(this.f22278e);
        sb2.append(", focused=");
        sb2.append(this.f22279f);
        sb2.append(", disabled=");
        sb2.append(this.f22280g);
        sb2.append(", tabBarItemActiveIndicatorColor=");
        sb2.append(this.f22281h);
        sb2.append(", tabBarItemActiveIndicatorEnabled=");
        sb2.append(this.f22282i);
        sb2.append(", tabBarItemTitleFontFamily=");
        sb2.append(this.f22283j);
        sb2.append(", tabBarItemTitleSmallLabelFontSize=");
        sb2.append(this.k);
        sb2.append(", tabBarItemTitleLargeLabelFontSize=");
        sb2.append(this.l);
        sb2.append(", tabBarItemTitleFontWeight=");
        x2.t(sb2, this.f22284m, ", tabBarItemTitleFontStyle=", this.f22285n, ", tabBarItemBadgeBackgroundColor=");
        sb2.append(this.f22286o);
        sb2.append(", tabBarItemBadgeTextColor=");
        sb2.append(this.f22287p);
        sb2.append(")");
        return sb2.toString();
    }
}
