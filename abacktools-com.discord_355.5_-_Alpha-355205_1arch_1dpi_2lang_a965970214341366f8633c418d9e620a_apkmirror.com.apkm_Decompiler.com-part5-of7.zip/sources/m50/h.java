package m50;

/* JADX INFO: loaded from: classes3.dex */
public final class h extends k {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final k f21155i;

    public h(k elementType) {
        kotlin.jvm.internal.k.g(elementType, "elementType");
        this.f21155i = elementType;
    }
}
