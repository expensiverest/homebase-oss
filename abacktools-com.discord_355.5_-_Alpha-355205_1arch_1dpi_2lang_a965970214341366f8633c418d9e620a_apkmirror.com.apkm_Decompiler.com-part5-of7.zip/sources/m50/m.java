package m50;

/* JADX INFO: loaded from: classes3.dex */
public interface m {
    void B(y50.f fVar);

    l K(t50.b bVar);

    void j(t50.b bVar, t50.e eVar);

    void k();

    void u(Object obj);
}
