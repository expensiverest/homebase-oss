package m50;

/* JADX INFO: loaded from: classes3.dex */
public interface l {
    l C(t50.b bVar, t50.e eVar);

    void H(t50.e eVar, y50.f fVar);

    void k();

    void q(t50.e eVar, Object obj);

    m t(t50.e eVar);

    void z(t50.e eVar, t50.b bVar, t50.e eVar2);
}
