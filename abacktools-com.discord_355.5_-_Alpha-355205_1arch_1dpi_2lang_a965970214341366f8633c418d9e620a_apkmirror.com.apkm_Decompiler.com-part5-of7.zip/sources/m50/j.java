package m50;

/* JADX INFO: loaded from: classes3.dex */
public final class j extends k {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final b60.c f21157i;

    public j(b60.c cVar) {
        this.f21157i = cVar;
    }
}
