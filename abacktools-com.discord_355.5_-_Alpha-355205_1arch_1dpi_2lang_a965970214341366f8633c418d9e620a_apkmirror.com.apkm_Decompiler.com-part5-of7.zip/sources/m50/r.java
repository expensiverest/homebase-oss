package m50;

/* JADX INFO: loaded from: classes3.dex */
public final class r {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final r f21169i = new r(new r(null, 2047), 2012);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f21170a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f21171b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final r f21172c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21173d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final r f21174e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final r f21175f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f21176g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f21177h;

    public r(boolean z11, boolean z12, r rVar, boolean z13, r rVar2, r rVar3, boolean z14, boolean z15) {
        this.f21170a = z11;
        this.f21171b = z12;
        this.f21172c = rVar;
        this.f21173d = z13;
        this.f21174e = rVar2;
        this.f21175f = rVar3;
        this.f21176g = z14;
        this.f21177h = z15;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ r(r rVar, int i11) {
        boolean z11 = (i11 & 1) != 0;
        boolean z12 = (i11 & 2) != 0;
        r rVar2 = (i11 & 32) != 0 ? null : rVar;
        this(z11, z12, rVar2, true, rVar2, rVar2, (i11 & 512) == 0, (i11 & 1024) == 0);
    }
}
