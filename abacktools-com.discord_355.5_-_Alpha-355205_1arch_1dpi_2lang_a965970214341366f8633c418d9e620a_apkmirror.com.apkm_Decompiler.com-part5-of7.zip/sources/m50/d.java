package m50;

import java.util.Set;
import kotlin.jvm.functions.Function0;
import m30.s;

/* JADX INFO: loaded from: classes3.dex */
public final class d implements Function0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final d f21143d = new d();

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Set set = e.f21144b;
        return s.f20879d;
    }
}
