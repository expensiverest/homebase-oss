package m50;

import o50.f0;

/* JADX INFO: loaded from: classes3.dex */
public final class g implements i60.k {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final b60.b f21152d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final b60.b f21153e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final v40.b f21154i;

    public g(v40.b kotlinClass, f0 packageProto, s50.f nameResolver, boolean z11, i60.j jVar) {
        kotlin.jvm.internal.k.g(kotlinClass, "kotlinClass");
        kotlin.jvm.internal.k.g(packageProto, "packageProto");
        kotlin.jvm.internal.k.g(nameResolver, "nameResolver");
        b60.b bVar = new b60.b(b60.b.e(w40.c.a(kotlinClass.f32194a)));
        fy.a aVar = kotlinClass.f32195b;
        b60.b bVarC = null;
        String str = ((n50.a) aVar.f12558d) != n50.a.MULTIFILE_CLASS_PART ? null : (String) aVar.f12557c;
        if (str != null && str.length() > 0) {
            bVarC = b60.b.c(str);
        }
        this.f21152d = bVar;
        this.f21153e = bVarC;
        this.f21154i = kotlinClass;
        u50.m packageModuleName = r50.j.f27739m;
        kotlin.jvm.internal.k.f(packageModuleName, "packageModuleName");
        Integer num = (Integer) a.a.A(packageProto, packageModuleName);
        if (num != null) {
            nameResolver.getString(num.intValue());
        }
    }

    public final t50.b a() {
        t50.c cVar;
        b60.b bVar = this.f21152d;
        String str = bVar.f2873a;
        int iLastIndexOf = str.lastIndexOf("/");
        if (iLastIndexOf == -1) {
            cVar = t50.c.f29785c;
            if (cVar == null) {
                b60.b.a(9);
                throw null;
            }
        } else {
            cVar = new t50.c(str.substring(0, iLastIndexOf).replace('/', '.'));
        }
        String strD = bVar.d();
        kotlin.jvm.internal.k.f(strD, "getInternalName(...)");
        return new t50.b(cVar, t50.e.e(w60.o.P0('/', strD, strD)));
    }

    @Override // i60.k
    public final String f() {
        return a1.h.k(new StringBuilder("Class '"), a().a().f29786a.f29789a, '\'');
    }

    public final String toString() {
        return g.class.getSimpleName() + ": " + this.f21152d;
    }
}
