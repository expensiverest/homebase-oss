package m50;

import i60.w;

/* JADX INFO: loaded from: classes3.dex */
public final class o implements i60.k {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final v40.b f21166d;

    public o(v40.b bVar, w wVar, i60.j jVar) {
        this.f21166d = bVar;
    }

    @Override // i60.k
    public final String f() {
        return a1.h.k(new StringBuilder("Class '"), w40.c.a(this.f21166d.f32194a).a().f29786a.f29789a, '\'');
    }

    public final String toString() {
        return o.class.getSimpleName() + ": " + this.f21166d;
    }
}
