package m50;

/* JADX INFO: loaded from: classes3.dex */
public interface n {
    l e(t50.b bVar, v40.a aVar);
}
