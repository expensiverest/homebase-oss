package m50;

import java.util.HashMap;

/* JADX INFO: loaded from: classes3.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f21140a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f21141b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f21142c;

    public c(HashMap map, HashMap map2, HashMap map3) {
        this.f21140a = map;
        this.f21141b = map2;
        this.f21142c = map3;
    }
}
