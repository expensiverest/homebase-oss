package m50;

import i60.w;
import java.util.Set;
import o50.f0;
import q40.d0;

/* JADX INFO: loaded from: classes3.dex */
public final class e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Set f21144b = su.e.J(n50.a.CLASS);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Set f21145c = m30.k.v0(new n50.a[]{n50.a.FILE_FACADE, n50.a.MULTIFILE_CLASS_PART});

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final q50.e f21146d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final q50.e f21147e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public g60.i f21148a;

    static {
        new q50.e(new int[]{1, 1, 2}, false);
        f21146d = new q50.e(new int[]{1, 1, 11}, false);
        f21147e = new q50.e(new int[]{1, 1, 13}, false);
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0027  */
    public final i60.q a(d0 d0Var, v40.b kotlinClass) {
        l30.j jVarH;
        kotlin.jvm.internal.k.g(kotlinClass, "kotlinClass");
        fy.a aVar = kotlinClass.f32195b;
        String[] strArr = (String[]) aVar.f12560f;
        if (strArr == null) {
            strArr = (String[]) aVar.f12561g;
        }
        if (strArr != null) {
            if (!f21145c.contains((n50.a) aVar.f12558d)) {
                strArr = null;
            }
        } else {
            strArr = null;
        }
        if (strArr != null) {
            q50.e eVar = (q50.e) aVar.f12559e;
            String[] strArr2 = (String[]) aVar.f12562h;
            if (strArr2 != null) {
                try {
                    try {
                        jVarH = s50.g.h(strArr, strArr2);
                    } catch (u50.q e4) {
                        throw new IllegalStateException("Could not read data from " + kotlinClass.a(), e4);
                    }
                } catch (Throwable th2) {
                    c().f12849c.getClass();
                    if (eVar.b(e())) {
                        throw th2;
                    }
                    jVarH = null;
                }
                if (jVarH != null) {
                    s50.f fVar = (s50.f) jVarH.f19982d;
                    f0 f0Var = (f0) jVarH.f19983e;
                    d(kotlinClass);
                    g gVar = new g(kotlinClass, f0Var, fVar, f(kotlinClass), b(kotlinClass));
                    return new i60.q(d0Var, f0Var, fVar, eVar, gVar, c(), "scope for " + gVar + " in " + d0Var, d.f21143d);
                }
            }
        }
        return null;
    }

    public final i60.j b(v40.b bVar) {
        c().f12849c.getClass();
        int i11 = bVar.f32195b.f12556b;
        return ((i11 & 16) == 0 || (i11 & 32) != 0) ? i60.j.f15351d : i60.j.f15352e;
    }

    public final g60.i c() {
        g60.i iVar = this.f21148a;
        if (iVar != null) {
            return iVar;
        }
        kotlin.jvm.internal.k.q("components");
        throw null;
    }

    public final g60.n d(v40.b bVar) {
        c().f12849c.getClass();
        if (((q50.e) bVar.f32195b.f12559e).b(e())) {
            return null;
        }
        q50.e eVar = (q50.e) bVar.f32195b.f12559e;
        q50.e eVar2 = q50.e.f26625g;
        q50.e eVarE = e();
        q50.e eVarE2 = e();
        boolean z11 = eVar.f26627f;
        eVarE2.getClass();
        q50.e eVar3 = z11 ? eVar2 : q50.e.f26626h;
        int i11 = eVar3.f26597b;
        int i12 = eVarE2.f26597b;
        if (i11 > i12 || (i11 >= i12 && eVar3.f26598c > eVarE2.f26598c)) {
            eVarE2 = eVar3;
        }
        return new g60.n(eVar, eVar2, eVarE, eVarE2, bVar.a());
    }

    public final q50.e e() {
        c().f12849c.getClass();
        return q50.e.f26625g;
    }

    public final boolean f(v40.b bVar) {
        c().f12849c.getClass();
        c().f12849c.getClass();
        fy.a aVar = bVar.f32195b;
        return (aVar.f12556b & 2) != 0 && ((q50.e) aVar.f12559e).equals(f21146d);
    }

    /* JADX WARN: Code duplicated, block: B:10:0x001e  */
    public final g60.d g(v40.b bVar) {
        l30.j jVarF;
        fy.a aVar = bVar.f32195b;
        String[] strArr = (String[]) aVar.f12560f;
        if (strArr == null) {
            strArr = (String[]) aVar.f12561g;
        }
        if (strArr != null) {
            if (!f21144b.contains((n50.a) aVar.f12558d)) {
                strArr = null;
            }
        } else {
            strArr = null;
        }
        if (strArr != null) {
            q50.e eVar = (q50.e) aVar.f12559e;
            String[] strArr2 = (String[]) aVar.f12562h;
            try {
                if (strArr2 != null) {
                    try {
                        jVarF = s50.g.f(strArr, strArr2);
                        if (jVarF != null) {
                            s50.f fVar = (s50.f) jVarF.f19982d;
                            o50.k kVar = (o50.k) jVarF.f19983e;
                            d(bVar);
                            return new g60.d(fVar, kVar, eVar, new o(bVar, new w(f(bVar)), b(bVar)));
                        }
                    } catch (u50.q e4) {
                        throw new IllegalStateException("Could not read data from " + bVar.a(), e4);
                    }
                }
            } catch (Throwable th2) {
                c().f12849c.getClass();
                if (eVar.b(e())) {
                    throw th2;
                }
                jVarF = null;
            }
        }
        return null;
    }
}
