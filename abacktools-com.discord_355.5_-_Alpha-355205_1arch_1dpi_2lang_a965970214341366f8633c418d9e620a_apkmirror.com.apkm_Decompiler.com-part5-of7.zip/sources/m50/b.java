package m50;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final b f21136d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final b f21137e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final b f21138i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ b[] f21139v;

    static {
        b bVar = new b("PROPERTY", 0);
        f21136d = bVar;
        b bVar2 = new b("BACKING_FIELD", 1);
        f21137e = bVar2;
        b bVar3 = new b("DELEGATE_FIELD", 2);
        f21138i = bVar3;
        b[] bVarArr = {bVar, bVar2, bVar3};
        f21139v = bVarArr;
        oq.a.G(bVarArr);
    }

    public static b valueOf(String str) {
        return (b) Enum.valueOf(b.class, str);
    }

    public static b[] values() {
        return (b[]) f21139v.clone();
    }
}
