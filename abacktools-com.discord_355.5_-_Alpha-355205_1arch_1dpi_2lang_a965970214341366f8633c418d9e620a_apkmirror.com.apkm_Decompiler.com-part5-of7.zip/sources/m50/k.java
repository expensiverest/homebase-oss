package m50;

/* JADX INFO: loaded from: classes3.dex */
public abstract class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j f21158a = new j(b60.c.BOOLEAN);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final j f21159b = new j(b60.c.CHAR);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final j f21160c = new j(b60.c.BYTE);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final j f21161d = new j(b60.c.SHORT);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final j f21162e = new j(b60.c.INT);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final j f21163f = new j(b60.c.FLOAT);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final j f21164g = new j(b60.c.LONG);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final j f21165h = new j(b60.c.DOUBLE);

    public final String toString() {
        return f.z0(this);
    }
}
