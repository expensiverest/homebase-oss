package m50;

/* JADX INFO: loaded from: classes3.dex */
public final class i extends k {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f21156i;

    public i(String internalName) {
        kotlin.jvm.internal.k.g(internalName, "internalName");
        this.f21156i = internalName;
    }
}
