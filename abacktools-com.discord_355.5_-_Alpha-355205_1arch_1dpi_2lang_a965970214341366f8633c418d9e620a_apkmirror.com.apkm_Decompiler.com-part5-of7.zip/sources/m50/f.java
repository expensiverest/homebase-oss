package m50;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import k60.a0;
import k60.f0;
import k60.l0;
import k60.o0;
import k60.w;
import k60.y0;
import kotlin.jvm.internal.v;
import l60.t;
import o50.t0;
import q40.q0;

/* JADX INFO: loaded from: classes3.dex */
public final class f implements g60.m, l60.b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final f f21149d = new f();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final f f21150e = new f();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final f f21151i = new f();

    public static k I(String representation) {
        b60.c cVar;
        kotlin.jvm.internal.k.g(representation, "representation");
        char cCharAt = representation.charAt(0);
        b60.c[] cVarArrValues = b60.c.values();
        int length = cVarArrValues.length;
        int i11 = 0;
        while (true) {
            if (i11 >= length) {
                cVar = null;
                break;
            }
            cVar = cVarArrValues[i11];
            if (cVar.c().charAt(0) == cCharAt) {
                break;
            }
            i11++;
        }
        if (cVar != null) {
            return new j(cVar);
        }
        if (cCharAt == 'V') {
            return new j(null);
        }
        if (cCharAt == '[') {
            String strSubstring = representation.substring(1);
            kotlin.jvm.internal.k.f(strSubstring, "substring(...)");
            return new h(I(strSubstring));
        }
        if (cCharAt == 'L') {
            w60.o.r0(representation, ';');
        }
        String strSubstring2 = representation.substring(1, representation.length() - 1);
        kotlin.jvm.internal.k.f(strSubstring2, "substring(...)");
        return new i(strSubstring2);
    }

    public static String[] a(String... strArr) {
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add("<init>(" + str + ")V");
        }
        return (String[]) arrayList.toArray(new String[0]);
    }

    public static i b0(String internalName) {
        kotlin.jvm.internal.k.g(internalName, "internalName");
        return new i(internalName);
    }

    public static LinkedHashSet c0(String internalName, String... signatures) {
        kotlin.jvm.internal.k.g(internalName, "internalName");
        kotlin.jvm.internal.k.g(signatures, "signatures");
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        for (String str : signatures) {
            linkedHashSet.add(internalName + '.' + str);
        }
        return linkedHashSet;
    }

    public static LinkedHashSet q0(String str, String... signatures) {
        kotlin.jvm.internal.k.g(signatures, "signatures");
        return c0("java/lang/".concat(str), (String[]) Arrays.copyOf(signatures, signatures.length));
    }

    public static LinkedHashSet w0(String str, String... strArr) {
        return c0("java/util/".concat(str), (String[]) Arrays.copyOf(strArr, strArr.length));
    }

    public static String z0(k type) {
        String strC;
        kotlin.jvm.internal.k.g(type, "type");
        if (type instanceof h) {
            return "[" + z0(((h) type).f21155i);
        }
        if (type instanceof j) {
            b60.c cVar = ((j) type).f21157i;
            return (cVar == null || (strC = cVar.c()) == null) ? "V" : strC;
        }
        if (type instanceof i) {
            return a1.h.k(new StringBuilder("L"), ((i) type).f21156i, ';');
        }
        throw new an.g(false);
    }

    @Override // l60.b
    public boolean A(n60.e eVar) {
        kotlin.jvm.internal.k.g(eVar, "<this>");
        return l60.g.B(l60.g.Z(eVar));
    }

    @Override // l60.b
    public o0 B(n60.e eVar, int i11) {
        if (i11 < 0 || i11 >= l60.g.c(eVar)) {
            return null;
        }
        return l60.g.p(eVar, i11);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // l60.b
    public o0 C(n60.g gVar, int i11) {
        kotlin.jvm.internal.k.g(gVar, "<this>");
        if (gVar instanceof n60.f) {
            return l60.g.p((n60.d) gVar, i11);
        }
        if (gVar instanceof n60.a) {
            E e4 = ((n60.a) gVar).get(i11);
            kotlin.jvm.internal.k.f(e4, "get(...)");
            return (o0) e4;
        }
        throw new IllegalStateException(("unknown type argument list type: " + gVar + ", " + v.f19658a.b(gVar.getClass())).toString());
    }

    @Override // l60.b
    public /* bridge */ n60.c E(a0 a0Var) {
        return l60.g.e(this, a0Var);
    }

    @Override // l60.b
    public a0 F(n60.d dVar) {
        a0 a0VarQ;
        kotlin.jvm.internal.k.g(dVar, "<this>");
        k60.q qVarG = l60.g.g(dVar);
        if (qVarG != null && (a0VarQ = l60.g.Q(qVarG)) != null) {
            return a0VarQ;
        }
        a0 a0VarH = l60.g.h(dVar);
        kotlin.jvm.internal.k.d(a0VarH);
        return a0VarH;
    }

    @Override // l60.b
    public /* bridge */ void G(n60.e eVar) {
        l60.g.P(eVar);
    }

    @Override // l60.b
    public void H(n60.d dVar) {
        kotlin.jvm.internal.k.g(dVar, "<this>");
        l60.g.g(dVar);
    }

    @Override // l60.b
    public /* bridge */ boolean J(n60.h hVar) {
        return l60.g.B(hVar);
    }

    @Override // l60.b
    public boolean K(y0 y0Var) {
        kotlin.jvm.internal.k.g(y0Var, "<this>");
        return l60.g.I(F(y0Var)) != l60.g.I(S(y0Var));
    }

    @Override // l60.b
    public /* bridge */ int L(n60.h hVar) {
        return l60.g.T(hVar);
    }

    @Override // l60.b
    public /* bridge */ a0 M(k60.q qVar) {
        return l60.g.Q(qVar);
    }

    @Override // l60.b
    public boolean N(n60.e eVar) {
        return l60.g.G(l60.g.Z(eVar));
    }

    @Override // l60.b
    public y0 O(n60.d dVar) {
        return l60.g.S(dVar);
    }

    @Override // l60.b
    public /* bridge */ a0 P(k60.q qVar) {
        return l60.g.b0(qVar);
    }

    @Override // l60.b
    public /* bridge */ boolean Q(n60.d dVar) {
        return l60.g.E(dVar);
    }

    @Override // l60.b
    public /* bridge */ boolean R(n60.d dVar) {
        return l60.g.I(dVar);
    }

    @Override // l60.b
    public a0 S(n60.d dVar) {
        a0 a0VarB0;
        kotlin.jvm.internal.k.g(dVar, "<this>");
        k60.q qVarG = l60.g.g(dVar);
        if (qVarG != null && (a0VarB0 = l60.g.b0(qVarG)) != null) {
            return a0VarB0;
        }
        a0 a0VarH = l60.g.h(dVar);
        kotlin.jvm.internal.k.d(a0VarH);
        return a0VarH;
    }

    @Override // l60.b
    public y0 T(ArrayList arrayList) {
        a0 a0Var;
        int size = arrayList.size();
        if (size == 0) {
            throw new IllegalStateException("Expected some types");
        }
        if (size == 1) {
            return (y0) m30.q.H0(arrayList);
        }
        ArrayList arrayList2 = new ArrayList(m30.l.W(arrayList, 10));
        Iterator it = arrayList.iterator();
        boolean z11 = false;
        boolean z12 = false;
        while (it.hasNext()) {
            y0 y0Var = (y0) it.next();
            z11 = z11 || k60.c.k(y0Var);
            if (y0Var instanceof a0) {
                a0Var = (a0) y0Var;
            } else {
                if (!(y0Var instanceof k60.q)) {
                    throw new an.g(false);
                }
                a0Var = ((k60.q) y0Var).f19278e;
                z12 = true;
            }
            arrayList2.add(a0Var);
        }
        if (z11) {
            return m60.m.c(m60.l.INTERSECTION_OF_ERROR_TYPES, arrayList.toString());
        }
        t tVar = t.f20185a;
        if (!z12) {
            return tVar.b(arrayList2);
        }
        ArrayList arrayList3 = new ArrayList(m30.l.W(arrayList, 10));
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            arrayList3.add(k60.c.F((y0) it2.next()));
        }
        return k60.c.f(tVar.b(arrayList2), tVar.b(arrayList3));
    }

    @Override // l60.b
    public boolean U(n60.d receiver) {
        kotlin.jvm.internal.k.g(receiver, "$receiver");
        return receiver instanceof l50.g;
    }

    @Override // l60.b
    public /* bridge */ a0 V(w wVar) {
        return l60.g.h(wVar);
    }

    @Override // l60.b
    public /* bridge */ a0 W(n60.e eVar) {
        n60.b bVar = n60.b.f22658d;
        return l60.g.j(eVar);
    }

    @Override // l60.b
    public /* bridge */ Set X(n60.e eVar) {
        return l60.g.U(this, eVar);
    }

    @Override // l60.b
    public /* bridge */ boolean Y(n60.h hVar) {
        return l60.g.G(hVar);
    }

    @Override // l60.b
    public /* bridge */ k60.q Z(n60.d dVar) {
        return l60.g.g(dVar);
    }

    @Override // l60.b
    public /* bridge */ boolean a0(n60.h hVar) {
        return l60.g.D(hVar);
    }

    @Override // g60.m
    public w b(t0 proto, String flexibleId, a0 lowerBound, a0 upperBound) {
        kotlin.jvm.internal.k.g(proto, "proto");
        kotlin.jvm.internal.k.g(flexibleId, "flexibleId");
        kotlin.jvm.internal.k.g(lowerBound, "lowerBound");
        kotlin.jvm.internal.k.g(upperBound, "upperBound");
        if (flexibleId.equals("kotlin.jvm.PlatformType")) {
            return proto.j(r50.j.f27735g) ? new i50.h(lowerBound, upperBound) : k60.c.f(lowerBound, upperBound);
        }
        return m60.m.c(m60.l.ERROR_FLEXIBLE_TYPE, flexibleId, lowerBound.toString(), upperBound.toString());
    }

    @Override // l60.b
    public /* bridge */ boolean c(n60.e eVar, n60.e eVar2) {
        return l60.g.z(eVar, eVar2);
    }

    @Override // l60.b
    public /* bridge */ l60.a d(n60.e eVar) {
        return l60.g.X(this, eVar);
    }

    @Override // l60.b
    public /* bridge */ Collection d0(n60.h hVar) {
        return l60.g.Y(hVar);
    }

    @Override // l60.b
    public /* bridge */ boolean e(q0 q0Var, n60.h hVar) {
        return l60.g.y(q0Var, hVar);
    }

    @Override // l60.b
    public boolean e0(n60.c cVar) {
        return cVar instanceof x50.a;
    }

    @Override // l60.b
    public /* bridge */ l60.i f(n60.c cVar) {
        return l60.g.a0(cVar);
    }

    @Override // l60.b
    public /* bridge */ l0 f0(n60.e eVar) {
        return l60.g.Z(eVar);
    }

    @Override // l60.b
    public n40.i g() {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override // l60.b
    public int g0(n60.g gVar) {
        kotlin.jvm.internal.k.g(gVar, "<this>");
        if (gVar instanceof n60.e) {
            return l60.g.c((n60.d) gVar);
        }
        if (gVar instanceof n60.a) {
            return ((n60.a) gVar).size();
        }
        throw new IllegalStateException(("unknown type argument list type: " + gVar + ", " + v.f19658a.b(gVar.getClass())).toString());
    }

    @Override // l60.b
    public /* bridge */ boolean h(n60.h hVar, n60.h hVar2) {
        return l60.g.b(hVar, hVar2);
    }

    @Override // l60.b
    public /* bridge */ a0 h0(k60.q qVar) {
        return l60.g.Q(qVar);
    }

    @Override // l60.b
    public /* bridge */ q0 i(n60.h hVar, int i11) {
        return l60.g.r(hVar, i11);
    }

    @Override // l60.b
    public /* bridge */ o0 i0(n60.d dVar, int i11) {
        return l60.g.p(dVar, i11);
    }

    @Override // l60.b
    public /* bridge */ boolean j(n60.h hVar) {
        return l60.g.C(hVar);
    }

    @Override // l60.b
    public /* bridge */ n60.d j0(n60.d dVar) {
        return l60.g.d0(this, dVar);
    }

    @Override // l60.b
    public /* bridge */ void k(n60.e eVar) {
        l60.g.O(eVar);
    }

    @Override // l60.b
    public /* bridge */ a0 k0(n60.e eVar) {
        return l60.g.c0(eVar, true);
    }

    @Override // l60.b
    public /* bridge */ y0 l(n60.c cVar) {
        return l60.g.R(cVar);
    }

    @Override // l60.b
    public /* bridge */ boolean l0(n60.h hVar) {
        return l60.g.J(hVar);
    }

    @Override // l60.b
    public /* bridge */ boolean m(o0 o0Var) {
        return l60.g.N(o0Var);
    }

    @Override // l60.b
    public /* bridge */ boolean m0(n60.h hVar) {
        return l60.g.H(hVar);
    }

    @Override // l60.b
    public /* bridge */ n60.j n(q0 q0Var) {
        return l60.g.w(q0Var);
    }

    @Override // l60.b
    public /* bridge */ n60.b n0(n60.c cVar) {
        return l60.g.k(cVar);
    }

    @Override // l60.b
    public /* bridge */ n60.g o(n60.e eVar) {
        return l60.g.d(eVar);
    }

    @Override // l60.b
    public /* bridge */ a0 o0(k60.q qVar) {
        return l60.g.b0(qVar);
    }

    @Override // l60.b
    public /* bridge */ y0 p(n60.f fVar, n60.f fVar2) {
        return l60.g.m(this, fVar, fVar2);
    }

    @Override // l60.b
    public l0 p0(n60.d dVar) {
        kotlin.jvm.internal.k.g(dVar, "<this>");
        a0 a0VarH = l60.g.h(dVar);
        if (a0VarH == null) {
            a0VarH = F(dVar);
        }
        return l60.g.Z(a0VarH);
    }

    @Override // l60.b
    public n60.c q(n60.e eVar) {
        return l60.g.e(this, y0(eVar));
    }

    @Override // l60.b
    public boolean r(n60.d dVar) {
        kotlin.jvm.internal.k.g(dVar, "<this>");
        a0 a0VarH = l60.g.h(dVar);
        return (a0VarH != null ? l60.g.e(this, y0(a0VarH)) : null) != null;
    }

    @Override // l60.b
    public /* bridge */ a0 r0(n60.d dVar) {
        return l60.g.h(dVar);
    }

    @Override // l60.b
    public /* bridge */ o0 s(x50.b bVar) {
        return l60.g.V(bVar);
    }

    @Override // l60.b
    public /* bridge */ n60.j s0(o0 o0Var) {
        return l60.g.v(o0Var);
    }

    @Override // l60.b
    public boolean t(n60.d dVar) {
        kotlin.jvm.internal.k.g(dVar, "<this>");
        a0 a0VarH = l60.g.h(dVar);
        return (a0VarH != null ? l60.g.f(a0VarH) : null) != null;
    }

    @Override // l60.b
    public boolean t0(n60.d dVar) {
        kotlin.jvm.internal.k.g(dVar, "<this>");
        return !kotlin.jvm.internal.k.b(l60.g.Z(F(dVar)), l60.g.Z(S(dVar)));
    }

    @Override // l60.b
    public /* bridge */ boolean u(n60.h hVar) {
        return l60.g.A(hVar);
    }

    @Override // l60.b
    public /* bridge */ int u0(n60.d dVar) {
        return l60.g.c(dVar);
    }

    @Override // l60.b
    public boolean v(n60.e eVar) {
        kotlin.jvm.internal.k.g(eVar, "<this>");
        return l60.g.f(eVar) != null;
    }

    @Override // l60.b
    public /* bridge */ y0 v0(o0 o0Var) {
        return l60.g.t(this, o0Var);
    }

    @Override // l60.b
    public /* bridge */ f0 w(n60.d dVar) {
        return l60.g.i(dVar);
    }

    @Override // l60.b
    public /* bridge */ a0 x(n60.e eVar) {
        return l60.g.c0(eVar, false);
    }

    public n60.d x0(n60.d dVar) {
        a0 a0VarC0;
        kotlin.jvm.internal.k.g(dVar, "<this>");
        a0 a0VarH = l60.g.h(dVar);
        return (a0VarH == null || (a0VarC0 = l60.g.c0(a0VarH, true)) == null) ? dVar : a0VarC0;
    }

    @Override // l60.b
    public /* bridge */ boolean y(n60.c cVar) {
        return l60.g.M(cVar);
    }

    public n60.f y0(n60.e eVar) {
        a0 a0Var;
        k60.l lVarF = l60.g.f(eVar);
        return (lVarF == null || (a0Var = lVarF.f19269e) == null) ? (n60.f) eVar : a0Var;
    }

    @Override // l60.b
    public boolean z(n60.e eVar) {
        kotlin.jvm.internal.k.g(eVar, "<this>");
        return l60.g.J(p0(eVar)) && !l60.g.K(eVar);
    }

    @Override // l60.b
    public void D(n60.e eVar, n60.h hVar) {
    }
}
