package m50;

import kotlin.jvm.functions.Function1;

/* JADX INFO: loaded from: classes3.dex */
public final class q implements Function1 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final q f21168d = new q();

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String it = (String) obj;
        kotlin.jvm.internal.k.g(it, "it");
        return it.length() > 1 ? hs.q.i(';', "L", it) : it;
    }
}
