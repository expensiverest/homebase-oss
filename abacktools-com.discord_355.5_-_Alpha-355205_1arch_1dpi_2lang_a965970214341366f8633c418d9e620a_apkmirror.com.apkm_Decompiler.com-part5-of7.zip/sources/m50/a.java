package m50;

import kotlin.jvm.functions.Function2;

/* JADX INFO: loaded from: classes3.dex */
public final class a implements Function2 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f21133e = new a(0);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final a f21134i = new a(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21135d;

    public /* synthetic */ a(int i11) {
        this.f21135d = i11;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        c loadConstantFromProperty = (c) obj;
        p it = (p) obj2;
        switch (this.f21135d) {
            case 0:
                kotlin.jvm.internal.k.g(loadConstantFromProperty, "$this$loadConstantFromProperty");
                kotlin.jvm.internal.k.g(it, "it");
                return loadConstantFromProperty.f21142c.get(it);
            default:
                kotlin.jvm.internal.k.g(loadConstantFromProperty, "$this$loadConstantFromProperty");
                kotlin.jvm.internal.k.g(it, "it");
                return loadConstantFromProperty.f21141b.get(it);
        }
    }
}
