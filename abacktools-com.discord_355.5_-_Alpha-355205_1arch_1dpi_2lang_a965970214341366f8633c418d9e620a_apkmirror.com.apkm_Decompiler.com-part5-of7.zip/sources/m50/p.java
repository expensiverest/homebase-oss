package m50;

/* JADX INFO: loaded from: classes3.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f21167a;

    public p(String str) {
        this.f21167a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof p) && kotlin.jvm.internal.k.b(this.f21167a, ((p) obj).f21167a);
    }

    public final int hashCode() {
        return this.f21167a.hashCode();
    }

    public final String toString() {
        return a1.h.k(new StringBuilder("MemberSignature(signature="), this.f21167a, ')');
    }
}
