package m70;

import ay.f;
import l70.g;

/* JADX INFO: loaded from: classes3.dex */
public interface c {
    Object A(j70.b bVar);

    byte C();

    short E();

    float F();

    double H();

    f a();

    a b(g gVar);

    boolean d();

    char e();

    int k();

    int o(g gVar);

    String r();

    c t(g gVar);

    long u();

    boolean w();
}
