package m70;

import ay.f;
import l70.g;
import n70.x0;

/* JADX INFO: loaded from: classes3.dex */
public interface a {
    double D(g gVar, int i11);

    long I(g gVar, int i11);

    f a();

    void c(g gVar);

    Object f(g gVar, int i11, j70.b bVar, Object obj);

    byte g(x0 x0Var, int i11);

    c h(x0 x0Var, int i11);

    int i(g gVar);

    int m(g gVar);

    short n(x0 x0Var, int i11);

    int p(g gVar, int i11);

    char q(x0 x0Var, int i11);

    Object s(g gVar, int i11, j70.b bVar, Object obj);

    boolean v(g gVar, int i11);

    String x(g gVar, int i11);

    float y(g gVar, int i11);

    boolean z();
}
