package m70;

import j70.j;
import l70.g;
import n70.x0;

/* JADX INFO: loaded from: classes3.dex */
public interface b {
    void A(g gVar, int i11, j jVar, Object obj);

    boolean D(g gVar, int i11);

    void F(g gVar, int i11, boolean z11);

    void c(g gVar);

    void d(g gVar, int i11, String str);

    void l(x0 x0Var, int i11, short s4);

    void n(int i11, int i12, g gVar);

    void r(g gVar, int i11, double d11);

    void s(g gVar, int i11, j jVar, Object obj);

    void v(g gVar, int i11, long j6);

    d w(x0 x0Var, int i11);

    void x(x0 x0Var, int i11, char c11);

    void y(g gVar, int i11, float f3);

    void z(x0 x0Var, int i11, byte b11);
}
