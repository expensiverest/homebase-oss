package m70;

import ay.f;
import j70.j;
import l70.g;

/* JADX INFO: loaded from: classes3.dex */
public interface d {
    void C(int i11);

    d E(g gVar);

    void G(long j6);

    b H(g gVar, int i11);

    void I(String str);

    f a();

    b b(g gVar);

    void e();

    void f(double d11);

    void g(short s4);

    void h(byte b11);

    void i(boolean z11);

    void m(j jVar, Object obj);

    void o(float f3);

    void p(char c11);

    void q();

    void t(g gVar, int i11);
}
