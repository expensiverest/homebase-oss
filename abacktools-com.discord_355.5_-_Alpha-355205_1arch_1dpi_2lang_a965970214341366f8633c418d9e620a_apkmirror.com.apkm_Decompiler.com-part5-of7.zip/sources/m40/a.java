package m40;

import d50.w;
import java.util.LinkedHashSet;
import java.util.List;
import kotlin.jvm.internal.k;
import s1.e;
import t50.b;
import t50.c;

/* JADX INFO: loaded from: classes3.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final LinkedHashSet f21062a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f21063b;

    static {
        List<c> listU = e.u(w.f8963a, w.f8970h, w.f8971i, w.f8965c, w.f8966d, w.f8968f);
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        for (c topLevelFqName : listU) {
            k.g(topLevelFqName, "topLevelFqName");
            linkedHashSet.add(new b(topLevelFqName.b(), topLevelFqName.f29786a.g()));
        }
        f21062a = linkedHashSet;
        c REPEATABLE_ANNOTATION = w.f8969g;
        k.f(REPEATABLE_ANNOTATION, "REPEATABLE_ANNOTATION");
        f21063b = new b(REPEATABLE_ANNOTATION.b(), REPEATABLE_ANNOTATION.f29786a.g());
    }
}
