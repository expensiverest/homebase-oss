package m30;

/* JADX INFO: loaded from: classes3.dex */
public abstract class m extends l {
}
