package m30;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes3.dex */
public final class z extends f {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f20890d;

    public z(List delegate) {
        kotlin.jvm.internal.k.g(delegate, "delegate");
        this.f20890d = delegate;
    }

    @Override // m30.f
    public final int a() {
        return this.f20890d.size();
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i11, Object obj) {
        this.f20890d.add(q.a0(i11, this), obj);
    }

    @Override // m30.f
    public final Object b(int i11) {
        return this.f20890d.remove(q.Z(i11, this));
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final void clear() {
        this.f20890d.clear();
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i11) {
        return this.f20890d.get(q.Z(i11, this));
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        return new y(this, 0);
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator() {
        return new y(this, 0);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i11, Object obj) {
        return this.f20890d.set(q.Z(i11, this), obj);
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator(int i11) {
        return new y(this, i11);
    }
}
