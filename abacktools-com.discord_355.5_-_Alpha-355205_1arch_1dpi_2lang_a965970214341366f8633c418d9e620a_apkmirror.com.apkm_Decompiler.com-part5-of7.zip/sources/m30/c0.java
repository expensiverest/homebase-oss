package m30;

import java.util.Arrays;
import java.util.Iterator;
import java.util.RandomAccess;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public final class c0 extends e implements RandomAccess {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object[] f20858d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f20859e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20860i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f20861v;

    public c0(int i11, Object[] objArr) {
        this.f20858d = objArr;
        if (i11 < 0) {
            throw new IllegalArgumentException(hs.q.j(i11, "ring buffer filled size should not be negative but it is ").toString());
        }
        if (i11 <= objArr.length) {
            this.f20859e = objArr.length;
            this.f20861v = i11;
        } else {
            StringBuilder sbL = x2.l(i11, "ring buffer filled size: ", " cannot be larger than the buffer size: ");
            sbL.append(objArr.length);
            throw new IllegalArgumentException(sbL.toString().toString());
        }
    }

    @Override // m30.a
    public final int a() {
        return this.f20861v;
    }

    public final void b() {
        if (2 > this.f20861v) {
            throw new IllegalArgumentException(("n shouldn't be greater than the buffer size: n = 2, size = " + this.f20861v).toString());
        }
        int i11 = this.f20860i;
        int i12 = this.f20859e;
        int i13 = (i11 + 2) % i12;
        Object[] objArr = this.f20858d;
        if (i11 > i13) {
            Arrays.fill(objArr, i11, i12, (Object) null);
            Arrays.fill(objArr, 0, i13, (Object) null);
        } else {
            Arrays.fill(objArr, i11, i13, (Object) null);
        }
        this.f20860i = i13;
        this.f20861v -= 2;
    }

    @Override // java.util.List
    public final Object get(int i11) {
        int iA = a();
        if (i11 < 0 || i11 >= iA) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, iA, ", size: "));
        }
        return this.f20858d[(this.f20860i + i11) % this.f20859e];
    }

    @Override // m30.e, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        return new b0(this);
    }

    @Override // m30.a, java.util.Collection
    public final Object[] toArray() {
        return toArray(new Object[a()]);
    }

    @Override // m30.a, java.util.Collection
    public final Object[] toArray(Object[] array) {
        Object[] objArr;
        kotlin.jvm.internal.k.g(array, "array");
        int length = array.length;
        int i11 = this.f20861v;
        if (length < i11) {
            array = Arrays.copyOf(array, i11);
            kotlin.jvm.internal.k.f(array, "copyOf(...)");
        }
        int i12 = this.f20861v;
        int i13 = this.f20860i;
        int i14 = 0;
        int i15 = 0;
        while (true) {
            objArr = this.f20858d;
            if (i15 >= i12 || i13 >= this.f20859e) {
                break;
            }
            array[i15] = objArr[i13];
            i15++;
            i13++;
        }
        while (i15 < i12) {
            array[i15] = objArr[i14];
            i15++;
            i14++;
        }
        if (i12 < array.length) {
            array[i12] = null;
        }
        return array;
    }
}
