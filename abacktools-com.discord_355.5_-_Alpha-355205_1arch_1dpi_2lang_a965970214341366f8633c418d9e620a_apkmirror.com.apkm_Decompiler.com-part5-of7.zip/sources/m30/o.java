package m30;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public abstract class o extends n {
    public static void Y(Comparator comparator, List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        kotlin.jvm.internal.k.g(comparator, "comparator");
        if (list.size() > 1) {
            Collections.sort(list, comparator);
        }
    }
}
