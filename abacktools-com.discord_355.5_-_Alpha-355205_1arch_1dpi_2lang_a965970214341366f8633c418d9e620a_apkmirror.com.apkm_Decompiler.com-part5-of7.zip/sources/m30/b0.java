package m30;

/* JADX INFO: loaded from: classes3.dex */
public final class b0 extends b {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20854i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f20855v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ c0 f20856w;

    public b0(c0 c0Var) {
        this.f20856w = c0Var;
        this.f20854i = c0Var.f20861v;
        this.f20855v = c0Var.f20860i;
    }

    @Override // m30.b
    public final void a() {
        int i11 = this.f20854i;
        if (i11 == 0) {
            this.f20852d = 2;
            return;
        }
        c0 c0Var = this.f20856w;
        Object[] objArr = c0Var.f20858d;
        int i12 = this.f20855v;
        this.f20853e = objArr[i12];
        this.f20852d = 1;
        this.f20855v = (i12 + 1) % c0Var.f20859e;
        this.f20854i = i11 - 1;
    }
}
