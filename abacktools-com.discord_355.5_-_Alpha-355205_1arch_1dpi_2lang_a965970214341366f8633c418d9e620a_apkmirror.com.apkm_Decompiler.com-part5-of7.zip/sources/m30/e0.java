package m30;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import kotlin.jvm.functions.Function2;

/* JADX INFO: loaded from: classes3.dex */
public final class e0 extends s30.h implements Function2 {
    public final /* synthetic */ Iterator J;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f20865e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Iterator f20866i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f20867v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f20868w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f20869x;
    public /* synthetic */ Object y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e0(Iterator it, q30.c cVar) {
        super(2, cVar);
        this.J = it;
    }

    @Override // s30.a
    public final q30.c create(Object obj, q30.c cVar) {
        e0 e0Var = new e0(this.J, cVar);
        e0Var.y = obj;
        return e0Var;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        return ((e0) create((v60.l) obj, (q30.c) obj2)).invokeSuspend(l30.a0.f19963a);
    }

    @Override // s30.a
    public final Object invokeSuspend(Object obj) {
        int i11;
        int i12;
        ArrayList arrayList;
        Iterator it;
        int i13;
        int i14;
        int i15;
        c0 c0Var;
        Object[] array;
        v60.l lVar = (v60.l) this.y;
        r30.a aVar = r30.a.f27567d;
        int i16 = this.f20869x;
        boolean z11 = true;
        if (i16 != 0) {
            if (i16 != 1) {
                if (i16 != 2) {
                    if (i16 == 3) {
                        i14 = this.f20868w;
                        int i17 = this.f20867v;
                        Iterator it2 = this.f20866i;
                        c0 c0Var2 = (c0) this.f20865e;
                        android.support.v4.media.session.b.i0(obj);
                        c0Var2.b();
                        while (true) {
                            int i18 = c0Var2.f20859e;
                            Object[] objArr = c0Var2.f20858d;
                            if (!it2.hasNext()) {
                                i15 = i17;
                                c0Var = c0Var2;
                                break;
                            }
                            Object next = it2.next();
                            boolean z12 = z11;
                            if (c0Var2.a() == i18) {
                                throw new IllegalStateException("ring buffer is full");
                            }
                            int i19 = c0Var2.f20860i;
                            int i21 = c0Var2.f20861v;
                            objArr[(i19 + i21) % i18] = next;
                            c0Var2.f20861v = i21 + 1;
                            if (c0Var2.a() == i18) {
                                if (c0Var2.f20861v >= 2) {
                                    ArrayList arrayList2 = new ArrayList(c0Var2);
                                    this.y = lVar;
                                    this.f20865e = c0Var2;
                                    this.f20866i = it2;
                                    this.f20867v = i17;
                                    this.f20868w = i14;
                                    this.f20869x = 3;
                                    lVar.b(arrayList2, this);
                                    r30.a aVar2 = r30.a.f27567d;
                                    return aVar;
                                }
                                int i22 = i18 + (i18 >> 1) + 1;
                                if (i22 > 2) {
                                    i22 = 2;
                                }
                                if (c0Var2.f20860i == 0) {
                                    array = Arrays.copyOf(objArr, i22);
                                    kotlin.jvm.internal.k.f(array, "copyOf(...)");
                                } else {
                                    array = c0Var2.toArray(new Object[i22]);
                                }
                                c0Var2 = new c0(c0Var2.f20861v, array);
                            }
                            z11 = z12;
                        }
                    } else if (i16 == 4) {
                        i14 = this.f20868w;
                        i15 = this.f20867v;
                        c0Var = (c0) this.f20865e;
                        android.support.v4.media.session.b.i0(obj);
                        c0Var.b();
                    } else {
                        if (i16 != 5) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                    if (c0Var.f20861v > 2) {
                        ArrayList arrayList3 = new ArrayList(c0Var);
                        this.y = lVar;
                        this.f20865e = c0Var;
                        this.f20866i = null;
                        this.f20867v = i15;
                        this.f20868w = i14;
                        this.f20869x = 4;
                        lVar.b(arrayList3, this);
                        r30.a aVar3 = r30.a.f27567d;
                        return aVar;
                    }
                    if (!c0Var.isEmpty()) {
                        this.y = null;
                        this.f20865e = null;
                        this.f20866i = null;
                        this.f20867v = i15;
                        this.f20868w = i14;
                        this.f20869x = 5;
                        lVar.b(c0Var, this);
                        r30.a aVar4 = r30.a.f27567d;
                        return aVar;
                    }
                }
                android.support.v4.media.session.b.i0(obj);
            } else {
                i11 = this.f20868w;
                int i23 = this.f20867v;
                Iterator it3 = this.f20866i;
                android.support.v4.media.session.b.i0(obj);
                arrayList = new ArrayList(2);
                it = it3;
                i13 = i23;
                i12 = i11;
            }
            return l30.a0.f19963a;
        }
        android.support.v4.media.session.b.i0(obj);
        i11 = 0;
        i12 = 0;
        arrayList = new ArrayList(2);
        it = this.J;
        i13 = 2;
        while (it.hasNext()) {
            Object next2 = it.next();
            if (i11 > 0) {
                i11--;
            } else {
                arrayList.add(next2);
                if (arrayList.size() == 2) {
                    this.y = lVar;
                    this.f20865e = arrayList;
                    this.f20866i = it;
                    this.f20867v = i13;
                    this.f20868w = i12;
                    this.f20869x = 1;
                    lVar.b(arrayList, this);
                    r30.a aVar5 = r30.a.f27567d;
                    return aVar;
                }
            }
        }
        if (!arrayList.isEmpty()) {
            this.y = null;
            this.f20865e = null;
            this.f20866i = null;
            this.f20867v = i13;
            this.f20868w = i12;
            this.f20869x = 2;
            lVar.b(arrayList, this);
            r30.a aVar6 = r30.a.f27567d;
            return aVar;
        }
        return l30.a0.f19963a;
    }
}
