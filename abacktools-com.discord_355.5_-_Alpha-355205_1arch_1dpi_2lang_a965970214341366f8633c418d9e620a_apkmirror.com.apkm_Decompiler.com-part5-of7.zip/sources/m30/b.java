package m30;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes3.dex */
public abstract class b implements Iterator, b40.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f20852d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f20853e;

    public abstract void a();

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i11 = this.f20852d;
        if (i11 == 0) {
            this.f20852d = 3;
            a();
            return this.f20852d == 1;
        }
        if (i11 == 1) {
            return true;
        }
        if (i11 == 2) {
            return false;
        }
        throw new IllegalArgumentException("hasNext called when the iterator is in the FAILED state.");
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i11 = this.f20852d;
        if (i11 == 1) {
            this.f20852d = 0;
            return this.f20853e;
        }
        if (i11 != 2) {
            this.f20852d = 3;
            a();
            if (this.f20852d == 1) {
                this.f20852d = 0;
                return this.f20853e;
            }
        }
        throw new NoSuchElementException();
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
