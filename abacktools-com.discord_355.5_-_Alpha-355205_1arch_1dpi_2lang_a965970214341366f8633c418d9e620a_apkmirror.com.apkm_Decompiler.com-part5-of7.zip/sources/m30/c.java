package m30;

import androidx.core.view.d1;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes3.dex */
public final class c extends d1 implements ListIterator {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ e f20857v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(e eVar, int i11) {
        super(7, eVar);
        this.f20857v = eVar;
        int iA = eVar.a();
        if (i11 < 0 || i11 > iA) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, iA, ", size: "));
        }
        this.f1458e = i11;
    }

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.f1458e > 0;
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.f1458e;
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        int i11 = this.f1458e - 1;
        this.f1458e = i11;
        return this.f20857v.get(i11);
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.f1458e - 1;
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
