package m30;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: loaded from: classes3.dex */
public abstract class l extends s1.e {
    public static int W(Iterable iterable, int i11) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        return iterable instanceof Collection ? ((Collection) iterable).size() : i11;
    }

    public static ArrayList X(Collection collection) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        ArrayList arrayList = new ArrayList();
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            q.b0((Iterable) it.next(), arrayList);
        }
        return arrayList;
    }
}
