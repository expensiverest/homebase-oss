package m30;

import java.util.RandomAccess;

/* JADX INFO: loaded from: classes3.dex */
public final class j extends e implements RandomAccess {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int[] f20876d;

    public j(int[] iArr) {
        this.f20876d = iArr;
    }

    @Override // m30.a
    public final int a() {
        return this.f20876d.length;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0022 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:15:0x0024 A[RETURN] */
    @Override // m30.a, java.util.Collection
    public final boolean contains(Object obj) {
        if (!(obj instanceof Integer)) {
            return false;
        }
        int iIntValue = ((Number) obj).intValue();
        int[] iArr = this.f20876d;
        kotlin.jvm.internal.k.g(iArr, "<this>");
        int length = iArr.length;
        int i11 = 0;
        while (i11 < length) {
            if (iIntValue == iArr[i11]) {
                if (i11 >= 0) {
                    return true;
                }
                return false;
            }
            i11++;
        }
        i11 = -1;
        if (i11 >= 0) {
            return true;
        }
        return false;
    }

    @Override // java.util.List
    public final Object get(int i11) {
        return Integer.valueOf(this.f20876d[i11]);
    }

    @Override // m30.e, java.util.List
    public final int indexOf(Object obj) {
        if (!(obj instanceof Integer)) {
            return -1;
        }
        int iIntValue = ((Number) obj).intValue();
        int[] iArr = this.f20876d;
        kotlin.jvm.internal.k.g(iArr, "<this>");
        int length = iArr.length;
        for (int i11 = 0; i11 < length; i11++) {
            if (iIntValue == iArr[i11]) {
                return i11;
            }
        }
        return -1;
    }

    @Override // m30.a, java.util.Collection
    public final boolean isEmpty() {
        return this.f20876d.length == 0;
    }

    @Override // m30.e, java.util.List
    public final int lastIndexOf(Object obj) {
        if (!(obj instanceof Integer)) {
            return -1;
        }
        int iIntValue = ((Number) obj).intValue();
        int[] iArr = this.f20876d;
        kotlin.jvm.internal.k.g(iArr, "<this>");
        int length = iArr.length - 1;
        if (length >= 0) {
            while (true) {
                int i11 = length - 1;
                if (iIntValue == iArr[length]) {
                    return length;
                }
                if (i11 >= 0) {
                    length = i11;
                }
            }
        }
        return -1;
    }
}
