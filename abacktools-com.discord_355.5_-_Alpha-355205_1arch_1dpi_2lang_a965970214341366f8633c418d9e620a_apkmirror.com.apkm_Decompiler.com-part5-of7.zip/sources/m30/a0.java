package m30;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes3.dex */
public final class a0 extends e {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20850d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f20851e;

    public a0(List delegate) {
        kotlin.jvm.internal.k.g(delegate, "delegate");
        this.f20851e = delegate;
    }

    @Override // m30.a
    public final int a() {
        switch (this.f20850d) {
            case 0:
                return ((List) this.f20851e).size();
            default:
                return ((w60.k) this.f20851e).f33625a.groupCount() + 1;
        }
    }

    @Override // m30.a, java.util.Collection
    public /* bridge */ boolean contains(Object obj) {
        switch (this.f20850d) {
            case 1:
                if (obj instanceof String) {
                    return super.contains((String) obj);
                }
                return false;
            default:
                return super.contains(obj);
        }
    }

    @Override // java.util.List
    public final Object get(int i11) {
        switch (this.f20850d) {
            case 0:
                return ((List) this.f20851e).get(q.Z(i11, this));
            default:
                String strGroup = ((w60.k) this.f20851e).f33625a.group(i11);
                return strGroup == null ? "" : strGroup;
        }
    }

    @Override // m30.e, java.util.List
    public /* bridge */ int indexOf(Object obj) {
        switch (this.f20850d) {
            case 1:
                if (obj instanceof String) {
                    return super.indexOf((String) obj);
                }
                return -1;
            default:
                return super.indexOf(obj);
        }
    }

    @Override // m30.e, java.util.Collection, java.lang.Iterable, java.util.List
    public Iterator iterator() {
        switch (this.f20850d) {
            case 0:
                return new y(this, 0);
            default:
                return super.iterator();
        }
    }

    @Override // m30.e, java.util.List
    public /* bridge */ int lastIndexOf(Object obj) {
        switch (this.f20850d) {
            case 1:
                if (obj instanceof String) {
                    return super.lastIndexOf((String) obj);
                }
                return -1;
            default:
                return super.lastIndexOf(obj);
        }
    }

    @Override // m30.e, java.util.List
    public ListIterator listIterator() {
        switch (this.f20850d) {
            case 0:
                return new y(this, 0);
            default:
                return super.listIterator();
        }
    }

    @Override // m30.e, java.util.List
    public ListIterator listIterator(int i11) {
        switch (this.f20850d) {
            case 0:
                return new y(this, i11);
            default:
                return super.listIterator(i11);
        }
    }

    public a0(w60.k kVar) {
        this.f20851e = kVar;
    }
}
