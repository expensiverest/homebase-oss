package m30;

import androidx.core.view.c1;
import java.io.IOException;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import java.util.Set;
import kotlin.jvm.functions.Function1;
import p.x2;

/* JADX INFO: loaded from: classes3.dex */
public abstract class q extends o {
    public static ArrayList A0(Iterable iterable, Object obj) {
        if (iterable instanceof Collection) {
            return C0((Collection) iterable, obj);
        }
        ArrayList arrayList = new ArrayList();
        b0(iterable, arrayList);
        arrayList.add(obj);
        return arrayList;
    }

    public static ArrayList B0(Iterable elements, Collection collection) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        kotlin.jvm.internal.k.g(elements, "elements");
        if (!(elements instanceof Collection)) {
            ArrayList arrayList = new ArrayList(collection);
            b0(elements, arrayList);
            return arrayList;
        }
        Collection collection2 = (Collection) elements;
        ArrayList arrayList2 = new ArrayList(collection2.size() + collection.size());
        arrayList2.addAll(collection);
        arrayList2.addAll(collection2);
        return arrayList2;
    }

    public static ArrayList C0(Collection collection, Object obj) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        ArrayList arrayList = new ArrayList(collection.size() + 1);
        arrayList.addAll(collection);
        arrayList.add(obj);
        return arrayList;
    }

    public static void D0(List list, Function1 function1) {
        int iO;
        kotlin.jvm.internal.k.g(list, "<this>");
        if (!(list instanceof RandomAccess)) {
            if ((list instanceof b40.a) && !(list instanceof b40.b)) {
                kotlin.jvm.internal.y.i(list, "kotlin.collections.MutableIterable");
                throw null;
            }
            Iterator it = list.iterator();
            while (it.hasNext()) {
                if (((Boolean) function1.invoke(it.next())).booleanValue()) {
                    it.remove();
                }
            }
            return;
        }
        int iO2 = s1.e.o(list);
        int i11 = 0;
        if (iO2 >= 0) {
            int i12 = 0;
            while (true) {
                Object obj = list.get(i11);
                if (!((Boolean) function1.invoke(obj)).booleanValue()) {
                    if (i12 != i11) {
                        list.set(i12, obj);
                    }
                    i12++;
                }
                if (i11 == iO2) {
                    break;
                } else {
                    i11++;
                }
            }
            i11 = i12;
        }
        if (i11 >= list.size() || i11 > (iO = s1.e.o(list))) {
            return;
        }
        while (true) {
            list.remove(iO);
            if (iO == i11) {
                return;
            } else {
                iO--;
            }
        }
    }

    public static Object E0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.isEmpty()) {
            return null;
        }
        return list.remove(0);
    }

    public static Object F0(ArrayList arrayList) {
        kotlin.jvm.internal.k.g(arrayList, "<this>");
        if (arrayList.isEmpty()) {
            throw new NoSuchElementException("List is empty.");
        }
        return arrayList.remove(s1.e.o(arrayList));
    }

    public static List G0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if ((iterable instanceof Collection) && ((Collection) iterable).size() <= 1) {
            return S0(iterable);
        }
        List listU0 = U0(iterable);
        Collections.reverse(listU0);
        return listU0;
    }

    public static Object H0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof List) {
            return I0((List) iterable);
        }
        Iterator it = iterable.iterator();
        if (!it.hasNext()) {
            throw new NoSuchElementException("Collection is empty.");
        }
        Object next = it.next();
        if (it.hasNext()) {
            throw new IllegalArgumentException("Collection has more than one element.");
        }
        return next;
    }

    public static Object I0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        int size = list.size();
        if (size == 0) {
            throw new NoSuchElementException("List is empty.");
        }
        if (size == 1) {
            return list.get(0);
        }
        throw new IllegalArgumentException("List has more than one element.");
    }

    public static Object J0(Collection collection) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        if (collection instanceof List) {
            List list = (List) collection;
            if (list.size() == 1) {
                return list.get(0);
            }
            return null;
        }
        Iterator it = collection.iterator();
        if (!it.hasNext()) {
            return null;
        }
        Object next = it.next();
        if (it.hasNext()) {
            return null;
        }
        return next;
    }

    public static Object K0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.size() == 1) {
            return list.get(0);
        }
        return null;
    }

    public static List L0(List list, g40.c indices) {
        kotlin.jvm.internal.k.g(list, "<this>");
        kotlin.jvm.internal.k.g(indices, "indices");
        return indices.isEmpty() ? s.f20879d : S0(list.subList(indices.f12690d, indices.f12691e + 1));
    }

    public static List M0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.size() <= 1) {
            return S0(list);
        }
        Object[] array = list.toArray(new Comparable[0]);
        Comparable[] comparableArr = (Comparable[]) array;
        kotlin.jvm.internal.k.g(comparableArr, "<this>");
        if (comparableArr.length > 1) {
            Arrays.sort(comparableArr);
        }
        return k.Q(array);
    }

    public static List N0(Collection collection, Comparator comparator) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        if (collection.size() <= 1) {
            return S0(collection);
        }
        Object[] array = collection.toArray(new Object[0]);
        k.p0(array, comparator);
        return k.Q(array);
    }

    public static List O0(Iterable iterable, int i11) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (i11 < 0) {
            throw new IllegalArgumentException(x2.e(i11, "Requested element count ", " is less than zero.").toString());
        }
        if (i11 == 0) {
            return s.f20879d;
        }
        if (iterable instanceof Collection) {
            if (i11 >= ((Collection) iterable).size()) {
                return S0(iterable);
            }
            if (i11 == 1) {
                return s1.e.t(m0(iterable));
            }
        }
        ArrayList arrayList = new ArrayList(i11);
        Iterator it = iterable.iterator();
        int i12 = 0;
        while (it.hasNext()) {
            arrayList.add(it.next());
            i12++;
            if (i12 == i11) {
                break;
            }
        }
        return s1.e.A(arrayList);
    }

    public static final void P0(Iterable iterable, AbstractCollection abstractCollection) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            abstractCollection.add(it.next());
        }
    }

    public static HashSet Q0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        HashSet hashSet = new HashSet(x.p0(l.W(iterable, 12)));
        P0(iterable, hashSet);
        return hashSet;
    }

    public static int[] R0(ArrayList arrayList) {
        int[] iArr = new int[arrayList.size()];
        Iterator it = arrayList.iterator();
        int i11 = 0;
        while (it.hasNext()) {
            iArr[i11] = ((Number) it.next()).intValue();
            i11++;
        }
        return iArr;
    }

    public static List S0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return s1.e.A(U0(iterable));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return s.f20879d;
        }
        if (size != 1) {
            return T0(collection);
        }
        return s1.e.t(iterable instanceof List ? ((List) iterable).get(0) : collection.iterator().next());
    }

    public static ArrayList T0(Collection collection) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        return new ArrayList(collection);
    }

    public static final List U0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof Collection) {
            return T0((Collection) iterable);
        }
        ArrayList arrayList = new ArrayList();
        P0(iterable, arrayList);
        return arrayList;
    }

    public static Set V0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof Collection) {
            return new LinkedHashSet((Collection) iterable);
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        P0(iterable, linkedHashSet);
        return linkedHashSet;
    }

    public static Set W0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof Collection) {
            Collection collection = (Collection) iterable;
            int size = collection.size();
            if (size != 0) {
                if (size == 1) {
                    return su.e.J(iterable instanceof List ? ((List) iterable).get(0) : collection.iterator().next());
                }
                LinkedHashSet linkedHashSet = new LinkedHashSet(x.p0(collection.size()));
                P0(iterable, linkedHashSet);
                return linkedHashSet;
            }
        } else {
            LinkedHashSet linkedHashSet2 = new LinkedHashSet();
            P0(iterable, linkedHashSet2);
            int size2 = linkedHashSet2.size();
            if (size2 != 0) {
                return size2 != 1 ? linkedHashSet2 : su.e.J(linkedHashSet2.iterator().next());
            }
        }
        return u.f20881d;
    }

    public static l70.i X0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        return new l70.i(2, new ld.c(3, list));
    }

    public static ArrayList Y0(List list, List other) {
        kotlin.jvm.internal.k.g(list, "<this>");
        kotlin.jvm.internal.k.g(other, "other");
        Iterator it = list.iterator();
        Iterator it2 = other.iterator();
        ArrayList arrayList = new ArrayList(Math.min(l.W(list, 10), l.W(other, 10)));
        while (it.hasNext() && it2.hasNext()) {
            arrayList.add(new l30.j(it.next(), it2.next()));
        }
        return arrayList;
    }

    public static final int Z(int i11, List list) {
        if (i11 >= 0 && i11 <= s1.e.o(list)) {
            return s1.e.o(list) - i11;
        }
        StringBuilder sbL = x2.l(i11, "Element index ", " must be in range [");
        sbL.append(new g40.c(0, s1.e.o(list), 1));
        sbL.append("].");
        throw new IndexOutOfBoundsException(sbL.toString());
    }

    public static final int a0(int i11, List list) {
        if (i11 >= 0 && i11 <= list.size()) {
            return list.size() - i11;
        }
        StringBuilder sbL = x2.l(i11, "Position index ", " must be in range [");
        sbL.append(new g40.c(0, list.size(), 1));
        sbL.append("].");
        throw new IndexOutOfBoundsException(sbL.toString());
    }

    public static void b0(Iterable elements, Collection collection) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        kotlin.jvm.internal.k.g(elements, "elements");
        if (elements instanceof Collection) {
            collection.addAll((Collection) elements);
            return;
        }
        Iterator it = elements.iterator();
        while (it.hasNext()) {
            collection.add(it.next());
        }
    }

    public static void c0(ArrayList arrayList, v60.k elements) {
        kotlin.jvm.internal.k.g(arrayList, "<this>");
        kotlin.jvm.internal.k.g(elements, "elements");
        Iterator it = elements.iterator();
        while (it.hasNext()) {
            arrayList.add(it.next());
        }
    }

    public static boolean d0(Collection collection, Object[] elements) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        kotlin.jvm.internal.k.g(elements, "elements");
        return collection.addAll(k.Q(elements));
    }

    public static a0 e0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        return new a0(list);
    }

    public static z f0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        return new z(list);
    }

    public static c1 g0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        return new c1(2, iterable);
    }

    public static double h0(ArrayList arrayList) {
        Iterator it = arrayList.iterator();
        double dFloatValue = 0.0d;
        int i11 = 0;
        while (it.hasNext()) {
            dFloatValue += (double) ((Number) it.next()).floatValue();
            i11++;
            if (i11 < 0) {
                throw new ArithmeticException("Count overflow has happened.");
            }
        }
        if (i11 == 0) {
            return Double.NaN;
        }
        return dFloatValue / ((double) i11);
    }

    public static boolean i0(Iterable iterable, Object obj) {
        int iIndexOf;
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof Collection) {
            return ((Collection) iterable).contains(obj);
        }
        if (!(iterable instanceof List)) {
            Iterator it = iterable.iterator();
            int i11 = 0;
            while (true) {
                if (!it.hasNext()) {
                    iIndexOf = -1;
                    break;
                }
                Object next = it.next();
                if (i11 < 0) {
                    s1.e.P();
                    throw null;
                }
                if (kotlin.jvm.internal.k.b(obj, next)) {
                    iIndexOf = i11;
                    break;
                }
                i11++;
            }
        } else {
            iIndexOf = ((List) iterable).indexOf(obj);
        }
        return iIndexOf >= 0;
    }

    public static List j0(int i11, List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (i11 < 0) {
            throw new IllegalArgumentException(x2.e(i11, "Requested element count ", " is less than zero.").toString());
        }
        if (i11 == 0) {
            return S0(list);
        }
        int size = list.size() - i11;
        if (size <= 0) {
            return s.f20879d;
        }
        if (size == 1) {
            return s1.e.t(u0(list));
        }
        ArrayList arrayList = new ArrayList(size);
        if (list instanceof RandomAccess) {
            int size2 = list.size();
            while (i11 < size2) {
                arrayList.add(list.get(i11));
                i11++;
            }
        } else {
            ListIterator listIterator = list.listIterator(i11);
            while (listIterator.hasNext()) {
                arrayList.add(listIterator.next());
            }
        }
        return arrayList;
    }

    public static List k0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        int size = list.size() - 1;
        if (size < 0) {
            size = 0;
        }
        return O0(list, size);
    }

    public static List l0(List list) {
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (obj != null) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    public static Object m0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof List) {
            return n0((List) iterable);
        }
        Iterator it = iterable.iterator();
        if (it.hasNext()) {
            return it.next();
        }
        throw new NoSuchElementException("Collection is empty.");
    }

    public static Object n0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.isEmpty()) {
            throw new NoSuchElementException("List is empty.");
        }
        return list.get(0);
    }

    public static Object o0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof List) {
            List list = (List) iterable;
            if (list.isEmpty()) {
                return null;
            }
            return list.get(0);
        }
        Iterator it = iterable.iterator();
        if (it.hasNext()) {
            return it.next();
        }
        return null;
    }

    public static Object p0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public static Object q0(int i11, List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (i11 < 0 || i11 >= list.size()) {
            return null;
        }
        return list.get(i11);
    }

    public static final void r0(Iterable iterable, Appendable buffer, CharSequence separator, CharSequence prefix, CharSequence postfix, CharSequence charSequence, Function1 function1) throws IOException {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        kotlin.jvm.internal.k.g(buffer, "buffer");
        kotlin.jvm.internal.k.g(separator, "separator");
        kotlin.jvm.internal.k.g(prefix, "prefix");
        kotlin.jvm.internal.k.g(postfix, "postfix");
        buffer.append(prefix);
        int i11 = 0;
        for (Object obj : iterable) {
            i11++;
            if (i11 > 1) {
                buffer.append(separator);
            }
            e00.a.b(buffer, obj, function1);
        }
        buffer.append(postfix);
    }

    public static /* synthetic */ void s0(Iterable iterable, StringBuilder sb2, String str, String str2, String str3, Function1 function1, int i11) throws IOException {
        if ((i11 & 2) != 0) {
            str = ", ";
        }
        String str4 = str;
        String str5 = (i11 & 4) != 0 ? "" : str2;
        String str6 = (i11 & 8) != 0 ? "" : str3;
        if ((i11 & 64) != 0) {
            function1 = null;
        }
        r0(iterable, sb2, str4, str5, str6, "...", function1);
    }

    public static String t0(Iterable iterable, String str, String str2, String str3, Function1 function1, int i11) throws IOException {
        if ((i11 & 1) != 0) {
            str = ", ";
        }
        String str4 = str;
        String prefix = (i11 & 2) != 0 ? "" : str2;
        String str5 = (i11 & 4) != 0 ? "" : str3;
        if ((i11 & 32) != 0) {
            function1 = null;
        }
        kotlin.jvm.internal.k.g(iterable, "<this>");
        kotlin.jvm.internal.k.g(prefix, "prefix");
        StringBuilder sb2 = new StringBuilder();
        r0(iterable, sb2, str4, prefix, str5, "...", function1);
        return sb2.toString();
    }

    public static Object u0(Iterable iterable) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof List) {
            return v0((List) iterable);
        }
        Iterator it = iterable.iterator();
        if (!it.hasNext()) {
            throw new NoSuchElementException("Collection is empty.");
        }
        Object next = it.next();
        while (it.hasNext()) {
            next = it.next();
        }
        return next;
    }

    public static Object v0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.isEmpty()) {
            throw new NoSuchElementException("List is empty.");
        }
        return list.get(s1.e.o(list));
    }

    public static Object w0(Collection collection) {
        kotlin.jvm.internal.k.g(collection, "<this>");
        if (collection instanceof List) {
            List list = (List) collection;
            if (list.isEmpty()) {
                return null;
            }
            return x2.d(1, list);
        }
        Iterator it = collection.iterator();
        if (!it.hasNext()) {
            return null;
        }
        Object next = it.next();
        while (it.hasNext()) {
            next = it.next();
        }
        return next;
    }

    public static Object x0(List list) {
        kotlin.jvm.internal.k.g(list, "<this>");
        if (list.isEmpty()) {
            return null;
        }
        return x2.d(1, list);
    }

    public static List y0(Iterable iterable, Set set) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (set.isEmpty()) {
            return S0(iterable);
        }
        ArrayList arrayList = new ArrayList();
        for (Object obj : iterable) {
            if (!set.contains(obj)) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    public static ArrayList z0(Iterable iterable, Iterable iterable2) {
        kotlin.jvm.internal.k.g(iterable, "<this>");
        if (iterable instanceof Collection) {
            return B0(iterable2, (Collection) iterable);
        }
        ArrayList arrayList = new ArrayList();
        b0(iterable, arrayList);
        b0(iterable2, arrayList);
        return arrayList;
    }
}
