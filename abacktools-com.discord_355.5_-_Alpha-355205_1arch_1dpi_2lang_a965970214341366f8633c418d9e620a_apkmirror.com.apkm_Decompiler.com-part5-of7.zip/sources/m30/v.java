package m30;

/* JADX INFO: loaded from: classes3.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f20882a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f20883b;

    public v(int i11, Object obj) {
        this.f20882a = i11;
        this.f20883b = obj;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof v)) {
            return false;
        }
        v vVar = (v) obj;
        return this.f20882a == vVar.f20882a && kotlin.jvm.internal.k.b(this.f20883b, vVar.f20883b);
    }

    public final int hashCode() {
        int iHashCode = Integer.hashCode(this.f20882a) * 31;
        Object obj = this.f20883b;
        return iHashCode + (obj == null ? 0 : obj.hashCode());
    }

    public final String toString() {
        return "IndexedValue(index=" + this.f20882a + ", value=" + this.f20883b + ')';
    }
}
