package m30;

import java.util.List;
import java.util.RandomAccess;

/* JADX INFO: loaded from: classes3.dex */
public final class d extends e implements RandomAccess {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f20862d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f20863e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f20864i;

    public d(e eVar, int i11, int i12) {
        this.f20862d = eVar;
        this.f20863e = i11;
        oq.a.x(i11, i12, eVar.a());
        this.f20864i = i12 - i11;
    }

    @Override // m30.a
    public final int a() {
        return this.f20864i;
    }

    @Override // java.util.List
    public final Object get(int i11) {
        int i12 = this.f20864i;
        if (i11 < 0 || i11 >= i12) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, i12, ", size: "));
        }
        return this.f20862d.get(this.f20863e + i11);
    }

    @Override // m30.e, java.util.List
    public final List subList(int i11, int i12) {
        oq.a.x(i11, i12, this.f20864i);
        int i13 = this.f20863e;
        return new d(this.f20862d, i11 + i13, i13 + i12);
    }
}
