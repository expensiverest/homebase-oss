package m30;

import androidx.core.view.c1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.jvm.functions.Function1;

/* JADX INFO: loaded from: classes3.dex */
public abstract class k extends ox.b {
    public static Iterable P(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        return objArr.length == 0 ? s.f20879d : new l70.i(1, objArr);
    }

    public static List Q(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        List listAsList = Arrays.asList(objArr);
        kotlin.jvm.internal.k.f(listAsList, "asList(...)");
        return listAsList;
    }

    public static v60.k R(Object[] objArr) {
        return objArr.length == 0 ? v60.f.f32556a : new c1(1, objArr);
    }

    public static boolean S(Object obj, Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        return j0(obj, objArr) >= 0;
    }

    public static void T(int i11, int i12, int i13, byte[] bArr, byte[] destination) {
        kotlin.jvm.internal.k.g(bArr, "<this>");
        kotlin.jvm.internal.k.g(destination, "destination");
        System.arraycopy(bArr, i12, destination, i11, i13 - i12);
    }

    public static void U(int i11, int i12, int i13, int[] iArr, int[] destination) {
        kotlin.jvm.internal.k.g(iArr, "<this>");
        kotlin.jvm.internal.k.g(destination, "destination");
        System.arraycopy(iArr, i12, destination, i11, i13 - i12);
    }

    public static void V(int i11, int i12, int i13, Object[] objArr, Object[] destination) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        kotlin.jvm.internal.k.g(destination, "destination");
        System.arraycopy(objArr, i12, destination, i11, i13 - i12);
    }

    public static void W(long[] jArr, long[] destination, int i11, int i12, int i13) {
        kotlin.jvm.internal.k.g(jArr, "<this>");
        kotlin.jvm.internal.k.g(destination, "destination");
        System.arraycopy(jArr, i12, destination, i11, i13 - i12);
    }

    public static /* synthetic */ void X(int i11, int i12, int i13, Object[] objArr, Object[] objArr2) {
        if ((i13 & 4) != 0) {
            i11 = 0;
        }
        if ((i13 & 8) != 0) {
            i12 = objArr.length;
        }
        V(0, i11, i12, objArr, objArr2);
    }

    public static /* synthetic */ void Y(int i11, int i12, int[] iArr, int[] iArr2) {
        if ((i12 & 8) != 0) {
            i11 = iArr.length;
        }
        U(0, 0, i11, iArr, iArr2);
    }

    public static byte[] Z(byte[] bArr, int i11, int i12) {
        kotlin.jvm.internal.k.g(bArr, "<this>");
        ox.b.g(i12, bArr.length);
        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, i11, i12);
        kotlin.jvm.internal.k.f(bArrCopyOfRange, "copyOfRange(...)");
        return bArrCopyOfRange;
    }

    public static Object[] a0(Object[] objArr, int i11, int i12) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        ox.b.g(i12, objArr.length);
        Object[] objArrCopyOfRange = Arrays.copyOfRange(objArr, i11, i12);
        kotlin.jvm.internal.k.f(objArrCopyOfRange, "copyOfRange(...)");
        return objArrCopyOfRange;
    }

    public static void b0(Object[] objArr, Object obj, int i11, int i12) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        Arrays.fill(objArr, i11, i12, obj);
    }

    public static void c0(long[] jArr, long j6) {
        int length = jArr.length;
        kotlin.jvm.internal.k.g(jArr, "<this>");
        Arrays.fill(jArr, 0, length, j6);
    }

    public static ArrayList e0(Object[] objArr) {
        ArrayList arrayList = new ArrayList();
        for (Object obj : objArr) {
            if (obj != null) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }

    public static Object f0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        if (objArr.length != 0) {
            return objArr[0];
        }
        throw new NoSuchElementException("Array is empty.");
    }

    public static Object g0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        if (objArr.length == 0) {
            return null;
        }
        return objArr[0];
    }

    public static Integer h0(int i11, int[] iArr) {
        kotlin.jvm.internal.k.g(iArr, "<this>");
        if (i11 < 0 || i11 >= iArr.length) {
            return null;
        }
        return Integer.valueOf(iArr[i11]);
    }

    public static Object i0(int i11, Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        if (i11 < 0 || i11 >= objArr.length) {
            return null;
        }
        return objArr[i11];
    }

    public static int j0(Object obj, Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        int i11 = 0;
        if (obj == null) {
            int length = objArr.length;
            while (i11 < length) {
                if (objArr[i11] == null) {
                    return i11;
                }
                i11++;
            }
            return -1;
        }
        int length2 = objArr.length;
        while (i11 < length2) {
            if (obj.equals(objArr[i11])) {
                return i11;
            }
            i11++;
        }
        return -1;
    }

    public static final void k0(Object[] objArr, StringBuilder sb2, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, CharSequence charSequence4, Function1 function1) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        sb2.append(charSequence2);
        int i11 = 0;
        for (Object obj : objArr) {
            i11++;
            if (i11 > 1) {
                sb2.append(charSequence);
            }
            e00.a.b(sb2, obj, function1);
        }
        sb2.append(charSequence3);
    }

    public static String l0(int i11, int[] iArr) {
        kotlin.jvm.internal.k.g(iArr, "<this>");
        StringBuilder sb2 = new StringBuilder();
        sb2.append((CharSequence) "");
        int i12 = 0;
        for (int i13 : iArr) {
            i12++;
            if (i12 > 1) {
                sb2.append((CharSequence) ", ");
            }
            sb2.append((CharSequence) String.valueOf(i13));
        }
        sb2.append((CharSequence) "");
        return sb2.toString();
    }

    public static String m0(Object[] objArr, String str, String str2, String str3, Function1 function1, int i11) {
        if ((i11 & 1) != 0) {
            str = ", ";
        }
        String str4 = str;
        String str5 = (i11 & 2) != 0 ? "" : str2;
        String str6 = (i11 & 4) != 0 ? "" : str3;
        if ((i11 & 32) != 0) {
            function1 = null;
        }
        kotlin.jvm.internal.k.g(objArr, "<this>");
        StringBuilder sb2 = new StringBuilder();
        k0(objArr, sb2, str4, str5, str6, "...", function1);
        return sb2.toString();
    }

    public static Object n0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        if (objArr.length != 0) {
            return objArr[objArr.length - 1];
        }
        throw new NoSuchElementException("Array is empty.");
    }

    public static Object o0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        int length = objArr.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        }
        if (length == 1) {
            return objArr[0];
        }
        throw new IllegalArgumentException("Array has more than one element.");
    }

    public static void p0(Object[] objArr, Comparator comparator) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        if (objArr.length > 1) {
            Arrays.sort(objArr, comparator);
        }
    }

    public static List q0(Object[] objArr, Comparator comparator) {
        if (objArr.length != 0) {
            objArr = Arrays.copyOf(objArr, objArr.length);
            kotlin.jvm.internal.k.f(objArr, "copyOf(...)");
            p0(objArr, comparator);
        }
        return Q(objArr);
    }

    public static final void r0(Object[] objArr, HashSet hashSet) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        for (Object obj : objArr) {
            hashSet.add(obj);
        }
    }

    public static List s0(int[] iArr) {
        kotlin.jvm.internal.k.g(iArr, "<this>");
        int length = iArr.length;
        if (length == 0) {
            return s.f20879d;
        }
        if (length == 1) {
            return s1.e.t(Integer.valueOf(iArr[0]));
        }
        ArrayList arrayList = new ArrayList(iArr.length);
        for (int i11 : iArr) {
            arrayList.add(Integer.valueOf(i11));
        }
        return arrayList;
    }

    public static List t0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        int length = objArr.length;
        if (length != 0) {
            return length != 1 ? u0(objArr) : s1.e.t(objArr[0]);
        }
        return s.f20879d;
    }

    public static ArrayList u0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        return new ArrayList(new h(objArr, false));
    }

    public static Set v0(Object[] objArr) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        int length = objArr.length;
        if (length == 0) {
            return u.f20881d;
        }
        if (length == 1) {
            return su.e.J(objArr[0]);
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet(x.p0(objArr.length));
        r0(objArr, linkedHashSet);
        return linkedHashSet;
    }

    public static ArrayList w0(Object[] objArr, Object[] other) {
        kotlin.jvm.internal.k.g(objArr, "<this>");
        kotlin.jvm.internal.k.g(other, "other");
        int iMin = Math.min(objArr.length, other.length);
        ArrayList arrayList = new ArrayList(iMin);
        for (int i11 = 0; i11 < iMin; i11++) {
            arrayList.add(new l30.j(objArr[i11], other[i11]));
        }
        return arrayList;
    }
}
