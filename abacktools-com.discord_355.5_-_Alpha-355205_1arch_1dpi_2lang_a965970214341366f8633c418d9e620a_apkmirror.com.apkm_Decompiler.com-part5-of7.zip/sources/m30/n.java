package m30;

/* JADX INFO: loaded from: classes3.dex */
public abstract class n extends m {
}
