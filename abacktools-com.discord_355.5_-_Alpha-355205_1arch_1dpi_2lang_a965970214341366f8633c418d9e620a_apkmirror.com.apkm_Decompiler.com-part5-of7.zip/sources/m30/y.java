package m30;

import java.util.List;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes3.dex */
public final class y implements ListIterator, b40.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20887d = 1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ListIterator f20888e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f20889i;

    public y(a0 a0Var, int i11) {
        this.f20889i = a0Var;
        this.f20888e = ((List) a0Var.f20851e).listIterator(q.a0(i11, a0Var));
    }

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        switch (this.f20887d) {
            case 0:
                ListIterator listIterator = this.f20888e;
                listIterator.add(obj);
                listIterator.previous();
                return;
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final boolean hasNext() {
        switch (this.f20887d) {
            case 0:
                break;
        }
        return this.f20888e.hasPrevious();
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        switch (this.f20887d) {
            case 0:
                break;
        }
        return this.f20888e.hasNext();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final Object next() {
        switch (this.f20887d) {
            case 0:
                break;
        }
        return this.f20888e.previous();
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        int iPreviousIndex;
        int iO;
        switch (this.f20887d) {
            case 0:
                z zVar = (z) this.f20889i;
                iPreviousIndex = this.f20888e.previousIndex();
                iO = s1.e.o(zVar);
                break;
            default:
                a0 a0Var = (a0) this.f20889i;
                iPreviousIndex = this.f20888e.previousIndex();
                iO = s1.e.o(a0Var);
                break;
        }
        return iO - iPreviousIndex;
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        switch (this.f20887d) {
            case 0:
                break;
        }
        return this.f20888e.next();
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        int iNextIndex;
        int iO;
        switch (this.f20887d) {
            case 0:
                z zVar = (z) this.f20889i;
                iNextIndex = this.f20888e.nextIndex();
                iO = s1.e.o(zVar);
                break;
            default:
                a0 a0Var = (a0) this.f20889i;
                iNextIndex = this.f20888e.nextIndex();
                iO = s1.e.o(a0Var);
                break;
        }
        return iO - iNextIndex;
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final void remove() {
        switch (this.f20887d) {
            case 0:
                this.f20888e.remove();
                return;
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        switch (this.f20887d) {
            case 0:
                this.f20888e.set(obj);
                return;
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public y(z zVar, int i11) {
        this.f20889i = zVar;
        this.f20888e = zVar.f20890d.listIterator(q.a0(i11, zVar));
    }
}
