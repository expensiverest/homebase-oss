package m30;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes3.dex */
public abstract class x extends sg.a {
    public static Object n0(Map map, Object obj) {
        kotlin.jvm.internal.k.g(map, "<this>");
        Object obj2 = map.get(obj);
        if (obj2 != null || map.containsKey(obj)) {
            return obj2;
        }
        throw new NoSuchElementException("Key " + obj + " is missing in the map.");
    }

    public static HashMap o0(l30.j... jVarArr) {
        HashMap map = new HashMap(p0(jVarArr.length));
        v0(map, jVarArr);
        return map;
    }

    public static int p0(int i11) {
        if (i11 < 0) {
            return i11;
        }
        if (i11 < 3) {
            return i11 + 1;
        }
        if (i11 < 1073741824) {
            return (int) ((i11 / 0.75f) + 1.0f);
        }
        return Integer.MAX_VALUE;
    }

    public static Map q0(l30.j pair) {
        kotlin.jvm.internal.k.g(pair, "pair");
        Map mapSingletonMap = Collections.singletonMap(pair.f19982d, pair.f19983e);
        kotlin.jvm.internal.k.f(mapSingletonMap, "singletonMap(...)");
        return mapSingletonMap;
    }

    public static Map r0(l30.j... jVarArr) {
        if (jVarArr.length <= 0) {
            return t.f20880d;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(p0(jVarArr.length));
        v0(linkedHashMap, jVarArr);
        return linkedHashMap;
    }

    public static LinkedHashMap s0(l30.j... jVarArr) {
        LinkedHashMap linkedHashMap = new LinkedHashMap(p0(jVarArr.length));
        v0(linkedHashMap, jVarArr);
        return linkedHashMap;
    }

    public static LinkedHashMap t0(Map map, Map map2) {
        kotlin.jvm.internal.k.g(map, "<this>");
        LinkedHashMap linkedHashMap = new LinkedHashMap(map);
        linkedHashMap.putAll(map2);
        return linkedHashMap;
    }

    public static Map u0(Map map, l30.j jVar) {
        kotlin.jvm.internal.k.g(map, "<this>");
        if (map.isEmpty()) {
            return q0(jVar);
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(map);
        linkedHashMap.put(jVar.f19982d, jVar.f19983e);
        return linkedHashMap;
    }

    public static final void v0(HashMap map, l30.j[] jVarArr) {
        for (l30.j jVar : jVarArr) {
            map.put(jVar.f19982d, jVar.f19983e);
        }
    }

    public static final void w0(LinkedHashMap linkedHashMap, List list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            l30.j jVar = (l30.j) it.next();
            linkedHashMap.put(jVar.f19982d, jVar.f19983e);
        }
    }

    public static Map x0(List list) {
        int size = list.size();
        if (size == 0) {
            return t.f20880d;
        }
        if (size == 1) {
            return q0((l30.j) list.get(0));
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(p0(list.size()));
        w0(linkedHashMap, list);
        return linkedHashMap;
    }

    public static Map y0(Map map) {
        kotlin.jvm.internal.k.g(map, "<this>");
        int size = map.size();
        if (size == 0) {
            return t.f20880d;
        }
        if (size != 1) {
            return z0(map);
        }
        kotlin.jvm.internal.k.g(map, "<this>");
        Map.Entry entry = (Map.Entry) map.entrySet().iterator().next();
        Map mapSingletonMap = Collections.singletonMap(entry.getKey(), entry.getValue());
        kotlin.jvm.internal.k.f(mapSingletonMap, "with(...)");
        return mapSingletonMap;
    }

    public static LinkedHashMap z0(Map map) {
        kotlin.jvm.internal.k.g(map, "<this>");
        return new LinkedHashMap(map);
    }
}
