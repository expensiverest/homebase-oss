package m30;

import java.lang.reflect.Array;
import java.util.AbstractList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes3.dex */
public final class i extends f {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final Object[] f20872v = new Object[0];

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f20873d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object[] f20874e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20875i;

    public i() {
        this.f20874e = f20872v;
    }

    @Override // m30.f
    public final int a() {
        return this.f20875i;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i11, Object obj) {
        int length;
        int i12 = this.f20875i;
        if (i11 < 0 || i11 > i12) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, i12, ", size: "));
        }
        if (i11 == i12) {
            addLast(obj);
            return;
        }
        if (i11 == 0) {
            addFirst(obj);
            return;
        }
        p();
        f(this.f20875i + 1);
        int iO = o(this.f20873d + i11);
        int i13 = this.f20875i;
        if (i11 < ((i13 + 1) >> 1)) {
            if (iO == 0) {
                Object[] objArr = this.f20874e;
                kotlin.jvm.internal.k.g(objArr, "<this>");
                iO = objArr.length;
            }
            int i14 = iO - 1;
            int i15 = this.f20873d;
            if (i15 == 0) {
                Object[] objArr2 = this.f20874e;
                kotlin.jvm.internal.k.g(objArr2, "<this>");
                length = objArr2.length - 1;
            } else {
                length = i15 - 1;
            }
            int i16 = this.f20873d;
            if (i14 >= i16) {
                Object[] objArr3 = this.f20874e;
                objArr3[length] = objArr3[i16];
                k.V(i16, i16 + 1, i14 + 1, objArr3, objArr3);
            } else {
                Object[] objArr4 = this.f20874e;
                k.V(i16 - 1, i16, objArr4.length, objArr4, objArr4);
                Object[] objArr5 = this.f20874e;
                objArr5[objArr5.length - 1] = objArr5[0];
                k.V(0, 1, i14 + 1, objArr5, objArr5);
            }
            this.f20874e[i14] = obj;
            this.f20873d = length;
        } else {
            int iO2 = o(i13 + this.f20873d);
            if (iO < iO2) {
                Object[] objArr6 = this.f20874e;
                k.V(iO + 1, iO, iO2, objArr6, objArr6);
            } else {
                Object[] objArr7 = this.f20874e;
                k.V(1, 0, iO2, objArr7, objArr7);
                Object[] objArr8 = this.f20874e;
                objArr8[0] = objArr8[objArr8.length - 1];
                k.V(iO + 1, iO, objArr8.length - 1, objArr8, objArr8);
            }
            this.f20874e[iO] = obj;
        }
        this.f20875i++;
    }

    @Override // java.util.AbstractList, java.util.List
    public final boolean addAll(int i11, Collection elements) {
        kotlin.jvm.internal.k.g(elements, "elements");
        int i12 = this.f20875i;
        if (i11 < 0 || i11 > i12) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, i12, ", size: "));
        }
        if (elements.isEmpty()) {
            return false;
        }
        if (i11 == this.f20875i) {
            return addAll(elements);
        }
        p();
        f(elements.size() + this.f20875i);
        int iO = o(this.f20875i + this.f20873d);
        int iO2 = o(this.f20873d + i11);
        int size = elements.size();
        if (i11 >= ((this.f20875i + 1) >> 1)) {
            int i13 = iO2 + size;
            if (iO2 < iO) {
                int i14 = size + iO;
                Object[] objArr = this.f20874e;
                if (i14 <= objArr.length) {
                    k.V(i13, iO2, iO, objArr, objArr);
                } else if (i13 >= objArr.length) {
                    k.V(i13 - objArr.length, iO2, iO, objArr, objArr);
                } else {
                    int length = iO - (i14 - objArr.length);
                    k.V(0, length, iO, objArr, objArr);
                    Object[] objArr2 = this.f20874e;
                    k.V(i13, iO2, length, objArr2, objArr2);
                }
            } else {
                Object[] objArr3 = this.f20874e;
                k.V(size, 0, iO, objArr3, objArr3);
                Object[] objArr4 = this.f20874e;
                if (i13 >= objArr4.length) {
                    k.V(i13 - objArr4.length, iO2, objArr4.length, objArr4, objArr4);
                } else {
                    k.V(0, objArr4.length - size, objArr4.length, objArr4, objArr4);
                    Object[] objArr5 = this.f20874e;
                    k.V(i13, iO2, objArr5.length - size, objArr5, objArr5);
                }
            }
            e(iO2, elements);
            return true;
        }
        int i15 = this.f20873d;
        int length2 = i15 - size;
        if (iO2 < i15) {
            Object[] objArr6 = this.f20874e;
            k.V(length2, i15, objArr6.length, objArr6, objArr6);
            if (size >= iO2) {
                Object[] objArr7 = this.f20874e;
                k.V(objArr7.length - size, 0, iO2, objArr7, objArr7);
            } else {
                Object[] objArr8 = this.f20874e;
                k.V(objArr8.length - size, 0, size, objArr8, objArr8);
                Object[] objArr9 = this.f20874e;
                k.V(0, size, iO2, objArr9, objArr9);
            }
        } else if (length2 >= 0) {
            Object[] objArr10 = this.f20874e;
            k.V(length2, i15, iO2, objArr10, objArr10);
        } else {
            Object[] objArr11 = this.f20874e;
            length2 += objArr11.length;
            int i16 = iO2 - i15;
            int length3 = objArr11.length - length2;
            if (length3 >= i16) {
                k.V(length2, i15, iO2, objArr11, objArr11);
            } else {
                k.V(length2, i15, i15 + length3, objArr11, objArr11);
                Object[] objArr12 = this.f20874e;
                k.V(0, this.f20873d + length3, iO2, objArr12, objArr12);
            }
        }
        this.f20873d = length2;
        e(k(iO2 - size), elements);
        return true;
    }

    public final void addFirst(Object obj) {
        p();
        f(this.f20875i + 1);
        int length = this.f20873d;
        if (length == 0) {
            Object[] objArr = this.f20874e;
            kotlin.jvm.internal.k.g(objArr, "<this>");
            length = objArr.length;
        }
        int i11 = length - 1;
        this.f20873d = i11;
        this.f20874e[i11] = obj;
        this.f20875i++;
    }

    public final void addLast(Object obj) {
        p();
        f(a() + 1);
        this.f20874e[o(a() + this.f20873d)] = obj;
        this.f20875i = a() + 1;
    }

    @Override // m30.f
    public final Object b(int i11) {
        int i12 = this.f20875i;
        if (i11 < 0 || i11 >= i12) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, i12, ", size: "));
        }
        if (i11 == s1.e.o(this)) {
            return removeLast();
        }
        if (i11 == 0) {
            return removeFirst();
        }
        p();
        int iO = o(this.f20873d + i11);
        Object[] objArr = this.f20874e;
        Object obj = objArr[iO];
        if (i11 < (this.f20875i >> 1)) {
            int i13 = this.f20873d;
            if (iO >= i13) {
                k.V(i13 + 1, i13, iO, objArr, objArr);
            } else {
                k.V(1, 0, iO, objArr, objArr);
                Object[] objArr2 = this.f20874e;
                objArr2[0] = objArr2[objArr2.length - 1];
                int i14 = this.f20873d;
                k.V(i14 + 1, i14, objArr2.length - 1, objArr2, objArr2);
            }
            Object[] objArr3 = this.f20874e;
            int i15 = this.f20873d;
            objArr3[i15] = null;
            this.f20873d = h(i15);
        } else {
            int iO2 = o(s1.e.o(this) + this.f20873d);
            if (iO <= iO2) {
                Object[] objArr4 = this.f20874e;
                k.V(iO, iO + 1, iO2 + 1, objArr4, objArr4);
            } else {
                Object[] objArr5 = this.f20874e;
                k.V(iO, iO + 1, objArr5.length, objArr5, objArr5);
                Object[] objArr6 = this.f20874e;
                objArr6[objArr6.length - 1] = objArr6[0];
                k.V(0, 1, iO2 + 1, objArr6, objArr6);
            }
            this.f20874e[iO2] = null;
        }
        this.f20875i--;
        return obj;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final void clear() {
        if (!isEmpty()) {
            p();
            m(this.f20873d, o(a() + this.f20873d));
        }
        this.f20873d = 0;
        this.f20875i = 0;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    public final void e(int i11, Collection collection) {
        Iterator it = collection.iterator();
        int length = this.f20874e.length;
        while (i11 < length && it.hasNext()) {
            this.f20874e[i11] = it.next();
            i11++;
        }
        int i12 = this.f20873d;
        for (int i13 = 0; i13 < i12 && it.hasNext(); i13++) {
            this.f20874e[i13] = it.next();
        }
        this.f20875i = collection.size() + this.f20875i;
    }

    public final void f(int i11) {
        if (i11 < 0) {
            throw new IllegalStateException("Deque is too big.");
        }
        Object[] objArr = this.f20874e;
        if (i11 <= objArr.length) {
            return;
        }
        if (objArr == f20872v) {
            if (i11 < 10) {
                i11 = 10;
            }
            this.f20874e = new Object[i11];
            return;
        }
        int length = objArr.length;
        int i12 = length + (length >> 1);
        if (i12 - i11 < 0) {
            i12 = i11;
        }
        if (i12 - 2147483639 > 0) {
            i12 = i11 > 2147483639 ? Integer.MAX_VALUE : 2147483639;
        }
        Object[] objArr2 = new Object[i12];
        k.V(0, this.f20873d, objArr.length, objArr, objArr2);
        Object[] objArr3 = this.f20874e;
        int length2 = objArr3.length;
        int i13 = this.f20873d;
        k.V(length2 - i13, 0, i13, objArr3, objArr2);
        this.f20873d = 0;
        this.f20874e = objArr2;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i11) {
        int iA = a();
        if (i11 < 0 || i11 >= iA) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, iA, ", size: "));
        }
        return this.f20874e[o(this.f20873d + i11)];
    }

    public final int h(int i11) {
        Object[] objArr = this.f20874e;
        kotlin.jvm.internal.k.g(objArr, "<this>");
        if (i11 == objArr.length - 1) {
            return 0;
        }
        return i11 + 1;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int indexOf(Object obj) {
        int i11;
        int iO = o(a() + this.f20873d);
        int length = this.f20873d;
        if (length < iO) {
            while (length < iO) {
                if (kotlin.jvm.internal.k.b(obj, this.f20874e[length])) {
                    i11 = this.f20873d;
                } else {
                    length++;
                }
            }
            return -1;
        }
        if (length < iO) {
            return -1;
        }
        int length2 = this.f20874e.length;
        while (true) {
            if (length >= length2) {
                for (int i12 = 0; i12 < iO; i12++) {
                    if (kotlin.jvm.internal.k.b(obj, this.f20874e[i12])) {
                        length = i12 + this.f20874e.length;
                        i11 = this.f20873d;
                        break;
                    }
                }
                return -1;
            }
            if (kotlin.jvm.internal.k.b(obj, this.f20874e[length])) {
                i11 = this.f20873d;
                break;
            }
            length++;
        }
        return length - i11;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean isEmpty() {
        return a() == 0;
    }

    public final int k(int i11) {
        return i11 < 0 ? i11 + this.f20874e.length : i11;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int lastIndexOf(Object obj) {
        int length;
        int i11;
        int iO = o(this.f20875i + this.f20873d);
        int i12 = this.f20873d;
        if (i12 < iO) {
            length = iO - 1;
            if (i12 <= length) {
                while (!kotlin.jvm.internal.k.b(obj, this.f20874e[length])) {
                    if (length != i12) {
                        length--;
                    }
                }
                i11 = this.f20873d;
                return length - i11;
            }
            return -1;
        }
        if (i12 > iO) {
            for (int i13 = iO - 1; -1 < i13; i13--) {
                if (kotlin.jvm.internal.k.b(obj, this.f20874e[i13])) {
                    length = i13 + this.f20874e.length;
                    i11 = this.f20873d;
                    return length - i11;
                }
            }
            Object[] objArr = this.f20874e;
            kotlin.jvm.internal.k.g(objArr, "<this>");
            length = objArr.length - 1;
            int i14 = this.f20873d;
            if (i14 <= length) {
                while (!kotlin.jvm.internal.k.b(obj, this.f20874e[length])) {
                    if (length != i14) {
                        length--;
                    }
                }
                i11 = this.f20873d;
                return length - i11;
            }
        }
        return -1;
    }

    public final void m(int i11, int i12) {
        if (i11 < i12) {
            k.b0(this.f20874e, null, i11, i12);
            return;
        }
        Object[] objArr = this.f20874e;
        k.b0(objArr, null, i11, objArr.length);
        k.b0(this.f20874e, null, 0, i12);
    }

    public final int o(int i11) {
        Object[] objArr = this.f20874e;
        return i11 >= objArr.length ? i11 - objArr.length : i11;
    }

    public final void p() {
        ((AbstractList) this).modCount++;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean remove(Object obj) {
        int iIndexOf = indexOf(obj);
        if (iIndexOf == -1) {
            return false;
        }
        b(iIndexOf);
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean removeAll(Collection elements) {
        int iO;
        kotlin.jvm.internal.k.g(elements, "elements");
        boolean z11 = false;
        z11 = false;
        z11 = false;
        if (!isEmpty() && this.f20874e.length != 0) {
            int iO2 = o(a() + this.f20873d);
            int i11 = this.f20873d;
            if (i11 < iO2) {
                iO = i11;
                while (i11 < iO2) {
                    Object obj = this.f20874e[i11];
                    if (elements.contains(obj)) {
                        z11 = true;
                    } else {
                        this.f20874e[iO] = obj;
                        iO++;
                    }
                    i11++;
                }
                k.b0(this.f20874e, null, iO, iO2);
            } else {
                int length = this.f20874e.length;
                boolean z12 = false;
                int i12 = i11;
                while (i11 < length) {
                    Object[] objArr = this.f20874e;
                    Object obj2 = objArr[i11];
                    objArr[i11] = null;
                    if (elements.contains(obj2)) {
                        z12 = true;
                    } else {
                        this.f20874e[i12] = obj2;
                        i12++;
                    }
                    i11++;
                }
                iO = o(i12);
                for (int i13 = 0; i13 < iO2; i13++) {
                    Object[] objArr2 = this.f20874e;
                    Object obj3 = objArr2[i13];
                    objArr2[i13] = null;
                    if (elements.contains(obj3)) {
                        z12 = true;
                    } else {
                        this.f20874e[iO] = obj3;
                        iO = h(iO);
                    }
                }
                z11 = z12;
            }
            if (z11) {
                p();
                this.f20875i = k(iO - this.f20873d);
            }
        }
        return z11;
    }

    public final Object removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException("ArrayDeque is empty.");
        }
        p();
        Object[] objArr = this.f20874e;
        int i11 = this.f20873d;
        Object obj = objArr[i11];
        objArr[i11] = null;
        this.f20873d = h(i11);
        this.f20875i = a() - 1;
        return obj;
    }

    public final Object removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException("ArrayDeque is empty.");
        }
        p();
        int iO = o(s1.e.o(this) + this.f20873d);
        Object[] objArr = this.f20874e;
        Object obj = objArr[iO];
        objArr[iO] = null;
        this.f20875i = a() - 1;
        return obj;
    }

    @Override // java.util.AbstractList
    public final void removeRange(int i11, int i12) {
        oq.a.x(i11, i12, this.f20875i);
        int i13 = i12 - i11;
        if (i13 == 0) {
            return;
        }
        if (i13 == this.f20875i) {
            clear();
            return;
        }
        if (i13 == 1) {
            b(i11);
            return;
        }
        p();
        if (i11 < this.f20875i - i12) {
            int iO = o(this.f20873d + (i11 - 1));
            int iO2 = o(this.f20873d + (i12 - 1));
            while (i11 > 0) {
                int i14 = iO + 1;
                int iMin = Math.min(i11, Math.min(i14, iO2 + 1));
                Object[] objArr = this.f20874e;
                int i15 = iO2 - iMin;
                int i16 = iO - iMin;
                k.V(i15 + 1, i16 + 1, i14, objArr, objArr);
                iO = k(i16);
                iO2 = k(i15);
                i11 -= iMin;
            }
            int iO3 = o(this.f20873d + i13);
            m(this.f20873d, iO3);
            this.f20873d = iO3;
        } else {
            int iO4 = o(this.f20873d + i12);
            int iO5 = o(this.f20873d + i11);
            int i17 = this.f20875i;
            while (true) {
                i17 -= i12;
                if (i17 <= 0) {
                    break;
                }
                Object[] objArr2 = this.f20874e;
                i12 = Math.min(i17, Math.min(objArr2.length - iO4, objArr2.length - iO5));
                Object[] objArr3 = this.f20874e;
                int i18 = iO4 + i12;
                k.V(iO5, iO4, i18, objArr3, objArr3);
                iO4 = o(i18);
                iO5 = o(iO5 + i12);
            }
            int iO6 = o(this.f20875i + this.f20873d);
            m(k(iO6 - i13), iO6);
        }
        this.f20875i -= i13;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean retainAll(Collection elements) {
        int iO;
        kotlin.jvm.internal.k.g(elements, "elements");
        boolean z11 = false;
        z11 = false;
        z11 = false;
        if (!isEmpty() && this.f20874e.length != 0) {
            int iO2 = o(a() + this.f20873d);
            int i11 = this.f20873d;
            if (i11 < iO2) {
                iO = i11;
                while (i11 < iO2) {
                    Object obj = this.f20874e[i11];
                    if (elements.contains(obj)) {
                        this.f20874e[iO] = obj;
                        iO++;
                    } else {
                        z11 = true;
                    }
                    i11++;
                }
                k.b0(this.f20874e, null, iO, iO2);
            } else {
                int length = this.f20874e.length;
                boolean z12 = false;
                int i12 = i11;
                while (i11 < length) {
                    Object[] objArr = this.f20874e;
                    Object obj2 = objArr[i11];
                    objArr[i11] = null;
                    if (elements.contains(obj2)) {
                        this.f20874e[i12] = obj2;
                        i12++;
                    } else {
                        z12 = true;
                    }
                    i11++;
                }
                iO = o(i12);
                for (int i13 = 0; i13 < iO2; i13++) {
                    Object[] objArr2 = this.f20874e;
                    Object obj3 = objArr2[i13];
                    objArr2[i13] = null;
                    if (elements.contains(obj3)) {
                        this.f20874e[iO] = obj3;
                        iO = h(iO);
                    } else {
                        z12 = true;
                    }
                }
                z11 = z12;
            }
            if (z11) {
                p();
                this.f20875i = k(iO - this.f20873d);
            }
        }
        return z11;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i11, Object obj) {
        int iA = a();
        if (i11 < 0 || i11 >= iA) {
            throw new IndexOutOfBoundsException(a1.h.g("index: ", i11, iA, ", size: "));
        }
        int iO = o(this.f20873d + i11);
        Object[] objArr = this.f20874e;
        Object obj2 = objArr[iO];
        objArr[iO] = obj;
        return obj2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final Object[] toArray() {
        return toArray(new Object[a()]);
    }

    public i(List list) {
        Object[] array = list.toArray(new Object[0]);
        this.f20874e = array;
        this.f20875i = array.length;
        if (array.length == 0) {
            this.f20874e = f20872v;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final Object[] toArray(Object[] array) {
        kotlin.jvm.internal.k.g(array, "array");
        int length = array.length;
        int i11 = this.f20875i;
        if (length < i11) {
            Object objNewInstance = Array.newInstance(array.getClass().getComponentType(), i11);
            kotlin.jvm.internal.k.e(objNewInstance, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.arrayOfNulls>");
            array = (Object[]) objNewInstance;
        }
        int iO = o(this.f20875i + this.f20873d);
        int i12 = this.f20873d;
        if (i12 < iO) {
            k.X(i12, iO, 2, this.f20874e, array);
        } else if (!isEmpty()) {
            Object[] objArr = this.f20874e;
            k.V(0, this.f20873d, objArr.length, objArr, array);
            Object[] objArr2 = this.f20874e;
            k.V(objArr2.length - this.f20873d, 0, iO, objArr2, array);
        }
        int i13 = this.f20875i;
        if (i13 < array.length) {
            array[i13] = null;
        }
        return array;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        addLast(obj);
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection elements) {
        kotlin.jvm.internal.k.g(elements, "elements");
        if (elements.isEmpty()) {
            return false;
        }
        p();
        f(elements.size() + a());
        e(o(a() + this.f20873d), elements);
        return true;
    }
}
