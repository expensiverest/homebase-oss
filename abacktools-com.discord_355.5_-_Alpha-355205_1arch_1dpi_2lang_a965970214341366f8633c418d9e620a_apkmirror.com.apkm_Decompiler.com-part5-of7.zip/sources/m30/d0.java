package m30;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes3.dex */
public abstract class d0 extends su.e {
    public static Set T(Iterable elements, Set set) {
        kotlin.jvm.internal.k.g(set, "<this>");
        kotlin.jvm.internal.k.g(elements, "elements");
        Collection<?> collectionS0 = elements instanceof Collection ? (Collection) elements : q.S0(elements);
        if (collectionS0.isEmpty()) {
            return q.W0(set);
        }
        if (!(collectionS0 instanceof Set)) {
            LinkedHashSet linkedHashSet = new LinkedHashSet(set);
            linkedHashSet.removeAll(collectionS0);
            return linkedHashSet;
        }
        LinkedHashSet linkedHashSet2 = new LinkedHashSet();
        for (Object obj : set) {
            if (!((Set) collectionS0).contains(obj)) {
                linkedHashSet2.add(obj);
            }
        }
        return linkedHashSet2;
    }

    public static LinkedHashSet U(Iterable elements, Set set) {
        int size;
        kotlin.jvm.internal.k.g(set, "<this>");
        kotlin.jvm.internal.k.g(elements, "elements");
        Integer numValueOf = elements instanceof Collection ? Integer.valueOf(((Collection) elements).size()) : null;
        if (numValueOf != null) {
            size = set.size() + numValueOf.intValue();
        } else {
            size = set.size() * 2;
        }
        LinkedHashSet linkedHashSet = new LinkedHashSet(x.p0(size));
        linkedHashSet.addAll(set);
        q.b0(elements, linkedHashSet);
        return linkedHashSet;
    }

    public static LinkedHashSet V(Set set, Object obj) {
        kotlin.jvm.internal.k.g(set, "<this>");
        LinkedHashSet linkedHashSet = new LinkedHashSet(x.p0(set.size() + 1));
        linkedHashSet.addAll(set);
        linkedHashSet.add(obj);
        return linkedHashSet;
    }
}
