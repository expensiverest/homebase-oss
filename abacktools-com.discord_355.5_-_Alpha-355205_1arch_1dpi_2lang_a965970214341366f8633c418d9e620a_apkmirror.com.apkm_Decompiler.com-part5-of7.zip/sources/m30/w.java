package m30;

import java.util.Iterator;

/* JADX INFO: loaded from: classes3.dex */
public final class w implements Iterator, b40.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20884d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Iterator f20885e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20886i;

    public w(Iterator iterator) {
        kotlin.jvm.internal.k.g(iterator, "iterator");
        this.f20885e = iterator;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        Iterator it;
        switch (this.f20884d) {
            case 0:
                return this.f20885e.hasNext();
        }
        while (true) {
            int i11 = this.f20886i;
            it = this.f20885e;
            if (i11 <= 0 || !it.hasNext()) {
                break;
            }
            it.next();
            this.f20886i--;
        }
        return it.hasNext();
    }

    @Override // java.util.Iterator
    public final Object next() {
        Iterator it;
        switch (this.f20884d) {
            case 0:
                int i11 = this.f20886i;
                this.f20886i = i11 + 1;
                if (i11 >= 0) {
                    return new v(i11, this.f20885e.next());
                }
                s1.e.P();
                throw null;
        }
        while (true) {
            int i12 = this.f20886i;
            it = this.f20885e;
            if (i12 <= 0 || !it.hasNext()) {
                break;
            }
            it.next();
            this.f20886i--;
        }
        return it.next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        switch (this.f20884d) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public w(v60.b bVar) {
        this.f20885e = bVar.f32546a.iterator();
        this.f20886i = bVar.f32547b;
    }
}
