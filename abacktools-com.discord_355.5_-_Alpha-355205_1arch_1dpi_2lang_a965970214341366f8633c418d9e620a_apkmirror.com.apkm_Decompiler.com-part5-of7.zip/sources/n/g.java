package n;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import com.google.android.gms.internal.fido.nb;
import java.lang.reflect.Constructor;
import o.n;
import o.r;

/* JADX INFO: loaded from: classes.dex */
public final class g {
    public CharSequence A;
    public CharSequence B;
    public final /* synthetic */ h E;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Menu f22162a;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f22169h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f22170i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f22171j;
    public CharSequence k;
    public CharSequence l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f22172m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public char f22173n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f22174o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public char f22175p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f22176q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f22177r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f22178s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f22179t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f22180u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f22181v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f22182w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String f22183x;
    public String y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public n f22184z;
    public ColorStateList C = null;
    public PorterDuff.Mode D = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f22163b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f22164c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f22165d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f22166e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f22167f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f22168g = true;

    public g(h hVar, Menu menu) {
        this.E = hVar;
        this.f22162a = menu;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.E.f22189c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e4) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e4);
            return null;
        }
    }

    public final void b(MenuItem menuItem) {
        h hVar = this.E;
        Context context = hVar.f22189c;
        boolean z11 = false;
        menuItem.setChecked(this.f22178s).setVisible(this.f22179t).setEnabled(this.f22180u).setCheckable(this.f22177r >= 1).setTitleCondensed(this.l).setIcon(this.f22172m);
        int i11 = this.f22181v;
        if (i11 >= 0) {
            menuItem.setShowAsAction(i11);
        }
        if (this.y != null) {
            if (context.isRestricted()) {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
            if (hVar.f22190d == null) {
                hVar.f22190d = h.a(context);
            }
            Object obj = hVar.f22190d;
            String str = this.y;
            f fVar = new f();
            fVar.f22160a = obj;
            Class<?> cls = obj.getClass();
            try {
                fVar.f22161b = cls.getMethod(str, f.f22159c);
                menuItem.setOnMenuItemClickListener(fVar);
            } catch (Exception e4) {
                StringBuilder sbP = nb.p("Couldn't resolve menu item onClick handler ", str, " in class ");
                sbP.append(cls.getName());
                InflateException inflateException = new InflateException(sbP.toString());
                inflateException.initCause(e4);
                throw inflateException;
            }
        }
        if (this.f22177r >= 2) {
            if (menuItem instanceof o.m) {
                o.m mVar = (o.m) menuItem;
                mVar.f23762x = (mVar.f23762x & (-5)) | 4;
            } else if (menuItem instanceof r) {
                r rVar = (r) menuItem;
                k1.a aVar = rVar.f23771c;
                try {
                    if (rVar.f23772d == null) {
                        rVar.f23772d = aVar.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                    }
                    rVar.f23772d.invoke(aVar, Boolean.TRUE);
                } catch (Exception e9) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e9);
                }
            }
        }
        String str2 = this.f22183x;
        if (str2 != null) {
            menuItem.setActionView((View) a(str2, h.f22185e, hVar.f22187a));
            z11 = true;
        }
        int i12 = this.f22182w;
        if (i12 > 0) {
            if (z11) {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            } else {
                menuItem.setActionView(i12);
            }
        }
        n nVar = this.f22184z;
        if (nVar != null) {
            if (menuItem instanceof k1.a) {
                ((k1.a) menuItem).b(nVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.A;
        boolean z12 = menuItem instanceof k1.a;
        if (z12) {
            ((k1.a) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            l3.g.k(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.B;
        if (z12) {
            ((k1.a) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            l3.g.p(menuItem, charSequence2);
        }
        char c11 = this.f22173n;
        int i13 = this.f22174o;
        if (z12) {
            ((k1.a) menuItem).setAlphabeticShortcut(c11, i13);
        } else if (Build.VERSION.SDK_INT >= 26) {
            l3.g.j(menuItem, c11, i13);
        }
        char c12 = this.f22175p;
        int i14 = this.f22176q;
        if (z12) {
            ((k1.a) menuItem).setNumericShortcut(c12, i14);
        } else if (Build.VERSION.SDK_INT >= 26) {
            l3.g.o(menuItem, c12, i14);
        }
        PorterDuff.Mode mode = this.D;
        if (mode != null) {
            if (z12) {
                ((k1.a) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                l3.g.n(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.C;
        if (colorStateList != null) {
            if (z12) {
                ((k1.a) menuItem).setIconTintList(colorStateList);
            } else if (Build.VERSION.SDK_INT >= 26) {
                l3.g.m(menuItem, colorStateList);
            }
        }
    }
}
