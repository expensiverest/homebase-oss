package n;

import androidx.core.view.i1;
import p.n3;

/* JADX INFO: loaded from: classes.dex */
public final class i extends mn.a {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f22191s = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f22192t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f22193u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ Object f22194v;

    public i(j jVar) {
        super(1);
        this.f22194v = jVar;
        this.f22192t = false;
        this.f22193u = 0;
    }

    @Override // mn.a, androidx.core.view.i1
    public void a() {
        switch (this.f22191s) {
            case 1:
                this.f22192t = true;
                break;
        }
    }

    @Override // mn.a, androidx.core.view.i1
    public final void b() {
        switch (this.f22191s) {
            case 0:
                if (!this.f22192t) {
                    this.f22192t = true;
                    i1 i1Var = ((j) this.f22194v).f22198d;
                    if (i1Var != null) {
                        i1Var.b();
                    }
                    break;
                }
                break;
            default:
                ((n3) this.f22194v).f25375a.setVisibility(0);
                break;
        }
    }

    @Override // androidx.core.view.i1
    public final void c() {
        switch (this.f22191s) {
            case 0:
                int i11 = this.f22193u + 1;
                this.f22193u = i11;
                j jVar = (j) this.f22194v;
                if (i11 == jVar.f22195a.size()) {
                    i1 i1Var = jVar.f22198d;
                    if (i1Var != null) {
                        i1Var.c();
                    }
                    this.f22193u = 0;
                    this.f22192t = false;
                    jVar.f22199e = false;
                }
                break;
            default:
                if (!this.f22192t) {
                    ((n3) this.f22194v).f25375a.setVisibility(this.f22193u);
                }
                break;
        }
    }

    public i(n3 n3Var, int i11) {
        super(1);
        this.f22194v = n3Var;
        this.f22193u = i11;
        this.f22192t = false;
    }
}
