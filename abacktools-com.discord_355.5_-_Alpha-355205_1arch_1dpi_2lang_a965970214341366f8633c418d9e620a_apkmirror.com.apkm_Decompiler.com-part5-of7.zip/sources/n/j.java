package n;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.h1;
import androidx.core.view.i1;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Interpolator f22197c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public i1 f22198d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f22199e;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f22196b = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i f22200f = new i(this);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f22195a = new ArrayList();

    public final void a() {
        if (this.f22199e) {
            Iterator it = this.f22195a.iterator();
            while (it.hasNext()) {
                ((h1) it.next()).b();
            }
            this.f22199e = false;
        }
    }

    public final void b() {
        View view;
        if (this.f22199e) {
            return;
        }
        for (h1 h1Var : this.f22195a) {
            long j6 = this.f22196b;
            if (j6 >= 0) {
                h1Var.c(j6);
            }
            Interpolator interpolator = this.f22197c;
            if (interpolator != null && (view = (View) h1Var.f1503a.get()) != null) {
                view.animate().setInterpolator(interpolator);
            }
            if (this.f22198d != null) {
                h1Var.d(this.f22200f);
            }
            View view2 = (View) h1Var.f1503a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.f22199e = true;
    }
}
