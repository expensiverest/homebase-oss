package n;

import android.view.MenuInflater;
import android.view.View;
import java.util.ArrayList;
import kotlin.jvm.internal.v;
import m30.q;
import n70.x0;
import q40.d1;

/* JADX INFO: loaded from: classes.dex */
public abstract class a implements m70.c, m70.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f22145d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f22146e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Object f22147i;

    public a(String str, boolean z11) {
        this.f22145d = 2;
        this.f22147i = str;
        this.f22146e = z11;
    }

    @Override // m70.c
    public abstract Object A(j70.b bVar);

    @Override // m70.c
    public byte C() {
        return M(k0());
    }

    @Override // m70.a
    public double D(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return O(f0(descriptor, i11));
    }

    @Override // m70.c
    public short E() {
        return V(k0());
    }

    @Override // m70.c
    public float F() {
        return Q(k0());
    }

    @Override // m70.c
    public double H() {
        return O(k0());
    }

    @Override // m70.a
    public long I(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return T(f0(descriptor, i11));
    }

    public Integer J(a visibility) {
        kotlin.jvm.internal.k.g(visibility, "visibility");
        n30.f fVar = d1.f26534a;
        if (this == visibility) {
            return 0;
        }
        n30.f fVar2 = d1.f26534a;
        Integer num = (Integer) fVar2.get(this);
        Integer num2 = (Integer) fVar2.get(visibility);
        if (num == null || num2 == null || num.equals(num2)) {
            return null;
        }
        return Integer.valueOf(num.intValue() - num2.intValue());
    }

    public String K(String str, String childName) {
        kotlin.jvm.internal.k.g(childName, "childName");
        if (str.length() == 0) {
            return childName;
        }
        return str + '.' + childName;
    }

    public abstract boolean L(Object obj);

    public abstract byte M(Object obj);

    public abstract char N(Object obj);

    public abstract double O(Object obj);

    public abstract int P(Object obj, l70.g gVar);

    public abstract float Q(Object obj);

    public m70.c R(Object obj, l70.g inlineDescriptor) {
        kotlin.jvm.internal.k.g(inlineDescriptor, "inlineDescriptor");
        ((ArrayList) this.f22147i).add(obj);
        return this;
    }

    public abstract int S(Object obj);

    public abstract long T(Object obj);

    public boolean U(Object obj) {
        return true;
    }

    public abstract short V(Object obj);

    public String W(Object obj) {
        Object objX = X(obj);
        kotlin.jvm.internal.k.e(objX, "null cannot be cast to non-null type kotlin.String");
        return (String) objX;
    }

    public Object X(Object obj) {
        throw new j70.i(v.f19658a.b(getClass()) + " can't retrieve untyped values");
    }

    public String Y(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return descriptor.o(i11);
    }

    public abstract void Z();

    public abstract View a0();

    public String b0() {
        return (String) this.f22147i;
    }

    @Override // m70.a
    public void c(l70.g descriptor) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
    }

    public abstract o.k c0();

    @Override // m70.c
    public boolean d() {
        return L(k0());
    }

    public abstract MenuInflater d0();

    @Override // m70.c
    public char e() {
        return N(k0());
    }

    public abstract CharSequence e0();

    @Override // m70.a
    public Object f(l70.g descriptor, int i11, j70.b deserializer, Object obj) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        kotlin.jvm.internal.k.g(deserializer, "deserializer");
        ((ArrayList) this.f22147i).add(f0(descriptor, i11));
        kotlin.jvm.internal.k.g(deserializer, "deserializer");
        Object objA = A(deserializer);
        if (!this.f22146e) {
            k0();
        }
        this.f22146e = false;
        return objA;
    }

    public String f0(l70.g gVar, int i11) {
        kotlin.jvm.internal.k.g(gVar, "<this>");
        String nestedName = Y(gVar, i11);
        kotlin.jvm.internal.k.g(nestedName, "nestedName");
        String str = (String) q.x0((ArrayList) this.f22147i);
        if (str == null) {
            str = "";
        }
        return K(str, nestedName);
    }

    @Override // m70.a
    public byte g(x0 descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return M(f0(descriptor, i11));
    }

    public abstract CharSequence g0();

    @Override // m70.a
    public m70.c h(x0 descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return R(f0(descriptor, i11), descriptor.q(i11));
    }

    public abstract void h0();

    @Override // m70.a
    public int i(l70.g descriptor) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return -1;
    }

    public abstract boolean i0();

    @Override // m70.c
    public int k() {
        return S(k0());
    }

    public Object k0() {
        ArrayList arrayList = (ArrayList) this.f22147i;
        Object objRemove = arrayList.remove(s1.e.o(arrayList));
        this.f22146e = true;
        return objRemove;
    }

    public String l0() {
        ArrayList arrayList = (ArrayList) this.f22147i;
        return arrayList.isEmpty() ? "$" : q.t0(arrayList, ".", "$.", null, null, 60);
    }

    public abstract void m0(View view);

    @Override // m70.a
    public short n(x0 descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return V(f0(descriptor, i11));
    }

    public abstract void n0(int i11);

    @Override // m70.c
    public int o(l70.g enumDescriptor) {
        kotlin.jvm.internal.k.g(enumDescriptor, "enumDescriptor");
        return P(k0(), enumDescriptor);
    }

    public abstract void o0(CharSequence charSequence);

    @Override // m70.a
    public int p(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return S(f0(descriptor, i11));
    }

    public abstract void p0(int i11);

    @Override // m70.a
    public char q(x0 descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return N(f0(descriptor, i11));
    }

    public abstract void q0(CharSequence charSequence);

    @Override // m70.c
    public String r() {
        return W(k0());
    }

    public abstract void r0(boolean z11);

    @Override // m70.a
    public Object s(l70.g descriptor, int i11, j70.b deserializer, Object obj) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        kotlin.jvm.internal.k.g(deserializer, "deserializer");
        ((ArrayList) this.f22147i).add(f0(descriptor, i11));
        Object objA = (deserializer.d().l() || w()) ? A(deserializer) : null;
        if (!this.f22146e) {
            k0();
        }
        this.f22146e = false;
        return objA;
    }

    @Override // m70.c
    public m70.c t(l70.g descriptor) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return R(k0(), descriptor);
    }

    public String toString() {
        switch (this.f22145d) {
            case 2:
                return b0();
            default:
                return super.toString();
        }
    }

    @Override // m70.c
    public long u() {
        return T(k0());
    }

    @Override // m70.a
    public boolean v(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return L(f0(descriptor, i11));
    }

    @Override // m70.c
    public boolean w() {
        Object objX0 = q.x0((ArrayList) this.f22147i);
        if (objX0 == null) {
            return false;
        }
        return U(objX0);
    }

    @Override // m70.a
    public String x(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return W(f0(descriptor, i11));
    }

    @Override // m70.a
    public float y(l70.g descriptor, int i11) {
        kotlin.jvm.internal.k.g(descriptor, "descriptor");
        return Q(f0(descriptor, i11));
    }

    @Override // m70.a
    public boolean z() {
        return false;
    }

    public a(int i11) {
        this.f22145d = i11;
        switch (i11) {
            case 1:
                this.f22147i = new ArrayList();
                break;
        }
    }

    public a j0() {
        return this;
    }
}
