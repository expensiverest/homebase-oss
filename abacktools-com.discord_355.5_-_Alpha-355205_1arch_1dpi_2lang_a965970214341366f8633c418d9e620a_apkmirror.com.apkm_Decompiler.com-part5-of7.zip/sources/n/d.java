package n;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public final class d extends a implements o.i {
    public boolean J;
    public o.k K;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Context f22154v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ActionBarContextView f22155w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public k7.c f22156x;
    public WeakReference y;

    @Override // o.i
    public final void G(o.k kVar) {
        h0();
        p.j jVar = this.f22155w.f1326v;
        if (jVar != null) {
            jVar.n();
        }
    }

    @Override // n.a
    public final void Z() {
        if (this.J) {
            return;
        }
        this.J = true;
        this.f22156x.k(this);
    }

    @Override // n.a
    public final View a0() {
        WeakReference weakReference = this.y;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // n.a
    public final o.k c0() {
        return this.K;
    }

    @Override // n.a
    public final MenuInflater d0() {
        return new h(this.f22155w.getContext());
    }

    @Override // n.a
    public final CharSequence e0() {
        return this.f22155w.getSubtitle();
    }

    @Override // n.a
    public final CharSequence g0() {
        return this.f22155w.getTitle();
    }

    @Override // n.a
    public final void h0() {
        this.f22156x.l(this, this.K);
    }

    @Override // n.a
    public final boolean i0() {
        return this.f22155w.U;
    }

    @Override // o.i
    public final boolean l(o.k kVar, MenuItem menuItem) {
        return ((ld.d) this.f22156x.f19321e).j(this, menuItem);
    }

    @Override // n.a
    public final void m0(View view) {
        this.f22155w.setCustomView(view);
        this.y = view != null ? new WeakReference(view) : null;
    }

    @Override // n.a
    public final void n0(int i11) {
        o0(this.f22154v.getString(i11));
    }

    @Override // n.a
    public final void o0(CharSequence charSequence) {
        this.f22155w.setSubtitle(charSequence);
    }

    @Override // n.a
    public final void p0(int i11) {
        q0(this.f22154v.getString(i11));
    }

    @Override // n.a
    public final void q0(CharSequence charSequence) {
        this.f22155w.setTitle(charSequence);
    }

    @Override // n.a
    public final void r0(boolean z11) {
        this.f22146e = z11;
        this.f22155w.setTitleOptional(z11);
    }
}
