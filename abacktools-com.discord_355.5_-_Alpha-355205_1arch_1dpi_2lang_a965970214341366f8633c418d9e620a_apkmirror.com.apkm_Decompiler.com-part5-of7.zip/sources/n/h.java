package n;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.SubMenu;
import androidx.core.view.j1;
import app.p001rive.semantics.SemanticState;
import java.io.IOException;
import o.n;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import p.k1;

/* JADX INFO: loaded from: classes.dex */
public final class h extends MenuInflater {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Class[] f22185e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Class[] f22186f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object[] f22187a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object[] f22188b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f22189c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f22190d;

    static {
        Class[] clsArr = {Context.class};
        f22185e = clsArr;
        f22186f = clsArr;
    }

    public h(Context context) {
        super(context);
        this.f22189c = context;
        Object[] objArr = {context};
        this.f22187a = objArr;
        this.f22188b = objArr;
    }

    public static Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    public final void b(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) throws XmlPullParserException, IOException {
        int i11;
        ColorStateList colorStateList;
        int resourceId;
        g gVar = new g(this, menu);
        int eventType = xmlPullParser.getEventType();
        do {
            i11 = 2;
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if (!name.equals("menu")) {
                    throw new RuntimeException("Expecting menu, got ".concat(name));
                }
                eventType = xmlPullParser.next();
                break;
            }
            eventType = xmlPullParser.next();
        } while (eventType != 1);
        boolean z11 = false;
        boolean z12 = false;
        String str = null;
        while (!z11) {
            if (eventType == 1) {
                throw new RuntimeException("Unexpected end of document");
            }
            Menu menu2 = gVar.f22162a;
            if (eventType == i11) {
                if (!z12) {
                    String name2 = xmlPullParser.getName();
                    boolean zEquals = name2.equals("group");
                    Context context = this.f22189c;
                    if (zEquals) {
                        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.a.f14945p);
                        gVar.f22163b = typedArrayObtainStyledAttributes.getResourceId(1, 0);
                        gVar.f22164c = typedArrayObtainStyledAttributes.getInt(3, 0);
                        gVar.f22165d = typedArrayObtainStyledAttributes.getInt(4, 0);
                        gVar.f22166e = typedArrayObtainStyledAttributes.getInt(5, 0);
                        gVar.f22167f = typedArrayObtainStyledAttributes.getBoolean(2, true);
                        gVar.f22168g = typedArrayObtainStyledAttributes.getBoolean(0, true);
                        typedArrayObtainStyledAttributes.recycle();
                    } else if (name2.equals("item")) {
                        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, i.a.f14946q);
                        gVar.f22170i = typedArrayObtainStyledAttributes2.getResourceId(2, 0);
                        gVar.f22171j = (typedArrayObtainStyledAttributes2.getInt(5, gVar.f22164c) & (-65536)) | (typedArrayObtainStyledAttributes2.getInt(6, gVar.f22165d) & 65535);
                        gVar.k = typedArrayObtainStyledAttributes2.getText(7);
                        gVar.l = typedArrayObtainStyledAttributes2.getText(8);
                        gVar.f22172m = typedArrayObtainStyledAttributes2.getResourceId(0, 0);
                        String string = typedArrayObtainStyledAttributes2.getString(9);
                        gVar.f22173n = string == null ? (char) 0 : string.charAt(0);
                        gVar.f22174o = typedArrayObtainStyledAttributes2.getInt(16, SemanticState.Obscured);
                        String string2 = typedArrayObtainStyledAttributes2.getString(10);
                        gVar.f22175p = string2 == null ? (char) 0 : string2.charAt(0);
                        gVar.f22176q = typedArrayObtainStyledAttributes2.getInt(20, SemanticState.Obscured);
                        if (typedArrayObtainStyledAttributes2.hasValue(11)) {
                            gVar.f22177r = typedArrayObtainStyledAttributes2.getBoolean(11, false) ? 1 : 0;
                        } else {
                            gVar.f22177r = gVar.f22166e;
                        }
                        gVar.f22178s = typedArrayObtainStyledAttributes2.getBoolean(3, false);
                        gVar.f22179t = typedArrayObtainStyledAttributes2.getBoolean(4, gVar.f22167f);
                        gVar.f22180u = typedArrayObtainStyledAttributes2.getBoolean(1, gVar.f22168g);
                        gVar.f22181v = typedArrayObtainStyledAttributes2.getInt(21, -1);
                        gVar.y = typedArrayObtainStyledAttributes2.getString(12);
                        gVar.f22182w = typedArrayObtainStyledAttributes2.getResourceId(13, 0);
                        gVar.f22183x = typedArrayObtainStyledAttributes2.getString(15);
                        String string3 = typedArrayObtainStyledAttributes2.getString(14);
                        boolean z13 = string3 != null;
                        if (z13 && gVar.f22182w == 0 && gVar.f22183x == null) {
                            gVar.f22184z = (n) gVar.a(string3, f22186f, this.f22188b);
                        } else {
                            if (z13) {
                                Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                            }
                            gVar.f22184z = null;
                        }
                        gVar.A = typedArrayObtainStyledAttributes2.getText(17);
                        gVar.B = typedArrayObtainStyledAttributes2.getText(22);
                        if (typedArrayObtainStyledAttributes2.hasValue(19)) {
                            gVar.D = k1.c(typedArrayObtainStyledAttributes2.getInt(19, -1), gVar.D);
                        } else {
                            gVar.D = null;
                        }
                        if (typedArrayObtainStyledAttributes2.hasValue(18)) {
                            if (!typedArrayObtainStyledAttributes2.hasValue(18) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(18, 0)) == 0 || (colorStateList = j1.i(context, resourceId)) == null) {
                                colorStateList = typedArrayObtainStyledAttributes2.getColorStateList(18);
                            }
                            gVar.C = colorStateList;
                        } else {
                            gVar.C = null;
                        }
                        typedArrayObtainStyledAttributes2.recycle();
                        gVar.f22169h = false;
                        xmlPullParser = xmlPullParser;
                    } else if (name2.equals("menu")) {
                        gVar.f22169h = true;
                        SubMenu subMenuAddSubMenu = menu2.addSubMenu(gVar.f22163b, gVar.f22170i, gVar.f22171j, gVar.k);
                        gVar.b(subMenuAddSubMenu.getItem());
                        xmlPullParser = xmlPullParser;
                        b(xmlPullParser, attributeSet, subMenuAddSubMenu);
                    } else {
                        xmlPullParser = xmlPullParser;
                        str = name2;
                        z12 = true;
                    }
                }
                z11 = z11;
            } else if (eventType != 3) {
                z11 = z11;
            } else {
                String name3 = xmlPullParser.getName();
                if (z12 && name3.equals(str)) {
                    xmlPullParser = xmlPullParser;
                    z12 = false;
                    str = null;
                } else {
                    if (name3.equals("group")) {
                        gVar.f22163b = 0;
                        gVar.f22164c = 0;
                        gVar.f22165d = 0;
                        gVar.f22166e = 0;
                        gVar.f22167f = true;
                        gVar.f22168g = true;
                    } else if (name3.equals("item")) {
                        if (!gVar.f22169h) {
                            n nVar = gVar.f22184z;
                            if (nVar == null || !nVar.f23765b.hasSubMenu()) {
                                gVar.f22169h = true;
                                gVar.b(menu2.add(gVar.f22163b, gVar.f22170i, gVar.f22171j, gVar.k));
                            } else {
                                gVar.f22169h = true;
                                gVar.b(menu2.addSubMenu(gVar.f22163b, gVar.f22170i, gVar.f22171j, gVar.k).getItem());
                            }
                        }
                    } else if (name3.equals("menu")) {
                        z11 = true;
                    }
                    z11 = z11;
                }
            }
            eventType = xmlPullParser.next();
            i11 = 2;
            z11 = z11;
            z12 = z12;
        }
    }

    @Override // android.view.MenuInflater
    public final void inflate(int i11, Menu menu) {
        if (!(menu instanceof o.k)) {
            super.inflate(i11, menu);
            return;
        }
        XmlResourceParser layout = null;
        boolean z11 = false;
        try {
            try {
                layout = this.f22189c.getResources().getLayout(i11);
                AttributeSet attributeSetAsAttributeSet = Xml.asAttributeSet(layout);
                if (menu instanceof o.k) {
                    o.k kVar = (o.k) menu;
                    if (!kVar.f23729p) {
                        kVar.w();
                        z11 = true;
                    }
                }
                b(layout, attributeSetAsAttributeSet, menu);
                if (z11) {
                    ((o.k) menu).v();
                }
                layout.close();
            } catch (IOException e4) {
                throw new InflateException("Error inflating menu XML", e4);
            } catch (XmlPullParserException e9) {
                throw new InflateException("Error inflating menu XML", e9);
            }
        } catch (Throwable th2) {
            if (z11) {
                ((o.k) menu).v();
            }
            if (layout != null) {
                layout.close();
            }
            throw th2;
        }
    }
}
