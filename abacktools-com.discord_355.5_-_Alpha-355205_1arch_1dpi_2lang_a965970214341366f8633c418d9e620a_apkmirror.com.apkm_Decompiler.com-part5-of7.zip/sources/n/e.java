package n;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import o.z;

/* JADX INFO: loaded from: classes.dex */
public final class e extends ActionMode {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f22157a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a f22158b;

    public e(Context context, a aVar) {
        this.f22157a = context;
        this.f22158b = aVar;
    }

    @Override // android.view.ActionMode
    public final void finish() {
        this.f22158b.Z();
    }

    @Override // android.view.ActionMode
    public final View getCustomView() {
        return this.f22158b.a0();
    }

    @Override // android.view.ActionMode
    public final Menu getMenu() {
        return new z(this.f22157a, this.f22158b.c0());
    }

    @Override // android.view.ActionMode
    public final MenuInflater getMenuInflater() {
        return this.f22158b.d0();
    }

    @Override // android.view.ActionMode
    public final CharSequence getSubtitle() {
        return this.f22158b.e0();
    }

    @Override // android.view.ActionMode
    public final Object getTag() {
        return this.f22158b.f22147i;
    }

    @Override // android.view.ActionMode
    public final CharSequence getTitle() {
        return this.f22158b.g0();
    }

    @Override // android.view.ActionMode
    public final boolean getTitleOptionalHint() {
        return this.f22158b.f22146e;
    }

    @Override // android.view.ActionMode
    public final void invalidate() {
        this.f22158b.h0();
    }

    @Override // android.view.ActionMode
    public final boolean isTitleOptional() {
        return this.f22158b.i0();
    }

    @Override // android.view.ActionMode
    public final void setCustomView(View view) {
        this.f22158b.m0(view);
    }

    @Override // android.view.ActionMode
    public final void setSubtitle(CharSequence charSequence) {
        this.f22158b.o0(charSequence);
    }

    @Override // android.view.ActionMode
    public final void setTag(Object obj) {
        this.f22158b.f22147i = obj;
    }

    @Override // android.view.ActionMode
    public final void setTitle(CharSequence charSequence) {
        this.f22158b.q0(charSequence);
    }

    @Override // android.view.ActionMode
    public final void setTitleOptionalHint(boolean z11) {
        this.f22158b.r0(z11);
    }

    @Override // android.view.ActionMode
    public final void setSubtitle(int i11) {
        this.f22158b.n0(i11);
    }

    @Override // android.view.ActionMode
    public final void setTitle(int i11) {
        this.f22158b.p0(i11);
    }
}
