package n;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.view.LayoutInflater;
import com.discord.R;

/* JADX INFO: loaded from: classes.dex */
public final class c extends ContextWrapper {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static Configuration f22148f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f22149a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Resources.Theme f22150b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public LayoutInflater f22151c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Configuration f22152d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Resources f22153e;

    public c(Context context, int i11) {
        super(context);
        this.f22149a = i11;
    }

    public final void a(Configuration configuration) {
        if (this.f22153e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        }
        if (this.f22152d != null) {
            throw new IllegalStateException("Override configuration has already been set");
        }
        this.f22152d = new Configuration(configuration);
    }

    @Override // android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public final void b() {
        if (this.f22150b == null) {
            this.f22150b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f22150b.setTo(theme);
            }
        }
        this.f22150b.applyStyle(this.f22149a, true);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final AssetManager getAssets() {
        return getResources().getAssets();
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0032  */
    @Override // android.content.ContextWrapper, android.content.Context
    public final Resources getResources() {
        if (this.f22153e == null) {
            Configuration configuration = this.f22152d;
            if (configuration == null) {
                this.f22153e = super.getResources();
            } else {
                if (Build.VERSION.SDK_INT >= 26) {
                    if (f22148f == null) {
                        Configuration configuration2 = new Configuration();
                        configuration2.fontScale = 0.0f;
                        f22148f = configuration2;
                    }
                    if (configuration.equals(f22148f)) {
                        this.f22153e = super.getResources();
                    }
                }
                this.f22153e = createConfigurationContext(this.f22152d).getResources();
            }
        }
        return this.f22153e;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f22151c == null) {
            this.f22151c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f22151c;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final Resources.Theme getTheme() {
        Resources.Theme theme = this.f22150b;
        if (theme != null) {
            return theme;
        }
        if (this.f22149a == 0) {
            this.f22149a = R.style.Theme_AppCompat_Light;
        }
        b();
        return this.f22150b;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i11) {
        if (this.f22149a != i11) {
            this.f22149a = i11;
            b();
        }
    }
}
