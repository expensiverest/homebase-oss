package ml;

/* JADX INFO: loaded from: classes.dex */
public interface b extends a {
    @Override // ml.a
    @fl.c
    /* bridge */ /* synthetic */ default long now() {
        return super.now();
    }

    @Override // ml.a
    @fl.c
    /* synthetic */ long nowNanos();
}
