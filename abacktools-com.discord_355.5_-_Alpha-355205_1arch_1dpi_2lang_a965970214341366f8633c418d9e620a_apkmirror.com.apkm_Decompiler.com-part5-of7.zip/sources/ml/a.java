package ml;

import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public interface a {
    @fl.c
    default long now() {
        return TimeUnit.NANOSECONDS.toMillis(nowNanos());
    }

    @fl.c
    long nowNanos();
}
