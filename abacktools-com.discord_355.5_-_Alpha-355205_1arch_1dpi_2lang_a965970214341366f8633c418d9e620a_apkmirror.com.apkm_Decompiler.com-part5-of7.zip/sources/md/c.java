package md;

import android.net.Uri;
import com.appsflyer.deeplink.DeepLink;
import com.appsflyer.deeplink.DeepLinkListener;
import com.appsflyer.deeplink.DeepLinkResult;
import kotlin.jvm.internal.k;
import m30.q;
import w60.o;

/* JADX INFO: loaded from: classes.dex */
public final class c implements DeepLinkListener {
    /* JADX WARN: Code duplicated, block: B:46:0x009d A[DONT_GENERATE] */
    /* JADX WARN: Code duplicated, block: B:48:0x009f A[Catch: all -> 0x007e, TRY_ENTER, TRY_LEAVE, TryCatch #0 {, blocks: (B:16:0x0035, B:18:0x003b, B:23:0x004b, B:25:0x0053, B:27:0x006f, B:29:0x0075, B:40:0x0087, B:44:0x0091, B:48:0x009f), top: B:53:0x0035 }] */
    @Override // com.appsflyer.deeplink.DeepLinkListener
    public final void onDeepLinking(DeepLinkResult deepLinkResult) {
        DeepLink deepLink;
        String queryParameter;
        String host;
        k.g(deepLinkResult, "deepLinkResult");
        if (deepLinkResult.getStatus() == DeepLinkResult.Status.FOUND && (deepLink = deepLinkResult.getDeepLink()) != null) {
            String deepLinkValue = deepLink.getDeepLinkValue();
            String stringValue = deepLink.getStringValue("link");
            String str = null;
            if (stringValue == null) {
                stringValue = null;
            }
            d dVar = d.f21318a;
            boolean zB = k.b(deepLink.isDeferred(), Boolean.TRUE);
            synchronized (dVar) {
                if (deepLinkValue != null) {
                    if (stringValue == null && d.f21322e.contains(stringValue)) {
                        return;
                    }
                    if (Uri.parse(deepLinkValue).getQueryParameter("fromAppsFlyer") != null) {
                        return;
                    }
                    dVar.a(d.c(deepLinkValue), stringValue, zB);
                    return;
                }
                if (stringValue != null) {
                    Uri uri = Uri.parse(stringValue);
                    if (uri != null) {
                        if (!k.b(uri.getHost(), "discordapp.onelink.me")) {
                            uri = null;
                        }
                        if (uri != null && (queryParameter = uri.getQueryParameter("deep_link_value")) != null) {
                            Uri uri2 = Uri.parse(queryParameter);
                            if (q.i0(m30.k.v0(new String[]{"http", "https", "discord"}), uri2.getScheme()) && (host = uri2.getHost()) != null && !o.y0(host)) {
                                str = queryParameter;
                            }
                        }
                    }
                }
                deepLinkValue = str;
                if (deepLinkValue == null) {
                    return;
                }
                if (stringValue == null) {
                }
                if (Uri.parse(deepLinkValue).getQueryParameter("fromAppsFlyer") != null) {
                    return;
                }
                dVar.a(d.c(deepLinkValue), stringValue, zB);
                return;
                throw th;
            }
        }
    }
}
