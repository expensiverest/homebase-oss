package md;

import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f21323a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f21324b;

    public e(String str, boolean z11) {
        this.f21323a = str;
        this.f21324b = z11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return k.b(this.f21323a, eVar.f21323a) && this.f21324b == eVar.f21324b;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f21324b) + (this.f21323a.hashCode() * 31);
    }

    public final String toString() {
        return "InitialAppsFlyerUrl(url=" + this.f21323a + ", isDeferred=" + this.f21324b + ")";
    }
}
