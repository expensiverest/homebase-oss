package md;

import hs.q;
import kotlin.jvm.internal.k;
import p.x2;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f21312a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f21313b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f21314c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21315d;

    public a(String str, String str2, int i11, boolean z11) {
        z11 = (i11 & 4) != 0 ? false : z11;
        boolean z12 = (i11 & 8) == 0;
        this.f21312a = str;
        this.f21313b = str2;
        this.f21314c = z11;
        this.f21315d = z12;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return k.b(this.f21312a, aVar.f21312a) && k.b(this.f21313b, aVar.f21313b) && this.f21314c == aVar.f21314c && this.f21315d == aVar.f21315d;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f21315d) + q.d(q.c(this.f21312a.hashCode() * 31, 31, this.f21313b), 31, this.f21314c);
    }

    public final String toString() {
        StringBuilder sbN = x2.n("DeepLinkDelivery(url=", this.f21312a, ", source=", this.f21313b, ", isDeferred=");
        sbN.append(this.f21314c);
        sbN.append(", isColdStart=");
        sbN.append(this.f21315d);
        sbN.append(")");
        return sbN.toString();
    }
}
