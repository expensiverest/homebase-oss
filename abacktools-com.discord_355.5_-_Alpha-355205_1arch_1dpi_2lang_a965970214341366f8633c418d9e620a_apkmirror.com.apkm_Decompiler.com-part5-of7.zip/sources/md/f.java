package md;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import kotlin.jvm.internal.k;

/* JADX INFO: loaded from: classes.dex */
public final class f implements ui.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f21325a;

    public f(a aVar) {
        this.f21325a = aVar;
    }

    @Override // ui.a
    public final WritableMap a() {
        WritableMap writableMapCreateMap = Arguments.createMap();
        a aVar = this.f21325a;
        writableMapCreateMap.putString("url", aVar.f21312a);
        writableMapCreateMap.putString("source", aVar.f21313b);
        writableMapCreateMap.putBoolean("isDeferred", aVar.f21314c);
        writableMapCreateMap.putBoolean("isColdStart", aVar.f21315d);
        return writableMapCreateMap;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof f) && k.b(this.f21325a, ((f) obj).f21325a);
    }

    public final int hashCode() {
        return this.f21325a.hashCode();
    }

    public final String toString() {
        return "NativeDeepLinkEvent(delivery=" + this.f21325a + ")";
    }
}
