package md;

import android.animation.Animator;
import bc.g0;
import com.discord.R;
import com.discord.age_assurance.DigitalCredentialModule;
import com.discord.chat.presentation.list.ChatListViewManager;
import com.discord.crash_reporting.CrashReporting;
import com.discord.deep_link.DeepLinkManagerModule;
import com.discord.external_pip.ExternalPipModule;
import com.discord.media_player.MediaPlayerManagerModule;
import com.discord.mobile_voice_overlay.MobileVoiceOverlayModule;
import com.discord.primitives.ChannelId;
import com.discord.zoom_layout.ZoomLayoutViewManager;
import com.facebook.imageutils.JfifUtil;
import com.facebook.react.animated.NativeAnimatedModule;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReadableArrayBuilder;
import com.github.yamill.orientation.OrientationModule;
import eg.e0;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.util.HashSet;
import java.util.List;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import l30.a0;
import m30.q;
import n70.i1;
import n70.v0;
import org.webrtc.Logging;
import p70.t;
import rd.h0;
import rf.p;
import rf.t0;
import t10.z0;
import tc.h;
import w60.j;
import w60.m;
import y9.c1;
import zb.i;
import zc.g;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements Function1 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21316d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f21317e;

    public /* synthetic */ b(int i11, Object obj) {
        this.f21316d = i11;
        this.f21317e = obj;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String str = null;
        boolean z11 = false;
        switch (this.f21316d) {
            case 0:
                return Boolean.valueOf(DeepLinkManagerModule.eventSink$lambda$0((DeepLinkManagerModule) this.f21317e, (a) obj));
            case 1:
                j70.a aVar = (j70.a) this.f21317e;
                l70.a buildSerialDescriptor = (l70.a) obj;
                k.g(buildSerialDescriptor, "$this$buildSerialDescriptor");
                List list = (List) aVar.f17972c;
                k.g(list, "<set-?>");
                buildSerialDescriptor.f20229b = list;
                return a0.f19963a;
            case 2:
                v0 v0Var = (v0) this.f21317e;
                int iIntValue = ((Integer) obj).intValue();
                return v0Var.f22786e[iIntValue] + ": " + v0Var.q(iIntValue).k();
            case 3:
                i1 i1Var = (i1) this.f21317e;
                l70.a buildClassSerialDescriptor = (l70.a) obj;
                k.g(buildClassSerialDescriptor, "$this$buildClassSerialDescriptor");
                l70.a.a(buildClassSerialDescriptor, "first", i1Var.f22711a.d());
                l70.a.a(buildClassSerialDescriptor, "second", i1Var.f22712b.d());
                l70.a.a(buildClassSerialDescriptor, "third", i1Var.f22713c.d());
                return a0.f19963a;
            case 4:
                o20.f fVar = (o20.f) this.f21317e;
                int iIntValue2 = ((Integer) obj).intValue();
                n.c cVar = fVar.L;
                if (iIntValue2 == 16) {
                    cVar.setTheme(R.style.Theme_Material3_Light_NoActionBar);
                } else if (iIntValue2 != 32) {
                    cVar.setTheme(R.style.Theme_Material3_DayNight_NoActionBar);
                } else {
                    cVar.setTheme(R.style.Theme_Material3_Dark_NoActionBar);
                }
                fVar.S.J(cVar, fVar);
                return a0.f19963a;
            case 5:
                t tVar = (t) this.f21317e;
                kotlinx.serialization.json.b node = (kotlinx.serialization.json.b) obj;
                k.g(node, "node");
                tVar.f0((String) q.v0(tVar.f22642d), node);
                return a0.f19963a;
            case 6:
                return qh.d.b((ReactApplicationContext) this.f21317e);
            case 7:
                Object obj2 = this.f21317e;
                Promise it = (Promise) obj;
                k.g(it, "it");
                it.resolve(obj2);
                return a0.f19963a;
            case 8:
                Throwable th2 = (Throwable) this.f21317e;
                Promise it2 = (Promise) obj;
                k.g(it2, "it");
                it2.reject(th2);
                return a0.f19963a;
            case 9:
                return Integer.valueOf(h0.v0((h0) this.f21317e, ((Integer) obj).intValue()));
            case 10:
                p pVar = (p) this.f21317e;
                Boolean bool = (Boolean) obj;
                bool.getClass();
                try {
                    t0 t0Var = pVar.f28210f;
                    if (t0Var != null) {
                        t0Var.invoke(bool);
                    }
                    break;
                } catch (Throwable th3) {
                    CrashReporting crashReporting = CrashReporting.INSTANCE;
                    RuntimeException runtimeException = new RuntimeException("media engine native callback [onBroadcastVisibilityChanged] threw", th3);
                    crashReporting.getClass();
                    CrashReporting.c(runtimeException, false);
                }
                return a0.f19963a;
            case 11:
                z0.l((z0) this.f21317e, (t10.a) obj);
                return a0.f19963a;
            case 12:
                h hVar = (h) this.f21317e;
                boolean zBooleanValue = ((Boolean) obj).booleanValue();
                ChannelId channelId = hVar.f30214i;
                MediaPlayerManagerModule mediaPlayerManagerModule = hVar.f30213e;
                e0 e0Var = hVar.f30215v;
                if (channelId != null) {
                    long j6 = channelId.f5634d;
                    if (e0Var != null && hVar.f30217x != zBooleanValue) {
                        hVar.f30217x = zBooleanValue;
                        if (zBooleanValue) {
                            if (mediaPlayerManagerModule != null) {
                                mediaPlayerManagerModule.m357onMediaPlayerViewWillAppearLJLSWy8(j6, e0Var);
                            }
                        } else if (mediaPlayerManagerModule != null) {
                            mediaPlayerManagerModule.m356onMediaPlayerViewDetachedLJLSWy8(j6, e0Var);
                        }
                    }
                }
                return a0.f19963a;
            case 13:
                g0 g0Var = (g0) this.f21317e;
                k.g((c1) obj, "it");
                return new g(g0Var.f3346q ? je.a.PrimarySemibold : je.a.PrimaryNormal, g0Var.f3342m, null, null, 12);
            case 14:
                i iVar = (i) this.f21317e;
                vi.a reaction = (vi.a) obj;
                k.g(reaction, "reaction");
                iVar.invoke(reaction);
                return a0.f19963a;
            case 15:
                i iVar2 = (i) this.f21317e;
                vi.a reaction2 = (vi.a) obj;
                k.g(reaction2, "reaction");
                iVar2.invoke(reaction2);
                return a0.f19963a;
            case 16:
                de.c cVar2 = (de.c) this.f21317e;
                w60.k match = (w60.k) obj;
                k.g(match, "match");
                m mVar = ti.c.f30397a;
                String str2 = (String) ((m30.a0) match.a()).get(3);
                if (((String) ((m30.a0) match.a()).get(2)).length() > 0 && ((String) ((m30.a0) match.a()).get(4)).length() > 0) {
                    z11 = true;
                }
                if (((String) ((m30.a0) match.a()).get(1)).length() > 0 && ((String) ((m30.a0) match.a()).get(5)).length() > 0) {
                    str = (String) ((m30.a0) match.a()).get(7);
                }
                return (CharSequence) cVar2.invoke(str2, str, Boolean.valueOf(z11));
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                return NativeAnimatedModule.userDrivenScrollEnded$lambda$2$lambda$1((HashSet) this.f21317e, (ReadableArrayBuilder) obj);
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                return Float.valueOf(((u10.h) this.f21317e).b().getHeight());
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                return ChatListViewManager.addView$lambda$2((rk.a) this.f21317e, ((Double) obj).doubleValue());
            case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                z60.q qVar = (z60.q) this.f21317e;
                Boolean bool2 = (Boolean) obj;
                bool2.getClass();
                qVar.P(bool2);
                return a0.f19963a;
            case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                uf.c cVar3 = (uf.c) this.f21317e;
                Exception ex2 = (Exception) obj;
                k.g(ex2, "ex");
                Logging.e("EglRenderer", "Exception on EglRenderer thread", ex2);
                synchronized (cVar3.f31566e) {
                    cVar3.f31567i = null;
                }
                return a0.f19963a;
            case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                return OrientationModule._init_$lambda$0((OrientationModule) this.f21317e, ((Boolean) obj).booleanValue());
            case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                return ((j) this.f21317e).b(((Integer) obj).intValue());
            case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                wc.b bVar = (wc.b) this.f21317e;
                k.g((Animator) obj, "it");
                bVar.y = bVar.a(JfifUtil.MARKER_FIRST_BYTE, 0, 0L, new uc.b(8));
                return a0.f19963a;
            case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                return ExternalPipModule.onUserLeaveHint$lambda$0((ExternalPipModule) this.f21317e, (l30.m) obj);
            case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                qc.a aVar2 = (qc.a) this.f21317e;
                k.g((a0) obj, "it");
                aVar2.f26942t = false;
                return a0.f19963a;
            case 27:
                return ZoomLayoutViewManager.createViewInstance$lambda$0((ZoomLayoutViewManager) this.f21317e, (xk.b) obj);
            case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                ah.a aVar3 = (ah.a) this.f21317e;
                k.g((bh.e) obj, "it");
                aVar3.b();
                return a0.f19963a;
            default:
                return MobileVoiceOverlayModule.mobileVoiceOverlay_delegate$lambda$0$1((MobileVoiceOverlayModule) this.f21317e, (String) obj);
        }
    }
}
