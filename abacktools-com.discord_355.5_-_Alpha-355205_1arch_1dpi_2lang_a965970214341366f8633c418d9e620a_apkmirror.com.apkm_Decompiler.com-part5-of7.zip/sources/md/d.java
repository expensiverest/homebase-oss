package md;

import android.net.Uri;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import m30.q;
import w60.o;
import w60.v;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Function1 f21320c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f21318a = new d();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final f80.e f21319b = new f80.e();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ArrayList f21321d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final LinkedHashSet f21322e = new LinkedHashSet();

    public static void b() {
        Function1 function1;
        while (true) {
            ArrayList arrayList = f21321d;
            if (arrayList.isEmpty() || (function1 = f21320c) == null || !((Boolean) function1.invoke(q.n0(arrayList))).booleanValue()) {
                return;
            } else {
                arrayList.remove(0);
            }
        }
    }

    public static String c(String str) {
        Uri.Builder builderBuildUpon = Uri.parse(str).buildUpon();
        Uri uriBuild = builderBuildUpon.build();
        builderBuildUpon.clearQuery();
        for (String str2 : uriBuild.getQueryParameterNames()) {
            if (!k.b(str2, "fromAppsFlyer")) {
                Iterator<String> it = uriBuild.getQueryParameters(str2).iterator();
                while (it.hasNext()) {
                    builderBuildUpon.appendQueryParameter(str2, it.next());
                }
            }
        }
        builderBuildUpon.appendQueryParameter("fromAppsFlyer", "true");
        String string = builderBuildUpon.toString();
        k.f(string, "toString(...)");
        return string;
    }

    public static void d(String str) {
        String host;
        int iV0 = o.v0(str, '#', 0, 6);
        if (!v.i0(str, "discord://app/open", false) || iV0 < 0) {
            return;
        }
        String strSubstring = str.substring(iV0 + 1);
        k.f(strSubstring, "substring(...)");
        Uri uri = Uri.parse(strSubstring);
        if (!q.i0(m30.k.v0(new String[]{"http", "https", "discord"}), uri.getScheme()) || (host = uri.getHost()) == null || o.y0(host)) {
            return;
        }
        LinkedHashSet linkedHashSet = f21322e;
        linkedHashSet.remove(str);
        linkedHashSet.add(str);
        if (linkedHashSet.size() > 16) {
            Iterator it = linkedHashSet.iterator();
            k.f(it, "iterator(...)");
            it.next();
            it.remove();
        }
    }

    public static void e(String str) {
        f80.e eVar = f21319b;
        String str2 = (String) eVar.f11492x;
        if (str2 != null) {
            eVar.y = str2;
            eVar.f11492x = null;
        }
        String str3 = (String) eVar.y;
        if (str3 != null && k.b(Uri.parse(str).getHost(), "discordapp.onelink.me")) {
            String queryParameter = Uri.parse(str3).getQueryParameter("deep_link_value");
            if (queryParameter == null) {
                eVar.y = null;
                return;
            }
            String queryParameter2 = Uri.parse(str).getQueryParameter("deep_link_value");
            if (queryParameter2 == null || !queryParameter2.equals(queryParameter)) {
                return;
            }
            eVar.y = null;
        }
    }

    public final synchronized void a(String str, String str2, boolean z11) {
        Uri uri;
        if (z11) {
            if (f21319b.f11489i) {
                return;
            }
        }
        String host = null;
        if (!z11) {
            f80.e eVar = f21319b;
            String str3 = (String) eVar.y;
            if (str3 != null) {
                String queryParameter = Uri.parse(str3).getQueryParameter("deep_link_value");
                if (queryParameter != null) {
                    boolean zB = k.b(str2, str3);
                    boolean zEquals = c(queryParameter).equals(str);
                    if (zB || zEquals) {
                        eVar.y = null;
                    }
                } else if (k.b(str2, str3)) {
                    eVar.y = null;
                }
                return;
            }
        }
        f80.e eVar2 = f21319b;
        if (((String) eVar2.f11492x) != null) {
            eVar2.f11492x = null;
            f21321d.add(new a(str, "appsflyer", 4, false));
            b();
            return;
        }
        String str4 = (String) eVar2.f11491w;
        if (str4 != null && (uri = Uri.parse(str4)) != null) {
            host = uri.getHost();
        }
        boolean zB2 = k.b(host, "discordapp.onelink.me");
        if (!eVar2.f11488e && ((e) eVar2.f11490v) == null && (((String) eVar2.f11491w) == null || zB2)) {
            eVar2.f11490v = new e(str, z11);
            return;
        }
        f21321d.add(new a(str, "appsflyer", 8, z11));
        b();
    }
}
