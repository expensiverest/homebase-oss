package m7;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final g f21261c = new g();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Thread f21262a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile g f21263b;

    public g() {
        h.f21266x.Z(this, Thread.currentThread());
    }
}
