package m7;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a f21246c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a f21247d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f21248a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Throwable f21249b;

    static {
        if (h.f21264v) {
            f21247d = null;
            f21246c = null;
        } else {
            f21247d = new a(null, false);
            f21246c = new a(null, true);
        }
    }

    public a(Throwable th2, boolean z11) {
        this.f21248a = z11;
        this.f21249b = th2;
    }
}
