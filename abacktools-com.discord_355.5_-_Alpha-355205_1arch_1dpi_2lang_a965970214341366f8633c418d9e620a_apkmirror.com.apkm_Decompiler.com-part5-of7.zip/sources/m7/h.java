package m7;

import com.discord.age_assurance.DigitalCredentialModule;
import com.google.android.gms.internal.fido.nb;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;
import mx.y;
import p.x2;

/* JADX INFO: loaded from: classes.dex */
public abstract class h implements y {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final boolean f21264v = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final Logger f21265w = Logger.getLogger(h.class.getName());

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final com.facebook.imagepipeline.nativecode.b f21266x;
    public static final Object y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile Object f21267d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile c f21268e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public volatile g f21269i;

    static {
        com.facebook.imagepipeline.nativecode.b fVar;
        try {
            fVar = new d(AtomicReferenceFieldUpdater.newUpdater(g.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(g.class, g.class, "b"), AtomicReferenceFieldUpdater.newUpdater(h.class, g.class, "i"), AtomicReferenceFieldUpdater.newUpdater(h.class, c.class, "e"), AtomicReferenceFieldUpdater.newUpdater(h.class, Object.class, "d"));
            th = null;
        } catch (Throwable th2) {
            th = th2;
            fVar = new f();
        }
        f21266x = fVar;
        if (th != null) {
            f21265w.log(Level.SEVERE, "SafeAtomicHelper is broken!", th);
        }
        y = new Object();
    }

    public static void e(h hVar) {
        c cVar;
        c cVar2;
        c cVar3 = null;
        while (true) {
            g gVar = hVar.f21269i;
            if (f21266x.k(hVar, gVar, g.f21261c)) {
                while (gVar != null) {
                    Thread thread = gVar.f21262a;
                    if (thread != null) {
                        gVar.f21262a = null;
                        LockSupport.unpark(thread);
                    }
                    gVar = gVar.f21263b;
                }
                do {
                    cVar = hVar.f21268e;
                } while (!f21266x.g(hVar, cVar, c.f21252d));
                while (true) {
                    cVar2 = cVar3;
                    cVar3 = cVar;
                    if (cVar3 == null) {
                        break;
                    }
                    cVar = cVar3.f21255c;
                    cVar3.f21255c = cVar2;
                }
                while (cVar2 != null) {
                    cVar3 = cVar2.f21255c;
                    Runnable runnable = cVar2.f21253a;
                    if (runnable instanceof e) {
                        e eVar = (e) runnable;
                        hVar = eVar.f21259d;
                        if (hVar.f21267d == eVar) {
                            if (f21266x.i(hVar, eVar, h(eVar.f21260e))) {
                            }
                        } else {
                            continue;
                        }
                    } else {
                        f(runnable, cVar2.f21254b);
                    }
                    cVar2 = cVar3;
                }
                return;
            }
        }
    }

    public static void f(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (RuntimeException e4) {
            f21265w.log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, (Throwable) e4);
        }
    }

    public static Object g(Object obj) throws ExecutionException {
        if (obj instanceof a) {
            Throwable th2 = ((a) obj).f21249b;
            CancellationException cancellationException = new CancellationException("Task was cancelled.");
            cancellationException.initCause(th2);
            throw cancellationException;
        }
        if (obj instanceof b) {
            throw new ExecutionException(((b) obj).f21251a);
        }
        if (obj == y) {
            return null;
        }
        return obj;
    }

    public static Object h(y yVar) {
        Object obj;
        if (yVar instanceof h) {
            Object obj2 = ((h) yVar).f21267d;
            if (!(obj2 instanceof a)) {
                return obj2;
            }
            a aVar = (a) obj2;
            if (aVar.f21248a) {
                return aVar.f21249b != null ? new a(aVar.f21249b, false) : a.f21247d;
            }
            return obj2;
        }
        boolean zIsCancelled = yVar.isCancelled();
        boolean z11 = true;
        if ((!f21264v) && zIsCancelled) {
            return a.f21247d;
        }
        boolean z12 = false;
        while (true) {
            try {
                try {
                    obj = yVar.get();
                    break;
                } catch (InterruptedException unused) {
                    z12 = z11;
                } catch (Throwable th2) {
                    if (z12) {
                        Thread.currentThread().interrupt();
                    }
                    throw th2;
                }
            } catch (CancellationException e4) {
                if (zIsCancelled) {
                    return new a(e4, false);
                }
                return new b(new IllegalArgumentException("get() threw CancellationException, despite reporting isCancelled() == false: " + yVar, e4));
            } catch (ExecutionException e9) {
                return new b(e9.getCause());
            } catch (Throwable th3) {
                return new b(th3);
            }
        }
        if (z12) {
            Thread.currentThread().interrupt();
        }
        return obj == null ? y : obj;
    }

    @Override // mx.y
    public final void a(Runnable runnable, Executor executor) {
        executor.getClass();
        c cVar = this.f21268e;
        c cVar2 = c.f21252d;
        if (cVar != cVar2) {
            c cVar3 = new c(runnable, executor);
            do {
                cVar3.f21255c = cVar;
                if (f21266x.g(this, cVar, cVar3)) {
                    return;
                } else {
                    cVar = this.f21268e;
                }
            } while (cVar != cVar2);
        }
        f(runnable, executor);
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z11) {
        a aVar;
        Object obj = this.f21267d;
        if (!(obj == null) && !(obj instanceof e)) {
            return false;
        }
        if (f21264v) {
            aVar = new a(new CancellationException("Future.cancel() was called."), z11);
        } else {
            aVar = z11 ? a.f21246c : a.f21247d;
        }
        h hVar = this;
        boolean z12 = false;
        while (true) {
            if (f21266x.i(hVar, obj, aVar)) {
                e(hVar);
                if (!(obj instanceof e)) {
                    break;
                }
                y yVar = ((e) obj).f21260e;
                if (!(yVar instanceof h)) {
                    yVar.cancel(z11);
                    break;
                }
                hVar = (h) yVar;
                obj = hVar.f21267d;
                if (!(obj == null) && !(obj instanceof e)) {
                    break;
                }
                z12 = true;
            } else {
                obj = hVar.f21267d;
                if (!(obj instanceof e)) {
                    return z12;
                }
            }
        }
        return true;
    }

    public final void d(StringBuilder sb2) {
        Object obj;
        boolean z11 = false;
        while (true) {
            try {
                try {
                    obj = get();
                    break;
                } catch (InterruptedException unused) {
                    z11 = true;
                } catch (Throwable th2) {
                    if (z11) {
                        Thread.currentThread().interrupt();
                    }
                    throw th2;
                }
            } catch (CancellationException unused2) {
                sb2.append(DigitalCredentialModule.CODE_CANCELLED);
                return;
            } catch (RuntimeException e4) {
                sb2.append("UNKNOWN, cause=[");
                sb2.append(e4.getClass());
                sb2.append(" thrown from get()]");
                return;
            } catch (ExecutionException e9) {
                sb2.append("FAILURE, cause=[");
                sb2.append(e9.getCause());
                sb2.append("]");
                return;
            }
        }
        if (z11) {
            Thread.currentThread().interrupt();
        }
        sb2.append("SUCCESS, result=[");
        sb2.append(obj == this ? "this future" : String.valueOf(obj));
        sb2.append("]");
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j6, TimeUnit timeUnit) throws InterruptedException, TimeoutException {
        boolean z11;
        g gVar = g.f21261c;
        long nanos = timeUnit.toNanos(j6);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f21267d;
        if ((obj != null) && (!(obj instanceof e))) {
            return g(obj);
        }
        long jNanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            g gVar2 = this.f21269i;
            if (gVar2 != gVar) {
                g gVar3 = new g();
                z11 = true;
                while (true) {
                    com.facebook.imagepipeline.nativecode.b bVar = f21266x;
                    bVar.X(gVar3, gVar2);
                    if (bVar.k(this, gVar2, gVar3)) {
                        do {
                            LockSupport.parkNanos(this, nanos);
                            if (Thread.interrupted()) {
                                j(gVar3);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f21267d;
                            if ((obj2 != null) && (!(obj2 instanceof e))) {
                                return g(obj2);
                            }
                            nanos = jNanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        j(gVar3);
                        break;
                    }
                    gVar2 = this.f21269i;
                    if (gVar2 == gVar) {
                    }
                }
            }
            return g(this.f21267d);
        }
        z11 = true;
        while (nanos > 0) {
            Object obj3 = this.f21267d;
            if ((obj3 != null ? z11 : false) && (!(obj3 instanceof e))) {
                return g(obj3);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = jNanoTime - System.nanoTime();
        }
        String string = toString();
        String string2 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = string2.toLowerCase(locale);
        StringBuilder sbM = x2.m(j6, "Waited ", " ");
        sbM.append(timeUnit.toString().toLowerCase(locale));
        String string3 = sbM.toString();
        if (nanos + 1000 < 0) {
            String strG = x2.g(string3, " (plus ");
            long j11 = -nanos;
            long jConvert = timeUnit.convert(j11, TimeUnit.NANOSECONDS);
            long nanos2 = j11 - timeUnit.toNanos(jConvert);
            boolean z12 = (jConvert == 0 || nanos2 > 1000) ? z11 : false;
            if (jConvert > 0) {
                String strG2 = strG + jConvert + " " + lowerCase;
                if (z12) {
                    strG2 = x2.g(strG2, ",");
                }
                strG = x2.g(strG2, " ");
            }
            if (z12) {
                strG = strG + nanos2 + " nanoseconds ";
            }
            string3 = x2.g(strG, "delay)");
        }
        if (isDone()) {
            throw new TimeoutException(x2.g(string3, " but future completed as timeout expired"));
        }
        throw new TimeoutException(x2.h(string3, " for ", string));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final String i() {
        Object obj = this.f21267d;
        if (obj instanceof e) {
            StringBuilder sb2 = new StringBuilder("setFuture=[");
            y yVar = ((e) obj).f21260e;
            return nb.o(sb2, yVar == this ? "this future" : String.valueOf(yVar), "]");
        }
        if (!(this instanceof ScheduledFuture)) {
            return null;
        }
        return "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f21267d instanceof a;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        Object obj = this.f21267d;
        return (!(obj instanceof e)) & (obj != null);
    }

    public final void j(g gVar) {
        gVar.f21262a = null;
        while (true) {
            g gVar2 = this.f21269i;
            if (gVar2 == g.f21261c) {
                return;
            }
            g gVar3 = null;
            while (gVar2 != null) {
                g gVar4 = gVar2.f21263b;
                if (gVar2.f21262a != null) {
                    gVar3 = gVar2;
                } else if (gVar3 != null) {
                    gVar3.f21263b = gVar4;
                    if (gVar3.f21262a == null) {
                    }
                } else if (!f21266x.k(this, gVar2, gVar4)) {
                }
                gVar2 = gVar4;
            }
            return;
        }
    }

    public final String toString() {
        String strI;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.toString());
        sb2.append("[status=");
        if (this.f21267d instanceof a) {
            sb2.append(DigitalCredentialModule.CODE_CANCELLED);
        } else if (isDone()) {
            d(sb2);
        } else {
            try {
                strI = i();
            } catch (RuntimeException e4) {
                strI = "Exception thrown from implementation: " + e4.getClass();
            }
            if (strI != null && !strI.isEmpty()) {
                sb2.append("PENDING, info=[");
                sb2.append(strI);
                sb2.append("]");
            } else if (isDone()) {
                d(sb2);
            } else {
                sb2.append("PENDING");
            }
        }
        sb2.append("]");
        return sb2.toString();
    }

    @Override // java.util.concurrent.Future
    public final Object get() throws InterruptedException {
        Object obj;
        g gVar = g.f21261c;
        if (!Thread.interrupted()) {
            Object obj2 = this.f21267d;
            if ((obj2 != null) & (!(obj2 instanceof e))) {
                return g(obj2);
            }
            g gVar2 = this.f21269i;
            if (gVar2 != gVar) {
                g gVar3 = new g();
                do {
                    com.facebook.imagepipeline.nativecode.b bVar = f21266x;
                    bVar.X(gVar3, gVar2);
                    if (bVar.k(this, gVar2, gVar3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f21267d;
                            } else {
                                j(gVar3);
                                throw new InterruptedException();
                            }
                        } while (!((obj != null) & (!(obj instanceof e))));
                        return g(obj);
                    }
                    gVar2 = this.f21269i;
                } while (gVar2 != gVar);
            }
            return g(this.f21267d);
        }
        throw new InterruptedException();
    }
}
