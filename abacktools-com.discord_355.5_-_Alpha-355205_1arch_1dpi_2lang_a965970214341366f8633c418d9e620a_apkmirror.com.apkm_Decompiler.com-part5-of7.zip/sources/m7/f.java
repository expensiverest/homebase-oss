package m7;

/* JADX INFO: loaded from: classes.dex */
public final class f extends com.facebook.imagepipeline.nativecode.b {
    @Override // com.facebook.imagepipeline.nativecode.b
    public final void X(g gVar, g gVar2) {
        gVar.f21263b = gVar2;
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final void Z(g gVar, Thread thread) {
        gVar.f21262a = thread;
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final boolean g(h hVar, c cVar, c cVar2) {
        synchronized (hVar) {
            try {
                if (hVar.f21268e != cVar) {
                    return false;
                }
                hVar.f21268e = cVar2;
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final boolean i(h hVar, Object obj, Object obj2) {
        synchronized (hVar) {
            try {
                if (hVar.f21267d != obj) {
                    return false;
                }
                hVar.f21267d = obj2;
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final boolean k(h hVar, g gVar, g gVar2) {
        synchronized (hVar) {
            try {
                if (hVar.f21269i != gVar) {
                    return false;
                }
                hVar.f21269i = gVar2;
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
