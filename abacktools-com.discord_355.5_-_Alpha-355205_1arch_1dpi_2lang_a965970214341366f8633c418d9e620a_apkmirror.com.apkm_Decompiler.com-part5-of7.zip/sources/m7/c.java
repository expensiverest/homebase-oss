package m7;

import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final c f21252d = new c(null, null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Runnable f21253a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Executor f21254b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public c f21255c;

    public c(Runnable runnable, Executor executor) {
        this.f21253a = runnable;
        this.f21254b = executor;
    }
}
