package m7;

import com.google.android.gms.internal.play_billing.l1;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f21250b = new b(new l1("Failure occurred while trying to finish a future.", 2));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Throwable f21251a;

    public b(Throwable th2) {
        boolean z11 = h.f21264v;
        th2.getClass();
        this.f21251a = th2;
    }
}
