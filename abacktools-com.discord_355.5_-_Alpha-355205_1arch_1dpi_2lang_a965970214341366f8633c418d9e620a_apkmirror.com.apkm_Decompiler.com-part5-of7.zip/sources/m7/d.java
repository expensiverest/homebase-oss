package m7;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: loaded from: classes.dex */
public final class d extends com.facebook.imagepipeline.nativecode.b {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f21256j;
    public final AtomicReferenceFieldUpdater k;
    public final AtomicReferenceFieldUpdater l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f21257m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f21258n;

    public d(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
        this.f21256j = atomicReferenceFieldUpdater;
        this.k = atomicReferenceFieldUpdater2;
        this.l = atomicReferenceFieldUpdater3;
        this.f21257m = atomicReferenceFieldUpdater4;
        this.f21258n = atomicReferenceFieldUpdater5;
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final void X(g gVar, g gVar2) {
        this.k.lazySet(gVar, gVar2);
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final void Z(g gVar, Thread thread) {
        this.f21256j.lazySet(gVar, thread);
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final boolean g(h hVar, c cVar, c cVar2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f21257m;
            if (atomicReferenceFieldUpdater.compareAndSet(hVar, cVar, cVar2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(hVar) == cVar);
        return false;
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final boolean i(h hVar, Object obj, Object obj2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f21258n;
            if (atomicReferenceFieldUpdater.compareAndSet(hVar, obj, obj2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(hVar) == obj);
        return false;
    }

    @Override // com.facebook.imagepipeline.nativecode.b
    public final boolean k(h hVar, g gVar, g gVar2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.l;
            if (atomicReferenceFieldUpdater.compareAndSet(hVar, gVar, gVar2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(hVar) == gVar);
        return false;
    }
}
