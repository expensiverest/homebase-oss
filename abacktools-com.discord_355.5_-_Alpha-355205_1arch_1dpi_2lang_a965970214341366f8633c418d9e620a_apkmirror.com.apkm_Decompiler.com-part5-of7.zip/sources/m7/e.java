package m7;

import mx.y;

/* JADX INFO: loaded from: classes.dex */
public final class e implements Runnable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final j f21259d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final y f21260e;

    public e(j jVar, y yVar) {
        this.f21259d = jVar;
        this.f21260e = yVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.f21259d.f21267d != this) {
            return;
        }
        if (h.f21266x.i(this.f21259d, this, h.h(this.f21260e))) {
            h.e(this.f21259d);
        }
    }
}
