package m7;

import mx.y;

/* JADX INFO: loaded from: classes.dex */
public final class j extends h {
    public final boolean k(Object obj) {
        if (obj == null) {
            obj = h.y;
        }
        if (!h.f21266x.i(this, null, obj)) {
            return false;
        }
        h.e(this);
        return true;
    }

    public final boolean l(Throwable th2) {
        if (!h.f21266x.i(this, null, new b(th2))) {
            return false;
        }
        h.e(this);
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0048  */
    public final boolean m(y yVar) {
        b bVar;
        yVar.getClass();
        Object obj = this.f21267d;
        if (obj != null) {
            if (obj instanceof a) {
                yVar.cancel(((a) obj).f21248a);
            }
        } else if (yVar.isDone()) {
            if (h.f21266x.i(this, null, h.h(yVar))) {
                h.e(this);
                return true;
            }
        } else {
            e eVar = new e(this, yVar);
            if (h.f21266x.i(this, null, eVar)) {
                try {
                    yVar.a(eVar, i.f21270d);
                    return true;
                } catch (Throwable th2) {
                    try {
                        bVar = new b(th2);
                    } catch (Throwable unused) {
                        bVar = b.f21250b;
                    }
                    h.f21266x.i(this, eVar, bVar);
                    return true;
                }
            }
            obj = this.f21267d;
            if (obj instanceof a) {
                yVar.cancel(((a) obj).f21248a);
            }
        }
        return false;
    }
}
