package lz;

import com.discord.R;

/* JADX INFO: loaded from: classes3.dex */
public abstract class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f20720a = {R.attr.hideWheelUntilFocused, R.attr.internalLayout, R.attr.internalMaxHeight, R.attr.internalMaxWidth, R.attr.internalMinHeight, R.attr.internalMinWidth, R.attr.selectionDivider, R.attr.selectionDividerHeight, R.attr.selectionDividersDistance, R.attr.solidColor, R.attr.virtualButtonPressedDrawable};
}
