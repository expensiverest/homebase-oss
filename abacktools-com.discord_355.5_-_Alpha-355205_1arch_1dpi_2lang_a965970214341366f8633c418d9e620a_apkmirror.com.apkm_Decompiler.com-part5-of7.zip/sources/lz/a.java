package lz;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

/* JADX INFO: loaded from: classes3.dex */
public final class a implements Callback {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20701d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ m f20702e;

    public /* synthetic */ a(m mVar, int i11) {
        this.f20701d = i11;
        this.f20702e = mVar;
    }

    @Override // com.facebook.react.bridge.Callback
    public final void invoke(Object... objArr) {
        switch (this.f20701d) {
            case 0:
                m mVar = this.f20702e;
                String date = mVar.getDate();
                String pickerId = mVar.getPickerId();
                WritableMap writableMapCreateMap = Arguments.createMap();
                writableMapCreateMap.putString("date", date);
                writableMapCreateMap.putString("id", pickerId);
                ((DeviceEventManagerModule.RCTDeviceEventEmitter) com.mkuczera.haptic.c.f8414b.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("onConfirm", writableMapCreateMap);
                break;
            default:
                String pickerId2 = this.f20702e.getPickerId();
                WritableMap writableMapCreateMap2 = Arguments.createMap();
                writableMapCreateMap2.putString("id", pickerId2);
                ((DeviceEventManagerModule.RCTDeviceEventEmitter) com.mkuczera.haptic.c.f8414b.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)).emit("onCancel", writableMapCreateMap2);
                break;
        }
    }
}
