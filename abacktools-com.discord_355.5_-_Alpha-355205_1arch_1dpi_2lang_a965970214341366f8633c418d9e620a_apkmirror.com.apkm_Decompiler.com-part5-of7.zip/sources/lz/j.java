package lz;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes3.dex */
public final class j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final j f20710d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final j f20711e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final j f20712i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ j[] f20713v;

    static {
        j jVar = new j("MMMEd", 0);
        f20710d = jVar;
        j jVar2 = new j("d", 1);
        f20711e = jVar2;
        j jVar3 = new j("y", 2);
        f20712i = jVar3;
        f20713v = new j[]{jVar, jVar2, jVar3};
    }

    public static j valueOf(String str) {
        return (j) Enum.valueOf(j.class, str);
    }

    public static j[] values() {
        return (j[]) f20713v.clone();
    }
}
