package lz;

import java.util.EnumMap;

/* JADX INFO: loaded from: classes3.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final i f20714a = b("EEE, MMM d", "d", "y");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final h f20715b;

    static {
        h hVar = new h();
        hVar.put("af", b("EEE d MMM", "d", "y"));
        hVar.put("am", b("EEE፣ MMM d", "d", "y"));
        hVar.put("ar", b("EEE، d MMM", "d", "y"));
        hVar.put("ar_DZ", b("EEE، d MMM", "d", "y"));
        hVar.put("ar_EG", b("EEE، d MMM", "d", "y"));
        hVar.put("az", b("d MMM, EEE", "d", "y"));
        hVar.put("be", b("EEE, d MMM", "d", "y"));
        hVar.put("bg", b("EEE, d.MM", "d", "y 'г'."));
        hVar.put("bn", b("EEE d MMM", "d", "y"));
        hVar.put("br", b("EEE d MMM", "d", "y"));
        hVar.put("bs", b("EEE, d. MMM", "d.", "y."));
        hVar.put("ca", b("EEE, d MMM", "d", "y"));
        hVar.put("chr", b("EEE, MMM d", "d", "y"));
        hVar.put("cs", b("EEE d. M.", "d.", "y"));
        hVar.put("cy", b("EEE, d MMM", "d", "y"));
        hVar.put("da", b("EEE d. MMM", "d.", "y"));
        hVar.put("de", b("EEE, d. MMM", "d", "y"));
        hVar.put("de_AT", b("EEE, d. MMM", "d", "y"));
        hVar.put("de_CH", b("EEE, d. MMM", "d", "y"));
        hVar.put("el", b("EEE, d MMM", "d", "y"));
        hVar.put("en", b("EEE, MMM d", "d", "y"));
        hVar.put("en_AU", b("EEE, d MMM", "d", "y"));
        hVar.put("en_CA", b("EEE, MMM d", "d", "y"));
        hVar.put("en_GB", b("EEE, d MMM", "d", "y"));
        hVar.put("en_IE", b("EEE, d MMM", "d", "y"));
        hVar.put("en_IN", b("EEE, d MMM", "d", "y"));
        hVar.put("en_SG", b("EEE, d MMM", "d", "y"));
        hVar.put("en_US", b("EEE, MMM d", "d", "y"));
        hVar.put("en_ZA", b("EEE, dd MMM", "d", "y"));
        hVar.put("es", b("EEE, d MMM", "d", "y"));
        hVar.put("es_419", b("EEE, d MMM", "d", "y"));
        hVar.put("es_ES", b("EEE, d MMM", "d", "y"));
        hVar.put("es_MX", b("EEE d 'de' MMM", "d", "y"));
        hVar.put("es_US", b("EEE, d 'de' MMM", "d", "y"));
        hVar.put("et", b("EEE, d. MMM", "d", "y"));
        hVar.put("eu", b("MMM d, EEE", "d", "y"));
        hVar.put("fa", b("EEE d LLL", "d", "y"));
        hVar.put("fi", b("EEE d. MMM", "d", "y"));
        hVar.put("fil", b("EEE, MMM d", "d", "y"));
        hVar.put("fr", b("EEE d MMM", "d", "y"));
        hVar.put("fr_CA", b("EEE d MMM", "d", "y"));
        hVar.put("ga", b("EEE d MMM", "d", "y"));
        hVar.put("gl", b("EEE, d 'de' MMM", "d", "y"));
        hVar.put("gsw", b("EEE d. MMM", "d", "y"));
        hVar.put("gu", b("EEE, d MMM", "d", "y"));
        hVar.put("haw", b("EEE, d MMM", "d", "y"));
        hVar.put("he", b("EEE, d בMMM", "d", "y"));
        hVar.put("hi", b("EEE, d MMM", "d", "y"));
        hVar.put("hr", b("EEE, d. MMM", "d.", "y."));
        hVar.put("hu", b("MMM d., EEE", "d", "y."));
        hVar.put("hy", b("d MMM, EEE", "d", "y"));
        hVar.put("id", b("EEE, d MMM", "d", "y"));
        hVar.put("in", b("EEE, d MMM", "d", "y"));
        hVar.put("is", b("EEE, d. MMM", "d", "y"));
        hVar.put("it", b("EEE d MMM", "d", "y"));
        hVar.put("iw", b("EEE, d בMMM", "d", "y"));
        hVar.put("ja", b("M月d日 EEE", "d日", "y年"));
        hVar.put("ka", b("EEE, d MMM", "d", "y"));
        hVar.put("kk", b("d MMM, EEE", "d", "y"));
        hVar.put("km", b("EEE d MMM", "d", "y"));
        hVar.put("kn", b("EEE, d MMM", "d", "y"));
        hVar.put("ko", b("MMM d일 EEE", "d일", "y년"));
        hVar.put("ky", b("d-MMM, EEE", "d", "y"));
        hVar.put("lb", b("EEE d MMM", "d", "y"));
        hVar.put("ln", b("EEE d MMM", "d", "y"));
        hVar.put("lo", b("EEE d MMM", "d", "y"));
        hVar.put("lt", b("MM-dd, EEE", "dd", "y"));
        hVar.put("lv", b("EEE, d. MMM", "d", "y. 'g'."));
        hVar.put("mk", b("EEE, d MMM", "d", "y"));
        hVar.put("ml", b("MMM d, EEE", "d", "y"));
        hVar.put("mn", b("MMM'ын' d. EEE", "d", "y"));
        hVar.put("mo", b("EEE, d MMM", "d", "y"));
        hVar.put("mr", b("EEE, d MMM", "d", "y"));
        hVar.put("ms", b("EEE, d MMM", "d", "y"));
        hVar.put("mt", b("EEE, d 'ta'’ MMM", "d", "y"));
        hVar.put("my", b("MMM d၊ EEE", "d", "y"));
        hVar.put("nb", b("EEE d. MMM", "d.", "y"));
        hVar.put("ne", b("MMM d, EEE", "d", "y"));
        hVar.put("nl", b("EEE d MMM", "d", "y"));
        hVar.put("nn", b("EEE d. MMM", "d.", "y"));
        hVar.put("no", b("EEE d. MMM", "d.", "y"));
        hVar.put("no_NO", b("EEE d. MMM", "d.", "y"));
        hVar.put("or", b("EEE, MMM d", "d", "y"));
        hVar.put("pa", b("EEE, d MMM", "d", "y"));
        hVar.put("pl", b("EEE, d MMM", "d", "y"));
        hVar.put("pt", b("EEE, d 'de' MMM", "d", "y"));
        hVar.put("pt_BR", b("EEE, d 'de' MMM", "d", "y"));
        hVar.put("pt_PT", b("EEE, d/MM", "d", "y"));
        hVar.put("ro", b("EEE, d MMM", "d", "y"));
        hVar.put("ru", b("ccc, d MMM", "d", "y"));
        hVar.put("sh", b("EEE d. MMM", "d", "y."));
        hVar.put("si", b("MMM d EEE", "d", "y"));
        hVar.put("sk", b("EEE d. M.", "d.", "y"));
        hVar.put("sl", b("EEE, d. MMM", "d.", "y"));
        hVar.put("sq", b("EEE, d MMM", "d", "y"));
        hVar.put("sr", b("EEE d. MMM", "d", "y."));
        hVar.put("sr_Latn", b("EEE d. MMM", "d", "y."));
        hVar.put("sv", b("EEE d MMM", "d", "y"));
        hVar.put("sw", b("EEE, d MMM", "d", "y"));
        hVar.put("ta", b("MMM d, EEE", "d", "y"));
        hVar.put("te", b("d MMM, EEE", "d", "y"));
        hVar.put("th", b("EEE d MMM", "d", "y"));
        hVar.put("tl", b("EEE, MMM d", "d", "y"));
        hVar.put("tr", b("d MMMM EEE", "d", "y"));
        hVar.put("uk", b("EEE, d MMM", "d", "y"));
        hVar.put("ur", b("EEE، d MMM", "d", "y"));
        hVar.put("uz", b("EEE, d-MMM", "d", "y"));
        hVar.put("vi", b("EEE, d MMM", "d", "y"));
        hVar.put("zh", b("M月d日EEE", "d日", "y年"));
        hVar.put("zh_CN", b("M月d日EEE", "d日", "y年"));
        hVar.put("zh_HK", b("M月d日EEE", "d日", "y年"));
        hVar.put("zh_TW", b("M月d日 EEE", "d日", "y年"));
        hVar.put("zu", b("EEE, MMM d", "d", "y"));
        hVar.put("en_ISO", b("EEE, MMM d", "d", "y"));
        hVar.put("en_MY", b("EEE, d MMM", "d", "y"));
        hVar.put("fr_CH", b("EEE d MMM", "d", "y"));
        hVar.put("it_CH", b("EEE d MMM", "d", "y"));
        hVar.put("ps", b("MMM d, EEE", "d", "y"));
        f20715b = hVar;
    }

    public static String a(String str, j jVar) throws k {
        try {
            return ((String) ((EnumMap) f20715b.get(str)).get(jVar)).replaceAll(",", "");
        } catch (NullPointerException unused) {
            throw new k();
        }
    }

    public static i b(String str, String str2, String str3) {
        i iVar = new i(j.class);
        iVar.put(j.f20710d, str);
        iVar.put(j.f20711e, str2);
        iVar.put(j.f20712i, str3);
        return iVar;
    }
}
