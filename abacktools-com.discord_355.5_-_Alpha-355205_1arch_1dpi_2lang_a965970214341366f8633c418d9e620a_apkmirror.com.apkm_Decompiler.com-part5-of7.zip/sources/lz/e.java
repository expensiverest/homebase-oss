package lz;

/* JADX INFO: loaded from: classes3.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g f20708a;

    public e(g gVar) {
        this.f20708a = gVar;
    }
}
