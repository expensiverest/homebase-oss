package lz;

import android.app.AlertDialog;

/* JADX INFO: loaded from: classes3.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AlertDialog f20709a;
}
