package lz;

import android.content.DialogInterface;

/* JADX INFO: loaded from: classes3.dex */
public final class c implements DialogInterface.OnClickListener {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ a f20704d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ m f20705e;

    public c(a aVar, m mVar) {
        this.f20704d = aVar;
        this.f20705e = mVar;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i11) {
        this.f20704d.invoke(this.f20705e.getDate());
        dialogInterface.dismiss();
    }
}
