package lz;

import java.util.EnumMap;

/* JADX INFO: loaded from: classes3.dex */
public final class i extends EnumMap {
}
