package lz;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;

/* JADX INFO: loaded from: classes3.dex */
public final class d implements DialogInterface.OnShowListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f20706a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ AlertDialog f20707b;

    public d(String str, AlertDialog alertDialog) {
        this.f20706a = str;
        this.f20707b = alertDialog;
    }

    @Override // android.content.DialogInterface.OnShowListener
    public final void onShow(DialogInterface dialogInterface) {
        String str = this.f20706a;
        if (str != null) {
            int color = Color.parseColor(str);
            AlertDialog alertDialog = this.f20707b;
            alertDialog.getButton(-1).setTextColor(color);
            alertDialog.getButton(-2).setTextColor(color);
        }
    }
}
