package lz;

import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.core.view.d0;
import com.discord.R;
import com.henninghall.date_picker.pickers.AndroidNative;
import fb.c0;
import j$.util.DesugarTimeZone;
import j.e0;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import k3.j0;
import k7.p;
import mr.k0;

/* JADX INFO: loaded from: classes3.dex */
public final class m extends RelativeLayout {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final j0 f20716d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p f20717e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ArrayList f20718i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final e0 f20719v;

    public m(LinearLayout.LayoutParams layoutParams) {
        super(com.mkuczera.haptic.c.f8414b);
        p pVar = new p();
        this.f20717e = pVar;
        this.f20718i = new ArrayList();
        this.f20719v = new e0(4, this);
        LinearLayout linearLayout = new LinearLayout(getContext());
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(getContext());
        ((d0) pVar.Q).getClass();
        layoutInflaterFrom.inflate(R.layout.native_picker, linearLayout);
        addView(linearLayout, layoutParams);
        this.f20716d = new j0(pVar, this);
    }

    public final boolean a(String... strArr) {
        for (String str : strArr) {
            if (this.f20718i.contains(str)) {
                return true;
            }
        }
        return false;
    }

    public final void b() {
        boolean zA = a("textColor");
        j0 j0Var = this.f20716d;
        if (zA) {
            c0 c0Var = (c0) j0Var.f18648i;
            String str = (String) ((pz.a) ((p) j0Var.f18647e).f19376x).f26312a;
            Iterator it = c0Var.a().iterator();
            while (it.hasNext()) {
                ((sz.e) it.next()).f29496d.setTextColor(str);
            }
        }
        if (a("mode", "is24hourSource")) {
            for (sz.e eVar : ((c0) j0Var.f18648i).a()) {
                eVar.f29496d.setVisibility(eVar.h() ? 0 : 8);
            }
        }
        if (a("mode", "locale", "is24hourSource")) {
            c0 c0Var2 = (c0) j0Var.f18648i;
            k0 k0Var = (k0) c0Var2.M;
            ((LinearLayout) k0Var.f21633d).removeAllViews();
            Iterator it2 = ((d0) ((p) c0Var2.f11572w).Q).m().iterator();
            while (it2.hasNext()) {
                ((LinearLayout) k0Var.f21633d).addView(((sz.e) ((h) c0Var2.N).get((nz.c) it2.next())).f29496d.getView());
            }
        }
        if (a("date", "locale", "maximumDate", "minimumDate", "minuteInterval", "mode", "timezoneOffsetInMinutes")) {
            c0 c0Var3 = (c0) j0Var.f18648i;
            new nw.f(21);
            for (sz.e eVar2 : c0Var3.a()) {
                eVar2.getClass();
                eVar2.f29497e = new SimpleDateFormat(eVar2.a(), eVar2.f29493a.f());
                if (eVar2.h()) {
                    oz.e eVar3 = eVar2.f29496d;
                    eVar3.setMinValue(0);
                    eVar3.setMaxValue(0);
                    ArrayList arrayListF = eVar2.f();
                    eVar2.f29495c = arrayListF;
                    ArrayList arrayList = new ArrayList();
                    Iterator it3 = arrayListF.iterator();
                    while (it3.hasNext()) {
                        arrayList.add(eVar2.g((String) it3.next()));
                    }
                    eVar3.setDisplayedValues((String[]) arrayList.toArray(new String[0]));
                    eVar3.setMaxValue(eVar2.f29495c.size() - 1);
                }
            }
        }
        boolean zA2 = a("locale");
        p pVar = this.f20717e;
        if (zA2) {
            pVar.f();
            int i11 = qz.a.f27353a;
        }
        if (a("dividerColor")) {
            String str2 = (String) ((pz.a) pVar.O).f26312a;
            Iterator it4 = ((c0) j0Var.f18648i).a().iterator();
            while (it4.hasNext()) {
                ((sz.e) it4.next()).f29496d.setDividerColor(str2);
            }
        }
        c0 c0Var4 = (c0) j0Var.f18648i;
        Calendar calendarH = ((p) j0Var.f18647e).h();
        for (sz.e eVar4 : c0Var4.a()) {
            oz.e eVar5 = eVar4.f29496d;
            eVar4.f29497e.setTimeZone(eVar4.f29493a.l());
            eVar4.f29494b = calendarH;
            int iB = eVar4.b(calendarH);
            if (iB > -1) {
                if (eVar5.getValue() == 0) {
                    eVar5.setValue(iB);
                } else {
                    ((AndroidNative) eVar5).t(iB);
                }
            }
        }
        this.f20718i = new ArrayList();
    }

    public String getDate() {
        p pVar = (p) ((d0) this.f20717e.Q).f1456d;
        Calendar calendar = (Calendar) pVar.f19372e;
        String str = (String) ((pz.a) pVar.f19373i).f26312a;
        if (calendar == null) {
            return str;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        simpleDateFormat.setTimeZone(DesugarTimeZone.getTimeZone("UTC"));
        return simpleDateFormat.format(calendar.getTime());
    }

    public String getPickerId() {
        return (String) ((pz.a) this.f20717e.N).f26312a;
    }

    @Override // android.widget.RelativeLayout, android.view.View, android.view.ViewParent
    public final void requestLayout() {
        super.requestLayout();
        post(this.f20719v);
    }
}
