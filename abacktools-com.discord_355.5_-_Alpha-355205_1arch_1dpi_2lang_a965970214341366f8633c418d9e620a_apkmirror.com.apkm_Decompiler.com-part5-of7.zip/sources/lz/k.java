package lz;

/* JADX INFO: loaded from: classes3.dex */
public final class k extends Exception {
}
