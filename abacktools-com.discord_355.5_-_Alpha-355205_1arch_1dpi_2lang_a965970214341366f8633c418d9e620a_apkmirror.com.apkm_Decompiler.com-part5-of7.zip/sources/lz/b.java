package lz;

import android.content.DialogInterface;

/* JADX INFO: loaded from: classes3.dex */
public final class b implements DialogInterface.OnClickListener {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ a f20703d;

    public b(a aVar) {
        this.f20703d = aVar;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i11) {
        this.f20703d.invoke(new Object[0]);
        dialogInterface.dismiss();
    }
}
