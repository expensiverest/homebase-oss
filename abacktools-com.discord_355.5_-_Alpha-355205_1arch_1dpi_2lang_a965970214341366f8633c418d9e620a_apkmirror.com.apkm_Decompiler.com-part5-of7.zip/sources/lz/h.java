package lz;

import java.util.HashMap;

/* JADX INFO: loaded from: classes3.dex */
public final class h extends HashMap {
}
