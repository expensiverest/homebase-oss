package mt;

import android.content.Context;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.os.Looper;
import android.text.TextUtils;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.CaptioningManager;
import hx.m0;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import ss.w0;

/* JADX INFO: loaded from: classes3.dex */
public final class g extends v {
    public boolean A;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public boolean H;
    public boolean I;
    public boolean J;
    public boolean K;
    public boolean L;
    public boolean M;
    public boolean N;
    public final SparseArray O;
    public final SparseBooleanArray P;

    /* JADX WARN: Code duplicated, block: B:54:0x00ef  */
    /* JADX WARN: Code duplicated, block: B:56:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:57:0x0107 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:58:0x0109  */
    /* JADX WARN: Code duplicated, block: B:59:0x010d  */
    public g(Context context) {
        Point point;
        Point point2;
        DisplayManager displayManager;
        CaptioningManager captioningManager;
        int i11 = qt.x.f27318a;
        if (i11 >= 19 && ((i11 >= 23 || Looper.myLooper() != null) && (captioningManager = (CaptioningManager) context.getSystemService("captioning")) != null && captioningManager.isEnabled())) {
            this.f21990t = 1088;
            Locale locale = captioningManager.getLocale();
            if (locale != null) {
                this.f21989s = m0.v(i11 >= 21 ? locale.toLanguageTag() : locale.toString());
            }
        }
        Display display = (i11 < 17 || (displayManager = (DisplayManager) context.getSystemService("display")) == null) ? null : displayManager.getDisplay(0);
        if (display == null) {
            WindowManager windowManager = (WindowManager) context.getSystemService("window");
            windowManager.getClass();
            display = windowManager.getDefaultDisplay();
        }
        if (display.getDisplayId() == 0 && qt.x.H(context)) {
            String strA = i11 < 28 ? qt.x.A("sys.display-size") : qt.x.A("vendor.display-size");
            if (!TextUtils.isEmpty(strA)) {
                try {
                    String[] strArrSplit = strA.trim().split("x", -1);
                    if (strArrSplit.length == 2) {
                        int i12 = Integer.parseInt(strArrSplit[0]);
                        int i13 = Integer.parseInt(strArrSplit[1]);
                        if (i12 > 0 && i13 > 0) {
                            point2 = new Point(i12, i13);
                        }
                    }
                } catch (NumberFormatException unused) {
                }
                qt.a.r("Util", "Invalid display size: " + strA);
            }
            if ("Sony".equals(qt.x.f27320c) && qt.x.f27321d.startsWith("BRAVIA") && context.getPackageManager().hasSystemFeature("com.sony.dtv.hardware.panel.qfhd")) {
                point = new Point(3840, 2160);
            } else {
                point = new Point();
                if (i11 >= 23) {
                    Display.Mode mode = display.getMode();
                    point.x = mode.getPhysicalWidth();
                    point.y = mode.getPhysicalHeight();
                } else if (i11 >= 17) {
                    display.getRealSize(point);
                } else {
                    display.getSize(point);
                }
            }
            point2 = point;
        } else {
            point = new Point();
            if (i11 >= 23) {
                Display.Mode mode2 = display.getMode();
                point.x = mode2.getPhysicalWidth();
                point.y = mode2.getPhysicalHeight();
            } else if (i11 >= 17) {
                display.getRealSize(point);
            } else {
                display.getSize(point);
            }
            point2 = point;
        }
        b(point2.x, point2.y);
        this.O = new SparseArray();
        this.P = new SparseBooleanArray();
        c();
    }

    @Override // mt.v
    public final v b(int i11, int i12) {
        super.b(i11, i12);
        return this;
    }

    public final void c() {
        this.A = true;
        this.B = false;
        this.C = true;
        this.D = false;
        this.E = true;
        this.F = false;
        this.G = false;
        this.H = false;
        this.I = false;
        this.J = true;
        this.K = true;
        this.L = false;
        this.M = true;
        this.N = false;
    }

    public final void d(int i11, boolean z11) {
        SparseBooleanArray sparseBooleanArray = this.P;
        if (sparseBooleanArray.get(i11) == z11) {
            return;
        }
        if (z11) {
            sparseBooleanArray.put(i11, true);
        } else {
            sparseBooleanArray.delete(i11);
        }
    }

    public final void e(int i11, w0 w0Var, i iVar) {
        SparseArray sparseArray = this.O;
        Map map = (Map) sparseArray.get(i11);
        if (map == null) {
            map = new HashMap();
            sparseArray.put(i11, map);
        }
        if (map.containsKey(w0Var) && qt.x.a(map.get(w0Var), iVar)) {
            return;
        }
        map.put(w0Var, iVar);
    }

    public g(h hVar) {
        a(hVar);
        this.A = hVar.f21921c0;
        this.B = hVar.f21922d0;
        this.C = hVar.f21923e0;
        this.D = hVar.f21924f0;
        this.E = hVar.f21925g0;
        this.F = hVar.f21926h0;
        this.G = hVar.f21927i0;
        this.H = hVar.f21928j0;
        this.I = hVar.f21929k0;
        this.J = hVar.f21930l0;
        this.K = hVar.f21931m0;
        this.L = hVar.f21932n0;
        this.M = hVar.f21933o0;
        this.N = hVar.f21934p0;
        SparseArray sparseArray = hVar.f21935q0;
        SparseArray sparseArray2 = new SparseArray();
        for (int i11 = 0; i11 < sparseArray.size(); i11++) {
            sparseArray2.put(sparseArray.keyAt(i11), new HashMap((Map) sparseArray.valueAt(i11)));
        }
        this.O = sparseArray2;
        this.P = hVar.f21936r0.clone();
    }

    public g() {
        this.O = new SparseArray();
        this.P = new SparseBooleanArray();
        c();
    }
}
