package mt;

import hx.m0;
import hx.p0;
import hx.x0;

/* JADX INFO: loaded from: classes3.dex */
public class w implements mr.e {
    public final int J;
    public final int K;
    public final int L;
    public final boolean M;
    public final m0 N;
    public final int O;
    public final m0 P;
    public final int Q;
    public final int R;
    public final int S;
    public final m0 T;
    public final m0 U;
    public final int V;
    public final int W;
    public final boolean X;
    public final boolean Y;
    public final boolean Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final p0 f21996a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final x0 f21997b0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21998d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f21999e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f22000i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f22001v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f22002w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f22003x;
    public final int y;

    static {
        new w(new v());
        int i11 = qt.x.f27318a;
        Integer.toString(1, 36);
        Integer.toString(2, 36);
        Integer.toString(3, 36);
        Integer.toString(4, 36);
        Integer.toString(5, 36);
        Integer.toString(6, 36);
        Integer.toString(7, 36);
        Integer.toString(8, 36);
        Integer.toString(9, 36);
        Integer.toString(10, 36);
        Integer.toString(11, 36);
        Integer.toString(12, 36);
        Integer.toString(13, 36);
        Integer.toString(14, 36);
        Integer.toString(15, 36);
        Integer.toString(16, 36);
        Integer.toString(17, 36);
        Integer.toString(18, 36);
        Integer.toString(19, 36);
        Integer.toString(20, 36);
        Integer.toString(21, 36);
        Integer.toString(22, 36);
        Integer.toString(23, 36);
        Integer.toString(24, 36);
        Integer.toString(25, 36);
        Integer.toString(26, 36);
    }

    public w(v vVar) {
        this.f21998d = vVar.f21973a;
        this.f21999e = vVar.f21974b;
        this.f22000i = vVar.f21975c;
        this.f22001v = vVar.f21976d;
        this.f22002w = vVar.f21977e;
        this.f22003x = vVar.f21978f;
        this.y = vVar.f21979g;
        this.J = vVar.f21980h;
        this.K = vVar.f21981i;
        this.L = vVar.f21982j;
        this.M = vVar.k;
        this.N = vVar.l;
        this.O = vVar.f21983m;
        this.P = vVar.f21984n;
        this.Q = vVar.f21985o;
        this.R = vVar.f21986p;
        this.S = vVar.f21987q;
        this.T = vVar.f21988r;
        this.U = vVar.f21989s;
        this.V = vVar.f21990t;
        this.W = vVar.f21991u;
        this.X = vVar.f21992v;
        this.Y = vVar.f21993w;
        this.Z = vVar.f21994x;
        this.f21996a0 = p0.a(vVar.y);
        this.f21997b0 = x0.q(vVar.f21995z);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            w wVar = (w) obj;
            if (this.f21998d == wVar.f21998d && this.f21999e == wVar.f21999e && this.f22000i == wVar.f22000i && this.f22001v == wVar.f22001v && this.f22002w == wVar.f22002w && this.f22003x == wVar.f22003x && this.y == wVar.y && this.J == wVar.J && this.M == wVar.M && this.K == wVar.K && this.L == wVar.L && this.N.equals(wVar.N) && this.O == wVar.O && this.P.equals(wVar.P) && this.Q == wVar.Q && this.R == wVar.R && this.S == wVar.S && this.T.equals(wVar.T) && this.U.equals(wVar.U) && this.V == wVar.V && this.W == wVar.W && this.X == wVar.X && this.Y == wVar.Y && this.Z == wVar.Z) {
                p0 p0Var = wVar.f21996a0;
                p0 p0Var2 = this.f21996a0;
                p0Var2.getClass();
                if (hx.s.j(p0Var2, p0Var) && this.f21997b0.equals(wVar.f21997b0)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        return this.f21997b0.hashCode() + ((this.f21996a0.hashCode() + ((((((((((((this.U.hashCode() + ((this.T.hashCode() + ((((((((this.P.hashCode() + ((((this.N.hashCode() + ((((((((((((((((((((((this.f21998d + 31) * 31) + this.f21999e) * 31) + this.f22000i) * 31) + this.f22001v) * 31) + this.f22002w) * 31) + this.f22003x) * 31) + this.y) * 31) + this.J) * 31) + (this.M ? 1 : 0)) * 31) + this.K) * 31) + this.L) * 31)) * 31) + this.O) * 31)) * 31) + this.Q) * 31) + this.R) * 31) + this.S) * 31)) * 31)) * 31) + this.V) * 31) + this.W) * 31) + (this.X ? 1 : 0)) * 31) + (this.Y ? 1 : 0)) * 31) + (this.Z ? 1 : 0)) * 31)) * 31);
    }
}
