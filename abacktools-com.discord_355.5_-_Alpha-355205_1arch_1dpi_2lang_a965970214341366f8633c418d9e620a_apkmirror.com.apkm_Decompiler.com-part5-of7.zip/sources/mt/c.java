package mt;

import android.os.SystemClock;
import java.util.Arrays;
import java.util.List;
import mr.i0;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public abstract class c implements q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v0 f21909a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f21910b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f21911c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final i0[] f21912d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long[] f21913e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f21914f;

    public c(v0 v0Var, int[] iArr) {
        int i11 = 0;
        qt.a.k(iArr.length > 0);
        v0Var.getClass();
        this.f21909a = v0Var;
        int length = iArr.length;
        this.f21910b = length;
        this.f21912d = new i0[length];
        for (int i12 = 0; i12 < iArr.length; i12++) {
            this.f21912d[i12] = v0Var.f29352v[iArr[i12]];
        }
        Arrays.sort(this.f21912d, new a4.h(20));
        this.f21911c = new int[this.f21910b];
        while (true) {
            int i13 = this.f21910b;
            if (i11 >= i13) {
                this.f21913e = new long[i13];
                return;
            } else {
                this.f21911c[i11] = v0Var.a(this.f21912d[i11]);
                i11++;
            }
        }
    }

    @Override // mt.q
    public final boolean a(int i11, long j6) {
        return this.f21913e[i11] > j6;
    }

    @Override // mt.q
    public final v0 b() {
        return this.f21909a;
    }

    @Override // mt.q
    public final i0 e(int i11) {
        return this.f21912d[i11];
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            c cVar = (c) obj;
            if (this.f21909a == cVar.f21909a && Arrays.equals(this.f21911c, cVar.f21911c)) {
                return true;
            }
        }
        return false;
    }

    @Override // mt.q
    public final int f(int i11) {
        return this.f21911c[i11];
    }

    @Override // mt.q
    public int g(long j6, List list) {
        return list.size();
    }

    @Override // mt.q
    public final int h() {
        return this.f21911c[c()];
    }

    public final int hashCode() {
        if (this.f21914f == 0) {
            this.f21914f = Arrays.hashCode(this.f21911c) + (System.identityHashCode(this.f21909a) * 31);
        }
        return this.f21914f;
    }

    @Override // mt.q
    public final i0 i() {
        return this.f21912d[c()];
    }

    @Override // mt.q
    public final boolean k(int i11, long j6) {
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        boolean zA = a(i11, jElapsedRealtime);
        int i12 = 0;
        while (i12 < this.f21910b && !zA) {
            zA = (i12 == i11 || a(i12, jElapsedRealtime)) ? false : true;
            i12++;
        }
        if (!zA) {
            return false;
        }
        long[] jArr = this.f21913e;
        long j11 = jArr[i11];
        int i13 = qt.x.f27318a;
        long j12 = jElapsedRealtime + j6;
        if (((j6 ^ j12) & (jElapsedRealtime ^ j12)) < 0) {
            j12 = Long.MAX_VALUE;
        }
        jArr[i11] = Math.max(j11, j12);
        return true;
    }

    @Override // mt.q
    public final int length() {
        return this.f21911c.length;
    }

    @Override // mt.q
    public final int p(int i11) {
        for (int i12 = 0; i12 < this.f21910b; i12++) {
            if (this.f21911c[i12] == i11) {
                return i12;
            }
        }
        return -1;
    }

    @Override // mt.q
    public final int r(i0 i0Var) {
        for (int i11 = 0; i11 < this.f21910b; i11++) {
            if (this.f21912d[i11] == i0Var) {
                return i11;
            }
        }
        return -1;
    }

    @Override // mt.q
    public void disable() {
    }

    @Override // mt.q
    public void enable() {
    }

    @Override // mt.q
    public void l(float f3) {
    }
}
