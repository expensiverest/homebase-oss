package mt;

import mr.i0;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public abstract class m {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21949d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final v0 f21950e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21951i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final i0 f21952v;

    public m(int i11, v0 v0Var, int i12) {
        this.f21949d = i11;
        this.f21950e = v0Var;
        this.f21951i = i12;
        this.f21952v = v0Var.f29352v[i12];
    }

    public abstract int a();

    public abstract boolean b(m mVar);
}
