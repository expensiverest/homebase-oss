package mt;

import hx.a0;
import hx.m0;
import hx.r1;
import mr.i0;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public final class n extends m {
    public final boolean J;
    public final int K;
    public final int L;
    public final int M;
    public final int N;
    public final boolean O;
    public final boolean P;
    public final int Q;
    public final boolean R;
    public final boolean S;
    public final int T;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f21953w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final h f21954x;
    public final boolean y;

    /* JADX WARN: Code duplicated, block: B:115:0x013b  */
    /* JADX WARN: Code duplicated, block: B:31:0x004d  */
    /* JADX WARN: Code duplicated, block: B:51:0x007b  */
    public n(int i11, v0 v0Var, int i12, h hVar, int i13, int i14, boolean z11) {
        boolean z12;
        boolean z13;
        int i15;
        int i16;
        i0 i0Var;
        int i17;
        int i18;
        int i19;
        i0 i0Var2;
        int i21;
        int i22;
        int i23;
        super(i11, v0Var, i12);
        this.f21954x = hVar;
        boolean z14 = hVar.f21923e0;
        m0 m0Var = hVar.N;
        int i24 = z14 ? 24 : 16;
        int i25 = 0;
        this.P = hVar.f21922d0 && (i14 & i24) != 0;
        if (!z11 || (((i21 = (i0Var2 = this.f21952v).S) != -1 && i21 > hVar.f21998d) || ((i22 = i0Var2.T) != -1 && i22 > hVar.f21999e))) {
            z12 = false;
        } else {
            float f3 = i0Var2.U;
            if ((f3 == -1.0f || f3 <= hVar.f22000i) && ((i23 = i0Var2.J) == -1 || i23 <= hVar.f22001v)) {
                z12 = true;
            } else {
                z12 = false;
            }
        }
        this.f21953w = z12;
        if (!z11 || (((i17 = (i0Var = this.f21952v).S) != -1 && i17 < hVar.f22002w) || ((i18 = i0Var.T) != -1 && i18 < hVar.f22003x))) {
            z13 = false;
        } else {
            float f11 = i0Var.U;
            if ((f11 == -1.0f || f11 >= hVar.y) && ((i19 = i0Var.J) == -1 || i19 >= hVar.J)) {
                z13 = true;
            } else {
                z13 = false;
            }
        }
        this.y = z13;
        this.J = o.d(i13, false);
        i0 i0Var3 = this.f21952v;
        this.K = i0Var3.J;
        int i26 = i0Var3.S;
        this.L = (i26 == -1 || (i16 = i0Var3.T) == -1) ? -1 : i26 * i16;
        int i27 = i0Var3.f21574w;
        int i28 = hVar.O;
        int i29 = Integer.MAX_VALUE;
        this.N = (i27 == 0 || i27 != i28) ? Integer.bitCount(i27 & i28) : Integer.MAX_VALUE;
        int i31 = this.f21952v.f21574w;
        this.O = i31 == 0 || (i31 & 1) != 0;
        for (int i32 = 0; i32 < m0Var.size(); i32++) {
            String str = this.f21952v.N;
            if (str != null && str.equals(m0Var.get(i32))) {
                i29 = i32;
                break;
            }
        }
        this.M = i29;
        this.R = (i13 & 384) == 128;
        this.S = (i13 & 64) == 64;
        i0 i0Var4 = this.f21952v;
        String str2 = i0Var4.N;
        if (str2 != null) {
            i15 = 4;
            switch (str2) {
                case "video/dolby-vision":
                    i15 = 5;
                    break;
                case "video/av01":
                    break;
                case "video/hevc":
                    i15 = 3;
                    break;
                case "video/avc":
                    i15 = 1;
                    break;
                case "video/x-vnd.on2.vp9":
                    i15 = 2;
                    break;
                default:
                    i15 = 0;
                    break;
            }
        } else {
            i15 = 0;
        }
        this.T = i15;
        boolean z15 = this.f21953w;
        h hVar2 = this.f21954x;
        if ((i0Var4.f21574w & 16384) == 0 && o.d(i13, hVar2.f21931m0) && (z15 || hVar2.f21921c0)) {
            i25 = (!o.d(i13, false) || !this.y || !z15 || i0Var4.J == -1 || hVar2.Z || hVar2.Y || (i24 & i13) == 0) ? 1 : 2;
        }
        this.Q = i25;
    }

    public static int c(n nVar, n nVar2) {
        a0 a0VarB = a0.f14763a.c(nVar.J, nVar2.J).a(nVar.N, nVar2.N).c(nVar.O, nVar2.O).c(nVar.f21953w, nVar2.f21953w).c(nVar.y, nVar2.y).b(Integer.valueOf(nVar.M), Integer.valueOf(nVar2.M), r1.f14868i);
        boolean z11 = nVar.R;
        a0 a0VarC = a0VarB.c(z11, nVar2.R);
        boolean z12 = nVar.S;
        a0 a0VarC2 = a0VarC.c(z12, nVar2.S);
        if (z11 && z12) {
            a0VarC2 = a0VarC2.a(nVar.T, nVar2.T);
        }
        return a0VarC2.e();
    }

    @Override // mt.m
    public final int a() {
        return this.Q;
    }

    @Override // mt.m
    public final boolean b(m mVar) {
        n nVar = (n) mVar;
        if (!this.P && !qt.x.a(this.f21952v.N, nVar.f21952v.N)) {
            return false;
        }
        if (this.f21954x.f21924f0) {
            return true;
        }
        return this.R == nVar.R && this.S == nVar.S;
    }
}
