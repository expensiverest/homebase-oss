package mt;

import hx.k0;
import hx.m0;
import hx.w1;
import java.util.HashMap;
import java.util.HashSet;

/* JADX INFO: loaded from: classes3.dex */
public class v {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21977e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f21978f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f21979g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f21980h;
    public m0 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f21983m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public m0 f21984n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f21985o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f21986p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f21987q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public m0 f21988r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public m0 f21989s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f21990t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f21991u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f21992v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f21993w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f21994x;
    public HashMap y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public HashSet f21995z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f21973a = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f21974b = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f21975c = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f21976d = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f21981i = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f21982j = Integer.MAX_VALUE;
    public boolean k = true;

    public v() {
        k0 k0Var = m0.f14841e;
        w1 w1Var = w1.f14911w;
        this.l = w1Var;
        this.f21983m = 0;
        this.f21984n = w1Var;
        this.f21985o = 0;
        this.f21986p = Integer.MAX_VALUE;
        this.f21987q = Integer.MAX_VALUE;
        this.f21988r = w1Var;
        this.f21989s = w1Var;
        this.f21990t = 0;
        this.f21991u = 0;
        this.f21992v = false;
        this.f21993w = false;
        this.f21994x = false;
        this.y = new HashMap();
        this.f21995z = new HashSet();
    }

    public final void a(w wVar) {
        this.f21973a = wVar.f21998d;
        this.f21974b = wVar.f21999e;
        this.f21975c = wVar.f22000i;
        this.f21976d = wVar.f22001v;
        this.f21977e = wVar.f22002w;
        this.f21978f = wVar.f22003x;
        this.f21979g = wVar.y;
        this.f21980h = wVar.J;
        this.f21981i = wVar.K;
        this.f21982j = wVar.L;
        this.k = wVar.M;
        this.l = wVar.N;
        this.f21983m = wVar.O;
        this.f21984n = wVar.P;
        this.f21985o = wVar.Q;
        this.f21986p = wVar.R;
        this.f21987q = wVar.S;
        this.f21988r = wVar.T;
        this.f21989s = wVar.U;
        this.f21990t = wVar.V;
        this.f21991u = wVar.W;
        this.f21992v = wVar.X;
        this.f21993w = wVar.Y;
        this.f21994x = wVar.Z;
        this.f21995z = new HashSet(wVar.f21997b0);
        this.y = new HashMap(wVar.f21996a0);
    }

    public v b(int i11, int i12) {
        this.f21981i = i11;
        this.f21982j = i12;
        this.k = true;
        return this;
    }
}
