package mt;

import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.reactnativecommunity.webview.RNCWebViewManager;
import java.util.Map;
import ss.w0;

/* JADX INFO: loaded from: classes3.dex */
public final class h extends w {

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final h f21920s0;
    public static final h t0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public final boolean f21921c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final boolean f21922d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final boolean f21923e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final boolean f21924f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public final boolean f21925g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public final boolean f21926h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public final boolean f21927i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public final boolean f21928j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public final boolean f21929k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public final boolean f21930l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public final boolean f21931m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public final boolean f21932n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public final boolean f21933o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public final boolean f21934p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public final SparseArray f21935q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final SparseBooleanArray f21936r0;

    static {
        h hVar = new h(new g());
        f21920s0 = hVar;
        t0 = hVar;
        int i11 = qt.x.f27318a;
        Integer.toString(RNCWebViewManager.COMMAND_CLEAR_FORM_DATA, 36);
        Integer.toString(RNCWebViewManager.COMMAND_CLEAR_CACHE, 36);
        Integer.toString(RNCWebViewManager.COMMAND_CLEAR_HISTORY, 36);
        Integer.toString(1003, 36);
        Integer.toString(1004, 36);
        Integer.toString(1005, 36);
        Integer.toString(1006, 36);
        Integer.toString(1007, 36);
        Integer.toString(1008, 36);
        Integer.toString(1009, 36);
        Integer.toString(1010, 36);
        Integer.toString(1011, 36);
        Integer.toString(1012, 36);
        Integer.toString(1013, 36);
        Integer.toString(1014, 36);
        Integer.toString(1015, 36);
        Integer.toString(1016, 36);
        Integer.toString(1017, 36);
    }

    public h(g gVar) {
        super(gVar);
        this.f21921c0 = gVar.A;
        this.f21922d0 = gVar.B;
        this.f21923e0 = gVar.C;
        this.f21924f0 = gVar.D;
        this.f21925g0 = gVar.E;
        this.f21926h0 = gVar.F;
        this.f21927i0 = gVar.G;
        this.f21928j0 = gVar.H;
        this.f21929k0 = gVar.I;
        this.f21930l0 = gVar.J;
        this.f21931m0 = gVar.K;
        this.f21932n0 = gVar.L;
        this.f21933o0 = gVar.M;
        this.f21934p0 = gVar.N;
        this.f21935q0 = gVar.O;
        this.f21936r0 = gVar.P;
    }

    @Override // mt.w
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && h.class == obj.getClass()) {
            h hVar = (h) obj;
            if (super.equals(hVar) && this.f21921c0 == hVar.f21921c0 && this.f21922d0 == hVar.f21922d0 && this.f21923e0 == hVar.f21923e0 && this.f21924f0 == hVar.f21924f0 && this.f21925g0 == hVar.f21925g0 && this.f21926h0 == hVar.f21926h0 && this.f21927i0 == hVar.f21927i0 && this.f21928j0 == hVar.f21928j0 && this.f21929k0 == hVar.f21929k0 && this.f21930l0 == hVar.f21930l0 && this.f21931m0 == hVar.f21931m0 && this.f21932n0 == hVar.f21932n0 && this.f21933o0 == hVar.f21933o0 && this.f21934p0 == hVar.f21934p0) {
                SparseBooleanArray sparseBooleanArray = hVar.f21936r0;
                SparseBooleanArray sparseBooleanArray2 = this.f21936r0;
                int size = sparseBooleanArray2.size();
                if (sparseBooleanArray.size() == size) {
                    int i11 = 0;
                    while (true) {
                        if (i11 >= size) {
                            SparseArray sparseArray = hVar.f21935q0;
                            SparseArray sparseArray2 = this.f21935q0;
                            int size2 = sparseArray2.size();
                            if (sparseArray.size() != size2) {
                                break;
                            }
                            for (int i12 = 0; i12 < size2; i12++) {
                                int iIndexOfKey = sparseArray.indexOfKey(sparseArray2.keyAt(i12));
                                if (iIndexOfKey < 0) {
                                    break;
                                }
                                Map map = (Map) sparseArray2.valueAt(i12);
                                Map map2 = (Map) sparseArray.valueAt(iIndexOfKey);
                                if (map2.size() != map.size()) {
                                    break;
                                }
                                for (Map.Entry entry : map.entrySet()) {
                                    w0 w0Var = (w0) entry.getKey();
                                    if (!map2.containsKey(w0Var) || !qt.x.a(entry.getValue(), map2.get(w0Var))) {
                                        break;
                                    }
                                }
                            }
                            return true;
                        }
                        if (sparseBooleanArray.indexOfKey(sparseBooleanArray2.keyAt(i11)) < 0) {
                            break;
                        }
                        i11++;
                    }
                }
            }
        }
        return false;
    }

    @Override // mt.w
    public final int hashCode() {
        return ((((((((((((((((((((((((((((super.hashCode() + 31) * 31) + (this.f21921c0 ? 1 : 0)) * 31) + (this.f21922d0 ? 1 : 0)) * 31) + (this.f21923e0 ? 1 : 0)) * 31) + (this.f21924f0 ? 1 : 0)) * 31) + (this.f21925g0 ? 1 : 0)) * 31) + (this.f21926h0 ? 1 : 0)) * 31) + (this.f21927i0 ? 1 : 0)) * 31) + (this.f21928j0 ? 1 : 0)) * 31) + (this.f21929k0 ? 1 : 0)) * 31) + (this.f21930l0 ? 1 : 0)) * 31) + (this.f21931m0 ? 1 : 0)) * 31) + (this.f21932n0 ? 1 : 0)) * 31) + (this.f21933o0 ? 1 : 0)) * 31) + (this.f21934p0 ? 1 : 0);
    }
}
