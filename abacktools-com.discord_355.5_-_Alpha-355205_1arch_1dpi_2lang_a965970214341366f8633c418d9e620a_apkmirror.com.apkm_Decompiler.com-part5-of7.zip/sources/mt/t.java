package mt;

import mr.f0;

/* JADX INFO: loaded from: classes3.dex */
public abstract class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public f0 f21970a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ot.f f21971b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public s f21972c;
}
