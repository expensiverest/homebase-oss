package mt;

import hx.a0;
import mr.i0;

/* JADX INFO: loaded from: classes3.dex */
public final class f implements Comparable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f21918d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f21919e;

    public f(i0 i0Var, int i11) {
        this.f21918d = (i0Var.f21573v & 1) != 0;
        this.f21919e = o.d(i11, false);
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        f fVar = (f) obj;
        return a0.f14763a.c(this.f21919e, fVar.f21919e).c(this.f21918d, fVar.f21918d).e();
    }
}
