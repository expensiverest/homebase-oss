package mt;

import java.util.List;
import mr.i0;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public interface q {
    boolean a(int i11, long j6);

    v0 b();

    int c();

    void disable();

    i0 e(int i11);

    void enable();

    int f(int i11);

    int g(long j6, List list);

    int h();

    i0 i();

    int j();

    boolean k(int i11, long j6);

    void l(float f3);

    int length();

    Object m();

    int p(int i11);

    void q(long j6, long j11, long j12, List list, us.m[] mVarArr);

    int r(i0 i0Var);

    default boolean s(long j6, us.e eVar, List list) {
        return false;
    }

    default void n() {
    }

    default void o() {
    }

    default void d(boolean z11) {
    }
}
