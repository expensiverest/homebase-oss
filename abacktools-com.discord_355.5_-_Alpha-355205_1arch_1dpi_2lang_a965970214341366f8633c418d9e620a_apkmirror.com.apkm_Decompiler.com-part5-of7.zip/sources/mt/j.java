package mt;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.Spatializer;
import android.os.Handler;
import android.os.Looper;
import mr.i0;
import org.webrtc.MediaStreamTrack;

/* JADX INFO: loaded from: classes3.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Spatializer f21943a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f21944b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Handler f21945c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public l4.a f21946d;

    public j(Spatializer spatializer) {
        this.f21943a = spatializer;
        this.f21944b = spatializer.getImmersiveAudioLevel() != 0;
    }

    public static j f(Context context) {
        AudioManager audioManager = (AudioManager) context.getSystemService(MediaStreamTrack.AUDIO_TRACK_KIND);
        if (audioManager == null) {
            return null;
        }
        return new j(audioManager.getSpatializer());
    }

    public final boolean a(i0 i0Var, or.d dVar) {
        String str = i0Var.N;
        int i11 = i0Var.f21560a0;
        if ("audio/eac3-joc".equals(str) && i11 == 16) {
            i11 = 12;
        }
        AudioFormat.Builder channelMask = new AudioFormat.Builder().setEncoding(2).setChannelMask(qt.x.o(i11));
        int i12 = i0Var.f21561b0;
        if (i12 != -1) {
            channelMask.setSampleRate(i12);
        }
        return this.f21943a.canBeSpatialized((AudioAttributes) dVar.a().f19723e, channelMask.build());
    }

    public final void b(o oVar, Looper looper) {
        if (this.f21946d == null && this.f21945c == null) {
            int i11 = 1;
            this.f21946d = new l4.a(i11, oVar);
            Handler handler = new Handler(looper);
            this.f21945c = handler;
            this.f21943a.addOnSpatializerStateChangedListener(new v3.u(i11, handler), this.f21946d);
        }
    }

    public final boolean c() {
        return this.f21943a.isAvailable();
    }

    public final boolean d() {
        return this.f21943a.isEnabled();
    }

    public final void e() {
        l4.a aVar = this.f21946d;
        if (aVar == null || this.f21945c == null) {
            return;
        }
        this.f21943a.removeOnSpatializerStateChangedListener(aVar);
        Handler handler = this.f21945c;
        int i11 = qt.x.f27318a;
        handler.removeCallbacksAndMessages(null);
        this.f21945c = null;
        this.f21946d = null;
    }
}
