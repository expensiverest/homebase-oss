package mt;

import mr.i0;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class d implements gx.m {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ o f21915d;

    /* JADX WARN: Code duplicated, block: B:40:0x0062 A[Catch: all -> 0x0087, FALL_THROUGH, TryCatch #0 {all -> 0x0087, blocks: (B:4:0x0007, B:6:0x000e, B:8:0x0012, B:10:0x0017, B:34:0x0056, B:36:0x005a, B:38:0x005e, B:40:0x0062, B:42:0x0066, B:44:0x006a, B:46:0x006e, B:48:0x0074, B:50:0x007c, B:56:0x008a), top: B:60:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:55:0x0089  */
    @Override // gx.m
    public final boolean apply(Object obj) {
        boolean z11;
        j jVar;
        j jVar2;
        o oVar = this.f21915d;
        i0 i0Var = (i0) obj;
        synchronized (oVar.f21955d) {
            try {
                z11 = true;
                if (oVar.f21959h.f21930l0 && !oVar.f21958g) {
                    if (i0Var.f21560a0 > 2) {
                        String str = i0Var.N;
                        if (str != null) {
                            switch (str) {
                                case "audio/eac3-joc":
                                case "audio/ac3":
                                case "audio/ac4":
                                case "audio/eac3":
                                    if (qt.x.f27318a >= 32 && (jVar2 = oVar.f21960i) != null && jVar2.f21944b) {
                                    }
                                default:
                                    if (qt.x.f27318a < 32) {
                                        z11 = false;
                                        break;
                                    } else {
                                        z11 = false;
                                        break;
                                    }
                                    break;
                            }
                        } else if (qt.x.f27318a < 32 || (jVar = oVar.f21960i) == null || !jVar.f21944b || !jVar.c() || !oVar.f21960i.d() || !oVar.f21960i.a(i0Var, oVar.f21961j)) {
                            z11 = false;
                        }
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return z11;
    }
}
