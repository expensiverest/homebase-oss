package mt;

import hx.a0;
import hx.m0;
import hx.r1;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public final class k extends m implements Comparable {
    public final boolean J;
    public final int K;
    public final int L;
    public final int M;
    public final int N;
    public final boolean O;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21947w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final boolean f21948x;
    public final boolean y;

    public k(int i11, v0 v0Var, int i12, h hVar, int i13, String str) {
        int iB;
        super(i11, v0Var, i12);
        int i14 = 0;
        this.f21948x = o.d(i13, false);
        int i15 = this.f21952v.f21573v;
        int i16 = hVar.W;
        m0 m0Var = hVar.U;
        int i17 = i15 & (~i16);
        this.y = (i17 & 1) != 0;
        this.J = (i17 & 2) != 0;
        m0 m0VarV = m0Var.isEmpty() ? m0.v("") : m0Var;
        int i18 = 0;
        while (true) {
            if (i18 >= m0VarV.size()) {
                iB = 0;
                i18 = Integer.MAX_VALUE;
                break;
            } else {
                iB = o.b(this.f21952v, (String) m0VarV.get(i18), hVar.X);
                if (iB > 0) {
                    break;
                } else {
                    i18++;
                }
            }
        }
        this.K = i18;
        this.L = iB;
        int i19 = this.f21952v.f21574w;
        int i21 = hVar.V;
        int iBitCount = (i19 == 0 || i19 != i21) ? Integer.bitCount(i19 & i21) : Integer.MAX_VALUE;
        this.M = iBitCount;
        this.O = (this.f21952v.f21574w & 1088) != 0;
        int iB2 = o.b(this.f21952v, str, o.f(str) == null);
        this.N = iB2;
        boolean z11 = iB > 0 || (m0Var.isEmpty() && iBitCount > 0) || this.y || (this.J && iB2 > 0);
        if (o.d(i13, hVar.f21931m0) && z11) {
            i14 = 1;
        }
        this.f21947w = i14;
    }

    @Override // mt.m
    public final int a() {
        return this.f21947w;
    }

    @Override // mt.m
    public final /* bridge */ /* synthetic */ boolean b(m mVar) {
        return false;
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public final int compareTo(k kVar) {
        a0 a0VarC = a0.f14763a.c(this.f21948x, kVar.f21948x);
        Integer numValueOf = Integer.valueOf(this.K);
        Integer numValueOf2 = Integer.valueOf(kVar.K);
        r1 r1Var = r1.f14867e;
        r1 r1Var2 = r1.f14868i;
        a0 a0VarB = a0VarC.b(numValueOf, numValueOf2, r1Var2);
        int i11 = kVar.L;
        int i12 = this.L;
        a0 a0VarA = a0VarB.a(i12, i11);
        int i13 = kVar.M;
        int i14 = this.M;
        a0 a0VarC2 = a0VarA.a(i14, i13).c(this.y, kVar.y);
        Boolean boolValueOf = Boolean.valueOf(this.J);
        Boolean boolValueOf2 = Boolean.valueOf(kVar.J);
        if (i12 != 0) {
            r1Var = r1Var2;
        }
        a0 a0VarA2 = a0VarC2.b(boolValueOf, boolValueOf2, r1Var).a(this.N, kVar.N);
        if (i14 == 0) {
            a0VarA2 = a0VarA2.d(this.O, kVar.O);
        }
        return a0VarA2.e();
    }
}
