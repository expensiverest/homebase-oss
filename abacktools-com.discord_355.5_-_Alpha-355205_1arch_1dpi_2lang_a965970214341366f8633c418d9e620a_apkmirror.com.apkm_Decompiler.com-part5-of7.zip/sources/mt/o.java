package mt;

import android.content.Context;
import android.text.TextUtils;
import android.util.Pair;
import hx.m0;
import hx.u1;
import hx.w1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.RandomAccess;
import mr.f0;
import mr.i0;
import ss.v0;
import ss.w0;

/* JADX INFO: loaded from: classes3.dex */
public final class o extends t {
    public static final u1 k = u1.a(new a4.h(21));
    public static final u1 l = u1.a(new a4.h(22));

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f21955d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Context f21956e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final cl.a f21957f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f21958g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h f21959h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final j f21960i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public or.d f21961j;

    public o(w wVar, cl.a aVar, Context context) {
        this.f21955d = new Object();
        this.f21956e = context != null ? context.getApplicationContext() : null;
        this.f21957f = aVar;
        if (wVar instanceof h) {
            this.f21959h = (h) wVar;
        } else {
            h hVar = context != null ? new h(new g(context)) : h.f21920s0;
            hVar.getClass();
            g gVar = new g(hVar);
            gVar.a(wVar);
            this.f21959h = new h(gVar);
        }
        this.f21961j = or.d.y;
        boolean z11 = context != null && qt.x.H(context);
        this.f21958g = z11;
        if (!z11 && context != null && qt.x.f27318a >= 32) {
            this.f21960i = j.f(context);
        }
        if (this.f21959h.f21930l0 && context == null) {
            qt.a.N("DefaultTrackSelector", "Audio channel count constraints cannot be applied without reference to Context. Build the track selector instance with one of the non-deprecated constructors that take a Context argument.");
        }
    }

    public static void a(w0 w0Var, h hVar, HashMap map) {
        for (int i11 = 0; i11 < w0Var.f29356d; i11++) {
        }
    }

    public static int b(i0 i0Var, String str, boolean z11) {
        if (!TextUtils.isEmpty(str) && str.equals(i0Var.f21570i)) {
            return 4;
        }
        String strF = f(str);
        String strF2 = f(i0Var.f21570i);
        if (strF2 == null || strF == null) {
            return (z11 && strF2 == null) ? 1 : 0;
        }
        if (strF2.startsWith(strF) || strF.startsWith(strF2)) {
            return 3;
        }
        int i11 = qt.x.f27318a;
        return strF2.split("-", 2)[0].equals(strF.split("-", 2)[0]) ? 2 : 0;
    }

    public static boolean d(int i11, boolean z11) {
        int i12 = i11 & 7;
        if (i12 != 4) {
            return z11 && i12 == 3;
        }
        return true;
    }

    public static String f(String str) {
        if (TextUtils.isEmpty(str) || TextUtils.equals(str, "und")) {
            return null;
        }
        return str;
    }

    public static Pair g(int i11, s sVar, int[][][] iArr, l lVar, Comparator comparator) {
        int i12;
        RandomAccess randomAccessV;
        s sVar2 = sVar;
        ArrayList arrayList = new ArrayList();
        int i13 = sVar2.f21964a;
        int i14 = 0;
        while (i14 < i13) {
            if (i11 == sVar2.f21965b[i14]) {
                w0 w0Var = sVar2.f21966c[i14];
                for (int i15 = 0; i15 < w0Var.f29356d; i15++) {
                    v0 v0VarA = w0Var.a(i15);
                    w1 w1VarD = lVar.d(i14, v0VarA, iArr[i14][i15]);
                    int i16 = v0VarA.f29349d;
                    boolean[] zArr = new boolean[i16];
                    int i17 = 0;
                    while (i17 < i16) {
                        m mVar = (m) w1VarD.get(i17);
                        int iA = mVar.a();
                        if (zArr[i17] || iA == 0) {
                            i12 = i13;
                        } else {
                            if (iA == 1) {
                                randomAccessV = m0.v(mVar);
                            } else {
                                ArrayList arrayList2 = new ArrayList();
                                arrayList2.add(mVar);
                                int i18 = i17 + 1;
                                while (i18 < i16) {
                                    m mVar2 = (m) w1VarD.get(i18);
                                    int i19 = i13;
                                    if (mVar2.a() == 2 && mVar.b(mVar2)) {
                                        arrayList2.add(mVar2);
                                        zArr[i18] = true;
                                    }
                                    i18++;
                                    i13 = i19;
                                }
                                randomAccessV = arrayList2;
                            }
                            i12 = i13;
                            arrayList.add(randomAccessV);
                        }
                        i17++;
                        i13 = i12;
                    }
                }
            }
            i14++;
            sVar2 = sVar;
            i13 = i13;
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        List list = (List) Collections.max(arrayList, comparator);
        int[] iArr2 = new int[list.size()];
        for (int i21 = 0; i21 < list.size(); i21++) {
            iArr2[i21] = ((m) list.get(i21)).f21951i;
        }
        m mVar3 = (m) list.get(0);
        return Pair.create(new p(0, mVar3.f21950e, iArr2), Integer.valueOf(mVar3.f21949d));
    }

    public final h c() {
        h hVar;
        synchronized (this.f21955d) {
            hVar = this.f21959h;
        }
        return hVar;
    }

    public final void e() {
        boolean z11;
        f0 f0Var;
        j jVar;
        synchronized (this.f21955d) {
            try {
                z11 = this.f21959h.f21930l0 && !this.f21958g && qt.x.f27318a >= 32 && (jVar = this.f21960i) != null && jVar.f21944b;
            } catch (Throwable th2) {
                throw th2;
            }
        }
        if (!z11 || (f0Var = this.f21970a) == null) {
            return;
        }
        f0Var.J.d(10);
    }

    public final void h(w wVar) {
        if (wVar instanceof h) {
            i((h) wVar);
        }
        g gVar = new g(c());
        gVar.a(wVar);
        i(new h(gVar));
    }

    public final void i(h hVar) {
        boolean zEquals;
        hVar.getClass();
        synchronized (this.f21955d) {
            zEquals = this.f21959h.equals(hVar);
            this.f21959h = hVar;
        }
        if (zEquals) {
            return;
        }
        if (hVar.f21930l0 && this.f21956e == null) {
            qt.a.N("DefaultTrackSelector", "Audio channel count constraints cannot be applied without reference to Context. Build the track selector instance with one of the non-deprecated constructors that take a Context argument.");
        }
        f0 f0Var = this.f21970a;
        if (f0Var != null) {
            f0Var.J.d(10);
        }
    }

    public o(Context context) {
        cl.a aVar = new cl.a(15);
        h hVar = h.f21920s0;
        this(new h(new g(context)), aVar, context);
    }
}
