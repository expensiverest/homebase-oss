package mt;

import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v0 f21962a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int[] f21963b;

    public p(int i11, v0 v0Var, int[] iArr) {
        if (iArr.length == 0) {
            qt.a.s("ETSDefinition", "Empty tracks are not allowed", new IllegalArgumentException());
        }
        this.f21962a = v0Var;
        this.f21963b = iArr;
    }
}
