package mt;

import java.util.Arrays;

/* JADX INFO: loaded from: classes3.dex */
public final class i implements mr.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String f21937v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final String f21938w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final String f21939x;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f21940d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[] f21941e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21942i;

    static {
        int i11 = qt.x.f27318a;
        f21937v = Integer.toString(0, 36);
        f21938w = Integer.toString(1, 36);
        f21939x = Integer.toString(2, 36);
    }

    public i(int i11, int i12, int[] iArr) {
        this.f21940d = i11;
        int[] iArrCopyOf = Arrays.copyOf(iArr, iArr.length);
        this.f21941e = iArrCopyOf;
        this.f21942i = i12;
        Arrays.sort(iArrCopyOf);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && i.class == obj.getClass()) {
            i iVar = (i) obj;
            if (this.f21940d == iVar.f21940d && Arrays.equals(this.f21941e, iVar.f21941e) && this.f21942i == iVar.f21942i) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((Arrays.hashCode(this.f21941e) + (this.f21940d * 31)) * 31) + this.f21942i;
    }
}
