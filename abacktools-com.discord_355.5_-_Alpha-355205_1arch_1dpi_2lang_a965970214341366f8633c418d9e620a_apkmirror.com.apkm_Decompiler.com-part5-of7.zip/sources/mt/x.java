package mt;

import mr.a2;
import mr.l2;

/* JADX INFO: loaded from: classes3.dex */
public final class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f22004a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a2[] f22005b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final q[] f22006c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final l2 f22007d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f22008e;

    public x(a2[] a2VarArr, q[] qVarArr, l2 l2Var, s sVar) {
        this.f22005b = a2VarArr;
        this.f22006c = (q[]) qVarArr.clone();
        this.f22007d = l2Var;
        this.f22008e = sVar;
        this.f22004a = a2VarArr.length;
    }

    public final boolean a(x xVar, int i11) {
        return xVar != null && qt.x.a(this.f22005b[i11], xVar.f22005b[i11]) && qt.x.a(this.f22006c[i11], xVar.f22006c[i11]);
    }

    public final boolean b(int i11) {
        return this.f22005b[i11] != null;
    }
}
