package mt;

import ss.w0;

/* JADX INFO: loaded from: classes3.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f21964a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int[] f21965b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w0[] f21966c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f21967d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[][][] f21968e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final w0 f21969f;

    public s(int[] iArr, w0[] w0VarArr, int[] iArr2, int[][][] iArr3, w0 w0Var) {
        this.f21965b = iArr;
        this.f21966c = w0VarArr;
        this.f21968e = iArr3;
        this.f21967d = iArr2;
        this.f21969f = w0Var;
        this.f21964a = iArr.length;
    }
}
