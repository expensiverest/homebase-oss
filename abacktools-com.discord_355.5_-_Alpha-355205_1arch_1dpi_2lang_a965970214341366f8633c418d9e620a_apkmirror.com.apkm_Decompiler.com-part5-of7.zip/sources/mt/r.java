package mt;

import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class r extends c {
    @Override // mt.q
    public final int c() {
        return 0;
    }

    @Override // mt.q
    public final int j() {
        return 0;
    }

    @Override // mt.q
    public final Object m() {
        return null;
    }

    @Override // mt.q
    public final void q(long j6, long j11, long j12, List list, us.m[] mVarArr) {
    }
}
