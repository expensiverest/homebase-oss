package mt;

import hx.w1;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public interface l {
    w1 d(int i11, v0 v0Var, int[] iArr);
}
