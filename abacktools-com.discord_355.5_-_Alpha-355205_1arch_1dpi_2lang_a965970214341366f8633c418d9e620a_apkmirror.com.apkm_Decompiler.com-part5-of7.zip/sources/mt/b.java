package mt;

import android.os.SystemClock;
import hx.j0;
import hx.m0;
import java.util.ArrayList;
import java.util.List;
import mr.i0;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public final class b extends c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ot.f f21896g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f21897h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long f21898i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final long f21899j;
    public final int k;
    public final int l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final float f21900m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final float f21901n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final m0 f21902o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final qt.s f21903p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f21904q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f21905r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f21906s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public long f21907t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public us.l f21908u;

    public b(v0 v0Var, int[] iArr, ot.f fVar, long j6, long j11, long j12, m0 m0Var) {
        super(v0Var, iArr);
        if (j12 < j6) {
            qt.a.N("AdaptiveTrackSelection", "Adjusting minDurationToRetainAfterDiscardMs to be at least minDurationForQualityIncreaseMs");
            j12 = j6;
        }
        this.f21896g = fVar;
        this.f21897h = j6 * 1000;
        this.f21898i = j11 * 1000;
        this.f21899j = j12 * 1000;
        this.k = 1279;
        this.l = 719;
        this.f21900m = 0.7f;
        this.f21901n = 0.75f;
        this.f21902o = m0.q(m0Var);
        this.f21903p = qt.s.f27310a;
        this.f21904q = 1.0f;
        this.f21906s = 0;
        this.f21907t = -9223372036854775807L;
    }

    public static void t(ArrayList arrayList, long[] jArr) {
        long j6 = 0;
        for (long j11 : jArr) {
            j6 += j11;
        }
        for (int i11 = 0; i11 < arrayList.size(); i11++) {
            j0 j0Var = (j0) arrayList.get(i11);
            if (j0Var != null) {
                j0Var.c(new a(j6, jArr[i11]));
            }
        }
    }

    public static long v(List list) {
        if (!list.isEmpty()) {
            us.l lVar = (us.l) hx.s.n(list);
            long j6 = lVar.y;
            if (j6 != -9223372036854775807L) {
                long j11 = lVar.J;
                if (j11 != -9223372036854775807L) {
                    return j11 - j6;
                }
            }
        }
        return -9223372036854775807L;
    }

    @Override // mt.q
    public final int c() {
        return this.f21905r;
    }

    @Override // mt.c, mt.q
    public final void disable() {
        this.f21908u = null;
    }

    @Override // mt.c, mt.q
    public final void enable() {
        this.f21907t = -9223372036854775807L;
        this.f21908u = null;
    }

    @Override // mt.c, mt.q
    public final int g(long j6, List list) {
        int i11;
        int i12;
        this.f21903p.getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        long j11 = this.f21907t;
        if (j11 != -9223372036854775807L && jElapsedRealtime - j11 < 1000 && (list.isEmpty() || ((us.l) hx.s.n(list)).equals(this.f21908u))) {
            return list.size();
        }
        this.f21907t = jElapsedRealtime;
        this.f21908u = list.isEmpty() ? null : (us.l) hx.s.n(list);
        if (list.isEmpty()) {
            return 0;
        }
        int size = list.size();
        long jY = qt.x.y(((us.l) list.get(size - 1)).y - j6, this.f21904q);
        long j12 = this.f21899j;
        if (jY >= j12) {
            v(list);
            i0 i0Var = this.f21912d[u(jElapsedRealtime)];
            for (int i13 = 0; i13 < size; i13++) {
                us.l lVar = (us.l) list.get(i13);
                i0 i0Var2 = lVar.f31626v;
                if (qt.x.y(lVar.y - j6, this.f21904q) >= j12 && i0Var2.J < i0Var.J && (i11 = i0Var2.T) != -1 && i11 <= this.l && (i12 = i0Var2.S) != -1 && i12 <= this.k && i11 < i0Var.T) {
                    return i13;
                }
            }
        }
        return size;
    }

    @Override // mt.q
    public final int j() {
        return this.f21906s;
    }

    @Override // mt.c, mt.q
    public final void l(float f3) {
        this.f21904q = f3;
    }

    @Override // mt.q
    public final Object m() {
        return null;
    }

    @Override // mt.q
    public final void q(long j6, long j11, long j12, List list, us.m[] mVarArr) {
        long jV;
        this.f21903p.getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        int i11 = this.f21905r;
        if (i11 >= mVarArr.length || !mVarArr[i11].next()) {
            int length = mVarArr.length;
            int i12 = 0;
            while (true) {
                if (i12 >= length) {
                    jV = v(list);
                    break;
                }
                us.m mVar = mVarArr[i12];
                if (mVar.next()) {
                    jV = mVar.j() - mVar.e();
                    break;
                }
                i12++;
            }
        } else {
            us.m mVar2 = mVarArr[this.f21905r];
            jV = mVar2.j() - mVar2.e();
        }
        int i13 = this.f21906s;
        if (i13 == 0) {
            this.f21906s = 1;
            this.f21905r = u(jElapsedRealtime);
            return;
        }
        int i14 = this.f21905r;
        int iR = list.isEmpty() ? -1 : r(((us.l) hx.s.n(list)).f31626v);
        if (iR != -1) {
            i13 = ((us.l) hx.s.n(list)).f31627w;
            i14 = iR;
        }
        int iU = u(jElapsedRealtime);
        if (iU != i14 && !a(i14, jElapsedRealtime)) {
            i0[] i0VarArr = this.f21912d;
            i0 i0Var = i0VarArr[i14];
            i0 i0Var2 = i0VarArr[iU];
            long jMin = this.f21897h;
            if (j12 != -9223372036854775807L) {
                jMin = Math.min((long) ((jV != -9223372036854775807L ? j12 - jV : j12) * this.f21901n), jMin);
            }
            int i15 = i0Var2.J;
            int i16 = i0Var.J;
            if ((i15 > i16 && j11 < jMin) || (i15 < i16 && j11 >= this.f21898i)) {
                iU = i14;
            }
        }
        if (iU != i14) {
            i13 = 3;
        }
        this.f21906s = i13;
        this.f21905r = iU;
    }

    public final int u(long j6) {
        long j11;
        ot.s sVar = (ot.s) this.f21896g;
        synchronized (sVar) {
            j11 = sVar.l;
        }
        long j12 = (long) (j11 * this.f21900m);
        this.f21896g.getClass();
        long j13 = (long) (j12 / this.f21904q);
        if (!this.f21902o.isEmpty()) {
            int i11 = 1;
            while (i11 < this.f21902o.size() - 1 && ((a) this.f21902o.get(i11)).f21894a < j13) {
                i11++;
            }
            a aVar = (a) this.f21902o.get(i11 - 1);
            a aVar2 = (a) this.f21902o.get(i11);
            long j14 = aVar.f21894a;
            float f3 = (j13 - j14) / (aVar2.f21894a - j14);
            long j15 = aVar.f21895b;
            j13 = j15 + ((long) (f3 * (aVar2.f21895b - j15)));
        }
        int i12 = 0;
        for (int i13 = 0; i13 < this.f21910b; i13++) {
            if (j6 == Long.MIN_VALUE || !a(i13, j6)) {
                if (this.f21912d[i13].J <= j13) {
                    return i13;
                }
                i12 = i13;
            }
        }
        return i12;
    }
}
