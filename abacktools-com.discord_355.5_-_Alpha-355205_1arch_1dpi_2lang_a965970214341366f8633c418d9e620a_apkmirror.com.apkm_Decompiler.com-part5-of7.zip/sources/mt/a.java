package mt;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f21894a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f21895b;

    public a(long j6, long j11) {
        this.f21894a = j6;
        this.f21895b = j11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.f21894a == aVar.f21894a && this.f21895b == aVar.f21895b;
    }

    public final int hashCode() {
        return (((int) this.f21894a) * 31) + ((int) this.f21895b);
    }
}
