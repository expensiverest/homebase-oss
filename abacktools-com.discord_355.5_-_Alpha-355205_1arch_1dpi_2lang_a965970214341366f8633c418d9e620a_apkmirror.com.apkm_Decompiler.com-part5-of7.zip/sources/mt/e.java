package mt;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;
import hx.a0;
import hx.m0;
import hx.r1;
import hx.u1;
import java.util.Locale;
import mr.i0;
import ss.v0;

/* JADX INFO: loaded from: classes3.dex */
public final class e extends m implements Comparable {
    public final h J;
    public final boolean K;
    public final int L;
    public final int M;
    public final int N;
    public final boolean O;
    public final int P;
    public final int Q;
    public final boolean R;
    public final int S;
    public final int T;
    public final int U;
    public final int V;
    public final boolean W;
    public final boolean X;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f21916w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final boolean f21917x;
    public final String y;

    public e(int i11, v0 v0Var, int i12, h hVar, int i13, boolean z11, d dVar) {
        m0 m0Var;
        int i14;
        int iB;
        String[] strArrSplit;
        int iB2;
        super(i11, v0Var, i12);
        this.J = hVar;
        this.y = o.f(this.f21952v.f21570i);
        int i15 = 0;
        this.K = o.d(i13, false);
        int i16 = 0;
        while (true) {
            m0 m0Var2 = hVar.P;
            m0Var = hVar.T;
            i14 = Integer.MAX_VALUE;
            if (i16 >= m0Var2.size()) {
                iB = 0;
                i16 = Integer.MAX_VALUE;
                break;
            } else {
                iB = o.b(this.f21952v, (String) hVar.P.get(i16), false);
                if (iB > 0) {
                    break;
                } else {
                    i16++;
                }
            }
        }
        this.M = i16;
        this.L = iB;
        int i17 = this.f21952v.f21574w;
        int i18 = hVar.Q;
        this.N = (i17 == 0 || i17 != i18) ? Integer.bitCount(i17 & i18) : Integer.MAX_VALUE;
        i0 i0Var = this.f21952v;
        int i19 = i0Var.f21574w;
        this.O = i19 == 0 || (i19 & 1) != 0;
        this.R = (i0Var.f21573v & 1) != 0;
        int i21 = i0Var.f21560a0;
        this.S = i21;
        this.T = i0Var.f21561b0;
        int i22 = i0Var.J;
        this.U = i22;
        this.f21917x = (i22 == -1 || i22 <= hVar.S) && (i21 == -1 || i21 <= hVar.R) && dVar.apply(i0Var);
        Configuration configuration = Resources.getSystem().getConfiguration();
        int i23 = qt.x.f27318a;
        if (i23 >= 24) {
            strArrSplit = configuration.getLocales().toLanguageTags().split(",", -1);
        } else {
            Locale locale = configuration.locale;
            strArrSplit = new String[]{i23 >= 21 ? locale.toLanguageTag() : locale.toString()};
        }
        for (int i24 = 0; i24 < strArrSplit.length; i24++) {
            strArrSplit[i24] = qt.x.J(strArrSplit[i24]);
        }
        int i25 = 0;
        while (true) {
            if (i25 >= strArrSplit.length) {
                iB2 = 0;
                i25 = Integer.MAX_VALUE;
                break;
            } else {
                iB2 = o.b(this.f21952v, strArrSplit[i25], false);
                if (iB2 > 0) {
                    break;
                } else {
                    i25++;
                }
            }
        }
        this.P = i25;
        this.Q = iB2;
        for (int i26 = 0; i26 < m0Var.size(); i26++) {
            String str = this.f21952v.N;
            if (str != null && str.equals(m0Var.get(i26))) {
                i14 = i26;
                break;
            }
        }
        this.V = i14;
        this.W = (i13 & 384) == 128;
        this.X = (i13 & 64) == 64;
        boolean z12 = this.f21917x;
        h hVar2 = this.J;
        if (o.d(i13, hVar2.f21931m0) && (z12 || hVar2.f21925g0)) {
            i15 = (!o.d(i13, false) || !z12 || this.f21952v.J == -1 || hVar2.Z || hVar2.Y || (!hVar2.f21933o0 && z11)) ? 1 : 2;
        }
        this.f21916w = i15;
    }

    @Override // mt.m
    public final int a() {
        return this.f21916w;
    }

    @Override // mt.m
    public final boolean b(m mVar) {
        int i11;
        String str;
        int i12;
        e eVar = (e) mVar;
        i0 i0Var = eVar.f21952v;
        h hVar = this.J;
        boolean z11 = hVar.f21928j0;
        i0 i0Var2 = this.f21952v;
        if (!z11 && ((i12 = i0Var2.f21560a0) == -1 || i12 != i0Var.f21560a0)) {
            return false;
        }
        if (!hVar.f21926h0 && ((str = i0Var2.N) == null || !TextUtils.equals(str, i0Var.N))) {
            return false;
        }
        if (!hVar.f21927i0 && ((i11 = i0Var2.f21561b0) == -1 || i11 != i0Var.f21561b0)) {
            return false;
        }
        if (hVar.f21929k0) {
            return true;
        }
        return this.W == eVar.W && this.X == eVar.X;
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public final int compareTo(e eVar) {
        boolean z11 = this.K;
        boolean z12 = this.f21917x;
        u1 u1VarC = (z12 && z11) ? o.k : o.k.c();
        boolean z13 = eVar.K;
        int i11 = eVar.U;
        a0 a0VarC = a0.f14763a.c(z11, z13);
        Integer numValueOf = Integer.valueOf(this.M);
        Integer numValueOf2 = Integer.valueOf(eVar.M);
        r1 r1Var = r1.f14868i;
        a0 a0VarB = a0VarC.b(numValueOf, numValueOf2, r1Var).a(this.L, eVar.L).a(this.N, eVar.N).c(this.R, eVar.R).c(this.O, eVar.O).b(Integer.valueOf(this.P), Integer.valueOf(eVar.P), r1Var).a(this.Q, eVar.Q).c(z12, eVar.f21917x).b(Integer.valueOf(this.V), Integer.valueOf(eVar.V), r1Var);
        int i12 = this.U;
        a0 a0VarB2 = a0VarB.b(Integer.valueOf(i12), Integer.valueOf(i11), this.J.Y ? o.k.c() : o.l).c(this.W, eVar.W).c(this.X, eVar.X).b(Integer.valueOf(this.S), Integer.valueOf(eVar.S), u1VarC).b(Integer.valueOf(this.T), Integer.valueOf(eVar.T), u1VarC);
        Integer numValueOf3 = Integer.valueOf(i12);
        Integer numValueOf4 = Integer.valueOf(i11);
        if (!qt.x.a(this.y, eVar.y)) {
            u1VarC = o.l;
        }
        return a0VarB2.b(numValueOf3, numValueOf4, u1VarC).e();
    }
}
