package n0;

/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f22250a;

    public /* synthetic */ o(String str) {
        this.f22250a = str;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof o) {
            return kotlin.jvm.internal.k.b(this.f22250a, ((o) obj).f22250a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f22250a.hashCode();
    }

    public final String toString() {
        return hs.q.i(')', "StringAnnotation(value=", this.f22250a);
    }
}
