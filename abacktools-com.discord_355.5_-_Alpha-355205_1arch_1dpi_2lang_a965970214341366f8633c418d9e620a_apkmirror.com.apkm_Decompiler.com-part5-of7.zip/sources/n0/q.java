package n0;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f22255a;

    public q(String str) {
        this.f22255a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof q) {
            return kotlin.jvm.internal.k.b(this.f22255a, ((q) obj).f22255a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f22255a.hashCode();
    }

    public final String toString() {
        return a1.h.k(new StringBuilder("UrlAnnotation(url="), this.f22255a, ')');
    }
}
