package n0;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;

/* JADX INFO: loaded from: classes.dex */
public final class l implements a0.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Function2 f22221d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Function1 f22222e;

    public l(Function2 function2, Function1 function1) {
        this.f22221d = function2;
        this.f22222e = function1;
    }

    @Override // a0.a
    public final Object a(Object obj) {
        return this.f22221d.invoke(null, obj);
    }
}
