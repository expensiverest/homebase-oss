package n0;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f22201a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f22202b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f22203c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f22204d;

    public a(Object obj, int i11, int i12, String str) {
        this.f22201a = obj;
        this.f22202b = i11;
        this.f22203c = i12;
        this.f22204d = str;
        if (i11 <= i12) {
            return;
        }
        p0.a.a("Reversed range is not supported");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return kotlin.jvm.internal.k.b(this.f22201a, aVar.f22201a) && this.f22202b == aVar.f22202b && this.f22203c == aVar.f22203c && kotlin.jvm.internal.k.b(this.f22204d, aVar.f22204d);
    }

    public final int hashCode() {
        Object obj = this.f22201a;
        return this.f22204d.hashCode() + hs.q.a(this.f22203c, hs.q.a(this.f22202b, (obj == null ? 0 : obj.hashCode()) * 31, 31), 31);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Range(item=");
        sb2.append(this.f22201a);
        sb2.append(", start=");
        sb2.append(this.f22202b);
        sb2.append(", end=");
        sb2.append(this.f22203c);
        sb2.append(", tag=");
        return a1.h.k(sb2, this.f22204d, ')');
    }
}
