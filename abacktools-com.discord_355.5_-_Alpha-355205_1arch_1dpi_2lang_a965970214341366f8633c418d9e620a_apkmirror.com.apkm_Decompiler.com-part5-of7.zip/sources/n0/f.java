package n0;

/* JADX INFO: loaded from: classes.dex */
public final class f extends k80.d {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f22214f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final p f22215g;

    public f(String str, p pVar) {
        this.f22214f = str;
        this.f22215g = pVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return kotlin.jvm.internal.k.b(this.f22214f, fVar.f22214f) && kotlin.jvm.internal.k.b(this.f22215g, fVar.f22215g);
    }

    public final int hashCode() {
        int iHashCode = this.f22214f.hashCode() * 31;
        p pVar = this.f22215g;
        return (iHashCode + (pVar != null ? pVar.hashCode() : 0)) * 31;
    }

    public final String toString() {
        return a1.h.k(new StringBuilder("LinkAnnotation.Clickable(tag="), this.f22214f, ')');
    }
}
