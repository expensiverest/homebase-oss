package n0;

/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f22251a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final n f22252b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final n f22253c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final n f22254d;

    public p(n nVar, n nVar2, n nVar3, n nVar4) {
        this.f22251a = nVar;
        this.f22252b = nVar2;
        this.f22253c = nVar3;
        this.f22254d = nVar4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof p)) {
            return false;
        }
        p pVar = (p) obj;
        return kotlin.jvm.internal.k.b(this.f22251a, pVar.f22251a) && kotlin.jvm.internal.k.b(this.f22252b, pVar.f22252b) && kotlin.jvm.internal.k.b(this.f22253c, pVar.f22253c) && kotlin.jvm.internal.k.b(this.f22254d, pVar.f22254d);
    }

    public final int hashCode() {
        n nVar = this.f22251a;
        int iHashCode = (nVar != null ? nVar.hashCode() : 0) * 31;
        n nVar2 = this.f22252b;
        int iHashCode2 = (iHashCode + (nVar2 != null ? nVar2.hashCode() : 0)) * 31;
        n nVar3 = this.f22253c;
        int iHashCode3 = (iHashCode2 + (nVar3 != null ? nVar3.hashCode() : 0)) * 31;
        n nVar4 = this.f22254d;
        return iHashCode3 + (nVar4 != null ? nVar4.hashCode() : 0);
    }
}
