package n0;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class c implements CharSequence {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f22205d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f22206e;

    static {
        io.sentry.internal.debugmeta.c cVar = m.f22223a;
    }

    public c(String str, List list) {
        ArrayList arrayList;
        this.f22205d = list;
        this.f22206e = str;
        if (list != null) {
            int size = list.size();
            ArrayList arrayList2 = null;
            arrayList = null;
            for (int i11 = 0; i11 < size; i11++) {
                a aVar = (a) list.get(i11);
                Object obj = aVar.f22201a;
                if (obj instanceof n) {
                    arrayList2 = arrayList2 == null ? new ArrayList() : arrayList2;
                    arrayList2.add(aVar);
                } else if (obj instanceof h) {
                    arrayList = arrayList == null ? new ArrayList() : arrayList;
                    arrayList.add(aVar);
                }
            }
        } else {
            arrayList = null;
        }
        List listN0 = arrayList != null ? m30.q.N0(arrayList, new b()) : null;
        if (listN0 == null || listN0.isEmpty()) {
            return;
        }
        int i12 = ((a) m30.q.n0(listN0)).f22203c;
        int i13 = v.g.f31720a;
        int i14 = 1;
        int[] iArrCopyOf = {i12};
        int size2 = listN0.size();
        int i15 = 1;
        while (i14 < size2) {
            a aVar2 = (a) listN0.get(i14);
            while (i15 != 0) {
                if (i15 == 0) {
                    throw new NoSuchElementException("IntList is empty.");
                }
                int i16 = i15 - 1;
                int i17 = iArrCopyOf[i16];
                int i18 = aVar2.f22202b;
                int i19 = aVar2.f22203c;
                if (i18 < i17) {
                    if (i19 <= i17) {
                        break;
                    }
                    p0.a.a("Paragraph overlap not allowed, end " + i19 + " should be less than or equal to " + i17);
                    break;
                }
                if (i16 < 0 || i16 >= i15) {
                    throw new IndexOutOfBoundsException("Index must be between 0 and size");
                }
                i15--;
            }
            int i21 = aVar2.f22203c;
            int i22 = i15 + 1;
            if (iArrCopyOf.length < i22) {
                iArrCopyOf = Arrays.copyOf(iArrCopyOf, Math.max(i22, (iArrCopyOf.length * 3) / 2));
                kotlin.jvm.internal.k.f(iArrCopyOf, "copyOf(...)");
            }
            iArrCopyOf[i15] = i21;
            i14++;
            i15 = i22;
        }
    }

    @Override // java.lang.CharSequence
    public final char charAt(int i11) {
        return this.f22206e.charAt(i11);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return kotlin.jvm.internal.k.b(this.f22206e, cVar.f22206e) && kotlin.jvm.internal.k.b(this.f22205d, cVar.f22205d);
    }

    public final int hashCode() {
        int iHashCode = this.f22206e.hashCode() * 31;
        List list = this.f22205d;
        return iHashCode + (list != null ? list.hashCode() : 0);
    }

    @Override // java.lang.CharSequence
    public final int length() {
        return this.f22206e.length();
    }

    /* JADX WARN: Code duplicated, block: B:44:0x00b3  */
    @Override // java.lang.CharSequence
    public final CharSequence subSequence(int i11, int i12) {
        ArrayList arrayList;
        if (i11 > i12) {
            p0.a.a("start (" + i11 + ") should be less or equal to end (" + i12 + ')');
        }
        String str = this.f22206e;
        if (i11 == 0 && i12 == str.length()) {
            return this;
        }
        String strSubstring = str.substring(i11, i12);
        kotlin.jvm.internal.k.f(strSubstring, "substring(...)");
        int i13 = d.f22207a;
        if (i11 > i12) {
            p0.a.a("start (" + i11 + ") should be less than or equal to end (" + i12 + ')');
        }
        List list = this.f22205d;
        if (list == null) {
            arrayList = null;
        } else {
            arrayList = new ArrayList(list.size());
            int size = list.size();
            for (int i14 = 0; i14 < size; i14++) {
                a aVar = (a) list.get(i14);
                int i15 = aVar.f22202b;
                int i16 = aVar.f22203c;
                if (((i15 < i12) & (i11 < i16)) | (((i11 == i12) | (i15 == i16)) & (i11 == i15))) {
                    arrayList.add(new a(aVar.f22201a, Math.max(i11, i15) - i11, Math.min(i12, i16) - i11, aVar.f22204d));
                }
            }
            if (arrayList.isEmpty()) {
                arrayList = null;
            }
        }
        return new c(strSubstring, arrayList);
    }

    @Override // java.lang.CharSequence
    public final String toString() {
        return this.f22206e;
    }
}
