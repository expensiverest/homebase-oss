package n0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class e {
    public static final /* synthetic */ e[] J;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final e f22208d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final e f22209e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final e f22210i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final e f22211v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final e f22212w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final e f22213x;
    public static final e y;

    static {
        e eVar = new e("Paragraph", 0);
        f22208d = eVar;
        e eVar2 = new e("Span", 1);
        f22209e = eVar2;
        e eVar3 = new e("VerbatimTts", 2);
        f22210i = eVar3;
        e eVar4 = new e("Url", 3);
        f22211v = eVar4;
        e eVar5 = new e("Link", 4);
        f22212w = eVar5;
        e eVar6 = new e("Clickable", 5);
        f22213x = eVar6;
        e eVar7 = new e("String", 6);
        y = eVar7;
        e[] eVarArr = {eVar, eVar2, eVar3, eVar4, eVar5, eVar6, eVar7};
        J = eVarArr;
        oq.a.G(eVarArr);
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) J.clone();
    }
}
