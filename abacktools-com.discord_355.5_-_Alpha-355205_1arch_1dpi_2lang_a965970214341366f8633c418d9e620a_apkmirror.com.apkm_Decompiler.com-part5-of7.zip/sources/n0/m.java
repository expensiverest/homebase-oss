package n0;

/* JADX INFO: loaded from: classes.dex */
public abstract class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22223a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22224b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22225c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22226d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22227e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22228f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22229g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22230h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22231i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22232j;
    public static final io.sentry.internal.debugmeta.c k;
    public static final io.sentry.internal.debugmeta.c l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22233m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22234n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final l f22235o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final l f22236p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final l f22237q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22238r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final io.sentry.internal.debugmeta.c f22239s;

    static {
        int i11 = 1;
        new io.sentry.internal.debugmeta.c(i11, new com.facebook.react.bridge.a(24), new kj.d(6));
        f22223a = new io.sentry.internal.debugmeta.c(i11, new i(1), new kj.d(17));
        f22224b = new io.sentry.internal.debugmeta.c(i11, new i(8), new kj.d(20));
        f22225c = new io.sentry.internal.debugmeta.c(i11, new i(9), new kj.d(21));
        f22226d = new io.sentry.internal.debugmeta.c(i11, new i(11), new kj.d(22));
        f22227e = new io.sentry.internal.debugmeta.c(i11, new com.facebook.react.bridge.a(29), new kj.d(15));
        f22228f = new io.sentry.internal.debugmeta.c(i11, new i(10), new kj.d(23));
        f22229g = new io.sentry.internal.debugmeta.c(i11, new i(12), new kj.d(24));
        f22230h = new io.sentry.internal.debugmeta.c(i11, new i(13), new kj.d(25));
        f22231i = new io.sentry.internal.debugmeta.c(i11, new i(14), new kj.d(5));
        f22232j = new io.sentry.internal.debugmeta.c(i11, new com.facebook.react.bridge.a(25), new kj.d(7));
        k = new io.sentry.internal.debugmeta.c(i11, new com.facebook.react.bridge.a(26), new kj.d(8));
        new io.sentry.internal.debugmeta.c(i11, new com.facebook.react.bridge.a(27), new kj.d(9));
        l = new io.sentry.internal.debugmeta.c(i11, new com.facebook.react.bridge.a(28), new kj.d(10));
        f22233m = new io.sentry.internal.debugmeta.c(i11, new i(0), new kj.d(11));
        f22234n = new io.sentry.internal.debugmeta.c(i11, new i(2), new kj.d(12));
        f22235o = new l(j.f22219d, k.f22220d);
        f22236p = new l(new i(3), new kj.d(13));
        f22237q = new l(new i(4), new kj.d(14));
        f22238r = new io.sentry.internal.debugmeta.c(i11, new i(5), new kj.d(16));
        f22239s = new io.sentry.internal.debugmeta.c(i11, new i(6), new kj.d(18));
        new io.sentry.internal.debugmeta.c(i11, new i(7), new kj.d(19));
    }

    public static final Object a(Object obj, a0.a aVar) {
        Object objA;
        return (obj == null || (objA = aVar.a(obj)) == null) ? Boolean.FALSE : objA;
    }
}
