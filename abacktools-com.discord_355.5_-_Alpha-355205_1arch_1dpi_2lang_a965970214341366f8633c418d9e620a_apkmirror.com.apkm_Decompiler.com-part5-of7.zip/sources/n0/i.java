package n0;

import android.content.Context;
import bc.d0;
import c70.n0;
import cg.g0;
import cg.o0;
import com.discord.MainApplication;
import com.discord.chat.presentation.message.MessageView;
import com.discord.crash_reporting.CrashReporting;
import eg.e0;
import eg.h0;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.jvm.functions.Function2;
import l30.a0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i implements Function2 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f22218d;

    public /* synthetic */ i(int i11) {
        this.f22218d = i11;
    }

    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.Object, java.util.Collection, java.util.List] */
    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        e eVar;
        Object objA;
        q30.b bVar;
        int i11 = -1;
        switch (this.f22218d) {
            case 0:
                if (obj == null) {
                    return Float.valueOf(((r0.a) obj2).f27369a);
                }
                throw new ClassCastException();
            case 1:
                if (obj != null) {
                    throw new ClassCastException();
                }
                List list = (List) obj2;
                ArrayList arrayList = new ArrayList(list.size());
                int size = list.size();
                for (int i12 = 0; i12 < size; i12++) {
                    arrayList.add(m.a((a) list.get(i12), m.f22224b));
                }
                return arrayList;
            case 2:
                if (obj != null) {
                    throw new ClassCastException();
                }
                e0.d dVar = (e0.d) obj2;
                return s1.e.d(m.a(new e0.a(dVar.f9664a), m.f22235o), m.a(new d0.a(dVar.f9665b), m.f22237q), Float.valueOf(dVar.f9666c));
            case 3:
                if (obj != null) {
                    throw new ClassCastException();
                }
                s0.d dVar2 = (s0.d) obj2;
                if (dVar2 != null ? s0.d.a(dVar2.f28653a, s0.d.f28652c) : false) {
                    return Boolean.FALSE;
                }
                return s1.e.d(Float.valueOf(Float.intBitsToFloat((int) (dVar2.f28653a & 4294967295L))), new s0.e(s0.d.f28651b[(int) ((dVar2.f28653a & 1095216660480L) >>> 32)].f28654a));
            case 4:
                if (obj != null) {
                    throw new ClassCastException();
                }
                d0.a aVar = (d0.a) obj2;
                return (aVar != null && aVar.f8736a == 9205357640488583168L) ? Boolean.FALSE : s1.e.d(Float.valueOf(Float.intBitsToFloat((int) (aVar.f8736a >> 32))), Float.valueOf(Float.intBitsToFloat((int) (aVar.f8736a & 4294967295L))));
            case 5:
                if (obj != null) {
                    throw new ClassCastException();
                }
                ?? r11 = ((q0.b) obj2).f26322d;
                ArrayList arrayList2 = new ArrayList(r11.size());
                int size2 = r11.size();
                for (int i13 = 0; i13 < size2; i13++) {
                    arrayList2.add(m.a((q0.a) r11.get(i13), m.f22239s));
                }
                return arrayList2;
            case 6:
                if (obj == null) {
                    return ((q0.a) obj2).f26320a.toLanguageTag();
                }
                throw new ClassCastException();
            case 7:
                if (obj != null) {
                    throw new ClassCastException();
                }
                throw null;
            case 8:
                if (obj != null) {
                    throw new ClassCastException();
                }
                a aVar2 = (a) obj2;
                Object obj3 = aVar2.f22201a;
                if (obj3 instanceof h) {
                    eVar = e.f22208d;
                } else if (obj3 instanceof n) {
                    eVar = e.f22209e;
                } else if (obj3 instanceof r) {
                    eVar = e.f22210i;
                } else if (obj3 instanceof q) {
                    eVar = e.f22211v;
                } else if (obj3 instanceof g) {
                    eVar = e.f22212w;
                } else if (obj3 instanceof f) {
                    eVar = e.f22213x;
                } else {
                    if (!(obj3 instanceof o)) {
                        throw new UnsupportedOperationException();
                    }
                    eVar = e.y;
                }
                switch (eVar.ordinal()) {
                    case 0:
                        objA = m.a((h) obj3, m.f22229g);
                        break;
                    case 1:
                        objA = m.a((n) obj3, m.f22230h);
                        break;
                    case 2:
                        objA = m.a((r) obj3, m.f22225c);
                        break;
                    case 3:
                        objA = m.a((q) obj3, m.f22226d);
                        break;
                    case 4:
                        objA = m.a((g) obj3, m.f22227e);
                        break;
                    case 5:
                        objA = m.a((f) obj3, m.f22228f);
                        break;
                    case 6:
                        objA = ((o) obj3).f22250a;
                        break;
                    default:
                        throw new an.g(false);
                }
                return s1.e.d(eVar, objA, Integer.valueOf(aVar2.f22202b), Integer.valueOf(aVar2.f22203c), aVar2.f22204d);
            case 9:
                if (obj == null) {
                    return ((r) obj2).f22256a;
                }
                throw new ClassCastException();
            case 10:
                if (obj != null) {
                    throw new ClassCastException();
                }
                f fVar = (f) obj2;
                return s1.e.d(fVar.f22214f, m.a(fVar.f22215g, m.f22231i));
            case 11:
                if (obj == null) {
                    return ((q) obj2).f22255a;
                }
                throw new ClassCastException();
            case 12:
                if (obj != null) {
                    throw new ClassCastException();
                }
                throw null;
            case 13:
                if (obj != null) {
                    throw new ClassCastException();
                }
                n nVar = (n) obj2;
                e0.a aVar3 = new e0.a(nVar.f22240a.a());
                l lVar = m.f22235o;
                Object objA2 = m.a(aVar3, lVar);
                s0.d dVar3 = new s0.d(nVar.f22241b);
                l lVar2 = m.f22236p;
                Object objA3 = m.a(dVar3, lVar2);
                o0.a aVar4 = nVar.f22242c;
                List list2 = o0.a.f23786e;
                Object objA4 = m.a(aVar4, m.l);
                String str = nVar.f22243d;
                Object objA5 = m.a(new s0.d(nVar.f22244e), lVar2);
                Object objA6 = m.a(nVar.f22245f, m.f22233m);
                Object objA7 = m.a(nVar.f22246g, m.k);
                q0.b bVar2 = nVar.f22247h;
                int i14 = q0.b.f26321i;
                Object objA8 = m.a(bVar2, m.f22238r);
                Object objA9 = m.a(new e0.a(nVar.f22248i), lVar);
                Object objA10 = m.a(nVar.f22249j, m.f22232j);
                e0.d dVar4 = nVar.k;
                int i15 = e0.d.f9663d;
                return s1.e.d(objA2, objA3, objA4, null, null, -1, str, objA5, objA6, objA7, objA8, objA9, objA10, m.a(dVar4, m.f22234n));
            case 14:
                if (obj != null) {
                    throw new ClassCastException();
                }
                p pVar = (p) obj2;
                n nVar2 = pVar.f22251a;
                io.sentry.internal.debugmeta.c cVar = m.f22230h;
                return s1.e.d(m.a(nVar2, cVar), m.a(pVar.f22252b, cVar), m.a(pVar.f22253c, cVar), m.a(pVar.f22254d, cVar));
            case 15:
                String message = (String) obj;
                Map data = (Map) obj2;
                int i16 = MainApplication.J;
                kotlin.jvm.internal.k.g(message, "message");
                kotlin.jvm.internal.k.g(data, "data");
                CrashReporting.b(CrashReporting.INSTANCE, message, data, "fgs_guard", 24);
                return a0.f19963a;
            case 16:
                String acc = (String) obj;
                q30.f element = (q30.f) obj2;
                kotlin.jvm.internal.k.g(acc, "acc");
                kotlin.jvm.internal.k.g(element, "element");
                if (acc.length() == 0) {
                    return element.toString();
                }
                return acc + ", " + element;
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                q30.h acc2 = (q30.h) obj;
                q30.f element2 = (q30.f) obj2;
                kotlin.jvm.internal.k.g(acc2, "acc");
                kotlin.jvm.internal.k.g(element2, "element");
                q30.h hVarX = acc2.x(element2.getKey());
                q30.i iVar = q30.i.f26481d;
                if (hVarX == iVar) {
                    return element2;
                }
                q30.d dVar5 = q30.d.f26480d;
                q30.e eVar2 = (q30.e) hVarX.Z(dVar5);
                if (eVar2 == null) {
                    bVar = new q30.b(element2, hVarX);
                } else {
                    q30.h hVarX2 = hVarX.x(dVar5);
                    if (hVarX2 == iVar) {
                        return new q30.b(eVar2, element2);
                    }
                    bVar = new q30.b(eVar2, new q30.b(element2, hVarX2));
                }
                return bVar;
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                return Integer.valueOf(Long.signum(((qo.h) obj).f27181b - ((qo.h) obj2).f27181b));
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                cg.h player = (cg.h) obj;
                kotlin.jvm.internal.k.g(player, "player");
                kotlin.jvm.internal.k.g((g0) obj2, "<unused var>");
                sc.d dVar6 = sc.d.f28937a;
                if (!sc.d.f28944h) {
                    if (player.f4977x == null) {
                        sc.d.f28950p.g(null);
                        sc.d.f28948n = null;
                        sc.d.f28941e = null;
                        sc.d.f28942f = null;
                    } else {
                        o0 o0Var = player.f4977x;
                        if (o0Var != null && o0Var.f5050h) {
                            Context context = sc.d.f28938b;
                            if (context == null) {
                                kotlin.jvm.internal.k.q("appContext");
                                throw null;
                            }
                            dVar6.c(context);
                            h0 h0Var = sc.d.f28949o;
                            e0 e0VarB0 = h0Var != null ? h0Var.b0() : null;
                            String str2 = e0VarB0 != null ? e0VarB0.f10433i : null;
                            String str3 = e0VarB0 != null ? e0VarB0.f10425a : null;
                            if (e0VarB0 != null && str2 != null && str3 != null) {
                                sc.b bVar3 = new sc.b(e0VarB0.f10432h, str2, str3, e0VarB0.f10434j);
                                if (!sc.d.e(bVar3)) {
                                    n0 n0Var = sc.d.f28950p;
                                    sc.d.j((sc.b) n0Var.getValue());
                                    n0Var.getClass();
                                    n0Var.h(null, bVar3);
                                    sc.d.f28948n = null;
                                }
                            }
                        }
                    }
                }
                return a0.f19963a;
            case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                return Long.valueOf(u00.c.a((InputStream) obj, (OutputStream) obj2));
            case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                return new l30.j(obj, obj2);
            case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                ((Float) obj2).floatValue();
                kotlin.jvm.internal.k.g((String) obj, "<unused var>");
                return a0.f19963a;
            case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                Boolean bool = (Boolean) obj;
                bool.booleanValue();
                return bool;
            case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                return ((q30.h) obj).A((q30.f) obj2);
            case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                return ((q30.h) obj).A((q30.f) obj2);
            case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                d0 d0Var = (d0) obj2;
                int i17 = MessageView.Q;
                boolean z11 = ((d0) obj).f3318c;
                if (!z11 && d0Var.f3318c) {
                    i11 = 1;
                } else if (!z11 || d0Var.f3318c) {
                    i11 = 0;
                }
                return Integer.valueOf(i11);
            default:
                kotlin.jvm.internal.k.g((String) obj, "<unused var>");
                kotlin.jvm.internal.k.g((String) obj2, "<unused var>");
                return a0.f19963a;
        }
    }
}
