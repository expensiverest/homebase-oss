package n0;

import com.google.android.gms.internal.fido.nb;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r0.h f22240a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f22241b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final o0.a f22242c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f22243d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f22244e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final r0.a f22245f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final r0.i f22246g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final q0.b f22247h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long f22248i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final r0.f f22249j;
    public final e0.d k;

    public n(long j6, long j11, o0.a aVar, String str, long j12, r0.a aVar2, r0.i iVar, q0.b bVar, long j13, r0.f fVar, e0.d dVar) {
        this.f22240a = j6 != 16 ? new r0.b(j6) : r0.g.f27373a;
        this.f22241b = j11;
        this.f22242c = aVar;
        this.f22243d = str;
        this.f22244e = j12;
        this.f22245f = aVar2;
        this.f22246g = iVar;
        this.f22247h = bVar;
        this.f22248i = j13;
        this.f22249j = fVar;
        this.k = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof n) {
            n nVar = (n) obj;
            if (this != nVar) {
                if (s0.d.a(this.f22241b, nVar.f22241b) && kotlin.jvm.internal.k.b(this.f22242c, nVar.f22242c) && kotlin.jvm.internal.k.b(this.f22243d, nVar.f22243d) && s0.d.a(this.f22244e, nVar.f22244e) && kotlin.jvm.internal.k.b(this.f22245f, nVar.f22245f) && kotlin.jvm.internal.k.b(this.f22246g, nVar.f22246g) && kotlin.jvm.internal.k.b(this.f22247h, nVar.f22247h)) {
                    long j6 = nVar.f22248i;
                    int i11 = e0.a.f9660c;
                    if (this.f22248i != j6) {
                        return false;
                    }
                    if (kotlin.jvm.internal.k.b(this.f22240a, nVar.f22240a) && kotlin.jvm.internal.k.b(this.f22249j, nVar.f22249j) && kotlin.jvm.internal.k.b(this.k, nVar.k)) {
                        return true;
                    }
                }
            } else if (kotlin.jvm.internal.k.b(this.f22240a, nVar.f22240a)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        r0.h hVar = this.f22240a;
        long jA = hVar.a();
        int i11 = e0.a.f9660c;
        int iHashCode = Long.hashCode(jA);
        hVar.getClass();
        int iHashCode2 = Float.hashCode(hVar.b());
        s0.e[] eVarArr = s0.d.f28651b;
        int iH = nb.h((iHashCode2 + (iHashCode * 961)) * 31, 31, this.f22241b);
        o0.a aVar = this.f22242c;
        int i12 = (iH + (aVar != null ? aVar.f23787d : 0)) * 923521;
        String str = this.f22243d;
        int iH2 = nb.h((i12 + (str != null ? str.hashCode() : 0)) * 31, 31, this.f22244e);
        r0.a aVar2 = this.f22245f;
        int iHashCode3 = (iH2 + (aVar2 != null ? Float.hashCode(aVar2.f27369a) : 0)) * 31;
        r0.i iVar = this.f22246g;
        int iHashCode4 = (iHashCode3 + (iVar != null ? iVar.hashCode() : 0)) * 31;
        q0.b bVar = this.f22247h;
        int iH3 = nb.h((iHashCode4 + (bVar != null ? bVar.f26322d.hashCode() : 0)) * 31, 31, this.f22248i);
        r0.f fVar = this.f22249j;
        int i13 = (iH3 + (fVar != null ? fVar.f27372a : 0)) * 31;
        e0.d dVar = this.k;
        return (i13 + (dVar != null ? dVar.hashCode() : 0)) * 961;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("SpanStyle(color=");
        r0.h hVar = this.f22240a;
        sb2.append((Object) e0.a.e(hVar.a()));
        sb2.append(", brush=null, alpha=");
        hVar.getClass();
        sb2.append(hVar.b());
        sb2.append(", fontSize=");
        sb2.append((Object) s0.d.b(this.f22241b));
        sb2.append(", fontWeight=");
        sb2.append(this.f22242c);
        sb2.append(", fontStyle=null, fontSynthesis=null, fontFamily=null, fontFeatureSettings=");
        sb2.append(this.f22243d);
        sb2.append(", letterSpacing=");
        sb2.append((Object) s0.d.b(this.f22244e));
        sb2.append(", baselineShift=");
        sb2.append(this.f22245f);
        sb2.append(", textGeometricTransform=");
        sb2.append(this.f22246g);
        sb2.append(", localeList=");
        sb2.append(this.f22247h);
        sb2.append(", background=");
        sb2.append((Object) e0.a.e(this.f22248i));
        sb2.append(", textDecoration=");
        sb2.append(this.f22249j);
        sb2.append(", shadow=");
        sb2.append(this.k);
        sb2.append(", platformStyle=null, drawStyle=null)");
        return sb2.toString();
    }
}
