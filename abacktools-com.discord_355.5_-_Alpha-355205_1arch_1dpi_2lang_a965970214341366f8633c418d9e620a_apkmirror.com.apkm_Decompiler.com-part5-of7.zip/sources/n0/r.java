package n0;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f22256a;

    public r(String str) {
        this.f22256a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof r) {
            return kotlin.jvm.internal.k.b(this.f22256a, ((r) obj).f22256a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f22256a.hashCode();
    }

    public final String toString() {
        return a1.h.k(new StringBuilder("VerbatimTtsAnnotation(verbatim="), this.f22256a, ')');
    }
}
