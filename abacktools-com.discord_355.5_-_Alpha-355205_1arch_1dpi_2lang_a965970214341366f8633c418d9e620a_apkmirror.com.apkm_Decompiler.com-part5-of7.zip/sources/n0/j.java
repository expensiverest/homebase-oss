package n0;

import kotlin.jvm.functions.Function2;

/* JADX INFO: loaded from: classes.dex */
public final class j implements Function2 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final j f22219d = new j();

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        f0.g gVarE;
        if (obj != null) {
            throw new ClassCastException();
        }
        long j6 = ((e0.a) obj2).f9661a;
        if (j6 == 16) {
            return Boolean.FALSE;
        }
        f0.p pVar = f0.d.f10954e;
        int i11 = e0.a.f9660c;
        f0.c cVar = f0.d.f10957h[(int) (63 & j6)];
        int i12 = cVar.f10949c;
        int i13 = pVar.f10949c;
        if ((i12 | i13) < 0) {
            gVarE = f0.j.e(cVar, pVar);
        } else {
            v.m mVar = f0.h.f10965a;
            int i14 = i12 | (i13 << 6);
            Object objC = mVar.c(i14);
            if (objC == null) {
                objC = f0.j.e(cVar, pVar);
                mVar.f(i14, objC);
            }
            gVarE = (f0.g) objC;
        }
        return Integer.valueOf((int) (gVarE.a(j6) >>> 32));
    }
}
