package n0;

import java.util.Comparator;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return k80.l.n(Integer.valueOf(((a) obj).f22202b), Integer.valueOf(((a) obj2).f22202b));
    }
}
