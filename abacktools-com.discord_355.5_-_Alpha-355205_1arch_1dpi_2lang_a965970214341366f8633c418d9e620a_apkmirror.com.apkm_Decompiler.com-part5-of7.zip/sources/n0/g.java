package n0;

/* JADX INFO: loaded from: classes.dex */
public final class g extends k80.d {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f22216f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final p f22217g;

    public g(String str, p pVar) {
        this.f22216f = str;
        this.f22217g = pVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return kotlin.jvm.internal.k.b(this.f22216f, gVar.f22216f) && kotlin.jvm.internal.k.b(this.f22217g, gVar.f22217g);
    }

    public final int hashCode() {
        int iHashCode = this.f22216f.hashCode() * 31;
        p pVar = this.f22217g;
        return (iHashCode + (pVar != null ? pVar.hashCode() : 0)) * 31;
    }

    public final String toString() {
        return a1.h.k(new StringBuilder("LinkAnnotation.Url(url="), this.f22216f, ')');
    }
}
