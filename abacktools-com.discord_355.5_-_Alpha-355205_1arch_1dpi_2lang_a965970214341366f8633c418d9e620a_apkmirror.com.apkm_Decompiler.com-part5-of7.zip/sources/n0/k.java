package n0;

import kotlin.jvm.functions.Function1;

/* JADX INFO: loaded from: classes.dex */
public final class k implements Function1 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final k f22220d = new k();

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        if (kotlin.jvm.internal.k.b(obj, Boolean.FALSE)) {
            return new e0.a(e0.a.f9659b);
        }
        kotlin.jvm.internal.k.e(obj, "null cannot be cast to non-null type kotlin.Int");
        return new e0.a(((long) ((Integer) obj).intValue()) << 32);
    }
}
