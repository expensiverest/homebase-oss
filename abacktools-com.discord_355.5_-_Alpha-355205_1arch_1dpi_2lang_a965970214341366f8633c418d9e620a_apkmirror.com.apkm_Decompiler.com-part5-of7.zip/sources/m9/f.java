package m9;

import com.facebook.react.bridge.WritableNativeMap;
import g8.i0;
import j70.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.jvm.internal.k;
import l30.i;
import l30.j;
import l9.y;
import m30.l;
import n70.t0;

/* JADX INFO: loaded from: classes.dex */
@h
public final class f implements ui.a {
    public static final e Companion = new e();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Lazy[] f21277b = {a.a.J(i.f19979e, new hh.c(16))};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final List f21278a;

    public /* synthetic */ f(int i11, List list) {
        if (1 == (i11 & 1)) {
            this.f21278a = list;
        } else {
            t0.j(i11, 1, d.f21276a.d());
            throw null;
        }
    }

    @Override // ui.a
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final WritableNativeMap a() {
        List list = this.f21278a;
        ArrayList arrayList = new ArrayList(l.W(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(((y) it.next()).a());
        }
        return gi.f.h(new j("metrics", i0.D(arrayList)));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof f) && k.b(this.f21278a, ((f) obj).f21278a);
    }

    public final int hashCode() {
        return this.f21278a.hashCode();
    }

    public final String toString() {
        return "OtaCheckAttemptEvent(metrics=" + this.f21278a + ")";
    }

    public f(List metrics) {
        k.g(metrics, "metrics");
        this.f21278a = metrics;
    }
}
