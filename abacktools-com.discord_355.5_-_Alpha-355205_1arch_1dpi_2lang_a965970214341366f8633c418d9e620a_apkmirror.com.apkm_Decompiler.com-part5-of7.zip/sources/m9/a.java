package m9;

import j70.k;
import l70.g;
import n70.v0;
import n70.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f21274a;
    private static final g descriptor;

    static {
        a aVar = new a();
        f21274a = aVar;
        v0 v0Var = new v0("com.discord.bundle_updater.react.events.BundleDownloadedEvent", aVar, 1);
        v0Var.b("versionRequired", false);
        descriptor = v0Var;
    }

    @Override // j70.b
    public final Object a(m70.c cVar) {
        boolean zV;
        g gVar = descriptor;
        m70.a aVarB = cVar.b(gVar);
        int i11 = 1;
        if (aVarB.z()) {
            zV = aVarB.v(gVar, 0);
        } else {
            boolean z11 = true;
            zV = false;
            int i12 = 0;
            while (z11) {
                int iM = aVarB.m(gVar);
                if (iM == -1) {
                    z11 = false;
                } else {
                    if (iM != 0) {
                        throw new k(iM);
                    }
                    zV = aVarB.v(gVar, 0);
                    i12 = 1;
                }
            }
            i11 = i12;
        }
        aVarB.c(gVar);
        return new c(i11, zV);
    }

    @Override // n70.z
    public final j70.b[] b() {
        return new j70.b[]{n70.g.f22696a};
    }

    @Override // j70.j
    public final void c(m70.d dVar, Object obj) {
        c value = (c) obj;
        kotlin.jvm.internal.k.g(value, "value");
        g gVar = descriptor;
        m70.b bVarB = dVar.b(gVar);
        bVarB.F(gVar, 0, value.f21275a);
        bVarB.c(gVar);
    }

    @Override // j70.j
    public final g d() {
        return descriptor;
    }
}
