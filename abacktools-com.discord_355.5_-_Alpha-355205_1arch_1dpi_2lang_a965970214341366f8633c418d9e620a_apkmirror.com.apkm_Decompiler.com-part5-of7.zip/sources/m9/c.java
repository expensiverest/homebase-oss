package m9;

import com.facebook.react.bridge.WritableMap;
import j70.h;
import n70.t0;

/* JADX INFO: loaded from: classes.dex */
@h
public final class c implements ui.a {
    public static final b Companion = new b();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f21275a;

    public /* synthetic */ c(int i11, boolean z11) {
        if (1 == (i11 & 1)) {
            this.f21275a = z11;
        } else {
            t0.j(i11, 1, a.f21274a.d());
            throw null;
        }
    }

    @Override // ui.a
    public final /* bridge */ WritableMap a() {
        return s1.e.J(this);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof c) && this.f21275a == ((c) obj).f21275a;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f21275a);
    }

    public final String toString() {
        return "BundleDownloadedEvent(versionRequired=" + this.f21275a + ")";
    }

    public c(boolean z11) {
        this.f21275a = z11;
    }
}
