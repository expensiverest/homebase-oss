package m9;

import j70.j;
import j70.k;
import java.util.List;
import kotlin.Lazy;
import l70.g;
import n70.v0;
import n70.z;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f21276a;
    private static final g descriptor;

    static {
        d dVar = new d();
        f21276a = dVar;
        v0 v0Var = new v0("com.discord.bundle_updater.react.events.OtaCheckAttemptEvent", dVar, 1);
        v0Var.b("metrics", false);
        descriptor = v0Var;
    }

    @Override // j70.b
    public final Object a(m70.c cVar) {
        List list;
        g gVar = descriptor;
        m70.a aVarB = cVar.b(gVar);
        Lazy[] lazyArr = f.f21277b;
        int i11 = 1;
        List list2 = null;
        if (aVarB.z()) {
            list = (List) aVarB.f(gVar, 0, (j70.b) lazyArr[0].getValue(), null);
        } else {
            boolean z11 = true;
            int i12 = 0;
            while (z11) {
                int iM = aVarB.m(gVar);
                if (iM == -1) {
                    z11 = false;
                } else {
                    if (iM != 0) {
                        throw new k(iM);
                    }
                    list2 = (List) aVarB.f(gVar, 0, (j70.b) lazyArr[0].getValue(), list2);
                    i12 = 1;
                }
            }
            list = list2;
            i11 = i12;
        }
        aVarB.c(gVar);
        return new f(i11, list);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // n70.z
    public final j70.b[] b() {
        return new j70.b[]{f.f21277b[0].getValue()};
    }

    @Override // j70.j
    public final void c(m70.d dVar, Object obj) {
        f value = (f) obj;
        kotlin.jvm.internal.k.g(value, "value");
        g gVar = descriptor;
        m70.b bVarB = dVar.b(gVar);
        bVarB.s(gVar, 0, (j) f.f21277b[0].getValue(), value.f21278a);
        bVarB.c(gVar);
    }

    @Override // j70.j
    public final g d() {
        return descriptor;
    }
}
