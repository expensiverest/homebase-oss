package mn;

import al.c;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.FrameLayout;
import androidx.core.view.g0;
import androidx.core.view.i1;
import androidx.core.view.r2;
import androidx.core.view.s2;
import androidx.core.view.u2;
import androidx.core.view.v2;
import androidx.core.view.w2;
import b80.g;
import b80.i0;
import b80.n0;
import b80.y;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imageutils.JfifUtil;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.UiThreadUtil;
import com.facebook.react.uimanager.b0;
import com.horcrux.svg.h0;
import com.horcrux.svg.k0;
import eq.u;
import eq.v;
import i8.t;
import io.sentry.a5;
import io.sentry.a6;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import io.sentry.b3;
import io.sentry.util.h;
import j70.b;
import j8.d;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import k60.z0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import l70.i;
import l9.z;
import ln.e;
import m30.e0;
import m30.l;
import m30.r;
import m30.s;
import m30.w;
import n30.f;
import n70.s0;
import p.x2;
import q40.m0;
import q40.q0;
import q40.x;
import t10.a0;
import t10.o;
import t10.p;
import t10.q;
import t40.r0;

/* JADX INFO: loaded from: classes.dex */
public abstract class a implements i1 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static c f21345b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static float f21346c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static int f21347d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static int f21348e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static String f21349f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Path f21350g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static ArrayList f21351h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static float f21352i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static float f21353j;
    public static float k;
    public static float l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static float f21354m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static float f21355n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static boolean f21356o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static boolean f21357p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static boolean f21358q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static boolean f21359r;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f21360a;

    public /* synthetic */ a(int i11) {
        this.f21360a = i11;
    }

    public static final b A(b bVar) {
        k.g(bVar, "<this>");
        return bVar.d().l() ? bVar : new s0(bVar);
    }

    public static void B(a6 a6Var) {
        if (a6Var.getProfilingTracesDirPath() != null) {
            return;
        }
        File file = new File(System.getProperty("java.io.tmpdir"), "sentry_profiling_traces");
        if (file.mkdirs() || file.exists()) {
            a6Var.setProfilingTracesDirPath(file.getAbsolutePath());
        } else {
            throw new IllegalArgumentException("Creating a fallback directory for profiling failed in " + file.getAbsolutePath());
        }
    }

    public static pj.a C(Intent intent) {
        k.g(intent, "<this>");
        if (!intent.hasExtra("discord_shortcut")) {
            return null;
        }
        String stringExtra = intent.getStringExtra("discord_shortcut_tag");
        if (stringExtra == null) {
            stringExtra = "";
        }
        f fVar = new f();
        String[] stringArrayExtra = intent.getStringArrayExtra("discord_shortcut_data");
        if (stringArrayExtra != null) {
            Iterator iterator = m30.k.R(stringArrayExtra).iterator();
            k.g(iterator, "iterator");
            Iterator itO0 = !iterator.hasNext() ? r.f20878d : com.facebook.imagepipeline.nativecode.c.o0(new e0(iterator, null));
            while (itO0.hasNext()) {
                List list = (List) itO0.next();
                String str = (String) list.get(0);
                String str2 = (String) list.get(1);
                k.d(str);
                k.d(str2);
                fVar.put(str, str2);
            }
        }
        return new pj.a(stringExtra, fVar.b());
    }

    public static byte[] D(InputStream inputStream, int i11, j8.a aVar) throws Throwable {
        byte[] bArrA;
        d dVar = new d(aVar, i11);
        try {
            bArrA = aVar.a(1024);
            while (true) {
                try {
                    int i12 = inputStream.read(bArrA);
                    if (i12 == -1) {
                        break;
                    }
                    dVar.write(bArrA, 0, i12);
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        inputStream.close();
                    } catch (IOException unused) {
                        t.d("Error occurred when closing InputStream", new Object[0]);
                    }
                    aVar.b(bArrA);
                    dVar.close();
                    throw th;
                }
            }
            byte[] byteArray = dVar.toByteArray();
            try {
                inputStream.close();
            } catch (IOException unused2) {
                t.d("Error occurred when closing InputStream", new Object[0]);
            }
            aVar.b(bArrA);
            dVar.close();
            return byteArray;
        } catch (Throwable th3) {
            th = th3;
            bArrA = null;
        }
    }

    public static z E() {
        z zVar = z.f20345q;
        if (zVar != null) {
            return zVar;
        }
        k.q("updater");
        throw null;
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0033  */
    /* JADX WARN: Code duplicated, block: B:26:0x003d  */
    public static boolean F(n0 n0Var, i0 request) {
        String strA;
        k.g(request, "request");
        int i11 = n0Var.f3204v;
        if (i11 != 200 && i11 != 410 && i11 != 414 && i11 != 501 && i11 != 203 && i11 != 204) {
            if (i11 == 307) {
                strA = n0Var.f3206x.a("Expires");
                if (strA == null) {
                    strA = null;
                }
                if (strA == null && n0Var.c().f3128c == -1 && !n0Var.c().f3131f && !n0Var.c().f3130e) {
                    return false;
                }
            } else if (i11 != 308 && i11 != 404 && i11 != 405) {
                switch (i11) {
                    case 300:
                    case 301:
                        break;
                    case 302:
                        strA = n0Var.f3206x.a("Expires");
                        if (strA == null) {
                            strA = null;
                        }
                        if (strA == null) {
                            return false;
                        }
                        break;
                    default:
                        return false;
                }
            }
        }
        if (n0Var.c().f3127b) {
            return false;
        }
        g gVarG = (g) request.y;
        if (gVarG == null) {
            int i12 = g.f3125n;
            gVarG = z80.a.G((y) request.f3158v);
            request.y = gVarG;
        }
        return !gVarG.f3127b;
    }

    public static boolean G(int i11) {
        if (i11 == 0) {
            return false;
        }
        ThreadLocal threadLocal = i1.a.f14975a;
        double[] dArr = (double[]) threadLocal.get();
        if (dArr == null) {
            dArr = new double[3];
            threadLocal.set(dArr);
        }
        int iRed = Color.red(i11);
        int iGreen = Color.green(i11);
        int iBlue = Color.blue(i11);
        if (dArr.length != 3) {
            throw new IllegalArgumentException("outXyz must have a length of 3.");
        }
        double d11 = ((double) iRed) / 255.0d;
        double dPow = d11 < 0.04045d ? d11 / 12.92d : Math.pow((d11 + 0.055d) / 1.055d, 2.4d);
        double d12 = ((double) iGreen) / 255.0d;
        double dPow2 = d12 < 0.04045d ? d12 / 12.92d : Math.pow((d12 + 0.055d) / 1.055d, 2.4d);
        double d13 = ((double) iBlue) / 255.0d;
        double dPow3 = d13 < 0.04045d ? d13 / 12.92d : Math.pow((d13 + 0.055d) / 1.055d, 2.4d);
        dArr[0] = ((0.1805d * dPow3) + (0.3576d * dPow2) + (0.4124d * dPow)) * 100.0d;
        double d14 = ((0.0722d * dPow3) + (0.7152d * dPow2) + (0.2126d * dPow)) * 100.0d;
        dArr[1] = d14;
        dArr[2] = ((dPow3 * 0.9505d) + (dPow2 * 0.1192d) + (dPow * 0.0193d)) * 100.0d;
        return d14 / 100.0d > 0.5d;
    }

    public static final void H() {
        if (f21345b == null) {
            synchronized (a.class) {
                f21345b = new c(15);
            }
        }
    }

    public static int I(float f3, int i11, int i12) {
        return i1.a.c(i1.a.e(i12, Math.round(Color.alpha(i12) * f3)), i11);
    }

    public static void J(float f3, float f11) {
        X();
        f21352i = f3;
        k = f3;
        f21353j = f11;
        l = f11;
        Path path = f21350g;
        float f12 = f21346c;
        path.lineTo(f3 * f12, f12 * f11);
        f21351h.add(new h0(4, new k0[]{new k0(f3, f11)}));
    }

    public static void K(float f3, float f11) {
        f21352i = f3;
        k = f3;
        f21354m = f3;
        f21353j = f11;
        l = f11;
        f21355n = f11;
        Path path = f21350g;
        float f12 = f21346c;
        path.moveTo(f3 * f12, f12 * f11);
        f21351h.add(new h0(3, new k0[]{new k0(f3, f11)}));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void L(ViewGroup viewGroup, MotionEvent motionEvent) {
        com.facebook.react.uimanager.h0 h0Var;
        View view = viewGroup;
        while (true) {
            if (view instanceof com.facebook.react.uimanager.h0) {
                h0Var = (com.facebook.react.uimanager.h0) view;
                break;
            }
            Object parent = view.getParent();
            if (parent == null) {
                h0Var = null;
                break;
            } else {
                sg.a.b(parent instanceof View);
                view = (View) parent;
            }
        }
        if (h0Var != null) {
            h0Var.e(viewGroup, motionEvent);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void M(ViewGroup viewGroup, MotionEvent event) {
        com.facebook.react.uimanager.h0 h0Var;
        k.g(event, "event");
        View view = viewGroup;
        while (true) {
            if (view instanceof com.facebook.react.uimanager.h0) {
                h0Var = (com.facebook.react.uimanager.h0) view;
                break;
            }
            Object parent = view.getParent();
            if (parent == null) {
                h0Var = null;
                break;
            } else {
                sg.a.b(parent instanceof View);
                view = (View) parent;
            }
        }
        if (h0Var != null) {
            h0Var.c(viewGroup, event);
        }
    }

    public static boolean N() {
        c0();
        char cCharAt = f21349f.charAt(f21347d);
        if (cCharAt != '0' && cCharAt != '1') {
            throw new Error(String.format("Unexpected flag '%c' (i=%d, s=%s)", Character.valueOf(cCharAt), Integer.valueOf(f21347d), f21349f));
        }
        int i11 = f21347d + 1;
        f21347d = i11;
        if (i11 < f21348e && f21349f.charAt(i11) == ',') {
            f21347d++;
        }
        c0();
        return cCharAt == '1';
    }

    public static float O() {
        int i11;
        char cCharAt;
        if (f21347d == f21348e) {
            throw new Error(x2.u("Unexpected end (s=", f21349f, ")"));
        }
        c0();
        int i12 = f21347d;
        if (i12 == f21348e) {
            throw new Error(x2.u("Unexpected end (s=", f21349f, ")"));
        }
        char cCharAt2 = f21349f.charAt(i12);
        if (cCharAt2 == '-' || cCharAt2 == '+') {
            int i13 = f21347d + 1;
            f21347d = i13;
            cCharAt2 = f21349f.charAt(i13);
        }
        if (cCharAt2 >= '0' && cCharAt2 <= '9') {
            b0();
            int i14 = f21347d;
            if (i14 < f21348e) {
                cCharAt2 = f21349f.charAt(i14);
            }
        } else if (cCharAt2 != '.') {
            throw new IllegalArgumentException(String.format("Invalid number formating character '%c' (i=%d, s=%s)", Character.valueOf(cCharAt2), Integer.valueOf(f21347d), f21349f));
        }
        if (cCharAt2 == '.') {
            f21347d++;
            b0();
            int i15 = f21347d;
            if (i15 < f21348e) {
                cCharAt2 = f21349f.charAt(i15);
            }
        }
        if ((cCharAt2 == 'e' || cCharAt2 == 'E') && (i11 = f21347d + 1) < f21348e && (cCharAt = f21349f.charAt(i11)) != 'm' && cCharAt != 'x') {
            int i16 = f21347d + 1;
            f21347d = i16;
            char cCharAt3 = f21349f.charAt(i16);
            if (cCharAt3 == '+' || cCharAt3 == '-') {
                f21347d++;
                b0();
            } else {
                if (cCharAt3 < '0' || cCharAt3 > '9') {
                    throw new IllegalArgumentException(String.format("Invalid number formating character '%c' (i=%d, s=%s)", Character.valueOf(cCharAt3), Integer.valueOf(f21347d), f21349f));
                }
                b0();
            }
        }
        String strSubstring = f21349f.substring(i12, f21347d);
        float f3 = Float.parseFloat(strSubstring);
        if (Float.isInfinite(f3) || Float.isNaN(f3)) {
            throw new IllegalArgumentException(String.format("Invalid number '%s' (start=%d, i=%d, s=%s)", strSubstring, Integer.valueOf(i12), Integer.valueOf(f21347d), f21349f));
        }
        c0();
        int i17 = f21347d;
        if (i17 < f21348e && f21349f.charAt(i17) == ',') {
            f21347d++;
        }
        return f3;
    }

    public static void P(float f3, float f11, float f12, float f13) {
        k = f3;
        l = f11;
        float f14 = f3 * 2.0f;
        float f15 = f11 * 2.0f;
        t((f21352i + f14) / 3.0f, (f21353j + f15) / 3.0f, (f12 + f14) / 3.0f, (f13 + f15) / 3.0f, f12, f13);
    }

    public static void Q(eq.t tVar, FrameLayout frameLayout, int i11, ReadableArray readableArray) {
        if (frameLayout == null) {
            throw new IllegalStateException("Required value was null.");
        }
        if (i11 == 1) {
            if (readableArray == null) {
                throw new IllegalStateException("Required value was null.");
            }
            T(tVar, frameLayout, readableArray);
        } else if (i11 == 2) {
            if (readableArray == null) {
                throw new IllegalStateException("Required value was null.");
            }
            tVar.scrollToEnd(frameLayout, new v(readableArray.getBoolean(0)));
        } else {
            if (i11 == 3) {
                tVar.flashScrollIndicators(frameLayout);
                return;
            }
            throw new IllegalArgumentException("Unsupported command " + i11 + " received by " + tVar.getClass().getSimpleName() + ".");
        }
    }

    public static void R(eq.t tVar, FrameLayout frameLayout, String str, ReadableArray readableArray) {
        if (frameLayout == null) {
            throw new IllegalStateException("Required value was null.");
        }
        int iHashCode = str.hashCode();
        if (iHashCode != -402165208) {
            if (iHashCode != 28425985) {
                if (iHashCode == 2055114131 && str.equals("scrollToEnd")) {
                    if (readableArray == null) {
                        throw new IllegalStateException("Required value was null.");
                    }
                    tVar.scrollToEnd(frameLayout, new v(readableArray.getBoolean(0)));
                    return;
                }
            } else if (str.equals("flashScrollIndicators")) {
                tVar.flashScrollIndicators(frameLayout);
                return;
            }
        } else if (str.equals("scrollTo")) {
            if (readableArray == null) {
                throw new IllegalStateException("Required value was null.");
            }
            T(tVar, frameLayout, readableArray);
            return;
        }
        throw new IllegalArgumentException(x2.i("Unsupported command ", str, " received by ", tVar.getClass().getSimpleName(), "."));
    }

    public static final void S(Object[] objArr, int i11, int i12) {
        k.g(objArr, "<this>");
        while (i11 < i12) {
            objArr[i11] = null;
            i11++;
        }
    }

    public static void T(eq.t tVar, Object obj, ReadableArray readableArray) {
        tVar.scrollTo(obj, new u(Math.round(b0.w0((float) readableArray.getDouble(0))), Math.round(b0.w0((float) readableArray.getDouble(1))), readableArray.getBoolean(2)));
    }

    public static void U(p pVar, Activity activity) {
        Boolean bool;
        if (activity == null) {
            return;
        }
        p pVarV = v(pVar, o.f29589i);
        boolean zBooleanValue = (pVarV == null || (bool = pVarV.f29602k0) == null) ? false : bool.booleanValue();
        Window window = activity.getWindow();
        UiThreadUtil.runOnUiThread(new com.swmansion.reanimated.keyboard.b(zBooleanValue, new w2(window.getDecorView(), window), 7));
    }

    public static final void V(SimpleDraweeView simpleDraweeView, String str) {
        k.g(simpleDraweeView, "<this>");
        if (!ch.a.f5087e) {
            simpleDraweeView.setImageURI(str);
            return;
        }
        if (str == null || w60.o.y0(str)) {
            simpleDraweeView.setImageURI((String) null);
            return;
        }
        Uri uri = nl.a.f23245a;
        Uri uri2 = Uri.parse(str);
        if (uri2 == null) {
            simpleDraweeView.setImageURI(str);
            return;
        }
        e eVarD = e.d(uri2);
        k80.d.c(eVarD, uri2);
        eVarD.f20563d = null;
        eVarD.k = null;
        ln.d dVarA = eVarD.a();
        xl.e controllerBuilder = simpleDraweeView.getControllerBuilder();
        controllerBuilder.f35331d = dVarA;
        controllerBuilder.f35336i = simpleDraweeView.getController();
        simpleDraweeView.setController(controllerBuilder.build());
    }

    public static void W(p pVar, Activity activity) {
        s1.e s2Var;
        s1.e s2Var2;
        Boolean bool;
        if (activity == null) {
            return;
        }
        Window window = activity.getWindow();
        p pVarV = v(pVar, o.f29590v);
        if (!((pVarV == null || (bool = pVarV.f29603l0) == null) ? false : bool.booleanValue())) {
            g0 g0Var = new g0(window.getDecorView());
            int i11 = Build.VERSION.SDK_INT;
            if (i11 >= 35) {
                s2Var = new v2(window, g0Var);
            } else if (i11 >= 30) {
                s2Var = new u2(window, g0Var);
            } else {
                s2Var = i11 >= 26 ? new s2(window, g0Var) : new r2(window, g0Var);
            }
            s2Var.O(2);
            return;
        }
        g0 g0Var2 = new g0(window.getDecorView());
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 35) {
            s2Var2 = new v2(window, g0Var2);
        } else if (i12 >= 30) {
            s2Var2 = new u2(window, g0Var2);
        } else {
            s2Var2 = i12 >= 26 ? new s2(window, g0Var2) : new r2(window, g0Var2);
        }
        s2Var2.q(2);
        s2Var2.N();
    }

    public static void X() {
        if (f21356o) {
            return;
        }
        f21354m = f21352i;
        f21355n = f21353j;
        f21356o = true;
    }

    public static void Y(p pVar, Activity activity, ReactContext reactContext) {
        String statusBarStyle;
        if (activity == null || reactContext == null) {
            return;
        }
        p pVarV = v(pVar, o.f29588e);
        if (pVarV == null || (statusBarStyle = pVarV.getStatusBarStyle()) == null) {
            statusBarStyle = "light";
        }
        UiThreadUtil.runOnUiThread(new fp.a(activity, statusBarStyle, 1));
    }

    public static boolean Z(a6 a6Var, a6 a6Var2, boolean z11) {
        boolean z12 = h.f17234a;
        if (!z12 && (a6Var2.getVersionDetector() instanceof b3)) {
            a6Var2.setVersionDetector(new g0(21, a6Var2));
        }
        if (!a6Var2.getVersionDetector().e()) {
            return !z11 || a6Var == null || a6Var2.isForceInit() || a6Var.getInitPriority().ordinal() <= a6Var2.getInitPriority().ordinal();
        }
        a6Var2.getLogger().m(a5.ERROR, "Not initializing Sentry because mixed SDK versions have been detected.", new Object[0]);
        throw new IllegalStateException(x2.u("Sentry SDK has detected a mix of versions. This is not supported and likely leads to crashes. Please always use the same version of all SDK modules (dependencies). See ", z12 ? "https://docs.sentry.io/platforms/android/troubleshooting/mixed-versions" : "https://docs.sentry.io/platforms/java/troubleshooting/mixed-versions", " for more details."));
    }

    public static final b50.c a0(Collection collection, b50.d dVar) {
        Iterator it = collection.iterator();
        b50.c cVar = null;
        while (it.hasNext()) {
            b50.c cVar2 = (b50.c) it.next();
            if (k.b(cVar2.getType(), dVar)) {
                if (cVar != null) {
                    throw new IllegalStateException("Multiple extensions handle the same extension type: " + dVar);
                }
                cVar = cVar2;
            }
        }
        if (cVar != null) {
            return cVar;
        }
        throw new IllegalStateException("No extensions handle the extension type: " + dVar);
    }

    public static void b0() {
        while (true) {
            int i11 = f21347d;
            if (i11 >= f21348e || !Character.isDigit(f21349f.charAt(i11))) {
                return;
            } else {
                f21347d++;
            }
        }
    }

    public static void c0() {
        while (true) {
            int i11 = f21347d;
            if (i11 >= f21348e || !Character.isWhitespace(f21349f.charAt(i11))) {
                return;
            } else {
                f21347d++;
            }
        }
    }

    public static final n70.d d(b elementSerializer) {
        k.g(elementSerializer, "elementSerializer");
        return new n70.d(elementSerializer, 0);
    }

    public static void d0(p pVar, Activity activity, ReactContext reactContext) {
        Integer screenOrientation;
        if (f21357p && activity != null) {
            p pVarV = v(pVar, o.f29587d);
            activity.setRequestedOrientation((pVarV == null || (screenOrientation = pVarV.getScreenOrientation()) == null) ? -1 : screenOrientation.intValue());
        }
        if (f21358q) {
            Y(pVar, activity, reactContext);
            U(pVar, activity);
        }
        if (f21359r) {
            W(pVar, activity);
        }
    }

    public static final n70.h0 e(b keySerializer, b valueSerializer) {
        k.g(keySerializer, "keySerializer");
        k.g(valueSerializer, "valueSerializer");
        return new n70.h0(keySerializer, valueSerializer);
    }

    public static final Object e0(i20.d dVar) {
        k.g(dVar, "<this>");
        if (dVar.equals(i20.b.f15015a)) {
            return null;
        }
        if (dVar instanceof i20.c) {
            return ((i20.c) dVar).f15016a;
        }
        throw new an.g(false);
    }

    public static String f(File file) {
        if (!file.getName().endsWith(".apk")) {
            throw new IllegalArgumentException("Non-apk found in splits directory.");
        }
        String strReplaceFirst = file.getName().replaceFirst("(_\\d+)?\\.apk", "");
        if (strReplaceFirst.equals("base-master") || strReplaceFirst.equals("base-main")) {
            return "";
        }
        return strReplaceFirst.startsWith("base-") ? strReplaceFirst.replace("base-", "config.") : strReplaceFirst.replace("-", ".config.").replace(".config.master", "").replace(".config.main", "");
    }

    public static final ArrayList g(ArrayList arrayList) {
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            fx.r rVar = (fx.r) it.next();
            Bundle bundle = new Bundle();
            bundle.putInt("event_type", rVar.f12550a);
            bundle.putLong("event_timestamp", rVar.f12551b);
            arrayList2.add(bundle);
        }
        return arrayList2;
    }

    public static final String h(Object[] objArr, int i11, int i12, m30.f fVar) {
        StringBuilder sb2 = new StringBuilder((i12 * 3) + 2);
        sb2.append("[");
        for (int i13 = 0; i13 < i12; i13++) {
            if (i13 > 0) {
                sb2.append(", ");
            }
            Object obj = objArr[i11 + i13];
            if (obj == fVar) {
                sb2.append("(this Collection)");
            } else {
                sb2.append(obj);
            }
        }
        sb2.append("]");
        String string = sb2.toString();
        k.f(string, "toString(...)");
        return string;
    }

    public static void i(SpannableStringBuilder spannableStringBuilder, Object obj, int i11, int i12) {
        for (Object obj2 : spannableStringBuilder.getSpans(i11, i12, obj.getClass())) {
            if (spannableStringBuilder.getSpanStart(obj2) == i11 && spannableStringBuilder.getSpanEnd(obj2) == i12 && spannableStringBuilder.getSpanFlags(obj2) == 33) {
                spannableStringBuilder.removeSpan(obj2);
            }
        }
        spannableStringBuilder.setSpan(obj, i11, i12, 33);
    }

    public static final void j(View view, int i11, int i12, Function1 function1) {
        ValueAnimator valueAnimatorOfArgb = ValueAnimator.ofArgb(i11, i12);
        valueAnimatorOfArgb.addUpdateListener(new d20.a(view, 2));
        valueAnimatorOfArgb.addListener(new ub.o(function1, 0));
        valueAnimatorOfArgb.setStartDelay(300 + ((long) 100));
        valueAnimatorOfArgb.setDuration(600L);
        valueAnimatorOfArgb.start();
    }

    /* JADX WARN: Code duplicated, block: B:57:0x01d0 A[LOOP:0: B:56:0x01ce->B:57:0x01d0, LOOP_END] */
    public static void k(float f3, float f11, float f12, boolean z11, boolean z12, float f13, float f14) {
        float f15;
        float f16;
        float f17;
        double d11;
        int iCeil;
        float f18;
        float fTan;
        float fCos;
        float fSin;
        int i11;
        float f19 = f21352i;
        float f21 = f21353j;
        if (f11 == 0.0f) {
            f15 = f3 == 0.0f ? f14 - f21 : f3;
        } else {
            f15 = f11;
        }
        float fAbs = Math.abs(f15);
        float fAbs2 = Math.abs(f3 == 0.0f ? f13 - f19 : f3);
        if (fAbs2 == 0.0f || fAbs == 0.0f || (f13 == f19 && f14 == f21)) {
            J(f13, f14);
            return;
        }
        float radians = (float) Math.toRadians(f12);
        double d12 = radians;
        float fCos2 = (float) Math.cos(d12);
        float fSin2 = (float) Math.sin(d12);
        float f22 = f13 - f19;
        float f23 = f14 - f21;
        float f24 = ((fSin2 * f23) / 2.0f) + ((fCos2 * f22) / 2.0f);
        float f25 = -fSin2;
        float f26 = ((fCos2 * f23) / 2.0f) + ((f25 * f22) / 2.0f);
        float f27 = fAbs2 * fAbs2;
        float f28 = f27 * fAbs * fAbs;
        float f29 = fAbs * fAbs * f24 * f24;
        float f31 = f27 * f26 * f26;
        float f32 = (f28 - f31) - f29;
        if (f32 < 0.0f) {
            float fSqrt = (float) Math.sqrt(1.0f - (f32 / f28));
            fAbs2 *= fSqrt;
            fAbs *= fSqrt;
            f17 = f22 / 2.0f;
            f16 = f23 / 2.0f;
        } else {
            float fSqrt2 = (float) Math.sqrt(f32 / (f31 + f29));
            if (z11 == z12) {
                fSqrt2 = -fSqrt2;
            }
            float f33 = (((-fSqrt2) * f26) * fAbs2) / fAbs;
            float f34 = ((fSqrt2 * f24) * fAbs) / fAbs2;
            float f35 = (fCos2 * f33) - (fSin2 * f34);
            f16 = (f23 / 2.0f) + (f34 * fCos2) + (f33 * fSin2);
            f17 = (f22 / 2.0f) + f35;
        }
        float f36 = fCos2 / fAbs2;
        float f37 = fSin2 / fAbs2;
        float f38 = f25 / fAbs;
        float f39 = fCos2 / fAbs;
        float f41 = -f17;
        float f42 = -f16;
        float f43 = f17;
        float f44 = f16;
        float fAtan2 = (float) Math.atan2((f39 * f42) + (f38 * f41), (f37 * f42) + (f41 * f36));
        float f45 = f22 - f43;
        float f46 = f23 - f44;
        float fAtan3 = (float) Math.atan2((f39 * f46) + (f38 * f45), (f37 * f46) + (f36 * f45));
        float f47 = f43 + f19;
        float f48 = f44 + f21;
        float f49 = f22 + f19;
        float f51 = f23 + f21;
        X();
        k = f49;
        f21352i = f49;
        l = f51;
        f21353j = f51;
        if (fAbs2 == fAbs && radians == 0) {
            float degrees = (float) Math.toDegrees(fAtan2);
            float fAbs3 = Math.abs((degrees - ((float) Math.toDegrees(fAtan3))) % 360.0f);
            if (!z11 ? fAbs3 > 180.0f : fAbs3 < 180.0f) {
                fAbs3 = 360.0f - fAbs3;
            }
            if (!z12) {
                fAbs3 = -fAbs3;
            }
            float f52 = f21346c;
            f21350g.arcTo(new RectF((f47 - fAbs2) * f52, (f48 - fAbs2) * f52, (f47 + fAbs2) * f52, (f48 + fAbs2) * f52), degrees, fAbs3);
            f21351h.add(new h0(1, new k0[]{new k0(f49, f51)}));
            return;
        }
        float fCos3 = (float) Math.cos(d12);
        float fSin3 = (float) Math.sin(d12);
        float f53 = fCos3 * fAbs2;
        float f54 = (-fSin3) * fAbs;
        float f55 = fSin3 * fAbs2;
        float f56 = fCos3 * fAbs;
        float f57 = fAtan3 - fAtan2;
        if (f57 >= 0 || !z12) {
            if (f57 > 0 && !z12) {
                d11 = ((double) f57) - 6.283185307179586d;
            }
            double dPow = Math.pow(10.0d, 4.0d);
            iCeil = (int) Math.ceil(Math.abs(Math.round((((double) f57) / 1.5707963267948966d) * dPow) / dPow));
            f18 = f57 / iCeil;
            fTan = (float) (Math.tan(f18 / 4.0f) * 1.3333333333333333d);
            double d13 = fAtan2;
            fCos = (float) Math.cos(d13);
            fSin = (float) Math.sin(d13);
            i11 = 0;
            while (i11 < iCeil) {
                float f58 = fCos - (fTan * fSin);
                float f59 = (fCos * fTan) + fSin;
                float f61 = fAtan2 + f18;
                double d14 = f61;
                float f62 = f18;
                float fCos4 = (float) Math.cos(d14);
                fSin = (float) Math.sin(d14);
                float f63 = (fTan * fSin) + fCos4;
                float f64 = fSin - (fTan * fCos4);
                float f65 = (f54 * f59) + (f53 * f58) + f47;
                float f66 = (f59 * f56) + (f58 * f55) + f48;
                float f67 = (f54 * f64) + (f53 * f63) + f47;
                float f68 = (f64 * f56) + (f63 * f55) + f48;
                float f69 = (f54 * fSin) + (f53 * fCos4) + f47;
                float f70 = (f56 * fSin) + (f55 * fCos4) + f48;
                Path path = f21350g;
                float f71 = f21346c;
                path.cubicTo(f65 * f71, f66 * f71, f67 * f71, f68 * f71, f69 * f71, f70 * f71);
                f21351h.add(new h0(1, new k0[]{new k0(f65, f66), new k0(f67, f68), new k0(f69, f70)}));
                i11++;
                fAtan2 = f61;
                f56 = f56;
                f47 = f47;
                f48 = f48;
                f53 = f53;
                iCeil = iCeil;
                fTan = fTan;
                fCos = fCos4;
                f55 = f55;
                f18 = f62;
            }
        }
        d11 = ((double) f57) + 6.283185307179586d;
        f57 = (float) d11;
        double dPow2 = Math.pow(10.0d, 4.0d);
        iCeil = (int) Math.ceil(Math.abs(Math.round((((double) f57) / 1.5707963267948966d) * dPow2) / dPow2));
        f18 = f57 / iCeil;
        fTan = (float) (Math.tan(f18 / 4.0f) * 1.3333333333333333d);
        double d15 = fAtan2;
        fCos = (float) Math.cos(d15);
        fSin = (float) Math.sin(d15);
        i11 = 0;
        while (i11 < iCeil) {
            float f510 = fCos - (fTan * fSin);
            float f511 = (fCos * fTan) + fSin;
            float f610 = fAtan2 + f18;
            double d16 = f610;
            float f611 = f18;
            float fCos5 = (float) Math.cos(d16);
            fSin = (float) Math.sin(d16);
            float f612 = (fTan * fSin) + fCos5;
            float f613 = fSin - (fTan * fCos5);
            float f614 = (f54 * f511) + (f53 * f510) + f47;
            float f615 = (f511 * f56) + (f510 * f55) + f48;
            float f616 = (f54 * f613) + (f53 * f612) + f47;
            float f617 = (f613 * f56) + (f612 * f55) + f48;
            float f618 = (f54 * fSin) + (f53 * fCos5) + f47;
            float f72 = (f56 * fSin) + (f55 * fCos5) + f48;
            Path path2 = f21350g;
            float f73 = f21346c;
            path2.cubicTo(f614 * f73, f615 * f73, f616 * f73, f617 * f73, f618 * f73, f72 * f73);
            f21351h.add(new h0(1, new k0[]{new k0(f614, f615), new k0(f616, f617), new k0(f618, f72)}));
            i11++;
            fAtan2 = f610;
            f56 = f56;
            f47 = f47;
            f48 = f48;
            f53 = f53;
            iCeil = iCeil;
            fTan = fTan;
            fCos = fCos5;
            f55 = f55;
            f18 = f611;
        }
    }

    public static boolean m(p pVar, o oVar) {
        int iOrdinal = oVar.ordinal();
        if (iOrdinal != 0) {
            if (iOrdinal != 1) {
                if (iOrdinal != 2) {
                    if (iOrdinal != 3) {
                        if (iOrdinal != 4) {
                            throw new an.g(false);
                        }
                        if (pVar.f29603l0 == null) {
                            return false;
                        }
                    } else if (pVar.R == null) {
                        return false;
                    }
                } else if (pVar.f29602k0 == null) {
                    return false;
                }
            } else if (pVar.getStatusBarStyle() == null) {
                return false;
            }
        } else if (pVar.getScreenOrientation() == null) {
            return false;
        }
        return true;
    }

    public static p n(p pVar, o oVar) {
        a0 fragmentWrapper;
        if (pVar == null || (fragmentWrapper = pVar.getFragmentWrapper()) == null) {
            return null;
        }
        Iterator it = ((t10.z) fragmentWrapper).f29636z0.iterator();
        while (it.hasNext()) {
            p topScreen = ((q) it.next()).getTopScreen();
            p pVarN = n(topScreen, oVar);
            if (pVarN != null) {
                return pVarN;
            }
            if (topScreen != null && m(topScreen, oVar)) {
                return topScreen;
            }
        }
        return null;
    }

    public static int o(int i11, int i12) {
        return i1.a.e(i11, (Color.alpha(i11) * i12) / JfifUtil.MARKER_FIRST_BYTE);
    }

    public static void p(long j6, qt.q qVar, vr.u[] uVarArr) {
        int i11;
        int iU;
        while (true) {
            if (qVar.a() <= 1) {
                return;
            }
            int i12 = 0;
            while (true) {
                if (qVar.a() == 0) {
                    i11 = -1;
                    break;
                }
                int iU2 = qVar.u();
                i12 += iU2;
                if (iU2 != 255) {
                    i11 = i12;
                    break;
                }
            }
            int i13 = 0;
            do {
                if (qVar.a() == 0) {
                    i13 = -1;
                    break;
                } else {
                    iU = qVar.u();
                    i13 += iU;
                }
            } while (iU == 255);
            int i14 = qVar.f27305b + i13;
            if (i13 == -1 || i13 > qVar.a()) {
                qt.a.N("CeaUtil", "Skipping remainder of malformed SEI NAL unit.");
                i14 = qVar.f27306c;
            } else if (i11 == 4 && i13 >= 8) {
                int iU3 = qVar.u();
                int iZ = qVar.z();
                int iG = iZ == 49 ? qVar.g() : 0;
                int iU4 = qVar.u();
                if (iZ == 47) {
                    qVar.G(1);
                }
                boolean z11 = iU3 == 181 && (iZ == 49 || iZ == 47) && iU4 == 3;
                if (iZ == 49) {
                    z11 &= iG == 1195456820;
                }
                if (z11) {
                    q(j6, qVar, uVarArr);
                }
            }
            qVar.F(i14);
        }
    }

    public static void q(long j6, qt.q qVar, vr.u[] uVarArr) {
        long j11;
        int iU = qVar.u();
        if ((iU & 64) != 0) {
            qVar.G(1);
            int i11 = (iU & 31) * 3;
            int i12 = qVar.f27305b;
            int length = uVarArr.length;
            int i13 = 0;
            while (i13 < length) {
                vr.u uVar = uVarArr[i13];
                qVar.F(i12);
                uVar.a(i11, qVar);
                if (j6 != -9223372036854775807L) {
                    j11 = j6;
                    uVar.e(j11, 1, i11, 0, null);
                } else {
                    j11 = j6;
                }
                i13++;
                j6 = j11;
            }
        }
    }

    public static o40.f r(o40.c functionClass, boolean z11) {
        String lowerCase;
        k.g(functionClass, "functionClass");
        List list = functionClass.M;
        o40.f fVar = new o40.f(functionClass, null, 1, z11);
        t40.u uVarR2 = functionClass.r2();
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (((q0) obj).M0() != z0.IN_VARIANCE) {
                break;
            }
            arrayList.add(obj);
        }
        i iVarX0 = m30.q.X0(arrayList);
        ArrayList arrayList2 = new ArrayList(l.W(iVarX0, 10));
        Iterator it = iVarX0.iterator();
        while (true) {
            w wVar = (w) it;
            if (!wVar.f20885e.hasNext()) {
                k60.a0 a0VarM = ((q0) m30.q.v0(list)).M();
                x xVar = x.f26584w;
                d50.o oVar = q40.o.f26557e;
                s sVar = s.f20879d;
                fVar.O2(null, uVarR2, sVar, sVar, arrayList2, a0VarM, xVar, oVar);
                o40.f fVar2 = fVar;
                fVar2.Z = true;
                return fVar2;
            }
            m30.v vVar = (m30.v) wVar.next();
            int i11 = vVar.f20882a;
            q0 q0Var = (q0) vVar.f20883b;
            String strB = q0Var.getName().b();
            k.f(strB, "asString(...)");
            if (strB.equals("T")) {
                lowerCase = "instance";
            } else if (strB.equals("E")) {
                lowerCase = "receiver";
            } else {
                lowerCase = strB.toLowerCase(Locale.ROOT);
                k.f(lowerCase, "toLowerCase(...)");
            }
            o40.f fVar3 = fVar;
            t50.e eVarE = t50.e.e(lowerCase);
            k60.a0 a0VarM2 = q0Var.M();
            k.f(a0VarM2, "getDefaultType(...)");
            arrayList2.add(new r0(fVar3, null, i11, r40.g.f27594a, eVarE, a0VarM2, false, false, false, null, m0.f26549u));
            fVar = fVar3;
        }
    }

    public static Intent s(Context context, String str, Class clazz, String tag, Map data) {
        k.g(context, "context");
        k.g(clazz, "clazz");
        k.g(tag, "tag");
        k.g(data, "data");
        Intent intentPutExtra = new Intent(str, null, context, clazz).putExtra("discord_shortcut", true).putExtra("discord_shortcut_tag", tag);
        n30.c cVarJ = s1.e.j();
        for (Map.Entry entry : data.entrySet()) {
            String str2 = (String) entry.getKey();
            String str3 = (String) entry.getValue();
            if (str3 != null) {
                cVarJ.add(str2);
                cVarJ.add(str3);
            }
        }
        Intent intentPutExtra2 = intentPutExtra.putExtra("discord_shortcut_data", (String[]) s1.e.f(cVarJ).toArray(new String[0]));
        k.f(intentPutExtra2, "putExtra(...)");
        return intentPutExtra2;
    }

    public static void t(float f3, float f11, float f12, float f13, float f14, float f15) {
        X();
        f21352i = f14;
        f21353j = f15;
        Path path = f21350g;
        float f16 = f21346c;
        path.cubicTo(f3 * f16, f11 * f16, f12 * f16, f13 * f16, f14 * f16, f16 * f15);
        f21351h.add(new h0(1, new k0[]{new k0(f3, f11), new k0(f12, f13), new k0(f14, f15)}));
    }

    public static boolean u(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    public static p v(p pVar, o oVar) {
        p pVarN = n(pVar, oVar);
        if (pVarN != null) {
            return pVarN;
        }
        if (m(pVar, oVar)) {
            return pVar;
        }
        for (ViewParent container = pVar.getContainer(); container != null; container = container.getParent()) {
            if (container instanceof p) {
                p pVar2 = (p) container;
                if (m(pVar2, oVar)) {
                    return pVar2;
                }
            }
        }
        return null;
    }

    public static ya.b w(ya.g gVar, String containerId, String itemType, String itemKey, Boolean bool) {
        k.g(containerId, "containerId");
        k.g(itemType, "itemType");
        k.g(itemKey, "itemKey");
        StringBuilder sb2 = new StringBuilder();
        sb2.append(itemType);
        return x(gVar, containerId, a1.h.l(sb2, "(", itemKey, ")"), bool);
    }

    public static ya.b x(ya.g gVar, String str, String str2, Boolean bool) {
        String strC = gVar.c();
        if (strC != null) {
            String id2 = "obscure:containerId(" + str + "):" + str2;
            k.g(id2, "id");
            return new ya.b(id2, new com.margelo.nitro.nitrofetch.a(strC, 5), new com.margelo.nitro.nitrofetch.a(strC, 6), ya.f.f36578e, bool);
        }
        String strA = gVar.a();
        if (strA == null) {
            return null;
        }
        String id3 = "spoiler:containerId(" + str + "):" + str2;
        k.g(id3, "id");
        return new ya.b(id3, new uc.b(20), new com.margelo.nitro.nitrofetch.a(strA, 7), ya.f.f36577d, bool);
    }

    public static int y(View view, int i11) {
        Context context = view.getContext();
        Context context2 = view.getContext();
        String canonicalName = view.getClass().getCanonicalName();
        TypedValue typedValueL = ul.b.L(context2, i11);
        if (typedValueL == null) {
            throw new IllegalArgumentException(String.format("%1$s requires a value for the %2$s attribute to be set in your app theme. You can either set the attribute in your theme or update your theme to inherit from Theme.MaterialComponents (or a descendant).", canonicalName, context2.getResources().getResourceName(i11)));
        }
        int i12 = typedValueL.resourceId;
        return i12 != 0 ? context.getColor(i12) : typedValueL.data;
    }

    public static i8.g z(i8.k kVar, List list) {
        i8.b cacheEntry = kVar.getCacheEntry();
        if (cacheEntry == null) {
            return new i8.g(null, true, list);
        }
        TreeSet treeSet = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        if (!list.isEmpty()) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                treeSet.add(((i8.e) it.next()).f15443a);
            }
        }
        ArrayList arrayList = new ArrayList(list);
        List list2 = cacheEntry.f15436h;
        if (list2 != null) {
            if (!list2.isEmpty()) {
                for (i8.e eVar : cacheEntry.f15436h) {
                    if (!treeSet.contains(eVar.f15443a)) {
                        arrayList.add(eVar);
                    }
                }
            }
        } else if (!cacheEntry.f15435g.isEmpty()) {
            for (Map.Entry entry : cacheEntry.f15435g.entrySet()) {
                if (!treeSet.contains(entry.getKey())) {
                    arrayList.add(new i8.e((String) entry.getKey(), (String) entry.getValue()));
                }
            }
        }
        return new i8.g(cacheEntry.f15429a, true, arrayList);
    }

    public abstract String l();

    public String toString() {
        switch (this.f21360a) {
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                return l();
            default:
                return super.toString();
        }
    }

    @Override // androidx.core.view.i1
    public void a() {
    }

    @Override // androidx.core.view.i1
    public void b() {
    }
}
