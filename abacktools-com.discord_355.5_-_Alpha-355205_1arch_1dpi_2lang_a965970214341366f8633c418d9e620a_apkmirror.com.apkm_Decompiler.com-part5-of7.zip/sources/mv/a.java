package mv;

import an.g;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.WorkSource;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.view.j1;
import hs.q;
import hu.s;
import j.e0;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import mu.f;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final long f22022n = TimeUnit.DAYS.toMillis(366);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static volatile ScheduledExecutorService f22023o = null;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final Object f22024p = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f22025a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final PowerManager.WakeLock f22026b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f22027c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ScheduledFuture f22028d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f22029e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final HashSet f22030f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f22031g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public iv.a f22032h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final mu.b f22033i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final String f22034j;
    public final HashMap k;
    public final AtomicInteger l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ScheduledExecutorService f22035m;

    public a(Context context, String str) {
        boolean zBooleanValue;
        String packageName = context.getPackageName();
        this.f22025a = new Object();
        this.f22027c = 0;
        this.f22030f = new HashSet();
        this.f22031g = true;
        this.f22033i = mu.b.f22009a;
        this.k = new HashMap();
        this.l = new AtomicInteger(0);
        s.e(str, "WakeLock: wakeLockName must not be empty");
        context.getApplicationContext();
        WorkSource workSource = null;
        this.f22032h = null;
        if ("com.google.android.gms".equals(context.getPackageName())) {
            this.f22034j = str;
        } else {
            this.f22034j = str.length() != 0 ? "*gcore*:".concat(str) : new String("*gcore*:");
        }
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        if (powerManager == null) {
            StringBuilder sb2 = new StringBuilder(29);
            sb2.append((CharSequence) "expected a non-null reference", 0, 29);
            throw new g(sb2.toString(), 12);
        }
        this.f22026b = powerManager.newWakeLock(1, str);
        Method method = mu.g.f22019a;
        synchronized (mu.g.class) {
            Boolean bool = mu.g.f22021c;
            if (bool != null) {
                zBooleanValue = bool.booleanValue();
            } else {
                zBooleanValue = j1.d(context, "android.permission.UPDATE_DEVICE_STATS") == 0;
                mu.g.f22021c = Boolean.valueOf(zBooleanValue);
            }
        }
        if (zBooleanValue) {
            int i11 = f.f22018a;
            packageName = packageName == null || packageName.trim().isEmpty() ? context.getPackageName() : packageName;
            if (context.getPackageManager() != null && packageName != null) {
                try {
                    ApplicationInfo applicationInfo = ou.b.a(context).f4021a.getPackageManager().getApplicationInfo(packageName, 0);
                    if (applicationInfo == null) {
                        Log.e("WorkSourceUtil", "Could not get applicationInfo from package: ".concat(packageName));
                    } else {
                        int i12 = applicationInfo.uid;
                        workSource = new WorkSource();
                        Method method2 = mu.g.f22020b;
                        if (method2 != null) {
                            try {
                                method2.invoke(workSource, Integer.valueOf(i12), packageName);
                            } catch (Exception e4) {
                                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", e4);
                            }
                        } else {
                            Method method3 = mu.g.f22019a;
                            if (method3 != null) {
                                try {
                                    method3.invoke(workSource, Integer.valueOf(i12));
                                } catch (Exception e9) {
                                    Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", e9);
                                }
                            }
                        }
                    }
                } catch (PackageManager.NameNotFoundException unused) {
                    Log.e("WorkSourceUtil", "Could not find package: ".concat(packageName));
                }
            }
            if (workSource != null) {
                try {
                    this.f22026b.setWorkSource(workSource);
                } catch (ArrayIndexOutOfBoundsException | IllegalArgumentException e11) {
                    Log.wtf("WakeLock", e11.toString());
                }
            }
        }
        ScheduledExecutorService scheduledExecutorServiceUnconfigurableScheduledExecutorService = f22023o;
        if (scheduledExecutorServiceUnconfigurableScheduledExecutorService == null) {
            synchronized (f22024p) {
                try {
                    scheduledExecutorServiceUnconfigurableScheduledExecutorService = f22023o;
                    if (scheduledExecutorServiceUnconfigurableScheduledExecutorService == null) {
                        scheduledExecutorServiceUnconfigurableScheduledExecutorService = Executors.unconfigurableScheduledExecutorService(Executors.newScheduledThreadPool(1));
                        f22023o = scheduledExecutorServiceUnconfigurableScheduledExecutorService;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        this.f22035m = scheduledExecutorServiceUnconfigurableScheduledExecutorService;
    }

    public final void a(long j6) {
        this.l.incrementAndGet();
        long jMax = Math.max(Math.min(Long.MAX_VALUE, f22022n), 1L);
        if (j6 > 0) {
            jMax = Math.min(j6, jMax);
        }
        synchronized (this.f22025a) {
            try {
                if (!b()) {
                    this.f22032h = iv.a.f17377d;
                    this.f22026b.acquire();
                    this.f22033i.getClass();
                    SystemClock.elapsedRealtime();
                }
                this.f22027c++;
                if (this.f22031g) {
                    TextUtils.isEmpty(null);
                }
                b bVar = (b) this.k.get(null);
                if (bVar == null) {
                    bVar = new b();
                    this.k.put(null, bVar);
                }
                bVar.f22036a++;
                this.f22033i.getClass();
                long jElapsedRealtime = SystemClock.elapsedRealtime();
                long j11 = Long.MAX_VALUE - jElapsedRealtime > jMax ? jElapsedRealtime + jMax : Long.MAX_VALUE;
                if (j11 > this.f22029e) {
                    this.f22029e = j11;
                    ScheduledFuture scheduledFuture = this.f22028d;
                    if (scheduledFuture != null) {
                        scheduledFuture.cancel(false);
                    }
                    this.f22028d = this.f22035m.schedule(new e0(6, this), jMax, TimeUnit.MILLISECONDS);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final boolean b() {
        boolean z11;
        synchronized (this.f22025a) {
            z11 = this.f22027c > 0;
        }
        return z11;
    }

    public final void c() {
        if (this.l.decrementAndGet() < 0) {
            Log.e("WakeLock", String.valueOf(this.f22034j).concat(" release without a matched acquire!"));
        }
        synchronized (this.f22025a) {
            try {
                if (this.f22031g) {
                    TextUtils.isEmpty(null);
                }
                if (this.k.containsKey(null)) {
                    b bVar = (b) this.k.get(null);
                    if (bVar != null) {
                        int i11 = bVar.f22036a - 1;
                        bVar.f22036a = i11;
                        if (i11 == 0) {
                            this.k.remove(null);
                        }
                    }
                } else {
                    Log.w("WakeLock", String.valueOf(this.f22034j).concat(" counter does not exist"));
                }
                e();
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void d() {
        HashSet hashSet = this.f22030f;
        if (hashSet.isEmpty()) {
            return;
        }
        ArrayList arrayList = new ArrayList(hashSet);
        hashSet.clear();
        if (arrayList.size() > 0) {
            throw q.g(0, arrayList);
        }
    }

    public final void e() {
        synchronized (this.f22025a) {
            try {
                if (b()) {
                    if (this.f22031g) {
                        int i11 = this.f22027c - 1;
                        this.f22027c = i11;
                        if (i11 > 0) {
                            return;
                        }
                    } else {
                        this.f22027c = 0;
                    }
                    d();
                    Iterator it = this.k.values().iterator();
                    while (it.hasNext()) {
                        ((b) it.next()).f22036a = 0;
                    }
                    this.k.clear();
                    ScheduledFuture scheduledFuture = this.f22028d;
                    if (scheduledFuture != null) {
                        scheduledFuture.cancel(false);
                        this.f22028d = null;
                        this.f22029e = 0L;
                    }
                    if (this.f22026b.isHeld()) {
                        try {
                            try {
                                this.f22026b.release();
                                if (this.f22032h != null) {
                                    this.f22032h = null;
                                }
                            } catch (RuntimeException e4) {
                                if (!e4.getClass().equals(RuntimeException.class)) {
                                    throw e4;
                                }
                                Log.e("WakeLock", String.valueOf(this.f22034j).concat(" failed to release!"), e4);
                                if (this.f22032h != null) {
                                    this.f22032h = null;
                                }
                            }
                        } catch (Throwable th2) {
                            if (this.f22032h != null) {
                                this.f22032h = null;
                            }
                            throw th2;
                        }
                    } else {
                        Log.e("WakeLock", String.valueOf(this.f22034j).concat(" should be held!"));
                    }
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
    }
}
