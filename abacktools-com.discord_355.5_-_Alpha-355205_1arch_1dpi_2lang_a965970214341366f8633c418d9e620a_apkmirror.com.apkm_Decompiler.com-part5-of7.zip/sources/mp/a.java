package mp;

import android.net.Uri;
import android.os.Bundle;
import com.discord.age_assurance.DigitalCredentialModule;
import com.facebook.react.views.drawer.ReactDrawerLayoutManager;
import com.facebook.react.views.image.ReactImageManager;
import com.facebook.react.views.modal.ReactModalHostManager;
import com.facebook.react.views.progressbar.ReactProgressBarViewManager;
import com.facebook.react.views.scroll.ReactHorizontalScrollContainerViewManager;
import com.facebook.react.views.scroll.ReactHorizontalScrollViewManager;
import com.facebook.react.views.swiperefresh.SwipeRefreshLayoutManager;
import com.facebook.react.views.text.PreparedLayoutTextViewManager;
import com.facebook.react.views.text.ReactTextViewManager;
import com.facebook.react.views.text.SelectableTextViewManager;
import com.facebook.react.views.textinput.ReactTextInputManager;
import com.facebook.react.views.unimplementedview.ReactUnimplementedViewManager;
import com.facebook.react.views.view.ReactViewManager;
import com.facebook.react.views.virtual.view.ReactVirtualViewManager;
import gx.k;
import hs.q;
import hx.b2;
import hx.p0;
import hx.w1;
import io.sentry.android.core.internal.tombstone.TombstoneProtos$Tombstone;
import is.c;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;
import javax.inject.Provider;
import k3.e0;
import mr.d;
import mr.e2;
import mr.f2;
import mr.h0;
import mr.i0;
import mr.j;
import mr.j0;
import mr.k0;
import mr.l0;
import mr.l1;
import mr.m0;
import mr.n0;
import mr.o0;
import mr.q0;
import mr.r0;
import mr.r1;
import mr.s0;
import mr.s1;
import mr.u0;
import mr.v0;
import mr.w0;
import mr.x0;
import mr.z;
import mr.z1;
import qt.e;
import qt.g;
import qt.h;
import qt.s;
import qt.x;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Provider, k, g, h, d {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f21361d;

    public /* synthetic */ a(int i11) {
        this.f21361d = i11;
    }

    @Override // qt.h
    public void a(Object obj, e eVar) {
        ((s1) obj).H(new r1(eVar));
    }

    @Override // gx.k
    public Object apply(Object obj) {
        return new nr.g((s) obj);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v119 */
    /* JADX WARN: Type inference failed for: r4v122 */
    /* JADX WARN: Type inference failed for: r4v88, types: [java.lang.Cloneable] */
    @Override // mr.d
    public mr.e e(Bundle bundle) {
        p0 p0VarA;
        w1 w1VarG;
        w1 w1VarV;
        Bundle bundle2;
        Bundle bundle3;
        boolean z11 = true;
        int i11 = 0;
        boolean z12 = false;
        switch (this.f21361d) {
            case TombstoneProtos$Tombstone.MEMORY_MAPPINGS_FIELD_NUMBER /* 17 */:
                i0 i0Var = i0.f21545k0;
                h0 h0Var = new h0();
                if (bundle != null) {
                    ClassLoader classLoader = qt.a.class.getClassLoader();
                    int i12 = x.f27318a;
                    bundle.setClassLoader(classLoader);
                }
                String string = bundle.getString(i0.f21546l0);
                String str = i0Var.f21563d;
                if (string == null) {
                    string = str;
                }
                h0Var.f21509a = string;
                String string2 = bundle.getString(i0.f21547m0);
                String str2 = i0Var.f21565e;
                if (string2 == null) {
                    string2 = str2;
                }
                h0Var.f21510b = string2;
                String string3 = bundle.getString(i0.f21548n0);
                String str3 = i0Var.f21570i;
                if (string3 == null) {
                    string3 = str3;
                }
                h0Var.f21511c = string3;
                h0Var.f21512d = bundle.getInt(i0.f21549o0, i0Var.f21573v);
                h0Var.f21513e = bundle.getInt(i0.f21550p0, i0Var.f21574w);
                h0Var.f21514f = bundle.getInt(i0.f21551q0, i0Var.f21575x);
                h0Var.f21515g = bundle.getInt(i0.f21552r0, i0Var.y);
                String string4 = bundle.getString(i0.f21553s0);
                String str4 = i0Var.K;
                if (string4 == null) {
                    string4 = str4;
                }
                h0Var.f21516h = string4;
                c cVar = (c) bundle.getParcelable(i0.t0);
                c cVar2 = i0Var.L;
                if (cVar == null) {
                    cVar = cVar2;
                }
                h0Var.f21517i = cVar;
                String string5 = bundle.getString(i0.f21554u0);
                String str5 = i0Var.M;
                if (string5 == null) {
                    string5 = str5;
                }
                h0Var.f21518j = string5;
                String string6 = bundle.getString(i0.f21555v0);
                String str6 = i0Var.N;
                if (string6 == null) {
                    string6 = str6;
                }
                h0Var.k = string6;
                h0Var.l = bundle.getInt(i0.f21556w0, i0Var.O);
                ArrayList arrayList = new ArrayList();
                while (true) {
                    byte[] byteArray = bundle.getByteArray(i0.f21557x0 + "_" + Integer.toString(i11, 36));
                    if (byteArray == null) {
                        break;
                    }
                    arrayList.add(byteArray);
                    i11++;
                }
                h0Var.f21519m = arrayList;
                h0Var.f21520n = (sr.h) bundle.getParcelable(i0.f21558y0);
                h0Var.f21521o = bundle.getLong(i0.f21559z0, i0Var.R);
                h0Var.f21522p = bundle.getInt(i0.A0, i0Var.S);
                h0Var.f21523q = bundle.getInt(i0.B0, i0Var.T);
                h0Var.f21524r = bundle.getFloat(i0.C0, i0Var.U);
                h0Var.f21525s = bundle.getInt(i0.D0, i0Var.V);
                h0Var.f21526t = bundle.getFloat(i0.E0, i0Var.W);
                h0Var.f21527u = bundle.getByteArray(i0.F0);
                h0Var.f21528v = bundle.getInt(i0.G0, i0Var.Y);
                Bundle bundle4 = bundle.getBundle(i0.H0);
                if (bundle4 != null) {
                    h0Var.f21529w = (rt.b) rt.b.M.e(bundle4);
                }
                h0Var.f21530x = bundle.getInt(i0.I0, i0Var.f21560a0);
                h0Var.y = bundle.getInt(i0.J0, i0Var.f21561b0);
                h0Var.f21531z = bundle.getInt(i0.K0, i0Var.f21562c0);
                h0Var.A = bundle.getInt(i0.L0, i0Var.f21564d0);
                h0Var.B = bundle.getInt(i0.M0, i0Var.f21566e0);
                h0Var.C = bundle.getInt(i0.N0, i0Var.f21567f0);
                h0Var.D = bundle.getInt(i0.P0, i0Var.f21568g0);
                h0Var.E = bundle.getInt(i0.Q0, i0Var.f21569h0);
                h0Var.F = bundle.getInt(i0.O0, i0Var.f21571i0);
                return new i0(h0Var);
            case TombstoneProtos$Tombstone.LOG_BUFFERS_FIELD_NUMBER /* 18 */:
                qt.a.g(bundle.getInt(z1.f21880d, -1) == 0);
                return bundle.getBoolean(j0.f21600w, false) ? new j0(bundle.getBoolean(j0.f21601x, false)) : new j0();
            case TombstoneProtos$Tombstone.OPEN_FDS_FIELD_NUMBER /* 19 */:
                String string7 = bundle.getString(v0.K, "");
                string7.getClass();
                Bundle bundle5 = bundle.getBundle(v0.L);
                q0 q0Var = bundle5 == null ? q0.f21706x : (q0) q0.N.e(bundle5);
                Bundle bundle6 = bundle.getBundle(v0.M);
                x0 x0Var = bundle6 == null ? x0.f21790k0 : (x0) x0.S0.e(bundle6);
                Bundle bundle7 = bundle.getBundle(v0.N);
                o0 o0Var = bundle7 == null ? o0.O : (o0) n0.N.e(bundle7);
                Bundle bundle8 = bundle.getBundle(v0.O);
                s0 s0Var = bundle8 == null ? s0.f21725i : (s0) s0.y.e(bundle8);
                Bundle bundle9 = bundle.getBundle(v0.P);
                return new v0(string7, o0Var, bundle9 != null ? (r0) r0.Q.e(bundle9) : null, q0Var, x0Var, s0Var);
            case TombstoneProtos$Tombstone.PROCESS_UPTIME_FIELD_NUMBER /* 20 */:
                Uri uri = (Uri) bundle.getParcelable(l0.f21645e);
                uri.getClass();
                k0 k0Var = new k0();
                k0Var.f21633d = uri;
                return new l0(k0Var);
            case TombstoneProtos$Tombstone.CRASH_DETAILS_FIELD_NUMBER /* 21 */:
                m0 m0Var = new m0();
                String str7 = n0.y;
                o0 o0Var2 = n0.f21664x;
                long j6 = bundle.getLong(str7, o0Var2.f21665d);
                qt.a.g(j6 >= 0);
                m0Var.f21655a = j6;
                long j11 = bundle.getLong(n0.J, o0Var2.f21666e);
                if (j11 != Long.MIN_VALUE && j11 < 0) {
                    z11 = false;
                }
                qt.a.g(z11);
                m0Var.f21656b = j11;
                m0Var.f21657c = bundle.getBoolean(n0.K, o0Var2.f21667i);
                m0Var.f21658d = bundle.getBoolean(n0.L, o0Var2.f21668v);
                m0Var.f21659e = bundle.getBoolean(n0.M, o0Var2.f21669w);
                return new o0(m0Var);
            case TombstoneProtos$Tombstone.PAGE_SIZE_FIELD_NUMBER /* 22 */:
                String string8 = bundle.getString(mr.p0.K);
                string8.getClass();
                UUID uuidFromString = UUID.fromString(string8);
                Uri uri2 = (Uri) bundle.getParcelable(mr.p0.L);
                String str8 = mr.p0.M;
                Bundle bundle10 = Bundle.EMPTY;
                Bundle bundle11 = bundle.getBundle(str8);
                if (bundle11 == null) {
                    bundle11 = bundle10;
                }
                b2 b2Var = b2.y;
                if (bundle11 == bundle10) {
                    p0VarA = b2Var;
                } else {
                    HashMap map = new HashMap();
                    if (bundle11 != bundle10) {
                        for (String str9 : bundle11.keySet()) {
                            String string9 = bundle11.getString(str9);
                            if (string9 != null) {
                                map.put(str9, string9);
                            }
                        }
                    }
                    p0VarA = p0.a(map);
                }
                boolean z13 = bundle.getBoolean(mr.p0.N, false);
                boolean z14 = bundle.getBoolean(mr.p0.O, false);
                boolean z15 = bundle.getBoolean(mr.p0.P, false);
                String str10 = mr.p0.Q;
                ArrayList<Integer> arrayList2 = new ArrayList<>();
                ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList(str10);
                if (integerArrayList != null) {
                    arrayList2 = integerArrayList;
                }
                hx.m0 m0VarQ = hx.m0.q(arrayList2);
                byte[] byteArray2 = bundle.getByteArray(mr.p0.R);
                e0 e0Var = new e0();
                e0Var.f18574a = uuidFromString;
                e0Var.f18576c = b2Var;
                e0Var.f18580g = w1.f14911w;
                e0Var.f18575b = uri2;
                e0Var.f18576c = p0.a(p0VarA);
                e0Var.f18577d = z13;
                e0Var.f18579f = z15;
                e0Var.f18578e = z14;
                e0Var.f18580g = hx.m0.q(m0VarQ);
                e0Var.f18581h = byteArray2 != null ? Arrays.copyOf(byteArray2, byteArray2.length) : 0;
                return new mr.p0(e0Var);
            case TombstoneProtos$Tombstone.HAS_BEEN_16KB_MODE_FIELD_NUMBER /* 23 */:
                return new q0(bundle.getLong(q0.y, -9223372036854775807L), bundle.getLong(q0.J, -9223372036854775807L), bundle.getLong(q0.K, -9223372036854775807L), bundle.getFloat(q0.L, -3.4028235E38f), bundle.getFloat(q0.M, -3.4028235E38f));
            case TombstoneProtos$Tombstone.GUEST_ARCH_FIELD_NUMBER /* 24 */:
                Bundle bundle12 = bundle.getBundle(r0.L);
                mr.p0 p0Var = bundle12 == null ? null : (mr.p0) mr.p0.S.e(bundle12);
                Bundle bundle13 = bundle.getBundle(r0.M);
                l0 l0Var = bundle13 != null ? (l0) l0.f21646i.e(bundle13) : null;
                ArrayList parcelableArrayList = bundle.getParcelableArrayList(r0.N);
                if (parcelableArrayList == null) {
                    hx.k0 k0Var2 = hx.m0.f14841e;
                    w1VarG = w1.f14911w;
                } else {
                    hx.j0 j0VarP = hx.m0.p();
                    for (int i13 = 0; i13 < parcelableArrayList.size(); i13++) {
                        Bundle bundle14 = (Bundle) parcelableArrayList.get(i13);
                        bundle14.getClass();
                        j0VarP.c(new rs.b(bundle14.getInt(rs.b.f28415v, 0), bundle14.getInt(rs.b.f28416w, 0), bundle14.getInt(rs.b.f28417x, 0)));
                    }
                    w1VarG = j0VarP.g();
                }
                w1 w1Var = w1VarG;
                ArrayList parcelableArrayList2 = bundle.getParcelableArrayList(r0.P);
                if (parcelableArrayList2 == null) {
                    hx.k0 k0Var3 = hx.m0.f14841e;
                    w1VarV = w1.f14911w;
                } else {
                    w1VarV = qt.a.v(u0.Q, parcelableArrayList2);
                }
                w1 w1Var2 = w1VarV;
                Uri uri3 = (Uri) bundle.getParcelable(r0.J);
                uri3.getClass();
                return new r0(uri3, bundle.getString(r0.K), p0Var, l0Var, w1Var, bundle.getString(r0.O), w1Var2);
            case TombstoneProtos$Tombstone.GUEST_THREADS_FIELD_NUMBER /* 25 */:
                k7.e eVar = new k7.e((char) (z12 ? 1 : 0), 22);
                eVar.f19326e = (Uri) bundle.getParcelable(s0.f21726v);
                eVar.f19327i = bundle.getString(s0.f21727w);
                bundle.getBundle(s0.f21728x);
                return new s0(eVar);
            case TombstoneProtos$Tombstone.STACK_HISTORY_BUFFER_FIELD_NUMBER /* 26 */:
                Uri uri4 = (Uri) bundle.getParcelable(u0.J);
                uri4.getClass();
                String string10 = bundle.getString(u0.K);
                String string11 = bundle.getString(u0.L);
                int i14 = bundle.getInt(u0.M, 0);
                int i15 = bundle.getInt(u0.N, 0);
                String string12 = bundle.getString(u0.O);
                String string13 = bundle.getString(u0.P);
                k3.m0 m0Var2 = new k3.m0(uri4);
                m0Var2.f18700b = string10;
                m0Var2.f18701c = string11;
                m0Var2.f18702d = i14;
                m0Var2.f18703e = i15;
                m0Var2.f18704f = string12;
                m0Var2.f18705g = string13;
                return new u0(m0Var2);
            case 27:
                w0 w0Var = new w0();
                w0Var.f21754a = bundle.getCharSequence(x0.f21791l0);
                w0Var.f21755b = bundle.getCharSequence(x0.f21792m0);
                w0Var.f21756c = bundle.getCharSequence(x0.f21793n0);
                w0Var.f21757d = bundle.getCharSequence(x0.f21794o0);
                w0Var.f21758e = bundle.getCharSequence(x0.f21795p0);
                w0Var.f21759f = bundle.getCharSequence(x0.f21796q0);
                w0Var.f21760g = bundle.getCharSequence(x0.f21797r0);
                byte[] byteArray3 = bundle.getByteArray(x0.f21799u0);
                String str11 = x0.N0;
                Integer numValueOf = bundle.containsKey(str11) ? Integer.valueOf(bundle.getInt(str11)) : null;
                w0Var.f21763j = byteArray3 != null ? (byte[]) byteArray3.clone() : null;
                w0Var.k = numValueOf;
                w0Var.l = (Uri) bundle.getParcelable(x0.f21800v0);
                w0Var.f21775x = bundle.getCharSequence(x0.G0);
                w0Var.y = bundle.getCharSequence(x0.H0);
                w0Var.f21776z = bundle.getCharSequence(x0.I0);
                w0Var.C = bundle.getCharSequence(x0.L0);
                w0Var.D = bundle.getCharSequence(x0.M0);
                w0Var.E = bundle.getCharSequence(x0.O0);
                w0Var.G = bundle.getBundle(x0.R0);
                String str12 = x0.f21798s0;
                if (bundle.containsKey(str12) && (bundle3 = bundle.getBundle(str12)) != null) {
                    w0Var.f21761h = (z1) z1.f21881e.e(bundle3);
                }
                String str13 = x0.t0;
                if (bundle.containsKey(str13) && (bundle2 = bundle.getBundle(str13)) != null) {
                    w0Var.f21762i = (z1) z1.f21881e.e(bundle2);
                }
                String str14 = x0.f21801w0;
                if (bundle.containsKey(str14)) {
                    w0Var.f21764m = Integer.valueOf(bundle.getInt(str14));
                }
                String str15 = x0.f21802x0;
                if (bundle.containsKey(str15)) {
                    w0Var.f21765n = Integer.valueOf(bundle.getInt(str15));
                }
                String str16 = x0.f21803y0;
                if (bundle.containsKey(str16)) {
                    w0Var.f21766o = Integer.valueOf(bundle.getInt(str16));
                }
                String str17 = x0.Q0;
                if (bundle.containsKey(str17)) {
                    w0Var.f21767p = Boolean.valueOf(bundle.getBoolean(str17));
                }
                String str18 = x0.f21804z0;
                if (bundle.containsKey(str18)) {
                    w0Var.f21768q = Boolean.valueOf(bundle.getBoolean(str18));
                }
                String str19 = x0.A0;
                if (bundle.containsKey(str19)) {
                    w0Var.f21769r = Integer.valueOf(bundle.getInt(str19));
                }
                String str20 = x0.B0;
                if (bundle.containsKey(str20)) {
                    w0Var.f21770s = Integer.valueOf(bundle.getInt(str20));
                }
                String str21 = x0.C0;
                if (bundle.containsKey(str21)) {
                    w0Var.f21771t = Integer.valueOf(bundle.getInt(str21));
                }
                String str22 = x0.D0;
                if (bundle.containsKey(str22)) {
                    w0Var.f21772u = Integer.valueOf(bundle.getInt(str22));
                }
                String str23 = x0.E0;
                if (bundle.containsKey(str23)) {
                    w0Var.f21773v = Integer.valueOf(bundle.getInt(str23));
                }
                String str24 = x0.F0;
                if (bundle.containsKey(str24)) {
                    w0Var.f21774w = Integer.valueOf(bundle.getInt(str24));
                }
                String str25 = x0.J0;
                if (bundle.containsKey(str25)) {
                    w0Var.A = Integer.valueOf(bundle.getInt(str25));
                }
                String str26 = x0.K0;
                if (bundle.containsKey(str26)) {
                    w0Var.B = Integer.valueOf(bundle.getInt(str26));
                }
                String str27 = x0.P0;
                if (bundle.containsKey(str27)) {
                    w0Var.F = Integer.valueOf(bundle.getInt(str27));
                }
                return new x0(w0Var);
            case DigitalCredentialModule.MINIMUM_API_LEVEL /* 28 */:
                qt.a.g(bundle.getInt(z1.f21880d, -1) == 1);
                float f3 = bundle.getFloat(l1.f21648v, -1.0f);
                return f3 == -1.0f ? new l1() : new l1(f3);
            default:
                int i16 = bundle.getInt(z1.f21880d, -1);
                if (i16 == 0) {
                    return (z1) j0.y.e(bundle);
                }
                if (i16 == 1) {
                    return (z1) l1.f21649w.e(bundle);
                }
                if (i16 == 2) {
                    return (z1) e2.y.e(bundle);
                }
                if (i16 == 3) {
                    return (z1) f2.y.e(bundle);
                }
                throw new IllegalArgumentException(q.j(i16, "Unknown RatingType: "));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // javax.inject.Provider
    public Object get() {
        switch (this.f21361d) {
            case 0:
                return new SwipeRefreshLayoutManager();
            case 1:
                return new ReactImageManager(null, null, null, 7, null);
            case 2:
                return new ReactModalHostManager();
            case 3:
                return new ReactTextInputManager();
            case 4:
                return new ReactDrawerLayoutManager();
            case 5:
                int i11 = 1;
                return fo.a.f() ? new PreparedLayoutTextViewManager(null, i11, 0 == true ? 1 : 0) : new ReactTextViewManager(0 == true ? 1 : 0, i11, 0 == true ? 1 : 0);
            case 6:
                return new SelectableTextViewManager(null, 1, 0 == true ? 1 : 0);
            case 7:
                return new ReactViewManager();
            case 8:
                return new ReactVirtualViewManager();
            case 9:
                return new ReactUnimplementedViewManager();
            case 10:
                return new ReactHorizontalScrollViewManager(null, 1, 0 == true ? 1 : 0);
            case 11:
                return new ReactHorizontalScrollContainerViewManager();
            default:
                return new ReactProgressBarViewManager();
        }
    }

    @Override // qt.g, n3.n
    public void invoke(Object obj) {
        s1 s1Var = (s1) obj;
        switch (this.f21361d) {
            case 14:
                s1Var.m(new j(2, new an.g("Player release timed out.", 19), 1003));
                break;
            default:
                s1Var.i();
                break;
        }
    }

    public /* synthetic */ a(z zVar) {
        this.f21361d = 15;
    }
}
