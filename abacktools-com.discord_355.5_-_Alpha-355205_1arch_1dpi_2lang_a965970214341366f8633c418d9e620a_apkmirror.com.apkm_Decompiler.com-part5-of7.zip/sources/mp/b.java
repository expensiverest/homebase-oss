package mp;

import bn.i;
import com.facebook.react.animated.NativeAnimatedModule;
import com.facebook.react.bridge.ModuleSpec;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.module.model.ReactModuleInfo;
import com.facebook.react.modules.accessibilityinfo.AccessibilityInfoModule;
import com.facebook.react.modules.appearance.AppearanceModule;
import com.facebook.react.modules.appstate.AppStateModule;
import com.facebook.react.modules.blob.BlobModule;
import com.facebook.react.modules.blob.FileReaderModule;
import com.facebook.react.modules.camera.ImageStoreManager;
import com.facebook.react.modules.clipboard.ClipboardModule;
import com.facebook.react.modules.devloading.DevLoadingModule;
import com.facebook.react.modules.devtoolsruntimesettings.ReactDevToolsRuntimeSettingsModule;
import com.facebook.react.modules.dialog.DialogModule;
import com.facebook.react.modules.fresco.FrescoModule;
import com.facebook.react.modules.i18nmanager.I18nManagerModule;
import com.facebook.react.modules.image.ImageLoaderModule;
import com.facebook.react.modules.intent.IntentModule;
import com.facebook.react.modules.network.NetworkingModule;
import com.facebook.react.modules.permissions.PermissionsModule;
import com.facebook.react.modules.reactdevtoolssettings.ReactDevToolsSettingsManagerModule;
import com.facebook.react.modules.share.ShareModule;
import com.facebook.react.modules.sound.SoundManagerModule;
import com.facebook.react.modules.statusbar.StatusBarModule;
import com.facebook.react.modules.toast.ToastModule;
import com.facebook.react.modules.vibration.VibrationModule;
import com.facebook.react.modules.websocket.WebSocketModule;
import com.facebook.react.turbomodule.core.interfaces.TurboModule;
import com.facebook.react.uimanager.ViewManager;
import com.facebook.react.views.drawer.ReactDrawerLayoutManager;
import com.facebook.react.views.image.ReactImageManager;
import com.facebook.react.views.modal.ReactModalHostManager;
import com.facebook.react.views.progressbar.ReactProgressBarViewManager;
import com.facebook.react.views.safeareaview.ReactSafeAreaViewManager;
import com.facebook.react.views.scroll.ReactHorizontalScrollContainerViewManager;
import com.facebook.react.views.scroll.ReactHorizontalScrollViewManager;
import com.facebook.react.views.swiperefresh.SwipeRefreshLayoutManager;
import com.facebook.react.views.switchview.ReactSwitchManager;
import com.facebook.react.views.text.PreparedLayoutTextViewManager;
import com.facebook.react.views.text.ReactTextViewManager;
import com.facebook.react.views.text.SelectableTextViewManager;
import com.facebook.react.views.textinput.ReactTextInputManager;
import com.facebook.react.views.unimplementedview.ReactUnimplementedViewManager;
import com.facebook.react.views.view.ReactViewManager;
import com.facebook.react.views.virtual.view.ReactVirtualViewManager;
import com.swmansion.reanimated.d;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import javax.inject.Provider;
import kotlin.jvm.internal.k;
import l30.j;
import m30.l;
import m30.q;
import m30.x;
import s1.e;
import sn.c;
import sn.y;

/* JADX INFO: loaded from: classes.dex */
public final class b extends c implements y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f21362a;

    public b() {
        ModuleSpec.Companion companion = ModuleSpec.INSTANCE;
        this.f21362a = x.r0(new j(ReactDrawerLayoutManager.REACT_CLASS, companion.viewManagerSpec(new a(4))), new j(ReactHorizontalScrollViewManager.REACT_CLASS, companion.viewManagerSpec(new a(10))), new j(ReactHorizontalScrollContainerViewManager.REACT_CLASS, companion.viewManagerSpec(new a(11))), new j(ReactProgressBarViewManager.REACT_CLASS, companion.viewManagerSpec(new a(12))), new j(ReactSafeAreaViewManager.REACT_CLASS, companion.viewManagerSpec(new j10.a(28))), new j(ReactSwitchManager.REACT_CLASS, companion.viewManagerSpec(new j10.a(29))), new j(SwipeRefreshLayoutManager.REACT_CLASS, companion.viewManagerSpec(new a(0))), new j(ReactImageManager.REACT_CLASS, companion.viewManagerSpec(new a(1))), new j(ReactModalHostManager.REACT_CLASS, companion.viewManagerSpec(new a(2))), new j(ReactTextInputManager.REACT_CLASS, companion.viewManagerSpec(new a(3))), new j("RCTText", companion.viewManagerSpec(new a(5))), new j(SelectableTextViewManager.REACT_CLASS, companion.viewManagerSpec(new a(6))), new j(ReactViewManager.REACT_CLASS, companion.viewManagerSpec(new a(7))), new j(ReactVirtualViewManager.REACT_CLASS, companion.viewManagerSpec(new a(8))), new j(ReactUnimplementedViewManager.REACT_CLASS, companion.viewManagerSpec(new a(9))));
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object, java.util.Map] */
    @Override // sn.y
    public final ViewManager createViewManager(ReactApplicationContext reactApplicationContext, String viewManagerName) {
        Provider provider;
        k.g(viewManagerName, "viewManagerName");
        ModuleSpec moduleSpec = (ModuleSpec) this.f21362a.get(viewManagerName);
        NativeModule nativeModule = (moduleSpec == null || (provider = moduleSpec.provider()) == null) ? null : (NativeModule) provider.get();
        if (nativeModule instanceof ViewManager) {
            return (ViewManager) nativeModule;
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // sn.c, sn.p
    public final List createViewManagers(ReactApplicationContext reactContext) {
        k.g(reactContext, "reactContext");
        int i11 = 1;
        return e.u(new ReactDrawerLayoutManager(), new ReactHorizontalScrollViewManager(null, i11, 0 == true ? 1 : 0), new ReactHorizontalScrollContainerViewManager(), new ReactProgressBarViewManager(), new ReactSwitchManager(), new ReactSafeAreaViewManager(), new SwipeRefreshLayoutManager(), new ReactImageManager(null, null, null, 7, null), new ReactModalHostManager(), new ReactTextInputManager(), fo.a.f() ? new PreparedLayoutTextViewManager(0 == true ? 1 : 0, i11, 0 == true ? 1 : 0) : new ReactTextViewManager(null, 1, null), new SelectableTextViewManager(null, 1, null), new ReactViewManager(), new ReactVirtualViewManager(), new ReactUnimplementedViewManager());
    }

    @Override // sn.c
    public final NativeModule getModule(String name, ReactApplicationContext reactContext) {
        k.g(name, "name");
        k.g(reactContext, "reactContext");
        if (name.equals("AccessibilityInfo")) {
            return new AccessibilityInfoModule(reactContext);
        }
        if (name.equals("Appearance")) {
            return new AppearanceModule(reactContext, null, 2, null);
        }
        if (name.equals("AppState")) {
            return new AppStateModule(reactContext);
        }
        if (name.equals("BlobModule")) {
            return new BlobModule(reactContext);
        }
        if (name.equals("DevLoadingView")) {
            return new DevLoadingModule(reactContext);
        }
        FileReaderModule.Companion.getClass();
        if (name.equals(FileReaderModule.NAME)) {
            return new FileReaderModule(reactContext);
        }
        if (name.equals("Clipboard")) {
            return new ClipboardModule(reactContext);
        }
        if (name.equals("DialogManagerAndroid")) {
            return new DialogModule(reactContext);
        }
        if (name.equals(FrescoModule.NAME)) {
            return new FrescoModule(reactContext, true, (i) null);
        }
        if (name.equals("I18nManager")) {
            return new I18nManagerModule(reactContext);
        }
        if (name.equals("ImageLoader")) {
            return new ImageLoaderModule(reactContext);
        }
        if (name.equals("ImageStoreManager")) {
            return new ImageStoreManager(reactContext);
        }
        if (name.equals("IntentAndroid")) {
            return new IntentModule(reactContext);
        }
        if (name.equals("NativeAnimatedModule")) {
            if (!((fo.c) fo.a.f12125a).cxxNativeAnimatedEnabled()) {
                return new NativeAnimatedModule(reactContext);
            }
        } else {
            if (name.equals("Networking")) {
                return new NetworkingModule(reactContext);
            }
            if (name.equals("PermissionsAndroid")) {
                return new PermissionsModule(reactContext);
            }
            if (name.equals("ShareModule")) {
                return new ShareModule(reactContext);
            }
            if (name.equals("StatusBarManager")) {
                return new StatusBarModule(reactContext);
            }
            if (name.equals("SoundManager")) {
                return new SoundManagerModule(reactContext);
            }
            if (name.equals("ToastAndroid")) {
                return new ToastModule(reactContext);
            }
            if (name.equals("Vibration")) {
                return new VibrationModule(reactContext);
            }
            if (name.equals("WebSocketModule")) {
                return new WebSocketModule(reactContext);
            }
            if (name.equals("ReactDevToolsSettingsManager")) {
                return new ReactDevToolsSettingsManagerModule(reactContext);
            }
            if (name.equals("ReactDevToolsRuntimeSettingsModule")) {
                return new ReactDevToolsRuntimeSettingsModule(reactContext);
            }
        }
        return null;
    }

    @Override // sn.c
    public final jo.a getReactModuleInfoProvider() {
        Class[] clsArr = (Class[]) m30.k.e0(new Class[]{AccessibilityInfoModule.class, AppearanceModule.class, AppStateModule.class, BlobModule.class, DevLoadingModule.class, FileReaderModule.class, ClipboardModule.class, DialogModule.class, FrescoModule.class, I18nManagerModule.class, ImageLoaderModule.class, ImageStoreManager.class, IntentModule.class, ((fo.c) fo.a.f12125a).cxxNativeAnimatedEnabled() ? null : NativeAnimatedModule.class, NetworkingModule.class, PermissionsModule.class, ReactDevToolsSettingsManagerModule.class, ReactDevToolsRuntimeSettingsModule.class, ShareModule.class, StatusBarModule.class, SoundManagerModule.class, ToastModule.class, VibrationModule.class, WebSocketModule.class}).toArray(new Class[0]);
        ArrayList<Class> arrayList = new ArrayList();
        for (Class cls : clsArr) {
            if (cls.isAnnotationPresent(io.a.class)) {
                arrayList.add(cls);
            }
        }
        int iP0 = x.p0(l.W(arrayList, 10));
        if (iP0 < 16) {
            iP0 = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(iP0);
        for (Class cls2 : arrayList) {
            Annotation annotation = cls2.getAnnotation(io.a.class);
            if (annotation == null) {
                throw new IllegalStateException("Required value was null.");
            }
            io.a aVar = (io.a) annotation;
            String strName = aVar.name();
            String strName2 = aVar.name();
            String name = cls2.getName();
            boolean zCanOverrideExistingModule = aVar.canOverrideExistingModule();
            boolean zNeedsEagerInit = aVar.needsEagerInit();
            aVar.isCxxModule();
            linkedHashMap.put(strName, new ReactModuleInfo(strName2, name, zCanOverrideExistingModule, zNeedsEagerInit, TurboModule.class.isAssignableFrom(cls2)));
        }
        return new d(linkedHashMap, 3);
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Object, java.util.Map] */
    @Override // sn.y
    public final Collection getViewManagerNames(ReactApplicationContext reactApplicationContext) {
        return this.f21362a.keySet();
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.Object, java.util.Map] */
    @Override // sn.c
    public final List getViewManagers(ReactApplicationContext reactContext) {
        k.g(reactContext, "reactContext");
        return q.S0(this.f21362a.values());
    }
}
