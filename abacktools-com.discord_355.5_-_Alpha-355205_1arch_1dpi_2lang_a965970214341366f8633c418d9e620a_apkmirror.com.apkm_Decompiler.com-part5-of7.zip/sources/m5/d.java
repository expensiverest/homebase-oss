package m5;

import android.text.Layout;
import android.text.SpannableStringBuilder;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a4.h f21091c = new a4.h(19);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m3.b f21092a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f21093b;

    public d(SpannableStringBuilder spannableStringBuilder, Layout.Alignment alignment, float f3, int i11, float f11, int i12, boolean z11, int i13, int i14) {
        this.f21092a = new m3.b(spannableStringBuilder, alignment, null, null, f3, 0, i11, f11, i12, androidx.customview.widget.b.INVALID_ID, -3.4028235E38f, -3.4028235E38f, -3.4028235E38f, z11, z11 ? i13 : -16777216, androidx.customview.widget.b.INVALID_ID, 0.0f, 0);
        this.f21093b = i14;
    }
}
