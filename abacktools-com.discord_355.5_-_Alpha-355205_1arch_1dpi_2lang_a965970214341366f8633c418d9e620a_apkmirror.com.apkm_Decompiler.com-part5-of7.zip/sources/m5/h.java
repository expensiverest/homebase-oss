package m5;

import io.sentry.android.core.n0;
import java.util.ArrayDeque;
import l5.j;
import n3.l0;

/* JADX INFO: loaded from: classes.dex */
public abstract class h implements l5.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayDeque f21125a = new ArrayDeque();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayDeque f21126b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayDeque f21127c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public g f21128d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f21129e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f21130f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f21131g;

    public h() {
        for (int i11 = 0; i11 < 10; i11++) {
            this.f21125a.add(new g(1));
        }
        this.f21126b = new ArrayDeque();
        for (int i12 = 0; i12 < 2; i12++) {
            ArrayDeque arrayDeque = this.f21126b;
            n0 n0Var = new n0(19, this);
            l5.c cVar = new l5.c();
            cVar.J = n0Var;
            arrayDeque.add(cVar);
        }
        this.f21127c = new ArrayDeque();
        this.f21131g = -9223372036854775807L;
    }

    @Override // l5.e
    public final void a(long j6) {
        this.f21129e = j6;
    }

    @Override // u3.b
    public final Object c() {
        oq.a.z(this.f21128d == null);
        ArrayDeque arrayDeque = this.f21125a;
        if (arrayDeque.isEmpty()) {
            return null;
        }
        g gVar = (g) arrayDeque.pollFirst();
        this.f21128d = gVar;
        return gVar;
    }

    @Override // u3.b
    public final void d(long j6) {
        this.f21131g = j6;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0033  */
    @Override // u3.b
    public final void e(j jVar) {
        oq.a.n(jVar == this.f21128d);
        g gVar = (g) jVar;
        if (gVar.g(4)) {
            long j6 = this.f21130f;
            this.f21130f = 1 + j6;
            gVar.M = j6;
            this.f21127c.add(gVar);
        } else {
            long j11 = gVar.y;
            if (j11 != Long.MIN_VALUE) {
                long j12 = this.f21131g;
                if (j12 == -9223372036854775807L || j11 >= j12) {
                    long j13 = this.f21130f;
                    this.f21130f = 1 + j13;
                    gVar.M = j13;
                    this.f21127c.add(gVar);
                } else {
                    gVar.o();
                    this.f21125a.add(gVar);
                }
            } else {
                long j14 = this.f21130f;
                this.f21130f = 1 + j14;
                gVar.M = j14;
                this.f21127c.add(gVar);
            }
        }
        this.f21128d = null;
    }

    public abstract i f();

    @Override // u3.b
    public void flush() {
        ArrayDeque arrayDeque;
        this.f21130f = 0L;
        this.f21129e = 0L;
        while (true) {
            ArrayDeque arrayDeque2 = this.f21127c;
            boolean zIsEmpty = arrayDeque2.isEmpty();
            arrayDeque = this.f21125a;
            if (zIsEmpty) {
                break;
            }
            g gVar = (g) arrayDeque2.poll();
            String str = l0.f22358a;
            gVar.o();
            arrayDeque.add(gVar);
        }
        g gVar2 = this.f21128d;
        if (gVar2 != null) {
            gVar2.o();
            arrayDeque.add(gVar2);
            this.f21128d = null;
        }
    }

    public abstract void g(g gVar);

    @Override // u3.b
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public l5.c b() {
        ArrayDeque arrayDeque = this.f21126b;
        if (arrayDeque.isEmpty()) {
            return null;
        }
        while (true) {
            ArrayDeque arrayDeque2 = this.f21127c;
            if (arrayDeque2.isEmpty()) {
                return null;
            }
            g gVar = (g) arrayDeque2.peek();
            String str = l0.f22358a;
            if (gVar.y > this.f21129e) {
                return null;
            }
            g gVar2 = (g) arrayDeque2.poll();
            boolean zG = gVar2.g(4);
            ArrayDeque arrayDeque3 = this.f21125a;
            if (zG) {
                l5.c cVar = (l5.c) arrayDeque.pollFirst();
                cVar.a(4);
                gVar2.o();
                arrayDeque3.add(gVar2);
                return cVar;
            }
            g(gVar2);
            if (i()) {
                i iVarF = f();
                l5.c cVar2 = (l5.c) arrayDeque.pollFirst();
                long j6 = gVar2.y;
                cVar2.f30834i = j6;
                cVar2.f20070w = iVarF;
                cVar2.f20071x = j6;
                gVar2.o();
                arrayDeque3.add(gVar2);
                return cVar2;
            }
            gVar2.o();
            arrayDeque3.add(gVar2);
        }
    }

    public abstract boolean i();

    @Override // u3.b
    public void release() {
    }
}
