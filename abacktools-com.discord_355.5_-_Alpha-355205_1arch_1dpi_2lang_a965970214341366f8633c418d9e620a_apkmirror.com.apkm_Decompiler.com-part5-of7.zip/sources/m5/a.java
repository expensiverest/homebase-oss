package m5;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f21064a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f21065b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f21066c;

    public a(int i11, boolean z11, int i12) {
        this.f21064a = i11;
        this.f21065b = z11;
        this.f21066c = i12;
    }
}
