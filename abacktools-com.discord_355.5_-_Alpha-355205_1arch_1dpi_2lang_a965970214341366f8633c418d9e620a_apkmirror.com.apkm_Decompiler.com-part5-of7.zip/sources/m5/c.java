package m5;

import com.facebook.imageutils.JfifUtil;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import n3.x;

/* JADX INFO: loaded from: classes.dex */
public final class c extends h {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f21077i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f21078j;
    public final int k;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public List f21081o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public List f21082p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f21083q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f21084r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f21085s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f21086t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public byte f21087u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public byte f21088v;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f21090x;
    public long y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final int[] f21075z = {11, 1, 3, 12, 14, 5, 7, 9};
    public static final int[] A = {0, 4, 8, 12, 16, 20, 24, 28};
    public static final int[] B = {-1, -16711936, -16776961, -16711681, -65536, -256, -65281};
    public static final int[] C = {32, 33, 34, 35, 36, 37, 38, 39, 40, 41, JfifUtil.MARKER_APP1, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632};
    public static final int[] D = {174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251};
    public static final int[] E = {193, 201, 211, JfifUtil.MARKER_SOS, 220, 252, 8216, 161, 42, 39, 8212, 169, 8480, 8226, 8220, 8221, JfifUtil.MARKER_SOFn, 194, 199, 200, 202, 203, 235, 206, 207, 239, 212, JfifUtil.MARKER_EOI, 249, 219, 171, 187};
    public static final int[] F = {195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9474, 197, 229, JfifUtil.MARKER_SOI, 248, 9484, 9488, 9492, 9496};
    public static final boolean[] G = {false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false};

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final x f21076h = new x();

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f21079m = new ArrayList();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public b f21080n = new b(0, 4);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f21089w = 0;
    public final long l = 16000000;

    public c(String str, int i11) {
        this.f21077i = "application/x-mp4-cea-608".equals(str) ? 2 : 3;
        if (i11 == 1) {
            this.k = 0;
            this.f21078j = 0;
        } else if (i11 == 2) {
            this.k = 1;
            this.f21078j = 0;
        } else if (i11 == 3) {
            this.k = 0;
            this.f21078j = 1;
        } else if (i11 != 4) {
            n3.b.l("Cea608Decoder", "Invalid channel. Defaulting to CC1.");
            this.k = 0;
            this.f21078j = 0;
        } else {
            this.k = 1;
            this.f21078j = 1;
        }
        l(0);
        k();
        this.f21090x = true;
        this.y = -9223372036854775807L;
    }

    @Override // m5.h
    public final i f() {
        List list = this.f21081o;
        this.f21082p = list;
        list.getClass();
        return new i(list);
    }

    @Override // m5.h, u3.b
    public final void flush() {
        super.flush();
        this.f21081o = null;
        this.f21082p = null;
        l(0);
        this.f21084r = 4;
        this.f21080n.f21074h = 4;
        k();
        this.f21085s = false;
        this.f21086t = false;
        this.f21087u = (byte) 0;
        this.f21088v = (byte) 0;
        this.f21089w = 0;
        this.f21090x = true;
        this.y = -9223372036854775807L;
    }

    /* JADX WARN: Code duplicated, block: B:121:0x019a  */
    /* JADX WARN: Code duplicated, block: B:123:0x01a0 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:127:0x01ae A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:128:0x01b0  */
    /* JADX WARN: Code duplicated, block: B:131:0x01b6  */
    /* JADX WARN: Code duplicated, block: B:133:0x01ba  */
    /* JADX WARN: Code duplicated, block: B:134:0x01bd  */
    /* JADX WARN: Code duplicated, block: B:137:0x01c3 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:138:0x01c5  */
    /* JADX WARN: Code duplicated, block: B:140:0x01ca  */
    /* JADX WARN: Code duplicated, block: B:141:0x01d5  */
    /* JADX WARN: Code duplicated, block: B:142:0x01da  */
    /* JADX WARN: Code duplicated, block: B:143:0x01dc  */
    /* JADX WARN: Code duplicated, block: B:148:0x0207 A[LOOP:1: B:146:0x0201->B:148:0x0207, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:149:0x020b  */
    /* JADX WARN: Code duplicated, block: B:151:0x0211 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:152:0x0213  */
    /* JADX WARN: Code duplicated, block: B:153:0x0218  */
    /* JADX WARN: Code duplicated, block: B:154:0x021f  */
    /* JADX WARN: Code duplicated, block: B:155:0x022a  */
    /* JADX WARN: Code duplicated, block: B:156:0x0235  */
    /* JADX WARN: Code duplicated, block: B:157:0x0240  */
    /* JADX WARN: Code duplicated, block: B:158:0x0245  */
    /* JADX WARN: Code duplicated, block: B:159:0x024a  */
    /* JADX WARN: Code duplicated, block: B:161:0x025b  */
    /* JADX WARN: Code duplicated, block: B:179:0x0085 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:180:0x0080 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:181:0x007e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:182:0x00ae A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:183:0x00bd A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:188:0x0014 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:189:0x0014 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:191:0x0014 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:26:0x0059  */
    /* JADX WARN: Code duplicated, block: B:49:0x0092  */
    /* JADX WARN: Code duplicated, block: B:51:0x0096  */
    /* JADX WARN: Code duplicated, block: B:52:0x0098  */
    /* JADX WARN: Code duplicated, block: B:58:0x00a6 A[FALL_THROUGH] */
    /* JADX WARN: Code duplicated, block: B:64:0x00b2  */
    /* JADX WARN: Code duplicated, block: B:68:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:73:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:75:0x00de  */
    /* JADX WARN: Code duplicated, block: B:83:0x0100 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:84:0x0102  */
    /* JADX WARN: Code duplicated, block: B:91:0x012a  */
    /* JADX WARN: Code duplicated, block: B:93:0x012e  */
    @Override // m5.h
    public final void g(g gVar) {
        boolean z11;
        int i11;
        int[] iArr;
        int i12;
        int i13;
        int i14;
        ArrayList arrayList;
        int iMin;
        ByteBuffer byteBuffer = gVar.f30832w;
        byteBuffer.getClass();
        byte[] bArrArray = byteBuffer.array();
        int iLimit = byteBuffer.limit();
        x xVar = this.f21076h;
        xVar.L(bArrArray, iLimit);
        boolean z12 = false;
        while (true) {
            int iA = xVar.a();
            int i15 = this.f21077i;
            if (iA < i15) {
                break;
            }
            int iA2 = i15 == 2 ? -4 : xVar.A();
            int iA3 = xVar.A();
            int iA4 = xVar.A();
            if ((iA2 & 2) == 0 && (iA2 & 1) == this.f21078j) {
                byte b11 = (byte) (iA3 & 127);
                byte b12 = (byte) (iA4 & 127);
                if (b11 != 0 || b12 != 0) {
                    boolean z13 = this.f21085s;
                    if ((iA2 & 4) == 4) {
                        boolean[] zArr = G;
                        if (zArr[iA3] && zArr[iA4]) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                    } else {
                        z11 = false;
                    }
                    this.f21085s = z11;
                    if (!z11 || (b11 & 240) != 16) {
                        this.f21086t = false;
                        if (!z11) {
                            if (1 > b11 && b11 <= 15) {
                                this.f21090x = false;
                            } else if ((b11 & 246) == 20) {
                                if (b12 == 32 && b12 != 47) {
                                    switch (b12) {
                                        default:
                                            switch (b12) {
                                                case 42:
                                                case 43:
                                                    this.f21090x = false;
                                                    break;
                                            }
                                        case 37:
                                        case 38:
                                        case 39:
                                            this.f21090x = true;
                                            break;
                                    }
                                } else {
                                    this.f21090x = true;
                                }
                            }
                            if (this.f21090x) {
                                i11 = b11 & 224;
                                if (i11 == 0) {
                                    this.f21089w = (b11 >> 3) & 1;
                                }
                                if (this.f21089w != this.k) {
                                    if (i11 == 0) {
                                        i12 = b11 & 247;
                                        if (i12 == 17 || (b12 & 240) != 48) {
                                            i13 = b11 & 246;
                                            if (i13 != 18 && (b12 & 224) == 32) {
                                                this.f21080n.b();
                                                this.f21080n.a((char) ((b11 & 1) == 0 ? E[b12 & 31] : F[b12 & 31]));
                                            } else if (i12 != 17 && (b12 & 240) == 32) {
                                                this.f21080n.a(' ');
                                                boolean z14 = (b12 & 1) == 1;
                                                b bVar = this.f21080n;
                                                bVar.f21067a.add(new a((b12 >> 1) & 7, z14, bVar.f21069c.length()));
                                            } else if ((b11 & 240) != 16 && (b12 & 192) == 64) {
                                                int i16 = f21075z[b11 & 7];
                                                if ((b12 & 32) != 0) {
                                                    i16++;
                                                }
                                                b bVar2 = this.f21080n;
                                                if (i16 != bVar2.f21070d) {
                                                    if (this.f21083q != 1 && !bVar2.e()) {
                                                        b bVar3 = new b(this.f21083q, this.f21084r);
                                                        this.f21080n = bVar3;
                                                        this.f21079m.add(bVar3);
                                                    }
                                                    this.f21080n.f21070d = i16;
                                                }
                                                boolean z15 = (b12 & 16) == 16;
                                                boolean z16 = (b12 & 1) == 1;
                                                int i17 = (b12 >> 1) & 7;
                                                b bVar4 = this.f21080n;
                                                bVar4.f21067a.add(new a(z15 ? 8 : i17, z16, bVar4.f21069c.length()));
                                                if (z15) {
                                                    this.f21080n.f21071e = A[i17];
                                                }
                                            } else if (i12 != 23 && b12 >= 33 && b12 <= 35) {
                                                this.f21080n.f21072f = b12 - 32;
                                            } else if (i13 == 20 && (b12 & 240) == 32) {
                                                if (b12 == 32) {
                                                    l(2);
                                                } else if (b12 != 41) {
                                                    switch (b12) {
                                                        case 37:
                                                            l(1);
                                                            this.f21084r = 2;
                                                            this.f21080n.f21074h = 2;
                                                            break;
                                                        case 38:
                                                            l(1);
                                                            this.f21084r = 3;
                                                            this.f21080n.f21074h = 3;
                                                            break;
                                                        case 39:
                                                            l(1);
                                                            this.f21084r = 4;
                                                            this.f21080n.f21074h = 4;
                                                            break;
                                                        default:
                                                            i14 = this.f21083q;
                                                            if (i14 != 0) {
                                                                if (b12 != 33) {
                                                                    switch (b12) {
                                                                        case 44:
                                                                            this.f21081o = Collections.EMPTY_LIST;
                                                                            if (i14 != 1 || i14 == 3) {
                                                                                k();
                                                                            }
                                                                            break;
                                                                        case 45:
                                                                            if (i14 == 1 && !this.f21080n.e()) {
                                                                                b bVar5 = this.f21080n;
                                                                                arrayList = bVar5.f21068b;
                                                                                arrayList.add(bVar5.d());
                                                                                bVar5.f21069c.setLength(0);
                                                                                bVar5.f21067a.clear();
                                                                                iMin = Math.min(bVar5.f21074h, bVar5.f21070d);
                                                                                while (arrayList.size() >= iMin) {
                                                                                    arrayList.remove(0);
                                                                                }
                                                                            }
                                                                            break;
                                                                        case 46:
                                                                            k();
                                                                            break;
                                                                        case 47:
                                                                            this.f21081o = j();
                                                                            k();
                                                                            break;
                                                                    }
                                                                } else {
                                                                    this.f21080n.b();
                                                                    break;
                                                                }
                                                            }
                                                            break;
                                                    }
                                                } else {
                                                    l(3);
                                                }
                                            }
                                        } else {
                                            this.f21080n.a((char) D[b12 & 15]);
                                        }
                                    } else {
                                        b bVar6 = this.f21080n;
                                        iArr = C;
                                        bVar6.a((char) iArr[(b11 & 127) - 32]);
                                        if ((b12 & 224) != 0) {
                                            this.f21080n.a((char) iArr[(b12 & 127) - 32]);
                                        }
                                    }
                                    z12 = true;
                                }
                            }
                        } else if (z13) {
                            k();
                            z12 = true;
                        }
                    } else if (this.f21086t && this.f21087u == b11 && this.f21088v == b12) {
                        this.f21086t = false;
                    } else {
                        this.f21086t = true;
                        this.f21087u = b11;
                        this.f21088v = b12;
                        if (!z11) {
                            if (1 > b11) {
                                if ((b11 & 246) == 20) {
                                    if (b12 == 32) {
                                        this.f21090x = true;
                                    } else {
                                        this.f21090x = true;
                                    }
                                }
                            } else if ((b11 & 246) == 20) {
                                if (b12 == 32) {
                                    this.f21090x = true;
                                } else {
                                    this.f21090x = true;
                                }
                            }
                            if (this.f21090x) {
                                i11 = b11 & 224;
                                if (i11 == 0) {
                                    this.f21089w = (b11 >> 3) & 1;
                                }
                                if (this.f21089w != this.k) {
                                    if (i11 == 0) {
                                        i12 = b11 & 247;
                                        if (i12 == 17) {
                                            i13 = b11 & 246;
                                            if (i13 != 18) {
                                                if (i12 != 17) {
                                                    if ((b11 & 240) != 16) {
                                                        if (i12 != 23) {
                                                            if (i13 == 20) {
                                                                if (b12 == 32) {
                                                                    l(2);
                                                                } else if (b12 != 41) {
                                                                    switch (b12) {
                                                                        case 37:
                                                                            l(1);
                                                                            this.f21084r = 2;
                                                                            this.f21080n.f21074h = 2;
                                                                            break;
                                                                        case 38:
                                                                            l(1);
                                                                            this.f21084r = 3;
                                                                            this.f21080n.f21074h = 3;
                                                                            break;
                                                                        case 39:
                                                                            l(1);
                                                                            this.f21084r = 4;
                                                                            this.f21080n.f21074h = 4;
                                                                            break;
                                                                        default:
                                                                            i14 = this.f21083q;
                                                                            if (i14 != 0) {
                                                                                if (b12 != 33) {
                                                                                    switch (b12) {
                                                                                        case 44:
                                                                                            this.f21081o = Collections.EMPTY_LIST;
                                                                                            if (i14 != 1) {
                                                                                                k();
                                                                                            } else {
                                                                                                k();
                                                                                            }
                                                                                            break;
                                                                                        case 45:
                                                                                            if (i14 == 1) {
                                                                                                b bVar7 = this.f21080n;
                                                                                                arrayList = bVar7.f21068b;
                                                                                                arrayList.add(bVar7.d());
                                                                                                bVar7.f21069c.setLength(0);
                                                                                                bVar7.f21067a.clear();
                                                                                                iMin = Math.min(bVar7.f21074h, bVar7.f21070d);
                                                                                                while (arrayList.size() >= iMin) {
                                                                                                    arrayList.remove(0);
                                                                                                }
                                                                                            }
                                                                                            break;
                                                                                        case 46:
                                                                                            k();
                                                                                            break;
                                                                                        case 47:
                                                                                            this.f21081o = j();
                                                                                            k();
                                                                                            break;
                                                                                    }
                                                                                } else {
                                                                                    this.f21080n.b();
                                                                                    break;
                                                                                }
                                                                            }
                                                                            break;
                                                                    }
                                                                } else {
                                                                    l(3);
                                                                }
                                                            }
                                                        } else if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar8 = this.f21080n;
                                                                                            arrayList = bVar8.f21068b;
                                                                                            arrayList.add(bVar8.d());
                                                                                            bVar8.f21069c.setLength(0);
                                                                                            bVar8.f21067a.clear();
                                                                                            iMin = Math.min(bVar8.f21074h, bVar8.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i12 != 23) {
                                                        if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar9 = this.f21080n;
                                                                                            arrayList = bVar9.f21068b;
                                                                                            arrayList.add(bVar9.d());
                                                                                            bVar9.f21069c.setLength(0);
                                                                                            bVar9.f21067a.clear();
                                                                                            iMin = Math.min(bVar9.f21074h, bVar9.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar10 = this.f21080n;
                                                                                        arrayList = bVar10.f21068b;
                                                                                        arrayList.add(bVar10.d());
                                                                                        bVar10.f21069c.setLength(0);
                                                                                        bVar10.f21067a.clear();
                                                                                        iMin = Math.min(bVar10.f21074h, bVar10.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if ((b11 & 240) != 16) {
                                                    if (i12 != 23) {
                                                        if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar11 = this.f21080n;
                                                                                            arrayList = bVar11.f21068b;
                                                                                            arrayList.add(bVar11.d());
                                                                                            bVar11.f21069c.setLength(0);
                                                                                            bVar11.f21067a.clear();
                                                                                            iMin = Math.min(bVar11.f21074h, bVar11.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar12 = this.f21080n;
                                                                                        arrayList = bVar12.f21068b;
                                                                                        arrayList.add(bVar12.d());
                                                                                        bVar12.f21069c.setLength(0);
                                                                                        bVar12.f21067a.clear();
                                                                                        iMin = Math.min(bVar12.f21074h, bVar12.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i12 != 23) {
                                                    if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar13 = this.f21080n;
                                                                                        arrayList = bVar13.f21068b;
                                                                                        arrayList.add(bVar13.d());
                                                                                        bVar13.f21069c.setLength(0);
                                                                                        bVar13.f21067a.clear();
                                                                                        iMin = Math.min(bVar13.f21074h, bVar13.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar14 = this.f21080n;
                                                                                    arrayList = bVar14.f21068b;
                                                                                    arrayList.add(bVar14.d());
                                                                                    bVar14.f21069c.setLength(0);
                                                                                    bVar14.f21067a.clear();
                                                                                    iMin = Math.min(bVar14.f21074h, bVar14.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if (i12 != 17) {
                                                if ((b11 & 240) != 16) {
                                                    if (i12 != 23) {
                                                        if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar15 = this.f21080n;
                                                                                            arrayList = bVar15.f21068b;
                                                                                            arrayList.add(bVar15.d());
                                                                                            bVar15.f21069c.setLength(0);
                                                                                            bVar15.f21067a.clear();
                                                                                            iMin = Math.min(bVar15.f21074h, bVar15.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar16 = this.f21080n;
                                                                                        arrayList = bVar16.f21068b;
                                                                                        arrayList.add(bVar16.d());
                                                                                        bVar16.f21069c.setLength(0);
                                                                                        bVar16.f21067a.clear();
                                                                                        iMin = Math.min(bVar16.f21074h, bVar16.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i12 != 23) {
                                                    if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar17 = this.f21080n;
                                                                                        arrayList = bVar17.f21068b;
                                                                                        arrayList.add(bVar17.d());
                                                                                        bVar17.f21069c.setLength(0);
                                                                                        bVar17.f21067a.clear();
                                                                                        iMin = Math.min(bVar17.f21074h, bVar17.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar18 = this.f21080n;
                                                                                    arrayList = bVar18.f21068b;
                                                                                    arrayList.add(bVar18.d());
                                                                                    bVar18.f21069c.setLength(0);
                                                                                    bVar18.f21067a.clear();
                                                                                    iMin = Math.min(bVar18.f21074h, bVar18.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if ((b11 & 240) != 16) {
                                                if (i12 != 23) {
                                                    if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar19 = this.f21080n;
                                                                                        arrayList = bVar19.f21068b;
                                                                                        arrayList.add(bVar19.d());
                                                                                        bVar19.f21069c.setLength(0);
                                                                                        bVar19.f21067a.clear();
                                                                                        iMin = Math.min(bVar19.f21074h, bVar19.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar110 = this.f21080n;
                                                                                    arrayList = bVar110.f21068b;
                                                                                    arrayList.add(bVar110.d());
                                                                                    bVar110.f21069c.setLength(0);
                                                                                    bVar110.f21067a.clear();
                                                                                    iMin = Math.min(bVar110.f21074h, bVar110.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if (i12 != 23) {
                                                if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar111 = this.f21080n;
                                                                                    arrayList = bVar111.f21068b;
                                                                                    arrayList.add(bVar111.d());
                                                                                    bVar111.f21069c.setLength(0);
                                                                                    bVar111.f21067a.clear();
                                                                                    iMin = Math.min(bVar111.f21074h, bVar111.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if (i13 == 20) {
                                                if (b12 == 32) {
                                                    l(2);
                                                } else if (b12 != 41) {
                                                    switch (b12) {
                                                        case 37:
                                                            l(1);
                                                            this.f21084r = 2;
                                                            this.f21080n.f21074h = 2;
                                                            break;
                                                        case 38:
                                                            l(1);
                                                            this.f21084r = 3;
                                                            this.f21080n.f21074h = 3;
                                                            break;
                                                        case 39:
                                                            l(1);
                                                            this.f21084r = 4;
                                                            this.f21080n.f21074h = 4;
                                                            break;
                                                        default:
                                                            i14 = this.f21083q;
                                                            if (i14 != 0) {
                                                                if (b12 != 33) {
                                                                    switch (b12) {
                                                                        case 44:
                                                                            this.f21081o = Collections.EMPTY_LIST;
                                                                            if (i14 != 1) {
                                                                                k();
                                                                            } else {
                                                                                k();
                                                                            }
                                                                            break;
                                                                        case 45:
                                                                            if (i14 == 1) {
                                                                                b bVar112 = this.f21080n;
                                                                                arrayList = bVar112.f21068b;
                                                                                arrayList.add(bVar112.d());
                                                                                bVar112.f21069c.setLength(0);
                                                                                bVar112.f21067a.clear();
                                                                                iMin = Math.min(bVar112.f21074h, bVar112.f21070d);
                                                                                while (arrayList.size() >= iMin) {
                                                                                    arrayList.remove(0);
                                                                                }
                                                                            }
                                                                            break;
                                                                        case 46:
                                                                            k();
                                                                            break;
                                                                        case 47:
                                                                            this.f21081o = j();
                                                                            k();
                                                                            break;
                                                                    }
                                                                } else {
                                                                    this.f21080n.b();
                                                                    break;
                                                                }
                                                            }
                                                            break;
                                                    }
                                                } else {
                                                    l(3);
                                                }
                                            }
                                        } else {
                                            i13 = b11 & 246;
                                            if (i13 != 18) {
                                                if (i12 != 17) {
                                                    if ((b11 & 240) != 16) {
                                                        if (i12 != 23) {
                                                            if (i13 == 20) {
                                                                if (b12 == 32) {
                                                                    l(2);
                                                                } else if (b12 != 41) {
                                                                    switch (b12) {
                                                                        case 37:
                                                                            l(1);
                                                                            this.f21084r = 2;
                                                                            this.f21080n.f21074h = 2;
                                                                            break;
                                                                        case 38:
                                                                            l(1);
                                                                            this.f21084r = 3;
                                                                            this.f21080n.f21074h = 3;
                                                                            break;
                                                                        case 39:
                                                                            l(1);
                                                                            this.f21084r = 4;
                                                                            this.f21080n.f21074h = 4;
                                                                            break;
                                                                        default:
                                                                            i14 = this.f21083q;
                                                                            if (i14 != 0) {
                                                                                if (b12 != 33) {
                                                                                    switch (b12) {
                                                                                        case 44:
                                                                                            this.f21081o = Collections.EMPTY_LIST;
                                                                                            if (i14 != 1) {
                                                                                                k();
                                                                                            } else {
                                                                                                k();
                                                                                            }
                                                                                            break;
                                                                                        case 45:
                                                                                            if (i14 == 1) {
                                                                                                b bVar113 = this.f21080n;
                                                                                                arrayList = bVar113.f21068b;
                                                                                                arrayList.add(bVar113.d());
                                                                                                bVar113.f21069c.setLength(0);
                                                                                                bVar113.f21067a.clear();
                                                                                                iMin = Math.min(bVar113.f21074h, bVar113.f21070d);
                                                                                                while (arrayList.size() >= iMin) {
                                                                                                    arrayList.remove(0);
                                                                                                }
                                                                                            }
                                                                                            break;
                                                                                        case 46:
                                                                                            k();
                                                                                            break;
                                                                                        case 47:
                                                                                            this.f21081o = j();
                                                                                            k();
                                                                                            break;
                                                                                    }
                                                                                } else {
                                                                                    this.f21080n.b();
                                                                                    break;
                                                                                }
                                                                            }
                                                                            break;
                                                                    }
                                                                } else {
                                                                    l(3);
                                                                }
                                                            }
                                                        } else if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar114 = this.f21080n;
                                                                                            arrayList = bVar114.f21068b;
                                                                                            arrayList.add(bVar114.d());
                                                                                            bVar114.f21069c.setLength(0);
                                                                                            bVar114.f21067a.clear();
                                                                                            iMin = Math.min(bVar114.f21074h, bVar114.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i12 != 23) {
                                                        if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar115 = this.f21080n;
                                                                                            arrayList = bVar115.f21068b;
                                                                                            arrayList.add(bVar115.d());
                                                                                            bVar115.f21069c.setLength(0);
                                                                                            bVar115.f21067a.clear();
                                                                                            iMin = Math.min(bVar115.f21074h, bVar115.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar116 = this.f21080n;
                                                                                        arrayList = bVar116.f21068b;
                                                                                        arrayList.add(bVar116.d());
                                                                                        bVar116.f21069c.setLength(0);
                                                                                        bVar116.f21067a.clear();
                                                                                        iMin = Math.min(bVar116.f21074h, bVar116.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if ((b11 & 240) != 16) {
                                                    if (i12 != 23) {
                                                        if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar117 = this.f21080n;
                                                                                            arrayList = bVar117.f21068b;
                                                                                            arrayList.add(bVar117.d());
                                                                                            bVar117.f21069c.setLength(0);
                                                                                            bVar117.f21067a.clear();
                                                                                            iMin = Math.min(bVar117.f21074h, bVar117.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar118 = this.f21080n;
                                                                                        arrayList = bVar118.f21068b;
                                                                                        arrayList.add(bVar118.d());
                                                                                        bVar118.f21069c.setLength(0);
                                                                                        bVar118.f21067a.clear();
                                                                                        iMin = Math.min(bVar118.f21074h, bVar118.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i12 != 23) {
                                                    if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar119 = this.f21080n;
                                                                                        arrayList = bVar119.f21068b;
                                                                                        arrayList.add(bVar119.d());
                                                                                        bVar119.f21069c.setLength(0);
                                                                                        bVar119.f21067a.clear();
                                                                                        iMin = Math.min(bVar119.f21074h, bVar119.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar1110 = this.f21080n;
                                                                                    arrayList = bVar1110.f21068b;
                                                                                    arrayList.add(bVar1110.d());
                                                                                    bVar1110.f21069c.setLength(0);
                                                                                    bVar1110.f21067a.clear();
                                                                                    iMin = Math.min(bVar1110.f21074h, bVar1110.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if (i12 != 17) {
                                                if ((b11 & 240) != 16) {
                                                    if (i12 != 23) {
                                                        if (i13 == 20) {
                                                            if (b12 == 32) {
                                                                l(2);
                                                            } else if (b12 != 41) {
                                                                switch (b12) {
                                                                    case 37:
                                                                        l(1);
                                                                        this.f21084r = 2;
                                                                        this.f21080n.f21074h = 2;
                                                                        break;
                                                                    case 38:
                                                                        l(1);
                                                                        this.f21084r = 3;
                                                                        this.f21080n.f21074h = 3;
                                                                        break;
                                                                    case 39:
                                                                        l(1);
                                                                        this.f21084r = 4;
                                                                        this.f21080n.f21074h = 4;
                                                                        break;
                                                                    default:
                                                                        i14 = this.f21083q;
                                                                        if (i14 != 0) {
                                                                            if (b12 != 33) {
                                                                                switch (b12) {
                                                                                    case 44:
                                                                                        this.f21081o = Collections.EMPTY_LIST;
                                                                                        if (i14 != 1) {
                                                                                            k();
                                                                                        } else {
                                                                                            k();
                                                                                        }
                                                                                        break;
                                                                                    case 45:
                                                                                        if (i14 == 1) {
                                                                                            b bVar1111 = this.f21080n;
                                                                                            arrayList = bVar1111.f21068b;
                                                                                            arrayList.add(bVar1111.d());
                                                                                            bVar1111.f21069c.setLength(0);
                                                                                            bVar1111.f21067a.clear();
                                                                                            iMin = Math.min(bVar1111.f21074h, bVar1111.f21070d);
                                                                                            while (arrayList.size() >= iMin) {
                                                                                                arrayList.remove(0);
                                                                                            }
                                                                                        }
                                                                                        break;
                                                                                    case 46:
                                                                                        k();
                                                                                        break;
                                                                                    case 47:
                                                                                        this.f21081o = j();
                                                                                        k();
                                                                                        break;
                                                                                }
                                                                            } else {
                                                                                this.f21080n.b();
                                                                                break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            } else {
                                                                l(3);
                                                            }
                                                        }
                                                    } else if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar1112 = this.f21080n;
                                                                                        arrayList = bVar1112.f21068b;
                                                                                        arrayList.add(bVar1112.d());
                                                                                        bVar1112.f21069c.setLength(0);
                                                                                        bVar1112.f21067a.clear();
                                                                                        iMin = Math.min(bVar1112.f21074h, bVar1112.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i12 != 23) {
                                                    if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar1113 = this.f21080n;
                                                                                        arrayList = bVar1113.f21068b;
                                                                                        arrayList.add(bVar1113.d());
                                                                                        bVar1113.f21069c.setLength(0);
                                                                                        bVar1113.f21067a.clear();
                                                                                        iMin = Math.min(bVar1113.f21074h, bVar1113.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar1114 = this.f21080n;
                                                                                    arrayList = bVar1114.f21068b;
                                                                                    arrayList.add(bVar1114.d());
                                                                                    bVar1114.f21069c.setLength(0);
                                                                                    bVar1114.f21067a.clear();
                                                                                    iMin = Math.min(bVar1114.f21074h, bVar1114.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if ((b11 & 240) != 16) {
                                                if (i12 != 23) {
                                                    if (i13 == 20) {
                                                        if (b12 == 32) {
                                                            l(2);
                                                        } else if (b12 != 41) {
                                                            switch (b12) {
                                                                case 37:
                                                                    l(1);
                                                                    this.f21084r = 2;
                                                                    this.f21080n.f21074h = 2;
                                                                    break;
                                                                case 38:
                                                                    l(1);
                                                                    this.f21084r = 3;
                                                                    this.f21080n.f21074h = 3;
                                                                    break;
                                                                case 39:
                                                                    l(1);
                                                                    this.f21084r = 4;
                                                                    this.f21080n.f21074h = 4;
                                                                    break;
                                                                default:
                                                                    i14 = this.f21083q;
                                                                    if (i14 != 0) {
                                                                        if (b12 != 33) {
                                                                            switch (b12) {
                                                                                case 44:
                                                                                    this.f21081o = Collections.EMPTY_LIST;
                                                                                    if (i14 != 1) {
                                                                                        k();
                                                                                    } else {
                                                                                        k();
                                                                                    }
                                                                                    break;
                                                                                case 45:
                                                                                    if (i14 == 1) {
                                                                                        b bVar1115 = this.f21080n;
                                                                                        arrayList = bVar1115.f21068b;
                                                                                        arrayList.add(bVar1115.d());
                                                                                        bVar1115.f21069c.setLength(0);
                                                                                        bVar1115.f21067a.clear();
                                                                                        iMin = Math.min(bVar1115.f21074h, bVar1115.f21070d);
                                                                                        while (arrayList.size() >= iMin) {
                                                                                            arrayList.remove(0);
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                case 46:
                                                                                    k();
                                                                                    break;
                                                                                case 47:
                                                                                    this.f21081o = j();
                                                                                    k();
                                                                                    break;
                                                                            }
                                                                        } else {
                                                                            this.f21080n.b();
                                                                            break;
                                                                        }
                                                                    }
                                                                    break;
                                                            }
                                                        } else {
                                                            l(3);
                                                        }
                                                    }
                                                } else if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar1116 = this.f21080n;
                                                                                    arrayList = bVar1116.f21068b;
                                                                                    arrayList.add(bVar1116.d());
                                                                                    bVar1116.f21069c.setLength(0);
                                                                                    bVar1116.f21067a.clear();
                                                                                    iMin = Math.min(bVar1116.f21074h, bVar1116.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if (i12 != 23) {
                                                if (i13 == 20) {
                                                    if (b12 == 32) {
                                                        l(2);
                                                    } else if (b12 != 41) {
                                                        switch (b12) {
                                                            case 37:
                                                                l(1);
                                                                this.f21084r = 2;
                                                                this.f21080n.f21074h = 2;
                                                                break;
                                                            case 38:
                                                                l(1);
                                                                this.f21084r = 3;
                                                                this.f21080n.f21074h = 3;
                                                                break;
                                                            case 39:
                                                                l(1);
                                                                this.f21084r = 4;
                                                                this.f21080n.f21074h = 4;
                                                                break;
                                                            default:
                                                                i14 = this.f21083q;
                                                                if (i14 != 0) {
                                                                    if (b12 != 33) {
                                                                        switch (b12) {
                                                                            case 44:
                                                                                this.f21081o = Collections.EMPTY_LIST;
                                                                                if (i14 != 1) {
                                                                                    k();
                                                                                } else {
                                                                                    k();
                                                                                }
                                                                                break;
                                                                            case 45:
                                                                                if (i14 == 1) {
                                                                                    b bVar1117 = this.f21080n;
                                                                                    arrayList = bVar1117.f21068b;
                                                                                    arrayList.add(bVar1117.d());
                                                                                    bVar1117.f21069c.setLength(0);
                                                                                    bVar1117.f21067a.clear();
                                                                                    iMin = Math.min(bVar1117.f21074h, bVar1117.f21070d);
                                                                                    while (arrayList.size() >= iMin) {
                                                                                        arrayList.remove(0);
                                                                                    }
                                                                                }
                                                                                break;
                                                                            case 46:
                                                                                k();
                                                                                break;
                                                                            case 47:
                                                                                this.f21081o = j();
                                                                                k();
                                                                                break;
                                                                        }
                                                                    } else {
                                                                        this.f21080n.b();
                                                                        break;
                                                                    }
                                                                }
                                                                break;
                                                        }
                                                    } else {
                                                        l(3);
                                                    }
                                                }
                                            } else if (i13 == 20) {
                                                if (b12 == 32) {
                                                    l(2);
                                                } else if (b12 != 41) {
                                                    switch (b12) {
                                                        case 37:
                                                            l(1);
                                                            this.f21084r = 2;
                                                            this.f21080n.f21074h = 2;
                                                            break;
                                                        case 38:
                                                            l(1);
                                                            this.f21084r = 3;
                                                            this.f21080n.f21074h = 3;
                                                            break;
                                                        case 39:
                                                            l(1);
                                                            this.f21084r = 4;
                                                            this.f21080n.f21074h = 4;
                                                            break;
                                                        default:
                                                            i14 = this.f21083q;
                                                            if (i14 != 0) {
                                                                if (b12 != 33) {
                                                                    switch (b12) {
                                                                        case 44:
                                                                            this.f21081o = Collections.EMPTY_LIST;
                                                                            if (i14 != 1) {
                                                                                k();
                                                                            } else {
                                                                                k();
                                                                            }
                                                                            break;
                                                                        case 45:
                                                                            if (i14 == 1) {
                                                                                b bVar1118 = this.f21080n;
                                                                                arrayList = bVar1118.f21068b;
                                                                                arrayList.add(bVar1118.d());
                                                                                bVar1118.f21069c.setLength(0);
                                                                                bVar1118.f21067a.clear();
                                                                                iMin = Math.min(bVar1118.f21074h, bVar1118.f21070d);
                                                                                while (arrayList.size() >= iMin) {
                                                                                    arrayList.remove(0);
                                                                                }
                                                                            }
                                                                            break;
                                                                        case 46:
                                                                            k();
                                                                            break;
                                                                        case 47:
                                                                            this.f21081o = j();
                                                                            k();
                                                                            break;
                                                                    }
                                                                } else {
                                                                    this.f21080n.b();
                                                                    break;
                                                                }
                                                            }
                                                            break;
                                                    }
                                                } else {
                                                    l(3);
                                                }
                                            }
                                        }
                                    } else {
                                        b bVar20 = this.f21080n;
                                        iArr = C;
                                        bVar20.a((char) iArr[(b11 & 127) - 32]);
                                        if ((b12 & 224) != 0) {
                                            this.f21080n.a((char) iArr[(b12 & 127) - 32]);
                                        }
                                    }
                                    z12 = true;
                                }
                            }
                        } else if (z13) {
                            k();
                            z12 = true;
                        }
                    }
                }
            }
        }
        if (z12) {
            int i18 = this.f21083q;
            if (i18 == 1 || i18 == 3) {
                this.f21081o = j();
                this.y = this.f21129e;
            }
        }
    }

    @Override // m5.h, u3.b
    /* JADX INFO: renamed from: h */
    public final l5.c b() {
        l5.c cVar;
        l5.c cVarB = super.b();
        if (cVarB != null) {
            return cVarB;
        }
        long j6 = this.l;
        if (j6 == -9223372036854775807L) {
            return null;
        }
        long j11 = this.y;
        if (j11 == -9223372036854775807L || this.f21129e - j11 < j6 || (cVar = (l5.c) this.f21126b.pollFirst()) == null) {
            return null;
        }
        this.f21081o = Collections.EMPTY_LIST;
        this.y = -9223372036854775807L;
        i iVarF = f();
        long j12 = this.f21129e;
        cVar.f30834i = j12;
        cVar.f20070w = iVarF;
        cVar.f20071x = j12;
        return cVar;
    }

    @Override // m5.h
    public final boolean i() {
        return this.f21081o != this.f21082p;
    }

    public final ArrayList j() {
        ArrayList arrayList = this.f21079m;
        int size = arrayList.size();
        ArrayList arrayList2 = new ArrayList(size);
        int iMin = 2;
        for (int i11 = 0; i11 < size; i11++) {
            m3.b bVarC = ((b) arrayList.get(i11)).c(androidx.customview.widget.b.INVALID_ID);
            arrayList2.add(bVarC);
            if (bVarC != null) {
                iMin = Math.min(iMin, bVarC.f20819i);
            }
        }
        ArrayList arrayList3 = new ArrayList(size);
        for (int i12 = 0; i12 < size; i12++) {
            m3.b bVarC2 = (m3.b) arrayList2.get(i12);
            if (bVarC2 != null) {
                if (bVarC2.f20819i != iMin) {
                    bVarC2 = ((b) arrayList.get(i12)).c(iMin);
                    bVarC2.getClass();
                }
                arrayList3.add(bVarC2);
            }
        }
        return arrayList3;
    }

    public final void k() {
        b bVar = this.f21080n;
        bVar.f21073g = this.f21083q;
        bVar.f21067a.clear();
        bVar.f21068b.clear();
        bVar.f21069c.setLength(0);
        bVar.f21070d = 15;
        bVar.f21071e = 0;
        bVar.f21072f = 0;
        ArrayList arrayList = this.f21079m;
        arrayList.clear();
        arrayList.add(this.f21080n);
    }

    public final void l(int i11) {
        int i12 = this.f21083q;
        if (i12 == i11) {
            return;
        }
        this.f21083q = i11;
        if (i11 != 3) {
            k();
            if (i12 == 3 || i11 == 1 || i11 == 0) {
                this.f21081o = Collections.EMPTY_LIST;
                return;
            }
            return;
        }
        int i13 = 0;
        while (true) {
            ArrayList arrayList = this.f21079m;
            if (i13 >= arrayList.size()) {
                return;
            }
            ((b) arrayList.get(i13)).f21073g = i11;
            i13++;
        }
    }

    @Override // m5.h, u3.b
    public final void release() {
    }
}
