package m5;

import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class i implements l5.d {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f21132d;

    public /* synthetic */ i(List list) {
        this.f21132d = list;
    }

    @Override // l5.d
    public int c(long j6) {
        return j6 < 0 ? 0 : -1;
    }

    @Override // l5.d
    public long d(int i11) {
        oq.a.n(i11 == 0);
        return 0L;
    }

    @Override // l5.d
    public List e(long j6) {
        return j6 >= 0 ? this.f21132d : Collections.EMPTY_LIST;
    }

    @Override // l5.d
    public int i() {
        return 1;
    }
}
