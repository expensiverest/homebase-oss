package m5;

import l5.j;

/* JADX INFO: loaded from: classes.dex */
public final class g extends j implements Comparable {
    public long M;

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        g gVar = (g) obj;
        if (g(4) != gVar.g(4)) {
            return g(4) ? 1 : -1;
        }
        long j6 = this.y - gVar.y;
        if (j6 == 0) {
            j6 = this.M - gVar.M;
            if (j6 == 0) {
                return 0;
            }
        }
        return j6 > 0 ? 1 : -1;
    }
}
