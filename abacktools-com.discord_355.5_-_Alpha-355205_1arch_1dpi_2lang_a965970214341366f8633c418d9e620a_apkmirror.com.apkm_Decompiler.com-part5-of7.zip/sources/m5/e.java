package m5;

import android.graphics.Color;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class e {
    public static final boolean[] A;
    public static final int[] B;
    public static final int[] C;
    public static final int[] D;
    public static final int[] E;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final int f21094v = c(2, 2, 2, 0);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final int f21095w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final int[] f21096x;
    public static final int[] y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final int[] f21097z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f21098a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final SpannableStringBuilder f21099b = new SpannableStringBuilder();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f21100c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f21101d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21102e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f21103f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f21104g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f21105h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f21106i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f21107j;
    public int k;
    public int l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f21108m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f21109n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f21110o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f21111p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f21112q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f21113r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f21114s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f21115t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f21116u;

    static {
        int iC = c(0, 0, 0, 0);
        f21095w = iC;
        int iC2 = c(0, 0, 0, 3);
        f21096x = new int[]{0, 0, 0, 0, 0, 2, 0};
        y = new int[]{0, 0, 0, 0, 0, 0, 2};
        f21097z = new int[]{3, 3, 3, 3, 3, 3, 1};
        A = new boolean[]{false, false, false, true, true, true, false};
        B = new int[]{iC, iC2, iC, iC, iC2, iC, iC};
        C = new int[]{0, 1, 2, 3, 4, 3, 4};
        D = new int[]{0, 0, 0, 0, 0, 3, 3};
        E = new int[]{iC, iC, iC, iC, iC, iC2, iC2};
    }

    public e() {
        d();
    }

    /* JADX WARN: Code duplicated, block: B:9:0x001b  */
    public static int c(int i11, int i12, int i13, int i14) {
        int i15;
        oq.a.s(i11, 4);
        oq.a.s(i12, 4);
        oq.a.s(i13, 4);
        oq.a.s(i14, 4);
        if (i14 == 0 || i14 == 1) {
            i15 = 255;
        } else if (i14 == 2) {
            i15 = 127;
        } else if (i14 != 3) {
            i15 = 255;
        } else {
            i15 = 0;
        }
        return Color.argb(i15, i11 > 1 ? 255 : 0, i12 > 1 ? 255 : 0, i13 > 1 ? 255 : 0);
    }

    public final void a(char c11) {
        SpannableStringBuilder spannableStringBuilder = this.f21099b;
        if (c11 != '\n') {
            spannableStringBuilder.append(c11);
            return;
        }
        SpannableString spannableStringB = b();
        ArrayList arrayList = this.f21098a;
        arrayList.add(spannableStringB);
        spannableStringBuilder.clear();
        if (this.f21110o != -1) {
            this.f21110o = 0;
        }
        if (this.f21111p != -1) {
            this.f21111p = 0;
        }
        if (this.f21112q != -1) {
            this.f21112q = 0;
        }
        if (this.f21114s != -1) {
            this.f21114s = 0;
        }
        while (true) {
            if (arrayList.size() < this.f21107j && arrayList.size() < 15) {
                this.f21116u = arrayList.size();
                return;
            }
            arrayList.remove(0);
        }
    }

    public final SpannableString b() {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(this.f21099b);
        int length = spannableStringBuilder.length();
        if (length > 0) {
            if (this.f21110o != -1) {
                spannableStringBuilder.setSpan(new StyleSpan(2), this.f21110o, length, 33);
            }
            if (this.f21111p != -1) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), this.f21111p, length, 33);
            }
            if (this.f21112q != -1) {
                spannableStringBuilder.setSpan(new ForegroundColorSpan(this.f21113r), this.f21112q, length, 33);
            }
            if (this.f21114s != -1) {
                spannableStringBuilder.setSpan(new BackgroundColorSpan(this.f21115t), this.f21114s, length, 33);
            }
        }
        return new SpannableString(spannableStringBuilder);
    }

    public final void d() {
        this.f21098a.clear();
        this.f21099b.clear();
        this.f21110o = -1;
        this.f21111p = -1;
        this.f21112q = -1;
        this.f21114s = -1;
        this.f21116u = 0;
        this.f21100c = false;
        this.f21101d = false;
        this.f21102e = 4;
        this.f21103f = false;
        this.f21104g = 0;
        this.f21105h = 0;
        this.f21106i = 0;
        this.f21107j = 15;
        this.k = 0;
        this.l = 0;
        this.f21108m = 0;
        int i11 = f21095w;
        this.f21109n = i11;
        this.f21113r = f21094v;
        this.f21115t = i11;
    }

    public final void e(boolean z11, boolean z12) {
        int i11 = this.f21110o;
        SpannableStringBuilder spannableStringBuilder = this.f21099b;
        if (i11 != -1) {
            if (!z11) {
                spannableStringBuilder.setSpan(new StyleSpan(2), this.f21110o, spannableStringBuilder.length(), 33);
                this.f21110o = -1;
            }
        } else if (z11) {
            this.f21110o = spannableStringBuilder.length();
        }
        if (this.f21111p == -1) {
            if (z12) {
                this.f21111p = spannableStringBuilder.length();
            }
        } else {
            if (z12) {
                return;
            }
            spannableStringBuilder.setSpan(new UnderlineSpan(), this.f21111p, spannableStringBuilder.length(), 33);
            this.f21111p = -1;
        }
    }

    public final void f(int i11, int i12) {
        int i13 = this.f21112q;
        SpannableStringBuilder spannableStringBuilder = this.f21099b;
        if (i13 != -1 && this.f21113r != i11) {
            spannableStringBuilder.setSpan(new ForegroundColorSpan(this.f21113r), this.f21112q, spannableStringBuilder.length(), 33);
        }
        if (i11 != f21094v) {
            this.f21112q = spannableStringBuilder.length();
            this.f21113r = i11;
        }
        if (this.f21114s != -1 && this.f21115t != i12) {
            spannableStringBuilder.setSpan(new BackgroundColorSpan(this.f21115t), this.f21114s, spannableStringBuilder.length(), 33);
        }
        if (i12 != f21095w) {
            this.f21114s = spannableStringBuilder.length();
            this.f21115t = i12;
        }
    }
}
