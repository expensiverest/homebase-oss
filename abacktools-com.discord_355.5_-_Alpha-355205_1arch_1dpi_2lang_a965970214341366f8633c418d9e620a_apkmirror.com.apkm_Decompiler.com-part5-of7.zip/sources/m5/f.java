package m5;

import android.text.Layout;
import android.text.SpannableStringBuilder;
import com.facebook.imageutils.JfifUtil;
import hs.q;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import n3.x;

/* JADX INFO: loaded from: classes.dex */
public final class f extends h {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final x f21117h = new x();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ct.f f21118i = new ct.f(2);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f21119j = -1;
    public final int k;
    public final e[] l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public e f21120m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public List f21121n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public List f21122o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public ct.f f21123p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f21124q;

    public f(int i11, List list) {
        this.k = i11 == -1 ? 1 : i11;
        if (list != null) {
            byte[] bArr = n3.g.f22324a;
            if (list.size() == 1 && ((byte[]) list.get(0)).length == 1) {
                byte b11 = ((byte[]) list.get(0))[0];
            }
        }
        this.l = new e[8];
        for (int i12 = 0; i12 < 8; i12++) {
            this.l[i12] = new e();
        }
        this.f21120m = this.l[0];
    }

    @Override // m5.h
    public final i f() {
        List list = this.f21121n;
        this.f21122o = list;
        list.getClass();
        return new i(list);
    }

    @Override // m5.h, u3.b
    public final void flush() {
        super.flush();
        this.f21121n = null;
        this.f21122o = null;
        this.f21124q = 0;
        this.f21120m = this.l[0];
        l();
        this.f21123p = null;
    }

    @Override // m5.h
    public final void g(g gVar) {
        ByteBuffer byteBuffer = gVar.f30832w;
        byteBuffer.getClass();
        byte[] bArrArray = byteBuffer.array();
        int iLimit = byteBuffer.limit();
        x xVar = this.f21117h;
        xVar.L(bArrArray, iLimit);
        while (xVar.a() >= 3) {
            int iA = xVar.A();
            int i11 = iA & 3;
            boolean z11 = (iA & 4) == 4;
            byte bA = (byte) xVar.A();
            byte bA2 = (byte) xVar.A();
            if (i11 == 2 || i11 == 3) {
                if (z11) {
                    if (i11 == 3) {
                        j();
                        int i12 = (bA & 192) >> 6;
                        int i13 = this.f21119j;
                        if (i13 != -1 && i12 != (i13 + 1) % 4) {
                            l();
                            n3.b.l("Cea708Decoder", "Sequence number discontinuity. previous=" + this.f21119j + " current=" + i12);
                        }
                        this.f21119j = i12;
                        int i14 = bA & 63;
                        if (i14 == 0) {
                            i14 = 64;
                        }
                        ct.f fVar = new ct.f(i12, i14, 1);
                        this.f21123p = fVar;
                        byte[] bArr = fVar.f8679d;
                        fVar.f8680e = 1;
                        bArr[0] = bA2;
                    } else {
                        oq.a.n(i11 == 2);
                        ct.f fVar2 = this.f21123p;
                        if (fVar2 == null) {
                            n3.b.c("Cea708Decoder", "Encountered DTVCC_PACKET_DATA before DTVCC_PACKET_START");
                        } else {
                            byte[] bArr2 = fVar2.f8679d;
                            int i15 = fVar2.f8680e;
                            int i16 = i15 + 1;
                            fVar2.f8680e = i16;
                            bArr2[i15] = bA;
                            fVar2.f8680e = i15 + 2;
                            bArr2[i16] = bA2;
                        }
                    }
                    ct.f fVar3 = this.f21123p;
                    if (fVar3.f8680e == (fVar3.f8678c * 2) - 1) {
                        j();
                    }
                }
            }
        }
    }

    @Override // m5.h
    public final boolean i() {
        return this.f21121n != this.f21122o;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public final void j() {
        char c11;
        boolean z11;
        ct.f fVar = this.f21123p;
        if (fVar == null) {
            return;
        }
        int i11 = 2;
        if (fVar.f8680e != (fVar.f8678c * 2) - 1) {
            n3.b.b("Cea708Decoder", "DtvCcPacket ended prematurely; size is " + ((this.f21123p.f8678c * 2) - 1) + ", but current index is " + this.f21123p.f8680e + " (sequence number " + this.f21123p.f8677b + ");");
        }
        ct.f fVar2 = this.f21123p;
        byte[] bArr = fVar2.f8679d;
        int i12 = fVar2.f8680e;
        ct.f fVar3 = this.f21118i;
        fVar3.q(bArr, i12);
        boolean z12 = false;
        while (fVar3.b() > 0) {
            int i13 = 3;
            int i14 = fVar3.i(3);
            int i15 = fVar3.i(5);
            if (i14 == 7) {
                fVar3.u(i11);
                i14 = fVar3.i(6);
                if (i14 < 7) {
                    q.r(i14, "Invalid extended service number: ", "Cea708Decoder");
                }
            }
            if (i15 == 0) {
                if (i14 == 0) {
                    break;
                }
                n3.b.l("Cea708Decoder", "serviceNumber is non-zero (" + i14 + ") when blockSize is 0");
                break;
            }
            if (i14 != this.k) {
                fVar3.v(i15);
            } else {
                int iG = (i15 * 8) + fVar3.g();
                while (fVar3.g() < iG) {
                    int i16 = fVar3.i(8);
                    if (i16 != 16) {
                        if (i16 <= 31) {
                            if (i16 != 0) {
                                if (i16 == i13) {
                                    this.f21121n = k();
                                } else if (i16 != 8) {
                                    switch (i16) {
                                        case 12:
                                            l();
                                            break;
                                        case 13:
                                            this.f21120m.a('\n');
                                            break;
                                        case 14:
                                            break;
                                        default:
                                            if (i16 >= 17 && i16 <= 23) {
                                                n3.b.l("Cea708Decoder", "Currently unsupported COMMAND_EXT1 Command: " + i16);
                                                fVar3.u(8);
                                            } else if (i16 < 24 || i16 > 31) {
                                                q.r(i16, "Invalid C0 command: ", "Cea708Decoder");
                                            } else {
                                                n3.b.l("Cea708Decoder", "Currently unsupported COMMAND_P16 Command: " + i16);
                                                fVar3.u(16);
                                            }
                                            break;
                                    }
                                } else {
                                    SpannableStringBuilder spannableStringBuilder = this.f21120m.f21099b;
                                    int length = spannableStringBuilder.length();
                                    if (length > 0) {
                                        spannableStringBuilder.delete(length - 1, length);
                                    }
                                }
                            }
                        } else if (i16 <= 127) {
                            if (i16 == 127) {
                                this.f21120m.a((char) 9835);
                            } else {
                                this.f21120m.a((char) (i16 & JfifUtil.MARKER_FIRST_BYTE));
                            }
                            z12 = true;
                        } else {
                            if (i16 <= 159) {
                                e[] eVarArr = this.l;
                                switch (i16) {
                                    case 128:
                                    case 129:
                                    case 130:
                                    case 131:
                                    case 132:
                                    case 133:
                                    case 134:
                                    case 135:
                                        z11 = true;
                                        int i17 = i16 - 128;
                                        if (this.f21124q != i17) {
                                            this.f21124q = i17;
                                            this.f21120m = eVarArr[i17];
                                        }
                                        break;
                                    case 136:
                                        z11 = true;
                                        for (int i18 = 1; i18 <= 8; i18++) {
                                            if (fVar3.h()) {
                                                e eVar = eVarArr[8 - i18];
                                                eVar.f21098a.clear();
                                                eVar.f21099b.clear();
                                                eVar.f21110o = -1;
                                                eVar.f21111p = -1;
                                                eVar.f21112q = -1;
                                                eVar.f21114s = -1;
                                                eVar.f21116u = 0;
                                            }
                                        }
                                        break;
                                    case 137:
                                        for (int i19 = 1; i19 <= 8; i19++) {
                                            if (fVar3.h()) {
                                                eVarArr[8 - i19].f21101d = true;
                                            }
                                        }
                                        z11 = true;
                                        break;
                                    case 138:
                                        for (int i21 = 1; i21 <= 8; i21++) {
                                            if (fVar3.h()) {
                                                eVarArr[8 - i21].f21101d = false;
                                            }
                                        }
                                        z11 = true;
                                        break;
                                    case 139:
                                        for (int i22 = 1; i22 <= 8; i22++) {
                                            if (fVar3.h()) {
                                                e eVar2 = eVarArr[8 - i22];
                                                eVar2.f21101d = !eVar2.f21101d;
                                            }
                                        }
                                        z11 = true;
                                        break;
                                    case 140:
                                        for (int i23 = 1; i23 <= 8; i23++) {
                                            if (fVar3.h()) {
                                                eVarArr[8 - i23].d();
                                            }
                                        }
                                        z11 = true;
                                        break;
                                    case 141:
                                        fVar3.u(8);
                                        z11 = true;
                                        break;
                                    case 142:
                                        z11 = true;
                                        break;
                                    case 143:
                                        l();
                                        z11 = true;
                                        break;
                                    case 144:
                                        int i24 = i11;
                                        if (this.f21120m.f21100c) {
                                            fVar3.i(4);
                                            fVar3.i(i24);
                                            fVar3.i(i24);
                                            boolean zH = fVar3.h();
                                            boolean zH2 = fVar3.h();
                                            i13 = 3;
                                            fVar3.i(3);
                                            fVar3.i(3);
                                            this.f21120m.e(zH, zH2);
                                            z11 = true;
                                        } else {
                                            fVar3.u(16);
                                            z11 = true;
                                            i13 = 3;
                                        }
                                        break;
                                    case 145:
                                        if (this.f21120m.f21100c) {
                                            int iC = e.c(fVar3.i(2), fVar3.i(2), fVar3.i(2), fVar3.i(2));
                                            int iC2 = e.c(fVar3.i(2), fVar3.i(2), fVar3.i(2), fVar3.i(2));
                                            fVar3.u(2);
                                            e.c(fVar3.i(2), fVar3.i(2), fVar3.i(2), 0);
                                            this.f21120m.f(iC, iC2);
                                        } else {
                                            fVar3.u(24);
                                        }
                                        z11 = true;
                                        i13 = 3;
                                        break;
                                    case 146:
                                        if (this.f21120m.f21100c) {
                                            fVar3.u(4);
                                            int i25 = fVar3.i(4);
                                            fVar3.u(2);
                                            fVar3.i(6);
                                            e eVar3 = this.f21120m;
                                            if (eVar3.f21116u != i25) {
                                                eVar3.a('\n');
                                            }
                                            eVar3.f21116u = i25;
                                        } else {
                                            fVar3.u(16);
                                        }
                                        z11 = true;
                                        i13 = 3;
                                        break;
                                    case 147:
                                    case 148:
                                    case 149:
                                    case 150:
                                    default:
                                        q.r(i16, "Invalid C1 command: ", "Cea708Decoder");
                                        z11 = true;
                                        break;
                                    case 151:
                                        if (this.f21120m.f21100c) {
                                            int iC3 = e.c(fVar3.i(2), fVar3.i(2), fVar3.i(2), fVar3.i(2));
                                            fVar3.i(2);
                                            e.c(fVar3.i(2), fVar3.i(2), fVar3.i(2), 0);
                                            fVar3.h();
                                            fVar3.h();
                                            fVar3.i(2);
                                            fVar3.i(2);
                                            int i26 = fVar3.i(2);
                                            fVar3.u(8);
                                            e eVar4 = this.f21120m;
                                            eVar4.f21109n = iC3;
                                            eVar4.k = i26;
                                        } else {
                                            fVar3.u(32);
                                        }
                                        z11 = true;
                                        i13 = 3;
                                        break;
                                    case 152:
                                    case 153:
                                    case 154:
                                    case 155:
                                    case 156:
                                    case 157:
                                    case 158:
                                    case 159:
                                        int i27 = i16 - 152;
                                        e eVar5 = eVarArr[i27];
                                        fVar3.u(i11);
                                        boolean zH3 = fVar3.h();
                                        fVar3.u(i11);
                                        int i28 = fVar3.i(i13);
                                        boolean zH4 = fVar3.h();
                                        int i29 = fVar3.i(7);
                                        int i31 = fVar3.i(8);
                                        int i32 = fVar3.i(4);
                                        int i33 = fVar3.i(4);
                                        fVar3.u(i11);
                                        fVar3.u(6);
                                        fVar3.u(i11);
                                        int i34 = fVar3.i(3);
                                        int i35 = fVar3.i(3);
                                        ArrayList arrayList = eVar5.f21098a;
                                        eVar5.f21100c = true;
                                        eVar5.f21101d = zH3;
                                        eVar5.f21102e = i28;
                                        eVar5.f21103f = zH4;
                                        eVar5.f21104g = i29;
                                        eVar5.f21105h = i31;
                                        eVar5.f21106i = i32;
                                        int i36 = i33 + 1;
                                        if (eVar5.f21107j != i36) {
                                            eVar5.f21107j = i36;
                                            while (true) {
                                                if (arrayList.size() < eVar5.f21107j && arrayList.size() < 15) {
                                                    break;
                                                } else {
                                                    arrayList.remove(0);
                                                }
                                            }
                                        }
                                        if (i34 != 0 && eVar5.l != i34) {
                                            eVar5.l = i34;
                                            int i37 = i34 - 1;
                                            int i38 = e.B[i37];
                                            boolean z13 = e.A[i37];
                                            int i39 = e.y[i37];
                                            int i40 = e.f21097z[i37];
                                            int i41 = e.f21096x[i37];
                                            eVar5.f21109n = i38;
                                            eVar5.k = i41;
                                        }
                                        if (i35 != 0 && eVar5.f21108m != i35) {
                                            eVar5.f21108m = i35;
                                            int i42 = i35 - 1;
                                            int i43 = e.D[i42];
                                            int i44 = e.C[i42];
                                            eVar5.e(false, false);
                                            eVar5.f(e.f21094v, e.E[i42]);
                                        }
                                        if (this.f21124q != i27) {
                                            this.f21124q = i27;
                                            this.f21120m = eVarArr[i27];
                                        }
                                        z11 = true;
                                        i13 = 3;
                                        break;
                                }
                            } else {
                                z11 = true;
                                if (i16 <= 255) {
                                    this.f21120m.a((char) (i16 & JfifUtil.MARKER_FIRST_BYTE));
                                } else {
                                    q.r(i16, "Invalid base command: ", "Cea708Decoder");
                                }
                                i11 = 2;
                                c11 = 7;
                            }
                            z12 = z11;
                            i11 = 2;
                            c11 = 7;
                        }
                        c11 = 7;
                    } else {
                        int i45 = fVar3.i(8);
                        if (i45 <= 31) {
                            c11 = 7;
                            if (i45 > 7) {
                                if (i45 <= 15) {
                                    fVar3.u(8);
                                } else if (i45 <= 23) {
                                    fVar3.u(16);
                                } else if (i45 <= 31) {
                                    fVar3.u(24);
                                }
                            }
                        } else {
                            c11 = 7;
                            if (i45 <= 127) {
                                if (i45 == 32) {
                                    this.f21120m.a(' ');
                                } else if (i45 == 33) {
                                    this.f21120m.a((char) 160);
                                } else if (i45 == 37) {
                                    this.f21120m.a((char) 8230);
                                } else if (i45 == 42) {
                                    this.f21120m.a((char) 352);
                                } else if (i45 == 44) {
                                    this.f21120m.a((char) 338);
                                } else if (i45 == 63) {
                                    this.f21120m.a((char) 376);
                                } else if (i45 == 57) {
                                    this.f21120m.a((char) 8482);
                                } else if (i45 == 58) {
                                    this.f21120m.a((char) 353);
                                } else if (i45 == 60) {
                                    this.f21120m.a((char) 339);
                                } else if (i45 != 61) {
                                    switch (i45) {
                                        case 48:
                                            this.f21120m.a((char) 9608);
                                            break;
                                        case 49:
                                            this.f21120m.a((char) 8216);
                                            break;
                                        case 50:
                                            this.f21120m.a((char) 8217);
                                            break;
                                        case 51:
                                            this.f21120m.a((char) 8220);
                                            break;
                                        case 52:
                                            this.f21120m.a((char) 8221);
                                            break;
                                        case 53:
                                            this.f21120m.a((char) 8226);
                                            break;
                                        default:
                                            switch (i45) {
                                                case 118:
                                                    this.f21120m.a((char) 8539);
                                                    break;
                                                case 119:
                                                    this.f21120m.a((char) 8540);
                                                    break;
                                                case 120:
                                                    this.f21120m.a((char) 8541);
                                                    break;
                                                case 121:
                                                    this.f21120m.a((char) 8542);
                                                    break;
                                                case 122:
                                                    this.f21120m.a((char) 9474);
                                                    break;
                                                case 123:
                                                    this.f21120m.a((char) 9488);
                                                    break;
                                                case 124:
                                                    this.f21120m.a((char) 9492);
                                                    break;
                                                case 125:
                                                    this.f21120m.a((char) 9472);
                                                    break;
                                                case 126:
                                                    this.f21120m.a((char) 9496);
                                                    break;
                                                case 127:
                                                    this.f21120m.a((char) 9484);
                                                    break;
                                                default:
                                                    q.r(i45, "Invalid G2 character: ", "Cea708Decoder");
                                                    break;
                                            }
                                            break;
                                    }
                                } else {
                                    this.f21120m.a((char) 8480);
                                }
                                i11 = 2;
                                z12 = true;
                            } else if (i45 > 159) {
                                i11 = 2;
                                if (i45 <= 255) {
                                    if (i45 == 160) {
                                        this.f21120m.a((char) 13252);
                                    } else {
                                        q.r(i45, "Invalid G3 character: ", "Cea708Decoder");
                                        this.f21120m.a('_');
                                    }
                                    z12 = true;
                                } else {
                                    q.r(i45, "Invalid extended command: ", "Cea708Decoder");
                                }
                            } else if (i45 <= 135) {
                                fVar3.u(32);
                            } else if (i45 <= 143) {
                                fVar3.u(40);
                            } else if (i45 <= 159) {
                                i11 = 2;
                                fVar3.u(2);
                                fVar3.u(fVar3.i(6) * 8);
                            }
                        }
                        i11 = 2;
                    }
                    i11 = i11;
                }
            }
        }
        if (z12) {
            this.f21121n = k();
        }
        this.f21123p = null;
    }

    public final List k() {
        d dVar;
        Layout.Alignment alignment;
        float f3;
        float f11;
        ArrayList arrayList = new ArrayList();
        for (int i11 = 0; i11 < 8; i11++) {
            e[] eVarArr = this.l;
            e eVar = eVarArr[i11];
            if (eVar.f21100c && (!eVar.f21098a.isEmpty() || eVar.f21099b.length() != 0)) {
                e eVar2 = eVarArr[i11];
                if (eVar2.f21101d) {
                    ArrayList arrayList2 = eVar2.f21098a;
                    if (!eVar2.f21100c || (arrayList2.isEmpty() && eVar2.f21099b.length() == 0)) {
                        dVar = null;
                    } else {
                        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
                        for (int i12 = 0; i12 < arrayList2.size(); i12++) {
                            spannableStringBuilder.append((CharSequence) arrayList2.get(i12));
                            spannableStringBuilder.append('\n');
                        }
                        spannableStringBuilder.append((CharSequence) eVar2.b());
                        int i13 = eVar2.k;
                        if (i13 == 0) {
                            alignment = Layout.Alignment.ALIGN_NORMAL;
                        } else if (i13 == 1) {
                            alignment = Layout.Alignment.ALIGN_OPPOSITE;
                        } else if (i13 != 2) {
                            if (i13 != 3) {
                                throw new IllegalArgumentException("Unexpected justification value: " + eVar2.k);
                            }
                            alignment = Layout.Alignment.ALIGN_NORMAL;
                        } else {
                            alignment = Layout.Alignment.ALIGN_CENTER;
                        }
                        Layout.Alignment alignment2 = alignment;
                        if (eVar2.f21103f) {
                            f3 = eVar2.f21105h / 99.0f;
                            f11 = eVar2.f21104g / 99.0f;
                        } else {
                            f3 = eVar2.f21105h / 209.0f;
                            f11 = eVar2.f21104g / 74.0f;
                        }
                        float f12 = (f3 * 0.9f) + 0.05f;
                        float f13 = (f11 * 0.9f) + 0.05f;
                        int i14 = eVar2.f21106i;
                        int i15 = i14 / 3;
                        int i16 = i15 == 0 ? 0 : i15 == 1 ? 1 : 2;
                        int i17 = i14 % 3;
                        int i18 = i17 == 0 ? 0 : i17 == 1 ? 1 : 2;
                        int i19 = eVar2.f21109n;
                        dVar = new d(spannableStringBuilder, alignment2, f13, i16, f12, i18, i19 != e.f21095w, i19, eVar2.f21102e);
                    }
                    if (dVar != null) {
                        arrayList.add(dVar);
                    }
                } else {
                    continue;
                }
            }
        }
        Collections.sort(arrayList, d.f21091c);
        ArrayList arrayList3 = new ArrayList(arrayList.size());
        for (int i21 = 0; i21 < arrayList.size(); i21++) {
            arrayList3.add(((d) arrayList.get(i21)).f21092a);
        }
        return Collections.unmodifiableList(arrayList3);
    }

    public final void l() {
        for (int i11 = 0; i11 < 8; i11++) {
            this.l[i11].d();
        }
    }
}
