package mm;

import am.d;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import com.google.firebase.messaging.o;
import im.c;
import j.e0;
import kotlin.jvm.internal.k;
import zm.n;

/* JADX INFO: loaded from: classes.dex */
public final class a extends Drawable implements Animatable, sl.a {
    public static final n R = new n(14);
    public long J;
    public long K;
    public int L;
    public int N;
    public d P;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final fm.a f21339d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final as.d f21340e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public volatile boolean f21341i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f21342v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f21343w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public long f21344x;
    public int y;
    public final long M = 8;
    public volatile n O = R;
    public final e0 Q = new e0(5, this);

    public a(fm.a aVar) {
        this.f21339d = aVar;
        this.f21340e = new as.d(aVar);
    }

    @Override // sl.a
    public final void a() {
        fm.a aVar = this.f21339d;
        if (aVar != null) {
            aVar.f12118a.a();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas canvas) throws Throwable {
        long j6;
        c cVar;
        im.a aVar;
        k.g(canvas, "canvas");
        if (this.f21339d == null || this.f21340e == null) {
            return;
        }
        long jUptimeMillis = SystemClock.uptimeMillis();
        long jMax = this.f21341i ? jUptimeMillis - this.f21342v : (long) Math.max(this.f21343w, 0.0d);
        as.d dVar = this.f21340e;
        k.d(dVar);
        fm.a aVar2 = (fm.a) dVar.f2306i;
        long jO = dVar.O();
        int iA = 0;
        if (jO == 0) {
            long jB = 0;
            while (true) {
                jB += (long) aVar2.b(iA);
                int i11 = iA + 1;
                if (0 < jB) {
                    break;
                } else {
                    iA = i11;
                }
            }
        } else if (aVar2.c() != 0 && jMax / jO >= aVar2.c()) {
            iA = -1;
        } else {
            long j11 = jMax % jO;
            long jB2 = 0;
            while (true) {
                jB2 += (long) aVar2.b(iA);
                int i12 = iA + 1;
                if (j11 < jB2) {
                    break;
                } else {
                    iA = i12;
                }
            }
        }
        if (iA == -1) {
            fm.a aVar3 = this.f21339d;
            k.d(aVar3);
            iA = aVar3.a() - 1;
            this.O.getClass();
            this.f21341i = false;
        } else if (iA == 0 && this.y != -1 && jUptimeMillis >= this.f21344x) {
            this.O.getClass();
        }
        fm.a aVar4 = this.f21339d;
        k.d(aVar4);
        aVar4.f12122e = aVar4.f12119b.now();
        gm.a aVar5 = aVar4.f12118a;
        boolean zC = aVar5.c(canvas, iA, 0);
        if (!aVar5.f13387e && (cVar = aVar5.f13389g) != null && (aVar = aVar5.f13388f) != null) {
            aVar.a(cVar, aVar5.f13384b, aVar5, iA);
        }
        boolean z11 = zC;
        aVar4.d();
        if (z11) {
            this.O.m(this, iA);
            this.y = iA;
        }
        if (!z11) {
            this.N++;
            if (gl.a.f13381a.L(2)) {
                gl.a.m("Dropped a frame. Count: %s", Integer.valueOf(this.N), a.class);
            }
        }
        long jUptimeMillis2 = SystemClock.uptimeMillis();
        if (this.f21341i) {
            as.d dVar2 = this.f21340e;
            k.d(dVar2);
            long j12 = jUptimeMillis2 - this.f21342v;
            fm.a aVar6 = (fm.a) dVar2.f2306i;
            long jO2 = dVar2.O();
            long jB3 = 0;
            if (jO2 != 0 && (aVar6.c() == 0 || j12 / jO2 < aVar6.c())) {
                long j13 = j12 % jO2;
                int iA2 = aVar6.a();
                for (int i13 = 0; i13 < iA2 && jB3 <= j13; i13++) {
                    jB3 += (long) aVar6.b(i13);
                }
                j6 = j12 + (jB3 - j13);
            } else {
                j6 = -1;
            }
            if (j6 != -1) {
                long j14 = this.f21342v + j6 + this.M;
                this.f21344x = j14;
                scheduleSelf(this.Q, j14);
            } else {
                this.O.getClass();
                this.f21341i = false;
            }
        }
        this.f21343w = jMax;
    }

    @Override // android.graphics.drawable.Drawable
    public final int getIntrinsicHeight() {
        fm.a aVar = this.f21339d;
        return aVar != null ? aVar.f12118a.l : super.getIntrinsicHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public final int getIntrinsicWidth() {
        fm.a aVar = this.f21339d;
        return aVar != null ? aVar.f12118a.k : super.getIntrinsicWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Animatable
    public final boolean isRunning() {
        return this.f21341i;
    }

    @Override // android.graphics.drawable.Drawable
    public final void onBoundsChange(Rect bounds) {
        k.g(bounds, "bounds");
        super.onBoundsChange(bounds);
        fm.a aVar = this.f21339d;
        if (aVar != null) {
            gm.a aVar2 = aVar.f12118a;
            aVar2.f13392j = bounds;
            lm.a aVar3 = aVar2.f13386d;
            vm.a aVar4 = (vm.a) aVar3.f20530d;
            if (!vm.a.a(aVar4.f32840c, bounds).equals(aVar4.f32841d)) {
                aVar4 = new vm.a(aVar4.f32838a, aVar4.f32839b, bounds, aVar4.f32847j);
            }
            if (aVar4 != ((vm.a) aVar3.f20530d)) {
                aVar3.f20530d = aVar4;
                aVar3.f20531e = new o(aVar4, aVar3.f20528b, (a8.c) aVar3.f20532f);
            }
            aVar2.d();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final boolean onLevelChange(int i11) {
        if (this.f21341i) {
            return false;
        }
        long j6 = i11;
        if (this.f21343w == j6) {
            return false;
        }
        this.f21343w = j6;
        invalidateSelf();
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i11) {
        if (this.P == null) {
            this.P = new d();
        }
        d dVar = this.P;
        k.d(dVar);
        dVar.f1195a = i11;
        fm.a aVar = this.f21339d;
        if (aVar != null) {
            aVar.f12118a.f13391i.setAlpha(i11);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        if (this.P == null) {
            this.P = new d();
        }
        d dVar = this.P;
        k.d(dVar);
        dVar.f1197c = colorFilter;
        dVar.f1196b = colorFilter != null;
        fm.a aVar = this.f21339d;
        if (aVar != null) {
            aVar.f12118a.f13391i.setColorFilter(colorFilter);
        }
    }

    @Override // android.graphics.drawable.Animatable
    public final void start() {
        fm.a aVar;
        if (this.f21341i || (aVar = this.f21339d) == null || aVar.a() <= 1) {
            return;
        }
        this.f21341i = true;
        long jUptimeMillis = SystemClock.uptimeMillis();
        long j6 = jUptimeMillis - this.J;
        this.f21342v = j6;
        this.f21344x = j6;
        this.f21343w = jUptimeMillis - this.K;
        this.y = this.L;
        invalidateSelf();
        this.O.getClass();
    }

    @Override // android.graphics.drawable.Animatable
    public final void stop() {
        if (this.f21341i) {
            long jUptimeMillis = SystemClock.uptimeMillis();
            this.J = jUptimeMillis - this.f21342v;
            this.K = jUptimeMillis - this.f21343w;
            this.L = this.y;
            this.f21341i = false;
            this.f21342v = 0L;
            this.f21344x = 0L;
            this.f21343w = -1L;
            this.y = -1;
            unscheduleSelf(this.Q);
            this.O.getClass();
        }
    }
}
