package n1;

import android.os.Build;
import java.util.HashMap;
import l30.j;
import m30.x;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f22269a;

    public a() {
        int i11;
        HashMap mapO0 = x.o0(new j("robolectric-BrandX/ProductX/Device30:11", 30), new j("robolectric-BrandX/ProductX/Device31:12", 31), new j("OPPO/CPH2025EEA/OP4BA2L1:12", 30), new j("OPPO/CPH2207EEA/OP4F0BL1:12", 30), new j("OPPO/PENM00/OP4EC1:11", 30), new j("OnePlus/OnePlus7TTMO/OnePlus7TTMO:11", 30), new j("OnePlus/OnePlus8_BETA/OnePlus8:11", 30), new j("Xiaomi/umi_global/umi:11", 30), new j("realme/RMX2085/RMX2085L1:11", 30), new j("samsung/c1qsqw/c1q:12", 30), new j("samsung/o1quew/o1q:12", 30), new j("samsung/r0quew/r0q:12", 30), new j("samsung/r0sxxx/r0s:12", 30));
        int i12 = Build.VERSION.SDK_INT >= 31 ? Build.VERSION.MEDIA_PERFORMANCE_CLASS : 0;
        if (i12 >= 30) {
            i11 = i12;
        } else {
            Integer num = (Integer) mapO0.get(Build.BRAND + '/' + Build.PRODUCT + '/' + Build.DEVICE + ':' + Build.VERSION.RELEASE);
            int iIntValue = (num == null ? 0 : num).intValue();
            i11 = iIntValue >= 30 ? iIntValue : 0;
        }
        this.f22269a = i11;
    }
}
