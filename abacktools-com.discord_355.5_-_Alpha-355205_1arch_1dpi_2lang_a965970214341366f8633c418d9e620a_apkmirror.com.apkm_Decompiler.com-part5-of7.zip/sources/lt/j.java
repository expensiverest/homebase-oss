package lt;

import java.util.regex.Pattern;
import mr.k1;
import qt.q;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public abstract class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Pattern f20662a = Pattern.compile("^NOTE([ \t].*)?$");

    public static boolean a(q qVar) {
        qVar.getClass();
        String strH = qVar.h(gx.j.f13622c);
        return strH != null && strH.startsWith("WEBVTT");
    }

    public static float b(String str) {
        if (str.endsWith("%")) {
            return Float.parseFloat(str.substring(0, str.length() - 1)) / 100.0f;
        }
        throw new NumberFormatException("Percentages must end with %");
    }

    public static long c(String str) {
        int i11 = x.f27318a;
        String[] strArrSplit = str.split("\\.", 2);
        long j6 = 0;
        for (String str2 : strArrSplit[0].split(":", -1)) {
            j6 = (j6 * 60) + Long.parseLong(str2);
        }
        long j11 = j6 * 1000;
        if (strArrSplit.length == 2) {
            j11 += Long.parseLong(strArrSplit[1]);
        }
        return j11 * 1000;
    }

    public static void d(q qVar) throws k1 {
        int i11 = qVar.f27305b;
        if (a(qVar)) {
            return;
        }
        qVar.F(i11);
        throw k1.a(null, "Expected WEBVTT. Got " + qVar.h(gx.j.f13622c));
    }
}
