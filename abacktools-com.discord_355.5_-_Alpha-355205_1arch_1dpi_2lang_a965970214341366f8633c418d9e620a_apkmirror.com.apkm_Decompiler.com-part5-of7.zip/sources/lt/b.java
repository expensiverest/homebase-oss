package lt;

import java.util.Set;

/* JADX INFO: loaded from: classes3.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f20619a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f20620b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Set f20621c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f20622d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f20623e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f20624f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f20625g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f20626h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f20627i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f20628j;
    public int k;
    public int l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f20629m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f20630n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public float f20631o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f20632p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f20633q;

    public static int a(String str, int i11, int i12, String str2) {
        if (str.isEmpty() || i11 == -1) {
            return i11;
        }
        if (str.equals(str2)) {
            return i11 + i12;
        }
        return -1;
    }
}
