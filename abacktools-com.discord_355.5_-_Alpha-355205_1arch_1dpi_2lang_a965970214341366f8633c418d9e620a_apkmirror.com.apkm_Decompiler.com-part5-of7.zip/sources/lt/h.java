package lt;

import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import com.facebook.imageutils.JfifUtil;
import g8.i0;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import p.x2;
import qt.q;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Pattern f20656a = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)(.*)?$");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Pattern f20657b = Pattern.compile("(\\S+?):(\\S+)");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Map f20658c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Map f20659d;

    static {
        HashMap map = new HashMap();
        x2.o(JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, map, "white");
        x2.o(0, JfifUtil.MARKER_FIRST_BYTE, 0, map, "lime");
        x2.o(0, JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, map, "cyan");
        x2.o(JfifUtil.MARKER_FIRST_BYTE, 0, 0, map, "red");
        x2.o(JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, 0, map, "yellow");
        x2.o(JfifUtil.MARKER_FIRST_BYTE, 0, JfifUtil.MARKER_FIRST_BYTE, map, "magenta");
        x2.o(0, 0, JfifUtil.MARKER_FIRST_BYTE, map, "blue");
        x2.o(0, 0, 0, map, "black");
        f20658c = Collections.unmodifiableMap(map);
        HashMap map2 = new HashMap();
        x2.o(JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, map2, "bg_white");
        x2.o(0, JfifUtil.MARKER_FIRST_BYTE, 0, map2, "bg_lime");
        x2.o(0, JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, map2, "bg_cyan");
        x2.o(JfifUtil.MARKER_FIRST_BYTE, 0, 0, map2, "bg_red");
        x2.o(JfifUtil.MARKER_FIRST_BYTE, JfifUtil.MARKER_FIRST_BYTE, 0, map2, "bg_yellow");
        x2.o(JfifUtil.MARKER_FIRST_BYTE, 0, JfifUtil.MARKER_FIRST_BYTE, map2, "bg_magenta");
        x2.o(0, 0, JfifUtil.MARKER_FIRST_BYTE, map2, "bg_blue");
        x2.o(0, 0, 0, map2, "bg_black");
        f20659d = Collections.unmodifiableMap(map2);
    }

    public static void a(String str, e eVar, List list, SpannableStringBuilder spannableStringBuilder, List list2) {
        int i11;
        int i12;
        int i13;
        int i14 = eVar.f20641b;
        int length = spannableStringBuilder.length();
        String str2 = eVar.f20640a;
        str2.getClass();
        int i15 = -1;
        switch (str2) {
            case "":
            case "v":
            case "lang":
                break;
            case "b":
                spannableStringBuilder.setSpan(new StyleSpan(1), i14, length, 33);
                break;
            case "c":
                for (String str3 : eVar.f20643d) {
                    Map map = f20658c;
                    if (map.containsKey(str3)) {
                        spannableStringBuilder.setSpan(new ForegroundColorSpan(((Integer) map.get(str3)).intValue()), i14, length, 33);
                    } else {
                        Map map2 = f20659d;
                        if (map2.containsKey(str3)) {
                            spannableStringBuilder.setSpan(new BackgroundColorSpan(((Integer) map2.get(str3)).intValue()), i14, length, 33);
                        }
                    }
                }
                break;
            case "i":
                spannableStringBuilder.setSpan(new StyleSpan(2), i14, length, 33);
                break;
            case "u":
                spannableStringBuilder.setSpan(new UnderlineSpan(), i14, length, 33);
                break;
            case "ruby":
                int iC = c(list2, str, eVar);
                ArrayList arrayList = new ArrayList(list.size());
                arrayList.addAll(list);
                Collections.sort(arrayList, d.f20637c);
                int i16 = eVar.f20641b;
                int i17 = 0;
                int length2 = 0;
                while (i17 < arrayList.size()) {
                    if ("rt".equals(((d) arrayList.get(i17)).f20638a.f20640a)) {
                        d dVar = (d) arrayList.get(i17);
                        int iC2 = c(list2, str, dVar.f20638a);
                        if (iC2 == i15) {
                            iC2 = iC != i15 ? iC : 1;
                        }
                        int i18 = dVar.f20638a.f20641b - length2;
                        int i19 = dVar.f20639b - length2;
                        CharSequence charSequenceSubSequence = spannableStringBuilder.subSequence(i18, i19);
                        spannableStringBuilder.delete(i18, i19);
                        spannableStringBuilder.setSpan(new ft.c(charSequenceSubSequence.toString(), iC2), i16, i18, 33);
                        length2 = charSequenceSubSequence.length() + length2;
                        i16 = i18;
                    }
                    i17++;
                    i15 = -1;
                }
                break;
            default:
                return;
        }
        ArrayList arrayListB = b(list2, str, eVar);
        for (int i21 = 0; i21 < arrayListB.size(); i21++) {
            b bVar = ((f) arrayListB.get(i21)).f20645e;
            int i22 = bVar.l;
            if (i22 == -1 && bVar.f20629m == -1) {
                i11 = -1;
            } else {
                i11 = (bVar.f20629m == 1 ? (char) 2 : (char) 0) | (i22 == 1 ? (char) 1 : (char) 0);
            }
            if (i11 != -1) {
                int i23 = bVar.l;
                if (i23 == -1 && bVar.f20629m == -1) {
                    i13 = -1;
                    i12 = 1;
                } else {
                    i12 = 1;
                    i13 = (i23 == 1 ? 1 : 0) | (bVar.f20629m == 1 ? 2 : 0);
                }
                i0.c(spannableStringBuilder, new StyleSpan(i13), i14, length);
            } else {
                i12 = 1;
            }
            if (bVar.f20628j == i12) {
                spannableStringBuilder.setSpan(new StrikethroughSpan(), i14, length, 33);
            }
            if (bVar.k == i12) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), i14, length, 33);
            }
            if (bVar.f20625g) {
                if (!bVar.f20625g) {
                    throw new IllegalStateException("Font color not defined");
                }
                i0.c(spannableStringBuilder, new ForegroundColorSpan(bVar.f20624f), i14, length);
            }
            if (bVar.f20627i) {
                if (!bVar.f20627i) {
                    throw new IllegalStateException("Background color not defined.");
                }
                i0.c(spannableStringBuilder, new BackgroundColorSpan(bVar.f20626h), i14, length);
            }
            if (bVar.f20623e != null) {
                i0.c(spannableStringBuilder, new TypefaceSpan(bVar.f20623e), i14, length);
            }
            int i24 = bVar.f20630n;
            if (i24 == 1) {
                i0.c(spannableStringBuilder, new AbsoluteSizeSpan((int) bVar.f20631o, true), i14, length);
            } else if (i24 == 2) {
                i0.c(spannableStringBuilder, new RelativeSizeSpan(bVar.f20631o), i14, length);
            } else if (i24 == 3) {
                i0.c(spannableStringBuilder, new RelativeSizeSpan(bVar.f20631o / 100.0f), i14, length);
            }
            if (bVar.f20633q) {
                spannableStringBuilder.setSpan(new ft.a(), i14, length, 33);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v5, types: [int] */
    /* JADX WARN: Type inference failed for: r4v7 */
    /* JADX WARN: Type inference failed for: r4v8 */
    public static ArrayList b(List list, String str, e eVar) {
        ?? r11;
        int size;
        boolean zIsEmpty;
        ArrayList arrayList = new ArrayList();
        for (int i11 = 0; i11 < list.size(); i11++) {
            b bVar = (b) list.get(i11);
            String str2 = eVar.f20640a;
            Set set = eVar.f20643d;
            String str3 = eVar.f20642c;
            if (bVar.f20619a.isEmpty() && bVar.f20620b.isEmpty() && bVar.f20621c.isEmpty() && bVar.f20622d.isEmpty()) {
                zIsEmpty = TextUtils.isEmpty(str2);
            } else {
                int iA = b.a(bVar.f20622d, b.a(bVar.f20620b, b.a(bVar.f20619a, 0, 1073741824, str), 2, str2), 4, str3);
                if (iA == -1 || !set.containsAll(bVar.f20621c)) {
                    r11 = 0;
                } else {
                    size = iA + (bVar.f20621c.size() * 4);
                }
            }
            if (r11 > 0) {
                r11 = size;
                r11 = zIsEmpty;
                arrayList.add(new f(r11, bVar));
            } else {
                r11 = size;
                r11 = zIsEmpty;
            }
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static int c(List list, String str, e eVar) {
        ArrayList arrayListB = b(list, str, eVar);
        for (int i11 = 0; i11 < arrayListB.size(); i11++) {
            int i12 = ((f) arrayListB.get(i11)).f20645e.f20632p;
            if (i12 != -1) {
                return i12;
            }
        }
        return -1;
    }

    public static c d(String str, Matcher matcher, q qVar, ArrayList arrayList) {
        g gVar = new g();
        try {
            String strGroup = matcher.group(1);
            strGroup.getClass();
            gVar.f20646a = j.c(strGroup);
            String strGroup2 = matcher.group(2);
            strGroup2.getClass();
            gVar.f20647b = j.c(strGroup2);
            String strGroup3 = matcher.group(3);
            strGroup3.getClass();
            e(strGroup3, gVar);
            StringBuilder sb2 = new StringBuilder();
            qVar.getClass();
            String strH = qVar.h(gx.j.f13622c);
            while (!TextUtils.isEmpty(strH)) {
                if (sb2.length() > 0) {
                    sb2.append("\n");
                }
                sb2.append(strH.trim());
                strH = qVar.h(gx.j.f13622c);
            }
            gVar.f20648c = f(str, sb2.toString(), arrayList);
            return new c(gVar.a().a(), gVar.f20646a, gVar.f20647b);
        } catch (NumberFormatException unused) {
            qt.a.N("WebvttCueParser", "Skipping cue with bad header: " + matcher.group());
            return null;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static void e(String str, g gVar) {
        int i11;
        int i12;
        int i13;
        Matcher matcher = f20657b.matcher(str);
        while (matcher.find()) {
            String strGroup = matcher.group(1);
            strGroup.getClass();
            String strGroup2 = matcher.group(2);
            strGroup2.getClass();
            try {
                if ("line".equals(strGroup)) {
                    g(strGroup2, gVar);
                } else {
                    if ("align".equals(strGroup)) {
                        switch (strGroup2) {
                            case "center":
                            case "middle":
                                i11 = 2;
                                break;
                            case "end":
                                i11 = 3;
                                break;
                            case "left":
                                i11 = 4;
                                break;
                            case "right":
                                i11 = 5;
                                break;
                            case "start":
                                i11 = 1;
                                break;
                            default:
                                qt.a.N("WebvttCueParser", "Invalid alignment value: ".concat(strGroup2));
                                i11 = 2;
                                break;
                        }
                        gVar.f20649d = i11;
                    } else if ("position".equals(strGroup)) {
                        int iIndexOf = strGroup2.indexOf(44);
                        if (iIndexOf != -1) {
                            String strSubstring = strGroup2.substring(iIndexOf + 1);
                            strSubstring.getClass();
                            switch (strSubstring) {
                                case "line-left":
                                case "start":
                                    i12 = 0;
                                    break;
                                case "center":
                                case "middle":
                                    i12 = 1;
                                    break;
                                case "line-right":
                                case "end":
                                    i12 = 2;
                                    break;
                                default:
                                    qt.a.N("WebvttCueParser", "Invalid anchor value: ".concat(strSubstring));
                                    i12 = Integer.MIN_VALUE;
                                    break;
                            }
                            gVar.f20654i = i12;
                            strGroup2 = strGroup2.substring(0, iIndexOf);
                        }
                        gVar.f20653h = j.b(strGroup2);
                    } else if ("size".equals(strGroup)) {
                        gVar.f20655j = j.b(strGroup2);
                    } else if ("vertical".equals(strGroup)) {
                        if (strGroup2.equals("lr")) {
                            i13 = 2;
                        } else if (strGroup2.equals("rl")) {
                            i13 = 1;
                        } else {
                            qt.a.N("WebvttCueParser", "Invalid 'vertical' value: ".concat(strGroup2));
                            i13 = Integer.MIN_VALUE;
                        }
                        gVar.k = i13;
                    } else {
                        qt.a.N("WebvttCueParser", "Unknown cue setting " + strGroup + ":" + strGroup2);
                    }
                }
            } catch (NumberFormatException unused) {
                qt.a.N("WebvttCueParser", "Skipping bad cue setting: " + matcher.group());
            }
        }
    }

    public static SpannedString f(String str, String str2, List list) {
        char c11;
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        ArrayDeque arrayDeque = new ArrayDeque();
        ArrayList arrayList = new ArrayList();
        int i11 = 0;
        while (true) {
            String strTrim = "";
            if (i11 >= str2.length()) {
                break;
            }
            char cCharAt = str2.charAt(i11);
            if (cCharAt == '&') {
                i11++;
                int iIndexOf = str2.indexOf(59, i11);
                int iIndexOf2 = str2.indexOf(32, i11);
                if (iIndexOf == -1) {
                    iIndexOf = iIndexOf2;
                } else if (iIndexOf2 != -1) {
                    iIndexOf = Math.min(iIndexOf, iIndexOf2);
                }
                if (iIndexOf != -1) {
                    String strSubstring = str2.substring(i11, iIndexOf);
                    strSubstring.getClass();
                    switch (strSubstring) {
                        case "gt":
                            spannableStringBuilder.append('>');
                            break;
                        case "lt":
                            spannableStringBuilder.append('<');
                            break;
                        case "amp":
                            spannableStringBuilder.append('&');
                            break;
                        case "nbsp":
                            spannableStringBuilder.append(' ');
                            break;
                        default:
                            qt.a.N("WebvttCueParser", "ignoring unsupported entity: '&" + strSubstring + ";'");
                            break;
                    }
                    if (iIndexOf == iIndexOf2) {
                        spannableStringBuilder.append((CharSequence) " ");
                    }
                    i11 = iIndexOf + 1;
                } else {
                    spannableStringBuilder.append(cCharAt);
                }
            } else if (cCharAt != '<') {
                spannableStringBuilder.append(cCharAt);
                i11++;
            } else {
                int length = i11 + 1;
                if (length < str2.length()) {
                    boolean z11 = str2.charAt(length) == '/';
                    int iIndexOf3 = str2.indexOf(62, length);
                    length = iIndexOf3 == -1 ? str2.length() : iIndexOf3 + 1;
                    int i12 = length - 2;
                    boolean z12 = str2.charAt(i12) == '/';
                    int i13 = i11 + (z11 ? 2 : 1);
                    if (!z12) {
                        i12 = length - 1;
                    }
                    String strSubstring2 = str2.substring(i13, i12);
                    if (!strSubstring2.trim().isEmpty()) {
                        String strTrim2 = strSubstring2.trim();
                        qt.a.g(!strTrim2.isEmpty());
                        int i14 = x.f27318a;
                        String str3 = strTrim2.split("[ \\.]", 2)[0];
                        str3.getClass();
                        switch (str3) {
                            case "b":
                            case "c":
                            case "i":
                            case "u":
                            case "v":
                            case "rt":
                            case "lang":
                            case "ruby":
                                if (z11) {
                                    while (!arrayDeque.isEmpty()) {
                                        e eVar = (e) arrayDeque.pop();
                                        a(str, eVar, arrayList, spannableStringBuilder, list);
                                        if (arrayDeque.isEmpty()) {
                                            arrayList.clear();
                                        } else {
                                            arrayList.add(new d(eVar, spannableStringBuilder.length()));
                                        }
                                        if (eVar.f20640a.equals(str3)) {
                                            break;
                                        }
                                    }
                                    break;
                                } else if (!z12) {
                                    int length2 = spannableStringBuilder.length();
                                    String strTrim3 = strSubstring2.trim();
                                    qt.a.g(!strTrim3.isEmpty());
                                    int iIndexOf4 = strTrim3.indexOf(" ");
                                    if (iIndexOf4 == -1) {
                                        c11 = 0;
                                    } else {
                                        strTrim = strTrim3.substring(iIndexOf4).trim();
                                        c11 = 0;
                                        strTrim3 = strTrim3.substring(0, iIndexOf4);
                                    }
                                    String[] strArrSplit = strTrim3.split("\\.", -1);
                                    String str4 = strArrSplit[c11];
                                    HashSet hashSet = new HashSet();
                                    for (int i15 = 1; i15 < strArrSplit.length; i15++) {
                                        hashSet.add(strArrSplit[i15]);
                                    }
                                    arrayDeque.push(new e(str4, length2, strTrim, hashSet));
                                    break;
                                }
                                break;
                        }
                    }
                }
                i11 = length;
            }
        }
        while (!arrayDeque.isEmpty()) {
            a(str, (e) arrayDeque.pop(), arrayList, spannableStringBuilder, list);
        }
        a(str, new e("", 0, "", Collections.EMPTY_SET), Collections.EMPTY_LIST, spannableStringBuilder, list);
        return SpannedString.valueOf(spannableStringBuilder);
    }

    public static void g(String str, g gVar) {
        int iIndexOf = str.indexOf(44);
        if (iIndexOf != -1) {
            String strSubstring = str.substring(iIndexOf + 1);
            strSubstring.getClass();
            int i11 = 2;
            switch (strSubstring) {
                case "center":
                case "middle":
                    i11 = 1;
                    break;
                case "end":
                    break;
                case "start":
                    i11 = 0;
                    break;
                default:
                    qt.a.N("WebvttCueParser", "Invalid anchor value: ".concat(strSubstring));
                    i11 = androidx.customview.widget.b.INVALID_ID;
                    break;
            }
            gVar.f20652g = i11;
            str = str.substring(0, iIndexOf);
        }
        if (str.endsWith("%")) {
            gVar.f20650e = j.b(str);
            gVar.f20651f = 0;
        } else {
            gVar.f20650e = Integer.parseInt(str);
            gVar.f20651f = 1;
        }
    }
}
