package lt;

/* JADX INFO: loaded from: classes3.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final bt.b f20634a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f20635b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f20636c;

    public c(bt.b bVar, long j6, long j11) {
        this.f20634a = bVar;
        this.f20635b = j6;
        this.f20636c = j11;
    }
}
