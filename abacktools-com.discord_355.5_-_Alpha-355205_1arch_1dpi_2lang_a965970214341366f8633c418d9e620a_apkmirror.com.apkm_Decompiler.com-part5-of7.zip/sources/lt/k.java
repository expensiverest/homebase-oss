package lt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import n3.l0;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public final class k implements bt.g, l5.d {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f20663d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f20664e;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long[] f20665i;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final long[] f20666v;

    public k(int i11, ArrayList arrayList) {
        this.f20663d = i11;
        switch (i11) {
            case 1:
                this.f20664e = Collections.unmodifiableList(new ArrayList(arrayList));
                this.f20665i = new long[arrayList.size() * 2];
                for (int i12 = 0; i12 < arrayList.size(); i12++) {
                    u5.c cVar = (u5.c) arrayList.get(i12);
                    int i13 = i12 * 2;
                    long[] jArr = this.f20665i;
                    jArr[i13] = cVar.f30896b;
                    jArr[i13 + 1] = cVar.f30897c;
                }
                long[] jArr2 = this.f20665i;
                long[] jArrCopyOf = Arrays.copyOf(jArr2, jArr2.length);
                this.f20666v = jArrCopyOf;
                Arrays.sort(jArrCopyOf);
                break;
            default:
                this.f20664e = Collections.unmodifiableList(new ArrayList(arrayList));
                this.f20665i = new long[arrayList.size() * 2];
                for (int i14 = 0; i14 < arrayList.size(); i14++) {
                    c cVar2 = (c) arrayList.get(i14);
                    int i15 = i14 * 2;
                    long[] jArr3 = this.f20665i;
                    jArr3[i15] = cVar2.f20635b;
                    jArr3[i15 + 1] = cVar2.f20636c;
                }
                long[] jArr4 = this.f20665i;
                long[] jArrCopyOf2 = Arrays.copyOf(jArr4, jArr4.length);
                this.f20666v = jArrCopyOf2;
                Arrays.sort(jArrCopyOf2);
                break;
        }
    }

    @Override // bt.g
    public final int c(long j6) {
        switch (this.f20663d) {
            case 0:
                long[] jArr = this.f20666v;
                int iB = x.b(jArr, j6, false);
                if (iB < jArr.length) {
                    return iB;
                }
                return -1;
            default:
                long[] jArr2 = this.f20666v;
                int iB2 = l0.b(jArr2, j6, false);
                if (iB2 < jArr2.length) {
                    return iB2;
                }
                return -1;
        }
    }

    @Override // bt.g
    public final long d(int i11) {
        switch (this.f20663d) {
            case 0:
                qt.a.g(i11 >= 0);
                long[] jArr = this.f20666v;
                qt.a.g(i11 < jArr.length);
                return jArr[i11];
            default:
                oq.a.n(i11 >= 0);
                long[] jArr2 = this.f20666v;
                oq.a.n(i11 < jArr2.length);
                return jArr2[i11];
        }
    }

    @Override // bt.g
    public final List e(long j6) {
        switch (this.f20663d) {
            case 0:
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                int i11 = 0;
                while (true) {
                    List list = this.f20664e;
                    if (i11 >= list.size()) {
                        break;
                    }
                    int i12 = i11 * 2;
                    long[] jArr = this.f20665i;
                    if (jArr[i12] <= j6 && j6 < jArr[i12 + 1]) {
                        c cVar = (c) list.get(i11);
                        bt.b bVar = cVar.f20634a;
                        if (bVar.f4142w == -3.4028235E38f) {
                            arrayList2.add(cVar);
                        } else {
                            arrayList.add(bVar);
                        }
                    }
                    i11++;
                }
                Collections.sort(arrayList2, new a4.h(18));
                for (int i13 = 0; i13 < arrayList2.size(); i13++) {
                    bt.a aVarA = ((c) arrayList2.get(i13)).f20634a.a();
                    aVarA.f4115e = (-1) - i13;
                    aVarA.f4116f = 1;
                    arrayList.add(aVarA.a());
                }
                return arrayList;
            default:
                ArrayList arrayList3 = new ArrayList();
                ArrayList arrayList4 = new ArrayList();
                int i14 = 0;
                while (true) {
                    List list2 = this.f20664e;
                    if (i14 >= list2.size()) {
                        break;
                    }
                    int i15 = i14 * 2;
                    long[] jArr2 = this.f20665i;
                    if (jArr2[i15] <= j6 && j6 < jArr2[i15 + 1]) {
                        u5.c cVar2 = (u5.c) list2.get(i14);
                        m3.b bVar2 = cVar2.f30895a;
                        if (bVar2.f20815e == -3.4028235E38f) {
                            arrayList4.add(cVar2);
                        } else {
                            arrayList3.add(bVar2);
                        }
                    }
                    i14++;
                }
                Collections.sort(arrayList4, new o10.g(6));
                for (int i16 = 0; i16 < arrayList4.size(); i16++) {
                    m3.a aVarA2 = ((u5.c) arrayList4.get(i16)).f30895a.a();
                    aVarA2.f20792e = (-1) - i16;
                    aVarA2.f20793f = 1;
                    arrayList3.add(aVarA2.a());
                }
                return arrayList3;
        }
    }

    @Override // bt.g
    public final int i() {
        switch (this.f20663d) {
            case 0:
                break;
        }
        return this.f20666v.length;
    }
}
