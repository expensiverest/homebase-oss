package lt;

import java.util.Set;

/* JADX INFO: loaded from: classes3.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f20640a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f20641b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f20642c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Set f20643d;

    public e(String str, int i11, String str2, Set set) {
        this.f20641b = i11;
        this.f20640a = str;
        this.f20642c = str2;
        this.f20643d = set;
    }
}
