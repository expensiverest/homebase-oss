package lt;

import android.text.TextUtils;
import app.p001rive.runtime.kotlin.fonts.Fonts;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import k80.l;
import mr.k1;
import qt.q;
import qt.x;

/* JADX INFO: loaded from: classes3.dex */
public final class i extends bt.f {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final q f20660m = new q();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final a f20661n = new a();

    /* JADX WARN: Code duplicated, block: B:120:0x0229  */
    /* JADX WARN: Code duplicated, block: B:129:0x024a  */
    /* JADX WARN: Code duplicated, block: B:130:0x0255  */
    /* JADX WARN: Code duplicated, block: B:132:0x025e  */
    /* JADX WARN: Code duplicated, block: B:133:0x0268  */
    /* JADX WARN: Code duplicated, block: B:135:0x0270  */
    /* JADX WARN: Code duplicated, block: B:137:0x0278  */
    /* JADX WARN: Code duplicated, block: B:138:0x027c  */
    /* JADX WARN: Code duplicated, block: B:140:0x0284  */
    /* JADX WARN: Code duplicated, block: B:141:0x028b  */
    /* JADX WARN: Code duplicated, block: B:143:0x0293  */
    /* JADX WARN: Code duplicated, block: B:149:0x02a6  */
    /* JADX WARN: Code duplicated, block: B:151:0x02ab  */
    /* JADX WARN: Code duplicated, block: B:153:0x02b3  */
    /* JADX WARN: Code duplicated, block: B:155:0x02bb  */
    /* JADX WARN: Code duplicated, block: B:156:0x02bf  */
    /* JADX WARN: Code duplicated, block: B:158:0x02c7  */
    /* JADX WARN: Code duplicated, block: B:159:0x02cf  */
    /* JADX WARN: Code duplicated, block: B:161:0x02d7  */
    /* JADX WARN: Code duplicated, block: B:163:0x02df  */
    /* JADX WARN: Code duplicated, block: B:164:0x02e3  */
    /* JADX WARN: Code duplicated, block: B:166:0x02ec  */
    /* JADX WARN: Code duplicated, block: B:168:0x02f4  */
    /* JADX WARN: Code duplicated, block: B:170:0x02f9  */
    /* JADX WARN: Code duplicated, block: B:172:0x0301  */
    /* JADX WARN: Code duplicated, block: B:174:0x0311  */
    /* JADX WARN: Code duplicated, block: B:175:0x032b  */
    /* JADX WARN: Code duplicated, block: B:178:0x033c  */
    /* JADX WARN: Code duplicated, block: B:181:0x0345  */
    /* JADX WARN: Code duplicated, block: B:182:0x0347  */
    /* JADX WARN: Code duplicated, block: B:185:0x0350  */
    /* JADX WARN: Code duplicated, block: B:186:0x0352  */
    /* JADX WARN: Code duplicated, block: B:189:0x035b  */
    /* JADX WARN: Code duplicated, block: B:193:0x0365  */
    /* JADX WARN: Code duplicated, block: B:194:0x036a  */
    /* JADX WARN: Code duplicated, block: B:195:0x036f  */
    /* JADX WARN: Code duplicated, block: B:197:0x0382  */
    /* JADX WARN: Code duplicated, block: B:238:0x035f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:37:0x00a5  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Instruction removed from duplicated block: B:174:0x0311, please report this as an issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v18 */
    /* JADX WARN: Type inference failed for: r13v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r13v20 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r4v48 */
    /* JADX WARN: Type inference failed for: r4v49 */
    /* JADX WARN: Type inference failed for: r4v50 */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v13 */
    /* JADX WARN: Type inference failed for: r7v16 */
    @Override // bt.f
    public final bt.g e(int i11, boolean z11, byte[] bArr) throws bt.i {
        int i12;
        c cVarD;
        String strTrim;
        int i13;
        String string;
        int i14;
        Matcher matcher;
        String strGroup;
        byte b11;
        boolean z12;
        i iVar = this;
        q qVar = iVar.f20660m;
        qVar.D(bArr, i11);
        ArrayList arrayList = new ArrayList();
        try {
            j.d(qVar);
            while (!TextUtils.isEmpty(qVar.h(gx.j.f13622c))) {
            }
            ArrayList arrayList2 = new ArrayList();
            while (true) {
                boolean z13 = false;
                int i15 = -1;
                int i16 = 0;
                byte b12 = -1;
                while (true) {
                    i12 = 1;
                    if (b12 != -1) {
                        break;
                    }
                    i16 = qVar.f27305b;
                    String strH = qVar.h(gx.j.f13622c);
                    if (strH == null) {
                        b12 = 0;
                    } else if ("STYLE".equals(strH)) {
                        b12 = 2;
                    } else {
                        b12 = strH.startsWith("NOTE") ? (byte) 1 : (byte) 3;
                    }
                }
                qVar.F(i16);
                if (b12 == 0) {
                    return new k(0, arrayList2);
                }
                if (b12 == 1) {
                    while (!TextUtils.isEmpty(qVar.h(gx.j.f13622c))) {
                    }
                } else {
                    String str = null;
                    if (b12 == 2) {
                        if (!arrayList2.isEmpty()) {
                            throw new bt.i("A style block was found after the first cue.");
                        }
                        qVar.h(gx.j.f13622c);
                        a aVar = iVar.f20661n;
                        q qVar2 = aVar.f20617a;
                        StringBuilder sb2 = aVar.f20618b;
                        sb2.setLength(0);
                        int i17 = qVar.f27305b;
                        while (!TextUtils.isEmpty(qVar.h(gx.j.f13622c))) {
                        }
                        qVar2.D(qVar.f27304a, qVar.f27305b);
                        qVar2.F(i17);
                        ArrayList arrayList3 = new ArrayList();
                        while (true) {
                            a.c(qVar2);
                            if (qVar2.a() >= 5 && "::cue".equals(qVar2.s(5, gx.j.f13622c))) {
                                int i18 = qVar2.f27305b;
                                String strB = a.b(qVar2, sb2);
                                if (strB == null) {
                                    strTrim = str;
                                } else if ("{".equals(strB)) {
                                    qVar2.F(i18);
                                    strTrim = "";
                                } else {
                                    if ("(".equals(strB)) {
                                        int i19 = qVar2.f27305b;
                                        int i21 = qVar2.f27306c;
                                        int i22 = z13 ? 1 : 0;
                                        while (i19 < i21 && i22 == 0) {
                                            int i23 = i19 + 1;
                                            i22 = ((char) qVar2.f27304a[i19]) == ')' ? i12 : z13 ? 1 : 0;
                                            i19 = i23;
                                        }
                                        strTrim = qVar2.s((i19 - 1) - qVar2.f27305b, gx.j.f13622c).trim();
                                    } else {
                                        strTrim = str;
                                    }
                                    if (!")".equals(a.b(qVar2, sb2))) {
                                        strTrim = str;
                                    }
                                }
                            } else {
                                strTrim = str;
                            }
                            if (strTrim == null || !"{".equals(a.b(qVar2, sb2))) {
                                break;
                            }
                            b bVar = new b();
                            bVar.f20619a = "";
                            bVar.f20620b = "";
                            bVar.f20621c = Collections.EMPTY_SET;
                            bVar.f20622d = "";
                            bVar.f20623e = str;
                            bVar.f20625g = z13;
                            bVar.f20627i = z13;
                            bVar.f20628j = i15;
                            bVar.k = i15;
                            bVar.l = i15;
                            bVar.f20629m = i15;
                            bVar.f20630n = i15;
                            bVar.f20632p = i15;
                            bVar.f20633q = z13;
                            if (!"".equals(strTrim)) {
                                int iIndexOf = strTrim.indexOf(91);
                                if (iIndexOf != i15) {
                                    Matcher matcher2 = a.f20615c.matcher(strTrim.substring(iIndexOf));
                                    if (matcher2.matches()) {
                                        String strGroup2 = matcher2.group(i12);
                                        strGroup2.getClass();
                                        bVar.f20622d = strGroup2;
                                    }
                                    strTrim = strTrim.substring(z13 ? 1 : 0, iIndexOf);
                                }
                                int i24 = x.f27318a;
                                String[] strArrSplit = strTrim.split("\\.", i15);
                                String str2 = strArrSplit[z13 ? 1 : 0];
                                int iIndexOf2 = str2.indexOf(35);
                                if (iIndexOf2 != i15) {
                                    bVar.f20620b = str2.substring(z13 ? 1 : 0, iIndexOf2);
                                    bVar.f20619a = str2.substring(iIndexOf2 + 1);
                                } else {
                                    bVar.f20620b = str2;
                                }
                                if (strArrSplit.length > i12) {
                                    int length = strArrSplit.length;
                                    qt.a.g(length <= strArrSplit.length ? i12 : z13 ? 1 : 0);
                                    bVar.f20621c = new HashSet(Arrays.asList((String[]) Arrays.copyOfRange(strArrSplit, i12, length)));
                                }
                            }
                            ?? r11 = z13 ? 1 : 0;
                            String strB2 = null;
                            while (r11 == 0) {
                                int i25 = qVar2.f27305b;
                                strB2 = a.b(qVar2, sb2);
                                ?? r14 = (strB2 == null || "}".equals(strB2)) ? i12 : z13;
                                if (r14 == 0) {
                                    qVar2.F(i25);
                                    a.c(qVar2);
                                    String strA = a.a(qVar2, sb2);
                                    if (!"".equals(strA) && ":".equals(a.b(qVar2, sb2))) {
                                        a.c(qVar2);
                                        StringBuilder sb3 = new StringBuilder();
                                        boolean z14 = false;
                                        while (true) {
                                            if (z14) {
                                                string = sb3.toString();
                                                break;
                                            }
                                            int i26 = qVar2.f27305b;
                                            boolean z15 = z14;
                                            String strB3 = a.b(qVar2, sb2);
                                            if (strB3 == null) {
                                                string = null;
                                                break;
                                            }
                                            if ("}".equals(strB3) || ";".equals(strB3)) {
                                                qVar2.F(i26);
                                                z14 = true;
                                            } else {
                                                sb3.append(strB3);
                                                z14 = z15;
                                            }
                                        }
                                        if (string == null || "".equals(string)) {
                                            i13 = 1;
                                        } else {
                                            int i27 = qVar2.f27305b;
                                            String strB4 = a.b(qVar2, sb2);
                                            if (";".equals(strB4)) {
                                                if ("color".equals(strA)) {
                                                    i14 = 1;
                                                    bVar.f20624f = qt.b.a(string, true);
                                                    bVar.f20625g = true;
                                                } else {
                                                    i14 = 1;
                                                    if ("background-color".equals(strA)) {
                                                        bVar.f20626h = qt.b.a(string, true);
                                                        bVar.f20627i = true;
                                                    } else if ("ruby-position".equals(strA)) {
                                                        if ("text-combine-upright".equals(strA)) {
                                                            if ("all".equals(string)) {
                                                                z12 = true;
                                                            } else {
                                                                z12 = true;
                                                            }
                                                            bVar.f20633q = z12;
                                                        } else if ("text-decoration".equals(strA)) {
                                                            if ("underline".equals(string)) {
                                                                i14 = 1;
                                                                bVar.k = 1;
                                                            }
                                                        } else if ("font-family".equals(strA)) {
                                                            bVar.f20623e = l.Z(string);
                                                        } else if ("font-weight".equals(strA)) {
                                                            i14 = 1;
                                                            if ("font-style".equals(strA)) {
                                                                if (Fonts.Font.STYLE_ITALIC.equals(string)) {
                                                                    bVar.f20629m = 1;
                                                                }
                                                            } else if ("font-size".equals(strA)) {
                                                                matcher = a.f20616d.matcher(l.Z(string));
                                                                if (matcher.matches()) {
                                                                    strGroup = matcher.group(2);
                                                                    strGroup.getClass();
                                                                    switch (strGroup.hashCode()) {
                                                                        case 37:
                                                                            if (!strGroup.equals("%")) {
                                                                                b11 = 0;
                                                                            }
                                                                            switch (b11) {
                                                                                case 0:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 3;
                                                                                    break;
                                                                                case 1:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 2;
                                                                                    break;
                                                                                case 2:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 1;
                                                                                    break;
                                                                                default:
                                                                                    throw new IllegalStateException();
                                                                            }
                                                                            String strGroup3 = matcher.group(i13);
                                                                            strGroup3.getClass();
                                                                            bVar.f20631o = Float.parseFloat(strGroup3);
                                                                            break;
                                                                        case 3240:
                                                                            if (!strGroup.equals("em")) {
                                                                                b11 = 1;
                                                                            }
                                                                            switch (b11) {
                                                                                case 0:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 3;
                                                                                    break;
                                                                                case 1:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 2;
                                                                                    break;
                                                                                case 2:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 1;
                                                                                    break;
                                                                                default:
                                                                                    throw new IllegalStateException();
                                                                            }
                                                                            String strGroup4 = matcher.group(i13);
                                                                            strGroup4.getClass();
                                                                            bVar.f20631o = Float.parseFloat(strGroup4);
                                                                            break;
                                                                        case 3592:
                                                                            if (!strGroup.equals("px")) {
                                                                                b11 = 2;
                                                                            }
                                                                            switch (b11) {
                                                                                case 0:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 3;
                                                                                    break;
                                                                                case 1:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 2;
                                                                                    break;
                                                                                case 2:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 1;
                                                                                    break;
                                                                                default:
                                                                                    throw new IllegalStateException();
                                                                            }
                                                                            String strGroup5 = matcher.group(i13);
                                                                            strGroup5.getClass();
                                                                            bVar.f20631o = Float.parseFloat(strGroup5);
                                                                            break;
                                                                    }
                                                                    b11 = -1;
                                                                    switch (b11) {
                                                                        case 0:
                                                                            i13 = 1;
                                                                            bVar.f20630n = 3;
                                                                            break;
                                                                        case 1:
                                                                            i13 = 1;
                                                                            bVar.f20630n = 2;
                                                                            break;
                                                                        case 2:
                                                                            i13 = 1;
                                                                            bVar.f20630n = 1;
                                                                            break;
                                                                        default:
                                                                            throw new IllegalStateException();
                                                                    }
                                                                    String strGroup6 = matcher.group(i13);
                                                                    strGroup6.getClass();
                                                                    bVar.f20631o = Float.parseFloat(strGroup6);
                                                                } else {
                                                                    qt.a.N("WebvttCssParser", "Invalid font-size: '" + string + "'.");
                                                                }
                                                            }
                                                        } else if ("bold".equals(string)) {
                                                            i14 = 1;
                                                            bVar.l = 1;
                                                        }
                                                        i13 = 1;
                                                    } else if ("over".equals(string)) {
                                                        bVar.f20632p = 1;
                                                    } else if ("under".equals(string)) {
                                                        bVar.f20632p = 2;
                                                        i13 = 1;
                                                    } else {
                                                        i13 = 1;
                                                    }
                                                }
                                                i13 = i14;
                                            } else if ("}".equals(strB4)) {
                                                qVar2.F(i27);
                                                if ("color".equals(strA)) {
                                                    i14 = 1;
                                                    bVar.f20624f = qt.b.a(string, true);
                                                    bVar.f20625g = true;
                                                } else {
                                                    i14 = 1;
                                                    if ("background-color".equals(strA)) {
                                                        bVar.f20626h = qt.b.a(string, true);
                                                        bVar.f20627i = true;
                                                    } else if ("ruby-position".equals(strA)) {
                                                        if ("text-combine-upright".equals(strA)) {
                                                            if ("all".equals(string) || string.startsWith("digits")) {
                                                                z12 = true;
                                                            } else {
                                                                z12 = false;
                                                            }
                                                            bVar.f20633q = z12;
                                                        } else if ("text-decoration".equals(strA)) {
                                                            if ("underline".equals(string)) {
                                                                i14 = 1;
                                                                bVar.k = 1;
                                                            }
                                                        } else if ("font-family".equals(strA)) {
                                                            bVar.f20623e = l.Z(string);
                                                        } else if ("font-weight".equals(strA)) {
                                                            i14 = 1;
                                                            if ("font-style".equals(strA)) {
                                                                if (Fonts.Font.STYLE_ITALIC.equals(string)) {
                                                                    bVar.f20629m = 1;
                                                                }
                                                            } else if ("font-size".equals(strA)) {
                                                                matcher = a.f20616d.matcher(l.Z(string));
                                                                if (matcher.matches()) {
                                                                    qt.a.N("WebvttCssParser", "Invalid font-size: '" + string + "'.");
                                                                } else {
                                                                    strGroup = matcher.group(2);
                                                                    strGroup.getClass();
                                                                    switch (strGroup.hashCode()) {
                                                                        case 37:
                                                                            if (!strGroup.equals("%")) {
                                                                                b11 = 0;
                                                                            }
                                                                            switch (b11) {
                                                                                case 0:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 3;
                                                                                    break;
                                                                                case 1:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 2;
                                                                                    break;
                                                                                case 2:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 1;
                                                                                    break;
                                                                                default:
                                                                                    throw new IllegalStateException();
                                                                            }
                                                                            String strGroup7 = matcher.group(i13);
                                                                            strGroup7.getClass();
                                                                            bVar.f20631o = Float.parseFloat(strGroup7);
                                                                            break;
                                                                        case 3240:
                                                                            if (!strGroup.equals("em")) {
                                                                                b11 = 1;
                                                                            }
                                                                            switch (b11) {
                                                                                case 0:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 3;
                                                                                    break;
                                                                                case 1:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 2;
                                                                                    break;
                                                                                case 2:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 1;
                                                                                    break;
                                                                                default:
                                                                                    throw new IllegalStateException();
                                                                            }
                                                                            String strGroup8 = matcher.group(i13);
                                                                            strGroup8.getClass();
                                                                            bVar.f20631o = Float.parseFloat(strGroup8);
                                                                            break;
                                                                        case 3592:
                                                                            if (!strGroup.equals("px")) {
                                                                                b11 = 2;
                                                                            }
                                                                            switch (b11) {
                                                                                case 0:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 3;
                                                                                    break;
                                                                                case 1:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 2;
                                                                                    break;
                                                                                case 2:
                                                                                    i13 = 1;
                                                                                    bVar.f20630n = 1;
                                                                                    break;
                                                                                default:
                                                                                    throw new IllegalStateException();
                                                                            }
                                                                            String strGroup9 = matcher.group(i13);
                                                                            strGroup9.getClass();
                                                                            bVar.f20631o = Float.parseFloat(strGroup9);
                                                                            break;
                                                                    }
                                                                    b11 = -1;
                                                                    switch (b11) {
                                                                        case 0:
                                                                            i13 = 1;
                                                                            bVar.f20630n = 3;
                                                                            break;
                                                                        case 1:
                                                                            i13 = 1;
                                                                            bVar.f20630n = 2;
                                                                            break;
                                                                        case 2:
                                                                            i13 = 1;
                                                                            bVar.f20630n = 1;
                                                                            break;
                                                                        default:
                                                                            throw new IllegalStateException();
                                                                    }
                                                                    String strGroup10 = matcher.group(i13);
                                                                    strGroup10.getClass();
                                                                    bVar.f20631o = Float.parseFloat(strGroup10);
                                                                }
                                                            }
                                                        } else if ("bold".equals(string)) {
                                                            i14 = 1;
                                                            bVar.l = 1;
                                                        }
                                                        i13 = 1;
                                                    } else if ("over".equals(string)) {
                                                        bVar.f20632p = 1;
                                                    } else if ("under".equals(string)) {
                                                        bVar.f20632p = 2;
                                                        i13 = 1;
                                                    } else {
                                                        i13 = 1;
                                                    }
                                                }
                                                i13 = i14;
                                            } else {
                                                i13 = 1;
                                            }
                                        }
                                    } else {
                                        i13 = i12;
                                    }
                                } else {
                                    i13 = i12;
                                }
                                i12 = i13;
                                r11 = r14;
                                z13 = false;
                            }
                            int i28 = i12;
                            if ("}".equals(strB2)) {
                                arrayList3.add(bVar);
                            }
                            i12 = i28;
                            z13 = false;
                            i15 = -1;
                            str = null;
                        }
                        arrayList.addAll(arrayList3);
                    } else if (b12 == 3) {
                        Pattern pattern = h.f20656a;
                        Charset charset = gx.j.f13622c;
                        String strH2 = qVar.h(charset);
                        if (strH2 == null) {
                            cVarD = null;
                        } else {
                            Pattern pattern2 = h.f20656a;
                            Matcher matcher3 = pattern2.matcher(strH2);
                            if (matcher3.matches()) {
                                cVarD = h.d(null, matcher3, qVar, arrayList);
                            } else {
                                cVarD = null;
                                String strH3 = qVar.h(charset);
                                if (strH3 != null) {
                                    Matcher matcher4 = pattern2.matcher(strH3);
                                    if (matcher4.matches()) {
                                        cVarD = h.d(strH2.trim(), matcher4, qVar, arrayList);
                                    }
                                }
                            }
                        }
                        if (cVarD != null) {
                            arrayList2.add(cVarD);
                        }
                    }
                    iVar = this;
                }
            }
        } catch (k1 e4) {
            throw new bt.i(e4);
        }
    }
}
