package lt;

/* JADX INFO: loaded from: classes3.dex */
public final class f implements Comparable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f20644d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final b f20645e;

    public f(int i11, b bVar) {
        this.f20644d = i11;
        this.f20645e = bVar;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return Integer.compare(this.f20644d, ((f) obj).f20644d);
    }
}
