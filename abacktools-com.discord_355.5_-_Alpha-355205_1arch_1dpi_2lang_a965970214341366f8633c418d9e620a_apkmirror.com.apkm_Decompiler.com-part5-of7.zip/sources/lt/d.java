package lt;

/* JADX INFO: loaded from: classes3.dex */
public final class d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a4.h f20637c = new a4.h(17);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f20638a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f20639b;

    public d(e eVar, int i11) {
        this.f20638a = eVar;
        this.f20639b = i11;
    }
}
