package lt;

import java.util.regex.Pattern;
import qt.q;

/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Pattern f20615c = Pattern.compile("\\[voice=\"([^\"]*)\"\\]");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Pattern f20616d = Pattern.compile("^((?:[0-9]*\\.)?[0-9]+)(px|em|%)$");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q f20617a = new q();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final StringBuilder f20618b = new StringBuilder();

    public static String a(q qVar, StringBuilder sb2) {
        boolean z11 = false;
        sb2.setLength(0);
        int i11 = qVar.f27305b;
        int i12 = qVar.f27306c;
        while (i11 < i12 && !z11) {
            char c11 = (char) qVar.f27304a[i11];
            if ((c11 < 'A' || c11 > 'Z') && ((c11 < 'a' || c11 > 'z') && !((c11 >= '0' && c11 <= '9') || c11 == '#' || c11 == '-' || c11 == '.' || c11 == '_'))) {
                z11 = true;
            } else {
                i11++;
                sb2.append(c11);
            }
        }
        qVar.G(i11 - qVar.f27305b);
        return sb2.toString();
    }

    public static String b(q qVar, StringBuilder sb2) {
        c(qVar);
        if (qVar.a() == 0) {
            return null;
        }
        String strA = a(qVar, sb2);
        if (!"".equals(strA)) {
            return strA;
        }
        return "" + ((char) qVar.u());
    }

    public static void c(q qVar) {
        while (true) {
            boolean z11 = true;
            while (true) {
                if (qVar.a() <= 0 || !z11) {
                    return;
                }
                int i11 = qVar.f27305b;
                byte[] bArr = qVar.f27304a;
                byte b11 = bArr[i11];
                char c11 = (char) b11;
                if (c11 == '\t' || c11 == '\n' || c11 == '\f' || c11 == '\r' || c11 == ' ') {
                    qVar.G(1);
                    break;
                }
                int i12 = qVar.f27306c;
                int i13 = i11 + 2;
                if (i13 <= i12) {
                    int i14 = i11 + 1;
                    if (b11 == 47 && bArr[i14] == 42) {
                        while (true) {
                            int i15 = i13 + 1;
                            if (i15 >= i12) {
                                break;
                            }
                            if (((char) bArr[i13]) == '*' && ((char) bArr[i15]) == '/') {
                                i13 += 2;
                                i12 = i13;
                            } else {
                                i13 = i15;
                            }
                        }
                        qVar.G(i12 - qVar.f27305b);
                        break;
                    }
                }
                z11 = false;
            }
        }
    }
}
