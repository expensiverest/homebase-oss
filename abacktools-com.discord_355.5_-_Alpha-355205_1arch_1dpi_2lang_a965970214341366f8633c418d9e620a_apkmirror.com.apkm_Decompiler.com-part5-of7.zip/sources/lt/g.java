package lt;

import android.text.Layout;
import hs.q;

/* JADX INFO: loaded from: classes3.dex */
public final class g {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f20648c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f20646a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f20647b = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f20649d = 2;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f20650e = -3.4028235E38f;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f20651f = 1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f20652g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f20653h = -3.4028235E38f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f20654i = androidx.customview.widget.b.INVALID_ID;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f20655j = 1.0f;
    public int k = androidx.customview.widget.b.INVALID_ID;

    /* JADX WARN: Code duplicated, block: B:20:0x0032  */
    /* JADX WARN: Code duplicated, block: B:21:0x0034  */
    /* JADX WARN: Code duplicated, block: B:29:0x004f  */
    /* JADX WARN: Code duplicated, block: B:31:0x0055  */
    /* JADX WARN: Code duplicated, block: B:39:0x006b  */
    public bt.a a() {
        Layout.Alignment alignment;
        float f3 = this.f20653h;
        float f11 = -3.4028235E38f;
        if (f3 == -3.4028235E38f) {
            int i11 = this.f20649d;
            if (i11 != 4) {
                f3 = i11 != 5 ? 0.5f : 1.0f;
            } else {
                f3 = 0.0f;
            }
        }
        int i12 = this.f20654i;
        if (i12 == Integer.MIN_VALUE) {
            int i13 = this.f20649d;
            if (i13 == 1) {
                i12 = 0;
            } else if (i13 == 3) {
                i12 = 2;
            } else if (i13 == 4) {
                i12 = 0;
            } else if (i13 != 5) {
                i12 = 1;
            } else {
                i12 = 2;
            }
        }
        bt.a aVar = new bt.a();
        int i14 = this.f20649d;
        if (i14 == 1) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i14 == 2) {
            alignment = Layout.Alignment.ALIGN_CENTER;
        } else if (i14 == 3) {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        } else if (i14 == 4) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i14 != 5) {
            q.x(i14, "Unknown textAlignment: ", "WebvttCueParser");
            alignment = null;
        } else {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        }
        aVar.f4113c = alignment;
        float f12 = this.f20650e;
        int i15 = this.f20651f;
        if (f12 != -3.4028235E38f && i15 == 0 && (f12 < 0.0f || f12 > 1.0f)) {
            f11 = 1.0f;
        } else if (f12 != -3.4028235E38f) {
            f11 = f12;
        } else if (i15 == 0) {
            f11 = 1.0f;
        }
        aVar.f4115e = f11;
        aVar.f4116f = i15;
        aVar.f4117g = this.f20652g;
        aVar.f4118h = f3;
        aVar.f4119i = i12;
        float f13 = this.f20655j;
        if (i12 == 0) {
            f3 = 1.0f - f3;
        } else if (i12 == 1) {
            f3 = f3 <= 0.5f ? f3 * 2.0f : (1.0f - f3) * 2.0f;
        } else if (i12 != 2) {
            throw new IllegalStateException(String.valueOf(i12));
        }
        aVar.l = Math.min(f13, f3);
        aVar.f4124p = this.k;
        CharSequence charSequence = this.f20648c;
        if (charSequence != null) {
            aVar.f4111a = charSequence;
        }
        return aVar;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0032  */
    /* JADX WARN: Code duplicated, block: B:21:0x0034  */
    /* JADX WARN: Code duplicated, block: B:29:0x0050  */
    /* JADX WARN: Code duplicated, block: B:31:0x0056  */
    /* JADX WARN: Code duplicated, block: B:39:0x006c  */
    public m3.a b() {
        Layout.Alignment alignment;
        float f3 = this.f20653h;
        float f11 = -3.4028235E38f;
        if (f3 == -3.4028235E38f) {
            int i11 = this.f20649d;
            if (i11 != 4) {
                f3 = i11 != 5 ? 0.5f : 1.0f;
            } else {
                f3 = 0.0f;
            }
        }
        int i12 = this.f20654i;
        if (i12 == Integer.MIN_VALUE) {
            int i13 = this.f20649d;
            if (i13 == 1) {
                i12 = 0;
            } else if (i13 == 3) {
                i12 = 2;
            } else if (i13 == 4) {
                i12 = 0;
            } else if (i13 != 5) {
                i12 = 1;
            } else {
                i12 = 2;
            }
        }
        m3.a aVar = new m3.a();
        int i14 = this.f20649d;
        if (i14 == 1) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i14 == 2) {
            alignment = Layout.Alignment.ALIGN_CENTER;
        } else if (i14 == 3) {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        } else if (i14 == 4) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i14 != 5) {
            q.r(i14, "Unknown textAlignment: ", "WebvttCueParser");
            alignment = null;
        } else {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        }
        aVar.f20790c = alignment;
        float f12 = this.f20650e;
        int i15 = this.f20651f;
        if (f12 != -3.4028235E38f && i15 == 0 && (f12 < 0.0f || f12 > 1.0f)) {
            f11 = 1.0f;
        } else if (f12 != -3.4028235E38f) {
            f11 = f12;
        } else if (i15 == 0) {
            f11 = 1.0f;
        }
        aVar.f20792e = f11;
        aVar.f20793f = i15;
        aVar.f20794g = this.f20652g;
        aVar.f20795h = f3;
        aVar.f20796i = i12;
        float f13 = this.f20655j;
        if (i12 == 0) {
            f3 = 1.0f - f3;
        } else if (i12 == 1) {
            f3 = f3 <= 0.5f ? f3 * 2.0f : (1.0f - f3) * 2.0f;
        } else if (i12 != 2) {
            throw new IllegalStateException(String.valueOf(i12));
        }
        aVar.l = Math.min(f13, f3);
        aVar.f20801p = this.k;
        CharSequence charSequence = this.f20648c;
        if (charSequence != null) {
            aVar.f20788a = charSequence;
            aVar.f20789b = null;
        }
        return aVar;
    }
}
